var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052911948092a0704114807f4d717494df9f054e"] = {
  "startTime": "2018-05-29T17:16:11.3755817Z",
  "websitePageUrl": "/16",
  "visitTime": 116185,
  "engagementTime": 89308,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "6e926f8f0a7d38521c721dd2947bd17b",
    "created": "2018-05-29T17:16:11.3755817+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=RRF03",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "22cd799f566b99bad6f95ec597d685d4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6e926f8f0a7d38521c721dd2947bd17b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 193,
      "e": 193,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 193,
      "e": 193,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 560,
      "y": 609
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 52035,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 6,
      "x": 566,
      "y": 570,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 570,
      "y": 545
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 53159,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3279,
      "e": 3279,
      "ty": 3,
      "x": 570,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3281,
      "e": 3281,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3374,
      "e": 3374,
      "ty": 4,
      "x": 53159,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3374,
      "e": 3374,
      "ty": 5,
      "x": 570,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 577,
      "y": 551
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 54058,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 578,
      "y": 554
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 581,
      "y": 565
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 54395,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 582,
      "y": 584
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 582,
      "y": 591
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 54508,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 582,
      "y": 592
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 582,
      "y": 594
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 54508,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8224,
      "e": 8224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 8225,
      "e": 8225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8302,
      "e": 8302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8302,
      "e": 8302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8310,
      "e": 8310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yo"
    },
    {
      "t": 8350,
      "e": 8350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yo"
    },
    {
      "t": 8511,
      "e": 8511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 8511,
      "e": 8511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8574,
      "e": 8574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you"
    },
    {
      "t": 8766,
      "e": 8766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8767,
      "e": 8767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8830,
      "e": 8830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you "
    },
    {
      "t": 10005,
      "e": 10005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10112,
      "e": 10112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10112,
      "e": 10112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10190,
      "e": 10190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10375,
      "e": 10375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10376,
      "e": 10376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10471,
      "e": 10471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 10478,
      "e": 10478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10479,
      "e": 10479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10527,
      "e": 10527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 10631,
      "e": 10631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10631,
      "e": 10631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10686,
      "e": 10686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 10694,
      "e": 10694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10694,
      "e": 10694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10758,
      "e": 10758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11231,
      "e": 11231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11231,
      "e": 11231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11270,
      "e": 11270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 11407,
      "e": 11407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 1"
    },
    {
      "t": 11599,
      "e": 11599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11600,
      "e": 11600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11638,
      "e": 11638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 12446,
      "e": 12446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 12447,
      "e": 12447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12510,
      "e": 12510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 12679,
      "e": 12679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12680,
      "e": 12680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12726,
      "e": 12726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 12838,
      "e": 12838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12839,
      "e": 12839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12902,
      "e": 12902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13007,
      "e": 13007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm "
    },
    {
      "t": 13038,
      "e": 13038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13039,
      "e": 13039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13095,
      "e": 13095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13207,
      "e": 13207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm o"
    },
    {
      "t": 13255,
      "e": 13255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13256,
      "e": 13256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13303,
      "e": 13303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 13407,
      "e": 13407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on"
    },
    {
      "t": 13686,
      "e": 13686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13688,
      "e": 13688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13750,
      "e": 13750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13991,
      "e": 13991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13992,
      "e": 13992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14053,
      "e": 14053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14655,
      "e": 14655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14655,
      "e": 14655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14694,
      "e": 14694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14781,
      "e": 14781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14783,
      "e": 14783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14855,
      "e": 14855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14886,
      "e": 14886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14887,
      "e": 14887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14950,
      "e": 14950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15223,
      "e": 15223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15224,
      "e": 15224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15309,
      "e": 15309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15608,
      "e": 15608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15663,
      "e": 15663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the "
    },
    {
      "t": 15807,
      "e": 15807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the "
    },
    {
      "t": 15830,
      "e": 15830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 15831,
      "e": 15831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15902,
      "e": 15902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16006,
      "e": 16006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the x"
    },
    {
      "t": 16158,
      "e": 16158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16206,
      "e": 16206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the "
    },
    {
      "t": 16463,
      "e": 16463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 16463,
      "e": 16463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16470,
      "e": 16470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16606,
      "e": 16606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the \n"
    },
    {
      "t": 16702,
      "e": 16702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 16727,
      "e": 16727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17102,
      "e": 17102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17158,
      "e": 17158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the "
    },
    {
      "t": 17822,
      "e": 17822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17927,
      "e": 17927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17928,
      "e": 17928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17958,
      "e": 17958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 17981,
      "e": 17981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18199,
      "e": 18199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 18200,
      "e": 18200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18253,
      "e": 18253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 18568,
      "e": 18568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18569,
      "e": 18569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18622,
      "e": 18622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19598,
      "e": 19598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19600,
      "e": 19600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19670,
      "e": 19670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19774,
      "e": 19774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19774,
      "e": 19774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19830,
      "e": 19830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20006,
      "e": 20006,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20319,
      "e": 20319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20319,
      "e": 20319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20373,
      "e": 20373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20390,
      "e": 20390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20390,
      "e": 20390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20446,
      "e": 20446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20510,
      "e": 20510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20510,
      "e": 20510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20567,
      "e": 20567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20591,
      "e": 20591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20591,
      "e": 20591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20638,
      "e": 20638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20693,
      "e": 20693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20694,
      "e": 20694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20774,
      "e": 20774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20782,
      "e": 20782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20782,
      "e": 20782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20846,
      "e": 20846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20934,
      "e": 20934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20936,
      "e": 20936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20989,
      "e": 20989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20990,
      "e": 20990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20997,
      "e": 20997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 21054,
      "e": 21054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21109,
      "e": 21109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21110,
      "e": 21110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21167,
      "e": 21167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21167,
      "e": 21167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21190,
      "e": 21190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 21230,
      "e": 21230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21318,
      "e": 21318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21318,
      "e": 21318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21382,
      "e": 21382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25287,
      "e": 25287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25288,
      "e": 25288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25342,
      "e": 25342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25398,
      "e": 25398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25399,
      "e": 25399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25469,
      "e": 25469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25631,
      "e": 25631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25632,
      "e": 25632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25701,
      "e": 25701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25806,
      "e": 25806,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go "
    },
    {
      "t": 25846,
      "e": 25846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 25847,
      "e": 25847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25934,
      "e": 25934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 25998,
      "e": 25998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 25998,
      "e": 25998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26070,
      "e": 26070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26231,
      "e": 26231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26231,
      "e": 26231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26301,
      "e": 26301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26405,
      "e": 26405,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up "
    },
    {
      "t": 26413,
      "e": 26413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26415,
      "e": 26415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26478,
      "e": 26478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26494,
      "e": 26494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26495,
      "e": 26495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26549,
      "e": 26549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26702,
      "e": 26702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26704,
      "e": 26704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26766,
      "e": 26766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26935,
      "e": 26935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26935,
      "e": 26935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26998,
      "e": 26998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26999,
      "e": 26999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27007,
      "e": 27007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 27053,
      "e": 27053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27134,
      "e": 27134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27134,
      "e": 27134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27214,
      "e": 27214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27814,
      "e": 27814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27816,
      "e": 27816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27885,
      "e": 27885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27942,
      "e": 27942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27942,
      "e": 27942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28007,
      "e": 28007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28038,
      "e": 28038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28039,
      "e": 28039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28110,
      "e": 28110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28142,
      "e": 28142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28142,
      "e": 28142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28206,
      "e": 28206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28350,
      "e": 28350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 28352,
      "e": 28352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28406,
      "e": 28406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 28566,
      "e": 28566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28567,
      "e": 28567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28696,
      "e": 28696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28696,
      "e": 28696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28725,
      "e": 28725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 28789,
      "e": 28789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28911,
      "e": 28911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28911,
      "e": 28911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28974,
      "e": 28974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29006,
      "e": 29006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29006,
      "e": 29006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29062,
      "e": 29062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29159,
      "e": 29159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 29159,
      "e": 29159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29222,
      "e": 29222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 29390,
      "e": 29390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29391,
      "e": 29391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29454,
      "e": 29454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29454,
      "e": 29454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29478,
      "e": 29478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 29510,
      "e": 29510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29630,
      "e": 29630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29631,
      "e": 29631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29701,
      "e": 29701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29806,
      "e": 29806,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical "
    },
    {
      "t": 29870,
      "e": 29870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29871,
      "e": 29871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29917,
      "e": 29871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 30102,
      "e": 30056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30102,
      "e": 30056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30166,
      "e": 30120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30302,
      "e": 30256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30303,
      "e": 30257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30373,
      "e": 30327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30445,
      "e": 30399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30447,
      "e": 30401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30494,
      "e": 30448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30502,
      "e": 30456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30502,
      "e": 30456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30558,
      "e": 30512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30654,
      "e": 30608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30654,
      "e": 30608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30662,
      "e": 30616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 30662,
      "e": 30616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30687,
      "e": 30641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ty"
    },
    {
      "t": 30709,
      "e": 30663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30718,
      "e": 30672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30718,
      "e": 30672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30773,
      "e": 30727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30934,
      "e": 30888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30935,
      "e": 30889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31006,
      "e": 30960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31878,
      "e": 31832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31925,
      "e": 31879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line tyo"
    },
    {
      "t": 32045,
      "e": 31999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32093,
      "e": 32047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line ty"
    },
    {
      "t": 32190,
      "e": 32144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32214,
      "e": 32168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line t"
    },
    {
      "t": 32838,
      "e": 32792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32839,
      "e": 32793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32894,
      "e": 32848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 33007,
      "e": 32961,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line to"
    },
    {
      "t": 33046,
      "e": 33000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33046,
      "e": 33000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33101,
      "e": 33055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33101,
      "e": 33055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33118,
      "e": 33072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 33173,
      "e": 33127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33310,
      "e": 33264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33311,
      "e": 33265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33366,
      "e": 33320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33453,
      "e": 33407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33454,
      "e": 33408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33517,
      "e": 33471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33518,
      "e": 33472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33525,
      "e": 33479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 33574,
      "e": 33528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34030,
      "e": 33984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 34031,
      "e": 33985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34085,
      "e": 34039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 34109,
      "e": 34063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34110,
      "e": 34064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34165,
      "e": 34119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34303,
      "e": 34257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34304,
      "e": 34258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34374,
      "e": 34328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34430,
      "e": 34384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 34430,
      "e": 34384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34494,
      "e": 34448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 34510,
      "e": 34464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34511,
      "e": 34465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34567,
      "e": 34521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34703,
      "e": 34657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34704,
      "e": 34658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34766,
      "e": 34720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34926,
      "e": 34880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 34927,
      "e": 34881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35006,
      "e": 34960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 35126,
      "e": 35080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35127,
      "e": 35081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35206,
      "e": 35160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 35350,
      "e": 35304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35350,
      "e": 35304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35413,
      "e": 35367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35534,
      "e": 35488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35535,
      "e": 35489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35590,
      "e": 35544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35590,
      "e": 35544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35606,
      "e": 35560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 35645,
      "e": 35599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35863,
      "e": 35817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35863,
      "e": 35817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35917,
      "e": 35871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35918,
      "e": 35872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35933,
      "e": 35887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 35973,
      "e": 35927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36358,
      "e": 36312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36360,
      "e": 36314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36421,
      "e": 36375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36550,
      "e": 36504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36551,
      "e": 36505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36614,
      "e": 36568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36672,
      "e": 36570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36673,
      "e": 36571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36733,
      "e": 36631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36758,
      "e": 36656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36758,
      "e": 36656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36822,
      "e": 36720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36974,
      "e": 36872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 36974,
      "e": 36872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37021,
      "e": 36919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 37454,
      "e": 37352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37517,
      "e": 37415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line to see which points lie "
    },
    {
      "t": 38702,
      "e": 38600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38702,
      "e": 38600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38774,
      "e": 38672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38927,
      "e": 38825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38927,
      "e": 38825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38989,
      "e": 38887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39118,
      "e": 39016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39118,
      "e": 39016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39181,
      "e": 39079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39189,
      "e": 39087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39189,
      "e": 39087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39253,
      "e": 39151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39317,
      "e": 39215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39317,
      "e": 39215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39390,
      "e": 39288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 39598,
      "e": 39496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39598,
      "e": 39496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39685,
      "e": 39583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39862,
      "e": 39760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39863,
      "e": 39761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39925,
      "e": 39823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39925,
      "e": 39823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39925,
      "e": 39823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39989,
      "e": 39887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40158,
      "e": 40056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40159,
      "e": 40057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40221,
      "e": 40119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 40366,
      "e": 40264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40367,
      "e": 40265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40437,
      "e": 40335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40582,
      "e": 40480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40583,
      "e": 40481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40638,
      "e": 40536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40646,
      "e": 40544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40646,
      "e": 40544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40701,
      "e": 40599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40807,
      "e": 40705,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line to see which points lie on that line"
    },
    {
      "t": 46534,
      "e": 45705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 46535,
      "e": 45706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46597,
      "e": 45768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 48074,
      "e": 47245,
      "ty": 7,
      "x": 523,
      "y": 613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48105,
      "e": 47276,
      "ty": 2,
      "x": 497,
      "y": 621
    },
    {
      "t": 48205,
      "e": 47376,
      "ty": 2,
      "x": 406,
      "y": 638
    },
    {
      "t": 48241,
      "e": 47412,
      "ty": 6,
      "x": 355,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 48255,
      "e": 47426,
      "ty": 41,
      "x": 8959,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 48258,
      "e": 47429,
      "ty": 7,
      "x": 334,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 48305,
      "e": 47476,
      "ty": 2,
      "x": 331,
      "y": 670
    },
    {
      "t": 48504,
      "e": 47675,
      "ty": 2,
      "x": 330,
      "y": 672
    },
    {
      "t": 48505,
      "e": 47676,
      "ty": 41,
      "x": 5339,
      "y": 32941,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 48525,
      "e": 47696,
      "ty": 6,
      "x": 342,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 48604,
      "e": 47775,
      "ty": 2,
      "x": 401,
      "y": 681
    },
    {
      "t": 48705,
      "e": 47876,
      "ty": 2,
      "x": 407,
      "y": 682
    },
    {
      "t": 48755,
      "e": 47926,
      "ty": 41,
      "x": 37358,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 48786,
      "e": 47957,
      "ty": 3,
      "x": 407,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 48786,
      "e": 47957,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you take 12pm on the X-axis and then go up along the vertical line to see which points lie on that line."
    },
    {
      "t": 48787,
      "e": 47958,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48788,
      "e": 47959,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48914,
      "e": 48085,
      "ty": 4,
      "x": 37358,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 48930,
      "e": 48101,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48931,
      "e": 48102,
      "ty": 5,
      "x": 407,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 48939,
      "e": 48110,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 49934,
      "e": 49105,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 50004,
      "e": 49175,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 51404,
      "e": 50575,
      "ty": 2,
      "x": 802,
      "y": 811
    },
    {
      "t": 51504,
      "e": 50675,
      "ty": 2,
      "x": 894,
      "y": 827
    },
    {
      "t": 51504,
      "e": 50675,
      "ty": 41,
      "x": 30511,
      "y": 45370,
      "ta": "html > body"
    },
    {
      "t": 51604,
      "e": 50775,
      "ty": 2,
      "x": 912,
      "y": 742
    },
    {
      "t": 51704,
      "e": 50875,
      "ty": 2,
      "x": 916,
      "y": 484
    },
    {
      "t": 51754,
      "e": 50925,
      "ty": 41,
      "x": 31269,
      "y": 26369,
      "ta": "html > body"
    },
    {
      "t": 51804,
      "e": 50975,
      "ty": 2,
      "x": 907,
      "y": 515
    },
    {
      "t": 51827,
      "e": 50998,
      "ty": 6,
      "x": 891,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51844,
      "e": 51015,
      "ty": 7,
      "x": 884,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51904,
      "e": 51075,
      "ty": 2,
      "x": 877,
      "y": 592
    },
    {
      "t": 52004,
      "e": 51175,
      "ty": 41,
      "x": 14923,
      "y": 6342,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 52204,
      "e": 51375,
      "ty": 2,
      "x": 877,
      "y": 577
    },
    {
      "t": 52254,
      "e": 51425,
      "ty": 41,
      "x": 14923,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 52378,
      "e": 51549,
      "ty": 6,
      "x": 877,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52404,
      "e": 51575,
      "ty": 2,
      "x": 877,
      "y": 572
    },
    {
      "t": 52505,
      "e": 51676,
      "ty": 2,
      "x": 878,
      "y": 569
    },
    {
      "t": 52505,
      "e": 51676,
      "ty": 41,
      "x": 15140,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52578,
      "e": 51749,
      "ty": 3,
      "x": 878,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52579,
      "e": 51750,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52665,
      "e": 51836,
      "ty": 4,
      "x": 15140,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52665,
      "e": 51836,
      "ty": 5,
      "x": 878,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53222,
      "e": 52393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 53223,
      "e": 52394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53349,
      "e": 52520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 53678,
      "e": 52849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 53678,
      "e": 52849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53742,
      "e": 52913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 54663,
      "e": 53834,
      "ty": 7,
      "x": 886,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54704,
      "e": 53875,
      "ty": 2,
      "x": 886,
      "y": 598
    },
    {
      "t": 54755,
      "e": 53926,
      "ty": 41,
      "x": 16870,
      "y": 21064,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 54804,
      "e": 53975,
      "ty": 2,
      "x": 886,
      "y": 615
    },
    {
      "t": 54904,
      "e": 54075,
      "ty": 2,
      "x": 891,
      "y": 642
    },
    {
      "t": 55004,
      "e": 54175,
      "ty": 2,
      "x": 891,
      "y": 645
    },
    {
      "t": 55004,
      "e": 54175,
      "ty": 41,
      "x": 17951,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 55234,
      "e": 54405,
      "ty": 6,
      "x": 891,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55255,
      "e": 54426,
      "ty": 41,
      "x": 17951,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55304,
      "e": 54475,
      "ty": 2,
      "x": 891,
      "y": 656
    },
    {
      "t": 55404,
      "e": 54575,
      "ty": 2,
      "x": 891,
      "y": 658
    },
    {
      "t": 55425,
      "e": 54596,
      "ty": 3,
      "x": 891,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55427,
      "e": 54598,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 55427,
      "e": 54598,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55428,
      "e": 54599,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55505,
      "e": 54676,
      "ty": 41,
      "x": 17951,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55505,
      "e": 54676,
      "ty": 4,
      "x": 17951,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55505,
      "e": 54676,
      "ty": 5,
      "x": 891,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56118,
      "e": 55289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 56617,
      "e": 55788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 56650,
      "e": 55821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 56683,
      "e": 55854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 56694,
      "e": 55865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 56695,
      "e": 55866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56765,
      "e": 55936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "O"
    },
    {
      "t": 56789,
      "e": 55960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "O"
    },
    {
      "t": 57814,
      "e": 56985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 57860,
      "e": 57031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 58005,
      "e": 57176,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 58581,
      "e": 57752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 58822,
      "e": 57993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 58824,
      "e": 57995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58885,
      "e": 58056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "O"
    },
    {
      "t": 58909,
      "e": 58080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "O"
    },
    {
      "t": 59918,
      "e": 59089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 59957,
      "e": 59128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 60004,
      "e": 59175,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60261,
      "e": 59432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 60485,
      "e": 59656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 60485,
      "e": 59656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60533,
      "e": 59704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 60550,
      "e": 59721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 60949,
      "e": 60120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 60951,
      "e": 60122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61014,
      "e": 60185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "In"
    },
    {
      "t": 61150,
      "e": 60321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 61150,
      "e": 60321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61213,
      "e": 60384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ind"
    },
    {
      "t": 61421,
      "e": 60592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 61423,
      "e": 60594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61477,
      "e": 60648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Indi"
    },
    {
      "t": 61581,
      "e": 60752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 61582,
      "e": 60753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61645,
      "e": 60816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 62437,
      "e": 61608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 62438,
      "e": 61609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62501,
      "e": 61672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 62605,
      "e": 61776,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "India\n"
    },
    {
      "t": 64325,
      "e": 63496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 64438,
      "e": 63609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "India"
    },
    {
      "t": 66005,
      "e": 65176,
      "ty": 2,
      "x": 899,
      "y": 663
    },
    {
      "t": 66005,
      "e": 65176,
      "ty": 41,
      "x": 19682,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66021,
      "e": 65192,
      "ty": 7,
      "x": 915,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66022,
      "e": 65193,
      "ty": 6,
      "x": 915,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66089,
      "e": 65260,
      "ty": 7,
      "x": 949,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66105,
      "e": 65276,
      "ty": 2,
      "x": 949,
      "y": 711
    },
    {
      "t": 66205,
      "e": 65376,
      "ty": 2,
      "x": 950,
      "y": 712
    },
    {
      "t": 66255,
      "e": 65426,
      "ty": 41,
      "x": 32440,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 66405,
      "e": 65576,
      "ty": 2,
      "x": 952,
      "y": 712
    },
    {
      "t": 66439,
      "e": 65610,
      "ty": 6,
      "x": 953,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66504,
      "e": 65675,
      "ty": 2,
      "x": 954,
      "y": 705
    },
    {
      "t": 66505,
      "e": 65676,
      "ty": 41,
      "x": 29932,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66605,
      "e": 65776,
      "ty": 2,
      "x": 954,
      "y": 697
    },
    {
      "t": 66698,
      "e": 65869,
      "ty": 3,
      "x": 954,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66699,
      "e": 65870,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "India"
    },
    {
      "t": 66700,
      "e": 65871,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66700,
      "e": 65871,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66704,
      "e": 65875,
      "ty": 2,
      "x": 954,
      "y": 696
    },
    {
      "t": 66755,
      "e": 65926,
      "ty": 41,
      "x": 29932,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66825,
      "e": 65996,
      "ty": 4,
      "x": 29932,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66826,
      "e": 65997,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66826,
      "e": 65997,
      "ty": 5,
      "x": 954,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66826,
      "e": 65997,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 67851,
      "e": 67022,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 68609,
      "e": 67780,
      "ty": 2,
      "x": 954,
      "y": 619
    },
    {
      "t": 68709,
      "e": 67880,
      "ty": 2,
      "x": 873,
      "y": 364
    },
    {
      "t": 68760,
      "e": 67931,
      "ty": 41,
      "x": 10816,
      "y": 14123,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68809,
      "e": 67980,
      "ty": 2,
      "x": 867,
      "y": 335
    },
    {
      "t": 68908,
      "e": 68079,
      "ty": 2,
      "x": 861,
      "y": 243
    },
    {
      "t": 69009,
      "e": 68180,
      "ty": 2,
      "x": 858,
      "y": 235
    },
    {
      "t": 69009,
      "e": 68180,
      "ty": 41,
      "x": 29952,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69183,
      "e": 68354,
      "ty": 3,
      "x": 858,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69341,
      "e": 68512,
      "ty": 4,
      "x": 29952,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69342,
      "e": 68513,
      "ty": 5,
      "x": 858,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69342,
      "e": 68513,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69343,
      "e": 68514,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 69709,
      "e": 68880,
      "ty": 2,
      "x": 864,
      "y": 285
    },
    {
      "t": 69759,
      "e": 68930,
      "ty": 41,
      "x": 47231,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 69809,
      "e": 68980,
      "ty": 2,
      "x": 877,
      "y": 353
    },
    {
      "t": 69909,
      "e": 69080,
      "ty": 2,
      "x": 892,
      "y": 433
    },
    {
      "t": 70009,
      "e": 69180,
      "ty": 2,
      "x": 893,
      "y": 443
    },
    {
      "t": 70009,
      "e": 69180,
      "ty": 41,
      "x": 57173,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 70010,
      "e": 69181,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 71109,
      "e": 70280,
      "ty": 2,
      "x": 893,
      "y": 444
    },
    {
      "t": 71209,
      "e": 70380,
      "ty": 2,
      "x": 892,
      "y": 445
    },
    {
      "t": 71260,
      "e": 70431,
      "ty": 41,
      "x": 56374,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 71309,
      "e": 70480,
      "ty": 2,
      "x": 892,
      "y": 446
    },
    {
      "t": 71409,
      "e": 70580,
      "ty": 2,
      "x": 889,
      "y": 446
    },
    {
      "t": 71509,
      "e": 70680,
      "ty": 41,
      "x": 53978,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 71510,
      "e": 70681,
      "ty": 3,
      "x": 889,
      "y": 446,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 71512,
      "e": 70683,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71653,
      "e": 70824,
      "ty": 4,
      "x": 53978,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 71653,
      "e": 70824,
      "ty": 5,
      "x": 889,
      "y": 446,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 71654,
      "e": 70825,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 71655,
      "e": 70826,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 72010,
      "e": 71181,
      "ty": 2,
      "x": 888,
      "y": 485
    },
    {
      "t": 72010,
      "e": 71181,
      "ty": 41,
      "x": 15800,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 72109,
      "e": 71280,
      "ty": 2,
      "x": 910,
      "y": 843
    },
    {
      "t": 72209,
      "e": 71380,
      "ty": 2,
      "x": 915,
      "y": 891
    },
    {
      "t": 72259,
      "e": 71430,
      "ty": 41,
      "x": 22208,
      "y": 16131,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 72309,
      "e": 71480,
      "ty": 2,
      "x": 915,
      "y": 916
    },
    {
      "t": 72409,
      "e": 71580,
      "ty": 2,
      "x": 915,
      "y": 917
    },
    {
      "t": 72509,
      "e": 71680,
      "ty": 41,
      "x": 22208,
      "y": 21172,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 74709,
      "e": 73880,
      "ty": 2,
      "x": 939,
      "y": 896
    },
    {
      "t": 74759,
      "e": 73930,
      "ty": 41,
      "x": 31226,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 74809,
      "e": 73980,
      "ty": 2,
      "x": 967,
      "y": 857
    },
    {
      "t": 74909,
      "e": 74080,
      "ty": 2,
      "x": 977,
      "y": 793
    },
    {
      "t": 75009,
      "e": 74180,
      "ty": 2,
      "x": 998,
      "y": 684
    },
    {
      "t": 75009,
      "e": 74180,
      "ty": 41,
      "x": 47411,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75109,
      "e": 74280,
      "ty": 2,
      "x": 1004,
      "y": 670
    },
    {
      "t": 75209,
      "e": 74380,
      "ty": 2,
      "x": 1004,
      "y": 668
    },
    {
      "t": 75259,
      "e": 74430,
      "ty": 41,
      "x": 49022,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75410,
      "e": 74581,
      "ty": 2,
      "x": 1007,
      "y": 678
    },
    {
      "t": 75509,
      "e": 74680,
      "ty": 41,
      "x": 49827,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75609,
      "e": 74780,
      "ty": 2,
      "x": 1012,
      "y": 696
    },
    {
      "t": 75710,
      "e": 74881,
      "ty": 2,
      "x": 1013,
      "y": 702
    },
    {
      "t": 75760,
      "e": 74931,
      "ty": 41,
      "x": 48274,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 75766,
      "e": 74937,
      "ty": 3,
      "x": 1013,
      "y": 702,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 75768,
      "e": 74939,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 75877,
      "e": 75048,
      "ty": 4,
      "x": 48274,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 75877,
      "e": 75048,
      "ty": 5,
      "x": 1013,
      "y": 702,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 75877,
      "e": 75048,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 75878,
      "e": 75049,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 76209,
      "e": 75380,
      "ty": 2,
      "x": 1013,
      "y": 726
    },
    {
      "t": 76259,
      "e": 75430,
      "ty": 41,
      "x": 45466,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 76310,
      "e": 75481,
      "ty": 2,
      "x": 1017,
      "y": 816
    },
    {
      "t": 76409,
      "e": 75580,
      "ty": 2,
      "x": 1017,
      "y": 842
    },
    {
      "t": 76509,
      "e": 75680,
      "ty": 2,
      "x": 1010,
      "y": 862
    },
    {
      "t": 76509,
      "e": 75680,
      "ty": 41,
      "x": 44754,
      "y": 52383,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 76609,
      "e": 75780,
      "ty": 2,
      "x": 995,
      "y": 882
    },
    {
      "t": 76709,
      "e": 75880,
      "ty": 2,
      "x": 980,
      "y": 888
    },
    {
      "t": 76760,
      "e": 75931,
      "ty": 41,
      "x": 35498,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 76810,
      "e": 75981,
      "ty": 2,
      "x": 964,
      "y": 900
    },
    {
      "t": 76909,
      "e": 76080,
      "ty": 2,
      "x": 953,
      "y": 913
    },
    {
      "t": 77009,
      "e": 76180,
      "ty": 2,
      "x": 935,
      "y": 934
    },
    {
      "t": 77010,
      "e": 76181,
      "ty": 41,
      "x": 26954,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 77109,
      "e": 76280,
      "ty": 2,
      "x": 924,
      "y": 942
    },
    {
      "t": 77210,
      "e": 76381,
      "ty": 2,
      "x": 905,
      "y": 952
    },
    {
      "t": 77259,
      "e": 76430,
      "ty": 41,
      "x": 61136,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77309,
      "e": 76480,
      "ty": 2,
      "x": 896,
      "y": 956
    },
    {
      "t": 77409,
      "e": 76580,
      "ty": 2,
      "x": 893,
      "y": 958
    },
    {
      "t": 77510,
      "e": 76581,
      "ty": 2,
      "x": 890,
      "y": 961
    },
    {
      "t": 77512,
      "e": 76583,
      "ty": 41,
      "x": 55474,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77607,
      "e": 76678,
      "ty": 3,
      "x": 890,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77607,
      "e": 76678,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77610,
      "e": 76681,
      "ty": 2,
      "x": 890,
      "y": 962
    },
    {
      "t": 77693,
      "e": 76764,
      "ty": 4,
      "x": 55474,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77694,
      "e": 76765,
      "ty": 5,
      "x": 890,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77695,
      "e": 76766,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77696,
      "e": 76767,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 77758,
      "e": 76829,
      "ty": 41,
      "x": 55474,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77869,
      "e": 76940,
      "ty": 6,
      "x": 890,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 77908,
      "e": 76979,
      "ty": 2,
      "x": 891,
      "y": 1029
    },
    {
      "t": 78008,
      "e": 77079,
      "ty": 2,
      "x": 892,
      "y": 1030
    },
    {
      "t": 78009,
      "e": 77080,
      "ty": 41,
      "x": 32252,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80663,
      "e": 79734,
      "ty": 3,
      "x": 892,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80664,
      "e": 79735,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80665,
      "e": 79736,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80757,
      "e": 79828,
      "ty": 4,
      "x": 32252,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80757,
      "e": 79828,
      "ty": 5,
      "x": 892,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80758,
      "e": 79829,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80760,
      "e": 79831,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 80760,
      "e": 79831,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 82088,
      "e": 81159,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 90008,
      "e": 84831,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 111708,
      "e": 84831,
      "ty": 2,
      "x": 959,
      "y": 1022
    },
    {
      "t": 111759,
      "e": 84882,
      "ty": 41,
      "x": 32792,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 111809,
      "e": 84932,
      "ty": 2,
      "x": 963,
      "y": 1022
    },
    {
      "t": 111908,
      "e": 85031,
      "ty": 2,
      "x": 968,
      "y": 1020
    },
    {
      "t": 112008,
      "e": 85131,
      "ty": 2,
      "x": 979,
      "y": 1016
    },
    {
      "t": 112009,
      "e": 85132,
      "ty": 41,
      "x": 33726,
      "y": 61609,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112109,
      "e": 85232,
      "ty": 2,
      "x": 998,
      "y": 1011
    },
    {
      "t": 112208,
      "e": 85331,
      "ty": 2,
      "x": 1020,
      "y": 1004
    },
    {
      "t": 112258,
      "e": 85381,
      "ty": 41,
      "x": 35842,
      "y": 60709,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112308,
      "e": 85431,
      "ty": 2,
      "x": 1022,
      "y": 1003
    },
    {
      "t": 112509,
      "e": 85632,
      "ty": 2,
      "x": 1016,
      "y": 1036
    },
    {
      "t": 112509,
      "e": 85632,
      "ty": 41,
      "x": 35547,
      "y": 62994,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112608,
      "e": 85731,
      "ty": 2,
      "x": 1012,
      "y": 1044
    },
    {
      "t": 112708,
      "e": 85831,
      "ty": 2,
      "x": 1010,
      "y": 1055
    },
    {
      "t": 112759,
      "e": 85882,
      "ty": 41,
      "x": 35202,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112804,
      "e": 85927,
      "ty": 6,
      "x": 1006,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 112809,
      "e": 85932,
      "ty": 2,
      "x": 1006,
      "y": 1072
    },
    {
      "t": 112908,
      "e": 86031,
      "ty": 2,
      "x": 1003,
      "y": 1080
    },
    {
      "t": 113009,
      "e": 86132,
      "ty": 41,
      "x": 51062,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 113054,
      "e": 86177,
      "ty": 3,
      "x": 1003,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 113056,
      "e": 86179,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 113253,
      "e": 86376,
      "ty": 4,
      "x": 51062,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 113254,
      "e": 86377,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 113255,
      "e": 86378,
      "ty": 5,
      "x": 1003,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 113256,
      "e": 86379,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 114300,
      "e": 87423,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 116185,
      "e": 89308,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 56590, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 56595, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3890, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 61575, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13697, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"OSCAR\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 76279, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15772, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 93137, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11582, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 105723, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 26220, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 133157, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-12 PM-11 AM-A -A -10 AM-11 AM-11 AM-5\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:969,y:919,t:1527613507188};\\\", \\\"{x:969,y:915,t:1527613510148};\\\", \\\"{x:970,y:913,t:1527613510164};\\\", \\\"{x:971,y:912,t:1527613510180};\\\", \\\"{x:973,y:911,t:1527613510212};\\\", \\\"{x:974,y:910,t:1527613510228};\\\", \\\"{x:975,y:909,t:1527613510236};\\\", \\\"{x:975,y:908,t:1527613510247};\\\", \\\"{x:977,y:905,t:1527613510265};\\\", \\\"{x:979,y:902,t:1527613510280};\\\", \\\"{x:982,y:897,t:1527613510297};\\\", \\\"{x:987,y:888,t:1527613510315};\\\", \\\"{x:993,y:874,t:1527613510331};\\\", \\\"{x:998,y:862,t:1527613510347};\\\", \\\"{x:1007,y:839,t:1527613510364};\\\", \\\"{x:1010,y:831,t:1527613510381};\\\", \\\"{x:1012,y:827,t:1527613510397};\\\", \\\"{x:1014,y:822,t:1527613510414};\\\", \\\"{x:1016,y:817,t:1527613510431};\\\", \\\"{x:1018,y:811,t:1527613510447};\\\", \\\"{x:1021,y:803,t:1527613510464};\\\", \\\"{x:1023,y:796,t:1527613510480};\\\", \\\"{x:1025,y:787,t:1527613510496};\\\", \\\"{x:1029,y:772,t:1527613510513};\\\", \\\"{x:1033,y:763,t:1527613510531};\\\", \\\"{x:1034,y:759,t:1527613510547};\\\", \\\"{x:1036,y:757,t:1527613510564};\\\", \\\"{x:1036,y:756,t:1527613510581};\\\", \\\"{x:1037,y:755,t:1527613510597};\\\", \\\"{x:1039,y:758,t:1527613510821};\\\", \\\"{x:1042,y:768,t:1527613510832};\\\", \\\"{x:1050,y:784,t:1527613510847};\\\", \\\"{x:1057,y:805,t:1527613510865};\\\", \\\"{x:1068,y:824,t:1527613510882};\\\", \\\"{x:1077,y:838,t:1527613510898};\\\", \\\"{x:1085,y:851,t:1527613510915};\\\", \\\"{x:1102,y:876,t:1527613510932};\\\", \\\"{x:1115,y:893,t:1527613510947};\\\", \\\"{x:1127,y:905,t:1527613510964};\\\", \\\"{x:1142,y:920,t:1527613510981};\\\", \\\"{x:1155,y:931,t:1527613510997};\\\", \\\"{x:1169,y:943,t:1527613511013};\\\", \\\"{x:1182,y:952,t:1527613511031};\\\", \\\"{x:1195,y:960,t:1527613511048};\\\", \\\"{x:1206,y:967,t:1527613511063};\\\", \\\"{x:1218,y:971,t:1527613511081};\\\", \\\"{x:1230,y:977,t:1527613511097};\\\", \\\"{x:1239,y:981,t:1527613511114};\\\", \\\"{x:1254,y:986,t:1527613511131};\\\", \\\"{x:1261,y:988,t:1527613511148};\\\", \\\"{x:1263,y:989,t:1527613511165};\\\", \\\"{x:1264,y:989,t:1527613511188};\\\", \\\"{x:1265,y:989,t:1527613511324};\\\", \\\"{x:1266,y:989,t:1527613511340};\\\", \\\"{x:1268,y:989,t:1527613511356};\\\", \\\"{x:1270,y:989,t:1527613511380};\\\", \\\"{x:1272,y:988,t:1527613511398};\\\", \\\"{x:1275,y:988,t:1527613511415};\\\", \\\"{x:1279,y:986,t:1527613511431};\\\", \\\"{x:1283,y:985,t:1527613511448};\\\", \\\"{x:1285,y:983,t:1527613511465};\\\", \\\"{x:1289,y:982,t:1527613511481};\\\", \\\"{x:1292,y:980,t:1527613511498};\\\", \\\"{x:1294,y:979,t:1527613511515};\\\", \\\"{x:1297,y:978,t:1527613511532};\\\", \\\"{x:1299,y:977,t:1527613511548};\\\", \\\"{x:1302,y:975,t:1527613511567};\\\", \\\"{x:1305,y:975,t:1527613511582};\\\", \\\"{x:1310,y:973,t:1527613511599};\\\", \\\"{x:1314,y:972,t:1527613511616};\\\", \\\"{x:1318,y:971,t:1527613511632};\\\", \\\"{x:1321,y:971,t:1527613511648};\\\", \\\"{x:1324,y:969,t:1527613511665};\\\", \\\"{x:1327,y:969,t:1527613511682};\\\", \\\"{x:1329,y:969,t:1527613511699};\\\", \\\"{x:1332,y:968,t:1527613511716};\\\", \\\"{x:1333,y:968,t:1527613511732};\\\", \\\"{x:1334,y:968,t:1527613511780};\\\", \\\"{x:1335,y:968,t:1527613511885};\\\", \\\"{x:1335,y:966,t:1527613512604};\\\", \\\"{x:1328,y:966,t:1527613512616};\\\", \\\"{x:1311,y:973,t:1527613512633};\\\", \\\"{x:1296,y:976,t:1527613512650};\\\", \\\"{x:1287,y:976,t:1527613512665};\\\", \\\"{x:1283,y:976,t:1527613512683};\\\", \\\"{x:1282,y:976,t:1527613512821};\\\", \\\"{x:1282,y:974,t:1527613512844};\\\", \\\"{x:1282,y:973,t:1527613512860};\\\", \\\"{x:1283,y:971,t:1527613512868};\\\", \\\"{x:1283,y:970,t:1527613512883};\\\", \\\"{x:1285,y:967,t:1527613512900};\\\", \\\"{x:1288,y:963,t:1527613512916};\\\", \\\"{x:1291,y:958,t:1527613512933};\\\", \\\"{x:1294,y:952,t:1527613512949};\\\", \\\"{x:1297,y:947,t:1527613512966};\\\", \\\"{x:1299,y:944,t:1527613512983};\\\", \\\"{x:1302,y:942,t:1527613513000};\\\", \\\"{x:1303,y:940,t:1527613513017};\\\", \\\"{x:1303,y:939,t:1527613513032};\\\", \\\"{x:1305,y:937,t:1527613513049};\\\", \\\"{x:1305,y:936,t:1527613513067};\\\", \\\"{x:1306,y:936,t:1527613513100};\\\", \\\"{x:1306,y:935,t:1527613513117};\\\", \\\"{x:1306,y:934,t:1527613513140};\\\", \\\"{x:1307,y:934,t:1527613513164};\\\", \\\"{x:1308,y:933,t:1527613513172};\\\", \\\"{x:1308,y:932,t:1527613513188};\\\", \\\"{x:1308,y:931,t:1527613513204};\\\", \\\"{x:1308,y:929,t:1527613513216};\\\", \\\"{x:1308,y:927,t:1527613513233};\\\", \\\"{x:1308,y:924,t:1527613513250};\\\", \\\"{x:1308,y:920,t:1527613513267};\\\", \\\"{x:1309,y:917,t:1527613513282};\\\", \\\"{x:1309,y:913,t:1527613513300};\\\", \\\"{x:1309,y:911,t:1527613513316};\\\", \\\"{x:1308,y:907,t:1527613513332};\\\", \\\"{x:1307,y:905,t:1527613513350};\\\", \\\"{x:1307,y:903,t:1527613513367};\\\", \\\"{x:1307,y:901,t:1527613513384};\\\", \\\"{x:1305,y:900,t:1527613513400};\\\", \\\"{x:1305,y:899,t:1527613513420};\\\", \\\"{x:1305,y:898,t:1527613513436};\\\", \\\"{x:1305,y:897,t:1527613513449};\\\", \\\"{x:1304,y:895,t:1527613513467};\\\", \\\"{x:1304,y:894,t:1527613513484};\\\", \\\"{x:1304,y:892,t:1527613513500};\\\", \\\"{x:1302,y:890,t:1527613513517};\\\", \\\"{x:1302,y:889,t:1527613513534};\\\", \\\"{x:1301,y:887,t:1527613513549};\\\", \\\"{x:1301,y:886,t:1527613513566};\\\", \\\"{x:1301,y:885,t:1527613513583};\\\", \\\"{x:1300,y:884,t:1527613513599};\\\", \\\"{x:1299,y:883,t:1527613513616};\\\", \\\"{x:1299,y:882,t:1527613513633};\\\", \\\"{x:1299,y:881,t:1527613513659};\\\", \\\"{x:1299,y:880,t:1527613513675};\\\", \\\"{x:1299,y:879,t:1527613513691};\\\", \\\"{x:1299,y:878,t:1527613513773};\\\", \\\"{x:1299,y:877,t:1527613513788};\\\", \\\"{x:1298,y:876,t:1527613513804};\\\", \\\"{x:1298,y:875,t:1527613513817};\\\", \\\"{x:1298,y:873,t:1527613513834};\\\", \\\"{x:1296,y:871,t:1527613513850};\\\", \\\"{x:1296,y:870,t:1527613513884};\\\", \\\"{x:1295,y:869,t:1527613513900};\\\", \\\"{x:1295,y:868,t:1527613513956};\\\", \\\"{x:1294,y:867,t:1527613514028};\\\", \\\"{x:1294,y:866,t:1527613514036};\\\", \\\"{x:1294,y:865,t:1527613514051};\\\", \\\"{x:1293,y:863,t:1527613514067};\\\", \\\"{x:1292,y:861,t:1527613514084};\\\", \\\"{x:1292,y:860,t:1527613514101};\\\", \\\"{x:1292,y:857,t:1527613514116};\\\", \\\"{x:1291,y:856,t:1527613514829};\\\", \\\"{x:1289,y:853,t:1527613514836};\\\", \\\"{x:1289,y:849,t:1527613514851};\\\", \\\"{x:1288,y:847,t:1527613514868};\\\", \\\"{x:1288,y:844,t:1527613514884};\\\", \\\"{x:1287,y:842,t:1527613514904};\\\", \\\"{x:1287,y:841,t:1527613514917};\\\", \\\"{x:1287,y:840,t:1527613515101};\\\", \\\"{x:1286,y:838,t:1527613515118};\\\", \\\"{x:1286,y:837,t:1527613515136};\\\", \\\"{x:1285,y:836,t:1527613515483};\\\", \\\"{x:1284,y:827,t:1527613518439};\\\", \\\"{x:1283,y:812,t:1527613518444};\\\", \\\"{x:1283,y:786,t:1527613518460};\\\", \\\"{x:1280,y:770,t:1527613518477};\\\", \\\"{x:1279,y:759,t:1527613518494};\\\", \\\"{x:1276,y:749,t:1527613518511};\\\", \\\"{x:1276,y:743,t:1527613518527};\\\", \\\"{x:1276,y:740,t:1527613518544};\\\", \\\"{x:1275,y:736,t:1527613518561};\\\", \\\"{x:1275,y:730,t:1527613518578};\\\", \\\"{x:1275,y:718,t:1527613518593};\\\", \\\"{x:1275,y:690,t:1527613518611};\\\", \\\"{x:1275,y:663,t:1527613518628};\\\", \\\"{x:1274,y:647,t:1527613518644};\\\", \\\"{x:1272,y:634,t:1527613518661};\\\", \\\"{x:1270,y:618,t:1527613518678};\\\", \\\"{x:1269,y:607,t:1527613518694};\\\", \\\"{x:1267,y:599,t:1527613518711};\\\", \\\"{x:1266,y:591,t:1527613518727};\\\", \\\"{x:1266,y:582,t:1527613518744};\\\", \\\"{x:1266,y:574,t:1527613518761};\\\", \\\"{x:1266,y:568,t:1527613518778};\\\", \\\"{x:1266,y:565,t:1527613518794};\\\", \\\"{x:1266,y:562,t:1527613518810};\\\", \\\"{x:1266,y:561,t:1527613518883};\\\", \\\"{x:1266,y:566,t:1527613519156};\\\", \\\"{x:1266,y:570,t:1527613519164};\\\", \\\"{x:1266,y:573,t:1527613519179};\\\", \\\"{x:1265,y:579,t:1527613519195};\\\", \\\"{x:1265,y:581,t:1527613519211};\\\", \\\"{x:1265,y:585,t:1527613519229};\\\", \\\"{x:1265,y:587,t:1527613519246};\\\", \\\"{x:1265,y:589,t:1527613519261};\\\", \\\"{x:1265,y:592,t:1527613519278};\\\", \\\"{x:1265,y:594,t:1527613519296};\\\", \\\"{x:1265,y:597,t:1527613519312};\\\", \\\"{x:1265,y:602,t:1527613519328};\\\", \\\"{x:1265,y:605,t:1527613519346};\\\", \\\"{x:1265,y:609,t:1527613519362};\\\", \\\"{x:1265,y:616,t:1527613519378};\\\", \\\"{x:1265,y:634,t:1527613519396};\\\", \\\"{x:1265,y:645,t:1527613519411};\\\", \\\"{x:1265,y:659,t:1527613519429};\\\", \\\"{x:1265,y:670,t:1527613519445};\\\", \\\"{x:1265,y:683,t:1527613519461};\\\", \\\"{x:1265,y:688,t:1527613519478};\\\", \\\"{x:1265,y:695,t:1527613519496};\\\", \\\"{x:1265,y:703,t:1527613519511};\\\", \\\"{x:1263,y:711,t:1527613519528};\\\", \\\"{x:1263,y:720,t:1527613519546};\\\", \\\"{x:1263,y:727,t:1527613519562};\\\", \\\"{x:1263,y:732,t:1527613519577};\\\", \\\"{x:1263,y:736,t:1527613519595};\\\", \\\"{x:1263,y:737,t:1527613519611};\\\", \\\"{x:1263,y:739,t:1527613519628};\\\", \\\"{x:1263,y:741,t:1527613519645};\\\", \\\"{x:1263,y:745,t:1527613519662};\\\", \\\"{x:1263,y:748,t:1527613519678};\\\", \\\"{x:1263,y:752,t:1527613519695};\\\", \\\"{x:1263,y:755,t:1527613519712};\\\", \\\"{x:1263,y:759,t:1527613519727};\\\", \\\"{x:1263,y:763,t:1527613519745};\\\", \\\"{x:1263,y:769,t:1527613519762};\\\", \\\"{x:1263,y:773,t:1527613519778};\\\", \\\"{x:1263,y:780,t:1527613519795};\\\", \\\"{x:1263,y:784,t:1527613519812};\\\", \\\"{x:1263,y:788,t:1527613519828};\\\", \\\"{x:1263,y:791,t:1527613519845};\\\", \\\"{x:1263,y:795,t:1527613519862};\\\", \\\"{x:1263,y:797,t:1527613519878};\\\", \\\"{x:1263,y:801,t:1527613519895};\\\", \\\"{x:1263,y:803,t:1527613519912};\\\", \\\"{x:1263,y:806,t:1527613519928};\\\", \\\"{x:1263,y:810,t:1527613519945};\\\", \\\"{x:1263,y:815,t:1527613519963};\\\", \\\"{x:1264,y:820,t:1527613519979};\\\", \\\"{x:1266,y:828,t:1527613519996};\\\", \\\"{x:1266,y:832,t:1527613520012};\\\", \\\"{x:1267,y:837,t:1527613520028};\\\", \\\"{x:1268,y:842,t:1527613520045};\\\", \\\"{x:1268,y:847,t:1527613520063};\\\", \\\"{x:1269,y:851,t:1527613520079};\\\", \\\"{x:1270,y:856,t:1527613520096};\\\", \\\"{x:1270,y:860,t:1527613520112};\\\", \\\"{x:1271,y:864,t:1527613520129};\\\", \\\"{x:1272,y:869,t:1527613520146};\\\", \\\"{x:1273,y:873,t:1527613520162};\\\", \\\"{x:1274,y:878,t:1527613520179};\\\", \\\"{x:1274,y:880,t:1527613520195};\\\", \\\"{x:1275,y:883,t:1527613520212};\\\", \\\"{x:1275,y:887,t:1527613520229};\\\", \\\"{x:1275,y:894,t:1527613520245};\\\", \\\"{x:1275,y:901,t:1527613520262};\\\", \\\"{x:1275,y:909,t:1527613520280};\\\", \\\"{x:1275,y:914,t:1527613520296};\\\", \\\"{x:1275,y:919,t:1527613520312};\\\", \\\"{x:1275,y:924,t:1527613520329};\\\", \\\"{x:1275,y:929,t:1527613520345};\\\", \\\"{x:1275,y:937,t:1527613520363};\\\", \\\"{x:1277,y:949,t:1527613520379};\\\", \\\"{x:1278,y:953,t:1527613520395};\\\", \\\"{x:1278,y:957,t:1527613520412};\\\", \\\"{x:1278,y:959,t:1527613520430};\\\", \\\"{x:1279,y:960,t:1527613520446};\\\", \\\"{x:1279,y:961,t:1527613520462};\\\", \\\"{x:1281,y:963,t:1527613520479};\\\", \\\"{x:1281,y:960,t:1527613520596};\\\", \\\"{x:1281,y:914,t:1527613520612};\\\", \\\"{x:1281,y:881,t:1527613520629};\\\", \\\"{x:1276,y:860,t:1527613520646};\\\", \\\"{x:1273,y:841,t:1527613520662};\\\", \\\"{x:1270,y:820,t:1527613520679};\\\", \\\"{x:1267,y:802,t:1527613520696};\\\", \\\"{x:1263,y:782,t:1527613520713};\\\", \\\"{x:1259,y:758,t:1527613520730};\\\", \\\"{x:1256,y:727,t:1527613520746};\\\", \\\"{x:1251,y:696,t:1527613520762};\\\", \\\"{x:1246,y:665,t:1527613520779};\\\", \\\"{x:1245,y:653,t:1527613520796};\\\", \\\"{x:1245,y:647,t:1527613520813};\\\", \\\"{x:1244,y:646,t:1527613520830};\\\", \\\"{x:1240,y:646,t:1527613520916};\\\", \\\"{x:1227,y:652,t:1527613520929};\\\", \\\"{x:1174,y:676,t:1527613520947};\\\", \\\"{x:1079,y:706,t:1527613520962};\\\", \\\"{x:891,y:742,t:1527613520979};\\\", \\\"{x:768,y:748,t:1527613520997};\\\", \\\"{x:676,y:750,t:1527613521013};\\\", \\\"{x:611,y:751,t:1527613521029};\\\", \\\"{x:567,y:751,t:1527613521046};\\\", \\\"{x:517,y:740,t:1527613521064};\\\", \\\"{x:468,y:721,t:1527613521081};\\\", \\\"{x:417,y:697,t:1527613521097};\\\", \\\"{x:366,y:667,t:1527613521113};\\\", \\\"{x:317,y:639,t:1527613521130};\\\", \\\"{x:241,y:596,t:1527613521147};\\\", \\\"{x:194,y:567,t:1527613521164};\\\", \\\"{x:163,y:539,t:1527613521179};\\\", \\\"{x:149,y:523,t:1527613521197};\\\", \\\"{x:147,y:520,t:1527613521213};\\\", \\\"{x:147,y:519,t:1527613521266};\\\", \\\"{x:147,y:517,t:1527613521280};\\\", \\\"{x:147,y:515,t:1527613521297};\\\", \\\"{x:148,y:512,t:1527613521314};\\\", \\\"{x:148,y:511,t:1527613521330};\\\", \\\"{x:149,y:509,t:1527613521347};\\\", \\\"{x:150,y:508,t:1527613521428};\\\", \\\"{x:153,y:509,t:1527613521442};\\\", \\\"{x:158,y:515,t:1527613521450};\\\", \\\"{x:160,y:519,t:1527613521464};\\\", \\\"{x:172,y:528,t:1527613521480};\\\", \\\"{x:188,y:535,t:1527613521497};\\\", \\\"{x:208,y:537,t:1527613521514};\\\", \\\"{x:234,y:538,t:1527613521529};\\\", \\\"{x:267,y:538,t:1527613521547};\\\", \\\"{x:278,y:538,t:1527613521564};\\\", \\\"{x:279,y:538,t:1527613521579};\\\", \\\"{x:280,y:538,t:1527613521603};\\\", \\\"{x:280,y:537,t:1527613521618};\\\", \\\"{x:280,y:535,t:1527613521631};\\\", \\\"{x:280,y:533,t:1527613521647};\\\", \\\"{x:280,y:532,t:1527613521663};\\\", \\\"{x:280,y:530,t:1527613521680};\\\", \\\"{x:280,y:529,t:1527613521696};\\\", \\\"{x:283,y:524,t:1527613521713};\\\", \\\"{x:291,y:520,t:1527613521730};\\\", \\\"{x:301,y:518,t:1527613521746};\\\", \\\"{x:315,y:517,t:1527613521763};\\\", \\\"{x:330,y:517,t:1527613521780};\\\", \\\"{x:344,y:517,t:1527613521796};\\\", \\\"{x:351,y:517,t:1527613521812};\\\", \\\"{x:352,y:517,t:1527613521830};\\\", \\\"{x:353,y:517,t:1527613521891};\\\", \\\"{x:354,y:517,t:1527613522012};\\\", \\\"{x:355,y:517,t:1527613522027};\\\", \\\"{x:356,y:518,t:1527613522035};\\\", \\\"{x:358,y:519,t:1527613522067};\\\", \\\"{x:360,y:519,t:1527613522099};\\\", \\\"{x:361,y:519,t:1527613522113};\\\", \\\"{x:364,y:520,t:1527613522129};\\\", \\\"{x:366,y:521,t:1527613522146};\\\", \\\"{x:367,y:522,t:1527613522163};\\\", \\\"{x:368,y:522,t:1527613522203};\\\", \\\"{x:370,y:522,t:1527613522235};\\\", \\\"{x:370,y:523,t:1527613522251};\\\", \\\"{x:371,y:523,t:1527613522299};\\\", \\\"{x:373,y:523,t:1527613522740};\\\", \\\"{x:377,y:527,t:1527613522747};\\\", \\\"{x:382,y:530,t:1527613522760};\\\", \\\"{x:384,y:531,t:1527613522781};\\\", \\\"{x:386,y:531,t:1527613522898};\\\", \\\"{x:387,y:530,t:1527613522915};\\\", \\\"{x:388,y:529,t:1527613522988};\\\", \\\"{x:390,y:529,t:1527613523403};\\\", \\\"{x:407,y:537,t:1527613523416};\\\", \\\"{x:460,y:562,t:1527613523432};\\\", \\\"{x:519,y:580,t:1527613523448};\\\", \\\"{x:579,y:595,t:1527613523466};\\\", \\\"{x:631,y:606,t:1527613523481};\\\", \\\"{x:710,y:632,t:1527613523499};\\\", \\\"{x:756,y:651,t:1527613523515};\\\", \\\"{x:814,y:674,t:1527613523532};\\\", \\\"{x:886,y:706,t:1527613523548};\\\", \\\"{x:978,y:733,t:1527613523564};\\\", \\\"{x:1072,y:759,t:1527613523582};\\\", \\\"{x:1163,y:786,t:1527613523599};\\\", \\\"{x:1241,y:810,t:1527613523615};\\\", \\\"{x:1286,y:822,t:1527613523632};\\\", \\\"{x:1354,y:836,t:1527613523648};\\\", \\\"{x:1448,y:845,t:1527613523666};\\\", \\\"{x:1506,y:852,t:1527613523681};\\\", \\\"{x:1539,y:859,t:1527613523699};\\\", \\\"{x:1556,y:865,t:1527613523716};\\\", \\\"{x:1563,y:866,t:1527613523732};\\\", \\\"{x:1564,y:867,t:1527613523754};\\\", \\\"{x:1565,y:867,t:1527613523766};\\\", \\\"{x:1582,y:874,t:1527613523783};\\\", \\\"{x:1591,y:878,t:1527613523799};\\\", \\\"{x:1591,y:879,t:1527613523816};\\\", \\\"{x:1589,y:879,t:1527613524100};\\\", \\\"{x:1584,y:879,t:1527613524117};\\\", \\\"{x:1581,y:877,t:1527613524135};\\\", \\\"{x:1580,y:877,t:1527613524364};\\\", \\\"{x:1579,y:877,t:1527613524370};\\\", \\\"{x:1579,y:876,t:1527613524384};\\\", \\\"{x:1578,y:876,t:1527613524411};\\\", \\\"{x:1577,y:876,t:1527613524419};\\\", \\\"{x:1576,y:875,t:1527613524434};\\\", \\\"{x:1575,y:875,t:1527613524451};\\\", \\\"{x:1574,y:875,t:1527613524469};\\\", \\\"{x:1573,y:875,t:1527613524588};\\\", \\\"{x:1570,y:875,t:1527613526220};\\\", \\\"{x:1532,y:875,t:1527613526228};\\\", \\\"{x:1457,y:875,t:1527613526240};\\\", \\\"{x:1272,y:848,t:1527613526257};\\\", \\\"{x:1026,y:805,t:1527613526274};\\\", \\\"{x:771,y:763,t:1527613526290};\\\", \\\"{x:550,y:723,t:1527613526307};\\\", \\\"{x:416,y:712,t:1527613526323};\\\", \\\"{x:413,y:715,t:1527613526340};\\\", \\\"{x:412,y:715,t:1527613526362};\\\", \\\"{x:441,y:729,t:1527613526375};\\\", \\\"{x:561,y:771,t:1527613526393};\\\", \\\"{x:698,y:790,t:1527613526410};\\\", \\\"{x:723,y:797,t:1527613526426};\\\", \\\"{x:730,y:801,t:1527613526443};\\\", \\\"{x:732,y:801,t:1527613526499};\\\", \\\"{x:736,y:801,t:1527613526509};\\\", \\\"{x:752,y:801,t:1527613526526};\\\", \\\"{x:775,y:801,t:1527613526543};\\\", \\\"{x:804,y:802,t:1527613526559};\\\", \\\"{x:835,y:808,t:1527613526576};\\\", \\\"{x:868,y:811,t:1527613526592};\\\", \\\"{x:899,y:817,t:1527613526609};\\\", \\\"{x:959,y:826,t:1527613526626};\\\", \\\"{x:979,y:826,t:1527613526642};\\\", \\\"{x:1038,y:826,t:1527613526660};\\\", \\\"{x:1066,y:826,t:1527613526676};\\\", \\\"{x:1092,y:826,t:1527613526693};\\\", \\\"{x:1109,y:826,t:1527613526709};\\\", \\\"{x:1117,y:826,t:1527613526727};\\\", \\\"{x:1121,y:826,t:1527613526742};\\\", \\\"{x:1122,y:826,t:1527613526759};\\\", \\\"{x:1124,y:828,t:1527613526776};\\\", \\\"{x:1134,y:837,t:1527613526792};\\\", \\\"{x:1151,y:854,t:1527613526809};\\\", \\\"{x:1176,y:876,t:1527613526826};\\\", \\\"{x:1194,y:895,t:1527613526843};\\\", \\\"{x:1215,y:921,t:1527613526859};\\\", \\\"{x:1219,y:928,t:1527613526876};\\\", \\\"{x:1220,y:928,t:1527613526892};\\\", \\\"{x:1220,y:929,t:1527613526910};\\\", \\\"{x:1220,y:932,t:1527613526926};\\\", \\\"{x:1220,y:939,t:1527613526943};\\\", \\\"{x:1220,y:944,t:1527613526958};\\\", \\\"{x:1221,y:947,t:1527613526975};\\\", \\\"{x:1221,y:951,t:1527613526993};\\\", \\\"{x:1221,y:953,t:1527613527052};\\\", \\\"{x:1223,y:957,t:1527613527058};\\\", \\\"{x:1225,y:962,t:1527613527075};\\\", \\\"{x:1230,y:970,t:1527613527093};\\\", \\\"{x:1236,y:975,t:1527613527108};\\\", \\\"{x:1238,y:978,t:1527613527125};\\\", \\\"{x:1244,y:982,t:1527613527142};\\\", \\\"{x:1247,y:984,t:1527613527158};\\\", \\\"{x:1249,y:986,t:1527613527176};\\\", \\\"{x:1249,y:983,t:1527613527260};\\\", \\\"{x:1249,y:977,t:1527613527275};\\\", \\\"{x:1249,y:972,t:1527613527291};\\\", \\\"{x:1249,y:965,t:1527613527309};\\\", \\\"{x:1249,y:962,t:1527613527325};\\\", \\\"{x:1251,y:958,t:1527613527342};\\\", \\\"{x:1251,y:956,t:1527613527358};\\\", \\\"{x:1253,y:954,t:1527613527375};\\\", \\\"{x:1255,y:951,t:1527613527392};\\\", \\\"{x:1258,y:949,t:1527613527408};\\\", \\\"{x:1259,y:947,t:1527613527424};\\\", \\\"{x:1260,y:947,t:1527613527443};\\\", \\\"{x:1260,y:946,t:1527613527539};\\\", \\\"{x:1261,y:946,t:1527613527547};\\\", \\\"{x:1262,y:946,t:1527613527563};\\\", \\\"{x:1263,y:946,t:1527613527575};\\\", \\\"{x:1264,y:946,t:1527613527592};\\\", \\\"{x:1267,y:946,t:1527613527608};\\\", \\\"{x:1270,y:946,t:1527613527625};\\\", \\\"{x:1272,y:947,t:1527613527640};\\\", \\\"{x:1273,y:949,t:1527613527675};\\\", \\\"{x:1274,y:949,t:1527613527715};\\\", \\\"{x:1277,y:952,t:1527613527844};\\\", \\\"{x:1277,y:955,t:1527613527858};\\\", \\\"{x:1280,y:961,t:1527613527874};\\\", \\\"{x:1284,y:968,t:1527613527891};\\\", \\\"{x:1287,y:976,t:1527613527907};\\\", \\\"{x:1291,y:984,t:1527613527923};\\\", \\\"{x:1292,y:989,t:1527613527941};\\\", \\\"{x:1292,y:990,t:1527613527956};\\\", \\\"{x:1292,y:989,t:1527613528187};\\\", \\\"{x:1292,y:980,t:1527613528196};\\\", \\\"{x:1290,y:968,t:1527613528207};\\\", \\\"{x:1287,y:952,t:1527613528223};\\\", \\\"{x:1283,y:936,t:1527613528239};\\\", \\\"{x:1279,y:918,t:1527613528257};\\\", \\\"{x:1278,y:906,t:1527613528273};\\\", \\\"{x:1277,y:899,t:1527613528290};\\\", \\\"{x:1275,y:890,t:1527613528306};\\\", \\\"{x:1275,y:886,t:1527613528323};\\\", \\\"{x:1275,y:882,t:1527613528339};\\\", \\\"{x:1275,y:876,t:1527613528356};\\\", \\\"{x:1275,y:872,t:1527613528372};\\\", \\\"{x:1274,y:868,t:1527613528389};\\\", \\\"{x:1274,y:865,t:1527613528406};\\\", \\\"{x:1274,y:862,t:1527613528422};\\\", \\\"{x:1274,y:859,t:1527613528440};\\\", \\\"{x:1274,y:855,t:1527613528456};\\\", \\\"{x:1274,y:852,t:1527613528473};\\\", \\\"{x:1274,y:848,t:1527613528490};\\\", \\\"{x:1274,y:844,t:1527613528506};\\\", \\\"{x:1274,y:837,t:1527613528523};\\\", \\\"{x:1274,y:833,t:1527613528540};\\\", \\\"{x:1273,y:829,t:1527613528556};\\\", \\\"{x:1273,y:827,t:1527613528573};\\\", \\\"{x:1273,y:826,t:1527613528595};\\\", \\\"{x:1272,y:824,t:1527613528644};\\\", \\\"{x:1272,y:823,t:1527613528656};\\\", \\\"{x:1272,y:820,t:1527613528673};\\\", \\\"{x:1271,y:819,t:1527613528688};\\\", \\\"{x:1271,y:817,t:1527613528706};\\\", \\\"{x:1271,y:814,t:1527613528722};\\\", \\\"{x:1270,y:810,t:1527613528739};\\\", \\\"{x:1270,y:807,t:1527613528755};\\\", \\\"{x:1270,y:801,t:1527613528771};\\\", \\\"{x:1270,y:795,t:1527613528788};\\\", \\\"{x:1268,y:788,t:1527613528805};\\\", \\\"{x:1267,y:784,t:1527613528821};\\\", \\\"{x:1267,y:781,t:1527613528838};\\\", \\\"{x:1267,y:777,t:1527613528856};\\\", \\\"{x:1266,y:773,t:1527613528871};\\\", \\\"{x:1264,y:770,t:1527613528888};\\\", \\\"{x:1264,y:769,t:1527613528905};\\\", \\\"{x:1264,y:766,t:1527613528922};\\\", \\\"{x:1264,y:761,t:1527613528938};\\\", \\\"{x:1263,y:758,t:1527613528954};\\\", \\\"{x:1262,y:754,t:1527613528971};\\\", \\\"{x:1261,y:748,t:1527613528988};\\\", \\\"{x:1261,y:746,t:1527613529004};\\\", \\\"{x:1261,y:744,t:1527613529022};\\\", \\\"{x:1260,y:742,t:1527613529038};\\\", \\\"{x:1259,y:739,t:1527613529054};\\\", \\\"{x:1259,y:734,t:1527613529071};\\\", \\\"{x:1259,y:730,t:1527613529087};\\\", \\\"{x:1259,y:725,t:1527613529104};\\\", \\\"{x:1259,y:720,t:1527613529121};\\\", \\\"{x:1259,y:717,t:1527613529138};\\\", \\\"{x:1259,y:708,t:1527613529155};\\\", \\\"{x:1257,y:701,t:1527613529172};\\\", \\\"{x:1257,y:696,t:1527613529188};\\\", \\\"{x:1256,y:694,t:1527613529205};\\\", \\\"{x:1256,y:691,t:1527613529222};\\\", \\\"{x:1256,y:690,t:1527613529238};\\\", \\\"{x:1256,y:688,t:1527613529254};\\\", \\\"{x:1256,y:685,t:1527613529270};\\\", \\\"{x:1255,y:683,t:1527613529287};\\\", \\\"{x:1255,y:681,t:1527613529305};\\\", \\\"{x:1255,y:680,t:1527613529321};\\\", \\\"{x:1255,y:678,t:1527613529338};\\\", \\\"{x:1255,y:675,t:1527613529354};\\\", \\\"{x:1255,y:672,t:1527613529371};\\\", \\\"{x:1254,y:668,t:1527613529387};\\\", \\\"{x:1253,y:664,t:1527613529405};\\\", \\\"{x:1252,y:656,t:1527613529421};\\\", \\\"{x:1251,y:651,t:1527613529438};\\\", \\\"{x:1251,y:648,t:1527613529454};\\\", \\\"{x:1250,y:644,t:1527613529470};\\\", \\\"{x:1250,y:642,t:1527613529487};\\\", \\\"{x:1249,y:641,t:1527613529503};\\\", \\\"{x:1249,y:639,t:1527613529521};\\\", \\\"{x:1249,y:638,t:1527613529538};\\\", \\\"{x:1249,y:636,t:1527613529554};\\\", \\\"{x:1249,y:635,t:1527613529571};\\\", \\\"{x:1249,y:633,t:1527613529588};\\\", \\\"{x:1249,y:632,t:1527613529604};\\\", \\\"{x:1249,y:629,t:1527613529621};\\\", \\\"{x:1249,y:628,t:1527613529643};\\\", \\\"{x:1249,y:627,t:1527613529654};\\\", \\\"{x:1248,y:626,t:1527613529875};\\\", \\\"{x:1239,y:626,t:1527613529887};\\\", \\\"{x:1208,y:626,t:1527613529904};\\\", \\\"{x:1168,y:626,t:1527613529919};\\\", \\\"{x:1122,y:629,t:1527613529937};\\\", \\\"{x:1090,y:631,t:1527613529953};\\\", \\\"{x:1075,y:632,t:1527613529969};\\\", \\\"{x:1071,y:633,t:1527613529987};\\\", \\\"{x:1068,y:634,t:1527613530002};\\\", \\\"{x:1063,y:636,t:1527613530019};\\\", \\\"{x:1054,y:638,t:1527613530037};\\\", \\\"{x:1033,y:645,t:1527613530053};\\\", \\\"{x:1008,y:655,t:1527613530071};\\\", \\\"{x:988,y:665,t:1527613530086};\\\", \\\"{x:974,y:672,t:1527613530102};\\\", \\\"{x:961,y:681,t:1527613530119};\\\", \\\"{x:946,y:689,t:1527613530135};\\\", \\\"{x:930,y:702,t:1527613530152};\\\", \\\"{x:904,y:715,t:1527613530169};\\\", \\\"{x:869,y:729,t:1527613530185};\\\", \\\"{x:806,y:745,t:1527613530202};\\\", \\\"{x:767,y:750,t:1527613530219};\\\", \\\"{x:728,y:754,t:1527613530235};\\\", \\\"{x:706,y:754,t:1527613530252};\\\", \\\"{x:687,y:754,t:1527613530268};\\\", \\\"{x:675,y:754,t:1527613530285};\\\", \\\"{x:667,y:754,t:1527613530303};\\\", \\\"{x:664,y:754,t:1527613530319};\\\", \\\"{x:663,y:754,t:1527613530335};\\\", \\\"{x:660,y:754,t:1527613530352};\\\", \\\"{x:656,y:754,t:1527613530368};\\\", \\\"{x:656,y:753,t:1527613530386};\\\", \\\"{x:655,y:753,t:1527613530402};\\\", \\\"{x:652,y:751,t:1527613530418};\\\", \\\"{x:646,y:750,t:1527613530435};\\\", \\\"{x:637,y:748,t:1527613530451};\\\", \\\"{x:630,y:747,t:1527613530468};\\\", \\\"{x:624,y:746,t:1527613530485};\\\", \\\"{x:620,y:746,t:1527613530501};\\\", \\\"{x:613,y:743,t:1527613530518};\\\", \\\"{x:606,y:742,t:1527613530536};\\\", \\\"{x:595,y:738,t:1527613530552};\\\", \\\"{x:585,y:735,t:1527613530569};\\\", \\\"{x:564,y:729,t:1527613530586};\\\", \\\"{x:548,y:724,t:1527613530601};\\\", \\\"{x:527,y:719,t:1527613530618};\\\", \\\"{x:506,y:713,t:1527613530637};\\\", \\\"{x:490,y:707,t:1527613530653};\\\", \\\"{x:479,y:702,t:1527613530670};\\\", \\\"{x:475,y:701,t:1527613530687};\\\", \\\"{x:473,y:701,t:1527613530703};\\\", \\\"{x:474,y:701,t:1527613531211};\\\", \\\"{x:476,y:701,t:1527613531221};\\\", \\\"{x:482,y:702,t:1527613531237};\\\", \\\"{x:488,y:703,t:1527613531255};\\\", \\\"{x:500,y:704,t:1527613531270};\\\", \\\"{x:508,y:707,t:1527613531288};\\\", \\\"{x:512,y:708,t:1527613531304};\\\", \\\"{x:513,y:708,t:1527613531363};\\\" ] }, { \\\"rt\\\": 15268, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 149672, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:705,t:1527613537716};\\\", \\\"{x:673,y:652,t:1527613537732};\\\", \\\"{x:816,y:641,t:1527613537751};\\\", \\\"{x:1067,y:656,t:1527613537776};\\\", \\\"{x:1167,y:669,t:1527613537794};\\\", \\\"{x:1205,y:675,t:1527613537809};\\\", \\\"{x:1218,y:676,t:1527613537826};\\\", \\\"{x:1219,y:676,t:1527613537843};\\\", \\\"{x:1221,y:676,t:1527613537859};\\\", \\\"{x:1228,y:676,t:1527613537876};\\\", \\\"{x:1247,y:675,t:1527613537893};\\\", \\\"{x:1269,y:668,t:1527613537909};\\\", \\\"{x:1316,y:650,t:1527613537926};\\\", \\\"{x:1376,y:627,t:1527613537943};\\\", \\\"{x:1418,y:620,t:1527613537959};\\\", \\\"{x:1456,y:613,t:1527613537976};\\\", \\\"{x:1485,y:608,t:1527613537994};\\\", \\\"{x:1509,y:608,t:1527613538009};\\\", \\\"{x:1539,y:608,t:1527613538026};\\\", \\\"{x:1550,y:612,t:1527613538044};\\\", \\\"{x:1566,y:620,t:1527613538059};\\\", \\\"{x:1586,y:625,t:1527613538076};\\\", \\\"{x:1593,y:629,t:1527613538093};\\\", \\\"{x:1594,y:629,t:1527613538111};\\\", \\\"{x:1594,y:631,t:1527613538130};\\\", \\\"{x:1594,y:638,t:1527613538143};\\\", \\\"{x:1594,y:663,t:1527613538160};\\\", \\\"{x:1583,y:697,t:1527613538176};\\\", \\\"{x:1577,y:721,t:1527613538194};\\\", \\\"{x:1571,y:742,t:1527613538210};\\\", \\\"{x:1566,y:766,t:1527613538227};\\\", \\\"{x:1565,y:777,t:1527613538243};\\\", \\\"{x:1563,y:786,t:1527613538261};\\\", \\\"{x:1562,y:795,t:1527613538276};\\\", \\\"{x:1560,y:809,t:1527613538294};\\\", \\\"{x:1555,y:825,t:1527613538310};\\\", \\\"{x:1550,y:843,t:1527613538326};\\\", \\\"{x:1545,y:856,t:1527613538343};\\\", \\\"{x:1543,y:864,t:1527613538360};\\\", \\\"{x:1540,y:871,t:1527613538377};\\\", \\\"{x:1537,y:876,t:1527613538394};\\\", \\\"{x:1525,y:893,t:1527613538410};\\\", \\\"{x:1516,y:903,t:1527613538427};\\\", \\\"{x:1509,y:910,t:1527613538444};\\\", \\\"{x:1503,y:917,t:1527613538461};\\\", \\\"{x:1499,y:921,t:1527613538477};\\\", \\\"{x:1497,y:922,t:1527613538494};\\\", \\\"{x:1495,y:923,t:1527613538511};\\\", \\\"{x:1494,y:924,t:1527613538527};\\\", \\\"{x:1492,y:925,t:1527613538544};\\\", \\\"{x:1490,y:925,t:1527613538561};\\\", \\\"{x:1487,y:927,t:1527613538578};\\\", \\\"{x:1486,y:927,t:1527613538594};\\\", \\\"{x:1483,y:929,t:1527613538610};\\\", \\\"{x:1478,y:931,t:1527613538627};\\\", \\\"{x:1473,y:933,t:1527613538644};\\\", \\\"{x:1467,y:935,t:1527613538661};\\\", \\\"{x:1459,y:937,t:1527613538678};\\\", \\\"{x:1455,y:939,t:1527613538694};\\\", \\\"{x:1452,y:940,t:1527613538711};\\\", \\\"{x:1450,y:941,t:1527613538728};\\\", \\\"{x:1449,y:941,t:1527613538744};\\\", \\\"{x:1447,y:941,t:1527613538760};\\\", \\\"{x:1446,y:941,t:1527613538777};\\\", \\\"{x:1445,y:942,t:1527613538793};\\\", \\\"{x:1443,y:942,t:1527613538810};\\\", \\\"{x:1441,y:943,t:1527613538827};\\\", \\\"{x:1439,y:943,t:1527613538844};\\\", \\\"{x:1437,y:943,t:1527613538861};\\\", \\\"{x:1434,y:943,t:1527613538877};\\\", \\\"{x:1431,y:943,t:1527613538893};\\\", \\\"{x:1429,y:943,t:1527613538910};\\\", \\\"{x:1426,y:943,t:1527613538927};\\\", \\\"{x:1421,y:943,t:1527613538944};\\\", \\\"{x:1403,y:943,t:1527613538960};\\\", \\\"{x:1360,y:943,t:1527613538978};\\\", \\\"{x:1322,y:944,t:1527613538994};\\\", \\\"{x:1295,y:948,t:1527613539010};\\\", \\\"{x:1280,y:949,t:1527613539028};\\\", \\\"{x:1275,y:949,t:1527613539045};\\\", \\\"{x:1278,y:949,t:1527613539659};\\\", \\\"{x:1281,y:950,t:1527613539667};\\\", \\\"{x:1283,y:950,t:1527613539678};\\\", \\\"{x:1285,y:950,t:1527613539695};\\\", \\\"{x:1286,y:950,t:1527613539712};\\\", \\\"{x:1287,y:952,t:1527613539728};\\\", \\\"{x:1289,y:952,t:1527613539746};\\\", \\\"{x:1292,y:952,t:1527613539761};\\\", \\\"{x:1294,y:953,t:1527613539778};\\\", \\\"{x:1299,y:954,t:1527613539794};\\\", \\\"{x:1303,y:954,t:1527613539811};\\\", \\\"{x:1306,y:954,t:1527613539829};\\\", \\\"{x:1310,y:954,t:1527613539845};\\\", \\\"{x:1313,y:954,t:1527613539861};\\\", \\\"{x:1314,y:954,t:1527613539878};\\\", \\\"{x:1316,y:953,t:1527613539895};\\\", \\\"{x:1318,y:952,t:1527613539911};\\\", \\\"{x:1327,y:948,t:1527613539928};\\\", \\\"{x:1352,y:936,t:1527613539944};\\\", \\\"{x:1375,y:927,t:1527613539962};\\\", \\\"{x:1401,y:913,t:1527613539978};\\\", \\\"{x:1413,y:908,t:1527613539994};\\\", \\\"{x:1419,y:904,t:1527613540012};\\\", \\\"{x:1424,y:900,t:1527613540029};\\\", \\\"{x:1429,y:896,t:1527613540044};\\\", \\\"{x:1437,y:889,t:1527613540062};\\\", \\\"{x:1439,y:886,t:1527613540079};\\\", \\\"{x:1445,y:879,t:1527613540094};\\\", \\\"{x:1453,y:874,t:1527613540112};\\\", \\\"{x:1458,y:870,t:1527613540129};\\\", \\\"{x:1464,y:866,t:1527613540144};\\\", \\\"{x:1471,y:862,t:1527613540162};\\\", \\\"{x:1478,y:858,t:1527613540178};\\\", \\\"{x:1482,y:856,t:1527613540195};\\\", \\\"{x:1486,y:853,t:1527613540211};\\\", \\\"{x:1489,y:851,t:1527613540229};\\\", \\\"{x:1496,y:848,t:1527613540245};\\\", \\\"{x:1509,y:843,t:1527613540262};\\\", \\\"{x:1522,y:838,t:1527613540278};\\\", \\\"{x:1537,y:830,t:1527613540296};\\\", \\\"{x:1551,y:827,t:1527613540312};\\\", \\\"{x:1571,y:822,t:1527613540329};\\\", \\\"{x:1596,y:815,t:1527613540346};\\\", \\\"{x:1637,y:802,t:1527613540362};\\\", \\\"{x:1719,y:772,t:1527613540378};\\\", \\\"{x:1816,y:732,t:1527613540395};\\\", \\\"{x:1895,y:700,t:1527613540411};\\\", \\\"{x:1913,y:689,t:1527613540428};\\\", \\\"{x:1918,y:684,t:1527613540445};\\\", \\\"{x:1919,y:683,t:1527613540461};\\\", \\\"{x:1919,y:679,t:1527613540478};\\\", \\\"{x:1919,y:673,t:1527613540496};\\\", \\\"{x:1919,y:666,t:1527613540511};\\\", \\\"{x:1919,y:652,t:1527613540529};\\\", \\\"{x:1919,y:636,t:1527613540546};\\\", \\\"{x:1919,y:625,t:1527613540561};\\\", \\\"{x:1917,y:610,t:1527613540578};\\\", \\\"{x:1913,y:600,t:1527613540595};\\\", \\\"{x:1911,y:594,t:1527613540611};\\\", \\\"{x:1908,y:589,t:1527613540629};\\\", \\\"{x:1903,y:585,t:1527613540645};\\\", \\\"{x:1900,y:580,t:1527613540661};\\\", \\\"{x:1895,y:576,t:1527613540679};\\\", \\\"{x:1893,y:575,t:1527613540696};\\\", \\\"{x:1891,y:574,t:1527613540712};\\\", \\\"{x:1882,y:570,t:1527613540729};\\\", \\\"{x:1867,y:564,t:1527613540745};\\\", \\\"{x:1844,y:554,t:1527613540762};\\\", \\\"{x:1835,y:550,t:1527613540778};\\\", \\\"{x:1829,y:549,t:1527613540795};\\\", \\\"{x:1827,y:548,t:1527613540812};\\\", \\\"{x:1826,y:547,t:1527613540829};\\\", \\\"{x:1825,y:547,t:1527613540845};\\\", \\\"{x:1815,y:547,t:1527613540862};\\\", \\\"{x:1795,y:548,t:1527613540879};\\\", \\\"{x:1768,y:548,t:1527613540895};\\\", \\\"{x:1743,y:548,t:1527613540913};\\\", \\\"{x:1720,y:549,t:1527613540928};\\\", \\\"{x:1702,y:549,t:1527613540946};\\\", \\\"{x:1695,y:549,t:1527613540962};\\\", \\\"{x:1693,y:547,t:1527613541043};\\\", \\\"{x:1692,y:538,t:1527613541051};\\\", \\\"{x:1689,y:528,t:1527613541063};\\\", \\\"{x:1687,y:510,t:1527613541078};\\\", \\\"{x:1685,y:500,t:1527613541096};\\\", \\\"{x:1684,y:491,t:1527613541113};\\\", \\\"{x:1682,y:484,t:1527613541129};\\\", \\\"{x:1680,y:481,t:1527613541146};\\\", \\\"{x:1679,y:479,t:1527613541162};\\\", \\\"{x:1678,y:476,t:1527613541179};\\\", \\\"{x:1676,y:474,t:1527613541196};\\\", \\\"{x:1674,y:472,t:1527613541213};\\\", \\\"{x:1673,y:470,t:1527613541229};\\\", \\\"{x:1669,y:465,t:1527613541246};\\\", \\\"{x:1667,y:463,t:1527613541263};\\\", \\\"{x:1664,y:459,t:1527613541279};\\\", \\\"{x:1662,y:457,t:1527613541296};\\\", \\\"{x:1659,y:454,t:1527613541313};\\\", \\\"{x:1656,y:451,t:1527613541330};\\\", \\\"{x:1654,y:450,t:1527613541345};\\\", \\\"{x:1653,y:449,t:1527613541363};\\\", \\\"{x:1651,y:448,t:1527613541380};\\\", \\\"{x:1649,y:447,t:1527613541402};\\\", \\\"{x:1647,y:446,t:1527613541418};\\\", \\\"{x:1646,y:445,t:1527613541458};\\\", \\\"{x:1643,y:445,t:1527613541483};\\\", \\\"{x:1642,y:444,t:1527613541496};\\\", \\\"{x:1638,y:443,t:1527613541513};\\\", \\\"{x:1637,y:443,t:1527613541530};\\\", \\\"{x:1635,y:443,t:1527613541546};\\\", \\\"{x:1632,y:442,t:1527613541563};\\\", \\\"{x:1630,y:442,t:1527613541580};\\\", \\\"{x:1629,y:442,t:1527613541596};\\\", \\\"{x:1629,y:441,t:1527613541613};\\\", \\\"{x:1627,y:440,t:1527613541650};\\\", \\\"{x:1624,y:439,t:1527613541666};\\\", \\\"{x:1623,y:439,t:1527613541691};\\\", \\\"{x:1623,y:438,t:1527613541699};\\\", \\\"{x:1622,y:438,t:1527613541723};\\\", \\\"{x:1621,y:439,t:1527613541875};\\\", \\\"{x:1619,y:448,t:1527613541883};\\\", \\\"{x:1619,y:456,t:1527613541897};\\\", \\\"{x:1618,y:469,t:1527613541913};\\\", \\\"{x:1617,y:478,t:1527613541930};\\\", \\\"{x:1617,y:486,t:1527613541947};\\\", \\\"{x:1617,y:489,t:1527613541963};\\\", \\\"{x:1617,y:491,t:1527613541980};\\\", \\\"{x:1617,y:495,t:1527613541997};\\\", \\\"{x:1619,y:498,t:1527613542013};\\\", \\\"{x:1621,y:503,t:1527613542030};\\\", \\\"{x:1623,y:507,t:1527613542047};\\\", \\\"{x:1626,y:513,t:1527613542063};\\\", \\\"{x:1630,y:521,t:1527613542080};\\\", \\\"{x:1632,y:527,t:1527613542097};\\\", \\\"{x:1634,y:532,t:1527613542113};\\\", \\\"{x:1635,y:539,t:1527613542131};\\\", \\\"{x:1636,y:547,t:1527613542146};\\\", \\\"{x:1637,y:555,t:1527613542164};\\\", \\\"{x:1639,y:562,t:1527613542180};\\\", \\\"{x:1639,y:568,t:1527613542197};\\\", \\\"{x:1639,y:577,t:1527613542214};\\\", \\\"{x:1639,y:584,t:1527613542229};\\\", \\\"{x:1639,y:588,t:1527613542247};\\\", \\\"{x:1639,y:594,t:1527613542264};\\\", \\\"{x:1638,y:601,t:1527613542280};\\\", \\\"{x:1638,y:607,t:1527613542297};\\\", \\\"{x:1638,y:613,t:1527613542314};\\\", \\\"{x:1638,y:616,t:1527613542330};\\\", \\\"{x:1637,y:624,t:1527613542347};\\\", \\\"{x:1637,y:630,t:1527613542364};\\\", \\\"{x:1634,y:639,t:1527613542380};\\\", \\\"{x:1633,y:647,t:1527613542397};\\\", \\\"{x:1633,y:653,t:1527613542414};\\\", \\\"{x:1633,y:655,t:1527613542430};\\\", \\\"{x:1631,y:659,t:1527613542447};\\\", \\\"{x:1631,y:661,t:1527613542464};\\\", \\\"{x:1630,y:662,t:1527613542480};\\\", \\\"{x:1630,y:664,t:1527613542498};\\\", \\\"{x:1630,y:665,t:1527613542514};\\\", \\\"{x:1630,y:667,t:1527613542531};\\\", \\\"{x:1629,y:671,t:1527613542547};\\\", \\\"{x:1628,y:675,t:1527613542564};\\\", \\\"{x:1627,y:681,t:1527613542580};\\\", \\\"{x:1626,y:687,t:1527613542597};\\\", \\\"{x:1625,y:691,t:1527613542614};\\\", \\\"{x:1624,y:697,t:1527613542630};\\\", \\\"{x:1624,y:704,t:1527613542647};\\\", \\\"{x:1622,y:710,t:1527613542664};\\\", \\\"{x:1622,y:714,t:1527613542681};\\\", \\\"{x:1622,y:721,t:1527613542697};\\\", \\\"{x:1622,y:729,t:1527613542714};\\\", \\\"{x:1622,y:736,t:1527613542731};\\\", \\\"{x:1622,y:740,t:1527613542747};\\\", \\\"{x:1622,y:744,t:1527613542764};\\\", \\\"{x:1622,y:747,t:1527613542781};\\\", \\\"{x:1622,y:749,t:1527613542797};\\\", \\\"{x:1622,y:752,t:1527613542814};\\\", \\\"{x:1622,y:756,t:1527613542831};\\\", \\\"{x:1622,y:761,t:1527613542846};\\\", \\\"{x:1622,y:764,t:1527613542864};\\\", \\\"{x:1622,y:767,t:1527613542881};\\\", \\\"{x:1622,y:771,t:1527613542897};\\\", \\\"{x:1622,y:774,t:1527613542914};\\\", \\\"{x:1622,y:779,t:1527613542931};\\\", \\\"{x:1622,y:787,t:1527613542947};\\\", \\\"{x:1622,y:799,t:1527613542964};\\\", \\\"{x:1622,y:815,t:1527613542982};\\\", \\\"{x:1622,y:831,t:1527613542997};\\\", \\\"{x:1622,y:845,t:1527613543014};\\\", \\\"{x:1622,y:852,t:1527613543031};\\\", \\\"{x:1622,y:857,t:1527613543047};\\\", \\\"{x:1622,y:859,t:1527613543064};\\\", \\\"{x:1622,y:863,t:1527613543081};\\\", \\\"{x:1622,y:866,t:1527613543098};\\\", \\\"{x:1622,y:875,t:1527613543115};\\\", \\\"{x:1622,y:881,t:1527613543130};\\\", \\\"{x:1623,y:885,t:1527613543148};\\\", \\\"{x:1623,y:889,t:1527613543164};\\\", \\\"{x:1623,y:893,t:1527613543181};\\\", \\\"{x:1623,y:903,t:1527613543198};\\\", \\\"{x:1625,y:914,t:1527613543214};\\\", \\\"{x:1625,y:921,t:1527613543230};\\\", \\\"{x:1628,y:932,t:1527613543248};\\\", \\\"{x:1629,y:939,t:1527613543263};\\\", \\\"{x:1629,y:945,t:1527613543281};\\\", \\\"{x:1629,y:948,t:1527613543297};\\\", \\\"{x:1630,y:950,t:1527613543314};\\\", \\\"{x:1630,y:951,t:1527613543330};\\\", \\\"{x:1629,y:952,t:1527613543348};\\\", \\\"{x:1617,y:953,t:1527613543363};\\\", \\\"{x:1597,y:953,t:1527613543380};\\\", \\\"{x:1550,y:934,t:1527613543398};\\\", \\\"{x:1435,y:890,t:1527613543413};\\\", \\\"{x:1256,y:815,t:1527613543430};\\\", \\\"{x:1068,y:767,t:1527613543448};\\\", \\\"{x:904,y:736,t:1527613543464};\\\", \\\"{x:793,y:715,t:1527613543480};\\\", \\\"{x:707,y:693,t:1527613543497};\\\", \\\"{x:637,y:672,t:1527613543514};\\\", \\\"{x:609,y:667,t:1527613543531};\\\", \\\"{x:585,y:667,t:1527613543547};\\\", \\\"{x:561,y:667,t:1527613543564};\\\", \\\"{x:540,y:674,t:1527613543581};\\\", \\\"{x:523,y:678,t:1527613543598};\\\", \\\"{x:514,y:681,t:1527613543614};\\\", \\\"{x:512,y:682,t:1527613543630};\\\", \\\"{x:511,y:682,t:1527613543690};\\\", \\\"{x:505,y:678,t:1527613543699};\\\", \\\"{x:490,y:656,t:1527613543714};\\\", \\\"{x:481,y:644,t:1527613543733};\\\", \\\"{x:468,y:630,t:1527613543747};\\\", \\\"{x:460,y:624,t:1527613543764};\\\", \\\"{x:456,y:621,t:1527613543780};\\\", \\\"{x:456,y:620,t:1527613543797};\\\", \\\"{x:456,y:618,t:1527613543815};\\\", \\\"{x:453,y:612,t:1527613543830};\\\", \\\"{x:438,y:589,t:1527613543847};\\\", \\\"{x:404,y:553,t:1527613543865};\\\", \\\"{x:379,y:535,t:1527613543882};\\\", \\\"{x:360,y:528,t:1527613543898};\\\", \\\"{x:357,y:527,t:1527613543914};\\\", \\\"{x:355,y:527,t:1527613543962};\\\", \\\"{x:351,y:529,t:1527613543970};\\\", \\\"{x:346,y:532,t:1527613543982};\\\", \\\"{x:340,y:542,t:1527613543998};\\\", \\\"{x:334,y:553,t:1527613544014};\\\", \\\"{x:332,y:560,t:1527613544031};\\\", \\\"{x:332,y:566,t:1527613544047};\\\", \\\"{x:333,y:574,t:1527613544064};\\\", \\\"{x:344,y:584,t:1527613544082};\\\", \\\"{x:365,y:594,t:1527613544097};\\\", \\\"{x:420,y:608,t:1527613544114};\\\", \\\"{x:457,y:614,t:1527613544132};\\\", \\\"{x:490,y:619,t:1527613544147};\\\", \\\"{x:514,y:620,t:1527613544165};\\\", \\\"{x:525,y:620,t:1527613544181};\\\", \\\"{x:535,y:620,t:1527613544197};\\\", \\\"{x:540,y:619,t:1527613544215};\\\", \\\"{x:545,y:616,t:1527613544231};\\\", \\\"{x:550,y:615,t:1527613544249};\\\", \\\"{x:559,y:611,t:1527613544265};\\\", \\\"{x:567,y:607,t:1527613544281};\\\", \\\"{x:571,y:606,t:1527613544297};\\\", \\\"{x:576,y:603,t:1527613544315};\\\", \\\"{x:581,y:601,t:1527613544331};\\\", \\\"{x:587,y:599,t:1527613544348};\\\", \\\"{x:591,y:597,t:1527613544364};\\\", \\\"{x:596,y:596,t:1527613544381};\\\", \\\"{x:604,y:594,t:1527613544399};\\\", \\\"{x:610,y:592,t:1527613544414};\\\", \\\"{x:617,y:590,t:1527613544431};\\\", \\\"{x:625,y:587,t:1527613544448};\\\", \\\"{x:635,y:583,t:1527613544465};\\\", \\\"{x:642,y:580,t:1527613544483};\\\", \\\"{x:643,y:580,t:1527613544521};\\\", \\\"{x:643,y:578,t:1527613544532};\\\", \\\"{x:627,y:572,t:1527613544549};\\\", \\\"{x:596,y:572,t:1527613544565};\\\", \\\"{x:541,y:572,t:1527613544582};\\\", \\\"{x:449,y:572,t:1527613544599};\\\", \\\"{x:377,y:572,t:1527613544616};\\\", \\\"{x:347,y:575,t:1527613544633};\\\", \\\"{x:338,y:576,t:1527613544648};\\\", \\\"{x:337,y:576,t:1527613544723};\\\", \\\"{x:334,y:577,t:1527613544732};\\\", \\\"{x:327,y:583,t:1527613544750};\\\", \\\"{x:321,y:589,t:1527613544766};\\\", \\\"{x:310,y:599,t:1527613544782};\\\", \\\"{x:300,y:606,t:1527613544799};\\\", \\\"{x:285,y:617,t:1527613544816};\\\", \\\"{x:274,y:623,t:1527613544832};\\\", \\\"{x:266,y:627,t:1527613544849};\\\", \\\"{x:259,y:631,t:1527613544866};\\\", \\\"{x:256,y:632,t:1527613544882};\\\", \\\"{x:251,y:635,t:1527613544899};\\\", \\\"{x:242,y:639,t:1527613544916};\\\", \\\"{x:232,y:639,t:1527613544932};\\\", \\\"{x:223,y:639,t:1527613544949};\\\", \\\"{x:217,y:639,t:1527613544966};\\\", \\\"{x:213,y:639,t:1527613544982};\\\", \\\"{x:211,y:639,t:1527613544999};\\\", \\\"{x:210,y:638,t:1527613545075};\\\", \\\"{x:209,y:638,t:1527613545131};\\\", \\\"{x:207,y:637,t:1527613545138};\\\", \\\"{x:207,y:636,t:1527613545149};\\\", \\\"{x:206,y:636,t:1527613545179};\\\", \\\"{x:200,y:636,t:1527613545625};\\\", \\\"{x:195,y:637,t:1527613545634};\\\", \\\"{x:184,y:637,t:1527613545648};\\\", \\\"{x:158,y:638,t:1527613545666};\\\", \\\"{x:145,y:638,t:1527613545682};\\\", \\\"{x:141,y:639,t:1527613545699};\\\", \\\"{x:141,y:640,t:1527613546371};\\\", \\\"{x:142,y:640,t:1527613546674};\\\", \\\"{x:142,y:638,t:1527613546778};\\\", \\\"{x:142,y:637,t:1527613547107};\\\", \\\"{x:143,y:637,t:1527613547117};\\\", \\\"{x:144,y:637,t:1527613547162};\\\", \\\"{x:146,y:637,t:1527613547202};\\\", \\\"{x:147,y:637,t:1527613547226};\\\", \\\"{x:149,y:637,t:1527613547268};\\\", \\\"{x:150,y:637,t:1527613547298};\\\", \\\"{x:152,y:637,t:1527613547843};\\\", \\\"{x:153,y:637,t:1527613547850};\\\", \\\"{x:160,y:639,t:1527613547868};\\\", \\\"{x:189,y:650,t:1527613547886};\\\", \\\"{x:252,y:675,t:1527613547901};\\\", \\\"{x:324,y:694,t:1527613547917};\\\", \\\"{x:387,y:719,t:1527613547935};\\\", \\\"{x:499,y:758,t:1527613547951};\\\", \\\"{x:566,y:777,t:1527613547968};\\\", \\\"{x:581,y:782,t:1527613547984};\\\", \\\"{x:588,y:782,t:1527613548000};\\\", \\\"{x:591,y:783,t:1527613548018};\\\", \\\"{x:592,y:783,t:1527613548034};\\\", \\\"{x:593,y:783,t:1527613548138};\\\", \\\"{x:593,y:779,t:1527613548151};\\\", \\\"{x:591,y:771,t:1527613548167};\\\", \\\"{x:590,y:769,t:1527613548184};\\\", \\\"{x:587,y:765,t:1527613548201};\\\", \\\"{x:584,y:761,t:1527613548218};\\\", \\\"{x:580,y:759,t:1527613548235};\\\", \\\"{x:579,y:758,t:1527613548250};\\\", \\\"{x:576,y:757,t:1527613548267};\\\", \\\"{x:576,y:756,t:1527613548285};\\\", \\\"{x:568,y:753,t:1527613548300};\\\", \\\"{x:546,y:744,t:1527613548318};\\\", \\\"{x:523,y:734,t:1527613548335};\\\", \\\"{x:512,y:729,t:1527613548352};\\\", \\\"{x:511,y:728,t:1527613548367};\\\", \\\"{x:509,y:728,t:1527613548384};\\\", \\\"{x:508,y:726,t:1527613548402};\\\" ] }, { \\\"rt\\\": 42590, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 193547, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -C -11 AM-11 AM-Z -Z -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:728,t:1527613563634};\\\", \\\"{x:669,y:771,t:1527613563653};\\\", \\\"{x:776,y:799,t:1527613563668};\\\", \\\"{x:847,y:815,t:1527613563684};\\\", \\\"{x:866,y:819,t:1527613563694};\\\", \\\"{x:888,y:827,t:1527613563710};\\\", \\\"{x:890,y:827,t:1527613563727};\\\", \\\"{x:892,y:828,t:1527613563744};\\\", \\\"{x:896,y:828,t:1527613563761};\\\", \\\"{x:904,y:828,t:1527613563777};\\\", \\\"{x:923,y:828,t:1527613563794};\\\", \\\"{x:952,y:833,t:1527613563810};\\\", \\\"{x:980,y:837,t:1527613563827};\\\", \\\"{x:1011,y:839,t:1527613563845};\\\", \\\"{x:1031,y:841,t:1527613563860};\\\", \\\"{x:1041,y:843,t:1527613563878};\\\", \\\"{x:1054,y:843,t:1527613563894};\\\", \\\"{x:1067,y:843,t:1527613563910};\\\", \\\"{x:1078,y:842,t:1527613563928};\\\", \\\"{x:1093,y:835,t:1527613563944};\\\", \\\"{x:1108,y:828,t:1527613563960};\\\", \\\"{x:1142,y:806,t:1527613563978};\\\", \\\"{x:1205,y:764,t:1527613563994};\\\", \\\"{x:1298,y:728,t:1527613564011};\\\", \\\"{x:1370,y:710,t:1527613564027};\\\", \\\"{x:1414,y:699,t:1527613564045};\\\", \\\"{x:1438,y:696,t:1527613564060};\\\", \\\"{x:1456,y:695,t:1527613564078};\\\", \\\"{x:1465,y:694,t:1527613564094};\\\", \\\"{x:1468,y:694,t:1527613564111};\\\", \\\"{x:1474,y:694,t:1527613564128};\\\", \\\"{x:1482,y:694,t:1527613564145};\\\", \\\"{x:1492,y:694,t:1527613564161};\\\", \\\"{x:1510,y:694,t:1527613564178};\\\", \\\"{x:1522,y:694,t:1527613564194};\\\", \\\"{x:1527,y:694,t:1527613564212};\\\", \\\"{x:1527,y:695,t:1527613564323};\\\", \\\"{x:1522,y:702,t:1527613564330};\\\", \\\"{x:1514,y:711,t:1527613564345};\\\", \\\"{x:1473,y:748,t:1527613564362};\\\", \\\"{x:1442,y:772,t:1527613564378};\\\", \\\"{x:1424,y:784,t:1527613564395};\\\", \\\"{x:1409,y:793,t:1527613564411};\\\", \\\"{x:1403,y:796,t:1527613564428};\\\", \\\"{x:1402,y:797,t:1527613564445};\\\", \\\"{x:1399,y:798,t:1527613564462};\\\", \\\"{x:1398,y:798,t:1527613564477};\\\", \\\"{x:1397,y:799,t:1527613564495};\\\", \\\"{x:1395,y:801,t:1527613564522};\\\", \\\"{x:1393,y:801,t:1527613564587};\\\", \\\"{x:1391,y:803,t:1527613564602};\\\", \\\"{x:1390,y:804,t:1527613564618};\\\", \\\"{x:1389,y:804,t:1527613564627};\\\", \\\"{x:1386,y:804,t:1527613564645};\\\", \\\"{x:1385,y:804,t:1527613564661};\\\", \\\"{x:1382,y:805,t:1527613564677};\\\", \\\"{x:1379,y:805,t:1527613564695};\\\", \\\"{x:1376,y:806,t:1527613564711};\\\", \\\"{x:1373,y:806,t:1527613564728};\\\", \\\"{x:1372,y:807,t:1527613564744};\\\", \\\"{x:1369,y:807,t:1527613564761};\\\", \\\"{x:1366,y:808,t:1527613564777};\\\", \\\"{x:1364,y:808,t:1527613564794};\\\", \\\"{x:1359,y:808,t:1527613564811};\\\", \\\"{x:1357,y:808,t:1527613564829};\\\", \\\"{x:1355,y:808,t:1527613564845};\\\", \\\"{x:1352,y:808,t:1527613564861};\\\", \\\"{x:1348,y:808,t:1527613564879};\\\", \\\"{x:1345,y:808,t:1527613564895};\\\", \\\"{x:1341,y:808,t:1527613564911};\\\", \\\"{x:1338,y:809,t:1527613564928};\\\", \\\"{x:1336,y:810,t:1527613564945};\\\", \\\"{x:1333,y:810,t:1527613564961};\\\", \\\"{x:1332,y:810,t:1527613564979};\\\", \\\"{x:1329,y:811,t:1527613564994};\\\", \\\"{x:1328,y:811,t:1527613565012};\\\", \\\"{x:1326,y:813,t:1527613565029};\\\", \\\"{x:1322,y:813,t:1527613565045};\\\", \\\"{x:1319,y:814,t:1527613565062};\\\", \\\"{x:1317,y:814,t:1527613565082};\\\", \\\"{x:1316,y:814,t:1527613565094};\\\", \\\"{x:1315,y:814,t:1527613565112};\\\", \\\"{x:1314,y:814,t:1527613565129};\\\", \\\"{x:1313,y:815,t:1527613565145};\\\", \\\"{x:1312,y:815,t:1527613565162};\\\", \\\"{x:1311,y:815,t:1527613565178};\\\", \\\"{x:1309,y:816,t:1527613565195};\\\", \\\"{x:1308,y:816,t:1527613565218};\\\", \\\"{x:1307,y:816,t:1527613565229};\\\", \\\"{x:1306,y:817,t:1527613565244};\\\", \\\"{x:1304,y:817,t:1527613565262};\\\", \\\"{x:1302,y:817,t:1527613565279};\\\", \\\"{x:1300,y:817,t:1527613565295};\\\", \\\"{x:1297,y:817,t:1527613565312};\\\", \\\"{x:1296,y:817,t:1527613565329};\\\", \\\"{x:1295,y:817,t:1527613565345};\\\", \\\"{x:1294,y:817,t:1527613565362};\\\", \\\"{x:1293,y:817,t:1527613565434};\\\", \\\"{x:1292,y:817,t:1527613565451};\\\", \\\"{x:1291,y:817,t:1527613565474};\\\", \\\"{x:1290,y:818,t:1527613565482};\\\", \\\"{x:1289,y:818,t:1527613565495};\\\", \\\"{x:1286,y:818,t:1527613565512};\\\", \\\"{x:1277,y:820,t:1527613565528};\\\", \\\"{x:1271,y:821,t:1527613565545};\\\", \\\"{x:1266,y:822,t:1527613565561};\\\", \\\"{x:1262,y:822,t:1527613565578};\\\", \\\"{x:1260,y:823,t:1527613565595};\\\", \\\"{x:1257,y:824,t:1527613565611};\\\", \\\"{x:1254,y:825,t:1527613565628};\\\", \\\"{x:1251,y:825,t:1527613565645};\\\", \\\"{x:1247,y:827,t:1527613565661};\\\", \\\"{x:1243,y:829,t:1527613565678};\\\", \\\"{x:1240,y:829,t:1527613565695};\\\", \\\"{x:1239,y:829,t:1527613565711};\\\", \\\"{x:1237,y:830,t:1527613565728};\\\", \\\"{x:1234,y:831,t:1527613565745};\\\", \\\"{x:1231,y:832,t:1527613565761};\\\", \\\"{x:1229,y:833,t:1527613565778};\\\", \\\"{x:1227,y:833,t:1527613565795};\\\", \\\"{x:1224,y:834,t:1527613565812};\\\", \\\"{x:1221,y:836,t:1527613565828};\\\", \\\"{x:1219,y:836,t:1527613565845};\\\", \\\"{x:1216,y:836,t:1527613565861};\\\", \\\"{x:1214,y:838,t:1527613565899};\\\", \\\"{x:1212,y:838,t:1527613565914};\\\", \\\"{x:1209,y:838,t:1527613565930};\\\", \\\"{x:1209,y:839,t:1527613566003};\\\", \\\"{x:1209,y:838,t:1527613573730};\\\", \\\"{x:1207,y:834,t:1527613573739};\\\", \\\"{x:1205,y:833,t:1527613573750};\\\", \\\"{x:1203,y:830,t:1527613573768};\\\", \\\"{x:1202,y:829,t:1527613573784};\\\", \\\"{x:1201,y:829,t:1527613574570};\\\", \\\"{x:1198,y:830,t:1527613574585};\\\", \\\"{x:1195,y:831,t:1527613574601};\\\", \\\"{x:1191,y:832,t:1527613574618};\\\", \\\"{x:1187,y:833,t:1527613574634};\\\", \\\"{x:1186,y:833,t:1527613574650};\\\", \\\"{x:1184,y:833,t:1527613574667};\\\", \\\"{x:1183,y:833,t:1527613574684};\\\", \\\"{x:1182,y:833,t:1527613574714};\\\", \\\"{x:1180,y:833,t:1527613574730};\\\", \\\"{x:1179,y:833,t:1527613574746};\\\", \\\"{x:1177,y:833,t:1527613574762};\\\", \\\"{x:1176,y:833,t:1527613574770};\\\", \\\"{x:1175,y:833,t:1527613574784};\\\", \\\"{x:1169,y:834,t:1527613574800};\\\", \\\"{x:1160,y:835,t:1527613574817};\\\", \\\"{x:1139,y:836,t:1527613574834};\\\", \\\"{x:1130,y:837,t:1527613574851};\\\", \\\"{x:1125,y:838,t:1527613574867};\\\", \\\"{x:1123,y:838,t:1527613574884};\\\", \\\"{x:1122,y:838,t:1527613574906};\\\", \\\"{x:1121,y:838,t:1527613574922};\\\", \\\"{x:1120,y:838,t:1527613574934};\\\", \\\"{x:1116,y:838,t:1527613574951};\\\", \\\"{x:1112,y:838,t:1527613574968};\\\", \\\"{x:1107,y:838,t:1527613574984};\\\", \\\"{x:1100,y:835,t:1527613575002};\\\", \\\"{x:1097,y:835,t:1527613575017};\\\", \\\"{x:1094,y:834,t:1527613575034};\\\", \\\"{x:1093,y:834,t:1527613575082};\\\", \\\"{x:1093,y:833,t:1527613575090};\\\", \\\"{x:1092,y:833,t:1527613575101};\\\", \\\"{x:1090,y:831,t:1527613575116};\\\", \\\"{x:1088,y:831,t:1527613575134};\\\", \\\"{x:1086,y:830,t:1527613575151};\\\", \\\"{x:1085,y:830,t:1527613575167};\\\", \\\"{x:1084,y:830,t:1527613575209};\\\", \\\"{x:1084,y:829,t:1527613575289};\\\", \\\"{x:1085,y:829,t:1527613575530};\\\", \\\"{x:1086,y:829,t:1527613575546};\\\", \\\"{x:1087,y:829,t:1527613575561};\\\", \\\"{x:1089,y:829,t:1527613575585};\\\", \\\"{x:1090,y:829,t:1527613575601};\\\", \\\"{x:1092,y:828,t:1527613575617};\\\", \\\"{x:1093,y:828,t:1527613575641};\\\", \\\"{x:1095,y:828,t:1527613575651};\\\", \\\"{x:1097,y:828,t:1527613575673};\\\", \\\"{x:1098,y:827,t:1527613575698};\\\", \\\"{x:1099,y:827,t:1527613575713};\\\", \\\"{x:1100,y:827,t:1527613575737};\\\", \\\"{x:1101,y:827,t:1527613575778};\\\", \\\"{x:1102,y:827,t:1527613575786};\\\", \\\"{x:1103,y:827,t:1527613575801};\\\", \\\"{x:1104,y:826,t:1527613575818};\\\", \\\"{x:1106,y:826,t:1527613575834};\\\", \\\"{x:1109,y:825,t:1527613575851};\\\", \\\"{x:1110,y:825,t:1527613575874};\\\", \\\"{x:1111,y:825,t:1527613575946};\\\", \\\"{x:1113,y:825,t:1527613575953};\\\", \\\"{x:1114,y:825,t:1527613575969};\\\", \\\"{x:1115,y:824,t:1527613575984};\\\", \\\"{x:1117,y:824,t:1527613576001};\\\", \\\"{x:1117,y:823,t:1527613576058};\\\", \\\"{x:1118,y:823,t:1527613576074};\\\", \\\"{x:1119,y:823,t:1527613576100};\\\", \\\"{x:1120,y:823,t:1527613576106};\\\", \\\"{x:1122,y:823,t:1527613576118};\\\", \\\"{x:1125,y:823,t:1527613576135};\\\", \\\"{x:1127,y:823,t:1527613576151};\\\", \\\"{x:1129,y:823,t:1527613576169};\\\", \\\"{x:1130,y:823,t:1527613576226};\\\", \\\"{x:1131,y:823,t:1527613576242};\\\", \\\"{x:1132,y:823,t:1527613576251};\\\", \\\"{x:1134,y:823,t:1527613576268};\\\", \\\"{x:1135,y:822,t:1527613576285};\\\", \\\"{x:1136,y:822,t:1527613576306};\\\", \\\"{x:1137,y:822,t:1527613576322};\\\", \\\"{x:1138,y:822,t:1527613576337};\\\", \\\"{x:1139,y:822,t:1527613576354};\\\", \\\"{x:1141,y:822,t:1527613576368};\\\", \\\"{x:1143,y:822,t:1527613576386};\\\", \\\"{x:1145,y:822,t:1527613576401};\\\", \\\"{x:1148,y:822,t:1527613576418};\\\", \\\"{x:1150,y:822,t:1527613576442};\\\", \\\"{x:1154,y:822,t:1527613576451};\\\", \\\"{x:1162,y:822,t:1527613576468};\\\", \\\"{x:1167,y:819,t:1527613576485};\\\", \\\"{x:1170,y:819,t:1527613576501};\\\", \\\"{x:1174,y:819,t:1527613576518};\\\", \\\"{x:1177,y:819,t:1527613576535};\\\", \\\"{x:1178,y:818,t:1527613576551};\\\", \\\"{x:1179,y:818,t:1527613576568};\\\", \\\"{x:1180,y:818,t:1527613576594};\\\", \\\"{x:1181,y:818,t:1527613576722};\\\", \\\"{x:1184,y:818,t:1527613576874};\\\", \\\"{x:1186,y:819,t:1527613576885};\\\", \\\"{x:1190,y:819,t:1527613576902};\\\", \\\"{x:1191,y:819,t:1527613576918};\\\", \\\"{x:1192,y:819,t:1527613576935};\\\", \\\"{x:1193,y:819,t:1527613576952};\\\", \\\"{x:1194,y:820,t:1527613577034};\\\", \\\"{x:1195,y:820,t:1527613577154};\\\", \\\"{x:1196,y:820,t:1527613577499};\\\", \\\"{x:1198,y:820,t:1527613577513};\\\", \\\"{x:1199,y:820,t:1527613577522};\\\", \\\"{x:1201,y:822,t:1527613577538};\\\", \\\"{x:1204,y:822,t:1527613577554};\\\", \\\"{x:1205,y:823,t:1527613577570};\\\", \\\"{x:1206,y:823,t:1527613577585};\\\", \\\"{x:1208,y:825,t:1527613577602};\\\", \\\"{x:1209,y:825,t:1527613577619};\\\", \\\"{x:1210,y:826,t:1527613577677};\\\", \\\"{x:1210,y:827,t:1527613577825};\\\", \\\"{x:1210,y:831,t:1527613577835};\\\", \\\"{x:1216,y:845,t:1527613577852};\\\", \\\"{x:1223,y:859,t:1527613577869};\\\", \\\"{x:1227,y:865,t:1527613577885};\\\", \\\"{x:1228,y:869,t:1527613577902};\\\", \\\"{x:1232,y:875,t:1527613577919};\\\", \\\"{x:1234,y:882,t:1527613577935};\\\", \\\"{x:1236,y:886,t:1527613577952};\\\", \\\"{x:1237,y:888,t:1527613577969};\\\", \\\"{x:1237,y:892,t:1527613577985};\\\", \\\"{x:1239,y:902,t:1527613578002};\\\", \\\"{x:1239,y:908,t:1527613578019};\\\", \\\"{x:1240,y:912,t:1527613578035};\\\", \\\"{x:1242,y:916,t:1527613578052};\\\", \\\"{x:1242,y:920,t:1527613578069};\\\", \\\"{x:1242,y:925,t:1527613578086};\\\", \\\"{x:1242,y:928,t:1527613578103};\\\", \\\"{x:1242,y:932,t:1527613578119};\\\", \\\"{x:1242,y:941,t:1527613578136};\\\", \\\"{x:1242,y:949,t:1527613578155};\\\", \\\"{x:1242,y:956,t:1527613578173};\\\", \\\"{x:1242,y:967,t:1527613578189};\\\", \\\"{x:1242,y:972,t:1527613578206};\\\", \\\"{x:1242,y:979,t:1527613578222};\\\", \\\"{x:1244,y:986,t:1527613578240};\\\", \\\"{x:1245,y:988,t:1527613578256};\\\", \\\"{x:1245,y:989,t:1527613578294};\\\", \\\"{x:1246,y:990,t:1527613578390};\\\", \\\"{x:1250,y:990,t:1527613578406};\\\", \\\"{x:1256,y:985,t:1527613578423};\\\", \\\"{x:1261,y:982,t:1527613578439};\\\", \\\"{x:1267,y:979,t:1527613578456};\\\", \\\"{x:1271,y:977,t:1527613578473};\\\", \\\"{x:1276,y:973,t:1527613578490};\\\", \\\"{x:1279,y:970,t:1527613578506};\\\", \\\"{x:1284,y:965,t:1527613578524};\\\", \\\"{x:1285,y:963,t:1527613578540};\\\", \\\"{x:1288,y:958,t:1527613578556};\\\", \\\"{x:1290,y:956,t:1527613578573};\\\", \\\"{x:1291,y:954,t:1527613578590};\\\", \\\"{x:1291,y:953,t:1527613578670};\\\", \\\"{x:1295,y:956,t:1527613578838};\\\", \\\"{x:1295,y:963,t:1527613578847};\\\", \\\"{x:1296,y:970,t:1527613578857};\\\", \\\"{x:1296,y:975,t:1527613578873};\\\", \\\"{x:1298,y:980,t:1527613578890};\\\", \\\"{x:1298,y:981,t:1527613578906};\\\", \\\"{x:1298,y:982,t:1527613578923};\\\", \\\"{x:1299,y:981,t:1527613579038};\\\", \\\"{x:1305,y:976,t:1527613579046};\\\", \\\"{x:1310,y:972,t:1527613579057};\\\", \\\"{x:1315,y:968,t:1527613579073};\\\", \\\"{x:1324,y:963,t:1527613579091};\\\", \\\"{x:1331,y:960,t:1527613579107};\\\", \\\"{x:1335,y:958,t:1527613579123};\\\", \\\"{x:1339,y:955,t:1527613579140};\\\", \\\"{x:1342,y:954,t:1527613579157};\\\", \\\"{x:1344,y:952,t:1527613579173};\\\", \\\"{x:1345,y:949,t:1527613579190};\\\", \\\"{x:1346,y:948,t:1527613579207};\\\", \\\"{x:1347,y:948,t:1527613579342};\\\", \\\"{x:1348,y:949,t:1527613579357};\\\", \\\"{x:1353,y:958,t:1527613579373};\\\", \\\"{x:1353,y:961,t:1527613579390};\\\", \\\"{x:1355,y:963,t:1527613579407};\\\", \\\"{x:1355,y:961,t:1527613582671};\\\", \\\"{x:1355,y:950,t:1527613582678};\\\", \\\"{x:1355,y:936,t:1527613582692};\\\", \\\"{x:1355,y:922,t:1527613582709};\\\", \\\"{x:1355,y:912,t:1527613582725};\\\", \\\"{x:1355,y:910,t:1527613582742};\\\", \\\"{x:1355,y:909,t:1527613582759};\\\", \\\"{x:1355,y:908,t:1527613582774};\\\", \\\"{x:1355,y:907,t:1527613582792};\\\", \\\"{x:1355,y:905,t:1527613583006};\\\", \\\"{x:1355,y:904,t:1527613583053};\\\", \\\"{x:1354,y:903,t:1527613583061};\\\", \\\"{x:1354,y:902,t:1527613583077};\\\", \\\"{x:1354,y:901,t:1527613583092};\\\", \\\"{x:1354,y:900,t:1527613583166};\\\", \\\"{x:1354,y:899,t:1527613583462};\\\", \\\"{x:1354,y:893,t:1527613583477};\\\", \\\"{x:1354,y:884,t:1527613583493};\\\", \\\"{x:1354,y:880,t:1527613583509};\\\", \\\"{x:1354,y:878,t:1527613583526};\\\", \\\"{x:1354,y:876,t:1527613583542};\\\", \\\"{x:1354,y:873,t:1527613583560};\\\", \\\"{x:1354,y:870,t:1527613583576};\\\", \\\"{x:1354,y:869,t:1527613583592};\\\", \\\"{x:1354,y:867,t:1527613583609};\\\", \\\"{x:1354,y:866,t:1527613583626};\\\", \\\"{x:1354,y:864,t:1527613583642};\\\", \\\"{x:1354,y:860,t:1527613583659};\\\", \\\"{x:1354,y:859,t:1527613583676};\\\", \\\"{x:1355,y:857,t:1527613583692};\\\", \\\"{x:1355,y:855,t:1527613583709};\\\", \\\"{x:1355,y:854,t:1527613583726};\\\", \\\"{x:1355,y:853,t:1527613583846};\\\", \\\"{x:1354,y:856,t:1527613583862};\\\", \\\"{x:1354,y:864,t:1527613583877};\\\", \\\"{x:1350,y:879,t:1527613583893};\\\", \\\"{x:1350,y:886,t:1527613583909};\\\", \\\"{x:1350,y:899,t:1527613583926};\\\", \\\"{x:1350,y:908,t:1527613583943};\\\", \\\"{x:1350,y:919,t:1527613583959};\\\", \\\"{x:1350,y:929,t:1527613583975};\\\", \\\"{x:1350,y:937,t:1527613583993};\\\", \\\"{x:1350,y:941,t:1527613584009};\\\", \\\"{x:1350,y:947,t:1527613584026};\\\", \\\"{x:1350,y:950,t:1527613584043};\\\", \\\"{x:1350,y:951,t:1527613584059};\\\", \\\"{x:1350,y:949,t:1527613584222};\\\", \\\"{x:1350,y:943,t:1527613584230};\\\", \\\"{x:1350,y:938,t:1527613584243};\\\", \\\"{x:1350,y:931,t:1527613584259};\\\", \\\"{x:1350,y:928,t:1527613584276};\\\", \\\"{x:1350,y:920,t:1527613584293};\\\", \\\"{x:1350,y:915,t:1527613584310};\\\", \\\"{x:1351,y:911,t:1527613584326};\\\", \\\"{x:1352,y:905,t:1527613584343};\\\", \\\"{x:1352,y:901,t:1527613584359};\\\", \\\"{x:1352,y:897,t:1527613584377};\\\", \\\"{x:1352,y:894,t:1527613584393};\\\", \\\"{x:1352,y:892,t:1527613584410};\\\", \\\"{x:1352,y:891,t:1527613584426};\\\", \\\"{x:1352,y:890,t:1527613584443};\\\", \\\"{x:1352,y:889,t:1527613584459};\\\", \\\"{x:1352,y:888,t:1527613584476};\\\", \\\"{x:1353,y:884,t:1527613584494};\\\", \\\"{x:1353,y:882,t:1527613584509};\\\", \\\"{x:1353,y:880,t:1527613584526};\\\", \\\"{x:1353,y:876,t:1527613584544};\\\", \\\"{x:1353,y:871,t:1527613584560};\\\", \\\"{x:1353,y:861,t:1527613584576};\\\", \\\"{x:1353,y:853,t:1527613584593};\\\", \\\"{x:1353,y:844,t:1527613584611};\\\", \\\"{x:1353,y:833,t:1527613584627};\\\", \\\"{x:1353,y:823,t:1527613584643};\\\", \\\"{x:1353,y:812,t:1527613584660};\\\", \\\"{x:1353,y:801,t:1527613584676};\\\", \\\"{x:1353,y:789,t:1527613584693};\\\", \\\"{x:1353,y:784,t:1527613584709};\\\", \\\"{x:1353,y:778,t:1527613584726};\\\", \\\"{x:1353,y:761,t:1527613584743};\\\", \\\"{x:1353,y:744,t:1527613584760};\\\", \\\"{x:1353,y:737,t:1527613584777};\\\", \\\"{x:1353,y:733,t:1527613584794};\\\", \\\"{x:1353,y:726,t:1527613584810};\\\", \\\"{x:1352,y:721,t:1527613584826};\\\", \\\"{x:1351,y:716,t:1527613584843};\\\", \\\"{x:1350,y:710,t:1527613584860};\\\", \\\"{x:1350,y:703,t:1527613584876};\\\", \\\"{x:1350,y:695,t:1527613584894};\\\", \\\"{x:1349,y:694,t:1527613584909};\\\", \\\"{x:1349,y:691,t:1527613584926};\\\", \\\"{x:1349,y:688,t:1527613584944};\\\", \\\"{x:1349,y:684,t:1527613584961};\\\", \\\"{x:1349,y:681,t:1527613584976};\\\", \\\"{x:1349,y:680,t:1527613584993};\\\", \\\"{x:1349,y:678,t:1527613585010};\\\", \\\"{x:1349,y:676,t:1527613585026};\\\", \\\"{x:1349,y:674,t:1527613585043};\\\", \\\"{x:1349,y:673,t:1527613585061};\\\", \\\"{x:1348,y:671,t:1527613585077};\\\", \\\"{x:1348,y:669,t:1527613585094};\\\", \\\"{x:1348,y:668,t:1527613585110};\\\", \\\"{x:1347,y:666,t:1527613585128};\\\", \\\"{x:1347,y:663,t:1527613585143};\\\", \\\"{x:1347,y:661,t:1527613585160};\\\", \\\"{x:1346,y:658,t:1527613585177};\\\", \\\"{x:1346,y:654,t:1527613585193};\\\", \\\"{x:1346,y:648,t:1527613585211};\\\", \\\"{x:1346,y:646,t:1527613585228};\\\", \\\"{x:1346,y:642,t:1527613585243};\\\", \\\"{x:1346,y:640,t:1527613585261};\\\", \\\"{x:1346,y:638,t:1527613585278};\\\", \\\"{x:1346,y:635,t:1527613585293};\\\", \\\"{x:1345,y:633,t:1527613585310};\\\", \\\"{x:1345,y:629,t:1527613585327};\\\", \\\"{x:1345,y:625,t:1527613585343};\\\", \\\"{x:1345,y:621,t:1527613585360};\\\", \\\"{x:1344,y:617,t:1527613585377};\\\", \\\"{x:1344,y:613,t:1527613585393};\\\", \\\"{x:1344,y:609,t:1527613585411};\\\", \\\"{x:1344,y:606,t:1527613585428};\\\", \\\"{x:1344,y:603,t:1527613585443};\\\", \\\"{x:1344,y:600,t:1527613585460};\\\", \\\"{x:1344,y:593,t:1527613585477};\\\", \\\"{x:1344,y:588,t:1527613585493};\\\", \\\"{x:1344,y:581,t:1527613585510};\\\", \\\"{x:1344,y:577,t:1527613585527};\\\", \\\"{x:1344,y:573,t:1527613585544};\\\", \\\"{x:1344,y:569,t:1527613585561};\\\", \\\"{x:1344,y:566,t:1527613585577};\\\", \\\"{x:1345,y:563,t:1527613585593};\\\", \\\"{x:1346,y:560,t:1527613585610};\\\", \\\"{x:1346,y:555,t:1527613585628};\\\", \\\"{x:1346,y:551,t:1527613585643};\\\", \\\"{x:1346,y:547,t:1527613585661};\\\", \\\"{x:1346,y:539,t:1527613585678};\\\", \\\"{x:1346,y:534,t:1527613585694};\\\", \\\"{x:1346,y:530,t:1527613585710};\\\", \\\"{x:1346,y:525,t:1527613585727};\\\", \\\"{x:1346,y:519,t:1527613585744};\\\", \\\"{x:1346,y:515,t:1527613585760};\\\", \\\"{x:1346,y:509,t:1527613585777};\\\", \\\"{x:1346,y:502,t:1527613585794};\\\", \\\"{x:1346,y:495,t:1527613585809};\\\", \\\"{x:1346,y:487,t:1527613585827};\\\", \\\"{x:1346,y:478,t:1527613585844};\\\", \\\"{x:1346,y:474,t:1527613585859};\\\", \\\"{x:1346,y:468,t:1527613585877};\\\", \\\"{x:1346,y:465,t:1527613585893};\\\", \\\"{x:1346,y:461,t:1527613585909};\\\", \\\"{x:1346,y:456,t:1527613585927};\\\", \\\"{x:1346,y:453,t:1527613585944};\\\", \\\"{x:1346,y:449,t:1527613585960};\\\", \\\"{x:1346,y:448,t:1527613585997};\\\", \\\"{x:1346,y:447,t:1527613586013};\\\", \\\"{x:1346,y:446,t:1527613586045};\\\", \\\"{x:1346,y:445,t:1527613586060};\\\", \\\"{x:1346,y:443,t:1527613586077};\\\", \\\"{x:1346,y:440,t:1527613586094};\\\", \\\"{x:1346,y:438,t:1527613586110};\\\", \\\"{x:1346,y:435,t:1527613586127};\\\", \\\"{x:1346,y:433,t:1527613586144};\\\", \\\"{x:1346,y:438,t:1527613586350};\\\", \\\"{x:1346,y:448,t:1527613586361};\\\", \\\"{x:1346,y:471,t:1527613586377};\\\", \\\"{x:1346,y:486,t:1527613586394};\\\", \\\"{x:1346,y:500,t:1527613586411};\\\", \\\"{x:1346,y:510,t:1527613586427};\\\", \\\"{x:1346,y:518,t:1527613586444};\\\", \\\"{x:1346,y:535,t:1527613586461};\\\", \\\"{x:1346,y:545,t:1527613586477};\\\", \\\"{x:1346,y:553,t:1527613586494};\\\", \\\"{x:1347,y:561,t:1527613586511};\\\", \\\"{x:1348,y:564,t:1527613586527};\\\", \\\"{x:1348,y:566,t:1527613586544};\\\", \\\"{x:1348,y:568,t:1527613586561};\\\", \\\"{x:1348,y:569,t:1527613586577};\\\", \\\"{x:1348,y:572,t:1527613586594};\\\", \\\"{x:1348,y:578,t:1527613586611};\\\", \\\"{x:1348,y:587,t:1527613586627};\\\", \\\"{x:1348,y:598,t:1527613586644};\\\", \\\"{x:1348,y:613,t:1527613586661};\\\", \\\"{x:1348,y:622,t:1527613586677};\\\", \\\"{x:1348,y:629,t:1527613586694};\\\", \\\"{x:1348,y:635,t:1527613586712};\\\", \\\"{x:1348,y:639,t:1527613586727};\\\", \\\"{x:1348,y:644,t:1527613586745};\\\", \\\"{x:1348,y:650,t:1527613586761};\\\", \\\"{x:1348,y:654,t:1527613586777};\\\", \\\"{x:1348,y:660,t:1527613586794};\\\", \\\"{x:1350,y:666,t:1527613586812};\\\", \\\"{x:1350,y:671,t:1527613586827};\\\", \\\"{x:1350,y:677,t:1527613586844};\\\", \\\"{x:1351,y:685,t:1527613586861};\\\", \\\"{x:1351,y:692,t:1527613586878};\\\", \\\"{x:1351,y:699,t:1527613586894};\\\", \\\"{x:1351,y:707,t:1527613586911};\\\", \\\"{x:1352,y:713,t:1527613586927};\\\", \\\"{x:1352,y:724,t:1527613586945};\\\", \\\"{x:1351,y:738,t:1527613586962};\\\", \\\"{x:1350,y:752,t:1527613586978};\\\", \\\"{x:1350,y:767,t:1527613586994};\\\", \\\"{x:1350,y:775,t:1527613587011};\\\", \\\"{x:1349,y:782,t:1527613587027};\\\", \\\"{x:1348,y:784,t:1527613587044};\\\", \\\"{x:1348,y:790,t:1527613587061};\\\", \\\"{x:1348,y:794,t:1527613587077};\\\", \\\"{x:1348,y:799,t:1527613587094};\\\", \\\"{x:1348,y:803,t:1527613587111};\\\", \\\"{x:1348,y:806,t:1527613587129};\\\", \\\"{x:1348,y:810,t:1527613587145};\\\", \\\"{x:1348,y:814,t:1527613587161};\\\", \\\"{x:1350,y:820,t:1527613587178};\\\", \\\"{x:1350,y:827,t:1527613587194};\\\", \\\"{x:1351,y:834,t:1527613587211};\\\", \\\"{x:1351,y:839,t:1527613587227};\\\", \\\"{x:1352,y:847,t:1527613587244};\\\", \\\"{x:1352,y:855,t:1527613587261};\\\", \\\"{x:1354,y:858,t:1527613587278};\\\", \\\"{x:1354,y:861,t:1527613587294};\\\", \\\"{x:1354,y:862,t:1527613587311};\\\", \\\"{x:1354,y:865,t:1527613587328};\\\", \\\"{x:1354,y:872,t:1527613587344};\\\", \\\"{x:1354,y:875,t:1527613587361};\\\", \\\"{x:1355,y:878,t:1527613587378};\\\", \\\"{x:1355,y:883,t:1527613587394};\\\", \\\"{x:1355,y:888,t:1527613587411};\\\", \\\"{x:1355,y:893,t:1527613587428};\\\", \\\"{x:1355,y:899,t:1527613587444};\\\", \\\"{x:1355,y:905,t:1527613587461};\\\", \\\"{x:1355,y:909,t:1527613587478};\\\", \\\"{x:1355,y:913,t:1527613587494};\\\", \\\"{x:1355,y:917,t:1527613587512};\\\", \\\"{x:1355,y:919,t:1527613587528};\\\", \\\"{x:1355,y:922,t:1527613587544};\\\", \\\"{x:1355,y:926,t:1527613587562};\\\", \\\"{x:1355,y:930,t:1527613587578};\\\", \\\"{x:1355,y:933,t:1527613587594};\\\", \\\"{x:1354,y:935,t:1527613587611};\\\", \\\"{x:1354,y:937,t:1527613587629};\\\", \\\"{x:1353,y:941,t:1527613587645};\\\", \\\"{x:1352,y:947,t:1527613587662};\\\", \\\"{x:1352,y:952,t:1527613587678};\\\", \\\"{x:1351,y:956,t:1527613587695};\\\", \\\"{x:1350,y:961,t:1527613587711};\\\", \\\"{x:1350,y:962,t:1527613587728};\\\", \\\"{x:1350,y:964,t:1527613587746};\\\", \\\"{x:1349,y:965,t:1527613587762};\\\", \\\"{x:1349,y:967,t:1527613587778};\\\", \\\"{x:1349,y:970,t:1527613587796};\\\", \\\"{x:1349,y:972,t:1527613587812};\\\", \\\"{x:1347,y:977,t:1527613587828};\\\", \\\"{x:1347,y:979,t:1527613587846};\\\", \\\"{x:1346,y:980,t:1527613587918};\\\", \\\"{x:1339,y:980,t:1527613587928};\\\", \\\"{x:1292,y:952,t:1527613587946};\\\", \\\"{x:1184,y:875,t:1527613587961};\\\", \\\"{x:1055,y:775,t:1527613587978};\\\", \\\"{x:904,y:683,t:1527613587995};\\\", \\\"{x:767,y:608,t:1527613588013};\\\", \\\"{x:671,y:566,t:1527613588028};\\\", \\\"{x:658,y:557,t:1527613588045};\\\", \\\"{x:656,y:564,t:1527613588270};\\\", \\\"{x:644,y:575,t:1527613588287};\\\", \\\"{x:630,y:582,t:1527613588303};\\\", \\\"{x:617,y:589,t:1527613588319};\\\", \\\"{x:594,y:596,t:1527613588336};\\\", \\\"{x:572,y:607,t:1527613588353};\\\", \\\"{x:556,y:611,t:1527613588370};\\\", \\\"{x:542,y:613,t:1527613588387};\\\", \\\"{x:523,y:616,t:1527613588403};\\\", \\\"{x:505,y:618,t:1527613588420};\\\", \\\"{x:491,y:620,t:1527613588437};\\\", \\\"{x:483,y:621,t:1527613588453};\\\", \\\"{x:473,y:621,t:1527613588469};\\\", \\\"{x:458,y:621,t:1527613588486};\\\", \\\"{x:445,y:621,t:1527613588503};\\\", \\\"{x:425,y:621,t:1527613588520};\\\", \\\"{x:403,y:620,t:1527613588537};\\\", \\\"{x:377,y:617,t:1527613588554};\\\", \\\"{x:347,y:615,t:1527613588570};\\\", \\\"{x:320,y:614,t:1527613588587};\\\", \\\"{x:294,y:609,t:1527613588608};\\\", \\\"{x:276,y:607,t:1527613588620};\\\", \\\"{x:257,y:606,t:1527613588638};\\\", \\\"{x:250,y:606,t:1527613588654};\\\", \\\"{x:246,y:606,t:1527613588670};\\\", \\\"{x:241,y:606,t:1527613588687};\\\", \\\"{x:238,y:606,t:1527613588704};\\\", \\\"{x:236,y:606,t:1527613588720};\\\", \\\"{x:235,y:606,t:1527613588748};\\\", \\\"{x:234,y:606,t:1527613588757};\\\", \\\"{x:232,y:606,t:1527613588770};\\\", \\\"{x:225,y:606,t:1527613588786};\\\", \\\"{x:213,y:606,t:1527613588804};\\\", \\\"{x:196,y:606,t:1527613588820};\\\", \\\"{x:174,y:606,t:1527613588838};\\\", \\\"{x:164,y:606,t:1527613588854};\\\", \\\"{x:155,y:603,t:1527613588870};\\\", \\\"{x:147,y:602,t:1527613588888};\\\", \\\"{x:142,y:601,t:1527613588903};\\\", \\\"{x:141,y:600,t:1527613588920};\\\", \\\"{x:140,y:600,t:1527613588990};\\\", \\\"{x:143,y:600,t:1527613589029};\\\", \\\"{x:158,y:600,t:1527613589038};\\\", \\\"{x:191,y:606,t:1527613589054};\\\", \\\"{x:218,y:610,t:1527613589070};\\\", \\\"{x:232,y:612,t:1527613589086};\\\", \\\"{x:233,y:612,t:1527613589104};\\\", \\\"{x:233,y:604,t:1527613589132};\\\", \\\"{x:233,y:600,t:1527613589140};\\\", \\\"{x:230,y:596,t:1527613589154};\\\", \\\"{x:223,y:589,t:1527613589169};\\\", \\\"{x:214,y:583,t:1527613589187};\\\", \\\"{x:205,y:577,t:1527613589204};\\\", \\\"{x:200,y:574,t:1527613589222};\\\", \\\"{x:199,y:573,t:1527613589236};\\\", \\\"{x:198,y:573,t:1527613589277};\\\", \\\"{x:197,y:571,t:1527613589301};\\\", \\\"{x:196,y:570,t:1527613589309};\\\", \\\"{x:196,y:569,t:1527613589321};\\\", \\\"{x:196,y:567,t:1527613589337};\\\", \\\"{x:195,y:565,t:1527613589354};\\\", \\\"{x:193,y:564,t:1527613589371};\\\", \\\"{x:193,y:563,t:1527613589387};\\\", \\\"{x:192,y:563,t:1527613589581};\\\", \\\"{x:192,y:563,t:1527613589687};\\\", \\\"{x:191,y:563,t:1527613590293};\\\", \\\"{x:190,y:563,t:1527613590306};\\\", \\\"{x:175,y:562,t:1527613590322};\\\", \\\"{x:160,y:558,t:1527613590337};\\\", \\\"{x:144,y:553,t:1527613590355};\\\", \\\"{x:133,y:552,t:1527613590372};\\\", \\\"{x:132,y:552,t:1527613590387};\\\", \\\"{x:134,y:552,t:1527613590677};\\\", \\\"{x:137,y:552,t:1527613590694};\\\", \\\"{x:138,y:552,t:1527613590705};\\\", \\\"{x:140,y:552,t:1527613590722};\\\", \\\"{x:141,y:552,t:1527613590738};\\\", \\\"{x:143,y:552,t:1527613590764};\\\", \\\"{x:146,y:552,t:1527613590772};\\\", \\\"{x:152,y:552,t:1527613590788};\\\", \\\"{x:164,y:554,t:1527613590804};\\\", \\\"{x:180,y:558,t:1527613590822};\\\", \\\"{x:189,y:560,t:1527613590839};\\\", \\\"{x:190,y:560,t:1527613590855};\\\", \\\"{x:189,y:560,t:1527613591213};\\\", \\\"{x:188,y:560,t:1527613591222};\\\", \\\"{x:187,y:560,t:1527613591239};\\\", \\\"{x:186,y:560,t:1527613591269};\\\", \\\"{x:185,y:560,t:1527613591277};\\\", \\\"{x:183,y:561,t:1527613591289};\\\", \\\"{x:181,y:562,t:1527613591305};\\\", \\\"{x:177,y:564,t:1527613591322};\\\", \\\"{x:175,y:564,t:1527613591338};\\\", \\\"{x:173,y:565,t:1527613591356};\\\", \\\"{x:170,y:565,t:1527613591485};\\\", \\\"{x:168,y:565,t:1527613591509};\\\", \\\"{x:167,y:565,t:1527613591557};\\\", \\\"{x:176,y:577,t:1527613592063};\\\", \\\"{x:207,y:598,t:1527613592073};\\\", \\\"{x:277,y:649,t:1527613592089};\\\", \\\"{x:351,y:677,t:1527613592107};\\\", \\\"{x:419,y:704,t:1527613592123};\\\", \\\"{x:452,y:719,t:1527613592139};\\\", \\\"{x:464,y:724,t:1527613592156};\\\", \\\"{x:470,y:724,t:1527613592172};\\\", \\\"{x:471,y:725,t:1527613592189};\\\", \\\"{x:472,y:725,t:1527613592220};\\\", \\\"{x:473,y:725,t:1527613592228};\\\", \\\"{x:475,y:725,t:1527613592240};\\\", \\\"{x:478,y:725,t:1527613592256};\\\", \\\"{x:483,y:725,t:1527613592273};\\\", \\\"{x:487,y:725,t:1527613592290};\\\", \\\"{x:488,y:725,t:1527613592306};\\\", \\\"{x:489,y:725,t:1527613592974};\\\", \\\"{x:489,y:724,t:1527613593037};\\\", \\\"{x:493,y:719,t:1527613593053};\\\", \\\"{x:497,y:716,t:1527613593061};\\\", \\\"{x:499,y:714,t:1527613593073};\\\", \\\"{x:504,y:710,t:1527613593090};\\\", \\\"{x:510,y:706,t:1527613593108};\\\", \\\"{x:513,y:704,t:1527613593125};\\\", \\\"{x:515,y:703,t:1527613593140};\\\", \\\"{x:517,y:700,t:1527613593156};\\\", \\\"{x:518,y:699,t:1527613593174};\\\", \\\"{x:519,y:698,t:1527613593191};\\\", \\\"{x:520,y:697,t:1527613593212};\\\", \\\"{x:521,y:697,t:1527613593228};\\\", \\\"{x:521,y:696,t:1527613593325};\\\" ] }, { \\\"rt\\\": 81555, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 276324, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-12 PM-02 PM-02 PM-U -U -Z -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:695,t:1527613595342};\\\", \\\"{x:524,y:695,t:1527613595598};\\\", \\\"{x:528,y:694,t:1527613595609};\\\", \\\"{x:538,y:692,t:1527613595625};\\\", \\\"{x:548,y:692,t:1527613595642};\\\", \\\"{x:559,y:692,t:1527613595660};\\\", \\\"{x:570,y:692,t:1527613595675};\\\", \\\"{x:580,y:692,t:1527613595692};\\\", \\\"{x:597,y:692,t:1527613595709};\\\", \\\"{x:609,y:692,t:1527613595726};\\\", \\\"{x:622,y:695,t:1527613595743};\\\", \\\"{x:636,y:697,t:1527613595759};\\\", \\\"{x:645,y:700,t:1527613595777};\\\", \\\"{x:661,y:704,t:1527613595792};\\\", \\\"{x:680,y:709,t:1527613595810};\\\", \\\"{x:695,y:712,t:1527613595826};\\\", \\\"{x:711,y:718,t:1527613595842};\\\", \\\"{x:727,y:723,t:1527613595860};\\\", \\\"{x:741,y:727,t:1527613595876};\\\", \\\"{x:757,y:731,t:1527613595893};\\\", \\\"{x:790,y:741,t:1527613595909};\\\", \\\"{x:813,y:747,t:1527613595926};\\\", \\\"{x:834,y:752,t:1527613595942};\\\", \\\"{x:857,y:759,t:1527613595959};\\\", \\\"{x:878,y:765,t:1527613595977};\\\", \\\"{x:899,y:770,t:1527613595993};\\\", \\\"{x:921,y:775,t:1527613596010};\\\", \\\"{x:941,y:778,t:1527613596027};\\\", \\\"{x:957,y:783,t:1527613596042};\\\", \\\"{x:971,y:785,t:1527613596059};\\\", \\\"{x:992,y:788,t:1527613596077};\\\", \\\"{x:995,y:788,t:1527613596092};\\\", \\\"{x:1007,y:791,t:1527613596109};\\\", \\\"{x:1016,y:793,t:1527613596127};\\\", \\\"{x:1030,y:796,t:1527613596143};\\\", \\\"{x:1047,y:797,t:1527613596160};\\\", \\\"{x:1062,y:800,t:1527613596177};\\\", \\\"{x:1077,y:802,t:1527613596193};\\\", \\\"{x:1097,y:805,t:1527613596210};\\\", \\\"{x:1111,y:810,t:1527613596227};\\\", \\\"{x:1126,y:814,t:1527613596243};\\\", \\\"{x:1140,y:819,t:1527613596260};\\\", \\\"{x:1156,y:823,t:1527613596277};\\\", \\\"{x:1176,y:829,t:1527613596294};\\\", \\\"{x:1187,y:834,t:1527613596309};\\\", \\\"{x:1198,y:837,t:1527613596326};\\\", \\\"{x:1212,y:842,t:1527613596343};\\\", \\\"{x:1223,y:846,t:1527613596360};\\\", \\\"{x:1227,y:848,t:1527613596377};\\\", \\\"{x:1229,y:848,t:1527613596394};\\\", \\\"{x:1231,y:850,t:1527613596409};\\\", \\\"{x:1233,y:850,t:1527613596427};\\\", \\\"{x:1233,y:851,t:1527613596444};\\\", \\\"{x:1236,y:855,t:1527613596459};\\\", \\\"{x:1243,y:866,t:1527613596477};\\\", \\\"{x:1258,y:885,t:1527613596493};\\\", \\\"{x:1267,y:899,t:1527613596510};\\\", \\\"{x:1272,y:909,t:1527613596527};\\\", \\\"{x:1275,y:917,t:1527613596544};\\\", \\\"{x:1277,y:921,t:1527613596559};\\\", \\\"{x:1278,y:924,t:1527613596576};\\\", \\\"{x:1279,y:929,t:1527613596594};\\\", \\\"{x:1280,y:933,t:1527613596610};\\\", \\\"{x:1281,y:939,t:1527613596627};\\\", \\\"{x:1281,y:943,t:1527613596644};\\\", \\\"{x:1283,y:948,t:1527613596660};\\\", \\\"{x:1284,y:956,t:1527613596677};\\\", \\\"{x:1285,y:964,t:1527613596694};\\\", \\\"{x:1285,y:968,t:1527613596710};\\\", \\\"{x:1285,y:970,t:1527613596727};\\\", \\\"{x:1285,y:972,t:1527613596743};\\\", \\\"{x:1285,y:973,t:1527613596760};\\\", \\\"{x:1285,y:974,t:1527613596789};\\\", \\\"{x:1284,y:975,t:1527613596797};\\\", \\\"{x:1283,y:977,t:1527613596810};\\\", \\\"{x:1281,y:977,t:1527613596827};\\\", \\\"{x:1276,y:979,t:1527613596844};\\\", \\\"{x:1273,y:981,t:1527613596861};\\\", \\\"{x:1267,y:981,t:1527613596877};\\\", \\\"{x:1263,y:981,t:1527613596893};\\\", \\\"{x:1257,y:981,t:1527613596912};\\\", \\\"{x:1255,y:981,t:1527613596927};\\\", \\\"{x:1253,y:981,t:1527613596943};\\\", \\\"{x:1252,y:981,t:1527613596965};\\\", \\\"{x:1251,y:981,t:1527613596997};\\\", \\\"{x:1250,y:981,t:1527613597014};\\\", \\\"{x:1249,y:981,t:1527613597027};\\\", \\\"{x:1248,y:981,t:1527613597101};\\\", \\\"{x:1260,y:979,t:1527613603214};\\\", \\\"{x:1297,y:979,t:1527613603232};\\\", \\\"{x:1329,y:979,t:1527613603248};\\\", \\\"{x:1355,y:983,t:1527613603265};\\\", \\\"{x:1370,y:986,t:1527613603282};\\\", \\\"{x:1376,y:987,t:1527613603298};\\\", \\\"{x:1379,y:987,t:1527613603315};\\\", \\\"{x:1382,y:986,t:1527613603332};\\\", \\\"{x:1385,y:981,t:1527613603349};\\\", \\\"{x:1388,y:974,t:1527613603365};\\\", \\\"{x:1391,y:970,t:1527613603382};\\\", \\\"{x:1394,y:967,t:1527613603398};\\\", \\\"{x:1395,y:965,t:1527613603415};\\\", \\\"{x:1399,y:960,t:1527613603432};\\\", \\\"{x:1403,y:956,t:1527613603448};\\\", \\\"{x:1409,y:952,t:1527613603465};\\\", \\\"{x:1418,y:946,t:1527613603482};\\\", \\\"{x:1435,y:941,t:1527613603499};\\\", \\\"{x:1458,y:935,t:1527613603515};\\\", \\\"{x:1481,y:930,t:1527613603532};\\\", \\\"{x:1516,y:922,t:1527613603550};\\\", \\\"{x:1534,y:920,t:1527613603565};\\\", \\\"{x:1548,y:920,t:1527613603582};\\\", \\\"{x:1554,y:920,t:1527613603598};\\\", \\\"{x:1557,y:920,t:1527613603614};\\\", \\\"{x:1559,y:920,t:1527613603631};\\\", \\\"{x:1560,y:920,t:1527613603652};\\\", \\\"{x:1558,y:923,t:1527613603756};\\\", \\\"{x:1550,y:929,t:1527613603765};\\\", \\\"{x:1535,y:942,t:1527613603781};\\\", \\\"{x:1520,y:955,t:1527613603799};\\\", \\\"{x:1509,y:967,t:1527613603815};\\\", \\\"{x:1500,y:980,t:1527613603831};\\\", \\\"{x:1496,y:986,t:1527613603849};\\\", \\\"{x:1495,y:986,t:1527613603865};\\\", \\\"{x:1495,y:988,t:1527613603885};\\\", \\\"{x:1492,y:986,t:1527613604029};\\\", \\\"{x:1489,y:981,t:1527613604037};\\\", \\\"{x:1485,y:975,t:1527613604049};\\\", \\\"{x:1478,y:963,t:1527613604067};\\\", \\\"{x:1473,y:955,t:1527613604082};\\\", \\\"{x:1469,y:944,t:1527613604099};\\\", \\\"{x:1464,y:936,t:1527613604116};\\\", \\\"{x:1464,y:933,t:1527613604132};\\\", \\\"{x:1460,y:924,t:1527613604149};\\\", \\\"{x:1460,y:918,t:1527613604165};\\\", \\\"{x:1459,y:908,t:1527613604182};\\\", \\\"{x:1457,y:904,t:1527613604199};\\\", \\\"{x:1457,y:901,t:1527613604216};\\\", \\\"{x:1457,y:900,t:1527613604232};\\\", \\\"{x:1457,y:897,t:1527613604249};\\\", \\\"{x:1457,y:895,t:1527613604269};\\\", \\\"{x:1457,y:894,t:1527613604293};\\\", \\\"{x:1457,y:893,t:1527613604309};\\\", \\\"{x:1457,y:892,t:1527613604317};\\\", \\\"{x:1457,y:891,t:1527613604332};\\\", \\\"{x:1457,y:886,t:1527613604349};\\\", \\\"{x:1457,y:885,t:1527613604366};\\\", \\\"{x:1457,y:884,t:1527613604382};\\\", \\\"{x:1457,y:882,t:1527613604399};\\\", \\\"{x:1457,y:881,t:1527613604416};\\\", \\\"{x:1457,y:880,t:1527613604433};\\\", \\\"{x:1457,y:879,t:1527613604449};\\\", \\\"{x:1457,y:878,t:1527613604467};\\\", \\\"{x:1457,y:876,t:1527613604483};\\\", \\\"{x:1457,y:875,t:1527613604499};\\\", \\\"{x:1457,y:873,t:1527613604516};\\\", \\\"{x:1458,y:870,t:1527613604533};\\\", \\\"{x:1458,y:869,t:1527613604549};\\\", \\\"{x:1458,y:867,t:1527613604566};\\\", \\\"{x:1458,y:866,t:1527613604589};\\\", \\\"{x:1459,y:864,t:1527613604599};\\\", \\\"{x:1459,y:863,t:1527613604616};\\\", \\\"{x:1459,y:862,t:1527613604632};\\\", \\\"{x:1459,y:861,t:1527613604649};\\\", \\\"{x:1459,y:859,t:1527613604666};\\\", \\\"{x:1460,y:857,t:1527613604683};\\\", \\\"{x:1460,y:855,t:1527613604699};\\\", \\\"{x:1460,y:854,t:1527613604715};\\\", \\\"{x:1461,y:850,t:1527613604733};\\\", \\\"{x:1461,y:849,t:1527613604756};\\\", \\\"{x:1463,y:847,t:1527613604766};\\\", \\\"{x:1463,y:845,t:1527613604789};\\\", \\\"{x:1463,y:844,t:1527613604804};\\\", \\\"{x:1463,y:843,t:1527613604815};\\\", \\\"{x:1463,y:842,t:1527613604833};\\\", \\\"{x:1464,y:842,t:1527613604849};\\\", \\\"{x:1464,y:841,t:1527613604868};\\\", \\\"{x:1465,y:840,t:1527613604883};\\\", \\\"{x:1465,y:839,t:1527613604899};\\\", \\\"{x:1466,y:838,t:1527613604916};\\\", \\\"{x:1467,y:837,t:1527613604957};\\\", \\\"{x:1468,y:836,t:1527613604966};\\\", \\\"{x:1468,y:835,t:1527613604983};\\\", \\\"{x:1470,y:832,t:1527613605000};\\\", \\\"{x:1471,y:830,t:1527613605016};\\\", \\\"{x:1473,y:828,t:1527613605033};\\\", \\\"{x:1474,y:826,t:1527613605050};\\\", \\\"{x:1476,y:824,t:1527613605067};\\\", \\\"{x:1477,y:823,t:1527613605083};\\\", \\\"{x:1477,y:822,t:1527613605198};\\\", \\\"{x:1482,y:822,t:1527613605589};\\\", \\\"{x:1489,y:825,t:1527613605601};\\\", \\\"{x:1502,y:828,t:1527613605617};\\\", \\\"{x:1509,y:830,t:1527613605633};\\\", \\\"{x:1516,y:832,t:1527613605651};\\\", \\\"{x:1528,y:837,t:1527613605667};\\\", \\\"{x:1538,y:839,t:1527613605683};\\\", \\\"{x:1544,y:841,t:1527613605700};\\\", \\\"{x:1553,y:843,t:1527613605717};\\\", \\\"{x:1560,y:846,t:1527613605733};\\\", \\\"{x:1565,y:847,t:1527613605750};\\\", \\\"{x:1572,y:847,t:1527613605767};\\\", \\\"{x:1578,y:849,t:1527613605783};\\\", \\\"{x:1583,y:850,t:1527613605800};\\\", \\\"{x:1590,y:850,t:1527613605817};\\\", \\\"{x:1593,y:850,t:1527613605834};\\\", \\\"{x:1595,y:850,t:1527613605850};\\\", \\\"{x:1596,y:850,t:1527613605867};\\\", \\\"{x:1598,y:850,t:1527613605884};\\\", \\\"{x:1599,y:850,t:1527613605900};\\\", \\\"{x:1601,y:850,t:1527613605917};\\\", \\\"{x:1603,y:848,t:1527613605934};\\\", \\\"{x:1605,y:846,t:1527613605950};\\\", \\\"{x:1605,y:844,t:1527613606062};\\\", \\\"{x:1604,y:845,t:1527613606285};\\\", \\\"{x:1603,y:846,t:1527613606299};\\\", \\\"{x:1595,y:850,t:1527613606316};\\\", \\\"{x:1592,y:852,t:1527613606333};\\\", \\\"{x:1591,y:853,t:1527613606350};\\\", \\\"{x:1590,y:854,t:1527613606404};\\\", \\\"{x:1589,y:855,t:1527613606416};\\\", \\\"{x:1586,y:859,t:1527613606433};\\\", \\\"{x:1579,y:866,t:1527613606450};\\\", \\\"{x:1575,y:871,t:1527613606467};\\\", \\\"{x:1572,y:876,t:1527613606484};\\\", \\\"{x:1567,y:884,t:1527613606501};\\\", \\\"{x:1564,y:888,t:1527613606517};\\\", \\\"{x:1560,y:893,t:1527613606534};\\\", \\\"{x:1558,y:899,t:1527613606550};\\\", \\\"{x:1555,y:905,t:1527613606567};\\\", \\\"{x:1552,y:909,t:1527613606583};\\\", \\\"{x:1552,y:910,t:1527613606600};\\\", \\\"{x:1551,y:912,t:1527613606617};\\\", \\\"{x:1551,y:913,t:1527613606644};\\\", \\\"{x:1550,y:914,t:1527613606652};\\\", \\\"{x:1550,y:913,t:1527613606782};\\\", \\\"{x:1550,y:901,t:1527613606789};\\\", \\\"{x:1550,y:888,t:1527613606801};\\\", \\\"{x:1548,y:871,t:1527613606817};\\\", \\\"{x:1547,y:857,t:1527613606834};\\\", \\\"{x:1543,y:846,t:1527613606851};\\\", \\\"{x:1540,y:834,t:1527613606868};\\\", \\\"{x:1540,y:831,t:1527613606884};\\\", \\\"{x:1538,y:825,t:1527613606901};\\\", \\\"{x:1536,y:819,t:1527613606918};\\\", \\\"{x:1535,y:815,t:1527613606935};\\\", \\\"{x:1534,y:811,t:1527613606951};\\\", \\\"{x:1534,y:809,t:1527613606968};\\\", \\\"{x:1533,y:806,t:1527613606984};\\\", \\\"{x:1533,y:805,t:1527613607001};\\\", \\\"{x:1532,y:803,t:1527613607018};\\\", \\\"{x:1532,y:801,t:1527613607034};\\\", \\\"{x:1532,y:800,t:1527613607052};\\\", \\\"{x:1533,y:806,t:1527613607165};\\\", \\\"{x:1537,y:814,t:1527613607173};\\\", \\\"{x:1539,y:823,t:1527613607184};\\\", \\\"{x:1547,y:839,t:1527613607201};\\\", \\\"{x:1555,y:850,t:1527613607218};\\\", \\\"{x:1559,y:856,t:1527613607234};\\\", \\\"{x:1563,y:859,t:1527613607251};\\\", \\\"{x:1565,y:860,t:1527613607268};\\\", \\\"{x:1567,y:862,t:1527613607285};\\\", \\\"{x:1568,y:862,t:1527613607301};\\\", \\\"{x:1570,y:863,t:1527613607317};\\\", \\\"{x:1574,y:863,t:1527613607334};\\\", \\\"{x:1579,y:864,t:1527613607351};\\\", \\\"{x:1585,y:866,t:1527613607367};\\\", \\\"{x:1592,y:866,t:1527613607384};\\\", \\\"{x:1596,y:866,t:1527613607401};\\\", \\\"{x:1600,y:866,t:1527613607418};\\\", \\\"{x:1602,y:865,t:1527613607435};\\\", \\\"{x:1605,y:861,t:1527613607451};\\\", \\\"{x:1607,y:857,t:1527613607468};\\\", \\\"{x:1610,y:849,t:1527613607485};\\\", \\\"{x:1612,y:842,t:1527613607501};\\\", \\\"{x:1612,y:840,t:1527613607525};\\\", \\\"{x:1613,y:840,t:1527613607535};\\\", \\\"{x:1614,y:837,t:1527613607551};\\\", \\\"{x:1614,y:836,t:1527613607569};\\\", \\\"{x:1614,y:835,t:1527613607585};\\\", \\\"{x:1614,y:833,t:1527613607601};\\\", \\\"{x:1614,y:832,t:1527613607620};\\\", \\\"{x:1614,y:831,t:1527613607773};\\\", \\\"{x:1614,y:830,t:1527613607796};\\\", \\\"{x:1614,y:829,t:1527613607812};\\\", \\\"{x:1614,y:828,t:1527613607828};\\\", \\\"{x:1614,y:827,t:1527613607845};\\\", \\\"{x:1614,y:826,t:1527613607893};\\\", \\\"{x:1614,y:825,t:1527613607901};\\\", \\\"{x:1614,y:824,t:1527613607918};\\\", \\\"{x:1614,y:823,t:1527613607935};\\\", \\\"{x:1614,y:822,t:1527613607952};\\\", \\\"{x:1614,y:821,t:1527613608013};\\\", \\\"{x:1614,y:820,t:1527613609117};\\\", \\\"{x:1605,y:819,t:1527613609125};\\\", \\\"{x:1584,y:815,t:1527613609136};\\\", \\\"{x:1480,y:814,t:1527613609153};\\\", \\\"{x:1350,y:809,t:1527613609170};\\\", \\\"{x:1212,y:797,t:1527613609186};\\\", \\\"{x:1099,y:782,t:1527613609202};\\\", \\\"{x:994,y:769,t:1527613609219};\\\", \\\"{x:836,y:745,t:1527613609236};\\\", \\\"{x:510,y:719,t:1527613609254};\\\", \\\"{x:374,y:717,t:1527613609269};\\\", \\\"{x:309,y:713,t:1527613609303};\\\", \\\"{x:306,y:712,t:1527613609319};\\\", \\\"{x:305,y:712,t:1527613609340};\\\", \\\"{x:305,y:711,t:1527613609404};\\\", \\\"{x:305,y:706,t:1527613609419};\\\", \\\"{x:305,y:660,t:1527613609436};\\\", \\\"{x:315,y:616,t:1527613609452};\\\", \\\"{x:330,y:582,t:1527613609471};\\\", \\\"{x:347,y:559,t:1527613609488};\\\", \\\"{x:381,y:537,t:1527613609503};\\\", \\\"{x:413,y:525,t:1527613609520};\\\", \\\"{x:444,y:517,t:1527613609537};\\\", \\\"{x:492,y:517,t:1527613609553};\\\", \\\"{x:542,y:517,t:1527613609571};\\\", \\\"{x:610,y:520,t:1527613609586};\\\", \\\"{x:656,y:530,t:1527613609603};\\\", \\\"{x:675,y:538,t:1527613609621};\\\", \\\"{x:681,y:541,t:1527613609636};\\\", \\\"{x:681,y:543,t:1527613609708};\\\", \\\"{x:678,y:548,t:1527613609721};\\\", \\\"{x:674,y:557,t:1527613609736};\\\", \\\"{x:664,y:572,t:1527613609754};\\\", \\\"{x:657,y:581,t:1527613609770};\\\", \\\"{x:656,y:583,t:1527613609788};\\\", \\\"{x:654,y:585,t:1527613609803};\\\", \\\"{x:652,y:586,t:1527613609821};\\\", \\\"{x:651,y:586,t:1527613609844};\\\", \\\"{x:650,y:586,t:1527613609854};\\\", \\\"{x:648,y:588,t:1527613609871};\\\", \\\"{x:645,y:588,t:1527613609887};\\\", \\\"{x:642,y:588,t:1527613609904};\\\", \\\"{x:641,y:588,t:1527613609920};\\\", \\\"{x:637,y:588,t:1527613609936};\\\", \\\"{x:635,y:588,t:1527613609953};\\\", \\\"{x:632,y:588,t:1527613609970};\\\", \\\"{x:629,y:588,t:1527613609987};\\\", \\\"{x:623,y:588,t:1527613610004};\\\", \\\"{x:607,y:588,t:1527613610021};\\\", \\\"{x:604,y:588,t:1527613610037};\\\", \\\"{x:603,y:588,t:1527613610054};\\\", \\\"{x:602,y:588,t:1527613610084};\\\", \\\"{x:602,y:589,t:1527613610198};\\\", \\\"{x:602,y:592,t:1527613610205};\\\", \\\"{x:602,y:599,t:1527613610220};\\\", \\\"{x:602,y:601,t:1527613610237};\\\", \\\"{x:602,y:602,t:1527613610253};\\\", \\\"{x:602,y:603,t:1527613610284};\\\", \\\"{x:573,y:625,t:1527613656162};\\\", \\\"{x:457,y:728,t:1527613656177};\\\", \\\"{x:436,y:759,t:1527613656193};\\\", \\\"{x:436,y:761,t:1527613656212};\\\", \\\"{x:436,y:762,t:1527613656289};\\\", \\\"{x:437,y:765,t:1527613656297};\\\", \\\"{x:449,y:771,t:1527613656312};\\\", \\\"{x:481,y:784,t:1527613656329};\\\", \\\"{x:503,y:793,t:1527613656346};\\\", \\\"{x:527,y:806,t:1527613656362};\\\", \\\"{x:573,y:835,t:1527613656379};\\\", \\\"{x:631,y:872,t:1527613656396};\\\", \\\"{x:701,y:909,t:1527613656413};\\\", \\\"{x:769,y:934,t:1527613656429};\\\", \\\"{x:831,y:944,t:1527613656446};\\\", \\\"{x:912,y:943,t:1527613656462};\\\", \\\"{x:1019,y:900,t:1527613656479};\\\", \\\"{x:1132,y:832,t:1527613656496};\\\", \\\"{x:1250,y:757,t:1527613656513};\\\", \\\"{x:1411,y:673,t:1527613656529};\\\", \\\"{x:1499,y:634,t:1527613656546};\\\", \\\"{x:1579,y:600,t:1527613656563};\\\", \\\"{x:1628,y:574,t:1527613656579};\\\", \\\"{x:1658,y:555,t:1527613656596};\\\", \\\"{x:1680,y:544,t:1527613656613};\\\", \\\"{x:1691,y:538,t:1527613656629};\\\", \\\"{x:1695,y:536,t:1527613656646};\\\", \\\"{x:1695,y:535,t:1527613656664};\\\", \\\"{x:1698,y:536,t:1527613656866};\\\", \\\"{x:1701,y:548,t:1527613656880};\\\", \\\"{x:1705,y:572,t:1527613656897};\\\", \\\"{x:1706,y:595,t:1527613656913};\\\", \\\"{x:1706,y:602,t:1527613656930};\\\", \\\"{x:1706,y:603,t:1527613656947};\\\", \\\"{x:1705,y:604,t:1527613657130};\\\", \\\"{x:1687,y:623,t:1527613657147};\\\", \\\"{x:1670,y:642,t:1527613657163};\\\", \\\"{x:1652,y:663,t:1527613657180};\\\", \\\"{x:1637,y:679,t:1527613657197};\\\", \\\"{x:1619,y:692,t:1527613657214};\\\", \\\"{x:1606,y:699,t:1527613657230};\\\", \\\"{x:1595,y:702,t:1527613657246};\\\", \\\"{x:1587,y:703,t:1527613657263};\\\", \\\"{x:1580,y:704,t:1527613657280};\\\", \\\"{x:1577,y:704,t:1527613657296};\\\", \\\"{x:1572,y:706,t:1527613657313};\\\", \\\"{x:1570,y:707,t:1527613657331};\\\", \\\"{x:1569,y:707,t:1527613657426};\\\", \\\"{x:1564,y:714,t:1527613657434};\\\", \\\"{x:1560,y:723,t:1527613657446};\\\", \\\"{x:1553,y:738,t:1527613657463};\\\", \\\"{x:1549,y:752,t:1527613657481};\\\", \\\"{x:1542,y:764,t:1527613657496};\\\", \\\"{x:1535,y:775,t:1527613657514};\\\", \\\"{x:1533,y:776,t:1527613657530};\\\", \\\"{x:1532,y:779,t:1527613657547};\\\", \\\"{x:1531,y:779,t:1527613657564};\\\", \\\"{x:1528,y:779,t:1527613657581};\\\", \\\"{x:1525,y:779,t:1527613657597};\\\", \\\"{x:1521,y:781,t:1527613657613};\\\", \\\"{x:1518,y:781,t:1527613657630};\\\", \\\"{x:1515,y:782,t:1527613657647};\\\", \\\"{x:1511,y:784,t:1527613657663};\\\", \\\"{x:1505,y:785,t:1527613657681};\\\", \\\"{x:1498,y:786,t:1527613657697};\\\", \\\"{x:1483,y:791,t:1527613657714};\\\", \\\"{x:1472,y:793,t:1527613657730};\\\", \\\"{x:1458,y:795,t:1527613657746};\\\", \\\"{x:1446,y:797,t:1527613657763};\\\", \\\"{x:1442,y:797,t:1527613657780};\\\", \\\"{x:1441,y:797,t:1527613657797};\\\", \\\"{x:1441,y:793,t:1527613658050};\\\", \\\"{x:1441,y:789,t:1527613658063};\\\", \\\"{x:1441,y:780,t:1527613658081};\\\", \\\"{x:1441,y:774,t:1527613658097};\\\", \\\"{x:1441,y:769,t:1527613658114};\\\", \\\"{x:1441,y:763,t:1527613658131};\\\", \\\"{x:1441,y:761,t:1527613658148};\\\", \\\"{x:1441,y:759,t:1527613658164};\\\", \\\"{x:1442,y:759,t:1527613658498};\\\", \\\"{x:1447,y:759,t:1527613658514};\\\", \\\"{x:1453,y:759,t:1527613658531};\\\", \\\"{x:1458,y:762,t:1527613658548};\\\", \\\"{x:1460,y:763,t:1527613658565};\\\", \\\"{x:1461,y:763,t:1527613658581};\\\", \\\"{x:1462,y:763,t:1527613658598};\\\", \\\"{x:1463,y:763,t:1527613658615};\\\", \\\"{x:1463,y:764,t:1527613659186};\\\", \\\"{x:1466,y:765,t:1527613659834};\\\", \\\"{x:1474,y:765,t:1527613659848};\\\", \\\"{x:1499,y:773,t:1527613659865};\\\", \\\"{x:1519,y:777,t:1527613659882};\\\", \\\"{x:1523,y:777,t:1527613659898};\\\", \\\"{x:1525,y:777,t:1527613659915};\\\", \\\"{x:1527,y:777,t:1527613659932};\\\", \\\"{x:1529,y:777,t:1527613659949};\\\", \\\"{x:1530,y:777,t:1527613659986};\\\", \\\"{x:1531,y:777,t:1527613660026};\\\", \\\"{x:1532,y:777,t:1527613660034};\\\", \\\"{x:1533,y:777,t:1527613660049};\\\", \\\"{x:1534,y:775,t:1527613660065};\\\", \\\"{x:1534,y:774,t:1527613660090};\\\", \\\"{x:1534,y:773,t:1527613660114};\\\", \\\"{x:1536,y:772,t:1527613660131};\\\", \\\"{x:1536,y:771,t:1527613660149};\\\", \\\"{x:1536,y:770,t:1527613660290};\\\", \\\"{x:1535,y:770,t:1527613660322};\\\", \\\"{x:1533,y:770,t:1527613660332};\\\", \\\"{x:1526,y:770,t:1527613660348};\\\", \\\"{x:1516,y:771,t:1527613660365};\\\", \\\"{x:1508,y:773,t:1527613660382};\\\", \\\"{x:1506,y:774,t:1527613660399};\\\", \\\"{x:1506,y:773,t:1527613660785};\\\", \\\"{x:1511,y:765,t:1527613660799};\\\", \\\"{x:1520,y:755,t:1527613660815};\\\", \\\"{x:1526,y:746,t:1527613660831};\\\", \\\"{x:1530,y:743,t:1527613660848};\\\", \\\"{x:1534,y:740,t:1527613660865};\\\", \\\"{x:1540,y:740,t:1527613661091};\\\", \\\"{x:1547,y:745,t:1527613661099};\\\", \\\"{x:1562,y:750,t:1527613661116};\\\", \\\"{x:1567,y:751,t:1527613661133};\\\", \\\"{x:1573,y:754,t:1527613661149};\\\", \\\"{x:1576,y:755,t:1527613661166};\\\", \\\"{x:1578,y:755,t:1527613661183};\\\", \\\"{x:1578,y:756,t:1527613661199};\\\", \\\"{x:1579,y:756,t:1527613661296};\\\", \\\"{x:1579,y:763,t:1527613665474};\\\", \\\"{x:1573,y:774,t:1527613665485};\\\", \\\"{x:1556,y:791,t:1527613665502};\\\", \\\"{x:1540,y:803,t:1527613665518};\\\", \\\"{x:1524,y:812,t:1527613665535};\\\", \\\"{x:1516,y:817,t:1527613665553};\\\", \\\"{x:1512,y:820,t:1527613665568};\\\", \\\"{x:1509,y:822,t:1527613665585};\\\", \\\"{x:1491,y:837,t:1527613665601};\\\", \\\"{x:1468,y:851,t:1527613665618};\\\", \\\"{x:1444,y:863,t:1527613665635};\\\", \\\"{x:1425,y:874,t:1527613665652};\\\", \\\"{x:1413,y:880,t:1527613665667};\\\", \\\"{x:1409,y:883,t:1527613665684};\\\", \\\"{x:1409,y:886,t:1527613665769};\\\", \\\"{x:1408,y:888,t:1527613665784};\\\", \\\"{x:1399,y:896,t:1527613665800};\\\", \\\"{x:1390,y:902,t:1527613665818};\\\", \\\"{x:1386,y:905,t:1527613665835};\\\", \\\"{x:1378,y:909,t:1527613665852};\\\", \\\"{x:1372,y:912,t:1527613665868};\\\", \\\"{x:1368,y:914,t:1527613665884};\\\", \\\"{x:1366,y:916,t:1527613665902};\\\", \\\"{x:1365,y:917,t:1527613665917};\\\", \\\"{x:1363,y:917,t:1527613665934};\\\", \\\"{x:1362,y:918,t:1527613665952};\\\", \\\"{x:1361,y:918,t:1527613665968};\\\", \\\"{x:1360,y:918,t:1527613665985};\\\", \\\"{x:1356,y:918,t:1527613666002};\\\", \\\"{x:1353,y:918,t:1527613666018};\\\", \\\"{x:1351,y:918,t:1527613666035};\\\", \\\"{x:1350,y:917,t:1527613666052};\\\", \\\"{x:1349,y:917,t:1527613666068};\\\", \\\"{x:1347,y:917,t:1527613666085};\\\", \\\"{x:1347,y:916,t:1527613666102};\\\", \\\"{x:1346,y:916,t:1527613666145};\\\", \\\"{x:1344,y:915,t:1527613666186};\\\", \\\"{x:1343,y:914,t:1527613666202};\\\", \\\"{x:1342,y:914,t:1527613666219};\\\", \\\"{x:1341,y:910,t:1527613666235};\\\", \\\"{x:1341,y:909,t:1527613666252};\\\", \\\"{x:1341,y:907,t:1527613666269};\\\", \\\"{x:1341,y:906,t:1527613666284};\\\", \\\"{x:1341,y:905,t:1527613666301};\\\", \\\"{x:1341,y:904,t:1527613666318};\\\", \\\"{x:1341,y:902,t:1527613666334};\\\", \\\"{x:1341,y:900,t:1527613666352};\\\", \\\"{x:1341,y:897,t:1527613666377};\\\", \\\"{x:1341,y:896,t:1527613666385};\\\", \\\"{x:1341,y:895,t:1527613670131};\\\", \\\"{x:1343,y:895,t:1527613670140};\\\", \\\"{x:1346,y:895,t:1527613670153};\\\", \\\"{x:1347,y:895,t:1527613670171};\\\", \\\"{x:1350,y:895,t:1527613670187};\\\", \\\"{x:1351,y:895,t:1527613670204};\\\", \\\"{x:1352,y:895,t:1527613670221};\\\", \\\"{x:1351,y:895,t:1527613670561};\\\", \\\"{x:1351,y:894,t:1527613671529};\\\", \\\"{x:1348,y:893,t:1527613671538};\\\", \\\"{x:1341,y:889,t:1527613671556};\\\", \\\"{x:1329,y:886,t:1527613671571};\\\", \\\"{x:1321,y:883,t:1527613671588};\\\", \\\"{x:1316,y:881,t:1527613671605};\\\", \\\"{x:1313,y:879,t:1527613671621};\\\", \\\"{x:1312,y:879,t:1527613671641};\\\", \\\"{x:1311,y:878,t:1527613671842};\\\", \\\"{x:1310,y:876,t:1527613671855};\\\", \\\"{x:1309,y:871,t:1527613671872};\\\", \\\"{x:1308,y:869,t:1527613671888};\\\", \\\"{x:1307,y:865,t:1527613671905};\\\", \\\"{x:1307,y:862,t:1527613671921};\\\", \\\"{x:1306,y:858,t:1527613671938};\\\", \\\"{x:1305,y:856,t:1527613671955};\\\", \\\"{x:1305,y:854,t:1527613671973};\\\", \\\"{x:1304,y:852,t:1527613671988};\\\", \\\"{x:1302,y:849,t:1527613672005};\\\", \\\"{x:1301,y:846,t:1527613672022};\\\", \\\"{x:1299,y:845,t:1527613672038};\\\", \\\"{x:1299,y:844,t:1527613672055};\\\", \\\"{x:1298,y:844,t:1527613672073};\\\", \\\"{x:1296,y:843,t:1527613672114};\\\", \\\"{x:1296,y:842,t:1527613672129};\\\", \\\"{x:1295,y:842,t:1527613672138};\\\", \\\"{x:1294,y:842,t:1527613672155};\\\", \\\"{x:1293,y:842,t:1527613672172};\\\", \\\"{x:1292,y:841,t:1527613672188};\\\", \\\"{x:1290,y:841,t:1527613672205};\\\", \\\"{x:1289,y:840,t:1527613672450};\\\", \\\"{x:1288,y:839,t:1527613672498};\\\", \\\"{x:1287,y:839,t:1527613672514};\\\", \\\"{x:1286,y:839,t:1527613672522};\\\", \\\"{x:1285,y:839,t:1527613672546};\\\", \\\"{x:1285,y:838,t:1527613672555};\\\", \\\"{x:1284,y:838,t:1527613672572};\\\", \\\"{x:1283,y:838,t:1527613672589};\\\", \\\"{x:1282,y:838,t:1527613672605};\\\", \\\"{x:1282,y:837,t:1527613673258};\\\", \\\"{x:1281,y:837,t:1527613673570};\\\", \\\"{x:1279,y:837,t:1527613673664};\\\", \\\"{x:1273,y:837,t:1527613673673};\\\", \\\"{x:1253,y:831,t:1527613673689};\\\", \\\"{x:1240,y:828,t:1527613673705};\\\", \\\"{x:1235,y:828,t:1527613673723};\\\", \\\"{x:1229,y:828,t:1527613673738};\\\", \\\"{x:1225,y:828,t:1527613673755};\\\", \\\"{x:1223,y:828,t:1527613673773};\\\", \\\"{x:1222,y:828,t:1527613673788};\\\", \\\"{x:1221,y:828,t:1527613673817};\\\", \\\"{x:1219,y:828,t:1527613673826};\\\", \\\"{x:1218,y:828,t:1527613673856};\\\", \\\"{x:1211,y:826,t:1527613673873};\\\", \\\"{x:1210,y:826,t:1527613673905};\\\", \\\"{x:1209,y:826,t:1527613673931};\\\", \\\"{x:1210,y:828,t:1527613674177};\\\", \\\"{x:1213,y:841,t:1527613674189};\\\", \\\"{x:1214,y:872,t:1527613674206};\\\", \\\"{x:1209,y:911,t:1527613674222};\\\", \\\"{x:1185,y:959,t:1527613674239};\\\", \\\"{x:1145,y:1006,t:1527613674255};\\\", \\\"{x:1032,y:1072,t:1527613674273};\\\", \\\"{x:915,y:1107,t:1527613674289};\\\", \\\"{x:778,y:1122,t:1527613674306};\\\", \\\"{x:612,y:1122,t:1527613674323};\\\", \\\"{x:461,y:1108,t:1527613674339};\\\", \\\"{x:324,y:1085,t:1527613674356};\\\", \\\"{x:238,y:1058,t:1527613674372};\\\", \\\"{x:209,y:1044,t:1527613674390};\\\", \\\"{x:205,y:1041,t:1527613674406};\\\", \\\"{x:205,y:1040,t:1527613674530};\\\", \\\"{x:205,y:1031,t:1527613674540};\\\", \\\"{x:215,y:990,t:1527613674556};\\\", \\\"{x:230,y:942,t:1527613674573};\\\", \\\"{x:260,y:881,t:1527613674589};\\\", \\\"{x:301,y:810,t:1527613674606};\\\", \\\"{x:332,y:769,t:1527613674623};\\\", \\\"{x:347,y:751,t:1527613674640};\\\", \\\"{x:353,y:744,t:1527613674656};\\\", \\\"{x:355,y:743,t:1527613674673};\\\", \\\"{x:356,y:743,t:1527613674730};\\\", \\\"{x:359,y:743,t:1527613674741};\\\", \\\"{x:374,y:743,t:1527613674756};\\\", \\\"{x:402,y:746,t:1527613674773};\\\", \\\"{x:429,y:751,t:1527613674790};\\\", \\\"{x:449,y:755,t:1527613674806};\\\", \\\"{x:460,y:757,t:1527613674822};\\\", \\\"{x:465,y:760,t:1527613674840};\\\", \\\"{x:470,y:760,t:1527613674856};\\\", \\\"{x:473,y:760,t:1527613674872};\\\", \\\"{x:476,y:760,t:1527613674890};\\\", \\\"{x:484,y:756,t:1527613674906};\\\", \\\"{x:489,y:747,t:1527613674923};\\\", \\\"{x:492,y:737,t:1527613674939};\\\", \\\"{x:495,y:728,t:1527613674957};\\\", \\\"{x:496,y:725,t:1527613674972};\\\", \\\"{x:496,y:724,t:1527613674990};\\\", \\\"{x:496,y:721,t:1527613675088};\\\", \\\"{x:496,y:720,t:1527613675097};\\\" ] }, { \\\"rt\\\": 92419, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 370288, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-I -I -O -I -11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-03 PM-01 PM-01 PM-02 PM-03 PM-02 PM-Z -Z -Z -A -C -A -O -O -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:673,t:1527613677827};\\\", \\\"{x:592,y:494,t:1527613677845};\\\", \\\"{x:633,y:408,t:1527613677863};\\\", \\\"{x:637,y:401,t:1527613677879};\\\", \\\"{x:638,y:402,t:1527613685010};\\\", \\\"{x:642,y:403,t:1527613685019};\\\", \\\"{x:657,y:403,t:1527613685035};\\\", \\\"{x:677,y:406,t:1527613685051};\\\", \\\"{x:710,y:417,t:1527613685068};\\\", \\\"{x:795,y:451,t:1527613685086};\\\", \\\"{x:857,y:470,t:1527613685101};\\\", \\\"{x:872,y:474,t:1527613685118};\\\", \\\"{x:878,y:476,t:1527613685135};\\\", \\\"{x:881,y:477,t:1527613685151};\\\", \\\"{x:888,y:478,t:1527613685168};\\\", \\\"{x:909,y:482,t:1527613685185};\\\", \\\"{x:927,y:485,t:1527613685200};\\\", \\\"{x:948,y:489,t:1527613685217};\\\", \\\"{x:969,y:491,t:1527613685235};\\\", \\\"{x:992,y:494,t:1527613685251};\\\", \\\"{x:1017,y:499,t:1527613685268};\\\", \\\"{x:1036,y:502,t:1527613685284};\\\", \\\"{x:1057,y:504,t:1527613685301};\\\", \\\"{x:1084,y:504,t:1527613685318};\\\", \\\"{x:1113,y:504,t:1527613685334};\\\", \\\"{x:1145,y:504,t:1527613685352};\\\", \\\"{x:1160,y:504,t:1527613685368};\\\", \\\"{x:1170,y:504,t:1527613685384};\\\", \\\"{x:1182,y:503,t:1527613685401};\\\", \\\"{x:1191,y:500,t:1527613685418};\\\", \\\"{x:1199,y:497,t:1527613685435};\\\", \\\"{x:1203,y:495,t:1527613685452};\\\", \\\"{x:1205,y:494,t:1527613685468};\\\", \\\"{x:1207,y:493,t:1527613685485};\\\", \\\"{x:1208,y:493,t:1527613685502};\\\", \\\"{x:1208,y:492,t:1527613685518};\\\", \\\"{x:1211,y:491,t:1527613685535};\\\", \\\"{x:1220,y:487,t:1527613685552};\\\", \\\"{x:1221,y:487,t:1527613685568};\\\", \\\"{x:1223,y:486,t:1527613685585};\\\", \\\"{x:1226,y:485,t:1527613685602};\\\", \\\"{x:1231,y:484,t:1527613685618};\\\", \\\"{x:1236,y:482,t:1527613685636};\\\", \\\"{x:1245,y:481,t:1527613685653};\\\", \\\"{x:1249,y:480,t:1527613685668};\\\", \\\"{x:1253,y:478,t:1527613685685};\\\", \\\"{x:1259,y:476,t:1527613685703};\\\", \\\"{x:1265,y:476,t:1527613685718};\\\", \\\"{x:1268,y:476,t:1527613685735};\\\", \\\"{x:1270,y:476,t:1527613685753};\\\", \\\"{x:1273,y:476,t:1527613685769};\\\", \\\"{x:1274,y:476,t:1527613685785};\\\", \\\"{x:1276,y:476,t:1527613685803};\\\", \\\"{x:1277,y:476,t:1527613685819};\\\", \\\"{x:1278,y:476,t:1527613685953};\\\", \\\"{x:1280,y:476,t:1527613685969};\\\", \\\"{x:1282,y:476,t:1527613685986};\\\", \\\"{x:1283,y:476,t:1527613686009};\\\", \\\"{x:1284,y:476,t:1527613686020};\\\", \\\"{x:1286,y:476,t:1527613686036};\\\", \\\"{x:1288,y:476,t:1527613686053};\\\", \\\"{x:1290,y:477,t:1527613686070};\\\", \\\"{x:1292,y:477,t:1527613686086};\\\", \\\"{x:1294,y:478,t:1527613686103};\\\", \\\"{x:1295,y:478,t:1527613686119};\\\", \\\"{x:1297,y:480,t:1527613686136};\\\", \\\"{x:1299,y:480,t:1527613686153};\\\", \\\"{x:1301,y:481,t:1527613686170};\\\", \\\"{x:1301,y:482,t:1527613686186};\\\", \\\"{x:1302,y:482,t:1527613686202};\\\", \\\"{x:1303,y:483,t:1527613686219};\\\", \\\"{x:1305,y:484,t:1527613686235};\\\", \\\"{x:1306,y:486,t:1527613686253};\\\", \\\"{x:1308,y:490,t:1527613686270};\\\", \\\"{x:1309,y:492,t:1527613686290};\\\", \\\"{x:1310,y:495,t:1527613686305};\\\", \\\"{x:1312,y:498,t:1527613686319};\\\", \\\"{x:1313,y:501,t:1527613686335};\\\", \\\"{x:1314,y:505,t:1527613686352};\\\", \\\"{x:1315,y:506,t:1527613686369};\\\", \\\"{x:1315,y:507,t:1527613686386};\\\", \\\"{x:1315,y:509,t:1527613686402};\\\", \\\"{x:1315,y:510,t:1527613686464};\\\", \\\"{x:1316,y:510,t:1527613686505};\\\", \\\"{x:1316,y:512,t:1527613686570};\\\", \\\"{x:1316,y:510,t:1527613687073};\\\", \\\"{x:1316,y:509,t:1527613687087};\\\", \\\"{x:1316,y:506,t:1527613687103};\\\", \\\"{x:1316,y:505,t:1527613687121};\\\", \\\"{x:1316,y:504,t:1527613687136};\\\", \\\"{x:1316,y:503,t:1527613687153};\\\", \\\"{x:1316,y:501,t:1527613687169};\\\", \\\"{x:1316,y:500,t:1527613687186};\\\", \\\"{x:1316,y:511,t:1527613688915};\\\", \\\"{x:1313,y:528,t:1527613688922};\\\", \\\"{x:1313,y:555,t:1527613688938};\\\", \\\"{x:1313,y:577,t:1527613688955};\\\", \\\"{x:1312,y:603,t:1527613688972};\\\", \\\"{x:1312,y:634,t:1527613688988};\\\", \\\"{x:1311,y:661,t:1527613689006};\\\", \\\"{x:1309,y:689,t:1527613689022};\\\", \\\"{x:1309,y:719,t:1527613689037};\\\", \\\"{x:1309,y:750,t:1527613689055};\\\", \\\"{x:1309,y:775,t:1527613689072};\\\", \\\"{x:1309,y:787,t:1527613689088};\\\", \\\"{x:1309,y:793,t:1527613689105};\\\", \\\"{x:1309,y:794,t:1527613689122};\\\", \\\"{x:1310,y:795,t:1527613689138};\\\", \\\"{x:1310,y:796,t:1527613689161};\\\", \\\"{x:1311,y:798,t:1527613689172};\\\", \\\"{x:1312,y:801,t:1527613689188};\\\", \\\"{x:1313,y:808,t:1527613689205};\\\", \\\"{x:1315,y:813,t:1527613689222};\\\", \\\"{x:1316,y:819,t:1527613689238};\\\", \\\"{x:1316,y:823,t:1527613689255};\\\", \\\"{x:1316,y:828,t:1527613689271};\\\", \\\"{x:1316,y:831,t:1527613689289};\\\", \\\"{x:1316,y:836,t:1527613689306};\\\", \\\"{x:1316,y:837,t:1527613689322};\\\", \\\"{x:1316,y:839,t:1527613689339};\\\", \\\"{x:1316,y:840,t:1527613689355};\\\", \\\"{x:1316,y:841,t:1527613689377};\\\", \\\"{x:1316,y:843,t:1527613689393};\\\", \\\"{x:1316,y:844,t:1527613689404};\\\", \\\"{x:1316,y:848,t:1527613689422};\\\", \\\"{x:1316,y:853,t:1527613689438};\\\", \\\"{x:1316,y:858,t:1527613689455};\\\", \\\"{x:1316,y:864,t:1527613689472};\\\", \\\"{x:1316,y:870,t:1527613689489};\\\", \\\"{x:1315,y:875,t:1527613689505};\\\", \\\"{x:1314,y:880,t:1527613689522};\\\", \\\"{x:1313,y:883,t:1527613689539};\\\", \\\"{x:1312,y:887,t:1527613689555};\\\", \\\"{x:1312,y:889,t:1527613689572};\\\", \\\"{x:1311,y:892,t:1527613689588};\\\", \\\"{x:1311,y:897,t:1527613689605};\\\", \\\"{x:1311,y:900,t:1527613689622};\\\", \\\"{x:1311,y:904,t:1527613689639};\\\", \\\"{x:1309,y:907,t:1527613689655};\\\", \\\"{x:1309,y:908,t:1527613689671};\\\", \\\"{x:1309,y:912,t:1527613689690};\\\", \\\"{x:1309,y:913,t:1527613689714};\\\", \\\"{x:1309,y:914,t:1527613689729};\\\", \\\"{x:1309,y:916,t:1527613689753};\\\", \\\"{x:1309,y:917,t:1527613689761};\\\", \\\"{x:1309,y:918,t:1527613689771};\\\", \\\"{x:1309,y:921,t:1527613689788};\\\", \\\"{x:1308,y:921,t:1527613689805};\\\", \\\"{x:1308,y:923,t:1527613689821};\\\", \\\"{x:1308,y:917,t:1527613689953};\\\", \\\"{x:1308,y:910,t:1527613689960};\\\", \\\"{x:1308,y:896,t:1527613689972};\\\", \\\"{x:1313,y:865,t:1527613689989};\\\", \\\"{x:1316,y:838,t:1527613690005};\\\", \\\"{x:1321,y:816,t:1527613690022};\\\", \\\"{x:1322,y:796,t:1527613690038};\\\", \\\"{x:1325,y:776,t:1527613690055};\\\", \\\"{x:1328,y:760,t:1527613690072};\\\", \\\"{x:1331,y:735,t:1527613690088};\\\", \\\"{x:1333,y:721,t:1527613690105};\\\", \\\"{x:1334,y:706,t:1527613690121};\\\", \\\"{x:1337,y:695,t:1527613690139};\\\", \\\"{x:1338,y:686,t:1527613690156};\\\", \\\"{x:1338,y:679,t:1527613690172};\\\", \\\"{x:1339,y:669,t:1527613690188};\\\", \\\"{x:1339,y:654,t:1527613690206};\\\", \\\"{x:1339,y:639,t:1527613690223};\\\", \\\"{x:1341,y:616,t:1527613690238};\\\", \\\"{x:1341,y:595,t:1527613690256};\\\", \\\"{x:1340,y:569,t:1527613690272};\\\", \\\"{x:1339,y:559,t:1527613690288};\\\", \\\"{x:1337,y:553,t:1527613690306};\\\", \\\"{x:1337,y:548,t:1527613690322};\\\", \\\"{x:1337,y:546,t:1527613690339};\\\", \\\"{x:1336,y:542,t:1527613690355};\\\", \\\"{x:1335,y:539,t:1527613690372};\\\", \\\"{x:1333,y:535,t:1527613690388};\\\", \\\"{x:1332,y:531,t:1527613690406};\\\", \\\"{x:1331,y:529,t:1527613690422};\\\", \\\"{x:1330,y:526,t:1527613690439};\\\", \\\"{x:1328,y:520,t:1527613690455};\\\", \\\"{x:1324,y:515,t:1527613690473};\\\", \\\"{x:1322,y:511,t:1527613690488};\\\", \\\"{x:1321,y:511,t:1527613690521};\\\", \\\"{x:1320,y:509,t:1527613690529};\\\", \\\"{x:1319,y:507,t:1527613690569};\\\", \\\"{x:1318,y:504,t:1527613690585};\\\", \\\"{x:1318,y:502,t:1527613690601};\\\", \\\"{x:1317,y:502,t:1527613690609};\\\", \\\"{x:1317,y:501,t:1527613690622};\\\", \\\"{x:1316,y:500,t:1527613690639};\\\", \\\"{x:1316,y:499,t:1527613690656};\\\", \\\"{x:1315,y:498,t:1527613690672};\\\", \\\"{x:1315,y:497,t:1527613690689};\\\", \\\"{x:1314,y:496,t:1527613690705};\\\", \\\"{x:1313,y:495,t:1527613690722};\\\", \\\"{x:1312,y:494,t:1527613690739};\\\", \\\"{x:1311,y:493,t:1527613690755};\\\", \\\"{x:1311,y:492,t:1527613690772};\\\", \\\"{x:1312,y:494,t:1527613691209};\\\", \\\"{x:1312,y:496,t:1527613691223};\\\", \\\"{x:1313,y:501,t:1527613691240};\\\", \\\"{x:1314,y:510,t:1527613691258};\\\", \\\"{x:1317,y:517,t:1527613691273};\\\", \\\"{x:1317,y:520,t:1527613691290};\\\", \\\"{x:1318,y:522,t:1527613691307};\\\", \\\"{x:1319,y:524,t:1527613691323};\\\", \\\"{x:1319,y:525,t:1527613691340};\\\", \\\"{x:1319,y:526,t:1527613691356};\\\", \\\"{x:1319,y:529,t:1527613691373};\\\", \\\"{x:1319,y:531,t:1527613691389};\\\", \\\"{x:1319,y:534,t:1527613691406};\\\", \\\"{x:1319,y:538,t:1527613691422};\\\", \\\"{x:1319,y:540,t:1527613691439};\\\", \\\"{x:1319,y:542,t:1527613691456};\\\", \\\"{x:1319,y:543,t:1527613691480};\\\", \\\"{x:1318,y:543,t:1527613691489};\\\", \\\"{x:1318,y:545,t:1527613691521};\\\", \\\"{x:1318,y:546,t:1527613691593};\\\", \\\"{x:1317,y:547,t:1527613691625};\\\", \\\"{x:1317,y:548,t:1527613691641};\\\", \\\"{x:1317,y:549,t:1527613691745};\\\", \\\"{x:1317,y:551,t:1527613691769};\\\", \\\"{x:1316,y:553,t:1527613691784};\\\", \\\"{x:1316,y:554,t:1527613691808};\\\", \\\"{x:1316,y:555,t:1527613691823};\\\", \\\"{x:1314,y:557,t:1527613691839};\\\", \\\"{x:1314,y:559,t:1527613691856};\\\", \\\"{x:1313,y:562,t:1527613691873};\\\", \\\"{x:1313,y:563,t:1527613691889};\\\", \\\"{x:1313,y:564,t:1527613691907};\\\", \\\"{x:1313,y:565,t:1527613691923};\\\", \\\"{x:1313,y:567,t:1527613691939};\\\", \\\"{x:1312,y:569,t:1527613691956};\\\", \\\"{x:1312,y:570,t:1527613691973};\\\", \\\"{x:1312,y:571,t:1527613691989};\\\", \\\"{x:1312,y:574,t:1527613692007};\\\", \\\"{x:1311,y:576,t:1527613692024};\\\", \\\"{x:1311,y:577,t:1527613692040};\\\", \\\"{x:1310,y:579,t:1527613692057};\\\", \\\"{x:1310,y:580,t:1527613692089};\\\", \\\"{x:1309,y:581,t:1527613692113};\\\", \\\"{x:1309,y:583,t:1527613692137};\\\", \\\"{x:1309,y:585,t:1527613692153};\\\", \\\"{x:1309,y:586,t:1527613692168};\\\", \\\"{x:1309,y:587,t:1527613692176};\\\", \\\"{x:1309,y:588,t:1527613692190};\\\", \\\"{x:1309,y:590,t:1527613692207};\\\", \\\"{x:1309,y:593,t:1527613692223};\\\", \\\"{x:1309,y:597,t:1527613692240};\\\", \\\"{x:1309,y:600,t:1527613692256};\\\", \\\"{x:1309,y:603,t:1527613692273};\\\", \\\"{x:1309,y:606,t:1527613692290};\\\", \\\"{x:1309,y:607,t:1527613692307};\\\", \\\"{x:1309,y:608,t:1527613692323};\\\", \\\"{x:1309,y:609,t:1527613692340};\\\", \\\"{x:1309,y:611,t:1527613692356};\\\", \\\"{x:1309,y:616,t:1527613692373};\\\", \\\"{x:1307,y:620,t:1527613692391};\\\", \\\"{x:1307,y:625,t:1527613692406};\\\", \\\"{x:1306,y:628,t:1527613692423};\\\", \\\"{x:1306,y:632,t:1527613692440};\\\", \\\"{x:1306,y:634,t:1527613692457};\\\", \\\"{x:1306,y:637,t:1527613692474};\\\", \\\"{x:1306,y:642,t:1527613692491};\\\", \\\"{x:1306,y:650,t:1527613692506};\\\", \\\"{x:1306,y:657,t:1527613692524};\\\", \\\"{x:1306,y:665,t:1527613692541};\\\", \\\"{x:1306,y:668,t:1527613692558};\\\", \\\"{x:1306,y:670,t:1527613692573};\\\", \\\"{x:1306,y:672,t:1527613692590};\\\", \\\"{x:1306,y:673,t:1527613692607};\\\", \\\"{x:1306,y:678,t:1527613692624};\\\", \\\"{x:1306,y:684,t:1527613692641};\\\", \\\"{x:1306,y:690,t:1527613692657};\\\", \\\"{x:1306,y:695,t:1527613692674};\\\", \\\"{x:1306,y:698,t:1527613692692};\\\", \\\"{x:1306,y:702,t:1527613692708};\\\", \\\"{x:1306,y:708,t:1527613692724};\\\", \\\"{x:1306,y:713,t:1527613692741};\\\", \\\"{x:1306,y:720,t:1527613692758};\\\", \\\"{x:1306,y:729,t:1527613692773};\\\", \\\"{x:1306,y:738,t:1527613692791};\\\", \\\"{x:1306,y:751,t:1527613692807};\\\", \\\"{x:1307,y:764,t:1527613692824};\\\", \\\"{x:1308,y:767,t:1527613692824};\\\", \\\"{x:1308,y:776,t:1527613692840};\\\", \\\"{x:1308,y:784,t:1527613692857};\\\", \\\"{x:1309,y:790,t:1527613692873};\\\", \\\"{x:1309,y:795,t:1527613692890};\\\", \\\"{x:1309,y:805,t:1527613692908};\\\", \\\"{x:1311,y:814,t:1527613692925};\\\", \\\"{x:1311,y:817,t:1527613692940};\\\", \\\"{x:1311,y:821,t:1527613692958};\\\", \\\"{x:1311,y:824,t:1527613692975};\\\", \\\"{x:1311,y:826,t:1527613692990};\\\", \\\"{x:1311,y:827,t:1527613693008};\\\", \\\"{x:1311,y:828,t:1527613693025};\\\", \\\"{x:1311,y:830,t:1527613693042};\\\", \\\"{x:1311,y:831,t:1527613693058};\\\", \\\"{x:1311,y:833,t:1527613693074};\\\", \\\"{x:1311,y:834,t:1527613693091};\\\", \\\"{x:1311,y:836,t:1527613693108};\\\", \\\"{x:1311,y:837,t:1527613693125};\\\", \\\"{x:1311,y:838,t:1527613693142};\\\", \\\"{x:1311,y:839,t:1527613693158};\\\", \\\"{x:1311,y:839,t:1527613693174};\\\", \\\"{x:1311,y:840,t:1527613693208};\\\", \\\"{x:1313,y:844,t:1527613693224};\\\", \\\"{x:1317,y:850,t:1527613693242};\\\", \\\"{x:1318,y:853,t:1527613693259};\\\", \\\"{x:1319,y:855,t:1527613693275};\\\", \\\"{x:1320,y:856,t:1527613693291};\\\", \\\"{x:1320,y:858,t:1527613693410};\\\", \\\"{x:1320,y:860,t:1527613693425};\\\", \\\"{x:1320,y:862,t:1527613693442};\\\", \\\"{x:1320,y:865,t:1527613693459};\\\", \\\"{x:1320,y:868,t:1527613693475};\\\", \\\"{x:1320,y:869,t:1527613693492};\\\", \\\"{x:1320,y:873,t:1527613693508};\\\", \\\"{x:1320,y:879,t:1527613693525};\\\", \\\"{x:1322,y:889,t:1527613693542};\\\", \\\"{x:1324,y:899,t:1527613693559};\\\", \\\"{x:1324,y:908,t:1527613693576};\\\", \\\"{x:1326,y:913,t:1527613693592};\\\", \\\"{x:1326,y:918,t:1527613693609};\\\", \\\"{x:1327,y:919,t:1527613693625};\\\", \\\"{x:1327,y:921,t:1527613693642};\\\", \\\"{x:1327,y:924,t:1527613693659};\\\", \\\"{x:1327,y:929,t:1527613693675};\\\", \\\"{x:1327,y:932,t:1527613693692};\\\", \\\"{x:1327,y:936,t:1527613693709};\\\", \\\"{x:1327,y:939,t:1527613693725};\\\", \\\"{x:1327,y:941,t:1527613693741};\\\", \\\"{x:1327,y:942,t:1527613693759};\\\", \\\"{x:1327,y:943,t:1527613693775};\\\", \\\"{x:1327,y:945,t:1527613693792};\\\", \\\"{x:1327,y:946,t:1527613693817};\\\", \\\"{x:1327,y:947,t:1527613693825};\\\", \\\"{x:1327,y:948,t:1527613693842};\\\", \\\"{x:1327,y:951,t:1527613693858};\\\", \\\"{x:1326,y:952,t:1527613693874};\\\", \\\"{x:1326,y:954,t:1527613693891};\\\", \\\"{x:1326,y:956,t:1527613693908};\\\", \\\"{x:1325,y:958,t:1527613693924};\\\", \\\"{x:1324,y:959,t:1527613693941};\\\", \\\"{x:1324,y:961,t:1527613693959};\\\", \\\"{x:1323,y:963,t:1527613693985};\\\", \\\"{x:1322,y:964,t:1527613694425};\\\", \\\"{x:1319,y:964,t:1527613697074};\\\", \\\"{x:1311,y:968,t:1527613697082};\\\", \\\"{x:1307,y:969,t:1527613697092};\\\", \\\"{x:1303,y:973,t:1527613697109};\\\", \\\"{x:1301,y:974,t:1527613697127};\\\", \\\"{x:1301,y:972,t:1527613697409};\\\", \\\"{x:1301,y:971,t:1527613697433};\\\", \\\"{x:1303,y:970,t:1527613697443};\\\", \\\"{x:1304,y:969,t:1527613697459};\\\", \\\"{x:1307,y:966,t:1527613697476};\\\", \\\"{x:1310,y:964,t:1527613697492};\\\", \\\"{x:1313,y:962,t:1527613697509};\\\", \\\"{x:1316,y:961,t:1527613697526};\\\", \\\"{x:1318,y:961,t:1527613697553};\\\", \\\"{x:1319,y:961,t:1527613697609};\\\", \\\"{x:1321,y:961,t:1527613697626};\\\", \\\"{x:1323,y:961,t:1527613697642};\\\", \\\"{x:1325,y:962,t:1527613697659};\\\", \\\"{x:1327,y:962,t:1527613697676};\\\", \\\"{x:1330,y:963,t:1527613697692};\\\", \\\"{x:1335,y:965,t:1527613697710};\\\", \\\"{x:1337,y:966,t:1527613697725};\\\", \\\"{x:1338,y:966,t:1527613697742};\\\", \\\"{x:1342,y:966,t:1527613697759};\\\", \\\"{x:1343,y:966,t:1527613697776};\\\", \\\"{x:1344,y:966,t:1527613697792};\\\", \\\"{x:1345,y:966,t:1527613697809};\\\", \\\"{x:1346,y:966,t:1527613697825};\\\", \\\"{x:1347,y:966,t:1527613697849};\\\", \\\"{x:1348,y:966,t:1527613697865};\\\", \\\"{x:1350,y:966,t:1527613697897};\\\", \\\"{x:1351,y:966,t:1527613698627};\\\", \\\"{x:1352,y:967,t:1527613698636};\\\", \\\"{x:1353,y:967,t:1527613698652};\\\", \\\"{x:1357,y:970,t:1527613698669};\\\", \\\"{x:1362,y:970,t:1527613698686};\\\", \\\"{x:1368,y:973,t:1527613698702};\\\", \\\"{x:1374,y:973,t:1527613698719};\\\", \\\"{x:1379,y:975,t:1527613698736};\\\", \\\"{x:1387,y:975,t:1527613698752};\\\", \\\"{x:1394,y:975,t:1527613698769};\\\", \\\"{x:1396,y:975,t:1527613698786};\\\", \\\"{x:1398,y:975,t:1527613698802};\\\", \\\"{x:1400,y:975,t:1527613698819};\\\", \\\"{x:1402,y:975,t:1527613698836};\\\", \\\"{x:1403,y:973,t:1527613698852};\\\", \\\"{x:1403,y:970,t:1527613698869};\\\", \\\"{x:1404,y:968,t:1527613698886};\\\", \\\"{x:1406,y:964,t:1527613698902};\\\", \\\"{x:1406,y:963,t:1527613698919};\\\", \\\"{x:1407,y:963,t:1527613698936};\\\", \\\"{x:1408,y:962,t:1527613698952};\\\", \\\"{x:1408,y:961,t:1527613698969};\\\", \\\"{x:1408,y:960,t:1527613698986};\\\", \\\"{x:1409,y:959,t:1527613699220};\\\", \\\"{x:1412,y:959,t:1527613699237};\\\", \\\"{x:1414,y:959,t:1527613699252};\\\", \\\"{x:1417,y:962,t:1527613699269};\\\", \\\"{x:1417,y:964,t:1527613699286};\\\", \\\"{x:1419,y:965,t:1527613699302};\\\", \\\"{x:1420,y:965,t:1527613699319};\\\", \\\"{x:1422,y:965,t:1527613699336};\\\", \\\"{x:1425,y:965,t:1527613699352};\\\", \\\"{x:1430,y:965,t:1527613699369};\\\", \\\"{x:1438,y:965,t:1527613699386};\\\", \\\"{x:1444,y:965,t:1527613699402};\\\", \\\"{x:1448,y:963,t:1527613699419};\\\", \\\"{x:1449,y:962,t:1527613699437};\\\", \\\"{x:1452,y:960,t:1527613699454};\\\", \\\"{x:1454,y:957,t:1527613699469};\\\", \\\"{x:1456,y:957,t:1527613699486};\\\", \\\"{x:1456,y:956,t:1527613699503};\\\", \\\"{x:1459,y:954,t:1527613699519};\\\", \\\"{x:1461,y:953,t:1527613699536};\\\", \\\"{x:1462,y:952,t:1527613699554};\\\", \\\"{x:1463,y:951,t:1527613699569};\\\", \\\"{x:1465,y:951,t:1527613699787};\\\", \\\"{x:1467,y:951,t:1527613699835};\\\", \\\"{x:1469,y:952,t:1527613699853};\\\", \\\"{x:1472,y:955,t:1527613699869};\\\", \\\"{x:1475,y:958,t:1527613699886};\\\", \\\"{x:1478,y:963,t:1527613699904};\\\", \\\"{x:1480,y:966,t:1527613699919};\\\", \\\"{x:1482,y:969,t:1527613699936};\\\", \\\"{x:1483,y:969,t:1527613699953};\\\", \\\"{x:1484,y:970,t:1527613699969};\\\", \\\"{x:1485,y:970,t:1527613699995};\\\", \\\"{x:1485,y:971,t:1527613700002};\\\", \\\"{x:1488,y:972,t:1527613700019};\\\", \\\"{x:1491,y:974,t:1527613700036};\\\", \\\"{x:1499,y:978,t:1527613700053};\\\", \\\"{x:1513,y:982,t:1527613700069};\\\", \\\"{x:1523,y:984,t:1527613700086};\\\", \\\"{x:1531,y:984,t:1527613700103};\\\", \\\"{x:1535,y:984,t:1527613700119};\\\", \\\"{x:1538,y:984,t:1527613700136};\\\", \\\"{x:1539,y:984,t:1527613700155};\\\", \\\"{x:1540,y:984,t:1527613700170};\\\", \\\"{x:1541,y:983,t:1527613700185};\\\", \\\"{x:1546,y:979,t:1527613700202};\\\", \\\"{x:1549,y:975,t:1527613700219};\\\", \\\"{x:1552,y:972,t:1527613700236};\\\", \\\"{x:1554,y:970,t:1527613700252};\\\", \\\"{x:1557,y:966,t:1527613700268};\\\", \\\"{x:1558,y:963,t:1527613700286};\\\", \\\"{x:1559,y:961,t:1527613700302};\\\", \\\"{x:1559,y:959,t:1527613700319};\\\", \\\"{x:1559,y:957,t:1527613700336};\\\", \\\"{x:1559,y:956,t:1527613700523};\\\", \\\"{x:1554,y:956,t:1527613700536};\\\", \\\"{x:1551,y:957,t:1527613700553};\\\", \\\"{x:1546,y:958,t:1527613700570};\\\", \\\"{x:1544,y:958,t:1527613700586};\\\", \\\"{x:1546,y:958,t:1527613704610};\\\", \\\"{x:1547,y:957,t:1527613704620};\\\", \\\"{x:1549,y:956,t:1527613704636};\\\", \\\"{x:1548,y:958,t:1527613704939};\\\", \\\"{x:1547,y:958,t:1527613704953};\\\", \\\"{x:1547,y:959,t:1527613704971};\\\", \\\"{x:1547,y:960,t:1527613705203};\\\", \\\"{x:1521,y:961,t:1527613707074};\\\", \\\"{x:1416,y:961,t:1527613707087};\\\", \\\"{x:1219,y:930,t:1527613707102};\\\", \\\"{x:1112,y:907,t:1527613707120};\\\", \\\"{x:1026,y:870,t:1527613707137};\\\", \\\"{x:908,y:797,t:1527613707152};\\\", \\\"{x:805,y:716,t:1527613707170};\\\", \\\"{x:766,y:688,t:1527613707187};\\\", \\\"{x:755,y:681,t:1527613707203};\\\", \\\"{x:755,y:680,t:1527613707220};\\\", \\\"{x:757,y:674,t:1527613707237};\\\", \\\"{x:761,y:667,t:1527613707253};\\\", \\\"{x:769,y:658,t:1527613707270};\\\", \\\"{x:772,y:653,t:1527613707286};\\\", \\\"{x:782,y:643,t:1527613707303};\\\", \\\"{x:792,y:634,t:1527613707320};\\\", \\\"{x:796,y:629,t:1527613707337};\\\", \\\"{x:797,y:628,t:1527613707353};\\\", \\\"{x:792,y:621,t:1527613707372};\\\", \\\"{x:771,y:612,t:1527613707387};\\\", \\\"{x:740,y:603,t:1527613707402};\\\", \\\"{x:727,y:600,t:1527613707413};\\\", \\\"{x:701,y:599,t:1527613707431};\\\", \\\"{x:683,y:599,t:1527613707445};\\\", \\\"{x:672,y:601,t:1527613707462};\\\", \\\"{x:671,y:602,t:1527613707480};\\\", \\\"{x:665,y:604,t:1527613707603};\\\", \\\"{x:655,y:607,t:1527613707613};\\\", \\\"{x:633,y:610,t:1527613707631};\\\", \\\"{x:613,y:613,t:1527613707645};\\\", \\\"{x:603,y:613,t:1527613707663};\\\", \\\"{x:602,y:613,t:1527613707679};\\\", \\\"{x:602,y:614,t:1527613708419};\\\", \\\"{x:624,y:614,t:1527613708431};\\\", \\\"{x:711,y:617,t:1527613708448};\\\", \\\"{x:799,y:629,t:1527613708464};\\\", \\\"{x:919,y:647,t:1527613708480};\\\", \\\"{x:1033,y:687,t:1527613708497};\\\", \\\"{x:1170,y:734,t:1527613708514};\\\", \\\"{x:1210,y:751,t:1527613708530};\\\", \\\"{x:1226,y:761,t:1527613708547};\\\", \\\"{x:1236,y:767,t:1527613708564};\\\", \\\"{x:1249,y:777,t:1527613708579};\\\", \\\"{x:1267,y:792,t:1527613708597};\\\", \\\"{x:1288,y:812,t:1527613708614};\\\", \\\"{x:1322,y:840,t:1527613708630};\\\", \\\"{x:1354,y:865,t:1527613708647};\\\", \\\"{x:1392,y:887,t:1527613708664};\\\", \\\"{x:1430,y:911,t:1527613708679};\\\", \\\"{x:1460,y:928,t:1527613708697};\\\", \\\"{x:1488,y:941,t:1527613708714};\\\", \\\"{x:1502,y:947,t:1527613708730};\\\", \\\"{x:1512,y:952,t:1527613708747};\\\", \\\"{x:1526,y:956,t:1527613708764};\\\", \\\"{x:1536,y:959,t:1527613708780};\\\", \\\"{x:1552,y:964,t:1527613708797};\\\", \\\"{x:1572,y:966,t:1527613708814};\\\", \\\"{x:1590,y:966,t:1527613708830};\\\", \\\"{x:1599,y:966,t:1527613708847};\\\", \\\"{x:1602,y:966,t:1527613708864};\\\", \\\"{x:1603,y:966,t:1527613708923};\\\", \\\"{x:1604,y:966,t:1527613708939};\\\", \\\"{x:1605,y:966,t:1527613709187};\\\", \\\"{x:1606,y:966,t:1527613709227};\\\", \\\"{x:1606,y:965,t:1527613709243};\\\", \\\"{x:1608,y:964,t:1527613709251};\\\", \\\"{x:1608,y:963,t:1527613709264};\\\", \\\"{x:1609,y:962,t:1527613709282};\\\", \\\"{x:1611,y:960,t:1527613709298};\\\", \\\"{x:1612,y:959,t:1527613709315};\\\", \\\"{x:1613,y:959,t:1527613709331};\\\", \\\"{x:1615,y:959,t:1527613709348};\\\", \\\"{x:1614,y:959,t:1527613712123};\\\", \\\"{x:1610,y:967,t:1527613712133};\\\", \\\"{x:1608,y:971,t:1527613712150};\\\", \\\"{x:1606,y:974,t:1527613712167};\\\", \\\"{x:1604,y:977,t:1527613712182};\\\", \\\"{x:1603,y:980,t:1527613712199};\\\", \\\"{x:1602,y:981,t:1527613712217};\\\", \\\"{x:1600,y:983,t:1527613712274};\\\", \\\"{x:1596,y:983,t:1527613712298};\\\", \\\"{x:1593,y:984,t:1527613712305};\\\", \\\"{x:1587,y:984,t:1527613712316};\\\", \\\"{x:1569,y:988,t:1527613712332};\\\", \\\"{x:1549,y:988,t:1527613712349};\\\", \\\"{x:1535,y:988,t:1527613712366};\\\", \\\"{x:1530,y:987,t:1527613712382};\\\", \\\"{x:1527,y:986,t:1527613712399};\\\", \\\"{x:1527,y:985,t:1527613712490};\\\", \\\"{x:1526,y:985,t:1527613712531};\\\", \\\"{x:1526,y:984,t:1527613712571};\\\", \\\"{x:1526,y:982,t:1527613712586};\\\", \\\"{x:1526,y:981,t:1527613712600};\\\", \\\"{x:1528,y:976,t:1527613712617};\\\", \\\"{x:1532,y:971,t:1527613712633};\\\", \\\"{x:1536,y:968,t:1527613712650};\\\", \\\"{x:1542,y:964,t:1527613712666};\\\", \\\"{x:1547,y:961,t:1527613712684};\\\", \\\"{x:1548,y:960,t:1527613712715};\\\", \\\"{x:1549,y:959,t:1527613712722};\\\", \\\"{x:1551,y:958,t:1527613712747};\\\", \\\"{x:1551,y:957,t:1527613712763};\\\", \\\"{x:1551,y:956,t:1527613713171};\\\", \\\"{x:1551,y:955,t:1527613713250};\\\", \\\"{x:1550,y:955,t:1527613713651};\\\", \\\"{x:1549,y:955,t:1527613713666};\\\", \\\"{x:1547,y:955,t:1527613713684};\\\", \\\"{x:1544,y:955,t:1527613713700};\\\", \\\"{x:1543,y:956,t:1527613713718};\\\", \\\"{x:1541,y:956,t:1527613728546};\\\", \\\"{x:1539,y:956,t:1527613728559};\\\", \\\"{x:1537,y:955,t:1527613728576};\\\", \\\"{x:1533,y:946,t:1527613728593};\\\", \\\"{x:1512,y:898,t:1527613728610};\\\", \\\"{x:1504,y:886,t:1527613728626};\\\", \\\"{x:1499,y:879,t:1527613728643};\\\", \\\"{x:1497,y:876,t:1527613728660};\\\", \\\"{x:1496,y:875,t:1527613728676};\\\", \\\"{x:1496,y:874,t:1527613728707};\\\", \\\"{x:1496,y:873,t:1527613728714};\\\", \\\"{x:1496,y:871,t:1527613728726};\\\", \\\"{x:1494,y:865,t:1527613728743};\\\", \\\"{x:1489,y:859,t:1527613728761};\\\", \\\"{x:1485,y:853,t:1527613728776};\\\", \\\"{x:1479,y:848,t:1527613728793};\\\", \\\"{x:1472,y:842,t:1527613728810};\\\", \\\"{x:1470,y:840,t:1527613728826};\\\", \\\"{x:1467,y:839,t:1527613728843};\\\", \\\"{x:1467,y:838,t:1527613728860};\\\", \\\"{x:1465,y:837,t:1527613728876};\\\", \\\"{x:1462,y:835,t:1527613728893};\\\", \\\"{x:1459,y:833,t:1527613728910};\\\", \\\"{x:1456,y:832,t:1527613728926};\\\", \\\"{x:1454,y:831,t:1527613728943};\\\", \\\"{x:1453,y:830,t:1527613728970};\\\", \\\"{x:1452,y:829,t:1527613728987};\\\", \\\"{x:1451,y:829,t:1527613728994};\\\", \\\"{x:1450,y:828,t:1527613729010};\\\", \\\"{x:1447,y:827,t:1527613729026};\\\", \\\"{x:1444,y:827,t:1527613729043};\\\", \\\"{x:1439,y:825,t:1527613729060};\\\", \\\"{x:1434,y:824,t:1527613729077};\\\", \\\"{x:1431,y:823,t:1527613729093};\\\", \\\"{x:1428,y:823,t:1527613729110};\\\", \\\"{x:1427,y:822,t:1527613729127};\\\", \\\"{x:1426,y:821,t:1527613729211};\\\", \\\"{x:1425,y:821,t:1527613729283};\\\", \\\"{x:1424,y:821,t:1527613729293};\\\", \\\"{x:1423,y:830,t:1527613729311};\\\", \\\"{x:1423,y:847,t:1527613729327};\\\", \\\"{x:1421,y:857,t:1527613729343};\\\", \\\"{x:1421,y:863,t:1527613729362};\\\", \\\"{x:1421,y:867,t:1527613729377};\\\", \\\"{x:1421,y:871,t:1527613729393};\\\", \\\"{x:1421,y:874,t:1527613729411};\\\", \\\"{x:1421,y:877,t:1527613729427};\\\", \\\"{x:1419,y:884,t:1527613729443};\\\", \\\"{x:1418,y:896,t:1527613729461};\\\", \\\"{x:1416,y:910,t:1527613729478};\\\", \\\"{x:1414,y:919,t:1527613729494};\\\", \\\"{x:1414,y:924,t:1527613729510};\\\", \\\"{x:1414,y:927,t:1527613729528};\\\", \\\"{x:1414,y:930,t:1527613729543};\\\", \\\"{x:1415,y:934,t:1527613729561};\\\", \\\"{x:1417,y:939,t:1527613729577};\\\", \\\"{x:1421,y:944,t:1527613729593};\\\", \\\"{x:1424,y:954,t:1527613729609};\\\", \\\"{x:1426,y:959,t:1527613729627};\\\", \\\"{x:1427,y:962,t:1527613729644};\\\", \\\"{x:1429,y:967,t:1527613729660};\\\", \\\"{x:1429,y:968,t:1527613729677};\\\", \\\"{x:1429,y:969,t:1527613729694};\\\", \\\"{x:1430,y:970,t:1527613729747};\\\", \\\"{x:1427,y:970,t:1527613729906};\\\", \\\"{x:1426,y:970,t:1527613729914};\\\", \\\"{x:1425,y:970,t:1527613729930};\\\", \\\"{x:1424,y:970,t:1527613729944};\\\", \\\"{x:1422,y:970,t:1527613729962};\\\", \\\"{x:1421,y:970,t:1527613729977};\\\", \\\"{x:1419,y:969,t:1527613729994};\\\", \\\"{x:1418,y:968,t:1527613730099};\\\", \\\"{x:1417,y:968,t:1527613730111};\\\", \\\"{x:1416,y:968,t:1527613730127};\\\", \\\"{x:1415,y:967,t:1527613730145};\\\", \\\"{x:1414,y:967,t:1527613730163};\\\", \\\"{x:1413,y:966,t:1527613730177};\\\", \\\"{x:1411,y:966,t:1527613730257};\\\", \\\"{x:1411,y:965,t:1527613730281};\\\", \\\"{x:1413,y:965,t:1527613730443};\\\", \\\"{x:1414,y:965,t:1527613730450};\\\", \\\"{x:1416,y:965,t:1527613730461};\\\", \\\"{x:1422,y:967,t:1527613730477};\\\", \\\"{x:1426,y:969,t:1527613730495};\\\", \\\"{x:1430,y:972,t:1527613730510};\\\", \\\"{x:1433,y:974,t:1527613730526};\\\", \\\"{x:1438,y:974,t:1527613730544};\\\", \\\"{x:1445,y:977,t:1527613730561};\\\", \\\"{x:1460,y:977,t:1527613730577};\\\", \\\"{x:1481,y:979,t:1527613730594};\\\", \\\"{x:1487,y:980,t:1527613730611};\\\", \\\"{x:1490,y:980,t:1527613730627};\\\", \\\"{x:1491,y:980,t:1527613730644};\\\", \\\"{x:1494,y:980,t:1527613730661};\\\", \\\"{x:1498,y:979,t:1527613730677};\\\", \\\"{x:1501,y:976,t:1527613730694};\\\", \\\"{x:1505,y:972,t:1527613730711};\\\", \\\"{x:1506,y:969,t:1527613730728};\\\", \\\"{x:1508,y:966,t:1527613730743};\\\", \\\"{x:1508,y:964,t:1527613730761};\\\", \\\"{x:1508,y:963,t:1527613730777};\\\", \\\"{x:1508,y:962,t:1527613730794};\\\", \\\"{x:1509,y:961,t:1527613730811};\\\", \\\"{x:1509,y:965,t:1527613730938};\\\", \\\"{x:1510,y:972,t:1527613730946};\\\", \\\"{x:1515,y:978,t:1527613730961};\\\", \\\"{x:1523,y:982,t:1527613730978};\\\", \\\"{x:1526,y:982,t:1527613730994};\\\", \\\"{x:1532,y:982,t:1527613731011};\\\", \\\"{x:1539,y:978,t:1527613731028};\\\", \\\"{x:1546,y:973,t:1527613731045};\\\", \\\"{x:1550,y:969,t:1527613731061};\\\", \\\"{x:1554,y:966,t:1527613731078};\\\", \\\"{x:1555,y:964,t:1527613731094};\\\", \\\"{x:1557,y:959,t:1527613731111};\\\", \\\"{x:1559,y:953,t:1527613731128};\\\", \\\"{x:1559,y:951,t:1527613731144};\\\", \\\"{x:1560,y:950,t:1527613731161};\\\", \\\"{x:1560,y:949,t:1527613731177};\\\", \\\"{x:1557,y:947,t:1527613731265};\\\", \\\"{x:1546,y:944,t:1527613731278};\\\", \\\"{x:1517,y:935,t:1527613731293};\\\", \\\"{x:1461,y:919,t:1527613731311};\\\", \\\"{x:1374,y:888,t:1527613731328};\\\", \\\"{x:1289,y:849,t:1527613731345};\\\", \\\"{x:1225,y:809,t:1527613731361};\\\", \\\"{x:1169,y:760,t:1527613731378};\\\", \\\"{x:1123,y:728,t:1527613731395};\\\", \\\"{x:1073,y:693,t:1527613731411};\\\", \\\"{x:1001,y:647,t:1527613731428};\\\", \\\"{x:937,y:615,t:1527613731446};\\\", \\\"{x:886,y:591,t:1527613731461};\\\", \\\"{x:854,y:575,t:1527613731477};\\\", \\\"{x:821,y:558,t:1527613731498};\\\", \\\"{x:810,y:552,t:1527613731516};\\\", \\\"{x:808,y:551,t:1527613731531};\\\", \\\"{x:804,y:551,t:1527613731549};\\\", \\\"{x:795,y:551,t:1527613731564};\\\", \\\"{x:769,y:551,t:1527613731582};\\\", \\\"{x:746,y:551,t:1527613731599};\\\", \\\"{x:729,y:551,t:1527613731616};\\\", \\\"{x:723,y:551,t:1527613731632};\\\", \\\"{x:719,y:553,t:1527613731648};\\\", \\\"{x:717,y:554,t:1527613731666};\\\", \\\"{x:716,y:555,t:1527613731682};\\\", \\\"{x:715,y:555,t:1527613731698};\\\", \\\"{x:713,y:557,t:1527613731715};\\\", \\\"{x:711,y:558,t:1527613731732};\\\", \\\"{x:709,y:560,t:1527613731748};\\\", \\\"{x:708,y:561,t:1527613731766};\\\", \\\"{x:707,y:564,t:1527613731782};\\\", \\\"{x:705,y:567,t:1527613731798};\\\", \\\"{x:701,y:570,t:1527613731815};\\\", \\\"{x:699,y:572,t:1527613731831};\\\", \\\"{x:699,y:574,t:1527613731848};\\\", \\\"{x:699,y:575,t:1527613731882};\\\", \\\"{x:697,y:578,t:1527613732371};\\\", \\\"{x:692,y:584,t:1527613732384};\\\", \\\"{x:680,y:597,t:1527613732401};\\\", \\\"{x:662,y:609,t:1527613732417};\\\", \\\"{x:642,y:618,t:1527613732433};\\\", \\\"{x:626,y:624,t:1527613732449};\\\", \\\"{x:609,y:627,t:1527613732466};\\\", \\\"{x:596,y:630,t:1527613732482};\\\", \\\"{x:577,y:630,t:1527613732498};\\\", \\\"{x:566,y:630,t:1527613732516};\\\", \\\"{x:559,y:630,t:1527613732533};\\\", \\\"{x:556,y:630,t:1527613732549};\\\", \\\"{x:553,y:630,t:1527613732602};\\\", \\\"{x:543,y:630,t:1527613732616};\\\", \\\"{x:513,y:630,t:1527613732633};\\\", \\\"{x:486,y:630,t:1527613732648};\\\", \\\"{x:462,y:628,t:1527613732666};\\\", \\\"{x:456,y:625,t:1527613732683};\\\", \\\"{x:452,y:625,t:1527613732699};\\\", \\\"{x:447,y:625,t:1527613732716};\\\", \\\"{x:440,y:623,t:1527613732732};\\\", \\\"{x:428,y:618,t:1527613732749};\\\", \\\"{x:411,y:615,t:1527613732766};\\\", \\\"{x:400,y:610,t:1527613732782};\\\", \\\"{x:396,y:607,t:1527613732799};\\\", \\\"{x:396,y:601,t:1527613732825};\\\", \\\"{x:396,y:597,t:1527613732834};\\\", \\\"{x:398,y:595,t:1527613732849};\\\", \\\"{x:402,y:588,t:1527613732866};\\\", \\\"{x:406,y:583,t:1527613732883};\\\", \\\"{x:406,y:582,t:1527613732900};\\\", \\\"{x:407,y:581,t:1527613732916};\\\", \\\"{x:407,y:578,t:1527613732932};\\\", \\\"{x:408,y:576,t:1527613732950};\\\", \\\"{x:408,y:575,t:1527613732977};\\\", \\\"{x:408,y:574,t:1527613732993};\\\", \\\"{x:408,y:573,t:1527613733010};\\\", \\\"{x:407,y:572,t:1527613733042};\\\", \\\"{x:405,y:571,t:1527613733058};\\\", \\\"{x:404,y:571,t:1527613733114};\\\", \\\"{x:403,y:570,t:1527613733730};\\\", \\\"{x:416,y:570,t:1527613733746};\\\", \\\"{x:460,y:577,t:1527613733755};\\\", \\\"{x:512,y:593,t:1527613733768};\\\", \\\"{x:641,y:642,t:1527613733784};\\\", \\\"{x:811,y:708,t:1527613733800};\\\", \\\"{x:993,y:791,t:1527613733817};\\\", \\\"{x:1320,y:945,t:1527613733833};\\\", \\\"{x:1505,y:1021,t:1527613733849};\\\", \\\"{x:1588,y:1058,t:1527613733867};\\\", \\\"{x:1605,y:1065,t:1527613733884};\\\", \\\"{x:1609,y:1066,t:1527613733900};\\\", \\\"{x:1612,y:1066,t:1527613733916};\\\", \\\"{x:1611,y:1065,t:1527613734034};\\\", \\\"{x:1607,y:1064,t:1527613734050};\\\", \\\"{x:1595,y:1055,t:1527613734067};\\\", \\\"{x:1577,y:1039,t:1527613734084};\\\", \\\"{x:1553,y:1018,t:1527613734099};\\\", \\\"{x:1524,y:999,t:1527613734117};\\\", \\\"{x:1502,y:983,t:1527613734134};\\\", \\\"{x:1483,y:972,t:1527613734150};\\\", \\\"{x:1465,y:965,t:1527613734167};\\\", \\\"{x:1438,y:954,t:1527613734184};\\\", \\\"{x:1420,y:946,t:1527613734200};\\\", \\\"{x:1402,y:944,t:1527613734217};\\\", \\\"{x:1374,y:944,t:1527613734234};\\\", \\\"{x:1351,y:944,t:1527613734251};\\\", \\\"{x:1337,y:944,t:1527613734267};\\\", \\\"{x:1332,y:944,t:1527613734284};\\\", \\\"{x:1331,y:944,t:1527613734301};\\\", \\\"{x:1331,y:946,t:1527613735018};\\\", \\\"{x:1331,y:947,t:1527613735034};\\\", \\\"{x:1332,y:948,t:1527613735051};\\\", \\\"{x:1332,y:949,t:1527613735074};\\\", \\\"{x:1333,y:949,t:1527613735090};\\\", \\\"{x:1333,y:950,t:1527613735106};\\\", \\\"{x:1333,y:952,t:1527613735138};\\\", \\\"{x:1333,y:953,t:1527613735177};\\\", \\\"{x:1333,y:954,t:1527613735201};\\\", \\\"{x:1333,y:955,t:1527613735217};\\\", \\\"{x:1332,y:955,t:1527613735257};\\\", \\\"{x:1332,y:956,t:1527613735370};\\\", \\\"{x:1331,y:956,t:1527613735586};\\\", \\\"{x:1326,y:954,t:1527613735602};\\\", \\\"{x:1322,y:942,t:1527613735618};\\\", \\\"{x:1311,y:924,t:1527613735635};\\\", \\\"{x:1305,y:916,t:1527613735651};\\\", \\\"{x:1304,y:915,t:1527613735668};\\\", \\\"{x:1304,y:914,t:1527613735685};\\\", \\\"{x:1304,y:913,t:1527613735705};\\\", \\\"{x:1304,y:912,t:1527613735769};\\\", \\\"{x:1304,y:911,t:1527613735923};\\\", \\\"{x:1304,y:910,t:1527613735979};\\\", \\\"{x:1305,y:910,t:1527613735986};\\\", \\\"{x:1305,y:909,t:1527613736002};\\\", \\\"{x:1307,y:909,t:1527613736018};\\\", \\\"{x:1308,y:909,t:1527613736042};\\\", \\\"{x:1308,y:908,t:1527613736052};\\\", \\\"{x:1310,y:908,t:1527613736068};\\\", \\\"{x:1313,y:907,t:1527613736085};\\\", \\\"{x:1315,y:906,t:1527613736102};\\\", \\\"{x:1320,y:905,t:1527613736118};\\\", \\\"{x:1323,y:905,t:1527613736135};\\\", \\\"{x:1326,y:904,t:1527613736152};\\\", \\\"{x:1328,y:903,t:1527613736168};\\\", \\\"{x:1331,y:902,t:1527613736185};\\\", \\\"{x:1336,y:902,t:1527613736201};\\\", \\\"{x:1338,y:902,t:1527613736218};\\\", \\\"{x:1341,y:902,t:1527613736235};\\\", \\\"{x:1345,y:901,t:1527613736252};\\\", \\\"{x:1346,y:901,t:1527613736268};\\\", \\\"{x:1348,y:899,t:1527613736285};\\\", \\\"{x:1349,y:899,t:1527613736314};\\\", \\\"{x:1349,y:898,t:1527613736355};\\\", \\\"{x:1349,y:897,t:1527613736369};\\\", \\\"{x:1349,y:896,t:1527613736384};\\\", \\\"{x:1349,y:895,t:1527613736401};\\\", \\\"{x:1349,y:894,t:1527613736449};\\\", \\\"{x:1350,y:894,t:1527613739818};\\\", \\\"{x:1351,y:894,t:1527613739907};\\\", \\\"{x:1352,y:894,t:1527613739945};\\\", \\\"{x:1353,y:894,t:1527613740074};\\\", \\\"{x:1354,y:894,t:1527613740089};\\\", \\\"{x:1355,y:894,t:1527613740105};\\\", \\\"{x:1355,y:895,t:1527613740162};\\\", \\\"{x:1356,y:895,t:1527613740266};\\\", \\\"{x:1357,y:896,t:1527613740451};\\\", \\\"{x:1358,y:896,t:1527613741274};\\\", \\\"{x:1359,y:896,t:1527613741289};\\\", \\\"{x:1363,y:897,t:1527613741307};\\\", \\\"{x:1364,y:899,t:1527613741338};\\\", \\\"{x:1365,y:899,t:1527613741355};\\\", \\\"{x:1366,y:900,t:1527613741394};\\\", \\\"{x:1368,y:900,t:1527613741442};\\\", \\\"{x:1369,y:902,t:1527613741466};\\\", \\\"{x:1369,y:903,t:1527613741474};\\\", \\\"{x:1370,y:907,t:1527613741490};\\\", \\\"{x:1370,y:909,t:1527613741506};\\\", \\\"{x:1370,y:911,t:1527613741523};\\\", \\\"{x:1371,y:912,t:1527613741540};\\\", \\\"{x:1371,y:915,t:1527613741555};\\\", \\\"{x:1371,y:917,t:1527613741573};\\\", \\\"{x:1372,y:920,t:1527613741590};\\\", \\\"{x:1372,y:922,t:1527613741605};\\\", \\\"{x:1373,y:926,t:1527613741623};\\\", \\\"{x:1373,y:930,t:1527613741640};\\\", \\\"{x:1373,y:935,t:1527613741655};\\\", \\\"{x:1373,y:937,t:1527613741673};\\\", \\\"{x:1373,y:940,t:1527613741690};\\\", \\\"{x:1373,y:942,t:1527613741706};\\\", \\\"{x:1373,y:943,t:1527613741723};\\\", \\\"{x:1373,y:944,t:1527613741739};\\\", \\\"{x:1373,y:946,t:1527613741756};\\\", \\\"{x:1373,y:947,t:1527613741773};\\\", \\\"{x:1373,y:948,t:1527613741789};\\\", \\\"{x:1373,y:949,t:1527613741806};\\\", \\\"{x:1373,y:951,t:1527613741822};\\\", \\\"{x:1373,y:952,t:1527613741839};\\\", \\\"{x:1373,y:953,t:1527613741882};\\\", \\\"{x:1372,y:953,t:1527613742043};\\\", \\\"{x:1369,y:952,t:1527613742057};\\\", \\\"{x:1368,y:948,t:1527613742072};\\\", \\\"{x:1365,y:939,t:1527613742090};\\\", \\\"{x:1361,y:931,t:1527613742106};\\\", \\\"{x:1356,y:920,t:1527613742123};\\\", \\\"{x:1351,y:907,t:1527613742139};\\\", \\\"{x:1347,y:895,t:1527613742157};\\\", \\\"{x:1346,y:888,t:1527613742173};\\\", \\\"{x:1343,y:882,t:1527613742190};\\\", \\\"{x:1342,y:877,t:1527613742207};\\\", \\\"{x:1341,y:875,t:1527613742223};\\\", \\\"{x:1339,y:872,t:1527613742240};\\\", \\\"{x:1338,y:869,t:1527613742257};\\\", \\\"{x:1336,y:867,t:1527613742273};\\\", \\\"{x:1335,y:866,t:1527613742290};\\\", \\\"{x:1332,y:864,t:1527613742307};\\\", \\\"{x:1330,y:862,t:1527613742323};\\\", \\\"{x:1325,y:859,t:1527613742340};\\\", \\\"{x:1322,y:858,t:1527613742357};\\\", \\\"{x:1314,y:855,t:1527613742372};\\\", \\\"{x:1309,y:853,t:1527613742389};\\\", \\\"{x:1306,y:852,t:1527613742406};\\\", \\\"{x:1302,y:851,t:1527613742422};\\\", \\\"{x:1301,y:850,t:1527613742449};\\\", \\\"{x:1300,y:850,t:1527613742562};\\\", \\\"{x:1300,y:849,t:1527613742578};\\\", \\\"{x:1298,y:849,t:1527613742594};\\\", \\\"{x:1298,y:848,t:1527613742606};\\\", \\\"{x:1296,y:847,t:1527613742623};\\\", \\\"{x:1294,y:845,t:1527613742639};\\\", \\\"{x:1293,y:844,t:1527613742657};\\\", \\\"{x:1290,y:842,t:1527613742673};\\\", \\\"{x:1286,y:840,t:1527613742690};\\\", \\\"{x:1282,y:838,t:1527613742707};\\\", \\\"{x:1279,y:836,t:1527613742723};\\\", \\\"{x:1278,y:836,t:1527613742740};\\\", \\\"{x:1278,y:835,t:1527613742866};\\\", \\\"{x:1278,y:834,t:1527613745825};\\\", \\\"{x:1279,y:834,t:1527613745841};\\\", \\\"{x:1281,y:834,t:1527613745858};\\\", \\\"{x:1283,y:834,t:1527613745875};\\\", \\\"{x:1284,y:834,t:1527613745891};\\\", \\\"{x:1285,y:834,t:1527613745921};\\\", \\\"{x:1286,y:834,t:1527613745938};\\\", \\\"{x:1287,y:834,t:1527613745946};\\\", \\\"{x:1288,y:834,t:1527613745961};\\\", \\\"{x:1290,y:834,t:1527613745975};\\\", \\\"{x:1291,y:833,t:1527613745992};\\\", \\\"{x:1293,y:833,t:1527613746009};\\\", \\\"{x:1294,y:833,t:1527613746026};\\\", \\\"{x:1295,y:833,t:1527613746041};\\\", \\\"{x:1296,y:833,t:1527613746066};\\\", \\\"{x:1297,y:833,t:1527613746082};\\\", \\\"{x:1299,y:833,t:1527613746106};\\\", \\\"{x:1300,y:833,t:1527613746122};\\\", \\\"{x:1302,y:833,t:1527613746130};\\\", \\\"{x:1303,y:833,t:1527613746142};\\\", \\\"{x:1306,y:831,t:1527613746159};\\\", \\\"{x:1307,y:831,t:1527613746175};\\\", \\\"{x:1309,y:831,t:1527613746193};\\\", \\\"{x:1311,y:831,t:1527613746208};\\\", \\\"{x:1314,y:831,t:1527613746225};\\\", \\\"{x:1317,y:831,t:1527613746243};\\\", \\\"{x:1319,y:831,t:1527613746258};\\\", \\\"{x:1321,y:831,t:1527613746276};\\\", \\\"{x:1322,y:831,t:1527613746293};\\\", \\\"{x:1323,y:831,t:1527613746309};\\\", \\\"{x:1324,y:831,t:1527613746401};\\\", \\\"{x:1325,y:831,t:1527613746425};\\\", \\\"{x:1327,y:830,t:1527613746442};\\\", \\\"{x:1328,y:830,t:1527613746458};\\\", \\\"{x:1329,y:830,t:1527613746475};\\\", \\\"{x:1330,y:830,t:1527613746513};\\\", \\\"{x:1331,y:830,t:1527613746561};\\\", \\\"{x:1332,y:830,t:1527613746578};\\\", \\\"{x:1333,y:830,t:1527613746633};\\\", \\\"{x:1334,y:830,t:1527613746683};\\\", \\\"{x:1335,y:830,t:1527613746714};\\\", \\\"{x:1336,y:830,t:1527613746778};\\\", \\\"{x:1337,y:830,t:1527613746818};\\\", \\\"{x:1338,y:830,t:1527613746834};\\\", \\\"{x:1339,y:830,t:1527613746906};\\\", \\\"{x:1340,y:830,t:1527613746930};\\\", \\\"{x:1341,y:830,t:1527613746943};\\\", \\\"{x:1343,y:830,t:1527613746962};\\\", \\\"{x:1344,y:830,t:1527613746976};\\\", \\\"{x:1345,y:830,t:1527613746994};\\\", \\\"{x:1346,y:830,t:1527613747010};\\\", \\\"{x:1347,y:830,t:1527613747067};\\\", \\\"{x:1342,y:830,t:1527613747811};\\\", \\\"{x:1269,y:836,t:1527613747827};\\\", \\\"{x:1265,y:838,t:1527613748146};\\\", \\\"{x:1258,y:838,t:1527613748163};\\\", \\\"{x:1254,y:838,t:1527613748176};\\\", \\\"{x:1239,y:838,t:1527613748193};\\\", \\\"{x:1229,y:838,t:1527613748210};\\\", \\\"{x:1225,y:838,t:1527613748226};\\\", \\\"{x:1223,y:838,t:1527613748243};\\\", \\\"{x:1222,y:838,t:1527613748297};\\\", \\\"{x:1219,y:839,t:1527613748310};\\\", \\\"{x:1215,y:840,t:1527613748327};\\\", \\\"{x:1214,y:840,t:1527613748343};\\\", \\\"{x:1214,y:838,t:1527613748514};\\\", \\\"{x:1214,y:837,t:1527613748562};\\\", \\\"{x:1214,y:836,t:1527613748578};\\\", \\\"{x:1214,y:835,t:1527613748594};\\\", \\\"{x:1214,y:834,t:1527613748627};\\\", \\\"{x:1215,y:834,t:1527613748643};\\\", \\\"{x:1215,y:833,t:1527613748682};\\\", \\\"{x:1215,y:832,t:1527613748698};\\\", \\\"{x:1215,y:831,t:1527613748729};\\\", \\\"{x:1215,y:830,t:1527613748743};\\\", \\\"{x:1215,y:829,t:1527613748761};\\\", \\\"{x:1216,y:827,t:1527613748786};\\\", \\\"{x:1217,y:826,t:1527613749547};\\\", \\\"{x:1218,y:826,t:1527613749778};\\\", \\\"{x:1220,y:826,t:1527613749835};\\\", \\\"{x:1221,y:826,t:1527613749890};\\\", \\\"{x:1224,y:826,t:1527613749898};\\\", \\\"{x:1229,y:826,t:1527613749912};\\\", \\\"{x:1240,y:826,t:1527613749928};\\\", \\\"{x:1251,y:826,t:1527613749945};\\\", \\\"{x:1270,y:826,t:1527613749962};\\\", \\\"{x:1277,y:826,t:1527613749978};\\\", \\\"{x:1280,y:826,t:1527613749995};\\\", \\\"{x:1282,y:826,t:1527613750011};\\\", \\\"{x:1283,y:826,t:1527613750028};\\\", \\\"{x:1286,y:825,t:1527613750046};\\\", \\\"{x:1287,y:825,t:1527613750062};\\\", \\\"{x:1289,y:825,t:1527613750078};\\\", \\\"{x:1292,y:825,t:1527613750095};\\\", \\\"{x:1295,y:825,t:1527613750111};\\\", \\\"{x:1297,y:825,t:1527613750127};\\\", \\\"{x:1299,y:825,t:1527613750145};\\\", \\\"{x:1301,y:825,t:1527613750163};\\\", \\\"{x:1302,y:824,t:1527613750178};\\\", \\\"{x:1308,y:814,t:1527613750426};\\\", \\\"{x:1311,y:804,t:1527613750434};\\\", \\\"{x:1314,y:796,t:1527613750445};\\\", \\\"{x:1322,y:783,t:1527613750462};\\\", \\\"{x:1328,y:765,t:1527613750479};\\\", \\\"{x:1329,y:745,t:1527613750495};\\\", \\\"{x:1330,y:731,t:1527613750512};\\\", \\\"{x:1330,y:722,t:1527613750529};\\\", \\\"{x:1330,y:702,t:1527613750546};\\\", \\\"{x:1330,y:678,t:1527613750561};\\\", \\\"{x:1329,y:674,t:1527613750579};\\\", \\\"{x:1329,y:672,t:1527613750594};\\\", \\\"{x:1328,y:671,t:1527613750612};\\\", \\\"{x:1327,y:669,t:1527613750650};\\\", \\\"{x:1327,y:668,t:1527613750745};\\\", \\\"{x:1327,y:666,t:1527613750769};\\\", \\\"{x:1327,y:665,t:1527613750785};\\\", \\\"{x:1327,y:664,t:1527613750801};\\\", \\\"{x:1327,y:663,t:1527613750811};\\\", \\\"{x:1327,y:662,t:1527613750833};\\\", \\\"{x:1326,y:661,t:1527613750849};\\\", \\\"{x:1325,y:660,t:1527613750862};\\\", \\\"{x:1325,y:659,t:1527613750878};\\\", \\\"{x:1324,y:656,t:1527613750896};\\\", \\\"{x:1323,y:654,t:1527613750911};\\\", \\\"{x:1322,y:651,t:1527613750928};\\\", \\\"{x:1320,y:646,t:1527613750946};\\\", \\\"{x:1318,y:642,t:1527613750962};\\\", \\\"{x:1317,y:639,t:1527613750978};\\\", \\\"{x:1316,y:638,t:1527613750996};\\\", \\\"{x:1316,y:636,t:1527613751011};\\\", \\\"{x:1315,y:634,t:1527613751030};\\\", \\\"{x:1315,y:633,t:1527613751046};\\\", \\\"{x:1314,y:632,t:1527613751062};\\\", \\\"{x:1316,y:632,t:1527613753026};\\\", \\\"{x:1318,y:632,t:1527613753033};\\\", \\\"{x:1321,y:632,t:1527613753048};\\\", \\\"{x:1325,y:632,t:1527613753064};\\\", \\\"{x:1328,y:632,t:1527613753080};\\\", \\\"{x:1329,y:632,t:1527613753097};\\\", \\\"{x:1331,y:632,t:1527613753122};\\\", \\\"{x:1332,y:632,t:1527613753154};\\\", \\\"{x:1335,y:631,t:1527613753164};\\\", \\\"{x:1340,y:630,t:1527613753180};\\\", \\\"{x:1349,y:628,t:1527613753198};\\\", \\\"{x:1354,y:628,t:1527613753214};\\\", \\\"{x:1358,y:627,t:1527613753230};\\\", \\\"{x:1360,y:627,t:1527613753247};\\\", \\\"{x:1361,y:627,t:1527613753264};\\\", \\\"{x:1362,y:627,t:1527613753281};\\\", \\\"{x:1364,y:626,t:1527613753297};\\\", \\\"{x:1365,y:626,t:1527613753314};\\\", \\\"{x:1368,y:626,t:1527613753331};\\\", \\\"{x:1370,y:625,t:1527613753347};\\\", \\\"{x:1373,y:625,t:1527613753364};\\\", \\\"{x:1375,y:625,t:1527613753380};\\\", \\\"{x:1378,y:624,t:1527613753397};\\\", \\\"{x:1380,y:624,t:1527613753414};\\\", \\\"{x:1383,y:624,t:1527613753430};\\\", \\\"{x:1384,y:624,t:1527613753447};\\\", \\\"{x:1385,y:624,t:1527613753463};\\\", \\\"{x:1386,y:624,t:1527613754386};\\\", \\\"{x:1388,y:624,t:1527613754398};\\\", \\\"{x:1408,y:624,t:1527613754415};\\\", \\\"{x:1435,y:624,t:1527613754431};\\\", \\\"{x:1453,y:624,t:1527613754448};\\\", \\\"{x:1477,y:625,t:1527613754465};\\\", \\\"{x:1478,y:626,t:1527613754481};\\\", \\\"{x:1479,y:626,t:1527613754498};\\\", \\\"{x:1478,y:627,t:1527613754842};\\\", \\\"{x:1477,y:627,t:1527613754850};\\\", \\\"{x:1475,y:627,t:1527613754865};\\\", \\\"{x:1472,y:628,t:1527613754882};\\\", \\\"{x:1469,y:628,t:1527613754898};\\\", \\\"{x:1468,y:628,t:1527613754915};\\\", \\\"{x:1467,y:628,t:1527613754932};\\\", \\\"{x:1465,y:628,t:1527613754970};\\\", \\\"{x:1463,y:628,t:1527613754982};\\\", \\\"{x:1459,y:628,t:1527613754998};\\\", \\\"{x:1456,y:628,t:1527613755015};\\\", \\\"{x:1454,y:628,t:1527613755032};\\\", \\\"{x:1453,y:628,t:1527613755058};\\\", \\\"{x:1451,y:628,t:1527613755090};\\\", \\\"{x:1450,y:628,t:1527613755113};\\\", \\\"{x:1448,y:628,t:1527613755132};\\\", \\\"{x:1447,y:628,t:1527613755149};\\\", \\\"{x:1445,y:628,t:1527613755165};\\\", \\\"{x:1446,y:628,t:1527613758685};\\\", \\\"{x:1447,y:629,t:1527613758748};\\\", \\\"{x:1448,y:629,t:1527613758932};\\\", \\\"{x:1449,y:629,t:1527613758980};\\\", \\\"{x:1450,y:630,t:1527613758994};\\\", \\\"{x:1451,y:630,t:1527613759019};\\\", \\\"{x:1453,y:631,t:1527613759028};\\\", \\\"{x:1454,y:631,t:1527613759044};\\\", \\\"{x:1456,y:632,t:1527613759061};\\\", \\\"{x:1457,y:632,t:1527613759078};\\\", \\\"{x:1459,y:633,t:1527613759094};\\\", \\\"{x:1460,y:633,t:1527613759132};\\\", \\\"{x:1462,y:633,t:1527613759180};\\\", \\\"{x:1463,y:633,t:1527613759252};\\\", \\\"{x:1464,y:634,t:1527613759284};\\\", \\\"{x:1465,y:634,t:1527613759300};\\\", \\\"{x:1466,y:634,t:1527613759372};\\\", \\\"{x:1468,y:634,t:1527613759428};\\\", \\\"{x:1469,y:634,t:1527613759460};\\\", \\\"{x:1471,y:634,t:1527613759491};\\\", \\\"{x:1472,y:634,t:1527613759500};\\\", \\\"{x:1476,y:634,t:1527613759511};\\\", \\\"{x:1483,y:634,t:1527613759528};\\\", \\\"{x:1489,y:634,t:1527613759544};\\\", \\\"{x:1492,y:634,t:1527613759561};\\\", \\\"{x:1493,y:634,t:1527613759578};\\\", \\\"{x:1491,y:634,t:1527613759788};\\\", \\\"{x:1490,y:634,t:1527613759812};\\\", \\\"{x:1489,y:634,t:1527613759836};\\\", \\\"{x:1488,y:634,t:1527613759845};\\\", \\\"{x:1487,y:634,t:1527613759861};\\\", \\\"{x:1485,y:633,t:1527613759878};\\\", \\\"{x:1484,y:632,t:1527613759896};\\\", \\\"{x:1480,y:631,t:1527613759916};\\\", \\\"{x:1477,y:630,t:1527613759929};\\\", \\\"{x:1476,y:630,t:1527613759945};\\\", \\\"{x:1474,y:629,t:1527613759961};\\\", \\\"{x:1473,y:628,t:1527613759978};\\\", \\\"{x:1460,y:628,t:1527613759995};\\\", \\\"{x:1440,y:629,t:1527613760010};\\\", \\\"{x:1419,y:636,t:1527613760028};\\\", \\\"{x:1399,y:640,t:1527613760044};\\\", \\\"{x:1366,y:645,t:1527613760061};\\\", \\\"{x:1346,y:647,t:1527613760077};\\\", \\\"{x:1326,y:649,t:1527613760095};\\\", \\\"{x:1312,y:651,t:1527613760111};\\\", \\\"{x:1302,y:653,t:1527613760128};\\\", \\\"{x:1299,y:653,t:1527613760145};\\\", \\\"{x:1298,y:653,t:1527613760316};\\\", \\\"{x:1297,y:653,t:1527613760328};\\\", \\\"{x:1296,y:653,t:1527613760345};\\\", \\\"{x:1292,y:653,t:1527613760362};\\\", \\\"{x:1286,y:650,t:1527613760378};\\\", \\\"{x:1282,y:647,t:1527613760396};\\\", \\\"{x:1281,y:647,t:1527613760412};\\\", \\\"{x:1280,y:646,t:1527613760477};\\\", \\\"{x:1280,y:645,t:1527613760499};\\\", \\\"{x:1280,y:644,t:1527613760513};\\\", \\\"{x:1280,y:643,t:1527613760531};\\\", \\\"{x:1280,y:642,t:1527613760546};\\\", \\\"{x:1280,y:641,t:1527613760563};\\\", \\\"{x:1281,y:638,t:1527613760578};\\\", \\\"{x:1283,y:637,t:1527613760596};\\\", \\\"{x:1283,y:636,t:1527613760612};\\\", \\\"{x:1283,y:635,t:1527613760629};\\\", \\\"{x:1284,y:634,t:1527613760645};\\\", \\\"{x:1286,y:634,t:1527613760662};\\\", \\\"{x:1289,y:634,t:1527613760679};\\\", \\\"{x:1290,y:634,t:1527613760696};\\\", \\\"{x:1293,y:634,t:1527613760712};\\\", \\\"{x:1295,y:634,t:1527613760729};\\\", \\\"{x:1298,y:634,t:1527613760746};\\\", \\\"{x:1300,y:634,t:1527613760761};\\\", \\\"{x:1301,y:634,t:1527613760779};\\\", \\\"{x:1303,y:634,t:1527613760827};\\\", \\\"{x:1304,y:634,t:1527613760883};\\\", \\\"{x:1306,y:634,t:1527613760979};\\\", \\\"{x:1311,y:633,t:1527613760995};\\\", \\\"{x:1314,y:630,t:1527613761012};\\\", \\\"{x:1315,y:628,t:1527613761028};\\\", \\\"{x:1317,y:626,t:1527613761045};\\\", \\\"{x:1318,y:625,t:1527613761468};\\\", \\\"{x:1320,y:625,t:1527613761480};\\\", \\\"{x:1321,y:625,t:1527613761496};\\\", \\\"{x:1322,y:625,t:1527613761512};\\\", \\\"{x:1324,y:626,t:1527613761529};\\\", \\\"{x:1325,y:626,t:1527613761546};\\\", \\\"{x:1326,y:627,t:1527613761562};\\\", \\\"{x:1327,y:627,t:1527613761579};\\\", \\\"{x:1328,y:628,t:1527613761596};\\\", \\\"{x:1330,y:629,t:1527613761612};\\\", \\\"{x:1331,y:629,t:1527613761629};\\\", \\\"{x:1334,y:631,t:1527613761646};\\\", \\\"{x:1335,y:631,t:1527613761663};\\\", \\\"{x:1336,y:631,t:1527613761679};\\\", \\\"{x:1337,y:632,t:1527613761740};\\\", \\\"{x:1338,y:632,t:1527613761884};\\\", \\\"{x:1340,y:632,t:1527613761896};\\\", \\\"{x:1341,y:632,t:1527613761914};\\\", \\\"{x:1344,y:632,t:1527613761929};\\\", \\\"{x:1350,y:632,t:1527613761947};\\\", \\\"{x:1352,y:632,t:1527613761964};\\\", \\\"{x:1353,y:632,t:1527613762028};\\\", \\\"{x:1354,y:632,t:1527613762148};\\\", \\\"{x:1355,y:632,t:1527613762324};\\\", \\\"{x:1356,y:631,t:1527613762331};\\\", \\\"{x:1356,y:630,t:1527613762348};\\\", \\\"{x:1358,y:630,t:1527613762364};\\\", \\\"{x:1359,y:629,t:1527613762380};\\\", \\\"{x:1360,y:628,t:1527613762636};\\\", \\\"{x:1361,y:627,t:1527613762668};\\\", \\\"{x:1362,y:627,t:1527613762683};\\\", \\\"{x:1363,y:627,t:1527613762780};\\\", \\\"{x:1364,y:627,t:1527613762798};\\\", \\\"{x:1365,y:627,t:1527613762813};\\\", \\\"{x:1366,y:627,t:1527613762831};\\\", \\\"{x:1367,y:627,t:1527613762848};\\\", \\\"{x:1369,y:627,t:1527613762863};\\\", \\\"{x:1370,y:627,t:1527613762880};\\\", \\\"{x:1372,y:627,t:1527613762898};\\\", \\\"{x:1374,y:628,t:1527613762914};\\\", \\\"{x:1375,y:628,t:1527613762932};\\\", \\\"{x:1376,y:628,t:1527613762980};\\\", \\\"{x:1378,y:628,t:1527613763012};\\\", \\\"{x:1379,y:628,t:1527613763044};\\\", \\\"{x:1381,y:628,t:1527613763068};\\\", \\\"{x:1382,y:628,t:1527613763108};\\\", \\\"{x:1384,y:628,t:1527613763124};\\\", \\\"{x:1385,y:628,t:1527613763181};\\\", \\\"{x:1387,y:628,t:1527613763620};\\\", \\\"{x:1388,y:628,t:1527613763631};\\\", \\\"{x:1392,y:628,t:1527613763647};\\\", \\\"{x:1393,y:628,t:1527613763664};\\\", \\\"{x:1395,y:628,t:1527613763681};\\\", \\\"{x:1397,y:628,t:1527613763697};\\\", \\\"{x:1399,y:628,t:1527613763715};\\\", \\\"{x:1400,y:628,t:1527613763730};\\\", \\\"{x:1404,y:628,t:1527613763747};\\\", \\\"{x:1405,y:628,t:1527613763764};\\\", \\\"{x:1407,y:628,t:1527613763781};\\\", \\\"{x:1410,y:628,t:1527613763797};\\\", \\\"{x:1412,y:628,t:1527613763815};\\\", \\\"{x:1417,y:628,t:1527613763832};\\\", \\\"{x:1420,y:628,t:1527613763847};\\\", \\\"{x:1429,y:628,t:1527613763864};\\\", \\\"{x:1432,y:628,t:1527613763882};\\\", \\\"{x:1436,y:628,t:1527613763898};\\\", \\\"{x:1437,y:628,t:1527613763924};\\\", \\\"{x:1438,y:628,t:1527613763932};\\\", \\\"{x:1439,y:628,t:1527613763964};\\\", \\\"{x:1440,y:628,t:1527613764116};\\\", \\\"{x:1443,y:628,t:1527613764131};\\\", \\\"{x:1445,y:627,t:1527613764147};\\\", \\\"{x:1446,y:627,t:1527613764164};\\\", \\\"{x:1448,y:627,t:1527613764182};\\\", \\\"{x:1449,y:627,t:1527613764364};\\\", \\\"{x:1451,y:627,t:1527613764381};\\\", \\\"{x:1456,y:627,t:1527613764398};\\\", \\\"{x:1460,y:625,t:1527613764414};\\\", \\\"{x:1462,y:625,t:1527613764432};\\\", \\\"{x:1463,y:625,t:1527613764448};\\\", \\\"{x:1464,y:625,t:1527613764468};\\\", \\\"{x:1465,y:625,t:1527613764516};\\\", \\\"{x:1466,y:625,t:1527613764532};\\\", \\\"{x:1468,y:625,t:1527613764548};\\\", \\\"{x:1469,y:625,t:1527613764565};\\\", \\\"{x:1472,y:625,t:1527613764581};\\\", \\\"{x:1472,y:624,t:1527613764644};\\\", \\\"{x:1473,y:624,t:1527613764884};\\\", \\\"{x:1474,y:624,t:1527613764908};\\\", \\\"{x:1475,y:626,t:1527613765148};\\\", \\\"{x:1475,y:632,t:1527613765166};\\\", \\\"{x:1475,y:634,t:1527613765182};\\\", \\\"{x:1475,y:636,t:1527613765199};\\\", \\\"{x:1475,y:639,t:1527613765216};\\\", \\\"{x:1475,y:641,t:1527613765232};\\\", \\\"{x:1475,y:644,t:1527613765249};\\\", \\\"{x:1475,y:647,t:1527613765265};\\\", \\\"{x:1477,y:653,t:1527613765282};\\\", \\\"{x:1477,y:657,t:1527613765299};\\\", \\\"{x:1478,y:662,t:1527613765316};\\\", \\\"{x:1479,y:667,t:1527613765331};\\\", \\\"{x:1479,y:669,t:1527613765348};\\\", \\\"{x:1479,y:673,t:1527613765365};\\\", \\\"{x:1479,y:677,t:1527613765383};\\\", \\\"{x:1480,y:682,t:1527613765399};\\\", \\\"{x:1480,y:688,t:1527613765415};\\\", \\\"{x:1482,y:693,t:1527613765432};\\\", \\\"{x:1482,y:696,t:1527613765449};\\\", \\\"{x:1482,y:697,t:1527613765466};\\\", \\\"{x:1482,y:700,t:1527613765483};\\\", \\\"{x:1482,y:702,t:1527613765499};\\\", \\\"{x:1482,y:707,t:1527613765516};\\\", \\\"{x:1482,y:711,t:1527613765532};\\\", \\\"{x:1482,y:713,t:1527613765548};\\\", \\\"{x:1482,y:716,t:1527613765566};\\\", \\\"{x:1482,y:717,t:1527613765583};\\\", \\\"{x:1482,y:720,t:1527613765598};\\\", \\\"{x:1482,y:724,t:1527613765616};\\\", \\\"{x:1482,y:730,t:1527613765632};\\\", \\\"{x:1482,y:735,t:1527613765648};\\\", \\\"{x:1482,y:738,t:1527613765666};\\\", \\\"{x:1482,y:740,t:1527613765682};\\\", \\\"{x:1482,y:742,t:1527613765699};\\\", \\\"{x:1482,y:748,t:1527613765715};\\\", \\\"{x:1482,y:752,t:1527613765732};\\\", \\\"{x:1482,y:755,t:1527613765750};\\\", \\\"{x:1482,y:758,t:1527613765765};\\\", \\\"{x:1482,y:761,t:1527613765782};\\\", \\\"{x:1482,y:762,t:1527613765799};\\\", \\\"{x:1482,y:766,t:1527613765815};\\\", \\\"{x:1482,y:770,t:1527613765832};\\\", \\\"{x:1482,y:773,t:1527613765849};\\\", \\\"{x:1482,y:777,t:1527613765865};\\\", \\\"{x:1482,y:780,t:1527613765882};\\\", \\\"{x:1481,y:792,t:1527613765899};\\\", \\\"{x:1481,y:798,t:1527613765914};\\\", \\\"{x:1481,y:803,t:1527613765932};\\\", \\\"{x:1481,y:806,t:1527613765949};\\\", \\\"{x:1481,y:807,t:1527613765965};\\\", \\\"{x:1481,y:809,t:1527613765982};\\\", \\\"{x:1481,y:813,t:1527613765999};\\\", \\\"{x:1481,y:816,t:1527613766015};\\\", \\\"{x:1481,y:821,t:1527613766032};\\\", \\\"{x:1479,y:824,t:1527613766049};\\\", \\\"{x:1478,y:828,t:1527613766065};\\\", \\\"{x:1477,y:832,t:1527613766082};\\\", \\\"{x:1477,y:838,t:1527613766100};\\\", \\\"{x:1476,y:841,t:1527613766116};\\\", \\\"{x:1475,y:842,t:1527613766132};\\\", \\\"{x:1475,y:844,t:1527613766150};\\\", \\\"{x:1475,y:845,t:1527613766165};\\\", \\\"{x:1475,y:847,t:1527613766182};\\\", \\\"{x:1475,y:851,t:1527613766200};\\\", \\\"{x:1475,y:856,t:1527613766216};\\\", \\\"{x:1475,y:859,t:1527613766232};\\\", \\\"{x:1475,y:862,t:1527613766249};\\\", \\\"{x:1475,y:864,t:1527613766266};\\\", \\\"{x:1475,y:866,t:1527613766283};\\\", \\\"{x:1475,y:870,t:1527613766300};\\\", \\\"{x:1475,y:871,t:1527613766317};\\\", \\\"{x:1475,y:873,t:1527613766332};\\\", \\\"{x:1475,y:874,t:1527613766349};\\\", \\\"{x:1475,y:875,t:1527613766367};\\\", \\\"{x:1476,y:878,t:1527613766382};\\\", \\\"{x:1476,y:879,t:1527613766399};\\\", \\\"{x:1476,y:881,t:1527613766416};\\\", \\\"{x:1476,y:883,t:1527613766434};\\\", \\\"{x:1476,y:884,t:1527613766449};\\\", \\\"{x:1476,y:886,t:1527613766466};\\\", \\\"{x:1477,y:887,t:1527613766482};\\\", \\\"{x:1477,y:889,t:1527613766499};\\\", \\\"{x:1477,y:892,t:1527613766515};\\\", \\\"{x:1478,y:894,t:1527613766532};\\\", \\\"{x:1478,y:896,t:1527613766549};\\\", \\\"{x:1478,y:899,t:1527613766566};\\\", \\\"{x:1478,y:901,t:1527613766582};\\\", \\\"{x:1478,y:902,t:1527613766599};\\\", \\\"{x:1478,y:903,t:1527613766619};\\\", \\\"{x:1478,y:905,t:1527613766632};\\\", \\\"{x:1479,y:907,t:1527613766649};\\\", \\\"{x:1479,y:909,t:1527613766666};\\\", \\\"{x:1479,y:912,t:1527613766682};\\\", \\\"{x:1480,y:916,t:1527613766699};\\\", \\\"{x:1480,y:918,t:1527613766716};\\\", \\\"{x:1480,y:921,t:1527613766733};\\\", \\\"{x:1480,y:923,t:1527613766750};\\\", \\\"{x:1480,y:926,t:1527613766767};\\\", \\\"{x:1480,y:931,t:1527613766783};\\\", \\\"{x:1480,y:936,t:1527613766799};\\\", \\\"{x:1480,y:938,t:1527613766816};\\\", \\\"{x:1480,y:939,t:1527613766833};\\\", \\\"{x:1480,y:941,t:1527613766849};\\\", \\\"{x:1480,y:942,t:1527613766867};\\\", \\\"{x:1480,y:943,t:1527613766884};\\\", \\\"{x:1480,y:944,t:1527613766899};\\\", \\\"{x:1480,y:946,t:1527613766916};\\\", \\\"{x:1480,y:948,t:1527613766934};\\\", \\\"{x:1480,y:951,t:1527613766949};\\\", \\\"{x:1482,y:954,t:1527613766967};\\\", \\\"{x:1482,y:955,t:1527613766983};\\\", \\\"{x:1482,y:956,t:1527613767020};\\\", \\\"{x:1482,y:957,t:1527613767036};\\\", \\\"{x:1482,y:958,t:1527613767049};\\\", \\\"{x:1482,y:959,t:1527613767066};\\\", \\\"{x:1482,y:961,t:1527613767084};\\\", \\\"{x:1482,y:962,t:1527613767164};\\\", \\\"{x:1483,y:963,t:1527613767188};\\\", \\\"{x:1482,y:964,t:1527613767973};\\\", \\\"{x:1479,y:964,t:1527613767984};\\\", \\\"{x:1475,y:960,t:1527613768000};\\\", \\\"{x:1467,y:944,t:1527613768018};\\\", \\\"{x:1461,y:931,t:1527613768034};\\\", \\\"{x:1454,y:917,t:1527613768051};\\\", \\\"{x:1442,y:889,t:1527613768066};\\\", \\\"{x:1435,y:872,t:1527613768083};\\\", \\\"{x:1430,y:856,t:1527613768100};\\\", \\\"{x:1422,y:837,t:1527613768117};\\\", \\\"{x:1414,y:815,t:1527613768133};\\\", \\\"{x:1405,y:792,t:1527613768150};\\\", \\\"{x:1398,y:775,t:1527613768166};\\\", \\\"{x:1392,y:759,t:1527613768183};\\\", \\\"{x:1383,y:734,t:1527613768200};\\\", \\\"{x:1375,y:707,t:1527613768217};\\\", \\\"{x:1366,y:683,t:1527613768233};\\\", \\\"{x:1358,y:663,t:1527613768251};\\\", \\\"{x:1346,y:636,t:1527613768267};\\\", \\\"{x:1340,y:620,t:1527613768283};\\\", \\\"{x:1329,y:604,t:1527613768300};\\\", \\\"{x:1315,y:589,t:1527613768317};\\\", \\\"{x:1306,y:581,t:1527613768334};\\\", \\\"{x:1300,y:577,t:1527613768350};\\\", \\\"{x:1289,y:573,t:1527613768368};\\\", \\\"{x:1270,y:572,t:1527613768384};\\\", \\\"{x:1234,y:572,t:1527613768401};\\\", \\\"{x:1177,y:583,t:1527613768418};\\\", \\\"{x:1086,y:608,t:1527613768435};\\\", \\\"{x:992,y:636,t:1527613768450};\\\", \\\"{x:853,y:675,t:1527613768467};\\\", \\\"{x:771,y:693,t:1527613768485};\\\", \\\"{x:715,y:701,t:1527613768500};\\\", \\\"{x:667,y:709,t:1527613768518};\\\", \\\"{x:630,y:710,t:1527613768535};\\\", \\\"{x:590,y:711,t:1527613768550};\\\", \\\"{x:560,y:711,t:1527613768568};\\\", \\\"{x:516,y:711,t:1527613768584};\\\", \\\"{x:471,y:711,t:1527613768600};\\\", \\\"{x:430,y:708,t:1527613768617};\\\", \\\"{x:405,y:700,t:1527613768635};\\\", \\\"{x:385,y:695,t:1527613768651};\\\", \\\"{x:371,y:691,t:1527613768668};\\\", \\\"{x:369,y:690,t:1527613768684};\\\", \\\"{x:368,y:690,t:1527613768701};\\\", \\\"{x:367,y:690,t:1527613768836};\\\", \\\"{x:369,y:692,t:1527613768851};\\\", \\\"{x:383,y:701,t:1527613768867};\\\", \\\"{x:391,y:704,t:1527613768885};\\\", \\\"{x:403,y:707,t:1527613768902};\\\", \\\"{x:418,y:712,t:1527613768917};\\\", \\\"{x:435,y:716,t:1527613768934};\\\", \\\"{x:451,y:721,t:1527613768952};\\\", \\\"{x:471,y:727,t:1527613768967};\\\", \\\"{x:487,y:731,t:1527613768984};\\\", \\\"{x:495,y:733,t:1527613769001};\\\", \\\"{x:503,y:735,t:1527613769021};\\\", \\\"{x:503,y:736,t:1527613769138};\\\", \\\"{x:503,y:736,t:1527613769293};\\\" ] }, { \\\"rt\\\": 11822, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 383682, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:736,t:1527613771579};\\\", \\\"{x:505,y:735,t:1527613772292};\\\", \\\"{x:506,y:734,t:1527613772372};\\\", \\\"{x:507,y:734,t:1527613772828};\\\", \\\"{x:509,y:734,t:1527613772843};\\\", \\\"{x:511,y:733,t:1527613772859};\\\", \\\"{x:514,y:732,t:1527613772873};\\\", \\\"{x:541,y:731,t:1527613772890};\\\", \\\"{x:603,y:736,t:1527613772909};\\\", \\\"{x:616,y:737,t:1527613772922};\\\", \\\"{x:668,y:747,t:1527613772940};\\\", \\\"{x:697,y:750,t:1527613772957};\\\", \\\"{x:706,y:752,t:1527613772974};\\\", \\\"{x:710,y:753,t:1527613772990};\\\", \\\"{x:712,y:754,t:1527613773042};\\\", \\\"{x:713,y:755,t:1527613773057};\\\", \\\"{x:718,y:758,t:1527613773075};\\\", \\\"{x:733,y:763,t:1527613773091};\\\", \\\"{x:741,y:767,t:1527613773107};\\\", \\\"{x:750,y:771,t:1527613773124};\\\", \\\"{x:762,y:776,t:1527613773141};\\\", \\\"{x:774,y:780,t:1527613773158};\\\", \\\"{x:780,y:783,t:1527613773174};\\\", \\\"{x:790,y:789,t:1527613773191};\\\", \\\"{x:802,y:795,t:1527613773207};\\\", \\\"{x:809,y:802,t:1527613773224};\\\", \\\"{x:819,y:809,t:1527613773241};\\\", \\\"{x:828,y:815,t:1527613773257};\\\", \\\"{x:842,y:825,t:1527613773274};\\\", \\\"{x:853,y:833,t:1527613773291};\\\", \\\"{x:865,y:839,t:1527613773307};\\\", \\\"{x:880,y:848,t:1527613773324};\\\", \\\"{x:898,y:859,t:1527613773341};\\\", \\\"{x:919,y:872,t:1527613773357};\\\", \\\"{x:941,y:886,t:1527613773374};\\\", \\\"{x:961,y:897,t:1527613773391};\\\", \\\"{x:977,y:905,t:1527613773408};\\\", \\\"{x:994,y:910,t:1527613773425};\\\", \\\"{x:1003,y:913,t:1527613773442};\\\", \\\"{x:1008,y:913,t:1527613773458};\\\", \\\"{x:1016,y:913,t:1527613773475};\\\", \\\"{x:1026,y:913,t:1527613773491};\\\", \\\"{x:1039,y:911,t:1527613773508};\\\", \\\"{x:1050,y:907,t:1527613773525};\\\", \\\"{x:1062,y:902,t:1527613773542};\\\", \\\"{x:1073,y:896,t:1527613773559};\\\", \\\"{x:1086,y:888,t:1527613773575};\\\", \\\"{x:1096,y:878,t:1527613773591};\\\", \\\"{x:1108,y:862,t:1527613773609};\\\", \\\"{x:1111,y:852,t:1527613773625};\\\", \\\"{x:1115,y:843,t:1527613773642};\\\", \\\"{x:1117,y:830,t:1527613773659};\\\", \\\"{x:1119,y:813,t:1527613773675};\\\", \\\"{x:1121,y:798,t:1527613773691};\\\", \\\"{x:1121,y:784,t:1527613773709};\\\", \\\"{x:1121,y:770,t:1527613773725};\\\", \\\"{x:1121,y:761,t:1527613773742};\\\", \\\"{x:1121,y:744,t:1527613773758};\\\", \\\"{x:1121,y:725,t:1527613773775};\\\", \\\"{x:1121,y:703,t:1527613773792};\\\", \\\"{x:1120,y:684,t:1527613773809};\\\", \\\"{x:1114,y:663,t:1527613773825};\\\", \\\"{x:1109,y:641,t:1527613773842};\\\", \\\"{x:1106,y:617,t:1527613773859};\\\", \\\"{x:1103,y:598,t:1527613773875};\\\", \\\"{x:1100,y:568,t:1527613773891};\\\", \\\"{x:1096,y:553,t:1527613773909};\\\", \\\"{x:1095,y:545,t:1527613773925};\\\", \\\"{x:1094,y:539,t:1527613773942};\\\", \\\"{x:1093,y:538,t:1527613774051};\\\", \\\"{x:1092,y:538,t:1527613774059};\\\", \\\"{x:1090,y:538,t:1527613774076};\\\", \\\"{x:1088,y:538,t:1527613774092};\\\", \\\"{x:1087,y:538,t:1527613774109};\\\", \\\"{x:1086,y:538,t:1527613774131};\\\", \\\"{x:1086,y:539,t:1527613774142};\\\", \\\"{x:1086,y:545,t:1527613774158};\\\", \\\"{x:1086,y:552,t:1527613774176};\\\", \\\"{x:1089,y:560,t:1527613774192};\\\", \\\"{x:1097,y:568,t:1527613774209};\\\", \\\"{x:1107,y:574,t:1527613774226};\\\", \\\"{x:1114,y:577,t:1527613774242};\\\", \\\"{x:1122,y:577,t:1527613774258};\\\", \\\"{x:1134,y:578,t:1527613774276};\\\", \\\"{x:1141,y:578,t:1527613774292};\\\", \\\"{x:1149,y:578,t:1527613774309};\\\", \\\"{x:1161,y:576,t:1527613774325};\\\", \\\"{x:1167,y:575,t:1527613774342};\\\", \\\"{x:1172,y:575,t:1527613774359};\\\", \\\"{x:1174,y:575,t:1527613774376};\\\", \\\"{x:1176,y:573,t:1527613774391};\\\", \\\"{x:1177,y:573,t:1527613774412};\\\", \\\"{x:1178,y:572,t:1527613774426};\\\", \\\"{x:1179,y:572,t:1527613774442};\\\", \\\"{x:1180,y:572,t:1527613774458};\\\", \\\"{x:1182,y:570,t:1527613774476};\\\", \\\"{x:1184,y:570,t:1527613774492};\\\", \\\"{x:1185,y:570,t:1527613774509};\\\", \\\"{x:1189,y:570,t:1527613774526};\\\", \\\"{x:1191,y:569,t:1527613774543};\\\", \\\"{x:1193,y:569,t:1527613774559};\\\", \\\"{x:1196,y:569,t:1527613774576};\\\", \\\"{x:1198,y:569,t:1527613774592};\\\", \\\"{x:1202,y:569,t:1527613774608};\\\", \\\"{x:1209,y:569,t:1527613774625};\\\", \\\"{x:1220,y:569,t:1527613774642};\\\", \\\"{x:1245,y:569,t:1527613774658};\\\", \\\"{x:1262,y:569,t:1527613774676};\\\", \\\"{x:1277,y:569,t:1527613774692};\\\", \\\"{x:1286,y:569,t:1527613774708};\\\", \\\"{x:1290,y:569,t:1527613774725};\\\", \\\"{x:1292,y:569,t:1527613774742};\\\", \\\"{x:1295,y:569,t:1527613774758};\\\", \\\"{x:1296,y:569,t:1527613774787};\\\", \\\"{x:1298,y:569,t:1527613774803};\\\", \\\"{x:1299,y:569,t:1527613774819};\\\", \\\"{x:1298,y:569,t:1527613775060};\\\", \\\"{x:1272,y:569,t:1527613775076};\\\", \\\"{x:1231,y:569,t:1527613775093};\\\", \\\"{x:1171,y:562,t:1527613775110};\\\", \\\"{x:1120,y:555,t:1527613775125};\\\", \\\"{x:1086,y:553,t:1527613775142};\\\", \\\"{x:1056,y:552,t:1527613775159};\\\", \\\"{x:1033,y:550,t:1527613775175};\\\", \\\"{x:1014,y:548,t:1527613775193};\\\", \\\"{x:992,y:548,t:1527613775209};\\\", \\\"{x:974,y:547,t:1527613775225};\\\", \\\"{x:938,y:541,t:1527613775243};\\\", \\\"{x:913,y:537,t:1527613775259};\\\", \\\"{x:885,y:532,t:1527613775275};\\\", \\\"{x:857,y:530,t:1527613775292};\\\", \\\"{x:827,y:525,t:1527613775309};\\\", \\\"{x:802,y:522,t:1527613775327};\\\", \\\"{x:778,y:519,t:1527613775342};\\\", \\\"{x:754,y:516,t:1527613775360};\\\", \\\"{x:734,y:516,t:1527613775376};\\\", \\\"{x:718,y:516,t:1527613775394};\\\", \\\"{x:702,y:516,t:1527613775409};\\\", \\\"{x:679,y:516,t:1527613775426};\\\", \\\"{x:663,y:516,t:1527613775442};\\\", \\\"{x:649,y:516,t:1527613775459};\\\", \\\"{x:638,y:516,t:1527613775476};\\\", \\\"{x:628,y:516,t:1527613775492};\\\", \\\"{x:618,y:516,t:1527613775509};\\\", \\\"{x:607,y:516,t:1527613775526};\\\", \\\"{x:595,y:516,t:1527613775542};\\\", \\\"{x:581,y:516,t:1527613775559};\\\", \\\"{x:567,y:514,t:1527613775576};\\\", \\\"{x:553,y:513,t:1527613775592};\\\", \\\"{x:547,y:511,t:1527613775609};\\\", \\\"{x:539,y:511,t:1527613775627};\\\", \\\"{x:534,y:510,t:1527613775643};\\\", \\\"{x:532,y:510,t:1527613775659};\\\", \\\"{x:528,y:509,t:1527613775676};\\\", \\\"{x:525,y:509,t:1527613775692};\\\", \\\"{x:520,y:507,t:1527613775709};\\\", \\\"{x:514,y:506,t:1527613775726};\\\", \\\"{x:510,y:504,t:1527613775743};\\\", \\\"{x:504,y:503,t:1527613775759};\\\", \\\"{x:494,y:501,t:1527613775778};\\\", \\\"{x:484,y:498,t:1527613775792};\\\", \\\"{x:467,y:496,t:1527613775810};\\\", \\\"{x:455,y:493,t:1527613775826};\\\", \\\"{x:443,y:492,t:1527613775844};\\\", \\\"{x:433,y:491,t:1527613775860};\\\", \\\"{x:428,y:490,t:1527613775877};\\\", \\\"{x:426,y:490,t:1527613775893};\\\", \\\"{x:425,y:489,t:1527613775910};\\\", \\\"{x:425,y:488,t:1527613776004};\\\", \\\"{x:425,y:487,t:1527613776010};\\\", \\\"{x:427,y:485,t:1527613776028};\\\", \\\"{x:428,y:483,t:1527613776045};\\\", \\\"{x:431,y:481,t:1527613776060};\\\", \\\"{x:436,y:480,t:1527613776076};\\\", \\\"{x:444,y:478,t:1527613776093};\\\", \\\"{x:452,y:478,t:1527613776110};\\\", \\\"{x:462,y:477,t:1527613776126};\\\", \\\"{x:470,y:477,t:1527613776143};\\\", \\\"{x:477,y:477,t:1527613776160};\\\", \\\"{x:480,y:477,t:1527613776177};\\\", \\\"{x:485,y:477,t:1527613776193};\\\", \\\"{x:502,y:477,t:1527613776210};\\\", \\\"{x:525,y:480,t:1527613776227};\\\", \\\"{x:549,y:485,t:1527613776243};\\\", \\\"{x:588,y:494,t:1527613776261};\\\", \\\"{x:625,y:499,t:1527613776276};\\\", \\\"{x:651,y:502,t:1527613776294};\\\", \\\"{x:664,y:505,t:1527613776310};\\\", \\\"{x:669,y:506,t:1527613776328};\\\", \\\"{x:671,y:506,t:1527613776394};\\\", \\\"{x:677,y:506,t:1527613776410};\\\", \\\"{x:685,y:506,t:1527613776426};\\\", \\\"{x:700,y:506,t:1527613776443};\\\", \\\"{x:719,y:506,t:1527613776460};\\\", \\\"{x:742,y:506,t:1527613776478};\\\", \\\"{x:774,y:506,t:1527613776493};\\\", \\\"{x:841,y:508,t:1527613776510};\\\", \\\"{x:933,y:521,t:1527613776528};\\\", \\\"{x:1043,y:535,t:1527613776543};\\\", \\\"{x:1158,y:556,t:1527613776560};\\\", \\\"{x:1242,y:573,t:1527613776577};\\\", \\\"{x:1305,y:586,t:1527613776595};\\\", \\\"{x:1314,y:587,t:1527613776611};\\\", \\\"{x:1315,y:587,t:1527613776627};\\\", \\\"{x:1315,y:588,t:1527613776844};\\\", \\\"{x:1312,y:588,t:1527613776861};\\\", \\\"{x:1302,y:588,t:1527613776878};\\\", \\\"{x:1293,y:588,t:1527613776895};\\\", \\\"{x:1279,y:588,t:1527613776911};\\\", \\\"{x:1271,y:588,t:1527613776928};\\\", \\\"{x:1270,y:588,t:1527613777036};\\\", \\\"{x:1272,y:586,t:1527613777803};\\\", \\\"{x:1274,y:585,t:1527613777812};\\\", \\\"{x:1281,y:579,t:1527613777829};\\\", \\\"{x:1283,y:577,t:1527613777845};\\\", \\\"{x:1284,y:576,t:1527613777862};\\\", \\\"{x:1284,y:574,t:1527613778140};\\\", \\\"{x:1284,y:571,t:1527613778147};\\\", \\\"{x:1284,y:569,t:1527613778162};\\\", \\\"{x:1285,y:565,t:1527613778182};\\\", \\\"{x:1285,y:564,t:1527613778195};\\\", \\\"{x:1286,y:562,t:1527613778211};\\\", \\\"{x:1286,y:561,t:1527613778234};\\\", \\\"{x:1291,y:560,t:1527613778692};\\\", \\\"{x:1299,y:558,t:1527613778700};\\\", \\\"{x:1309,y:558,t:1527613778712};\\\", \\\"{x:1330,y:558,t:1527613778728};\\\", \\\"{x:1355,y:558,t:1527613778745};\\\", \\\"{x:1387,y:558,t:1527613778762};\\\", \\\"{x:1397,y:558,t:1527613778778};\\\", \\\"{x:1400,y:558,t:1527613778795};\\\", \\\"{x:1401,y:558,t:1527613778812};\\\", \\\"{x:1402,y:558,t:1527613778829};\\\", \\\"{x:1404,y:557,t:1527613778859};\\\", \\\"{x:1408,y:557,t:1527613778867};\\\", \\\"{x:1411,y:556,t:1527613778880};\\\", \\\"{x:1419,y:556,t:1527613778896};\\\", \\\"{x:1430,y:554,t:1527613778912};\\\", \\\"{x:1438,y:554,t:1527613778930};\\\", \\\"{x:1444,y:554,t:1527613778945};\\\", \\\"{x:1449,y:553,t:1527613778963};\\\", \\\"{x:1450,y:553,t:1527613779234};\\\", \\\"{x:1461,y:553,t:1527613779246};\\\", \\\"{x:1491,y:553,t:1527613779262};\\\", \\\"{x:1536,y:553,t:1527613779279};\\\", \\\"{x:1614,y:553,t:1527613779297};\\\", \\\"{x:1670,y:553,t:1527613779312};\\\", \\\"{x:1698,y:553,t:1527613779329};\\\", \\\"{x:1702,y:553,t:1527613779347};\\\", \\\"{x:1695,y:559,t:1527613779395};\\\", \\\"{x:1631,y:577,t:1527613779413};\\\", \\\"{x:1505,y:602,t:1527613779429};\\\", \\\"{x:1338,y:609,t:1527613779447};\\\", \\\"{x:1150,y:609,t:1527613779463};\\\", \\\"{x:991,y:592,t:1527613779480};\\\", \\\"{x:874,y:572,t:1527613779501};\\\", \\\"{x:823,y:564,t:1527613779513};\\\", \\\"{x:797,y:561,t:1527613779530};\\\", \\\"{x:780,y:561,t:1527613779545};\\\", \\\"{x:744,y:559,t:1527613779562};\\\", \\\"{x:702,y:557,t:1527613779578};\\\", \\\"{x:649,y:557,t:1527613779595};\\\", \\\"{x:582,y:548,t:1527613779613};\\\", \\\"{x:515,y:547,t:1527613779629};\\\", \\\"{x:482,y:543,t:1527613779647};\\\", \\\"{x:468,y:541,t:1527613779662};\\\", \\\"{x:469,y:536,t:1527613779811};\\\", \\\"{x:478,y:531,t:1527613779818};\\\", \\\"{x:485,y:527,t:1527613779829};\\\", \\\"{x:506,y:519,t:1527613779847};\\\", \\\"{x:529,y:509,t:1527613779864};\\\", \\\"{x:557,y:500,t:1527613779879};\\\", \\\"{x:570,y:497,t:1527613779896};\\\", \\\"{x:574,y:495,t:1527613779913};\\\", \\\"{x:576,y:495,t:1527613780116};\\\", \\\"{x:581,y:495,t:1527613780131};\\\", \\\"{x:587,y:496,t:1527613780147};\\\", \\\"{x:597,y:500,t:1527613780164};\\\", \\\"{x:603,y:501,t:1527613780182};\\\", \\\"{x:606,y:501,t:1527613780198};\\\", \\\"{x:607,y:502,t:1527613780772};\\\", \\\"{x:610,y:504,t:1527613780786};\\\", \\\"{x:623,y:507,t:1527613780797};\\\", \\\"{x:678,y:525,t:1527613780814};\\\", \\\"{x:771,y:544,t:1527613780831};\\\", \\\"{x:872,y:564,t:1527613780848};\\\", \\\"{x:961,y:581,t:1527613780864};\\\", \\\"{x:1018,y:591,t:1527613780880};\\\", \\\"{x:1034,y:593,t:1527613780897};\\\", \\\"{x:1036,y:593,t:1527613780913};\\\", \\\"{x:1036,y:592,t:1527613781044};\\\", \\\"{x:1034,y:590,t:1527613781051};\\\", \\\"{x:1030,y:588,t:1527613781065};\\\", \\\"{x:1020,y:583,t:1527613781082};\\\", \\\"{x:1004,y:575,t:1527613781097};\\\", \\\"{x:981,y:568,t:1527613781114};\\\", \\\"{x:970,y:565,t:1527613781131};\\\", \\\"{x:963,y:563,t:1527613781148};\\\", \\\"{x:960,y:562,t:1527613781164};\\\", \\\"{x:958,y:561,t:1527613781181};\\\", \\\"{x:953,y:561,t:1527613781198};\\\", \\\"{x:948,y:561,t:1527613781215};\\\", \\\"{x:941,y:561,t:1527613781231};\\\", \\\"{x:930,y:561,t:1527613781248};\\\", \\\"{x:917,y:561,t:1527613781264};\\\", \\\"{x:905,y:564,t:1527613781282};\\\", \\\"{x:887,y:565,t:1527613781299};\\\", \\\"{x:879,y:565,t:1527613781315};\\\", \\\"{x:870,y:566,t:1527613781331};\\\", \\\"{x:866,y:566,t:1527613781349};\\\", \\\"{x:862,y:566,t:1527613781365};\\\", \\\"{x:860,y:566,t:1527613781380};\\\", \\\"{x:858,y:566,t:1527613781410};\\\", \\\"{x:858,y:565,t:1527613781419};\\\", \\\"{x:857,y:563,t:1527613781430};\\\", \\\"{x:855,y:558,t:1527613781447};\\\", \\\"{x:855,y:555,t:1527613781464};\\\", \\\"{x:855,y:550,t:1527613781481};\\\", \\\"{x:853,y:545,t:1527613781497};\\\", \\\"{x:852,y:538,t:1527613781514};\\\", \\\"{x:850,y:533,t:1527613781531};\\\", \\\"{x:849,y:532,t:1527613781547};\\\", \\\"{x:844,y:532,t:1527613781995};\\\", \\\"{x:825,y:540,t:1527613782003};\\\", \\\"{x:797,y:548,t:1527613782016};\\\", \\\"{x:738,y:567,t:1527613782032};\\\", \\\"{x:647,y:590,t:1527613782049};\\\", \\\"{x:575,y:612,t:1527613782065};\\\", \\\"{x:530,y:625,t:1527613782082};\\\", \\\"{x:502,y:640,t:1527613782099};\\\", \\\"{x:495,y:648,t:1527613782115};\\\", \\\"{x:488,y:657,t:1527613782131};\\\", \\\"{x:486,y:661,t:1527613782148};\\\", \\\"{x:484,y:663,t:1527613782164};\\\", \\\"{x:483,y:665,t:1527613782182};\\\", \\\"{x:482,y:667,t:1527613782199};\\\", \\\"{x:480,y:671,t:1527613782216};\\\", \\\"{x:480,y:673,t:1527613782232};\\\", \\\"{x:480,y:676,t:1527613782249};\\\", \\\"{x:480,y:678,t:1527613782265};\\\", \\\"{x:481,y:683,t:1527613782282};\\\", \\\"{x:487,y:694,t:1527613782299};\\\", \\\"{x:490,y:703,t:1527613782315};\\\", \\\"{x:495,y:711,t:1527613782332};\\\", \\\"{x:497,y:718,t:1527613782349};\\\", \\\"{x:498,y:724,t:1527613782367};\\\", \\\"{x:501,y:731,t:1527613782382};\\\", \\\"{x:502,y:736,t:1527613782398};\\\", \\\"{x:504,y:741,t:1527613782416};\\\", \\\"{x:505,y:743,t:1527613782431};\\\" ] }, { \\\"rt\\\": 21178, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 406174, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:743,t:1527613789770};\\\", \\\"{x:507,y:743,t:1527613790412};\\\", \\\"{x:508,y:743,t:1527613790619};\\\", \\\"{x:509,y:743,t:1527613790642};\\\", \\\"{x:509,y:742,t:1527613790651};\\\", \\\"{x:511,y:742,t:1527613790667};\\\", \\\"{x:512,y:742,t:1527613790715};\\\", \\\"{x:515,y:741,t:1527613790731};\\\", \\\"{x:516,y:741,t:1527613790739};\\\", \\\"{x:518,y:741,t:1527613790749};\\\", \\\"{x:527,y:741,t:1527613790766};\\\", \\\"{x:546,y:741,t:1527613790783};\\\", \\\"{x:559,y:740,t:1527613790799};\\\", \\\"{x:578,y:740,t:1527613790816};\\\", \\\"{x:592,y:740,t:1527613790833};\\\", \\\"{x:610,y:740,t:1527613790850};\\\", \\\"{x:622,y:740,t:1527613790871};\\\", \\\"{x:636,y:740,t:1527613790889};\\\", \\\"{x:651,y:740,t:1527613790905};\\\", \\\"{x:666,y:741,t:1527613790921};\\\", \\\"{x:686,y:744,t:1527613790938};\\\", \\\"{x:700,y:744,t:1527613790955};\\\", \\\"{x:710,y:745,t:1527613790972};\\\", \\\"{x:720,y:745,t:1527613790989};\\\", \\\"{x:736,y:745,t:1527613791005};\\\", \\\"{x:754,y:745,t:1527613791021};\\\", \\\"{x:771,y:745,t:1527613791039};\\\", \\\"{x:790,y:745,t:1527613791055};\\\", \\\"{x:808,y:745,t:1527613791072};\\\", \\\"{x:816,y:745,t:1527613791089};\\\", \\\"{x:824,y:745,t:1527613791105};\\\", \\\"{x:834,y:745,t:1527613791123};\\\", \\\"{x:848,y:745,t:1527613791139};\\\", \\\"{x:860,y:743,t:1527613791155};\\\", \\\"{x:871,y:741,t:1527613791172};\\\", \\\"{x:887,y:736,t:1527613791189};\\\", \\\"{x:902,y:731,t:1527613791206};\\\", \\\"{x:910,y:728,t:1527613791222};\\\", \\\"{x:916,y:725,t:1527613791239};\\\", \\\"{x:924,y:716,t:1527613791256};\\\", \\\"{x:931,y:708,t:1527613791272};\\\", \\\"{x:933,y:703,t:1527613791289};\\\", \\\"{x:937,y:695,t:1527613791306};\\\", \\\"{x:942,y:688,t:1527613791322};\\\", \\\"{x:947,y:681,t:1527613791339};\\\", \\\"{x:951,y:677,t:1527613791356};\\\", \\\"{x:956,y:672,t:1527613791373};\\\", \\\"{x:960,y:668,t:1527613791389};\\\", \\\"{x:969,y:663,t:1527613791407};\\\", \\\"{x:979,y:659,t:1527613791422};\\\", \\\"{x:994,y:655,t:1527613791440};\\\", \\\"{x:1006,y:652,t:1527613791456};\\\", \\\"{x:1027,y:647,t:1527613791473};\\\", \\\"{x:1046,y:643,t:1527613791490};\\\", \\\"{x:1069,y:641,t:1527613791506};\\\", \\\"{x:1093,y:638,t:1527613791523};\\\", \\\"{x:1103,y:638,t:1527613791539};\\\", \\\"{x:1108,y:638,t:1527613791556};\\\", \\\"{x:1109,y:638,t:1527613791573};\\\", \\\"{x:1110,y:637,t:1527613791748};\\\", \\\"{x:1110,y:638,t:1527613791874};\\\", \\\"{x:1109,y:646,t:1527613791889};\\\", \\\"{x:1108,y:657,t:1527613791906};\\\", \\\"{x:1106,y:669,t:1527613791922};\\\", \\\"{x:1106,y:675,t:1527613791939};\\\", \\\"{x:1106,y:681,t:1527613791956};\\\", \\\"{x:1106,y:687,t:1527613791973};\\\", \\\"{x:1106,y:694,t:1527613791990};\\\", \\\"{x:1106,y:700,t:1527613792006};\\\", \\\"{x:1106,y:707,t:1527613792023};\\\", \\\"{x:1106,y:711,t:1527613792040};\\\", \\\"{x:1106,y:717,t:1527613792056};\\\", \\\"{x:1106,y:724,t:1527613792073};\\\", \\\"{x:1106,y:731,t:1527613792090};\\\", \\\"{x:1108,y:737,t:1527613792106};\\\", \\\"{x:1109,y:746,t:1527613792122};\\\", \\\"{x:1109,y:753,t:1527613792140};\\\", \\\"{x:1109,y:758,t:1527613792156};\\\", \\\"{x:1110,y:761,t:1527613792173};\\\", \\\"{x:1112,y:764,t:1527613792190};\\\", \\\"{x:1112,y:765,t:1527613792260};\\\", \\\"{x:1113,y:765,t:1527613792547};\\\", \\\"{x:1115,y:765,t:1527613792557};\\\", \\\"{x:1128,y:759,t:1527613792573};\\\", \\\"{x:1140,y:754,t:1527613792591};\\\", \\\"{x:1155,y:749,t:1527613792608};\\\", \\\"{x:1167,y:744,t:1527613792624};\\\", \\\"{x:1174,y:741,t:1527613792640};\\\", \\\"{x:1178,y:739,t:1527613792658};\\\", \\\"{x:1183,y:737,t:1527613792674};\\\", \\\"{x:1186,y:737,t:1527613792690};\\\", \\\"{x:1199,y:733,t:1527613792707};\\\", \\\"{x:1206,y:733,t:1527613792725};\\\", \\\"{x:1215,y:731,t:1527613792741};\\\", \\\"{x:1220,y:731,t:1527613792758};\\\", \\\"{x:1227,y:729,t:1527613792775};\\\", \\\"{x:1232,y:729,t:1527613792790};\\\", \\\"{x:1236,y:728,t:1527613792807};\\\", \\\"{x:1246,y:727,t:1527613792824};\\\", \\\"{x:1266,y:723,t:1527613792841};\\\", \\\"{x:1285,y:721,t:1527613792857};\\\", \\\"{x:1301,y:718,t:1527613792875};\\\", \\\"{x:1314,y:717,t:1527613792891};\\\", \\\"{x:1315,y:717,t:1527613792908};\\\", \\\"{x:1316,y:717,t:1527613793371};\\\", \\\"{x:1319,y:717,t:1527613793379};\\\", \\\"{x:1323,y:714,t:1527613793391};\\\", \\\"{x:1329,y:709,t:1527613793408};\\\", \\\"{x:1332,y:708,t:1527613793424};\\\", \\\"{x:1334,y:706,t:1527613793442};\\\", \\\"{x:1334,y:705,t:1527613793459};\\\", \\\"{x:1335,y:704,t:1527613793508};\\\", \\\"{x:1336,y:703,t:1527613793539};\\\", \\\"{x:1337,y:703,t:1527613793563};\\\", \\\"{x:1338,y:702,t:1527613793575};\\\", \\\"{x:1340,y:701,t:1527613793592};\\\", \\\"{x:1341,y:700,t:1527613793609};\\\", \\\"{x:1341,y:699,t:1527613793625};\\\", \\\"{x:1342,y:698,t:1527613793644};\\\", \\\"{x:1343,y:697,t:1527613793762};\\\", \\\"{x:1343,y:700,t:1527613795251};\\\", \\\"{x:1343,y:707,t:1527613795261};\\\", \\\"{x:1343,y:718,t:1527613795277};\\\", \\\"{x:1344,y:724,t:1527613795292};\\\", \\\"{x:1344,y:728,t:1527613795309};\\\", \\\"{x:1344,y:731,t:1527613795326};\\\", \\\"{x:1345,y:732,t:1527613795342};\\\", \\\"{x:1346,y:733,t:1527613795379};\\\", \\\"{x:1346,y:734,t:1527613795403};\\\", \\\"{x:1346,y:735,t:1527613795419};\\\", \\\"{x:1346,y:736,t:1527613795427};\\\", \\\"{x:1346,y:738,t:1527613795443};\\\", \\\"{x:1346,y:741,t:1527613795459};\\\", \\\"{x:1346,y:744,t:1527613795477};\\\", \\\"{x:1346,y:746,t:1527613795493};\\\", \\\"{x:1346,y:747,t:1527613795509};\\\", \\\"{x:1346,y:749,t:1527613795526};\\\", \\\"{x:1346,y:750,t:1527613795543};\\\", \\\"{x:1346,y:751,t:1527613795559};\\\", \\\"{x:1345,y:753,t:1527613795576};\\\", \\\"{x:1345,y:755,t:1527613795594};\\\", \\\"{x:1345,y:756,t:1527613795610};\\\", \\\"{x:1345,y:759,t:1527613795628};\\\", \\\"{x:1345,y:754,t:1527613797370};\\\", \\\"{x:1345,y:740,t:1527613797377};\\\", \\\"{x:1345,y:730,t:1527613797393};\\\", \\\"{x:1345,y:727,t:1527613797411};\\\", \\\"{x:1345,y:721,t:1527613797428};\\\", \\\"{x:1345,y:719,t:1527613797444};\\\", \\\"{x:1342,y:727,t:1527613797619};\\\", \\\"{x:1342,y:739,t:1527613797629};\\\", \\\"{x:1337,y:761,t:1527613797646};\\\", \\\"{x:1335,y:770,t:1527613797662};\\\", \\\"{x:1332,y:778,t:1527613797678};\\\", \\\"{x:1331,y:783,t:1527613797695};\\\", \\\"{x:1331,y:784,t:1527613797712};\\\", \\\"{x:1331,y:785,t:1527613797729};\\\", \\\"{x:1331,y:778,t:1527613797900};\\\", \\\"{x:1331,y:774,t:1527613797912};\\\", \\\"{x:1331,y:768,t:1527613797929};\\\", \\\"{x:1331,y:761,t:1527613797946};\\\", \\\"{x:1331,y:755,t:1527613797961};\\\", \\\"{x:1331,y:751,t:1527613797979};\\\", \\\"{x:1331,y:750,t:1527613797995};\\\", \\\"{x:1331,y:755,t:1527613798114};\\\", \\\"{x:1333,y:764,t:1527613798128};\\\", \\\"{x:1334,y:772,t:1527613798145};\\\", \\\"{x:1335,y:781,t:1527613798162};\\\", \\\"{x:1335,y:782,t:1527613798177};\\\", \\\"{x:1335,y:780,t:1527613798290};\\\", \\\"{x:1335,y:771,t:1527613798298};\\\", \\\"{x:1333,y:761,t:1527613798312};\\\", \\\"{x:1332,y:751,t:1527613798329};\\\", \\\"{x:1331,y:742,t:1527613798345};\\\", \\\"{x:1331,y:739,t:1527613798361};\\\", \\\"{x:1331,y:738,t:1527613798379};\\\", \\\"{x:1331,y:743,t:1527613798490};\\\", \\\"{x:1331,y:747,t:1527613798498};\\\", \\\"{x:1332,y:752,t:1527613798512};\\\", \\\"{x:1332,y:756,t:1527613798529};\\\", \\\"{x:1333,y:762,t:1527613798545};\\\", \\\"{x:1333,y:766,t:1527613798561};\\\", \\\"{x:1334,y:767,t:1527613798579};\\\", \\\"{x:1333,y:761,t:1527613798698};\\\", \\\"{x:1331,y:755,t:1527613798712};\\\", \\\"{x:1330,y:747,t:1527613798729};\\\", \\\"{x:1328,y:742,t:1527613798746};\\\", \\\"{x:1328,y:741,t:1527613798762};\\\", \\\"{x:1328,y:743,t:1527613798930};\\\", \\\"{x:1330,y:755,t:1527613798946};\\\", \\\"{x:1330,y:766,t:1527613798962};\\\", \\\"{x:1330,y:773,t:1527613798979};\\\", \\\"{x:1330,y:778,t:1527613798996};\\\", \\\"{x:1331,y:781,t:1527613799012};\\\", \\\"{x:1319,y:781,t:1527613799442};\\\", \\\"{x:1268,y:778,t:1527613799449};\\\", \\\"{x:1209,y:772,t:1527613799463};\\\", \\\"{x:1063,y:735,t:1527613799480};\\\", \\\"{x:902,y:686,t:1527613799496};\\\", \\\"{x:756,y:647,t:1527613799513};\\\", \\\"{x:654,y:632,t:1527613799530};\\\", \\\"{x:646,y:632,t:1527613799546};\\\", \\\"{x:642,y:632,t:1527613799562};\\\", \\\"{x:639,y:632,t:1527613799580};\\\", \\\"{x:638,y:633,t:1527613799596};\\\", \\\"{x:637,y:634,t:1527613799613};\\\", \\\"{x:632,y:635,t:1527613799630};\\\", \\\"{x:621,y:644,t:1527613799646};\\\", \\\"{x:602,y:653,t:1527613799663};\\\", \\\"{x:572,y:665,t:1527613799680};\\\", \\\"{x:538,y:675,t:1527613799696};\\\", \\\"{x:507,y:685,t:1527613799713};\\\", \\\"{x:468,y:697,t:1527613799730};\\\", \\\"{x:446,y:699,t:1527613799746};\\\", \\\"{x:430,y:701,t:1527613799763};\\\", \\\"{x:422,y:701,t:1527613799780};\\\", \\\"{x:417,y:701,t:1527613799796};\\\", \\\"{x:415,y:701,t:1527613799813};\\\", \\\"{x:414,y:701,t:1527613799830};\\\", \\\"{x:413,y:700,t:1527613799849};\\\", \\\"{x:413,y:699,t:1527613799865};\\\", \\\"{x:413,y:693,t:1527613799880};\\\", \\\"{x:413,y:682,t:1527613799897};\\\", \\\"{x:413,y:672,t:1527613799912};\\\", \\\"{x:428,y:650,t:1527613799930};\\\", \\\"{x:453,y:629,t:1527613799947};\\\", \\\"{x:498,y:609,t:1527613799963};\\\", \\\"{x:541,y:594,t:1527613799979};\\\", \\\"{x:569,y:590,t:1527613799996};\\\", \\\"{x:590,y:582,t:1527613800012};\\\", \\\"{x:602,y:578,t:1527613800029};\\\", \\\"{x:604,y:577,t:1527613800045};\\\", \\\"{x:604,y:576,t:1527613800129};\\\", \\\"{x:605,y:575,t:1527613800145};\\\", \\\"{x:608,y:568,t:1527613800162};\\\", \\\"{x:610,y:563,t:1527613800179};\\\", \\\"{x:612,y:556,t:1527613800196};\\\", \\\"{x:614,y:550,t:1527613800212};\\\", \\\"{x:615,y:543,t:1527613800229};\\\", \\\"{x:619,y:535,t:1527613800245};\\\", \\\"{x:619,y:527,t:1527613800262};\\\", \\\"{x:621,y:523,t:1527613800279};\\\", \\\"{x:622,y:522,t:1527613800296};\\\", \\\"{x:631,y:519,t:1527613800498};\\\", \\\"{x:649,y:517,t:1527613800513};\\\", \\\"{x:716,y:517,t:1527613800529};\\\", \\\"{x:835,y:517,t:1527613800546};\\\", \\\"{x:871,y:521,t:1527613800563};\\\", \\\"{x:878,y:523,t:1527613800579};\\\", \\\"{x:872,y:522,t:1527613800786};\\\", \\\"{x:862,y:519,t:1527613800796};\\\", \\\"{x:845,y:514,t:1527613800814};\\\", \\\"{x:828,y:508,t:1527613800829};\\\", \\\"{x:819,y:505,t:1527613800846};\\\", \\\"{x:817,y:503,t:1527613800863};\\\", \\\"{x:816,y:501,t:1527613800906};\\\", \\\"{x:816,y:500,t:1527613800914};\\\", \\\"{x:816,y:499,t:1527613800929};\\\", \\\"{x:815,y:498,t:1527613800946};\\\", \\\"{x:816,y:498,t:1527613801154};\\\", \\\"{x:818,y:498,t:1527613801163};\\\", \\\"{x:819,y:499,t:1527613801180};\\\", \\\"{x:822,y:500,t:1527613801196};\\\", \\\"{x:822,y:513,t:1527613801706};\\\", \\\"{x:822,y:524,t:1527613801715};\\\", \\\"{x:822,y:540,t:1527613801731};\\\", \\\"{x:822,y:545,t:1527613801745};\\\", \\\"{x:823,y:559,t:1527613801762};\\\", \\\"{x:824,y:564,t:1527613801780};\\\", \\\"{x:825,y:567,t:1527613801797};\\\", \\\"{x:826,y:569,t:1527613801813};\\\", \\\"{x:827,y:572,t:1527613801830};\\\", \\\"{x:827,y:573,t:1527613801847};\\\", \\\"{x:827,y:574,t:1527613801863};\\\", \\\"{x:827,y:575,t:1527613801889};\\\", \\\"{x:827,y:576,t:1527613801938};\\\", \\\"{x:827,y:578,t:1527613801947};\\\", \\\"{x:827,y:579,t:1527613801964};\\\", \\\"{x:827,y:577,t:1527613802050};\\\", \\\"{x:827,y:568,t:1527613802064};\\\", \\\"{x:828,y:555,t:1527613802080};\\\", \\\"{x:830,y:547,t:1527613802097};\\\", \\\"{x:831,y:543,t:1527613802114};\\\", \\\"{x:832,y:541,t:1527613802130};\\\", \\\"{x:832,y:540,t:1527613802147};\\\", \\\"{x:832,y:539,t:1527613802194};\\\", \\\"{x:833,y:539,t:1527613802209};\\\", \\\"{x:833,y:537,t:1527613802225};\\\", \\\"{x:834,y:536,t:1527613802233};\\\", \\\"{x:835,y:534,t:1527613802247};\\\", \\\"{x:838,y:527,t:1527613802265};\\\", \\\"{x:838,y:525,t:1527613802280};\\\", \\\"{x:841,y:522,t:1527613802298};\\\", \\\"{x:842,y:519,t:1527613802313};\\\", \\\"{x:842,y:515,t:1527613802330};\\\", \\\"{x:842,y:512,t:1527613802347};\\\", \\\"{x:843,y:510,t:1527613802364};\\\", \\\"{x:844,y:510,t:1527613802380};\\\", \\\"{x:842,y:510,t:1527613802698};\\\", \\\"{x:784,y:522,t:1527613802714};\\\", \\\"{x:689,y:537,t:1527613802731};\\\", \\\"{x:589,y:551,t:1527613802747};\\\", \\\"{x:522,y:561,t:1527613802764};\\\", \\\"{x:492,y:569,t:1527613802781};\\\", \\\"{x:477,y:575,t:1527613802797};\\\", \\\"{x:468,y:579,t:1527613802814};\\\", \\\"{x:461,y:584,t:1527613802831};\\\", \\\"{x:454,y:588,t:1527613802848};\\\", \\\"{x:451,y:591,t:1527613802864};\\\", \\\"{x:449,y:592,t:1527613802881};\\\", \\\"{x:448,y:594,t:1527613802979};\\\", \\\"{x:447,y:596,t:1527613802986};\\\", \\\"{x:442,y:600,t:1527613802997};\\\", \\\"{x:437,y:604,t:1527613803015};\\\", \\\"{x:425,y:612,t:1527613803031};\\\", \\\"{x:412,y:617,t:1527613803048};\\\", \\\"{x:398,y:625,t:1527613803064};\\\", \\\"{x:386,y:629,t:1527613803081};\\\", \\\"{x:363,y:632,t:1527613803098};\\\", \\\"{x:352,y:634,t:1527613803113};\\\", \\\"{x:339,y:634,t:1527613803130};\\\", \\\"{x:327,y:634,t:1527613803147};\\\", \\\"{x:310,y:634,t:1527613803163};\\\", \\\"{x:296,y:634,t:1527613803181};\\\", \\\"{x:283,y:634,t:1527613803197};\\\", \\\"{x:275,y:634,t:1527613803214};\\\", \\\"{x:271,y:634,t:1527613803231};\\\", \\\"{x:268,y:634,t:1527613803248};\\\", \\\"{x:263,y:634,t:1527613803264};\\\", \\\"{x:253,y:633,t:1527613803281};\\\", \\\"{x:236,y:631,t:1527613803298};\\\", \\\"{x:229,y:628,t:1527613803314};\\\", \\\"{x:224,y:628,t:1527613803331};\\\", \\\"{x:221,y:628,t:1527613803348};\\\", \\\"{x:216,y:628,t:1527613803364};\\\", \\\"{x:210,y:628,t:1527613803380};\\\", \\\"{x:206,y:628,t:1527613803398};\\\", \\\"{x:204,y:628,t:1527613803414};\\\", \\\"{x:203,y:628,t:1527613803434};\\\", \\\"{x:202,y:628,t:1527613803466};\\\", \\\"{x:201,y:628,t:1527613803481};\\\", \\\"{x:197,y:626,t:1527613803497};\\\", \\\"{x:194,y:622,t:1527613803515};\\\", \\\"{x:191,y:617,t:1527613803532};\\\", \\\"{x:190,y:612,t:1527613803548};\\\", \\\"{x:190,y:606,t:1527613803565};\\\", \\\"{x:187,y:601,t:1527613803581};\\\", \\\"{x:187,y:597,t:1527613803599};\\\", \\\"{x:187,y:595,t:1527613803615};\\\", \\\"{x:186,y:591,t:1527613803632};\\\", \\\"{x:184,y:587,t:1527613803649};\\\", \\\"{x:184,y:584,t:1527613803665};\\\", \\\"{x:182,y:573,t:1527613803681};\\\", \\\"{x:182,y:568,t:1527613803697};\\\", \\\"{x:181,y:563,t:1527613803715};\\\", \\\"{x:179,y:560,t:1527613803732};\\\", \\\"{x:179,y:557,t:1527613803748};\\\", \\\"{x:179,y:554,t:1527613803765};\\\", \\\"{x:179,y:550,t:1527613803781};\\\", \\\"{x:177,y:548,t:1527613803798};\\\", \\\"{x:177,y:546,t:1527613803815};\\\", \\\"{x:177,y:544,t:1527613803841};\\\", \\\"{x:177,y:543,t:1527613803922};\\\", \\\"{x:177,y:541,t:1527613803946};\\\", \\\"{x:179,y:545,t:1527613804353};\\\", \\\"{x:189,y:555,t:1527613804365};\\\", \\\"{x:210,y:575,t:1527613804383};\\\", \\\"{x:235,y:593,t:1527613804399};\\\", \\\"{x:268,y:612,t:1527613804416};\\\", \\\"{x:293,y:627,t:1527613804433};\\\", \\\"{x:306,y:635,t:1527613804450};\\\", \\\"{x:311,y:637,t:1527613804465};\\\", \\\"{x:320,y:644,t:1527613804482};\\\", \\\"{x:326,y:649,t:1527613804499};\\\", \\\"{x:339,y:654,t:1527613804515};\\\", \\\"{x:355,y:660,t:1527613804532};\\\", \\\"{x:372,y:667,t:1527613804549};\\\", \\\"{x:386,y:673,t:1527613804566};\\\", \\\"{x:400,y:679,t:1527613804582};\\\", \\\"{x:413,y:683,t:1527613804599};\\\", \\\"{x:421,y:686,t:1527613804617};\\\", \\\"{x:425,y:687,t:1527613804632};\\\", \\\"{x:428,y:688,t:1527613804649};\\\", \\\"{x:432,y:689,t:1527613804666};\\\", \\\"{x:437,y:689,t:1527613804683};\\\", \\\"{x:446,y:691,t:1527613804699};\\\", \\\"{x:454,y:693,t:1527613804716};\\\", \\\"{x:463,y:697,t:1527613804733};\\\", \\\"{x:470,y:699,t:1527613804749};\\\", \\\"{x:478,y:703,t:1527613804766};\\\", \\\"{x:485,y:707,t:1527613804783};\\\", \\\"{x:491,y:712,t:1527613804799};\\\", \\\"{x:495,y:715,t:1527613804816};\\\", \\\"{x:498,y:718,t:1527613804834};\\\", \\\"{x:500,y:721,t:1527613804852};\\\", \\\"{x:501,y:723,t:1527613804866};\\\", \\\"{x:501,y:724,t:1527613804882};\\\", \\\"{x:502,y:725,t:1527613804899};\\\", \\\"{x:502,y:726,t:1527613804916};\\\", \\\"{x:503,y:729,t:1527613804932};\\\", \\\"{x:503,y:731,t:1527613804949};\\\", \\\"{x:504,y:733,t:1527613804966};\\\", \\\"{x:504,y:735,t:1527613804982};\\\" ] }, { \\\"rt\\\": 41091, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 448478, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -E -E -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:732,t:1527613808402};\\\", \\\"{x:510,y:722,t:1527613808417};\\\", \\\"{x:512,y:718,t:1527613808423};\\\", \\\"{x:516,y:711,t:1527613808439};\\\", \\\"{x:519,y:702,t:1527613808456};\\\", \\\"{x:527,y:692,t:1527613808468};\\\", \\\"{x:531,y:688,t:1527613808486};\\\", \\\"{x:534,y:682,t:1527613808503};\\\", \\\"{x:536,y:678,t:1527613808518};\\\", \\\"{x:539,y:673,t:1527613808535};\\\", \\\"{x:544,y:664,t:1527613808553};\\\", \\\"{x:547,y:657,t:1527613808569};\\\", \\\"{x:555,y:646,t:1527613808585};\\\", \\\"{x:568,y:634,t:1527613808602};\\\", \\\"{x:577,y:627,t:1527613808619};\\\", \\\"{x:580,y:623,t:1527613808636};\\\", \\\"{x:583,y:622,t:1527613808652};\\\", \\\"{x:585,y:619,t:1527613808669};\\\", \\\"{x:588,y:617,t:1527613808685};\\\", \\\"{x:591,y:616,t:1527613808702};\\\", \\\"{x:593,y:616,t:1527613808719};\\\", \\\"{x:604,y:616,t:1527613808736};\\\", \\\"{x:627,y:611,t:1527613808752};\\\", \\\"{x:709,y:610,t:1527613808769};\\\", \\\"{x:787,y:610,t:1527613808785};\\\", \\\"{x:854,y:610,t:1527613808803};\\\", \\\"{x:953,y:584,t:1527613808819};\\\", \\\"{x:1095,y:534,t:1527613808836};\\\", \\\"{x:1225,y:448,t:1527613808852};\\\", \\\"{x:1308,y:377,t:1527613808869};\\\", \\\"{x:1365,y:263,t:1527613808885};\\\", \\\"{x:1408,y:125,t:1527613808902};\\\", \\\"{x:1438,y:16,t:1527613808920};\\\", \\\"{x:1454,y:16,t:1527613808936};\\\", \\\"{x:1457,y:16,t:1527613808952};\\\", \\\"{x:1456,y:16,t:1527613809026};\\\", \\\"{x:1451,y:16,t:1527613809035};\\\", \\\"{x:1405,y:16,t:1527613809052};\\\", \\\"{x:1250,y:16,t:1527613809070};\\\", \\\"{x:989,y:16,t:1527613809085};\\\", \\\"{x:641,y:16,t:1527613809103};\\\", \\\"{x:237,y:16,t:1527613809119};\\\", \\\"{x:0,y:16,t:1527613809136};\\\", \\\"{x:0,y:17,t:1527613809169};\\\", \\\"{x:0,y:51,t:1527613809185};\\\", \\\"{x:0,y:100,t:1527613809202};\\\", \\\"{x:0,y:136,t:1527613809219};\\\", \\\"{x:0,y:171,t:1527613809235};\\\", \\\"{x:0,y:192,t:1527613809252};\\\", \\\"{x:0,y:202,t:1527613809269};\\\", \\\"{x:1,y:200,t:1527613809321};\\\", \\\"{x:4,y:197,t:1527613809335};\\\", \\\"{x:7,y:196,t:1527613809352};\\\", \\\"{x:16,y:196,t:1527613809370};\\\", \\\"{x:37,y:205,t:1527613809385};\\\", \\\"{x:52,y:218,t:1527613809403};\\\", \\\"{x:58,y:242,t:1527613809419};\\\", \\\"{x:67,y:276,t:1527613809435};\\\", \\\"{x:74,y:314,t:1527613809452};\\\", \\\"{x:86,y:354,t:1527613809469};\\\", \\\"{x:95,y:394,t:1527613809485};\\\", \\\"{x:99,y:412,t:1527613809502};\\\", \\\"{x:99,y:416,t:1527613809519};\\\", \\\"{x:98,y:418,t:1527613809535};\\\", \\\"{x:93,y:420,t:1527613809552};\\\", \\\"{x:89,y:422,t:1527613809569};\\\", \\\"{x:88,y:422,t:1527613809585};\\\", \\\"{x:86,y:422,t:1527613809754};\\\", \\\"{x:75,y:420,t:1527613809770};\\\", \\\"{x:44,y:409,t:1527613809785};\\\", \\\"{x:22,y:400,t:1527613809802};\\\", \\\"{x:0,y:390,t:1527613809819};\\\", \\\"{x:0,y:386,t:1527613809835};\\\", \\\"{x:0,y:384,t:1527613809852};\\\", \\\"{x:0,y:382,t:1527613809873};\\\", \\\"{x:0,y:381,t:1527613809885};\\\", \\\"{x:0,y:376,t:1527613809902};\\\", \\\"{x:0,y:370,t:1527613809919};\\\", \\\"{x:0,y:366,t:1527613809935};\\\", \\\"{x:0,y:363,t:1527613809952};\\\", \\\"{x:0,y:360,t:1527613809986};\\\", \\\"{x:0,y:354,t:1527613810002};\\\", \\\"{x:0,y:347,t:1527613810019};\\\", \\\"{x:0,y:342,t:1527613810035};\\\", \\\"{x:0,y:339,t:1527613810053};\\\", \\\"{x:0,y:337,t:1527613811114};\\\", \\\"{x:0,y:336,t:1527613811137};\\\", \\\"{x:0,y:335,t:1527613811169};\\\", \\\"{x:0,y:334,t:1527613811217};\\\", \\\"{x:7,y:340,t:1527613813802};\\\", \\\"{x:81,y:416,t:1527613813818};\\\", \\\"{x:192,y:498,t:1527613813836};\\\", \\\"{x:339,y:562,t:1527613813852};\\\", \\\"{x:476,y:597,t:1527613813868};\\\", \\\"{x:662,y:632,t:1527613813889};\\\", \\\"{x:800,y:669,t:1527613813907};\\\", \\\"{x:932,y:703,t:1527613813924};\\\", \\\"{x:1018,y:730,t:1527613813940};\\\", \\\"{x:1068,y:742,t:1527613813956};\\\", \\\"{x:1094,y:749,t:1527613813974};\\\", \\\"{x:1114,y:754,t:1527613813989};\\\", \\\"{x:1131,y:761,t:1527613814007};\\\", \\\"{x:1146,y:767,t:1527613814023};\\\", \\\"{x:1156,y:772,t:1527613814040};\\\", \\\"{x:1164,y:774,t:1527613814056};\\\", \\\"{x:1165,y:774,t:1527613814081};\\\", \\\"{x:1166,y:774,t:1527613814089};\\\", \\\"{x:1172,y:774,t:1527613814107};\\\", \\\"{x:1178,y:776,t:1527613814124};\\\", \\\"{x:1182,y:779,t:1527613814140};\\\", \\\"{x:1183,y:779,t:1527613814157};\\\", \\\"{x:1184,y:779,t:1527613814174};\\\", \\\"{x:1187,y:780,t:1527613814190};\\\", \\\"{x:1200,y:784,t:1527613814207};\\\", \\\"{x:1214,y:789,t:1527613814223};\\\", \\\"{x:1233,y:794,t:1527613814240};\\\", \\\"{x:1255,y:800,t:1527613814256};\\\", \\\"{x:1280,y:806,t:1527613814274};\\\", \\\"{x:1285,y:806,t:1527613814291};\\\", \\\"{x:1287,y:806,t:1527613814306};\\\", \\\"{x:1287,y:809,t:1527613814490};\\\", \\\"{x:1283,y:810,t:1527613814497};\\\", \\\"{x:1277,y:813,t:1527613814506};\\\", \\\"{x:1260,y:813,t:1527613814523};\\\", \\\"{x:1244,y:813,t:1527613814541};\\\", \\\"{x:1226,y:813,t:1527613814557};\\\", \\\"{x:1206,y:813,t:1527613814573};\\\", \\\"{x:1198,y:813,t:1527613814591};\\\", \\\"{x:1193,y:813,t:1527613814607};\\\", \\\"{x:1190,y:813,t:1527613814624};\\\", \\\"{x:1188,y:813,t:1527613814640};\\\", \\\"{x:1187,y:813,t:1527613814874};\\\", \\\"{x:1187,y:808,t:1527613814890};\\\", \\\"{x:1185,y:803,t:1527613814907};\\\", \\\"{x:1183,y:797,t:1527613814924};\\\", \\\"{x:1183,y:794,t:1527613814940};\\\", \\\"{x:1180,y:789,t:1527613814958};\\\", \\\"{x:1180,y:786,t:1527613814975};\\\", \\\"{x:1180,y:784,t:1527613814990};\\\", \\\"{x:1179,y:782,t:1527613815007};\\\", \\\"{x:1178,y:780,t:1527613815024};\\\", \\\"{x:1175,y:775,t:1527613815040};\\\", \\\"{x:1174,y:770,t:1527613815057};\\\", \\\"{x:1173,y:769,t:1527613815074};\\\", \\\"{x:1173,y:768,t:1527613815091};\\\", \\\"{x:1172,y:767,t:1527613815108};\\\", \\\"{x:1172,y:765,t:1527613815125};\\\", \\\"{x:1172,y:767,t:1527613815562};\\\", \\\"{x:1172,y:770,t:1527613815574};\\\", \\\"{x:1174,y:774,t:1527613815591};\\\", \\\"{x:1177,y:780,t:1527613815608};\\\", \\\"{x:1179,y:787,t:1527613815624};\\\", \\\"{x:1182,y:790,t:1527613815641};\\\", \\\"{x:1183,y:793,t:1527613815659};\\\", \\\"{x:1184,y:796,t:1527613815675};\\\", \\\"{x:1185,y:796,t:1527613815691};\\\", \\\"{x:1186,y:797,t:1527613815708};\\\", \\\"{x:1186,y:798,t:1527613815738};\\\", \\\"{x:1187,y:799,t:1527613815746};\\\", \\\"{x:1188,y:800,t:1527613815761};\\\", \\\"{x:1189,y:802,t:1527613815785};\\\", \\\"{x:1191,y:803,t:1527613815793};\\\", \\\"{x:1193,y:805,t:1527613815809};\\\", \\\"{x:1195,y:807,t:1527613815825};\\\", \\\"{x:1197,y:808,t:1527613815842};\\\", \\\"{x:1198,y:810,t:1527613815858};\\\", \\\"{x:1199,y:810,t:1527613815876};\\\", \\\"{x:1199,y:809,t:1527613818899};\\\", \\\"{x:1197,y:807,t:1527613818924};\\\", \\\"{x:1196,y:805,t:1527613818963};\\\", \\\"{x:1196,y:801,t:1527613818971};\\\", \\\"{x:1195,y:797,t:1527613818989};\\\", \\\"{x:1195,y:795,t:1527613819005};\\\", \\\"{x:1194,y:792,t:1527613819021};\\\", \\\"{x:1194,y:790,t:1527613819039};\\\", \\\"{x:1193,y:787,t:1527613819054};\\\", \\\"{x:1193,y:785,t:1527613819071};\\\", \\\"{x:1193,y:783,t:1527613819088};\\\", \\\"{x:1193,y:782,t:1527613819105};\\\", \\\"{x:1192,y:780,t:1527613819121};\\\", \\\"{x:1192,y:778,t:1527613819138};\\\", \\\"{x:1191,y:776,t:1527613819156};\\\", \\\"{x:1191,y:775,t:1527613819171};\\\", \\\"{x:1191,y:773,t:1527613819188};\\\", \\\"{x:1190,y:772,t:1527613819206};\\\", \\\"{x:1189,y:771,t:1527613819222};\\\", \\\"{x:1188,y:769,t:1527613819238};\\\", \\\"{x:1187,y:765,t:1527613819256};\\\", \\\"{x:1186,y:762,t:1527613819272};\\\", \\\"{x:1185,y:758,t:1527613819289};\\\", \\\"{x:1185,y:757,t:1527613819306};\\\", \\\"{x:1187,y:759,t:1527613819627};\\\", \\\"{x:1187,y:761,t:1527613819639};\\\", \\\"{x:1188,y:762,t:1527613819656};\\\", \\\"{x:1189,y:763,t:1527613819676};\\\", \\\"{x:1190,y:764,t:1527613819692};\\\", \\\"{x:1190,y:765,t:1527613819705};\\\", \\\"{x:1191,y:766,t:1527613819722};\\\", \\\"{x:1192,y:769,t:1527613819739};\\\", \\\"{x:1193,y:770,t:1527613819756};\\\", \\\"{x:1195,y:772,t:1527613819772};\\\", \\\"{x:1196,y:774,t:1527613819788};\\\", \\\"{x:1197,y:774,t:1527613819806};\\\", \\\"{x:1197,y:776,t:1527613819823};\\\", \\\"{x:1199,y:778,t:1527613819839};\\\", \\\"{x:1200,y:779,t:1527613819859};\\\", \\\"{x:1201,y:781,t:1527613819891};\\\", \\\"{x:1202,y:781,t:1527613819907};\\\", \\\"{x:1202,y:782,t:1527613819922};\\\", \\\"{x:1204,y:783,t:1527613819939};\\\", \\\"{x:1204,y:784,t:1527613819956};\\\", \\\"{x:1205,y:785,t:1527613819973};\\\", \\\"{x:1206,y:785,t:1527613819995};\\\", \\\"{x:1206,y:786,t:1527613820019};\\\", \\\"{x:1207,y:786,t:1527613820035};\\\", \\\"{x:1208,y:787,t:1527613820043};\\\", \\\"{x:1209,y:788,t:1527613820059};\\\", \\\"{x:1209,y:789,t:1527613820107};\\\", \\\"{x:1210,y:789,t:1527613820124};\\\", \\\"{x:1210,y:790,t:1527613820148};\\\", \\\"{x:1210,y:791,t:1527613820163};\\\", \\\"{x:1211,y:791,t:1527613820179};\\\", \\\"{x:1211,y:792,t:1527613820196};\\\", \\\"{x:1212,y:792,t:1527613820207};\\\", \\\"{x:1212,y:793,t:1527613820235};\\\", \\\"{x:1213,y:793,t:1527613820300};\\\", \\\"{x:1213,y:794,t:1527613820324};\\\", \\\"{x:1214,y:795,t:1527613820340};\\\", \\\"{x:1214,y:796,t:1527613820380};\\\", \\\"{x:1215,y:797,t:1527613820396};\\\", \\\"{x:1216,y:798,t:1527613820412};\\\", \\\"{x:1216,y:799,t:1527613820436};\\\", \\\"{x:1217,y:800,t:1527613820468};\\\", \\\"{x:1217,y:799,t:1527613820772};\\\", \\\"{x:1217,y:795,t:1527613820779};\\\", \\\"{x:1215,y:790,t:1527613820791};\\\", \\\"{x:1214,y:786,t:1527613820807};\\\", \\\"{x:1213,y:784,t:1527613820824};\\\", \\\"{x:1213,y:783,t:1527613820839};\\\", \\\"{x:1213,y:781,t:1527613820856};\\\", \\\"{x:1212,y:780,t:1527613820874};\\\", \\\"{x:1212,y:779,t:1527613820891};\\\", \\\"{x:1211,y:777,t:1527613820907};\\\", \\\"{x:1210,y:776,t:1527613820931};\\\", \\\"{x:1210,y:774,t:1527613820963};\\\", \\\"{x:1209,y:774,t:1527613820987};\\\", \\\"{x:1209,y:773,t:1527613821011};\\\", \\\"{x:1209,y:772,t:1527613821035};\\\", \\\"{x:1209,y:771,t:1527613821044};\\\", \\\"{x:1208,y:771,t:1527613821056};\\\", \\\"{x:1208,y:770,t:1527613821074};\\\", \\\"{x:1207,y:768,t:1527613821090};\\\", \\\"{x:1207,y:766,t:1527613821107};\\\", \\\"{x:1207,y:765,t:1527613821124};\\\", \\\"{x:1206,y:764,t:1527613821147};\\\", \\\"{x:1206,y:763,t:1527613821163};\\\", \\\"{x:1206,y:762,t:1527613821188};\\\", \\\"{x:1206,y:761,t:1527613821203};\\\", \\\"{x:1205,y:760,t:1527613821211};\\\", \\\"{x:1205,y:759,t:1527613821227};\\\", \\\"{x:1205,y:756,t:1527613821243};\\\", \\\"{x:1205,y:753,t:1527613821258};\\\", \\\"{x:1209,y:743,t:1527613821274};\\\", \\\"{x:1219,y:730,t:1527613821290};\\\", \\\"{x:1235,y:712,t:1527613821307};\\\", \\\"{x:1243,y:704,t:1527613821324};\\\", \\\"{x:1248,y:697,t:1527613821340};\\\", \\\"{x:1254,y:689,t:1527613821358};\\\", \\\"{x:1257,y:683,t:1527613821373};\\\", \\\"{x:1261,y:673,t:1527613821391};\\\", \\\"{x:1264,y:665,t:1527613821408};\\\", \\\"{x:1264,y:662,t:1527613821424};\\\", \\\"{x:1265,y:658,t:1527613821442};\\\", \\\"{x:1265,y:655,t:1527613821457};\\\", \\\"{x:1266,y:653,t:1527613821475};\\\", \\\"{x:1266,y:652,t:1527613821491};\\\", \\\"{x:1266,y:651,t:1527613821508};\\\", \\\"{x:1266,y:650,t:1527613821524};\\\", \\\"{x:1267,y:648,t:1527613821541};\\\", \\\"{x:1267,y:646,t:1527613821558};\\\", \\\"{x:1268,y:643,t:1527613821574};\\\", \\\"{x:1269,y:641,t:1527613821591};\\\", \\\"{x:1271,y:639,t:1527613821608};\\\", \\\"{x:1273,y:637,t:1527613821625};\\\", \\\"{x:1276,y:634,t:1527613821641};\\\", \\\"{x:1278,y:632,t:1527613821658};\\\", \\\"{x:1281,y:628,t:1527613821675};\\\", \\\"{x:1282,y:627,t:1527613821691};\\\", \\\"{x:1284,y:624,t:1527613821707};\\\", \\\"{x:1285,y:622,t:1527613821739};\\\", \\\"{x:1285,y:621,t:1527613821819};\\\", \\\"{x:1285,y:619,t:1527613821827};\\\", \\\"{x:1285,y:618,t:1527613821842};\\\", \\\"{x:1285,y:614,t:1527613821858};\\\", \\\"{x:1285,y:611,t:1527613821875};\\\", \\\"{x:1285,y:608,t:1527613821891};\\\", \\\"{x:1285,y:605,t:1527613821907};\\\", \\\"{x:1285,y:602,t:1527613821925};\\\", \\\"{x:1285,y:599,t:1527613821942};\\\", \\\"{x:1285,y:598,t:1527613821958};\\\", \\\"{x:1285,y:596,t:1527613821974};\\\", \\\"{x:1285,y:594,t:1527613821992};\\\", \\\"{x:1285,y:593,t:1527613822007};\\\", \\\"{x:1285,y:591,t:1527613822025};\\\", \\\"{x:1285,y:590,t:1527613822042};\\\", \\\"{x:1285,y:589,t:1527613822057};\\\", \\\"{x:1285,y:588,t:1527613822074};\\\", \\\"{x:1285,y:587,t:1527613822092};\\\", \\\"{x:1286,y:584,t:1527613822108};\\\", \\\"{x:1286,y:582,t:1527613822125};\\\", \\\"{x:1287,y:581,t:1527613822141};\\\", \\\"{x:1288,y:579,t:1527613822158};\\\", \\\"{x:1288,y:578,t:1527613822180};\\\", \\\"{x:1288,y:577,t:1527613822203};\\\", \\\"{x:1288,y:576,t:1527613822211};\\\", \\\"{x:1290,y:575,t:1527613822227};\\\", \\\"{x:1290,y:574,t:1527613822242};\\\", \\\"{x:1290,y:573,t:1527613822259};\\\", \\\"{x:1290,y:571,t:1527613822275};\\\", \\\"{x:1290,y:570,t:1527613822411};\\\", \\\"{x:1290,y:568,t:1527613822443};\\\", \\\"{x:1290,y:567,t:1527613822459};\\\", \\\"{x:1290,y:565,t:1527613822475};\\\", \\\"{x:1290,y:564,t:1527613822556};\\\", \\\"{x:1289,y:563,t:1527613822827};\\\", \\\"{x:1288,y:563,t:1527613822851};\\\", \\\"{x:1287,y:563,t:1527613823508};\\\", \\\"{x:1284,y:564,t:1527613823526};\\\", \\\"{x:1283,y:565,t:1527613823542};\\\", \\\"{x:1281,y:566,t:1527613823559};\\\", \\\"{x:1280,y:567,t:1527613823577};\\\", \\\"{x:1279,y:568,t:1527613830012};\\\", \\\"{x:1279,y:569,t:1527613830029};\\\", \\\"{x:1280,y:569,t:1527613830036};\\\", \\\"{x:1281,y:569,t:1527613830051};\\\", \\\"{x:1284,y:571,t:1527613830068};\\\", \\\"{x:1287,y:571,t:1527613830084};\\\", \\\"{x:1288,y:571,t:1527613830100};\\\", \\\"{x:1289,y:571,t:1527613830117};\\\", \\\"{x:1290,y:571,t:1527613830133};\\\", \\\"{x:1292,y:571,t:1527613830151};\\\", \\\"{x:1294,y:571,t:1527613830167};\\\", \\\"{x:1297,y:570,t:1527613830184};\\\", \\\"{x:1300,y:569,t:1527613830201};\\\", \\\"{x:1305,y:567,t:1527613830217};\\\", \\\"{x:1308,y:566,t:1527613830234};\\\", \\\"{x:1312,y:564,t:1527613830251};\\\", \\\"{x:1316,y:563,t:1527613830268};\\\", \\\"{x:1320,y:561,t:1527613830285};\\\", \\\"{x:1322,y:559,t:1527613830300};\\\", \\\"{x:1327,y:557,t:1527613830317};\\\", \\\"{x:1328,y:556,t:1527613830333};\\\", \\\"{x:1329,y:556,t:1527613830349};\\\", \\\"{x:1332,y:556,t:1527613830435};\\\", \\\"{x:1334,y:556,t:1527613830450};\\\", \\\"{x:1339,y:561,t:1527613830467};\\\", \\\"{x:1343,y:564,t:1527613830483};\\\", \\\"{x:1344,y:565,t:1527613830501};\\\", \\\"{x:1346,y:566,t:1527613830517};\\\", \\\"{x:1348,y:566,t:1527613830534};\\\", \\\"{x:1351,y:566,t:1527613830550};\\\", \\\"{x:1359,y:566,t:1527613830568};\\\", \\\"{x:1377,y:569,t:1527613830585};\\\", \\\"{x:1399,y:571,t:1527613830601};\\\", \\\"{x:1417,y:573,t:1527613830618};\\\", \\\"{x:1430,y:573,t:1527613830634};\\\", \\\"{x:1433,y:573,t:1527613830650};\\\", \\\"{x:1435,y:573,t:1527613830668};\\\", \\\"{x:1436,y:572,t:1527613830692};\\\", \\\"{x:1434,y:572,t:1527613830829};\\\", \\\"{x:1431,y:574,t:1527613830836};\\\", \\\"{x:1426,y:576,t:1527613830852};\\\", \\\"{x:1422,y:579,t:1527613830868};\\\", \\\"{x:1420,y:582,t:1527613830884};\\\", \\\"{x:1420,y:583,t:1527613830901};\\\", \\\"{x:1419,y:584,t:1527613830917};\\\", \\\"{x:1419,y:583,t:1527613831003};\\\", \\\"{x:1421,y:582,t:1527613831017};\\\", \\\"{x:1425,y:581,t:1527613831034};\\\", \\\"{x:1433,y:578,t:1527613831051};\\\", \\\"{x:1441,y:577,t:1527613831067};\\\", \\\"{x:1444,y:574,t:1527613831084};\\\", \\\"{x:1447,y:573,t:1527613831101};\\\", \\\"{x:1451,y:570,t:1527613831118};\\\", \\\"{x:1453,y:569,t:1527613831134};\\\", \\\"{x:1455,y:567,t:1527613831151};\\\", \\\"{x:1456,y:566,t:1527613831167};\\\", \\\"{x:1458,y:564,t:1527613831185};\\\", \\\"{x:1459,y:563,t:1527613831201};\\\", \\\"{x:1461,y:561,t:1527613831219};\\\", \\\"{x:1462,y:560,t:1527613831235};\\\", \\\"{x:1463,y:559,t:1527613831252};\\\", \\\"{x:1465,y:559,t:1527613831341};\\\", \\\"{x:1470,y:559,t:1527613831352};\\\", \\\"{x:1485,y:566,t:1527613831369};\\\", \\\"{x:1495,y:569,t:1527613831385};\\\", \\\"{x:1499,y:569,t:1527613831402};\\\", \\\"{x:1506,y:571,t:1527613831419};\\\", \\\"{x:1515,y:572,t:1527613831435};\\\", \\\"{x:1518,y:572,t:1527613831452};\\\", \\\"{x:1519,y:573,t:1527613831469};\\\", \\\"{x:1520,y:573,t:1527613831581};\\\", \\\"{x:1520,y:572,t:1527613831588};\\\", \\\"{x:1520,y:571,t:1527613831602};\\\", \\\"{x:1520,y:568,t:1527613831619};\\\", \\\"{x:1520,y:567,t:1527613831636};\\\", \\\"{x:1520,y:566,t:1527613831652};\\\", \\\"{x:1520,y:563,t:1527613831669};\\\", \\\"{x:1522,y:559,t:1527613831686};\\\", \\\"{x:1522,y:554,t:1527613831701};\\\", \\\"{x:1523,y:547,t:1527613831719};\\\", \\\"{x:1523,y:544,t:1527613831735};\\\", \\\"{x:1523,y:543,t:1527613831752};\\\", \\\"{x:1524,y:543,t:1527613831844};\\\", \\\"{x:1528,y:550,t:1527613831852};\\\", \\\"{x:1539,y:566,t:1527613831869};\\\", \\\"{x:1555,y:579,t:1527613831886};\\\", \\\"{x:1573,y:588,t:1527613831903};\\\", \\\"{x:1586,y:589,t:1527613831919};\\\", \\\"{x:1590,y:589,t:1527613831936};\\\", \\\"{x:1592,y:589,t:1527613831953};\\\", \\\"{x:1593,y:587,t:1527613831969};\\\", \\\"{x:1593,y:581,t:1527613831986};\\\", \\\"{x:1593,y:573,t:1527613832003};\\\", \\\"{x:1593,y:570,t:1527613832019};\\\", \\\"{x:1594,y:566,t:1527613832035};\\\", \\\"{x:1594,y:563,t:1527613832053};\\\", \\\"{x:1594,y:562,t:1527613832085};\\\", \\\"{x:1594,y:561,t:1527613832101};\\\", \\\"{x:1594,y:560,t:1527613832109};\\\", \\\"{x:1594,y:559,t:1527613832124};\\\", \\\"{x:1594,y:558,t:1527613832136};\\\", \\\"{x:1594,y:557,t:1527613832153};\\\", \\\"{x:1595,y:558,t:1527613832285};\\\", \\\"{x:1600,y:568,t:1527613832303};\\\", \\\"{x:1605,y:575,t:1527613832319};\\\", \\\"{x:1609,y:578,t:1527613832336};\\\", \\\"{x:1610,y:579,t:1527613832445};\\\", \\\"{x:1611,y:579,t:1527613832460};\\\", \\\"{x:1613,y:579,t:1527613832470};\\\", \\\"{x:1614,y:579,t:1527613832486};\\\", \\\"{x:1616,y:579,t:1527613832503};\\\", \\\"{x:1617,y:579,t:1527613832520};\\\", \\\"{x:1619,y:578,t:1527613832536};\\\", \\\"{x:1621,y:577,t:1527613832553};\\\", \\\"{x:1622,y:577,t:1527613832572};\\\", \\\"{x:1622,y:576,t:1527613832612};\\\", \\\"{x:1624,y:576,t:1527613832637};\\\", \\\"{x:1626,y:574,t:1527613832653};\\\", \\\"{x:1627,y:572,t:1527613832670};\\\", \\\"{x:1628,y:572,t:1527613832687};\\\", \\\"{x:1629,y:571,t:1527613832702};\\\", \\\"{x:1630,y:570,t:1527613832720};\\\", \\\"{x:1632,y:569,t:1527613832737};\\\", \\\"{x:1632,y:568,t:1527613832753};\\\", \\\"{x:1634,y:566,t:1527613832772};\\\", \\\"{x:1634,y:565,t:1527613832787};\\\", \\\"{x:1635,y:564,t:1527613832803};\\\", \\\"{x:1637,y:563,t:1527613832820};\\\", \\\"{x:1637,y:562,t:1527613832845};\\\", \\\"{x:1627,y:557,t:1527613836557};\\\", \\\"{x:1515,y:539,t:1527613836574};\\\", \\\"{x:1391,y:539,t:1527613836591};\\\", \\\"{x:1255,y:539,t:1527613836608};\\\", \\\"{x:1122,y:539,t:1527613836623};\\\", \\\"{x:1017,y:539,t:1527613836641};\\\", \\\"{x:958,y:539,t:1527613836657};\\\", \\\"{x:934,y:539,t:1527613836676};\\\", \\\"{x:926,y:539,t:1527613836690};\\\", \\\"{x:924,y:539,t:1527613836706};\\\", \\\"{x:921,y:538,t:1527613836717};\\\", \\\"{x:906,y:538,t:1527613836734};\\\", \\\"{x:882,y:538,t:1527613836751};\\\", \\\"{x:852,y:537,t:1527613836767};\\\", \\\"{x:829,y:537,t:1527613836785};\\\", \\\"{x:814,y:537,t:1527613836803};\\\", \\\"{x:809,y:537,t:1527613836817};\\\", \\\"{x:806,y:537,t:1527613836834};\\\", \\\"{x:788,y:535,t:1527613836851};\\\", \\\"{x:779,y:533,t:1527613836868};\\\", \\\"{x:770,y:532,t:1527613836885};\\\", \\\"{x:756,y:530,t:1527613836901};\\\", \\\"{x:741,y:524,t:1527613836918};\\\", \\\"{x:731,y:522,t:1527613836935};\\\", \\\"{x:722,y:519,t:1527613836951};\\\", \\\"{x:714,y:516,t:1527613836969};\\\", \\\"{x:703,y:513,t:1527613836984};\\\", \\\"{x:679,y:507,t:1527613837001};\\\", \\\"{x:652,y:497,t:1527613837018};\\\", \\\"{x:636,y:490,t:1527613837035};\\\", \\\"{x:628,y:486,t:1527613837052};\\\", \\\"{x:627,y:485,t:1527613837100};\\\", \\\"{x:626,y:485,t:1527613837115};\\\", \\\"{x:624,y:484,t:1527613837124};\\\", \\\"{x:620,y:483,t:1527613837134};\\\", \\\"{x:615,y:483,t:1527613837152};\\\", \\\"{x:614,y:483,t:1527613837168};\\\", \\\"{x:613,y:484,t:1527613837493};\\\", \\\"{x:613,y:487,t:1527613837502};\\\", \\\"{x:612,y:491,t:1527613837519};\\\", \\\"{x:612,y:494,t:1527613837535};\\\", \\\"{x:612,y:495,t:1527613837551};\\\", \\\"{x:612,y:496,t:1527613837571};\\\", \\\"{x:612,y:497,t:1527613837651};\\\", \\\"{x:625,y:503,t:1527613838196};\\\", \\\"{x:652,y:507,t:1527613838203};\\\", \\\"{x:721,y:525,t:1527613838219};\\\", \\\"{x:776,y:538,t:1527613838236};\\\", \\\"{x:840,y:547,t:1527613838252};\\\", \\\"{x:910,y:559,t:1527613838269};\\\", \\\"{x:952,y:565,t:1527613838285};\\\", \\\"{x:976,y:565,t:1527613838303};\\\", \\\"{x:993,y:566,t:1527613838319};\\\", \\\"{x:1003,y:568,t:1527613838335};\\\", \\\"{x:1007,y:569,t:1527613838352};\\\", \\\"{x:1012,y:569,t:1527613838369};\\\", \\\"{x:1019,y:570,t:1527613838385};\\\", \\\"{x:1034,y:578,t:1527613838402};\\\", \\\"{x:1064,y:591,t:1527613838419};\\\", \\\"{x:1081,y:601,t:1527613838437};\\\", \\\"{x:1099,y:611,t:1527613838453};\\\", \\\"{x:1114,y:621,t:1527613838470};\\\", \\\"{x:1123,y:629,t:1527613838487};\\\", \\\"{x:1125,y:635,t:1527613838503};\\\", \\\"{x:1127,y:642,t:1527613838519};\\\", \\\"{x:1127,y:651,t:1527613838537};\\\", \\\"{x:1130,y:664,t:1527613838552};\\\", \\\"{x:1133,y:673,t:1527613838569};\\\", \\\"{x:1136,y:685,t:1527613838587};\\\", \\\"{x:1139,y:694,t:1527613838603};\\\", \\\"{x:1140,y:699,t:1527613838620};\\\", \\\"{x:1142,y:705,t:1527613838637};\\\", \\\"{x:1142,y:708,t:1527613838654};\\\", \\\"{x:1142,y:712,t:1527613838669};\\\", \\\"{x:1143,y:718,t:1527613838687};\\\", \\\"{x:1145,y:722,t:1527613838703};\\\", \\\"{x:1146,y:723,t:1527613838720};\\\", \\\"{x:1146,y:724,t:1527613838739};\\\", \\\"{x:1147,y:725,t:1527613838754};\\\", \\\"{x:1150,y:728,t:1527613838771};\\\", \\\"{x:1153,y:731,t:1527613838787};\\\", \\\"{x:1156,y:733,t:1527613838803};\\\", \\\"{x:1157,y:736,t:1527613838821};\\\", \\\"{x:1158,y:737,t:1527613838837};\\\", \\\"{x:1159,y:740,t:1527613838854};\\\", \\\"{x:1160,y:744,t:1527613838871};\\\", \\\"{x:1163,y:751,t:1527613838888};\\\", \\\"{x:1165,y:758,t:1527613838904};\\\", \\\"{x:1167,y:762,t:1527613838921};\\\", \\\"{x:1168,y:763,t:1527613838938};\\\", \\\"{x:1169,y:765,t:1527613838955};\\\", \\\"{x:1170,y:766,t:1527613838971};\\\", \\\"{x:1170,y:767,t:1527613838988};\\\", \\\"{x:1172,y:767,t:1527613839164};\\\", \\\"{x:1174,y:767,t:1527613839172};\\\", \\\"{x:1176,y:765,t:1527613839188};\\\", \\\"{x:1177,y:764,t:1527613839205};\\\", \\\"{x:1179,y:762,t:1527613839221};\\\", \\\"{x:1180,y:762,t:1527613839238};\\\", \\\"{x:1180,y:761,t:1527613839484};\\\", \\\"{x:1180,y:760,t:1527613840812};\\\", \\\"{x:1182,y:760,t:1527613840825};\\\", \\\"{x:1186,y:760,t:1527613840842};\\\", \\\"{x:1189,y:760,t:1527613840860};\\\", \\\"{x:1192,y:761,t:1527613840875};\\\", \\\"{x:1193,y:761,t:1527613840900};\\\", \\\"{x:1194,y:761,t:1527613840948};\\\", \\\"{x:1196,y:761,t:1527613840963};\\\", \\\"{x:1198,y:761,t:1527613840979};\\\", \\\"{x:1200,y:761,t:1527613840992};\\\", \\\"{x:1202,y:759,t:1527613841008};\\\", \\\"{x:1203,y:758,t:1527613841025};\\\", \\\"{x:1206,y:757,t:1527613841042};\\\", \\\"{x:1207,y:756,t:1527613841058};\\\", \\\"{x:1210,y:754,t:1527613841075};\\\", \\\"{x:1211,y:753,t:1527613841093};\\\", \\\"{x:1211,y:752,t:1527613841109};\\\", \\\"{x:1212,y:752,t:1527613841139};\\\", \\\"{x:1214,y:752,t:1527613841268};\\\", \\\"{x:1218,y:756,t:1527613841276};\\\", \\\"{x:1221,y:762,t:1527613841293};\\\", \\\"{x:1226,y:768,t:1527613841310};\\\", \\\"{x:1228,y:770,t:1527613841327};\\\", \\\"{x:1229,y:770,t:1527613841343};\\\", \\\"{x:1230,y:770,t:1527613841364};\\\", \\\"{x:1231,y:770,t:1527613841377};\\\", \\\"{x:1234,y:770,t:1527613841393};\\\", \\\"{x:1238,y:770,t:1527613841411};\\\", \\\"{x:1242,y:769,t:1527613841428};\\\", \\\"{x:1245,y:768,t:1527613841443};\\\", \\\"{x:1251,y:765,t:1527613841460};\\\", \\\"{x:1254,y:764,t:1527613841477};\\\", \\\"{x:1258,y:762,t:1527613841493};\\\", \\\"{x:1261,y:761,t:1527613841510};\\\", \\\"{x:1265,y:759,t:1527613841527};\\\", \\\"{x:1267,y:757,t:1527613841544};\\\", \\\"{x:1270,y:754,t:1527613841560};\\\", \\\"{x:1275,y:751,t:1527613841577};\\\", \\\"{x:1278,y:749,t:1527613841594};\\\", \\\"{x:1281,y:747,t:1527613841610};\\\", \\\"{x:1282,y:746,t:1527613841628};\\\", \\\"{x:1284,y:744,t:1527613841644};\\\", \\\"{x:1285,y:743,t:1527613841660};\\\", \\\"{x:1287,y:741,t:1527613841692};\\\", \\\"{x:1289,y:742,t:1527613841853};\\\", \\\"{x:1292,y:747,t:1527613841861};\\\", \\\"{x:1296,y:752,t:1527613841878};\\\", \\\"{x:1300,y:760,t:1527613841894};\\\", \\\"{x:1303,y:766,t:1527613841911};\\\", \\\"{x:1306,y:771,t:1527613841928};\\\", \\\"{x:1308,y:773,t:1527613841948};\\\", \\\"{x:1309,y:774,t:1527613841972};\\\", \\\"{x:1309,y:775,t:1527613841981};\\\", \\\"{x:1312,y:777,t:1527613841996};\\\", \\\"{x:1316,y:779,t:1527613842012};\\\", \\\"{x:1329,y:783,t:1527613842028};\\\", \\\"{x:1338,y:787,t:1527613842045};\\\", \\\"{x:1347,y:790,t:1527613842061};\\\", \\\"{x:1352,y:791,t:1527613842078};\\\", \\\"{x:1353,y:791,t:1527613842096};\\\", \\\"{x:1355,y:791,t:1527613842111};\\\", \\\"{x:1355,y:789,t:1527613842148};\\\", \\\"{x:1357,y:787,t:1527613842163};\\\", \\\"{x:1358,y:786,t:1527613842178};\\\", \\\"{x:1361,y:782,t:1527613842195};\\\", \\\"{x:1362,y:780,t:1527613842211};\\\", \\\"{x:1363,y:777,t:1527613842228};\\\", \\\"{x:1363,y:773,t:1527613842244};\\\", \\\"{x:1363,y:772,t:1527613842262};\\\", \\\"{x:1363,y:769,t:1527613842279};\\\", \\\"{x:1363,y:766,t:1527613842295};\\\", \\\"{x:1363,y:765,t:1527613842311};\\\", \\\"{x:1363,y:763,t:1527613842328};\\\", \\\"{x:1363,y:761,t:1527613842345};\\\", \\\"{x:1363,y:760,t:1527613842361};\\\", \\\"{x:1363,y:759,t:1527613842379};\\\", \\\"{x:1363,y:758,t:1527613842395};\\\", \\\"{x:1363,y:757,t:1527613842412};\\\", \\\"{x:1358,y:758,t:1527613843788};\\\", \\\"{x:1351,y:762,t:1527613843800};\\\", \\\"{x:1336,y:769,t:1527613843815};\\\", \\\"{x:1318,y:779,t:1527613843831};\\\", \\\"{x:1301,y:788,t:1527613843849};\\\", \\\"{x:1289,y:795,t:1527613843864};\\\", \\\"{x:1286,y:797,t:1527613843882};\\\", \\\"{x:1285,y:799,t:1527613843899};\\\", \\\"{x:1280,y:809,t:1527613843915};\\\", \\\"{x:1275,y:825,t:1527613843932};\\\", \\\"{x:1271,y:841,t:1527613843949};\\\", \\\"{x:1269,y:856,t:1527613843965};\\\", \\\"{x:1264,y:868,t:1527613843982};\\\", \\\"{x:1263,y:877,t:1527613843999};\\\", \\\"{x:1262,y:881,t:1527613844016};\\\", \\\"{x:1262,y:882,t:1527613844032};\\\", \\\"{x:1261,y:882,t:1527613844049};\\\", \\\"{x:1261,y:883,t:1527613844066};\\\", \\\"{x:1256,y:884,t:1527613844084};\\\", \\\"{x:1252,y:884,t:1527613844099};\\\", \\\"{x:1235,y:882,t:1527613844115};\\\", \\\"{x:1225,y:877,t:1527613844133};\\\", \\\"{x:1216,y:872,t:1527613844149};\\\", \\\"{x:1214,y:871,t:1527613844166};\\\", \\\"{x:1213,y:871,t:1527613844188};\\\", \\\"{x:1212,y:869,t:1527613844204};\\\", \\\"{x:1212,y:868,t:1527613844216};\\\", \\\"{x:1212,y:866,t:1527613844233};\\\", \\\"{x:1212,y:863,t:1527613844249};\\\", \\\"{x:1213,y:857,t:1527613844266};\\\", \\\"{x:1214,y:853,t:1527613844283};\\\", \\\"{x:1217,y:847,t:1527613844300};\\\", \\\"{x:1218,y:844,t:1527613844315};\\\", \\\"{x:1220,y:840,t:1527613844332};\\\", \\\"{x:1221,y:839,t:1527613844350};\\\", \\\"{x:1221,y:837,t:1527613844366};\\\", \\\"{x:1223,y:834,t:1527613844383};\\\", \\\"{x:1223,y:833,t:1527613844400};\\\", \\\"{x:1224,y:833,t:1527613845212};\\\", \\\"{x:1225,y:835,t:1527613845228};\\\", \\\"{x:1227,y:836,t:1527613845236};\\\", \\\"{x:1227,y:837,t:1527613845251};\\\", \\\"{x:1229,y:838,t:1527613845270};\\\", \\\"{x:1230,y:838,t:1527613845292};\\\", \\\"{x:1230,y:839,t:1527613845308};\\\", \\\"{x:1231,y:839,t:1527613845340};\\\", \\\"{x:1233,y:839,t:1527613845356};\\\", \\\"{x:1234,y:839,t:1527613845372};\\\", \\\"{x:1236,y:839,t:1527613845386};\\\", \\\"{x:1238,y:838,t:1527613845402};\\\", \\\"{x:1241,y:833,t:1527613845419};\\\", \\\"{x:1244,y:830,t:1527613845436};\\\", \\\"{x:1245,y:829,t:1527613845452};\\\", \\\"{x:1246,y:828,t:1527613845470};\\\", \\\"{x:1246,y:827,t:1527613845500};\\\", \\\"{x:1248,y:827,t:1527613845596};\\\", \\\"{x:1248,y:830,t:1527613845604};\\\", \\\"{x:1252,y:835,t:1527613845619};\\\", \\\"{x:1259,y:844,t:1527613845636};\\\", \\\"{x:1270,y:851,t:1527613845652};\\\", \\\"{x:1283,y:856,t:1527613845670};\\\", \\\"{x:1293,y:856,t:1527613845686};\\\", \\\"{x:1297,y:856,t:1527613845702};\\\", \\\"{x:1301,y:855,t:1527613845720};\\\", \\\"{x:1302,y:855,t:1527613845736};\\\", \\\"{x:1302,y:853,t:1527613845755};\\\", \\\"{x:1302,y:848,t:1527613845770};\\\", \\\"{x:1307,y:837,t:1527613845786};\\\", \\\"{x:1311,y:826,t:1527613845803};\\\", \\\"{x:1315,y:816,t:1527613845820};\\\", \\\"{x:1316,y:814,t:1527613845837};\\\", \\\"{x:1317,y:813,t:1527613845854};\\\", \\\"{x:1317,y:812,t:1527613845883};\\\", \\\"{x:1317,y:811,t:1527613846003};\\\", \\\"{x:1286,y:807,t:1527613846020};\\\", \\\"{x:1181,y:795,t:1527613846037};\\\", \\\"{x:1023,y:766,t:1527613846054};\\\", \\\"{x:832,y:739,t:1527613846070};\\\", \\\"{x:628,y:709,t:1527613846087};\\\", \\\"{x:475,y:687,t:1527613846104};\\\", \\\"{x:373,y:674,t:1527613846121};\\\", \\\"{x:339,y:670,t:1527613846137};\\\", \\\"{x:330,y:670,t:1527613846154};\\\", \\\"{x:329,y:670,t:1527613846227};\\\", \\\"{x:325,y:675,t:1527613846236};\\\", \\\"{x:320,y:694,t:1527613846253};\\\", \\\"{x:318,y:716,t:1527613846270};\\\", \\\"{x:315,y:733,t:1527613846288};\\\", \\\"{x:318,y:743,t:1527613846304};\\\", \\\"{x:325,y:747,t:1527613846320};\\\", \\\"{x:342,y:749,t:1527613846338};\\\", \\\"{x:370,y:754,t:1527613846353};\\\", \\\"{x:432,y:762,t:1527613846371};\\\", \\\"{x:485,y:771,t:1527613846388};\\\", \\\"{x:533,y:777,t:1527613846405};\\\", \\\"{x:562,y:777,t:1527613846421};\\\", \\\"{x:576,y:781,t:1527613846438};\\\", \\\"{x:580,y:781,t:1527613846455};\\\", \\\"{x:580,y:780,t:1527613846612};\\\", \\\"{x:580,y:779,t:1527613846622};\\\", \\\"{x:580,y:778,t:1527613846638};\\\", \\\"{x:577,y:775,t:1527613846655};\\\", \\\"{x:575,y:773,t:1527613846673};\\\", \\\"{x:569,y:770,t:1527613846689};\\\", \\\"{x:565,y:769,t:1527613846705};\\\", \\\"{x:560,y:766,t:1527613846722};\\\", \\\"{x:557,y:763,t:1527613846739};\\\", \\\"{x:555,y:762,t:1527613846755};\\\", \\\"{x:553,y:760,t:1527613846772};\\\", \\\"{x:548,y:758,t:1527613846789};\\\", \\\"{x:544,y:755,t:1527613846805};\\\", \\\"{x:542,y:754,t:1527613846823};\\\", \\\"{x:541,y:753,t:1527613846839};\\\", \\\"{x:540,y:752,t:1527613846856};\\\", \\\"{x:539,y:752,t:1527613846915};\\\", \\\"{x:538,y:751,t:1527613846926};\\\", \\\"{x:537,y:749,t:1527613846943};\\\", \\\"{x:535,y:749,t:1527613846958};\\\", \\\"{x:535,y:748,t:1527613846987};\\\", \\\"{x:534,y:747,t:1527613847027};\\\", \\\"{x:534,y:746,t:1527613847051};\\\", \\\"{x:533,y:746,t:1527613847076};\\\", \\\"{x:533,y:744,t:1527613847132};\\\", \\\"{x:533,y:743,t:1527613847196};\\\", \\\"{x:533,y:741,t:1527613847235};\\\" ] }, { \\\"rt\\\": 50613, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 500298, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-B -I -09 AM-J -J -I -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:730,t:1527613850084};\\\", \\\"{x:533,y:691,t:1527613850104};\\\", \\\"{x:528,y:681,t:1527613850114};\\\", \\\"{x:520,y:649,t:1527613850130};\\\", \\\"{x:516,y:638,t:1527613850145};\\\", \\\"{x:512,y:625,t:1527613850163};\\\", \\\"{x:506,y:612,t:1527613850178};\\\", \\\"{x:499,y:599,t:1527613850195};\\\", \\\"{x:497,y:594,t:1527613850212};\\\", \\\"{x:496,y:591,t:1527613850229};\\\", \\\"{x:495,y:588,t:1527613850245};\\\", \\\"{x:494,y:586,t:1527613850262};\\\", \\\"{x:494,y:585,t:1527613850279};\\\", \\\"{x:493,y:583,t:1527613850314};\\\", \\\"{x:492,y:582,t:1527613850404};\\\", \\\"{x:491,y:581,t:1527613850419};\\\", \\\"{x:490,y:581,t:1527613850436};\\\", \\\"{x:490,y:580,t:1527613850445};\\\", \\\"{x:488,y:579,t:1527613850462};\\\", \\\"{x:487,y:578,t:1527613850479};\\\", \\\"{x:483,y:576,t:1527613850496};\\\", \\\"{x:480,y:575,t:1527613850512};\\\", \\\"{x:476,y:573,t:1527613850529};\\\", \\\"{x:474,y:572,t:1527613850545};\\\", \\\"{x:471,y:571,t:1527613850562};\\\", \\\"{x:466,y:568,t:1527613850579};\\\", \\\"{x:462,y:565,t:1527613850595};\\\", \\\"{x:455,y:562,t:1527613850613};\\\", \\\"{x:447,y:559,t:1527613850629};\\\", \\\"{x:435,y:554,t:1527613850645};\\\", \\\"{x:421,y:550,t:1527613850662};\\\", \\\"{x:404,y:544,t:1527613850679};\\\", \\\"{x:388,y:540,t:1527613850696};\\\", \\\"{x:374,y:537,t:1527613850711};\\\", \\\"{x:358,y:534,t:1527613850729};\\\", \\\"{x:346,y:529,t:1527613850746};\\\", \\\"{x:335,y:527,t:1527613850762};\\\", \\\"{x:319,y:523,t:1527613850779};\\\", \\\"{x:305,y:520,t:1527613850795};\\\", \\\"{x:294,y:518,t:1527613850812};\\\", \\\"{x:284,y:517,t:1527613850830};\\\", \\\"{x:277,y:516,t:1527613850845};\\\", \\\"{x:272,y:516,t:1527613850862};\\\", \\\"{x:270,y:515,t:1527613850879};\\\", \\\"{x:269,y:515,t:1527613851027};\\\", \\\"{x:268,y:515,t:1527613851772};\\\", \\\"{x:267,y:516,t:1527613857251};\\\", \\\"{x:338,y:619,t:1527613857267};\\\", \\\"{x:501,y:720,t:1527613857284};\\\", \\\"{x:685,y:800,t:1527613857300};\\\", \\\"{x:799,y:836,t:1527613857310};\\\", \\\"{x:1013,y:885,t:1527613857327};\\\", \\\"{x:1243,y:927,t:1527613857343};\\\", \\\"{x:1429,y:961,t:1527613857360};\\\", \\\"{x:1554,y:982,t:1527613857377};\\\", \\\"{x:1604,y:986,t:1527613857393};\\\", \\\"{x:1611,y:986,t:1527613857410};\\\", \\\"{x:1610,y:986,t:1527613857466};\\\", \\\"{x:1608,y:986,t:1527613857477};\\\", \\\"{x:1606,y:984,t:1527613857493};\\\", \\\"{x:1599,y:979,t:1527613857510};\\\", \\\"{x:1585,y:970,t:1527613857527};\\\", \\\"{x:1563,y:956,t:1527613857543};\\\", \\\"{x:1527,y:935,t:1527613857560};\\\", \\\"{x:1444,y:901,t:1527613857577};\\\", \\\"{x:1348,y:861,t:1527613857593};\\\", \\\"{x:1255,y:821,t:1527613857610};\\\", \\\"{x:1138,y:777,t:1527613857627};\\\", \\\"{x:1089,y:758,t:1527613857643};\\\", \\\"{x:1057,y:746,t:1527613857661};\\\", \\\"{x:1047,y:744,t:1527613857677};\\\", \\\"{x:1046,y:743,t:1527613857693};\\\", \\\"{x:1045,y:743,t:1527613857730};\\\", \\\"{x:1047,y:743,t:1527613857885};\\\", \\\"{x:1052,y:743,t:1527613857894};\\\", \\\"{x:1069,y:750,t:1527613857910};\\\", \\\"{x:1081,y:755,t:1527613857927};\\\", \\\"{x:1091,y:764,t:1527613857944};\\\", \\\"{x:1094,y:768,t:1527613857960};\\\", \\\"{x:1094,y:770,t:1527613857977};\\\", \\\"{x:1094,y:771,t:1527613858052};\\\", \\\"{x:1099,y:771,t:1527613858075};\\\", \\\"{x:1123,y:772,t:1527613858094};\\\", \\\"{x:1140,y:772,t:1527613858110};\\\", \\\"{x:1152,y:772,t:1527613858127};\\\", \\\"{x:1165,y:772,t:1527613858144};\\\", \\\"{x:1181,y:772,t:1527613858161};\\\", \\\"{x:1191,y:774,t:1527613858176};\\\", \\\"{x:1199,y:776,t:1527613858194};\\\", \\\"{x:1206,y:778,t:1527613858211};\\\", \\\"{x:1209,y:779,t:1527613858226};\\\", \\\"{x:1222,y:788,t:1527613858243};\\\", \\\"{x:1230,y:794,t:1527613858261};\\\", \\\"{x:1234,y:798,t:1527613858277};\\\", \\\"{x:1235,y:799,t:1527613858293};\\\", \\\"{x:1236,y:802,t:1527613858315};\\\", \\\"{x:1236,y:804,t:1527613858327};\\\", \\\"{x:1236,y:819,t:1527613858344};\\\", \\\"{x:1235,y:827,t:1527613858360};\\\", \\\"{x:1230,y:839,t:1527613858377};\\\", \\\"{x:1227,y:846,t:1527613858394};\\\", \\\"{x:1224,y:851,t:1527613858411};\\\", \\\"{x:1221,y:853,t:1527613858427};\\\", \\\"{x:1216,y:857,t:1527613858444};\\\", \\\"{x:1214,y:859,t:1527613858461};\\\", \\\"{x:1213,y:860,t:1527613858499};\\\", \\\"{x:1212,y:860,t:1527613858515};\\\", \\\"{x:1211,y:860,t:1527613858586};\\\", \\\"{x:1210,y:859,t:1527613858603};\\\", \\\"{x:1210,y:857,t:1527613858610};\\\", \\\"{x:1209,y:856,t:1527613858626};\\\", \\\"{x:1208,y:854,t:1527613858642};\\\", \\\"{x:1208,y:853,t:1527613858660};\\\", \\\"{x:1208,y:852,t:1527613858683};\\\", \\\"{x:1208,y:851,t:1527613858693};\\\", \\\"{x:1208,y:848,t:1527613858709};\\\", \\\"{x:1208,y:847,t:1527613858731};\\\", \\\"{x:1208,y:844,t:1527613858747};\\\", \\\"{x:1208,y:843,t:1527613858844};\\\", \\\"{x:1208,y:841,t:1527613858876};\\\", \\\"{x:1208,y:840,t:1527613858932};\\\", \\\"{x:1208,y:839,t:1527613861196};\\\", \\\"{x:1208,y:837,t:1527613861276};\\\", \\\"{x:1204,y:827,t:1527613861293};\\\", \\\"{x:1203,y:824,t:1527613861309};\\\", \\\"{x:1201,y:819,t:1527613861325};\\\", \\\"{x:1200,y:817,t:1527613861342};\\\", \\\"{x:1200,y:816,t:1527613861360};\\\", \\\"{x:1199,y:815,t:1527613861375};\\\", \\\"{x:1199,y:813,t:1527613861392};\\\", \\\"{x:1198,y:813,t:1527613861408};\\\", \\\"{x:1198,y:812,t:1527613861425};\\\", \\\"{x:1197,y:808,t:1527613861442};\\\", \\\"{x:1196,y:806,t:1527613861459};\\\", \\\"{x:1195,y:805,t:1527613861475};\\\", \\\"{x:1194,y:802,t:1527613861507};\\\", \\\"{x:1194,y:801,t:1527613861548};\\\", \\\"{x:1194,y:800,t:1527613861559};\\\", \\\"{x:1192,y:798,t:1527613861576};\\\", \\\"{x:1191,y:797,t:1527613861595};\\\", \\\"{x:1191,y:796,t:1527613861611};\\\", \\\"{x:1190,y:795,t:1527613861626};\\\", \\\"{x:1190,y:794,t:1527613861651};\\\", \\\"{x:1188,y:791,t:1527613861659};\\\", \\\"{x:1188,y:790,t:1527613861676};\\\", \\\"{x:1186,y:789,t:1527613861693};\\\", \\\"{x:1186,y:788,t:1527613861709};\\\", \\\"{x:1185,y:786,t:1527613861726};\\\", \\\"{x:1185,y:785,t:1527613861743};\\\", \\\"{x:1183,y:782,t:1527613861759};\\\", \\\"{x:1182,y:780,t:1527613861776};\\\", \\\"{x:1181,y:780,t:1527613861793};\\\", \\\"{x:1181,y:779,t:1527613861852};\\\", \\\"{x:1180,y:778,t:1527613861972};\\\", \\\"{x:1180,y:777,t:1527613861980};\\\", \\\"{x:1180,y:776,t:1527613862020};\\\", \\\"{x:1179,y:775,t:1527613862027};\\\", \\\"{x:1178,y:774,t:1527613862060};\\\", \\\"{x:1178,y:773,t:1527613862100};\\\", \\\"{x:1178,y:771,t:1527613862115};\\\", \\\"{x:1177,y:770,t:1527613862126};\\\", \\\"{x:1176,y:769,t:1527613862143};\\\", \\\"{x:1174,y:767,t:1527613862159};\\\", \\\"{x:1173,y:764,t:1527613862176};\\\", \\\"{x:1172,y:763,t:1527613862252};\\\", \\\"{x:1173,y:765,t:1527613867371};\\\", \\\"{x:1174,y:769,t:1527613867378};\\\", \\\"{x:1177,y:774,t:1527613867391};\\\", \\\"{x:1182,y:779,t:1527613867406};\\\", \\\"{x:1184,y:782,t:1527613867423};\\\", \\\"{x:1185,y:784,t:1527613867440};\\\", \\\"{x:1186,y:784,t:1527613867499};\\\", \\\"{x:1188,y:784,t:1527613867514};\\\", \\\"{x:1191,y:784,t:1527613867523};\\\", \\\"{x:1203,y:780,t:1527613867541};\\\", \\\"{x:1209,y:777,t:1527613867557};\\\", \\\"{x:1211,y:777,t:1527613867574};\\\", \\\"{x:1213,y:775,t:1527613867590};\\\", \\\"{x:1214,y:775,t:1527613867607};\\\", \\\"{x:1215,y:775,t:1527613867623};\\\", \\\"{x:1216,y:774,t:1527613867640};\\\", \\\"{x:1217,y:774,t:1527613867755};\\\", \\\"{x:1220,y:779,t:1527613867763};\\\", \\\"{x:1222,y:784,t:1527613867773};\\\", \\\"{x:1226,y:790,t:1527613867790};\\\", \\\"{x:1229,y:793,t:1527613867807};\\\", \\\"{x:1231,y:793,t:1527613867843};\\\", \\\"{x:1232,y:793,t:1527613867856};\\\", \\\"{x:1235,y:793,t:1527613867874};\\\", \\\"{x:1238,y:793,t:1527613867890};\\\", \\\"{x:1243,y:792,t:1527613867907};\\\", \\\"{x:1249,y:789,t:1527613867923};\\\", \\\"{x:1250,y:788,t:1527613867940};\\\", \\\"{x:1253,y:786,t:1527613867957};\\\", \\\"{x:1255,y:785,t:1527613867974};\\\", \\\"{x:1256,y:784,t:1527613867991};\\\", \\\"{x:1257,y:783,t:1527613868019};\\\", \\\"{x:1258,y:782,t:1527613868107};\\\", \\\"{x:1258,y:780,t:1527613868124};\\\", \\\"{x:1259,y:778,t:1527613868140};\\\", \\\"{x:1259,y:777,t:1527613868157};\\\", \\\"{x:1259,y:776,t:1527613868174};\\\", \\\"{x:1259,y:774,t:1527613868190};\\\", \\\"{x:1260,y:773,t:1527613868207};\\\", \\\"{x:1260,y:771,t:1527613868227};\\\", \\\"{x:1261,y:771,t:1527613868240};\\\", \\\"{x:1261,y:768,t:1527613868257};\\\", \\\"{x:1262,y:767,t:1527613868274};\\\", \\\"{x:1262,y:766,t:1527613868290};\\\", \\\"{x:1263,y:765,t:1527613868307};\\\", \\\"{x:1263,y:764,t:1527613868324};\\\", \\\"{x:1263,y:763,t:1527613868404};\\\", \\\"{x:1264,y:763,t:1527613868412};\\\", \\\"{x:1264,y:762,t:1527613868451};\\\", \\\"{x:1265,y:765,t:1527613870978};\\\", \\\"{x:1267,y:768,t:1527613870988};\\\", \\\"{x:1270,y:773,t:1527613871005};\\\", \\\"{x:1272,y:777,t:1527613871023};\\\", \\\"{x:1272,y:778,t:1527613871043};\\\", \\\"{x:1273,y:778,t:1527613871090};\\\", \\\"{x:1273,y:779,t:1527613871178};\\\", \\\"{x:1274,y:779,t:1527613871195};\\\", \\\"{x:1275,y:780,t:1527613871205};\\\", \\\"{x:1282,y:784,t:1527613871222};\\\", \\\"{x:1289,y:788,t:1527613871239};\\\", \\\"{x:1293,y:789,t:1527613871256};\\\", \\\"{x:1295,y:790,t:1527613871272};\\\", \\\"{x:1296,y:791,t:1527613871289};\\\", \\\"{x:1297,y:791,t:1527613871306};\\\", \\\"{x:1299,y:791,t:1527613871322};\\\", \\\"{x:1304,y:791,t:1527613871338};\\\", \\\"{x:1317,y:791,t:1527613871355};\\\", \\\"{x:1329,y:786,t:1527613871371};\\\", \\\"{x:1336,y:783,t:1527613871389};\\\", \\\"{x:1341,y:781,t:1527613871406};\\\", \\\"{x:1343,y:779,t:1527613871422};\\\", \\\"{x:1344,y:779,t:1527613871439};\\\", \\\"{x:1346,y:778,t:1527613871455};\\\", \\\"{x:1347,y:777,t:1527613871472};\\\", \\\"{x:1348,y:776,t:1527613871506};\\\", \\\"{x:1349,y:776,t:1527613871522};\\\", \\\"{x:1350,y:775,t:1527613871538};\\\", \\\"{x:1351,y:774,t:1527613871555};\\\", \\\"{x:1352,y:771,t:1527613871572};\\\", \\\"{x:1354,y:768,t:1527613871588};\\\", \\\"{x:1355,y:766,t:1527613871605};\\\", \\\"{x:1356,y:764,t:1527613871622};\\\", \\\"{x:1357,y:764,t:1527613871638};\\\", \\\"{x:1357,y:762,t:1527613871656};\\\", \\\"{x:1357,y:761,t:1527613871672};\\\", \\\"{x:1357,y:759,t:1527613871688};\\\", \\\"{x:1358,y:756,t:1527613871706};\\\", \\\"{x:1359,y:754,t:1527613871722};\\\", \\\"{x:1360,y:752,t:1527613871739};\\\", \\\"{x:1360,y:751,t:1527613871762};\\\", \\\"{x:1360,y:750,t:1527613871810};\\\", \\\"{x:1359,y:749,t:1527613872387};\\\", \\\"{x:1355,y:748,t:1527613872395};\\\", \\\"{x:1349,y:747,t:1527613872406};\\\", \\\"{x:1341,y:742,t:1527613872423};\\\", \\\"{x:1338,y:741,t:1527613872439};\\\", \\\"{x:1336,y:740,t:1527613872455};\\\", \\\"{x:1335,y:740,t:1527613872484};\\\", \\\"{x:1334,y:740,t:1527613872531};\\\", \\\"{x:1333,y:739,t:1527613872547};\\\", \\\"{x:1332,y:739,t:1527613872571};\\\", \\\"{x:1331,y:739,t:1527613872589};\\\", \\\"{x:1328,y:739,t:1527613872605};\\\", \\\"{x:1324,y:737,t:1527613872622};\\\", \\\"{x:1318,y:735,t:1527613872639};\\\", \\\"{x:1312,y:733,t:1527613872656};\\\", \\\"{x:1306,y:733,t:1527613872672};\\\", \\\"{x:1300,y:733,t:1527613872689};\\\", \\\"{x:1281,y:733,t:1527613872705};\\\", \\\"{x:1241,y:735,t:1527613872722};\\\", \\\"{x:1176,y:744,t:1527613872740};\\\", \\\"{x:1151,y:747,t:1527613872756};\\\", \\\"{x:1130,y:748,t:1527613872772};\\\", \\\"{x:1114,y:749,t:1527613872789};\\\", \\\"{x:1104,y:749,t:1527613872806};\\\", \\\"{x:1099,y:749,t:1527613872822};\\\", \\\"{x:1098,y:749,t:1527613872840};\\\", \\\"{x:1098,y:750,t:1527613873044};\\\", \\\"{x:1101,y:750,t:1527613873075};\\\", \\\"{x:1104,y:748,t:1527613873089};\\\", \\\"{x:1110,y:745,t:1527613873105};\\\", \\\"{x:1116,y:742,t:1527613873122};\\\", \\\"{x:1120,y:738,t:1527613873138};\\\", \\\"{x:1125,y:737,t:1527613873155};\\\", \\\"{x:1128,y:733,t:1527613873172};\\\", \\\"{x:1132,y:728,t:1527613873189};\\\", \\\"{x:1137,y:722,t:1527613873205};\\\", \\\"{x:1140,y:718,t:1527613873222};\\\", \\\"{x:1144,y:713,t:1527613873238};\\\", \\\"{x:1148,y:707,t:1527613873255};\\\", \\\"{x:1151,y:704,t:1527613873272};\\\", \\\"{x:1153,y:699,t:1527613873288};\\\", \\\"{x:1156,y:694,t:1527613873305};\\\", \\\"{x:1160,y:687,t:1527613873321};\\\", \\\"{x:1163,y:684,t:1527613873338};\\\", \\\"{x:1168,y:676,t:1527613873354};\\\", \\\"{x:1173,y:672,t:1527613873371};\\\", \\\"{x:1177,y:669,t:1527613873388};\\\", \\\"{x:1187,y:665,t:1527613873405};\\\", \\\"{x:1189,y:664,t:1527613873422};\\\", \\\"{x:1190,y:663,t:1527613873438};\\\", \\\"{x:1192,y:661,t:1527613873455};\\\", \\\"{x:1193,y:661,t:1527613873472};\\\", \\\"{x:1194,y:660,t:1527613873488};\\\", \\\"{x:1197,y:658,t:1527613873505};\\\", \\\"{x:1200,y:653,t:1527613873522};\\\", \\\"{x:1202,y:651,t:1527613873538};\\\", \\\"{x:1209,y:645,t:1527613873555};\\\", \\\"{x:1214,y:641,t:1527613873572};\\\", \\\"{x:1217,y:639,t:1527613873589};\\\", \\\"{x:1218,y:639,t:1527613873605};\\\", \\\"{x:1220,y:638,t:1527613873622};\\\", \\\"{x:1220,y:637,t:1527613873638};\\\", \\\"{x:1219,y:639,t:1527613873755};\\\", \\\"{x:1213,y:667,t:1527613873771};\\\", \\\"{x:1211,y:696,t:1527613873789};\\\", \\\"{x:1206,y:720,t:1527613873805};\\\", \\\"{x:1204,y:738,t:1527613873821};\\\", \\\"{x:1203,y:746,t:1527613873839};\\\", \\\"{x:1203,y:751,t:1527613873855};\\\", \\\"{x:1203,y:753,t:1527613873872};\\\", \\\"{x:1203,y:758,t:1527613873889};\\\", \\\"{x:1203,y:762,t:1527613873905};\\\", \\\"{x:1203,y:766,t:1527613873920};\\\", \\\"{x:1203,y:771,t:1527613873937};\\\", \\\"{x:1203,y:784,t:1527613873954};\\\", \\\"{x:1206,y:801,t:1527613873970};\\\", \\\"{x:1209,y:820,t:1527613873988};\\\", \\\"{x:1210,y:839,t:1527613874005};\\\", \\\"{x:1212,y:857,t:1527613874021};\\\", \\\"{x:1212,y:874,t:1527613874038};\\\", \\\"{x:1212,y:886,t:1527613874055};\\\", \\\"{x:1212,y:897,t:1527613874071};\\\", \\\"{x:1212,y:910,t:1527613874089};\\\", \\\"{x:1212,y:921,t:1527613874105};\\\", \\\"{x:1212,y:932,t:1527613874121};\\\", \\\"{x:1210,y:937,t:1527613874138};\\\", \\\"{x:1209,y:942,t:1527613874155};\\\", \\\"{x:1209,y:943,t:1527613874172};\\\", \\\"{x:1208,y:944,t:1527613874252};\\\", \\\"{x:1208,y:947,t:1527613874267};\\\", \\\"{x:1208,y:948,t:1527613874275};\\\", \\\"{x:1208,y:950,t:1527613874288};\\\", \\\"{x:1208,y:953,t:1527613874306};\\\", \\\"{x:1208,y:956,t:1527613874321};\\\", \\\"{x:1208,y:957,t:1527613874338};\\\", \\\"{x:1208,y:959,t:1527613874356};\\\", \\\"{x:1207,y:960,t:1527613874444};\\\", \\\"{x:1206,y:962,t:1527613874459};\\\", \\\"{x:1202,y:965,t:1527613874471};\\\", \\\"{x:1193,y:975,t:1527613874488};\\\", \\\"{x:1185,y:982,t:1527613874506};\\\", \\\"{x:1182,y:984,t:1527613874521};\\\", \\\"{x:1179,y:986,t:1527613874538};\\\", \\\"{x:1178,y:987,t:1527613874555};\\\", \\\"{x:1176,y:987,t:1527613874652};\\\", \\\"{x:1174,y:987,t:1527613874795};\\\", \\\"{x:1172,y:986,t:1527613874852};\\\", \\\"{x:1171,y:984,t:1527613874883};\\\", \\\"{x:1171,y:982,t:1527613874892};\\\", \\\"{x:1168,y:977,t:1527613874904};\\\", \\\"{x:1162,y:963,t:1527613874922};\\\", \\\"{x:1143,y:940,t:1527613874939};\\\", \\\"{x:1097,y:897,t:1527613874954};\\\", \\\"{x:963,y:814,t:1527613874972};\\\", \\\"{x:829,y:747,t:1527613874989};\\\", \\\"{x:683,y:680,t:1527613875004};\\\", \\\"{x:534,y:613,t:1527613875022};\\\", \\\"{x:388,y:549,t:1527613875039};\\\", \\\"{x:247,y:488,t:1527613875054};\\\", \\\"{x:92,y:422,t:1527613875082};\\\", \\\"{x:17,y:389,t:1527613875098};\\\", \\\"{x:0,y:366,t:1527613875114};\\\", \\\"{x:0,y:360,t:1527613875131};\\\", \\\"{x:0,y:357,t:1527613875148};\\\", \\\"{x:7,y:357,t:1527613875259};\\\", \\\"{x:16,y:359,t:1527613875267};\\\", \\\"{x:25,y:363,t:1527613875281};\\\", \\\"{x:54,y:373,t:1527613875298};\\\", \\\"{x:87,y:384,t:1527613875314};\\\", \\\"{x:165,y:406,t:1527613875330};\\\", \\\"{x:218,y:421,t:1527613875347};\\\", \\\"{x:268,y:435,t:1527613875364};\\\", \\\"{x:302,y:446,t:1527613875381};\\\", \\\"{x:324,y:455,t:1527613875397};\\\", \\\"{x:340,y:461,t:1527613875414};\\\", \\\"{x:351,y:467,t:1527613875431};\\\", \\\"{x:360,y:472,t:1527613875447};\\\", \\\"{x:367,y:475,t:1527613875464};\\\", \\\"{x:376,y:479,t:1527613875481};\\\", \\\"{x:386,y:484,t:1527613875497};\\\", \\\"{x:396,y:489,t:1527613875516};\\\", \\\"{x:410,y:494,t:1527613875531};\\\", \\\"{x:418,y:498,t:1527613875548};\\\", \\\"{x:420,y:499,t:1527613875564};\\\", \\\"{x:415,y:498,t:1527613876812};\\\", \\\"{x:400,y:498,t:1527613876833};\\\", \\\"{x:385,y:498,t:1527613876849};\\\", \\\"{x:374,y:498,t:1527613876866};\\\", \\\"{x:364,y:498,t:1527613876882};\\\", \\\"{x:363,y:497,t:1527613877059};\\\", \\\"{x:362,y:497,t:1527613877067};\\\", \\\"{x:355,y:493,t:1527613877083};\\\", \\\"{x:346,y:492,t:1527613877100};\\\", \\\"{x:338,y:489,t:1527613877116};\\\", \\\"{x:335,y:488,t:1527613877133};\\\", \\\"{x:334,y:488,t:1527613877202};\\\", \\\"{x:334,y:487,t:1527613877218};\\\", \\\"{x:334,y:486,t:1527613877233};\\\", \\\"{x:334,y:484,t:1527613877250};\\\", \\\"{x:334,y:483,t:1527613877265};\\\", \\\"{x:334,y:480,t:1527613877282};\\\", \\\"{x:334,y:477,t:1527613877299};\\\", \\\"{x:334,y:475,t:1527613877316};\\\", \\\"{x:334,y:473,t:1527613877333};\\\", \\\"{x:334,y:470,t:1527613877348};\\\", \\\"{x:334,y:468,t:1527613877366};\\\", \\\"{x:334,y:467,t:1527613877383};\\\", \\\"{x:334,y:466,t:1527613877508};\\\", \\\"{x:334,y:465,t:1527613877547};\\\", \\\"{x:335,y:464,t:1527613877555};\\\", \\\"{x:337,y:463,t:1527613877587};\\\", \\\"{x:339,y:462,t:1527613877602};\\\", \\\"{x:340,y:462,t:1527613877616};\\\", \\\"{x:344,y:461,t:1527613877633};\\\", \\\"{x:350,y:460,t:1527613877649};\\\", \\\"{x:358,y:460,t:1527613877666};\\\", \\\"{x:369,y:460,t:1527613877683};\\\", \\\"{x:374,y:460,t:1527613877700};\\\", \\\"{x:376,y:460,t:1527613877716};\\\", \\\"{x:379,y:460,t:1527613877734};\\\", \\\"{x:382,y:462,t:1527613877749};\\\", \\\"{x:383,y:463,t:1527613877766};\\\", \\\"{x:385,y:463,t:1527613877795};\\\", \\\"{x:385,y:464,t:1527613877803};\\\", \\\"{x:386,y:464,t:1527613877816};\\\", \\\"{x:391,y:466,t:1527613877833};\\\", \\\"{x:397,y:468,t:1527613877849};\\\", \\\"{x:411,y:471,t:1527613877867};\\\", \\\"{x:418,y:471,t:1527613877883};\\\", \\\"{x:426,y:473,t:1527613877899};\\\", \\\"{x:432,y:473,t:1527613877916};\\\", \\\"{x:440,y:476,t:1527613877933};\\\", \\\"{x:446,y:476,t:1527613877949};\\\", \\\"{x:453,y:478,t:1527613877966};\\\", \\\"{x:461,y:480,t:1527613877983};\\\", \\\"{x:466,y:481,t:1527613877998};\\\", \\\"{x:473,y:483,t:1527613878016};\\\", \\\"{x:478,y:484,t:1527613878033};\\\", \\\"{x:479,y:484,t:1527613878049};\\\", \\\"{x:480,y:484,t:1527613878066};\\\", \\\"{x:482,y:484,t:1527613878083};\\\", \\\"{x:486,y:484,t:1527613878099};\\\", \\\"{x:490,y:484,t:1527613878116};\\\", \\\"{x:498,y:484,t:1527613878133};\\\", \\\"{x:506,y:484,t:1527613878149};\\\", \\\"{x:517,y:483,t:1527613878166};\\\", \\\"{x:527,y:482,t:1527613878183};\\\", \\\"{x:533,y:481,t:1527613878200};\\\", \\\"{x:540,y:480,t:1527613878217};\\\", \\\"{x:546,y:480,t:1527613878233};\\\", \\\"{x:551,y:480,t:1527613878249};\\\", \\\"{x:556,y:480,t:1527613878266};\\\", \\\"{x:561,y:479,t:1527613878283};\\\", \\\"{x:565,y:479,t:1527613878299};\\\", \\\"{x:570,y:479,t:1527613878316};\\\", \\\"{x:574,y:479,t:1527613878334};\\\", \\\"{x:578,y:479,t:1527613878349};\\\", \\\"{x:583,y:479,t:1527613878366};\\\", \\\"{x:589,y:479,t:1527613878383};\\\", \\\"{x:593,y:479,t:1527613878399};\\\", \\\"{x:599,y:479,t:1527613878417};\\\", \\\"{x:603,y:479,t:1527613878433};\\\", \\\"{x:606,y:479,t:1527613878449};\\\", \\\"{x:610,y:479,t:1527613878467};\\\", \\\"{x:616,y:480,t:1527613878483};\\\", \\\"{x:622,y:481,t:1527613878499};\\\", \\\"{x:632,y:483,t:1527613878516};\\\", \\\"{x:644,y:484,t:1527613878533};\\\", \\\"{x:653,y:486,t:1527613878549};\\\", \\\"{x:666,y:488,t:1527613878566};\\\", \\\"{x:677,y:489,t:1527613878583};\\\", \\\"{x:684,y:490,t:1527613878601};\\\", \\\"{x:686,y:490,t:1527613878627};\\\", \\\"{x:689,y:490,t:1527613878643};\\\", \\\"{x:693,y:492,t:1527613878660};\\\", \\\"{x:696,y:492,t:1527613878678};\\\", \\\"{x:702,y:492,t:1527613878694};\\\", \\\"{x:710,y:495,t:1527613878711};\\\", \\\"{x:721,y:497,t:1527613878728};\\\", \\\"{x:737,y:501,t:1527613878744};\\\", \\\"{x:758,y:508,t:1527613878761};\\\", \\\"{x:784,y:515,t:1527613878778};\\\", \\\"{x:826,y:530,t:1527613878795};\\\", \\\"{x:849,y:544,t:1527613878810};\\\", \\\"{x:870,y:553,t:1527613878828};\\\", \\\"{x:893,y:568,t:1527613878845};\\\", \\\"{x:909,y:582,t:1527613878861};\\\", \\\"{x:929,y:603,t:1527613878879};\\\", \\\"{x:954,y:633,t:1527613878894};\\\", \\\"{x:983,y:659,t:1527613878911};\\\", \\\"{x:1019,y:690,t:1527613878928};\\\", \\\"{x:1063,y:729,t:1527613878945};\\\", \\\"{x:1087,y:748,t:1527613878961};\\\", \\\"{x:1117,y:775,t:1527613878978};\\\", \\\"{x:1135,y:788,t:1527613878995};\\\", \\\"{x:1146,y:799,t:1527613879012};\\\", \\\"{x:1153,y:808,t:1527613879028};\\\", \\\"{x:1165,y:824,t:1527613879044};\\\", \\\"{x:1174,y:836,t:1527613879063};\\\", \\\"{x:1182,y:846,t:1527613879078};\\\", \\\"{x:1192,y:855,t:1527613879095};\\\", \\\"{x:1203,y:863,t:1527613879113};\\\", \\\"{x:1215,y:872,t:1527613879129};\\\", \\\"{x:1223,y:880,t:1527613879145};\\\", \\\"{x:1227,y:883,t:1527613879163};\\\", \\\"{x:1230,y:885,t:1527613879179};\\\", \\\"{x:1231,y:886,t:1527613879195};\\\", \\\"{x:1232,y:886,t:1527613879269};\\\", \\\"{x:1232,y:882,t:1527613879279};\\\", \\\"{x:1228,y:870,t:1527613879296};\\\", \\\"{x:1224,y:853,t:1527613879312};\\\", \\\"{x:1217,y:832,t:1527613879332};\\\", \\\"{x:1211,y:819,t:1527613879346};\\\", \\\"{x:1203,y:803,t:1527613879363};\\\", \\\"{x:1198,y:789,t:1527613879379};\\\", \\\"{x:1196,y:783,t:1527613879396};\\\", \\\"{x:1194,y:775,t:1527613879413};\\\", \\\"{x:1193,y:771,t:1527613879430};\\\", \\\"{x:1193,y:769,t:1527613879446};\\\", \\\"{x:1192,y:766,t:1527613879462};\\\", \\\"{x:1192,y:765,t:1527613879479};\\\", \\\"{x:1192,y:761,t:1527613879496};\\\", \\\"{x:1191,y:759,t:1527613879513};\\\", \\\"{x:1191,y:758,t:1527613879533};\\\", \\\"{x:1190,y:758,t:1527613879789};\\\", \\\"{x:1183,y:758,t:1527613880022};\\\", \\\"{x:1180,y:759,t:1527613880032};\\\", \\\"{x:1172,y:763,t:1527613880049};\\\", \\\"{x:1163,y:766,t:1527613880065};\\\", \\\"{x:1157,y:768,t:1527613880082};\\\", \\\"{x:1154,y:769,t:1527613880098};\\\", \\\"{x:1154,y:768,t:1527613880445};\\\", \\\"{x:1154,y:767,t:1527613880453};\\\", \\\"{x:1154,y:766,t:1527613880466};\\\", \\\"{x:1155,y:764,t:1527613880483};\\\", \\\"{x:1155,y:761,t:1527613880501};\\\", \\\"{x:1156,y:760,t:1527613880516};\\\", \\\"{x:1158,y:759,t:1527613880693};\\\", \\\"{x:1159,y:759,t:1527613880700};\\\", \\\"{x:1162,y:759,t:1527613880717};\\\", \\\"{x:1166,y:759,t:1527613880735};\\\", \\\"{x:1167,y:759,t:1527613880752};\\\", \\\"{x:1169,y:759,t:1527613880768};\\\", \\\"{x:1170,y:759,t:1527613880784};\\\", \\\"{x:1171,y:759,t:1527613880821};\\\", \\\"{x:1173,y:760,t:1527613880845};\\\", \\\"{x:1175,y:760,t:1527613880902};\\\", \\\"{x:1173,y:760,t:1527613884404};\\\", \\\"{x:1167,y:758,t:1527613884413};\\\", \\\"{x:1138,y:750,t:1527613884429};\\\", \\\"{x:1113,y:743,t:1527613884447};\\\", \\\"{x:1095,y:739,t:1527613884463};\\\", \\\"{x:1084,y:736,t:1527613884480};\\\", \\\"{x:1083,y:736,t:1527613884497};\\\", \\\"{x:1082,y:736,t:1527613885580};\\\", \\\"{x:1085,y:747,t:1527613890421};\\\", \\\"{x:1090,y:756,t:1527613890435};\\\", \\\"{x:1100,y:776,t:1527613890451};\\\", \\\"{x:1107,y:784,t:1527613890468};\\\", \\\"{x:1114,y:791,t:1527613890485};\\\", \\\"{x:1115,y:792,t:1527613890500};\\\", \\\"{x:1117,y:794,t:1527613890518};\\\", \\\"{x:1121,y:797,t:1527613890535};\\\", \\\"{x:1123,y:798,t:1527613890552};\\\", \\\"{x:1129,y:801,t:1527613890568};\\\", \\\"{x:1137,y:805,t:1527613890585};\\\", \\\"{x:1142,y:806,t:1527613890602};\\\", \\\"{x:1148,y:808,t:1527613890618};\\\", \\\"{x:1154,y:809,t:1527613890635};\\\", \\\"{x:1160,y:809,t:1527613890652};\\\", \\\"{x:1164,y:809,t:1527613890669};\\\", \\\"{x:1166,y:809,t:1527613890685};\\\", \\\"{x:1167,y:809,t:1527613890701};\\\", \\\"{x:1168,y:809,t:1527613890719};\\\", \\\"{x:1170,y:807,t:1527613890736};\\\", \\\"{x:1172,y:804,t:1527613890752};\\\", \\\"{x:1173,y:803,t:1527613890769};\\\", \\\"{x:1174,y:802,t:1527613890786};\\\", \\\"{x:1175,y:800,t:1527613890802};\\\", \\\"{x:1175,y:799,t:1527613890818};\\\", \\\"{x:1175,y:798,t:1527613890836};\\\", \\\"{x:1177,y:797,t:1527613890853};\\\", \\\"{x:1177,y:795,t:1527613890869};\\\", \\\"{x:1177,y:794,t:1527613890886};\\\", \\\"{x:1178,y:792,t:1527613890903};\\\", \\\"{x:1179,y:790,t:1527613890919};\\\", \\\"{x:1180,y:788,t:1527613890936};\\\", \\\"{x:1181,y:786,t:1527613890957};\\\", \\\"{x:1182,y:786,t:1527613890980};\\\", \\\"{x:1182,y:785,t:1527613891006};\\\", \\\"{x:1183,y:785,t:1527613891020};\\\", \\\"{x:1184,y:784,t:1527613891044};\\\", \\\"{x:1185,y:782,t:1527613891052};\\\", \\\"{x:1186,y:781,t:1527613891069};\\\", \\\"{x:1189,y:779,t:1527613891086};\\\", \\\"{x:1194,y:777,t:1527613891103};\\\", \\\"{x:1200,y:771,t:1527613891119};\\\", \\\"{x:1203,y:769,t:1527613891136};\\\", \\\"{x:1207,y:767,t:1527613891153};\\\", \\\"{x:1207,y:766,t:1527613891169};\\\", \\\"{x:1209,y:765,t:1527613891186};\\\", \\\"{x:1209,y:764,t:1527613891204};\\\", \\\"{x:1210,y:764,t:1527613891253};\\\", \\\"{x:1210,y:762,t:1527613891277};\\\", \\\"{x:1211,y:762,t:1527613891292};\\\", \\\"{x:1212,y:761,t:1527613891303};\\\", \\\"{x:1213,y:761,t:1527613893205};\\\", \\\"{x:1215,y:761,t:1527613893213};\\\", \\\"{x:1217,y:765,t:1527613893226};\\\", \\\"{x:1222,y:775,t:1527613893244};\\\", \\\"{x:1226,y:782,t:1527613893260};\\\", \\\"{x:1229,y:785,t:1527613893278};\\\", \\\"{x:1229,y:786,t:1527613893294};\\\", \\\"{x:1230,y:787,t:1527613893310};\\\", \\\"{x:1231,y:787,t:1527613893380};\\\", \\\"{x:1232,y:788,t:1527613893396};\\\", \\\"{x:1233,y:788,t:1527613893411};\\\", \\\"{x:1234,y:788,t:1527613893427};\\\", \\\"{x:1238,y:790,t:1527613893444};\\\", \\\"{x:1242,y:790,t:1527613893461};\\\", \\\"{x:1244,y:790,t:1527613893477};\\\", \\\"{x:1248,y:790,t:1527613893495};\\\", \\\"{x:1250,y:790,t:1527613893512};\\\", \\\"{x:1251,y:790,t:1527613893528};\\\", \\\"{x:1252,y:790,t:1527613893545};\\\", \\\"{x:1254,y:790,t:1527613893605};\\\", \\\"{x:1255,y:789,t:1527613893613};\\\", \\\"{x:1255,y:788,t:1527613893629};\\\", \\\"{x:1257,y:786,t:1527613893645};\\\", \\\"{x:1258,y:785,t:1527613893662};\\\", \\\"{x:1260,y:783,t:1527613893679};\\\", \\\"{x:1261,y:783,t:1527613893696};\\\", \\\"{x:1261,y:781,t:1527613893711};\\\", \\\"{x:1262,y:780,t:1527613893728};\\\", \\\"{x:1263,y:778,t:1527613893746};\\\", \\\"{x:1264,y:777,t:1527613893761};\\\", \\\"{x:1265,y:776,t:1527613893780};\\\", \\\"{x:1265,y:775,t:1527613893795};\\\", \\\"{x:1266,y:774,t:1527613893820};\\\", \\\"{x:1267,y:773,t:1527613893836};\\\", \\\"{x:1267,y:772,t:1527613893852};\\\", \\\"{x:1268,y:771,t:1527613893868};\\\", \\\"{x:1268,y:769,t:1527613893885};\\\", \\\"{x:1269,y:768,t:1527613893896};\\\", \\\"{x:1269,y:767,t:1527613893912};\\\", \\\"{x:1269,y:765,t:1527613893929};\\\", \\\"{x:1269,y:764,t:1527613893946};\\\", \\\"{x:1270,y:762,t:1527613893962};\\\", \\\"{x:1270,y:761,t:1527613894004};\\\", \\\"{x:1270,y:760,t:1527613894028};\\\", \\\"{x:1270,y:759,t:1527613894068};\\\", \\\"{x:1273,y:761,t:1527613894677};\\\", \\\"{x:1274,y:764,t:1527613894685};\\\", \\\"{x:1275,y:766,t:1527613894699};\\\", \\\"{x:1279,y:773,t:1527613894716};\\\", \\\"{x:1281,y:777,t:1527613894732};\\\", \\\"{x:1285,y:782,t:1527613894749};\\\", \\\"{x:1287,y:785,t:1527613894766};\\\", \\\"{x:1291,y:789,t:1527613894783};\\\", \\\"{x:1295,y:793,t:1527613894799};\\\", \\\"{x:1303,y:795,t:1527613894816};\\\", \\\"{x:1308,y:799,t:1527613894833};\\\", \\\"{x:1310,y:799,t:1527613894850};\\\", \\\"{x:1312,y:799,t:1527613894981};\\\", \\\"{x:1313,y:799,t:1527613894997};\\\", \\\"{x:1316,y:799,t:1527613895004};\\\", \\\"{x:1316,y:798,t:1527613895016};\\\", \\\"{x:1318,y:797,t:1527613895033};\\\", \\\"{x:1319,y:796,t:1527613895050};\\\", \\\"{x:1321,y:795,t:1527613895067};\\\", \\\"{x:1323,y:794,t:1527613895085};\\\", \\\"{x:1326,y:792,t:1527613895101};\\\", \\\"{x:1328,y:790,t:1527613895116};\\\", \\\"{x:1330,y:788,t:1527613895134};\\\", \\\"{x:1331,y:787,t:1527613895151};\\\", \\\"{x:1333,y:785,t:1527613895167};\\\", \\\"{x:1335,y:784,t:1527613895184};\\\", \\\"{x:1336,y:783,t:1527613895201};\\\", \\\"{x:1337,y:782,t:1527613895217};\\\", \\\"{x:1339,y:781,t:1527613895234};\\\", \\\"{x:1340,y:780,t:1527613895251};\\\", \\\"{x:1341,y:779,t:1527613895268};\\\", \\\"{x:1342,y:777,t:1527613895284};\\\", \\\"{x:1344,y:777,t:1527613895301};\\\", \\\"{x:1345,y:775,t:1527613895318};\\\", \\\"{x:1346,y:774,t:1527613895357};\\\", \\\"{x:1347,y:773,t:1527613895380};\\\", \\\"{x:1347,y:772,t:1527613895397};\\\", \\\"{x:1347,y:771,t:1527613895413};\\\", \\\"{x:1348,y:771,t:1527613895421};\\\", \\\"{x:1349,y:769,t:1527613895435};\\\", \\\"{x:1350,y:768,t:1527613895461};\\\", \\\"{x:1351,y:766,t:1527613895485};\\\", \\\"{x:1351,y:765,t:1527613895557};\\\", \\\"{x:1352,y:764,t:1527613895572};\\\", \\\"{x:1352,y:763,t:1527613895605};\\\", \\\"{x:1352,y:762,t:1527613895645};\\\", \\\"{x:1352,y:761,t:1527613895660};\\\", \\\"{x:1351,y:758,t:1527613895790};\\\", \\\"{x:1346,y:755,t:1527613895803};\\\", \\\"{x:1324,y:747,t:1527613895820};\\\", \\\"{x:1271,y:744,t:1527613895836};\\\", \\\"{x:1146,y:744,t:1527613895853};\\\", \\\"{x:1035,y:742,t:1527613895870};\\\", \\\"{x:896,y:721,t:1527613895886};\\\", \\\"{x:771,y:702,t:1527613895902};\\\", \\\"{x:691,y:691,t:1527613895920};\\\", \\\"{x:653,y:685,t:1527613895938};\\\", \\\"{x:632,y:677,t:1527613895953};\\\", \\\"{x:616,y:668,t:1527613895970};\\\", \\\"{x:603,y:660,t:1527613895987};\\\", \\\"{x:595,y:653,t:1527613896003};\\\", \\\"{x:585,y:646,t:1527613896019};\\\", \\\"{x:569,y:634,t:1527613896037};\\\", \\\"{x:557,y:622,t:1527613896054};\\\", \\\"{x:544,y:613,t:1527613896069};\\\", \\\"{x:540,y:608,t:1527613896086};\\\", \\\"{x:537,y:605,t:1527613896107};\\\", \\\"{x:535,y:598,t:1527613896125};\\\", \\\"{x:533,y:590,t:1527613896142};\\\", \\\"{x:530,y:576,t:1527613896157};\\\", \\\"{x:529,y:567,t:1527613896174};\\\", \\\"{x:529,y:562,t:1527613896192};\\\", \\\"{x:528,y:559,t:1527613896207};\\\", \\\"{x:528,y:555,t:1527613896224};\\\", \\\"{x:527,y:553,t:1527613896241};\\\", \\\"{x:527,y:552,t:1527613896257};\\\", \\\"{x:527,y:551,t:1527613896274};\\\", \\\"{x:526,y:550,t:1527613896291};\\\", \\\"{x:525,y:550,t:1527613896324};\\\", \\\"{x:516,y:544,t:1527613896342};\\\", \\\"{x:498,y:539,t:1527613896358};\\\", \\\"{x:475,y:532,t:1527613896375};\\\", \\\"{x:434,y:532,t:1527613896392};\\\", \\\"{x:377,y:531,t:1527613896408};\\\", \\\"{x:312,y:526,t:1527613896425};\\\", \\\"{x:256,y:518,t:1527613896442};\\\", \\\"{x:189,y:507,t:1527613896459};\\\", \\\"{x:153,y:499,t:1527613896475};\\\", \\\"{x:144,y:499,t:1527613896492};\\\", \\\"{x:146,y:504,t:1527613896620};\\\", \\\"{x:151,y:515,t:1527613896627};\\\", \\\"{x:157,y:526,t:1527613896642};\\\", \\\"{x:174,y:547,t:1527613896659};\\\", \\\"{x:185,y:559,t:1527613896676};\\\", \\\"{x:192,y:565,t:1527613896692};\\\", \\\"{x:195,y:565,t:1527613896709};\\\", \\\"{x:196,y:565,t:1527613896932};\\\", \\\"{x:196,y:564,t:1527613896948};\\\", \\\"{x:195,y:561,t:1527613896960};\\\", \\\"{x:194,y:561,t:1527613896975};\\\", \\\"{x:194,y:560,t:1527613896991};\\\", \\\"{x:193,y:560,t:1527613897068};\\\", \\\"{x:192,y:558,t:1527613897108};\\\", \\\"{x:192,y:556,t:1527613897125};\\\", \\\"{x:191,y:555,t:1527613897143};\\\", \\\"{x:190,y:552,t:1527613897159};\\\", \\\"{x:190,y:551,t:1527613897175};\\\", \\\"{x:189,y:549,t:1527613897192};\\\", \\\"{x:189,y:548,t:1527613897212};\\\", \\\"{x:189,y:546,t:1527613897236};\\\", \\\"{x:188,y:546,t:1527613897244};\\\", \\\"{x:188,y:545,t:1527613897268};\\\", \\\"{x:188,y:542,t:1527613897292};\\\", \\\"{x:187,y:539,t:1527613897308};\\\", \\\"{x:186,y:536,t:1527613897326};\\\", \\\"{x:186,y:535,t:1527613897343};\\\", \\\"{x:183,y:530,t:1527613897358};\\\", \\\"{x:183,y:528,t:1527613897376};\\\", \\\"{x:183,y:526,t:1527613897394};\\\", \\\"{x:182,y:523,t:1527613897409};\\\", \\\"{x:181,y:522,t:1527613897426};\\\", \\\"{x:181,y:519,t:1527613897442};\\\", \\\"{x:180,y:518,t:1527613897459};\\\", \\\"{x:180,y:517,t:1527613897476};\\\", \\\"{x:180,y:516,t:1527613897508};\\\", \\\"{x:180,y:515,t:1527613897515};\\\", \\\"{x:180,y:513,t:1527613897526};\\\", \\\"{x:180,y:511,t:1527613897542};\\\", \\\"{x:179,y:509,t:1527613897558};\\\", \\\"{x:179,y:508,t:1527613897576};\\\", \\\"{x:178,y:507,t:1527613897592};\\\", \\\"{x:178,y:506,t:1527613897608};\\\", \\\"{x:178,y:505,t:1527613897626};\\\", \\\"{x:177,y:505,t:1527613897795};\\\", \\\"{x:177,y:505,t:1527613897885};\\\", \\\"{x:184,y:509,t:1527613898157};\\\", \\\"{x:198,y:519,t:1527613898166};\\\", \\\"{x:223,y:538,t:1527613898178};\\\", \\\"{x:271,y:571,t:1527613898193};\\\", \\\"{x:316,y:596,t:1527613898209};\\\", \\\"{x:357,y:611,t:1527613898228};\\\", \\\"{x:386,y:621,t:1527613898243};\\\", \\\"{x:408,y:634,t:1527613898260};\\\", \\\"{x:419,y:641,t:1527613898276};\\\", \\\"{x:428,y:647,t:1527613898292};\\\", \\\"{x:441,y:655,t:1527613898310};\\\", \\\"{x:452,y:662,t:1527613898325};\\\", \\\"{x:463,y:670,t:1527613898343};\\\", \\\"{x:474,y:679,t:1527613898359};\\\", \\\"{x:481,y:686,t:1527613898376};\\\", \\\"{x:483,y:687,t:1527613898392};\\\", \\\"{x:486,y:691,t:1527613898410};\\\", \\\"{x:490,y:697,t:1527613898426};\\\", \\\"{x:494,y:704,t:1527613898443};\\\", \\\"{x:496,y:708,t:1527613898459};\\\", \\\"{x:496,y:709,t:1527613898564};\\\", \\\"{x:496,y:710,t:1527613898877};\\\", \\\"{x:496,y:714,t:1527613898893};\\\", \\\"{x:497,y:716,t:1527613898909};\\\", \\\"{x:497,y:718,t:1527613898932};\\\", \\\"{x:498,y:719,t:1527613898949};\\\", \\\"{x:498,y:720,t:1527613898966};\\\", \\\"{x:498,y:721,t:1527613898976};\\\", \\\"{x:498,y:722,t:1527613898994};\\\", \\\"{x:498,y:725,t:1527613899010};\\\", \\\"{x:500,y:728,t:1527613899026};\\\", \\\"{x:501,y:735,t:1527613899043};\\\", \\\"{x:501,y:738,t:1527613899060};\\\", \\\"{x:501,y:739,t:1527613899077};\\\", \\\"{x:502,y:739,t:1527613899179};\\\", \\\"{x:503,y:739,t:1527613899211};\\\", \\\"{x:503,y:739,t:1527613899303};\\\" ] }, { \\\"rt\\\": 84263, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 585785, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B -B -Z -Z -C -G -G -Z -Z -Z -Z -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:737,t:1527613901605};\\\", \\\"{x:494,y:735,t:1527613901613};\\\", \\\"{x:475,y:727,t:1527613901630};\\\", \\\"{x:456,y:718,t:1527613901649};\\\", \\\"{x:444,y:711,t:1527613901662};\\\", \\\"{x:436,y:707,t:1527613901679};\\\", \\\"{x:430,y:704,t:1527613901695};\\\", \\\"{x:429,y:703,t:1527613901712};\\\", \\\"{x:428,y:702,t:1527613901728};\\\", \\\"{x:427,y:702,t:1527613901748};\\\", \\\"{x:426,y:701,t:1527613901764};\\\", \\\"{x:426,y:700,t:1527613901779};\\\", \\\"{x:422,y:698,t:1527613901795};\\\", \\\"{x:420,y:696,t:1527613901813};\\\", \\\"{x:415,y:693,t:1527613901829};\\\", \\\"{x:409,y:690,t:1527613901846};\\\", \\\"{x:401,y:686,t:1527613901863};\\\", \\\"{x:396,y:682,t:1527613901880};\\\", \\\"{x:387,y:680,t:1527613901896};\\\", \\\"{x:372,y:675,t:1527613901913};\\\", \\\"{x:351,y:665,t:1527613901932};\\\", \\\"{x:312,y:646,t:1527613901945};\\\", \\\"{x:254,y:618,t:1527613901963};\\\", \\\"{x:178,y:592,t:1527613901979};\\\", \\\"{x:39,y:532,t:1527613901996};\\\", \\\"{x:0,y:497,t:1527613902013};\\\", \\\"{x:0,y:470,t:1527613902028};\\\", \\\"{x:0,y:450,t:1527613902046};\\\", \\\"{x:0,y:435,t:1527613902063};\\\", \\\"{x:0,y:426,t:1527613902078};\\\", \\\"{x:0,y:418,t:1527613902096};\\\", \\\"{x:0,y:412,t:1527613902112};\\\", \\\"{x:0,y:407,t:1527613902129};\\\", \\\"{x:0,y:401,t:1527613902145};\\\", \\\"{x:0,y:390,t:1527613902163};\\\", \\\"{x:0,y:362,t:1527613902179};\\\", \\\"{x:0,y:312,t:1527613902196};\\\", \\\"{x:0,y:283,t:1527613902213};\\\", \\\"{x:0,y:243,t:1527613902229};\\\", \\\"{x:0,y:210,t:1527613902246};\\\", \\\"{x:0,y:185,t:1527613902262};\\\", \\\"{x:8,y:161,t:1527613902280};\\\", \\\"{x:17,y:143,t:1527613902296};\\\", \\\"{x:33,y:130,t:1527613902313};\\\", \\\"{x:59,y:113,t:1527613902330};\\\", \\\"{x:105,y:88,t:1527613902346};\\\", \\\"{x:159,y:59,t:1527613902362};\\\", \\\"{x:259,y:16,t:1527613902381};\\\", \\\"{x:342,y:16,t:1527613902396};\\\", \\\"{x:414,y:16,t:1527613902413};\\\", \\\"{x:478,y:16,t:1527613902430};\\\", \\\"{x:521,y:16,t:1527613902446};\\\", \\\"{x:578,y:16,t:1527613902463};\\\", \\\"{x:642,y:16,t:1527613902480};\\\", \\\"{x:711,y:16,t:1527613902497};\\\", \\\"{x:759,y:16,t:1527613902513};\\\", \\\"{x:812,y:16,t:1527613902530};\\\", \\\"{x:846,y:16,t:1527613902546};\\\", \\\"{x:886,y:21,t:1527613902563};\\\", \\\"{x:1048,y:63,t:1527613902581};\\\", \\\"{x:1189,y:100,t:1527613902596};\\\", \\\"{x:1333,y:144,t:1527613902614};\\\", \\\"{x:1473,y:180,t:1527613902631};\\\", \\\"{x:1577,y:219,t:1527613902646};\\\", \\\"{x:1661,y:262,t:1527613902663};\\\", \\\"{x:1713,y:303,t:1527613902680};\\\", \\\"{x:1753,y:334,t:1527613902696};\\\", \\\"{x:1777,y:352,t:1527613902713};\\\", \\\"{x:1796,y:369,t:1527613902730};\\\", \\\"{x:1815,y:381,t:1527613902747};\\\", \\\"{x:1834,y:392,t:1527613902763};\\\", \\\"{x:1859,y:411,t:1527613902780};\\\", \\\"{x:1870,y:419,t:1527613902796};\\\", \\\"{x:1873,y:426,t:1527613902814};\\\", \\\"{x:1873,y:428,t:1527613902831};\\\", \\\"{x:1873,y:433,t:1527613902847};\\\", \\\"{x:1871,y:440,t:1527613902863};\\\", \\\"{x:1862,y:448,t:1527613902880};\\\", \\\"{x:1855,y:457,t:1527613902897};\\\", \\\"{x:1846,y:463,t:1527613902915};\\\", \\\"{x:1836,y:472,t:1527613902930};\\\", \\\"{x:1824,y:481,t:1527613902947};\\\", \\\"{x:1810,y:490,t:1527613902963};\\\", \\\"{x:1797,y:501,t:1527613902981};\\\", \\\"{x:1784,y:513,t:1527613902996};\\\", \\\"{x:1769,y:526,t:1527613903013};\\\", \\\"{x:1756,y:536,t:1527613903031};\\\", \\\"{x:1742,y:548,t:1527613903047};\\\", \\\"{x:1732,y:558,t:1527613903064};\\\", \\\"{x:1718,y:570,t:1527613903080};\\\", \\\"{x:1703,y:581,t:1527613903097};\\\", \\\"{x:1682,y:594,t:1527613903113};\\\", \\\"{x:1656,y:610,t:1527613903131};\\\", \\\"{x:1612,y:639,t:1527613903147};\\\", \\\"{x:1506,y:695,t:1527613903165};\\\", \\\"{x:1415,y:736,t:1527613903181};\\\", \\\"{x:1319,y:777,t:1527613903197};\\\", \\\"{x:1220,y:815,t:1527613903214};\\\", \\\"{x:1135,y:836,t:1527613903230};\\\", \\\"{x:1092,y:843,t:1527613903247};\\\", \\\"{x:1078,y:845,t:1527613903265};\\\", \\\"{x:1079,y:845,t:1527613903348};\\\", \\\"{x:1083,y:846,t:1527613903363};\\\", \\\"{x:1087,y:848,t:1527613903379};\\\", \\\"{x:1091,y:848,t:1527613903397};\\\", \\\"{x:1092,y:850,t:1527613903413};\\\", \\\"{x:1094,y:851,t:1527613903430};\\\", \\\"{x:1098,y:851,t:1527613903447};\\\", \\\"{x:1109,y:851,t:1527613903464};\\\", \\\"{x:1137,y:847,t:1527613903480};\\\", \\\"{x:1182,y:835,t:1527613903497};\\\", \\\"{x:1250,y:810,t:1527613903515};\\\", \\\"{x:1327,y:789,t:1527613903530};\\\", \\\"{x:1384,y:780,t:1527613903547};\\\", \\\"{x:1419,y:772,t:1527613903564};\\\", \\\"{x:1428,y:770,t:1527613903580};\\\", \\\"{x:1431,y:768,t:1527613903597};\\\", \\\"{x:1433,y:767,t:1527613903628};\\\", \\\"{x:1433,y:766,t:1527613903677};\\\", \\\"{x:1433,y:764,t:1527613903685};\\\", \\\"{x:1433,y:763,t:1527613903697};\\\", \\\"{x:1433,y:759,t:1527613903715};\\\", \\\"{x:1433,y:758,t:1527613903781};\\\", \\\"{x:1433,y:757,t:1527613903909};\\\", \\\"{x:1432,y:757,t:1527613903917};\\\", \\\"{x:1430,y:757,t:1527613903930};\\\", \\\"{x:1428,y:757,t:1527613903947};\\\", \\\"{x:1424,y:757,t:1527613903964};\\\", \\\"{x:1421,y:757,t:1527613903981};\\\", \\\"{x:1420,y:757,t:1527613904036};\\\", \\\"{x:1419,y:757,t:1527613904076};\\\", \\\"{x:1416,y:759,t:1527613904117};\\\", \\\"{x:1415,y:760,t:1527613904131};\\\", \\\"{x:1406,y:764,t:1527613904148};\\\", \\\"{x:1398,y:766,t:1527613904164};\\\", \\\"{x:1381,y:770,t:1527613904182};\\\", \\\"{x:1354,y:770,t:1527613904198};\\\", \\\"{x:1323,y:770,t:1527613904213};\\\", \\\"{x:1307,y:768,t:1527613904230};\\\", \\\"{x:1301,y:767,t:1527613904248};\\\", \\\"{x:1301,y:766,t:1527613904300};\\\", \\\"{x:1301,y:765,t:1527613904347};\\\", \\\"{x:1301,y:764,t:1527613904364};\\\", \\\"{x:1302,y:759,t:1527613904381};\\\", \\\"{x:1305,y:754,t:1527613904398};\\\", \\\"{x:1308,y:749,t:1527613904414};\\\", \\\"{x:1310,y:746,t:1527613904430};\\\", \\\"{x:1314,y:743,t:1527613904448};\\\", \\\"{x:1318,y:736,t:1527613904464};\\\", \\\"{x:1322,y:729,t:1527613904481};\\\", \\\"{x:1323,y:724,t:1527613904498};\\\", \\\"{x:1327,y:715,t:1527613904515};\\\", \\\"{x:1327,y:709,t:1527613904531};\\\", \\\"{x:1329,y:704,t:1527613904547};\\\", \\\"{x:1330,y:701,t:1527613904565};\\\", \\\"{x:1330,y:700,t:1527613904596};\\\", \\\"{x:1330,y:699,t:1527613904604};\\\", \\\"{x:1330,y:698,t:1527613904615};\\\", \\\"{x:1330,y:695,t:1527613904631};\\\", \\\"{x:1330,y:693,t:1527613904648};\\\", \\\"{x:1331,y:690,t:1527613904665};\\\", \\\"{x:1331,y:689,t:1527613904681};\\\", \\\"{x:1332,y:687,t:1527613904698};\\\", \\\"{x:1333,y:685,t:1527613904715};\\\", \\\"{x:1334,y:684,t:1527613904731};\\\", \\\"{x:1334,y:682,t:1527613904747};\\\", \\\"{x:1335,y:680,t:1527613904772};\\\", \\\"{x:1336,y:679,t:1527613904781};\\\", \\\"{x:1337,y:679,t:1527613904812};\\\", \\\"{x:1338,y:679,t:1527613904820};\\\", \\\"{x:1339,y:678,t:1527613904831};\\\", \\\"{x:1340,y:678,t:1527613904852};\\\", \\\"{x:1341,y:678,t:1527613904865};\\\", \\\"{x:1342,y:678,t:1527613904881};\\\", \\\"{x:1343,y:678,t:1527613905021};\\\", \\\"{x:1344,y:679,t:1527613905069};\\\", \\\"{x:1345,y:680,t:1527613905101};\\\", \\\"{x:1346,y:681,t:1527613905117};\\\", \\\"{x:1346,y:683,t:1527613905131};\\\", \\\"{x:1347,y:685,t:1527613905147};\\\", \\\"{x:1348,y:686,t:1527613905164};\\\", \\\"{x:1349,y:690,t:1527613905181};\\\", \\\"{x:1349,y:691,t:1527613905244};\\\", \\\"{x:1349,y:692,t:1527613910800};\\\", \\\"{x:1353,y:695,t:1527613910819};\\\", \\\"{x:1356,y:702,t:1527613910836};\\\", \\\"{x:1356,y:704,t:1527613910852};\\\", \\\"{x:1357,y:706,t:1527613910869};\\\", \\\"{x:1359,y:708,t:1527613910908};\\\", \\\"{x:1360,y:709,t:1527613910956};\\\", \\\"{x:1361,y:709,t:1527613910972};\\\", \\\"{x:1362,y:709,t:1527613910988};\\\", \\\"{x:1363,y:709,t:1527613911036};\\\", \\\"{x:1364,y:709,t:1527613911059};\\\", \\\"{x:1367,y:709,t:1527613911075};\\\", \\\"{x:1368,y:709,t:1527613911086};\\\", \\\"{x:1371,y:706,t:1527613911102};\\\", \\\"{x:1376,y:705,t:1527613911119};\\\", \\\"{x:1377,y:703,t:1527613911136};\\\", \\\"{x:1380,y:701,t:1527613911152};\\\", \\\"{x:1381,y:701,t:1527613911171};\\\", \\\"{x:1381,y:700,t:1527613911187};\\\", \\\"{x:1381,y:699,t:1527613911203};\\\", \\\"{x:1381,y:698,t:1527613911219};\\\", \\\"{x:1382,y:697,t:1527613911236};\\\", \\\"{x:1382,y:696,t:1527613911253};\\\", \\\"{x:1383,y:696,t:1527613911373};\\\", \\\"{x:1385,y:696,t:1527613911387};\\\", \\\"{x:1386,y:696,t:1527613911403};\\\", \\\"{x:1387,y:696,t:1527613911420};\\\", \\\"{x:1389,y:696,t:1527613911437};\\\", \\\"{x:1390,y:696,t:1527613911453};\\\", \\\"{x:1398,y:696,t:1527613911469};\\\", \\\"{x:1412,y:694,t:1527613911487};\\\", \\\"{x:1438,y:693,t:1527613911504};\\\", \\\"{x:1468,y:693,t:1527613911519};\\\", \\\"{x:1483,y:693,t:1527613911537};\\\", \\\"{x:1488,y:693,t:1527613911554};\\\", \\\"{x:1490,y:693,t:1527613911570};\\\", \\\"{x:1491,y:693,t:1527613911661};\\\", \\\"{x:1491,y:692,t:1527613911671};\\\", \\\"{x:1491,y:688,t:1527613911687};\\\", \\\"{x:1491,y:685,t:1527613911704};\\\", \\\"{x:1490,y:686,t:1527613911837};\\\", \\\"{x:1489,y:709,t:1527613911854};\\\", \\\"{x:1492,y:727,t:1527613911870};\\\", \\\"{x:1497,y:735,t:1527613911887};\\\", \\\"{x:1500,y:739,t:1527613911904};\\\", \\\"{x:1501,y:739,t:1527613911965};\\\", \\\"{x:1502,y:739,t:1527613911972};\\\", \\\"{x:1504,y:738,t:1527613911987};\\\", \\\"{x:1507,y:735,t:1527613912004};\\\", \\\"{x:1510,y:730,t:1527613912020};\\\", \\\"{x:1510,y:726,t:1527613912037};\\\", \\\"{x:1512,y:722,t:1527613912053};\\\", \\\"{x:1512,y:717,t:1527613912070};\\\", \\\"{x:1512,y:713,t:1527613912087};\\\", \\\"{x:1512,y:708,t:1527613912104};\\\", \\\"{x:1512,y:704,t:1527613912120};\\\", \\\"{x:1512,y:700,t:1527613912137};\\\", \\\"{x:1512,y:699,t:1527613912153};\\\", \\\"{x:1515,y:700,t:1527613912364};\\\", \\\"{x:1519,y:706,t:1527613912373};\\\", \\\"{x:1522,y:713,t:1527613912388};\\\", \\\"{x:1530,y:724,t:1527613912404};\\\", \\\"{x:1538,y:733,t:1527613912421};\\\", \\\"{x:1539,y:733,t:1527613912438};\\\", \\\"{x:1540,y:733,t:1527613912501};\\\", \\\"{x:1543,y:732,t:1527613912508};\\\", \\\"{x:1546,y:729,t:1527613912521};\\\", \\\"{x:1551,y:722,t:1527613912538};\\\", \\\"{x:1558,y:714,t:1527613912554};\\\", \\\"{x:1562,y:710,t:1527613912571};\\\", \\\"{x:1567,y:707,t:1527613912588};\\\", \\\"{x:1571,y:703,t:1527613912604};\\\", \\\"{x:1574,y:699,t:1527613912620};\\\", \\\"{x:1575,y:697,t:1527613912638};\\\", \\\"{x:1578,y:692,t:1527613912655};\\\", \\\"{x:1581,y:688,t:1527613912671};\\\", \\\"{x:1581,y:686,t:1527613912688};\\\", \\\"{x:1581,y:685,t:1527613912708};\\\", \\\"{x:1582,y:685,t:1527613915509};\\\", \\\"{x:1583,y:685,t:1527613915541};\\\", \\\"{x:1584,y:685,t:1527613915557};\\\", \\\"{x:1585,y:685,t:1527613915573};\\\", \\\"{x:1586,y:685,t:1527613915629};\\\", \\\"{x:1587,y:686,t:1527613915640};\\\", \\\"{x:1588,y:688,t:1527613915657};\\\", \\\"{x:1589,y:689,t:1527613915673};\\\", \\\"{x:1592,y:692,t:1527613915690};\\\", \\\"{x:1595,y:695,t:1527613915707};\\\", \\\"{x:1597,y:697,t:1527613915723};\\\", \\\"{x:1599,y:697,t:1527613915740};\\\", \\\"{x:1601,y:699,t:1527613915756};\\\", \\\"{x:1603,y:699,t:1527613915853};\\\", \\\"{x:1604,y:699,t:1527613916149};\\\", \\\"{x:1605,y:699,t:1527613916172};\\\", \\\"{x:1605,y:697,t:1527613916212};\\\", \\\"{x:1606,y:696,t:1527613916637};\\\", \\\"{x:1607,y:695,t:1527613916661};\\\", \\\"{x:1596,y:704,t:1527613924661};\\\", \\\"{x:1567,y:716,t:1527613924668};\\\", \\\"{x:1527,y:733,t:1527613924680};\\\", \\\"{x:1474,y:752,t:1527613924696};\\\", \\\"{x:1459,y:757,t:1527613924713};\\\", \\\"{x:1458,y:757,t:1527613924732};\\\", \\\"{x:1458,y:758,t:1527613924746};\\\", \\\"{x:1458,y:757,t:1527613924762};\\\", \\\"{x:1458,y:756,t:1527613924780};\\\", \\\"{x:1456,y:755,t:1527613925052};\\\", \\\"{x:1455,y:755,t:1527613925133};\\\", \\\"{x:1453,y:755,t:1527613925284};\\\", \\\"{x:1452,y:756,t:1527613925297};\\\", \\\"{x:1451,y:761,t:1527613925313};\\\", \\\"{x:1445,y:769,t:1527613925330};\\\", \\\"{x:1438,y:776,t:1527613925348};\\\", \\\"{x:1429,y:783,t:1527613925363};\\\", \\\"{x:1415,y:790,t:1527613925380};\\\", \\\"{x:1401,y:795,t:1527613925397};\\\", \\\"{x:1385,y:799,t:1527613925414};\\\", \\\"{x:1364,y:802,t:1527613925430};\\\", \\\"{x:1344,y:802,t:1527613925447};\\\", \\\"{x:1329,y:802,t:1527613925464};\\\", \\\"{x:1322,y:803,t:1527613925480};\\\", \\\"{x:1321,y:803,t:1527613925497};\\\", \\\"{x:1320,y:802,t:1527613925717};\\\", \\\"{x:1321,y:795,t:1527613925730};\\\", \\\"{x:1324,y:789,t:1527613925747};\\\", \\\"{x:1329,y:780,t:1527613925764};\\\", \\\"{x:1331,y:776,t:1527613925781};\\\", \\\"{x:1333,y:770,t:1527613925797};\\\", \\\"{x:1336,y:767,t:1527613925814};\\\", \\\"{x:1337,y:763,t:1527613925831};\\\", \\\"{x:1338,y:760,t:1527613925848};\\\", \\\"{x:1340,y:757,t:1527613925864};\\\", \\\"{x:1341,y:755,t:1527613925881};\\\", \\\"{x:1344,y:750,t:1527613925897};\\\", \\\"{x:1344,y:748,t:1527613925916};\\\", \\\"{x:1345,y:748,t:1527613925965};\\\", \\\"{x:1346,y:748,t:1527613926075};\\\", \\\"{x:1347,y:748,t:1527613926083};\\\", \\\"{x:1350,y:748,t:1527613926097};\\\", \\\"{x:1353,y:749,t:1527613926114};\\\", \\\"{x:1354,y:749,t:1527613926130};\\\", \\\"{x:1354,y:751,t:1527613926146};\\\", \\\"{x:1355,y:754,t:1527613926163};\\\", \\\"{x:1355,y:755,t:1527613926188};\\\", \\\"{x:1355,y:756,t:1527613926212};\\\", \\\"{x:1355,y:757,t:1527613926332};\\\", \\\"{x:1355,y:759,t:1527613926364};\\\", \\\"{x:1354,y:759,t:1527613926381};\\\", \\\"{x:1354,y:760,t:1527613926398};\\\", \\\"{x:1354,y:761,t:1527613926414};\\\", \\\"{x:1354,y:762,t:1527613926436};\\\", \\\"{x:1354,y:763,t:1527613926460};\\\", \\\"{x:1354,y:764,t:1527613926492};\\\", \\\"{x:1354,y:765,t:1527613926508};\\\", \\\"{x:1354,y:766,t:1527613926516};\\\", \\\"{x:1355,y:768,t:1527613926532};\\\", \\\"{x:1357,y:770,t:1527613926548};\\\", \\\"{x:1359,y:771,t:1527613926564};\\\", \\\"{x:1362,y:774,t:1527613926581};\\\", \\\"{x:1368,y:778,t:1527613926598};\\\", \\\"{x:1377,y:783,t:1527613926614};\\\", \\\"{x:1386,y:788,t:1527613926631};\\\", \\\"{x:1402,y:793,t:1527613926648};\\\", \\\"{x:1418,y:796,t:1527613926664};\\\", \\\"{x:1432,y:797,t:1527613926682};\\\", \\\"{x:1440,y:798,t:1527613926698};\\\", \\\"{x:1442,y:798,t:1527613926716};\\\", \\\"{x:1443,y:798,t:1527613926748};\\\", \\\"{x:1443,y:797,t:1527613926765};\\\", \\\"{x:1443,y:796,t:1527613926782};\\\", \\\"{x:1443,y:794,t:1527613926798};\\\", \\\"{x:1443,y:791,t:1527613926815};\\\", \\\"{x:1443,y:787,t:1527613926831};\\\", \\\"{x:1443,y:780,t:1527613926848};\\\", \\\"{x:1440,y:772,t:1527613926865};\\\", \\\"{x:1437,y:769,t:1527613926881};\\\", \\\"{x:1437,y:767,t:1527613926898};\\\", \\\"{x:1436,y:766,t:1527613926916};\\\", \\\"{x:1436,y:765,t:1527613926931};\\\", \\\"{x:1435,y:764,t:1527613926972};\\\", \\\"{x:1434,y:764,t:1527613927004};\\\", \\\"{x:1433,y:764,t:1527613927085};\\\", \\\"{x:1431,y:764,t:1527613927100};\\\", \\\"{x:1429,y:763,t:1527613927133};\\\", \\\"{x:1427,y:762,t:1527613927156};\\\", \\\"{x:1426,y:761,t:1527613927172};\\\", \\\"{x:1425,y:761,t:1527613927182};\\\", \\\"{x:1424,y:761,t:1527613927204};\\\", \\\"{x:1422,y:760,t:1527613927261};\\\", \\\"{x:1421,y:760,t:1527613927293};\\\", \\\"{x:1421,y:759,t:1527613927300};\\\", \\\"{x:1420,y:759,t:1527613927325};\\\", \\\"{x:1419,y:759,t:1527613927333};\\\", \\\"{x:1419,y:758,t:1527613927348};\\\", \\\"{x:1418,y:758,t:1527613927428};\\\", \\\"{x:1418,y:759,t:1527613929275};\\\", \\\"{x:1418,y:762,t:1527613929283};\\\", \\\"{x:1420,y:766,t:1527613929299};\\\", \\\"{x:1420,y:769,t:1527613929316};\\\", \\\"{x:1422,y:773,t:1527613929332};\\\", \\\"{x:1422,y:774,t:1527613929350};\\\", \\\"{x:1423,y:775,t:1527613929366};\\\", \\\"{x:1424,y:776,t:1527613929383};\\\", \\\"{x:1425,y:776,t:1527613929404};\\\", \\\"{x:1426,y:777,t:1527613929420};\\\", \\\"{x:1427,y:777,t:1527613929435};\\\", \\\"{x:1429,y:778,t:1527613929450};\\\", \\\"{x:1432,y:778,t:1527613929466};\\\", \\\"{x:1435,y:779,t:1527613929483};\\\", \\\"{x:1444,y:780,t:1527613929500};\\\", \\\"{x:1448,y:780,t:1527613929516};\\\", \\\"{x:1455,y:780,t:1527613929533};\\\", \\\"{x:1462,y:780,t:1527613929551};\\\", \\\"{x:1465,y:780,t:1527613929566};\\\", \\\"{x:1467,y:780,t:1527613929583};\\\", \\\"{x:1468,y:780,t:1527613929604};\\\", \\\"{x:1469,y:780,t:1527613929628};\\\", \\\"{x:1471,y:780,t:1527613929660};\\\", \\\"{x:1473,y:778,t:1527613929692};\\\", \\\"{x:1473,y:776,t:1527613929708};\\\", \\\"{x:1474,y:776,t:1527613929718};\\\", \\\"{x:1475,y:773,t:1527613929733};\\\", \\\"{x:1477,y:771,t:1527613929750};\\\", \\\"{x:1477,y:770,t:1527613929767};\\\", \\\"{x:1477,y:768,t:1527613929783};\\\", \\\"{x:1479,y:767,t:1527613929800};\\\", \\\"{x:1479,y:766,t:1527613929817};\\\", \\\"{x:1479,y:765,t:1527613929833};\\\", \\\"{x:1479,y:764,t:1527613929851};\\\", \\\"{x:1479,y:763,t:1527613929908};\\\", \\\"{x:1479,y:762,t:1527613929947};\\\", \\\"{x:1479,y:761,t:1527613929964};\\\", \\\"{x:1479,y:760,t:1527613930012};\\\", \\\"{x:1478,y:760,t:1527613930028};\\\", \\\"{x:1478,y:759,t:1527613930036};\\\", \\\"{x:1478,y:758,t:1527613930052};\\\", \\\"{x:1478,y:757,t:1527613930101};\\\", \\\"{x:1479,y:758,t:1527613930612};\\\", \\\"{x:1480,y:758,t:1527613930636};\\\", \\\"{x:1481,y:759,t:1527613930652};\\\", \\\"{x:1482,y:760,t:1527613930668};\\\", \\\"{x:1483,y:761,t:1527613930684};\\\", \\\"{x:1484,y:762,t:1527613930701};\\\", \\\"{x:1485,y:764,t:1527613930732};\\\", \\\"{x:1486,y:765,t:1527613930756};\\\", \\\"{x:1487,y:767,t:1527613930780};\\\", \\\"{x:1488,y:767,t:1527613930796};\\\", \\\"{x:1488,y:768,t:1527613930804};\\\", \\\"{x:1489,y:768,t:1527613930817};\\\", \\\"{x:1489,y:770,t:1527613930876};\\\", \\\"{x:1489,y:771,t:1527613930924};\\\", \\\"{x:1490,y:771,t:1527613930935};\\\", \\\"{x:1490,y:773,t:1527613930952};\\\", \\\"{x:1491,y:774,t:1527613930968};\\\", \\\"{x:1492,y:774,t:1527613930984};\\\", \\\"{x:1493,y:776,t:1527613931002};\\\", \\\"{x:1494,y:777,t:1527613931020};\\\", \\\"{x:1495,y:778,t:1527613931076};\\\", \\\"{x:1495,y:779,t:1527613931084};\\\", \\\"{x:1496,y:779,t:1527613931102};\\\", \\\"{x:1497,y:780,t:1527613931119};\\\", \\\"{x:1498,y:782,t:1527613931135};\\\", \\\"{x:1500,y:783,t:1527613931151};\\\", \\\"{x:1501,y:784,t:1527613931171};\\\", \\\"{x:1504,y:786,t:1527613931196};\\\", \\\"{x:1505,y:786,t:1527613931221};\\\", \\\"{x:1506,y:786,t:1527613931236};\\\", \\\"{x:1507,y:786,t:1527613931260};\\\", \\\"{x:1507,y:787,t:1527613931284};\\\", \\\"{x:1508,y:787,t:1527613931301};\\\", \\\"{x:1509,y:787,t:1527613931319};\\\", \\\"{x:1511,y:787,t:1527613931334};\\\", \\\"{x:1514,y:787,t:1527613931352};\\\", \\\"{x:1516,y:787,t:1527613931368};\\\", \\\"{x:1520,y:787,t:1527613931384};\\\", \\\"{x:1521,y:787,t:1527613931401};\\\", \\\"{x:1522,y:787,t:1527613931418};\\\", \\\"{x:1523,y:787,t:1527613931443};\\\", \\\"{x:1524,y:787,t:1527613931467};\\\", \\\"{x:1526,y:786,t:1527613931499};\\\", \\\"{x:1527,y:786,t:1527613931540};\\\", \\\"{x:1529,y:785,t:1527613931556};\\\", \\\"{x:1530,y:784,t:1527613931571};\\\", \\\"{x:1532,y:784,t:1527613931583};\\\", \\\"{x:1538,y:782,t:1527613931601};\\\", \\\"{x:1541,y:781,t:1527613931619};\\\", \\\"{x:1543,y:781,t:1527613931635};\\\", \\\"{x:1544,y:781,t:1527613931651};\\\", \\\"{x:1544,y:779,t:1527613931908};\\\", \\\"{x:1545,y:778,t:1527613931948};\\\", \\\"{x:1545,y:777,t:1527613931988};\\\", \\\"{x:1547,y:775,t:1527613932020};\\\", \\\"{x:1547,y:774,t:1527613932108};\\\", \\\"{x:1548,y:773,t:1527613932149};\\\", \\\"{x:1548,y:772,t:1527613932260};\\\", \\\"{x:1549,y:770,t:1527613932356};\\\", \\\"{x:1550,y:769,t:1527613932444};\\\", \\\"{x:1550,y:768,t:1527613932660};\\\", \\\"{x:1550,y:767,t:1527613932693};\\\", \\\"{x:1550,y:766,t:1527613932717};\\\", \\\"{x:1550,y:764,t:1527613932747};\\\", \\\"{x:1550,y:763,t:1527613932812};\\\", \\\"{x:1550,y:769,t:1527613936941};\\\", \\\"{x:1537,y:808,t:1527613936956};\\\", \\\"{x:1514,y:833,t:1527613936973};\\\", \\\"{x:1491,y:855,t:1527613936988};\\\", \\\"{x:1480,y:869,t:1527613937006};\\\", \\\"{x:1479,y:872,t:1527613937023};\\\", \\\"{x:1471,y:878,t:1527613937038};\\\", \\\"{x:1470,y:878,t:1527613937055};\\\", \\\"{x:1469,y:878,t:1527613937620};\\\", \\\"{x:1468,y:878,t:1527613937660};\\\", \\\"{x:1467,y:879,t:1527613937700};\\\", \\\"{x:1463,y:880,t:1527613937724};\\\", \\\"{x:1450,y:880,t:1527613937740};\\\", \\\"{x:1428,y:880,t:1527613937756};\\\", \\\"{x:1413,y:880,t:1527613937773};\\\", \\\"{x:1405,y:880,t:1527613937790};\\\", \\\"{x:1404,y:880,t:1527613937820};\\\", \\\"{x:1402,y:880,t:1527613937828};\\\", \\\"{x:1400,y:880,t:1527613937844};\\\", \\\"{x:1398,y:880,t:1527613937856};\\\", \\\"{x:1386,y:880,t:1527613937872};\\\", \\\"{x:1360,y:883,t:1527613937890};\\\", \\\"{x:1320,y:888,t:1527613937907};\\\", \\\"{x:1279,y:891,t:1527613937922};\\\", \\\"{x:1239,y:896,t:1527613937940};\\\", \\\"{x:1224,y:897,t:1527613937956};\\\", \\\"{x:1216,y:897,t:1527613937973};\\\", \\\"{x:1206,y:897,t:1527613937989};\\\", \\\"{x:1191,y:897,t:1527613938006};\\\", \\\"{x:1169,y:900,t:1527613938023};\\\", \\\"{x:1144,y:900,t:1527613938039};\\\", \\\"{x:1127,y:900,t:1527613938057};\\\", \\\"{x:1114,y:900,t:1527613938073};\\\", \\\"{x:1108,y:900,t:1527613938090};\\\", \\\"{x:1103,y:900,t:1527613938107};\\\", \\\"{x:1101,y:900,t:1527613938123};\\\", \\\"{x:1099,y:900,t:1527613938140};\\\", \\\"{x:1098,y:900,t:1527613938460};\\\", \\\"{x:1099,y:896,t:1527613938476};\\\", \\\"{x:1101,y:895,t:1527613938490};\\\", \\\"{x:1106,y:888,t:1527613938506};\\\", \\\"{x:1117,y:877,t:1527613938524};\\\", \\\"{x:1125,y:867,t:1527613938539};\\\", \\\"{x:1128,y:861,t:1527613938557};\\\", \\\"{x:1132,y:856,t:1527613938573};\\\", \\\"{x:1135,y:853,t:1527613938590};\\\", \\\"{x:1138,y:848,t:1527613938606};\\\", \\\"{x:1141,y:843,t:1527613938623};\\\", \\\"{x:1145,y:840,t:1527613938648};\\\", \\\"{x:1148,y:836,t:1527613938665};\\\", \\\"{x:1154,y:832,t:1527613938682};\\\", \\\"{x:1158,y:828,t:1527613938698};\\\", \\\"{x:1163,y:825,t:1527613938715};\\\", \\\"{x:1171,y:821,t:1527613938732};\\\", \\\"{x:1185,y:816,t:1527613938748};\\\", \\\"{x:1202,y:807,t:1527613938764};\\\", \\\"{x:1222,y:801,t:1527613938781};\\\", \\\"{x:1238,y:797,t:1527613938798};\\\", \\\"{x:1245,y:795,t:1527613938814};\\\", \\\"{x:1253,y:792,t:1527613938832};\\\", \\\"{x:1255,y:792,t:1527613938849};\\\", \\\"{x:1256,y:793,t:1527613938900};\\\", \\\"{x:1257,y:795,t:1527613938915};\\\", \\\"{x:1259,y:822,t:1527613938932};\\\", \\\"{x:1259,y:832,t:1527613938948};\\\", \\\"{x:1259,y:836,t:1527613938965};\\\", \\\"{x:1259,y:839,t:1527613938982};\\\", \\\"{x:1259,y:842,t:1527613938999};\\\", \\\"{x:1259,y:844,t:1527613939014};\\\", \\\"{x:1259,y:845,t:1527613939032};\\\", \\\"{x:1259,y:847,t:1527613939048};\\\", \\\"{x:1259,y:848,t:1527613939064};\\\", \\\"{x:1260,y:849,t:1527613939082};\\\", \\\"{x:1261,y:850,t:1527613939100};\\\", \\\"{x:1262,y:850,t:1527613939132};\\\", \\\"{x:1269,y:850,t:1527613939148};\\\", \\\"{x:1283,y:847,t:1527613939166};\\\", \\\"{x:1298,y:845,t:1527613939181};\\\", \\\"{x:1315,y:842,t:1527613939198};\\\", \\\"{x:1324,y:839,t:1527613939215};\\\", \\\"{x:1329,y:837,t:1527613939231};\\\", \\\"{x:1331,y:835,t:1527613939249};\\\", \\\"{x:1331,y:834,t:1527613939266};\\\", \\\"{x:1332,y:831,t:1527613939282};\\\", \\\"{x:1332,y:830,t:1527613939299};\\\", \\\"{x:1333,y:830,t:1527613939572};\\\", \\\"{x:1335,y:830,t:1527613939582};\\\", \\\"{x:1343,y:826,t:1527613939599};\\\", \\\"{x:1353,y:820,t:1527613939616};\\\", \\\"{x:1363,y:812,t:1527613939632};\\\", \\\"{x:1370,y:807,t:1527613939649};\\\", \\\"{x:1373,y:805,t:1527613939665};\\\", \\\"{x:1373,y:804,t:1527613939683};\\\", \\\"{x:1373,y:803,t:1527613939700};\\\", \\\"{x:1374,y:801,t:1527613939716};\\\", \\\"{x:1374,y:800,t:1527613939772};\\\", \\\"{x:1372,y:799,t:1527613939908};\\\", \\\"{x:1365,y:799,t:1527613939915};\\\", \\\"{x:1343,y:799,t:1527613939932};\\\", \\\"{x:1315,y:799,t:1527613939949};\\\", \\\"{x:1293,y:799,t:1527613939965};\\\", \\\"{x:1284,y:799,t:1527613939983};\\\", \\\"{x:1281,y:799,t:1527613939998};\\\", \\\"{x:1278,y:799,t:1527613940016};\\\", \\\"{x:1277,y:800,t:1527613940033};\\\", \\\"{x:1275,y:801,t:1527613940049};\\\", \\\"{x:1270,y:801,t:1527613940066};\\\", \\\"{x:1264,y:802,t:1527613940083};\\\", \\\"{x:1262,y:802,t:1527613940098};\\\", \\\"{x:1258,y:802,t:1527613940116};\\\", \\\"{x:1257,y:802,t:1527613940133};\\\", \\\"{x:1250,y:804,t:1527613940150};\\\", \\\"{x:1243,y:804,t:1527613940166};\\\", \\\"{x:1231,y:804,t:1527613940182};\\\", \\\"{x:1220,y:804,t:1527613940200};\\\", \\\"{x:1212,y:804,t:1527613940216};\\\", \\\"{x:1207,y:804,t:1527613940232};\\\", \\\"{x:1206,y:804,t:1527613940250};\\\", \\\"{x:1204,y:804,t:1527613940265};\\\", \\\"{x:1203,y:804,t:1527613940316};\\\", \\\"{x:1202,y:801,t:1527613940332};\\\", \\\"{x:1201,y:797,t:1527613940349};\\\", \\\"{x:1200,y:792,t:1527613940365};\\\", \\\"{x:1199,y:790,t:1527613940382};\\\", \\\"{x:1199,y:788,t:1527613940398};\\\", \\\"{x:1199,y:787,t:1527613940415};\\\", \\\"{x:1199,y:785,t:1527613940432};\\\", \\\"{x:1199,y:784,t:1527613940449};\\\", \\\"{x:1199,y:782,t:1527613940465};\\\", \\\"{x:1199,y:781,t:1527613940483};\\\", \\\"{x:1199,y:780,t:1527613940508};\\\", \\\"{x:1199,y:779,t:1527613940539};\\\", \\\"{x:1199,y:777,t:1527613940580};\\\", \\\"{x:1199,y:776,t:1527613940595};\\\", \\\"{x:1199,y:774,t:1527613940604};\\\", \\\"{x:1199,y:773,t:1527613940616};\\\", \\\"{x:1197,y:771,t:1527613940632};\\\", \\\"{x:1196,y:768,t:1527613940649};\\\", \\\"{x:1196,y:766,t:1527613940667};\\\", \\\"{x:1196,y:765,t:1527613940684};\\\", \\\"{x:1195,y:764,t:1527613940699};\\\", \\\"{x:1194,y:763,t:1527613940717};\\\", \\\"{x:1193,y:762,t:1527613940748};\\\", \\\"{x:1193,y:761,t:1527613940852};\\\", \\\"{x:1194,y:761,t:1527613940997};\\\", \\\"{x:1198,y:761,t:1527613941004};\\\", \\\"{x:1201,y:761,t:1527613941016};\\\", \\\"{x:1208,y:761,t:1527613941034};\\\", \\\"{x:1216,y:761,t:1527613941050};\\\", \\\"{x:1222,y:761,t:1527613941067};\\\", \\\"{x:1229,y:761,t:1527613941082};\\\", \\\"{x:1233,y:761,t:1527613941099};\\\", \\\"{x:1236,y:759,t:1527613941115};\\\", \\\"{x:1239,y:759,t:1527613941133};\\\", \\\"{x:1242,y:758,t:1527613941149};\\\", \\\"{x:1245,y:757,t:1527613941166};\\\", \\\"{x:1250,y:755,t:1527613941183};\\\", \\\"{x:1254,y:754,t:1527613941199};\\\", \\\"{x:1258,y:751,t:1527613941216};\\\", \\\"{x:1260,y:751,t:1527613941234};\\\", \\\"{x:1264,y:750,t:1527613941249};\\\", \\\"{x:1265,y:749,t:1527613941266};\\\", \\\"{x:1266,y:748,t:1527613941283};\\\", \\\"{x:1268,y:748,t:1527613941307};\\\", \\\"{x:1266,y:748,t:1527613941468};\\\", \\\"{x:1260,y:750,t:1527613941484};\\\", \\\"{x:1258,y:750,t:1527613941500};\\\", \\\"{x:1257,y:753,t:1527613941516};\\\", \\\"{x:1257,y:757,t:1527613941534};\\\", \\\"{x:1261,y:761,t:1527613941551};\\\", \\\"{x:1274,y:765,t:1527613941567};\\\", \\\"{x:1287,y:767,t:1527613941584};\\\", \\\"{x:1299,y:767,t:1527613941601};\\\", \\\"{x:1308,y:767,t:1527613941616};\\\", \\\"{x:1313,y:767,t:1527613941633};\\\", \\\"{x:1314,y:767,t:1527613941650};\\\", \\\"{x:1315,y:767,t:1527613941666};\\\", \\\"{x:1317,y:767,t:1527613941683};\\\", \\\"{x:1319,y:766,t:1527613941700};\\\", \\\"{x:1325,y:764,t:1527613941717};\\\", \\\"{x:1329,y:762,t:1527613941734};\\\", \\\"{x:1330,y:761,t:1527613941750};\\\", \\\"{x:1332,y:761,t:1527613941767};\\\", \\\"{x:1332,y:760,t:1527613941784};\\\", \\\"{x:1333,y:760,t:1527613941860};\\\", \\\"{x:1333,y:759,t:1527613942132};\\\", \\\"{x:1335,y:759,t:1527613942156};\\\", \\\"{x:1336,y:759,t:1527613942168};\\\", \\\"{x:1340,y:761,t:1527613942184};\\\", \\\"{x:1344,y:763,t:1527613942202};\\\", \\\"{x:1352,y:766,t:1527613942217};\\\", \\\"{x:1363,y:770,t:1527613942234};\\\", \\\"{x:1374,y:772,t:1527613942251};\\\", \\\"{x:1381,y:773,t:1527613942267};\\\", \\\"{x:1385,y:773,t:1527613942284};\\\", \\\"{x:1386,y:773,t:1527613942301};\\\", \\\"{x:1388,y:773,t:1527613942340};\\\", \\\"{x:1389,y:773,t:1527613942356};\\\", \\\"{x:1390,y:772,t:1527613942372};\\\", \\\"{x:1391,y:771,t:1527613942384};\\\", \\\"{x:1393,y:768,t:1527613942401};\\\", \\\"{x:1393,y:767,t:1527613942418};\\\", \\\"{x:1393,y:766,t:1527613942434};\\\", \\\"{x:1393,y:765,t:1527613942452};\\\", \\\"{x:1393,y:763,t:1527613942669};\\\", \\\"{x:1393,y:762,t:1527613942692};\\\", \\\"{x:1393,y:761,t:1527613942701};\\\", \\\"{x:1392,y:761,t:1527613942724};\\\", \\\"{x:1388,y:761,t:1527613943044};\\\", \\\"{x:1381,y:762,t:1527613943052};\\\", \\\"{x:1366,y:768,t:1527613943068};\\\", \\\"{x:1350,y:777,t:1527613943085};\\\", \\\"{x:1334,y:784,t:1527613943102};\\\", \\\"{x:1326,y:790,t:1527613943118};\\\", \\\"{x:1324,y:791,t:1527613943134};\\\", \\\"{x:1323,y:793,t:1527613943151};\\\", \\\"{x:1323,y:789,t:1527613943468};\\\", \\\"{x:1324,y:786,t:1527613943485};\\\", \\\"{x:1328,y:780,t:1527613943502};\\\", \\\"{x:1332,y:775,t:1527613943519};\\\", \\\"{x:1338,y:771,t:1527613943535};\\\", \\\"{x:1343,y:768,t:1527613943551};\\\", \\\"{x:1352,y:764,t:1527613943568};\\\", \\\"{x:1363,y:761,t:1527613943584};\\\", \\\"{x:1374,y:758,t:1527613943601};\\\", \\\"{x:1389,y:756,t:1527613943618};\\\", \\\"{x:1402,y:754,t:1527613943634};\\\", \\\"{x:1418,y:749,t:1527613943651};\\\", \\\"{x:1427,y:746,t:1527613943668};\\\", \\\"{x:1433,y:745,t:1527613943684};\\\", \\\"{x:1437,y:743,t:1527613943702};\\\", \\\"{x:1442,y:742,t:1527613943718};\\\", \\\"{x:1446,y:741,t:1527613943734};\\\", \\\"{x:1450,y:740,t:1527613943751};\\\", \\\"{x:1455,y:736,t:1527613943768};\\\", \\\"{x:1463,y:733,t:1527613943784};\\\", \\\"{x:1472,y:731,t:1527613943802};\\\", \\\"{x:1478,y:728,t:1527613943819};\\\", \\\"{x:1484,y:724,t:1527613943834};\\\", \\\"{x:1489,y:721,t:1527613943851};\\\", \\\"{x:1489,y:720,t:1527613943869};\\\", \\\"{x:1491,y:719,t:1527613943884};\\\", \\\"{x:1492,y:718,t:1527613943901};\\\", \\\"{x:1493,y:716,t:1527613943919};\\\", \\\"{x:1495,y:713,t:1527613943935};\\\", \\\"{x:1497,y:711,t:1527613943952};\\\", \\\"{x:1499,y:707,t:1527613943969};\\\", \\\"{x:1501,y:704,t:1527613943986};\\\", \\\"{x:1502,y:703,t:1527613944002};\\\", \\\"{x:1503,y:701,t:1527613944019};\\\", \\\"{x:1503,y:699,t:1527613944036};\\\", \\\"{x:1503,y:698,t:1527613944052};\\\", \\\"{x:1505,y:697,t:1527613944068};\\\", \\\"{x:1505,y:695,t:1527613944086};\\\", \\\"{x:1505,y:694,t:1527613944131};\\\", \\\"{x:1506,y:694,t:1527613944172};\\\", \\\"{x:1505,y:694,t:1527613944412};\\\", \\\"{x:1500,y:695,t:1527613944420};\\\", \\\"{x:1489,y:708,t:1527613944436};\\\", \\\"{x:1480,y:715,t:1527613944452};\\\", \\\"{x:1469,y:725,t:1527613944468};\\\", \\\"{x:1462,y:732,t:1527613944485};\\\", \\\"{x:1460,y:734,t:1527613944503};\\\", \\\"{x:1460,y:732,t:1527613944660};\\\", \\\"{x:1460,y:727,t:1527613944669};\\\", \\\"{x:1460,y:722,t:1527613944686};\\\", \\\"{x:1460,y:719,t:1527613944702};\\\", \\\"{x:1460,y:715,t:1527613944719};\\\", \\\"{x:1460,y:713,t:1527613944736};\\\", \\\"{x:1460,y:712,t:1527613944753};\\\", \\\"{x:1460,y:710,t:1527613944769};\\\", \\\"{x:1460,y:709,t:1527613944786};\\\", \\\"{x:1458,y:708,t:1527613944932};\\\", \\\"{x:1455,y:708,t:1527613944940};\\\", \\\"{x:1451,y:709,t:1527613944953};\\\", \\\"{x:1441,y:712,t:1527613944970};\\\", \\\"{x:1429,y:716,t:1527613944986};\\\", \\\"{x:1421,y:718,t:1527613945003};\\\", \\\"{x:1415,y:720,t:1527613945019};\\\", \\\"{x:1412,y:720,t:1527613945036};\\\", \\\"{x:1410,y:720,t:1527613945053};\\\", \\\"{x:1402,y:723,t:1527613945070};\\\", \\\"{x:1395,y:724,t:1527613945086};\\\", \\\"{x:1389,y:724,t:1527613945102};\\\", \\\"{x:1386,y:724,t:1527613945120};\\\", \\\"{x:1385,y:724,t:1527613945188};\\\", \\\"{x:1384,y:724,t:1527613945260};\\\", \\\"{x:1384,y:723,t:1527613945404};\\\", \\\"{x:1384,y:719,t:1527613945420};\\\", \\\"{x:1384,y:716,t:1527613945437};\\\", \\\"{x:1385,y:715,t:1527613945453};\\\", \\\"{x:1387,y:713,t:1527613945469};\\\", \\\"{x:1387,y:712,t:1527613945487};\\\", \\\"{x:1388,y:711,t:1527613945503};\\\", \\\"{x:1389,y:709,t:1527613945520};\\\", \\\"{x:1390,y:709,t:1527613945636};\\\", \\\"{x:1393,y:706,t:1527613945651};\\\", \\\"{x:1394,y:705,t:1527613945669};\\\", \\\"{x:1397,y:702,t:1527613945686};\\\", \\\"{x:1400,y:701,t:1527613945702};\\\", \\\"{x:1403,y:698,t:1527613945719};\\\", \\\"{x:1406,y:696,t:1527613945736};\\\", \\\"{x:1410,y:694,t:1527613945752};\\\", \\\"{x:1411,y:693,t:1527613945769};\\\", \\\"{x:1412,y:692,t:1527613945786};\\\", \\\"{x:1413,y:692,t:1527613945803};\\\", \\\"{x:1414,y:692,t:1527613945876};\\\", \\\"{x:1415,y:692,t:1527613946637};\\\", \\\"{x:1418,y:695,t:1527613946654};\\\", \\\"{x:1419,y:698,t:1527613946671};\\\", \\\"{x:1420,y:703,t:1527613946687};\\\", \\\"{x:1421,y:705,t:1527613946704};\\\", \\\"{x:1421,y:706,t:1527613946721};\\\", \\\"{x:1422,y:707,t:1527613946738};\\\", \\\"{x:1424,y:707,t:1527613946948};\\\", \\\"{x:1426,y:707,t:1527613946955};\\\", \\\"{x:1427,y:707,t:1527613946971};\\\", \\\"{x:1437,y:706,t:1527613946988};\\\", \\\"{x:1444,y:704,t:1527613947004};\\\", \\\"{x:1449,y:704,t:1527613947020};\\\", \\\"{x:1452,y:701,t:1527613947038};\\\", \\\"{x:1455,y:701,t:1527613947054};\\\", \\\"{x:1457,y:700,t:1527613947072};\\\", \\\"{x:1458,y:699,t:1527613947088};\\\", \\\"{x:1459,y:699,t:1527613947116};\\\", \\\"{x:1459,y:698,t:1527613947125};\\\", \\\"{x:1461,y:698,t:1527613947139};\\\", \\\"{x:1462,y:697,t:1527613947153};\\\", \\\"{x:1463,y:696,t:1527613947170};\\\", \\\"{x:1468,y:694,t:1527613947187};\\\", \\\"{x:1471,y:692,t:1527613947204};\\\", \\\"{x:1473,y:691,t:1527613947220};\\\", \\\"{x:1474,y:690,t:1527613947242};\\\", \\\"{x:1475,y:690,t:1527613947267};\\\", \\\"{x:1476,y:689,t:1527613947355};\\\", \\\"{x:1477,y:688,t:1527613947395};\\\", \\\"{x:1478,y:688,t:1527613947420};\\\", \\\"{x:1479,y:688,t:1527613947484};\\\", \\\"{x:1481,y:688,t:1527613947548};\\\", \\\"{x:1482,y:688,t:1527613947571};\\\", \\\"{x:1484,y:690,t:1527613947588};\\\", \\\"{x:1485,y:691,t:1527613947605};\\\", \\\"{x:1486,y:692,t:1527613947621};\\\", \\\"{x:1487,y:693,t:1527613947660};\\\", \\\"{x:1488,y:693,t:1527613947700};\\\", \\\"{x:1491,y:694,t:1527613947740};\\\", \\\"{x:1492,y:694,t:1527613947755};\\\", \\\"{x:1501,y:695,t:1527613947772};\\\", \\\"{x:1507,y:695,t:1527613947788};\\\", \\\"{x:1518,y:696,t:1527613947805};\\\", \\\"{x:1526,y:696,t:1527613947822};\\\", \\\"{x:1530,y:696,t:1527613947838};\\\", \\\"{x:1533,y:695,t:1527613947855};\\\", \\\"{x:1536,y:694,t:1527613947872};\\\", \\\"{x:1538,y:693,t:1527613947888};\\\", \\\"{x:1541,y:692,t:1527613947905};\\\", \\\"{x:1541,y:691,t:1527613947924};\\\", \\\"{x:1543,y:691,t:1527613947938};\\\", \\\"{x:1544,y:690,t:1527613947988};\\\", \\\"{x:1545,y:690,t:1527613948164};\\\", \\\"{x:1546,y:690,t:1527613948172};\\\", \\\"{x:1548,y:690,t:1527613948189};\\\", \\\"{x:1552,y:693,t:1527613948204};\\\", \\\"{x:1557,y:695,t:1527613948222};\\\", \\\"{x:1561,y:696,t:1527613948239};\\\", \\\"{x:1564,y:697,t:1527613948255};\\\", \\\"{x:1569,y:699,t:1527613948272};\\\", \\\"{x:1574,y:701,t:1527613948289};\\\", \\\"{x:1581,y:703,t:1527613948304};\\\", \\\"{x:1582,y:704,t:1527613948323};\\\", \\\"{x:1584,y:704,t:1527613948339};\\\", \\\"{x:1584,y:705,t:1527613948355};\\\", \\\"{x:1585,y:705,t:1527613948404};\\\", \\\"{x:1589,y:705,t:1527613948422};\\\", \\\"{x:1590,y:705,t:1527613948439};\\\", \\\"{x:1596,y:702,t:1527613948455};\\\", \\\"{x:1603,y:700,t:1527613948471};\\\", \\\"{x:1609,y:698,t:1527613948490};\\\", \\\"{x:1616,y:697,t:1527613948505};\\\", \\\"{x:1623,y:694,t:1527613948524};\\\", \\\"{x:1623,y:693,t:1527613948539};\\\", \\\"{x:1624,y:693,t:1527613948554};\\\", \\\"{x:1625,y:693,t:1527613948572};\\\", \\\"{x:1626,y:693,t:1527613948588};\\\", \\\"{x:1626,y:692,t:1527613948635};\\\", \\\"{x:1623,y:693,t:1527613949116};\\\", \\\"{x:1620,y:695,t:1527613949124};\\\", \\\"{x:1615,y:697,t:1527613949140};\\\", \\\"{x:1613,y:698,t:1527613949155};\\\", \\\"{x:1612,y:698,t:1527613949173};\\\", \\\"{x:1611,y:698,t:1527613949212};\\\", \\\"{x:1611,y:697,t:1527613949388};\\\", \\\"{x:1611,y:696,t:1527613949406};\\\", \\\"{x:1612,y:696,t:1527613949427};\\\", \\\"{x:1611,y:695,t:1527613958435};\\\", \\\"{x:1589,y:684,t:1527613958447};\\\", \\\"{x:1536,y:666,t:1527613958462};\\\", \\\"{x:1492,y:658,t:1527613958479};\\\", \\\"{x:1460,y:651,t:1527613958497};\\\", \\\"{x:1454,y:651,t:1527613958513};\\\", \\\"{x:1451,y:648,t:1527613958596};\\\", \\\"{x:1441,y:641,t:1527613958613};\\\", \\\"{x:1432,y:633,t:1527613958629};\\\", \\\"{x:1425,y:627,t:1527613958647};\\\", \\\"{x:1420,y:624,t:1527613958664};\\\", \\\"{x:1419,y:623,t:1527613958680};\\\", \\\"{x:1416,y:621,t:1527613958696};\\\", \\\"{x:1411,y:617,t:1527613958713};\\\", \\\"{x:1402,y:612,t:1527613958729};\\\", \\\"{x:1382,y:604,t:1527613958746};\\\", \\\"{x:1351,y:595,t:1527613958763};\\\", \\\"{x:1336,y:589,t:1527613958780};\\\", \\\"{x:1328,y:587,t:1527613958796};\\\", \\\"{x:1327,y:587,t:1527613958814};\\\", \\\"{x:1326,y:587,t:1527613958843};\\\", \\\"{x:1325,y:586,t:1527613958851};\\\", \\\"{x:1324,y:585,t:1527613958875};\\\", \\\"{x:1322,y:583,t:1527613958892};\\\", \\\"{x:1321,y:581,t:1527613958956};\\\", \\\"{x:1321,y:580,t:1527613958995};\\\", \\\"{x:1321,y:579,t:1527613959013};\\\", \\\"{x:1321,y:577,t:1527613959029};\\\", \\\"{x:1321,y:576,t:1527613959046};\\\", \\\"{x:1321,y:573,t:1527613959064};\\\", \\\"{x:1321,y:571,t:1527613959081};\\\", \\\"{x:1321,y:569,t:1527613959096};\\\", \\\"{x:1321,y:566,t:1527613959113};\\\", \\\"{x:1321,y:564,t:1527613959129};\\\", \\\"{x:1321,y:563,t:1527613959147};\\\", \\\"{x:1321,y:560,t:1527613959163};\\\", \\\"{x:1321,y:559,t:1527613959180};\\\", \\\"{x:1321,y:557,t:1527613959196};\\\", \\\"{x:1322,y:556,t:1527613959213};\\\", \\\"{x:1323,y:554,t:1527613959243};\\\", \\\"{x:1323,y:553,t:1527613959290};\\\", \\\"{x:1324,y:551,t:1527613959339};\\\", \\\"{x:1324,y:550,t:1527613959378};\\\", \\\"{x:1325,y:550,t:1527613959396};\\\", \\\"{x:1326,y:550,t:1527613959764};\\\", \\\"{x:1345,y:568,t:1527613959780};\\\", \\\"{x:1363,y:585,t:1527613959797};\\\", \\\"{x:1378,y:594,t:1527613959813};\\\", \\\"{x:1389,y:599,t:1527613959829};\\\", \\\"{x:1390,y:600,t:1527613959847};\\\", \\\"{x:1392,y:600,t:1527613959867};\\\", \\\"{x:1393,y:600,t:1527613959880};\\\", \\\"{x:1394,y:598,t:1527613959897};\\\", \\\"{x:1396,y:593,t:1527613959913};\\\", \\\"{x:1397,y:589,t:1527613959929};\\\", \\\"{x:1398,y:580,t:1527613959946};\\\", \\\"{x:1398,y:574,t:1527613959964};\\\", \\\"{x:1398,y:564,t:1527613959980};\\\", \\\"{x:1398,y:557,t:1527613959997};\\\", \\\"{x:1395,y:553,t:1527613960014};\\\", \\\"{x:1394,y:549,t:1527613960030};\\\", \\\"{x:1392,y:547,t:1527613960047};\\\", \\\"{x:1392,y:545,t:1527613960064};\\\", \\\"{x:1391,y:545,t:1527613960080};\\\", \\\"{x:1391,y:543,t:1527613960097};\\\", \\\"{x:1391,y:544,t:1527613960196};\\\", \\\"{x:1391,y:556,t:1527613960203};\\\", \\\"{x:1391,y:568,t:1527613960215};\\\", \\\"{x:1391,y:595,t:1527613960231};\\\", \\\"{x:1396,y:609,t:1527613960247};\\\", \\\"{x:1400,y:615,t:1527613960264};\\\", \\\"{x:1401,y:615,t:1527613960280};\\\", \\\"{x:1402,y:615,t:1527613960308};\\\", \\\"{x:1403,y:614,t:1527613960325};\\\", \\\"{x:1405,y:610,t:1527613960330};\\\", \\\"{x:1409,y:602,t:1527613960346};\\\", \\\"{x:1414,y:594,t:1527613960364};\\\", \\\"{x:1419,y:583,t:1527613960379};\\\", \\\"{x:1424,y:574,t:1527613960397};\\\", \\\"{x:1425,y:569,t:1527613960413};\\\", \\\"{x:1427,y:566,t:1527613960429};\\\", \\\"{x:1430,y:561,t:1527613960446};\\\", \\\"{x:1432,y:556,t:1527613960463};\\\", \\\"{x:1433,y:555,t:1527613960481};\\\", \\\"{x:1435,y:553,t:1527613960497};\\\", \\\"{x:1435,y:551,t:1527613960514};\\\", \\\"{x:1436,y:550,t:1527613960531};\\\", \\\"{x:1437,y:548,t:1527613960547};\\\", \\\"{x:1443,y:555,t:1527613960659};\\\", \\\"{x:1449,y:565,t:1527613960667};\\\", \\\"{x:1455,y:572,t:1527613960681};\\\", \\\"{x:1464,y:583,t:1527613960697};\\\", \\\"{x:1474,y:592,t:1527613960714};\\\", \\\"{x:1478,y:595,t:1527613960731};\\\", \\\"{x:1480,y:595,t:1527613960780};\\\", \\\"{x:1483,y:593,t:1527613960795};\\\", \\\"{x:1488,y:590,t:1527613960804};\\\", \\\"{x:1491,y:587,t:1527613960815};\\\", \\\"{x:1504,y:576,t:1527613960831};\\\", \\\"{x:1512,y:571,t:1527613960847};\\\", \\\"{x:1517,y:568,t:1527613960864};\\\", \\\"{x:1519,y:565,t:1527613960881};\\\", \\\"{x:1520,y:562,t:1527613960897};\\\", \\\"{x:1521,y:560,t:1527613960914};\\\", \\\"{x:1523,y:559,t:1527613960932};\\\", \\\"{x:1523,y:557,t:1527613960947};\\\", \\\"{x:1527,y:561,t:1527613961092};\\\", \\\"{x:1531,y:569,t:1527613961099};\\\", \\\"{x:1536,y:576,t:1527613961113};\\\", \\\"{x:1548,y:585,t:1527613961130};\\\", \\\"{x:1554,y:588,t:1527613961147};\\\", \\\"{x:1557,y:589,t:1527613961164};\\\", \\\"{x:1559,y:589,t:1527613961203};\\\", \\\"{x:1560,y:588,t:1527613961214};\\\", \\\"{x:1564,y:581,t:1527613961231};\\\", \\\"{x:1569,y:575,t:1527613961248};\\\", \\\"{x:1573,y:570,t:1527613961264};\\\", \\\"{x:1577,y:564,t:1527613961281};\\\", \\\"{x:1579,y:561,t:1527613961298};\\\", \\\"{x:1580,y:560,t:1527613961314};\\\", \\\"{x:1581,y:558,t:1527613961331};\\\", \\\"{x:1582,y:556,t:1527613961348};\\\", \\\"{x:1582,y:555,t:1527613961364};\\\", \\\"{x:1583,y:554,t:1527613961395};\\\", \\\"{x:1589,y:554,t:1527613961635};\\\", \\\"{x:1598,y:569,t:1527613961649};\\\", \\\"{x:1617,y:594,t:1527613961665};\\\", \\\"{x:1639,y:610,t:1527613961682};\\\", \\\"{x:1655,y:620,t:1527613961698};\\\", \\\"{x:1667,y:625,t:1527613961715};\\\", \\\"{x:1668,y:625,t:1527613961731};\\\", \\\"{x:1671,y:623,t:1527613961756};\\\", \\\"{x:1672,y:620,t:1527613961766};\\\", \\\"{x:1678,y:609,t:1527613961782};\\\", \\\"{x:1685,y:601,t:1527613961798};\\\", \\\"{x:1691,y:591,t:1527613961816};\\\", \\\"{x:1694,y:583,t:1527613961832};\\\", \\\"{x:1695,y:577,t:1527613961848};\\\", \\\"{x:1696,y:573,t:1527613961865};\\\", \\\"{x:1697,y:569,t:1527613961883};\\\", \\\"{x:1697,y:568,t:1527613961898};\\\", \\\"{x:1697,y:565,t:1527613961916};\\\", \\\"{x:1697,y:562,t:1527613961932};\\\", \\\"{x:1697,y:560,t:1527613961949};\\\", \\\"{x:1697,y:558,t:1527613961966};\\\", \\\"{x:1697,y:557,t:1527613961983};\\\", \\\"{x:1697,y:556,t:1527613961998};\\\", \\\"{x:1697,y:555,t:1527613962044};\\\", \\\"{x:1697,y:554,t:1527613962268};\\\", \\\"{x:1695,y:554,t:1527613962468};\\\", \\\"{x:1692,y:554,t:1527613962483};\\\", \\\"{x:1688,y:554,t:1527613962499};\\\", \\\"{x:1676,y:559,t:1527613962516};\\\", \\\"{x:1668,y:564,t:1527613962532};\\\", \\\"{x:1662,y:565,t:1527613962549};\\\", \\\"{x:1660,y:566,t:1527613962566};\\\", \\\"{x:1651,y:570,t:1527613962582};\\\", \\\"{x:1639,y:575,t:1527613962600};\\\", \\\"{x:1620,y:581,t:1527613962615};\\\", \\\"{x:1600,y:585,t:1527613962632};\\\", \\\"{x:1582,y:587,t:1527613962650};\\\", \\\"{x:1560,y:591,t:1527613962666};\\\", \\\"{x:1541,y:593,t:1527613962682};\\\", \\\"{x:1515,y:597,t:1527613962700};\\\", \\\"{x:1504,y:599,t:1527613962715};\\\", \\\"{x:1495,y:603,t:1527613962733};\\\", \\\"{x:1488,y:604,t:1527613962749};\\\", \\\"{x:1482,y:606,t:1527613962766};\\\", \\\"{x:1477,y:606,t:1527613962783};\\\", \\\"{x:1472,y:607,t:1527613962800};\\\", \\\"{x:1468,y:607,t:1527613962817};\\\", \\\"{x:1463,y:609,t:1527613962833};\\\", \\\"{x:1461,y:610,t:1527613962849};\\\", \\\"{x:1458,y:610,t:1527613962867};\\\", \\\"{x:1457,y:610,t:1527613962882};\\\", \\\"{x:1457,y:611,t:1527613962940};\\\", \\\"{x:1455,y:611,t:1527613963675};\\\", \\\"{x:1450,y:611,t:1527613963682};\\\", \\\"{x:1439,y:611,t:1527613963699};\\\", \\\"{x:1428,y:611,t:1527613963716};\\\", \\\"{x:1425,y:611,t:1527613963733};\\\", \\\"{x:1424,y:611,t:1527613963778};\\\", \\\"{x:1423,y:610,t:1527613963819};\\\", \\\"{x:1420,y:604,t:1527613963833};\\\", \\\"{x:1417,y:591,t:1527613963850};\\\", \\\"{x:1414,y:581,t:1527613963866};\\\", \\\"{x:1414,y:563,t:1527613963884};\\\", \\\"{x:1414,y:554,t:1527613963902};\\\", \\\"{x:1416,y:546,t:1527613963916};\\\", \\\"{x:1421,y:536,t:1527613963934};\\\", \\\"{x:1425,y:528,t:1527613963951};\\\", \\\"{x:1427,y:522,t:1527613963967};\\\", \\\"{x:1428,y:518,t:1527613963984};\\\", \\\"{x:1430,y:515,t:1527613964000};\\\", \\\"{x:1432,y:511,t:1527613964016};\\\", \\\"{x:1433,y:508,t:1527613964034};\\\", \\\"{x:1435,y:505,t:1527613964051};\\\", \\\"{x:1437,y:500,t:1527613964067};\\\", \\\"{x:1439,y:495,t:1527613964083};\\\", \\\"{x:1440,y:493,t:1527613964101};\\\", \\\"{x:1442,y:489,t:1527613964117};\\\", \\\"{x:1442,y:487,t:1527613964134};\\\", \\\"{x:1443,y:484,t:1527613964151};\\\", \\\"{x:1443,y:474,t:1527613964167};\\\", \\\"{x:1441,y:460,t:1527613964184};\\\", \\\"{x:1441,y:457,t:1527613964201};\\\", \\\"{x:1441,y:455,t:1527613964217};\\\", \\\"{x:1440,y:453,t:1527613964234};\\\", \\\"{x:1440,y:451,t:1527613964250};\\\", \\\"{x:1439,y:450,t:1527613964268};\\\", \\\"{x:1439,y:449,t:1527613964283};\\\", \\\"{x:1439,y:448,t:1527613964307};\\\", \\\"{x:1439,y:447,t:1527613964331};\\\", \\\"{x:1439,y:446,t:1527613964363};\\\", \\\"{x:1439,y:445,t:1527613964378};\\\", \\\"{x:1438,y:444,t:1527613964411};\\\", \\\"{x:1438,y:446,t:1527613964539};\\\", \\\"{x:1436,y:463,t:1527613964550};\\\", \\\"{x:1429,y:526,t:1527613964567};\\\", \\\"{x:1422,y:571,t:1527613964583};\\\", \\\"{x:1421,y:598,t:1527613964600};\\\", \\\"{x:1421,y:615,t:1527613964617};\\\", \\\"{x:1421,y:625,t:1527613964634};\\\", \\\"{x:1421,y:628,t:1527613964650};\\\", \\\"{x:1422,y:633,t:1527613964667};\\\", \\\"{x:1423,y:638,t:1527613964685};\\\", \\\"{x:1428,y:644,t:1527613964700};\\\", \\\"{x:1431,y:647,t:1527613964717};\\\", \\\"{x:1434,y:651,t:1527613964734};\\\", \\\"{x:1439,y:658,t:1527613964751};\\\", \\\"{x:1442,y:662,t:1527613964768};\\\", \\\"{x:1446,y:666,t:1527613964784};\\\", \\\"{x:1450,y:672,t:1527613964801};\\\", \\\"{x:1454,y:679,t:1527613964817};\\\", \\\"{x:1458,y:686,t:1527613964835};\\\", \\\"{x:1464,y:696,t:1527613964851};\\\", \\\"{x:1471,y:707,t:1527613964867};\\\", \\\"{x:1475,y:714,t:1527613964885};\\\", \\\"{x:1477,y:718,t:1527613964901};\\\", \\\"{x:1479,y:723,t:1527613964917};\\\", \\\"{x:1482,y:733,t:1527613964934};\\\", \\\"{x:1489,y:747,t:1527613964951};\\\", \\\"{x:1496,y:762,t:1527613964967};\\\", \\\"{x:1500,y:774,t:1527613964984};\\\", \\\"{x:1501,y:780,t:1527613965000};\\\", \\\"{x:1504,y:786,t:1527613965018};\\\", \\\"{x:1505,y:792,t:1527613965034};\\\", \\\"{x:1505,y:795,t:1527613965050};\\\", \\\"{x:1506,y:795,t:1527613965099};\\\", \\\"{x:1507,y:795,t:1527613965164};\\\", \\\"{x:1510,y:792,t:1527613965171};\\\", \\\"{x:1518,y:789,t:1527613965185};\\\", \\\"{x:1534,y:778,t:1527613965201};\\\", \\\"{x:1555,y:768,t:1527613965218};\\\", \\\"{x:1573,y:758,t:1527613965235};\\\", \\\"{x:1594,y:743,t:1527613965251};\\\", \\\"{x:1599,y:737,t:1527613965267};\\\", \\\"{x:1604,y:730,t:1527613965284};\\\", \\\"{x:1605,y:726,t:1527613965301};\\\", \\\"{x:1606,y:723,t:1527613965317};\\\", \\\"{x:1608,y:718,t:1527613965334};\\\", \\\"{x:1609,y:712,t:1527613965352};\\\", \\\"{x:1610,y:711,t:1527613965367};\\\", \\\"{x:1611,y:708,t:1527613965384};\\\", \\\"{x:1611,y:707,t:1527613965402};\\\", \\\"{x:1612,y:706,t:1527613965417};\\\", \\\"{x:1612,y:702,t:1527613965434};\\\", \\\"{x:1612,y:697,t:1527613965451};\\\", \\\"{x:1612,y:695,t:1527613965467};\\\", \\\"{x:1612,y:694,t:1527613965491};\\\", \\\"{x:1612,y:693,t:1527613965501};\\\", \\\"{x:1612,y:692,t:1527613965523};\\\", \\\"{x:1609,y:696,t:1527613966068};\\\", \\\"{x:1588,y:712,t:1527613966085};\\\", \\\"{x:1557,y:726,t:1527613966101};\\\", \\\"{x:1511,y:742,t:1527613966119};\\\", \\\"{x:1480,y:749,t:1527613966134};\\\", \\\"{x:1458,y:754,t:1527613966151};\\\", \\\"{x:1445,y:756,t:1527613966169};\\\", \\\"{x:1438,y:757,t:1527613966185};\\\", \\\"{x:1433,y:758,t:1527613966202};\\\", \\\"{x:1431,y:758,t:1527613966218};\\\", \\\"{x:1422,y:760,t:1527613966234};\\\", \\\"{x:1414,y:762,t:1527613966251};\\\", \\\"{x:1405,y:762,t:1527613966268};\\\", \\\"{x:1398,y:763,t:1527613966284};\\\", \\\"{x:1392,y:764,t:1527613966301};\\\", \\\"{x:1387,y:764,t:1527613966317};\\\", \\\"{x:1385,y:765,t:1527613966335};\\\", \\\"{x:1380,y:766,t:1527613966351};\\\", \\\"{x:1374,y:767,t:1527613966368};\\\", \\\"{x:1367,y:768,t:1527613966385};\\\", \\\"{x:1357,y:770,t:1527613966401};\\\", \\\"{x:1347,y:770,t:1527613966418};\\\", \\\"{x:1336,y:771,t:1527613966434};\\\", \\\"{x:1332,y:772,t:1527613966452};\\\", \\\"{x:1331,y:772,t:1527613966468};\\\", \\\"{x:1330,y:772,t:1527613966523};\\\", \\\"{x:1329,y:772,t:1527613966539};\\\", \\\"{x:1328,y:772,t:1527613966572};\\\", \\\"{x:1328,y:771,t:1527613967980};\\\", \\\"{x:1330,y:769,t:1527613967988};\\\", \\\"{x:1333,y:768,t:1527613968003};\\\", \\\"{x:1342,y:760,t:1527613968019};\\\", \\\"{x:1353,y:752,t:1527613968036};\\\", \\\"{x:1360,y:747,t:1527613968053};\\\", \\\"{x:1363,y:745,t:1527613968070};\\\", \\\"{x:1365,y:744,t:1527613968087};\\\", \\\"{x:1365,y:743,t:1527613968107};\\\", \\\"{x:1365,y:748,t:1527613968420};\\\", \\\"{x:1333,y:782,t:1527613968436};\\\", \\\"{x:1309,y:805,t:1527613968454};\\\", \\\"{x:1290,y:816,t:1527613968469};\\\", \\\"{x:1285,y:820,t:1527613968487};\\\", \\\"{x:1284,y:820,t:1527613968504};\\\", \\\"{x:1286,y:817,t:1527613968547};\\\", \\\"{x:1287,y:817,t:1527613968555};\\\", \\\"{x:1287,y:815,t:1527613968570};\\\", \\\"{x:1290,y:811,t:1527613968587};\\\", \\\"{x:1291,y:808,t:1527613968604};\\\", \\\"{x:1292,y:805,t:1527613968620};\\\", \\\"{x:1293,y:803,t:1527613968637};\\\", \\\"{x:1294,y:800,t:1527613968654};\\\", \\\"{x:1297,y:796,t:1527613968671};\\\", \\\"{x:1298,y:793,t:1527613968687};\\\", \\\"{x:1300,y:788,t:1527613968704};\\\", \\\"{x:1302,y:784,t:1527613968720};\\\", \\\"{x:1305,y:779,t:1527613968736};\\\", \\\"{x:1306,y:775,t:1527613968753};\\\", \\\"{x:1309,y:772,t:1527613968771};\\\", \\\"{x:1310,y:770,t:1527613968787};\\\", \\\"{x:1311,y:766,t:1527613968804};\\\", \\\"{x:1314,y:764,t:1527613968821};\\\", \\\"{x:1316,y:762,t:1527613968837};\\\", \\\"{x:1318,y:761,t:1527613968859};\\\", \\\"{x:1319,y:759,t:1527613968883};\\\", \\\"{x:1320,y:759,t:1527613968900};\\\", \\\"{x:1320,y:758,t:1527613968923};\\\", \\\"{x:1321,y:756,t:1527613968939};\\\", \\\"{x:1322,y:756,t:1527613968954};\\\", \\\"{x:1323,y:755,t:1527613968970};\\\", \\\"{x:1325,y:754,t:1527613968988};\\\", \\\"{x:1325,y:753,t:1527613969019};\\\", \\\"{x:1326,y:752,t:1527613969027};\\\", \\\"{x:1326,y:751,t:1527613969060};\\\", \\\"{x:1326,y:750,t:1527613969071};\\\", \\\"{x:1326,y:747,t:1527613969088};\\\", \\\"{x:1327,y:746,t:1527613969103};\\\", \\\"{x:1328,y:744,t:1527613969121};\\\", \\\"{x:1328,y:743,t:1527613969137};\\\", \\\"{x:1329,y:741,t:1527613969170};\\\", \\\"{x:1329,y:740,t:1527613969186};\\\", \\\"{x:1330,y:738,t:1527613969203};\\\", \\\"{x:1331,y:736,t:1527613969220};\\\", \\\"{x:1333,y:734,t:1527613969237};\\\", \\\"{x:1334,y:732,t:1527613969253};\\\", \\\"{x:1336,y:730,t:1527613969270};\\\", \\\"{x:1337,y:727,t:1527613969288};\\\", \\\"{x:1340,y:725,t:1527613969304};\\\", \\\"{x:1342,y:722,t:1527613969320};\\\", \\\"{x:1344,y:720,t:1527613969337};\\\", \\\"{x:1345,y:719,t:1527613969354};\\\", \\\"{x:1346,y:717,t:1527613969370};\\\", \\\"{x:1347,y:717,t:1527613969387};\\\", \\\"{x:1348,y:716,t:1527613969404};\\\", \\\"{x:1349,y:715,t:1527613969420};\\\", \\\"{x:1350,y:714,t:1527613969443};\\\", \\\"{x:1352,y:713,t:1527613969454};\\\", \\\"{x:1354,y:712,t:1527613969491};\\\", \\\"{x:1355,y:711,t:1527613969508};\\\", \\\"{x:1356,y:710,t:1527613969524};\\\", \\\"{x:1358,y:710,t:1527613969538};\\\", \\\"{x:1359,y:708,t:1527613969555};\\\", \\\"{x:1361,y:707,t:1527613969570};\\\", \\\"{x:1362,y:706,t:1527613969587};\\\", \\\"{x:1363,y:705,t:1527613969605};\\\", \\\"{x:1364,y:705,t:1527613969635};\\\", \\\"{x:1367,y:702,t:1527613970187};\\\", \\\"{x:1371,y:696,t:1527613970205};\\\", \\\"{x:1374,y:691,t:1527613970222};\\\", \\\"{x:1376,y:689,t:1527613970238};\\\", \\\"{x:1377,y:689,t:1527613970254};\\\", \\\"{x:1377,y:690,t:1527613970403};\\\", \\\"{x:1380,y:698,t:1527613970411};\\\", \\\"{x:1382,y:705,t:1527613970421};\\\", \\\"{x:1386,y:715,t:1527613970438};\\\", \\\"{x:1389,y:719,t:1527613970454};\\\", \\\"{x:1390,y:719,t:1527613970471};\\\", \\\"{x:1392,y:718,t:1527613970555};\\\", \\\"{x:1397,y:712,t:1527613970572};\\\", \\\"{x:1398,y:709,t:1527613970588};\\\", \\\"{x:1400,y:706,t:1527613970604};\\\", \\\"{x:1403,y:703,t:1527613970622};\\\", \\\"{x:1408,y:699,t:1527613970639};\\\", \\\"{x:1413,y:694,t:1527613970654};\\\", \\\"{x:1419,y:690,t:1527613970672};\\\", \\\"{x:1425,y:685,t:1527613970688};\\\", \\\"{x:1430,y:681,t:1527613970705};\\\", \\\"{x:1437,y:675,t:1527613970723};\\\", \\\"{x:1439,y:674,t:1527613970738};\\\", \\\"{x:1441,y:671,t:1527613970755};\\\", \\\"{x:1443,y:670,t:1527613970772};\\\", \\\"{x:1444,y:670,t:1527613970788};\\\", \\\"{x:1444,y:669,t:1527613970804};\\\", \\\"{x:1445,y:668,t:1527613970835};\\\", \\\"{x:1449,y:669,t:1527613970932};\\\", \\\"{x:1452,y:674,t:1527613970938};\\\", \\\"{x:1462,y:689,t:1527613970955};\\\", \\\"{x:1472,y:700,t:1527613970971};\\\", \\\"{x:1479,y:709,t:1527613970988};\\\", \\\"{x:1484,y:712,t:1527613971005};\\\", \\\"{x:1485,y:713,t:1527613971021};\\\", \\\"{x:1486,y:713,t:1527613971038};\\\", \\\"{x:1488,y:714,t:1527613971058};\\\", \\\"{x:1488,y:715,t:1527613971072};\\\", \\\"{x:1490,y:715,t:1527613971089};\\\", \\\"{x:1491,y:715,t:1527613971155};\\\", \\\"{x:1496,y:714,t:1527613971172};\\\", \\\"{x:1505,y:704,t:1527613971189};\\\", \\\"{x:1513,y:693,t:1527613971206};\\\", \\\"{x:1519,y:685,t:1527613971221};\\\", \\\"{x:1524,y:677,t:1527613971238};\\\", \\\"{x:1524,y:676,t:1527613971256};\\\", \\\"{x:1532,y:678,t:1527613971500};\\\", \\\"{x:1539,y:686,t:1527613971507};\\\", \\\"{x:1549,y:699,t:1527613971523};\\\", \\\"{x:1558,y:711,t:1527613971540};\\\", \\\"{x:1561,y:714,t:1527613971556};\\\", \\\"{x:1562,y:715,t:1527613971573};\\\", \\\"{x:1564,y:715,t:1527613971659};\\\", \\\"{x:1566,y:714,t:1527613971707};\\\", \\\"{x:1574,y:704,t:1527613971723};\\\", \\\"{x:1584,y:694,t:1527613971739};\\\", \\\"{x:1593,y:687,t:1527613971755};\\\", \\\"{x:1601,y:680,t:1527613971773};\\\", \\\"{x:1608,y:675,t:1527613971788};\\\", \\\"{x:1611,y:674,t:1527613971806};\\\", \\\"{x:1611,y:673,t:1527613971823};\\\", \\\"{x:1611,y:672,t:1527613971840};\\\", \\\"{x:1612,y:672,t:1527613972139};\\\", \\\"{x:1613,y:679,t:1527613972156};\\\", \\\"{x:1615,y:682,t:1527613972172};\\\", \\\"{x:1616,y:685,t:1527613972189};\\\", \\\"{x:1616,y:686,t:1527613972205};\\\", \\\"{x:1616,y:687,t:1527613972380};\\\", \\\"{x:1616,y:689,t:1527613972395};\\\", \\\"{x:1616,y:692,t:1527613972407};\\\", \\\"{x:1616,y:695,t:1527613972422};\\\", \\\"{x:1616,y:696,t:1527613972439};\\\", \\\"{x:1616,y:698,t:1527613972456};\\\", \\\"{x:1615,y:699,t:1527613972475};\\\", \\\"{x:1615,y:700,t:1527613972515};\\\", \\\"{x:1613,y:700,t:1527613973028};\\\", \\\"{x:1612,y:700,t:1527613973040};\\\", \\\"{x:1610,y:700,t:1527613973056};\\\", \\\"{x:1609,y:700,t:1527613973075};\\\", \\\"{x:1609,y:699,t:1527613973090};\\\", \\\"{x:1608,y:699,t:1527613973107};\\\", \\\"{x:1607,y:699,t:1527613973683};\\\", \\\"{x:1599,y:705,t:1527613973691};\\\", \\\"{x:1581,y:720,t:1527613973707};\\\", \\\"{x:1565,y:734,t:1527613973724};\\\", \\\"{x:1550,y:744,t:1527613973741};\\\", \\\"{x:1541,y:750,t:1527613973757};\\\", \\\"{x:1539,y:752,t:1527613973774};\\\", \\\"{x:1539,y:753,t:1527613973791};\\\", \\\"{x:1537,y:754,t:1527613973808};\\\", \\\"{x:1533,y:761,t:1527613973824};\\\", \\\"{x:1524,y:771,t:1527613973841};\\\", \\\"{x:1512,y:780,t:1527613973858};\\\", \\\"{x:1504,y:787,t:1527613973874};\\\", \\\"{x:1500,y:790,t:1527613973891};\\\", \\\"{x:1500,y:788,t:1527613974163};\\\", \\\"{x:1500,y:786,t:1527613974173};\\\", \\\"{x:1501,y:783,t:1527613974191};\\\", \\\"{x:1503,y:778,t:1527613974207};\\\", \\\"{x:1504,y:776,t:1527613974225};\\\", \\\"{x:1506,y:771,t:1527613974241};\\\", \\\"{x:1507,y:769,t:1527613974257};\\\", \\\"{x:1508,y:768,t:1527613974275};\\\", \\\"{x:1497,y:768,t:1527613976380};\\\", \\\"{x:1481,y:773,t:1527613976393};\\\", \\\"{x:1450,y:780,t:1527613976409};\\\", \\\"{x:1412,y:781,t:1527613976426};\\\", \\\"{x:1386,y:781,t:1527613976443};\\\", \\\"{x:1381,y:783,t:1527613976459};\\\", \\\"{x:1380,y:783,t:1527613976507};\\\", \\\"{x:1379,y:783,t:1527613976684};\\\", \\\"{x:1376,y:783,t:1527613976693};\\\", \\\"{x:1367,y:783,t:1527613976710};\\\", \\\"{x:1350,y:785,t:1527613976726};\\\", \\\"{x:1335,y:785,t:1527613976743};\\\", \\\"{x:1323,y:785,t:1527613976760};\\\", \\\"{x:1319,y:785,t:1527613976775};\\\", \\\"{x:1318,y:785,t:1527613976956};\\\", \\\"{x:1318,y:784,t:1527613976971};\\\", \\\"{x:1319,y:782,t:1527613976979};\\\", \\\"{x:1321,y:779,t:1527613976993};\\\", \\\"{x:1323,y:776,t:1527613977010};\\\", \\\"{x:1329,y:770,t:1527613977027};\\\", \\\"{x:1334,y:767,t:1527613977043};\\\", \\\"{x:1341,y:763,t:1527613977060};\\\", \\\"{x:1346,y:761,t:1527613977077};\\\", \\\"{x:1350,y:759,t:1527613977093};\\\", \\\"{x:1352,y:757,t:1527613977110};\\\", \\\"{x:1353,y:757,t:1527613977127};\\\", \\\"{x:1351,y:759,t:1527613977588};\\\", \\\"{x:1346,y:762,t:1527613977609};\\\", \\\"{x:1342,y:764,t:1527613977627};\\\", \\\"{x:1341,y:764,t:1527613977668};\\\", \\\"{x:1339,y:766,t:1527613978324};\\\", \\\"{x:1335,y:770,t:1527613978331};\\\", \\\"{x:1330,y:774,t:1527613978344};\\\", \\\"{x:1319,y:780,t:1527613978361};\\\", \\\"{x:1306,y:785,t:1527613978377};\\\", \\\"{x:1294,y:790,t:1527613978394};\\\", \\\"{x:1284,y:795,t:1527613978410};\\\", \\\"{x:1279,y:798,t:1527613978426};\\\", \\\"{x:1271,y:800,t:1527613978444};\\\", \\\"{x:1261,y:803,t:1527613978460};\\\", \\\"{x:1249,y:805,t:1527613978478};\\\", \\\"{x:1238,y:807,t:1527613978494};\\\", \\\"{x:1234,y:807,t:1527613978511};\\\", \\\"{x:1233,y:807,t:1527613978528};\\\", \\\"{x:1232,y:807,t:1527613978587};\\\", \\\"{x:1231,y:807,t:1527613978611};\\\", \\\"{x:1230,y:807,t:1527613978628};\\\", \\\"{x:1228,y:807,t:1527613978644};\\\", \\\"{x:1228,y:806,t:1527613978661};\\\", \\\"{x:1227,y:806,t:1527613978683};\\\", \\\"{x:1225,y:804,t:1527613978694};\\\", \\\"{x:1222,y:802,t:1527613978711};\\\", \\\"{x:1218,y:800,t:1527613978728};\\\", \\\"{x:1213,y:798,t:1527613978744};\\\", \\\"{x:1207,y:797,t:1527613978761};\\\", \\\"{x:1203,y:795,t:1527613978778};\\\", \\\"{x:1202,y:795,t:1527613978793};\\\", \\\"{x:1201,y:795,t:1527613978835};\\\", \\\"{x:1200,y:795,t:1527613978859};\\\", \\\"{x:1199,y:794,t:1527613978891};\\\", \\\"{x:1199,y:793,t:1527613978907};\\\", \\\"{x:1197,y:792,t:1527613978915};\\\", \\\"{x:1197,y:791,t:1527613978928};\\\", \\\"{x:1197,y:790,t:1527613978945};\\\", \\\"{x:1196,y:788,t:1527613978961};\\\", \\\"{x:1196,y:787,t:1527613978978};\\\", \\\"{x:1195,y:785,t:1527613978995};\\\", \\\"{x:1194,y:784,t:1527613979011};\\\", \\\"{x:1194,y:783,t:1527613979035};\\\", \\\"{x:1194,y:782,t:1527613979045};\\\", \\\"{x:1194,y:780,t:1527613979061};\\\", \\\"{x:1194,y:779,t:1527613979083};\\\", \\\"{x:1194,y:778,t:1527613979099};\\\", \\\"{x:1194,y:777,t:1527613979111};\\\", \\\"{x:1194,y:776,t:1527613979127};\\\", \\\"{x:1194,y:774,t:1527613979144};\\\", \\\"{x:1194,y:773,t:1527613979160};\\\", \\\"{x:1194,y:771,t:1527613979177};\\\", \\\"{x:1194,y:770,t:1527613979194};\\\", \\\"{x:1194,y:769,t:1527613979250};\\\", \\\"{x:1190,y:768,t:1527613979404};\\\", \\\"{x:1176,y:769,t:1527613979411};\\\", \\\"{x:1126,y:773,t:1527613979428};\\\", \\\"{x:1074,y:777,t:1527613979445};\\\", \\\"{x:1035,y:777,t:1527613979462};\\\", \\\"{x:1021,y:777,t:1527613979478};\\\", \\\"{x:1020,y:777,t:1527613979495};\\\", \\\"{x:1019,y:777,t:1527613979531};\\\", \\\"{x:1017,y:777,t:1527613979545};\\\", \\\"{x:1003,y:768,t:1527613979562};\\\", \\\"{x:982,y:756,t:1527613979578};\\\", \\\"{x:947,y:735,t:1527613979595};\\\", \\\"{x:936,y:728,t:1527613979612};\\\", \\\"{x:930,y:725,t:1527613979628};\\\", \\\"{x:928,y:722,t:1527613979645};\\\", \\\"{x:925,y:717,t:1527613979662};\\\", \\\"{x:915,y:707,t:1527613979678};\\\", \\\"{x:901,y:700,t:1527613979695};\\\", \\\"{x:884,y:693,t:1527613979712};\\\", \\\"{x:858,y:684,t:1527613979728};\\\", \\\"{x:838,y:678,t:1527613979745};\\\", \\\"{x:816,y:674,t:1527613979762};\\\", \\\"{x:802,y:672,t:1527613979778};\\\", \\\"{x:790,y:668,t:1527613979795};\\\", \\\"{x:780,y:667,t:1527613979812};\\\", \\\"{x:770,y:663,t:1527613979827};\\\", \\\"{x:761,y:660,t:1527613979844};\\\", \\\"{x:738,y:658,t:1527613979861};\\\", \\\"{x:708,y:653,t:1527613979879};\\\", \\\"{x:669,y:650,t:1527613979894};\\\", \\\"{x:622,y:646,t:1527613979911};\\\", \\\"{x:572,y:638,t:1527613979929};\\\", \\\"{x:513,y:620,t:1527613979945};\\\", \\\"{x:454,y:601,t:1527613979963};\\\", \\\"{x:400,y:580,t:1527613979978};\\\", \\\"{x:392,y:576,t:1527613979992};\\\", \\\"{x:384,y:569,t:1527613980009};\\\", \\\"{x:381,y:566,t:1527613980026};\\\", \\\"{x:381,y:560,t:1527613980044};\\\", \\\"{x:381,y:550,t:1527613980060};\\\", \\\"{x:381,y:540,t:1527613980081};\\\", \\\"{x:385,y:529,t:1527613980098};\\\", \\\"{x:387,y:525,t:1527613980115};\\\", \\\"{x:389,y:521,t:1527613980133};\\\", \\\"{x:390,y:519,t:1527613980148};\\\", \\\"{x:392,y:517,t:1527613980166};\\\", \\\"{x:394,y:514,t:1527613980182};\\\", \\\"{x:397,y:512,t:1527613980199};\\\", \\\"{x:400,y:510,t:1527613980216};\\\", \\\"{x:406,y:507,t:1527613980232};\\\", \\\"{x:416,y:503,t:1527613980249};\\\", \\\"{x:432,y:501,t:1527613980265};\\\", \\\"{x:451,y:499,t:1527613980282};\\\", \\\"{x:453,y:499,t:1527613980298};\\\", \\\"{x:453,y:501,t:1527613980354};\\\", \\\"{x:453,y:503,t:1527613980366};\\\", \\\"{x:453,y:511,t:1527613980382};\\\", \\\"{x:453,y:519,t:1527613980400};\\\", \\\"{x:452,y:532,t:1527613980416};\\\", \\\"{x:442,y:548,t:1527613980432};\\\", \\\"{x:427,y:565,t:1527613980449};\\\", \\\"{x:410,y:577,t:1527613980466};\\\", \\\"{x:389,y:592,t:1527613980482};\\\", \\\"{x:379,y:599,t:1527613980499};\\\", \\\"{x:366,y:607,t:1527613980516};\\\", \\\"{x:350,y:614,t:1527613980533};\\\", \\\"{x:334,y:620,t:1527613980549};\\\", \\\"{x:325,y:623,t:1527613980565};\\\", \\\"{x:316,y:624,t:1527613980582};\\\", \\\"{x:305,y:625,t:1527613980599};\\\", \\\"{x:290,y:625,t:1527613980615};\\\", \\\"{x:277,y:625,t:1527613980633};\\\", \\\"{x:265,y:625,t:1527613980650};\\\", \\\"{x:248,y:625,t:1527613980665};\\\", \\\"{x:219,y:618,t:1527613980682};\\\", \\\"{x:206,y:616,t:1527613980699};\\\", \\\"{x:202,y:615,t:1527613980715};\\\", \\\"{x:200,y:613,t:1527613980732};\\\", \\\"{x:197,y:613,t:1527613980750};\\\", \\\"{x:197,y:612,t:1527613980770};\\\", \\\"{x:196,y:612,t:1527613980783};\\\", \\\"{x:193,y:608,t:1527613980799};\\\", \\\"{x:192,y:604,t:1527613980815};\\\", \\\"{x:190,y:599,t:1527613980833};\\\", \\\"{x:189,y:594,t:1527613980849};\\\", \\\"{x:187,y:589,t:1527613980866};\\\", \\\"{x:185,y:582,t:1527613980882};\\\", \\\"{x:183,y:577,t:1527613980899};\\\", \\\"{x:181,y:572,t:1527613980915};\\\", \\\"{x:178,y:568,t:1527613980933};\\\", \\\"{x:175,y:563,t:1527613980950};\\\", \\\"{x:172,y:560,t:1527613980967};\\\", \\\"{x:169,y:558,t:1527613980982};\\\", \\\"{x:168,y:557,t:1527613980999};\\\", \\\"{x:167,y:556,t:1527613981026};\\\", \\\"{x:167,y:554,t:1527613981051};\\\", \\\"{x:167,y:553,t:1527613981074};\\\", \\\"{x:167,y:551,t:1527613981129};\\\", \\\"{x:167,y:550,t:1527613981169};\\\", \\\"{x:168,y:548,t:1527613981194};\\\", \\\"{x:169,y:547,t:1527613981202};\\\", \\\"{x:171,y:545,t:1527613981216};\\\", \\\"{x:179,y:542,t:1527613981232};\\\", \\\"{x:199,y:538,t:1527613981250};\\\", \\\"{x:237,y:532,t:1527613981265};\\\", \\\"{x:326,y:532,t:1527613981282};\\\", \\\"{x:384,y:532,t:1527613981300};\\\", \\\"{x:414,y:531,t:1527613981317};\\\", \\\"{x:422,y:530,t:1527613981332};\\\", \\\"{x:424,y:530,t:1527613981349};\\\", \\\"{x:426,y:530,t:1527613981418};\\\", \\\"{x:429,y:530,t:1527613981434};\\\", \\\"{x:431,y:530,t:1527613981449};\\\", \\\"{x:439,y:530,t:1527613981466};\\\", \\\"{x:445,y:530,t:1527613981483};\\\", \\\"{x:449,y:530,t:1527613981500};\\\", \\\"{x:456,y:530,t:1527613981517};\\\", \\\"{x:468,y:530,t:1527613981533};\\\", \\\"{x:491,y:530,t:1527613981550};\\\", \\\"{x:523,y:530,t:1527613981568};\\\", \\\"{x:559,y:530,t:1527613981583};\\\", \\\"{x:618,y:530,t:1527613981600};\\\", \\\"{x:657,y:530,t:1527613981617};\\\", \\\"{x:686,y:530,t:1527613981633};\\\", \\\"{x:699,y:530,t:1527613981649};\\\", \\\"{x:700,y:530,t:1527613981666};\\\", \\\"{x:702,y:530,t:1527613981707};\\\", \\\"{x:703,y:530,t:1527613981717};\\\", \\\"{x:706,y:528,t:1527613981733};\\\", \\\"{x:710,y:528,t:1527613981750};\\\", \\\"{x:714,y:528,t:1527613981767};\\\", \\\"{x:720,y:528,t:1527613981783};\\\", \\\"{x:726,y:528,t:1527613981802};\\\", \\\"{x:738,y:528,t:1527613981816};\\\", \\\"{x:760,y:528,t:1527613981833};\\\", \\\"{x:815,y:530,t:1527613981849};\\\", \\\"{x:866,y:540,t:1527613981866};\\\", \\\"{x:916,y:554,t:1527613981884};\\\", \\\"{x:952,y:569,t:1527613981900};\\\", \\\"{x:979,y:585,t:1527613981916};\\\", \\\"{x:997,y:598,t:1527613981934};\\\", \\\"{x:1009,y:608,t:1527613981949};\\\", \\\"{x:1021,y:615,t:1527613981966};\\\", \\\"{x:1040,y:624,t:1527613981984};\\\", \\\"{x:1064,y:634,t:1527613982001};\\\", \\\"{x:1097,y:646,t:1527613982017};\\\", \\\"{x:1126,y:655,t:1527613982033};\\\", \\\"{x:1163,y:669,t:1527613982051};\\\", \\\"{x:1170,y:671,t:1527613982067};\\\", \\\"{x:1172,y:672,t:1527613982084};\\\", \\\"{x:1173,y:673,t:1527613982179};\\\", \\\"{x:1172,y:676,t:1527613982186};\\\", \\\"{x:1169,y:679,t:1527613982201};\\\", \\\"{x:1149,y:689,t:1527613982218};\\\", \\\"{x:1107,y:696,t:1527613982234};\\\", \\\"{x:1007,y:696,t:1527613982251};\\\", \\\"{x:915,y:696,t:1527613982268};\\\", \\\"{x:824,y:696,t:1527613982284};\\\", \\\"{x:732,y:696,t:1527613982301};\\\", \\\"{x:662,y:694,t:1527613982317};\\\", \\\"{x:608,y:686,t:1527613982334};\\\", \\\"{x:566,y:680,t:1527613982350};\\\", \\\"{x:523,y:677,t:1527613982368};\\\", \\\"{x:455,y:672,t:1527613982384};\\\", \\\"{x:381,y:667,t:1527613982402};\\\", \\\"{x:320,y:659,t:1527613982418};\\\", \\\"{x:284,y:653,t:1527613982433};\\\", \\\"{x:254,y:643,t:1527613982451};\\\", \\\"{x:245,y:641,t:1527613982467};\\\", \\\"{x:242,y:641,t:1527613982483};\\\", \\\"{x:241,y:641,t:1527613982514};\\\", \\\"{x:241,y:640,t:1527613982522};\\\", \\\"{x:237,y:639,t:1527613982534};\\\", \\\"{x:228,y:638,t:1527613982551};\\\", \\\"{x:217,y:633,t:1527613982567};\\\", \\\"{x:212,y:629,t:1527613982584};\\\", \\\"{x:210,y:629,t:1527613982600};\\\", \\\"{x:209,y:627,t:1527613982618};\\\", \\\"{x:208,y:625,t:1527613982634};\\\", \\\"{x:203,y:618,t:1527613982650};\\\", \\\"{x:200,y:614,t:1527613982668};\\\", \\\"{x:196,y:609,t:1527613982683};\\\", \\\"{x:195,y:606,t:1527613982701};\\\", \\\"{x:193,y:603,t:1527613982718};\\\", \\\"{x:192,y:602,t:1527613982734};\\\", \\\"{x:190,y:598,t:1527613982752};\\\", \\\"{x:187,y:594,t:1527613982768};\\\", \\\"{x:183,y:592,t:1527613982784};\\\", \\\"{x:179,y:589,t:1527613982800};\\\", \\\"{x:176,y:588,t:1527613982817};\\\", \\\"{x:174,y:586,t:1527613982834};\\\", \\\"{x:172,y:584,t:1527613982850};\\\", \\\"{x:171,y:582,t:1527613982874};\\\", \\\"{x:171,y:581,t:1527613982890};\\\", \\\"{x:170,y:580,t:1527613982914};\\\", \\\"{x:170,y:578,t:1527613982937};\\\", \\\"{x:170,y:577,t:1527613982954};\\\", \\\"{x:170,y:575,t:1527613982970};\\\", \\\"{x:170,y:574,t:1527613982983};\\\", \\\"{x:170,y:572,t:1527613983000};\\\", \\\"{x:170,y:570,t:1527613983017};\\\", \\\"{x:170,y:568,t:1527613983033};\\\", \\\"{x:170,y:564,t:1527613983051};\\\", \\\"{x:170,y:562,t:1527613983069};\\\", \\\"{x:171,y:561,t:1527613983084};\\\", \\\"{x:172,y:558,t:1527613983100};\\\", \\\"{x:174,y:556,t:1527613983117};\\\", \\\"{x:175,y:554,t:1527613983136};\\\", \\\"{x:178,y:551,t:1527613983152};\\\", \\\"{x:179,y:551,t:1527613983167};\\\", \\\"{x:179,y:550,t:1527613983186};\\\", \\\"{x:180,y:549,t:1527613983210};\\\", \\\"{x:181,y:548,t:1527613983217};\\\", \\\"{x:182,y:547,t:1527613983235};\\\", \\\"{x:183,y:545,t:1527613983251};\\\", \\\"{x:183,y:544,t:1527613983267};\\\", \\\"{x:185,y:543,t:1527613983284};\\\", \\\"{x:186,y:541,t:1527613983314};\\\", \\\"{x:194,y:541,t:1527613983659};\\\", \\\"{x:204,y:547,t:1527613983667};\\\", \\\"{x:223,y:556,t:1527613983685};\\\", \\\"{x:250,y:566,t:1527613983702};\\\", \\\"{x:277,y:577,t:1527613983719};\\\", \\\"{x:296,y:585,t:1527613983734};\\\", \\\"{x:309,y:590,t:1527613983752};\\\", \\\"{x:314,y:593,t:1527613983769};\\\", \\\"{x:318,y:595,t:1527613983785};\\\", \\\"{x:322,y:598,t:1527613983802};\\\", \\\"{x:343,y:611,t:1527613983819};\\\", \\\"{x:363,y:620,t:1527613983834};\\\", \\\"{x:375,y:628,t:1527613983852};\\\", \\\"{x:386,y:634,t:1527613983868};\\\", \\\"{x:393,y:638,t:1527613983884};\\\", \\\"{x:397,y:642,t:1527613983902};\\\", \\\"{x:401,y:645,t:1527613983918};\\\", \\\"{x:403,y:646,t:1527613983934};\\\", \\\"{x:404,y:648,t:1527613983951};\\\", \\\"{x:407,y:650,t:1527613983969};\\\", \\\"{x:412,y:654,t:1527613983984};\\\", \\\"{x:424,y:665,t:1527613984003};\\\", \\\"{x:459,y:690,t:1527613984018};\\\", \\\"{x:488,y:711,t:1527613984034};\\\", \\\"{x:515,y:730,t:1527613984051};\\\", \\\"{x:532,y:742,t:1527613984068};\\\", \\\"{x:545,y:751,t:1527613984084};\\\", \\\"{x:549,y:755,t:1527613984102};\\\", \\\"{x:550,y:756,t:1527613984119};\\\", \\\"{x:547,y:756,t:1527613984410};\\\", \\\"{x:543,y:752,t:1527613984419};\\\", \\\"{x:540,y:748,t:1527613984435};\\\", \\\"{x:539,y:746,t:1527613984451};\\\", \\\"{x:538,y:746,t:1527613984469};\\\", \\\"{x:538,y:745,t:1527613984485};\\\", \\\"{x:537,y:744,t:1527613984506};\\\" ] }, { \\\"rt\\\": 11229, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 598598, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:742,t:1527613987771};\\\", \\\"{x:634,y:734,t:1527613987788};\\\", \\\"{x:789,y:730,t:1527613987803};\\\", \\\"{x:971,y:730,t:1527613987821};\\\", \\\"{x:1148,y:730,t:1527613987837};\\\", \\\"{x:1276,y:730,t:1527613987855};\\\", \\\"{x:1327,y:726,t:1527613987870};\\\", \\\"{x:1343,y:726,t:1527613987887};\\\", \\\"{x:1345,y:726,t:1527613987904};\\\", \\\"{x:1346,y:729,t:1527613988194};\\\", \\\"{x:1347,y:738,t:1527613988204};\\\", \\\"{x:1351,y:753,t:1527613988222};\\\", \\\"{x:1353,y:766,t:1527613988238};\\\", \\\"{x:1358,y:781,t:1527613988254};\\\", \\\"{x:1366,y:798,t:1527613988272};\\\", \\\"{x:1373,y:811,t:1527613988287};\\\", \\\"{x:1379,y:824,t:1527613988305};\\\", \\\"{x:1387,y:845,t:1527613988323};\\\", \\\"{x:1390,y:856,t:1527613988339};\\\", \\\"{x:1392,y:865,t:1527613988355};\\\", \\\"{x:1396,y:873,t:1527613988372};\\\", \\\"{x:1398,y:882,t:1527613988388};\\\", \\\"{x:1405,y:887,t:1527613988405};\\\", \\\"{x:1406,y:891,t:1527613988422};\\\", \\\"{x:1406,y:892,t:1527613988438};\\\", \\\"{x:1407,y:894,t:1527613988455};\\\", \\\"{x:1407,y:897,t:1527613988472};\\\", \\\"{x:1408,y:900,t:1527613988488};\\\", \\\"{x:1408,y:901,t:1527613988755};\\\", \\\"{x:1411,y:902,t:1527613988772};\\\", \\\"{x:1411,y:904,t:1527613989027};\\\", \\\"{x:1412,y:906,t:1527613989040};\\\", \\\"{x:1421,y:920,t:1527613989056};\\\", \\\"{x:1432,y:932,t:1527613989072};\\\", \\\"{x:1440,y:948,t:1527613989090};\\\", \\\"{x:1452,y:966,t:1527613989105};\\\", \\\"{x:1469,y:988,t:1527613989123};\\\", \\\"{x:1480,y:998,t:1527613989139};\\\", \\\"{x:1484,y:1001,t:1527613989155};\\\", \\\"{x:1487,y:1004,t:1527613989173};\\\", \\\"{x:1493,y:1008,t:1527613989189};\\\", \\\"{x:1498,y:1012,t:1527613989206};\\\", \\\"{x:1504,y:1017,t:1527613989222};\\\", \\\"{x:1509,y:1021,t:1527613989238};\\\", \\\"{x:1511,y:1022,t:1527613989255};\\\", \\\"{x:1512,y:1023,t:1527613989272};\\\", \\\"{x:1513,y:1023,t:1527613989289};\\\", \\\"{x:1514,y:1023,t:1527613989330};\\\", \\\"{x:1515,y:1023,t:1527613989345};\\\", \\\"{x:1516,y:1023,t:1527613989362};\\\", \\\"{x:1519,y:1023,t:1527613989372};\\\", \\\"{x:1520,y:1023,t:1527613989388};\\\", \\\"{x:1522,y:1023,t:1527613989406};\\\", \\\"{x:1528,y:1022,t:1527613989422};\\\", \\\"{x:1534,y:1020,t:1527613989438};\\\", \\\"{x:1538,y:1016,t:1527613989456};\\\", \\\"{x:1543,y:1012,t:1527613989472};\\\", \\\"{x:1544,y:1010,t:1527613989489};\\\", \\\"{x:1546,y:1008,t:1527613989507};\\\", \\\"{x:1547,y:1007,t:1527613989531};\\\", \\\"{x:1547,y:1006,t:1527613989595};\\\", \\\"{x:1546,y:1005,t:1527613989619};\\\", \\\"{x:1546,y:1004,t:1527613989642};\\\", \\\"{x:1545,y:1004,t:1527613989656};\\\", \\\"{x:1543,y:1003,t:1527613989672};\\\", \\\"{x:1540,y:1001,t:1527613989689};\\\", \\\"{x:1531,y:998,t:1527613989707};\\\", \\\"{x:1522,y:997,t:1527613989723};\\\", \\\"{x:1508,y:995,t:1527613989739};\\\", \\\"{x:1498,y:995,t:1527613989756};\\\", \\\"{x:1488,y:993,t:1527613989773};\\\", \\\"{x:1477,y:992,t:1527613989790};\\\", \\\"{x:1472,y:992,t:1527613989806};\\\", \\\"{x:1469,y:992,t:1527613989823};\\\", \\\"{x:1465,y:992,t:1527613989839};\\\", \\\"{x:1460,y:991,t:1527613989855};\\\", \\\"{x:1452,y:990,t:1527613989873};\\\", \\\"{x:1437,y:989,t:1527613989889};\\\", \\\"{x:1420,y:987,t:1527613989905};\\\", \\\"{x:1409,y:987,t:1527613989922};\\\", \\\"{x:1401,y:987,t:1527613989938};\\\", \\\"{x:1394,y:987,t:1527613989956};\\\", \\\"{x:1393,y:987,t:1527613989973};\\\", \\\"{x:1390,y:987,t:1527613989989};\\\", \\\"{x:1386,y:987,t:1527613990005};\\\", \\\"{x:1381,y:987,t:1527613990023};\\\", \\\"{x:1376,y:987,t:1527613990038};\\\", \\\"{x:1369,y:987,t:1527613990056};\\\", \\\"{x:1365,y:987,t:1527613990072};\\\", \\\"{x:1362,y:987,t:1527613990090};\\\", \\\"{x:1361,y:987,t:1527613990114};\\\", \\\"{x:1360,y:986,t:1527613990122};\\\", \\\"{x:1359,y:985,t:1527613990139};\\\", \\\"{x:1358,y:985,t:1527613990156};\\\", \\\"{x:1354,y:984,t:1527613990173};\\\", \\\"{x:1350,y:983,t:1527613990188};\\\", \\\"{x:1347,y:981,t:1527613990206};\\\", \\\"{x:1345,y:980,t:1527613990227};\\\", \\\"{x:1344,y:980,t:1527613990243};\\\", \\\"{x:1343,y:979,t:1527613990256};\\\", \\\"{x:1341,y:979,t:1527613990273};\\\", \\\"{x:1341,y:978,t:1527613990289};\\\", \\\"{x:1340,y:977,t:1527613990307};\\\", \\\"{x:1339,y:975,t:1527613990323};\\\", \\\"{x:1339,y:972,t:1527613990340};\\\", \\\"{x:1338,y:972,t:1527613990356};\\\", \\\"{x:1338,y:971,t:1527613990373};\\\", \\\"{x:1338,y:969,t:1527613990389};\\\", \\\"{x:1338,y:968,t:1527613990408};\\\", \\\"{x:1338,y:966,t:1527613990423};\\\", \\\"{x:1338,y:965,t:1527613990440};\\\", \\\"{x:1338,y:964,t:1527613990466};\\\", \\\"{x:1338,y:963,t:1527613990490};\\\", \\\"{x:1338,y:962,t:1527613990506};\\\", \\\"{x:1339,y:961,t:1527613990538};\\\", \\\"{x:1339,y:960,t:1527613990562};\\\", \\\"{x:1340,y:960,t:1527613990594};\\\", \\\"{x:1341,y:960,t:1527613990610};\\\", \\\"{x:1342,y:959,t:1527613990626};\\\", \\\"{x:1343,y:959,t:1527613990666};\\\", \\\"{x:1343,y:957,t:1527613990843};\\\", \\\"{x:1344,y:955,t:1527613990856};\\\", \\\"{x:1344,y:953,t:1527613990874};\\\", \\\"{x:1344,y:950,t:1527613990890};\\\", \\\"{x:1344,y:949,t:1527613990907};\\\", \\\"{x:1344,y:947,t:1527613990924};\\\", \\\"{x:1344,y:946,t:1527613990941};\\\", \\\"{x:1345,y:943,t:1527613990956};\\\", \\\"{x:1345,y:941,t:1527613990974};\\\", \\\"{x:1347,y:939,t:1527613990990};\\\", \\\"{x:1347,y:938,t:1527613991034};\\\", \\\"{x:1347,y:937,t:1527613991051};\\\", \\\"{x:1347,y:936,t:1527613991066};\\\", \\\"{x:1347,y:935,t:1527613991107};\\\", \\\"{x:1347,y:934,t:1527613991122};\\\", \\\"{x:1347,y:933,t:1527613991140};\\\", \\\"{x:1347,y:932,t:1527613991186};\\\", \\\"{x:1347,y:931,t:1527613991210};\\\", \\\"{x:1347,y:930,t:1527613991226};\\\", \\\"{x:1347,y:929,t:1527613991258};\\\", \\\"{x:1347,y:928,t:1527613991282};\\\", \\\"{x:1347,y:927,t:1527613991314};\\\", \\\"{x:1347,y:926,t:1527613991361};\\\", \\\"{x:1347,y:925,t:1527613991386};\\\", \\\"{x:1347,y:924,t:1527613991402};\\\", \\\"{x:1347,y:923,t:1527613991466};\\\", \\\"{x:1347,y:922,t:1527613991491};\\\", \\\"{x:1347,y:921,t:1527613991515};\\\", \\\"{x:1347,y:920,t:1527613991547};\\\", \\\"{x:1347,y:919,t:1527613991571};\\\", \\\"{x:1347,y:918,t:1527613991579};\\\", \\\"{x:1347,y:917,t:1527613991603};\\\", \\\"{x:1347,y:916,t:1527613991611};\\\", \\\"{x:1347,y:915,t:1527613991624};\\\", \\\"{x:1347,y:912,t:1527613991642};\\\", \\\"{x:1347,y:909,t:1527613991658};\\\", \\\"{x:1347,y:901,t:1527613991674};\\\", \\\"{x:1347,y:897,t:1527613991691};\\\", \\\"{x:1347,y:895,t:1527613991707};\\\", \\\"{x:1347,y:893,t:1527613991725};\\\", \\\"{x:1346,y:890,t:1527613991741};\\\", \\\"{x:1345,y:886,t:1527613991757};\\\", \\\"{x:1345,y:884,t:1527613991774};\\\", \\\"{x:1345,y:882,t:1527613991790};\\\", \\\"{x:1345,y:878,t:1527613991807};\\\", \\\"{x:1344,y:874,t:1527613991824};\\\", \\\"{x:1344,y:873,t:1527613991840};\\\", \\\"{x:1344,y:871,t:1527613991857};\\\", \\\"{x:1344,y:867,t:1527613991875};\\\", \\\"{x:1344,y:863,t:1527613991891};\\\", \\\"{x:1343,y:863,t:1527613991907};\\\", \\\"{x:1343,y:861,t:1527613991924};\\\", \\\"{x:1343,y:860,t:1527613991941};\\\", \\\"{x:1343,y:859,t:1527613991958};\\\", \\\"{x:1343,y:857,t:1527613991974};\\\", \\\"{x:1343,y:855,t:1527613991990};\\\", \\\"{x:1342,y:852,t:1527613992007};\\\", \\\"{x:1342,y:850,t:1527613992025};\\\", \\\"{x:1342,y:848,t:1527613992041};\\\", \\\"{x:1342,y:845,t:1527613992058};\\\", \\\"{x:1342,y:842,t:1527613992075};\\\", \\\"{x:1341,y:840,t:1527613992092};\\\", \\\"{x:1340,y:836,t:1527613992107};\\\", \\\"{x:1340,y:834,t:1527613992125};\\\", \\\"{x:1340,y:827,t:1527613992142};\\\", \\\"{x:1340,y:817,t:1527613992157};\\\", \\\"{x:1340,y:810,t:1527613992174};\\\", \\\"{x:1340,y:804,t:1527613992191};\\\", \\\"{x:1340,y:799,t:1527613992208};\\\", \\\"{x:1340,y:795,t:1527613992224};\\\", \\\"{x:1340,y:792,t:1527613992242};\\\", \\\"{x:1340,y:789,t:1527613992257};\\\", \\\"{x:1340,y:784,t:1527613992275};\\\", \\\"{x:1340,y:781,t:1527613992291};\\\", \\\"{x:1340,y:777,t:1527613992307};\\\", \\\"{x:1340,y:774,t:1527613992324};\\\", \\\"{x:1340,y:771,t:1527613992341};\\\", \\\"{x:1340,y:769,t:1527613992357};\\\", \\\"{x:1340,y:766,t:1527613992374};\\\", \\\"{x:1340,y:762,t:1527613992391};\\\", \\\"{x:1341,y:758,t:1527613992407};\\\", \\\"{x:1341,y:755,t:1527613992425};\\\", \\\"{x:1342,y:751,t:1527613992442};\\\", \\\"{x:1342,y:750,t:1527613992467};\\\", \\\"{x:1342,y:747,t:1527613992475};\\\", \\\"{x:1343,y:747,t:1527613992491};\\\", \\\"{x:1343,y:744,t:1527613992507};\\\", \\\"{x:1344,y:741,t:1527613992526};\\\", \\\"{x:1344,y:739,t:1527613992541};\\\", \\\"{x:1344,y:735,t:1527613992558};\\\", \\\"{x:1344,y:734,t:1527613992575};\\\", \\\"{x:1344,y:733,t:1527613992592};\\\", \\\"{x:1345,y:730,t:1527613992608};\\\", \\\"{x:1345,y:728,t:1527613992625};\\\", \\\"{x:1345,y:726,t:1527613992642};\\\", \\\"{x:1346,y:724,t:1527613992657};\\\", \\\"{x:1346,y:719,t:1527613992674};\\\", \\\"{x:1347,y:716,t:1527613992691};\\\", \\\"{x:1347,y:714,t:1527613992708};\\\", \\\"{x:1347,y:712,t:1527613992724};\\\", \\\"{x:1348,y:711,t:1527613992742};\\\", \\\"{x:1348,y:708,t:1527613992758};\\\", \\\"{x:1348,y:706,t:1527613992774};\\\", \\\"{x:1348,y:704,t:1527613992791};\\\", \\\"{x:1350,y:700,t:1527613992810};\\\", \\\"{x:1350,y:698,t:1527613992824};\\\", \\\"{x:1350,y:695,t:1527613992840};\\\", \\\"{x:1351,y:692,t:1527613992858};\\\", \\\"{x:1351,y:691,t:1527613992874};\\\", \\\"{x:1351,y:689,t:1527613992891};\\\", \\\"{x:1351,y:686,t:1527613992908};\\\", \\\"{x:1351,y:683,t:1527613992924};\\\", \\\"{x:1351,y:678,t:1527613992941};\\\", \\\"{x:1351,y:672,t:1527613992958};\\\", \\\"{x:1351,y:662,t:1527613992974};\\\", \\\"{x:1351,y:653,t:1527613992991};\\\", \\\"{x:1351,y:643,t:1527613993008};\\\", \\\"{x:1352,y:634,t:1527613993024};\\\", \\\"{x:1355,y:626,t:1527613993042};\\\", \\\"{x:1355,y:619,t:1527613993059};\\\", \\\"{x:1355,y:616,t:1527613993075};\\\", \\\"{x:1355,y:614,t:1527613993091};\\\", \\\"{x:1350,y:613,t:1527613993171};\\\", \\\"{x:1335,y:621,t:1527613993179};\\\", \\\"{x:1310,y:637,t:1527613993191};\\\", \\\"{x:1229,y:682,t:1527613993208};\\\", \\\"{x:1143,y:721,t:1527613993224};\\\", \\\"{x:1060,y:744,t:1527613993242};\\\", \\\"{x:955,y:757,t:1527613993259};\\\", \\\"{x:905,y:757,t:1527613993274};\\\", \\\"{x:862,y:760,t:1527613993291};\\\", \\\"{x:836,y:760,t:1527613993308};\\\", \\\"{x:814,y:760,t:1527613993325};\\\", \\\"{x:799,y:760,t:1527613993341};\\\", \\\"{x:794,y:760,t:1527613993359};\\\", \\\"{x:791,y:760,t:1527613993375};\\\", \\\"{x:778,y:759,t:1527613993391};\\\", \\\"{x:754,y:757,t:1527613993408};\\\", \\\"{x:717,y:750,t:1527613993426};\\\", \\\"{x:656,y:742,t:1527613993441};\\\", \\\"{x:531,y:717,t:1527613993459};\\\", \\\"{x:488,y:703,t:1527613993474};\\\", \\\"{x:460,y:689,t:1527613993492};\\\", \\\"{x:450,y:682,t:1527613993508};\\\", \\\"{x:443,y:675,t:1527613993525};\\\", \\\"{x:438,y:666,t:1527613993543};\\\", \\\"{x:433,y:655,t:1527613993557};\\\", \\\"{x:428,y:642,t:1527613993575};\\\", \\\"{x:424,y:625,t:1527613993593};\\\", \\\"{x:422,y:609,t:1527613993609};\\\", \\\"{x:420,y:584,t:1527613993626};\\\", \\\"{x:421,y:569,t:1527613993643};\\\", \\\"{x:426,y:557,t:1527613993660};\\\", \\\"{x:432,y:544,t:1527613993676};\\\", \\\"{x:440,y:530,t:1527613993693};\\\", \\\"{x:446,y:523,t:1527613993709};\\\", \\\"{x:454,y:517,t:1527613993727};\\\", \\\"{x:461,y:510,t:1527613993742};\\\", \\\"{x:468,y:507,t:1527613993759};\\\", \\\"{x:475,y:504,t:1527613993775};\\\", \\\"{x:480,y:500,t:1527613993793};\\\", \\\"{x:490,y:498,t:1527613993809};\\\", \\\"{x:495,y:496,t:1527613993825};\\\", \\\"{x:499,y:495,t:1527613993845};\\\", \\\"{x:503,y:495,t:1527613993859};\\\", \\\"{x:506,y:495,t:1527613993875};\\\", \\\"{x:510,y:495,t:1527613993893};\\\", \\\"{x:517,y:500,t:1527613993910};\\\", \\\"{x:520,y:507,t:1527613993925};\\\", \\\"{x:522,y:520,t:1527613993943};\\\", \\\"{x:518,y:535,t:1527613993961};\\\", \\\"{x:498,y:550,t:1527613993977};\\\", \\\"{x:455,y:563,t:1527613993993};\\\", \\\"{x:343,y:573,t:1527613994009};\\\", \\\"{x:263,y:573,t:1527613994026};\\\", \\\"{x:204,y:573,t:1527613994043};\\\", \\\"{x:166,y:576,t:1527613994060};\\\", \\\"{x:139,y:577,t:1527613994077};\\\", \\\"{x:130,y:577,t:1527613994093};\\\", \\\"{x:130,y:576,t:1527613994251};\\\", \\\"{x:130,y:574,t:1527613994260};\\\", \\\"{x:130,y:571,t:1527613994277};\\\", \\\"{x:131,y:567,t:1527613994293};\\\", \\\"{x:133,y:565,t:1527613994309};\\\", \\\"{x:134,y:562,t:1527613994327};\\\", \\\"{x:135,y:560,t:1527613994343};\\\", \\\"{x:137,y:556,t:1527613994359};\\\", \\\"{x:138,y:555,t:1527613994377};\\\", \\\"{x:139,y:554,t:1527613994392};\\\", \\\"{x:140,y:554,t:1527613994410};\\\", \\\"{x:141,y:552,t:1527613994426};\\\", \\\"{x:143,y:551,t:1527613994450};\\\", \\\"{x:144,y:550,t:1527613994460};\\\", \\\"{x:145,y:549,t:1527613994476};\\\", \\\"{x:147,y:548,t:1527613994494};\\\", \\\"{x:149,y:546,t:1527613994510};\\\", \\\"{x:150,y:545,t:1527613994526};\\\", \\\"{x:151,y:545,t:1527613994542};\\\", \\\"{x:152,y:545,t:1527613994560};\\\", \\\"{x:154,y:543,t:1527613994577};\\\", \\\"{x:156,y:543,t:1527613994922};\\\", \\\"{x:157,y:543,t:1527613994930};\\\", \\\"{x:159,y:543,t:1527613994944};\\\", \\\"{x:175,y:543,t:1527613994960};\\\", \\\"{x:191,y:543,t:1527613994977};\\\", \\\"{x:211,y:544,t:1527613994995};\\\", \\\"{x:228,y:546,t:1527613995010};\\\", \\\"{x:242,y:548,t:1527613995027};\\\", \\\"{x:255,y:548,t:1527613995044};\\\", \\\"{x:269,y:548,t:1527613995060};\\\", \\\"{x:283,y:550,t:1527613995078};\\\", \\\"{x:297,y:551,t:1527613995094};\\\", \\\"{x:312,y:552,t:1527613995110};\\\", \\\"{x:330,y:554,t:1527613995127};\\\", \\\"{x:347,y:555,t:1527613995144};\\\", \\\"{x:369,y:557,t:1527613995160};\\\", \\\"{x:391,y:557,t:1527613995177};\\\", \\\"{x:425,y:558,t:1527613995193};\\\", \\\"{x:440,y:558,t:1527613995211};\\\", \\\"{x:447,y:558,t:1527613995227};\\\", \\\"{x:448,y:558,t:1527613995244};\\\", \\\"{x:450,y:558,t:1527613995260};\\\", \\\"{x:451,y:558,t:1527613995277};\\\", \\\"{x:453,y:558,t:1527613995294};\\\", \\\"{x:458,y:558,t:1527613995311};\\\", \\\"{x:466,y:558,t:1527613995327};\\\", \\\"{x:475,y:558,t:1527613995344};\\\", \\\"{x:485,y:558,t:1527613995361};\\\", \\\"{x:496,y:558,t:1527613995377};\\\", \\\"{x:517,y:557,t:1527613995394};\\\", \\\"{x:532,y:557,t:1527613995411};\\\", \\\"{x:547,y:557,t:1527613995427};\\\", \\\"{x:562,y:557,t:1527613995445};\\\", \\\"{x:572,y:557,t:1527613995461};\\\", \\\"{x:579,y:557,t:1527613995477};\\\", \\\"{x:583,y:557,t:1527613995495};\\\", \\\"{x:586,y:557,t:1527613995511};\\\", \\\"{x:590,y:557,t:1527613995527};\\\", \\\"{x:593,y:557,t:1527613995544};\\\", \\\"{x:598,y:557,t:1527613995561};\\\", \\\"{x:601,y:557,t:1527613995577};\\\", \\\"{x:604,y:557,t:1527613995594};\\\", \\\"{x:606,y:557,t:1527613995611};\\\", \\\"{x:607,y:557,t:1527613995627};\\\", \\\"{x:610,y:557,t:1527613995644};\\\", \\\"{x:613,y:557,t:1527613995661};\\\", \\\"{x:615,y:557,t:1527613995677};\\\", \\\"{x:617,y:557,t:1527613995694};\\\", \\\"{x:619,y:557,t:1527613995711};\\\", \\\"{x:620,y:557,t:1527613995728};\\\", \\\"{x:621,y:557,t:1527613995747};\\\", \\\"{x:623,y:558,t:1527613995770};\\\", \\\"{x:625,y:558,t:1527613995858};\\\", \\\"{x:625,y:559,t:1527613995867};\\\", \\\"{x:626,y:560,t:1527613995883};\\\", \\\"{x:626,y:561,t:1527613995894};\\\", \\\"{x:627,y:561,t:1527613995915};\\\", \\\"{x:628,y:563,t:1527613995930};\\\", \\\"{x:629,y:565,t:1527613995944};\\\", \\\"{x:630,y:568,t:1527613995961};\\\", \\\"{x:632,y:572,t:1527613995978};\\\", \\\"{x:632,y:573,t:1527613995993};\\\", \\\"{x:633,y:574,t:1527613996011};\\\", \\\"{x:634,y:576,t:1527613996098};\\\", \\\"{x:635,y:577,t:1527613996114};\\\", \\\"{x:636,y:577,t:1527613996128};\\\", \\\"{x:642,y:578,t:1527613996143};\\\", \\\"{x:659,y:579,t:1527613996161};\\\", \\\"{x:697,y:579,t:1527613996178};\\\", \\\"{x:726,y:579,t:1527613996196};\\\", \\\"{x:743,y:577,t:1527613996210};\\\", \\\"{x:750,y:575,t:1527613996228};\\\", \\\"{x:754,y:573,t:1527613996245};\\\", \\\"{x:757,y:572,t:1527613996260};\\\", \\\"{x:758,y:570,t:1527613996278};\\\", \\\"{x:764,y:564,t:1527613996295};\\\", \\\"{x:769,y:560,t:1527613996311};\\\", \\\"{x:771,y:558,t:1527613996327};\\\", \\\"{x:774,y:554,t:1527613996346};\\\", \\\"{x:775,y:553,t:1527613996360};\\\", \\\"{x:777,y:548,t:1527613996378};\\\", \\\"{x:778,y:544,t:1527613996395};\\\", \\\"{x:781,y:539,t:1527613996411};\\\", \\\"{x:783,y:537,t:1527613996428};\\\", \\\"{x:786,y:534,t:1527613996445};\\\", \\\"{x:789,y:530,t:1527613996461};\\\", \\\"{x:794,y:524,t:1527613996478};\\\", \\\"{x:804,y:519,t:1527613996495};\\\", \\\"{x:816,y:512,t:1527613996512};\\\", \\\"{x:823,y:508,t:1527613996527};\\\", \\\"{x:826,y:506,t:1527613996545};\\\", \\\"{x:828,y:505,t:1527613996562};\\\", \\\"{x:829,y:504,t:1527613996602};\\\", \\\"{x:830,y:504,t:1527613996642};\\\", \\\"{x:831,y:503,t:1527613996753};\\\", \\\"{x:831,y:503,t:1527613996847};\\\", \\\"{x:826,y:505,t:1527613996970};\\\", \\\"{x:801,y:526,t:1527613996980};\\\", \\\"{x:753,y:576,t:1527613996995};\\\", \\\"{x:706,y:624,t:1527613997012};\\\", \\\"{x:678,y:653,t:1527613997028};\\\", \\\"{x:663,y:671,t:1527613997045};\\\", \\\"{x:657,y:682,t:1527613997062};\\\", \\\"{x:653,y:690,t:1527613997079};\\\", \\\"{x:648,y:698,t:1527613997095};\\\", \\\"{x:642,y:705,t:1527613997112};\\\", \\\"{x:631,y:715,t:1527613997129};\\\", \\\"{x:617,y:724,t:1527613997145};\\\", \\\"{x:600,y:733,t:1527613997162};\\\", \\\"{x:593,y:737,t:1527613997179};\\\", \\\"{x:592,y:737,t:1527613997196};\\\", \\\"{x:592,y:738,t:1527613997212};\\\", \\\"{x:591,y:738,t:1527613997267};\\\", \\\"{x:588,y:738,t:1527613997280};\\\", \\\"{x:577,y:739,t:1527613997296};\\\", \\\"{x:558,y:742,t:1527613997313};\\\", \\\"{x:539,y:742,t:1527613997329};\\\", \\\"{x:525,y:742,t:1527613997344};\\\", \\\"{x:518,y:742,t:1527613997362};\\\", \\\"{x:517,y:742,t:1527613997379};\\\" ] }, { \\\"rt\\\": 15197, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 615004, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:742,t:1527614000574};\\\", \\\"{x:530,y:738,t:1527614004518};\\\", \\\"{x:578,y:735,t:1527614004529};\\\", \\\"{x:664,y:735,t:1527614004543};\\\", \\\"{x:758,y:735,t:1527614004559};\\\", \\\"{x:814,y:735,t:1527614004571};\\\", \\\"{x:902,y:735,t:1527614004588};\\\", \\\"{x:950,y:735,t:1527614004604};\\\", \\\"{x:991,y:736,t:1527614004622};\\\", \\\"{x:1005,y:736,t:1527614004637};\\\", \\\"{x:1013,y:736,t:1527614004655};\\\", \\\"{x:1022,y:736,t:1527614004672};\\\", \\\"{x:1032,y:737,t:1527614004688};\\\", \\\"{x:1042,y:739,t:1527614004705};\\\", \\\"{x:1049,y:739,t:1527614004722};\\\", \\\"{x:1055,y:740,t:1527614004738};\\\", \\\"{x:1058,y:740,t:1527614004755};\\\", \\\"{x:1064,y:740,t:1527614004772};\\\", \\\"{x:1070,y:740,t:1527614004789};\\\", \\\"{x:1081,y:741,t:1527614004805};\\\", \\\"{x:1096,y:743,t:1527614004822};\\\", \\\"{x:1108,y:743,t:1527614004838};\\\", \\\"{x:1116,y:745,t:1527614004854};\\\", \\\"{x:1121,y:745,t:1527614004872};\\\", \\\"{x:1123,y:745,t:1527614004889};\\\", \\\"{x:1124,y:745,t:1527614004905};\\\", \\\"{x:1129,y:745,t:1527614004922};\\\", \\\"{x:1138,y:745,t:1527614004939};\\\", \\\"{x:1147,y:745,t:1527614004955};\\\", \\\"{x:1165,y:745,t:1527614004972};\\\", \\\"{x:1184,y:747,t:1527614004990};\\\", \\\"{x:1216,y:748,t:1527614005006};\\\", \\\"{x:1232,y:750,t:1527614005022};\\\", \\\"{x:1249,y:752,t:1527614005039};\\\", \\\"{x:1270,y:753,t:1527614005056};\\\", \\\"{x:1297,y:753,t:1527614005072};\\\", \\\"{x:1318,y:753,t:1527614005089};\\\", \\\"{x:1340,y:753,t:1527614005106};\\\", \\\"{x:1358,y:753,t:1527614005122};\\\", \\\"{x:1372,y:753,t:1527614005139};\\\", \\\"{x:1382,y:753,t:1527614005156};\\\", \\\"{x:1393,y:753,t:1527614005172};\\\", \\\"{x:1398,y:753,t:1527614005189};\\\", \\\"{x:1401,y:753,t:1527614005205};\\\", \\\"{x:1403,y:752,t:1527614005222};\\\", \\\"{x:1405,y:751,t:1527614005239};\\\", \\\"{x:1406,y:750,t:1527614005256};\\\", \\\"{x:1408,y:748,t:1527614005272};\\\", \\\"{x:1412,y:740,t:1527614005290};\\\", \\\"{x:1416,y:731,t:1527614005306};\\\", \\\"{x:1417,y:724,t:1527614005323};\\\", \\\"{x:1418,y:719,t:1527614005340};\\\", \\\"{x:1418,y:714,t:1527614005357};\\\", \\\"{x:1419,y:706,t:1527614005374};\\\", \\\"{x:1419,y:705,t:1527614005389};\\\", \\\"{x:1419,y:700,t:1527614005406};\\\", \\\"{x:1419,y:698,t:1527614005438};\\\", \\\"{x:1419,y:697,t:1527614005462};\\\", \\\"{x:1419,y:696,t:1527614005478};\\\", \\\"{x:1417,y:694,t:1527614005503};\\\", \\\"{x:1416,y:693,t:1527614005526};\\\", \\\"{x:1414,y:691,t:1527614005542};\\\", \\\"{x:1413,y:690,t:1527614005565};\\\", \\\"{x:1412,y:689,t:1527614005581};\\\", \\\"{x:1411,y:688,t:1527614006550};\\\", \\\"{x:1405,y:694,t:1527614007806};\\\", \\\"{x:1397,y:703,t:1527614007814};\\\", \\\"{x:1390,y:710,t:1527614007826};\\\", \\\"{x:1379,y:719,t:1527614007842};\\\", \\\"{x:1370,y:726,t:1527614007860};\\\", \\\"{x:1360,y:734,t:1527614007876};\\\", \\\"{x:1357,y:737,t:1527614007893};\\\", \\\"{x:1356,y:738,t:1527614007909};\\\", \\\"{x:1356,y:737,t:1527614008183};\\\", \\\"{x:1356,y:735,t:1527614008193};\\\", \\\"{x:1356,y:733,t:1527614008209};\\\", \\\"{x:1356,y:731,t:1527614008226};\\\", \\\"{x:1356,y:729,t:1527614008243};\\\", \\\"{x:1356,y:727,t:1527614008259};\\\", \\\"{x:1356,y:726,t:1527614008278};\\\", \\\"{x:1356,y:725,t:1527614008293};\\\", \\\"{x:1356,y:724,t:1527614008326};\\\", \\\"{x:1356,y:723,t:1527614008374};\\\", \\\"{x:1356,y:722,t:1527614008398};\\\", \\\"{x:1356,y:721,t:1527614008414};\\\", \\\"{x:1356,y:719,t:1527614008438};\\\", \\\"{x:1355,y:718,t:1527614008462};\\\", \\\"{x:1354,y:718,t:1527614008476};\\\", \\\"{x:1354,y:717,t:1527614008494};\\\", \\\"{x:1354,y:716,t:1527614008510};\\\", \\\"{x:1353,y:715,t:1527614008526};\\\", \\\"{x:1353,y:714,t:1527614008544};\\\", \\\"{x:1353,y:712,t:1527614008560};\\\", \\\"{x:1353,y:710,t:1527614008598};\\\", \\\"{x:1352,y:709,t:1527614008611};\\\", \\\"{x:1351,y:708,t:1527614008626};\\\", \\\"{x:1351,y:707,t:1527614008643};\\\", \\\"{x:1350,y:705,t:1527614008659};\\\", \\\"{x:1349,y:703,t:1527614008676};\\\", \\\"{x:1348,y:701,t:1527614008709};\\\", \\\"{x:1348,y:706,t:1527614009272};\\\", \\\"{x:1348,y:710,t:1527614009278};\\\", \\\"{x:1347,y:714,t:1527614009294};\\\", \\\"{x:1347,y:717,t:1527614009312};\\\", \\\"{x:1347,y:721,t:1527614009327};\\\", \\\"{x:1347,y:722,t:1527614009344};\\\", \\\"{x:1347,y:725,t:1527614009362};\\\", \\\"{x:1347,y:728,t:1527614009378};\\\", \\\"{x:1347,y:730,t:1527614009394};\\\", \\\"{x:1347,y:732,t:1527614009412};\\\", \\\"{x:1347,y:734,t:1527614009427};\\\", \\\"{x:1347,y:735,t:1527614009444};\\\", \\\"{x:1347,y:738,t:1527614009461};\\\", \\\"{x:1347,y:739,t:1527614009477};\\\", \\\"{x:1347,y:740,t:1527614009495};\\\", \\\"{x:1347,y:741,t:1527614009541};\\\", \\\"{x:1347,y:742,t:1527614009550};\\\", \\\"{x:1347,y:743,t:1527614009574};\\\", \\\"{x:1348,y:744,t:1527614009590};\\\", \\\"{x:1348,y:745,t:1527614009598};\\\", \\\"{x:1348,y:746,t:1527614009611};\\\", \\\"{x:1348,y:749,t:1527614009627};\\\", \\\"{x:1348,y:755,t:1527614009644};\\\", \\\"{x:1351,y:769,t:1527614009663};\\\", \\\"{x:1351,y:777,t:1527614009677};\\\", \\\"{x:1352,y:783,t:1527614009695};\\\", \\\"{x:1352,y:786,t:1527614009711};\\\", \\\"{x:1352,y:790,t:1527614009729};\\\", \\\"{x:1352,y:793,t:1527614009744};\\\", \\\"{x:1352,y:797,t:1527614009762};\\\", \\\"{x:1351,y:802,t:1527614009779};\\\", \\\"{x:1349,y:811,t:1527614009794};\\\", \\\"{x:1348,y:819,t:1527614009812};\\\", \\\"{x:1347,y:827,t:1527614009828};\\\", \\\"{x:1346,y:836,t:1527614009844};\\\", \\\"{x:1346,y:842,t:1527614009861};\\\", \\\"{x:1346,y:847,t:1527614009877};\\\", \\\"{x:1346,y:854,t:1527614009895};\\\", \\\"{x:1346,y:860,t:1527614009911};\\\", \\\"{x:1346,y:868,t:1527614009928};\\\", \\\"{x:1346,y:879,t:1527614009945};\\\", \\\"{x:1346,y:890,t:1527614009961};\\\", \\\"{x:1346,y:904,t:1527614009978};\\\", \\\"{x:1343,y:913,t:1527614009995};\\\", \\\"{x:1343,y:921,t:1527614010011};\\\", \\\"{x:1342,y:926,t:1527614010028};\\\", \\\"{x:1341,y:930,t:1527614010045};\\\", \\\"{x:1341,y:932,t:1527614010061};\\\", \\\"{x:1341,y:933,t:1527614010078};\\\", \\\"{x:1341,y:935,t:1527614010095};\\\", \\\"{x:1341,y:938,t:1527614010112};\\\", \\\"{x:1339,y:942,t:1527614010128};\\\", \\\"{x:1339,y:944,t:1527614010145};\\\", \\\"{x:1338,y:946,t:1527614010162};\\\", \\\"{x:1338,y:947,t:1527614010178};\\\", \\\"{x:1338,y:948,t:1527614010198};\\\", \\\"{x:1338,y:949,t:1527614010286};\\\", \\\"{x:1302,y:945,t:1527614011118};\\\", \\\"{x:1242,y:917,t:1527614011129};\\\", \\\"{x:1116,y:870,t:1527614011146};\\\", \\\"{x:978,y:829,t:1527614011162};\\\", \\\"{x:851,y:795,t:1527614011179};\\\", \\\"{x:746,y:765,t:1527614011196};\\\", \\\"{x:681,y:746,t:1527614011212};\\\", \\\"{x:658,y:741,t:1527614011230};\\\", \\\"{x:638,y:738,t:1527614011245};\\\", \\\"{x:614,y:735,t:1527614011263};\\\", \\\"{x:585,y:730,t:1527614011280};\\\", \\\"{x:534,y:723,t:1527614011296};\\\", \\\"{x:497,y:716,t:1527614011314};\\\", \\\"{x:469,y:714,t:1527614011329};\\\", \\\"{x:445,y:709,t:1527614011342};\\\", \\\"{x:426,y:707,t:1527614011359};\\\", \\\"{x:404,y:704,t:1527614011377};\\\", \\\"{x:375,y:699,t:1527614011393};\\\", \\\"{x:339,y:695,t:1527614011410};\\\", \\\"{x:312,y:691,t:1527614011427};\\\", \\\"{x:289,y:684,t:1527614011443};\\\", \\\"{x:275,y:680,t:1527614011460};\\\", \\\"{x:258,y:674,t:1527614011476};\\\", \\\"{x:254,y:672,t:1527614011493};\\\", \\\"{x:249,y:669,t:1527614011510};\\\", \\\"{x:240,y:666,t:1527614011526};\\\", \\\"{x:227,y:661,t:1527614011543};\\\", \\\"{x:215,y:656,t:1527614011560};\\\", \\\"{x:204,y:651,t:1527614011577};\\\", \\\"{x:197,y:647,t:1527614011592};\\\", \\\"{x:196,y:645,t:1527614011610};\\\", \\\"{x:196,y:643,t:1527614011627};\\\", \\\"{x:192,y:639,t:1527614011643};\\\", \\\"{x:189,y:635,t:1527614011661};\\\", \\\"{x:185,y:627,t:1527614011678};\\\", \\\"{x:182,y:623,t:1527614011694};\\\", \\\"{x:182,y:621,t:1527614011710};\\\", \\\"{x:182,y:616,t:1527614011727};\\\", \\\"{x:182,y:611,t:1527614011743};\\\", \\\"{x:182,y:607,t:1527614011759};\\\", \\\"{x:182,y:601,t:1527614011778};\\\", \\\"{x:182,y:598,t:1527614011795};\\\", \\\"{x:182,y:597,t:1527614011810};\\\", \\\"{x:182,y:595,t:1527614011827};\\\", \\\"{x:181,y:594,t:1527614011844};\\\", \\\"{x:181,y:593,t:1527614011911};\\\", \\\"{x:181,y:592,t:1527614011927};\\\", \\\"{x:179,y:590,t:1527614011944};\\\", \\\"{x:178,y:589,t:1527614011959};\\\", \\\"{x:178,y:588,t:1527614011977};\\\", \\\"{x:178,y:586,t:1527614011994};\\\", \\\"{x:176,y:584,t:1527614012010};\\\", \\\"{x:175,y:583,t:1527614012027};\\\", \\\"{x:174,y:579,t:1527614012044};\\\", \\\"{x:173,y:575,t:1527614012060};\\\", \\\"{x:172,y:571,t:1527614012076};\\\", \\\"{x:172,y:568,t:1527614012094};\\\", \\\"{x:172,y:565,t:1527614012110};\\\", \\\"{x:171,y:560,t:1527614012127};\\\", \\\"{x:171,y:557,t:1527614012144};\\\", \\\"{x:171,y:553,t:1527614012162};\\\", \\\"{x:171,y:551,t:1527614012176};\\\", \\\"{x:171,y:550,t:1527614012194};\\\", \\\"{x:171,y:548,t:1527614012214};\\\", \\\"{x:171,y:547,t:1527614012229};\\\", \\\"{x:171,y:546,t:1527614012245};\\\", \\\"{x:172,y:545,t:1527614012277};\\\", \\\"{x:172,y:544,t:1527614012317};\\\", \\\"{x:173,y:543,t:1527614012845};\\\", \\\"{x:177,y:543,t:1527614012886};\\\", \\\"{x:192,y:546,t:1527614012896};\\\", \\\"{x:262,y:565,t:1527614012912};\\\", \\\"{x:350,y:588,t:1527614012928};\\\", \\\"{x:447,y:614,t:1527614012945};\\\", \\\"{x:516,y:623,t:1527614012962};\\\", \\\"{x:551,y:629,t:1527614012978};\\\", \\\"{x:556,y:629,t:1527614012993};\\\", \\\"{x:558,y:629,t:1527614013010};\\\", \\\"{x:559,y:629,t:1527614013093};\\\", \\\"{x:560,y:629,t:1527614013101};\\\", \\\"{x:561,y:629,t:1527614013111};\\\", \\\"{x:564,y:630,t:1527614013128};\\\", \\\"{x:568,y:632,t:1527614013144};\\\", \\\"{x:571,y:633,t:1527614013161};\\\", \\\"{x:572,y:633,t:1527614013178};\\\", \\\"{x:576,y:634,t:1527614013195};\\\", \\\"{x:577,y:634,t:1527614013213};\\\", \\\"{x:578,y:635,t:1527614013228};\\\", \\\"{x:582,y:636,t:1527614013245};\\\", \\\"{x:585,y:637,t:1527614013261};\\\", \\\"{x:596,y:641,t:1527614013278};\\\", \\\"{x:606,y:643,t:1527614013295};\\\", \\\"{x:620,y:647,t:1527614013311};\\\", \\\"{x:633,y:652,t:1527614013328};\\\", \\\"{x:641,y:656,t:1527614013345};\\\", \\\"{x:644,y:659,t:1527614013361};\\\", \\\"{x:645,y:660,t:1527614013378};\\\", \\\"{x:645,y:661,t:1527614013395};\\\", \\\"{x:645,y:665,t:1527614013411};\\\", \\\"{x:645,y:671,t:1527614013428};\\\", \\\"{x:645,y:684,t:1527614013444};\\\", \\\"{x:639,y:693,t:1527614013462};\\\", \\\"{x:631,y:704,t:1527614013478};\\\", \\\"{x:620,y:714,t:1527614013495};\\\", \\\"{x:606,y:720,t:1527614013512};\\\", \\\"{x:593,y:727,t:1527614013528};\\\", \\\"{x:580,y:730,t:1527614013545};\\\", \\\"{x:566,y:734,t:1527614013562};\\\", \\\"{x:554,y:737,t:1527614013578};\\\", \\\"{x:543,y:738,t:1527614013595};\\\", \\\"{x:537,y:739,t:1527614013612};\\\", \\\"{x:530,y:739,t:1527614013628};\\\", \\\"{x:516,y:739,t:1527614013645};\\\", \\\"{x:504,y:739,t:1527614013662};\\\", \\\"{x:495,y:739,t:1527614013678};\\\", \\\"{x:490,y:739,t:1527614013696};\\\", \\\"{x:485,y:738,t:1527614013712};\\\", \\\"{x:484,y:738,t:1527614013729};\\\", \\\"{x:483,y:737,t:1527614014470};\\\" ] }, { \\\"rt\\\": 39885, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 656164, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-I -Z -3-I -B -B -J -B -X -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:736,t:1527614015284};\\\", \\\"{x:486,y:735,t:1527614015380};\\\", \\\"{x:487,y:735,t:1527614015429};\\\", \\\"{x:488,y:735,t:1527614015444};\\\", \\\"{x:489,y:734,t:1527614015565};\\\", \\\"{x:491,y:734,t:1527614015900};\\\", \\\"{x:492,y:732,t:1527614015917};\\\", \\\"{x:493,y:732,t:1527614015933};\\\", \\\"{x:493,y:731,t:1527614015957};\\\", \\\"{x:494,y:731,t:1527614015964};\\\", \\\"{x:496,y:731,t:1527614015989};\\\", \\\"{x:497,y:731,t:1527614015998};\\\", \\\"{x:502,y:728,t:1527614016015};\\\", \\\"{x:504,y:727,t:1527614016033};\\\", \\\"{x:514,y:725,t:1527614016048};\\\", \\\"{x:530,y:721,t:1527614016065};\\\", \\\"{x:552,y:717,t:1527614016083};\\\", \\\"{x:575,y:714,t:1527614016098};\\\", \\\"{x:603,y:710,t:1527614016114};\\\", \\\"{x:628,y:706,t:1527614016130};\\\", \\\"{x:643,y:703,t:1527614016147};\\\", \\\"{x:657,y:700,t:1527614016164};\\\", \\\"{x:672,y:695,t:1527614016180};\\\", \\\"{x:688,y:692,t:1527614016197};\\\", \\\"{x:703,y:686,t:1527614016214};\\\", \\\"{x:710,y:685,t:1527614016230};\\\", \\\"{x:726,y:682,t:1527614016247};\\\", \\\"{x:744,y:680,t:1527614016264};\\\", \\\"{x:766,y:677,t:1527614016281};\\\", \\\"{x:792,y:675,t:1527614016297};\\\", \\\"{x:815,y:675,t:1527614016314};\\\", \\\"{x:834,y:675,t:1527614016331};\\\", \\\"{x:846,y:675,t:1527614016348};\\\", \\\"{x:851,y:675,t:1527614016364};\\\", \\\"{x:853,y:674,t:1527614016381};\\\", \\\"{x:856,y:674,t:1527614016397};\\\", \\\"{x:859,y:674,t:1527614016414};\\\", \\\"{x:864,y:673,t:1527614016431};\\\", \\\"{x:872,y:672,t:1527614016448};\\\", \\\"{x:884,y:672,t:1527614016464};\\\", \\\"{x:899,y:671,t:1527614016481};\\\", \\\"{x:916,y:670,t:1527614016498};\\\", \\\"{x:932,y:670,t:1527614016514};\\\", \\\"{x:951,y:670,t:1527614016532};\\\", \\\"{x:968,y:670,t:1527614016547};\\\", \\\"{x:990,y:670,t:1527614016565};\\\", \\\"{x:1008,y:670,t:1527614016582};\\\", \\\"{x:1020,y:670,t:1527614016598};\\\", \\\"{x:1027,y:670,t:1527614016615};\\\", \\\"{x:1033,y:672,t:1527614016632};\\\", \\\"{x:1035,y:672,t:1527614016648};\\\", \\\"{x:1035,y:673,t:1527614017046};\\\", \\\"{x:1040,y:676,t:1527614017061};\\\", \\\"{x:1051,y:686,t:1527614017070};\\\", \\\"{x:1062,y:696,t:1527614017082};\\\", \\\"{x:1106,y:722,t:1527614017100};\\\", \\\"{x:1140,y:745,t:1527614017115};\\\", \\\"{x:1157,y:752,t:1527614017132};\\\", \\\"{x:1168,y:759,t:1527614017148};\\\", \\\"{x:1178,y:765,t:1527614017168};\\\", \\\"{x:1181,y:766,t:1527614017181};\\\", \\\"{x:1185,y:767,t:1527614017198};\\\", \\\"{x:1195,y:770,t:1527614017215};\\\", \\\"{x:1216,y:776,t:1527614017231};\\\", \\\"{x:1238,y:780,t:1527614017248};\\\", \\\"{x:1260,y:785,t:1527614017265};\\\", \\\"{x:1277,y:789,t:1527614017281};\\\", \\\"{x:1295,y:789,t:1527614017298};\\\", \\\"{x:1314,y:791,t:1527614017316};\\\", \\\"{x:1328,y:792,t:1527614017332};\\\", \\\"{x:1342,y:792,t:1527614017348};\\\", \\\"{x:1361,y:786,t:1527614017365};\\\", \\\"{x:1372,y:780,t:1527614017381};\\\", \\\"{x:1381,y:777,t:1527614017398};\\\", \\\"{x:1390,y:772,t:1527614017415};\\\", \\\"{x:1395,y:770,t:1527614017431};\\\", \\\"{x:1399,y:769,t:1527614017448};\\\", \\\"{x:1405,y:766,t:1527614017466};\\\", \\\"{x:1415,y:761,t:1527614017483};\\\", \\\"{x:1423,y:757,t:1527614017498};\\\", \\\"{x:1430,y:754,t:1527614017516};\\\", \\\"{x:1436,y:752,t:1527614017533};\\\", \\\"{x:1441,y:750,t:1527614017549};\\\", \\\"{x:1444,y:748,t:1527614017566};\\\", \\\"{x:1446,y:748,t:1527614017583};\\\", \\\"{x:1452,y:746,t:1527614017599};\\\", \\\"{x:1456,y:745,t:1527614017616};\\\", \\\"{x:1463,y:742,t:1527614017633};\\\", \\\"{x:1470,y:740,t:1527614017649};\\\", \\\"{x:1480,y:739,t:1527614017666};\\\", \\\"{x:1490,y:737,t:1527614017683};\\\", \\\"{x:1497,y:737,t:1527614017699};\\\", \\\"{x:1506,y:736,t:1527614017715};\\\", \\\"{x:1519,y:733,t:1527614017733};\\\", \\\"{x:1536,y:732,t:1527614017750};\\\", \\\"{x:1553,y:731,t:1527614017766};\\\", \\\"{x:1571,y:728,t:1527614017782};\\\", \\\"{x:1575,y:727,t:1527614017800};\\\", \\\"{x:1581,y:726,t:1527614017815};\\\", \\\"{x:1582,y:726,t:1527614017833};\\\", \\\"{x:1583,y:726,t:1527614017850};\\\", \\\"{x:1586,y:724,t:1527614017894};\\\", \\\"{x:1589,y:722,t:1527614017902};\\\", \\\"{x:1595,y:719,t:1527614017915};\\\", \\\"{x:1601,y:715,t:1527614017932};\\\", \\\"{x:1608,y:710,t:1527614017950};\\\", \\\"{x:1611,y:708,t:1527614017966};\\\", \\\"{x:1612,y:706,t:1527614017983};\\\", \\\"{x:1614,y:705,t:1527614018000};\\\", \\\"{x:1615,y:703,t:1527614018015};\\\", \\\"{x:1615,y:702,t:1527614018038};\\\", \\\"{x:1615,y:700,t:1527614018213};\\\", \\\"{x:1615,y:699,t:1527614018286};\\\", \\\"{x:1616,y:698,t:1527614018299};\\\", \\\"{x:1603,y:704,t:1527614019327};\\\", \\\"{x:1547,y:740,t:1527614019333};\\\", \\\"{x:1458,y:785,t:1527614019351};\\\", \\\"{x:1409,y:805,t:1527614019368};\\\", \\\"{x:1372,y:810,t:1527614019384};\\\", \\\"{x:1330,y:817,t:1527614019401};\\\", \\\"{x:1305,y:817,t:1527614019418};\\\", \\\"{x:1300,y:817,t:1527614019434};\\\", \\\"{x:1299,y:817,t:1527614019454};\\\", \\\"{x:1298,y:817,t:1527614019469};\\\", \\\"{x:1295,y:817,t:1527614019484};\\\", \\\"{x:1292,y:815,t:1527614019500};\\\", \\\"{x:1283,y:797,t:1527614019517};\\\", \\\"{x:1280,y:779,t:1527614019535};\\\", \\\"{x:1280,y:765,t:1527614019551};\\\", \\\"{x:1280,y:756,t:1527614019568};\\\", \\\"{x:1283,y:748,t:1527614019585};\\\", \\\"{x:1290,y:740,t:1527614019601};\\\", \\\"{x:1297,y:730,t:1527614019618};\\\", \\\"{x:1306,y:720,t:1527614019635};\\\", \\\"{x:1313,y:712,t:1527614019651};\\\", \\\"{x:1320,y:703,t:1527614019667};\\\", \\\"{x:1326,y:696,t:1527614019686};\\\", \\\"{x:1330,y:692,t:1527614019702};\\\", \\\"{x:1333,y:688,t:1527614019718};\\\", \\\"{x:1337,y:684,t:1527614019734};\\\", \\\"{x:1341,y:680,t:1527614019750};\\\", \\\"{x:1344,y:676,t:1527614019768};\\\", \\\"{x:1349,y:671,t:1527614019785};\\\", \\\"{x:1355,y:667,t:1527614019801};\\\", \\\"{x:1359,y:664,t:1527614019817};\\\", \\\"{x:1362,y:662,t:1527614019834};\\\", \\\"{x:1367,y:659,t:1527614019850};\\\", \\\"{x:1375,y:656,t:1527614019867};\\\", \\\"{x:1385,y:652,t:1527614019884};\\\", \\\"{x:1398,y:647,t:1527614019901};\\\", \\\"{x:1405,y:645,t:1527614019917};\\\", \\\"{x:1409,y:643,t:1527614019935};\\\", \\\"{x:1410,y:643,t:1527614019951};\\\", \\\"{x:1411,y:643,t:1527614019967};\\\", \\\"{x:1414,y:643,t:1527614020062};\\\", \\\"{x:1416,y:648,t:1527614020069};\\\", \\\"{x:1420,y:655,t:1527614020084};\\\", \\\"{x:1431,y:673,t:1527614020101};\\\", \\\"{x:1434,y:678,t:1527614020117};\\\", \\\"{x:1434,y:681,t:1527614020134};\\\", \\\"{x:1435,y:685,t:1527614020152};\\\", \\\"{x:1436,y:686,t:1527614020173};\\\", \\\"{x:1436,y:689,t:1527614020190};\\\", \\\"{x:1436,y:693,t:1527614020202};\\\", \\\"{x:1427,y:701,t:1527614020218};\\\", \\\"{x:1418,y:708,t:1527614020234};\\\", \\\"{x:1402,y:715,t:1527614020252};\\\", \\\"{x:1385,y:720,t:1527614020268};\\\", \\\"{x:1357,y:728,t:1527614020285};\\\", \\\"{x:1289,y:737,t:1527614020302};\\\", \\\"{x:1208,y:737,t:1527614020319};\\\", \\\"{x:1109,y:737,t:1527614020335};\\\", \\\"{x:994,y:730,t:1527614020352};\\\", \\\"{x:875,y:698,t:1527614020369};\\\", \\\"{x:764,y:663,t:1527614020385};\\\", \\\"{x:667,y:638,t:1527614020402};\\\", \\\"{x:590,y:606,t:1527614020420};\\\", \\\"{x:533,y:584,t:1527614020436};\\\", \\\"{x:481,y:561,t:1527614020468};\\\", \\\"{x:474,y:560,t:1527614020484};\\\", \\\"{x:473,y:560,t:1527614020500};\\\", \\\"{x:472,y:559,t:1527614020541};\\\", \\\"{x:470,y:559,t:1527614020573};\\\", \\\"{x:470,y:557,t:1527614020589};\\\", \\\"{x:470,y:553,t:1527614020601};\\\", \\\"{x:470,y:546,t:1527614020617};\\\", \\\"{x:470,y:538,t:1527614020633};\\\", \\\"{x:471,y:530,t:1527614020651};\\\", \\\"{x:480,y:522,t:1527614020668};\\\", \\\"{x:494,y:512,t:1527614020685};\\\", \\\"{x:510,y:506,t:1527614020702};\\\", \\\"{x:527,y:501,t:1527614020717};\\\", \\\"{x:534,y:499,t:1527614020734};\\\", \\\"{x:538,y:499,t:1527614020751};\\\", \\\"{x:541,y:499,t:1527614020767};\\\", \\\"{x:545,y:499,t:1527614020784};\\\", \\\"{x:549,y:499,t:1527614020800};\\\", \\\"{x:554,y:500,t:1527614020817};\\\", \\\"{x:561,y:503,t:1527614020834};\\\", \\\"{x:566,y:504,t:1527614020852};\\\", \\\"{x:572,y:508,t:1527614020867};\\\", \\\"{x:576,y:511,t:1527614020885};\\\", \\\"{x:582,y:514,t:1527614020900};\\\", \\\"{x:583,y:514,t:1527614020917};\\\", \\\"{x:584,y:514,t:1527614020934};\\\", \\\"{x:586,y:515,t:1527614020951};\\\", \\\"{x:594,y:519,t:1527614020968};\\\", \\\"{x:621,y:531,t:1527614020986};\\\", \\\"{x:659,y:539,t:1527614021002};\\\", \\\"{x:732,y:553,t:1527614021018};\\\", \\\"{x:800,y:565,t:1527614021035};\\\", \\\"{x:855,y:572,t:1527614021050};\\\", \\\"{x:892,y:572,t:1527614021068};\\\", \\\"{x:905,y:572,t:1527614021084};\\\", \\\"{x:907,y:572,t:1527614021101};\\\", \\\"{x:908,y:570,t:1527614021117};\\\", \\\"{x:910,y:560,t:1527614021135};\\\", \\\"{x:910,y:555,t:1527614021151};\\\", \\\"{x:909,y:551,t:1527614021167};\\\", \\\"{x:906,y:546,t:1527614021184};\\\", \\\"{x:901,y:542,t:1527614021200};\\\", \\\"{x:895,y:539,t:1527614021217};\\\", \\\"{x:889,y:535,t:1527614021234};\\\", \\\"{x:882,y:534,t:1527614021250};\\\", \\\"{x:877,y:531,t:1527614021267};\\\", \\\"{x:875,y:530,t:1527614021284};\\\", \\\"{x:871,y:529,t:1527614021301};\\\", \\\"{x:867,y:527,t:1527614021317};\\\", \\\"{x:863,y:525,t:1527614021333};\\\", \\\"{x:863,y:524,t:1527614021366};\\\", \\\"{x:862,y:523,t:1527614021383};\\\", \\\"{x:860,y:520,t:1527614021400};\\\", \\\"{x:858,y:516,t:1527614021419};\\\", \\\"{x:855,y:511,t:1527614021434};\\\", \\\"{x:851,y:506,t:1527614021451};\\\", \\\"{x:849,y:504,t:1527614021468};\\\", \\\"{x:848,y:502,t:1527614021484};\\\", \\\"{x:847,y:501,t:1527614021501};\\\", \\\"{x:846,y:500,t:1527614021526};\\\", \\\"{x:846,y:503,t:1527614022094};\\\", \\\"{x:864,y:526,t:1527614022104};\\\", \\\"{x:921,y:571,t:1527614022119};\\\", \\\"{x:980,y:614,t:1527614022136};\\\", \\\"{x:1038,y:651,t:1527614022151};\\\", \\\"{x:1083,y:672,t:1527614022168};\\\", \\\"{x:1105,y:684,t:1527614022185};\\\", \\\"{x:1121,y:691,t:1527614022201};\\\", \\\"{x:1127,y:694,t:1527614022219};\\\", \\\"{x:1130,y:695,t:1527614022235};\\\", \\\"{x:1134,y:696,t:1527614022251};\\\", \\\"{x:1140,y:698,t:1527614022268};\\\", \\\"{x:1148,y:699,t:1527614022285};\\\", \\\"{x:1164,y:702,t:1527614022302};\\\", \\\"{x:1180,y:702,t:1527614022318};\\\", \\\"{x:1202,y:703,t:1527614022335};\\\", \\\"{x:1220,y:705,t:1527614022351};\\\", \\\"{x:1235,y:705,t:1527614022368};\\\", \\\"{x:1248,y:705,t:1527614022385};\\\", \\\"{x:1256,y:705,t:1527614022402};\\\", \\\"{x:1261,y:705,t:1527614022419};\\\", \\\"{x:1268,y:705,t:1527614022435};\\\", \\\"{x:1274,y:704,t:1527614022452};\\\", \\\"{x:1278,y:704,t:1527614022468};\\\", \\\"{x:1288,y:702,t:1527614022486};\\\", \\\"{x:1292,y:702,t:1527614022502};\\\", \\\"{x:1294,y:701,t:1527614022519};\\\", \\\"{x:1290,y:701,t:1527614027990};\\\", \\\"{x:1235,y:737,t:1527614028007};\\\", \\\"{x:1191,y:755,t:1527614028023};\\\", \\\"{x:1162,y:763,t:1527614028038};\\\", \\\"{x:1142,y:768,t:1527614028055};\\\", \\\"{x:1134,y:773,t:1527614028072};\\\", \\\"{x:1132,y:774,t:1527614028089};\\\", \\\"{x:1132,y:775,t:1527614028105};\\\", \\\"{x:1128,y:775,t:1527614028122};\\\", \\\"{x:1126,y:778,t:1527614028140};\\\", \\\"{x:1122,y:780,t:1527614028155};\\\", \\\"{x:1115,y:784,t:1527614028173};\\\", \\\"{x:1107,y:787,t:1527614028189};\\\", \\\"{x:1103,y:789,t:1527614028206};\\\", \\\"{x:1101,y:790,t:1527614028223};\\\", \\\"{x:1100,y:791,t:1527614028239};\\\", \\\"{x:1102,y:791,t:1527614028374};\\\", \\\"{x:1114,y:788,t:1527614028390};\\\", \\\"{x:1127,y:784,t:1527614028406};\\\", \\\"{x:1140,y:781,t:1527614028423};\\\", \\\"{x:1153,y:778,t:1527614028440};\\\", \\\"{x:1162,y:775,t:1527614028456};\\\", \\\"{x:1166,y:773,t:1527614028473};\\\", \\\"{x:1169,y:773,t:1527614028490};\\\", \\\"{x:1165,y:773,t:1527614028614};\\\", \\\"{x:1151,y:773,t:1527614028623};\\\", \\\"{x:1118,y:773,t:1527614028640};\\\", \\\"{x:1070,y:773,t:1527614028657};\\\", \\\"{x:1017,y:773,t:1527614028673};\\\", \\\"{x:978,y:773,t:1527614028690};\\\", \\\"{x:956,y:773,t:1527614028706};\\\", \\\"{x:948,y:773,t:1527614028723};\\\", \\\"{x:948,y:772,t:1527614028821};\\\", \\\"{x:949,y:771,t:1527614028829};\\\", \\\"{x:952,y:770,t:1527614028840};\\\", \\\"{x:962,y:767,t:1527614028857};\\\", \\\"{x:974,y:765,t:1527614028872};\\\", \\\"{x:984,y:765,t:1527614028890};\\\", \\\"{x:1002,y:765,t:1527614028906};\\\", \\\"{x:1021,y:765,t:1527614028923};\\\", \\\"{x:1037,y:765,t:1527614028940};\\\", \\\"{x:1050,y:765,t:1527614028957};\\\", \\\"{x:1056,y:765,t:1527614028974};\\\", \\\"{x:1059,y:765,t:1527614028990};\\\", \\\"{x:1062,y:765,t:1527614029007};\\\", \\\"{x:1064,y:763,t:1527614029024};\\\", \\\"{x:1066,y:763,t:1527614029040};\\\", \\\"{x:1069,y:762,t:1527614029056};\\\", \\\"{x:1070,y:762,t:1527614029072};\\\", \\\"{x:1074,y:762,t:1527614029090};\\\", \\\"{x:1077,y:762,t:1527614029106};\\\", \\\"{x:1082,y:761,t:1527614029124};\\\", \\\"{x:1086,y:761,t:1527614029140};\\\", \\\"{x:1092,y:759,t:1527614029156};\\\", \\\"{x:1094,y:759,t:1527614029173};\\\", \\\"{x:1098,y:759,t:1527614029190};\\\", \\\"{x:1101,y:759,t:1527614029207};\\\", \\\"{x:1105,y:759,t:1527614029222};\\\", \\\"{x:1107,y:759,t:1527614029240};\\\", \\\"{x:1112,y:759,t:1527614029257};\\\", \\\"{x:1116,y:759,t:1527614029273};\\\", \\\"{x:1122,y:759,t:1527614029290};\\\", \\\"{x:1129,y:758,t:1527614029307};\\\", \\\"{x:1137,y:757,t:1527614029324};\\\", \\\"{x:1141,y:757,t:1527614029340};\\\", \\\"{x:1146,y:756,t:1527614029357};\\\", \\\"{x:1150,y:755,t:1527614029373};\\\", \\\"{x:1156,y:755,t:1527614029390};\\\", \\\"{x:1161,y:754,t:1527614029407};\\\", \\\"{x:1167,y:754,t:1527614029424};\\\", \\\"{x:1174,y:754,t:1527614029440};\\\", \\\"{x:1179,y:754,t:1527614029457};\\\", \\\"{x:1188,y:754,t:1527614029475};\\\", \\\"{x:1198,y:754,t:1527614029490};\\\", \\\"{x:1211,y:754,t:1527614029507};\\\", \\\"{x:1220,y:754,t:1527614029524};\\\", \\\"{x:1229,y:754,t:1527614029540};\\\", \\\"{x:1243,y:754,t:1527614029557};\\\", \\\"{x:1253,y:754,t:1527614029574};\\\", \\\"{x:1264,y:754,t:1527614029591};\\\", \\\"{x:1275,y:754,t:1527614029608};\\\", \\\"{x:1287,y:754,t:1527614029624};\\\", \\\"{x:1301,y:754,t:1527614029640};\\\", \\\"{x:1312,y:754,t:1527614029657};\\\", \\\"{x:1318,y:754,t:1527614029674};\\\", \\\"{x:1320,y:754,t:1527614029691};\\\", \\\"{x:1321,y:754,t:1527614029829};\\\", \\\"{x:1322,y:754,t:1527614029845};\\\", \\\"{x:1323,y:754,t:1527614029857};\\\", \\\"{x:1328,y:754,t:1527614029873};\\\", \\\"{x:1335,y:754,t:1527614029891};\\\", \\\"{x:1338,y:754,t:1527614029907};\\\", \\\"{x:1342,y:754,t:1527614029924};\\\", \\\"{x:1344,y:754,t:1527614029997};\\\", \\\"{x:1346,y:755,t:1527614030126};\\\", \\\"{x:1349,y:762,t:1527614030142};\\\", \\\"{x:1350,y:765,t:1527614030157};\\\", \\\"{x:1351,y:767,t:1527614030174};\\\", \\\"{x:1351,y:768,t:1527614030191};\\\", \\\"{x:1352,y:768,t:1527614030208};\\\", \\\"{x:1353,y:768,t:1527614030302};\\\", \\\"{x:1355,y:768,t:1527614030326};\\\", \\\"{x:1358,y:768,t:1527614030341};\\\", \\\"{x:1359,y:768,t:1527614030357};\\\", \\\"{x:1365,y:768,t:1527614030374};\\\", \\\"{x:1371,y:768,t:1527614030391};\\\", \\\"{x:1378,y:768,t:1527614030408};\\\", \\\"{x:1385,y:768,t:1527614030425};\\\", \\\"{x:1392,y:768,t:1527614030441};\\\", \\\"{x:1397,y:766,t:1527614030458};\\\", \\\"{x:1402,y:766,t:1527614030474};\\\", \\\"{x:1406,y:765,t:1527614030491};\\\", \\\"{x:1409,y:763,t:1527614030509};\\\", \\\"{x:1412,y:763,t:1527614030524};\\\", \\\"{x:1413,y:762,t:1527614030541};\\\", \\\"{x:1415,y:761,t:1527614030558};\\\", \\\"{x:1416,y:760,t:1527614030575};\\\", \\\"{x:1417,y:760,t:1527614030598};\\\", \\\"{x:1418,y:758,t:1527614030621};\\\", \\\"{x:1419,y:757,t:1527614030637};\\\", \\\"{x:1420,y:755,t:1527614030653};\\\", \\\"{x:1420,y:754,t:1527614030661};\\\", \\\"{x:1421,y:752,t:1527614030675};\\\", \\\"{x:1422,y:749,t:1527614030691};\\\", \\\"{x:1422,y:748,t:1527614030741};\\\", \\\"{x:1423,y:748,t:1527614030989};\\\", \\\"{x:1423,y:750,t:1527614030997};\\\", \\\"{x:1428,y:760,t:1527614031008};\\\", \\\"{x:1438,y:778,t:1527614031025};\\\", \\\"{x:1445,y:792,t:1527614031041};\\\", \\\"{x:1453,y:803,t:1527614031058};\\\", \\\"{x:1459,y:813,t:1527614031076};\\\", \\\"{x:1462,y:816,t:1527614031092};\\\", \\\"{x:1463,y:817,t:1527614031109};\\\", \\\"{x:1464,y:818,t:1527614031125};\\\", \\\"{x:1465,y:818,t:1527614031205};\\\", \\\"{x:1468,y:817,t:1527614031213};\\\", \\\"{x:1470,y:815,t:1527614031225};\\\", \\\"{x:1474,y:808,t:1527614031243};\\\", \\\"{x:1477,y:803,t:1527614031258};\\\", \\\"{x:1482,y:793,t:1527614031276};\\\", \\\"{x:1484,y:789,t:1527614031293};\\\", \\\"{x:1486,y:784,t:1527614031309};\\\", \\\"{x:1487,y:778,t:1527614031326};\\\", \\\"{x:1488,y:775,t:1527614031342};\\\", \\\"{x:1488,y:772,t:1527614031358};\\\", \\\"{x:1488,y:768,t:1527614031375};\\\", \\\"{x:1488,y:766,t:1527614031392};\\\", \\\"{x:1488,y:765,t:1527614031409};\\\", \\\"{x:1488,y:764,t:1527614031426};\\\", \\\"{x:1488,y:763,t:1527614031443};\\\", \\\"{x:1488,y:762,t:1527614031459};\\\", \\\"{x:1488,y:761,t:1527614031517};\\\", \\\"{x:1488,y:760,t:1527614031541};\\\", \\\"{x:1488,y:759,t:1527614031582};\\\", \\\"{x:1488,y:758,t:1527614031645};\\\", \\\"{x:1488,y:757,t:1527614031660};\\\", \\\"{x:1488,y:756,t:1527614031700};\\\", \\\"{x:1488,y:759,t:1527614031942};\\\", \\\"{x:1490,y:766,t:1527614031959};\\\", \\\"{x:1492,y:770,t:1527614031975};\\\", \\\"{x:1494,y:776,t:1527614031992};\\\", \\\"{x:1495,y:780,t:1527614032009};\\\", \\\"{x:1496,y:781,t:1527614032025};\\\", \\\"{x:1497,y:782,t:1527614032045};\\\", \\\"{x:1497,y:783,t:1527614032061};\\\", \\\"{x:1498,y:784,t:1527614032077};\\\", \\\"{x:1499,y:784,t:1527614032206};\\\", \\\"{x:1501,y:784,t:1527614032214};\\\", \\\"{x:1505,y:784,t:1527614032225};\\\", \\\"{x:1518,y:784,t:1527614032242};\\\", \\\"{x:1533,y:784,t:1527614032259};\\\", \\\"{x:1545,y:784,t:1527614032276};\\\", \\\"{x:1550,y:784,t:1527614032293};\\\", \\\"{x:1552,y:784,t:1527614032310};\\\", \\\"{x:1553,y:784,t:1527614032342};\\\", \\\"{x:1554,y:783,t:1527614032366};\\\", \\\"{x:1555,y:783,t:1527614032376};\\\", \\\"{x:1556,y:781,t:1527614032393};\\\", \\\"{x:1557,y:777,t:1527614032409};\\\", \\\"{x:1557,y:775,t:1527614032428};\\\", \\\"{x:1559,y:771,t:1527614032442};\\\", \\\"{x:1559,y:768,t:1527614032460};\\\", \\\"{x:1559,y:764,t:1527614032476};\\\", \\\"{x:1559,y:763,t:1527614032492};\\\", \\\"{x:1559,y:760,t:1527614032510};\\\", \\\"{x:1559,y:759,t:1527614032526};\\\", \\\"{x:1558,y:758,t:1527614033717};\\\", \\\"{x:1536,y:762,t:1527614033726};\\\", \\\"{x:1489,y:773,t:1527614033744};\\\", \\\"{x:1447,y:779,t:1527614033760};\\\", \\\"{x:1431,y:780,t:1527614033777};\\\", \\\"{x:1426,y:780,t:1527614033793};\\\", \\\"{x:1426,y:779,t:1527614033870};\\\", \\\"{x:1426,y:778,t:1527614033877};\\\", \\\"{x:1427,y:776,t:1527614033893};\\\", \\\"{x:1428,y:775,t:1527614033911};\\\", \\\"{x:1431,y:771,t:1527614033927};\\\", \\\"{x:1434,y:768,t:1527614033944};\\\", \\\"{x:1437,y:766,t:1527614033960};\\\", \\\"{x:1442,y:763,t:1527614033978};\\\", \\\"{x:1448,y:760,t:1527614033994};\\\", \\\"{x:1454,y:756,t:1527614034011};\\\", \\\"{x:1458,y:755,t:1527614034027};\\\", \\\"{x:1460,y:754,t:1527614034044};\\\", \\\"{x:1465,y:752,t:1527614034061};\\\", \\\"{x:1467,y:752,t:1527614034078};\\\", \\\"{x:1468,y:752,t:1527614034094};\\\", \\\"{x:1469,y:752,t:1527614034117};\\\", \\\"{x:1470,y:752,t:1527614034127};\\\", \\\"{x:1473,y:752,t:1527614034143};\\\", \\\"{x:1477,y:752,t:1527614034161};\\\", \\\"{x:1481,y:753,t:1527614034178};\\\", \\\"{x:1485,y:754,t:1527614034193};\\\", \\\"{x:1487,y:754,t:1527614034221};\\\", \\\"{x:1489,y:754,t:1527614034253};\\\", \\\"{x:1490,y:756,t:1527614034261};\\\", \\\"{x:1493,y:758,t:1527614034278};\\\", \\\"{x:1497,y:762,t:1527614034294};\\\", \\\"{x:1501,y:768,t:1527614034310};\\\", \\\"{x:1505,y:774,t:1527614034328};\\\", \\\"{x:1508,y:780,t:1527614034345};\\\", \\\"{x:1512,y:785,t:1527614034360};\\\", \\\"{x:1512,y:787,t:1527614034378};\\\", \\\"{x:1513,y:788,t:1527614034502};\\\", \\\"{x:1515,y:788,t:1527614034511};\\\", \\\"{x:1520,y:783,t:1527614034527};\\\", \\\"{x:1523,y:778,t:1527614034545};\\\", \\\"{x:1527,y:774,t:1527614034560};\\\", \\\"{x:1528,y:771,t:1527614034577};\\\", \\\"{x:1530,y:770,t:1527614034595};\\\", \\\"{x:1531,y:768,t:1527614034610};\\\", \\\"{x:1531,y:766,t:1527614034628};\\\", \\\"{x:1533,y:764,t:1527614034644};\\\", \\\"{x:1533,y:762,t:1527614034660};\\\", \\\"{x:1535,y:758,t:1527614034678};\\\", \\\"{x:1537,y:756,t:1527614034694};\\\", \\\"{x:1537,y:755,t:1527614034710};\\\", \\\"{x:1537,y:754,t:1527614034727};\\\", \\\"{x:1537,y:753,t:1527614034765};\\\", \\\"{x:1537,y:752,t:1527614034778};\\\", \\\"{x:1538,y:752,t:1527614034795};\\\", \\\"{x:1539,y:751,t:1527614034810};\\\", \\\"{x:1540,y:750,t:1527614034828};\\\", \\\"{x:1540,y:749,t:1527614034844};\\\", \\\"{x:1541,y:748,t:1527614034862};\\\", \\\"{x:1542,y:746,t:1527614034877};\\\", \\\"{x:1543,y:746,t:1527614035036};\\\", \\\"{x:1545,y:748,t:1527614035261};\\\", \\\"{x:1549,y:767,t:1527614035277};\\\", \\\"{x:1553,y:775,t:1527614035294};\\\", \\\"{x:1554,y:780,t:1527614035311};\\\", \\\"{x:1556,y:784,t:1527614035328};\\\", \\\"{x:1557,y:788,t:1527614035344};\\\", \\\"{x:1558,y:788,t:1527614035429};\\\", \\\"{x:1560,y:788,t:1527614035444};\\\", \\\"{x:1593,y:779,t:1527614035460};\\\", \\\"{x:1619,y:768,t:1527614035477};\\\", \\\"{x:1633,y:762,t:1527614035494};\\\", \\\"{x:1637,y:761,t:1527614035511};\\\", \\\"{x:1638,y:759,t:1527614035527};\\\", \\\"{x:1641,y:757,t:1527614035544};\\\", \\\"{x:1644,y:756,t:1527614035561};\\\", \\\"{x:1648,y:753,t:1527614035578};\\\", \\\"{x:1651,y:751,t:1527614035594};\\\", \\\"{x:1652,y:750,t:1527614035629};\\\", \\\"{x:1649,y:750,t:1527614036118};\\\", \\\"{x:1640,y:756,t:1527614036129};\\\", \\\"{x:1630,y:766,t:1527614036145};\\\", \\\"{x:1619,y:775,t:1527614036161};\\\", \\\"{x:1612,y:780,t:1527614036178};\\\", \\\"{x:1610,y:782,t:1527614036194};\\\", \\\"{x:1608,y:784,t:1527614036211};\\\", \\\"{x:1604,y:790,t:1527614036227};\\\", \\\"{x:1596,y:799,t:1527614036244};\\\", \\\"{x:1590,y:804,t:1527614036260};\\\", \\\"{x:1581,y:809,t:1527614036277};\\\", \\\"{x:1570,y:816,t:1527614036295};\\\", \\\"{x:1561,y:823,t:1527614036311};\\\", \\\"{x:1547,y:829,t:1527614036328};\\\", \\\"{x:1532,y:836,t:1527614036345};\\\", \\\"{x:1519,y:842,t:1527614036363};\\\", \\\"{x:1507,y:848,t:1527614036378};\\\", \\\"{x:1493,y:852,t:1527614036395};\\\", \\\"{x:1481,y:853,t:1527614036412};\\\", \\\"{x:1463,y:857,t:1527614036428};\\\", \\\"{x:1433,y:860,t:1527614036445};\\\", \\\"{x:1403,y:862,t:1527614036462};\\\", \\\"{x:1375,y:862,t:1527614036478};\\\", \\\"{x:1352,y:862,t:1527614036495};\\\", \\\"{x:1338,y:862,t:1527614036513};\\\", \\\"{x:1327,y:862,t:1527614036528};\\\", \\\"{x:1320,y:862,t:1527614036545};\\\", \\\"{x:1312,y:862,t:1527614036562};\\\", \\\"{x:1303,y:862,t:1527614036579};\\\", \\\"{x:1288,y:862,t:1527614036596};\\\", \\\"{x:1267,y:862,t:1527614036612};\\\", \\\"{x:1251,y:862,t:1527614036628};\\\", \\\"{x:1231,y:861,t:1527614036645};\\\", \\\"{x:1224,y:861,t:1527614036662};\\\", \\\"{x:1220,y:859,t:1527614036679};\\\", \\\"{x:1219,y:858,t:1527614036933};\\\", \\\"{x:1219,y:855,t:1527614036946};\\\", \\\"{x:1219,y:848,t:1527614036962};\\\", \\\"{x:1219,y:842,t:1527614036979};\\\", \\\"{x:1219,y:839,t:1527614036995};\\\", \\\"{x:1219,y:836,t:1527614037013};\\\", \\\"{x:1219,y:834,t:1527614037029};\\\", \\\"{x:1219,y:832,t:1527614037062};\\\", \\\"{x:1221,y:832,t:1527614037750};\\\", \\\"{x:1226,y:836,t:1527614037762};\\\", \\\"{x:1235,y:848,t:1527614037779};\\\", \\\"{x:1250,y:861,t:1527614037797};\\\", \\\"{x:1261,y:871,t:1527614037813};\\\", \\\"{x:1268,y:876,t:1527614037829};\\\", \\\"{x:1269,y:876,t:1527614037845};\\\", \\\"{x:1270,y:876,t:1527614037867};\\\", \\\"{x:1271,y:876,t:1527614037900};\\\", \\\"{x:1273,y:876,t:1527614037913};\\\", \\\"{x:1282,y:868,t:1527614037929};\\\", \\\"{x:1294,y:859,t:1527614037945};\\\", \\\"{x:1304,y:849,t:1527614037963};\\\", \\\"{x:1308,y:840,t:1527614037978};\\\", \\\"{x:1312,y:831,t:1527614037995};\\\", \\\"{x:1312,y:829,t:1527614038012};\\\", \\\"{x:1312,y:828,t:1527614038029};\\\", \\\"{x:1314,y:833,t:1527614038174};\\\", \\\"{x:1316,y:840,t:1527614038181};\\\", \\\"{x:1317,y:845,t:1527614038196};\\\", \\\"{x:1322,y:855,t:1527614038212};\\\", \\\"{x:1326,y:858,t:1527614038229};\\\", \\\"{x:1327,y:859,t:1527614038246};\\\", \\\"{x:1328,y:859,t:1527614038263};\\\", \\\"{x:1330,y:859,t:1527614038279};\\\", \\\"{x:1340,y:859,t:1527614038296};\\\", \\\"{x:1350,y:853,t:1527614038314};\\\", \\\"{x:1361,y:846,t:1527614038329};\\\", \\\"{x:1375,y:837,t:1527614038346};\\\", \\\"{x:1387,y:829,t:1527614038364};\\\", \\\"{x:1393,y:826,t:1527614038380};\\\", \\\"{x:1395,y:824,t:1527614038396};\\\", \\\"{x:1393,y:822,t:1527614038437};\\\", \\\"{x:1388,y:819,t:1527614038446};\\\", \\\"{x:1373,y:813,t:1527614038463};\\\", \\\"{x:1339,y:807,t:1527614038480};\\\", \\\"{x:1268,y:793,t:1527614038496};\\\", \\\"{x:1213,y:780,t:1527614038514};\\\", \\\"{x:1168,y:773,t:1527614038531};\\\", \\\"{x:1143,y:768,t:1527614038546};\\\", \\\"{x:1136,y:765,t:1527614038564};\\\", \\\"{x:1135,y:765,t:1527614038662};\\\", \\\"{x:1135,y:764,t:1527614038669};\\\", \\\"{x:1135,y:763,t:1527614038680};\\\", \\\"{x:1135,y:762,t:1527614038696};\\\", \\\"{x:1135,y:761,t:1527614038714};\\\", \\\"{x:1135,y:759,t:1527614038731};\\\", \\\"{x:1136,y:759,t:1527614038806};\\\", \\\"{x:1138,y:758,t:1527614038813};\\\", \\\"{x:1140,y:758,t:1527614038830};\\\", \\\"{x:1143,y:758,t:1527614038846};\\\", \\\"{x:1146,y:758,t:1527614038863};\\\", \\\"{x:1150,y:757,t:1527614038881};\\\", \\\"{x:1154,y:755,t:1527614038896};\\\", \\\"{x:1158,y:753,t:1527614038914};\\\", \\\"{x:1164,y:751,t:1527614038930};\\\", \\\"{x:1169,y:747,t:1527614038946};\\\", \\\"{x:1173,y:745,t:1527614038963};\\\", \\\"{x:1175,y:744,t:1527614038980};\\\", \\\"{x:1176,y:743,t:1527614038996};\\\", \\\"{x:1180,y:743,t:1527614039078};\\\", \\\"{x:1183,y:748,t:1527614039085};\\\", \\\"{x:1186,y:753,t:1527614039098};\\\", \\\"{x:1189,y:756,t:1527614039113};\\\", \\\"{x:1190,y:758,t:1527614039130};\\\", \\\"{x:1191,y:758,t:1527614039147};\\\", \\\"{x:1195,y:758,t:1527614039211};\\\", \\\"{x:1202,y:758,t:1527614039220};\\\", \\\"{x:1210,y:758,t:1527614039230};\\\", \\\"{x:1222,y:758,t:1527614039247};\\\", \\\"{x:1232,y:758,t:1527614039263};\\\", \\\"{x:1240,y:755,t:1527614039279};\\\", \\\"{x:1246,y:751,t:1527614039296};\\\", \\\"{x:1249,y:748,t:1527614039312};\\\", \\\"{x:1251,y:746,t:1527614039329};\\\", \\\"{x:1252,y:746,t:1527614039347};\\\", \\\"{x:1253,y:745,t:1527614039363};\\\", \\\"{x:1254,y:744,t:1527614039380};\\\", \\\"{x:1256,y:744,t:1527614039484};\\\", \\\"{x:1262,y:746,t:1527614039496};\\\", \\\"{x:1269,y:753,t:1527614039513};\\\", \\\"{x:1278,y:761,t:1527614039530};\\\", \\\"{x:1288,y:767,t:1527614039546};\\\", \\\"{x:1301,y:772,t:1527614039563};\\\", \\\"{x:1306,y:774,t:1527614039580};\\\", \\\"{x:1311,y:774,t:1527614039597};\\\", \\\"{x:1312,y:774,t:1527614039614};\\\", \\\"{x:1315,y:773,t:1527614039630};\\\", \\\"{x:1318,y:771,t:1527614039647};\\\", \\\"{x:1323,y:765,t:1527614039664};\\\", \\\"{x:1329,y:760,t:1527614039679};\\\", \\\"{x:1331,y:757,t:1527614039697};\\\", \\\"{x:1333,y:755,t:1527614039715};\\\", \\\"{x:1334,y:753,t:1527614039731};\\\", \\\"{x:1334,y:752,t:1527614039747};\\\", \\\"{x:1335,y:752,t:1527614039765};\\\", \\\"{x:1337,y:752,t:1527614040045};\\\", \\\"{x:1338,y:755,t:1527614040053};\\\", \\\"{x:1340,y:760,t:1527614040064};\\\", \\\"{x:1343,y:766,t:1527614040082};\\\", \\\"{x:1347,y:771,t:1527614040099};\\\", \\\"{x:1350,y:773,t:1527614040115};\\\", \\\"{x:1350,y:774,t:1527614040132};\\\", \\\"{x:1351,y:774,t:1527614040173};\\\", \\\"{x:1354,y:774,t:1527614040181};\\\", \\\"{x:1359,y:773,t:1527614040197};\\\", \\\"{x:1365,y:770,t:1527614040215};\\\", \\\"{x:1371,y:765,t:1527614040231};\\\", \\\"{x:1375,y:762,t:1527614040247};\\\", \\\"{x:1377,y:760,t:1527614040265};\\\", \\\"{x:1378,y:759,t:1527614040282};\\\", \\\"{x:1380,y:757,t:1527614040297};\\\", \\\"{x:1380,y:756,t:1527614040315};\\\", \\\"{x:1382,y:754,t:1527614040331};\\\", \\\"{x:1389,y:755,t:1527614040886};\\\", \\\"{x:1407,y:768,t:1527614040899};\\\", \\\"{x:1450,y:802,t:1527614040915};\\\", \\\"{x:1483,y:816,t:1527614040932};\\\", \\\"{x:1503,y:824,t:1527614040950};\\\", \\\"{x:1506,y:825,t:1527614040965};\\\", \\\"{x:1503,y:825,t:1527614041332};\\\", \\\"{x:1475,y:825,t:1527614041348};\\\", \\\"{x:1452,y:825,t:1527614041365};\\\", \\\"{x:1439,y:824,t:1527614041381};\\\", \\\"{x:1438,y:824,t:1527614041398};\\\", \\\"{x:1435,y:830,t:1527614042228};\\\", \\\"{x:1429,y:842,t:1527614042236};\\\", \\\"{x:1425,y:851,t:1527614042249};\\\", \\\"{x:1411,y:873,t:1527614042265};\\\", \\\"{x:1405,y:886,t:1527614042282};\\\", \\\"{x:1402,y:893,t:1527614042299};\\\", \\\"{x:1400,y:897,t:1527614042315};\\\", \\\"{x:1398,y:899,t:1527614042332};\\\", \\\"{x:1397,y:899,t:1527614042445};\\\", \\\"{x:1394,y:899,t:1527614042452};\\\", \\\"{x:1390,y:899,t:1527614042465};\\\", \\\"{x:1383,y:899,t:1527614042482};\\\", \\\"{x:1380,y:899,t:1527614042499};\\\", \\\"{x:1377,y:899,t:1527614042515};\\\", \\\"{x:1372,y:899,t:1527614042532};\\\", \\\"{x:1369,y:899,t:1527614042549};\\\", \\\"{x:1368,y:900,t:1527614042566};\\\", \\\"{x:1367,y:900,t:1527614042582};\\\", \\\"{x:1366,y:900,t:1527614042708};\\\", \\\"{x:1365,y:900,t:1527614042716};\\\", \\\"{x:1365,y:901,t:1527614042940};\\\", \\\"{x:1365,y:902,t:1527614042949};\\\", \\\"{x:1366,y:904,t:1527614042966};\\\", \\\"{x:1368,y:906,t:1527614042982};\\\", \\\"{x:1370,y:908,t:1527614042999};\\\", \\\"{x:1372,y:909,t:1527614043016};\\\", \\\"{x:1374,y:910,t:1527614043032};\\\", \\\"{x:1381,y:914,t:1527614043049};\\\", \\\"{x:1388,y:915,t:1527614043066};\\\", \\\"{x:1391,y:917,t:1527614043082};\\\", \\\"{x:1396,y:918,t:1527614043100};\\\", \\\"{x:1400,y:918,t:1527614043116};\\\", \\\"{x:1404,y:918,t:1527614043132};\\\", \\\"{x:1408,y:918,t:1527614043149};\\\", \\\"{x:1411,y:918,t:1527614043167};\\\", \\\"{x:1415,y:918,t:1527614043183};\\\", \\\"{x:1418,y:918,t:1527614043199};\\\", \\\"{x:1422,y:918,t:1527614043216};\\\", \\\"{x:1424,y:918,t:1527614043233};\\\", \\\"{x:1428,y:918,t:1527614043249};\\\", \\\"{x:1430,y:917,t:1527614043266};\\\", \\\"{x:1432,y:915,t:1527614043283};\\\", \\\"{x:1434,y:913,t:1527614043299};\\\", \\\"{x:1438,y:907,t:1527614043316};\\\", \\\"{x:1440,y:905,t:1527614043333};\\\", \\\"{x:1440,y:904,t:1527614043349};\\\", \\\"{x:1441,y:903,t:1527614043366};\\\", \\\"{x:1442,y:902,t:1527614043388};\\\", \\\"{x:1442,y:901,t:1527614043420};\\\", \\\"{x:1442,y:900,t:1527614043508};\\\", \\\"{x:1442,y:899,t:1527614043765};\\\", \\\"{x:1441,y:896,t:1527614047316};\\\", \\\"{x:1438,y:896,t:1527614047324};\\\", \\\"{x:1434,y:894,t:1527614047335};\\\", \\\"{x:1423,y:891,t:1527614047352};\\\", \\\"{x:1418,y:888,t:1527614047369};\\\", \\\"{x:1415,y:888,t:1527614047386};\\\", \\\"{x:1412,y:889,t:1527614047402};\\\", \\\"{x:1409,y:891,t:1527614047419};\\\", \\\"{x:1407,y:892,t:1527614047435};\\\", \\\"{x:1405,y:892,t:1527614047836};\\\", \\\"{x:1402,y:892,t:1527614047852};\\\", \\\"{x:1399,y:890,t:1527614047870};\\\", \\\"{x:1395,y:888,t:1527614047886};\\\", \\\"{x:1390,y:887,t:1527614047902};\\\", \\\"{x:1390,y:886,t:1527614047948};\\\", \\\"{x:1390,y:885,t:1527614047964};\\\", \\\"{x:1391,y:882,t:1527614047972};\\\", \\\"{x:1393,y:881,t:1527614047986};\\\", \\\"{x:1393,y:880,t:1527614048002};\\\", \\\"{x:1395,y:880,t:1527614048019};\\\", \\\"{x:1396,y:879,t:1527614048036};\\\", \\\"{x:1398,y:879,t:1527614048084};\\\", \\\"{x:1399,y:879,t:1527614048140};\\\", \\\"{x:1400,y:879,t:1527614048152};\\\", \\\"{x:1404,y:879,t:1527614048170};\\\", \\\"{x:1407,y:879,t:1527614048186};\\\", \\\"{x:1411,y:879,t:1527614048203};\\\", \\\"{x:1416,y:878,t:1527614048219};\\\", \\\"{x:1423,y:875,t:1527614048236};\\\", \\\"{x:1427,y:874,t:1527614048253};\\\", \\\"{x:1433,y:873,t:1527614048269};\\\", \\\"{x:1442,y:870,t:1527614048286};\\\", \\\"{x:1455,y:866,t:1527614048304};\\\", \\\"{x:1468,y:865,t:1527614048320};\\\", \\\"{x:1485,y:863,t:1527614048337};\\\", \\\"{x:1499,y:860,t:1527614048353};\\\", \\\"{x:1509,y:858,t:1527614048369};\\\", \\\"{x:1512,y:858,t:1527614048386};\\\", \\\"{x:1513,y:857,t:1527614048404};\\\", \\\"{x:1514,y:855,t:1527614048428};\\\", \\\"{x:1516,y:854,t:1527614048436};\\\", \\\"{x:1522,y:851,t:1527614048453};\\\", \\\"{x:1527,y:847,t:1527614048469};\\\", \\\"{x:1530,y:845,t:1527614048486};\\\", \\\"{x:1531,y:845,t:1527614048503};\\\", \\\"{x:1531,y:844,t:1527614048748};\\\", \\\"{x:1529,y:844,t:1527614048756};\\\", \\\"{x:1527,y:843,t:1527614048770};\\\", \\\"{x:1523,y:842,t:1527614048786};\\\", \\\"{x:1516,y:841,t:1527614048803};\\\", \\\"{x:1513,y:840,t:1527614048820};\\\", \\\"{x:1512,y:839,t:1527614048837};\\\", \\\"{x:1511,y:838,t:1527614048859};\\\", \\\"{x:1511,y:837,t:1527614048871};\\\", \\\"{x:1509,y:835,t:1527614048886};\\\", \\\"{x:1507,y:833,t:1527614048903};\\\", \\\"{x:1506,y:832,t:1527614048920};\\\", \\\"{x:1504,y:830,t:1527614048936};\\\", \\\"{x:1503,y:830,t:1527614048953};\\\", \\\"{x:1502,y:829,t:1527614048970};\\\", \\\"{x:1500,y:829,t:1527614048987};\\\", \\\"{x:1497,y:829,t:1527614049012};\\\", \\\"{x:1496,y:831,t:1527614049020};\\\", \\\"{x:1495,y:837,t:1527614049036};\\\", \\\"{x:1495,y:844,t:1527614049053};\\\", \\\"{x:1495,y:848,t:1527614049070};\\\", \\\"{x:1495,y:851,t:1527614049086};\\\", \\\"{x:1495,y:853,t:1527614049103};\\\", \\\"{x:1498,y:856,t:1527614049120};\\\", \\\"{x:1501,y:859,t:1527614049136};\\\", \\\"{x:1508,y:860,t:1527614049153};\\\", \\\"{x:1512,y:860,t:1527614049170};\\\", \\\"{x:1514,y:858,t:1527614049212};\\\", \\\"{x:1518,y:855,t:1527614049236};\\\", \\\"{x:1519,y:853,t:1527614049276};\\\", \\\"{x:1520,y:851,t:1527614049286};\\\", \\\"{x:1522,y:849,t:1527614049303};\\\", \\\"{x:1522,y:848,t:1527614049320};\\\", \\\"{x:1523,y:845,t:1527614049336};\\\", \\\"{x:1525,y:843,t:1527614049353};\\\", \\\"{x:1525,y:842,t:1527614049388};\\\", \\\"{x:1526,y:842,t:1527614049403};\\\", \\\"{x:1527,y:841,t:1527614049420};\\\", \\\"{x:1528,y:839,t:1527614049437};\\\", \\\"{x:1528,y:838,t:1527614049453};\\\", \\\"{x:1528,y:836,t:1527614049470};\\\", \\\"{x:1531,y:834,t:1527614049487};\\\", \\\"{x:1531,y:833,t:1527614049508};\\\", \\\"{x:1532,y:832,t:1527614049523};\\\", \\\"{x:1532,y:831,t:1527614049539};\\\", \\\"{x:1533,y:830,t:1527614049556};\\\", \\\"{x:1534,y:829,t:1527614049852};\\\", \\\"{x:1535,y:828,t:1527614049859};\\\", \\\"{x:1537,y:825,t:1527614049870};\\\", \\\"{x:1538,y:824,t:1527614050149};\\\", \\\"{x:1539,y:824,t:1527614050156};\\\", \\\"{x:1540,y:824,t:1527614050172};\\\", \\\"{x:1541,y:824,t:1527614050188};\\\", \\\"{x:1543,y:826,t:1527614050204};\\\", \\\"{x:1545,y:829,t:1527614050220};\\\", \\\"{x:1549,y:834,t:1527614050237};\\\", \\\"{x:1553,y:839,t:1527614050255};\\\", \\\"{x:1559,y:846,t:1527614050270};\\\", \\\"{x:1561,y:850,t:1527614050287};\\\", \\\"{x:1566,y:854,t:1527614050304};\\\", \\\"{x:1570,y:855,t:1527614050320};\\\", \\\"{x:1571,y:857,t:1527614050337};\\\", \\\"{x:1572,y:857,t:1527614050355};\\\", \\\"{x:1574,y:857,t:1527614050404};\\\", \\\"{x:1575,y:857,t:1527614050492};\\\", \\\"{x:1576,y:857,t:1527614050508};\\\", \\\"{x:1577,y:857,t:1527614050522};\\\", \\\"{x:1578,y:857,t:1527614050540};\\\", \\\"{x:1579,y:857,t:1527614050556};\\\", \\\"{x:1580,y:856,t:1527614050571};\\\", \\\"{x:1582,y:855,t:1527614050620};\\\", \\\"{x:1583,y:854,t:1527614050651};\\\", \\\"{x:1584,y:854,t:1527614050676};\\\", \\\"{x:1585,y:854,t:1527614050687};\\\", \\\"{x:1586,y:854,t:1527614050704};\\\", \\\"{x:1587,y:853,t:1527614050731};\\\", \\\"{x:1589,y:852,t:1527614050772};\\\", \\\"{x:1590,y:852,t:1527614050788};\\\", \\\"{x:1591,y:851,t:1527614050820};\\\", \\\"{x:1592,y:851,t:1527614050836};\\\", \\\"{x:1594,y:850,t:1527614050860};\\\", \\\"{x:1596,y:850,t:1527614050871};\\\", \\\"{x:1599,y:848,t:1527614050889};\\\", \\\"{x:1603,y:847,t:1527614050904};\\\", \\\"{x:1608,y:846,t:1527614050921};\\\", \\\"{x:1610,y:846,t:1527614050938};\\\", \\\"{x:1612,y:845,t:1527614050964};\\\", \\\"{x:1613,y:844,t:1527614051076};\\\", \\\"{x:1614,y:843,t:1527614051148};\\\", \\\"{x:1615,y:842,t:1527614051196};\\\", \\\"{x:1615,y:841,t:1527614051252};\\\", \\\"{x:1615,y:838,t:1527614051420};\\\", \\\"{x:1615,y:837,t:1527614051427};\\\", \\\"{x:1615,y:836,t:1527614051438};\\\", \\\"{x:1615,y:835,t:1527614051455};\\\", \\\"{x:1615,y:834,t:1527614051472};\\\", \\\"{x:1615,y:833,t:1527614051500};\\\", \\\"{x:1615,y:830,t:1527614051636};\\\", \\\"{x:1613,y:829,t:1527614051644};\\\", \\\"{x:1613,y:827,t:1527614051655};\\\", \\\"{x:1610,y:824,t:1527614051671};\\\", \\\"{x:1608,y:821,t:1527614051689};\\\", \\\"{x:1607,y:820,t:1527614051705};\\\", \\\"{x:1607,y:819,t:1527614051721};\\\", \\\"{x:1606,y:819,t:1527614051748};\\\", \\\"{x:1606,y:818,t:1527614052630};\\\", \\\"{x:1603,y:818,t:1527614052640};\\\", \\\"{x:1601,y:818,t:1527614052656};\\\", \\\"{x:1600,y:818,t:1527614052673};\\\", \\\"{x:1599,y:818,t:1527614052717};\\\", \\\"{x:1597,y:818,t:1527614052725};\\\", \\\"{x:1590,y:818,t:1527614052740};\\\", \\\"{x:1508,y:833,t:1527614052756};\\\", \\\"{x:1289,y:835,t:1527614052773};\\\", \\\"{x:1120,y:835,t:1527614052789};\\\", \\\"{x:954,y:832,t:1527614052805};\\\", \\\"{x:789,y:816,t:1527614052822};\\\", \\\"{x:600,y:805,t:1527614052840};\\\", \\\"{x:387,y:773,t:1527614052855};\\\", \\\"{x:165,y:738,t:1527614052873};\\\", \\\"{x:0,y:708,t:1527614052889};\\\", \\\"{x:0,y:686,t:1527614052906};\\\", \\\"{x:0,y:654,t:1527614052923};\\\", \\\"{x:0,y:623,t:1527614052939};\\\", \\\"{x:0,y:607,t:1527614052955};\\\", \\\"{x:0,y:592,t:1527614052972};\\\", \\\"{x:0,y:586,t:1527614052989};\\\", \\\"{x:0,y:578,t:1527614053006};\\\", \\\"{x:0,y:571,t:1527614053023};\\\", \\\"{x:0,y:568,t:1527614053039};\\\", \\\"{x:0,y:563,t:1527614053056};\\\", \\\"{x:0,y:559,t:1527614053073};\\\", \\\"{x:0,y:550,t:1527614053089};\\\", \\\"{x:0,y:537,t:1527614053107};\\\", \\\"{x:5,y:526,t:1527614053122};\\\", \\\"{x:9,y:520,t:1527614053140};\\\", \\\"{x:13,y:519,t:1527614053156};\\\", \\\"{x:18,y:518,t:1527614053172};\\\", \\\"{x:45,y:520,t:1527614053189};\\\", \\\"{x:145,y:534,t:1527614053207};\\\", \\\"{x:281,y:536,t:1527614053223};\\\", \\\"{x:395,y:538,t:1527614053239};\\\", \\\"{x:486,y:538,t:1527614053260};\\\", \\\"{x:584,y:538,t:1527614053276};\\\", \\\"{x:623,y:538,t:1527614053294};\\\", \\\"{x:638,y:538,t:1527614053309};\\\", \\\"{x:639,y:538,t:1527614053326};\\\", \\\"{x:639,y:539,t:1527614053645};\\\", \\\"{x:637,y:543,t:1527614053660};\\\", \\\"{x:617,y:558,t:1527614053678};\\\", \\\"{x:606,y:564,t:1527614053694};\\\", \\\"{x:602,y:567,t:1527614053710};\\\", \\\"{x:602,y:568,t:1527614053727};\\\", \\\"{x:602,y:576,t:1527614054348};\\\", \\\"{x:598,y:585,t:1527614054361};\\\", \\\"{x:594,y:597,t:1527614054377};\\\", \\\"{x:592,y:607,t:1527614054394};\\\", \\\"{x:589,y:616,t:1527614054410};\\\", \\\"{x:589,y:619,t:1527614054427};\\\", \\\"{x:588,y:620,t:1527614054443};\\\", \\\"{x:588,y:621,t:1527614054460};\\\", \\\"{x:588,y:622,t:1527614054478};\\\", \\\"{x:586,y:624,t:1527614054493};\\\", \\\"{x:585,y:627,t:1527614054511};\\\", \\\"{x:580,y:635,t:1527614054528};\\\", \\\"{x:574,y:645,t:1527614054544};\\\", \\\"{x:567,y:654,t:1527614054560};\\\", \\\"{x:561,y:664,t:1527614054577};\\\", \\\"{x:557,y:671,t:1527614054593};\\\", \\\"{x:553,y:677,t:1527614054610};\\\", \\\"{x:551,y:683,t:1527614054628};\\\", \\\"{x:545,y:691,t:1527614054644};\\\", \\\"{x:541,y:699,t:1527614054660};\\\", \\\"{x:540,y:703,t:1527614054678};\\\", \\\"{x:540,y:704,t:1527614054693};\\\", \\\"{x:540,y:705,t:1527614054821};\\\", \\\"{x:537,y:710,t:1527614054828};\\\", \\\"{x:534,y:713,t:1527614054844};\\\", \\\"{x:521,y:735,t:1527614054860};\\\", \\\"{x:516,y:741,t:1527614054878};\\\", \\\"{x:516,y:742,t:1527614054894};\\\" ] }, { \\\"rt\\\": 68877, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 726256, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-8-J -X -M -O -O -03 PM-F -C -X -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:730,t:1527614057036};\\\", \\\"{x:551,y:716,t:1527614057045};\\\", \\\"{x:587,y:695,t:1527614057060};\\\", \\\"{x:636,y:676,t:1527614057079};\\\", \\\"{x:666,y:657,t:1527614057095};\\\", \\\"{x:690,y:647,t:1527614057112};\\\", \\\"{x:711,y:641,t:1527614057129};\\\", \\\"{x:728,y:637,t:1527614057146};\\\", \\\"{x:730,y:637,t:1527614057162};\\\", \\\"{x:730,y:636,t:1527614057180};\\\", \\\"{x:732,y:635,t:1527614057204};\\\", \\\"{x:735,y:633,t:1527614057212};\\\", \\\"{x:746,y:626,t:1527614057231};\\\", \\\"{x:758,y:620,t:1527614057246};\\\", \\\"{x:767,y:615,t:1527614057262};\\\", \\\"{x:783,y:610,t:1527614057279};\\\", \\\"{x:800,y:604,t:1527614057296};\\\", \\\"{x:821,y:597,t:1527614057313};\\\", \\\"{x:855,y:573,t:1527614057330};\\\", \\\"{x:884,y:552,t:1527614057348};\\\", \\\"{x:915,y:536,t:1527614057362};\\\", \\\"{x:926,y:534,t:1527614057380};\\\", \\\"{x:929,y:533,t:1527614057397};\\\", \\\"{x:932,y:533,t:1527614057436};\\\", \\\"{x:935,y:533,t:1527614057447};\\\", \\\"{x:961,y:537,t:1527614057464};\\\", \\\"{x:1014,y:551,t:1527614057480};\\\", \\\"{x:1066,y:564,t:1527614057497};\\\", \\\"{x:1102,y:573,t:1527614057512};\\\", \\\"{x:1125,y:581,t:1527614057530};\\\", \\\"{x:1137,y:587,t:1527614057547};\\\", \\\"{x:1148,y:591,t:1527614057563};\\\", \\\"{x:1159,y:597,t:1527614057580};\\\", \\\"{x:1181,y:611,t:1527614057596};\\\", \\\"{x:1203,y:626,t:1527614057613};\\\", \\\"{x:1225,y:640,t:1527614057630};\\\", \\\"{x:1250,y:651,t:1527614057647};\\\", \\\"{x:1270,y:662,t:1527614057663};\\\", \\\"{x:1286,y:672,t:1527614057680};\\\", \\\"{x:1297,y:678,t:1527614057697};\\\", \\\"{x:1305,y:681,t:1527614057714};\\\", \\\"{x:1306,y:682,t:1527614057917};\\\", \\\"{x:1306,y:683,t:1527614058029};\\\", \\\"{x:1307,y:683,t:1527614058398};\\\", \\\"{x:1307,y:684,t:1527614058485};\\\", \\\"{x:1306,y:684,t:1527614059841};\\\", \\\"{x:1300,y:688,t:1527614059853};\\\", \\\"{x:1283,y:690,t:1527614059869};\\\", \\\"{x:1259,y:693,t:1527614059886};\\\", \\\"{x:1226,y:694,t:1527614059903};\\\", \\\"{x:1173,y:694,t:1527614059919};\\\", \\\"{x:1068,y:694,t:1527614059937};\\\", \\\"{x:990,y:694,t:1527614059953};\\\", \\\"{x:887,y:694,t:1527614059970};\\\", \\\"{x:782,y:694,t:1527614059986};\\\", \\\"{x:683,y:687,t:1527614060003};\\\", \\\"{x:597,y:672,t:1527614060019};\\\", \\\"{x:535,y:662,t:1527614060036};\\\", \\\"{x:499,y:656,t:1527614060054};\\\", \\\"{x:481,y:651,t:1527614060069};\\\", \\\"{x:473,y:651,t:1527614060086};\\\", \\\"{x:470,y:651,t:1527614060101};\\\", \\\"{x:469,y:651,t:1527614060120};\\\", \\\"{x:468,y:651,t:1527614060134};\\\", \\\"{x:454,y:654,t:1527614060151};\\\", \\\"{x:427,y:659,t:1527614060168};\\\", \\\"{x:371,y:666,t:1527614060185};\\\", \\\"{x:291,y:666,t:1527614060202};\\\", \\\"{x:198,y:661,t:1527614060220};\\\", \\\"{x:103,y:645,t:1527614060235};\\\", \\\"{x:1,y:634,t:1527614060253};\\\", \\\"{x:0,y:634,t:1527614060268};\\\", \\\"{x:0,y:632,t:1527614060286};\\\", \\\"{x:0,y:616,t:1527614060303};\\\", \\\"{x:0,y:602,t:1527614060318};\\\", \\\"{x:0,y:590,t:1527614060336};\\\", \\\"{x:0,y:587,t:1527614060352};\\\", \\\"{x:0,y:584,t:1527614060369};\\\", \\\"{x:0,y:583,t:1527614060529};\\\", \\\"{x:0,y:582,t:1527614060537};\\\", \\\"{x:20,y:555,t:1527614060552};\\\", \\\"{x:82,y:507,t:1527614060570};\\\", \\\"{x:177,y:459,t:1527614060587};\\\", \\\"{x:290,y:413,t:1527614060603};\\\", \\\"{x:425,y:372,t:1527614060620};\\\", \\\"{x:542,y:353,t:1527614060637};\\\", \\\"{x:642,y:340,t:1527614060653};\\\", \\\"{x:730,y:332,t:1527614060670};\\\", \\\"{x:797,y:332,t:1527614060687};\\\", \\\"{x:850,y:332,t:1527614060703};\\\", \\\"{x:909,y:336,t:1527614060721};\\\", \\\"{x:933,y:343,t:1527614060736};\\\", \\\"{x:953,y:352,t:1527614060753};\\\", \\\"{x:966,y:359,t:1527614060770};\\\", \\\"{x:981,y:368,t:1527614060787};\\\", \\\"{x:993,y:376,t:1527614060804};\\\", \\\"{x:1011,y:390,t:1527614060821};\\\", \\\"{x:1033,y:409,t:1527614060838};\\\", \\\"{x:1060,y:431,t:1527614060854};\\\", \\\"{x:1080,y:450,t:1527614060871};\\\", \\\"{x:1091,y:467,t:1527614060888};\\\", \\\"{x:1098,y:491,t:1527614060904};\\\", \\\"{x:1102,y:505,t:1527614060920};\\\", \\\"{x:1102,y:515,t:1527614060937};\\\", \\\"{x:1104,y:524,t:1527614060955};\\\", \\\"{x:1106,y:531,t:1527614060972};\\\", \\\"{x:1108,y:538,t:1527614060987};\\\", \\\"{x:1108,y:539,t:1527614061004};\\\", \\\"{x:1108,y:540,t:1527614061081};\\\", \\\"{x:1108,y:543,t:1527614061089};\\\", \\\"{x:1103,y:559,t:1527614061105};\\\", \\\"{x:1094,y:580,t:1527614061121};\\\", \\\"{x:1088,y:599,t:1527614061138};\\\", \\\"{x:1088,y:604,t:1527614061154};\\\", \\\"{x:1088,y:608,t:1527614061171};\\\", \\\"{x:1088,y:611,t:1527614061188};\\\", \\\"{x:1088,y:618,t:1527614061204};\\\", \\\"{x:1090,y:621,t:1527614061220};\\\", \\\"{x:1096,y:633,t:1527614061238};\\\", \\\"{x:1096,y:635,t:1527614061254};\\\", \\\"{x:1096,y:637,t:1527614061369};\\\", \\\"{x:1098,y:640,t:1527614061376};\\\", \\\"{x:1100,y:646,t:1527614061388};\\\", \\\"{x:1103,y:661,t:1527614061406};\\\", \\\"{x:1106,y:678,t:1527614061421};\\\", \\\"{x:1111,y:698,t:1527614061439};\\\", \\\"{x:1117,y:719,t:1527614061455};\\\", \\\"{x:1127,y:742,t:1527614061473};\\\", \\\"{x:1131,y:762,t:1527614061489};\\\", \\\"{x:1139,y:785,t:1527614061505};\\\", \\\"{x:1144,y:808,t:1527614061522};\\\", \\\"{x:1149,y:825,t:1527614061539};\\\", \\\"{x:1154,y:839,t:1527614061555};\\\", \\\"{x:1158,y:852,t:1527614061573};\\\", \\\"{x:1162,y:860,t:1527614061588};\\\", \\\"{x:1165,y:868,t:1527614061605};\\\", \\\"{x:1168,y:875,t:1527614061622};\\\", \\\"{x:1171,y:878,t:1527614061639};\\\", \\\"{x:1175,y:883,t:1527614061655};\\\", \\\"{x:1181,y:885,t:1527614061672};\\\", \\\"{x:1187,y:888,t:1527614061688};\\\", \\\"{x:1195,y:892,t:1527614061706};\\\", \\\"{x:1203,y:897,t:1527614061723};\\\", \\\"{x:1207,y:900,t:1527614061740};\\\", \\\"{x:1211,y:901,t:1527614061756};\\\", \\\"{x:1213,y:901,t:1527614061873};\\\", \\\"{x:1224,y:899,t:1527614061890};\\\", \\\"{x:1242,y:893,t:1527614061906};\\\", \\\"{x:1269,y:891,t:1527614061923};\\\", \\\"{x:1299,y:891,t:1527614061940};\\\", \\\"{x:1328,y:891,t:1527614061956};\\\", \\\"{x:1343,y:891,t:1527614061973};\\\", \\\"{x:1349,y:891,t:1527614061991};\\\", \\\"{x:1352,y:891,t:1527614062005};\\\", \\\"{x:1352,y:890,t:1527614062032};\\\", \\\"{x:1345,y:889,t:1527614062225};\\\", \\\"{x:1327,y:885,t:1527614062240};\\\", \\\"{x:1295,y:878,t:1527614062257};\\\", \\\"{x:1261,y:873,t:1527614062273};\\\", \\\"{x:1233,y:868,t:1527614062290};\\\", \\\"{x:1212,y:864,t:1527614062307};\\\", \\\"{x:1197,y:861,t:1527614062323};\\\", \\\"{x:1195,y:861,t:1527614062340};\\\", \\\"{x:1194,y:861,t:1527614062357};\\\", \\\"{x:1192,y:861,t:1527614062373};\\\", \\\"{x:1189,y:861,t:1527614062391};\\\", \\\"{x:1188,y:861,t:1527614062408};\\\", \\\"{x:1187,y:861,t:1527614062424};\\\", \\\"{x:1188,y:861,t:1527614062721};\\\", \\\"{x:1191,y:861,t:1527614062729};\\\", \\\"{x:1193,y:860,t:1527614062742};\\\", \\\"{x:1201,y:859,t:1527614062758};\\\", \\\"{x:1204,y:858,t:1527614062774};\\\", \\\"{x:1209,y:857,t:1527614062791};\\\", \\\"{x:1212,y:855,t:1527614062808};\\\", \\\"{x:1214,y:855,t:1527614062825};\\\", \\\"{x:1216,y:854,t:1527614062841};\\\", \\\"{x:1218,y:852,t:1527614062858};\\\", \\\"{x:1222,y:850,t:1527614062876};\\\", \\\"{x:1223,y:849,t:1527614062891};\\\", \\\"{x:1225,y:848,t:1527614062909};\\\", \\\"{x:1226,y:847,t:1527614062926};\\\", \\\"{x:1227,y:847,t:1527614062942};\\\", \\\"{x:1228,y:846,t:1527614062959};\\\", \\\"{x:1228,y:845,t:1527614063281};\\\", \\\"{x:1228,y:844,t:1527614063292};\\\", \\\"{x:1226,y:841,t:1527614063309};\\\", \\\"{x:1224,y:838,t:1527614063326};\\\", \\\"{x:1221,y:834,t:1527614063343};\\\", \\\"{x:1219,y:832,t:1527614063361};\\\", \\\"{x:1218,y:832,t:1527614063376};\\\", \\\"{x:1217,y:831,t:1527614063392};\\\", \\\"{x:1218,y:832,t:1527614063713};\\\", \\\"{x:1219,y:834,t:1527614063728};\\\", \\\"{x:1223,y:841,t:1527614063744};\\\", \\\"{x:1229,y:847,t:1527614063761};\\\", \\\"{x:1232,y:850,t:1527614063777};\\\", \\\"{x:1236,y:852,t:1527614063794};\\\", \\\"{x:1237,y:852,t:1527614063817};\\\", \\\"{x:1239,y:852,t:1527614063833};\\\", \\\"{x:1240,y:852,t:1527614063882};\\\", \\\"{x:1242,y:852,t:1527614063893};\\\", \\\"{x:1246,y:852,t:1527614063911};\\\", \\\"{x:1249,y:852,t:1527614063927};\\\", \\\"{x:1253,y:852,t:1527614063943};\\\", \\\"{x:1259,y:851,t:1527614063961};\\\", \\\"{x:1262,y:850,t:1527614063977};\\\", \\\"{x:1265,y:848,t:1527614063994};\\\", \\\"{x:1268,y:847,t:1527614064010};\\\", \\\"{x:1270,y:846,t:1527614064028};\\\", \\\"{x:1272,y:845,t:1527614064044};\\\", \\\"{x:1274,y:843,t:1527614064061};\\\", \\\"{x:1276,y:841,t:1527614064078};\\\", \\\"{x:1277,y:841,t:1527614064094};\\\", \\\"{x:1279,y:839,t:1527614064110};\\\", \\\"{x:1281,y:837,t:1527614064128};\\\", \\\"{x:1282,y:835,t:1527614064144};\\\", \\\"{x:1282,y:833,t:1527614064160};\\\", \\\"{x:1282,y:832,t:1527614064177};\\\", \\\"{x:1284,y:830,t:1527614064194};\\\", \\\"{x:1284,y:829,t:1527614064211};\\\", \\\"{x:1285,y:828,t:1527614064320};\\\", \\\"{x:1288,y:828,t:1527614064328};\\\", \\\"{x:1294,y:829,t:1527614064344};\\\", \\\"{x:1301,y:832,t:1527614064361};\\\", \\\"{x:1305,y:834,t:1527614064378};\\\", \\\"{x:1308,y:835,t:1527614064394};\\\", \\\"{x:1314,y:838,t:1527614064412};\\\", \\\"{x:1317,y:838,t:1527614064429};\\\", \\\"{x:1321,y:838,t:1527614064444};\\\", \\\"{x:1322,y:838,t:1527614064462};\\\", \\\"{x:1324,y:838,t:1527614064478};\\\", \\\"{x:1325,y:838,t:1527614064495};\\\", \\\"{x:1327,y:838,t:1527614064512};\\\", \\\"{x:1328,y:838,t:1527614064528};\\\", \\\"{x:1329,y:837,t:1527614064545};\\\", \\\"{x:1331,y:836,t:1527614064561};\\\", \\\"{x:1332,y:833,t:1527614064579};\\\", \\\"{x:1334,y:830,t:1527614064595};\\\", \\\"{x:1335,y:829,t:1527614064612};\\\", \\\"{x:1337,y:826,t:1527614064628};\\\", \\\"{x:1339,y:824,t:1527614064645};\\\", \\\"{x:1340,y:823,t:1527614064662};\\\", \\\"{x:1341,y:823,t:1527614064678};\\\", \\\"{x:1343,y:821,t:1527614064696};\\\", \\\"{x:1344,y:820,t:1527614064753};\\\", \\\"{x:1345,y:820,t:1527614070713};\\\", \\\"{x:1348,y:820,t:1527614070725};\\\", \\\"{x:1405,y:820,t:1527614070742};\\\", \\\"{x:1517,y:839,t:1527614070759};\\\", \\\"{x:1601,y:856,t:1527614070775};\\\", \\\"{x:1623,y:862,t:1527614070792};\\\", \\\"{x:1655,y:874,t:1527614070809};\\\", \\\"{x:1661,y:878,t:1527614070825};\\\", \\\"{x:1660,y:878,t:1527614070961};\\\", \\\"{x:1658,y:878,t:1527614070976};\\\", \\\"{x:1649,y:875,t:1527614070992};\\\", \\\"{x:1627,y:866,t:1527614071008};\\\", \\\"{x:1610,y:862,t:1527614071026};\\\", \\\"{x:1594,y:856,t:1527614071043};\\\", \\\"{x:1584,y:854,t:1527614071059};\\\", \\\"{x:1570,y:849,t:1527614071076};\\\", \\\"{x:1564,y:847,t:1527614071093};\\\", \\\"{x:1562,y:846,t:1527614071109};\\\", \\\"{x:1561,y:845,t:1527614071126};\\\", \\\"{x:1559,y:842,t:1527614071143};\\\", \\\"{x:1559,y:837,t:1527614071159};\\\", \\\"{x:1559,y:826,t:1527614071176};\\\", \\\"{x:1561,y:808,t:1527614071193};\\\", \\\"{x:1566,y:798,t:1527614071209};\\\", \\\"{x:1568,y:794,t:1527614071226};\\\", \\\"{x:1568,y:793,t:1527614071243};\\\", \\\"{x:1568,y:792,t:1527614071260};\\\", \\\"{x:1568,y:791,t:1527614071313};\\\", \\\"{x:1567,y:791,t:1527614071329};\\\", \\\"{x:1566,y:790,t:1527614071343};\\\", \\\"{x:1563,y:790,t:1527614071360};\\\", \\\"{x:1549,y:790,t:1527614071377};\\\", \\\"{x:1539,y:791,t:1527614071393};\\\", \\\"{x:1530,y:793,t:1527614071410};\\\", \\\"{x:1519,y:797,t:1527614071427};\\\", \\\"{x:1513,y:798,t:1527614071443};\\\", \\\"{x:1510,y:801,t:1527614071460};\\\", \\\"{x:1502,y:804,t:1527614071477};\\\", \\\"{x:1496,y:809,t:1527614071492};\\\", \\\"{x:1489,y:813,t:1527614071510};\\\", \\\"{x:1483,y:818,t:1527614071527};\\\", \\\"{x:1477,y:821,t:1527614071544};\\\", \\\"{x:1474,y:824,t:1527614071561};\\\", \\\"{x:1469,y:827,t:1527614071576};\\\", \\\"{x:1466,y:832,t:1527614071594};\\\", \\\"{x:1460,y:839,t:1527614071609};\\\", \\\"{x:1454,y:845,t:1527614071627};\\\", \\\"{x:1446,y:851,t:1527614071644};\\\", \\\"{x:1442,y:856,t:1527614071660};\\\", \\\"{x:1439,y:860,t:1527614071677};\\\", \\\"{x:1436,y:862,t:1527614071694};\\\", \\\"{x:1432,y:865,t:1527614071711};\\\", \\\"{x:1426,y:869,t:1527614071728};\\\", \\\"{x:1423,y:871,t:1527614071745};\\\", \\\"{x:1419,y:874,t:1527614071760};\\\", \\\"{x:1417,y:874,t:1527614071776};\\\", \\\"{x:1415,y:876,t:1527614071794};\\\", \\\"{x:1412,y:878,t:1527614071811};\\\", \\\"{x:1411,y:878,t:1527614071827};\\\", \\\"{x:1410,y:879,t:1527614071844};\\\", \\\"{x:1409,y:880,t:1527614071861};\\\", \\\"{x:1406,y:882,t:1527614071878};\\\", \\\"{x:1404,y:883,t:1527614071896};\\\", \\\"{x:1402,y:884,t:1527614071920};\\\", \\\"{x:1401,y:885,t:1527614071936};\\\", \\\"{x:1400,y:886,t:1527614071977};\\\", \\\"{x:1398,y:887,t:1527614072008};\\\", \\\"{x:1397,y:889,t:1527614072025};\\\", \\\"{x:1395,y:890,t:1527614072049};\\\", \\\"{x:1394,y:890,t:1527614072065};\\\", \\\"{x:1392,y:892,t:1527614072081};\\\", \\\"{x:1391,y:893,t:1527614072095};\\\", \\\"{x:1388,y:893,t:1527614072111};\\\", \\\"{x:1387,y:894,t:1527614072127};\\\", \\\"{x:1386,y:894,t:1527614072145};\\\", \\\"{x:1384,y:895,t:1527614072161};\\\", \\\"{x:1383,y:896,t:1527614072193};\\\", \\\"{x:1382,y:896,t:1527614072233};\\\", \\\"{x:1382,y:897,t:1527614072248};\\\", \\\"{x:1381,y:898,t:1527614072369};\\\", \\\"{x:1380,y:898,t:1527614072641};\\\", \\\"{x:1375,y:889,t:1527614072649};\\\", \\\"{x:1369,y:879,t:1527614072663};\\\", \\\"{x:1356,y:860,t:1527614072679};\\\", \\\"{x:1344,y:845,t:1527614072697};\\\", \\\"{x:1342,y:842,t:1527614072712};\\\", \\\"{x:1341,y:841,t:1527614072729};\\\", \\\"{x:1341,y:840,t:1527614072793};\\\", \\\"{x:1340,y:839,t:1527614072800};\\\", \\\"{x:1340,y:836,t:1527614072812};\\\", \\\"{x:1340,y:833,t:1527614072829};\\\", \\\"{x:1343,y:828,t:1527614072845};\\\", \\\"{x:1355,y:821,t:1527614072862};\\\", \\\"{x:1372,y:816,t:1527614072879};\\\", \\\"{x:1390,y:810,t:1527614072895};\\\", \\\"{x:1420,y:803,t:1527614072912};\\\", \\\"{x:1435,y:801,t:1527614072930};\\\", \\\"{x:1450,y:798,t:1527614072945};\\\", \\\"{x:1462,y:796,t:1527614072963};\\\", \\\"{x:1471,y:795,t:1527614072979};\\\", \\\"{x:1480,y:791,t:1527614072996};\\\", \\\"{x:1492,y:786,t:1527614073012};\\\", \\\"{x:1503,y:783,t:1527614073029};\\\", \\\"{x:1508,y:781,t:1527614073046};\\\", \\\"{x:1511,y:778,t:1527614073063};\\\", \\\"{x:1515,y:776,t:1527614073079};\\\", \\\"{x:1518,y:774,t:1527614073097};\\\", \\\"{x:1519,y:773,t:1527614073113};\\\", \\\"{x:1519,y:772,t:1527614073136};\\\", \\\"{x:1519,y:771,t:1527614073161};\\\", \\\"{x:1519,y:769,t:1527614073168};\\\", \\\"{x:1520,y:769,t:1527614073180};\\\", \\\"{x:1521,y:767,t:1527614073200};\\\", \\\"{x:1521,y:766,t:1527614073216};\\\", \\\"{x:1521,y:765,t:1527614073229};\\\", \\\"{x:1521,y:764,t:1527614073248};\\\", \\\"{x:1521,y:763,t:1527614073272};\\\", \\\"{x:1521,y:762,t:1527614073305};\\\", \\\"{x:1521,y:761,t:1527614073360};\\\", \\\"{x:1521,y:760,t:1527614073384};\\\", \\\"{x:1520,y:759,t:1527614073396};\\\", \\\"{x:1519,y:759,t:1527614073413};\\\", \\\"{x:1518,y:758,t:1527614073439};\\\", \\\"{x:1517,y:757,t:1527614073471};\\\", \\\"{x:1515,y:757,t:1527614074793};\\\", \\\"{x:1511,y:759,t:1527614074800};\\\", \\\"{x:1506,y:761,t:1527614074817};\\\", \\\"{x:1505,y:761,t:1527614074834};\\\", \\\"{x:1504,y:762,t:1527614074850};\\\", \\\"{x:1503,y:763,t:1527614074866};\\\", \\\"{x:1502,y:763,t:1527614074888};\\\", \\\"{x:1501,y:764,t:1527614074921};\\\", \\\"{x:1500,y:764,t:1527614074936};\\\", \\\"{x:1498,y:765,t:1527614074952};\\\", \\\"{x:1497,y:766,t:1527614074966};\\\", \\\"{x:1491,y:771,t:1527614074984};\\\", \\\"{x:1474,y:774,t:1527614075000};\\\", \\\"{x:1450,y:778,t:1527614075017};\\\", \\\"{x:1422,y:782,t:1527614075034};\\\", \\\"{x:1391,y:782,t:1527614075050};\\\", \\\"{x:1364,y:782,t:1527614075068};\\\", \\\"{x:1344,y:781,t:1527614075084};\\\", \\\"{x:1330,y:776,t:1527614075101};\\\", \\\"{x:1323,y:775,t:1527614075118};\\\", \\\"{x:1320,y:774,t:1527614075134};\\\", \\\"{x:1321,y:770,t:1527614075328};\\\", \\\"{x:1322,y:768,t:1527614075336};\\\", \\\"{x:1323,y:766,t:1527614075351};\\\", \\\"{x:1325,y:764,t:1527614075367};\\\", \\\"{x:1328,y:761,t:1527614075384};\\\", \\\"{x:1330,y:759,t:1527614075402};\\\", \\\"{x:1330,y:758,t:1527614075457};\\\", \\\"{x:1331,y:757,t:1527614075567};\\\", \\\"{x:1331,y:756,t:1527614075584};\\\", \\\"{x:1332,y:756,t:1527614075601};\\\", \\\"{x:1333,y:756,t:1527614075663};\\\", \\\"{x:1334,y:756,t:1527614075728};\\\", \\\"{x:1336,y:756,t:1527614075752};\\\", \\\"{x:1337,y:756,t:1527614075768};\\\", \\\"{x:1338,y:756,t:1527614075785};\\\", \\\"{x:1340,y:756,t:1527614075889};\\\", \\\"{x:1341,y:756,t:1527614076145};\\\", \\\"{x:1341,y:759,t:1527614076161};\\\", \\\"{x:1341,y:761,t:1527614076170};\\\", \\\"{x:1341,y:764,t:1527614076187};\\\", \\\"{x:1342,y:766,t:1527614076203};\\\", \\\"{x:1343,y:768,t:1527614076220};\\\", \\\"{x:1344,y:769,t:1527614076295};\\\", \\\"{x:1345,y:770,t:1527614076352};\\\", \\\"{x:1346,y:770,t:1527614076367};\\\", \\\"{x:1348,y:770,t:1527614076384};\\\", \\\"{x:1348,y:772,t:1527614076391};\\\", \\\"{x:1350,y:773,t:1527614076403};\\\", \\\"{x:1350,y:774,t:1527614076420};\\\", \\\"{x:1352,y:775,t:1527614076436};\\\", \\\"{x:1354,y:776,t:1527614076454};\\\", \\\"{x:1356,y:776,t:1527614076512};\\\", \\\"{x:1357,y:776,t:1527614076585};\\\", \\\"{x:1358,y:776,t:1527614076600};\\\", \\\"{x:1359,y:776,t:1527614076609};\\\", \\\"{x:1362,y:776,t:1527614076624};\\\", \\\"{x:1364,y:776,t:1527614076637};\\\", \\\"{x:1377,y:776,t:1527614076654};\\\", \\\"{x:1384,y:776,t:1527614076672};\\\", \\\"{x:1393,y:776,t:1527614076688};\\\", \\\"{x:1397,y:776,t:1527614076704};\\\", \\\"{x:1399,y:776,t:1527614076721};\\\", \\\"{x:1400,y:776,t:1527614076738};\\\", \\\"{x:1401,y:776,t:1527614076754};\\\", \\\"{x:1403,y:775,t:1527614076771};\\\", \\\"{x:1407,y:774,t:1527614076788};\\\", \\\"{x:1410,y:772,t:1527614076805};\\\", \\\"{x:1414,y:770,t:1527614076821};\\\", \\\"{x:1417,y:767,t:1527614076838};\\\", \\\"{x:1421,y:764,t:1527614076855};\\\", \\\"{x:1422,y:764,t:1527614076871};\\\", \\\"{x:1422,y:763,t:1527614076888};\\\", \\\"{x:1423,y:762,t:1527614076906};\\\", \\\"{x:1423,y:761,t:1527614077073};\\\", \\\"{x:1423,y:759,t:1527614077113};\\\", \\\"{x:1423,y:758,t:1527614077122};\\\", \\\"{x:1423,y:756,t:1527614077138};\\\", \\\"{x:1424,y:754,t:1527614077155};\\\", \\\"{x:1424,y:753,t:1527614077172};\\\", \\\"{x:1425,y:752,t:1527614077190};\\\", \\\"{x:1426,y:752,t:1527614077369};\\\", \\\"{x:1430,y:757,t:1527614077377};\\\", \\\"{x:1432,y:762,t:1527614077389};\\\", \\\"{x:1436,y:767,t:1527614077406};\\\", \\\"{x:1439,y:772,t:1527614077422};\\\", \\\"{x:1443,y:778,t:1527614077440};\\\", \\\"{x:1446,y:782,t:1527614077456};\\\", \\\"{x:1447,y:782,t:1527614077473};\\\", \\\"{x:1448,y:782,t:1527614077537};\\\", \\\"{x:1449,y:782,t:1527614077544};\\\", \\\"{x:1452,y:782,t:1527614077555};\\\", \\\"{x:1457,y:782,t:1527614077573};\\\", \\\"{x:1462,y:780,t:1527614077589};\\\", \\\"{x:1466,y:779,t:1527614077606};\\\", \\\"{x:1469,y:778,t:1527614077623};\\\", \\\"{x:1471,y:777,t:1527614077640};\\\", \\\"{x:1473,y:777,t:1527614077656};\\\", \\\"{x:1474,y:777,t:1527614077673};\\\", \\\"{x:1475,y:776,t:1527614077690};\\\", \\\"{x:1477,y:775,t:1527614077706};\\\", \\\"{x:1479,y:774,t:1527614077723};\\\", \\\"{x:1482,y:771,t:1527614077740};\\\", \\\"{x:1484,y:768,t:1527614077756};\\\", \\\"{x:1485,y:767,t:1527614077773};\\\", \\\"{x:1487,y:765,t:1527614077791};\\\", \\\"{x:1487,y:764,t:1527614077807};\\\", \\\"{x:1487,y:762,t:1527614077880};\\\", \\\"{x:1488,y:762,t:1527614077897};\\\", \\\"{x:1488,y:761,t:1527614077912};\\\", \\\"{x:1488,y:759,t:1527614077937};\\\", \\\"{x:1488,y:758,t:1527614077968};\\\", \\\"{x:1488,y:756,t:1527614078009};\\\", \\\"{x:1488,y:755,t:1527614078089};\\\", \\\"{x:1488,y:754,t:1527614079273};\\\", \\\"{x:1485,y:757,t:1527614079281};\\\", \\\"{x:1483,y:760,t:1527614079293};\\\", \\\"{x:1478,y:765,t:1527614079310};\\\", \\\"{x:1477,y:766,t:1527614079326};\\\", \\\"{x:1475,y:768,t:1527614079343};\\\", \\\"{x:1474,y:769,t:1527614079648};\\\", \\\"{x:1474,y:767,t:1527614079664};\\\", \\\"{x:1474,y:765,t:1527614079680};\\\", \\\"{x:1473,y:764,t:1527614079694};\\\", \\\"{x:1472,y:763,t:1527614079712};\\\", \\\"{x:1472,y:761,t:1527614079727};\\\", \\\"{x:1472,y:760,t:1527614079744};\\\", \\\"{x:1473,y:761,t:1527614080057};\\\", \\\"{x:1473,y:764,t:1527614080065};\\\", \\\"{x:1473,y:765,t:1527614080078};\\\", \\\"{x:1475,y:768,t:1527614080095};\\\", \\\"{x:1476,y:771,t:1527614080111};\\\", \\\"{x:1476,y:772,t:1527614080128};\\\", \\\"{x:1477,y:772,t:1527614080145};\\\", \\\"{x:1478,y:773,t:1527614080161};\\\", \\\"{x:1479,y:774,t:1527614080178};\\\", \\\"{x:1481,y:775,t:1527614080195};\\\", \\\"{x:1483,y:777,t:1527614080212};\\\", \\\"{x:1484,y:778,t:1527614080227};\\\", \\\"{x:1486,y:779,t:1527614080244};\\\", \\\"{x:1487,y:779,t:1527614080263};\\\", \\\"{x:1488,y:779,t:1527614080303};\\\", \\\"{x:1489,y:780,t:1527614080312};\\\", \\\"{x:1490,y:781,t:1527614080368};\\\", \\\"{x:1491,y:781,t:1527614080392};\\\", \\\"{x:1493,y:781,t:1527614080400};\\\", \\\"{x:1494,y:782,t:1527614080412};\\\", \\\"{x:1501,y:784,t:1527614080429};\\\", \\\"{x:1507,y:784,t:1527614080445};\\\", \\\"{x:1514,y:785,t:1527614080462};\\\", \\\"{x:1518,y:786,t:1527614080479};\\\", \\\"{x:1521,y:786,t:1527614080495};\\\", \\\"{x:1523,y:788,t:1527614080512};\\\", \\\"{x:1524,y:788,t:1527614080584};\\\", \\\"{x:1525,y:788,t:1527614080596};\\\", \\\"{x:1527,y:788,t:1527614080612};\\\", \\\"{x:1528,y:788,t:1527614080629};\\\", \\\"{x:1532,y:788,t:1527614080646};\\\", \\\"{x:1534,y:787,t:1527614080662};\\\", \\\"{x:1535,y:787,t:1527614080679};\\\", \\\"{x:1537,y:787,t:1527614080696};\\\", \\\"{x:1538,y:786,t:1527614080760};\\\", \\\"{x:1538,y:785,t:1527614080768};\\\", \\\"{x:1540,y:785,t:1527614080792};\\\", \\\"{x:1541,y:785,t:1527614080824};\\\", \\\"{x:1541,y:784,t:1527614080832};\\\", \\\"{x:1543,y:784,t:1527614080881};\\\", \\\"{x:1544,y:783,t:1527614080921};\\\", \\\"{x:1545,y:782,t:1527614080936};\\\", \\\"{x:1545,y:781,t:1527614080952};\\\", \\\"{x:1546,y:781,t:1527614080977};\\\", \\\"{x:1547,y:779,t:1527614080985};\\\", \\\"{x:1548,y:777,t:1527614081017};\\\", \\\"{x:1548,y:776,t:1527614081040};\\\", \\\"{x:1548,y:775,t:1527614081064};\\\", \\\"{x:1548,y:774,t:1527614081088};\\\", \\\"{x:1548,y:773,t:1527614081128};\\\", \\\"{x:1547,y:772,t:1527614081152};\\\", \\\"{x:1547,y:771,t:1527614081177};\\\", \\\"{x:1546,y:771,t:1527614081200};\\\", \\\"{x:1545,y:770,t:1527614081223};\\\", \\\"{x:1544,y:769,t:1527614081247};\\\", \\\"{x:1543,y:768,t:1527614081264};\\\", \\\"{x:1543,y:767,t:1527614081280};\\\", \\\"{x:1543,y:766,t:1527614081297};\\\", \\\"{x:1543,y:765,t:1527614081319};\\\", \\\"{x:1543,y:764,t:1527614081331};\\\", \\\"{x:1543,y:763,t:1527614081347};\\\", \\\"{x:1543,y:762,t:1527614081368};\\\", \\\"{x:1543,y:761,t:1527614081392};\\\", \\\"{x:1543,y:760,t:1527614081424};\\\", \\\"{x:1543,y:759,t:1527614081448};\\\", \\\"{x:1543,y:758,t:1527614081497};\\\", \\\"{x:1543,y:757,t:1527614081696};\\\", \\\"{x:1543,y:758,t:1527614082168};\\\", \\\"{x:1543,y:761,t:1527614082183};\\\", \\\"{x:1543,y:767,t:1527614082198};\\\", \\\"{x:1543,y:776,t:1527614082215};\\\", \\\"{x:1543,y:780,t:1527614082231};\\\", \\\"{x:1543,y:783,t:1527614082249};\\\", \\\"{x:1543,y:788,t:1527614082266};\\\", \\\"{x:1544,y:792,t:1527614082283};\\\", \\\"{x:1544,y:795,t:1527614082299};\\\", \\\"{x:1544,y:798,t:1527614082315};\\\", \\\"{x:1544,y:801,t:1527614082333};\\\", \\\"{x:1544,y:808,t:1527614082349};\\\", \\\"{x:1545,y:812,t:1527614082366};\\\", \\\"{x:1545,y:816,t:1527614082382};\\\", \\\"{x:1546,y:820,t:1527614082399};\\\", \\\"{x:1546,y:827,t:1527614082415};\\\", \\\"{x:1548,y:835,t:1527614082433};\\\", \\\"{x:1551,y:844,t:1527614082450};\\\", \\\"{x:1553,y:850,t:1527614082465};\\\", \\\"{x:1555,y:855,t:1527614082482};\\\", \\\"{x:1557,y:857,t:1527614082499};\\\", \\\"{x:1558,y:861,t:1527614082515};\\\", \\\"{x:1558,y:864,t:1527614082533};\\\", \\\"{x:1559,y:866,t:1527614082549};\\\", \\\"{x:1559,y:870,t:1527614082566};\\\", \\\"{x:1559,y:872,t:1527614082582};\\\", \\\"{x:1559,y:876,t:1527614082600};\\\", \\\"{x:1559,y:880,t:1527614082617};\\\", \\\"{x:1559,y:887,t:1527614082632};\\\", \\\"{x:1559,y:892,t:1527614082650};\\\", \\\"{x:1559,y:898,t:1527614082667};\\\", \\\"{x:1558,y:903,t:1527614082683};\\\", \\\"{x:1557,y:906,t:1527614082699};\\\", \\\"{x:1556,y:909,t:1527614082717};\\\", \\\"{x:1556,y:911,t:1527614082733};\\\", \\\"{x:1555,y:914,t:1527614082750};\\\", \\\"{x:1553,y:921,t:1527614082768};\\\", \\\"{x:1551,y:926,t:1527614082784};\\\", \\\"{x:1551,y:933,t:1527614082800};\\\", \\\"{x:1549,y:942,t:1527614082817};\\\", \\\"{x:1549,y:949,t:1527614082835};\\\", \\\"{x:1548,y:953,t:1527614082850};\\\", \\\"{x:1548,y:957,t:1527614082867};\\\", \\\"{x:1548,y:959,t:1527614082884};\\\", \\\"{x:1548,y:960,t:1527614082900};\\\", \\\"{x:1548,y:962,t:1527614082917};\\\", \\\"{x:1548,y:964,t:1527614082936};\\\", \\\"{x:1547,y:965,t:1527614082951};\\\", \\\"{x:1547,y:967,t:1527614082967};\\\", \\\"{x:1547,y:969,t:1527614082984};\\\", \\\"{x:1547,y:970,t:1527614083008};\\\", \\\"{x:1547,y:971,t:1527614083016};\\\", \\\"{x:1547,y:972,t:1527614083034};\\\", \\\"{x:1547,y:973,t:1527614083051};\\\", \\\"{x:1547,y:974,t:1527614083072};\\\", \\\"{x:1545,y:975,t:1527614083249};\\\", \\\"{x:1543,y:974,t:1527614083256};\\\", \\\"{x:1540,y:971,t:1527614083268};\\\", \\\"{x:1539,y:958,t:1527614083286};\\\", \\\"{x:1538,y:953,t:1527614083301};\\\", \\\"{x:1537,y:947,t:1527614083318};\\\", \\\"{x:1536,y:942,t:1527614083335};\\\", \\\"{x:1536,y:937,t:1527614083351};\\\", \\\"{x:1533,y:921,t:1527614083368};\\\", \\\"{x:1532,y:907,t:1527614083385};\\\", \\\"{x:1532,y:896,t:1527614083402};\\\", \\\"{x:1532,y:888,t:1527614083419};\\\", \\\"{x:1532,y:882,t:1527614083435};\\\", \\\"{x:1532,y:875,t:1527614083452};\\\", \\\"{x:1532,y:865,t:1527614083468};\\\", \\\"{x:1532,y:855,t:1527614083485};\\\", \\\"{x:1532,y:845,t:1527614083502};\\\", \\\"{x:1532,y:840,t:1527614083519};\\\", \\\"{x:1532,y:832,t:1527614083535};\\\", \\\"{x:1532,y:821,t:1527614083552};\\\", \\\"{x:1532,y:813,t:1527614083569};\\\", \\\"{x:1532,y:805,t:1527614083585};\\\", \\\"{x:1532,y:796,t:1527614083602};\\\", \\\"{x:1532,y:789,t:1527614083620};\\\", \\\"{x:1531,y:784,t:1527614083636};\\\", \\\"{x:1531,y:781,t:1527614083652};\\\", \\\"{x:1531,y:780,t:1527614083672};\\\", \\\"{x:1531,y:778,t:1527614083697};\\\", \\\"{x:1531,y:777,t:1527614083712};\\\", \\\"{x:1531,y:775,t:1527614083720};\\\", \\\"{x:1529,y:773,t:1527614083736};\\\", \\\"{x:1529,y:771,t:1527614083752};\\\", \\\"{x:1529,y:769,t:1527614083769};\\\", \\\"{x:1529,y:768,t:1527614083786};\\\", \\\"{x:1529,y:764,t:1527614083802};\\\", \\\"{x:1529,y:761,t:1527614083819};\\\", \\\"{x:1529,y:759,t:1527614083837};\\\", \\\"{x:1530,y:755,t:1527614083852};\\\", \\\"{x:1531,y:751,t:1527614083869};\\\", \\\"{x:1531,y:750,t:1527614083886};\\\", \\\"{x:1532,y:748,t:1527614083903};\\\", \\\"{x:1532,y:747,t:1527614084017};\\\", \\\"{x:1522,y:760,t:1527614084024};\\\", \\\"{x:1504,y:779,t:1527614084036};\\\", \\\"{x:1452,y:820,t:1527614084054};\\\", \\\"{x:1363,y:859,t:1527614084070};\\\", \\\"{x:1274,y:886,t:1527614084086};\\\", \\\"{x:1193,y:899,t:1527614084103};\\\", \\\"{x:1091,y:915,t:1527614084120};\\\", \\\"{x:1026,y:920,t:1527614084136};\\\", \\\"{x:983,y:927,t:1527614084154};\\\", \\\"{x:954,y:930,t:1527614084171};\\\", \\\"{x:924,y:933,t:1527614084187};\\\", \\\"{x:901,y:933,t:1527614084203};\\\", \\\"{x:882,y:933,t:1527614084220};\\\", \\\"{x:857,y:932,t:1527614084237};\\\", \\\"{x:821,y:925,t:1527614084253};\\\", \\\"{x:773,y:903,t:1527614084270};\\\", \\\"{x:733,y:878,t:1527614084287};\\\", \\\"{x:675,y:845,t:1527614084303};\\\", \\\"{x:628,y:795,t:1527614084320};\\\", \\\"{x:616,y:765,t:1527614084337};\\\", \\\"{x:608,y:727,t:1527614084354};\\\", \\\"{x:604,y:688,t:1527614084370};\\\", \\\"{x:604,y:632,t:1527614084387};\\\", \\\"{x:604,y:582,t:1527614084406};\\\", \\\"{x:605,y:553,t:1527614084421};\\\", \\\"{x:603,y:531,t:1527614084437};\\\", \\\"{x:588,y:511,t:1527614084454};\\\", \\\"{x:562,y:494,t:1527614084470};\\\", \\\"{x:506,y:466,t:1527614084489};\\\", \\\"{x:483,y:459,t:1527614084504};\\\", \\\"{x:475,y:455,t:1527614084521};\\\", \\\"{x:474,y:454,t:1527614084539};\\\", \\\"{x:471,y:454,t:1527614084631};\\\", \\\"{x:461,y:458,t:1527614084639};\\\", \\\"{x:410,y:493,t:1527614084656};\\\", \\\"{x:333,y:544,t:1527614084673};\\\", \\\"{x:277,y:569,t:1527614084690};\\\", \\\"{x:252,y:580,t:1527614084705};\\\", \\\"{x:238,y:584,t:1527614084721};\\\", \\\"{x:235,y:585,t:1527614084738};\\\", \\\"{x:234,y:585,t:1527614084767};\\\", \\\"{x:230,y:585,t:1527614084953};\\\", \\\"{x:223,y:584,t:1527614084960};\\\", \\\"{x:214,y:581,t:1527614084972};\\\", \\\"{x:189,y:570,t:1527614084989};\\\", \\\"{x:161,y:563,t:1527614085006};\\\", \\\"{x:134,y:554,t:1527614085023};\\\", \\\"{x:125,y:550,t:1527614085039};\\\", \\\"{x:124,y:548,t:1527614085055};\\\", \\\"{x:124,y:547,t:1527614085072};\\\", \\\"{x:124,y:544,t:1527614085088};\\\", \\\"{x:124,y:543,t:1527614085106};\\\", \\\"{x:125,y:541,t:1527614085122};\\\", \\\"{x:125,y:540,t:1527614085139};\\\", \\\"{x:127,y:537,t:1527614085156};\\\", \\\"{x:128,y:536,t:1527614085172};\\\", \\\"{x:129,y:535,t:1527614085189};\\\", \\\"{x:130,y:533,t:1527614085206};\\\", \\\"{x:132,y:532,t:1527614085221};\\\", \\\"{x:136,y:531,t:1527614085238};\\\", \\\"{x:140,y:529,t:1527614085256};\\\", \\\"{x:141,y:529,t:1527614085272};\\\", \\\"{x:143,y:529,t:1527614085289};\\\", \\\"{x:145,y:529,t:1527614085306};\\\", \\\"{x:146,y:529,t:1527614085323};\\\", \\\"{x:149,y:530,t:1527614085341};\\\", \\\"{x:150,y:530,t:1527614085356};\\\", \\\"{x:151,y:531,t:1527614085372};\\\", \\\"{x:153,y:531,t:1527614085389};\\\", \\\"{x:153,y:532,t:1527614085406};\\\", \\\"{x:154,y:533,t:1527614085960};\\\", \\\"{x:168,y:533,t:1527614085973};\\\", \\\"{x:298,y:569,t:1527614085993};\\\", \\\"{x:472,y:623,t:1527614086007};\\\", \\\"{x:645,y:659,t:1527614086023};\\\", \\\"{x:885,y:721,t:1527614086039};\\\", \\\"{x:1052,y:757,t:1527614086056};\\\", \\\"{x:1198,y:796,t:1527614086073};\\\", \\\"{x:1325,y:828,t:1527614086090};\\\", \\\"{x:1421,y:849,t:1527614086105};\\\", \\\"{x:1482,y:859,t:1527614086123};\\\", \\\"{x:1530,y:865,t:1527614086140};\\\", \\\"{x:1556,y:866,t:1527614086156};\\\", \\\"{x:1576,y:866,t:1527614086173};\\\", \\\"{x:1596,y:864,t:1527614086190};\\\", \\\"{x:1613,y:859,t:1527614086207};\\\", \\\"{x:1628,y:854,t:1527614086223};\\\", \\\"{x:1637,y:852,t:1527614086240};\\\", \\\"{x:1644,y:850,t:1527614086257};\\\", \\\"{x:1645,y:850,t:1527614086272};\\\", \\\"{x:1646,y:850,t:1527614086290};\\\", \\\"{x:1647,y:849,t:1527614086306};\\\", \\\"{x:1647,y:850,t:1527614086472};\\\", \\\"{x:1646,y:855,t:1527614086490};\\\", \\\"{x:1646,y:858,t:1527614086507};\\\", \\\"{x:1643,y:862,t:1527614086523};\\\", \\\"{x:1640,y:866,t:1527614086540};\\\", \\\"{x:1638,y:868,t:1527614086558};\\\", \\\"{x:1635,y:870,t:1527614086572};\\\", \\\"{x:1632,y:871,t:1527614086590};\\\", \\\"{x:1630,y:873,t:1527614086607};\\\", \\\"{x:1627,y:876,t:1527614086623};\\\", \\\"{x:1622,y:879,t:1527614086640};\\\", \\\"{x:1619,y:882,t:1527614086657};\\\", \\\"{x:1616,y:884,t:1527614086673};\\\", \\\"{x:1611,y:887,t:1527614086689};\\\", \\\"{x:1606,y:890,t:1527614086707};\\\", \\\"{x:1598,y:892,t:1527614086724};\\\", \\\"{x:1589,y:895,t:1527614086739};\\\", \\\"{x:1577,y:899,t:1527614086756};\\\", \\\"{x:1572,y:900,t:1527614086774};\\\", \\\"{x:1567,y:900,t:1527614086791};\\\", \\\"{x:1560,y:901,t:1527614086807};\\\", \\\"{x:1552,y:903,t:1527614086824};\\\", \\\"{x:1544,y:904,t:1527614086839};\\\", \\\"{x:1536,y:907,t:1527614086857};\\\", \\\"{x:1533,y:907,t:1527614086874};\\\", \\\"{x:1527,y:908,t:1527614086889};\\\", \\\"{x:1519,y:909,t:1527614086907};\\\", \\\"{x:1512,y:909,t:1527614086924};\\\", \\\"{x:1502,y:911,t:1527614086940};\\\", \\\"{x:1494,y:911,t:1527614086958};\\\", \\\"{x:1487,y:911,t:1527614086974};\\\", \\\"{x:1481,y:911,t:1527614086991};\\\", \\\"{x:1478,y:911,t:1527614087007};\\\", \\\"{x:1470,y:911,t:1527614087024};\\\", \\\"{x:1461,y:908,t:1527614087040};\\\", \\\"{x:1452,y:903,t:1527614087057};\\\", \\\"{x:1441,y:897,t:1527614087075};\\\", \\\"{x:1434,y:893,t:1527614087090};\\\", \\\"{x:1428,y:887,t:1527614087107};\\\", \\\"{x:1421,y:876,t:1527614087125};\\\", \\\"{x:1410,y:862,t:1527614087141};\\\", \\\"{x:1406,y:855,t:1527614087157};\\\", \\\"{x:1403,y:848,t:1527614087174};\\\", \\\"{x:1401,y:844,t:1527614087191};\\\", \\\"{x:1399,y:838,t:1527614087207};\\\", \\\"{x:1397,y:833,t:1527614087223};\\\", \\\"{x:1396,y:832,t:1527614087248};\\\", \\\"{x:1395,y:830,t:1527614087272};\\\", \\\"{x:1394,y:829,t:1527614087288};\\\", \\\"{x:1394,y:828,t:1527614087304};\\\", \\\"{x:1392,y:828,t:1527614087336};\\\", \\\"{x:1391,y:827,t:1527614087352};\\\", \\\"{x:1390,y:827,t:1527614087385};\\\", \\\"{x:1389,y:827,t:1527614087416};\\\", \\\"{x:1388,y:826,t:1527614090505};\\\", \\\"{x:1388,y:815,t:1527614090512};\\\", \\\"{x:1388,y:792,t:1527614090527};\\\", \\\"{x:1388,y:759,t:1527614090544};\\\", \\\"{x:1387,y:741,t:1527614090560};\\\", \\\"{x:1386,y:735,t:1527614090576};\\\", \\\"{x:1386,y:734,t:1527614090600};\\\", \\\"{x:1386,y:733,t:1527614090640};\\\", \\\"{x:1385,y:732,t:1527614090656};\\\", \\\"{x:1384,y:731,t:1527614090673};\\\", \\\"{x:1384,y:730,t:1527614090688};\\\", \\\"{x:1383,y:729,t:1527614090696};\\\", \\\"{x:1382,y:728,t:1527614090710};\\\", \\\"{x:1381,y:726,t:1527614090726};\\\", \\\"{x:1380,y:725,t:1527614090742};\\\", \\\"{x:1380,y:722,t:1527614090759};\\\", \\\"{x:1378,y:719,t:1527614090776};\\\", \\\"{x:1378,y:716,t:1527614090792};\\\", \\\"{x:1378,y:713,t:1527614090810};\\\", \\\"{x:1378,y:712,t:1527614090826};\\\", \\\"{x:1378,y:710,t:1527614090847};\\\", \\\"{x:1379,y:709,t:1527614090863};\\\", \\\"{x:1379,y:708,t:1527614090880};\\\", \\\"{x:1381,y:706,t:1527614090894};\\\", \\\"{x:1383,y:705,t:1527614090910};\\\", \\\"{x:1385,y:703,t:1527614090928};\\\", \\\"{x:1386,y:702,t:1527614090943};\\\", \\\"{x:1388,y:700,t:1527614090960};\\\", \\\"{x:1389,y:699,t:1527614091017};\\\", \\\"{x:1390,y:699,t:1527614091129};\\\", \\\"{x:1390,y:698,t:1527614091232};\\\", \\\"{x:1391,y:698,t:1527614091369};\\\", \\\"{x:1396,y:697,t:1527614091378};\\\", \\\"{x:1406,y:692,t:1527614091394};\\\", \\\"{x:1412,y:690,t:1527614091411};\\\", \\\"{x:1418,y:687,t:1527614091427};\\\", \\\"{x:1420,y:686,t:1527614091444};\\\", \\\"{x:1422,y:686,t:1527614091461};\\\", \\\"{x:1422,y:687,t:1527614091857};\\\", \\\"{x:1418,y:690,t:1527614091864};\\\", \\\"{x:1414,y:695,t:1527614091878};\\\", \\\"{x:1410,y:699,t:1527614091895};\\\", \\\"{x:1407,y:704,t:1527614091912};\\\", \\\"{x:1404,y:705,t:1527614091928};\\\", \\\"{x:1399,y:708,t:1527614091945};\\\", \\\"{x:1396,y:708,t:1527614091962};\\\", \\\"{x:1392,y:709,t:1527614091978};\\\", \\\"{x:1388,y:711,t:1527614091995};\\\", \\\"{x:1386,y:712,t:1527614092032};\\\", \\\"{x:1385,y:712,t:1527614092044};\\\", \\\"{x:1382,y:713,t:1527614092064};\\\", \\\"{x:1380,y:714,t:1527614092077};\\\", \\\"{x:1374,y:716,t:1527614092094};\\\", \\\"{x:1365,y:720,t:1527614092112};\\\", \\\"{x:1358,y:724,t:1527614092128};\\\", \\\"{x:1347,y:730,t:1527614092144};\\\", \\\"{x:1334,y:739,t:1527614092161};\\\", \\\"{x:1318,y:750,t:1527614092177};\\\", \\\"{x:1301,y:763,t:1527614092194};\\\", \\\"{x:1282,y:779,t:1527614092211};\\\", \\\"{x:1263,y:790,t:1527614092227};\\\", \\\"{x:1249,y:798,t:1527614092244};\\\", \\\"{x:1241,y:803,t:1527614092261};\\\", \\\"{x:1240,y:804,t:1527614092384};\\\", \\\"{x:1239,y:804,t:1527614092407};\\\", \\\"{x:1239,y:806,t:1527614092416};\\\", \\\"{x:1239,y:811,t:1527614092429};\\\", \\\"{x:1239,y:823,t:1527614092444};\\\", \\\"{x:1237,y:828,t:1527614092461};\\\", \\\"{x:1237,y:832,t:1527614092479};\\\", \\\"{x:1237,y:833,t:1527614092494};\\\", \\\"{x:1237,y:834,t:1527614092511};\\\", \\\"{x:1237,y:835,t:1527614092552};\\\", \\\"{x:1235,y:835,t:1527614092793};\\\", \\\"{x:1234,y:835,t:1527614092808};\\\", \\\"{x:1233,y:835,t:1527614092816};\\\", \\\"{x:1232,y:835,t:1527614092840};\\\", \\\"{x:1234,y:835,t:1527614093153};\\\", \\\"{x:1235,y:835,t:1527614093162};\\\", \\\"{x:1244,y:839,t:1527614093178};\\\", \\\"{x:1256,y:843,t:1527614093196};\\\", \\\"{x:1259,y:845,t:1527614093212};\\\", \\\"{x:1261,y:845,t:1527614093229};\\\", \\\"{x:1263,y:845,t:1527614093245};\\\", \\\"{x:1264,y:845,t:1527614093262};\\\", \\\"{x:1266,y:843,t:1527614093278};\\\", \\\"{x:1274,y:836,t:1527614093296};\\\", \\\"{x:1278,y:833,t:1527614093312};\\\", \\\"{x:1281,y:831,t:1527614093328};\\\", \\\"{x:1284,y:828,t:1527614093346};\\\", \\\"{x:1285,y:828,t:1527614093363};\\\", \\\"{x:1285,y:827,t:1527614093384};\\\", \\\"{x:1285,y:826,t:1527614093409};\\\", \\\"{x:1288,y:825,t:1527614093520};\\\", \\\"{x:1291,y:825,t:1527614093528};\\\", \\\"{x:1294,y:826,t:1527614093546};\\\", \\\"{x:1298,y:826,t:1527614093563};\\\", \\\"{x:1302,y:828,t:1527614093579};\\\", \\\"{x:1303,y:828,t:1527614093596};\\\", \\\"{x:1304,y:829,t:1527614093613};\\\", \\\"{x:1306,y:829,t:1527614093656};\\\", \\\"{x:1307,y:829,t:1527614093664};\\\", \\\"{x:1312,y:829,t:1527614093679};\\\", \\\"{x:1320,y:828,t:1527614093696};\\\", \\\"{x:1336,y:825,t:1527614093712};\\\", \\\"{x:1342,y:822,t:1527614093729};\\\", \\\"{x:1349,y:818,t:1527614093745};\\\", \\\"{x:1352,y:813,t:1527614093762};\\\", \\\"{x:1354,y:809,t:1527614093778};\\\", \\\"{x:1354,y:804,t:1527614093795};\\\", \\\"{x:1354,y:802,t:1527614093813};\\\", \\\"{x:1354,y:800,t:1527614093856};\\\", \\\"{x:1352,y:800,t:1527614093888};\\\", \\\"{x:1349,y:800,t:1527614093913};\\\", \\\"{x:1343,y:800,t:1527614093929};\\\", \\\"{x:1331,y:802,t:1527614093945};\\\", \\\"{x:1318,y:805,t:1527614093962};\\\", \\\"{x:1302,y:807,t:1527614093980};\\\", \\\"{x:1282,y:809,t:1527614093996};\\\", \\\"{x:1267,y:809,t:1527614094012};\\\", \\\"{x:1257,y:809,t:1527614094029};\\\", \\\"{x:1248,y:807,t:1527614094045};\\\", \\\"{x:1240,y:804,t:1527614094062};\\\", \\\"{x:1237,y:802,t:1527614094079};\\\", \\\"{x:1234,y:800,t:1527614094095};\\\", \\\"{x:1231,y:798,t:1527614094112};\\\", \\\"{x:1226,y:794,t:1527614094129};\\\", \\\"{x:1219,y:788,t:1527614094146};\\\", \\\"{x:1216,y:785,t:1527614094162};\\\", \\\"{x:1213,y:782,t:1527614094179};\\\", \\\"{x:1213,y:781,t:1527614094195};\\\", \\\"{x:1212,y:780,t:1527614094212};\\\", \\\"{x:1211,y:779,t:1527614094239};\\\", \\\"{x:1210,y:779,t:1527614094296};\\\", \\\"{x:1207,y:777,t:1527614094313};\\\", \\\"{x:1206,y:777,t:1527614094329};\\\", \\\"{x:1204,y:776,t:1527614094347};\\\", \\\"{x:1202,y:775,t:1527614094363};\\\", \\\"{x:1199,y:774,t:1527614094379};\\\", \\\"{x:1196,y:772,t:1527614094396};\\\", \\\"{x:1194,y:772,t:1527614094412};\\\", \\\"{x:1200,y:771,t:1527614094721};\\\", \\\"{x:1211,y:771,t:1527614094730};\\\", \\\"{x:1230,y:768,t:1527614094746};\\\", \\\"{x:1247,y:767,t:1527614094764};\\\", \\\"{x:1261,y:764,t:1527614094780};\\\", \\\"{x:1279,y:762,t:1527614094796};\\\", \\\"{x:1299,y:756,t:1527614094814};\\\", \\\"{x:1314,y:752,t:1527614094830};\\\", \\\"{x:1325,y:747,t:1527614094847};\\\", \\\"{x:1336,y:741,t:1527614094864};\\\", \\\"{x:1347,y:734,t:1527614094880};\\\", \\\"{x:1353,y:732,t:1527614094896};\\\", \\\"{x:1357,y:729,t:1527614094914};\\\", \\\"{x:1361,y:726,t:1527614094930};\\\", \\\"{x:1365,y:724,t:1527614094947};\\\", \\\"{x:1367,y:721,t:1527614094964};\\\", \\\"{x:1372,y:717,t:1527614094980};\\\", \\\"{x:1375,y:714,t:1527614094996};\\\", \\\"{x:1377,y:711,t:1527614095014};\\\", \\\"{x:1378,y:709,t:1527614095029};\\\", \\\"{x:1378,y:708,t:1527614095047};\\\", \\\"{x:1379,y:707,t:1527614095105};\\\", \\\"{x:1380,y:705,t:1527614095114};\\\", \\\"{x:1383,y:699,t:1527614095130};\\\", \\\"{x:1384,y:695,t:1527614095146};\\\", \\\"{x:1386,y:693,t:1527614095163};\\\", \\\"{x:1387,y:689,t:1527614095179};\\\", \\\"{x:1388,y:689,t:1527614095196};\\\", \\\"{x:1388,y:687,t:1527614095213};\\\", \\\"{x:1384,y:685,t:1527614095465};\\\", \\\"{x:1366,y:684,t:1527614095480};\\\", \\\"{x:1351,y:684,t:1527614095497};\\\", \\\"{x:1345,y:684,t:1527614095514};\\\", \\\"{x:1343,y:683,t:1527614095530};\\\", \\\"{x:1342,y:683,t:1527614095705};\\\", \\\"{x:1342,y:685,t:1527614095737};\\\", \\\"{x:1342,y:688,t:1527614095748};\\\", \\\"{x:1340,y:692,t:1527614095764};\\\", \\\"{x:1339,y:696,t:1527614095780};\\\", \\\"{x:1339,y:697,t:1527614095798};\\\", \\\"{x:1337,y:700,t:1527614095813};\\\", \\\"{x:1337,y:701,t:1527614095830};\\\", \\\"{x:1337,y:702,t:1527614095879};\\\", \\\"{x:1338,y:704,t:1527614096184};\\\", \\\"{x:1339,y:704,t:1527614096198};\\\", \\\"{x:1340,y:704,t:1527614096214};\\\", \\\"{x:1342,y:705,t:1527614096230};\\\", \\\"{x:1346,y:708,t:1527614096247};\\\", \\\"{x:1347,y:708,t:1527614096263};\\\", \\\"{x:1348,y:709,t:1527614096280};\\\", \\\"{x:1350,y:710,t:1527614096297};\\\", \\\"{x:1354,y:711,t:1527614096314};\\\", \\\"{x:1361,y:711,t:1527614096330};\\\", \\\"{x:1368,y:711,t:1527614096347};\\\", \\\"{x:1373,y:711,t:1527614096364};\\\", \\\"{x:1380,y:711,t:1527614096380};\\\", \\\"{x:1383,y:711,t:1527614096398};\\\", \\\"{x:1385,y:711,t:1527614096414};\\\", \\\"{x:1388,y:711,t:1527614096430};\\\", \\\"{x:1389,y:709,t:1527614096448};\\\", \\\"{x:1392,y:707,t:1527614096464};\\\", \\\"{x:1395,y:704,t:1527614096481};\\\", \\\"{x:1399,y:701,t:1527614096498};\\\", \\\"{x:1400,y:700,t:1527614096514};\\\", \\\"{x:1401,y:699,t:1527614096531};\\\", \\\"{x:1405,y:696,t:1527614096547};\\\", \\\"{x:1405,y:695,t:1527614096564};\\\", \\\"{x:1407,y:693,t:1527614096581};\\\", \\\"{x:1408,y:690,t:1527614096600};\\\", \\\"{x:1409,y:690,t:1527614096616};\\\", \\\"{x:1409,y:689,t:1527614096631};\\\", \\\"{x:1410,y:686,t:1527614096648};\\\", \\\"{x:1411,y:686,t:1527614096664};\\\", \\\"{x:1412,y:686,t:1527614096760};\\\", \\\"{x:1414,y:686,t:1527614096768};\\\", \\\"{x:1416,y:689,t:1527614096782};\\\", \\\"{x:1419,y:692,t:1527614096797};\\\", \\\"{x:1422,y:696,t:1527614096814};\\\", \\\"{x:1427,y:700,t:1527614096832};\\\", \\\"{x:1433,y:702,t:1527614096848};\\\", \\\"{x:1444,y:706,t:1527614096865};\\\", \\\"{x:1451,y:707,t:1527614096882};\\\", \\\"{x:1464,y:707,t:1527614096897};\\\", \\\"{x:1472,y:707,t:1527614096915};\\\", \\\"{x:1477,y:707,t:1527614096931};\\\", \\\"{x:1480,y:707,t:1527614096948};\\\", \\\"{x:1482,y:706,t:1527614096965};\\\", \\\"{x:1484,y:704,t:1527614096981};\\\", \\\"{x:1485,y:703,t:1527614096998};\\\", \\\"{x:1489,y:699,t:1527614097015};\\\", \\\"{x:1490,y:698,t:1527614097032};\\\", \\\"{x:1491,y:698,t:1527614097047};\\\", \\\"{x:1491,y:700,t:1527614097153};\\\", \\\"{x:1494,y:706,t:1527614097165};\\\", \\\"{x:1496,y:710,t:1527614097181};\\\", \\\"{x:1496,y:712,t:1527614097199};\\\", \\\"{x:1498,y:713,t:1527614097215};\\\", \\\"{x:1500,y:713,t:1527614097248};\\\", \\\"{x:1507,y:713,t:1527614097265};\\\", \\\"{x:1520,y:710,t:1527614097282};\\\", \\\"{x:1531,y:705,t:1527614097298};\\\", \\\"{x:1546,y:698,t:1527614097315};\\\", \\\"{x:1559,y:695,t:1527614097332};\\\", \\\"{x:1564,y:693,t:1527614097348};\\\", \\\"{x:1569,y:690,t:1527614097365};\\\", \\\"{x:1572,y:689,t:1527614097381};\\\", \\\"{x:1579,y:685,t:1527614097399};\\\", \\\"{x:1580,y:684,t:1527614097415};\\\", \\\"{x:1581,y:684,t:1527614097432};\\\", \\\"{x:1579,y:684,t:1527614097544};\\\", \\\"{x:1573,y:683,t:1527614097552};\\\", \\\"{x:1567,y:683,t:1527614097566};\\\", \\\"{x:1552,y:680,t:1527614097582};\\\", \\\"{x:1535,y:678,t:1527614097599};\\\", \\\"{x:1512,y:674,t:1527614097615};\\\", \\\"{x:1500,y:673,t:1527614097631};\\\", \\\"{x:1481,y:669,t:1527614097648};\\\", \\\"{x:1462,y:667,t:1527614097665};\\\", \\\"{x:1445,y:664,t:1527614097681};\\\", \\\"{x:1439,y:663,t:1527614097698};\\\", \\\"{x:1436,y:663,t:1527614097716};\\\", \\\"{x:1435,y:661,t:1527614098528};\\\", \\\"{x:1437,y:655,t:1527614098536};\\\", \\\"{x:1438,y:652,t:1527614098549};\\\", \\\"{x:1441,y:644,t:1527614098566};\\\", \\\"{x:1442,y:639,t:1527614098583};\\\", \\\"{x:1443,y:637,t:1527614098600};\\\", \\\"{x:1443,y:636,t:1527614098616};\\\", \\\"{x:1443,y:635,t:1527614098633};\\\", \\\"{x:1444,y:635,t:1527614098833};\\\", \\\"{x:1447,y:635,t:1527614098881};\\\", \\\"{x:1455,y:637,t:1527614098901};\\\", \\\"{x:1462,y:638,t:1527614098916};\\\", \\\"{x:1475,y:642,t:1527614098933};\\\", \\\"{x:1483,y:645,t:1527614098950};\\\", \\\"{x:1490,y:648,t:1527614098966};\\\", \\\"{x:1491,y:649,t:1527614098983};\\\", \\\"{x:1492,y:650,t:1527614099000};\\\", \\\"{x:1492,y:651,t:1527614099040};\\\", \\\"{x:1493,y:652,t:1527614099050};\\\", \\\"{x:1494,y:653,t:1527614099067};\\\", \\\"{x:1496,y:658,t:1527614099083};\\\", \\\"{x:1499,y:662,t:1527614099100};\\\", \\\"{x:1503,y:667,t:1527614099117};\\\", \\\"{x:1506,y:671,t:1527614099133};\\\", \\\"{x:1511,y:678,t:1527614099150};\\\", \\\"{x:1514,y:684,t:1527614099167};\\\", \\\"{x:1516,y:691,t:1527614099183};\\\", \\\"{x:1520,y:705,t:1527614099200};\\\", \\\"{x:1523,y:719,t:1527614099216};\\\", \\\"{x:1525,y:735,t:1527614099233};\\\", \\\"{x:1525,y:754,t:1527614099250};\\\", \\\"{x:1527,y:776,t:1527614099267};\\\", \\\"{x:1530,y:792,t:1527614099283};\\\", \\\"{x:1531,y:806,t:1527614099300};\\\", \\\"{x:1531,y:824,t:1527614099316};\\\", \\\"{x:1531,y:839,t:1527614099333};\\\", \\\"{x:1531,y:852,t:1527614099350};\\\", \\\"{x:1529,y:859,t:1527614099367};\\\", \\\"{x:1528,y:872,t:1527614099383};\\\", \\\"{x:1527,y:881,t:1527614099400};\\\", \\\"{x:1527,y:884,t:1527614099416};\\\", \\\"{x:1527,y:885,t:1527614099433};\\\", \\\"{x:1526,y:887,t:1527614099456};\\\", \\\"{x:1526,y:888,t:1527614099480};\\\", \\\"{x:1526,y:890,t:1527614099488};\\\", \\\"{x:1526,y:891,t:1527614099504};\\\", \\\"{x:1526,y:892,t:1527614099517};\\\", \\\"{x:1526,y:893,t:1527614099534};\\\", \\\"{x:1526,y:894,t:1527614099616};\\\", \\\"{x:1526,y:895,t:1527614099648};\\\", \\\"{x:1526,y:896,t:1527614099657};\\\", \\\"{x:1526,y:895,t:1527614100792};\\\", \\\"{x:1525,y:886,t:1527614100800};\\\", \\\"{x:1518,y:868,t:1527614100818};\\\", \\\"{x:1510,y:850,t:1527614100834};\\\", \\\"{x:1505,y:840,t:1527614100851};\\\", \\\"{x:1500,y:831,t:1527614100868};\\\", \\\"{x:1495,y:825,t:1527614100884};\\\", \\\"{x:1492,y:820,t:1527614100901};\\\", \\\"{x:1488,y:818,t:1527614100918};\\\", \\\"{x:1479,y:814,t:1527614100935};\\\", \\\"{x:1457,y:810,t:1527614100951};\\\", \\\"{x:1425,y:794,t:1527614100968};\\\", \\\"{x:1421,y:794,t:1527614100985};\\\", \\\"{x:1395,y:792,t:1527614101001};\\\", \\\"{x:1393,y:791,t:1527614101019};\\\", \\\"{x:1393,y:789,t:1527614101040};\\\", \\\"{x:1392,y:789,t:1527614101051};\\\", \\\"{x:1392,y:787,t:1527614101120};\\\", \\\"{x:1392,y:786,t:1527614101136};\\\", \\\"{x:1392,y:785,t:1527614101151};\\\", \\\"{x:1392,y:773,t:1527614101168};\\\", \\\"{x:1393,y:765,t:1527614101184};\\\", \\\"{x:1395,y:750,t:1527614101201};\\\", \\\"{x:1399,y:729,t:1527614101217};\\\", \\\"{x:1401,y:707,t:1527614101234};\\\", \\\"{x:1404,y:687,t:1527614101250};\\\", \\\"{x:1406,y:668,t:1527614101267};\\\", \\\"{x:1409,y:653,t:1527614101284};\\\", \\\"{x:1411,y:640,t:1527614101301};\\\", \\\"{x:1411,y:635,t:1527614101317};\\\", \\\"{x:1413,y:631,t:1527614101334};\\\", \\\"{x:1413,y:629,t:1527614101351};\\\", \\\"{x:1413,y:627,t:1527614101367};\\\", \\\"{x:1413,y:626,t:1527614101384};\\\", \\\"{x:1413,y:624,t:1527614101401};\\\", \\\"{x:1413,y:622,t:1527614101418};\\\", \\\"{x:1413,y:621,t:1527614101434};\\\", \\\"{x:1413,y:619,t:1527614101451};\\\", \\\"{x:1413,y:618,t:1527614101468};\\\", \\\"{x:1411,y:617,t:1527614101485};\\\", \\\"{x:1409,y:617,t:1527614101504};\\\", \\\"{x:1409,y:616,t:1527614101518};\\\", \\\"{x:1407,y:615,t:1527614101534};\\\", \\\"{x:1403,y:615,t:1527614101552};\\\", \\\"{x:1400,y:613,t:1527614101568};\\\", \\\"{x:1398,y:612,t:1527614101585};\\\", \\\"{x:1395,y:610,t:1527614101602};\\\", \\\"{x:1388,y:605,t:1527614101618};\\\", \\\"{x:1381,y:601,t:1527614101635};\\\", \\\"{x:1370,y:596,t:1527614101652};\\\", \\\"{x:1353,y:589,t:1527614101668};\\\", \\\"{x:1347,y:584,t:1527614101685};\\\", \\\"{x:1340,y:580,t:1527614101702};\\\", \\\"{x:1337,y:577,t:1527614101718};\\\", \\\"{x:1336,y:576,t:1527614101735};\\\", \\\"{x:1335,y:573,t:1527614101752};\\\", \\\"{x:1334,y:572,t:1527614101768};\\\", \\\"{x:1334,y:571,t:1527614101800};\\\", \\\"{x:1334,y:569,t:1527614101832};\\\", \\\"{x:1334,y:567,t:1527614101856};\\\", \\\"{x:1334,y:566,t:1527614101880};\\\", \\\"{x:1334,y:565,t:1527614101896};\\\", \\\"{x:1334,y:564,t:1527614101928};\\\", \\\"{x:1338,y:560,t:1527614101968};\\\", \\\"{x:1339,y:558,t:1527614101985};\\\", \\\"{x:1341,y:558,t:1527614102008};\\\", \\\"{x:1342,y:557,t:1527614102064};\\\", \\\"{x:1343,y:557,t:1527614102088};\\\", \\\"{x:1344,y:557,t:1527614102136};\\\", \\\"{x:1346,y:557,t:1527614102368};\\\", \\\"{x:1364,y:557,t:1527614102386};\\\", \\\"{x:1395,y:566,t:1527614102402};\\\", \\\"{x:1421,y:573,t:1527614102419};\\\", \\\"{x:1450,y:582,t:1527614102436};\\\", \\\"{x:1471,y:590,t:1527614102452};\\\", \\\"{x:1482,y:598,t:1527614102469};\\\", \\\"{x:1484,y:599,t:1527614102486};\\\", \\\"{x:1484,y:598,t:1527614102656};\\\", \\\"{x:1483,y:595,t:1527614102669};\\\", \\\"{x:1477,y:590,t:1527614102686};\\\", \\\"{x:1472,y:583,t:1527614102702};\\\", \\\"{x:1470,y:580,t:1527614102718};\\\", \\\"{x:1467,y:578,t:1527614102736};\\\", \\\"{x:1466,y:577,t:1527614102752};\\\", \\\"{x:1465,y:576,t:1527614102769};\\\", \\\"{x:1464,y:575,t:1527614102786};\\\", \\\"{x:1463,y:575,t:1527614102802};\\\", \\\"{x:1462,y:575,t:1527614102848};\\\", \\\"{x:1459,y:575,t:1527614102856};\\\", \\\"{x:1456,y:576,t:1527614102869};\\\", \\\"{x:1448,y:581,t:1527614102886};\\\", \\\"{x:1441,y:586,t:1527614102903};\\\", \\\"{x:1435,y:593,t:1527614102919};\\\", \\\"{x:1436,y:593,t:1527614103000};\\\", \\\"{x:1443,y:590,t:1527614103008};\\\", \\\"{x:1446,y:587,t:1527614103019};\\\", \\\"{x:1455,y:581,t:1527614103036};\\\", \\\"{x:1462,y:573,t:1527614103053};\\\", \\\"{x:1469,y:568,t:1527614103069};\\\", \\\"{x:1476,y:564,t:1527614103086};\\\", \\\"{x:1477,y:564,t:1527614103103};\\\", \\\"{x:1478,y:566,t:1527614103241};\\\", \\\"{x:1479,y:571,t:1527614103253};\\\", \\\"{x:1482,y:578,t:1527614103270};\\\", \\\"{x:1485,y:583,t:1527614103286};\\\", \\\"{x:1489,y:587,t:1527614103303};\\\", \\\"{x:1496,y:589,t:1527614103320};\\\", \\\"{x:1500,y:589,t:1527614103336};\\\", \\\"{x:1503,y:589,t:1527614103353};\\\", \\\"{x:1507,y:589,t:1527614103370};\\\", \\\"{x:1511,y:589,t:1527614103386};\\\", \\\"{x:1518,y:584,t:1527614103403};\\\", \\\"{x:1524,y:581,t:1527614103420};\\\", \\\"{x:1529,y:577,t:1527614103436};\\\", \\\"{x:1536,y:568,t:1527614103453};\\\", \\\"{x:1540,y:563,t:1527614103470};\\\", \\\"{x:1542,y:560,t:1527614103486};\\\", \\\"{x:1544,y:557,t:1527614103503};\\\", \\\"{x:1545,y:556,t:1527614103520};\\\", \\\"{x:1545,y:560,t:1527614103640};\\\", \\\"{x:1545,y:565,t:1527614103653};\\\", \\\"{x:1545,y:570,t:1527614103670};\\\", \\\"{x:1548,y:575,t:1527614103686};\\\", \\\"{x:1549,y:578,t:1527614103703};\\\", \\\"{x:1552,y:581,t:1527614103720};\\\", \\\"{x:1554,y:581,t:1527614103736};\\\", \\\"{x:1555,y:581,t:1527614103753};\\\", \\\"{x:1569,y:580,t:1527614103770};\\\", \\\"{x:1582,y:577,t:1527614103787};\\\", \\\"{x:1591,y:572,t:1527614103803};\\\", \\\"{x:1599,y:568,t:1527614103820};\\\", \\\"{x:1605,y:565,t:1527614103837};\\\", \\\"{x:1610,y:560,t:1527614103853};\\\", \\\"{x:1613,y:558,t:1527614103870};\\\", \\\"{x:1614,y:554,t:1527614103887};\\\", \\\"{x:1615,y:554,t:1527614103903};\\\", \\\"{x:1617,y:551,t:1527614103920};\\\", \\\"{x:1617,y:556,t:1527614104031};\\\", \\\"{x:1620,y:562,t:1527614104039};\\\", \\\"{x:1620,y:566,t:1527614104052};\\\", \\\"{x:1623,y:578,t:1527614104070};\\\", \\\"{x:1625,y:588,t:1527614104086};\\\", \\\"{x:1629,y:597,t:1527614104102};\\\", \\\"{x:1634,y:604,t:1527614104119};\\\", \\\"{x:1638,y:604,t:1527614104137};\\\", \\\"{x:1644,y:604,t:1527614104154};\\\", \\\"{x:1650,y:603,t:1527614104170};\\\", \\\"{x:1660,y:595,t:1527614104187};\\\", \\\"{x:1671,y:586,t:1527614104203};\\\", \\\"{x:1682,y:574,t:1527614104220};\\\", \\\"{x:1688,y:565,t:1527614104237};\\\", \\\"{x:1691,y:557,t:1527614104254};\\\", \\\"{x:1696,y:548,t:1527614104270};\\\", \\\"{x:1697,y:546,t:1527614104287};\\\", \\\"{x:1698,y:544,t:1527614104303};\\\", \\\"{x:1698,y:545,t:1527614104449};\\\", \\\"{x:1697,y:547,t:1527614104456};\\\", \\\"{x:1697,y:549,t:1527614104470};\\\", \\\"{x:1696,y:551,t:1527614104487};\\\", \\\"{x:1692,y:555,t:1527614104504};\\\", \\\"{x:1690,y:556,t:1527614104520};\\\", \\\"{x:1686,y:559,t:1527614104537};\\\", \\\"{x:1680,y:563,t:1527614104554};\\\", \\\"{x:1669,y:569,t:1527614104571};\\\", \\\"{x:1656,y:579,t:1527614104587};\\\", \\\"{x:1636,y:590,t:1527614104604};\\\", \\\"{x:1614,y:603,t:1527614104621};\\\", \\\"{x:1585,y:619,t:1527614104637};\\\", \\\"{x:1562,y:631,t:1527614104654};\\\", \\\"{x:1540,y:646,t:1527614104671};\\\", \\\"{x:1522,y:656,t:1527614104686};\\\", \\\"{x:1498,y:672,t:1527614104704};\\\", \\\"{x:1492,y:679,t:1527614104720};\\\", \\\"{x:1488,y:684,t:1527614104736};\\\", \\\"{x:1487,y:686,t:1527614104767};\\\", \\\"{x:1487,y:687,t:1527614104791};\\\", \\\"{x:1487,y:688,t:1527614106072};\\\", \\\"{x:1490,y:712,t:1527614106088};\\\", \\\"{x:1498,y:744,t:1527614106106};\\\", \\\"{x:1504,y:779,t:1527614106123};\\\", \\\"{x:1510,y:814,t:1527614106139};\\\", \\\"{x:1515,y:836,t:1527614106156};\\\", \\\"{x:1518,y:852,t:1527614106172};\\\", \\\"{x:1520,y:860,t:1527614106189};\\\", \\\"{x:1520,y:863,t:1527614106205};\\\", \\\"{x:1520,y:865,t:1527614106221};\\\", \\\"{x:1520,y:871,t:1527614106237};\\\", \\\"{x:1520,y:880,t:1527614106254};\\\", \\\"{x:1521,y:907,t:1527614106271};\\\", \\\"{x:1522,y:922,t:1527614106287};\\\", \\\"{x:1522,y:934,t:1527614106304};\\\", \\\"{x:1522,y:945,t:1527614106321};\\\", \\\"{x:1522,y:953,t:1527614106338};\\\", \\\"{x:1522,y:957,t:1527614106355};\\\", \\\"{x:1520,y:961,t:1527614106371};\\\", \\\"{x:1520,y:967,t:1527614106387};\\\", \\\"{x:1519,y:971,t:1527614106405};\\\", \\\"{x:1517,y:974,t:1527614106422};\\\", \\\"{x:1516,y:979,t:1527614106437};\\\", \\\"{x:1515,y:982,t:1527614106455};\\\", \\\"{x:1513,y:986,t:1527614106472};\\\", \\\"{x:1513,y:987,t:1527614106487};\\\", \\\"{x:1513,y:989,t:1527614106505};\\\", \\\"{x:1512,y:990,t:1527614106521};\\\", \\\"{x:1511,y:991,t:1527614106584};\\\", \\\"{x:1510,y:991,t:1527614106600};\\\", \\\"{x:1509,y:991,t:1527614106648};\\\", \\\"{x:1508,y:991,t:1527614106680};\\\", \\\"{x:1507,y:991,t:1527614106695};\\\", \\\"{x:1507,y:992,t:1527614106705};\\\", \\\"{x:1508,y:992,t:1527614106800};\\\", \\\"{x:1511,y:992,t:1527614106808};\\\", \\\"{x:1517,y:992,t:1527614106822};\\\", \\\"{x:1525,y:987,t:1527614106839};\\\", \\\"{x:1533,y:983,t:1527614106855};\\\", \\\"{x:1542,y:974,t:1527614106872};\\\", \\\"{x:1543,y:973,t:1527614106889};\\\", \\\"{x:1544,y:971,t:1527614107081};\\\", \\\"{x:1546,y:968,t:1527614107264};\\\", \\\"{x:1546,y:967,t:1527614107272};\\\", \\\"{x:1546,y:964,t:1527614107289};\\\", \\\"{x:1546,y:963,t:1527614107306};\\\", \\\"{x:1546,y:961,t:1527614107322};\\\", \\\"{x:1546,y:960,t:1527614107520};\\\", \\\"{x:1546,y:959,t:1527614107536};\\\", \\\"{x:1546,y:958,t:1527614107560};\\\", \\\"{x:1546,y:957,t:1527614107584};\\\", \\\"{x:1546,y:956,t:1527614107591};\\\", \\\"{x:1546,y:955,t:1527614107606};\\\", \\\"{x:1546,y:953,t:1527614107623};\\\", \\\"{x:1546,y:949,t:1527614107639};\\\", \\\"{x:1546,y:946,t:1527614107656};\\\", \\\"{x:1545,y:945,t:1527614107673};\\\", \\\"{x:1545,y:944,t:1527614107690};\\\", \\\"{x:1544,y:942,t:1527614107712};\\\", \\\"{x:1543,y:941,t:1527614107744};\\\", \\\"{x:1543,y:940,t:1527614107768};\\\", \\\"{x:1543,y:939,t:1527614107776};\\\", \\\"{x:1543,y:938,t:1527614107792};\\\", \\\"{x:1543,y:937,t:1527614107807};\\\", \\\"{x:1542,y:935,t:1527614107823};\\\", \\\"{x:1542,y:932,t:1527614107839};\\\", \\\"{x:1542,y:928,t:1527614107856};\\\", \\\"{x:1542,y:924,t:1527614107873};\\\", \\\"{x:1542,y:922,t:1527614107890};\\\", \\\"{x:1542,y:918,t:1527614107906};\\\", \\\"{x:1542,y:913,t:1527614107923};\\\", \\\"{x:1542,y:910,t:1527614107940};\\\", \\\"{x:1542,y:905,t:1527614107956};\\\", \\\"{x:1543,y:902,t:1527614107973};\\\", \\\"{x:1544,y:897,t:1527614107991};\\\", \\\"{x:1544,y:894,t:1527614108006};\\\", \\\"{x:1544,y:891,t:1527614108023};\\\", \\\"{x:1544,y:888,t:1527614108039};\\\", \\\"{x:1545,y:881,t:1527614108056};\\\", \\\"{x:1545,y:877,t:1527614108073};\\\", \\\"{x:1545,y:873,t:1527614108090};\\\", \\\"{x:1545,y:871,t:1527614108106};\\\", \\\"{x:1545,y:865,t:1527614108123};\\\", \\\"{x:1545,y:860,t:1527614108140};\\\", \\\"{x:1545,y:848,t:1527614108156};\\\", \\\"{x:1547,y:826,t:1527614108173};\\\", \\\"{x:1547,y:807,t:1527614108190};\\\", \\\"{x:1547,y:788,t:1527614108206};\\\", \\\"{x:1547,y:773,t:1527614108223};\\\", \\\"{x:1548,y:760,t:1527614108239};\\\", \\\"{x:1548,y:756,t:1527614108256};\\\", \\\"{x:1548,y:754,t:1527614108273};\\\", \\\"{x:1548,y:753,t:1527614108656};\\\", \\\"{x:1548,y:756,t:1527614108808};\\\", \\\"{x:1546,y:766,t:1527614108823};\\\", \\\"{x:1543,y:788,t:1527614108839};\\\", \\\"{x:1543,y:792,t:1527614108857};\\\", \\\"{x:1543,y:794,t:1527614108873};\\\", \\\"{x:1543,y:797,t:1527614108890};\\\", \\\"{x:1542,y:798,t:1527614108907};\\\", \\\"{x:1542,y:799,t:1527614108960};\\\", \\\"{x:1542,y:800,t:1527614108976};\\\", \\\"{x:1542,y:801,t:1527614108991};\\\", \\\"{x:1542,y:803,t:1527614109007};\\\", \\\"{x:1542,y:806,t:1527614109024};\\\", \\\"{x:1542,y:808,t:1527614109040};\\\", \\\"{x:1542,y:810,t:1527614109057};\\\", \\\"{x:1542,y:811,t:1527614109075};\\\", \\\"{x:1542,y:812,t:1527614109104};\\\", \\\"{x:1542,y:814,t:1527614109128};\\\", \\\"{x:1542,y:815,t:1527614109168};\\\", \\\"{x:1542,y:817,t:1527614109425};\\\", \\\"{x:1543,y:820,t:1527614109442};\\\", \\\"{x:1543,y:822,t:1527614109457};\\\", \\\"{x:1544,y:824,t:1527614109474};\\\", \\\"{x:1544,y:825,t:1527614109492};\\\", \\\"{x:1544,y:827,t:1527614109507};\\\", \\\"{x:1546,y:828,t:1527614109649};\\\", \\\"{x:1546,y:829,t:1527614109728};\\\", \\\"{x:1546,y:830,t:1527614109888};\\\", \\\"{x:1546,y:825,t:1527614111089};\\\", \\\"{x:1546,y:818,t:1527614111096};\\\", \\\"{x:1546,y:816,t:1527614111109};\\\", \\\"{x:1546,y:814,t:1527614111125};\\\", \\\"{x:1546,y:812,t:1527614111142};\\\", \\\"{x:1546,y:811,t:1527614111158};\\\", \\\"{x:1546,y:810,t:1527614111175};\\\", \\\"{x:1546,y:809,t:1527614111376};\\\", \\\"{x:1546,y:808,t:1527614111407};\\\", \\\"{x:1546,y:806,t:1527614111423};\\\", \\\"{x:1546,y:804,t:1527614111432};\\\", \\\"{x:1546,y:803,t:1527614111442};\\\", \\\"{x:1546,y:801,t:1527614111459};\\\", \\\"{x:1546,y:800,t:1527614111475};\\\", \\\"{x:1546,y:799,t:1527614111492};\\\", \\\"{x:1545,y:799,t:1527614111509};\\\", \\\"{x:1545,y:798,t:1527614111535};\\\", \\\"{x:1545,y:797,t:1527614111544};\\\", \\\"{x:1545,y:796,t:1527614111559};\\\", \\\"{x:1545,y:795,t:1527614111575};\\\", \\\"{x:1545,y:793,t:1527614111593};\\\", \\\"{x:1544,y:791,t:1527614111609};\\\", \\\"{x:1544,y:790,t:1527614111625};\\\", \\\"{x:1544,y:788,t:1527614111643};\\\", \\\"{x:1544,y:787,t:1527614111659};\\\", \\\"{x:1544,y:786,t:1527614111680};\\\", \\\"{x:1544,y:785,t:1527614111695};\\\", \\\"{x:1544,y:784,t:1527614111709};\\\", \\\"{x:1544,y:782,t:1527614111725};\\\", \\\"{x:1544,y:781,t:1527614111742};\\\", \\\"{x:1544,y:780,t:1527614111768};\\\", \\\"{x:1544,y:779,t:1527614111792};\\\", \\\"{x:1544,y:778,t:1527614111809};\\\", \\\"{x:1544,y:777,t:1527614111847};\\\", \\\"{x:1544,y:776,t:1527614111864};\\\", \\\"{x:1544,y:775,t:1527614111888};\\\", \\\"{x:1544,y:774,t:1527614111903};\\\", \\\"{x:1544,y:773,t:1527614111927};\\\", \\\"{x:1544,y:772,t:1527614111943};\\\", \\\"{x:1544,y:771,t:1527614111968};\\\", \\\"{x:1544,y:770,t:1527614111976};\\\", \\\"{x:1544,y:769,t:1527614111992};\\\", \\\"{x:1544,y:768,t:1527614112032};\\\", \\\"{x:1544,y:767,t:1527614112048};\\\", \\\"{x:1544,y:766,t:1527614112064};\\\", \\\"{x:1544,y:765,t:1527614112161};\\\", \\\"{x:1544,y:764,t:1527614112225};\\\", \\\"{x:1544,y:763,t:1527614112240};\\\", \\\"{x:1544,y:762,t:1527614112272};\\\", \\\"{x:1544,y:761,t:1527614112296};\\\", \\\"{x:1544,y:760,t:1527614112336};\\\", \\\"{x:1544,y:759,t:1527614112480};\\\", \\\"{x:1544,y:757,t:1527614112493};\\\", \\\"{x:1544,y:756,t:1527614112545};\\\", \\\"{x:1544,y:755,t:1527614112568};\\\", \\\"{x:1544,y:754,t:1527614112600};\\\", \\\"{x:1544,y:753,t:1527614112672};\\\", \\\"{x:1544,y:752,t:1527614112704};\\\", \\\"{x:1544,y:751,t:1527614112744};\\\", \\\"{x:1544,y:750,t:1527614112784};\\\", \\\"{x:1544,y:749,t:1527614112794};\\\", \\\"{x:1544,y:748,t:1527614112810};\\\", \\\"{x:1544,y:746,t:1527614112826};\\\", \\\"{x:1544,y:745,t:1527614112843};\\\", \\\"{x:1546,y:743,t:1527614112860};\\\", \\\"{x:1546,y:742,t:1527614112911};\\\", \\\"{x:1546,y:741,t:1527614112927};\\\", \\\"{x:1546,y:740,t:1527614113032};\\\", \\\"{x:1546,y:739,t:1527614113055};\\\", \\\"{x:1546,y:738,t:1527614113072};\\\", \\\"{x:1546,y:737,t:1527614113128};\\\", \\\"{x:1546,y:736,t:1527614113144};\\\", \\\"{x:1546,y:735,t:1527614113160};\\\", \\\"{x:1546,y:734,t:1527614113176};\\\", \\\"{x:1546,y:732,t:1527614113193};\\\", \\\"{x:1546,y:730,t:1527614113210};\\\", \\\"{x:1546,y:727,t:1527614113227};\\\", \\\"{x:1546,y:726,t:1527614113244};\\\", \\\"{x:1545,y:725,t:1527614113260};\\\", \\\"{x:1545,y:723,t:1527614113277};\\\", \\\"{x:1545,y:722,t:1527614113293};\\\", \\\"{x:1545,y:721,t:1527614113311};\\\", \\\"{x:1545,y:719,t:1527614113328};\\\", \\\"{x:1545,y:718,t:1527614113344};\\\", \\\"{x:1545,y:717,t:1527614113376};\\\", \\\"{x:1545,y:716,t:1527614113394};\\\", \\\"{x:1545,y:714,t:1527614113411};\\\", \\\"{x:1544,y:713,t:1527614113427};\\\", \\\"{x:1544,y:712,t:1527614113456};\\\", \\\"{x:1544,y:711,t:1527614113576};\\\", \\\"{x:1544,y:710,t:1527614113615};\\\", \\\"{x:1544,y:709,t:1527614113640};\\\", \\\"{x:1544,y:708,t:1527614113688};\\\", \\\"{x:1546,y:713,t:1527614114608};\\\", \\\"{x:1548,y:719,t:1527614114616};\\\", \\\"{x:1548,y:721,t:1527614114628};\\\", \\\"{x:1549,y:725,t:1527614114644};\\\", \\\"{x:1549,y:726,t:1527614114661};\\\", \\\"{x:1550,y:728,t:1527614114679};\\\", \\\"{x:1550,y:729,t:1527614114694};\\\", \\\"{x:1550,y:730,t:1527614114711};\\\", \\\"{x:1550,y:731,t:1527614114727};\\\", \\\"{x:1550,y:733,t:1527614114745};\\\", \\\"{x:1550,y:737,t:1527614114761};\\\", \\\"{x:1550,y:742,t:1527614114779};\\\", \\\"{x:1550,y:745,t:1527614114794};\\\", \\\"{x:1550,y:749,t:1527614114811};\\\", \\\"{x:1550,y:751,t:1527614114828};\\\", \\\"{x:1550,y:754,t:1527614114844};\\\", \\\"{x:1550,y:755,t:1527614114861};\\\", \\\"{x:1550,y:757,t:1527614114878};\\\", \\\"{x:1550,y:758,t:1527614114894};\\\", \\\"{x:1549,y:760,t:1527614114912};\\\", \\\"{x:1549,y:761,t:1527614114928};\\\", \\\"{x:1549,y:762,t:1527614114952};\\\", \\\"{x:1549,y:763,t:1527614114961};\\\", \\\"{x:1549,y:766,t:1527614114978};\\\", \\\"{x:1548,y:768,t:1527614114994};\\\", \\\"{x:1548,y:767,t:1527614115344};\\\", \\\"{x:1548,y:763,t:1527614115362};\\\", \\\"{x:1548,y:759,t:1527614115378};\\\", \\\"{x:1549,y:756,t:1527614115395};\\\", \\\"{x:1549,y:754,t:1527614115411};\\\", \\\"{x:1550,y:753,t:1527614115432};\\\", \\\"{x:1551,y:751,t:1527614115471};\\\", \\\"{x:1551,y:750,t:1527614115496};\\\", \\\"{x:1551,y:749,t:1527614115512};\\\", \\\"{x:1551,y:748,t:1527614115529};\\\", \\\"{x:1551,y:747,t:1527614115552};\\\", \\\"{x:1551,y:746,t:1527614115568};\\\", \\\"{x:1551,y:745,t:1527614115592};\\\", \\\"{x:1552,y:744,t:1527614115607};\\\", \\\"{x:1552,y:743,t:1527614115648};\\\", \\\"{x:1552,y:742,t:1527614115662};\\\", \\\"{x:1552,y:741,t:1527614115720};\\\", \\\"{x:1552,y:740,t:1527614115729};\\\", \\\"{x:1552,y:739,t:1527614115746};\\\", \\\"{x:1552,y:738,t:1527614115768};\\\", \\\"{x:1552,y:737,t:1527614115784};\\\", \\\"{x:1552,y:736,t:1527614115795};\\\", \\\"{x:1552,y:735,t:1527614115832};\\\", \\\"{x:1552,y:734,t:1527614115845};\\\", \\\"{x:1552,y:733,t:1527614115864};\\\", \\\"{x:1552,y:732,t:1527614116000};\\\", \\\"{x:1552,y:731,t:1527614116013};\\\", \\\"{x:1552,y:730,t:1527614116029};\\\", \\\"{x:1552,y:728,t:1527614116046};\\\", \\\"{x:1552,y:727,t:1527614116080};\\\", \\\"{x:1552,y:726,t:1527614116279};\\\", \\\"{x:1552,y:725,t:1527614116295};\\\", \\\"{x:1552,y:723,t:1527614116311};\\\", \\\"{x:1552,y:720,t:1527614116328};\\\", \\\"{x:1552,y:719,t:1527614116345};\\\", \\\"{x:1553,y:717,t:1527614116362};\\\", \\\"{x:1553,y:716,t:1527614116379};\\\", \\\"{x:1553,y:715,t:1527614116544};\\\", \\\"{x:1553,y:713,t:1527614116768};\\\", \\\"{x:1553,y:711,t:1527614116784};\\\", \\\"{x:1553,y:710,t:1527614116797};\\\", \\\"{x:1553,y:708,t:1527614116813};\\\", \\\"{x:1553,y:707,t:1527614116839};\\\", \\\"{x:1552,y:707,t:1527614116976};\\\", \\\"{x:1551,y:707,t:1527614117440};\\\", \\\"{x:1551,y:714,t:1527614117448};\\\", \\\"{x:1551,y:733,t:1527614117464};\\\", \\\"{x:1550,y:747,t:1527614117480};\\\", \\\"{x:1550,y:751,t:1527614117497};\\\", \\\"{x:1550,y:752,t:1527614117513};\\\", \\\"{x:1550,y:754,t:1527614117530};\\\", \\\"{x:1550,y:755,t:1527614117592};\\\", \\\"{x:1549,y:756,t:1527614117623};\\\", \\\"{x:1549,y:757,t:1527614117632};\\\", \\\"{x:1549,y:759,t:1527614117647};\\\", \\\"{x:1548,y:763,t:1527614117664};\\\", \\\"{x:1548,y:765,t:1527614117680};\\\", \\\"{x:1548,y:766,t:1527614117696};\\\", \\\"{x:1548,y:767,t:1527614117713};\\\", \\\"{x:1547,y:769,t:1527614117744};\\\", \\\"{x:1547,y:765,t:1527614118304};\\\", \\\"{x:1547,y:760,t:1527614118314};\\\", \\\"{x:1547,y:757,t:1527614118330};\\\", \\\"{x:1547,y:756,t:1527614118347};\\\", \\\"{x:1547,y:755,t:1527614118364};\\\", \\\"{x:1547,y:754,t:1527614119124};\\\", \\\"{x:1547,y:753,t:1527614119139};\\\", \\\"{x:1547,y:747,t:1527614119151};\\\", \\\"{x:1547,y:738,t:1527614119168};\\\", \\\"{x:1547,y:735,t:1527614119185};\\\", \\\"{x:1547,y:733,t:1527614119201};\\\", \\\"{x:1547,y:732,t:1527614119217};\\\", \\\"{x:1547,y:731,t:1527614119379};\\\", \\\"{x:1547,y:730,t:1527614119387};\\\", \\\"{x:1547,y:729,t:1527614119402};\\\", \\\"{x:1547,y:728,t:1527614119476};\\\", \\\"{x:1548,y:727,t:1527614119644};\\\", \\\"{x:1548,y:726,t:1527614119660};\\\", \\\"{x:1548,y:725,t:1527614119691};\\\", \\\"{x:1548,y:724,t:1527614119724};\\\", \\\"{x:1548,y:723,t:1527614119883};\\\", \\\"{x:1548,y:722,t:1527614119916};\\\", \\\"{x:1548,y:721,t:1527614119924};\\\", \\\"{x:1548,y:720,t:1527614119935};\\\", \\\"{x:1548,y:719,t:1527614119952};\\\", \\\"{x:1548,y:718,t:1527614119969};\\\", \\\"{x:1548,y:717,t:1527614119985};\\\", \\\"{x:1548,y:716,t:1527614120027};\\\", \\\"{x:1548,y:715,t:1527614120035};\\\", \\\"{x:1548,y:714,t:1527614120052};\\\", \\\"{x:1548,y:712,t:1527614120070};\\\", \\\"{x:1548,y:711,t:1527614120086};\\\", \\\"{x:1548,y:710,t:1527614120131};\\\", \\\"{x:1548,y:709,t:1527614120260};\\\", \\\"{x:1548,y:708,t:1527614120307};\\\", \\\"{x:1548,y:707,t:1527614120323};\\\", \\\"{x:1548,y:706,t:1527614120339};\\\", \\\"{x:1548,y:705,t:1527614120352};\\\", \\\"{x:1548,y:704,t:1527614120388};\\\", \\\"{x:1548,y:703,t:1527614120402};\\\", \\\"{x:1548,y:702,t:1527614120419};\\\", \\\"{x:1548,y:701,t:1527614120437};\\\", \\\"{x:1548,y:699,t:1527614120459};\\\", \\\"{x:1548,y:698,t:1527614120484};\\\", \\\"{x:1548,y:695,t:1527614123092};\\\", \\\"{x:1548,y:691,t:1527614123106};\\\", \\\"{x:1548,y:688,t:1527614123122};\\\", \\\"{x:1548,y:685,t:1527614123138};\\\", \\\"{x:1548,y:684,t:1527614123154};\\\", \\\"{x:1548,y:682,t:1527614123172};\\\", \\\"{x:1548,y:681,t:1527614123219};\\\", \\\"{x:1548,y:679,t:1527614123252};\\\", \\\"{x:1548,y:678,t:1527614123275};\\\", \\\"{x:1548,y:676,t:1527614123291};\\\", \\\"{x:1548,y:675,t:1527614123316};\\\", \\\"{x:1548,y:674,t:1527614123323};\\\", \\\"{x:1548,y:673,t:1527614123339};\\\", \\\"{x:1548,y:672,t:1527614123355};\\\", \\\"{x:1548,y:670,t:1527614123372};\\\", \\\"{x:1548,y:669,t:1527614123395};\\\", \\\"{x:1548,y:668,t:1527614123405};\\\", \\\"{x:1548,y:666,t:1527614123422};\\\", \\\"{x:1548,y:665,t:1527614123444};\\\", \\\"{x:1548,y:664,t:1527614123455};\\\", \\\"{x:1548,y:663,t:1527614123472};\\\", \\\"{x:1548,y:662,t:1527614123488};\\\", \\\"{x:1548,y:660,t:1527614123505};\\\", \\\"{x:1548,y:658,t:1527614123522};\\\", \\\"{x:1548,y:657,t:1527614123539};\\\", \\\"{x:1548,y:656,t:1527614123554};\\\", \\\"{x:1549,y:654,t:1527614123571};\\\", \\\"{x:1549,y:653,t:1527614123589};\\\", \\\"{x:1549,y:652,t:1527614123605};\\\", \\\"{x:1549,y:651,t:1527614123621};\\\", \\\"{x:1549,y:650,t:1527614123643};\\\", \\\"{x:1549,y:649,t:1527614123675};\\\", \\\"{x:1549,y:648,t:1527614123707};\\\", \\\"{x:1549,y:647,t:1527614123803};\\\", \\\"{x:1549,y:646,t:1527614123820};\\\", \\\"{x:1549,y:645,t:1527614123843};\\\", \\\"{x:1549,y:644,t:1527614123883};\\\", \\\"{x:1549,y:643,t:1527614123899};\\\", \\\"{x:1549,y:642,t:1527614123916};\\\", \\\"{x:1549,y:641,t:1527614123964};\\\", \\\"{x:1549,y:640,t:1527614123972};\\\", \\\"{x:1549,y:639,t:1527614123989};\\\", \\\"{x:1549,y:638,t:1527614124006};\\\", \\\"{x:1549,y:636,t:1527614124022};\\\", \\\"{x:1548,y:634,t:1527614124038};\\\", \\\"{x:1548,y:633,t:1527614124056};\\\", \\\"{x:1548,y:630,t:1527614124071};\\\", \\\"{x:1548,y:626,t:1527614124089};\\\", \\\"{x:1546,y:623,t:1527614124106};\\\", \\\"{x:1546,y:617,t:1527614124123};\\\", \\\"{x:1546,y:614,t:1527614124138};\\\", \\\"{x:1544,y:606,t:1527614124155};\\\", \\\"{x:1544,y:603,t:1527614124173};\\\", \\\"{x:1543,y:599,t:1527614124189};\\\", \\\"{x:1542,y:596,t:1527614124205};\\\", \\\"{x:1542,y:592,t:1527614124223};\\\", \\\"{x:1541,y:592,t:1527614124242};\\\", \\\"{x:1540,y:592,t:1527614124267};\\\", \\\"{x:1536,y:592,t:1527614124274};\\\", \\\"{x:1516,y:596,t:1527614124288};\\\", \\\"{x:1417,y:636,t:1527614124305};\\\", \\\"{x:1294,y:676,t:1527614124322};\\\", \\\"{x:1109,y:705,t:1527614124338};\\\", \\\"{x:834,y:721,t:1527614124355};\\\", \\\"{x:706,y:720,t:1527614124372};\\\", \\\"{x:649,y:720,t:1527614124388};\\\", \\\"{x:638,y:718,t:1527614124405};\\\", \\\"{x:637,y:718,t:1527614124475};\\\", \\\"{x:635,y:719,t:1527614124488};\\\", \\\"{x:629,y:727,t:1527614124505};\\\", \\\"{x:627,y:731,t:1527614124522};\\\", \\\"{x:627,y:732,t:1527614124539};\\\", \\\"{x:626,y:733,t:1527614124571};\\\", \\\"{x:625,y:735,t:1527614124579};\\\", \\\"{x:621,y:739,t:1527614124589};\\\", \\\"{x:616,y:744,t:1527614124605};\\\", \\\"{x:611,y:746,t:1527614124622};\\\", \\\"{x:607,y:747,t:1527614124639};\\\", \\\"{x:606,y:747,t:1527614124700};\\\", \\\"{x:605,y:747,t:1527614124723};\\\", \\\"{x:601,y:747,t:1527614124739};\\\", \\\"{x:592,y:745,t:1527614124755};\\\", \\\"{x:585,y:742,t:1527614124772};\\\", \\\"{x:580,y:739,t:1527614124790};\\\", \\\"{x:577,y:738,t:1527614124805};\\\", \\\"{x:573,y:736,t:1527614124822};\\\", \\\"{x:571,y:735,t:1527614124840};\\\", \\\"{x:569,y:734,t:1527614124856};\\\", \\\"{x:568,y:734,t:1527614124872};\\\", \\\"{x:566,y:733,t:1527614124889};\\\", \\\"{x:562,y:732,t:1527614124906};\\\", \\\"{x:554,y:728,t:1527614124921};\\\", \\\"{x:545,y:724,t:1527614124938};\\\", \\\"{x:544,y:723,t:1527614124953};\\\", \\\"{x:539,y:721,t:1527614124970};\\\", \\\"{x:537,y:720,t:1527614124986};\\\", \\\"{x:535,y:720,t:1527614125027};\\\" ] }, { \\\"rt\\\": 43552, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 771385, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-02 PM-X -X -X -X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:720,t:1527614131283};\\\", \\\"{x:560,y:721,t:1527614131295};\\\", \\\"{x:638,y:732,t:1527614131313};\\\", \\\"{x:724,y:732,t:1527614131329};\\\", \\\"{x:807,y:732,t:1527614131346};\\\", \\\"{x:945,y:741,t:1527614131363};\\\", \\\"{x:1001,y:750,t:1527614131379};\\\", \\\"{x:1025,y:756,t:1527614131396};\\\", \\\"{x:1033,y:761,t:1527614131412};\\\", \\\"{x:1037,y:762,t:1527614131430};\\\", \\\"{x:1038,y:763,t:1527614131445};\\\", \\\"{x:1039,y:763,t:1527614131462};\\\", \\\"{x:1042,y:765,t:1527614131479};\\\", \\\"{x:1048,y:767,t:1527614131496};\\\", \\\"{x:1059,y:772,t:1527614131513};\\\", \\\"{x:1069,y:777,t:1527614131529};\\\", \\\"{x:1078,y:781,t:1527614131545};\\\", \\\"{x:1093,y:795,t:1527614131562};\\\", \\\"{x:1107,y:809,t:1527614131579};\\\", \\\"{x:1118,y:822,t:1527614131595};\\\", \\\"{x:1128,y:837,t:1527614131612};\\\", \\\"{x:1139,y:848,t:1527614131630};\\\", \\\"{x:1149,y:862,t:1527614131645};\\\", \\\"{x:1159,y:871,t:1527614131662};\\\", \\\"{x:1170,y:880,t:1527614131679};\\\", \\\"{x:1183,y:890,t:1527614131695};\\\", \\\"{x:1201,y:908,t:1527614131712};\\\", \\\"{x:1222,y:927,t:1527614131730};\\\", \\\"{x:1240,y:942,t:1527614131746};\\\", \\\"{x:1265,y:964,t:1527614131763};\\\", \\\"{x:1281,y:977,t:1527614131779};\\\", \\\"{x:1304,y:995,t:1527614131796};\\\", \\\"{x:1323,y:1008,t:1527614131812};\\\", \\\"{x:1341,y:1020,t:1527614131829};\\\", \\\"{x:1355,y:1029,t:1527614131846};\\\", \\\"{x:1369,y:1034,t:1527614131862};\\\", \\\"{x:1385,y:1043,t:1527614131880};\\\", \\\"{x:1399,y:1049,t:1527614131897};\\\", \\\"{x:1408,y:1054,t:1527614131912};\\\", \\\"{x:1422,y:1062,t:1527614131930};\\\", \\\"{x:1430,y:1065,t:1527614131946};\\\", \\\"{x:1436,y:1068,t:1527614131962};\\\", \\\"{x:1440,y:1070,t:1527614131979};\\\", \\\"{x:1443,y:1071,t:1527614131997};\\\", \\\"{x:1445,y:1072,t:1527614132013};\\\", \\\"{x:1446,y:1072,t:1527614132059};\\\", \\\"{x:1447,y:1072,t:1527614132163};\\\", \\\"{x:1448,y:1066,t:1527614132180};\\\", \\\"{x:1449,y:1060,t:1527614132197};\\\", \\\"{x:1454,y:1053,t:1527614132213};\\\", \\\"{x:1459,y:1045,t:1527614132230};\\\", \\\"{x:1467,y:1036,t:1527614132247};\\\", \\\"{x:1476,y:1024,t:1527614132264};\\\", \\\"{x:1479,y:1016,t:1527614132279};\\\", \\\"{x:1482,y:1010,t:1527614132296};\\\", \\\"{x:1483,y:1006,t:1527614132314};\\\", \\\"{x:1485,y:1004,t:1527614132330};\\\", \\\"{x:1485,y:1002,t:1527614132347};\\\", \\\"{x:1485,y:998,t:1527614132515};\\\", \\\"{x:1485,y:997,t:1527614132530};\\\", \\\"{x:1487,y:991,t:1527614132547};\\\", \\\"{x:1488,y:990,t:1527614132563};\\\", \\\"{x:1488,y:987,t:1527614132580};\\\", \\\"{x:1488,y:986,t:1527614132603};\\\", \\\"{x:1488,y:984,t:1527614132620};\\\", \\\"{x:1488,y:983,t:1527614132643};\\\", \\\"{x:1488,y:982,t:1527614132659};\\\", \\\"{x:1488,y:981,t:1527614132667};\\\", \\\"{x:1488,y:979,t:1527614132690};\\\", \\\"{x:1488,y:977,t:1527614132698};\\\", \\\"{x:1488,y:975,t:1527614132714};\\\", \\\"{x:1488,y:974,t:1527614132729};\\\", \\\"{x:1488,y:972,t:1527614132746};\\\", \\\"{x:1488,y:971,t:1527614132762};\\\", \\\"{x:1487,y:970,t:1527614132802};\\\", \\\"{x:1487,y:969,t:1527614133147};\\\", \\\"{x:1486,y:969,t:1527614133331};\\\", \\\"{x:1485,y:969,t:1527614133348};\\\", \\\"{x:1484,y:969,t:1527614133378};\\\", \\\"{x:1483,y:968,t:1527614133564};\\\", \\\"{x:1482,y:967,t:1527614133581};\\\", \\\"{x:1482,y:966,t:1527614133597};\\\", \\\"{x:1481,y:964,t:1527614133614};\\\", \\\"{x:1480,y:963,t:1527614133632};\\\", \\\"{x:1480,y:962,t:1527614133659};\\\", \\\"{x:1480,y:961,t:1527614133691};\\\", \\\"{x:1480,y:959,t:1527614133716};\\\", \\\"{x:1480,y:958,t:1527614133731};\\\", \\\"{x:1480,y:957,t:1527614133763};\\\", \\\"{x:1480,y:956,t:1527614133787};\\\", \\\"{x:1480,y:955,t:1527614133835};\\\", \\\"{x:1480,y:952,t:1527614134540};\\\", \\\"{x:1480,y:947,t:1527614134548};\\\", \\\"{x:1480,y:941,t:1527614134565};\\\", \\\"{x:1480,y:937,t:1527614134581};\\\", \\\"{x:1480,y:936,t:1527614134598};\\\", \\\"{x:1480,y:934,t:1527614134615};\\\", \\\"{x:1480,y:933,t:1527614134631};\\\", \\\"{x:1480,y:931,t:1527614134648};\\\", \\\"{x:1480,y:930,t:1527614134667};\\\", \\\"{x:1480,y:929,t:1527614134682};\\\", \\\"{x:1480,y:928,t:1527614134699};\\\", \\\"{x:1480,y:927,t:1527614134715};\\\", \\\"{x:1480,y:926,t:1527614134731};\\\", \\\"{x:1480,y:925,t:1527614134749};\\\", \\\"{x:1480,y:924,t:1527614134772};\\\", \\\"{x:1480,y:923,t:1527614134782};\\\", \\\"{x:1480,y:922,t:1527614134799};\\\", \\\"{x:1480,y:920,t:1527614134815};\\\", \\\"{x:1480,y:918,t:1527614134832};\\\", \\\"{x:1480,y:915,t:1527614134849};\\\", \\\"{x:1480,y:912,t:1527614134865};\\\", \\\"{x:1480,y:909,t:1527614134882};\\\", \\\"{x:1480,y:906,t:1527614134898};\\\", \\\"{x:1480,y:905,t:1527614134915};\\\", \\\"{x:1480,y:902,t:1527614134932};\\\", \\\"{x:1480,y:898,t:1527614134949};\\\", \\\"{x:1478,y:895,t:1527614134964};\\\", \\\"{x:1478,y:892,t:1527614134982};\\\", \\\"{x:1478,y:890,t:1527614134999};\\\", \\\"{x:1478,y:888,t:1527614135015};\\\", \\\"{x:1478,y:886,t:1527614135032};\\\", \\\"{x:1477,y:885,t:1527614135048};\\\", \\\"{x:1477,y:884,t:1527614135065};\\\", \\\"{x:1475,y:882,t:1527614135082};\\\", \\\"{x:1475,y:880,t:1527614135098};\\\", \\\"{x:1475,y:877,t:1527614135115};\\\", \\\"{x:1475,y:873,t:1527614135132};\\\", \\\"{x:1475,y:869,t:1527614135149};\\\", \\\"{x:1475,y:866,t:1527614135166};\\\", \\\"{x:1475,y:865,t:1527614135195};\\\", \\\"{x:1475,y:864,t:1527614135203};\\\", \\\"{x:1475,y:863,t:1527614135219};\\\", \\\"{x:1475,y:862,t:1527614135235};\\\", \\\"{x:1475,y:861,t:1527614135249};\\\", \\\"{x:1475,y:857,t:1527614135266};\\\", \\\"{x:1475,y:855,t:1527614135282};\\\", \\\"{x:1475,y:850,t:1527614135299};\\\", \\\"{x:1475,y:845,t:1527614135315};\\\", \\\"{x:1475,y:844,t:1527614135333};\\\", \\\"{x:1475,y:842,t:1527614135349};\\\", \\\"{x:1475,y:840,t:1527614135366};\\\", \\\"{x:1475,y:839,t:1527614135395};\\\", \\\"{x:1475,y:837,t:1527614135411};\\\", \\\"{x:1475,y:836,t:1527614135427};\\\", \\\"{x:1475,y:834,t:1527614135467};\\\", \\\"{x:1475,y:833,t:1527614135596};\\\", \\\"{x:1475,y:831,t:1527614135619};\\\", \\\"{x:1478,y:828,t:1527614136038};\\\", \\\"{x:1481,y:824,t:1527614136050};\\\", \\\"{x:1481,y:821,t:1527614136065};\\\", \\\"{x:1482,y:821,t:1527614136082};\\\", \\\"{x:1472,y:815,t:1527614147972};\\\", \\\"{x:1456,y:809,t:1527614147979};\\\", \\\"{x:1446,y:804,t:1527614147992};\\\", \\\"{x:1432,y:796,t:1527614148008};\\\", \\\"{x:1410,y:788,t:1527614148026};\\\", \\\"{x:1397,y:780,t:1527614148041};\\\", \\\"{x:1383,y:773,t:1527614148059};\\\", \\\"{x:1378,y:770,t:1527614148076};\\\", \\\"{x:1377,y:769,t:1527614148092};\\\", \\\"{x:1376,y:769,t:1527614148109};\\\", \\\"{x:1376,y:768,t:1527614148267};\\\", \\\"{x:1376,y:767,t:1527614148275};\\\", \\\"{x:1376,y:764,t:1527614148292};\\\", \\\"{x:1376,y:763,t:1527614148309};\\\", \\\"{x:1376,y:761,t:1527614148326};\\\", \\\"{x:1376,y:759,t:1527614148341};\\\", \\\"{x:1377,y:757,t:1527614148359};\\\", \\\"{x:1379,y:755,t:1527614148387};\\\", \\\"{x:1379,y:754,t:1527614148451};\\\", \\\"{x:1380,y:754,t:1527614148458};\\\", \\\"{x:1383,y:754,t:1527614148475};\\\", \\\"{x:1386,y:754,t:1527614148492};\\\", \\\"{x:1388,y:755,t:1527614148509};\\\", \\\"{x:1391,y:758,t:1527614148525};\\\", \\\"{x:1394,y:762,t:1527614148542};\\\", \\\"{x:1398,y:765,t:1527614148559};\\\", \\\"{x:1402,y:767,t:1527614148575};\\\", \\\"{x:1405,y:769,t:1527614148592};\\\", \\\"{x:1407,y:769,t:1527614148608};\\\", \\\"{x:1409,y:770,t:1527614148625};\\\", \\\"{x:1411,y:770,t:1527614148659};\\\", \\\"{x:1412,y:770,t:1527614148764};\\\", \\\"{x:1414,y:770,t:1527614148775};\\\", \\\"{x:1421,y:769,t:1527614148793};\\\", \\\"{x:1427,y:767,t:1527614148808};\\\", \\\"{x:1431,y:766,t:1527614148825};\\\", \\\"{x:1436,y:765,t:1527614148843};\\\", \\\"{x:1439,y:764,t:1527614148860};\\\", \\\"{x:1441,y:764,t:1527614148876};\\\", \\\"{x:1442,y:764,t:1527614148893};\\\", \\\"{x:1443,y:764,t:1527614148922};\\\", \\\"{x:1444,y:764,t:1527614148939};\\\", \\\"{x:1445,y:763,t:1527614148947};\\\", \\\"{x:1446,y:763,t:1527614148987};\\\", \\\"{x:1448,y:762,t:1527614148995};\\\", \\\"{x:1450,y:761,t:1527614149019};\\\", \\\"{x:1451,y:760,t:1527614149034};\\\", \\\"{x:1452,y:760,t:1527614149059};\\\", \\\"{x:1451,y:760,t:1527614149467};\\\", \\\"{x:1450,y:760,t:1527614149523};\\\", \\\"{x:1450,y:761,t:1527614149603};\\\", \\\"{x:1450,y:762,t:1527614149619};\\\", \\\"{x:1450,y:763,t:1527614149651};\\\", \\\"{x:1450,y:764,t:1527614149731};\\\", \\\"{x:1449,y:764,t:1527614149779};\\\", \\\"{x:1448,y:765,t:1527614149931};\\\", \\\"{x:1447,y:765,t:1527614150539};\\\", \\\"{x:1447,y:768,t:1527614150844};\\\", \\\"{x:1445,y:783,t:1527614150861};\\\", \\\"{x:1444,y:793,t:1527614150878};\\\", \\\"{x:1444,y:804,t:1527614150893};\\\", \\\"{x:1444,y:815,t:1527614150911};\\\", \\\"{x:1442,y:828,t:1527614150928};\\\", \\\"{x:1440,y:835,t:1527614150944};\\\", \\\"{x:1439,y:846,t:1527614150955};\\\", \\\"{x:1436,y:857,t:1527614150977};\\\", \\\"{x:1433,y:867,t:1527614150993};\\\", \\\"{x:1429,y:890,t:1527614151010};\\\", \\\"{x:1425,y:906,t:1527614151027};\\\", \\\"{x:1424,y:916,t:1527614151045};\\\", \\\"{x:1423,y:921,t:1527614151061};\\\", \\\"{x:1422,y:924,t:1527614151078};\\\", \\\"{x:1422,y:926,t:1527614151095};\\\", \\\"{x:1422,y:928,t:1527614151111};\\\", \\\"{x:1421,y:929,t:1527614151138};\\\", \\\"{x:1421,y:930,t:1527614151146};\\\", \\\"{x:1421,y:930,t:1527614151186};\\\", \\\"{x:1426,y:929,t:1527614151556};\\\", \\\"{x:1434,y:920,t:1527614151563};\\\", \\\"{x:1458,y:903,t:1527614151579};\\\", \\\"{x:1487,y:880,t:1527614151597};\\\", \\\"{x:1522,y:855,t:1527614151612};\\\", \\\"{x:1541,y:836,t:1527614151629};\\\", \\\"{x:1564,y:821,t:1527614151647};\\\", \\\"{x:1580,y:804,t:1527614151663};\\\", \\\"{x:1596,y:783,t:1527614151679};\\\", \\\"{x:1609,y:762,t:1527614151696};\\\", \\\"{x:1623,y:742,t:1527614151714};\\\", \\\"{x:1636,y:722,t:1527614151729};\\\", \\\"{x:1662,y:697,t:1527614151747};\\\", \\\"{x:1677,y:684,t:1527614151763};\\\", \\\"{x:1693,y:671,t:1527614151779};\\\", \\\"{x:1708,y:658,t:1527614151796};\\\", \\\"{x:1719,y:647,t:1527614151813};\\\", \\\"{x:1729,y:639,t:1527614151830};\\\", \\\"{x:1735,y:629,t:1527614151847};\\\", \\\"{x:1743,y:622,t:1527614151865};\\\", \\\"{x:1750,y:612,t:1527614151880};\\\", \\\"{x:1756,y:607,t:1527614151897};\\\", \\\"{x:1761,y:600,t:1527614151914};\\\", \\\"{x:1768,y:592,t:1527614151931};\\\", \\\"{x:1770,y:588,t:1527614151947};\\\", \\\"{x:1771,y:587,t:1527614151963};\\\", \\\"{x:1772,y:587,t:1527614151981};\\\", \\\"{x:1772,y:586,t:1527614152003};\\\", \\\"{x:1769,y:592,t:1527614152419};\\\", \\\"{x:1761,y:600,t:1527614152429};\\\", \\\"{x:1749,y:611,t:1527614152446};\\\", \\\"{x:1738,y:621,t:1527614152462};\\\", \\\"{x:1728,y:630,t:1527614152479};\\\", \\\"{x:1718,y:640,t:1527614152496};\\\", \\\"{x:1704,y:652,t:1527614152513};\\\", \\\"{x:1683,y:666,t:1527614152529};\\\", \\\"{x:1659,y:685,t:1527614152547};\\\", \\\"{x:1652,y:697,t:1527614152563};\\\", \\\"{x:1644,y:707,t:1527614152579};\\\", \\\"{x:1640,y:715,t:1527614152598};\\\", \\\"{x:1636,y:721,t:1527614152613};\\\", \\\"{x:1633,y:727,t:1527614152630};\\\", \\\"{x:1628,y:734,t:1527614152647};\\\", \\\"{x:1621,y:742,t:1527614152662};\\\", \\\"{x:1612,y:753,t:1527614152679};\\\", \\\"{x:1604,y:764,t:1527614152696};\\\", \\\"{x:1595,y:777,t:1527614152713};\\\", \\\"{x:1585,y:787,t:1527614152730};\\\", \\\"{x:1577,y:796,t:1527614152746};\\\", \\\"{x:1575,y:799,t:1527614152763};\\\", \\\"{x:1573,y:801,t:1527614152779};\\\", \\\"{x:1571,y:803,t:1527614152796};\\\", \\\"{x:1569,y:804,t:1527614152813};\\\", \\\"{x:1567,y:808,t:1527614152829};\\\", \\\"{x:1566,y:809,t:1527614152847};\\\", \\\"{x:1564,y:811,t:1527614152865};\\\", \\\"{x:1562,y:811,t:1527614152879};\\\", \\\"{x:1560,y:814,t:1527614152897};\\\", \\\"{x:1559,y:814,t:1527614153011};\\\", \\\"{x:1558,y:814,t:1527614153019};\\\", \\\"{x:1556,y:814,t:1527614153029};\\\", \\\"{x:1555,y:814,t:1527614153047};\\\", \\\"{x:1554,y:814,t:1527614153067};\\\", \\\"{x:1553,y:814,t:1527614153080};\\\", \\\"{x:1552,y:814,t:1527614154811};\\\", \\\"{x:1537,y:818,t:1527614154819};\\\", \\\"{x:1523,y:822,t:1527614154832};\\\", \\\"{x:1503,y:824,t:1527614154848};\\\", \\\"{x:1481,y:826,t:1527614154866};\\\", \\\"{x:1449,y:828,t:1527614154883};\\\", \\\"{x:1390,y:828,t:1527614154898};\\\", \\\"{x:1338,y:828,t:1527614154914};\\\", \\\"{x:1329,y:828,t:1527614154931};\\\", \\\"{x:1325,y:826,t:1527614155059};\\\", \\\"{x:1316,y:813,t:1527614155066};\\\", \\\"{x:1307,y:801,t:1527614155082};\\\", \\\"{x:1295,y:784,t:1527614155097};\\\", \\\"{x:1282,y:773,t:1527614155114};\\\", \\\"{x:1277,y:769,t:1527614155131};\\\", \\\"{x:1276,y:769,t:1527614155187};\\\", \\\"{x:1275,y:768,t:1527614155202};\\\", \\\"{x:1275,y:767,t:1527614155226};\\\", \\\"{x:1275,y:765,t:1527614155371};\\\", \\\"{x:1279,y:762,t:1527614155381};\\\", \\\"{x:1284,y:758,t:1527614155398};\\\", \\\"{x:1293,y:755,t:1527614155415};\\\", \\\"{x:1305,y:753,t:1527614155431};\\\", \\\"{x:1314,y:752,t:1527614155449};\\\", \\\"{x:1323,y:751,t:1527614155465};\\\", \\\"{x:1337,y:748,t:1527614155481};\\\", \\\"{x:1360,y:747,t:1527614155498};\\\", \\\"{x:1381,y:747,t:1527614155515};\\\", \\\"{x:1400,y:747,t:1527614155532};\\\", \\\"{x:1424,y:747,t:1527614155549};\\\", \\\"{x:1448,y:749,t:1527614155565};\\\", \\\"{x:1468,y:752,t:1527614155581};\\\", \\\"{x:1483,y:753,t:1527614155598};\\\", \\\"{x:1494,y:756,t:1527614155615};\\\", \\\"{x:1498,y:757,t:1527614155631};\\\", \\\"{x:1499,y:757,t:1527614155649};\\\", \\\"{x:1501,y:758,t:1527614155682};\\\", \\\"{x:1501,y:759,t:1527614155764};\\\", \\\"{x:1501,y:760,t:1527614155794};\\\", \\\"{x:1501,y:761,t:1527614155803};\\\", \\\"{x:1501,y:762,t:1527614155816};\\\", \\\"{x:1501,y:766,t:1527614155832};\\\", \\\"{x:1499,y:772,t:1527614155849};\\\", \\\"{x:1491,y:785,t:1527614155866};\\\", \\\"{x:1487,y:789,t:1527614155882};\\\", \\\"{x:1483,y:796,t:1527614155898};\\\", \\\"{x:1482,y:797,t:1527614155915};\\\", \\\"{x:1482,y:798,t:1527614155932};\\\", \\\"{x:1481,y:798,t:1527614156011};\\\", \\\"{x:1480,y:799,t:1527614156067};\\\", \\\"{x:1480,y:802,t:1527614156082};\\\", \\\"{x:1480,y:811,t:1527614156099};\\\", \\\"{x:1479,y:817,t:1527614156115};\\\", \\\"{x:1478,y:824,t:1527614156132};\\\", \\\"{x:1478,y:834,t:1527614156149};\\\", \\\"{x:1478,y:848,t:1527614156166};\\\", \\\"{x:1478,y:863,t:1527614156183};\\\", \\\"{x:1478,y:870,t:1527614156199};\\\", \\\"{x:1478,y:875,t:1527614156215};\\\", \\\"{x:1478,y:877,t:1527614156232};\\\", \\\"{x:1478,y:880,t:1527614156248};\\\", \\\"{x:1479,y:880,t:1527614156266};\\\", \\\"{x:1479,y:883,t:1527614156282};\\\", \\\"{x:1480,y:887,t:1527614156298};\\\", \\\"{x:1480,y:890,t:1527614156315};\\\", \\\"{x:1480,y:893,t:1527614156332};\\\", \\\"{x:1480,y:896,t:1527614156347};\\\", \\\"{x:1480,y:899,t:1527614156365};\\\", \\\"{x:1480,y:902,t:1527614156382};\\\", \\\"{x:1480,y:903,t:1527614156398};\\\", \\\"{x:1480,y:905,t:1527614156425};\\\", \\\"{x:1480,y:906,t:1527614156450};\\\", \\\"{x:1480,y:908,t:1527614156466};\\\", \\\"{x:1480,y:909,t:1527614156481};\\\", \\\"{x:1480,y:911,t:1527614156499};\\\", \\\"{x:1480,y:912,t:1527614156515};\\\", \\\"{x:1480,y:911,t:1527614156618};\\\", \\\"{x:1480,y:907,t:1527614156633};\\\", \\\"{x:1480,y:904,t:1527614156649};\\\", \\\"{x:1480,y:900,t:1527614156665};\\\", \\\"{x:1480,y:889,t:1527614156682};\\\", \\\"{x:1479,y:881,t:1527614156699};\\\", \\\"{x:1479,y:872,t:1527614156715};\\\", \\\"{x:1478,y:867,t:1527614156733};\\\", \\\"{x:1477,y:862,t:1527614156749};\\\", \\\"{x:1477,y:857,t:1527614156765};\\\", \\\"{x:1476,y:854,t:1527614156782};\\\", \\\"{x:1476,y:853,t:1527614156799};\\\", \\\"{x:1476,y:850,t:1527614156816};\\\", \\\"{x:1476,y:844,t:1527614156832};\\\", \\\"{x:1477,y:839,t:1527614156850};\\\", \\\"{x:1479,y:833,t:1527614156866};\\\", \\\"{x:1480,y:826,t:1527614156882};\\\", \\\"{x:1480,y:821,t:1527614156900};\\\", \\\"{x:1480,y:815,t:1527614156915};\\\", \\\"{x:1481,y:809,t:1527614156933};\\\", \\\"{x:1481,y:805,t:1527614156950};\\\", \\\"{x:1481,y:801,t:1527614156966};\\\", \\\"{x:1481,y:799,t:1527614156982};\\\", \\\"{x:1481,y:795,t:1527614157000};\\\", \\\"{x:1483,y:791,t:1527614157015};\\\", \\\"{x:1483,y:787,t:1527614157033};\\\", \\\"{x:1483,y:784,t:1527614157050};\\\", \\\"{x:1483,y:780,t:1527614157066};\\\", \\\"{x:1484,y:775,t:1527614157082};\\\", \\\"{x:1484,y:773,t:1527614157099};\\\", \\\"{x:1484,y:771,t:1527614157116};\\\", \\\"{x:1484,y:770,t:1527614157133};\\\", \\\"{x:1484,y:768,t:1527614157149};\\\", \\\"{x:1484,y:767,t:1527614157166};\\\", \\\"{x:1484,y:766,t:1527614157182};\\\", \\\"{x:1484,y:764,t:1527614157200};\\\", \\\"{x:1484,y:763,t:1527614157218};\\\", \\\"{x:1484,y:762,t:1527614157307};\\\", \\\"{x:1484,y:761,t:1527614157339};\\\", \\\"{x:1484,y:760,t:1527614157355};\\\", \\\"{x:1484,y:759,t:1527614157367};\\\", \\\"{x:1484,y:758,t:1527614157382};\\\", \\\"{x:1484,y:757,t:1527614157399};\\\", \\\"{x:1484,y:756,t:1527614157416};\\\", \\\"{x:1484,y:755,t:1527614157433};\\\", \\\"{x:1484,y:754,t:1527614157475};\\\", \\\"{x:1484,y:752,t:1527614157490};\\\", \\\"{x:1484,y:751,t:1527614157507};\\\", \\\"{x:1484,y:750,t:1527614157517};\\\", \\\"{x:1484,y:749,t:1527614157534};\\\", \\\"{x:1484,y:748,t:1527614157555};\\\", \\\"{x:1484,y:747,t:1527614157570};\\\", \\\"{x:1484,y:745,t:1527614157584};\\\", \\\"{x:1484,y:744,t:1527614157600};\\\", \\\"{x:1484,y:742,t:1527614157617};\\\", \\\"{x:1484,y:740,t:1527614157633};\\\", \\\"{x:1484,y:736,t:1527614157649};\\\", \\\"{x:1484,y:732,t:1527614157665};\\\", \\\"{x:1484,y:726,t:1527614157683};\\\", \\\"{x:1484,y:722,t:1527614157699};\\\", \\\"{x:1484,y:718,t:1527614157716};\\\", \\\"{x:1484,y:713,t:1527614157733};\\\", \\\"{x:1484,y:710,t:1527614157749};\\\", \\\"{x:1485,y:707,t:1527614157766};\\\", \\\"{x:1485,y:706,t:1527614157793};\\\", \\\"{x:1485,y:705,t:1527614157809};\\\", \\\"{x:1485,y:704,t:1527614157907};\\\", \\\"{x:1485,y:703,t:1527614158035};\\\", \\\"{x:1485,y:701,t:1527614158051};\\\", \\\"{x:1485,y:700,t:1527614158082};\\\", \\\"{x:1484,y:698,t:1527614160067};\\\", \\\"{x:1483,y:697,t:1527614160091};\\\", \\\"{x:1482,y:695,t:1527614160102};\\\", \\\"{x:1481,y:693,t:1527614160118};\\\", \\\"{x:1480,y:692,t:1527614160138};\\\", \\\"{x:1479,y:688,t:1527614165699};\\\", \\\"{x:1479,y:681,t:1527614165706};\\\", \\\"{x:1480,y:673,t:1527614165722};\\\", \\\"{x:1480,y:662,t:1527614165739};\\\", \\\"{x:1480,y:655,t:1527614165756};\\\", \\\"{x:1480,y:650,t:1527614165773};\\\", \\\"{x:1480,y:642,t:1527614165789};\\\", \\\"{x:1480,y:630,t:1527614165806};\\\", \\\"{x:1480,y:621,t:1527614165824};\\\", \\\"{x:1480,y:607,t:1527614165839};\\\", \\\"{x:1480,y:597,t:1527614165856};\\\", \\\"{x:1480,y:591,t:1527614165873};\\\", \\\"{x:1480,y:585,t:1527614165889};\\\", \\\"{x:1480,y:580,t:1527614165906};\\\", \\\"{x:1480,y:576,t:1527614165922};\\\", \\\"{x:1480,y:571,t:1527614165939};\\\", \\\"{x:1480,y:570,t:1527614165956};\\\", \\\"{x:1480,y:567,t:1527614165973};\\\", \\\"{x:1480,y:566,t:1527614165990};\\\", \\\"{x:1480,y:565,t:1527614166011};\\\", \\\"{x:1480,y:564,t:1527614166034};\\\", \\\"{x:1480,y:563,t:1527614166123};\\\", \\\"{x:1439,y:565,t:1527614167715};\\\", \\\"{x:1336,y:567,t:1527614167724};\\\", \\\"{x:1139,y:562,t:1527614167741};\\\", \\\"{x:955,y:539,t:1527614167757};\\\", \\\"{x:840,y:514,t:1527614167776};\\\", \\\"{x:793,y:504,t:1527614167791};\\\", \\\"{x:735,y:502,t:1527614167806};\\\", \\\"{x:723,y:501,t:1527614167825};\\\", \\\"{x:720,y:501,t:1527614167841};\\\", \\\"{x:720,y:502,t:1527614167857};\\\", \\\"{x:720,y:503,t:1527614167977};\\\", \\\"{x:720,y:504,t:1527614167991};\\\", \\\"{x:712,y:526,t:1527614168007};\\\", \\\"{x:690,y:571,t:1527614168025};\\\", \\\"{x:640,y:639,t:1527614168041};\\\", \\\"{x:612,y:657,t:1527614168058};\\\", \\\"{x:595,y:662,t:1527614168073};\\\", \\\"{x:591,y:664,t:1527614168091};\\\", \\\"{x:591,y:663,t:1527614168122};\\\", \\\"{x:588,y:659,t:1527614168129};\\\", \\\"{x:587,y:655,t:1527614168141};\\\", \\\"{x:585,y:643,t:1527614168158};\\\", \\\"{x:583,y:628,t:1527614168175};\\\", \\\"{x:583,y:614,t:1527614168192};\\\", \\\"{x:587,y:599,t:1527614168209};\\\", \\\"{x:592,y:587,t:1527614168224};\\\", \\\"{x:603,y:570,t:1527614168242};\\\", \\\"{x:621,y:557,t:1527614168259};\\\", \\\"{x:655,y:547,t:1527614168275};\\\", \\\"{x:714,y:528,t:1527614168292};\\\", \\\"{x:754,y:520,t:1527614168309};\\\", \\\"{x:765,y:517,t:1527614168324};\\\", \\\"{x:767,y:515,t:1527614168342};\\\", \\\"{x:769,y:515,t:1527614168410};\\\", \\\"{x:772,y:515,t:1527614168425};\\\", \\\"{x:775,y:515,t:1527614168441};\\\", \\\"{x:792,y:515,t:1527614168458};\\\", \\\"{x:807,y:515,t:1527614168475};\\\", \\\"{x:823,y:515,t:1527614168491};\\\", \\\"{x:833,y:515,t:1527614168509};\\\", \\\"{x:837,y:515,t:1527614168525};\\\", \\\"{x:838,y:515,t:1527614168541};\\\", \\\"{x:839,y:515,t:1527614168577};\\\", \\\"{x:840,y:515,t:1527614168601};\\\", \\\"{x:841,y:515,t:1527614168626};\\\", \\\"{x:836,y:512,t:1527614168875};\\\", \\\"{x:796,y:509,t:1527614168891};\\\", \\\"{x:708,y:502,t:1527614168909};\\\", \\\"{x:614,y:502,t:1527614168925};\\\", \\\"{x:547,y:502,t:1527614168942};\\\", \\\"{x:524,y:503,t:1527614168958};\\\", \\\"{x:521,y:510,t:1527614168975};\\\", \\\"{x:520,y:517,t:1527614168991};\\\", \\\"{x:520,y:522,t:1527614169009};\\\", \\\"{x:520,y:531,t:1527614169025};\\\", \\\"{x:521,y:538,t:1527614169042};\\\", \\\"{x:527,y:543,t:1527614169058};\\\", \\\"{x:534,y:548,t:1527614169075};\\\", \\\"{x:547,y:549,t:1527614169091};\\\", \\\"{x:555,y:551,t:1527614169108};\\\", \\\"{x:556,y:552,t:1527614169125};\\\", \\\"{x:560,y:552,t:1527614169143};\\\", \\\"{x:565,y:552,t:1527614169158};\\\", \\\"{x:569,y:552,t:1527614169176};\\\", \\\"{x:572,y:551,t:1527614169192};\\\", \\\"{x:576,y:550,t:1527614169209};\\\", \\\"{x:578,y:547,t:1527614169226};\\\", \\\"{x:580,y:545,t:1527614169242};\\\", \\\"{x:581,y:543,t:1527614169266};\\\", \\\"{x:582,y:542,t:1527614169276};\\\", \\\"{x:582,y:540,t:1527614169293};\\\", \\\"{x:585,y:537,t:1527614169310};\\\", \\\"{x:588,y:533,t:1527614169325};\\\", \\\"{x:592,y:528,t:1527614169342};\\\", \\\"{x:598,y:524,t:1527614169358};\\\", \\\"{x:601,y:522,t:1527614169376};\\\", \\\"{x:604,y:520,t:1527614169393};\\\", \\\"{x:604,y:519,t:1527614169408};\\\", \\\"{x:600,y:531,t:1527614169762};\\\", \\\"{x:592,y:569,t:1527614169777};\\\", \\\"{x:573,y:636,t:1527614169793};\\\", \\\"{x:559,y:699,t:1527614169810};\\\", \\\"{x:556,y:716,t:1527614169825};\\\", \\\"{x:556,y:723,t:1527614169842};\\\", \\\"{x:556,y:726,t:1527614169858};\\\", \\\"{x:556,y:732,t:1527614169876};\\\", \\\"{x:557,y:735,t:1527614169893};\\\", \\\"{x:557,y:736,t:1527614169913};\\\", \\\"{x:557,y:737,t:1527614169962};\\\", \\\"{x:556,y:738,t:1527614169994};\\\", \\\"{x:555,y:738,t:1527614170010};\\\", \\\"{x:553,y:738,t:1527614170027};\\\", \\\"{x:552,y:738,t:1527614170044};\\\", \\\"{x:550,y:738,t:1527614170060};\\\", \\\"{x:548,y:738,t:1527614170082};\\\", \\\"{x:546,y:737,t:1527614170098};\\\", \\\"{x:545,y:737,t:1527614170114};\\\", \\\"{x:544,y:737,t:1527614170155};\\\", \\\"{x:543,y:737,t:1527614170162};\\\", \\\"{x:541,y:737,t:1527614170178};\\\", \\\"{x:540,y:737,t:1527614170194};\\\" ] }, { \\\"rt\\\": 48725, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 821327, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"you take 12pm on the X-axis and then go up along the vertical line to see which points lie on that line.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 16892, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"India\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 839223, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12910, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 853156, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 31169, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 885652, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"RRF03\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"RRF03\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 120, dom: 502, initialDom: 568",
  "javascriptErrors": []
}