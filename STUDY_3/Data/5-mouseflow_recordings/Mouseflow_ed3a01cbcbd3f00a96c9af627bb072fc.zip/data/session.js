var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ed3a01cbcbd3f00a96c9af627bb072fc",
  "created": "2018-05-25T10:15:28.3669716-07:00",
  "lastActivity": "2018-05-25T10:15:49.6343833-07:00",
  "pageViews": [
    {
      "id": "052528712e1270b4f3250b6d0b18b722d798336d",
      "startTime": "2018-05-25T10:15:28.4143551-07:00",
      "endTime": "2018-05-25T10:15:49.6343833-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 21252,
      "engagementTime": 15966,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21252,
  "engagementTime": 15966,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YC7SX",
    "CONDITION=115-late",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "068afaab7d1d13ce170466ad6905d319",
  "gdpr": false
}