var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5923b542aeae6c8a9b9634fe5a8f9d72",
  "created": "2018-05-25T09:17:41.7102254-07:00",
  "lastActivity": "2018-05-25T09:17:50.6202254-07:00",
  "pageViews": [
    {
      "id": "05254187141876fb37e279dddd9f18b3d4d99a30",
      "startTime": "2018-05-25T09:17:41.7102254-07:00",
      "endTime": "2018-05-25T09:17:50.6202254-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 8910,
      "engagementTime": 8910,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 8910,
  "engagementTime": 8910,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MW3RC",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "192f94de450614855b0ffde2571440b8",
  "gdpr": false
}