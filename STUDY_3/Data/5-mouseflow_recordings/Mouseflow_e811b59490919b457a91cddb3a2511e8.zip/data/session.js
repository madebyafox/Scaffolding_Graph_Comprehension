var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e811b59490919b457a91cddb3a2511e8",
  "created": "2018-05-22T16:09:00.1352143-07:00",
  "lastActivity": "2018-05-22T16:09:24.3432143-07:00",
  "pageViews": [
    {
      "id": "05220023301c6a5ace6af45d04cb344479288f74",
      "startTime": "2018-05-22T16:09:00.1352143-07:00",
      "endTime": "2018-05-22T16:09:24.3432143-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 24208,
      "engagementTime": 24208,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24208,
  "engagementTime": 24208,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZY4DY",
    "CONDITION=115",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ec90bd730e2aed4a256e9a095ccaf9b0",
  "gdpr": false
}