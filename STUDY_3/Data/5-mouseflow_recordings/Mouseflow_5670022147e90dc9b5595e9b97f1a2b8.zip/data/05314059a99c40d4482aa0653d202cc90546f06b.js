var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05314059a99c40d4482aa0653d202cc90546f06b"] = {
  "startTime": "2018-05-31T19:04:41.2934906Z",
  "websitePageUrl": "/",
  "visitTime": 123135,
  "engagementTime": 82346,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "5670022147e90dc9b5595e9b97f1a2b8",
    "created": "2018-05-31T19:04:41.1811959+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "db3e29293f144aec0837f979fa24020e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5670022147e90dc9b5595e9b97f1a2b8/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 370,
      "e": 370,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 5500,
      "e": 5101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 5500,
      "e": 5101,
      "ty": 2,
      "x": 73,
      "y": 845
    },
    {
      "t": 5502,
      "e": 5103,
      "ty": 41,
      "x": 2238,
      "y": 46367,
      "ta": "html > body"
    },
    {
      "t": 10009,
      "e": 9610,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10901,
      "e": 10103,
      "ty": 2,
      "x": 484,
      "y": 863
    },
    {
      "t": 11000,
      "e": 10202,
      "ty": 2,
      "x": 803,
      "y": 919
    },
    {
      "t": 11001,
      "e": 10203,
      "ty": 41,
      "x": 24220,
      "y": 58940,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11100,
      "e": 10302,
      "ty": 2,
      "x": 1023,
      "y": 939
    },
    {
      "t": 11200,
      "e": 10402,
      "ty": 2,
      "x": 1028,
      "y": 885
    },
    {
      "t": 11251,
      "e": 10453,
      "ty": 41,
      "x": 36617,
      "y": 54844,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11300,
      "e": 10502,
      "ty": 2,
      "x": 1032,
      "y": 861
    },
    {
      "t": 11401,
      "e": 10603,
      "ty": 2,
      "x": 1032,
      "y": 860
    },
    {
      "t": 11495,
      "e": 10697,
      "ty": 3,
      "x": 1032,
      "y": 860,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11502,
      "e": 10704,
      "ty": 41,
      "x": 36726,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11604,
      "e": 10806,
      "ty": 4,
      "x": 36726,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11605,
      "e": 10807,
      "ty": 5,
      "x": 1032,
      "y": 860,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12201,
      "e": 11403,
      "ty": 2,
      "x": 947,
      "y": 964
    },
    {
      "t": 12254,
      "e": 11456,
      "ty": 41,
      "x": 31975,
      "y": 62790,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12304,
      "e": 11506,
      "ty": 2,
      "x": 945,
      "y": 967
    },
    {
      "t": 12501,
      "e": 11703,
      "ty": 41,
      "x": 31975,
      "y": 62872,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12605,
      "e": 11807,
      "ty": 2,
      "x": 944,
      "y": 967
    },
    {
      "t": 12700,
      "e": 11902,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 12751,
      "e": 11953,
      "ty": 41,
      "x": 31921,
      "y": 62872,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12801,
      "e": 12003,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 13101,
      "e": 12303,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 13201,
      "e": 12403,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 17801,
      "e": 17003,
      "ty": 2,
      "x": 923,
      "y": 922
    },
    {
      "t": 17901,
      "e": 17103,
      "ty": 2,
      "x": 883,
      "y": 867
    },
    {
      "t": 18004,
      "e": 17206,
      "ty": 2,
      "x": 879,
      "y": 860
    },
    {
      "t": 18005,
      "e": 17207,
      "ty": 41,
      "x": 28371,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18103,
      "e": 17305,
      "ty": 2,
      "x": 878,
      "y": 859
    },
    {
      "t": 18254,
      "e": 17456,
      "ty": 41,
      "x": 28316,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20005,
      "e": 19207,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 47201,
      "e": 22456,
      "ty": 2,
      "x": 995,
      "y": 855
    },
    {
      "t": 47251,
      "e": 22506,
      "ty": 41,
      "x": 38747,
      "y": 53697,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47301,
      "e": 22556,
      "ty": 2,
      "x": 1082,
      "y": 855
    },
    {
      "t": 47381,
      "e": 22636,
      "ty": 3,
      "x": 1082,
      "y": 855,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47501,
      "e": 22756,
      "ty": 41,
      "x": 39457,
      "y": 53697,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47532,
      "e": 22787,
      "ty": 4,
      "x": 39457,
      "y": 53697,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47532,
      "e": 22787,
      "ty": 5,
      "x": 1082,
      "y": 855,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50773,
      "e": 26028,
      "ty": 3,
      "x": 1082,
      "y": 855,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50876,
      "e": 26131,
      "ty": 4,
      "x": 39457,
      "y": 53697,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 52004,
      "e": 27259,
      "ty": 3,
      "x": 877,
      "y": 953,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 52100,
      "e": 27355,
      "ty": 2,
      "x": 877,
      "y": 953
    },
    {
      "t": 52123,
      "e": 27378,
      "ty": 4,
      "x": 28261,
      "y": 61725,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 52123,
      "e": 27378,
      "ty": 5,
      "x": 877,
      "y": 953,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 52250,
      "e": 27505,
      "ty": 41,
      "x": 28261,
      "y": 61725,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 52795,
      "e": 28050,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 53750,
      "e": 29005,
      "ty": 41,
      "x": 29995,
      "y": 52350,
      "ta": "html > body"
    },
    {
      "t": 53800,
      "e": 29055,
      "ty": 2,
      "x": 891,
      "y": 947
    },
    {
      "t": 53900,
      "e": 29155,
      "ty": 2,
      "x": 892,
      "y": 947
    },
    {
      "t": 53905,
      "e": 29160,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 54000,
      "e": 29255,
      "ty": 41,
      "x": 29446,
      "y": 56831,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 54400,
      "e": 29655,
      "ty": 2,
      "x": 892,
      "y": 946
    },
    {
      "t": 54500,
      "e": 29755,
      "ty": 2,
      "x": 874,
      "y": 895
    },
    {
      "t": 54500,
      "e": 29755,
      "ty": 41,
      "x": 28561,
      "y": 61498,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 54600,
      "e": 29855,
      "ty": 2,
      "x": 800,
      "y": 703
    },
    {
      "t": 54700,
      "e": 29955,
      "ty": 2,
      "x": 763,
      "y": 622
    },
    {
      "t": 54751,
      "e": 30006,
      "ty": 41,
      "x": 22755,
      "y": 54616,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 54800,
      "e": 30055,
      "ty": 2,
      "x": 749,
      "y": 603
    },
    {
      "t": 54900,
      "e": 30155,
      "ty": 2,
      "x": 737,
      "y": 591
    },
    {
      "t": 55000,
      "e": 30255,
      "ty": 2,
      "x": 731,
      "y": 583
    },
    {
      "t": 55001,
      "e": 30256,
      "ty": 41,
      "x": 21525,
      "y": 46814,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 55100,
      "e": 30355,
      "ty": 2,
      "x": 727,
      "y": 577
    },
    {
      "t": 55201,
      "e": 30456,
      "ty": 2,
      "x": 724,
      "y": 571
    },
    {
      "t": 55251,
      "e": 30506,
      "ty": 41,
      "x": 21132,
      "y": 43434,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 55301,
      "e": 30556,
      "ty": 2,
      "x": 723,
      "y": 570
    },
    {
      "t": 60005,
      "e": 35260,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60405,
      "e": 35556,
      "ty": 2,
      "x": 626,
      "y": 391
    },
    {
      "t": 60505,
      "e": 35656,
      "ty": 2,
      "x": 594,
      "y": 405
    },
    {
      "t": 60505,
      "e": 35656,
      "ty": 41,
      "x": 14786,
      "y": 524,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 60604,
      "e": 35755,
      "ty": 2,
      "x": 620,
      "y": 543
    },
    {
      "t": 60705,
      "e": 35856,
      "ty": 2,
      "x": 867,
      "y": 672
    },
    {
      "t": 60755,
      "e": 35906,
      "ty": 41,
      "x": 28462,
      "y": 943,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 60804,
      "e": 35955,
      "ty": 2,
      "x": 872,
      "y": 675
    },
    {
      "t": 60905,
      "e": 36056,
      "ty": 2,
      "x": 871,
      "y": 678
    },
    {
      "t": 61004,
      "e": 36155,
      "ty": 2,
      "x": 865,
      "y": 678
    },
    {
      "t": 61005,
      "e": 36156,
      "ty": 41,
      "x": 28118,
      "y": 2347,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 61105,
      "e": 36256,
      "ty": 2,
      "x": 860,
      "y": 674
    },
    {
      "t": 61254,
      "e": 36405,
      "ty": 41,
      "x": 27872,
      "y": 475,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 61404,
      "e": 36555,
      "ty": 2,
      "x": 845,
      "y": 622
    },
    {
      "t": 61504,
      "e": 36655,
      "ty": 2,
      "x": 816,
      "y": 548
    },
    {
      "t": 61505,
      "e": 36656,
      "ty": 41,
      "x": 25707,
      "y": 37712,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61605,
      "e": 36756,
      "ty": 2,
      "x": 742,
      "y": 390
    },
    {
      "t": 61705,
      "e": 36856,
      "ty": 2,
      "x": 759,
      "y": 416
    },
    {
      "t": 61754,
      "e": 36905,
      "ty": 41,
      "x": 23838,
      "y": 9886,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61804,
      "e": 36955,
      "ty": 2,
      "x": 778,
      "y": 451
    },
    {
      "t": 61904,
      "e": 37055,
      "ty": 2,
      "x": 713,
      "y": 581
    },
    {
      "t": 62004,
      "e": 37155,
      "ty": 2,
      "x": 802,
      "y": 831
    },
    {
      "t": 62004,
      "e": 37155,
      "ty": 41,
      "x": 25018,
      "y": 18,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 62104,
      "e": 37255,
      "ty": 2,
      "x": 844,
      "y": 855
    },
    {
      "t": 62254,
      "e": 37405,
      "ty": 41,
      "x": 27085,
      "y": 28104,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 62304,
      "e": 37455,
      "ty": 2,
      "x": 844,
      "y": 860
    },
    {
      "t": 62404,
      "e": 37555,
      "ty": 2,
      "x": 844,
      "y": 890
    },
    {
      "t": 62504,
      "e": 37655,
      "ty": 2,
      "x": 844,
      "y": 902
    },
    {
      "t": 62504,
      "e": 37655,
      "ty": 41,
      "x": 27085,
      "y": 62223,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 62604,
      "e": 37755,
      "ty": 2,
      "x": 843,
      "y": 917
    },
    {
      "t": 62704,
      "e": 37855,
      "ty": 2,
      "x": 831,
      "y": 919
    },
    {
      "t": 62754,
      "e": 37905,
      "ty": 41,
      "x": 41164,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 62804,
      "e": 37955,
      "ty": 2,
      "x": 812,
      "y": 920
    },
    {
      "t": 62905,
      "e": 38056,
      "ty": 2,
      "x": 811,
      "y": 920
    },
    {
      "t": 63002,
      "e": 38153,
      "ty": 3,
      "x": 811,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 63005,
      "e": 38156,
      "ty": 41,
      "x": 24780,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 63103,
      "e": 38254,
      "ty": 4,
      "x": 24780,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 63104,
      "e": 38255,
      "ty": 5,
      "x": 811,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 63105,
      "e": 38256,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 63109,
      "e": 38260,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 63204,
      "e": 38355,
      "ty": 2,
      "x": 812,
      "y": 920
    },
    {
      "t": 63255,
      "e": 38406,
      "ty": 41,
      "x": 44440,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 63304,
      "e": 38455,
      "ty": 2,
      "x": 872,
      "y": 969
    },
    {
      "t": 63405,
      "e": 38556,
      "ty": 2,
      "x": 962,
      "y": 1048
    },
    {
      "t": 63456,
      "e": 38607,
      "ty": 6,
      "x": 991,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 63504,
      "e": 38655,
      "ty": 2,
      "x": 992,
      "y": 1098
    },
    {
      "t": 63504,
      "e": 38655,
      "ty": 41,
      "x": 45055,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 63571,
      "e": 38722,
      "ty": 7,
      "x": 991,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 63605,
      "e": 38756,
      "ty": 2,
      "x": 990,
      "y": 1108
    },
    {
      "t": 63755,
      "e": 38906,
      "ty": 41,
      "x": 47044,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 63872,
      "e": 39023,
      "ty": 6,
      "x": 993,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 63905,
      "e": 39056,
      "ty": 2,
      "x": 997,
      "y": 1102
    },
    {
      "t": 64005,
      "e": 39156,
      "ty": 2,
      "x": 1004,
      "y": 1097
    },
    {
      "t": 64005,
      "e": 39156,
      "ty": 41,
      "x": 51608,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 64104,
      "e": 39255,
      "ty": 2,
      "x": 1004,
      "y": 1095
    },
    {
      "t": 64255,
      "e": 39406,
      "ty": 41,
      "x": 51608,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 64616,
      "e": 39767,
      "ty": 3,
      "x": 1004,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 64616,
      "e": 39767,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 64616,
      "e": 39767,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64751,
      "e": 39902,
      "ty": 4,
      "x": 51608,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 64753,
      "e": 39904,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64754,
      "e": 39905,
      "ty": 5,
      "x": 1004,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 64755,
      "e": 39906,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 65758,
      "e": 40909,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 66305,
      "e": 41456,
      "ty": 2,
      "x": 1001,
      "y": 1079
    },
    {
      "t": 66404,
      "e": 41555,
      "ty": 2,
      "x": 991,
      "y": 964
    },
    {
      "t": 66490,
      "e": 41641,
      "ty": 6,
      "x": 930,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66505,
      "e": 41656,
      "ty": 2,
      "x": 930,
      "y": 736
    },
    {
      "t": 66505,
      "e": 41656,
      "ty": 41,
      "x": 17563,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66507,
      "e": 41658,
      "ty": 7,
      "x": 923,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66574,
      "e": 41725,
      "ty": 6,
      "x": 902,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66590,
      "e": 41741,
      "ty": 7,
      "x": 900,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66604,
      "e": 41755,
      "ty": 2,
      "x": 900,
      "y": 584
    },
    {
      "t": 66705,
      "e": 41856,
      "ty": 2,
      "x": 892,
      "y": 507
    },
    {
      "t": 66754,
      "e": 41905,
      "ty": 41,
      "x": 24082,
      "y": 49151,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 66804,
      "e": 41955,
      "ty": 2,
      "x": 891,
      "y": 513
    },
    {
      "t": 66905,
      "e": 42056,
      "ty": 2,
      "x": 884,
      "y": 553
    },
    {
      "t": 66959,
      "e": 42110,
      "ty": 6,
      "x": 884,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67005,
      "e": 42156,
      "ty": 2,
      "x": 884,
      "y": 590
    },
    {
      "t": 67005,
      "e": 42156,
      "ty": 41,
      "x": 16437,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67232,
      "e": 42383,
      "ty": 3,
      "x": 884,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67234,
      "e": 42385,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67399,
      "e": 42550,
      "ty": 4,
      "x": 16437,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67400,
      "e": 42551,
      "ty": 5,
      "x": 884,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67805,
      "e": 42956,
      "ty": 2,
      "x": 885,
      "y": 590
    },
    {
      "t": 67904,
      "e": 43055,
      "ty": 2,
      "x": 887,
      "y": 590
    },
    {
      "t": 68005,
      "e": 43156,
      "ty": 41,
      "x": 17086,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70005,
      "e": 45156,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70324,
      "e": 45475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 70325,
      "e": 45476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70419,
      "e": 45570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "s"
    },
    {
      "t": 70755,
      "e": 45906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 70843,
      "e": 45994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 71092,
      "e": 46243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 71093,
      "e": 46244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71179,
      "e": 46330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "u"
    },
    {
      "t": 71276,
      "e": 46427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 71276,
      "e": 46427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71388,
      "e": 46539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "un"
    },
    {
      "t": 71500,
      "e": 46651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 71501,
      "e": 46652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71571,
      "e": 46722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "uno"
    },
    {
      "t": 71868,
      "e": 47019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 71940,
      "e": 47091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "un"
    },
    {
      "t": 72100,
      "e": 47251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 72100,
      "e": 47251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72179,
      "e": 47330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "uni"
    },
    {
      "t": 72203,
      "e": 47354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 72203,
      "e": 47354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72291,
      "e": 47442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "unif"
    },
    {
      "t": 72450,
      "e": 47601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 72451,
      "e": 47602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72547,
      "e": 47698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||o"
    },
    {
      "t": 72612,
      "e": 47763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 72612,
      "e": 47763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72659,
      "e": 47810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 72809,
      "e": 47960,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "unifor"
    },
    {
      "t": 72827,
      "e": 47978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 72827,
      "e": 47978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72931,
      "e": 48082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 73093,
      "e": 48244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 73094,
      "e": 48245,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "uniform"
    },
    {
      "t": 73094,
      "e": 48245,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73094,
      "e": 48245,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73195,
      "e": 48346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 74507,
      "e": 49658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 74509,
      "e": 49660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74587,
      "e": 49738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 74699,
      "e": 49850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 74701,
      "e": 49852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74795,
      "e": 49946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 74891,
      "e": 50042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "53"
    },
    {
      "t": 74891,
      "e": 50042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75009,
      "e": 50160,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 75019,
      "e": 50170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 76449,
      "e": 51600,
      "ty": 7,
      "x": 974,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76504,
      "e": 51655,
      "ty": 2,
      "x": 1239,
      "y": 629
    },
    {
      "t": 76505,
      "e": 51656,
      "ty": 41,
      "x": 42392,
      "y": 34401,
      "ta": "html > body"
    },
    {
      "t": 76605,
      "e": 51756,
      "ty": 2,
      "x": 1383,
      "y": 649
    },
    {
      "t": 76755,
      "e": 51906,
      "ty": 41,
      "x": 47351,
      "y": 35509,
      "ta": "html > body"
    },
    {
      "t": 77005,
      "e": 52156,
      "ty": 2,
      "x": 1307,
      "y": 659
    },
    {
      "t": 77005,
      "e": 52156,
      "ty": 41,
      "x": 44734,
      "y": 36063,
      "ta": "html > body"
    },
    {
      "t": 77105,
      "e": 52256,
      "ty": 2,
      "x": 1216,
      "y": 707
    },
    {
      "t": 77205,
      "e": 52356,
      "ty": 2,
      "x": 1182,
      "y": 710
    },
    {
      "t": 77255,
      "e": 52406,
      "ty": 41,
      "x": 39293,
      "y": 38667,
      "ta": "html > body"
    },
    {
      "t": 77305,
      "e": 52456,
      "ty": 2,
      "x": 1106,
      "y": 706
    },
    {
      "t": 77405,
      "e": 52556,
      "ty": 2,
      "x": 1063,
      "y": 710
    },
    {
      "t": 77484,
      "e": 52635,
      "ty": 6,
      "x": 1022,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77505,
      "e": 52656,
      "ty": 2,
      "x": 1021,
      "y": 727
    },
    {
      "t": 77505,
      "e": 52656,
      "ty": 41,
      "x": 64463,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77605,
      "e": 52756,
      "ty": 2,
      "x": 1007,
      "y": 737
    },
    {
      "t": 77755,
      "e": 52906,
      "ty": 41,
      "x": 57248,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78856,
      "e": 54007,
      "ty": 3,
      "x": 1007,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78858,
      "e": 54009,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 78859,
      "e": 54010,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78859,
      "e": 54010,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 80005,
      "e": 55156,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80071,
      "e": 55223,
      "ty": 4,
      "x": 57248,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 80072,
      "e": 55224,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 80073,
      "e": 55225,
      "ty": 5,
      "x": 1007,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 80073,
      "e": 55225,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 81200,
      "e": 56352,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 81233,
      "e": 56385,
      "ty": 6,
      "x": 1007,
      "y": 737,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 82405,
      "e": 57557,
      "ty": 2,
      "x": 1007,
      "y": 738
    },
    {
      "t": 82506,
      "e": 57658,
      "ty": 41,
      "x": 34197,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 90004,
      "e": 62658,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 93004,
      "e": 62658,
      "ty": 2,
      "x": 1051,
      "y": 750
    },
    {
      "t": 93005,
      "e": 62659,
      "ty": 41,
      "x": 36426,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 93062,
      "e": 62716,
      "ty": 7,
      "x": 1058,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 93062,
      "e": 62716,
      "ty": 6,
      "x": 1058,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 93104,
      "e": 62758,
      "ty": 2,
      "x": 1065,
      "y": 765
    },
    {
      "t": 93127,
      "e": 62781,
      "ty": 7,
      "x": 1079,
      "y": 801,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 93205,
      "e": 62859,
      "ty": 2,
      "x": 1102,
      "y": 887
    },
    {
      "t": 93255,
      "e": 62909,
      "ty": 41,
      "x": 40171,
      "y": 55654,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93305,
      "e": 62959,
      "ty": 2,
      "x": 1098,
      "y": 968
    },
    {
      "t": 93405,
      "e": 63059,
      "ty": 2,
      "x": 1044,
      "y": 1042
    },
    {
      "t": 93461,
      "e": 63115,
      "ty": 6,
      "x": 1014,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 93505,
      "e": 63159,
      "ty": 2,
      "x": 1009,
      "y": 1084
    },
    {
      "t": 93505,
      "e": 63159,
      "ty": 41,
      "x": 54339,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 93604,
      "e": 63258,
      "ty": 2,
      "x": 1007,
      "y": 1094
    },
    {
      "t": 93704,
      "e": 63358,
      "ty": 2,
      "x": 1007,
      "y": 1095
    },
    {
      "t": 93754,
      "e": 63408,
      "ty": 41,
      "x": 53247,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 100005,
      "e": 68408,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 102568,
      "e": 68408,
      "ty": 3,
      "x": 1007,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 102569,
      "e": 68409,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 106240,
      "e": 72080,
      "ty": 4,
      "x": 53247,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 106242,
      "e": 72082,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 106243,
      "e": 72083,
      "ty": 5,
      "x": 1007,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 106245,
      "e": 72085,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 107247,
      "e": 73087,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 109205,
      "e": 75045,
      "ty": 2,
      "x": 910,
      "y": 1091
    },
    {
      "t": 109255,
      "e": 75095,
      "ty": 41,
      "x": 29685,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 109304,
      "e": 75144,
      "ty": 2,
      "x": 833,
      "y": 1073
    },
    {
      "t": 109405,
      "e": 75245,
      "ty": 2,
      "x": 796,
      "y": 1066
    },
    {
      "t": 109505,
      "e": 75345,
      "ty": 2,
      "x": 795,
      "y": 1066
    },
    {
      "t": 109505,
      "e": 75345,
      "ty": 41,
      "x": 27102,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 110005,
      "e": 75845,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110255,
      "e": 76095,
      "ty": 41,
      "x": 27068,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 110306,
      "e": 76146,
      "ty": 2,
      "x": 794,
      "y": 1066
    },
    {
      "t": 111205,
      "e": 77045,
      "ty": 2,
      "x": 794,
      "y": 1065
    },
    {
      "t": 111255,
      "e": 77095,
      "ty": 41,
      "x": 27068,
      "y": 58554,
      "ta": "html > body"
    },
    {
      "t": 111305,
      "e": 77145,
      "ty": 2,
      "x": 792,
      "y": 1063
    },
    {
      "t": 111405,
      "e": 77245,
      "ty": 2,
      "x": 791,
      "y": 1062
    },
    {
      "t": 111506,
      "e": 77346,
      "ty": 41,
      "x": 26964,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 120008,
      "e": 82346,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 122129,
      "e": 82346,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 123135,
      "e": 82346,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 266, dom: 722, initialDom: 726",
  "javascriptErrors": []
}