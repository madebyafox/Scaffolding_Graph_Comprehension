var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052247111d800e71ba9271301e04cf6ae64f72d3"] = {
  "startTime": "2018-05-22T23:15:47.4251801Z",
  "websitePageUrl": "/16",
  "visitTime": 119234,
  "engagementTime": 108388,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "7cb6ca5ad86441b7c768087224a77c2b",
    "created": "2018-05-22T23:15:47.4251801+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=AS12V",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4391f90578c3db8819a577aee6a8dbbd",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7cb6ca5ad86441b7c768087224a77c2b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 174,
      "e": 174,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 532,
      "y": 741
    },
    {
      "t": 1370,
      "e": 1370,
      "ty": 6,
      "x": 531,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 534,
      "y": 579
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 554,
      "y": 540
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 51360,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1661,
      "e": 1661,
      "ty": 3,
      "x": 554,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1662,
      "e": 1662,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1749,
      "e": 1749,
      "ty": 4,
      "x": 51360,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1749,
      "e": 1749,
      "ty": 5,
      "x": 554,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 6749,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 17395,
      "e": 6749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17396,
      "e": 6750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17465,
      "e": 6819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 17825,
      "e": 7179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17904,
      "e": 7258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 18090,
      "e": 7444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18209,
      "e": 7563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18210,
      "e": 7564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18281,
      "e": 7635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 18403,
      "e": 7757,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 18403,
      "e": 7757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18404,
      "e": 7758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18424,
      "e": 7778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 18544,
      "e": 7898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 18818,
      "e": 8172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18818,
      "e": 8172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18889,
      "e": 8243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 19003,
      "e": 8357,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 19009,
      "e": 8363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19010,
      "e": 8364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19057,
      "e": 8411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I lo"
    },
    {
      "t": 19146,
      "e": 8500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19146,
      "e": 8500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19209,
      "e": 8563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19329,
      "e": 8683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 19330,
      "e": 8684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19409,
      "e": 8763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 19417,
      "e": 8771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19417,
      "e": 8771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19561,
      "e": 8915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19561,
      "e": 8915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19585,
      "e": 8939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 19665,
      "e": 9019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19666,
      "e": 9020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19722,
      "e": 9076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19738,
      "e": 9092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19738,
      "e": 9092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19761,
      "e": 9115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19833,
      "e": 9187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19833,
      "e": 9187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19864,
      "e": 9218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19953,
      "e": 9307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20042,
      "e": 9396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20042,
      "e": 9396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20129,
      "e": 9483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20208,
      "e": 9562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20208,
      "e": 9562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20305,
      "e": 9659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20305,
      "e": 9659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20337,
      "e": 9691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 20417,
      "e": 9771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21465,
      "e": 10819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 21466,
      "e": 10820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21537,
      "e": 10891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 21834,
      "e": 11188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 21834,
      "e": 11188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21937,
      "e": 11291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 22200,
      "e": 11554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22256,
      "e": 11610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the y"
    },
    {
      "t": 22344,
      "e": 11698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22416,
      "e": 11770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the "
    },
    {
      "t": 22521,
      "e": 11875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 22521,
      "e": 11875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22664,
      "e": 12018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 22955,
      "e": 12309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 22955,
      "e": 12309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23049,
      "e": 12403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 23049,
      "e": 12403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 23049,
      "e": 12403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23161,
      "e": 12515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 24209,
      "e": 13563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24210,
      "e": 13564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24328,
      "e": 13682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24409,
      "e": 13763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24409,
      "e": 13763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24529,
      "e": 13883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24657,
      "e": 14011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 24658,
      "e": 14012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24729,
      "e": 14083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 24913,
      "e": 14267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24914,
      "e": 14268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24993,
      "e": 14347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25329,
      "e": 14683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25393,
      "e": 14747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y ac"
    },
    {
      "t": 25480,
      "e": 14834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25561,
      "e": 14915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y a"
    },
    {
      "t": 25649,
      "e": 15003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 25650,
      "e": 15004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25656,
      "e": 15010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 25656,
      "e": 15010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25713,
      "e": 15067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||cx"
    },
    {
      "t": 25720,
      "e": 15074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26113,
      "e": 15467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26114,
      "e": 15468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26209,
      "e": 15563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26337,
      "e": 15691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26338,
      "e": 15692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26425,
      "e": 15779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26425,
      "e": 15779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26441,
      "e": 15795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 26505,
      "e": 15859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27818,
      "e": 17172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27880,
      "e": 17234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y acxes"
    },
    {
      "t": 27976,
      "e": 17330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28041,
      "e": 17395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y acxe"
    },
    {
      "t": 28129,
      "e": 17483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28185,
      "e": 17539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y acx"
    },
    {
      "t": 28272,
      "e": 17626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28337,
      "e": 17691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y ac"
    },
    {
      "t": 28456,
      "e": 17810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28513,
      "e": 17867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y a"
    },
    {
      "t": 28545,
      "e": 17868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 28545,
      "e": 17868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28665,
      "e": 17988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 28874,
      "e": 18197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28874,
      "e": 18197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28985,
      "e": 18308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29097,
      "e": 18420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29098,
      "e": 18421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29202,
      "e": 18525,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes"
    },
    {
      "t": 29224,
      "e": 18547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 29378,
      "e": 18701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 29378,
      "e": 18701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29424,
      "e": 18747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29424,
      "e": 18747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29440,
      "e": 18763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 29545,
      "e": 18868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29849,
      "e": 19172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29850,
      "e": 19173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29945,
      "e": 19268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30009,
      "e": 19332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30010,
      "e": 19333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30073,
      "e": 19396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30073,
      "e": 19396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30105,
      "e": 19428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 30169,
      "e": 19492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32129,
      "e": 21452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32130,
      "e": 21453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32192,
      "e": 21515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32288,
      "e": 21611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32289,
      "e": 21612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32385,
      "e": 21708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 32489,
      "e": 21812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32490,
      "e": 21813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32584,
      "e": 21907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32584,
      "e": 21907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32609,
      "e": 21932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 32712,
      "e": 22035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32721,
      "e": 22044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32721,
      "e": 22044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32793,
      "e": 22116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32794,
      "e": 22117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32833,
      "e": 22156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 32889,
      "e": 22212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32961,
      "e": 22284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32963,
      "e": 22286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33016,
      "e": 22339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33017,
      "e": 22340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33065,
      "e": 22388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 33105,
      "e": 22428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33105,
      "e": 22428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33153,
      "e": 22476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33224,
      "e": 22547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33297,
      "e": 22620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33297,
      "e": 22620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33403,
      "e": 22726,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a"
    },
    {
      "t": 33409,
      "e": 22732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33433,
      "e": 22756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33434,
      "e": 22757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33480,
      "e": 22803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33602,
      "e": 22925,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a "
    },
    {
      "t": 34217,
      "e": 23540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34218,
      "e": 23541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34298,
      "e": 23621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34298,
      "e": 23621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34344,
      "e": 23667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 34393,
      "e": 23716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34393,
      "e": 23716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34416,
      "e": 23739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34513,
      "e": 23836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34545,
      "e": 23868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34546,
      "e": 23869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34632,
      "e": 23955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34761,
      "e": 24084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34762,
      "e": 24085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34857,
      "e": 24180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34858,
      "e": 24181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34897,
      "e": 24220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 34960,
      "e": 24283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35090,
      "e": 24413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35090,
      "e": 24413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35203,
      "e": 24526,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift d"
    },
    {
      "t": 35249,
      "e": 24572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35337,
      "e": 24660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35338,
      "e": 24661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35456,
      "e": 24779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35488,
      "e": 24811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35489,
      "e": 24812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35593,
      "e": 24916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 35609,
      "e": 24932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 35610,
      "e": 24933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35720,
      "e": 25043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 35720,
      "e": 25043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35721,
      "e": 25044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35849,
      "e": 25172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35865,
      "e": 25188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35866,
      "e": 25189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35969,
      "e": 25292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35977,
      "e": 25300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35978,
      "e": 25301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36073,
      "e": 25396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36552,
      "e": 25875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36609,
      "e": 25932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift daught"
    },
    {
      "t": 36697,
      "e": 26020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36761,
      "e": 26021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift daugh"
    },
    {
      "t": 36824,
      "e": 26084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36897,
      "e": 26157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift daug"
    },
    {
      "t": 36969,
      "e": 26229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37024,
      "e": 26284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift dau"
    },
    {
      "t": 37112,
      "e": 26372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37177,
      "e": 26437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift da"
    },
    {
      "t": 37402,
      "e": 26662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37481,
      "e": 26741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift d"
    },
    {
      "t": 37592,
      "e": 26852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37593,
      "e": 26853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37689,
      "e": 26949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37690,
      "e": 26950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37728,
      "e": 26988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 37752,
      "e": 27012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37753,
      "e": 27013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37792,
      "e": 27052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37856,
      "e": 27116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38380,
      "e": 27640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38380,
      "e": 27640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38488,
      "e": 27748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38497,
      "e": 27757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 38497,
      "e": 27757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38593,
      "e": 27853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 38625,
      "e": 27885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38625,
      "e": 27885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38715,
      "e": 27975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38763,
      "e": 28023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 38764,
      "e": 28024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38890,
      "e": 28150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38890,
      "e": 28150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38938,
      "e": 28198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 38995,
      "e": 28255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39003,
      "e": 28263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39004,
      "e": 28264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39098,
      "e": 28358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39899,
      "e": 29159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39900,
      "e": 29160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39963,
      "e": 29223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40075,
      "e": 29335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40076,
      "e": 29336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40171,
      "e": 29431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 40250,
      "e": 29510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40251,
      "e": 29511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40339,
      "e": 29599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40340,
      "e": 29600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40362,
      "e": 29622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 40418,
      "e": 29678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41035,
      "e": 30295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 41036,
      "e": 30296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41083,
      "e": 30343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 41213,
      "e": 30473,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift dot above the x"
    },
    {
      "t": 41563,
      "e": 30823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41564,
      "e": 30824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41715,
      "e": 30975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41731,
      "e": 30991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41732,
      "e": 30992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41850,
      "e": 31110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 42059,
      "e": 31319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 42060,
      "e": 31320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42187,
      "e": 31447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 42467,
      "e": 31727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42468,
      "e": 31728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42554,
      "e": 31814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42651,
      "e": 31911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42651,
      "e": 31911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42715,
      "e": 31975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42716,
      "e": 31976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42763,
      "e": 32023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 42811,
      "e": 32071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44476,
      "e": 33736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 44476,
      "e": 33736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44610,
      "e": 33870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 44618,
      "e": 33878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44619,
      "e": 33879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44731,
      "e": 33991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44867,
      "e": 34127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44868,
      "e": 34128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44946,
      "e": 34206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44946,
      "e": 34206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45002,
      "e": 34262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 45058,
      "e": 34318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45059,
      "e": 34319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45090,
      "e": 34350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45115,
      "e": 34375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45115,
      "e": 34375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45179,
      "e": 34439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45235,
      "e": 34495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45276,
      "e": 34536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45276,
      "e": 34536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45362,
      "e": 34622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45370,
      "e": 34630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 45371,
      "e": 34631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45467,
      "e": 34727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 45475,
      "e": 34728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45476,
      "e": 34729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45522,
      "e": 34775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47635,
      "e": 36888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 47636,
      "e": 36889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47723,
      "e": 36976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 47723,
      "e": 36976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47770,
      "e": 37023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 47794,
      "e": 37047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48043,
      "e": 37296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 48043,
      "e": 37296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48147,
      "e": 37400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 48227,
      "e": 37480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 48227,
      "e": 37480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48379,
      "e": 37632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 48413,
      "e": 37666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48414,
      "e": 37667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48498,
      "e": 37751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48613,
      "e": 37866,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift dot above the x axes point of 12pm "
    },
    {
      "t": 48803,
      "e": 38056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 48875,
      "e": 38128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48876,
      "e": 38129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48938,
      "e": 38191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48938,
      "e": 38191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48954,
      "e": 38207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I "
    },
    {
      "t": 48971,
      "e": 38224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49051,
      "e": 38304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49195,
      "e": 38448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49196,
      "e": 38449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49258,
      "e": 38511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 49387,
      "e": 38640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49387,
      "e": 38640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49475,
      "e": 38728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49475,
      "e": 38728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49506,
      "e": 38759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||et"
    },
    {
      "t": 49578,
      "e": 38831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49619,
      "e": 38872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49620,
      "e": 38873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49698,
      "e": 38951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49700,
      "e": 38953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49762,
      "e": 39015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 49810,
      "e": 39063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49811,
      "e": 39064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49818,
      "e": 39071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 49906,
      "e": 39159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49987,
      "e": 39240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49987,
      "e": 39240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50058,
      "e": 39311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50058,
      "e": 39311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50074,
      "e": 39327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 50114,
      "e": 39367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50115,
      "e": 39368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50155,
      "e": 39408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50186,
      "e": 39439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50187,
      "e": 39440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50234,
      "e": 39487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50291,
      "e": 39544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50291,
      "e": 39544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50323,
      "e": 39576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50371,
      "e": 39624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50475,
      "e": 39728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50476,
      "e": 39729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50570,
      "e": 39823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50570,
      "e": 39823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50578,
      "e": 39831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 50715,
      "e": 39968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50716,
      "e": 39969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50730,
      "e": 39983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50747,
      "e": 40000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50747,
      "e": 40000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50802,
      "e": 40055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50875,
      "e": 40128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50875,
      "e": 40128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50882,
      "e": 40135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 50995,
      "e": 40248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50996,
      "e": 40249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50997,
      "e": 40250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51074,
      "e": 40327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51074,
      "e": 40327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51106,
      "e": 40359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 51179,
      "e": 40432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52867,
      "e": 42120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 52868,
      "e": 42121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52938,
      "e": 42191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 52970,
      "e": 42223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52970,
      "e": 42223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53058,
      "e": 42311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53059,
      "e": 42312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53075,
      "e": 42328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 53139,
      "e": 42392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53140,
      "e": 42393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53210,
      "e": 42463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53211,
      "e": 42464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53211,
      "e": 42464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53234,
      "e": 42487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53299,
      "e": 42552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53363,
      "e": 42616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 53363,
      "e": 42616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53450,
      "e": 42703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53450,
      "e": 42703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53483,
      "e": 42736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 53570,
      "e": 42823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53570,
      "e": 42823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53571,
      "e": 42824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53691,
      "e": 42944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53692,
      "e": 42945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53754,
      "e": 43007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 53763,
      "e": 43016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53850,
      "e": 43103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53851,
      "e": 43104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53954,
      "e": 43207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54002,
      "e": 43255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54002,
      "e": 43255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54131,
      "e": 43384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54133,
      "e": 43386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54178,
      "e": 43431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 54186,
      "e": 43439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54186,
      "e": 43439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54202,
      "e": 43455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54323,
      "e": 43576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54323,
      "e": 43576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54355,
      "e": 43608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54395,
      "e": 43648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54396,
      "e": 43649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54459,
      "e": 43712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54523,
      "e": 43776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54899,
      "e": 44152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 54900,
      "e": 44153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55010,
      "e": 44263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 55010,
      "e": 44263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55050,
      "e": 44303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 55115,
      "e": 44368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55123,
      "e": 44376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 55124,
      "e": 44377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55251,
      "e": 44504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 55275,
      "e": 44528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55277,
      "e": 44530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55330,
      "e": 44583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55910,
      "e": 45163,
      "ty": 2,
      "x": 554,
      "y": 539
    },
    {
      "t": 55923,
      "e": 45176,
      "ty": 7,
      "x": 608,
      "y": 518,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56010,
      "e": 45263,
      "ty": 2,
      "x": 667,
      "y": 682
    },
    {
      "t": 56011,
      "e": 45264,
      "ty": 41,
      "x": 64063,
      "y": 37337,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 56110,
      "e": 45363,
      "ty": 2,
      "x": 504,
      "y": 746
    },
    {
      "t": 56210,
      "e": 45463,
      "ty": 2,
      "x": 447,
      "y": 741
    },
    {
      "t": 56261,
      "e": 45514,
      "ty": 41,
      "x": 40906,
      "y": 38390,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 56310,
      "e": 45563,
      "ty": 2,
      "x": 462,
      "y": 672
    },
    {
      "t": 56410,
      "e": 45663,
      "ty": 2,
      "x": 461,
      "y": 671
    },
    {
      "t": 56510,
      "e": 45763,
      "ty": 41,
      "x": 40906,
      "y": 36728,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 56810,
      "e": 46063,
      "ty": 2,
      "x": 459,
      "y": 671
    },
    {
      "t": 56826,
      "e": 46079,
      "ty": 6,
      "x": 457,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 56902,
      "e": 46155,
      "ty": 3,
      "x": 446,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 56902,
      "e": 46155,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the x,y axes. if there is a shift dot above the x axes point of 12pm I determine that is what starts at 12. "
    },
    {
      "t": 56903,
      "e": 46156,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56903,
      "e": 46156,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56910,
      "e": 46163,
      "ty": 2,
      "x": 446,
      "y": 674
    },
    {
      "t": 57010,
      "e": 46263,
      "ty": 2,
      "x": 441,
      "y": 674
    },
    {
      "t": 57010,
      "e": 46263,
      "ty": 41,
      "x": 55926,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 57038,
      "e": 46291,
      "ty": 4,
      "x": 55380,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 57057,
      "e": 46310,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 57059,
      "e": 46312,
      "ty": 5,
      "x": 440,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 57064,
      "e": 46317,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 57110,
      "e": 46363,
      "ty": 2,
      "x": 440,
      "y": 674
    },
    {
      "t": 57261,
      "e": 46514,
      "ty": 41,
      "x": 14877,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 57411,
      "e": 46664,
      "ty": 2,
      "x": 586,
      "y": 712
    },
    {
      "t": 57510,
      "e": 46763,
      "ty": 2,
      "x": 926,
      "y": 808
    },
    {
      "t": 57510,
      "e": 46763,
      "ty": 41,
      "x": 31613,
      "y": 44317,
      "ta": "html > body"
    },
    {
      "t": 57611,
      "e": 46864,
      "ty": 2,
      "x": 936,
      "y": 812
    },
    {
      "t": 57760,
      "e": 47013,
      "ty": 41,
      "x": 31958,
      "y": 44539,
      "ta": "html > body"
    },
    {
      "t": 58068,
      "e": 47321,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 58760,
      "e": 48013,
      "ty": 41,
      "x": 32164,
      "y": 40052,
      "ta": "html > body"
    },
    {
      "t": 58776,
      "e": 48029,
      "ty": 6,
      "x": 942,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58792,
      "e": 48045,
      "ty": 7,
      "x": 940,
      "y": 674,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58810,
      "e": 48063,
      "ty": 6,
      "x": 937,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58811,
      "e": 48064,
      "ty": 2,
      "x": 937,
      "y": 653
    },
    {
      "t": 58826,
      "e": 48079,
      "ty": 7,
      "x": 936,
      "y": 641,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58911,
      "e": 48164,
      "ty": 2,
      "x": 936,
      "y": 615
    },
    {
      "t": 59010,
      "e": 48263,
      "ty": 2,
      "x": 937,
      "y": 599
    },
    {
      "t": 59011,
      "e": 48264,
      "ty": 41,
      "x": 27901,
      "y": 11274,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 59077,
      "e": 48330,
      "ty": 6,
      "x": 950,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59110,
      "e": 48363,
      "ty": 2,
      "x": 953,
      "y": 568
    },
    {
      "t": 59261,
      "e": 48514,
      "ty": 41,
      "x": 31361,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59424,
      "e": 48677,
      "ty": 3,
      "x": 953,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59425,
      "e": 48678,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59518,
      "e": 48771,
      "ty": 4,
      "x": 31361,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59518,
      "e": 48771,
      "ty": 5,
      "x": 953,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60011,
      "e": 49264,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60028,
      "e": 49281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 60028,
      "e": 49281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60122,
      "e": 49375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 60226,
      "e": 49479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "101"
    },
    {
      "t": 60228,
      "e": 49481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60314,
      "e": 49567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "25"
    },
    {
      "t": 60879,
      "e": 50132,
      "ty": 7,
      "x": 953,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60910,
      "e": 50163,
      "ty": 2,
      "x": 949,
      "y": 596
    },
    {
      "t": 60995,
      "e": 50248,
      "ty": 6,
      "x": 940,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61010,
      "e": 50263,
      "ty": 2,
      "x": 940,
      "y": 655
    },
    {
      "t": 61010,
      "e": 50263,
      "ty": 41,
      "x": 28549,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61010,
      "e": 50263,
      "ty": 7,
      "x": 940,
      "y": 674,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61028,
      "e": 50281,
      "ty": 6,
      "x": 939,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61110,
      "e": 50363,
      "ty": 2,
      "x": 934,
      "y": 695
    },
    {
      "t": 61210,
      "e": 50463,
      "ty": 2,
      "x": 929,
      "y": 686
    },
    {
      "t": 61260,
      "e": 50513,
      "ty": 41,
      "x": 17048,
      "y": 3971,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61262,
      "e": 50515,
      "ty": 7,
      "x": 929,
      "y": 672,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61278,
      "e": 50531,
      "ty": 6,
      "x": 929,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61310,
      "e": 50563,
      "ty": 2,
      "x": 929,
      "y": 658
    },
    {
      "t": 61345,
      "e": 50598,
      "ty": 7,
      "x": 929,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61410,
      "e": 50663,
      "ty": 2,
      "x": 928,
      "y": 638
    },
    {
      "t": 61511,
      "e": 50764,
      "ty": 41,
      "x": 25954,
      "y": 38757,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 61611,
      "e": 50864,
      "ty": 2,
      "x": 925,
      "y": 644
    },
    {
      "t": 61628,
      "e": 50881,
      "ty": 6,
      "x": 924,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61711,
      "e": 50964,
      "ty": 2,
      "x": 924,
      "y": 647
    },
    {
      "t": 61761,
      "e": 51014,
      "ty": 41,
      "x": 25089,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61800,
      "e": 51053,
      "ty": 3,
      "x": 924,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61800,
      "e": 51053,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "25"
    },
    {
      "t": 61801,
      "e": 51054,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61801,
      "e": 51054,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61902,
      "e": 51155,
      "ty": 4,
      "x": 25089,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61902,
      "e": 51155,
      "ty": 5,
      "x": 924,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62395,
      "e": 51648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 62539,
      "e": 51792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 62539,
      "e": 51792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62626,
      "e": 51879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 62650,
      "e": 51903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 62754,
      "e": 52007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 62755,
      "e": 52008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62866,
      "e": 52119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 62866,
      "e": 52119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62882,
      "e": 52135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 62954,
      "e": 52207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 62955,
      "e": 52208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62995,
      "e": 52248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 63027,
      "e": 52280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 63028,
      "e": 52281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63074,
      "e": 52327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 63123,
      "e": 52376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63227,
      "e": 52480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 63227,
      "e": 52480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63306,
      "e": 52559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 63307,
      "e": 52560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63371,
      "e": 52624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 63418,
      "e": 52671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 63459,
      "e": 52712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63514,
      "e": 52767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 63515,
      "e": 52768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63594,
      "e": 52847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 63650,
      "e": 52903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63650,
      "e": 52903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63654,
      "e": 52907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63786,
      "e": 53039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 63786,
      "e": 53039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63794,
      "e": 53047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 63907,
      "e": 53160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63907,
      "e": 53160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63930,
      "e": 53183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 64010,
      "e": 53263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 64010,
      "e": 53263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64018,
      "e": 53271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 64122,
      "e": 53375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 64202,
      "e": 53455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 64204,
      "e": 53457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64282,
      "e": 53535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 64831,
      "e": 54084,
      "ty": 7,
      "x": 952,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64831,
      "e": 54084,
      "ty": 6,
      "x": 952,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64848,
      "e": 54101,
      "ty": 7,
      "x": 974,
      "y": 729,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64911,
      "e": 54164,
      "ty": 2,
      "x": 993,
      "y": 746
    },
    {
      "t": 65011,
      "e": 54264,
      "ty": 2,
      "x": 996,
      "y": 746
    },
    {
      "t": 65011,
      "e": 54264,
      "ty": 41,
      "x": 34024,
      "y": 40883,
      "ta": "html > body"
    },
    {
      "t": 65110,
      "e": 54363,
      "ty": 2,
      "x": 1001,
      "y": 724
    },
    {
      "t": 65182,
      "e": 54435,
      "ty": 6,
      "x": 1007,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65210,
      "e": 54463,
      "ty": 2,
      "x": 1008,
      "y": 706
    },
    {
      "t": 65261,
      "e": 54514,
      "ty": 41,
      "x": 57763,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65310,
      "e": 54563,
      "ty": 2,
      "x": 1009,
      "y": 698
    },
    {
      "t": 65398,
      "e": 54651,
      "ty": 3,
      "x": 1009,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65399,
      "e": 54652,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 65399,
      "e": 54652,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65399,
      "e": 54652,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65411,
      "e": 54664,
      "ty": 2,
      "x": 1009,
      "y": 695
    },
    {
      "t": 65486,
      "e": 54739,
      "ty": 4,
      "x": 58279,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65487,
      "e": 54740,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65488,
      "e": 54741,
      "ty": 5,
      "x": 1009,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65488,
      "e": 54741,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 65511,
      "e": 54764,
      "ty": 41,
      "x": 34472,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 65811,
      "e": 55064,
      "ty": 2,
      "x": 1061,
      "y": 730
    },
    {
      "t": 65911,
      "e": 55164,
      "ty": 2,
      "x": 1430,
      "y": 889
    },
    {
      "t": 66011,
      "e": 55264,
      "ty": 2,
      "x": 1432,
      "y": 892
    },
    {
      "t": 66011,
      "e": 55264,
      "ty": 41,
      "x": 49039,
      "y": 48971,
      "ta": "html > body"
    },
    {
      "t": 66504,
      "e": 55757,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 67211,
      "e": 56464,
      "ty": 2,
      "x": 1403,
      "y": 855
    },
    {
      "t": 67261,
      "e": 56514,
      "ty": 41,
      "x": 42117,
      "y": 35343,
      "ta": "html > body"
    },
    {
      "t": 67311,
      "e": 56564,
      "ty": 2,
      "x": 1097,
      "y": 563
    },
    {
      "t": 67410,
      "e": 56663,
      "ty": 2,
      "x": 961,
      "y": 215
    },
    {
      "t": 67511,
      "e": 56764,
      "ty": 2,
      "x": 948,
      "y": 166
    },
    {
      "t": 67511,
      "e": 56764,
      "ty": 41,
      "x": 30040,
      "y": 373,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67761,
      "e": 57014,
      "ty": 41,
      "x": 30040,
      "y": 971,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67811,
      "e": 57064,
      "ty": 2,
      "x": 943,
      "y": 196
    },
    {
      "t": 67911,
      "e": 57164,
      "ty": 2,
      "x": 915,
      "y": 211
    },
    {
      "t": 68011,
      "e": 57264,
      "ty": 2,
      "x": 886,
      "y": 212
    },
    {
      "t": 68011,
      "e": 57264,
      "ty": 41,
      "x": 15325,
      "y": 13687,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 68111,
      "e": 57364,
      "ty": 2,
      "x": 876,
      "y": 225
    },
    {
      "t": 68211,
      "e": 57464,
      "ty": 2,
      "x": 873,
      "y": 231
    },
    {
      "t": 68261,
      "e": 57514,
      "ty": 41,
      "x": 42235,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 68318,
      "e": 57571,
      "ty": 3,
      "x": 873,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 68414,
      "e": 57667,
      "ty": 4,
      "x": 42235,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 68414,
      "e": 57667,
      "ty": 5,
      "x": 873,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 68415,
      "e": 57668,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68417,
      "e": 57670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 68710,
      "e": 57963,
      "ty": 2,
      "x": 871,
      "y": 276
    },
    {
      "t": 68761,
      "e": 58014,
      "ty": 41,
      "x": 11766,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 68811,
      "e": 58064,
      "ty": 2,
      "x": 872,
      "y": 378
    },
    {
      "t": 68911,
      "e": 58164,
      "ty": 2,
      "x": 873,
      "y": 379
    },
    {
      "t": 69011,
      "e": 58264,
      "ty": 2,
      "x": 873,
      "y": 385
    },
    {
      "t": 69011,
      "e": 58264,
      "ty": 41,
      "x": 12240,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 69111,
      "e": 58364,
      "ty": 2,
      "x": 873,
      "y": 387
    },
    {
      "t": 69211,
      "e": 58464,
      "ty": 2,
      "x": 873,
      "y": 396
    },
    {
      "t": 69261,
      "e": 58514,
      "ty": 41,
      "x": 12240,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 69311,
      "e": 58564,
      "ty": 2,
      "x": 873,
      "y": 403
    },
    {
      "t": 69411,
      "e": 58664,
      "ty": 2,
      "x": 873,
      "y": 417
    },
    {
      "t": 69511,
      "e": 58764,
      "ty": 41,
      "x": 60377,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 69611,
      "e": 58864,
      "ty": 2,
      "x": 877,
      "y": 396
    },
    {
      "t": 69711,
      "e": 58964,
      "ty": 2,
      "x": 897,
      "y": 381
    },
    {
      "t": 69761,
      "e": 59014,
      "ty": 41,
      "x": 18885,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 69811,
      "e": 59064,
      "ty": 2,
      "x": 902,
      "y": 379
    },
    {
      "t": 69911,
      "e": 59164,
      "ty": 2,
      "x": 918,
      "y": 379
    },
    {
      "t": 70011,
      "e": 59264,
      "ty": 2,
      "x": 929,
      "y": 379
    },
    {
      "t": 70011,
      "e": 59264,
      "ty": 41,
      "x": 25530,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 70211,
      "e": 59464,
      "ty": 2,
      "x": 925,
      "y": 379
    },
    {
      "t": 70261,
      "e": 59514,
      "ty": 41,
      "x": 24581,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 70310,
      "e": 59563,
      "ty": 2,
      "x": 937,
      "y": 384
    },
    {
      "t": 70410,
      "e": 59663,
      "ty": 2,
      "x": 943,
      "y": 384
    },
    {
      "t": 70511,
      "e": 59764,
      "ty": 41,
      "x": 28853,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 70611,
      "e": 59864,
      "ty": 2,
      "x": 955,
      "y": 384
    },
    {
      "t": 70711,
      "e": 59964,
      "ty": 2,
      "x": 968,
      "y": 384
    },
    {
      "t": 70761,
      "e": 60014,
      "ty": 41,
      "x": 35498,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 70811,
      "e": 60064,
      "ty": 2,
      "x": 971,
      "y": 384
    },
    {
      "t": 70910,
      "e": 60163,
      "ty": 2,
      "x": 972,
      "y": 384
    },
    {
      "t": 71011,
      "e": 60264,
      "ty": 2,
      "x": 973,
      "y": 389
    },
    {
      "t": 71011,
      "e": 60264,
      "ty": 41,
      "x": 35973,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 71110,
      "e": 60363,
      "ty": 2,
      "x": 882,
      "y": 491
    },
    {
      "t": 71211,
      "e": 60464,
      "ty": 2,
      "x": 876,
      "y": 499
    },
    {
      "t": 71261,
      "e": 60514,
      "ty": 41,
      "x": 11766,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 71310,
      "e": 60563,
      "ty": 2,
      "x": 866,
      "y": 529
    },
    {
      "t": 71410,
      "e": 60663,
      "ty": 2,
      "x": 859,
      "y": 569
    },
    {
      "t": 71511,
      "e": 60764,
      "ty": 2,
      "x": 859,
      "y": 570
    },
    {
      "t": 71512,
      "e": 60765,
      "ty": 41,
      "x": 8918,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 71611,
      "e": 60864,
      "ty": 2,
      "x": 859,
      "y": 559
    },
    {
      "t": 71710,
      "e": 60963,
      "ty": 2,
      "x": 859,
      "y": 542
    },
    {
      "t": 71761,
      "e": 61014,
      "ty": 41,
      "x": 45146,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 71810,
      "e": 61063,
      "ty": 2,
      "x": 860,
      "y": 521
    },
    {
      "t": 71911,
      "e": 61164,
      "ty": 2,
      "x": 860,
      "y": 517
    },
    {
      "t": 72011,
      "e": 61264,
      "ty": 2,
      "x": 856,
      "y": 524
    },
    {
      "t": 72011,
      "e": 61264,
      "ty": 41,
      "x": 40465,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72110,
      "e": 61363,
      "ty": 2,
      "x": 852,
      "y": 548
    },
    {
      "t": 72211,
      "e": 61464,
      "ty": 2,
      "x": 851,
      "y": 548
    },
    {
      "t": 72262,
      "e": 61515,
      "ty": 41,
      "x": 6782,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 72311,
      "e": 61564,
      "ty": 2,
      "x": 849,
      "y": 537
    },
    {
      "t": 72411,
      "e": 61664,
      "ty": 2,
      "x": 844,
      "y": 520
    },
    {
      "t": 72511,
      "e": 61764,
      "ty": 2,
      "x": 844,
      "y": 508
    },
    {
      "t": 72511,
      "e": 61764,
      "ty": 41,
      "x": 20264,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72710,
      "e": 61963,
      "ty": 2,
      "x": 845,
      "y": 509
    },
    {
      "t": 72761,
      "e": 62014,
      "ty": 41,
      "x": 26422,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72811,
      "e": 62064,
      "ty": 2,
      "x": 844,
      "y": 518
    },
    {
      "t": 73011,
      "e": 62264,
      "ty": 41,
      "x": 26422,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 73211,
      "e": 62464,
      "ty": 2,
      "x": 844,
      "y": 509
    },
    {
      "t": 73261,
      "e": 62514,
      "ty": 41,
      "x": 20264,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73311,
      "e": 62564,
      "ty": 2,
      "x": 844,
      "y": 503
    },
    {
      "t": 73384,
      "e": 62637,
      "ty": 3,
      "x": 844,
      "y": 503,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73387,
      "e": 62640,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73478,
      "e": 62731,
      "ty": 4,
      "x": 20264,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73478,
      "e": 62731,
      "ty": 5,
      "x": 844,
      "y": 503,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73479,
      "e": 62732,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 73480,
      "e": 62733,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 73511,
      "e": 62764,
      "ty": 41,
      "x": 20264,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73711,
      "e": 62964,
      "ty": 2,
      "x": 865,
      "y": 599
    },
    {
      "t": 73761,
      "e": 63014,
      "ty": 41,
      "x": 14922,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 73811,
      "e": 63064,
      "ty": 2,
      "x": 878,
      "y": 680
    },
    {
      "t": 73910,
      "e": 63163,
      "ty": 2,
      "x": 880,
      "y": 680
    },
    {
      "t": 74012,
      "e": 63265,
      "ty": 41,
      "x": 15728,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 74112,
      "e": 63365,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 74210,
      "e": 63463,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 74310,
      "e": 63563,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 74711,
      "e": 63964,
      "ty": 2,
      "x": 892,
      "y": 779
    },
    {
      "t": 74762,
      "e": 64015,
      "ty": 41,
      "x": 41657,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 74810,
      "e": 64063,
      "ty": 2,
      "x": 902,
      "y": 818
    },
    {
      "t": 74910,
      "e": 64163,
      "ty": 2,
      "x": 927,
      "y": 777
    },
    {
      "t": 75010,
      "e": 64263,
      "ty": 2,
      "x": 953,
      "y": 750
    },
    {
      "t": 75010,
      "e": 64263,
      "ty": 41,
      "x": 54901,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 75110,
      "e": 64363,
      "ty": 2,
      "x": 957,
      "y": 749
    },
    {
      "t": 75261,
      "e": 64514,
      "ty": 41,
      "x": 53232,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 75310,
      "e": 64563,
      "ty": 2,
      "x": 927,
      "y": 763
    },
    {
      "t": 75410,
      "e": 64663,
      "ty": 2,
      "x": 902,
      "y": 812
    },
    {
      "t": 75510,
      "e": 64763,
      "ty": 2,
      "x": 915,
      "y": 872
    },
    {
      "t": 75510,
      "e": 64763,
      "ty": 41,
      "x": 22208,
      "y": 53130,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 75610,
      "e": 64863,
      "ty": 2,
      "x": 926,
      "y": 885
    },
    {
      "t": 75711,
      "e": 64964,
      "ty": 2,
      "x": 915,
      "y": 878
    },
    {
      "t": 75760,
      "e": 65013,
      "ty": 41,
      "x": 22208,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 76010,
      "e": 65263,
      "ty": 2,
      "x": 915,
      "y": 876
    },
    {
      "t": 76010,
      "e": 65263,
      "ty": 41,
      "x": 22208,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 76410,
      "e": 65663,
      "ty": 2,
      "x": 929,
      "y": 857
    },
    {
      "t": 76511,
      "e": 65764,
      "ty": 2,
      "x": 948,
      "y": 836
    },
    {
      "t": 76511,
      "e": 65764,
      "ty": 41,
      "x": 30040,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 76611,
      "e": 65864,
      "ty": 2,
      "x": 961,
      "y": 828
    },
    {
      "t": 76710,
      "e": 65963,
      "ty": 2,
      "x": 985,
      "y": 807
    },
    {
      "t": 76761,
      "e": 66014,
      "ty": 41,
      "x": 40007,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 76810,
      "e": 66063,
      "ty": 2,
      "x": 996,
      "y": 795
    },
    {
      "t": 76910,
      "e": 66163,
      "ty": 2,
      "x": 1015,
      "y": 769
    },
    {
      "t": 77010,
      "e": 66263,
      "ty": 2,
      "x": 1030,
      "y": 732
    },
    {
      "t": 77011,
      "e": 66264,
      "ty": 41,
      "x": 52350,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 77110,
      "e": 66363,
      "ty": 2,
      "x": 1032,
      "y": 702
    },
    {
      "t": 77210,
      "e": 66463,
      "ty": 2,
      "x": 1024,
      "y": 691
    },
    {
      "t": 77261,
      "e": 66514,
      "ty": 41,
      "x": 46415,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 77310,
      "e": 66563,
      "ty": 2,
      "x": 1010,
      "y": 685
    },
    {
      "t": 77410,
      "e": 66663,
      "ty": 2,
      "x": 959,
      "y": 692
    },
    {
      "t": 77510,
      "e": 66763,
      "ty": 2,
      "x": 926,
      "y": 696
    },
    {
      "t": 77510,
      "e": 66763,
      "ty": 41,
      "x": 26351,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77611,
      "e": 66864,
      "ty": 2,
      "x": 883,
      "y": 705
    },
    {
      "t": 77710,
      "e": 66963,
      "ty": 2,
      "x": 863,
      "y": 707
    },
    {
      "t": 77760,
      "e": 67013,
      "ty": 41,
      "x": 9469,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77810,
      "e": 67063,
      "ty": 2,
      "x": 856,
      "y": 710
    },
    {
      "t": 77910,
      "e": 67163,
      "ty": 2,
      "x": 842,
      "y": 715
    },
    {
      "t": 78010,
      "e": 67263,
      "ty": 2,
      "x": 828,
      "y": 719
    },
    {
      "t": 78012,
      "e": 67265,
      "ty": 41,
      "x": 1561,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 78110,
      "e": 67363,
      "ty": 2,
      "x": 816,
      "y": 726
    },
    {
      "t": 78210,
      "e": 67463,
      "ty": 2,
      "x": 809,
      "y": 732
    },
    {
      "t": 78260,
      "e": 67513,
      "ty": 41,
      "x": 27584,
      "y": 40107,
      "ta": "html > body"
    },
    {
      "t": 78410,
      "e": 67663,
      "ty": 2,
      "x": 809,
      "y": 736
    },
    {
      "t": 78511,
      "e": 67764,
      "ty": 41,
      "x": 27584,
      "y": 40329,
      "ta": "html > body"
    },
    {
      "t": 78610,
      "e": 67863,
      "ty": 2,
      "x": 826,
      "y": 722
    },
    {
      "t": 78710,
      "e": 67963,
      "ty": 2,
      "x": 833,
      "y": 715
    },
    {
      "t": 78760,
      "e": 68013,
      "ty": 41,
      "x": 2747,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 79010,
      "e": 68263,
      "ty": 2,
      "x": 834,
      "y": 712
    },
    {
      "t": 79010,
      "e": 68263,
      "ty": 41,
      "x": 3169,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79311,
      "e": 68564,
      "ty": 2,
      "x": 834,
      "y": 709
    },
    {
      "t": 79326,
      "e": 68579,
      "ty": 6,
      "x": 834,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 79410,
      "e": 68663,
      "ty": 2,
      "x": 834,
      "y": 708
    },
    {
      "t": 79511,
      "e": 68764,
      "ty": 41,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 79810,
      "e": 69063,
      "ty": 2,
      "x": 834,
      "y": 704
    },
    {
      "t": 79910,
      "e": 69163,
      "ty": 2,
      "x": 834,
      "y": 698
    },
    {
      "t": 80011,
      "e": 69264,
      "ty": 41,
      "x": 38202,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82215,
      "e": 71468,
      "ty": 3,
      "x": 834,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82216,
      "e": 71469,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 82217,
      "e": 71470,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82349,
      "e": 71602,
      "ty": 4,
      "x": 38202,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82349,
      "e": 71602,
      "ty": 5,
      "x": 834,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82350,
      "e": 71603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 82510,
      "e": 71763,
      "ty": 2,
      "x": 835,
      "y": 697
    },
    {
      "t": 82510,
      "e": 71763,
      "ty": 41,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82518,
      "e": 71771,
      "ty": 7,
      "x": 840,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82610,
      "e": 71863,
      "ty": 2,
      "x": 989,
      "y": 821
    },
    {
      "t": 82711,
      "e": 71964,
      "ty": 2,
      "x": 1025,
      "y": 958
    },
    {
      "t": 82760,
      "e": 72013,
      "ty": 41,
      "x": 48314,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 83011,
      "e": 72264,
      "ty": 2,
      "x": 1026,
      "y": 967
    },
    {
      "t": 83011,
      "e": 72264,
      "ty": 41,
      "x": 48551,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 83110,
      "e": 72363,
      "ty": 2,
      "x": 983,
      "y": 1020
    },
    {
      "t": 83211,
      "e": 72464,
      "ty": 2,
      "x": 979,
      "y": 1016
    },
    {
      "t": 83261,
      "e": 72514,
      "ty": 41,
      "x": 36685,
      "y": 63218,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 83310,
      "e": 72563,
      "ty": 2,
      "x": 975,
      "y": 1005
    },
    {
      "t": 83411,
      "e": 72664,
      "ty": 2,
      "x": 971,
      "y": 981
    },
    {
      "t": 83510,
      "e": 72763,
      "ty": 2,
      "x": 969,
      "y": 969
    },
    {
      "t": 83510,
      "e": 72763,
      "ty": 41,
      "x": 35023,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 83611,
      "e": 72864,
      "ty": 2,
      "x": 969,
      "y": 968
    },
    {
      "t": 83761,
      "e": 73014,
      "ty": 41,
      "x": 35023,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 84110,
      "e": 73363,
      "ty": 2,
      "x": 923,
      "y": 997
    },
    {
      "t": 84114,
      "e": 73367,
      "ty": 6,
      "x": 913,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 84211,
      "e": 73464,
      "ty": 2,
      "x": 906,
      "y": 1009
    },
    {
      "t": 84260,
      "e": 73513,
      "ty": 41,
      "x": 38436,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 84310,
      "e": 73563,
      "ty": 2,
      "x": 902,
      "y": 1012
    },
    {
      "t": 84411,
      "e": 73664,
      "ty": 2,
      "x": 899,
      "y": 1014
    },
    {
      "t": 84510,
      "e": 73763,
      "ty": 2,
      "x": 890,
      "y": 1015
    },
    {
      "t": 84510,
      "e": 73763,
      "ty": 41,
      "x": 31221,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 84597,
      "e": 73850,
      "ty": 7,
      "x": 865,
      "y": 1002,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 84611,
      "e": 73864,
      "ty": 2,
      "x": 865,
      "y": 1002
    },
    {
      "t": 84711,
      "e": 73964,
      "ty": 2,
      "x": 880,
      "y": 886
    },
    {
      "t": 84760,
      "e": 74013,
      "ty": 41,
      "x": 14614,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 84811,
      "e": 74064,
      "ty": 2,
      "x": 883,
      "y": 883
    },
    {
      "t": 84911,
      "e": 74164,
      "ty": 2,
      "x": 882,
      "y": 889
    },
    {
      "t": 85011,
      "e": 74264,
      "ty": 2,
      "x": 870,
      "y": 900
    },
    {
      "t": 85011,
      "e": 74264,
      "ty": 41,
      "x": 11528,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 85110,
      "e": 74363,
      "ty": 2,
      "x": 864,
      "y": 903
    },
    {
      "t": 85210,
      "e": 74463,
      "ty": 2,
      "x": 857,
      "y": 906
    },
    {
      "t": 85261,
      "e": 74514,
      "ty": 41,
      "x": 8443,
      "y": 16131,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 85311,
      "e": 74564,
      "ty": 2,
      "x": 857,
      "y": 907
    },
    {
      "t": 85510,
      "e": 74763,
      "ty": 2,
      "x": 867,
      "y": 903
    },
    {
      "t": 85510,
      "e": 74763,
      "ty": 41,
      "x": 10816,
      "y": 14115,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 85611,
      "e": 74864,
      "ty": 2,
      "x": 888,
      "y": 940
    },
    {
      "t": 85710,
      "e": 74963,
      "ty": 2,
      "x": 863,
      "y": 984
    },
    {
      "t": 85761,
      "e": 75014,
      "ty": 41,
      "x": 38297,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 85811,
      "e": 75064,
      "ty": 2,
      "x": 857,
      "y": 984
    },
    {
      "t": 86010,
      "e": 75263,
      "ty": 2,
      "x": 856,
      "y": 984
    },
    {
      "t": 86011,
      "e": 75264,
      "ty": 41,
      "x": 34326,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 86110,
      "e": 75363,
      "ty": 2,
      "x": 861,
      "y": 964
    },
    {
      "t": 86211,
      "e": 75464,
      "ty": 2,
      "x": 860,
      "y": 962
    },
    {
      "t": 86261,
      "e": 75514,
      "ty": 41,
      "x": 31206,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 86303,
      "e": 75556,
      "ty": 3,
      "x": 860,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 86304,
      "e": 75557,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86391,
      "e": 75644,
      "ty": 4,
      "x": 31206,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 86391,
      "e": 75644,
      "ty": 5,
      "x": 860,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 86391,
      "e": 75644,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86392,
      "e": 75645,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 86511,
      "e": 75764,
      "ty": 2,
      "x": 860,
      "y": 1004
    },
    {
      "t": 86511,
      "e": 75764,
      "ty": 41,
      "x": 9155,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 86515,
      "e": 75768,
      "ty": 6,
      "x": 860,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86610,
      "e": 75863,
      "ty": 2,
      "x": 862,
      "y": 1025
    },
    {
      "t": 86711,
      "e": 75964,
      "ty": 2,
      "x": 863,
      "y": 1025
    },
    {
      "t": 86761,
      "e": 76014,
      "ty": 41,
      "x": 17305,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86848,
      "e": 76101,
      "ty": 3,
      "x": 864,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86848,
      "e": 76101,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86850,
      "e": 76103,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86911,
      "e": 76164,
      "ty": 2,
      "x": 865,
      "y": 1023
    },
    {
      "t": 86918,
      "e": 76171,
      "ty": 4,
      "x": 18336,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86918,
      "e": 76171,
      "ty": 5,
      "x": 865,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86923,
      "e": 76176,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86924,
      "e": 76177,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 86925,
      "e": 76178,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 87010,
      "e": 76263,
      "ty": 41,
      "x": 29513,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 87711,
      "e": 76964,
      "ty": 2,
      "x": 823,
      "y": 994
    },
    {
      "t": 87761,
      "e": 77014,
      "ty": 41,
      "x": 27343,
      "y": 53015,
      "ta": "html > body"
    },
    {
      "t": 87811,
      "e": 77064,
      "ty": 2,
      "x": 802,
      "y": 965
    },
    {
      "t": 87911,
      "e": 77164,
      "ty": 2,
      "x": 808,
      "y": 926
    },
    {
      "t": 88011,
      "e": 77264,
      "ty": 2,
      "x": 830,
      "y": 828
    },
    {
      "t": 88011,
      "e": 77264,
      "ty": 41,
      "x": 28307,
      "y": 45425,
      "ta": "html > body"
    },
    {
      "t": 88110,
      "e": 77363,
      "ty": 2,
      "x": 840,
      "y": 794
    },
    {
      "t": 88210,
      "e": 77463,
      "ty": 2,
      "x": 843,
      "y": 790
    },
    {
      "t": 88262,
      "e": 77515,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 88267,
      "e": 77520,
      "ty": 41,
      "x": 27036,
      "y": 52742,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89010,
      "e": 78263,
      "ty": 2,
      "x": 843,
      "y": 788
    },
    {
      "t": 89011,
      "e": 78264,
      "ty": 41,
      "x": 27036,
      "y": 52510,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89110,
      "e": 78363,
      "ty": 2,
      "x": 733,
      "y": 707
    },
    {
      "t": 89211,
      "e": 78464,
      "ty": 2,
      "x": 367,
      "y": 305
    },
    {
      "t": 89261,
      "e": 78514,
      "ty": 41,
      "x": 3323,
      "y": 12028,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89310,
      "e": 78563,
      "ty": 2,
      "x": 361,
      "y": 300
    },
    {
      "t": 89411,
      "e": 78664,
      "ty": 2,
      "x": 410,
      "y": 308
    },
    {
      "t": 89511,
      "e": 78764,
      "ty": 2,
      "x": 615,
      "y": 359
    },
    {
      "t": 89511,
      "e": 78764,
      "ty": 41,
      "x": 15819,
      "y": 57379,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 89611,
      "e": 78864,
      "ty": 2,
      "x": 680,
      "y": 375
    },
    {
      "t": 89711,
      "e": 78964,
      "ty": 2,
      "x": 693,
      "y": 375
    },
    {
      "t": 89761,
      "e": 79014,
      "ty": 41,
      "x": 21132,
      "y": 3880,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89811,
      "e": 79064,
      "ty": 2,
      "x": 763,
      "y": 363
    },
    {
      "t": 89911,
      "e": 79164,
      "ty": 2,
      "x": 782,
      "y": 361
    },
    {
      "t": 90011,
      "e": 79264,
      "ty": 2,
      "x": 785,
      "y": 361
    },
    {
      "t": 90011,
      "e": 79264,
      "ty": 41,
      "x": 24182,
      "y": 62060,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 90111,
      "e": 79364,
      "ty": 2,
      "x": 801,
      "y": 361
    },
    {
      "t": 90210,
      "e": 79463,
      "ty": 2,
      "x": 888,
      "y": 369
    },
    {
      "t": 90261,
      "e": 79514,
      "ty": 41,
      "x": 31021,
      "y": 4112,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 90311,
      "e": 79564,
      "ty": 2,
      "x": 931,
      "y": 370
    },
    {
      "t": 90411,
      "e": 79664,
      "ty": 2,
      "x": 958,
      "y": 375
    },
    {
      "t": 90511,
      "e": 79764,
      "ty": 2,
      "x": 969,
      "y": 377
    },
    {
      "t": 90512,
      "e": 79765,
      "ty": 41,
      "x": 33234,
      "y": 4922,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 90611,
      "e": 79864,
      "ty": 2,
      "x": 972,
      "y": 377
    },
    {
      "t": 90761,
      "e": 80014,
      "ty": 41,
      "x": 33382,
      "y": 4922,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 90811,
      "e": 80064,
      "ty": 2,
      "x": 975,
      "y": 377
    },
    {
      "t": 90910,
      "e": 80163,
      "ty": 2,
      "x": 1100,
      "y": 383
    },
    {
      "t": 91011,
      "e": 80264,
      "ty": 2,
      "x": 1120,
      "y": 383
    },
    {
      "t": 91012,
      "e": 80265,
      "ty": 41,
      "x": 40663,
      "y": 1962,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 92510,
      "e": 81763,
      "ty": 2,
      "x": 929,
      "y": 424
    },
    {
      "t": 92511,
      "e": 81764,
      "ty": 41,
      "x": 31266,
      "y": 33949,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 92611,
      "e": 81864,
      "ty": 2,
      "x": 673,
      "y": 429
    },
    {
      "t": 92711,
      "e": 81964,
      "ty": 2,
      "x": 659,
      "y": 436
    },
    {
      "t": 92761,
      "e": 82014,
      "ty": 41,
      "x": 17934,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 92811,
      "e": 82064,
      "ty": 2,
      "x": 658,
      "y": 438
    },
    {
      "t": 92911,
      "e": 82164,
      "ty": 2,
      "x": 636,
      "y": 445
    },
    {
      "t": 93011,
      "e": 82264,
      "ty": 2,
      "x": 591,
      "y": 459
    },
    {
      "t": 93011,
      "e": 82264,
      "ty": 41,
      "x": 14638,
      "y": 61256,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93111,
      "e": 82364,
      "ty": 2,
      "x": 580,
      "y": 459
    },
    {
      "t": 93262,
      "e": 82515,
      "ty": 41,
      "x": 14097,
      "y": 61256,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93611,
      "e": 82864,
      "ty": 2,
      "x": 561,
      "y": 465
    },
    {
      "t": 93711,
      "e": 82964,
      "ty": 2,
      "x": 503,
      "y": 471
    },
    {
      "t": 93761,
      "e": 83014,
      "ty": 41,
      "x": 8046,
      "y": 15806,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 93811,
      "e": 83064,
      "ty": 2,
      "x": 432,
      "y": 469
    },
    {
      "t": 93911,
      "e": 83164,
      "ty": 2,
      "x": 434,
      "y": 452
    },
    {
      "t": 94010,
      "e": 83263,
      "ty": 2,
      "x": 464,
      "y": 434
    },
    {
      "t": 94011,
      "e": 83264,
      "ty": 41,
      "x": 8390,
      "y": 41751,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94111,
      "e": 83364,
      "ty": 2,
      "x": 466,
      "y": 434
    },
    {
      "t": 94211,
      "e": 83464,
      "ty": 2,
      "x": 467,
      "y": 433
    },
    {
      "t": 94261,
      "e": 83514,
      "ty": 41,
      "x": 8833,
      "y": 40191,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94311,
      "e": 83564,
      "ty": 2,
      "x": 504,
      "y": 423
    },
    {
      "t": 94411,
      "e": 83664,
      "ty": 2,
      "x": 520,
      "y": 418
    },
    {
      "t": 94512,
      "e": 83765,
      "ty": 41,
      "x": 11145,
      "y": 29268,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94610,
      "e": 83863,
      "ty": 2,
      "x": 496,
      "y": 425
    },
    {
      "t": 94711,
      "e": 83964,
      "ty": 2,
      "x": 449,
      "y": 426
    },
    {
      "t": 94761,
      "e": 84014,
      "ty": 41,
      "x": 7357,
      "y": 36290,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94811,
      "e": 84064,
      "ty": 2,
      "x": 443,
      "y": 427
    },
    {
      "t": 94911,
      "e": 84164,
      "ty": 2,
      "x": 443,
      "y": 428
    },
    {
      "t": 95011,
      "e": 84264,
      "ty": 2,
      "x": 446,
      "y": 428
    },
    {
      "t": 95011,
      "e": 84264,
      "ty": 41,
      "x": 7504,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 95111,
      "e": 84364,
      "ty": 2,
      "x": 463,
      "y": 423
    },
    {
      "t": 95211,
      "e": 84464,
      "ty": 2,
      "x": 524,
      "y": 409
    },
    {
      "t": 95262,
      "e": 84515,
      "ty": 41,
      "x": 16753,
      "y": 22247,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 95311,
      "e": 84564,
      "ty": 2,
      "x": 677,
      "y": 404
    },
    {
      "t": 95411,
      "e": 84664,
      "ty": 2,
      "x": 745,
      "y": 408
    },
    {
      "t": 95511,
      "e": 84764,
      "ty": 2,
      "x": 824,
      "y": 411
    },
    {
      "t": 95512,
      "e": 84765,
      "ty": 41,
      "x": 26101,
      "y": 23807,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 95611,
      "e": 84864,
      "ty": 2,
      "x": 836,
      "y": 414
    },
    {
      "t": 95711,
      "e": 84964,
      "ty": 2,
      "x": 869,
      "y": 414
    },
    {
      "t": 95761,
      "e": 85014,
      "ty": 41,
      "x": 31709,
      "y": 27708,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 95811,
      "e": 85064,
      "ty": 2,
      "x": 1027,
      "y": 417
    },
    {
      "t": 95911,
      "e": 85164,
      "ty": 2,
      "x": 1108,
      "y": 431
    },
    {
      "t": 96011,
      "e": 85264,
      "ty": 2,
      "x": 1120,
      "y": 431
    },
    {
      "t": 96011,
      "e": 85264,
      "ty": 41,
      "x": 40663,
      "y": 39411,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 96111,
      "e": 85364,
      "ty": 2,
      "x": 1135,
      "y": 431
    },
    {
      "t": 96261,
      "e": 85514,
      "ty": 41,
      "x": 41499,
      "y": 39411,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 96311,
      "e": 85564,
      "ty": 2,
      "x": 1138,
      "y": 432
    },
    {
      "t": 96411,
      "e": 85664,
      "ty": 2,
      "x": 1148,
      "y": 434
    },
    {
      "t": 96511,
      "e": 85764,
      "ty": 2,
      "x": 1149,
      "y": 434
    },
    {
      "t": 96511,
      "e": 85764,
      "ty": 41,
      "x": 42090,
      "y": 41751,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 96711,
      "e": 85964,
      "ty": 2,
      "x": 1149,
      "y": 436
    },
    {
      "t": 96761,
      "e": 86014,
      "ty": 41,
      "x": 42090,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 97011,
      "e": 86264,
      "ty": 2,
      "x": 1138,
      "y": 446
    },
    {
      "t": 97011,
      "e": 86264,
      "ty": 41,
      "x": 41549,
      "y": 51113,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 97111,
      "e": 86364,
      "ty": 2,
      "x": 994,
      "y": 481
    },
    {
      "t": 97211,
      "e": 86464,
      "ty": 2,
      "x": 943,
      "y": 491
    },
    {
      "t": 97261,
      "e": 86514,
      "ty": 41,
      "x": 30627,
      "y": 3321,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97311,
      "e": 86564,
      "ty": 2,
      "x": 885,
      "y": 494
    },
    {
      "t": 97411,
      "e": 86664,
      "ty": 2,
      "x": 856,
      "y": 502
    },
    {
      "t": 97511,
      "e": 86764,
      "ty": 2,
      "x": 832,
      "y": 512
    },
    {
      "t": 97512,
      "e": 86765,
      "ty": 41,
      "x": 26494,
      "y": 11513,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97612,
      "e": 86766,
      "ty": 2,
      "x": 787,
      "y": 529
    },
    {
      "t": 97711,
      "e": 86865,
      "ty": 2,
      "x": 785,
      "y": 530
    },
    {
      "t": 97762,
      "e": 86916,
      "ty": 41,
      "x": 24182,
      "y": 18535,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97811,
      "e": 86965,
      "ty": 2,
      "x": 783,
      "y": 532
    },
    {
      "t": 97911,
      "e": 87065,
      "ty": 2,
      "x": 751,
      "y": 553
    },
    {
      "t": 98011,
      "e": 87165,
      "ty": 2,
      "x": 748,
      "y": 556
    },
    {
      "t": 98012,
      "e": 87166,
      "ty": 41,
      "x": 22362,
      "y": 28677,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98111,
      "e": 87265,
      "ty": 2,
      "x": 704,
      "y": 560
    },
    {
      "t": 98211,
      "e": 87365,
      "ty": 2,
      "x": 669,
      "y": 561
    },
    {
      "t": 98261,
      "e": 87415,
      "ty": 41,
      "x": 18426,
      "y": 30628,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98310,
      "e": 87464,
      "ty": 2,
      "x": 668,
      "y": 561
    },
    {
      "t": 98610,
      "e": 87764,
      "ty": 2,
      "x": 649,
      "y": 560
    },
    {
      "t": 98710,
      "e": 87864,
      "ty": 2,
      "x": 513,
      "y": 525
    },
    {
      "t": 98769,
      "e": 87923,
      "ty": 41,
      "x": 10653,
      "y": 15024,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98819,
      "e": 87973,
      "ty": 2,
      "x": 510,
      "y": 511
    },
    {
      "t": 98920,
      "e": 88074,
      "ty": 2,
      "x": 614,
      "y": 496
    },
    {
      "t": 99019,
      "e": 88173,
      "ty": 2,
      "x": 642,
      "y": 496
    },
    {
      "t": 99020,
      "e": 88174,
      "ty": 41,
      "x": 17147,
      "y": 5272,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99419,
      "e": 88573,
      "ty": 2,
      "x": 779,
      "y": 482
    },
    {
      "t": 99519,
      "e": 88673,
      "ty": 2,
      "x": 1093,
      "y": 482
    },
    {
      "t": 99519,
      "e": 88673,
      "ty": 41,
      "x": 39335,
      "y": 17080,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 99619,
      "e": 88773,
      "ty": 2,
      "x": 1049,
      "y": 492
    },
    {
      "t": 99719,
      "e": 88873,
      "ty": 2,
      "x": 737,
      "y": 507
    },
    {
      "t": 99769,
      "e": 88923,
      "ty": 41,
      "x": 14244,
      "y": 9563,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99819,
      "e": 88973,
      "ty": 2,
      "x": 525,
      "y": 522
    },
    {
      "t": 99919,
      "e": 89073,
      "ty": 2,
      "x": 483,
      "y": 551
    },
    {
      "t": 100019,
      "e": 89173,
      "ty": 2,
      "x": 476,
      "y": 558
    },
    {
      "t": 100020,
      "e": 89174,
      "ty": 41,
      "x": 8980,
      "y": 29457,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100219,
      "e": 89373,
      "ty": 2,
      "x": 486,
      "y": 544
    },
    {
      "t": 100269,
      "e": 89423,
      "ty": 41,
      "x": 9817,
      "y": 21656,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100319,
      "e": 89473,
      "ty": 2,
      "x": 502,
      "y": 534
    },
    {
      "t": 100419,
      "e": 89573,
      "ty": 2,
      "x": 534,
      "y": 525
    },
    {
      "t": 100519,
      "e": 89673,
      "ty": 2,
      "x": 549,
      "y": 519
    },
    {
      "t": 100519,
      "e": 89673,
      "ty": 41,
      "x": 12572,
      "y": 14244,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100619,
      "e": 89773,
      "ty": 2,
      "x": 583,
      "y": 514
    },
    {
      "t": 100720,
      "e": 89874,
      "ty": 2,
      "x": 619,
      "y": 508
    },
    {
      "t": 100769,
      "e": 89923,
      "ty": 41,
      "x": 16458,
      "y": 9563,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100819,
      "e": 89973,
      "ty": 2,
      "x": 639,
      "y": 507
    },
    {
      "t": 100919,
      "e": 90073,
      "ty": 2,
      "x": 697,
      "y": 507
    },
    {
      "t": 101019,
      "e": 90173,
      "ty": 2,
      "x": 707,
      "y": 505
    },
    {
      "t": 101020,
      "e": 90174,
      "ty": 41,
      "x": 20345,
      "y": 8783,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101119,
      "e": 90273,
      "ty": 2,
      "x": 731,
      "y": 506
    },
    {
      "t": 101219,
      "e": 90373,
      "ty": 2,
      "x": 807,
      "y": 506
    },
    {
      "t": 101270,
      "e": 90424,
      "ty": 41,
      "x": 26347,
      "y": 10343,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101319,
      "e": 90473,
      "ty": 2,
      "x": 869,
      "y": 513
    },
    {
      "t": 101419,
      "e": 90573,
      "ty": 2,
      "x": 922,
      "y": 514
    },
    {
      "t": 101519,
      "e": 90673,
      "ty": 2,
      "x": 957,
      "y": 514
    },
    {
      "t": 101520,
      "e": 90674,
      "ty": 41,
      "x": 32644,
      "y": 12293,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101619,
      "e": 90773,
      "ty": 2,
      "x": 998,
      "y": 514
    },
    {
      "t": 101719,
      "e": 90873,
      "ty": 2,
      "x": 1014,
      "y": 512
    },
    {
      "t": 101769,
      "e": 90923,
      "ty": 41,
      "x": 36285,
      "y": 10733,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101819,
      "e": 90973,
      "ty": 2,
      "x": 1055,
      "y": 510
    },
    {
      "t": 101919,
      "e": 91073,
      "ty": 2,
      "x": 1075,
      "y": 510
    },
    {
      "t": 102019,
      "e": 91173,
      "ty": 2,
      "x": 1105,
      "y": 510
    },
    {
      "t": 102019,
      "e": 91173,
      "ty": 41,
      "x": 39925,
      "y": 10733,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102120,
      "e": 91274,
      "ty": 2,
      "x": 1127,
      "y": 510
    },
    {
      "t": 102269,
      "e": 91423,
      "ty": 41,
      "x": 41007,
      "y": 10733,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102420,
      "e": 91574,
      "ty": 2,
      "x": 1150,
      "y": 509
    },
    {
      "t": 102519,
      "e": 91673,
      "ty": 2,
      "x": 1165,
      "y": 505
    },
    {
      "t": 102520,
      "e": 91674,
      "ty": 41,
      "x": 42877,
      "y": 8783,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102619,
      "e": 91773,
      "ty": 2,
      "x": 1172,
      "y": 502
    },
    {
      "t": 102770,
      "e": 91924,
      "ty": 41,
      "x": 43221,
      "y": 7612,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102919,
      "e": 92073,
      "ty": 2,
      "x": 1218,
      "y": 506
    },
    {
      "t": 103019,
      "e": 92173,
      "ty": 2,
      "x": 1240,
      "y": 508
    },
    {
      "t": 103019,
      "e": 92173,
      "ty": 41,
      "x": 46567,
      "y": 9953,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103119,
      "e": 92273,
      "ty": 2,
      "x": 1243,
      "y": 509
    },
    {
      "t": 103220,
      "e": 92374,
      "ty": 2,
      "x": 1247,
      "y": 510
    },
    {
      "t": 103269,
      "e": 92423,
      "ty": 41,
      "x": 46911,
      "y": 10733,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103419,
      "e": 92573,
      "ty": 2,
      "x": 1249,
      "y": 510
    },
    {
      "t": 103519,
      "e": 92673,
      "ty": 41,
      "x": 47010,
      "y": 10733,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103720,
      "e": 92874,
      "ty": 2,
      "x": 1243,
      "y": 511
    },
    {
      "t": 103770,
      "e": 92924,
      "ty": 41,
      "x": 44009,
      "y": 12293,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 103819,
      "e": 92973,
      "ty": 2,
      "x": 999,
      "y": 514
    },
    {
      "t": 103920,
      "e": 93074,
      "ty": 2,
      "x": 669,
      "y": 553
    },
    {
      "t": 104019,
      "e": 93173,
      "ty": 2,
      "x": 504,
      "y": 584
    },
    {
      "t": 104020,
      "e": 93174,
      "ty": 41,
      "x": 10358,
      "y": 39600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 104120,
      "e": 93274,
      "ty": 2,
      "x": 466,
      "y": 587
    },
    {
      "t": 104220,
      "e": 93374,
      "ty": 2,
      "x": 384,
      "y": 582
    },
    {
      "t": 104270,
      "e": 93424,
      "ty": 41,
      "x": 3470,
      "y": 38429,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 104319,
      "e": 93473,
      "ty": 2,
      "x": 364,
      "y": 581
    },
    {
      "t": 104719,
      "e": 93873,
      "ty": 2,
      "x": 348,
      "y": 581
    },
    {
      "t": 104770,
      "e": 93924,
      "ty": 41,
      "x": 1650,
      "y": 39210,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 104819,
      "e": 93973,
      "ty": 2,
      "x": 324,
      "y": 584
    },
    {
      "t": 105020,
      "e": 94174,
      "ty": 2,
      "x": 387,
      "y": 578
    },
    {
      "t": 105020,
      "e": 94174,
      "ty": 41,
      "x": 4602,
      "y": 37259,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 105119,
      "e": 94273,
      "ty": 2,
      "x": 398,
      "y": 565
    },
    {
      "t": 105219,
      "e": 94373,
      "ty": 2,
      "x": 418,
      "y": 546
    },
    {
      "t": 105270,
      "e": 94424,
      "ty": 41,
      "x": 6176,
      "y": 23606,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 105319,
      "e": 94473,
      "ty": 2,
      "x": 419,
      "y": 543
    },
    {
      "t": 105419,
      "e": 94573,
      "ty": 2,
      "x": 423,
      "y": 539
    },
    {
      "t": 105520,
      "e": 94674,
      "ty": 2,
      "x": 458,
      "y": 534
    },
    {
      "t": 105520,
      "e": 94674,
      "ty": 41,
      "x": 8095,
      "y": 20095,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 105619,
      "e": 94773,
      "ty": 2,
      "x": 464,
      "y": 534
    },
    {
      "t": 105719,
      "e": 94873,
      "ty": 2,
      "x": 467,
      "y": 534
    },
    {
      "t": 105769,
      "e": 94923,
      "ty": 41,
      "x": 9669,
      "y": 18925,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 105819,
      "e": 94973,
      "ty": 2,
      "x": 525,
      "y": 531
    },
    {
      "t": 105919,
      "e": 95073,
      "ty": 2,
      "x": 577,
      "y": 535
    },
    {
      "t": 106020,
      "e": 95174,
      "ty": 2,
      "x": 592,
      "y": 535
    },
    {
      "t": 106020,
      "e": 95174,
      "ty": 41,
      "x": 14687,
      "y": 20485,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 106120,
      "e": 95274,
      "ty": 2,
      "x": 633,
      "y": 529
    },
    {
      "t": 106219,
      "e": 95373,
      "ty": 2,
      "x": 652,
      "y": 529
    },
    {
      "t": 106269,
      "e": 95423,
      "ty": 41,
      "x": 17639,
      "y": 18145,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 106419,
      "e": 95573,
      "ty": 2,
      "x": 653,
      "y": 529
    },
    {
      "t": 106519,
      "e": 95673,
      "ty": 2,
      "x": 678,
      "y": 531
    },
    {
      "t": 106520,
      "e": 95674,
      "ty": 41,
      "x": 18918,
      "y": 18925,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 106620,
      "e": 95774,
      "ty": 2,
      "x": 689,
      "y": 531
    },
    {
      "t": 106720,
      "e": 95874,
      "ty": 2,
      "x": 710,
      "y": 529
    },
    {
      "t": 106770,
      "e": 95924,
      "ty": 41,
      "x": 20984,
      "y": 18145,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 106819,
      "e": 95973,
      "ty": 2,
      "x": 744,
      "y": 529
    },
    {
      "t": 106920,
      "e": 96074,
      "ty": 2,
      "x": 767,
      "y": 529
    },
    {
      "t": 107020,
      "e": 96174,
      "ty": 2,
      "x": 815,
      "y": 537
    },
    {
      "t": 107020,
      "e": 96174,
      "ty": 41,
      "x": 25658,
      "y": 21265,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107119,
      "e": 96273,
      "ty": 2,
      "x": 835,
      "y": 537
    },
    {
      "t": 107220,
      "e": 96374,
      "ty": 2,
      "x": 845,
      "y": 537
    },
    {
      "t": 107270,
      "e": 96424,
      "ty": 41,
      "x": 27380,
      "y": 21265,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107319,
      "e": 96473,
      "ty": 2,
      "x": 857,
      "y": 537
    },
    {
      "t": 107419,
      "e": 96573,
      "ty": 2,
      "x": 866,
      "y": 537
    },
    {
      "t": 107520,
      "e": 96674,
      "ty": 2,
      "x": 884,
      "y": 538
    },
    {
      "t": 107520,
      "e": 96674,
      "ty": 41,
      "x": 29053,
      "y": 21656,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107619,
      "e": 96773,
      "ty": 2,
      "x": 889,
      "y": 539
    },
    {
      "t": 107770,
      "e": 96924,
      "ty": 41,
      "x": 29299,
      "y": 22046,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107919,
      "e": 97073,
      "ty": 2,
      "x": 936,
      "y": 553
    },
    {
      "t": 108019,
      "e": 97173,
      "ty": 2,
      "x": 973,
      "y": 557
    },
    {
      "t": 108020,
      "e": 97174,
      "ty": 41,
      "x": 33431,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 108120,
      "e": 97274,
      "ty": 2,
      "x": 979,
      "y": 557
    },
    {
      "t": 108220,
      "e": 97374,
      "ty": 2,
      "x": 995,
      "y": 556
    },
    {
      "t": 108270,
      "e": 97424,
      "ty": 41,
      "x": 35301,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 108319,
      "e": 97473,
      "ty": 2,
      "x": 1018,
      "y": 552
    },
    {
      "t": 108420,
      "e": 97574,
      "ty": 2,
      "x": 1040,
      "y": 548
    },
    {
      "t": 108519,
      "e": 97673,
      "ty": 2,
      "x": 1048,
      "y": 546
    },
    {
      "t": 108519,
      "e": 97673,
      "ty": 41,
      "x": 37121,
      "y": 24776,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 108619,
      "e": 97773,
      "ty": 2,
      "x": 1077,
      "y": 546
    },
    {
      "t": 108720,
      "e": 97874,
      "ty": 2,
      "x": 1107,
      "y": 552
    },
    {
      "t": 108770,
      "e": 97924,
      "ty": 41,
      "x": 40663,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 108819,
      "e": 97973,
      "ty": 2,
      "x": 1122,
      "y": 553
    },
    {
      "t": 108920,
      "e": 98074,
      "ty": 2,
      "x": 1129,
      "y": 553
    },
    {
      "t": 109019,
      "e": 98173,
      "ty": 2,
      "x": 1139,
      "y": 553
    },
    {
      "t": 109020,
      "e": 98174,
      "ty": 41,
      "x": 41598,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 109119,
      "e": 98273,
      "ty": 2,
      "x": 1162,
      "y": 553
    },
    {
      "t": 109220,
      "e": 98374,
      "ty": 2,
      "x": 1180,
      "y": 553
    },
    {
      "t": 109270,
      "e": 98424,
      "ty": 41,
      "x": 44107,
      "y": 26727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 109320,
      "e": 98474,
      "ty": 2,
      "x": 1200,
      "y": 551
    },
    {
      "t": 109419,
      "e": 98573,
      "ty": 2,
      "x": 1215,
      "y": 549
    },
    {
      "t": 109520,
      "e": 98674,
      "ty": 2,
      "x": 1220,
      "y": 546
    },
    {
      "t": 109520,
      "e": 98674,
      "ty": 41,
      "x": 45583,
      "y": 24776,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 109619,
      "e": 98773,
      "ty": 2,
      "x": 1220,
      "y": 544
    },
    {
      "t": 109770,
      "e": 98924,
      "ty": 41,
      "x": 45583,
      "y": 23996,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 110020,
      "e": 99174,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110420,
      "e": 99574,
      "ty": 2,
      "x": 1199,
      "y": 544
    },
    {
      "t": 110519,
      "e": 99673,
      "ty": 2,
      "x": 1169,
      "y": 547
    },
    {
      "t": 110519,
      "e": 99673,
      "ty": 41,
      "x": 43074,
      "y": 25166,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 110619,
      "e": 99773,
      "ty": 2,
      "x": 1100,
      "y": 556
    },
    {
      "t": 110720,
      "e": 99874,
      "ty": 2,
      "x": 916,
      "y": 650
    },
    {
      "t": 110770,
      "e": 99924,
      "ty": 41,
      "x": 26740,
      "y": 16685,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 110819,
      "e": 99973,
      "ty": 2,
      "x": 779,
      "y": 736
    },
    {
      "t": 110920,
      "e": 100074,
      "ty": 2,
      "x": 600,
      "y": 779
    },
    {
      "t": 111019,
      "e": 100173,
      "ty": 2,
      "x": 325,
      "y": 756
    },
    {
      "t": 111019,
      "e": 100173,
      "ty": 41,
      "x": 1552,
      "y": 51208,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111119,
      "e": 100273,
      "ty": 2,
      "x": 230,
      "y": 712
    },
    {
      "t": 111220,
      "e": 100374,
      "ty": 2,
      "x": 270,
      "y": 627
    },
    {
      "t": 111270,
      "e": 100424,
      "ty": 41,
      "x": 666,
      "y": 43110,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 111320,
      "e": 100474,
      "ty": 2,
      "x": 329,
      "y": 578
    },
    {
      "t": 111420,
      "e": 100574,
      "ty": 2,
      "x": 348,
      "y": 568
    },
    {
      "t": 111519,
      "e": 100673,
      "ty": 2,
      "x": 350,
      "y": 566
    },
    {
      "t": 111520,
      "e": 100674,
      "ty": 41,
      "x": 2781,
      "y": 32578,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 111620,
      "e": 100774,
      "ty": 2,
      "x": 355,
      "y": 563
    },
    {
      "t": 111720,
      "e": 100874,
      "ty": 2,
      "x": 373,
      "y": 556
    },
    {
      "t": 111770,
      "e": 100924,
      "ty": 41,
      "x": 5290,
      "y": 23606,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 111819,
      "e": 100973,
      "ty": 2,
      "x": 422,
      "y": 535
    },
    {
      "t": 111919,
      "e": 101073,
      "ty": 2,
      "x": 428,
      "y": 533
    },
    {
      "t": 112019,
      "e": 101173,
      "ty": 2,
      "x": 445,
      "y": 532
    },
    {
      "t": 112020,
      "e": 101174,
      "ty": 41,
      "x": 7455,
      "y": 19315,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 112119,
      "e": 101273,
      "ty": 2,
      "x": 593,
      "y": 532
    },
    {
      "t": 112219,
      "e": 101373,
      "ty": 2,
      "x": 670,
      "y": 532
    },
    {
      "t": 112270,
      "e": 101424,
      "ty": 41,
      "x": 19361,
      "y": 19315,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 112320,
      "e": 101474,
      "ty": 2,
      "x": 692,
      "y": 532
    },
    {
      "t": 112420,
      "e": 101574,
      "ty": 2,
      "x": 693,
      "y": 535
    },
    {
      "t": 112520,
      "e": 101674,
      "ty": 2,
      "x": 692,
      "y": 547
    },
    {
      "t": 112520,
      "e": 101674,
      "ty": 41,
      "x": 19607,
      "y": 25166,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 112620,
      "e": 101774,
      "ty": 2,
      "x": 694,
      "y": 552
    },
    {
      "t": 112720,
      "e": 101874,
      "ty": 2,
      "x": 705,
      "y": 555
    },
    {
      "t": 112770,
      "e": 101924,
      "ty": 41,
      "x": 20837,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 112820,
      "e": 101974,
      "ty": 2,
      "x": 730,
      "y": 555
    },
    {
      "t": 112920,
      "e": 102074,
      "ty": 2,
      "x": 762,
      "y": 555
    },
    {
      "t": 113019,
      "e": 102173,
      "ty": 2,
      "x": 809,
      "y": 564
    },
    {
      "t": 113020,
      "e": 102174,
      "ty": 41,
      "x": 25363,
      "y": 31798,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 113120,
      "e": 102274,
      "ty": 2,
      "x": 872,
      "y": 576
    },
    {
      "t": 113219,
      "e": 102373,
      "ty": 2,
      "x": 895,
      "y": 577
    },
    {
      "t": 113270,
      "e": 102424,
      "ty": 41,
      "x": 30971,
      "y": 34138,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 113320,
      "e": 102474,
      "ty": 2,
      "x": 979,
      "y": 556
    },
    {
      "t": 113420,
      "e": 102574,
      "ty": 2,
      "x": 1044,
      "y": 537
    },
    {
      "t": 113519,
      "e": 102673,
      "ty": 2,
      "x": 1045,
      "y": 537
    },
    {
      "t": 113520,
      "e": 102674,
      "ty": 41,
      "x": 36973,
      "y": 21265,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 113719,
      "e": 102873,
      "ty": 2,
      "x": 956,
      "y": 588
    },
    {
      "t": 113769,
      "e": 102923,
      "ty": 41,
      "x": 23739,
      "y": 55983,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 113819,
      "e": 102973,
      "ty": 2,
      "x": 499,
      "y": 666
    },
    {
      "t": 113920,
      "e": 103074,
      "ty": 2,
      "x": 388,
      "y": 681
    },
    {
      "t": 114019,
      "e": 103173,
      "ty": 2,
      "x": 372,
      "y": 685
    },
    {
      "t": 114020,
      "e": 103174,
      "ty": 41,
      "x": 22094,
      "y": 41010,
      "ta": "> div.masterdiv > div:[2] > div > p:[4] > b"
    },
    {
      "t": 114119,
      "e": 103273,
      "ty": 2,
      "x": 372,
      "y": 692
    },
    {
      "t": 114219,
      "e": 103373,
      "ty": 2,
      "x": 399,
      "y": 700
    },
    {
      "t": 114269,
      "e": 103423,
      "ty": 41,
      "x": 7111,
      "y": 20196,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114320,
      "e": 103474,
      "ty": 2,
      "x": 489,
      "y": 703
    },
    {
      "t": 114420,
      "e": 103574,
      "ty": 2,
      "x": 519,
      "y": 699
    },
    {
      "t": 114519,
      "e": 103673,
      "ty": 2,
      "x": 535,
      "y": 695
    },
    {
      "t": 114520,
      "e": 103674,
      "ty": 41,
      "x": 11883,
      "y": 15515,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114620,
      "e": 103774,
      "ty": 2,
      "x": 604,
      "y": 689
    },
    {
      "t": 114719,
      "e": 103873,
      "ty": 2,
      "x": 654,
      "y": 677
    },
    {
      "t": 114770,
      "e": 103924,
      "ty": 41,
      "x": 17885,
      "y": 4982,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114819,
      "e": 103973,
      "ty": 2,
      "x": 663,
      "y": 677
    },
    {
      "t": 114920,
      "e": 104074,
      "ty": 2,
      "x": 687,
      "y": 677
    },
    {
      "t": 115019,
      "e": 104173,
      "ty": 2,
      "x": 721,
      "y": 676
    },
    {
      "t": 115020,
      "e": 104174,
      "ty": 41,
      "x": 21034,
      "y": 4397,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115120,
      "e": 104274,
      "ty": 2,
      "x": 734,
      "y": 674
    },
    {
      "t": 115220,
      "e": 104374,
      "ty": 2,
      "x": 750,
      "y": 674
    },
    {
      "t": 115270,
      "e": 104424,
      "ty": 41,
      "x": 23001,
      "y": 3227,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115320,
      "e": 104474,
      "ty": 2,
      "x": 779,
      "y": 679
    },
    {
      "t": 115419,
      "e": 104573,
      "ty": 2,
      "x": 793,
      "y": 683
    },
    {
      "t": 115520,
      "e": 104674,
      "ty": 2,
      "x": 811,
      "y": 686
    },
    {
      "t": 115520,
      "e": 104674,
      "ty": 41,
      "x": 25461,
      "y": 10248,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115620,
      "e": 104774,
      "ty": 2,
      "x": 1030,
      "y": 1001
    },
    {
      "t": 115719,
      "e": 104873,
      "ty": 2,
      "x": 1055,
      "y": 1053
    },
    {
      "t": 115770,
      "e": 104924,
      "ty": 41,
      "x": 37465,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115920,
      "e": 105074,
      "ty": 2,
      "x": 1055,
      "y": 1056
    },
    {
      "t": 116020,
      "e": 105174,
      "ty": 2,
      "x": 1036,
      "y": 1072
    },
    {
      "t": 116020,
      "e": 105174,
      "ty": 41,
      "x": 36531,
      "y": 65487,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 116120,
      "e": 105274,
      "ty": 2,
      "x": 1035,
      "y": 1072
    },
    {
      "t": 116159,
      "e": 105313,
      "ty": 6,
      "x": 1018,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 116220,
      "e": 105374,
      "ty": 2,
      "x": 994,
      "y": 1092
    },
    {
      "t": 116270,
      "e": 105424,
      "ty": 41,
      "x": 45055,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 116320,
      "e": 105474,
      "ty": 2,
      "x": 992,
      "y": 1092
    },
    {
      "t": 116359,
      "e": 105513,
      "ty": 3,
      "x": 992,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 116361,
      "e": 105515,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 116479,
      "e": 105633,
      "ty": 4,
      "x": 45055,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 116480,
      "e": 105634,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 116482,
      "e": 105636,
      "ty": 5,
      "x": 992,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 116483,
      "e": 105637,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 117515,
      "e": 106669,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 119234,
      "e": 108388,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 185453, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 185460, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3322, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 190115, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8673, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 199795, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 34189, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 235068, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 17877, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 253948, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 17719, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 273026, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:888,y:828,t:1527030352367};\\\", \\\"{x:888,y:786,t:1527030352382};\\\", \\\"{x:888,y:772,t:1527030352398};\\\", \\\"{x:881,y:751,t:1527030352415};\\\", \\\"{x:877,y:744,t:1527030352432};\\\", \\\"{x:872,y:741,t:1527030352789};\\\", \\\"{x:865,y:738,t:1527030352800};\\\", \\\"{x:855,y:732,t:1527030352816};\\\", \\\"{x:844,y:726,t:1527030352833};\\\", \\\"{x:827,y:714,t:1527030352849};\\\", \\\"{x:807,y:704,t:1527030352866};\\\", \\\"{x:787,y:692,t:1527030352882};\\\", \\\"{x:768,y:683,t:1527030352899};\\\", \\\"{x:753,y:673,t:1527030352916};\\\", \\\"{x:747,y:670,t:1527030352933};\\\", \\\"{x:743,y:668,t:1527030352950};\\\", \\\"{x:742,y:668,t:1527030352967};\\\", \\\"{x:739,y:667,t:1527030352983};\\\", \\\"{x:736,y:665,t:1527030352999};\\\", \\\"{x:734,y:665,t:1527030353017};\\\", \\\"{x:734,y:664,t:1527030353215};\\\", \\\"{x:733,y:664,t:1527030353223};\\\", \\\"{x:732,y:664,t:1527030353233};\\\", \\\"{x:727,y:662,t:1527030353250};\\\", \\\"{x:724,y:662,t:1527030353266};\\\", \\\"{x:720,y:662,t:1527030353284};\\\", \\\"{x:716,y:662,t:1527030353300};\\\", \\\"{x:711,y:662,t:1527030353316};\\\", \\\"{x:702,y:662,t:1527030353333};\\\", \\\"{x:695,y:662,t:1527030353350};\\\", \\\"{x:693,y:662,t:1527030353366};\\\", \\\"{x:692,y:662,t:1527030353390};\\\", \\\"{x:691,y:662,t:1527030353414};\\\", \\\"{x:690,y:663,t:1527030353430};\\\", \\\"{x:690,y:664,t:1527030353446};\\\", \\\"{x:690,y:666,t:1527030353454};\\\", \\\"{x:690,y:672,t:1527030353467};\\\", \\\"{x:703,y:690,t:1527030353484};\\\", \\\"{x:732,y:724,t:1527030353500};\\\", \\\"{x:762,y:762,t:1527030353516};\\\", \\\"{x:790,y:800,t:1527030353534};\\\", \\\"{x:845,y:864,t:1527030353550};\\\", \\\"{x:893,y:917,t:1527030353567};\\\", \\\"{x:948,y:967,t:1527030353584};\\\", \\\"{x:991,y:1008,t:1527030353601};\\\", \\\"{x:1021,y:1036,t:1527030353617};\\\", \\\"{x:1058,y:1062,t:1527030353634};\\\", \\\"{x:1090,y:1080,t:1527030353650};\\\", \\\"{x:1121,y:1092,t:1527030353666};\\\", \\\"{x:1154,y:1101,t:1527030353684};\\\", \\\"{x:1194,y:1108,t:1527030353700};\\\", \\\"{x:1225,y:1111,t:1527030353716};\\\", \\\"{x:1240,y:1111,t:1527030353733};\\\", \\\"{x:1253,y:1102,t:1527030353749};\\\", \\\"{x:1257,y:1098,t:1527030353766};\\\", \\\"{x:1270,y:1095,t:1527030353783};\\\", \\\"{x:1288,y:1094,t:1527030353801};\\\", \\\"{x:1301,y:1091,t:1527030353817};\\\", \\\"{x:1307,y:1089,t:1527030353833};\\\", \\\"{x:1313,y:1083,t:1527030353850};\\\", \\\"{x:1316,y:1077,t:1527030353868};\\\", \\\"{x:1316,y:1066,t:1527030353883};\\\", \\\"{x:1316,y:1056,t:1527030353901};\\\", \\\"{x:1315,y:1046,t:1527030353918};\\\", \\\"{x:1315,y:1040,t:1527030353934};\\\", \\\"{x:1315,y:1035,t:1527030353950};\\\", \\\"{x:1315,y:1030,t:1527030353968};\\\", \\\"{x:1315,y:1027,t:1527030353984};\\\", \\\"{x:1313,y:1022,t:1527030354001};\\\", \\\"{x:1311,y:1015,t:1527030354018};\\\", \\\"{x:1311,y:1012,t:1527030354034};\\\", \\\"{x:1311,y:1010,t:1527030354051};\\\", \\\"{x:1311,y:1009,t:1527030354068};\\\", \\\"{x:1310,y:1007,t:1527030354084};\\\", \\\"{x:1310,y:1006,t:1527030354103};\\\", \\\"{x:1310,y:1004,t:1527030354134};\\\", \\\"{x:1310,y:1003,t:1527030354151};\\\", \\\"{x:1309,y:1002,t:1527030354167};\\\", \\\"{x:1308,y:1001,t:1527030354184};\\\", \\\"{x:1308,y:998,t:1527030354201};\\\", \\\"{x:1307,y:996,t:1527030354218};\\\", \\\"{x:1307,y:995,t:1527030354234};\\\", \\\"{x:1304,y:992,t:1527030354251};\\\", \\\"{x:1304,y:990,t:1527030354268};\\\", \\\"{x:1302,y:987,t:1527030354284};\\\", \\\"{x:1299,y:984,t:1527030354301};\\\", \\\"{x:1298,y:982,t:1527030354317};\\\", \\\"{x:1296,y:978,t:1527030354335};\\\", \\\"{x:1296,y:976,t:1527030354351};\\\", \\\"{x:1294,y:975,t:1527030354368};\\\", \\\"{x:1294,y:974,t:1527030354385};\\\", \\\"{x:1293,y:971,t:1527030354401};\\\", \\\"{x:1292,y:969,t:1527030354422};\\\", \\\"{x:1291,y:968,t:1527030354447};\\\", \\\"{x:1291,y:967,t:1527030354462};\\\", \\\"{x:1291,y:966,t:1527030354470};\\\", \\\"{x:1291,y:965,t:1527030354485};\\\", \\\"{x:1291,y:963,t:1527030354503};\\\", \\\"{x:1290,y:962,t:1527030354518};\\\", \\\"{x:1289,y:959,t:1527030354535};\\\", \\\"{x:1288,y:955,t:1527030354550};\\\", \\\"{x:1286,y:943,t:1527030354568};\\\", \\\"{x:1282,y:929,t:1527030354585};\\\", \\\"{x:1279,y:913,t:1527030354600};\\\", \\\"{x:1276,y:898,t:1527030354618};\\\", \\\"{x:1273,y:882,t:1527030354635};\\\", \\\"{x:1269,y:868,t:1527030354651};\\\", \\\"{x:1266,y:855,t:1527030354668};\\\", \\\"{x:1265,y:849,t:1527030354684};\\\", \\\"{x:1262,y:842,t:1527030354701};\\\", \\\"{x:1262,y:837,t:1527030354717};\\\", \\\"{x:1260,y:831,t:1527030354735};\\\", \\\"{x:1259,y:828,t:1527030354750};\\\", \\\"{x:1259,y:827,t:1527030354774};\\\", \\\"{x:1259,y:826,t:1527030354785};\\\", \\\"{x:1259,y:824,t:1527030354801};\\\", \\\"{x:1259,y:822,t:1527030354818};\\\", \\\"{x:1259,y:819,t:1527030354835};\\\", \\\"{x:1259,y:817,t:1527030354852};\\\", \\\"{x:1259,y:814,t:1527030354868};\\\", \\\"{x:1259,y:812,t:1527030354885};\\\", \\\"{x:1260,y:812,t:1527030354902};\\\", \\\"{x:1259,y:810,t:1527030354958};\\\", \\\"{x:1254,y:810,t:1527030354968};\\\", \\\"{x:1227,y:810,t:1527030354984};\\\", \\\"{x:1184,y:809,t:1527030355002};\\\", \\\"{x:1117,y:802,t:1527030355018};\\\", \\\"{x:1049,y:787,t:1527030355034};\\\", \\\"{x:989,y:766,t:1527030355052};\\\", \\\"{x:939,y:742,t:1527030355068};\\\", \\\"{x:892,y:711,t:1527030355085};\\\", \\\"{x:865,y:691,t:1527030355102};\\\", \\\"{x:841,y:673,t:1527030355118};\\\", \\\"{x:808,y:652,t:1527030355135};\\\", \\\"{x:784,y:639,t:1527030355152};\\\", \\\"{x:736,y:618,t:1527030355167};\\\", \\\"{x:652,y:575,t:1527030355185};\\\", \\\"{x:546,y:538,t:1527030355202};\\\", \\\"{x:449,y:510,t:1527030355219};\\\", \\\"{x:363,y:485,t:1527030355235};\\\", \\\"{x:274,y:460,t:1527030355251};\\\", \\\"{x:189,y:438,t:1527030355268};\\\", \\\"{x:119,y:424,t:1527030355285};\\\", \\\"{x:103,y:420,t:1527030355302};\\\", \\\"{x:100,y:419,t:1527030355319};\\\", \\\"{x:100,y:421,t:1527030355462};\\\", \\\"{x:102,y:426,t:1527030355470};\\\", \\\"{x:107,y:435,t:1527030355486};\\\", \\\"{x:127,y:458,t:1527030355503};\\\", \\\"{x:141,y:469,t:1527030355519};\\\", \\\"{x:152,y:477,t:1527030355536};\\\", \\\"{x:155,y:479,t:1527030355552};\\\", \\\"{x:158,y:480,t:1527030355569};\\\", \\\"{x:160,y:481,t:1527030355586};\\\", \\\"{x:163,y:482,t:1527030355602};\\\", \\\"{x:169,y:485,t:1527030355619};\\\", \\\"{x:175,y:486,t:1527030355636};\\\", \\\"{x:184,y:489,t:1527030355653};\\\", \\\"{x:206,y:494,t:1527030355670};\\\", \\\"{x:224,y:496,t:1527030355686};\\\", \\\"{x:241,y:498,t:1527030355702};\\\", \\\"{x:256,y:501,t:1527030355719};\\\", \\\"{x:270,y:501,t:1527030355736};\\\", \\\"{x:281,y:502,t:1527030355752};\\\", \\\"{x:293,y:504,t:1527030355769};\\\", \\\"{x:301,y:505,t:1527030355786};\\\", \\\"{x:308,y:506,t:1527030355803};\\\", \\\"{x:316,y:510,t:1527030355820};\\\", \\\"{x:326,y:514,t:1527030355837};\\\", \\\"{x:335,y:519,t:1527030355852};\\\", \\\"{x:347,y:527,t:1527030355869};\\\", \\\"{x:362,y:539,t:1527030355887};\\\", \\\"{x:368,y:545,t:1527030355904};\\\", \\\"{x:372,y:549,t:1527030355919};\\\", \\\"{x:372,y:550,t:1527030355936};\\\", \\\"{x:374,y:551,t:1527030355974};\\\", \\\"{x:375,y:552,t:1527030355987};\\\", \\\"{x:376,y:552,t:1527030356046};\\\", \\\"{x:377,y:552,t:1527030356054};\\\", \\\"{x:380,y:552,t:1527030356070};\\\", \\\"{x:381,y:550,t:1527030356086};\\\", \\\"{x:386,y:547,t:1527030356103};\\\", \\\"{x:387,y:546,t:1527030356120};\\\", \\\"{x:389,y:544,t:1527030356135};\\\", \\\"{x:390,y:542,t:1527030356152};\\\", \\\"{x:391,y:540,t:1527030356169};\\\", \\\"{x:392,y:539,t:1527030356186};\\\", \\\"{x:392,y:538,t:1527030356203};\\\", \\\"{x:393,y:537,t:1527030356219};\\\", \\\"{x:393,y:536,t:1527030356237};\\\", \\\"{x:393,y:535,t:1527030356253};\\\", \\\"{x:393,y:534,t:1527030356269};\\\", \\\"{x:393,y:533,t:1527030356293};\\\", \\\"{x:393,y:531,t:1527030356415};\\\", \\\"{x:393,y:529,t:1527030356423};\\\", \\\"{x:393,y:528,t:1527030356436};\\\", \\\"{x:393,y:525,t:1527030356452};\\\", \\\"{x:393,y:527,t:1527030356974};\\\", \\\"{x:397,y:534,t:1527030356988};\\\", \\\"{x:413,y:561,t:1527030357003};\\\", \\\"{x:440,y:598,t:1527030357021};\\\", \\\"{x:468,y:633,t:1527030357036};\\\", \\\"{x:499,y:676,t:1527030357053};\\\", \\\"{x:512,y:692,t:1527030357070};\\\", \\\"{x:516,y:698,t:1527030357087};\\\", \\\"{x:520,y:702,t:1527030357104};\\\", \\\"{x:521,y:705,t:1527030357121};\\\", \\\"{x:523,y:708,t:1527030357137};\\\", \\\"{x:523,y:711,t:1527030357153};\\\", \\\"{x:526,y:716,t:1527030357170};\\\", \\\"{x:526,y:719,t:1527030357187};\\\", \\\"{x:526,y:723,t:1527030357203};\\\", \\\"{x:526,y:731,t:1527030357220};\\\", \\\"{x:526,y:738,t:1527030357237};\\\", \\\"{x:526,y:741,t:1527030357253};\\\", \\\"{x:526,y:742,t:1527030357270};\\\", \\\"{x:526,y:740,t:1527030357422};\\\", \\\"{x:526,y:735,t:1527030357439};\\\", \\\"{x:526,y:731,t:1527030357454};\\\", \\\"{x:526,y:727,t:1527030357470};\\\", \\\"{x:526,y:724,t:1527030357487};\\\", \\\"{x:526,y:720,t:1527030357504};\\\", \\\"{x:526,y:718,t:1527030357520};\\\", \\\"{x:526,y:717,t:1527030359998};\\\" ] }, { \\\"rt\\\": 18220, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 292489, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:710,t:1527030367295};\\\", \\\"{x:529,y:703,t:1527030367304};\\\", \\\"{x:531,y:695,t:1527030367313};\\\", \\\"{x:537,y:679,t:1527030367330};\\\", \\\"{x:545,y:660,t:1527030367346};\\\", \\\"{x:553,y:640,t:1527030367362};\\\", \\\"{x:557,y:623,t:1527030367378};\\\", \\\"{x:561,y:608,t:1527030367395};\\\", \\\"{x:566,y:591,t:1527030367411};\\\", \\\"{x:572,y:572,t:1527030367429};\\\", \\\"{x:585,y:540,t:1527030367446};\\\", \\\"{x:599,y:512,t:1527030367462};\\\", \\\"{x:615,y:478,t:1527030367479};\\\", \\\"{x:642,y:434,t:1527030367495};\\\", \\\"{x:668,y:390,t:1527030367511};\\\", \\\"{x:700,y:341,t:1527030367528};\\\", \\\"{x:733,y:290,t:1527030367545};\\\", \\\"{x:766,y:240,t:1527030367563};\\\", \\\"{x:790,y:199,t:1527030367578};\\\", \\\"{x:815,y:158,t:1527030367595};\\\", \\\"{x:838,y:120,t:1527030367613};\\\", \\\"{x:865,y:83,t:1527030367629};\\\", \\\"{x:893,y:41,t:1527030367646};\\\", \\\"{x:908,y:23,t:1527030367662};\\\", \\\"{x:922,y:8,t:1527030367680};\\\", \\\"{x:929,y:2,t:1527030367695};\\\", \\\"{x:933,y:2,t:1527030367712};\\\", \\\"{x:936,y:1,t:1527030367729};\\\", \\\"{x:938,y:1,t:1527030367746};\\\", \\\"{x:941,y:1,t:1527030367763};\\\", \\\"{x:949,y:1,t:1527030367779};\\\", \\\"{x:960,y:5,t:1527030367797};\\\", \\\"{x:987,y:13,t:1527030367814};\\\", \\\"{x:1003,y:19,t:1527030367829};\\\", \\\"{x:1018,y:24,t:1527030367846};\\\", \\\"{x:1027,y:28,t:1527030367864};\\\", \\\"{x:1035,y:31,t:1527030367880};\\\", \\\"{x:1043,y:35,t:1527030367897};\\\", \\\"{x:1049,y:39,t:1527030367914};\\\", \\\"{x:1055,y:42,t:1527030367931};\\\", \\\"{x:1060,y:45,t:1527030367946};\\\", \\\"{x:1064,y:47,t:1527030367963};\\\", \\\"{x:1072,y:51,t:1527030367980};\\\", \\\"{x:1088,y:61,t:1527030367998};\\\", \\\"{x:1101,y:66,t:1527030368013};\\\", \\\"{x:1107,y:70,t:1527030368031};\\\", \\\"{x:1113,y:73,t:1527030368048};\\\", \\\"{x:1122,y:79,t:1527030368065};\\\", \\\"{x:1134,y:89,t:1527030368081};\\\", \\\"{x:1143,y:94,t:1527030368098};\\\", \\\"{x:1151,y:102,t:1527030368115};\\\", \\\"{x:1158,y:108,t:1527030368132};\\\", \\\"{x:1163,y:112,t:1527030368148};\\\", \\\"{x:1166,y:116,t:1527030368164};\\\", \\\"{x:1170,y:121,t:1527030368181};\\\", \\\"{x:1172,y:125,t:1527030368198};\\\", \\\"{x:1174,y:127,t:1527030368214};\\\", \\\"{x:1175,y:129,t:1527030368232};\\\", \\\"{x:1176,y:131,t:1527030368249};\\\", \\\"{x:1176,y:132,t:1527030368265};\\\", \\\"{x:1176,y:133,t:1527030368282};\\\", \\\"{x:1176,y:136,t:1527030368299};\\\", \\\"{x:1177,y:138,t:1527030368315};\\\", \\\"{x:1177,y:139,t:1527030368332};\\\", \\\"{x:1177,y:141,t:1527030368348};\\\", \\\"{x:1177,y:144,t:1527030368365};\\\", \\\"{x:1177,y:145,t:1527030368383};\\\", \\\"{x:1177,y:147,t:1527030368399};\\\", \\\"{x:1177,y:150,t:1527030368416};\\\", \\\"{x:1177,y:152,t:1527030368432};\\\", \\\"{x:1177,y:155,t:1527030368450};\\\", \\\"{x:1177,y:161,t:1527030368466};\\\", \\\"{x:1176,y:164,t:1527030368482};\\\", \\\"{x:1176,y:168,t:1527030368500};\\\", \\\"{x:1173,y:170,t:1527030368517};\\\", \\\"{x:1173,y:173,t:1527030368533};\\\", \\\"{x:1171,y:177,t:1527030368549};\\\", \\\"{x:1171,y:178,t:1527030368566};\\\", \\\"{x:1170,y:181,t:1527030368583};\\\", \\\"{x:1170,y:182,t:1527030368599};\\\", \\\"{x:1170,y:183,t:1527030368617};\\\", \\\"{x:1170,y:185,t:1527030368633};\\\", \\\"{x:1169,y:187,t:1527030368650};\\\", \\\"{x:1169,y:188,t:1527030368667};\\\", \\\"{x:1169,y:189,t:1527030368683};\\\", \\\"{x:1169,y:192,t:1527030368700};\\\", \\\"{x:1169,y:195,t:1527030368716};\\\", \\\"{x:1169,y:199,t:1527030368734};\\\", \\\"{x:1169,y:203,t:1527030368751};\\\", \\\"{x:1167,y:207,t:1527030368768};\\\", \\\"{x:1166,y:214,t:1527030368784};\\\", \\\"{x:1165,y:220,t:1527030368800};\\\", \\\"{x:1162,y:226,t:1527030368818};\\\", \\\"{x:1161,y:232,t:1527030368835};\\\", \\\"{x:1159,y:236,t:1527030368850};\\\", \\\"{x:1158,y:242,t:1527030368867};\\\", \\\"{x:1158,y:248,t:1527030368885};\\\", \\\"{x:1155,y:253,t:1527030368901};\\\", \\\"{x:1155,y:260,t:1527030368918};\\\", \\\"{x:1153,y:265,t:1527030368934};\\\", \\\"{x:1151,y:270,t:1527030368952};\\\", \\\"{x:1151,y:274,t:1527030368968};\\\", \\\"{x:1150,y:279,t:1527030368984};\\\", \\\"{x:1150,y:285,t:1527030369002};\\\", \\\"{x:1150,y:292,t:1527030369018};\\\", \\\"{x:1150,y:299,t:1527030369035};\\\", \\\"{x:1147,y:308,t:1527030369052};\\\", \\\"{x:1147,y:318,t:1527030369068};\\\", \\\"{x:1147,y:334,t:1527030369086};\\\", \\\"{x:1147,y:344,t:1527030369102};\\\", \\\"{x:1147,y:358,t:1527030369118};\\\", \\\"{x:1146,y:373,t:1527030369135};\\\", \\\"{x:1144,y:394,t:1527030369152};\\\", \\\"{x:1140,y:412,t:1527030369169};\\\", \\\"{x:1134,y:438,t:1527030369185};\\\", \\\"{x:1133,y:467,t:1527030369203};\\\", \\\"{x:1129,y:501,t:1527030369219};\\\", \\\"{x:1128,y:528,t:1527030369236};\\\", \\\"{x:1128,y:556,t:1527030369252};\\\", \\\"{x:1127,y:601,t:1527030369269};\\\", \\\"{x:1123,y:627,t:1527030369286};\\\", \\\"{x:1117,y:651,t:1527030369303};\\\", \\\"{x:1110,y:672,t:1527030369320};\\\", \\\"{x:1103,y:691,t:1527030369337};\\\", \\\"{x:1098,y:703,t:1527030369353};\\\", \\\"{x:1095,y:709,t:1527030369370};\\\", \\\"{x:1093,y:715,t:1527030369386};\\\", \\\"{x:1092,y:719,t:1527030369404};\\\", \\\"{x:1092,y:724,t:1527030369419};\\\", \\\"{x:1091,y:729,t:1527030369437};\\\", \\\"{x:1088,y:741,t:1527030369452};\\\", \\\"{x:1087,y:753,t:1527030369471};\\\", \\\"{x:1084,y:768,t:1527030369487};\\\", \\\"{x:1082,y:784,t:1527030369504};\\\", \\\"{x:1077,y:805,t:1527030369521};\\\", \\\"{x:1066,y:836,t:1527030369537};\\\", \\\"{x:1053,y:866,t:1527030369553};\\\", \\\"{x:1040,y:898,t:1527030369570};\\\", \\\"{x:1024,y:928,t:1527030369587};\\\", \\\"{x:1013,y:952,t:1527030369603};\\\", \\\"{x:1005,y:971,t:1527030369620};\\\", \\\"{x:1004,y:990,t:1527030369637};\\\", \\\"{x:1005,y:1004,t:1527030369655};\\\", \\\"{x:1010,y:1019,t:1527030369671};\\\", \\\"{x:1017,y:1035,t:1527030369687};\\\", \\\"{x:1027,y:1054,t:1527030369705};\\\", \\\"{x:1040,y:1075,t:1527030369721};\\\", \\\"{x:1057,y:1097,t:1527030369737};\\\", \\\"{x:1079,y:1118,t:1527030369755};\\\", \\\"{x:1103,y:1137,t:1527030369771};\\\", \\\"{x:1130,y:1154,t:1527030369789};\\\", \\\"{x:1157,y:1168,t:1527030369805};\\\", \\\"{x:1203,y:1190,t:1527030369821};\\\", \\\"{x:1227,y:1196,t:1527030369839};\\\", \\\"{x:1236,y:1197,t:1527030369848};\\\", \\\"{x:1258,y:1198,t:1527030369863};\\\", \\\"{x:1278,y:1199,t:1527030369880};\\\", \\\"{x:1295,y:1199,t:1527030369898};\\\", \\\"{x:1312,y:1199,t:1527030369913};\\\", \\\"{x:1331,y:1199,t:1527030369931};\\\", \\\"{x:1347,y:1199,t:1527030369948};\\\", \\\"{x:1369,y:1199,t:1527030369965};\\\", \\\"{x:1393,y:1199,t:1527030369981};\\\", \\\"{x:1417,y:1199,t:1527030369997};\\\", \\\"{x:1434,y:1199,t:1527030370015};\\\", \\\"{x:1451,y:1199,t:1527030370031};\\\", \\\"{x:1463,y:1199,t:1527030370048};\\\", \\\"{x:1476,y:1199,t:1527030370065};\\\", \\\"{x:1491,y:1195,t:1527030370082};\\\", \\\"{x:1504,y:1191,t:1527030370099};\\\", \\\"{x:1519,y:1185,t:1527030370115};\\\", \\\"{x:1541,y:1175,t:1527030370132};\\\", \\\"{x:1566,y:1167,t:1527030370149};\\\", \\\"{x:1591,y:1158,t:1527030370164};\\\", \\\"{x:1608,y:1148,t:1527030370181};\\\", \\\"{x:1633,y:1127,t:1527030370198};\\\", \\\"{x:1642,y:1114,t:1527030370214};\\\", \\\"{x:1651,y:1096,t:1527030370231};\\\", \\\"{x:1658,y:1077,t:1527030370248};\\\", \\\"{x:1663,y:1057,t:1527030370264};\\\", \\\"{x:1671,y:1036,t:1527030370281};\\\", \\\"{x:1677,y:1011,t:1527030370299};\\\", \\\"{x:1682,y:992,t:1527030370313};\\\", \\\"{x:1690,y:968,t:1527030370331};\\\", \\\"{x:1696,y:944,t:1527030370347};\\\", \\\"{x:1703,y:919,t:1527030370363};\\\", \\\"{x:1708,y:892,t:1527030370381};\\\", \\\"{x:1721,y:849,t:1527030370397};\\\", \\\"{x:1726,y:819,t:1527030370413};\\\", \\\"{x:1729,y:788,t:1527030370431};\\\", \\\"{x:1729,y:761,t:1527030370447};\\\", \\\"{x:1729,y:735,t:1527030370464};\\\", \\\"{x:1729,y:714,t:1527030370480};\\\", \\\"{x:1729,y:695,t:1527030370498};\\\", \\\"{x:1729,y:670,t:1527030370515};\\\", \\\"{x:1729,y:647,t:1527030370531};\\\", \\\"{x:1725,y:624,t:1527030370548};\\\", \\\"{x:1724,y:603,t:1527030370564};\\\", \\\"{x:1720,y:583,t:1527030370581};\\\", \\\"{x:1715,y:554,t:1527030370597};\\\", \\\"{x:1709,y:537,t:1527030370615};\\\", \\\"{x:1695,y:516,t:1527030370631};\\\", \\\"{x:1676,y:493,t:1527030370648};\\\", \\\"{x:1647,y:464,t:1527030370665};\\\", \\\"{x:1624,y:447,t:1527030370681};\\\", \\\"{x:1616,y:442,t:1527030370698};\\\", \\\"{x:1615,y:442,t:1527030370774};\\\", \\\"{x:1614,y:441,t:1527030370798};\\\", \\\"{x:1613,y:441,t:1527030370830};\\\", \\\"{x:1610,y:441,t:1527030370848};\\\", \\\"{x:1604,y:441,t:1527030370865};\\\", \\\"{x:1595,y:442,t:1527030370881};\\\", \\\"{x:1585,y:445,t:1527030370899};\\\", \\\"{x:1573,y:453,t:1527030370915};\\\", \\\"{x:1563,y:458,t:1527030370932};\\\", \\\"{x:1551,y:465,t:1527030370949};\\\", \\\"{x:1544,y:470,t:1527030370965};\\\", \\\"{x:1533,y:478,t:1527030370982};\\\", \\\"{x:1525,y:482,t:1527030370998};\\\", \\\"{x:1516,y:489,t:1527030371016};\\\", \\\"{x:1505,y:496,t:1527030371033};\\\", \\\"{x:1492,y:507,t:1527030371049};\\\", \\\"{x:1483,y:517,t:1527030371065};\\\", \\\"{x:1473,y:530,t:1527030371083};\\\", \\\"{x:1467,y:541,t:1527030371099};\\\", \\\"{x:1460,y:557,t:1527030371115};\\\", \\\"{x:1453,y:574,t:1527030371132};\\\", \\\"{x:1445,y:590,t:1527030371149};\\\", \\\"{x:1436,y:612,t:1527030371165};\\\", \\\"{x:1421,y:641,t:1527030371182};\\\", \\\"{x:1409,y:662,t:1527030371198};\\\", \\\"{x:1401,y:679,t:1527030371215};\\\", \\\"{x:1388,y:702,t:1527030371232};\\\", \\\"{x:1373,y:726,t:1527030371248};\\\", \\\"{x:1358,y:752,t:1527030371265};\\\", \\\"{x:1342,y:780,t:1527030371282};\\\", \\\"{x:1322,y:808,t:1527030371298};\\\", \\\"{x:1303,y:830,t:1527030371314};\\\", \\\"{x:1284,y:847,t:1527030371332};\\\", \\\"{x:1267,y:859,t:1527030371348};\\\", \\\"{x:1259,y:863,t:1527030371365};\\\", \\\"{x:1255,y:866,t:1527030371381};\\\", \\\"{x:1254,y:866,t:1527030371399};\\\", \\\"{x:1252,y:866,t:1527030371502};\\\", \\\"{x:1251,y:866,t:1527030371534};\\\", \\\"{x:1250,y:866,t:1527030371566};\\\", \\\"{x:1246,y:860,t:1527030371581};\\\", \\\"{x:1240,y:851,t:1527030371599};\\\", \\\"{x:1237,y:846,t:1527030371615};\\\", \\\"{x:1236,y:845,t:1527030371632};\\\", \\\"{x:1236,y:844,t:1527030371654};\\\", \\\"{x:1235,y:842,t:1527030371666};\\\", \\\"{x:1234,y:841,t:1527030371683};\\\", \\\"{x:1234,y:838,t:1527030371699};\\\", \\\"{x:1232,y:834,t:1527030371715};\\\", \\\"{x:1232,y:830,t:1527030371733};\\\", \\\"{x:1231,y:823,t:1527030371749};\\\", \\\"{x:1231,y:816,t:1527030371765};\\\", \\\"{x:1228,y:805,t:1527030371783};\\\", \\\"{x:1227,y:795,t:1527030371799};\\\", \\\"{x:1226,y:785,t:1527030371816};\\\", \\\"{x:1226,y:779,t:1527030371832};\\\", \\\"{x:1226,y:775,t:1527030371850};\\\", \\\"{x:1226,y:772,t:1527030371866};\\\", \\\"{x:1226,y:768,t:1527030371882};\\\", \\\"{x:1226,y:766,t:1527030371899};\\\", \\\"{x:1226,y:762,t:1527030371916};\\\", \\\"{x:1226,y:758,t:1527030371932};\\\", \\\"{x:1226,y:752,t:1527030371949};\\\", \\\"{x:1226,y:744,t:1527030371966};\\\", \\\"{x:1226,y:737,t:1527030371983};\\\", \\\"{x:1228,y:728,t:1527030371999};\\\", \\\"{x:1230,y:722,t:1527030372016};\\\", \\\"{x:1232,y:714,t:1527030372033};\\\", \\\"{x:1233,y:707,t:1527030372050};\\\", \\\"{x:1235,y:700,t:1527030372066};\\\", \\\"{x:1238,y:693,t:1527030372082};\\\", \\\"{x:1241,y:685,t:1527030372100};\\\", \\\"{x:1244,y:680,t:1527030372116};\\\", \\\"{x:1251,y:674,t:1527030372132};\\\", \\\"{x:1260,y:670,t:1527030372149};\\\", \\\"{x:1269,y:666,t:1527030372165};\\\", \\\"{x:1274,y:663,t:1527030372183};\\\", \\\"{x:1277,y:660,t:1527030372199};\\\", \\\"{x:1281,y:659,t:1527030372216};\\\", \\\"{x:1283,y:658,t:1527030372233};\\\", \\\"{x:1285,y:656,t:1527030372249};\\\", \\\"{x:1287,y:655,t:1527030372266};\\\", \\\"{x:1290,y:653,t:1527030372284};\\\", \\\"{x:1294,y:651,t:1527030372299};\\\", \\\"{x:1299,y:649,t:1527030372316};\\\", \\\"{x:1305,y:647,t:1527030372333};\\\", \\\"{x:1307,y:645,t:1527030372348};\\\", \\\"{x:1316,y:641,t:1527030372366};\\\", \\\"{x:1325,y:639,t:1527030372383};\\\", \\\"{x:1331,y:636,t:1527030372398};\\\", \\\"{x:1338,y:634,t:1527030372416};\\\", \\\"{x:1343,y:631,t:1527030372433};\\\", \\\"{x:1350,y:628,t:1527030372449};\\\", \\\"{x:1358,y:624,t:1527030372466};\\\", \\\"{x:1367,y:621,t:1527030372483};\\\", \\\"{x:1374,y:618,t:1527030372499};\\\", \\\"{x:1383,y:613,t:1527030372516};\\\", \\\"{x:1393,y:606,t:1527030372533};\\\", \\\"{x:1407,y:596,t:1527030372549};\\\", \\\"{x:1425,y:581,t:1527030372566};\\\", \\\"{x:1440,y:571,t:1527030372583};\\\", \\\"{x:1454,y:560,t:1527030372599};\\\", \\\"{x:1468,y:548,t:1527030372616};\\\", \\\"{x:1484,y:537,t:1527030372633};\\\", \\\"{x:1495,y:529,t:1527030372650};\\\", \\\"{x:1507,y:521,t:1527030372666};\\\", \\\"{x:1517,y:514,t:1527030372683};\\\", \\\"{x:1530,y:505,t:1527030372700};\\\", \\\"{x:1541,y:496,t:1527030372716};\\\", \\\"{x:1568,y:472,t:1527030372733};\\\", \\\"{x:1589,y:454,t:1527030372749};\\\", \\\"{x:1613,y:438,t:1527030372766};\\\", \\\"{x:1635,y:426,t:1527030372783};\\\", \\\"{x:1648,y:418,t:1527030372799};\\\", \\\"{x:1651,y:416,t:1527030372816};\\\", \\\"{x:1652,y:416,t:1527030372833};\\\", \\\"{x:1649,y:416,t:1527030372982};\\\", \\\"{x:1643,y:416,t:1527030373000};\\\", \\\"{x:1637,y:417,t:1527030373016};\\\", \\\"{x:1631,y:419,t:1527030373033};\\\", \\\"{x:1624,y:422,t:1527030373050};\\\", \\\"{x:1620,y:423,t:1527030373066};\\\", \\\"{x:1617,y:423,t:1527030373083};\\\", \\\"{x:1616,y:423,t:1527030373109};\\\", \\\"{x:1614,y:424,t:1527030373310};\\\", \\\"{x:1612,y:424,t:1527030373318};\\\", \\\"{x:1612,y:425,t:1527030373336};\\\", \\\"{x:1610,y:428,t:1527030373350};\\\", \\\"{x:1608,y:432,t:1527030373367};\\\", \\\"{x:1607,y:439,t:1527030373382};\\\", \\\"{x:1605,y:448,t:1527030373400};\\\", \\\"{x:1604,y:458,t:1527030373417};\\\", \\\"{x:1602,y:472,t:1527030373433};\\\", \\\"{x:1600,y:488,t:1527030373449};\\\", \\\"{x:1597,y:505,t:1527030373466};\\\", \\\"{x:1597,y:521,t:1527030373482};\\\", \\\"{x:1597,y:541,t:1527030373500};\\\", \\\"{x:1604,y:578,t:1527030373517};\\\", \\\"{x:1607,y:595,t:1527030373533};\\\", \\\"{x:1607,y:607,t:1527030373550};\\\", \\\"{x:1607,y:621,t:1527030373567};\\\", \\\"{x:1607,y:631,t:1527030373584};\\\", \\\"{x:1608,y:633,t:1527030373600};\\\", \\\"{x:1608,y:634,t:1527030373616};\\\", \\\"{x:1608,y:632,t:1527030373767};\\\", \\\"{x:1608,y:626,t:1527030373785};\\\", \\\"{x:1609,y:620,t:1527030373801};\\\", \\\"{x:1610,y:614,t:1527030373817};\\\", \\\"{x:1611,y:610,t:1527030373834};\\\", \\\"{x:1611,y:606,t:1527030373850};\\\", \\\"{x:1611,y:604,t:1527030373867};\\\", \\\"{x:1612,y:602,t:1527030373885};\\\", \\\"{x:1612,y:601,t:1527030373900};\\\", \\\"{x:1612,y:600,t:1527030373917};\\\", \\\"{x:1612,y:598,t:1527030373934};\\\", \\\"{x:1613,y:597,t:1527030373958};\\\", \\\"{x:1613,y:596,t:1527030374039};\\\", \\\"{x:1613,y:595,t:1527030374051};\\\", \\\"{x:1613,y:590,t:1527030374067};\\\", \\\"{x:1609,y:581,t:1527030374085};\\\", \\\"{x:1603,y:572,t:1527030374102};\\\", \\\"{x:1598,y:565,t:1527030374118};\\\", \\\"{x:1594,y:561,t:1527030374133};\\\", \\\"{x:1585,y:555,t:1527030374152};\\\", \\\"{x:1573,y:547,t:1527030374167};\\\", \\\"{x:1526,y:528,t:1527030374184};\\\", \\\"{x:1444,y:509,t:1527030374202};\\\", \\\"{x:1355,y:500,t:1527030374217};\\\", \\\"{x:1264,y:500,t:1527030374233};\\\", \\\"{x:1157,y:506,t:1527030374250};\\\", \\\"{x:1035,y:521,t:1527030374267};\\\", \\\"{x:908,y:542,t:1527030374284};\\\", \\\"{x:732,y:548,t:1527030374301};\\\", \\\"{x:618,y:548,t:1527030374318};\\\", \\\"{x:532,y:548,t:1527030374334};\\\", \\\"{x:463,y:539,t:1527030374351};\\\", \\\"{x:425,y:530,t:1527030374367};\\\", \\\"{x:404,y:525,t:1527030374384};\\\", \\\"{x:401,y:524,t:1527030374401};\\\", \\\"{x:401,y:525,t:1527030374566};\\\", \\\"{x:402,y:528,t:1527030374573};\\\", \\\"{x:403,y:533,t:1527030374584};\\\", \\\"{x:404,y:544,t:1527030374601};\\\", \\\"{x:407,y:553,t:1527030374618};\\\", \\\"{x:407,y:560,t:1527030374633};\\\", \\\"{x:407,y:566,t:1527030374650};\\\", \\\"{x:407,y:570,t:1527030374668};\\\", \\\"{x:406,y:572,t:1527030374684};\\\", \\\"{x:406,y:577,t:1527030374701};\\\", \\\"{x:403,y:580,t:1527030374718};\\\", \\\"{x:400,y:584,t:1527030374734};\\\", \\\"{x:399,y:588,t:1527030374750};\\\", \\\"{x:395,y:591,t:1527030374768};\\\", \\\"{x:390,y:596,t:1527030374784};\\\", \\\"{x:385,y:599,t:1527030374800};\\\", \\\"{x:382,y:601,t:1527030374818};\\\", \\\"{x:379,y:602,t:1527030374834};\\\", \\\"{x:376,y:603,t:1527030374851};\\\", \\\"{x:374,y:603,t:1527030374867};\\\", \\\"{x:370,y:603,t:1527030374885};\\\", \\\"{x:365,y:603,t:1527030374900};\\\", \\\"{x:354,y:598,t:1527030374917};\\\", \\\"{x:331,y:588,t:1527030374935};\\\", \\\"{x:299,y:579,t:1527030374952};\\\", \\\"{x:273,y:575,t:1527030374968};\\\", \\\"{x:253,y:571,t:1527030374985};\\\", \\\"{x:238,y:571,t:1527030375000};\\\", \\\"{x:230,y:571,t:1527030375018};\\\", \\\"{x:224,y:571,t:1527030375034};\\\", \\\"{x:223,y:571,t:1527030375078};\\\", \\\"{x:221,y:571,t:1527030375101};\\\", \\\"{x:219,y:572,t:1527030375118};\\\", \\\"{x:215,y:575,t:1527030375136};\\\", \\\"{x:209,y:580,t:1527030375151};\\\", \\\"{x:203,y:583,t:1527030375169};\\\", \\\"{x:199,y:587,t:1527030375185};\\\", \\\"{x:193,y:592,t:1527030375201};\\\", \\\"{x:185,y:596,t:1527030375219};\\\", \\\"{x:174,y:602,t:1527030375235};\\\", \\\"{x:162,y:609,t:1527030375252};\\\", \\\"{x:150,y:615,t:1527030375269};\\\", \\\"{x:141,y:617,t:1527030375285};\\\", \\\"{x:139,y:618,t:1527030375302};\\\", \\\"{x:139,y:619,t:1527030375710};\\\", \\\"{x:139,y:622,t:1527030375720};\\\", \\\"{x:139,y:626,t:1527030375734};\\\", \\\"{x:140,y:630,t:1527030375752};\\\", \\\"{x:142,y:632,t:1527030375768};\\\", \\\"{x:142,y:633,t:1527030375785};\\\", \\\"{x:143,y:633,t:1527030376134};\\\", \\\"{x:145,y:634,t:1527030376141};\\\", \\\"{x:149,y:636,t:1527030376153};\\\", \\\"{x:152,y:637,t:1527030376169};\\\", \\\"{x:160,y:641,t:1527030376185};\\\", \\\"{x:188,y:653,t:1527030376202};\\\", \\\"{x:260,y:685,t:1527030376219};\\\", \\\"{x:340,y:719,t:1527030376235};\\\", \\\"{x:397,y:741,t:1527030376252};\\\", \\\"{x:444,y:752,t:1527030376269};\\\", \\\"{x:468,y:758,t:1527030376285};\\\", \\\"{x:486,y:761,t:1527030376302};\\\", \\\"{x:491,y:762,t:1527030376318};\\\", \\\"{x:492,y:762,t:1527030376335};\\\", \\\"{x:490,y:761,t:1527030376438};\\\", \\\"{x:487,y:759,t:1527030376452};\\\", \\\"{x:479,y:752,t:1527030376469};\\\", \\\"{x:476,y:749,t:1527030376486};\\\", \\\"{x:474,y:748,t:1527030376517};\\\", \\\"{x:471,y:747,t:1527030376525};\\\", \\\"{x:468,y:744,t:1527030376536};\\\", \\\"{x:450,y:737,t:1527030376552};\\\", \\\"{x:426,y:729,t:1527030376569};\\\", \\\"{x:393,y:721,t:1527030376586};\\\", \\\"{x:353,y:708,t:1527030376603};\\\", \\\"{x:315,y:699,t:1527030376619};\\\", \\\"{x:280,y:692,t:1527030376636};\\\", \\\"{x:252,y:685,t:1527030376654};\\\", \\\"{x:244,y:682,t:1527030376669};\\\", \\\"{x:238,y:679,t:1527030376686};\\\", \\\"{x:237,y:679,t:1527030376703};\\\", \\\"{x:236,y:678,t:1527030376719};\\\", \\\"{x:234,y:677,t:1527030376736};\\\", \\\"{x:229,y:675,t:1527030376753};\\\", \\\"{x:214,y:669,t:1527030376769};\\\", \\\"{x:191,y:659,t:1527030376787};\\\", \\\"{x:175,y:653,t:1527030376803};\\\", \\\"{x:162,y:646,t:1527030376820};\\\", \\\"{x:151,y:641,t:1527030376835};\\\", \\\"{x:143,y:638,t:1527030376852};\\\", \\\"{x:141,y:636,t:1527030376868};\\\", \\\"{x:140,y:635,t:1527030376886};\\\", \\\"{x:141,y:636,t:1527030377326};\\\", \\\"{x:142,y:636,t:1527030377342};\\\", \\\"{x:143,y:636,t:1527030377365};\\\", \\\"{x:145,y:637,t:1527030377381};\\\", \\\"{x:146,y:637,t:1527030377390};\\\", \\\"{x:149,y:638,t:1527030377404};\\\", \\\"{x:157,y:639,t:1527030377420};\\\", \\\"{x:160,y:639,t:1527030377437};\\\", \\\"{x:161,y:639,t:1527030377557};\\\", \\\"{x:170,y:640,t:1527030377797};\\\", \\\"{x:184,y:645,t:1527030377805};\\\", \\\"{x:198,y:648,t:1527030377820};\\\", \\\"{x:247,y:661,t:1527030377838};\\\", \\\"{x:268,y:666,t:1527030377853};\\\", \\\"{x:282,y:667,t:1527030377869};\\\", \\\"{x:288,y:668,t:1527030377887};\\\", \\\"{x:290,y:668,t:1527030377903};\\\", \\\"{x:291,y:668,t:1527030377920};\\\", \\\"{x:294,y:668,t:1527030377937};\\\", \\\"{x:297,y:668,t:1527030377953};\\\", \\\"{x:302,y:668,t:1527030377970};\\\", \\\"{x:311,y:668,t:1527030377987};\\\", \\\"{x:330,y:668,t:1527030378004};\\\", \\\"{x:350,y:675,t:1527030378020};\\\", \\\"{x:388,y:690,t:1527030378037};\\\", \\\"{x:407,y:699,t:1527030378053};\\\", \\\"{x:422,y:705,t:1527030378070};\\\", \\\"{x:433,y:710,t:1527030378087};\\\", \\\"{x:442,y:714,t:1527030378104};\\\", \\\"{x:454,y:718,t:1527030378120};\\\", \\\"{x:465,y:722,t:1527030378137};\\\", \\\"{x:471,y:724,t:1527030378153};\\\", \\\"{x:474,y:725,t:1527030378170};\\\", \\\"{x:482,y:729,t:1527030378187};\\\", \\\"{x:493,y:734,t:1527030378204};\\\", \\\"{x:500,y:737,t:1527030378221};\\\", \\\"{x:505,y:738,t:1527030378237};\\\", \\\"{x:507,y:738,t:1527030378254};\\\", \\\"{x:508,y:738,t:1527030378342};\\\", \\\"{x:508,y:737,t:1527030378366};\\\", \\\"{x:508,y:735,t:1527030378374};\\\", \\\"{x:508,y:734,t:1527030378389};\\\", \\\"{x:508,y:733,t:1527030378405};\\\", \\\"{x:508,y:732,t:1527030378452};\\\", \\\"{x:508,y:731,t:1527030378525};\\\", \\\"{x:508,y:730,t:1527030378537};\\\", \\\"{x:508,y:729,t:1527030378554};\\\", \\\"{x:508,y:728,t:1527030378845};\\\", \\\"{x:508,y:727,t:1527030378885};\\\", \\\"{x:506,y:727,t:1527030378990};\\\", \\\"{x:499,y:727,t:1527030379004};\\\", \\\"{x:486,y:723,t:1527030379021};\\\", \\\"{x:478,y:730,t:1527030379381};\\\", \\\"{x:467,y:737,t:1527030379389};\\\", \\\"{x:436,y:754,t:1527030379405};\\\", \\\"{x:419,y:767,t:1527030379421};\\\", \\\"{x:401,y:780,t:1527030379438};\\\", \\\"{x:387,y:793,t:1527030379455};\\\", \\\"{x:373,y:803,t:1527030379471};\\\", \\\"{x:364,y:810,t:1527030379488};\\\", \\\"{x:359,y:813,t:1527030379505};\\\", \\\"{x:356,y:815,t:1527030379521};\\\", \\\"{x:354,y:816,t:1527030379538};\\\", \\\"{x:354,y:817,t:1527030379638};\\\" ] }, { \\\"rt\\\": 23755, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 317485, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:370,y:817,t:1527030384726};\\\", \\\"{x:444,y:822,t:1527030384742};\\\", \\\"{x:525,y:835,t:1527030384759};\\\", \\\"{x:614,y:846,t:1527030384776};\\\", \\\"{x:706,y:864,t:1527030384792};\\\", \\\"{x:808,y:876,t:1527030384808};\\\", \\\"{x:906,y:891,t:1527030384826};\\\", \\\"{x:1000,y:905,t:1527030384843};\\\", \\\"{x:1091,y:912,t:1527030384859};\\\", \\\"{x:1155,y:914,t:1527030384876};\\\", \\\"{x:1206,y:914,t:1527030384892};\\\", \\\"{x:1257,y:905,t:1527030384909};\\\", \\\"{x:1334,y:895,t:1527030384926};\\\", \\\"{x:1368,y:892,t:1527030384943};\\\", \\\"{x:1386,y:889,t:1527030384960};\\\", \\\"{x:1394,y:887,t:1527030384976};\\\", \\\"{x:1395,y:886,t:1527030384992};\\\", \\\"{x:1395,y:885,t:1527030385014};\\\", \\\"{x:1395,y:884,t:1527030385038};\\\", \\\"{x:1395,y:883,t:1527030385046};\\\", \\\"{x:1394,y:883,t:1527030385060};\\\", \\\"{x:1394,y:882,t:1527030385076};\\\", \\\"{x:1393,y:882,t:1527030385093};\\\", \\\"{x:1389,y:881,t:1527030385110};\\\", \\\"{x:1379,y:880,t:1527030385126};\\\", \\\"{x:1360,y:880,t:1527030385142};\\\", \\\"{x:1342,y:878,t:1527030385159};\\\", \\\"{x:1320,y:878,t:1527030385175};\\\", \\\"{x:1296,y:878,t:1527030385192};\\\", \\\"{x:1273,y:878,t:1527030385209};\\\", \\\"{x:1256,y:878,t:1527030385226};\\\", \\\"{x:1248,y:878,t:1527030385242};\\\", \\\"{x:1246,y:878,t:1527030385259};\\\", \\\"{x:1245,y:878,t:1527030385277};\\\", \\\"{x:1244,y:877,t:1527030385292};\\\", \\\"{x:1243,y:876,t:1527030385478};\\\", \\\"{x:1241,y:876,t:1527030385493};\\\", \\\"{x:1235,y:873,t:1527030385510};\\\", \\\"{x:1233,y:873,t:1527030385527};\\\", \\\"{x:1232,y:871,t:1527030385540};\\\", \\\"{x:1230,y:870,t:1527030385557};\\\", \\\"{x:1230,y:869,t:1527030385574};\\\", \\\"{x:1229,y:868,t:1527030385590};\\\", \\\"{x:1228,y:866,t:1527030385607};\\\", \\\"{x:1228,y:865,t:1527030385625};\\\", \\\"{x:1227,y:865,t:1527030385640};\\\", \\\"{x:1227,y:864,t:1527030385658};\\\", \\\"{x:1227,y:863,t:1527030385675};\\\", \\\"{x:1227,y:862,t:1527030385690};\\\", \\\"{x:1227,y:860,t:1527030385707};\\\", \\\"{x:1225,y:858,t:1527030385725};\\\", \\\"{x:1225,y:856,t:1527030385741};\\\", \\\"{x:1224,y:855,t:1527030385757};\\\", \\\"{x:1224,y:854,t:1527030385774};\\\", \\\"{x:1222,y:852,t:1527030385789};\\\", \\\"{x:1222,y:851,t:1527030385807};\\\", \\\"{x:1222,y:850,t:1527030385824};\\\", \\\"{x:1222,y:849,t:1527030385839};\\\", \\\"{x:1221,y:847,t:1527030385867};\\\", \\\"{x:1221,y:846,t:1527030385883};\\\", \\\"{x:1220,y:845,t:1527030385898};\\\", \\\"{x:1220,y:844,t:1527030385907};\\\", \\\"{x:1220,y:843,t:1527030385924};\\\", \\\"{x:1220,y:842,t:1527030385940};\\\", \\\"{x:1219,y:840,t:1527030385957};\\\", \\\"{x:1219,y:838,t:1527030385979};\\\", \\\"{x:1218,y:838,t:1527030385991};\\\", \\\"{x:1217,y:837,t:1527030386007};\\\", \\\"{x:1217,y:835,t:1527030386025};\\\", \\\"{x:1216,y:834,t:1527030386040};\\\", \\\"{x:1216,y:832,t:1527030386292};\\\", \\\"{x:1215,y:831,t:1527030386307};\\\", \\\"{x:1214,y:830,t:1527030386331};\\\", \\\"{x:1214,y:829,t:1527030386341};\\\", \\\"{x:1213,y:828,t:1527030386357};\\\", \\\"{x:1216,y:827,t:1527030395388};\\\", \\\"{x:1229,y:827,t:1527030395399};\\\", \\\"{x:1250,y:828,t:1527030395415};\\\", \\\"{x:1268,y:828,t:1527030395431};\\\", \\\"{x:1288,y:831,t:1527030395448};\\\", \\\"{x:1304,y:832,t:1527030395465};\\\", \\\"{x:1320,y:834,t:1527030395482};\\\", \\\"{x:1335,y:834,t:1527030395497};\\\", \\\"{x:1350,y:834,t:1527030395515};\\\", \\\"{x:1355,y:833,t:1527030395531};\\\", \\\"{x:1356,y:833,t:1527030395555};\\\", \\\"{x:1358,y:832,t:1527030395565};\\\", \\\"{x:1357,y:831,t:1527030395739};\\\", \\\"{x:1355,y:831,t:1527030396107};\\\", \\\"{x:1355,y:833,t:1527030396115};\\\", \\\"{x:1354,y:837,t:1527030396131};\\\", \\\"{x:1353,y:840,t:1527030396149};\\\", \\\"{x:1352,y:844,t:1527030396165};\\\", \\\"{x:1352,y:845,t:1527030396187};\\\", \\\"{x:1352,y:847,t:1527030396210};\\\", \\\"{x:1352,y:848,t:1527030396235};\\\", \\\"{x:1352,y:850,t:1527030396251};\\\", \\\"{x:1352,y:851,t:1527030396264};\\\", \\\"{x:1352,y:853,t:1527030396282};\\\", \\\"{x:1352,y:858,t:1527030396298};\\\", \\\"{x:1352,y:864,t:1527030396315};\\\", \\\"{x:1352,y:868,t:1527030396331};\\\", \\\"{x:1352,y:872,t:1527030396348};\\\", \\\"{x:1352,y:876,t:1527030396365};\\\", \\\"{x:1352,y:879,t:1527030396382};\\\", \\\"{x:1352,y:882,t:1527030396398};\\\", \\\"{x:1352,y:886,t:1527030396415};\\\", \\\"{x:1352,y:888,t:1527030396432};\\\", \\\"{x:1352,y:890,t:1527030396449};\\\", \\\"{x:1352,y:893,t:1527030396466};\\\", \\\"{x:1352,y:895,t:1527030396482};\\\", \\\"{x:1352,y:896,t:1527030396498};\\\", \\\"{x:1351,y:897,t:1527030396516};\\\", \\\"{x:1345,y:897,t:1527030397371};\\\", \\\"{x:1339,y:897,t:1527030397384};\\\", \\\"{x:1318,y:887,t:1527030397399};\\\", \\\"{x:1305,y:882,t:1527030397416};\\\", \\\"{x:1292,y:877,t:1527030397432};\\\", \\\"{x:1281,y:874,t:1527030397450};\\\", \\\"{x:1264,y:869,t:1527030397466};\\\", \\\"{x:1237,y:861,t:1527030397483};\\\", \\\"{x:1211,y:854,t:1527030397499};\\\", \\\"{x:1180,y:844,t:1527030397515};\\\", \\\"{x:1134,y:827,t:1527030397532};\\\", \\\"{x:1093,y:811,t:1527030397550};\\\", \\\"{x:1056,y:800,t:1527030397565};\\\", \\\"{x:1025,y:790,t:1527030397582};\\\", \\\"{x:1001,y:784,t:1527030397599};\\\", \\\"{x:978,y:780,t:1527030397615};\\\", \\\"{x:958,y:777,t:1527030397632};\\\", \\\"{x:949,y:775,t:1527030397649};\\\", \\\"{x:943,y:773,t:1527030397665};\\\", \\\"{x:942,y:773,t:1527030397738};\\\", \\\"{x:941,y:773,t:1527030397749};\\\", \\\"{x:937,y:773,t:1527030397765};\\\", \\\"{x:923,y:773,t:1527030397782};\\\", \\\"{x:904,y:773,t:1527030397799};\\\", \\\"{x:879,y:773,t:1527030397815};\\\", \\\"{x:851,y:771,t:1527030397833};\\\", \\\"{x:824,y:770,t:1527030397850};\\\", \\\"{x:802,y:766,t:1527030397865};\\\", \\\"{x:779,y:761,t:1527030397882};\\\", \\\"{x:768,y:759,t:1527030397899};\\\", \\\"{x:759,y:756,t:1527030397916};\\\", \\\"{x:752,y:752,t:1527030397933};\\\", \\\"{x:744,y:748,t:1527030397950};\\\", \\\"{x:733,y:743,t:1527030397966};\\\", \\\"{x:721,y:736,t:1527030397982};\\\", \\\"{x:705,y:727,t:1527030397999};\\\", \\\"{x:689,y:717,t:1527030398017};\\\", \\\"{x:670,y:705,t:1527030398033};\\\", \\\"{x:650,y:695,t:1527030398049};\\\", \\\"{x:616,y:681,t:1527030398066};\\\", \\\"{x:590,y:670,t:1527030398082};\\\", \\\"{x:563,y:661,t:1527030398099};\\\", \\\"{x:545,y:655,t:1527030398117};\\\", \\\"{x:526,y:650,t:1527030398134};\\\", \\\"{x:509,y:641,t:1527030398149};\\\", \\\"{x:490,y:634,t:1527030398167};\\\", \\\"{x:475,y:628,t:1527030398182};\\\", \\\"{x:459,y:625,t:1527030398200};\\\", \\\"{x:444,y:623,t:1527030398217};\\\", \\\"{x:425,y:617,t:1527030398234};\\\", \\\"{x:417,y:616,t:1527030398250};\\\", \\\"{x:411,y:614,t:1527030398267};\\\", \\\"{x:405,y:613,t:1527030398284};\\\", \\\"{x:400,y:612,t:1527030398300};\\\", \\\"{x:393,y:609,t:1527030398317};\\\", \\\"{x:391,y:608,t:1527030398335};\\\", \\\"{x:389,y:608,t:1527030398351};\\\", \\\"{x:388,y:608,t:1527030398367};\\\", \\\"{x:387,y:608,t:1527030398384};\\\", \\\"{x:385,y:608,t:1527030398401};\\\", \\\"{x:383,y:608,t:1527030398417};\\\", \\\"{x:379,y:611,t:1527030398434};\\\", \\\"{x:377,y:614,t:1527030398451};\\\", \\\"{x:376,y:616,t:1527030398467};\\\", \\\"{x:376,y:617,t:1527030398484};\\\", \\\"{x:375,y:619,t:1527030398501};\\\", \\\"{x:375,y:622,t:1527030398517};\\\", \\\"{x:376,y:626,t:1527030398534};\\\", \\\"{x:383,y:631,t:1527030398551};\\\", \\\"{x:402,y:634,t:1527030398567};\\\", \\\"{x:430,y:637,t:1527030398584};\\\", \\\"{x:454,y:637,t:1527030398601};\\\", \\\"{x:480,y:637,t:1527030398617};\\\", \\\"{x:548,y:629,t:1527030398634};\\\", \\\"{x:606,y:621,t:1527030398651};\\\", \\\"{x:673,y:611,t:1527030398668};\\\", \\\"{x:737,y:602,t:1527030398685};\\\", \\\"{x:791,y:595,t:1527030398702};\\\", \\\"{x:833,y:589,t:1527030398717};\\\", \\\"{x:853,y:586,t:1527030398734};\\\", \\\"{x:862,y:584,t:1527030398752};\\\", \\\"{x:864,y:583,t:1527030398769};\\\", \\\"{x:863,y:583,t:1527030398947};\\\", \\\"{x:862,y:583,t:1527030398955};\\\", \\\"{x:861,y:583,t:1527030398968};\\\", \\\"{x:859,y:583,t:1527030398985};\\\", \\\"{x:856,y:584,t:1527030399002};\\\", \\\"{x:850,y:584,t:1527030399019};\\\", \\\"{x:845,y:584,t:1527030399035};\\\", \\\"{x:838,y:584,t:1527030399051};\\\", \\\"{x:831,y:584,t:1527030399068};\\\", \\\"{x:828,y:585,t:1527030399085};\\\", \\\"{x:825,y:587,t:1527030399101};\\\", \\\"{x:822,y:588,t:1527030399118};\\\", \\\"{x:818,y:591,t:1527030399134};\\\", \\\"{x:814,y:595,t:1527030399151};\\\", \\\"{x:808,y:599,t:1527030399168};\\\", \\\"{x:803,y:603,t:1527030399184};\\\", \\\"{x:793,y:608,t:1527030399201};\\\", \\\"{x:779,y:613,t:1527030399218};\\\", \\\"{x:759,y:617,t:1527030399235};\\\", \\\"{x:730,y:620,t:1527030399251};\\\", \\\"{x:688,y:620,t:1527030399268};\\\", \\\"{x:636,y:623,t:1527030399286};\\\", \\\"{x:606,y:623,t:1527030399301};\\\", \\\"{x:587,y:623,t:1527030399318};\\\", \\\"{x:571,y:624,t:1527030399335};\\\", \\\"{x:560,y:625,t:1527030399351};\\\", \\\"{x:550,y:625,t:1527030399368};\\\", \\\"{x:542,y:625,t:1527030399385};\\\", \\\"{x:535,y:625,t:1527030399401};\\\", \\\"{x:534,y:625,t:1527030399418};\\\", \\\"{x:533,y:625,t:1527030399435};\\\", \\\"{x:531,y:625,t:1527030399452};\\\", \\\"{x:529,y:625,t:1527030399468};\\\", \\\"{x:526,y:625,t:1527030399485};\\\", \\\"{x:518,y:625,t:1527030399502};\\\", \\\"{x:513,y:626,t:1527030399518};\\\", \\\"{x:508,y:629,t:1527030399536};\\\", \\\"{x:501,y:632,t:1527030399551};\\\", \\\"{x:492,y:635,t:1527030399570};\\\", \\\"{x:477,y:639,t:1527030399585};\\\", \\\"{x:465,y:643,t:1527030399601};\\\", \\\"{x:440,y:649,t:1527030399617};\\\", \\\"{x:420,y:652,t:1527030399635};\\\", \\\"{x:408,y:653,t:1527030399652};\\\", \\\"{x:401,y:653,t:1527030399668};\\\", \\\"{x:399,y:653,t:1527030399685};\\\", \\\"{x:398,y:653,t:1527030399947};\\\", \\\"{x:396,y:653,t:1527030399962};\\\", \\\"{x:394,y:653,t:1527030399970};\\\", \\\"{x:392,y:653,t:1527030399986};\\\", \\\"{x:391,y:653,t:1527030400315};\\\", \\\"{x:390,y:648,t:1527030400364};\\\", \\\"{x:390,y:640,t:1527030400371};\\\", \\\"{x:389,y:636,t:1527030400385};\\\", \\\"{x:388,y:624,t:1527030400402};\\\", \\\"{x:386,y:614,t:1527030400419};\\\", \\\"{x:382,y:603,t:1527030400435};\\\", \\\"{x:381,y:600,t:1527030400452};\\\", \\\"{x:381,y:596,t:1527030400469};\\\", \\\"{x:381,y:593,t:1527030400485};\\\", \\\"{x:381,y:589,t:1527030400502};\\\", \\\"{x:381,y:587,t:1527030400520};\\\", \\\"{x:381,y:585,t:1527030400535};\\\", \\\"{x:384,y:582,t:1527030400553};\\\", \\\"{x:392,y:579,t:1527030400570};\\\", \\\"{x:394,y:578,t:1527030400586};\\\", \\\"{x:391,y:578,t:1527030400931};\\\", \\\"{x:387,y:578,t:1527030400939};\\\", \\\"{x:386,y:578,t:1527030400952};\\\", \\\"{x:381,y:580,t:1527030400967};\\\", \\\"{x:377,y:580,t:1527030400985};\\\", \\\"{x:373,y:581,t:1527030401002};\\\", \\\"{x:370,y:582,t:1527030401018};\\\", \\\"{x:360,y:583,t:1527030401034};\\\", \\\"{x:349,y:583,t:1527030401053};\\\", \\\"{x:330,y:584,t:1527030401069};\\\", \\\"{x:302,y:587,t:1527030401087};\\\", \\\"{x:277,y:587,t:1527030401103};\\\", \\\"{x:261,y:589,t:1527030401121};\\\", \\\"{x:250,y:591,t:1527030401136};\\\", \\\"{x:242,y:592,t:1527030401153};\\\", \\\"{x:235,y:593,t:1527030401169};\\\", \\\"{x:224,y:596,t:1527030401186};\\\", \\\"{x:220,y:597,t:1527030401203};\\\", \\\"{x:214,y:599,t:1527030401219};\\\", \\\"{x:211,y:601,t:1527030401237};\\\", \\\"{x:209,y:603,t:1527030401254};\\\", \\\"{x:209,y:605,t:1527030401270};\\\", \\\"{x:209,y:610,t:1527030401286};\\\", \\\"{x:209,y:613,t:1527030401304};\\\", \\\"{x:209,y:614,t:1527030401320};\\\", \\\"{x:209,y:615,t:1527030401336};\\\", \\\"{x:209,y:617,t:1527030401354};\\\", \\\"{x:210,y:617,t:1527030401403};\\\", \\\"{x:212,y:617,t:1527030401443};\\\", \\\"{x:216,y:617,t:1527030401453};\\\", \\\"{x:229,y:616,t:1527030401470};\\\", \\\"{x:245,y:611,t:1527030401486};\\\", \\\"{x:261,y:606,t:1527030401503};\\\", \\\"{x:277,y:598,t:1527030401520};\\\", \\\"{x:287,y:590,t:1527030401536};\\\", \\\"{x:287,y:587,t:1527030401553};\\\", \\\"{x:289,y:584,t:1527030401570};\\\", \\\"{x:275,y:575,t:1527030401587};\\\", \\\"{x:257,y:569,t:1527030401604};\\\", \\\"{x:240,y:567,t:1527030401620};\\\", \\\"{x:227,y:564,t:1527030401636};\\\", \\\"{x:222,y:564,t:1527030401653};\\\", \\\"{x:216,y:564,t:1527030401670};\\\", \\\"{x:208,y:564,t:1527030401687};\\\", \\\"{x:202,y:564,t:1527030401703};\\\", \\\"{x:196,y:563,t:1527030401720};\\\", \\\"{x:194,y:563,t:1527030401738};\\\", \\\"{x:193,y:563,t:1527030401851};\\\", \\\"{x:192,y:563,t:1527030401963};\\\", \\\"{x:190,y:563,t:1527030401973};\\\", \\\"{x:189,y:563,t:1527030401987};\\\", \\\"{x:186,y:563,t:1527030402004};\\\", \\\"{x:185,y:562,t:1527030402020};\\\", \\\"{x:181,y:561,t:1527030402037};\\\", \\\"{x:179,y:560,t:1527030402054};\\\", \\\"{x:178,y:560,t:1527030402483};\\\", \\\"{x:184,y:568,t:1527030402490};\\\", \\\"{x:201,y:587,t:1527030402506};\\\", \\\"{x:245,y:626,t:1527030402521};\\\", \\\"{x:300,y:661,t:1527030402538};\\\", \\\"{x:402,y:706,t:1527030402554};\\\", \\\"{x:466,y:727,t:1527030402571};\\\", \\\"{x:495,y:738,t:1527030402588};\\\", \\\"{x:517,y:744,t:1527030402604};\\\", \\\"{x:540,y:753,t:1527030402621};\\\", \\\"{x:562,y:761,t:1527030402637};\\\", \\\"{x:584,y:770,t:1527030402654};\\\", \\\"{x:593,y:772,t:1527030402671};\\\", \\\"{x:596,y:774,t:1527030402687};\\\", \\\"{x:596,y:770,t:1527030402730};\\\", \\\"{x:593,y:767,t:1527030402738};\\\", \\\"{x:584,y:760,t:1527030402754};\\\", \\\"{x:580,y:756,t:1527030402771};\\\", \\\"{x:580,y:753,t:1527030402789};\\\", \\\"{x:579,y:749,t:1527030402804};\\\", \\\"{x:578,y:748,t:1527030402850};\\\", \\\"{x:577,y:747,t:1527030402867};\\\", \\\"{x:575,y:747,t:1527030402883};\\\", \\\"{x:575,y:746,t:1527030402890};\\\", \\\"{x:574,y:746,t:1527030402906};\\\", \\\"{x:566,y:742,t:1527030402922};\\\", \\\"{x:552,y:737,t:1527030402939};\\\", \\\"{x:545,y:733,t:1527030402957};\\\", \\\"{x:544,y:732,t:1527030402972};\\\", \\\"{x:542,y:732,t:1527030403002};\\\", \\\"{x:541,y:731,t:1527030403010};\\\", \\\"{x:541,y:728,t:1527030403203};\\\", \\\"{x:540,y:726,t:1527030403210};\\\", \\\"{x:539,y:723,t:1527030403221};\\\", \\\"{x:538,y:721,t:1527030403238};\\\", \\\"{x:538,y:720,t:1527030403254};\\\", \\\"{x:538,y:717,t:1527030403271};\\\", \\\"{x:538,y:715,t:1527030403289};\\\" ] }, { \\\"rt\\\": 59849, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 378611, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-06 PM-11 AM-05 PM-04 PM-Z -Z -U -U -F -F -F -U -Z -Z -Z -U -U -O -H -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:715,t:1527030408379};\\\", \\\"{x:548,y:718,t:1527030408392};\\\", \\\"{x:558,y:723,t:1527030408409};\\\", \\\"{x:568,y:725,t:1527030408427};\\\", \\\"{x:574,y:728,t:1527030408442};\\\", \\\"{x:599,y:738,t:1527030408458};\\\", \\\"{x:618,y:745,t:1527030408475};\\\", \\\"{x:645,y:752,t:1527030408493};\\\", \\\"{x:679,y:762,t:1527030408508};\\\", \\\"{x:720,y:772,t:1527030408525};\\\", \\\"{x:757,y:783,t:1527030408542};\\\", \\\"{x:784,y:789,t:1527030408558};\\\", \\\"{x:807,y:794,t:1527030408576};\\\", \\\"{x:825,y:795,t:1527030408592};\\\", \\\"{x:833,y:797,t:1527030408609};\\\", \\\"{x:834,y:797,t:1527030408625};\\\", \\\"{x:834,y:796,t:1527030410083};\\\", \\\"{x:834,y:795,t:1527030410115};\\\", \\\"{x:834,y:794,t:1527030410251};\\\", \\\"{x:833,y:792,t:1527030410483};\\\", \\\"{x:839,y:791,t:1527030411443};\\\", \\\"{x:855,y:794,t:1527030411450};\\\", \\\"{x:876,y:796,t:1527030411464};\\\", \\\"{x:926,y:803,t:1527030411481};\\\", \\\"{x:1004,y:813,t:1527030411497};\\\", \\\"{x:1109,y:829,t:1527030411513};\\\", \\\"{x:1288,y:856,t:1527030411531};\\\", \\\"{x:1407,y:873,t:1527030411547};\\\", \\\"{x:1524,y:891,t:1527030411564};\\\", \\\"{x:1624,y:903,t:1527030411580};\\\", \\\"{x:1690,y:912,t:1527030411597};\\\", \\\"{x:1725,y:917,t:1527030411613};\\\", \\\"{x:1736,y:918,t:1527030411630};\\\", \\\"{x:1738,y:918,t:1527030411647};\\\", \\\"{x:1737,y:918,t:1527030411859};\\\", \\\"{x:1735,y:918,t:1527030411867};\\\", \\\"{x:1733,y:917,t:1527030411881};\\\", \\\"{x:1727,y:915,t:1527030411898};\\\", \\\"{x:1709,y:913,t:1527030411916};\\\", \\\"{x:1686,y:911,t:1527030411931};\\\", \\\"{x:1639,y:911,t:1527030411947};\\\", \\\"{x:1581,y:905,t:1527030411965};\\\", \\\"{x:1511,y:903,t:1527030411982};\\\", \\\"{x:1436,y:903,t:1527030411997};\\\", \\\"{x:1363,y:903,t:1527030412014};\\\", \\\"{x:1302,y:903,t:1527030412031};\\\", \\\"{x:1240,y:914,t:1527030412047};\\\", \\\"{x:1197,y:929,t:1527030412065};\\\", \\\"{x:1166,y:944,t:1527030412082};\\\", \\\"{x:1144,y:957,t:1527030412098};\\\", \\\"{x:1131,y:965,t:1527030412115};\\\", \\\"{x:1128,y:967,t:1527030412131};\\\", \\\"{x:1127,y:968,t:1527030412148};\\\", \\\"{x:1131,y:966,t:1527030412355};\\\", \\\"{x:1148,y:961,t:1527030412365};\\\", \\\"{x:1182,y:955,t:1527030412381};\\\", \\\"{x:1233,y:955,t:1527030412398};\\\", \\\"{x:1311,y:953,t:1527030412415};\\\", \\\"{x:1397,y:953,t:1527030412431};\\\", \\\"{x:1506,y:970,t:1527030412449};\\\", \\\"{x:1605,y:984,t:1527030412465};\\\", \\\"{x:1689,y:997,t:1527030412481};\\\", \\\"{x:1764,y:1009,t:1527030412498};\\\", \\\"{x:1779,y:1009,t:1527030412515};\\\", \\\"{x:1784,y:1009,t:1527030412531};\\\", \\\"{x:1786,y:1008,t:1527030412548};\\\", \\\"{x:1786,y:1007,t:1527030412570};\\\", \\\"{x:1785,y:1007,t:1527030412586};\\\", \\\"{x:1783,y:1006,t:1527030412603};\\\", \\\"{x:1782,y:1005,t:1527030412618};\\\", \\\"{x:1781,y:1005,t:1527030412634};\\\", \\\"{x:1781,y:1004,t:1527030412650};\\\", \\\"{x:1780,y:1004,t:1527030412665};\\\", \\\"{x:1774,y:1000,t:1527030412682};\\\", \\\"{x:1767,y:996,t:1527030412698};\\\", \\\"{x:1762,y:993,t:1527030412715};\\\", \\\"{x:1757,y:990,t:1527030412732};\\\", \\\"{x:1753,y:988,t:1527030412748};\\\", \\\"{x:1748,y:984,t:1527030412765};\\\", \\\"{x:1744,y:981,t:1527030412782};\\\", \\\"{x:1743,y:980,t:1527030412797};\\\", \\\"{x:1742,y:978,t:1527030412814};\\\", \\\"{x:1741,y:978,t:1527030412832};\\\", \\\"{x:1740,y:977,t:1527030412848};\\\", \\\"{x:1739,y:975,t:1527030412865};\\\", \\\"{x:1724,y:943,t:1527030412882};\\\", \\\"{x:1701,y:898,t:1527030412898};\\\", \\\"{x:1687,y:850,t:1527030412915};\\\", \\\"{x:1676,y:796,t:1527030412932};\\\", \\\"{x:1663,y:744,t:1527030412949};\\\", \\\"{x:1657,y:709,t:1527030412965};\\\", \\\"{x:1653,y:680,t:1527030412982};\\\", \\\"{x:1650,y:654,t:1527030412998};\\\", \\\"{x:1645,y:626,t:1527030413015};\\\", \\\"{x:1642,y:599,t:1527030413032};\\\", \\\"{x:1638,y:573,t:1527030413049};\\\", \\\"{x:1628,y:540,t:1527030413065};\\\", \\\"{x:1602,y:470,t:1527030413082};\\\", \\\"{x:1588,y:433,t:1527030413099};\\\", \\\"{x:1576,y:405,t:1527030413116};\\\", \\\"{x:1565,y:382,t:1527030413132};\\\", \\\"{x:1555,y:363,t:1527030413149};\\\", \\\"{x:1547,y:350,t:1527030413166};\\\", \\\"{x:1539,y:335,t:1527030413182};\\\", \\\"{x:1537,y:331,t:1527030413199};\\\", \\\"{x:1535,y:327,t:1527030413216};\\\", \\\"{x:1534,y:327,t:1527030413323};\\\", \\\"{x:1531,y:330,t:1527030413333};\\\", \\\"{x:1523,y:347,t:1527030413349};\\\", \\\"{x:1516,y:364,t:1527030413366};\\\", \\\"{x:1508,y:386,t:1527030413384};\\\", \\\"{x:1497,y:407,t:1527030413399};\\\", \\\"{x:1487,y:427,t:1527030413416};\\\", \\\"{x:1477,y:446,t:1527030413433};\\\", \\\"{x:1468,y:463,t:1527030413449};\\\", \\\"{x:1457,y:488,t:1527030413466};\\\", \\\"{x:1450,y:508,t:1527030413483};\\\", \\\"{x:1444,y:522,t:1527030413499};\\\", \\\"{x:1443,y:534,t:1527030413517};\\\", \\\"{x:1443,y:541,t:1527030413534};\\\", \\\"{x:1442,y:548,t:1527030413549};\\\", \\\"{x:1440,y:561,t:1527030413566};\\\", \\\"{x:1439,y:579,t:1527030413584};\\\", \\\"{x:1434,y:605,t:1527030413600};\\\", \\\"{x:1432,y:633,t:1527030413616};\\\", \\\"{x:1421,y:668,t:1527030413633};\\\", \\\"{x:1403,y:725,t:1527030413650};\\\", \\\"{x:1384,y:771,t:1527030413666};\\\", \\\"{x:1368,y:817,t:1527030413683};\\\", \\\"{x:1345,y:865,t:1527030413701};\\\", \\\"{x:1330,y:903,t:1527030413716};\\\", \\\"{x:1317,y:931,t:1527030413734};\\\", \\\"{x:1307,y:953,t:1527030413750};\\\", \\\"{x:1301,y:967,t:1527030413766};\\\", \\\"{x:1296,y:974,t:1527030413783};\\\", \\\"{x:1295,y:977,t:1527030413800};\\\", \\\"{x:1295,y:978,t:1527030413867};\\\", \\\"{x:1293,y:978,t:1527030413883};\\\", \\\"{x:1284,y:967,t:1527030413901};\\\", \\\"{x:1280,y:962,t:1527030413917};\\\", \\\"{x:1280,y:961,t:1527030413933};\\\", \\\"{x:1279,y:961,t:1527030413955};\\\", \\\"{x:1279,y:958,t:1527030413995};\\\", \\\"{x:1278,y:953,t:1527030414003};\\\", \\\"{x:1273,y:945,t:1527030414017};\\\", \\\"{x:1268,y:933,t:1527030414034};\\\", \\\"{x:1256,y:912,t:1527030414051};\\\", \\\"{x:1247,y:899,t:1527030414067};\\\", \\\"{x:1243,y:892,t:1527030414083};\\\", \\\"{x:1241,y:887,t:1527030414101};\\\", \\\"{x:1241,y:886,t:1527030414882};\\\", \\\"{x:1241,y:884,t:1527030414890};\\\", \\\"{x:1241,y:881,t:1527030414901};\\\", \\\"{x:1242,y:878,t:1527030414918};\\\", \\\"{x:1244,y:876,t:1527030414936};\\\", \\\"{x:1248,y:871,t:1527030414951};\\\", \\\"{x:1251,y:869,t:1527030414968};\\\", \\\"{x:1255,y:865,t:1527030414985};\\\", \\\"{x:1257,y:862,t:1527030415001};\\\", \\\"{x:1261,y:858,t:1527030415018};\\\", \\\"{x:1264,y:856,t:1527030415035};\\\", \\\"{x:1266,y:855,t:1527030415051};\\\", \\\"{x:1270,y:852,t:1527030415068};\\\", \\\"{x:1274,y:851,t:1527030415085};\\\", \\\"{x:1281,y:847,t:1527030415102};\\\", \\\"{x:1288,y:843,t:1527030415118};\\\", \\\"{x:1297,y:838,t:1527030415135};\\\", \\\"{x:1311,y:829,t:1527030415152};\\\", \\\"{x:1321,y:821,t:1527030415169};\\\", \\\"{x:1335,y:812,t:1527030415185};\\\", \\\"{x:1355,y:801,t:1527030415202};\\\", \\\"{x:1367,y:794,t:1527030415218};\\\", \\\"{x:1373,y:788,t:1527030415235};\\\", \\\"{x:1377,y:784,t:1527030415252};\\\", \\\"{x:1381,y:781,t:1527030415268};\\\", \\\"{x:1387,y:776,t:1527030415285};\\\", \\\"{x:1392,y:772,t:1527030415302};\\\", \\\"{x:1401,y:771,t:1527030415319};\\\", \\\"{x:1413,y:771,t:1527030415335};\\\", \\\"{x:1424,y:771,t:1527030415352};\\\", \\\"{x:1431,y:771,t:1527030415368};\\\", \\\"{x:1440,y:772,t:1527030415385};\\\", \\\"{x:1455,y:777,t:1527030415402};\\\", \\\"{x:1468,y:782,t:1527030415419};\\\", \\\"{x:1483,y:789,t:1527030415435};\\\", \\\"{x:1496,y:794,t:1527030415453};\\\", \\\"{x:1511,y:800,t:1527030415469};\\\", \\\"{x:1526,y:805,t:1527030415486};\\\", \\\"{x:1538,y:809,t:1527030415502};\\\", \\\"{x:1548,y:812,t:1527030415520};\\\", \\\"{x:1555,y:814,t:1527030415535};\\\", \\\"{x:1563,y:816,t:1527030415553};\\\", \\\"{x:1570,y:819,t:1527030415569};\\\", \\\"{x:1581,y:824,t:1527030415585};\\\", \\\"{x:1599,y:832,t:1527030415602};\\\", \\\"{x:1611,y:839,t:1527030415620};\\\", \\\"{x:1624,y:846,t:1527030415637};\\\", \\\"{x:1633,y:853,t:1527030415653};\\\", \\\"{x:1647,y:863,t:1527030415669};\\\", \\\"{x:1658,y:873,t:1527030415687};\\\", \\\"{x:1669,y:885,t:1527030415702};\\\", \\\"{x:1673,y:892,t:1527030415720};\\\", \\\"{x:1675,y:898,t:1527030415737};\\\", \\\"{x:1677,y:905,t:1527030415752};\\\", \\\"{x:1678,y:911,t:1527030415769};\\\", \\\"{x:1682,y:919,t:1527030415786};\\\", \\\"{x:1684,y:925,t:1527030415803};\\\", \\\"{x:1685,y:930,t:1527030415819};\\\", \\\"{x:1687,y:935,t:1527030415836};\\\", \\\"{x:1687,y:938,t:1527030415853};\\\", \\\"{x:1687,y:941,t:1527030415869};\\\", \\\"{x:1688,y:943,t:1527030415886};\\\", \\\"{x:1688,y:946,t:1527030415903};\\\", \\\"{x:1689,y:949,t:1527030415918};\\\", \\\"{x:1689,y:951,t:1527030415936};\\\", \\\"{x:1689,y:954,t:1527030415953};\\\", \\\"{x:1689,y:956,t:1527030415969};\\\", \\\"{x:1689,y:959,t:1527030415986};\\\", \\\"{x:1689,y:961,t:1527030416003};\\\", \\\"{x:1689,y:962,t:1527030416020};\\\", \\\"{x:1689,y:964,t:1527030416037};\\\", \\\"{x:1689,y:965,t:1527030416054};\\\", \\\"{x:1689,y:967,t:1527030416070};\\\", \\\"{x:1689,y:969,t:1527030416086};\\\", \\\"{x:1688,y:971,t:1527030416103};\\\", \\\"{x:1688,y:972,t:1527030416120};\\\", \\\"{x:1686,y:974,t:1527030416136};\\\", \\\"{x:1685,y:975,t:1527030416154};\\\", \\\"{x:1682,y:977,t:1527030416170};\\\", \\\"{x:1681,y:978,t:1527030416186};\\\", \\\"{x:1680,y:978,t:1527030416203};\\\", \\\"{x:1679,y:978,t:1527030416220};\\\", \\\"{x:1676,y:980,t:1527030416236};\\\", \\\"{x:1674,y:981,t:1527030416259};\\\", \\\"{x:1673,y:981,t:1527030416271};\\\", \\\"{x:1671,y:981,t:1527030416286};\\\", \\\"{x:1669,y:983,t:1527030416303};\\\", \\\"{x:1667,y:983,t:1527030416320};\\\", \\\"{x:1666,y:983,t:1527030416338};\\\", \\\"{x:1665,y:983,t:1527030416354};\\\", \\\"{x:1663,y:983,t:1527030416371};\\\", \\\"{x:1660,y:983,t:1527030416387};\\\", \\\"{x:1658,y:983,t:1527030416403};\\\", \\\"{x:1654,y:983,t:1527030416421};\\\", \\\"{x:1650,y:983,t:1527030416438};\\\", \\\"{x:1646,y:983,t:1527030416453};\\\", \\\"{x:1642,y:982,t:1527030416471};\\\", \\\"{x:1638,y:981,t:1527030416487};\\\", \\\"{x:1636,y:980,t:1527030416503};\\\", \\\"{x:1635,y:980,t:1527030416521};\\\", \\\"{x:1632,y:979,t:1527030416537};\\\", \\\"{x:1631,y:979,t:1527030416619};\\\", \\\"{x:1630,y:978,t:1527030416634};\\\", \\\"{x:1629,y:977,t:1527030416642};\\\", \\\"{x:1627,y:975,t:1527030416659};\\\", \\\"{x:1625,y:974,t:1527030416670};\\\", \\\"{x:1623,y:972,t:1527030416687};\\\", \\\"{x:1619,y:969,t:1527030416704};\\\", \\\"{x:1613,y:965,t:1527030416721};\\\", \\\"{x:1610,y:962,t:1527030416737};\\\", \\\"{x:1605,y:959,t:1527030416754};\\\", \\\"{x:1605,y:958,t:1527030416793};\\\", \\\"{x:1604,y:958,t:1527030416963};\\\", \\\"{x:1603,y:957,t:1527030416979};\\\", \\\"{x:1602,y:955,t:1527030416995};\\\", \\\"{x:1600,y:954,t:1527030417004};\\\", \\\"{x:1600,y:953,t:1527030417021};\\\", \\\"{x:1599,y:951,t:1527030417050};\\\", \\\"{x:1598,y:950,t:1527030417082};\\\", \\\"{x:1598,y:949,t:1527030417130};\\\", \\\"{x:1598,y:948,t:1527030417154};\\\", \\\"{x:1598,y:947,t:1527030417171};\\\", \\\"{x:1597,y:945,t:1527030417189};\\\", \\\"{x:1597,y:943,t:1527030417227};\\\", \\\"{x:1597,y:942,t:1527030417250};\\\", \\\"{x:1596,y:940,t:1527030417266};\\\", \\\"{x:1596,y:939,t:1527030417282};\\\", \\\"{x:1595,y:938,t:1527030417298};\\\", \\\"{x:1595,y:937,t:1527030417306};\\\", \\\"{x:1594,y:935,t:1527030417321};\\\", \\\"{x:1592,y:933,t:1527030417338};\\\", \\\"{x:1590,y:930,t:1527030417355};\\\", \\\"{x:1590,y:929,t:1527030417371};\\\", \\\"{x:1589,y:925,t:1527030417388};\\\", \\\"{x:1589,y:920,t:1527030417405};\\\", \\\"{x:1589,y:915,t:1527030417421};\\\", \\\"{x:1588,y:905,t:1527030417437};\\\", \\\"{x:1586,y:896,t:1527030417455};\\\", \\\"{x:1585,y:888,t:1527030417471};\\\", \\\"{x:1584,y:880,t:1527030417488};\\\", \\\"{x:1583,y:873,t:1527030417505};\\\", \\\"{x:1580,y:866,t:1527030417521};\\\", \\\"{x:1576,y:861,t:1527030417538};\\\", \\\"{x:1570,y:857,t:1527030417555};\\\", \\\"{x:1560,y:852,t:1527030417572};\\\", \\\"{x:1551,y:850,t:1527030417588};\\\", \\\"{x:1539,y:847,t:1527030417605};\\\", \\\"{x:1524,y:847,t:1527030417621};\\\", \\\"{x:1500,y:847,t:1527030417637};\\\", \\\"{x:1470,y:847,t:1527030417654};\\\", \\\"{x:1427,y:847,t:1527030417672};\\\", \\\"{x:1373,y:842,t:1527030417687};\\\", \\\"{x:1329,y:839,t:1527030417705};\\\", \\\"{x:1291,y:839,t:1527030417721};\\\", \\\"{x:1276,y:839,t:1527030417739};\\\", \\\"{x:1268,y:839,t:1527030417755};\\\", \\\"{x:1263,y:839,t:1527030417772};\\\", \\\"{x:1260,y:839,t:1527030417789};\\\", \\\"{x:1257,y:839,t:1527030417804};\\\", \\\"{x:1254,y:840,t:1527030417821};\\\", \\\"{x:1252,y:840,t:1527030417839};\\\", \\\"{x:1250,y:841,t:1527030417855};\\\", \\\"{x:1248,y:843,t:1527030417871};\\\", \\\"{x:1246,y:844,t:1527030417889};\\\", \\\"{x:1243,y:845,t:1527030417905};\\\", \\\"{x:1242,y:847,t:1527030417922};\\\", \\\"{x:1240,y:848,t:1527030417939};\\\", \\\"{x:1240,y:849,t:1527030417956};\\\", \\\"{x:1240,y:850,t:1527030417994};\\\", \\\"{x:1240,y:851,t:1527030418009};\\\", \\\"{x:1241,y:852,t:1527030418022};\\\", \\\"{x:1242,y:852,t:1527030418039};\\\", \\\"{x:1243,y:852,t:1527030418056};\\\", \\\"{x:1245,y:852,t:1527030418072};\\\", \\\"{x:1247,y:852,t:1527030418089};\\\", \\\"{x:1253,y:852,t:1527030418106};\\\", \\\"{x:1257,y:852,t:1527030418122};\\\", \\\"{x:1259,y:852,t:1527030418139};\\\", \\\"{x:1261,y:852,t:1527030418156};\\\", \\\"{x:1263,y:851,t:1527030418172};\\\", \\\"{x:1263,y:852,t:1527030418467};\\\", \\\"{x:1262,y:853,t:1527030418474};\\\", \\\"{x:1262,y:854,t:1527030418489};\\\", \\\"{x:1261,y:855,t:1527030418546};\\\", \\\"{x:1259,y:855,t:1527030418570};\\\", \\\"{x:1257,y:855,t:1527030418586};\\\", \\\"{x:1256,y:854,t:1527030418609};\\\", \\\"{x:1255,y:853,t:1527030418875};\\\", \\\"{x:1255,y:852,t:1527030418916};\\\", \\\"{x:1256,y:852,t:1527030418939};\\\", \\\"{x:1257,y:851,t:1527030418946};\\\", \\\"{x:1261,y:851,t:1527030418958};\\\", \\\"{x:1270,y:851,t:1527030418974};\\\", \\\"{x:1285,y:851,t:1527030418990};\\\", \\\"{x:1298,y:851,t:1527030419007};\\\", \\\"{x:1313,y:852,t:1527030419024};\\\", \\\"{x:1327,y:855,t:1527030419041};\\\", \\\"{x:1334,y:858,t:1527030419058};\\\", \\\"{x:1336,y:858,t:1527030419075};\\\", \\\"{x:1337,y:858,t:1527030419090};\\\", \\\"{x:1336,y:859,t:1527030419203};\\\", \\\"{x:1335,y:861,t:1527030419227};\\\", \\\"{x:1335,y:864,t:1527030419242};\\\", \\\"{x:1335,y:865,t:1527030419257};\\\", \\\"{x:1335,y:872,t:1527030419274};\\\", \\\"{x:1335,y:875,t:1527030419292};\\\", \\\"{x:1335,y:876,t:1527030419308};\\\", \\\"{x:1335,y:878,t:1527030419324};\\\", \\\"{x:1336,y:879,t:1527030419341};\\\", \\\"{x:1336,y:881,t:1527030419370};\\\", \\\"{x:1337,y:883,t:1527030419386};\\\", \\\"{x:1337,y:884,t:1527030419394};\\\", \\\"{x:1338,y:885,t:1527030419407};\\\", \\\"{x:1339,y:886,t:1527030419425};\\\", \\\"{x:1340,y:887,t:1527030419441};\\\", \\\"{x:1341,y:889,t:1527030419457};\\\", \\\"{x:1343,y:890,t:1527030419482};\\\", \\\"{x:1343,y:891,t:1527030419498};\\\", \\\"{x:1344,y:892,t:1527030419516};\\\", \\\"{x:1346,y:892,t:1527030419524};\\\", \\\"{x:1349,y:892,t:1527030419541};\\\", \\\"{x:1350,y:894,t:1527030419558};\\\", \\\"{x:1351,y:894,t:1527030419574};\\\", \\\"{x:1352,y:894,t:1527030419591};\\\", \\\"{x:1355,y:894,t:1527030419609};\\\", \\\"{x:1359,y:895,t:1527030419624};\\\", \\\"{x:1363,y:895,t:1527030419642};\\\", \\\"{x:1370,y:895,t:1527030419657};\\\", \\\"{x:1373,y:895,t:1527030419674};\\\", \\\"{x:1378,y:894,t:1527030419691};\\\", \\\"{x:1382,y:894,t:1527030419708};\\\", \\\"{x:1388,y:894,t:1527030419725};\\\", \\\"{x:1393,y:893,t:1527030419742};\\\", \\\"{x:1398,y:892,t:1527030419758};\\\", \\\"{x:1400,y:892,t:1527030419775};\\\", \\\"{x:1405,y:890,t:1527030419791};\\\", \\\"{x:1409,y:889,t:1527030419809};\\\", \\\"{x:1416,y:886,t:1527030419825};\\\", \\\"{x:1422,y:885,t:1527030419841};\\\", \\\"{x:1429,y:880,t:1527030419858};\\\", \\\"{x:1435,y:877,t:1527030419875};\\\", \\\"{x:1439,y:874,t:1527030419891};\\\", \\\"{x:1441,y:872,t:1527030419908};\\\", \\\"{x:1444,y:869,t:1527030419925};\\\", \\\"{x:1446,y:866,t:1527030419941};\\\", \\\"{x:1450,y:861,t:1527030419958};\\\", \\\"{x:1455,y:858,t:1527030419975};\\\", \\\"{x:1459,y:855,t:1527030419992};\\\", \\\"{x:1463,y:852,t:1527030420008};\\\", \\\"{x:1464,y:851,t:1527030420026};\\\", \\\"{x:1465,y:850,t:1527030420042};\\\", \\\"{x:1465,y:848,t:1527030420059};\\\", \\\"{x:1465,y:846,t:1527030420155};\\\", \\\"{x:1466,y:845,t:1527030420162};\\\", \\\"{x:1467,y:844,t:1527030420176};\\\", \\\"{x:1469,y:843,t:1527030420193};\\\", \\\"{x:1470,y:841,t:1527030420209};\\\", \\\"{x:1471,y:841,t:1527030420226};\\\", \\\"{x:1472,y:840,t:1527030420242};\\\", \\\"{x:1473,y:838,t:1527030420259};\\\", \\\"{x:1475,y:837,t:1527030420275};\\\", \\\"{x:1475,y:836,t:1527030420292};\\\", \\\"{x:1476,y:835,t:1527030420309};\\\", \\\"{x:1477,y:834,t:1527030420326};\\\", \\\"{x:1477,y:833,t:1527030420359};\\\", \\\"{x:1478,y:832,t:1527030420419};\\\", \\\"{x:1478,y:831,t:1527030420458};\\\", \\\"{x:1479,y:830,t:1527030420476};\\\", \\\"{x:1480,y:828,t:1527030420492};\\\", \\\"{x:1481,y:827,t:1527030420509};\\\", \\\"{x:1483,y:825,t:1527030420538};\\\", \\\"{x:1481,y:822,t:1527030423300};\\\", \\\"{x:1475,y:821,t:1527030423314};\\\", \\\"{x:1457,y:821,t:1527030423330};\\\", \\\"{x:1398,y:815,t:1527030423346};\\\", \\\"{x:1300,y:799,t:1527030423364};\\\", \\\"{x:1178,y:778,t:1527030423380};\\\", \\\"{x:1017,y:734,t:1527030423397};\\\", \\\"{x:843,y:703,t:1527030423414};\\\", \\\"{x:670,y:667,t:1527030423431};\\\", \\\"{x:513,y:629,t:1527030423448};\\\", \\\"{x:377,y:608,t:1527030423464};\\\", \\\"{x:263,y:573,t:1527030423481};\\\", \\\"{x:215,y:568,t:1527030423504};\\\", \\\"{x:211,y:568,t:1527030423520};\\\", \\\"{x:210,y:568,t:1527030423537};\\\", \\\"{x:211,y:568,t:1527030423617};\\\", \\\"{x:212,y:568,t:1527030423634};\\\", \\\"{x:216,y:568,t:1527030423641};\\\", \\\"{x:221,y:570,t:1527030423654};\\\", \\\"{x:243,y:571,t:1527030423670};\\\", \\\"{x:280,y:574,t:1527030423688};\\\", \\\"{x:318,y:577,t:1527030423705};\\\", \\\"{x:347,y:577,t:1527030423721};\\\", \\\"{x:382,y:577,t:1527030423738};\\\", \\\"{x:404,y:572,t:1527030423755};\\\", \\\"{x:420,y:570,t:1527030423772};\\\", \\\"{x:435,y:569,t:1527030423787};\\\", \\\"{x:443,y:567,t:1527030423804};\\\", \\\"{x:445,y:567,t:1527030423821};\\\", \\\"{x:446,y:567,t:1527030423850};\\\", \\\"{x:446,y:568,t:1527030423890};\\\", \\\"{x:445,y:568,t:1527030423904};\\\", \\\"{x:439,y:569,t:1527030423921};\\\", \\\"{x:429,y:569,t:1527030423937};\\\", \\\"{x:411,y:571,t:1527030423954};\\\", \\\"{x:405,y:573,t:1527030423970};\\\", \\\"{x:404,y:574,t:1527030423988};\\\", \\\"{x:404,y:578,t:1527030424005};\\\", \\\"{x:405,y:584,t:1527030424021};\\\", \\\"{x:412,y:591,t:1527030424038};\\\", \\\"{x:420,y:594,t:1527030424055};\\\", \\\"{x:432,y:599,t:1527030424071};\\\", \\\"{x:454,y:604,t:1527030424088};\\\", \\\"{x:479,y:605,t:1527030424105};\\\", \\\"{x:503,y:605,t:1527030424122};\\\", \\\"{x:543,y:598,t:1527030424139};\\\", \\\"{x:566,y:586,t:1527030424154};\\\", \\\"{x:585,y:576,t:1527030424171};\\\", \\\"{x:592,y:569,t:1527030424189};\\\", \\\"{x:597,y:563,t:1527030424205};\\\", \\\"{x:599,y:560,t:1527030424221};\\\", \\\"{x:600,y:558,t:1527030424238};\\\", \\\"{x:601,y:556,t:1527030424255};\\\", \\\"{x:601,y:555,t:1527030424273};\\\", \\\"{x:602,y:555,t:1527030424288};\\\", \\\"{x:602,y:553,t:1527030424306};\\\", \\\"{x:602,y:554,t:1527030424442};\\\", \\\"{x:602,y:555,t:1527030424459};\\\", \\\"{x:602,y:556,t:1527030424514};\\\", \\\"{x:603,y:557,t:1527030424522};\\\", \\\"{x:604,y:558,t:1527030424539};\\\", \\\"{x:605,y:559,t:1527030424594};\\\", \\\"{x:606,y:562,t:1527030424607};\\\", \\\"{x:607,y:567,t:1527030424623};\\\", \\\"{x:609,y:573,t:1527030424641};\\\", \\\"{x:610,y:579,t:1527030424657};\\\", \\\"{x:612,y:582,t:1527030424672};\\\", \\\"{x:612,y:584,t:1527030424688};\\\", \\\"{x:613,y:585,t:1527030424706};\\\", \\\"{x:622,y:585,t:1527030425241};\\\", \\\"{x:643,y:586,t:1527030425255};\\\", \\\"{x:736,y:603,t:1527030425274};\\\", \\\"{x:852,y:618,t:1527030425290};\\\", \\\"{x:993,y:639,t:1527030425305};\\\", \\\"{x:1213,y:671,t:1527030425323};\\\", \\\"{x:1359,y:708,t:1527030425340};\\\", \\\"{x:1475,y:739,t:1527030425355};\\\", \\\"{x:1565,y:769,t:1527030425373};\\\", \\\"{x:1611,y:787,t:1527030425390};\\\", \\\"{x:1625,y:796,t:1527030425405};\\\", \\\"{x:1626,y:798,t:1527030425423};\\\", \\\"{x:1625,y:800,t:1527030425440};\\\", \\\"{x:1619,y:802,t:1527030425456};\\\", \\\"{x:1608,y:803,t:1527030425473};\\\", \\\"{x:1601,y:804,t:1527030425489};\\\", \\\"{x:1595,y:806,t:1527030425507};\\\", \\\"{x:1593,y:808,t:1527030425522};\\\", \\\"{x:1590,y:809,t:1527030425540};\\\", \\\"{x:1587,y:809,t:1527030425557};\\\", \\\"{x:1585,y:810,t:1527030425573};\\\", \\\"{x:1582,y:810,t:1527030425589};\\\", \\\"{x:1579,y:811,t:1527030425607};\\\", \\\"{x:1575,y:811,t:1527030425622};\\\", \\\"{x:1570,y:814,t:1527030425640};\\\", \\\"{x:1568,y:815,t:1527030425657};\\\", \\\"{x:1563,y:819,t:1527030425673};\\\", \\\"{x:1561,y:821,t:1527030425689};\\\", \\\"{x:1561,y:823,t:1527030425706};\\\", \\\"{x:1560,y:823,t:1527030425754};\\\", \\\"{x:1558,y:823,t:1527030425779};\\\", \\\"{x:1557,y:823,t:1527030425790};\\\", \\\"{x:1548,y:820,t:1527030425807};\\\", \\\"{x:1532,y:815,t:1527030425823};\\\", \\\"{x:1511,y:809,t:1527030425840};\\\", \\\"{x:1496,y:805,t:1527030425857};\\\", \\\"{x:1479,y:800,t:1527030425873};\\\", \\\"{x:1470,y:799,t:1527030425890};\\\", \\\"{x:1461,y:798,t:1527030425907};\\\", \\\"{x:1458,y:797,t:1527030425923};\\\", \\\"{x:1457,y:797,t:1527030425940};\\\", \\\"{x:1457,y:796,t:1527030426003};\\\", \\\"{x:1456,y:795,t:1527030426010};\\\", \\\"{x:1453,y:793,t:1527030426023};\\\", \\\"{x:1445,y:788,t:1527030426040};\\\", \\\"{x:1434,y:782,t:1527030426057};\\\", \\\"{x:1425,y:777,t:1527030426074};\\\", \\\"{x:1412,y:772,t:1527030426089};\\\", \\\"{x:1398,y:768,t:1527030426107};\\\", \\\"{x:1393,y:767,t:1527030426124};\\\", \\\"{x:1388,y:764,t:1527030426140};\\\", \\\"{x:1385,y:764,t:1527030426157};\\\", \\\"{x:1384,y:763,t:1527030426174};\\\", \\\"{x:1382,y:762,t:1527030426190};\\\", \\\"{x:1381,y:762,t:1527030426206};\\\", \\\"{x:1382,y:763,t:1527030428107};\\\", \\\"{x:1386,y:765,t:1527030428125};\\\", \\\"{x:1389,y:766,t:1527030428143};\\\", \\\"{x:1392,y:768,t:1527030428158};\\\", \\\"{x:1393,y:768,t:1527030428175};\\\", \\\"{x:1394,y:768,t:1527030428194};\\\", \\\"{x:1395,y:769,t:1527030428210};\\\", \\\"{x:1396,y:769,t:1527030428226};\\\", \\\"{x:1399,y:771,t:1527030428242};\\\", \\\"{x:1402,y:771,t:1527030428258};\\\", \\\"{x:1407,y:771,t:1527030428275};\\\", \\\"{x:1412,y:771,t:1527030428292};\\\", \\\"{x:1414,y:771,t:1527030428308};\\\", \\\"{x:1417,y:771,t:1527030428325};\\\", \\\"{x:1418,y:771,t:1527030428342};\\\", \\\"{x:1420,y:770,t:1527030428358};\\\", \\\"{x:1421,y:770,t:1527030428375};\\\", \\\"{x:1423,y:769,t:1527030428392};\\\", \\\"{x:1428,y:767,t:1527030428409};\\\", \\\"{x:1434,y:767,t:1527030428425};\\\", \\\"{x:1446,y:760,t:1527030428442};\\\", \\\"{x:1450,y:759,t:1527030428458};\\\", \\\"{x:1453,y:758,t:1527030428475};\\\", \\\"{x:1454,y:757,t:1527030428492};\\\", \\\"{x:1455,y:756,t:1527030428509};\\\", \\\"{x:1455,y:755,t:1527030428619};\\\", \\\"{x:1453,y:754,t:1527030428634};\\\", \\\"{x:1452,y:754,t:1527030428650};\\\", \\\"{x:1451,y:754,t:1527030428659};\\\", \\\"{x:1450,y:754,t:1527030428785};\\\", \\\"{x:1450,y:755,t:1527030428801};\\\", \\\"{x:1450,y:756,t:1527030428809};\\\", \\\"{x:1450,y:757,t:1527030428834};\\\", \\\"{x:1450,y:758,t:1527030428841};\\\", \\\"{x:1450,y:759,t:1527030428858};\\\", \\\"{x:1449,y:759,t:1527030430435};\\\", \\\"{x:1448,y:759,t:1527030430444};\\\", \\\"{x:1447,y:759,t:1527030430491};\\\", \\\"{x:1446,y:759,t:1527030430499};\\\", \\\"{x:1445,y:759,t:1527030430510};\\\", \\\"{x:1441,y:757,t:1527030430528};\\\", \\\"{x:1437,y:756,t:1527030430543};\\\", \\\"{x:1432,y:755,t:1527030430560};\\\", \\\"{x:1427,y:755,t:1527030430577};\\\", \\\"{x:1423,y:755,t:1527030430593};\\\", \\\"{x:1411,y:756,t:1527030430610};\\\", \\\"{x:1407,y:756,t:1527030430626};\\\", \\\"{x:1403,y:756,t:1527030430643};\\\", \\\"{x:1401,y:757,t:1527030430661};\\\", \\\"{x:1397,y:757,t:1527030430677};\\\", \\\"{x:1394,y:759,t:1527030430693};\\\", \\\"{x:1391,y:759,t:1527030430710};\\\", \\\"{x:1389,y:759,t:1527030430727};\\\", \\\"{x:1389,y:760,t:1527030430769};\\\", \\\"{x:1388,y:760,t:1527030430778};\\\", \\\"{x:1387,y:760,t:1527030430810};\\\", \\\"{x:1386,y:762,t:1527030430827};\\\", \\\"{x:1384,y:762,t:1527030430844};\\\", \\\"{x:1382,y:763,t:1527030430860};\\\", \\\"{x:1379,y:765,t:1527030430876};\\\", \\\"{x:1376,y:766,t:1527030430894};\\\", \\\"{x:1373,y:767,t:1527030430910};\\\", \\\"{x:1372,y:767,t:1527030430927};\\\", \\\"{x:1370,y:767,t:1527030430944};\\\", \\\"{x:1371,y:767,t:1527030433243};\\\", \\\"{x:1372,y:767,t:1527030433250};\\\", \\\"{x:1373,y:767,t:1527030433262};\\\", \\\"{x:1374,y:766,t:1527030433279};\\\", \\\"{x:1374,y:765,t:1527030433506};\\\", \\\"{x:1374,y:764,t:1527030433513};\\\", \\\"{x:1374,y:763,t:1527030433528};\\\", \\\"{x:1374,y:762,t:1527030433546};\\\", \\\"{x:1374,y:761,t:1527030433561};\\\", \\\"{x:1376,y:760,t:1527030433787};\\\", \\\"{x:1377,y:760,t:1527030433796};\\\", \\\"{x:1381,y:760,t:1527030433812};\\\", \\\"{x:1383,y:761,t:1527030433829};\\\", \\\"{x:1384,y:761,t:1527030436530};\\\", \\\"{x:1386,y:761,t:1527030436548};\\\", \\\"{x:1386,y:763,t:1527030436883};\\\", \\\"{x:1388,y:766,t:1527030436907};\\\", \\\"{x:1390,y:771,t:1527030436917};\\\", \\\"{x:1393,y:781,t:1527030436931};\\\", \\\"{x:1397,y:797,t:1527030436948};\\\", \\\"{x:1406,y:814,t:1527030436965};\\\", \\\"{x:1415,y:831,t:1527030436981};\\\", \\\"{x:1429,y:843,t:1527030436998};\\\", \\\"{x:1443,y:853,t:1527030437015};\\\", \\\"{x:1459,y:858,t:1527030437031};\\\", \\\"{x:1476,y:863,t:1527030437047};\\\", \\\"{x:1495,y:867,t:1527030437065};\\\", \\\"{x:1512,y:869,t:1527030437081};\\\", \\\"{x:1531,y:873,t:1527030437098};\\\", \\\"{x:1539,y:873,t:1527030437114};\\\", \\\"{x:1543,y:873,t:1527030437131};\\\", \\\"{x:1544,y:873,t:1527030437148};\\\", \\\"{x:1545,y:873,t:1527030437165};\\\", \\\"{x:1546,y:873,t:1527030437181};\\\", \\\"{x:1548,y:873,t:1527030437198};\\\", \\\"{x:1548,y:872,t:1527030437215};\\\", \\\"{x:1552,y:869,t:1527030437231};\\\", \\\"{x:1555,y:866,t:1527030437248};\\\", \\\"{x:1559,y:864,t:1527030437265};\\\", \\\"{x:1561,y:862,t:1527030437282};\\\", \\\"{x:1567,y:859,t:1527030437298};\\\", \\\"{x:1572,y:857,t:1527030437315};\\\", \\\"{x:1575,y:856,t:1527030437331};\\\", \\\"{x:1579,y:855,t:1527030437348};\\\", \\\"{x:1584,y:854,t:1527030437366};\\\", \\\"{x:1592,y:853,t:1527030437382};\\\", \\\"{x:1598,y:853,t:1527030437399};\\\", \\\"{x:1603,y:851,t:1527030437416};\\\", \\\"{x:1608,y:850,t:1527030437432};\\\", \\\"{x:1611,y:849,t:1527030437449};\\\", \\\"{x:1614,y:849,t:1527030437465};\\\", \\\"{x:1616,y:849,t:1527030437483};\\\", \\\"{x:1616,y:848,t:1527030437643};\\\", \\\"{x:1614,y:846,t:1527030437658};\\\", \\\"{x:1610,y:845,t:1527030437666};\\\", \\\"{x:1600,y:840,t:1527030437682};\\\", \\\"{x:1584,y:836,t:1527030437698};\\\", \\\"{x:1560,y:830,t:1527030437716};\\\", \\\"{x:1526,y:829,t:1527030437733};\\\", \\\"{x:1502,y:829,t:1527030437749};\\\", \\\"{x:1484,y:829,t:1527030437766};\\\", \\\"{x:1469,y:827,t:1527030437784};\\\", \\\"{x:1456,y:827,t:1527030437799};\\\", \\\"{x:1450,y:827,t:1527030437815};\\\", \\\"{x:1449,y:826,t:1527030437832};\\\", \\\"{x:1449,y:827,t:1527030438025};\\\", \\\"{x:1451,y:828,t:1527030438034};\\\", \\\"{x:1453,y:828,t:1527030438049};\\\", \\\"{x:1455,y:830,t:1527030438066};\\\", \\\"{x:1457,y:830,t:1527030438082};\\\", \\\"{x:1458,y:831,t:1527030438171};\\\", \\\"{x:1458,y:833,t:1527030438195};\\\", \\\"{x:1459,y:833,t:1527030438210};\\\", \\\"{x:1455,y:834,t:1527030438523};\\\", \\\"{x:1449,y:837,t:1527030438533};\\\", \\\"{x:1440,y:844,t:1527030438549};\\\", \\\"{x:1426,y:850,t:1527030438566};\\\", \\\"{x:1414,y:855,t:1527030438582};\\\", \\\"{x:1406,y:859,t:1527030438599};\\\", \\\"{x:1402,y:860,t:1527030438616};\\\", \\\"{x:1399,y:860,t:1527030438632};\\\", \\\"{x:1398,y:861,t:1527030438650};\\\", \\\"{x:1398,y:862,t:1527030438691};\\\", \\\"{x:1398,y:863,t:1527030438699};\\\", \\\"{x:1396,y:866,t:1527030438716};\\\", \\\"{x:1395,y:868,t:1527030438732};\\\", \\\"{x:1395,y:870,t:1527030438750};\\\", \\\"{x:1395,y:871,t:1527030438767};\\\", \\\"{x:1394,y:873,t:1527030438783};\\\", \\\"{x:1393,y:874,t:1527030438800};\\\", \\\"{x:1392,y:874,t:1527030438817};\\\", \\\"{x:1391,y:875,t:1527030438833};\\\", \\\"{x:1389,y:876,t:1527030438849};\\\", \\\"{x:1383,y:878,t:1527030438866};\\\", \\\"{x:1377,y:881,t:1527030438882};\\\", \\\"{x:1371,y:882,t:1527030438900};\\\", \\\"{x:1368,y:883,t:1527030438917};\\\", \\\"{x:1364,y:885,t:1527030438934};\\\", \\\"{x:1363,y:885,t:1527030438950};\\\", \\\"{x:1361,y:885,t:1527030439179};\\\", \\\"{x:1360,y:885,t:1527030439211};\\\", \\\"{x:1359,y:885,t:1527030439242};\\\", \\\"{x:1357,y:885,t:1527030439250};\\\", \\\"{x:1353,y:885,t:1527030439266};\\\", \\\"{x:1349,y:885,t:1527030439284};\\\", \\\"{x:1346,y:885,t:1527030439299};\\\", \\\"{x:1345,y:885,t:1527030439317};\\\", \\\"{x:1344,y:885,t:1527030439699};\\\", \\\"{x:1343,y:885,t:1527030439716};\\\", \\\"{x:1343,y:886,t:1527030439733};\\\", \\\"{x:1343,y:888,t:1527030439750};\\\", \\\"{x:1343,y:891,t:1527030439767};\\\", \\\"{x:1343,y:893,t:1527030439784};\\\", \\\"{x:1343,y:892,t:1527030440011};\\\", \\\"{x:1343,y:889,t:1527030440018};\\\", \\\"{x:1345,y:887,t:1527030440033};\\\", \\\"{x:1348,y:874,t:1527030440050};\\\", \\\"{x:1348,y:860,t:1527030440067};\\\", \\\"{x:1348,y:850,t:1527030440083};\\\", \\\"{x:1351,y:841,t:1527030440100};\\\", \\\"{x:1354,y:832,t:1527030440117};\\\", \\\"{x:1356,y:824,t:1527030440132};\\\", \\\"{x:1356,y:819,t:1527030440150};\\\", \\\"{x:1360,y:814,t:1527030440167};\\\", \\\"{x:1360,y:812,t:1527030440183};\\\", \\\"{x:1361,y:808,t:1527030440199};\\\", \\\"{x:1363,y:806,t:1527030440217};\\\", \\\"{x:1364,y:804,t:1527030440233};\\\", \\\"{x:1366,y:802,t:1527030440250};\\\", \\\"{x:1367,y:802,t:1527030440267};\\\", \\\"{x:1370,y:802,t:1527030440283};\\\", \\\"{x:1374,y:802,t:1527030440300};\\\", \\\"{x:1380,y:802,t:1527030440317};\\\", \\\"{x:1389,y:804,t:1527030440334};\\\", \\\"{x:1400,y:809,t:1527030440350};\\\", \\\"{x:1412,y:813,t:1527030440367};\\\", \\\"{x:1421,y:817,t:1527030440385};\\\", \\\"{x:1430,y:821,t:1527030440400};\\\", \\\"{x:1434,y:823,t:1527030440417};\\\", \\\"{x:1436,y:824,t:1527030440434};\\\", \\\"{x:1438,y:824,t:1527030440506};\\\", \\\"{x:1439,y:825,t:1527030440546};\\\", \\\"{x:1441,y:825,t:1527030440570};\\\", \\\"{x:1443,y:825,t:1527030440586};\\\", \\\"{x:1444,y:824,t:1527030440600};\\\", \\\"{x:1446,y:822,t:1527030440618};\\\", \\\"{x:1449,y:818,t:1527030440634};\\\", \\\"{x:1452,y:815,t:1527030440650};\\\", \\\"{x:1453,y:815,t:1527030440668};\\\", \\\"{x:1454,y:815,t:1527030440685};\\\", \\\"{x:1455,y:815,t:1527030440700};\\\", \\\"{x:1458,y:815,t:1527030440717};\\\", \\\"{x:1460,y:815,t:1527030440735};\\\", \\\"{x:1462,y:815,t:1527030440750};\\\", \\\"{x:1463,y:815,t:1527030440770};\\\", \\\"{x:1464,y:815,t:1527030440784};\\\", \\\"{x:1465,y:818,t:1527030440859};\\\", \\\"{x:1466,y:820,t:1527030440874};\\\", \\\"{x:1466,y:821,t:1527030440885};\\\", \\\"{x:1467,y:822,t:1527030440902};\\\", \\\"{x:1468,y:823,t:1527030440918};\\\", \\\"{x:1468,y:824,t:1527030440934};\\\", \\\"{x:1469,y:824,t:1527030441035};\\\", \\\"{x:1469,y:825,t:1527030441099};\\\", \\\"{x:1470,y:825,t:1527030441106};\\\", \\\"{x:1471,y:825,t:1527030441122};\\\", \\\"{x:1471,y:826,t:1527030441134};\\\", \\\"{x:1472,y:826,t:1527030441153};\\\", \\\"{x:1474,y:827,t:1527030441167};\\\", \\\"{x:1475,y:828,t:1527030441201};\\\", \\\"{x:1476,y:828,t:1527030441257};\\\", \\\"{x:1477,y:828,t:1527030441284};\\\", \\\"{x:1479,y:829,t:1527030441306};\\\", \\\"{x:1480,y:829,t:1527030441353};\\\", \\\"{x:1479,y:829,t:1527030442274};\\\", \\\"{x:1479,y:827,t:1527030442285};\\\", \\\"{x:1477,y:825,t:1527030442302};\\\", \\\"{x:1477,y:823,t:1527030442318};\\\", \\\"{x:1477,y:821,t:1527030442335};\\\", \\\"{x:1477,y:819,t:1527030442352};\\\", \\\"{x:1477,y:818,t:1527030442368};\\\", \\\"{x:1477,y:817,t:1527030442419};\\\", \\\"{x:1477,y:816,t:1527030442435};\\\", \\\"{x:1477,y:815,t:1527030442452};\\\", \\\"{x:1477,y:814,t:1527030442474};\\\", \\\"{x:1477,y:813,t:1527030442485};\\\", \\\"{x:1478,y:809,t:1527030442502};\\\", \\\"{x:1478,y:805,t:1527030442518};\\\", \\\"{x:1478,y:802,t:1527030442535};\\\", \\\"{x:1478,y:798,t:1527030442553};\\\", \\\"{x:1478,y:797,t:1527030442568};\\\", \\\"{x:1479,y:794,t:1527030442585};\\\", \\\"{x:1479,y:793,t:1527030442603};\\\", \\\"{x:1479,y:789,t:1527030442618};\\\", \\\"{x:1479,y:787,t:1527030442636};\\\", \\\"{x:1480,y:785,t:1527030442653};\\\", \\\"{x:1481,y:783,t:1527030442668};\\\", \\\"{x:1481,y:781,t:1527030442685};\\\", \\\"{x:1483,y:777,t:1527030442702};\\\", \\\"{x:1483,y:774,t:1527030442719};\\\", \\\"{x:1483,y:770,t:1527030442735};\\\", \\\"{x:1483,y:767,t:1527030442752};\\\", \\\"{x:1480,y:759,t:1527030442769};\\\", \\\"{x:1475,y:750,t:1527030442785};\\\", \\\"{x:1468,y:732,t:1527030442802};\\\", \\\"{x:1462,y:719,t:1527030442819};\\\", \\\"{x:1452,y:706,t:1527030442835};\\\", \\\"{x:1447,y:696,t:1527030442852};\\\", \\\"{x:1442,y:685,t:1527030442869};\\\", \\\"{x:1439,y:678,t:1527030442885};\\\", \\\"{x:1436,y:659,t:1527030442902};\\\", \\\"{x:1429,y:647,t:1527030442919};\\\", \\\"{x:1427,y:641,t:1527030442935};\\\", \\\"{x:1425,y:637,t:1527030442952};\\\", \\\"{x:1425,y:635,t:1527030442969};\\\", \\\"{x:1424,y:635,t:1527030442985};\\\", \\\"{x:1424,y:634,t:1527030443003};\\\", \\\"{x:1423,y:634,t:1527030443130};\\\", \\\"{x:1421,y:634,t:1527030443138};\\\", \\\"{x:1417,y:635,t:1527030443153};\\\", \\\"{x:1408,y:637,t:1527030443169};\\\", \\\"{x:1386,y:642,t:1527030443186};\\\", \\\"{x:1369,y:645,t:1527030443203};\\\", \\\"{x:1352,y:646,t:1527030443220};\\\", \\\"{x:1340,y:647,t:1527030443236};\\\", \\\"{x:1332,y:649,t:1527030443253};\\\", \\\"{x:1327,y:651,t:1527030443270};\\\", \\\"{x:1324,y:652,t:1527030443287};\\\", \\\"{x:1322,y:653,t:1527030443302};\\\", \\\"{x:1321,y:654,t:1527030443320};\\\", \\\"{x:1320,y:654,t:1527030443338};\\\", \\\"{x:1317,y:654,t:1527030443435};\\\", \\\"{x:1314,y:652,t:1527030443442};\\\", \\\"{x:1311,y:647,t:1527030443453};\\\", \\\"{x:1302,y:637,t:1527030443469};\\\", \\\"{x:1294,y:631,t:1527030443486};\\\", \\\"{x:1290,y:627,t:1527030443503};\\\", \\\"{x:1288,y:625,t:1527030443520};\\\", \\\"{x:1288,y:624,t:1527030443579};\\\", \\\"{x:1289,y:622,t:1527030443594};\\\", \\\"{x:1290,y:621,t:1527030443618};\\\", \\\"{x:1292,y:621,t:1527030443626};\\\", \\\"{x:1294,y:621,t:1527030443637};\\\", \\\"{x:1298,y:621,t:1527030443654};\\\", \\\"{x:1302,y:621,t:1527030443669};\\\", \\\"{x:1303,y:621,t:1527030443686};\\\", \\\"{x:1304,y:621,t:1527030443704};\\\", \\\"{x:1305,y:620,t:1527030443721};\\\", \\\"{x:1306,y:620,t:1527030444177};\\\", \\\"{x:1308,y:620,t:1527030444282};\\\", \\\"{x:1309,y:620,t:1527030444297};\\\", \\\"{x:1309,y:621,t:1527030444305};\\\", \\\"{x:1309,y:622,t:1527030444321};\\\", \\\"{x:1309,y:623,t:1527030444346};\\\", \\\"{x:1310,y:625,t:1527030444386};\\\", \\\"{x:1311,y:625,t:1527030444587};\\\", \\\"{x:1312,y:626,t:1527030444603};\\\", \\\"{x:1315,y:626,t:1527030451232};\\\", \\\"{x:1321,y:626,t:1527030451243};\\\", \\\"{x:1335,y:626,t:1527030451256};\\\", \\\"{x:1351,y:623,t:1527030451273};\\\", \\\"{x:1375,y:618,t:1527030451290};\\\", \\\"{x:1396,y:611,t:1527030451306};\\\", \\\"{x:1412,y:607,t:1527030451323};\\\", \\\"{x:1425,y:603,t:1527030451339};\\\", \\\"{x:1432,y:599,t:1527030451356};\\\", \\\"{x:1433,y:599,t:1527030451373};\\\", \\\"{x:1434,y:598,t:1527030451390};\\\", \\\"{x:1433,y:596,t:1527030451544};\\\", \\\"{x:1431,y:596,t:1527030451560};\\\", \\\"{x:1430,y:596,t:1527030451584};\\\", \\\"{x:1428,y:595,t:1527030451600};\\\", \\\"{x:1426,y:594,t:1527030451624};\\\", \\\"{x:1424,y:592,t:1527030451655};\\\", \\\"{x:1423,y:591,t:1527030451674};\\\", \\\"{x:1422,y:588,t:1527030451689};\\\", \\\"{x:1420,y:586,t:1527030451707};\\\", \\\"{x:1419,y:585,t:1527030451727};\\\", \\\"{x:1419,y:584,t:1527030451783};\\\", \\\"{x:1419,y:583,t:1527030451823};\\\", \\\"{x:1419,y:582,t:1527030451863};\\\", \\\"{x:1419,y:581,t:1527030451879};\\\", \\\"{x:1419,y:580,t:1527030451891};\\\", \\\"{x:1419,y:579,t:1527030451911};\\\", \\\"{x:1419,y:578,t:1527030451923};\\\", \\\"{x:1420,y:577,t:1527030451940};\\\", \\\"{x:1420,y:573,t:1527030451956};\\\", \\\"{x:1420,y:570,t:1527030451973};\\\", \\\"{x:1420,y:567,t:1527030451991};\\\", \\\"{x:1420,y:566,t:1527030452006};\\\", \\\"{x:1420,y:565,t:1527030452665};\\\", \\\"{x:1419,y:564,t:1527030452674};\\\", \\\"{x:1417,y:563,t:1527030452690};\\\", \\\"{x:1416,y:563,t:1527030452707};\\\", \\\"{x:1414,y:563,t:1527030454344};\\\", \\\"{x:1414,y:562,t:1527030454359};\\\", \\\"{x:1413,y:562,t:1527030454416};\\\", \\\"{x:1412,y:562,t:1527030454456};\\\", \\\"{x:1411,y:561,t:1527030454480};\\\", \\\"{x:1410,y:560,t:1527030454504};\\\", \\\"{x:1409,y:560,t:1527030454514};\\\", \\\"{x:1408,y:560,t:1527030454526};\\\", \\\"{x:1406,y:559,t:1527030454541};\\\", \\\"{x:1401,y:556,t:1527030454558};\\\", \\\"{x:1398,y:556,t:1527030454575};\\\", \\\"{x:1397,y:555,t:1527030454592};\\\", \\\"{x:1397,y:553,t:1527030454608};\\\", \\\"{x:1394,y:548,t:1527030454625};\\\", \\\"{x:1393,y:545,t:1527030454642};\\\", \\\"{x:1390,y:540,t:1527030454658};\\\", \\\"{x:1389,y:534,t:1527030454675};\\\", \\\"{x:1389,y:530,t:1527030454693};\\\", \\\"{x:1388,y:524,t:1527030454709};\\\", \\\"{x:1386,y:519,t:1527030454726};\\\", \\\"{x:1385,y:511,t:1527030454742};\\\", \\\"{x:1384,y:506,t:1527030454758};\\\", \\\"{x:1380,y:495,t:1527030454775};\\\", \\\"{x:1378,y:489,t:1527030454793};\\\", \\\"{x:1376,y:484,t:1527030454809};\\\", \\\"{x:1374,y:481,t:1527030454826};\\\", \\\"{x:1372,y:478,t:1527030454843};\\\", \\\"{x:1369,y:475,t:1527030454859};\\\", \\\"{x:1367,y:472,t:1527030454876};\\\", \\\"{x:1365,y:469,t:1527030454893};\\\", \\\"{x:1362,y:465,t:1527030454908};\\\", \\\"{x:1359,y:462,t:1527030454926};\\\", \\\"{x:1355,y:458,t:1527030454942};\\\", \\\"{x:1351,y:456,t:1527030454959};\\\", \\\"{x:1344,y:453,t:1527030454976};\\\", \\\"{x:1339,y:452,t:1527030454993};\\\", \\\"{x:1331,y:452,t:1527030455008};\\\", \\\"{x:1324,y:452,t:1527030455025};\\\", \\\"{x:1308,y:452,t:1527030455043};\\\", \\\"{x:1282,y:458,t:1527030455058};\\\", \\\"{x:1238,y:470,t:1527030455075};\\\", \\\"{x:1184,y:483,t:1527030455093};\\\", \\\"{x:1131,y:488,t:1527030455110};\\\", \\\"{x:1091,y:495,t:1527030455126};\\\", \\\"{x:1065,y:499,t:1527030455142};\\\", \\\"{x:1034,y:508,t:1527030455159};\\\", \\\"{x:1020,y:515,t:1527030455176};\\\", \\\"{x:1009,y:523,t:1527030455192};\\\", \\\"{x:1003,y:532,t:1527030455210};\\\", \\\"{x:994,y:544,t:1527030455225};\\\", \\\"{x:987,y:557,t:1527030455242};\\\", \\\"{x:981,y:575,t:1527030455259};\\\", \\\"{x:977,y:589,t:1527030455275};\\\", \\\"{x:974,y:603,t:1527030455292};\\\", \\\"{x:972,y:617,t:1527030455310};\\\", \\\"{x:970,y:635,t:1527030455325};\\\", \\\"{x:970,y:648,t:1527030455343};\\\", \\\"{x:973,y:658,t:1527030455359};\\\", \\\"{x:977,y:662,t:1527030455375};\\\", \\\"{x:981,y:665,t:1527030455393};\\\", \\\"{x:985,y:667,t:1527030455410};\\\", \\\"{x:989,y:669,t:1527030455426};\\\", \\\"{x:991,y:669,t:1527030455442};\\\", \\\"{x:992,y:669,t:1527030455460};\\\", \\\"{x:995,y:669,t:1527030455476};\\\", \\\"{x:999,y:669,t:1527030455492};\\\", \\\"{x:1005,y:666,t:1527030455509};\\\", \\\"{x:1011,y:664,t:1527030455526};\\\", \\\"{x:1019,y:660,t:1527030455542};\\\", \\\"{x:1039,y:653,t:1527030455559};\\\", \\\"{x:1056,y:649,t:1527030455576};\\\", \\\"{x:1077,y:642,t:1527030455593};\\\", \\\"{x:1100,y:636,t:1527030455609};\\\", \\\"{x:1125,y:629,t:1527030455626};\\\", \\\"{x:1151,y:622,t:1527030455642};\\\", \\\"{x:1181,y:610,t:1527030455659};\\\", \\\"{x:1209,y:598,t:1527030455676};\\\", \\\"{x:1238,y:586,t:1527030455692};\\\", \\\"{x:1273,y:570,t:1527030455710};\\\", \\\"{x:1313,y:555,t:1527030455727};\\\", \\\"{x:1354,y:539,t:1527030455743};\\\", \\\"{x:1405,y:518,t:1527030455759};\\\", \\\"{x:1430,y:507,t:1527030455777};\\\", \\\"{x:1445,y:500,t:1527030455793};\\\", \\\"{x:1452,y:495,t:1527030455810};\\\", \\\"{x:1454,y:493,t:1527030455827};\\\", \\\"{x:1454,y:491,t:1527030455920};\\\", \\\"{x:1454,y:490,t:1527030455928};\\\", \\\"{x:1453,y:487,t:1527030455944};\\\", \\\"{x:1449,y:481,t:1527030455960};\\\", \\\"{x:1447,y:478,t:1527030455977};\\\", \\\"{x:1445,y:476,t:1527030455993};\\\", \\\"{x:1444,y:475,t:1527030456010};\\\", \\\"{x:1443,y:473,t:1527030456027};\\\", \\\"{x:1440,y:472,t:1527030456043};\\\", \\\"{x:1439,y:471,t:1527030456060};\\\", \\\"{x:1436,y:470,t:1527030456077};\\\", \\\"{x:1433,y:468,t:1527030456094};\\\", \\\"{x:1429,y:466,t:1527030456110};\\\", \\\"{x:1427,y:465,t:1527030456127};\\\", \\\"{x:1417,y:461,t:1527030456144};\\\", \\\"{x:1414,y:460,t:1527030456159};\\\", \\\"{x:1411,y:458,t:1527030456177};\\\", \\\"{x:1410,y:458,t:1527030456193};\\\", \\\"{x:1409,y:458,t:1527030456224};\\\", \\\"{x:1407,y:458,t:1527030456232};\\\", \\\"{x:1406,y:458,t:1527030456244};\\\", \\\"{x:1401,y:460,t:1527030456261};\\\", \\\"{x:1397,y:465,t:1527030456277};\\\", \\\"{x:1393,y:469,t:1527030456294};\\\", \\\"{x:1390,y:474,t:1527030456310};\\\", \\\"{x:1389,y:477,t:1527030456327};\\\", \\\"{x:1387,y:481,t:1527030456343};\\\", \\\"{x:1387,y:483,t:1527030456360};\\\", \\\"{x:1386,y:484,t:1527030456377};\\\", \\\"{x:1385,y:485,t:1527030456394};\\\", \\\"{x:1384,y:487,t:1527030456415};\\\", \\\"{x:1383,y:488,t:1527030456448};\\\", \\\"{x:1382,y:488,t:1527030456460};\\\", \\\"{x:1379,y:488,t:1527030456477};\\\", \\\"{x:1377,y:490,t:1527030456494};\\\", \\\"{x:1375,y:490,t:1527030456511};\\\", \\\"{x:1371,y:490,t:1527030456527};\\\", \\\"{x:1363,y:491,t:1527030456544};\\\", \\\"{x:1357,y:491,t:1527030456561};\\\", \\\"{x:1353,y:491,t:1527030456577};\\\", \\\"{x:1350,y:491,t:1527030456594};\\\", \\\"{x:1347,y:491,t:1527030456611};\\\", \\\"{x:1346,y:492,t:1527030456639};\\\", \\\"{x:1345,y:492,t:1527030456720};\\\", \\\"{x:1343,y:492,t:1527030456726};\\\", \\\"{x:1338,y:494,t:1527030456743};\\\", \\\"{x:1329,y:498,t:1527030456761};\\\", \\\"{x:1319,y:501,t:1527030456777};\\\", \\\"{x:1307,y:503,t:1527030456793};\\\", \\\"{x:1302,y:504,t:1527030456811};\\\", \\\"{x:1300,y:505,t:1527030456827};\\\", \\\"{x:1302,y:504,t:1527030456983};\\\", \\\"{x:1304,y:503,t:1527030456994};\\\", \\\"{x:1312,y:499,t:1527030457011};\\\", \\\"{x:1316,y:498,t:1527030457028};\\\", \\\"{x:1321,y:495,t:1527030457045};\\\", \\\"{x:1322,y:495,t:1527030457061};\\\", \\\"{x:1323,y:495,t:1527030457143};\\\", \\\"{x:1324,y:495,t:1527030457160};\\\", \\\"{x:1326,y:495,t:1527030457178};\\\", \\\"{x:1327,y:495,t:1527030457223};\\\", \\\"{x:1329,y:495,t:1527030457535};\\\", \\\"{x:1331,y:495,t:1527030457544};\\\", \\\"{x:1332,y:495,t:1527030457561};\\\", \\\"{x:1333,y:495,t:1527030457578};\\\", \\\"{x:1334,y:495,t:1527030457594};\\\", \\\"{x:1334,y:496,t:1527030461559};\\\", \\\"{x:1333,y:500,t:1527030461567};\\\", \\\"{x:1326,y:505,t:1527030461581};\\\", \\\"{x:1302,y:516,t:1527030461597};\\\", \\\"{x:1271,y:528,t:1527030461614};\\\", \\\"{x:1216,y:545,t:1527030461631};\\\", \\\"{x:1154,y:564,t:1527030461647};\\\", \\\"{x:1057,y:601,t:1527030461664};\\\", \\\"{x:990,y:633,t:1527030461681};\\\", \\\"{x:920,y:670,t:1527030461697};\\\", \\\"{x:846,y:714,t:1527030461714};\\\", \\\"{x:773,y:753,t:1527030461731};\\\", \\\"{x:705,y:790,t:1527030461748};\\\", \\\"{x:652,y:817,t:1527030461763};\\\", \\\"{x:612,y:835,t:1527030461780};\\\", \\\"{x:588,y:847,t:1527030461798};\\\", \\\"{x:570,y:855,t:1527030461814};\\\", \\\"{x:557,y:860,t:1527030461831};\\\", \\\"{x:553,y:860,t:1527030461847};\\\", \\\"{x:552,y:861,t:1527030461864};\\\", \\\"{x:552,y:860,t:1527030462071};\\\", \\\"{x:552,y:858,t:1527030462081};\\\", \\\"{x:551,y:853,t:1527030462098};\\\", \\\"{x:551,y:847,t:1527030462114};\\\", \\\"{x:551,y:838,t:1527030462131};\\\", \\\"{x:551,y:828,t:1527030462148};\\\", \\\"{x:545,y:810,t:1527030462164};\\\", \\\"{x:536,y:787,t:1527030462181};\\\", \\\"{x:529,y:770,t:1527030462198};\\\", \\\"{x:520,y:753,t:1527030462214};\\\", \\\"{x:514,y:743,t:1527030462231};\\\", \\\"{x:512,y:735,t:1527030462250};\\\", \\\"{x:512,y:734,t:1527030462264};\\\", \\\"{x:512,y:733,t:1527030462280};\\\", \\\"{x:512,y:732,t:1527030462302};\\\", \\\"{x:512,y:731,t:1527030462335};\\\", \\\"{x:512,y:730,t:1527030462347};\\\", \\\"{x:512,y:729,t:1527030462363};\\\", \\\"{x:513,y:727,t:1527030462379};\\\", \\\"{x:514,y:726,t:1527030462397};\\\", \\\"{x:515,y:725,t:1527030462413};\\\" ] }, { \\\"rt\\\": 120605, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 500787, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -I -K -K -F -F -O -A -A -J -J -J -J -J -J -J -J -J -J -J -D -J -J -J -X -H -I -O -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:718,t:1527030467104};\\\", \\\"{x:515,y:702,t:1527030467122};\\\", \\\"{x:515,y:677,t:1527030467138};\\\", \\\"{x:517,y:646,t:1527030467154};\\\", \\\"{x:513,y:605,t:1527030467171};\\\", \\\"{x:497,y:552,t:1527030467188};\\\", \\\"{x:486,y:513,t:1527030467204};\\\", \\\"{x:472,y:481,t:1527030467220};\\\", \\\"{x:465,y:463,t:1527030467238};\\\", \\\"{x:462,y:451,t:1527030467254};\\\", \\\"{x:460,y:443,t:1527030467271};\\\", \\\"{x:464,y:446,t:1527030467512};\\\", \\\"{x:467,y:448,t:1527030467521};\\\", \\\"{x:479,y:452,t:1527030467538};\\\", \\\"{x:494,y:458,t:1527030467554};\\\", \\\"{x:512,y:461,t:1527030467571};\\\", \\\"{x:533,y:463,t:1527030467587};\\\", \\\"{x:553,y:466,t:1527030467605};\\\", \\\"{x:575,y:469,t:1527030467621};\\\", \\\"{x:594,y:469,t:1527030467638};\\\", \\\"{x:618,y:472,t:1527030467655};\\\", \\\"{x:627,y:474,t:1527030467671};\\\", \\\"{x:629,y:474,t:1527030467688};\\\", \\\"{x:628,y:476,t:1527030468215};\\\", \\\"{x:627,y:476,t:1527030468223};\\\", \\\"{x:625,y:476,t:1527030468238};\\\", \\\"{x:619,y:477,t:1527030468255};\\\", \\\"{x:614,y:479,t:1527030468271};\\\", \\\"{x:610,y:481,t:1527030468288};\\\", \\\"{x:605,y:482,t:1527030468305};\\\", \\\"{x:602,y:484,t:1527030468322};\\\", \\\"{x:597,y:485,t:1527030468338};\\\", \\\"{x:594,y:487,t:1527030468355};\\\", \\\"{x:589,y:488,t:1527030468372};\\\", \\\"{x:586,y:488,t:1527030468389};\\\", \\\"{x:584,y:489,t:1527030468405};\\\", \\\"{x:583,y:489,t:1527030468423};\\\", \\\"{x:582,y:489,t:1527030468447};\\\", \\\"{x:581,y:489,t:1527030468471};\\\", \\\"{x:580,y:489,t:1527030468495};\\\", \\\"{x:579,y:490,t:1527030468632};\\\", \\\"{x:575,y:490,t:1527030469656};\\\", \\\"{x:556,y:490,t:1527030469673};\\\", \\\"{x:540,y:490,t:1527030469690};\\\", \\\"{x:523,y:490,t:1527030469706};\\\", \\\"{x:510,y:490,t:1527030469723};\\\", \\\"{x:501,y:490,t:1527030469740};\\\", \\\"{x:498,y:490,t:1527030469757};\\\", \\\"{x:497,y:490,t:1527030469774};\\\", \\\"{x:496,y:490,t:1527030469816};\\\", \\\"{x:495,y:490,t:1527030469831};\\\", \\\"{x:494,y:490,t:1527030469847};\\\", \\\"{x:493,y:490,t:1527030469856};\\\", \\\"{x:492,y:489,t:1527030469974};\\\", \\\"{x:492,y:488,t:1527030469990};\\\", \\\"{x:497,y:486,t:1527030470006};\\\", \\\"{x:515,y:483,t:1527030470022};\\\", \\\"{x:529,y:483,t:1527030470039};\\\", \\\"{x:544,y:483,t:1527030470057};\\\", \\\"{x:558,y:483,t:1527030470073};\\\", \\\"{x:573,y:483,t:1527030470090};\\\", \\\"{x:591,y:483,t:1527030470107};\\\", \\\"{x:607,y:483,t:1527030470123};\\\", \\\"{x:623,y:486,t:1527030470140};\\\", \\\"{x:638,y:489,t:1527030470157};\\\", \\\"{x:652,y:489,t:1527030470173};\\\", \\\"{x:660,y:489,t:1527030470190};\\\", \\\"{x:662,y:489,t:1527030470207};\\\", \\\"{x:663,y:489,t:1527030470223};\\\", \\\"{x:664,y:490,t:1527030471425};\\\", \\\"{x:651,y:497,t:1527030471441};\\\", \\\"{x:626,y:502,t:1527030471458};\\\", \\\"{x:597,y:506,t:1527030471474};\\\", \\\"{x:566,y:511,t:1527030471491};\\\", \\\"{x:537,y:512,t:1527030471508};\\\", \\\"{x:514,y:512,t:1527030471524};\\\", \\\"{x:500,y:514,t:1527030471540};\\\", \\\"{x:491,y:514,t:1527030471558};\\\", \\\"{x:489,y:514,t:1527030471574};\\\", \\\"{x:488,y:515,t:1527030471591};\\\", \\\"{x:486,y:515,t:1527030471655};\\\", \\\"{x:485,y:516,t:1527030471663};\\\", \\\"{x:483,y:517,t:1527030471687};\\\", \\\"{x:484,y:517,t:1527030471848};\\\", \\\"{x:488,y:517,t:1527030471858};\\\", \\\"{x:499,y:517,t:1527030471875};\\\", \\\"{x:513,y:517,t:1527030471891};\\\", \\\"{x:528,y:517,t:1527030471909};\\\", \\\"{x:539,y:517,t:1527030471926};\\\", \\\"{x:548,y:518,t:1527030471941};\\\", \\\"{x:555,y:518,t:1527030471959};\\\", \\\"{x:562,y:519,t:1527030471975};\\\", \\\"{x:565,y:519,t:1527030471991};\\\", \\\"{x:566,y:519,t:1527030472008};\\\", \\\"{x:568,y:519,t:1527030472071};\\\", \\\"{x:567,y:518,t:1527030472256};\\\", \\\"{x:565,y:517,t:1527030472271};\\\", \\\"{x:564,y:515,t:1527030472279};\\\", \\\"{x:562,y:515,t:1527030472292};\\\", \\\"{x:556,y:512,t:1527030472308};\\\", \\\"{x:548,y:509,t:1527030472325};\\\", \\\"{x:542,y:507,t:1527030472343};\\\", \\\"{x:538,y:506,t:1527030472358};\\\", \\\"{x:540,y:505,t:1527030472632};\\\", \\\"{x:542,y:505,t:1527030472642};\\\", \\\"{x:545,y:505,t:1527030472659};\\\", \\\"{x:548,y:505,t:1527030472675};\\\", \\\"{x:550,y:503,t:1527030472692};\\\", \\\"{x:551,y:503,t:1527030472709};\\\", \\\"{x:551,y:502,t:1527030472904};\\\", \\\"{x:549,y:500,t:1527030472911};\\\", \\\"{x:545,y:498,t:1527030472927};\\\", \\\"{x:537,y:498,t:1527030472943};\\\", \\\"{x:528,y:496,t:1527030472959};\\\", \\\"{x:530,y:496,t:1527030473168};\\\", \\\"{x:532,y:496,t:1527030473175};\\\", \\\"{x:534,y:497,t:1527030473193};\\\", \\\"{x:537,y:498,t:1527030473209};\\\", \\\"{x:537,y:499,t:1527030473231};\\\", \\\"{x:538,y:499,t:1527030473255};\\\", \\\"{x:539,y:499,t:1527030473263};\\\", \\\"{x:541,y:499,t:1527030473295};\\\", \\\"{x:542,y:499,t:1527030473519};\\\", \\\"{x:543,y:499,t:1527030473527};\\\", \\\"{x:548,y:499,t:1527030473543};\\\", \\\"{x:557,y:499,t:1527030473560};\\\", \\\"{x:571,y:499,t:1527030473577};\\\", \\\"{x:593,y:499,t:1527030473594};\\\", \\\"{x:614,y:499,t:1527030473610};\\\", \\\"{x:630,y:499,t:1527030473626};\\\", \\\"{x:642,y:499,t:1527030473643};\\\", \\\"{x:646,y:499,t:1527030473659};\\\", \\\"{x:648,y:499,t:1527030473676};\\\", \\\"{x:649,y:499,t:1527030473863};\\\", \\\"{x:649,y:498,t:1527030473876};\\\", \\\"{x:644,y:498,t:1527030473893};\\\", \\\"{x:643,y:498,t:1527030473910};\\\", \\\"{x:641,y:498,t:1527030473926};\\\", \\\"{x:640,y:498,t:1527030473942};\\\", \\\"{x:641,y:498,t:1527030474127};\\\", \\\"{x:645,y:500,t:1527030474144};\\\", \\\"{x:652,y:502,t:1527030474161};\\\", \\\"{x:674,y:509,t:1527030474178};\\\", \\\"{x:723,y:522,t:1527030474195};\\\", \\\"{x:806,y:545,t:1527030474210};\\\", \\\"{x:931,y:568,t:1527030474227};\\\", \\\"{x:1081,y:596,t:1527030474244};\\\", \\\"{x:1251,y:630,t:1527030474260};\\\", \\\"{x:1419,y:675,t:1527030474276};\\\", \\\"{x:1579,y:717,t:1527030474293};\\\", \\\"{x:1697,y:761,t:1527030474310};\\\", \\\"{x:1770,y:798,t:1527030474327};\\\", \\\"{x:1813,y:838,t:1527030474343};\\\", \\\"{x:1825,y:862,t:1527030474360};\\\", \\\"{x:1827,y:884,t:1527030474376};\\\", \\\"{x:1824,y:900,t:1527030474393};\\\", \\\"{x:1810,y:910,t:1527030474410};\\\", \\\"{x:1791,y:917,t:1527030474426};\\\", \\\"{x:1776,y:917,t:1527030474443};\\\", \\\"{x:1766,y:917,t:1527030474460};\\\", \\\"{x:1755,y:916,t:1527030474476};\\\", \\\"{x:1742,y:913,t:1527030474494};\\\", \\\"{x:1722,y:906,t:1527030474510};\\\", \\\"{x:1701,y:900,t:1527030474527};\\\", \\\"{x:1672,y:893,t:1527030474543};\\\", \\\"{x:1656,y:888,t:1527030474560};\\\", \\\"{x:1642,y:887,t:1527030474577};\\\", \\\"{x:1633,y:887,t:1527030474593};\\\", \\\"{x:1626,y:886,t:1527030474611};\\\", \\\"{x:1620,y:886,t:1527030474626};\\\", \\\"{x:1613,y:886,t:1527030474643};\\\", \\\"{x:1606,y:886,t:1527030474660};\\\", \\\"{x:1600,y:886,t:1527030474678};\\\", \\\"{x:1594,y:886,t:1527030474693};\\\", \\\"{x:1588,y:888,t:1527030474711};\\\", \\\"{x:1577,y:890,t:1527030474728};\\\", \\\"{x:1569,y:893,t:1527030474744};\\\", \\\"{x:1555,y:895,t:1527030474760};\\\", \\\"{x:1536,y:900,t:1527030474778};\\\", \\\"{x:1505,y:910,t:1527030474793};\\\", \\\"{x:1464,y:920,t:1527030474811};\\\", \\\"{x:1421,y:928,t:1527030474827};\\\", \\\"{x:1383,y:933,t:1527030474843};\\\", \\\"{x:1362,y:938,t:1527030474860};\\\", \\\"{x:1343,y:940,t:1527030474877};\\\", \\\"{x:1332,y:942,t:1527030474893};\\\", \\\"{x:1322,y:943,t:1527030474910};\\\", \\\"{x:1312,y:943,t:1527030474927};\\\", \\\"{x:1305,y:943,t:1527030474943};\\\", \\\"{x:1296,y:943,t:1527030474960};\\\", \\\"{x:1291,y:943,t:1527030474977};\\\", \\\"{x:1285,y:941,t:1527030474993};\\\", \\\"{x:1279,y:938,t:1527030475011};\\\", \\\"{x:1274,y:936,t:1527030475027};\\\", \\\"{x:1271,y:935,t:1527030475043};\\\", \\\"{x:1270,y:934,t:1527030475061};\\\", \\\"{x:1267,y:933,t:1527030475077};\\\", \\\"{x:1262,y:930,t:1527030475094};\\\", \\\"{x:1257,y:930,t:1527030475110};\\\", \\\"{x:1253,y:926,t:1527030475127};\\\", \\\"{x:1252,y:926,t:1527030475200};\\\", \\\"{x:1252,y:925,t:1527030475211};\\\", \\\"{x:1252,y:918,t:1527030475228};\\\", \\\"{x:1258,y:914,t:1527030475244};\\\", \\\"{x:1267,y:907,t:1527030475260};\\\", \\\"{x:1278,y:901,t:1527030475278};\\\", \\\"{x:1290,y:894,t:1527030475295};\\\", \\\"{x:1302,y:888,t:1527030475311};\\\", \\\"{x:1321,y:879,t:1527030475328};\\\", \\\"{x:1333,y:869,t:1527030475345};\\\", \\\"{x:1344,y:859,t:1527030475360};\\\", \\\"{x:1359,y:848,t:1527030475377};\\\", \\\"{x:1373,y:838,t:1527030475395};\\\", \\\"{x:1392,y:828,t:1527030475411};\\\", \\\"{x:1409,y:821,t:1527030475428};\\\", \\\"{x:1430,y:815,t:1527030475445};\\\", \\\"{x:1451,y:811,t:1527030475461};\\\", \\\"{x:1472,y:809,t:1527030475478};\\\", \\\"{x:1495,y:805,t:1527030475495};\\\", \\\"{x:1518,y:805,t:1527030475511};\\\", \\\"{x:1546,y:812,t:1527030475528};\\\", \\\"{x:1568,y:821,t:1527030475544};\\\", \\\"{x:1589,y:836,t:1527030475560};\\\", \\\"{x:1609,y:854,t:1527030475578};\\\", \\\"{x:1620,y:869,t:1527030475594};\\\", \\\"{x:1626,y:884,t:1527030475611};\\\", \\\"{x:1628,y:897,t:1527030475627};\\\", \\\"{x:1629,y:902,t:1527030475644};\\\", \\\"{x:1629,y:905,t:1527030475661};\\\", \\\"{x:1628,y:908,t:1527030475677};\\\", \\\"{x:1625,y:910,t:1527030475695};\\\", \\\"{x:1613,y:912,t:1527030475711};\\\", \\\"{x:1602,y:912,t:1527030475727};\\\", \\\"{x:1585,y:910,t:1527030475744};\\\", \\\"{x:1561,y:904,t:1527030475762};\\\", \\\"{x:1536,y:900,t:1527030475777};\\\", \\\"{x:1508,y:896,t:1527030475795};\\\", \\\"{x:1483,y:893,t:1527030475812};\\\", \\\"{x:1458,y:887,t:1527030475827};\\\", \\\"{x:1434,y:882,t:1527030475844};\\\", \\\"{x:1415,y:874,t:1527030475861};\\\", \\\"{x:1395,y:868,t:1527030475877};\\\", \\\"{x:1385,y:867,t:1527030475894};\\\", \\\"{x:1382,y:864,t:1527030475910};\\\", \\\"{x:1381,y:864,t:1527030475927};\\\", \\\"{x:1380,y:864,t:1527030475944};\\\", \\\"{x:1378,y:863,t:1527030475961};\\\", \\\"{x:1374,y:860,t:1527030475978};\\\", \\\"{x:1370,y:856,t:1527030475994};\\\", \\\"{x:1364,y:851,t:1527030476011};\\\", \\\"{x:1356,y:844,t:1527030476029};\\\", \\\"{x:1351,y:839,t:1527030476044};\\\", \\\"{x:1346,y:834,t:1527030476062};\\\", \\\"{x:1341,y:819,t:1527030476078};\\\", \\\"{x:1336,y:790,t:1527030476095};\\\", \\\"{x:1335,y:707,t:1527030476111};\\\", \\\"{x:1335,y:654,t:1527030476128};\\\", \\\"{x:1335,y:606,t:1527030476145};\\\", \\\"{x:1335,y:578,t:1527030476161};\\\", \\\"{x:1335,y:556,t:1527030476179};\\\", \\\"{x:1335,y:545,t:1527030476195};\\\", \\\"{x:1335,y:537,t:1527030476211};\\\", \\\"{x:1337,y:533,t:1527030476229};\\\", \\\"{x:1341,y:526,t:1527030476244};\\\", \\\"{x:1342,y:525,t:1527030476262};\\\", \\\"{x:1343,y:524,t:1527030476279};\\\", \\\"{x:1344,y:523,t:1527030476294};\\\", \\\"{x:1346,y:520,t:1527030476312};\\\", \\\"{x:1347,y:519,t:1527030476608};\\\", \\\"{x:1347,y:518,t:1527030476615};\\\", \\\"{x:1343,y:515,t:1527030476628};\\\", \\\"{x:1337,y:513,t:1527030476645};\\\", \\\"{x:1332,y:511,t:1527030476661};\\\", \\\"{x:1329,y:510,t:1527030476678};\\\", \\\"{x:1325,y:507,t:1527030476695};\\\", \\\"{x:1324,y:506,t:1527030476967};\\\", \\\"{x:1323,y:505,t:1527030476979};\\\", \\\"{x:1318,y:503,t:1527030476996};\\\", \\\"{x:1317,y:503,t:1527030477014};\\\", \\\"{x:1315,y:503,t:1527030477029};\\\", \\\"{x:1315,y:502,t:1527030477394};\\\", \\\"{x:1315,y:501,t:1527030477412};\\\", \\\"{x:1315,y:500,t:1527030477879};\\\", \\\"{x:1314,y:497,t:1527030477897};\\\", \\\"{x:1312,y:493,t:1527030477913};\\\", \\\"{x:1311,y:492,t:1527030477930};\\\", \\\"{x:1310,y:493,t:1527030484496};\\\", \\\"{x:1310,y:502,t:1527030484505};\\\", \\\"{x:1310,y:511,t:1527030484518};\\\", \\\"{x:1310,y:539,t:1527030484535};\\\", \\\"{x:1310,y:554,t:1527030484552};\\\", \\\"{x:1310,y:565,t:1527030484568};\\\", \\\"{x:1310,y:575,t:1527030484585};\\\", \\\"{x:1310,y:583,t:1527030484602};\\\", \\\"{x:1310,y:589,t:1527030484618};\\\", \\\"{x:1310,y:594,t:1527030484635};\\\", \\\"{x:1310,y:598,t:1527030484652};\\\", \\\"{x:1311,y:604,t:1527030484668};\\\", \\\"{x:1312,y:609,t:1527030484686};\\\", \\\"{x:1313,y:614,t:1527030484702};\\\", \\\"{x:1313,y:621,t:1527030484718};\\\", \\\"{x:1315,y:631,t:1527030484736};\\\", \\\"{x:1316,y:638,t:1527030484753};\\\", \\\"{x:1316,y:644,t:1527030484768};\\\", \\\"{x:1316,y:650,t:1527030484785};\\\", \\\"{x:1317,y:655,t:1527030484802};\\\", \\\"{x:1317,y:660,t:1527030484819};\\\", \\\"{x:1317,y:663,t:1527030484837};\\\", \\\"{x:1317,y:666,t:1527030484852};\\\", \\\"{x:1317,y:668,t:1527030484869};\\\", \\\"{x:1317,y:669,t:1527030484885};\\\", \\\"{x:1317,y:671,t:1527030484902};\\\", \\\"{x:1317,y:675,t:1527030484919};\\\", \\\"{x:1317,y:680,t:1527030484934};\\\", \\\"{x:1317,y:684,t:1527030484951};\\\", \\\"{x:1317,y:688,t:1527030484969};\\\", \\\"{x:1317,y:695,t:1527030484985};\\\", \\\"{x:1317,y:700,t:1527030485002};\\\", \\\"{x:1317,y:704,t:1527030485018};\\\", \\\"{x:1317,y:709,t:1527030485034};\\\", \\\"{x:1317,y:713,t:1527030485052};\\\", \\\"{x:1319,y:716,t:1527030485068};\\\", \\\"{x:1320,y:718,t:1527030485084};\\\", \\\"{x:1320,y:720,t:1527030485102};\\\", \\\"{x:1320,y:724,t:1527030485118};\\\", \\\"{x:1320,y:726,t:1527030485135};\\\", \\\"{x:1320,y:730,t:1527030485152};\\\", \\\"{x:1321,y:732,t:1527030485169};\\\", \\\"{x:1321,y:736,t:1527030485185};\\\", \\\"{x:1322,y:738,t:1527030485202};\\\", \\\"{x:1322,y:739,t:1527030485219};\\\", \\\"{x:1322,y:740,t:1527030485236};\\\", \\\"{x:1322,y:742,t:1527030485279};\\\", \\\"{x:1323,y:745,t:1527030485544};\\\", \\\"{x:1323,y:747,t:1527030485552};\\\", \\\"{x:1324,y:750,t:1527030485569};\\\", \\\"{x:1324,y:753,t:1527030485585};\\\", \\\"{x:1324,y:759,t:1527030485601};\\\", \\\"{x:1324,y:767,t:1527030485618};\\\", \\\"{x:1324,y:779,t:1527030485636};\\\", \\\"{x:1324,y:794,t:1527030485653};\\\", \\\"{x:1323,y:812,t:1527030485668};\\\", \\\"{x:1320,y:832,t:1527030485685};\\\", \\\"{x:1317,y:854,t:1527030485703};\\\", \\\"{x:1317,y:867,t:1527030485718};\\\", \\\"{x:1316,y:878,t:1527030485736};\\\", \\\"{x:1315,y:886,t:1527030485753};\\\", \\\"{x:1315,y:891,t:1527030485768};\\\", \\\"{x:1315,y:893,t:1527030485785};\\\", \\\"{x:1315,y:896,t:1527030485803};\\\", \\\"{x:1315,y:898,t:1527030485819};\\\", \\\"{x:1315,y:900,t:1527030485838};\\\", \\\"{x:1315,y:902,t:1527030485853};\\\", \\\"{x:1316,y:904,t:1527030485869};\\\", \\\"{x:1316,y:905,t:1527030485885};\\\", \\\"{x:1316,y:906,t:1527030485975};\\\", \\\"{x:1317,y:909,t:1527030486080};\\\", \\\"{x:1317,y:912,t:1527030486095};\\\", \\\"{x:1317,y:914,t:1527030486111};\\\", \\\"{x:1317,y:915,t:1527030486127};\\\", \\\"{x:1317,y:918,t:1527030486143};\\\", \\\"{x:1317,y:920,t:1527030486153};\\\", \\\"{x:1317,y:926,t:1527030486170};\\\", \\\"{x:1317,y:932,t:1527030486186};\\\", \\\"{x:1317,y:937,t:1527030486203};\\\", \\\"{x:1317,y:941,t:1527030486220};\\\", \\\"{x:1317,y:945,t:1527030486236};\\\", \\\"{x:1317,y:948,t:1527030486253};\\\", \\\"{x:1317,y:950,t:1527030486270};\\\", \\\"{x:1317,y:951,t:1527030486286};\\\", \\\"{x:1317,y:953,t:1527030486303};\\\", \\\"{x:1317,y:954,t:1527030486320};\\\", \\\"{x:1317,y:955,t:1527030486336};\\\", \\\"{x:1317,y:956,t:1527030486353};\\\", \\\"{x:1317,y:957,t:1527030486471};\\\", \\\"{x:1317,y:960,t:1527030486486};\\\", \\\"{x:1317,y:965,t:1527030486502};\\\", \\\"{x:1317,y:970,t:1527030486520};\\\", \\\"{x:1316,y:975,t:1527030486536};\\\", \\\"{x:1315,y:977,t:1527030486552};\\\", \\\"{x:1315,y:978,t:1527030486569};\\\", \\\"{x:1313,y:979,t:1527030486855};\\\", \\\"{x:1313,y:980,t:1527030486870};\\\", \\\"{x:1312,y:980,t:1527030487976};\\\", \\\"{x:1311,y:980,t:1527030487988};\\\", \\\"{x:1310,y:977,t:1527030488004};\\\", \\\"{x:1308,y:976,t:1527030488021};\\\", \\\"{x:1306,y:971,t:1527030488038};\\\", \\\"{x:1305,y:967,t:1527030488054};\\\", \\\"{x:1305,y:965,t:1527030488071};\\\", \\\"{x:1305,y:964,t:1527030488088};\\\", \\\"{x:1307,y:962,t:1527030488288};\\\", \\\"{x:1309,y:961,t:1527030488306};\\\", \\\"{x:1310,y:961,t:1527030488656};\\\", \\\"{x:1311,y:961,t:1527030488854};\\\", \\\"{x:1313,y:961,t:1527030488886};\\\", \\\"{x:1313,y:962,t:1527030489336};\\\", \\\"{x:1313,y:963,t:1527030489376};\\\", \\\"{x:1312,y:964,t:1527030489791};\\\", \\\"{x:1311,y:965,t:1527030489807};\\\", \\\"{x:1311,y:966,t:1527030489822};\\\", \\\"{x:1308,y:967,t:1527030489839};\\\", \\\"{x:1308,y:968,t:1527030489856};\\\", \\\"{x:1307,y:968,t:1527030489873};\\\", \\\"{x:1307,y:969,t:1527030489911};\\\", \\\"{x:1305,y:968,t:1527030490392};\\\", \\\"{x:1305,y:966,t:1527030490406};\\\", \\\"{x:1302,y:960,t:1527030490422};\\\", \\\"{x:1302,y:959,t:1527030490438};\\\", \\\"{x:1302,y:958,t:1527030490456};\\\", \\\"{x:1301,y:957,t:1527030490473};\\\", \\\"{x:1301,y:958,t:1527030490656};\\\", \\\"{x:1302,y:964,t:1527030490673};\\\", \\\"{x:1304,y:969,t:1527030490691};\\\", \\\"{x:1305,y:972,t:1527030490706};\\\", \\\"{x:1306,y:974,t:1527030490723};\\\", \\\"{x:1307,y:974,t:1527030490740};\\\", \\\"{x:1308,y:974,t:1527030490816};\\\", \\\"{x:1309,y:974,t:1527030490823};\\\", \\\"{x:1310,y:974,t:1527030490840};\\\", \\\"{x:1312,y:974,t:1527030490855};\\\", \\\"{x:1312,y:973,t:1527030490958};\\\", \\\"{x:1312,y:971,t:1527030490973};\\\", \\\"{x:1312,y:970,t:1527030490990};\\\", \\\"{x:1312,y:968,t:1527030491007};\\\", \\\"{x:1313,y:968,t:1527030491151};\\\", \\\"{x:1313,y:969,t:1527030492007};\\\", \\\"{x:1313,y:971,t:1527030492024};\\\", \\\"{x:1315,y:972,t:1527030492041};\\\", \\\"{x:1316,y:971,t:1527030492344};\\\", \\\"{x:1316,y:970,t:1527030492358};\\\", \\\"{x:1316,y:969,t:1527030492374};\\\", \\\"{x:1316,y:967,t:1527030492391};\\\", \\\"{x:1316,y:966,t:1527030492408};\\\", \\\"{x:1317,y:964,t:1527030505789};\\\", \\\"{x:1320,y:960,t:1527030505800};\\\", \\\"{x:1322,y:950,t:1527030505815};\\\", \\\"{x:1323,y:939,t:1527030505832};\\\", \\\"{x:1325,y:927,t:1527030505848};\\\", \\\"{x:1328,y:915,t:1527030505866};\\\", \\\"{x:1330,y:910,t:1527030505882};\\\", \\\"{x:1332,y:905,t:1527030505898};\\\", \\\"{x:1333,y:904,t:1527030505916};\\\", \\\"{x:1333,y:903,t:1527030506717};\\\", \\\"{x:1334,y:874,t:1527030506733};\\\", \\\"{x:1340,y:819,t:1527030506751};\\\", \\\"{x:1340,y:749,t:1527030506766};\\\", \\\"{x:1344,y:668,t:1527030506783};\\\", \\\"{x:1358,y:603,t:1527030506800};\\\", \\\"{x:1374,y:547,t:1527030506818};\\\", \\\"{x:1383,y:513,t:1527030506834};\\\", \\\"{x:1388,y:503,t:1527030506851};\\\", \\\"{x:1390,y:502,t:1527030506867};\\\", \\\"{x:1390,y:503,t:1527030506933};\\\", \\\"{x:1389,y:503,t:1527030506951};\\\", \\\"{x:1388,y:503,t:1527030507109};\\\", \\\"{x:1384,y:503,t:1527030507117};\\\", \\\"{x:1373,y:503,t:1527030507135};\\\", \\\"{x:1350,y:503,t:1527030507151};\\\", \\\"{x:1323,y:503,t:1527030507167};\\\", \\\"{x:1301,y:503,t:1527030507184};\\\", \\\"{x:1287,y:506,t:1527030507200};\\\", \\\"{x:1283,y:506,t:1527030507217};\\\", \\\"{x:1283,y:507,t:1527030507234};\\\", \\\"{x:1283,y:508,t:1527030507334};\\\", \\\"{x:1286,y:510,t:1527030507351};\\\", \\\"{x:1290,y:511,t:1527030507368};\\\", \\\"{x:1293,y:512,t:1527030507385};\\\", \\\"{x:1297,y:513,t:1527030507401};\\\", \\\"{x:1301,y:513,t:1527030507418};\\\", \\\"{x:1305,y:512,t:1527030507434};\\\", \\\"{x:1309,y:510,t:1527030507450};\\\", \\\"{x:1312,y:508,t:1527030507468};\\\", \\\"{x:1312,y:507,t:1527030507606};\\\", \\\"{x:1312,y:506,t:1527030507629};\\\", \\\"{x:1312,y:505,t:1527030507652};\\\", \\\"{x:1312,y:504,t:1527030507676};\\\", \\\"{x:1312,y:503,t:1527030507725};\\\", \\\"{x:1312,y:502,t:1527030507735};\\\", \\\"{x:1313,y:500,t:1527030507751};\\\", \\\"{x:1314,y:497,t:1527030507767};\\\", \\\"{x:1314,y:494,t:1527030507783};\\\", \\\"{x:1316,y:492,t:1527030507801};\\\", \\\"{x:1316,y:491,t:1527030507817};\\\", \\\"{x:1316,y:498,t:1527030510812};\\\", \\\"{x:1316,y:504,t:1527030510822};\\\", \\\"{x:1316,y:514,t:1527030510837};\\\", \\\"{x:1320,y:524,t:1527030510854};\\\", \\\"{x:1326,y:540,t:1527030510871};\\\", \\\"{x:1337,y:566,t:1527030510887};\\\", \\\"{x:1356,y:613,t:1527030510904};\\\", \\\"{x:1380,y:692,t:1527030510921};\\\", \\\"{x:1403,y:775,t:1527030510937};\\\", \\\"{x:1428,y:845,t:1527030510954};\\\", \\\"{x:1446,y:896,t:1527030510971};\\\", \\\"{x:1458,y:928,t:1527030510987};\\\", \\\"{x:1464,y:949,t:1527030511004};\\\", \\\"{x:1468,y:959,t:1527030511021};\\\", \\\"{x:1468,y:961,t:1527030511037};\\\", \\\"{x:1468,y:959,t:1527030511181};\\\", \\\"{x:1466,y:953,t:1527030511189};\\\", \\\"{x:1464,y:950,t:1527030511204};\\\", \\\"{x:1456,y:941,t:1527030511221};\\\", \\\"{x:1451,y:935,t:1527030511238};\\\", \\\"{x:1449,y:932,t:1527030511254};\\\", \\\"{x:1448,y:931,t:1527030511271};\\\", \\\"{x:1447,y:928,t:1527030511288};\\\", \\\"{x:1446,y:928,t:1527030511304};\\\", \\\"{x:1445,y:926,t:1527030511321};\\\", \\\"{x:1445,y:925,t:1527030511380};\\\", \\\"{x:1445,y:924,t:1527030511388};\\\", \\\"{x:1444,y:924,t:1527030511405};\\\", \\\"{x:1442,y:923,t:1527030511420};\\\", \\\"{x:1441,y:922,t:1527030511438};\\\", \\\"{x:1440,y:921,t:1527030511454};\\\", \\\"{x:1439,y:921,t:1527030511470};\\\", \\\"{x:1438,y:921,t:1527030511488};\\\", \\\"{x:1437,y:921,t:1527030511504};\\\", \\\"{x:1434,y:921,t:1527030511520};\\\", \\\"{x:1431,y:921,t:1527030511538};\\\", \\\"{x:1428,y:921,t:1527030511554};\\\", \\\"{x:1426,y:921,t:1527030511570};\\\", \\\"{x:1423,y:921,t:1527030511588};\\\", \\\"{x:1420,y:921,t:1527030511604};\\\", \\\"{x:1418,y:921,t:1527030511620};\\\", \\\"{x:1417,y:921,t:1527030511638};\\\", \\\"{x:1416,y:921,t:1527030511868};\\\", \\\"{x:1415,y:921,t:1527030511876};\\\", \\\"{x:1414,y:921,t:1527030511891};\\\", \\\"{x:1413,y:921,t:1527030511923};\\\", \\\"{x:1411,y:921,t:1527030511972};\\\", \\\"{x:1409,y:920,t:1527030512028};\\\", \\\"{x:1408,y:919,t:1527030512037};\\\", \\\"{x:1407,y:919,t:1527030512054};\\\", \\\"{x:1403,y:919,t:1527030512071};\\\", \\\"{x:1399,y:919,t:1527030512087};\\\", \\\"{x:1392,y:917,t:1527030512104};\\\", \\\"{x:1385,y:915,t:1527030512121};\\\", \\\"{x:1380,y:914,t:1527030512137};\\\", \\\"{x:1375,y:913,t:1527030512154};\\\", \\\"{x:1371,y:911,t:1527030512171};\\\", \\\"{x:1368,y:909,t:1527030512187};\\\", \\\"{x:1366,y:907,t:1527030512204};\\\", \\\"{x:1365,y:905,t:1527030512222};\\\", \\\"{x:1364,y:904,t:1527030512238};\\\", \\\"{x:1364,y:900,t:1527030512812};\\\", \\\"{x:1364,y:897,t:1527030512821};\\\", \\\"{x:1364,y:893,t:1527030512838};\\\", \\\"{x:1364,y:886,t:1527030512854};\\\", \\\"{x:1364,y:874,t:1527030512871};\\\", \\\"{x:1366,y:849,t:1527030512889};\\\", \\\"{x:1377,y:797,t:1527030512905};\\\", \\\"{x:1387,y:743,t:1527030512921};\\\", \\\"{x:1393,y:696,t:1527030512939};\\\", \\\"{x:1393,y:640,t:1527030512956};\\\", \\\"{x:1394,y:613,t:1527030512971};\\\", \\\"{x:1393,y:590,t:1527030512988};\\\", \\\"{x:1389,y:579,t:1527030513005};\\\", \\\"{x:1385,y:570,t:1527030513022};\\\", \\\"{x:1382,y:564,t:1527030513039};\\\", \\\"{x:1379,y:558,t:1527030513056};\\\", \\\"{x:1378,y:551,t:1527030513071};\\\", \\\"{x:1377,y:548,t:1527030513088};\\\", \\\"{x:1376,y:547,t:1527030513105};\\\", \\\"{x:1375,y:546,t:1527030513125};\\\", \\\"{x:1374,y:545,t:1527030513140};\\\", \\\"{x:1373,y:545,t:1527030513156};\\\", \\\"{x:1372,y:545,t:1527030513171};\\\", \\\"{x:1370,y:543,t:1527030513189};\\\", \\\"{x:1368,y:543,t:1527030513206};\\\", \\\"{x:1367,y:541,t:1527030513223};\\\", \\\"{x:1366,y:537,t:1527030513239};\\\", \\\"{x:1362,y:532,t:1527030513256};\\\", \\\"{x:1359,y:527,t:1527030513271};\\\", \\\"{x:1356,y:522,t:1527030513288};\\\", \\\"{x:1354,y:519,t:1527030513305};\\\", \\\"{x:1352,y:515,t:1527030513321};\\\", \\\"{x:1350,y:512,t:1527030513338};\\\", \\\"{x:1348,y:509,t:1527030513356};\\\", \\\"{x:1345,y:506,t:1527030513372};\\\", \\\"{x:1344,y:504,t:1527030513388};\\\", \\\"{x:1342,y:502,t:1527030513405};\\\", \\\"{x:1341,y:501,t:1527030513423};\\\", \\\"{x:1341,y:500,t:1527030513438};\\\", \\\"{x:1340,y:497,t:1527030513456};\\\", \\\"{x:1341,y:496,t:1527030513525};\\\", \\\"{x:1342,y:496,t:1527030513538};\\\", \\\"{x:1347,y:496,t:1527030513555};\\\", \\\"{x:1352,y:496,t:1527030513573};\\\", \\\"{x:1355,y:496,t:1527030513589};\\\", \\\"{x:1356,y:496,t:1527030513606};\\\", \\\"{x:1357,y:496,t:1527030513623};\\\", \\\"{x:1355,y:496,t:1527030513789};\\\", \\\"{x:1352,y:495,t:1527030513806};\\\", \\\"{x:1351,y:494,t:1527030513822};\\\", \\\"{x:1350,y:493,t:1527030513861};\\\", \\\"{x:1349,y:493,t:1527030513901};\\\", \\\"{x:1348,y:493,t:1527030513917};\\\", \\\"{x:1349,y:493,t:1527030514037};\\\", \\\"{x:1351,y:494,t:1527030514044};\\\", \\\"{x:1352,y:494,t:1527030514056};\\\", \\\"{x:1356,y:495,t:1527030514073};\\\", \\\"{x:1358,y:496,t:1527030514091};\\\", \\\"{x:1359,y:496,t:1527030514106};\\\", \\\"{x:1362,y:497,t:1527030514123};\\\", \\\"{x:1366,y:497,t:1527030514140};\\\", \\\"{x:1370,y:497,t:1527030514156};\\\", \\\"{x:1375,y:497,t:1527030514173};\\\", \\\"{x:1376,y:497,t:1527030514190};\\\", \\\"{x:1377,y:497,t:1527030514221};\\\", \\\"{x:1378,y:497,t:1527030514253};\\\", \\\"{x:1379,y:497,t:1527030514277};\\\", \\\"{x:1380,y:496,t:1527030514290};\\\", \\\"{x:1382,y:496,t:1527030514307};\\\", \\\"{x:1383,y:496,t:1527030514323};\\\", \\\"{x:1386,y:494,t:1527030514340};\\\", \\\"{x:1391,y:493,t:1527030514356};\\\", \\\"{x:1393,y:492,t:1527030514373};\\\", \\\"{x:1395,y:490,t:1527030514390};\\\", \\\"{x:1396,y:490,t:1527030514413};\\\", \\\"{x:1397,y:490,t:1527030514445};\\\", \\\"{x:1398,y:490,t:1527030514457};\\\", \\\"{x:1398,y:489,t:1527030514473};\\\", \\\"{x:1400,y:489,t:1527030514490};\\\", \\\"{x:1402,y:487,t:1527030514507};\\\", \\\"{x:1404,y:487,t:1527030514533};\\\", \\\"{x:1405,y:487,t:1527030514597};\\\", \\\"{x:1409,y:487,t:1527030514607};\\\", \\\"{x:1415,y:488,t:1527030514623};\\\", \\\"{x:1422,y:491,t:1527030514640};\\\", \\\"{x:1429,y:492,t:1527030514657};\\\", \\\"{x:1436,y:494,t:1527030514673};\\\", \\\"{x:1442,y:495,t:1527030514690};\\\", \\\"{x:1447,y:495,t:1527030514707};\\\", \\\"{x:1452,y:496,t:1527030514723};\\\", \\\"{x:1461,y:497,t:1527030514740};\\\", \\\"{x:1479,y:497,t:1527030514756};\\\", \\\"{x:1487,y:497,t:1527030514773};\\\", \\\"{x:1494,y:497,t:1527030514790};\\\", \\\"{x:1500,y:497,t:1527030514806};\\\", \\\"{x:1506,y:497,t:1527030514823};\\\", \\\"{x:1508,y:497,t:1527030514839};\\\", \\\"{x:1510,y:497,t:1527030514856};\\\", \\\"{x:1510,y:498,t:1527030515029};\\\", \\\"{x:1510,y:499,t:1527030515040};\\\", \\\"{x:1509,y:500,t:1527030515056};\\\", \\\"{x:1508,y:500,t:1527030515074};\\\", \\\"{x:1507,y:500,t:1527030515132};\\\", \\\"{x:1508,y:501,t:1527030515876};\\\", \\\"{x:1508,y:502,t:1527030517253};\\\", \\\"{x:1510,y:505,t:1527030517261};\\\", \\\"{x:1510,y:511,t:1527030517275};\\\", \\\"{x:1510,y:520,t:1527030517293};\\\", \\\"{x:1510,y:526,t:1527030517308};\\\", \\\"{x:1510,y:532,t:1527030517326};\\\", \\\"{x:1510,y:537,t:1527030517342};\\\", \\\"{x:1511,y:542,t:1527030517359};\\\", \\\"{x:1511,y:547,t:1527030517376};\\\", \\\"{x:1511,y:553,t:1527030517392};\\\", \\\"{x:1511,y:558,t:1527030517409};\\\", \\\"{x:1512,y:564,t:1527030517426};\\\", \\\"{x:1514,y:571,t:1527030517442};\\\", \\\"{x:1514,y:573,t:1527030517459};\\\", \\\"{x:1515,y:578,t:1527030517476};\\\", \\\"{x:1515,y:579,t:1527030517492};\\\", \\\"{x:1515,y:581,t:1527030517509};\\\", \\\"{x:1515,y:583,t:1527030517526};\\\", \\\"{x:1515,y:584,t:1527030517557};\\\", \\\"{x:1515,y:585,t:1527030517564};\\\", \\\"{x:1515,y:586,t:1527030517581};\\\", \\\"{x:1515,y:587,t:1527030517597};\\\", \\\"{x:1515,y:588,t:1527030517609};\\\", \\\"{x:1515,y:589,t:1527030517626};\\\", \\\"{x:1515,y:591,t:1527030517642};\\\", \\\"{x:1515,y:592,t:1527030517659};\\\", \\\"{x:1515,y:597,t:1527030517676};\\\", \\\"{x:1515,y:601,t:1527030517693};\\\", \\\"{x:1515,y:605,t:1527030517709};\\\", \\\"{x:1514,y:609,t:1527030517726};\\\", \\\"{x:1514,y:614,t:1527030517743};\\\", \\\"{x:1514,y:620,t:1527030517758};\\\", \\\"{x:1514,y:622,t:1527030517775};\\\", \\\"{x:1514,y:626,t:1527030517793};\\\", \\\"{x:1514,y:629,t:1527030517808};\\\", \\\"{x:1514,y:633,t:1527030517825};\\\", \\\"{x:1514,y:636,t:1527030517843};\\\", \\\"{x:1514,y:640,t:1527030517859};\\\", \\\"{x:1515,y:645,t:1527030517875};\\\", \\\"{x:1515,y:648,t:1527030517892};\\\", \\\"{x:1515,y:651,t:1527030517908};\\\", \\\"{x:1515,y:652,t:1527030517926};\\\", \\\"{x:1515,y:654,t:1527030517943};\\\", \\\"{x:1516,y:657,t:1527030517959};\\\", \\\"{x:1516,y:659,t:1527030517976};\\\", \\\"{x:1517,y:662,t:1527030517992};\\\", \\\"{x:1517,y:664,t:1527030518009};\\\", \\\"{x:1517,y:665,t:1527030518025};\\\", \\\"{x:1517,y:667,t:1527030518042};\\\", \\\"{x:1517,y:668,t:1527030518060};\\\", \\\"{x:1518,y:669,t:1527030518075};\\\", \\\"{x:1518,y:670,t:1527030518093};\\\", \\\"{x:1518,y:672,t:1527030518109};\\\", \\\"{x:1518,y:674,t:1527030518126};\\\", \\\"{x:1518,y:676,t:1527030518143};\\\", \\\"{x:1518,y:680,t:1527030518158};\\\", \\\"{x:1519,y:684,t:1527030518176};\\\", \\\"{x:1519,y:688,t:1527030518193};\\\", \\\"{x:1519,y:692,t:1527030518208};\\\", \\\"{x:1519,y:698,t:1527030518226};\\\", \\\"{x:1519,y:702,t:1527030518243};\\\", \\\"{x:1519,y:710,t:1527030518259};\\\", \\\"{x:1520,y:722,t:1527030518276};\\\", \\\"{x:1522,y:731,t:1527030518292};\\\", \\\"{x:1522,y:741,t:1527030518310};\\\", \\\"{x:1523,y:750,t:1527030518326};\\\", \\\"{x:1523,y:755,t:1527030518343};\\\", \\\"{x:1523,y:761,t:1527030518360};\\\", \\\"{x:1524,y:765,t:1527030518376};\\\", \\\"{x:1524,y:769,t:1527030518393};\\\", \\\"{x:1524,y:772,t:1527030518410};\\\", \\\"{x:1524,y:773,t:1527030518426};\\\", \\\"{x:1524,y:775,t:1527030518443};\\\", \\\"{x:1524,y:777,t:1527030518461};\\\", \\\"{x:1524,y:779,t:1527030518476};\\\", \\\"{x:1524,y:780,t:1527030518500};\\\", \\\"{x:1524,y:781,t:1527030518510};\\\", \\\"{x:1524,y:782,t:1527030518531};\\\", \\\"{x:1524,y:783,t:1527030518725};\\\", \\\"{x:1523,y:778,t:1527030518837};\\\", \\\"{x:1521,y:770,t:1527030518844};\\\", \\\"{x:1515,y:754,t:1527030518860};\\\", \\\"{x:1511,y:740,t:1527030518876};\\\", \\\"{x:1511,y:732,t:1527030518892};\\\", \\\"{x:1511,y:728,t:1527030518909};\\\", \\\"{x:1511,y:726,t:1527030518926};\\\", \\\"{x:1510,y:726,t:1527030518989};\\\", \\\"{x:1509,y:726,t:1527030518996};\\\", \\\"{x:1508,y:726,t:1527030519010};\\\", \\\"{x:1507,y:729,t:1527030519027};\\\", \\\"{x:1507,y:735,t:1527030519043};\\\", \\\"{x:1505,y:744,t:1527030519061};\\\", \\\"{x:1504,y:748,t:1527030519076};\\\", \\\"{x:1504,y:752,t:1527030519094};\\\", \\\"{x:1504,y:754,t:1527030519109};\\\", \\\"{x:1504,y:756,t:1527030519127};\\\", \\\"{x:1504,y:758,t:1527030519143};\\\", \\\"{x:1504,y:759,t:1527030519160};\\\", \\\"{x:1503,y:761,t:1527030519177};\\\", \\\"{x:1501,y:764,t:1527030519194};\\\", \\\"{x:1501,y:765,t:1527030519212};\\\", \\\"{x:1500,y:766,t:1527030519445};\\\", \\\"{x:1493,y:768,t:1527030519460};\\\", \\\"{x:1485,y:770,t:1527030519477};\\\", \\\"{x:1476,y:773,t:1527030519494};\\\", \\\"{x:1466,y:777,t:1527030519510};\\\", \\\"{x:1459,y:779,t:1527030519527};\\\", \\\"{x:1456,y:781,t:1527030519544};\\\", \\\"{x:1452,y:783,t:1527030519561};\\\", \\\"{x:1448,y:784,t:1527030519577};\\\", \\\"{x:1447,y:786,t:1527030519594};\\\", \\\"{x:1444,y:786,t:1527030519612};\\\", \\\"{x:1442,y:788,t:1527030519627};\\\", \\\"{x:1439,y:788,t:1527030519644};\\\", \\\"{x:1438,y:788,t:1527030519661};\\\", \\\"{x:1437,y:788,t:1527030519685};\\\", \\\"{x:1436,y:788,t:1527030519701};\\\", \\\"{x:1434,y:788,t:1527030519740};\\\", \\\"{x:1434,y:786,t:1527030519748};\\\", \\\"{x:1434,y:784,t:1527030519762};\\\", \\\"{x:1431,y:780,t:1527030519778};\\\", \\\"{x:1430,y:777,t:1527030519794};\\\", \\\"{x:1429,y:774,t:1527030519811};\\\", \\\"{x:1426,y:772,t:1527030519827};\\\", \\\"{x:1421,y:768,t:1527030519843};\\\", \\\"{x:1420,y:767,t:1527030519860};\\\", \\\"{x:1418,y:767,t:1527030519891};\\\", \\\"{x:1416,y:766,t:1527030519908};\\\", \\\"{x:1415,y:766,t:1527030519923};\\\", \\\"{x:1414,y:766,t:1527030519939};\\\", \\\"{x:1413,y:766,t:1527030519948};\\\", \\\"{x:1412,y:766,t:1527030519961};\\\", \\\"{x:1411,y:766,t:1527030519979};\\\", \\\"{x:1410,y:766,t:1527030519996};\\\", \\\"{x:1409,y:766,t:1527030520011};\\\", \\\"{x:1404,y:766,t:1527030520027};\\\", \\\"{x:1401,y:766,t:1527030520043};\\\", \\\"{x:1400,y:766,t:1527030520061};\\\", \\\"{x:1398,y:767,t:1527030520157};\\\", \\\"{x:1397,y:767,t:1527030520437};\\\", \\\"{x:1396,y:767,t:1527030520445};\\\", \\\"{x:1394,y:767,t:1527030520461};\\\", \\\"{x:1392,y:767,t:1527030520478};\\\", \\\"{x:1390,y:767,t:1527030520495};\\\", \\\"{x:1388,y:766,t:1527030520511};\\\", \\\"{x:1386,y:765,t:1527030523237};\\\", \\\"{x:1385,y:765,t:1527030523247};\\\", \\\"{x:1384,y:764,t:1527030523262};\\\", \\\"{x:1382,y:763,t:1527030523280};\\\", \\\"{x:1380,y:762,t:1527030523296};\\\", \\\"{x:1380,y:768,t:1527030524748};\\\", \\\"{x:1382,y:790,t:1527030524766};\\\", \\\"{x:1384,y:818,t:1527030524781};\\\", \\\"{x:1390,y:852,t:1527030524798};\\\", \\\"{x:1396,y:887,t:1527030524814};\\\", \\\"{x:1397,y:913,t:1527030524831};\\\", \\\"{x:1397,y:934,t:1527030524848};\\\", \\\"{x:1397,y:952,t:1527030524865};\\\", \\\"{x:1394,y:967,t:1527030524882};\\\", \\\"{x:1389,y:981,t:1527030524899};\\\", \\\"{x:1387,y:994,t:1527030524915};\\\", \\\"{x:1384,y:1004,t:1527030524932};\\\", \\\"{x:1382,y:1013,t:1527030524948};\\\", \\\"{x:1381,y:1017,t:1527030524965};\\\", \\\"{x:1381,y:1018,t:1527030524981};\\\", \\\"{x:1381,y:1017,t:1527030525109};\\\", \\\"{x:1381,y:1013,t:1527030525116};\\\", \\\"{x:1381,y:1009,t:1527030525132};\\\", \\\"{x:1381,y:993,t:1527030525148};\\\", \\\"{x:1379,y:979,t:1527030525165};\\\", \\\"{x:1379,y:971,t:1527030525181};\\\", \\\"{x:1378,y:962,t:1527030525198};\\\", \\\"{x:1375,y:956,t:1527030525215};\\\", \\\"{x:1375,y:953,t:1527030525232};\\\", \\\"{x:1375,y:950,t:1527030525248};\\\", \\\"{x:1375,y:948,t:1527030525265};\\\", \\\"{x:1375,y:947,t:1527030525282};\\\", \\\"{x:1374,y:946,t:1527030525301};\\\", \\\"{x:1374,y:945,t:1527030525316};\\\", \\\"{x:1374,y:946,t:1527030525605};\\\", \\\"{x:1374,y:947,t:1527030525615};\\\", \\\"{x:1374,y:949,t:1527030525633};\\\", \\\"{x:1374,y:951,t:1527030525650};\\\", \\\"{x:1375,y:949,t:1527030526205};\\\", \\\"{x:1379,y:944,t:1527030526215};\\\", \\\"{x:1387,y:927,t:1527030526232};\\\", \\\"{x:1395,y:907,t:1527030526249};\\\", \\\"{x:1403,y:881,t:1527030526267};\\\", \\\"{x:1409,y:848,t:1527030526283};\\\", \\\"{x:1410,y:820,t:1527030526300};\\\", \\\"{x:1414,y:785,t:1527030526317};\\\", \\\"{x:1417,y:774,t:1527030526333};\\\", \\\"{x:1420,y:766,t:1527030526350};\\\", \\\"{x:1421,y:763,t:1527030526366};\\\", \\\"{x:1421,y:762,t:1527030526383};\\\", \\\"{x:1421,y:761,t:1527030526476};\\\", \\\"{x:1423,y:760,t:1527030526484};\\\", \\\"{x:1424,y:760,t:1527030526500};\\\", \\\"{x:1425,y:760,t:1527030526533};\\\", \\\"{x:1426,y:760,t:1527030526556};\\\", \\\"{x:1427,y:760,t:1527030526589};\\\", \\\"{x:1428,y:760,t:1527030526837};\\\", \\\"{x:1430,y:760,t:1527030526849};\\\", \\\"{x:1436,y:760,t:1527030526866};\\\", \\\"{x:1444,y:760,t:1527030526883};\\\", \\\"{x:1448,y:760,t:1527030526899};\\\", \\\"{x:1452,y:759,t:1527030526915};\\\", \\\"{x:1453,y:759,t:1527030526933};\\\", \\\"{x:1452,y:759,t:1527030527052};\\\", \\\"{x:1451,y:759,t:1527030527077};\\\", \\\"{x:1450,y:760,t:1527030527125};\\\", \\\"{x:1449,y:761,t:1527030527284};\\\", \\\"{x:1448,y:761,t:1527030527300};\\\", \\\"{x:1447,y:761,t:1527030527317};\\\", \\\"{x:1447,y:762,t:1527030527333};\\\", \\\"{x:1446,y:762,t:1527030527351};\\\", \\\"{x:1445,y:764,t:1527030527367};\\\", \\\"{x:1445,y:765,t:1527030527437};\\\", \\\"{x:1444,y:766,t:1527030530892};\\\", \\\"{x:1441,y:766,t:1527030530903};\\\", \\\"{x:1434,y:765,t:1527030530920};\\\", \\\"{x:1430,y:762,t:1527030530936};\\\", \\\"{x:1430,y:763,t:1527030531445};\\\", \\\"{x:1430,y:765,t:1527030531454};\\\", \\\"{x:1437,y:772,t:1527030531469};\\\", \\\"{x:1453,y:776,t:1527030531487};\\\", \\\"{x:1472,y:778,t:1527030531503};\\\", \\\"{x:1485,y:780,t:1527030531521};\\\", \\\"{x:1497,y:780,t:1527030531537};\\\", \\\"{x:1505,y:780,t:1527030531554};\\\", \\\"{x:1503,y:780,t:1527030531645};\\\", \\\"{x:1502,y:780,t:1527030531654};\\\", \\\"{x:1499,y:777,t:1527030531670};\\\", \\\"{x:1497,y:777,t:1527030531687};\\\", \\\"{x:1492,y:775,t:1527030531703};\\\", \\\"{x:1490,y:774,t:1527030531720};\\\", \\\"{x:1488,y:773,t:1527030531737};\\\", \\\"{x:1486,y:773,t:1527030531753};\\\", \\\"{x:1484,y:772,t:1527030531788};\\\", \\\"{x:1483,y:772,t:1527030531803};\\\", \\\"{x:1477,y:772,t:1527030531820};\\\", \\\"{x:1471,y:772,t:1527030531838};\\\", \\\"{x:1466,y:772,t:1527030531853};\\\", \\\"{x:1462,y:772,t:1527030531870};\\\", \\\"{x:1461,y:772,t:1527030531887};\\\", \\\"{x:1462,y:772,t:1527030532228};\\\", \\\"{x:1463,y:772,t:1527030532476};\\\", \\\"{x:1465,y:772,t:1527030532488};\\\", \\\"{x:1471,y:772,t:1527030532505};\\\", \\\"{x:1475,y:772,t:1527030532520};\\\", \\\"{x:1479,y:772,t:1527030532537};\\\", \\\"{x:1481,y:770,t:1527030532555};\\\", \\\"{x:1483,y:770,t:1527030532570};\\\", \\\"{x:1484,y:770,t:1527030532587};\\\", \\\"{x:1486,y:769,t:1527030532603};\\\", \\\"{x:1488,y:769,t:1527030532620};\\\", \\\"{x:1491,y:767,t:1527030532638};\\\", \\\"{x:1496,y:767,t:1527030532655};\\\", \\\"{x:1501,y:766,t:1527030532671};\\\", \\\"{x:1504,y:766,t:1527030532687};\\\", \\\"{x:1505,y:766,t:1527030532705};\\\", \\\"{x:1506,y:766,t:1527030533764};\\\", \\\"{x:1508,y:766,t:1527030533770};\\\", \\\"{x:1516,y:769,t:1527030533788};\\\", \\\"{x:1521,y:771,t:1527030533805};\\\", \\\"{x:1522,y:772,t:1527030533821};\\\", \\\"{x:1524,y:772,t:1527030533838};\\\", \\\"{x:1525,y:772,t:1527030533854};\\\", \\\"{x:1526,y:772,t:1527030534028};\\\", \\\"{x:1527,y:772,t:1527030534039};\\\", \\\"{x:1528,y:772,t:1527030534056};\\\", \\\"{x:1529,y:772,t:1527030534073};\\\", \\\"{x:1530,y:772,t:1527030534089};\\\", \\\"{x:1531,y:772,t:1527030534106};\\\", \\\"{x:1533,y:772,t:1527030534123};\\\", \\\"{x:1534,y:772,t:1527030534139};\\\", \\\"{x:1536,y:772,t:1527030534741};\\\", \\\"{x:1540,y:772,t:1527030534757};\\\", \\\"{x:1541,y:772,t:1527030534773};\\\", \\\"{x:1543,y:772,t:1527030534790};\\\", \\\"{x:1546,y:771,t:1527030534806};\\\", \\\"{x:1549,y:769,t:1527030534823};\\\", \\\"{x:1550,y:769,t:1527030534852};\\\", \\\"{x:1550,y:768,t:1527030534924};\\\", \\\"{x:1551,y:767,t:1527030535060};\\\", \\\"{x:1552,y:767,t:1527030535073};\\\", \\\"{x:1551,y:766,t:1527030535476};\\\", \\\"{x:1550,y:766,t:1527030535490};\\\", \\\"{x:1549,y:766,t:1527030535507};\\\", \\\"{x:1548,y:765,t:1527030535523};\\\", \\\"{x:1547,y:765,t:1527030535548};\\\", \\\"{x:1547,y:764,t:1527030535572};\\\", \\\"{x:1546,y:763,t:1527030535580};\\\", \\\"{x:1545,y:763,t:1527030535612};\\\", \\\"{x:1544,y:763,t:1527030535624};\\\", \\\"{x:1543,y:762,t:1527030535972};\\\", \\\"{x:1540,y:762,t:1527030535980};\\\", \\\"{x:1536,y:764,t:1527030535990};\\\", \\\"{x:1527,y:767,t:1527030536006};\\\", \\\"{x:1521,y:771,t:1527030536023};\\\", \\\"{x:1508,y:778,t:1527030536040};\\\", \\\"{x:1492,y:787,t:1527030536057};\\\", \\\"{x:1481,y:793,t:1527030536073};\\\", \\\"{x:1469,y:799,t:1527030536090};\\\", \\\"{x:1455,y:806,t:1527030536106};\\\", \\\"{x:1443,y:812,t:1527030536123};\\\", \\\"{x:1434,y:817,t:1527030536140};\\\", \\\"{x:1426,y:821,t:1527030536157};\\\", \\\"{x:1420,y:824,t:1527030536173};\\\", \\\"{x:1416,y:826,t:1527030536190};\\\", \\\"{x:1409,y:830,t:1527030536206};\\\", \\\"{x:1403,y:834,t:1527030536224};\\\", \\\"{x:1396,y:838,t:1527030536240};\\\", \\\"{x:1389,y:842,t:1527030536258};\\\", \\\"{x:1382,y:846,t:1527030536274};\\\", \\\"{x:1377,y:848,t:1527030536290};\\\", \\\"{x:1374,y:850,t:1527030536308};\\\", \\\"{x:1372,y:850,t:1527030536323};\\\", \\\"{x:1371,y:850,t:1527030536348};\\\", \\\"{x:1368,y:850,t:1527030536358};\\\", \\\"{x:1360,y:848,t:1527030536374};\\\", \\\"{x:1344,y:841,t:1527030536391};\\\", \\\"{x:1326,y:834,t:1527030536407};\\\", \\\"{x:1309,y:826,t:1527030536423};\\\", \\\"{x:1300,y:822,t:1527030536440};\\\", \\\"{x:1296,y:821,t:1527030536457};\\\", \\\"{x:1296,y:820,t:1527030536484};\\\", \\\"{x:1295,y:820,t:1527030536500};\\\", \\\"{x:1296,y:818,t:1527030536821};\\\", \\\"{x:1302,y:814,t:1527030536828};\\\", \\\"{x:1308,y:810,t:1527030536840};\\\", \\\"{x:1324,y:802,t:1527030536857};\\\", \\\"{x:1341,y:792,t:1527030536874};\\\", \\\"{x:1354,y:786,t:1527030536890};\\\", \\\"{x:1368,y:780,t:1527030536907};\\\", \\\"{x:1374,y:777,t:1527030536924};\\\", \\\"{x:1378,y:775,t:1527030536940};\\\", \\\"{x:1384,y:772,t:1527030536957};\\\", \\\"{x:1388,y:770,t:1527030536974};\\\", \\\"{x:1390,y:769,t:1527030536991};\\\", \\\"{x:1388,y:769,t:1527030537461};\\\", \\\"{x:1380,y:769,t:1527030537475};\\\", \\\"{x:1367,y:769,t:1527030537492};\\\", \\\"{x:1363,y:769,t:1527030537508};\\\", \\\"{x:1360,y:769,t:1527030537525};\\\", \\\"{x:1355,y:769,t:1527030537541};\\\", \\\"{x:1348,y:771,t:1527030537558};\\\", \\\"{x:1340,y:772,t:1527030537575};\\\", \\\"{x:1329,y:773,t:1527030537592};\\\", \\\"{x:1320,y:774,t:1527030537609};\\\", \\\"{x:1313,y:776,t:1527030537626};\\\", \\\"{x:1305,y:777,t:1527030537642};\\\", \\\"{x:1298,y:779,t:1527030537658};\\\", \\\"{x:1296,y:780,t:1527030537675};\\\", \\\"{x:1295,y:781,t:1527030537692};\\\", \\\"{x:1297,y:781,t:1527030537764};\\\", \\\"{x:1301,y:781,t:1527030537774};\\\", \\\"{x:1316,y:776,t:1527030537791};\\\", \\\"{x:1334,y:768,t:1527030537808};\\\", \\\"{x:1358,y:757,t:1527030537824};\\\", \\\"{x:1378,y:751,t:1527030537842};\\\", \\\"{x:1391,y:745,t:1527030537859};\\\", \\\"{x:1398,y:741,t:1527030537874};\\\", \\\"{x:1402,y:740,t:1527030537891};\\\", \\\"{x:1404,y:739,t:1527030537908};\\\", \\\"{x:1405,y:738,t:1527030537931};\\\", \\\"{x:1405,y:737,t:1527030537955};\\\", \\\"{x:1405,y:736,t:1527030537963};\\\", \\\"{x:1408,y:731,t:1527030537974};\\\", \\\"{x:1410,y:722,t:1527030537992};\\\", \\\"{x:1413,y:712,t:1527030538008};\\\", \\\"{x:1415,y:696,t:1527030538026};\\\", \\\"{x:1417,y:680,t:1527030538042};\\\", \\\"{x:1419,y:666,t:1527030538059};\\\", \\\"{x:1424,y:644,t:1527030538076};\\\", \\\"{x:1427,y:635,t:1527030538092};\\\", \\\"{x:1428,y:631,t:1527030538109};\\\", \\\"{x:1428,y:630,t:1527030538126};\\\", \\\"{x:1429,y:629,t:1527030538165};\\\", \\\"{x:1428,y:629,t:1527030538596};\\\", \\\"{x:1423,y:628,t:1527030538609};\\\", \\\"{x:1415,y:628,t:1527030538626};\\\", \\\"{x:1398,y:638,t:1527030538643};\\\", \\\"{x:1382,y:652,t:1527030538659};\\\", \\\"{x:1358,y:672,t:1527030538676};\\\", \\\"{x:1348,y:679,t:1527030538693};\\\", \\\"{x:1346,y:680,t:1527030538709};\\\", \\\"{x:1345,y:680,t:1527030538933};\\\", \\\"{x:1345,y:676,t:1527030538943};\\\", \\\"{x:1346,y:669,t:1527030538959};\\\", \\\"{x:1350,y:660,t:1527030538976};\\\", \\\"{x:1352,y:652,t:1527030538993};\\\", \\\"{x:1356,y:645,t:1527030539010};\\\", \\\"{x:1357,y:640,t:1527030539026};\\\", \\\"{x:1357,y:636,t:1527030539043};\\\", \\\"{x:1357,y:630,t:1527030539060};\\\", \\\"{x:1357,y:626,t:1527030539077};\\\", \\\"{x:1354,y:622,t:1527030539093};\\\", \\\"{x:1350,y:619,t:1527030539110};\\\", \\\"{x:1349,y:618,t:1527030539126};\\\", \\\"{x:1348,y:618,t:1527030539143};\\\", \\\"{x:1347,y:618,t:1527030539160};\\\", \\\"{x:1345,y:617,t:1527030539176};\\\", \\\"{x:1343,y:616,t:1527030539193};\\\", \\\"{x:1340,y:615,t:1527030539210};\\\", \\\"{x:1338,y:614,t:1527030539226};\\\", \\\"{x:1337,y:614,t:1527030539243};\\\", \\\"{x:1335,y:614,t:1527030539260};\\\", \\\"{x:1333,y:614,t:1527030539293};\\\", \\\"{x:1332,y:616,t:1527030539310};\\\", \\\"{x:1330,y:619,t:1527030539327};\\\", \\\"{x:1328,y:623,t:1527030539343};\\\", \\\"{x:1327,y:628,t:1527030539360};\\\", \\\"{x:1324,y:632,t:1527030539377};\\\", \\\"{x:1323,y:633,t:1527030539393};\\\", \\\"{x:1322,y:635,t:1527030539410};\\\", \\\"{x:1321,y:635,t:1527030539427};\\\", \\\"{x:1320,y:635,t:1527030539581};\\\", \\\"{x:1319,y:635,t:1527030539596};\\\", \\\"{x:1318,y:635,t:1527030539612};\\\", \\\"{x:1317,y:635,t:1527030539627};\\\", \\\"{x:1315,y:640,t:1527030543261};\\\", \\\"{x:1309,y:664,t:1527030543280};\\\", \\\"{x:1302,y:688,t:1527030543297};\\\", \\\"{x:1295,y:714,t:1527030543313};\\\", \\\"{x:1295,y:739,t:1527030543330};\\\", \\\"{x:1291,y:767,t:1527030543346};\\\", \\\"{x:1291,y:794,t:1527030543363};\\\", \\\"{x:1294,y:830,t:1527030543380};\\\", \\\"{x:1297,y:855,t:1527030543397};\\\", \\\"{x:1302,y:878,t:1527030543413};\\\", \\\"{x:1308,y:903,t:1527030543430};\\\", \\\"{x:1315,y:924,t:1527030543446};\\\", \\\"{x:1319,y:944,t:1527030543463};\\\", \\\"{x:1321,y:957,t:1527030543480};\\\", \\\"{x:1321,y:964,t:1527030543495};\\\", \\\"{x:1321,y:970,t:1527030543512};\\\", \\\"{x:1321,y:972,t:1527030543530};\\\", \\\"{x:1321,y:973,t:1527030543546};\\\", \\\"{x:1321,y:974,t:1527030543563};\\\", \\\"{x:1320,y:971,t:1527030543852};\\\", \\\"{x:1320,y:970,t:1527030543863};\\\", \\\"{x:1320,y:967,t:1527030543880};\\\", \\\"{x:1320,y:964,t:1527030543898};\\\", \\\"{x:1319,y:963,t:1527030543913};\\\", \\\"{x:1319,y:962,t:1527030543931};\\\", \\\"{x:1318,y:961,t:1527030543947};\\\", \\\"{x:1318,y:960,t:1527030543973};\\\", \\\"{x:1318,y:959,t:1527030543997};\\\", \\\"{x:1318,y:957,t:1527030544013};\\\", \\\"{x:1317,y:957,t:1527030544030};\\\", \\\"{x:1316,y:955,t:1527030544047};\\\", \\\"{x:1316,y:951,t:1527030544063};\\\", \\\"{x:1316,y:948,t:1527030544080};\\\", \\\"{x:1313,y:942,t:1527030544097};\\\", \\\"{x:1313,y:941,t:1527030544113};\\\", \\\"{x:1313,y:939,t:1527030544131};\\\", \\\"{x:1313,y:938,t:1527030544147};\\\", \\\"{x:1313,y:937,t:1527030544164};\\\", \\\"{x:1313,y:936,t:1527030544188};\\\", \\\"{x:1312,y:936,t:1527030544236};\\\", \\\"{x:1312,y:928,t:1527030544900};\\\", \\\"{x:1312,y:914,t:1527030544914};\\\", \\\"{x:1312,y:884,t:1527030544931};\\\", \\\"{x:1303,y:837,t:1527030544947};\\\", \\\"{x:1264,y:693,t:1527030544964};\\\", \\\"{x:1239,y:605,t:1527030544981};\\\", \\\"{x:1231,y:520,t:1527030544998};\\\", \\\"{x:1231,y:436,t:1527030545015};\\\", \\\"{x:1242,y:371,t:1527030545031};\\\", \\\"{x:1253,y:340,t:1527030545048};\\\", \\\"{x:1263,y:328,t:1527030545064};\\\", \\\"{x:1273,y:320,t:1527030545081};\\\", \\\"{x:1279,y:316,t:1527030545097};\\\", \\\"{x:1282,y:313,t:1527030545113};\\\", \\\"{x:1285,y:312,t:1527030545130};\\\", \\\"{x:1285,y:311,t:1527030545147};\\\", \\\"{x:1288,y:311,t:1527030545163};\\\", \\\"{x:1293,y:318,t:1527030545181};\\\", \\\"{x:1303,y:336,t:1527030545198};\\\", \\\"{x:1316,y:362,t:1527030545213};\\\", \\\"{x:1329,y:392,t:1527030545231};\\\", \\\"{x:1343,y:430,t:1527030545248};\\\", \\\"{x:1348,y:452,t:1527030545264};\\\", \\\"{x:1354,y:476,t:1527030545280};\\\", \\\"{x:1358,y:495,t:1527030545298};\\\", \\\"{x:1362,y:506,t:1527030545314};\\\", \\\"{x:1362,y:511,t:1527030545331};\\\", \\\"{x:1363,y:513,t:1527030545347};\\\", \\\"{x:1363,y:515,t:1527030545364};\\\", \\\"{x:1364,y:516,t:1527030545381};\\\", \\\"{x:1365,y:519,t:1527030545398};\\\", \\\"{x:1366,y:521,t:1527030545414};\\\", \\\"{x:1367,y:522,t:1527030545431};\\\", \\\"{x:1369,y:525,t:1527030545628};\\\", \\\"{x:1371,y:527,t:1527030545636};\\\", \\\"{x:1374,y:529,t:1527030545647};\\\", \\\"{x:1376,y:534,t:1527030545664};\\\", \\\"{x:1378,y:538,t:1527030545681};\\\", \\\"{x:1380,y:541,t:1527030545698};\\\", \\\"{x:1382,y:543,t:1527030545715};\\\", \\\"{x:1383,y:544,t:1527030545731};\\\", \\\"{x:1384,y:545,t:1527030545748};\\\", \\\"{x:1386,y:545,t:1527030545764};\\\", \\\"{x:1387,y:545,t:1527030545780};\\\", \\\"{x:1389,y:545,t:1527030545956};\\\", \\\"{x:1393,y:545,t:1527030545965};\\\", \\\"{x:1398,y:548,t:1527030545982};\\\", \\\"{x:1403,y:553,t:1527030545998};\\\", \\\"{x:1405,y:555,t:1527030546015};\\\", \\\"{x:1407,y:559,t:1527030546032};\\\", \\\"{x:1407,y:562,t:1527030546628};\\\", \\\"{x:1407,y:567,t:1527030546636};\\\", \\\"{x:1407,y:572,t:1527030546649};\\\", \\\"{x:1407,y:589,t:1527030546665};\\\", \\\"{x:1407,y:604,t:1527030546682};\\\", \\\"{x:1405,y:622,t:1527030546699};\\\", \\\"{x:1404,y:640,t:1527030546715};\\\", \\\"{x:1404,y:667,t:1527030546732};\\\", \\\"{x:1402,y:684,t:1527030546750};\\\", \\\"{x:1400,y:698,t:1527030546765};\\\", \\\"{x:1398,y:712,t:1527030546783};\\\", \\\"{x:1397,y:722,t:1527030546799};\\\", \\\"{x:1395,y:730,t:1527030546816};\\\", \\\"{x:1395,y:736,t:1527030546833};\\\", \\\"{x:1395,y:739,t:1527030546848};\\\", \\\"{x:1395,y:741,t:1527030546866};\\\", \\\"{x:1395,y:743,t:1527030546881};\\\", \\\"{x:1395,y:744,t:1527030546907};\\\", \\\"{x:1395,y:745,t:1527030546931};\\\", \\\"{x:1395,y:747,t:1527030546949};\\\", \\\"{x:1393,y:753,t:1527030546966};\\\", \\\"{x:1390,y:761,t:1527030546982};\\\", \\\"{x:1385,y:771,t:1527030546999};\\\", \\\"{x:1376,y:785,t:1527030547016};\\\", \\\"{x:1371,y:794,t:1527030547032};\\\", \\\"{x:1365,y:805,t:1527030547049};\\\", \\\"{x:1360,y:813,t:1527030547065};\\\", \\\"{x:1355,y:825,t:1527030547082};\\\", \\\"{x:1351,y:830,t:1527030547099};\\\", \\\"{x:1344,y:840,t:1527030547115};\\\", \\\"{x:1341,y:843,t:1527030547132};\\\", \\\"{x:1338,y:844,t:1527030547149};\\\", \\\"{x:1337,y:845,t:1527030547166};\\\", \\\"{x:1336,y:845,t:1527030547204};\\\", \\\"{x:1335,y:845,t:1527030547219};\\\", \\\"{x:1334,y:845,t:1527030547234};\\\", \\\"{x:1333,y:845,t:1527030547249};\\\", \\\"{x:1330,y:843,t:1527030547265};\\\", \\\"{x:1323,y:841,t:1527030547284};\\\", \\\"{x:1320,y:839,t:1527030547299};\\\", \\\"{x:1308,y:836,t:1527030547316};\\\", \\\"{x:1299,y:834,t:1527030547333};\\\", \\\"{x:1288,y:831,t:1527030547350};\\\", \\\"{x:1280,y:828,t:1527030547367};\\\", \\\"{x:1277,y:827,t:1527030547383};\\\", \\\"{x:1275,y:826,t:1527030547400};\\\", \\\"{x:1276,y:826,t:1527030547757};\\\", \\\"{x:1282,y:815,t:1527030552637};\\\", \\\"{x:1300,y:758,t:1527030552653};\\\", \\\"{x:1331,y:674,t:1527030552670};\\\", \\\"{x:1361,y:574,t:1527030552687};\\\", \\\"{x:1397,y:481,t:1527030552702};\\\", \\\"{x:1431,y:398,t:1527030552720};\\\", \\\"{x:1466,y:348,t:1527030552737};\\\", \\\"{x:1491,y:318,t:1527030552753};\\\", \\\"{x:1510,y:300,t:1527030552770};\\\", \\\"{x:1524,y:290,t:1527030552787};\\\", \\\"{x:1527,y:287,t:1527030552803};\\\", \\\"{x:1530,y:286,t:1527030552820};\\\", \\\"{x:1533,y:285,t:1527030552837};\\\", \\\"{x:1529,y:289,t:1527030552907};\\\", \\\"{x:1521,y:298,t:1527030552920};\\\", \\\"{x:1503,y:318,t:1527030552937};\\\", \\\"{x:1482,y:350,t:1527030552954};\\\", \\\"{x:1464,y:375,t:1527030552971};\\\", \\\"{x:1441,y:405,t:1527030552987};\\\", \\\"{x:1426,y:420,t:1527030553003};\\\", \\\"{x:1415,y:427,t:1527030553021};\\\", \\\"{x:1405,y:430,t:1527030553037};\\\", \\\"{x:1398,y:431,t:1527030553054};\\\", \\\"{x:1394,y:431,t:1527030553070};\\\", \\\"{x:1393,y:431,t:1527030553500};\\\", \\\"{x:1397,y:428,t:1527030553507};\\\", \\\"{x:1410,y:422,t:1527030553521};\\\", \\\"{x:1424,y:417,t:1527030553538};\\\", \\\"{x:1429,y:414,t:1527030553554};\\\", \\\"{x:1433,y:413,t:1527030553571};\\\", \\\"{x:1434,y:413,t:1527030553586};\\\", \\\"{x:1433,y:415,t:1527030553764};\\\", \\\"{x:1433,y:417,t:1527030553771};\\\", \\\"{x:1430,y:419,t:1527030553787};\\\", \\\"{x:1428,y:421,t:1527030553804};\\\", \\\"{x:1427,y:423,t:1527030553821};\\\", \\\"{x:1426,y:424,t:1527030553875};\\\", \\\"{x:1425,y:426,t:1527030554068};\\\", \\\"{x:1421,y:427,t:1527030554076};\\\", \\\"{x:1418,y:429,t:1527030554089};\\\", \\\"{x:1410,y:433,t:1527030554104};\\\", \\\"{x:1402,y:434,t:1527030554122};\\\", \\\"{x:1400,y:436,t:1527030554139};\\\", \\\"{x:1400,y:435,t:1527030555125};\\\", \\\"{x:1402,y:434,t:1527030555139};\\\", \\\"{x:1403,y:433,t:1527030555156};\\\", \\\"{x:1404,y:433,t:1527030555172};\\\", \\\"{x:1405,y:432,t:1527030555190};\\\", \\\"{x:1407,y:432,t:1527030555636};\\\", \\\"{x:1409,y:432,t:1527030555644};\\\", \\\"{x:1412,y:430,t:1527030555656};\\\", \\\"{x:1420,y:428,t:1527030555672};\\\", \\\"{x:1425,y:425,t:1527030555690};\\\", \\\"{x:1429,y:423,t:1527030555706};\\\", \\\"{x:1430,y:423,t:1527030555723};\\\", \\\"{x:1429,y:423,t:1527030555947};\\\", \\\"{x:1427,y:423,t:1527030555956};\\\", \\\"{x:1427,y:424,t:1527030556557};\\\", \\\"{x:1424,y:426,t:1527030556573};\\\", \\\"{x:1422,y:427,t:1527030556590};\\\", \\\"{x:1420,y:428,t:1527030556607};\\\", \\\"{x:1418,y:429,t:1527030556640};\\\", \\\"{x:1417,y:429,t:1527030556941};\\\", \\\"{x:1416,y:437,t:1527030559285};\\\", \\\"{x:1416,y:450,t:1527030559292};\\\", \\\"{x:1416,y:491,t:1527030559308};\\\", \\\"{x:1416,y:536,t:1527030559326};\\\", \\\"{x:1411,y:578,t:1527030559342};\\\", \\\"{x:1406,y:610,t:1527030559359};\\\", \\\"{x:1401,y:639,t:1527030559376};\\\", \\\"{x:1399,y:667,t:1527030559393};\\\", \\\"{x:1399,y:693,t:1527030559408};\\\", \\\"{x:1399,y:716,t:1527030559426};\\\", \\\"{x:1399,y:739,t:1527030559443};\\\", \\\"{x:1399,y:766,t:1527030559458};\\\", \\\"{x:1399,y:799,t:1527030559476};\\\", \\\"{x:1399,y:819,t:1527030559493};\\\", \\\"{x:1399,y:836,t:1527030559509};\\\", \\\"{x:1399,y:851,t:1527030559525};\\\", \\\"{x:1399,y:862,t:1527030559543};\\\", \\\"{x:1399,y:874,t:1527030559559};\\\", \\\"{x:1399,y:884,t:1527030559576};\\\", \\\"{x:1398,y:897,t:1527030559592};\\\", \\\"{x:1398,y:905,t:1527030559610};\\\", \\\"{x:1398,y:913,t:1527030559626};\\\", \\\"{x:1398,y:920,t:1527030559642};\\\", \\\"{x:1398,y:930,t:1527030559659};\\\", \\\"{x:1398,y:934,t:1527030559676};\\\", \\\"{x:1398,y:935,t:1527030559707};\\\", \\\"{x:1399,y:938,t:1527030559764};\\\", \\\"{x:1399,y:940,t:1527030559780};\\\", \\\"{x:1399,y:942,t:1527030559792};\\\", \\\"{x:1400,y:944,t:1527030559810};\\\", \\\"{x:1400,y:949,t:1527030559826};\\\", \\\"{x:1400,y:955,t:1527030559842};\\\", \\\"{x:1403,y:963,t:1527030559859};\\\", \\\"{x:1404,y:966,t:1527030559876};\\\", \\\"{x:1410,y:928,t:1527030567266};\\\", \\\"{x:1419,y:863,t:1527030567279};\\\", \\\"{x:1431,y:742,t:1527030567297};\\\", \\\"{x:1431,y:667,t:1527030567312};\\\", \\\"{x:1431,y:615,t:1527030567329};\\\", \\\"{x:1431,y:595,t:1527030567346};\\\", \\\"{x:1431,y:580,t:1527030567362};\\\", \\\"{x:1432,y:567,t:1527030567379};\\\", \\\"{x:1435,y:555,t:1527030567396};\\\", \\\"{x:1437,y:550,t:1527030567412};\\\", \\\"{x:1437,y:549,t:1527030567433};\\\", \\\"{x:1437,y:548,t:1527030567446};\\\", \\\"{x:1438,y:547,t:1527030567463};\\\", \\\"{x:1439,y:546,t:1527030567479};\\\", \\\"{x:1439,y:539,t:1527030567746};\\\", \\\"{x:1419,y:515,t:1527030567763};\\\", \\\"{x:1397,y:503,t:1527030567779};\\\", \\\"{x:1380,y:494,t:1527030567796};\\\", \\\"{x:1366,y:492,t:1527030567814};\\\", \\\"{x:1354,y:491,t:1527030567830};\\\", \\\"{x:1349,y:491,t:1527030567847};\\\", \\\"{x:1348,y:491,t:1527030567863};\\\", \\\"{x:1348,y:490,t:1527030567953};\\\", \\\"{x:1349,y:489,t:1527030567963};\\\", \\\"{x:1355,y:488,t:1527030567980};\\\", \\\"{x:1360,y:485,t:1527030567996};\\\", \\\"{x:1364,y:485,t:1527030568013};\\\", \\\"{x:1366,y:485,t:1527030568031};\\\", \\\"{x:1368,y:484,t:1527030568046};\\\", \\\"{x:1372,y:484,t:1527030568064};\\\", \\\"{x:1373,y:483,t:1527030568080};\\\", \\\"{x:1377,y:481,t:1527030568097};\\\", \\\"{x:1381,y:478,t:1527030568113};\\\", \\\"{x:1385,y:476,t:1527030568130};\\\", \\\"{x:1389,y:471,t:1527030568147};\\\", \\\"{x:1394,y:465,t:1527030568164};\\\", \\\"{x:1400,y:455,t:1527030568180};\\\", \\\"{x:1405,y:444,t:1527030568196};\\\", \\\"{x:1409,y:436,t:1527030568213};\\\", \\\"{x:1412,y:429,t:1527030568231};\\\", \\\"{x:1414,y:424,t:1527030568247};\\\", \\\"{x:1415,y:422,t:1527030568263};\\\", \\\"{x:1416,y:421,t:1527030568281};\\\", \\\"{x:1416,y:420,t:1527030568529};\\\", \\\"{x:1413,y:423,t:1527030568548};\\\", \\\"{x:1409,y:430,t:1527030568564};\\\", \\\"{x:1405,y:434,t:1527030568582};\\\", \\\"{x:1403,y:439,t:1527030568597};\\\", \\\"{x:1402,y:442,t:1527030568613};\\\", \\\"{x:1402,y:443,t:1527030569170};\\\", \\\"{x:1403,y:443,t:1527030569181};\\\", \\\"{x:1404,y:441,t:1527030569197};\\\", \\\"{x:1404,y:439,t:1527030569214};\\\", \\\"{x:1404,y:438,t:1527030569232};\\\", \\\"{x:1405,y:436,t:1527030569247};\\\", \\\"{x:1406,y:436,t:1527030569265};\\\", \\\"{x:1406,y:432,t:1527030569281};\\\", \\\"{x:1407,y:431,t:1527030569305};\\\", \\\"{x:1407,y:430,t:1527030569321};\\\", \\\"{x:1407,y:429,t:1527030569332};\\\", \\\"{x:1409,y:428,t:1527030569348};\\\", \\\"{x:1409,y:427,t:1527030569364};\\\", \\\"{x:1410,y:427,t:1527030569381};\\\", \\\"{x:1412,y:425,t:1527030569398};\\\", \\\"{x:1412,y:423,t:1527030569416};\\\", \\\"{x:1413,y:423,t:1527030569432};\\\", \\\"{x:1414,y:423,t:1527030569472};\\\", \\\"{x:1415,y:423,t:1527030569481};\\\", \\\"{x:1418,y:423,t:1527030569497};\\\", \\\"{x:1423,y:424,t:1527030569515};\\\", \\\"{x:1431,y:427,t:1527030569531};\\\", \\\"{x:1437,y:428,t:1527030569548};\\\", \\\"{x:1442,y:428,t:1527030569564};\\\", \\\"{x:1452,y:429,t:1527030569582};\\\", \\\"{x:1459,y:431,t:1527030569598};\\\", \\\"{x:1473,y:432,t:1527030569615};\\\", \\\"{x:1488,y:433,t:1527030569632};\\\", \\\"{x:1503,y:433,t:1527030569647};\\\", \\\"{x:1516,y:433,t:1527030569665};\\\", \\\"{x:1518,y:433,t:1527030569682};\\\", \\\"{x:1519,y:433,t:1527030569699};\\\", \\\"{x:1521,y:433,t:1527030569866};\\\", \\\"{x:1527,y:433,t:1527030569881};\\\", \\\"{x:1535,y:433,t:1527030569898};\\\", \\\"{x:1547,y:432,t:1527030569915};\\\", \\\"{x:1564,y:432,t:1527030569931};\\\", \\\"{x:1577,y:431,t:1527030569949};\\\", \\\"{x:1587,y:431,t:1527030569965};\\\", \\\"{x:1594,y:431,t:1527030569981};\\\", \\\"{x:1601,y:431,t:1527030569998};\\\", \\\"{x:1606,y:431,t:1527030570015};\\\", \\\"{x:1607,y:431,t:1527030570032};\\\", \\\"{x:1608,y:431,t:1527030570049};\\\", \\\"{x:1609,y:430,t:1527030570290};\\\", \\\"{x:1610,y:430,t:1527030570298};\\\", \\\"{x:1613,y:428,t:1527030570315};\\\", \\\"{x:1614,y:428,t:1527030570336};\\\", \\\"{x:1611,y:428,t:1527030571593};\\\", \\\"{x:1599,y:426,t:1527030571601};\\\", \\\"{x:1577,y:422,t:1527030571615};\\\", \\\"{x:1557,y:418,t:1527030571632};\\\", \\\"{x:1539,y:416,t:1527030571649};\\\", \\\"{x:1524,y:415,t:1527030571666};\\\", \\\"{x:1511,y:415,t:1527030571682};\\\", \\\"{x:1503,y:415,t:1527030571699};\\\", \\\"{x:1497,y:415,t:1527030571716};\\\", \\\"{x:1489,y:416,t:1527030571732};\\\", \\\"{x:1478,y:421,t:1527030571749};\\\", \\\"{x:1464,y:428,t:1527030571766};\\\", \\\"{x:1448,y:435,t:1527030571782};\\\", \\\"{x:1437,y:440,t:1527030571799};\\\", \\\"{x:1433,y:442,t:1527030571816};\\\", \\\"{x:1432,y:442,t:1527030571985};\\\", \\\"{x:1430,y:442,t:1527030571999};\\\", \\\"{x:1418,y:438,t:1527030572016};\\\", \\\"{x:1412,y:433,t:1527030572032};\\\", \\\"{x:1410,y:431,t:1527030572049};\\\", \\\"{x:1410,y:430,t:1527030572066};\\\", \\\"{x:1409,y:430,t:1527030572280};\\\", \\\"{x:1409,y:431,t:1527030572287};\\\", \\\"{x:1409,y:432,t:1527030572300};\\\", \\\"{x:1409,y:434,t:1527030572316};\\\", \\\"{x:1409,y:436,t:1527030572333};\\\", \\\"{x:1409,y:437,t:1527030572349};\\\", \\\"{x:1409,y:436,t:1527030572712};\\\", \\\"{x:1409,y:435,t:1527030572721};\\\", \\\"{x:1409,y:433,t:1527030572737};\\\", \\\"{x:1409,y:431,t:1527030572751};\\\", \\\"{x:1410,y:429,t:1527030572767};\\\", \\\"{x:1410,y:426,t:1527030572783};\\\", \\\"{x:1410,y:424,t:1527030572801};\\\", \\\"{x:1414,y:413,t:1527030574026};\\\", \\\"{x:1425,y:377,t:1527030574035};\\\", \\\"{x:1456,y:290,t:1527030574051};\\\", \\\"{x:1487,y:198,t:1527030574067};\\\", \\\"{x:1516,y:111,t:1527030574085};\\\", \\\"{x:1534,y:74,t:1527030574101};\\\", \\\"{x:1553,y:51,t:1527030574118};\\\", \\\"{x:1564,y:37,t:1527030574134};\\\", \\\"{x:1568,y:31,t:1527030574152};\\\", \\\"{x:1568,y:30,t:1527030574167};\\\", \\\"{x:1567,y:30,t:1527030574249};\\\", \\\"{x:1560,y:32,t:1527030574256};\\\", \\\"{x:1552,y:37,t:1527030574268};\\\", \\\"{x:1531,y:53,t:1527030574284};\\\", \\\"{x:1509,y:94,t:1527030574301};\\\", \\\"{x:1496,y:139,t:1527030574318};\\\", \\\"{x:1487,y:167,t:1527030574334};\\\", \\\"{x:1482,y:184,t:1527030574352};\\\", \\\"{x:1482,y:190,t:1527030574369};\\\", \\\"{x:1482,y:191,t:1527030574449};\\\", \\\"{x:1483,y:192,t:1527030574553};\\\", \\\"{x:1485,y:192,t:1527030574569};\\\", \\\"{x:1487,y:193,t:1527030574585};\\\", \\\"{x:1491,y:193,t:1527030574601};\\\", \\\"{x:1494,y:193,t:1527030574619};\\\", \\\"{x:1497,y:191,t:1527030574635};\\\", \\\"{x:1499,y:190,t:1527030574651};\\\", \\\"{x:1499,y:188,t:1527030574667};\\\", \\\"{x:1499,y:187,t:1527030574684};\\\", \\\"{x:1499,y:184,t:1527030574700};\\\", \\\"{x:1499,y:183,t:1527030574718};\\\", \\\"{x:1499,y:182,t:1527030574735};\\\", \\\"{x:1498,y:180,t:1527030574751};\\\", \\\"{x:1495,y:173,t:1527030574768};\\\", \\\"{x:1493,y:170,t:1527030574785};\\\", \\\"{x:1489,y:166,t:1527030574802};\\\", \\\"{x:1487,y:164,t:1527030574818};\\\", \\\"{x:1485,y:162,t:1527030574836};\\\", \\\"{x:1483,y:168,t:1527030576153};\\\", \\\"{x:1468,y:202,t:1527030576170};\\\", \\\"{x:1452,y:243,t:1527030576187};\\\", \\\"{x:1427,y:283,t:1527030576203};\\\", \\\"{x:1416,y:306,t:1527030576220};\\\", \\\"{x:1412,y:319,t:1527030576236};\\\", \\\"{x:1411,y:323,t:1527030576253};\\\", \\\"{x:1410,y:324,t:1527030576321};\\\", \\\"{x:1410,y:327,t:1527030576353};\\\", \\\"{x:1421,y:355,t:1527030576369};\\\", \\\"{x:1431,y:387,t:1527030576387};\\\", \\\"{x:1445,y:425,t:1527030576404};\\\", \\\"{x:1456,y:469,t:1527030576419};\\\", \\\"{x:1464,y:509,t:1527030576437};\\\", \\\"{x:1464,y:535,t:1527030576453};\\\", \\\"{x:1464,y:558,t:1527030576469};\\\", \\\"{x:1461,y:574,t:1527030576486};\\\", \\\"{x:1455,y:584,t:1527030576503};\\\", \\\"{x:1449,y:590,t:1527030576520};\\\", \\\"{x:1441,y:593,t:1527030576536};\\\", \\\"{x:1440,y:593,t:1527030576554};\\\", \\\"{x:1439,y:593,t:1527030576634};\\\", \\\"{x:1437,y:592,t:1527030576641};\\\", \\\"{x:1435,y:589,t:1527030576653};\\\", \\\"{x:1433,y:585,t:1527030576669};\\\", \\\"{x:1431,y:582,t:1527030576686};\\\", \\\"{x:1429,y:579,t:1527030576703};\\\", \\\"{x:1425,y:575,t:1527030576720};\\\", \\\"{x:1422,y:572,t:1527030576736};\\\", \\\"{x:1420,y:571,t:1527030576754};\\\", \\\"{x:1418,y:570,t:1527030576770};\\\", \\\"{x:1415,y:569,t:1527030576786};\\\", \\\"{x:1413,y:568,t:1527030576804};\\\", \\\"{x:1412,y:568,t:1527030576820};\\\", \\\"{x:1409,y:568,t:1527030576837};\\\", \\\"{x:1406,y:568,t:1527030576854};\\\", \\\"{x:1403,y:569,t:1527030576871};\\\", \\\"{x:1398,y:569,t:1527030576886};\\\", \\\"{x:1390,y:567,t:1527030576903};\\\", \\\"{x:1367,y:552,t:1527030576921};\\\", \\\"{x:1349,y:538,t:1527030576936};\\\", \\\"{x:1336,y:525,t:1527030576954};\\\", \\\"{x:1329,y:519,t:1527030576971};\\\", \\\"{x:1327,y:517,t:1527030576986};\\\", \\\"{x:1327,y:516,t:1527030577003};\\\", \\\"{x:1325,y:513,t:1527030577257};\\\", \\\"{x:1324,y:510,t:1527030577270};\\\", \\\"{x:1321,y:506,t:1527030577287};\\\", \\\"{x:1319,y:505,t:1527030577304};\\\", \\\"{x:1319,y:503,t:1527030577329};\\\", \\\"{x:1319,y:502,t:1527030577344};\\\", \\\"{x:1319,y:500,t:1527030577354};\\\", \\\"{x:1319,y:498,t:1527030577371};\\\", \\\"{x:1319,y:496,t:1527030577387};\\\", \\\"{x:1323,y:493,t:1527030577404};\\\", \\\"{x:1325,y:491,t:1527030577421};\\\", \\\"{x:1328,y:489,t:1527030577438};\\\", \\\"{x:1331,y:488,t:1527030577453};\\\", \\\"{x:1335,y:486,t:1527030577470};\\\", \\\"{x:1339,y:484,t:1527030577487};\\\", \\\"{x:1346,y:481,t:1527030577503};\\\", \\\"{x:1351,y:478,t:1527030577520};\\\", \\\"{x:1354,y:476,t:1527030577537};\\\", \\\"{x:1360,y:473,t:1527030577554};\\\", \\\"{x:1366,y:469,t:1527030577570};\\\", \\\"{x:1371,y:466,t:1527030577586};\\\", \\\"{x:1373,y:464,t:1527030577604};\\\", \\\"{x:1376,y:462,t:1527030577619};\\\", \\\"{x:1377,y:462,t:1527030577636};\\\", \\\"{x:1381,y:460,t:1527030577654};\\\", \\\"{x:1383,y:459,t:1527030577670};\\\", \\\"{x:1385,y:458,t:1527030577687};\\\", \\\"{x:1386,y:458,t:1527030577704};\\\", \\\"{x:1385,y:462,t:1527030577775};\\\", \\\"{x:1378,y:470,t:1527030577787};\\\", \\\"{x:1350,y:502,t:1527030577804};\\\", \\\"{x:1293,y:546,t:1527030577820};\\\", \\\"{x:1189,y:604,t:1527030577837};\\\", \\\"{x:1060,y:658,t:1527030577854};\\\", \\\"{x:938,y:694,t:1527030577870};\\\", \\\"{x:852,y:705,t:1527030577886};\\\", \\\"{x:786,y:708,t:1527030577904};\\\", \\\"{x:767,y:708,t:1527030577920};\\\", \\\"{x:758,y:708,t:1527030577937};\\\", \\\"{x:750,y:705,t:1527030577954};\\\", \\\"{x:742,y:700,t:1527030577970};\\\", \\\"{x:734,y:695,t:1527030577986};\\\", \\\"{x:725,y:688,t:1527030578004};\\\", \\\"{x:715,y:682,t:1527030578021};\\\", \\\"{x:701,y:674,t:1527030578037};\\\", \\\"{x:687,y:666,t:1527030578053};\\\", \\\"{x:682,y:661,t:1527030578072};\\\", \\\"{x:681,y:659,t:1527030578087};\\\", \\\"{x:681,y:654,t:1527030578103};\\\", \\\"{x:681,y:647,t:1527030578121};\\\", \\\"{x:681,y:637,t:1527030578138};\\\", \\\"{x:682,y:630,t:1527030578155};\\\", \\\"{x:683,y:621,t:1527030578172};\\\", \\\"{x:683,y:617,t:1527030578188};\\\", \\\"{x:683,y:612,t:1527030578205};\\\", \\\"{x:683,y:609,t:1527030578221};\\\", \\\"{x:683,y:608,t:1527030578238};\\\", \\\"{x:683,y:605,t:1527030578254};\\\", \\\"{x:683,y:603,t:1527030578271};\\\", \\\"{x:683,y:600,t:1527030578288};\\\", \\\"{x:683,y:597,t:1527030578305};\\\", \\\"{x:683,y:595,t:1527030578322};\\\", \\\"{x:683,y:593,t:1527030578338};\\\", \\\"{x:683,y:592,t:1527030578355};\\\", \\\"{x:684,y:592,t:1527030578440};\\\", \\\"{x:692,y:593,t:1527030578456};\\\", \\\"{x:722,y:600,t:1527030578472};\\\", \\\"{x:764,y:606,t:1527030578488};\\\", \\\"{x:785,y:606,t:1527030578505};\\\", \\\"{x:801,y:606,t:1527030578522};\\\", \\\"{x:811,y:606,t:1527030578538};\\\", \\\"{x:814,y:606,t:1527030578555};\\\", \\\"{x:816,y:606,t:1527030578572};\\\", \\\"{x:817,y:605,t:1527030578608};\\\", \\\"{x:817,y:604,t:1527030578622};\\\", \\\"{x:820,y:601,t:1527030578639};\\\", \\\"{x:822,y:594,t:1527030578655};\\\", \\\"{x:826,y:582,t:1527030578672};\\\", \\\"{x:829,y:574,t:1527030578689};\\\", \\\"{x:832,y:569,t:1527030578705};\\\", \\\"{x:833,y:567,t:1527030578722};\\\", \\\"{x:834,y:567,t:1527030579535};\\\", \\\"{x:835,y:567,t:1527030579552};\\\", \\\"{x:837,y:567,t:1527030579559};\\\", \\\"{x:839,y:569,t:1527030579573};\\\", \\\"{x:843,y:573,t:1527030579589};\\\", \\\"{x:849,y:578,t:1527030579606};\\\", \\\"{x:861,y:581,t:1527030579622};\\\", \\\"{x:871,y:584,t:1527030579639};\\\", \\\"{x:892,y:586,t:1527030579656};\\\", \\\"{x:907,y:589,t:1527030579674};\\\", \\\"{x:923,y:590,t:1527030579689};\\\", \\\"{x:938,y:590,t:1527030579706};\\\", \\\"{x:951,y:590,t:1527030579723};\\\", \\\"{x:962,y:590,t:1527030579739};\\\", \\\"{x:970,y:590,t:1527030579757};\\\", \\\"{x:980,y:590,t:1527030579773};\\\", \\\"{x:987,y:590,t:1527030579789};\\\", \\\"{x:994,y:590,t:1527030579806};\\\", \\\"{x:998,y:591,t:1527030579823};\\\", \\\"{x:1001,y:591,t:1527030579839};\\\", \\\"{x:1008,y:591,t:1527030579857};\\\", \\\"{x:1014,y:592,t:1527030579873};\\\", \\\"{x:1026,y:594,t:1527030579890};\\\", \\\"{x:1038,y:595,t:1527030579906};\\\", \\\"{x:1052,y:597,t:1527030579923};\\\", \\\"{x:1067,y:600,t:1527030579939};\\\", \\\"{x:1083,y:602,t:1527030579957};\\\", \\\"{x:1102,y:605,t:1527030579973};\\\", \\\"{x:1128,y:608,t:1527030579990};\\\", \\\"{x:1152,y:612,t:1527030580007};\\\", \\\"{x:1180,y:617,t:1527030580024};\\\", \\\"{x:1207,y:619,t:1527030580040};\\\", \\\"{x:1242,y:625,t:1527030580056};\\\", \\\"{x:1270,y:633,t:1527030580073};\\\", \\\"{x:1290,y:638,t:1527030580090};\\\", \\\"{x:1299,y:640,t:1527030580106};\\\", \\\"{x:1303,y:642,t:1527030580124};\\\", \\\"{x:1305,y:643,t:1527030580139};\\\", \\\"{x:1309,y:638,t:1527030580353};\\\", \\\"{x:1314,y:628,t:1527030580361};\\\", \\\"{x:1320,y:614,t:1527030580375};\\\", \\\"{x:1321,y:604,t:1527030580391};\\\", \\\"{x:1321,y:600,t:1527030580913};\\\", \\\"{x:1319,y:592,t:1527030580924};\\\", \\\"{x:1319,y:576,t:1527030580941};\\\", \\\"{x:1320,y:559,t:1527030580958};\\\", \\\"{x:1320,y:552,t:1527030580974};\\\", \\\"{x:1320,y:549,t:1527030580991};\\\", \\\"{x:1317,y:549,t:1527030581041};\\\", \\\"{x:1306,y:562,t:1527030581058};\\\", \\\"{x:1294,y:577,t:1527030581074};\\\", \\\"{x:1281,y:595,t:1527030581091};\\\", \\\"{x:1266,y:617,t:1527030581108};\\\", \\\"{x:1250,y:636,t:1527030581124};\\\", \\\"{x:1237,y:651,t:1527030581141};\\\", \\\"{x:1230,y:667,t:1527030581158};\\\", \\\"{x:1228,y:673,t:1527030581174};\\\", \\\"{x:1228,y:680,t:1527030581190};\\\", \\\"{x:1228,y:687,t:1527030581207};\\\", \\\"{x:1227,y:693,t:1527030581224};\\\", \\\"{x:1231,y:693,t:1527030581673};\\\", \\\"{x:1232,y:693,t:1527030581681};\\\", \\\"{x:1236,y:691,t:1527030581691};\\\", \\\"{x:1241,y:689,t:1527030581708};\\\", \\\"{x:1248,y:686,t:1527030581725};\\\", \\\"{x:1255,y:682,t:1527030581741};\\\", \\\"{x:1264,y:679,t:1527030581757};\\\", \\\"{x:1271,y:676,t:1527030581775};\\\", \\\"{x:1273,y:675,t:1527030581792};\\\", \\\"{x:1275,y:674,t:1527030581808};\\\", \\\"{x:1275,y:679,t:1527030581848};\\\", \\\"{x:1275,y:690,t:1527030581858};\\\", \\\"{x:1279,y:718,t:1527030581875};\\\", \\\"{x:1280,y:743,t:1527030581892};\\\", \\\"{x:1280,y:761,t:1527030581908};\\\", \\\"{x:1280,y:772,t:1527030581924};\\\", \\\"{x:1281,y:778,t:1527030581941};\\\", \\\"{x:1283,y:785,t:1527030581957};\\\", \\\"{x:1285,y:794,t:1527030581975};\\\", \\\"{x:1288,y:802,t:1527030581992};\\\", \\\"{x:1289,y:806,t:1527030582009};\\\", \\\"{x:1289,y:809,t:1527030582025};\\\", \\\"{x:1290,y:809,t:1527030582064};\\\", \\\"{x:1290,y:810,t:1527030582113};\\\", \\\"{x:1290,y:812,t:1527030582129};\\\", \\\"{x:1290,y:813,t:1527030582142};\\\", \\\"{x:1290,y:816,t:1527030582158};\\\", \\\"{x:1290,y:820,t:1527030582175};\\\", \\\"{x:1286,y:828,t:1527030582192};\\\", \\\"{x:1284,y:833,t:1527030582207};\\\", \\\"{x:1281,y:840,t:1527030582225};\\\", \\\"{x:1279,y:844,t:1527030582242};\\\", \\\"{x:1278,y:845,t:1527030582257};\\\", \\\"{x:1277,y:846,t:1527030582274};\\\", \\\"{x:1276,y:846,t:1527030582291};\\\", \\\"{x:1275,y:846,t:1527030582311};\\\", \\\"{x:1273,y:846,t:1527030582327};\\\", \\\"{x:1272,y:847,t:1527030582341};\\\", \\\"{x:1271,y:847,t:1527030582359};\\\", \\\"{x:1269,y:847,t:1527030582375};\\\", \\\"{x:1268,y:847,t:1527030582399};\\\", \\\"{x:1267,y:847,t:1527030582465};\\\", \\\"{x:1267,y:846,t:1527030582475};\\\", \\\"{x:1267,y:844,t:1527030582491};\\\", \\\"{x:1267,y:841,t:1527030582508};\\\", \\\"{x:1267,y:840,t:1527030582525};\\\", \\\"{x:1270,y:836,t:1527030582542};\\\", \\\"{x:1271,y:835,t:1527030582559};\\\", \\\"{x:1273,y:833,t:1527030582575};\\\", \\\"{x:1276,y:832,t:1527030582592};\\\", \\\"{x:1279,y:830,t:1527030582609};\\\", \\\"{x:1280,y:829,t:1527030582625};\\\", \\\"{x:1284,y:828,t:1527030582642};\\\", \\\"{x:1285,y:827,t:1527030582659};\\\", \\\"{x:1286,y:826,t:1527030582676};\\\", \\\"{x:1287,y:825,t:1527030582691};\\\", \\\"{x:1289,y:824,t:1527030582709};\\\", \\\"{x:1290,y:823,t:1527030582777};\\\", \\\"{x:1291,y:822,t:1527030582809};\\\", \\\"{x:1291,y:821,t:1527030582826};\\\", \\\"{x:1293,y:819,t:1527030582842};\\\", \\\"{x:1294,y:817,t:1527030582858};\\\", \\\"{x:1296,y:814,t:1527030582875};\\\", \\\"{x:1299,y:811,t:1527030582891};\\\", \\\"{x:1301,y:806,t:1527030582908};\\\", \\\"{x:1308,y:793,t:1527030582925};\\\", \\\"{x:1315,y:775,t:1527030582941};\\\", \\\"{x:1323,y:745,t:1527030582958};\\\", \\\"{x:1332,y:675,t:1527030582976};\\\", \\\"{x:1341,y:584,t:1527030582992};\\\", \\\"{x:1358,y:487,t:1527030583008};\\\", \\\"{x:1370,y:453,t:1527030583025};\\\", \\\"{x:1377,y:437,t:1527030583041};\\\", \\\"{x:1380,y:434,t:1527030583058};\\\", \\\"{x:1381,y:431,t:1527030583075};\\\", \\\"{x:1380,y:432,t:1527030583193};\\\", \\\"{x:1371,y:436,t:1527030583209};\\\", \\\"{x:1366,y:447,t:1527030583226};\\\", \\\"{x:1363,y:456,t:1527030583242};\\\", \\\"{x:1362,y:463,t:1527030583259};\\\", \\\"{x:1360,y:473,t:1527030583276};\\\", \\\"{x:1359,y:478,t:1527030583292};\\\", \\\"{x:1359,y:483,t:1527030583308};\\\", \\\"{x:1358,y:490,t:1527030583326};\\\", \\\"{x:1355,y:496,t:1527030583343};\\\", \\\"{x:1354,y:503,t:1527030583359};\\\", \\\"{x:1354,y:507,t:1527030583376};\\\", \\\"{x:1354,y:518,t:1527030583392};\\\", \\\"{x:1352,y:525,t:1527030583409};\\\", \\\"{x:1352,y:530,t:1527030583426};\\\", \\\"{x:1352,y:534,t:1527030583442};\\\", \\\"{x:1352,y:538,t:1527030583458};\\\", \\\"{x:1352,y:542,t:1527030583476};\\\", \\\"{x:1352,y:547,t:1527030583493};\\\", \\\"{x:1352,y:550,t:1527030583509};\\\", \\\"{x:1352,y:554,t:1527030583525};\\\", \\\"{x:1351,y:557,t:1527030583543};\\\", \\\"{x:1351,y:559,t:1527030583559};\\\", \\\"{x:1351,y:560,t:1527030583576};\\\", \\\"{x:1351,y:562,t:1527030583593};\\\", \\\"{x:1351,y:563,t:1527030583705};\\\", \\\"{x:1351,y:565,t:1527030583713};\\\", \\\"{x:1351,y:568,t:1527030583728};\\\", \\\"{x:1350,y:570,t:1527030583743};\\\", \\\"{x:1350,y:576,t:1527030583759};\\\", \\\"{x:1348,y:588,t:1527030583776};\\\", \\\"{x:1346,y:609,t:1527030583793};\\\", \\\"{x:1341,y:623,t:1527030583810};\\\", \\\"{x:1338,y:634,t:1527030583826};\\\", \\\"{x:1337,y:641,t:1527030583843};\\\", \\\"{x:1336,y:652,t:1527030583859};\\\", \\\"{x:1336,y:666,t:1527030583875};\\\", \\\"{x:1336,y:681,t:1527030583893};\\\", \\\"{x:1336,y:692,t:1527030583909};\\\", \\\"{x:1336,y:703,t:1527030583925};\\\", \\\"{x:1336,y:710,t:1527030583943};\\\", \\\"{x:1337,y:717,t:1527030583959};\\\", \\\"{x:1337,y:718,t:1527030583975};\\\", \\\"{x:1337,y:720,t:1527030583992};\\\", \\\"{x:1337,y:721,t:1527030584009};\\\", \\\"{x:1338,y:721,t:1527030584032};\\\", \\\"{x:1339,y:722,t:1527030584048};\\\", \\\"{x:1339,y:723,t:1527030584465};\\\", \\\"{x:1339,y:724,t:1527030584489};\\\", \\\"{x:1338,y:725,t:1527030584513};\\\", \\\"{x:1337,y:726,t:1527030584536};\\\", \\\"{x:1336,y:726,t:1527030584545};\\\", \\\"{x:1334,y:728,t:1527030585337};\\\", \\\"{x:1324,y:732,t:1527030585345};\\\", \\\"{x:1305,y:740,t:1527030585361};\\\", \\\"{x:1275,y:752,t:1527030585377};\\\", \\\"{x:1231,y:772,t:1527030585394};\\\", \\\"{x:1177,y:801,t:1527030585411};\\\", \\\"{x:1112,y:837,t:1527030585427};\\\", \\\"{x:1057,y:860,t:1527030585443};\\\", \\\"{x:1007,y:881,t:1527030585460};\\\", \\\"{x:974,y:896,t:1527030585476};\\\", \\\"{x:949,y:901,t:1527030585493};\\\", \\\"{x:936,y:905,t:1527030585511};\\\", \\\"{x:933,y:906,t:1527030585526};\\\", \\\"{x:932,y:906,t:1527030585544};\\\", \\\"{x:931,y:906,t:1527030585560};\\\", \\\"{x:929,y:906,t:1527030585576};\\\", \\\"{x:928,y:906,t:1527030585705};\\\", \\\"{x:927,y:906,t:1527030585712};\\\", \\\"{x:926,y:906,t:1527030585727};\\\", \\\"{x:922,y:906,t:1527030585744};\\\", \\\"{x:904,y:899,t:1527030585760};\\\", \\\"{x:877,y:888,t:1527030585777};\\\", \\\"{x:823,y:872,t:1527030585793};\\\", \\\"{x:735,y:847,t:1527030585810};\\\", \\\"{x:627,y:816,t:1527030585827};\\\", \\\"{x:524,y:786,t:1527030585843};\\\", \\\"{x:437,y:771,t:1527030585861};\\\", \\\"{x:388,y:760,t:1527030585876};\\\", \\\"{x:373,y:757,t:1527030585893};\\\", \\\"{x:370,y:756,t:1527030585910};\\\", \\\"{x:375,y:756,t:1527030586080};\\\", \\\"{x:379,y:754,t:1527030586093};\\\", \\\"{x:388,y:750,t:1527030586111};\\\", \\\"{x:397,y:748,t:1527030586127};\\\", \\\"{x:405,y:746,t:1527030586144};\\\", \\\"{x:409,y:745,t:1527030586160};\\\", \\\"{x:410,y:744,t:1527030586178};\\\", \\\"{x:412,y:744,t:1527030586194};\\\", \\\"{x:415,y:744,t:1527030586211};\\\", \\\"{x:420,y:744,t:1527030586227};\\\", \\\"{x:428,y:743,t:1527030586244};\\\", \\\"{x:433,y:740,t:1527030586260};\\\", \\\"{x:440,y:738,t:1527030586277};\\\", \\\"{x:445,y:735,t:1527030586294};\\\", \\\"{x:445,y:734,t:1527030586310};\\\", \\\"{x:446,y:733,t:1527030586367};\\\", \\\"{x:447,y:733,t:1527030586378};\\\", \\\"{x:452,y:733,t:1527030586394};\\\", \\\"{x:461,y:733,t:1527030586411};\\\", \\\"{x:469,y:733,t:1527030586428};\\\", \\\"{x:474,y:733,t:1527030586445};\\\", \\\"{x:476,y:733,t:1527030586461};\\\" ] }, { \\\"rt\\\": 27958, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 530267, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 6.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"A\\\", \\\"G\\\", \\\"K\\\", \\\"P\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:730,t:1527030592736};\\\", \\\"{x:485,y:723,t:1527030592749};\\\", \\\"{x:497,y:708,t:1527030592766};\\\", \\\"{x:505,y:700,t:1527030592781};\\\", \\\"{x:513,y:686,t:1527030592798};\\\", \\\"{x:520,y:677,t:1527030592817};\\\", \\\"{x:521,y:676,t:1527030592833};\\\", \\\"{x:522,y:676,t:1527030592849};\\\", \\\"{x:523,y:672,t:1527030592867};\\\", \\\"{x:524,y:670,t:1527030592883};\\\", \\\"{x:528,y:661,t:1527030592899};\\\", \\\"{x:534,y:648,t:1527030592916};\\\", \\\"{x:545,y:628,t:1527030592933};\\\", \\\"{x:551,y:607,t:1527030592950};\\\", \\\"{x:561,y:584,t:1527030592968};\\\", \\\"{x:573,y:556,t:1527030592984};\\\", \\\"{x:582,y:548,t:1527030593002};\\\", \\\"{x:588,y:543,t:1527030593017};\\\", \\\"{x:596,y:540,t:1527030593034};\\\", \\\"{x:617,y:537,t:1527030593050};\\\", \\\"{x:655,y:540,t:1527030593067};\\\", \\\"{x:733,y:564,t:1527030593085};\\\", \\\"{x:837,y:588,t:1527030593101};\\\", \\\"{x:948,y:605,t:1527030593117};\\\", \\\"{x:1062,y:619,t:1527030593134};\\\", \\\"{x:1181,y:619,t:1527030593151};\\\", \\\"{x:1306,y:619,t:1527030593166};\\\", \\\"{x:1461,y:619,t:1527030593184};\\\", \\\"{x:1522,y:619,t:1527030593201};\\\", \\\"{x:1552,y:619,t:1527030593217};\\\", \\\"{x:1561,y:618,t:1527030593234};\\\", \\\"{x:1562,y:618,t:1527030593271};\\\", \\\"{x:1562,y:617,t:1527030593284};\\\", \\\"{x:1559,y:615,t:1527030593301};\\\", \\\"{x:1556,y:614,t:1527030593316};\\\", \\\"{x:1552,y:611,t:1527030593334};\\\", \\\"{x:1551,y:611,t:1527030593351};\\\", \\\"{x:1549,y:610,t:1527030593367};\\\", \\\"{x:1548,y:610,t:1527030593384};\\\", \\\"{x:1545,y:608,t:1527030593401};\\\", \\\"{x:1541,y:607,t:1527030593418};\\\", \\\"{x:1533,y:603,t:1527030593434};\\\", \\\"{x:1521,y:598,t:1527030593451};\\\", \\\"{x:1508,y:593,t:1527030593467};\\\", \\\"{x:1501,y:590,t:1527030593484};\\\", \\\"{x:1500,y:589,t:1527030593528};\\\", \\\"{x:1499,y:589,t:1527030593537};\\\", \\\"{x:1496,y:588,t:1527030593551};\\\", \\\"{x:1493,y:588,t:1527030593568};\\\", \\\"{x:1474,y:585,t:1527030593584};\\\", \\\"{x:1464,y:584,t:1527030593601};\\\", \\\"{x:1451,y:581,t:1527030593619};\\\", \\\"{x:1441,y:580,t:1527030593634};\\\", \\\"{x:1430,y:578,t:1527030593651};\\\", \\\"{x:1422,y:576,t:1527030593667};\\\", \\\"{x:1417,y:575,t:1527030593684};\\\", \\\"{x:1415,y:574,t:1527030593701};\\\", \\\"{x:1413,y:573,t:1527030593717};\\\", \\\"{x:1411,y:572,t:1527030593897};\\\", \\\"{x:1407,y:570,t:1527030593904};\\\", \\\"{x:1399,y:567,t:1527030593918};\\\", \\\"{x:1379,y:565,t:1527030593935};\\\", \\\"{x:1354,y:562,t:1527030593951};\\\", \\\"{x:1328,y:561,t:1527030593967};\\\", \\\"{x:1275,y:561,t:1527030593984};\\\", \\\"{x:1221,y:559,t:1527030594001};\\\", \\\"{x:1146,y:559,t:1527030594019};\\\", \\\"{x:1071,y:559,t:1527030594035};\\\", \\\"{x:979,y:559,t:1527030594052};\\\", \\\"{x:896,y:559,t:1527030594067};\\\", \\\"{x:823,y:555,t:1527030594085};\\\", \\\"{x:766,y:552,t:1527030594101};\\\", \\\"{x:736,y:551,t:1527030594118};\\\", \\\"{x:724,y:548,t:1527030594135};\\\", \\\"{x:720,y:548,t:1527030594153};\\\", \\\"{x:718,y:548,t:1527030594167};\\\", \\\"{x:717,y:549,t:1527030594224};\\\", \\\"{x:714,y:551,t:1527030594234};\\\", \\\"{x:700,y:557,t:1527030594250};\\\", \\\"{x:680,y:565,t:1527030594268};\\\", \\\"{x:649,y:576,t:1527030594285};\\\", \\\"{x:621,y:583,t:1527030594301};\\\", \\\"{x:592,y:587,t:1527030594318};\\\", \\\"{x:556,y:593,t:1527030594335};\\\", \\\"{x:471,y:597,t:1527030594352};\\\", \\\"{x:390,y:597,t:1527030594368};\\\", \\\"{x:312,y:597,t:1527030594385};\\\", \\\"{x:278,y:600,t:1527030594401};\\\", \\\"{x:270,y:600,t:1527030594417};\\\", \\\"{x:273,y:597,t:1527030594553};\\\", \\\"{x:281,y:589,t:1527030594570};\\\", \\\"{x:293,y:576,t:1527030594585};\\\", \\\"{x:307,y:564,t:1527030594601};\\\", \\\"{x:317,y:555,t:1527030594618};\\\", \\\"{x:322,y:550,t:1527030594635};\\\", \\\"{x:323,y:548,t:1527030594652};\\\", \\\"{x:323,y:545,t:1527030594668};\\\", \\\"{x:323,y:542,t:1527030594684};\\\", \\\"{x:323,y:540,t:1527030594702};\\\", \\\"{x:325,y:537,t:1527030594717};\\\", \\\"{x:329,y:534,t:1527030594734};\\\", \\\"{x:347,y:525,t:1527030594751};\\\", \\\"{x:378,y:510,t:1527030594769};\\\", \\\"{x:419,y:493,t:1527030594785};\\\", \\\"{x:449,y:483,t:1527030594802};\\\", \\\"{x:461,y:479,t:1527030594818};\\\", \\\"{x:467,y:477,t:1527030594834};\\\", \\\"{x:470,y:477,t:1527030594852};\\\", \\\"{x:472,y:475,t:1527030594868};\\\", \\\"{x:476,y:474,t:1527030594885};\\\", \\\"{x:482,y:474,t:1527030594901};\\\", \\\"{x:487,y:474,t:1527030594919};\\\", \\\"{x:493,y:474,t:1527030594935};\\\", \\\"{x:498,y:474,t:1527030594952};\\\", \\\"{x:506,y:475,t:1527030594968};\\\", \\\"{x:518,y:482,t:1527030594984};\\\", \\\"{x:535,y:492,t:1527030595003};\\\", \\\"{x:548,y:500,t:1527030595018};\\\", \\\"{x:548,y:501,t:1527030595047};\\\", \\\"{x:548,y:502,t:1527030595064};\\\", \\\"{x:548,y:503,t:1527030595071};\\\", \\\"{x:548,y:504,t:1527030595087};\\\", \\\"{x:552,y:508,t:1527030595102};\\\", \\\"{x:561,y:510,t:1527030595118};\\\", \\\"{x:569,y:512,t:1527030595135};\\\", \\\"{x:583,y:514,t:1527030595151};\\\", \\\"{x:591,y:518,t:1527030595169};\\\", \\\"{x:600,y:519,t:1527030595185};\\\", \\\"{x:600,y:520,t:1527030595240};\\\", \\\"{x:599,y:521,t:1527030595253};\\\", \\\"{x:600,y:521,t:1527030595352};\\\", \\\"{x:601,y:521,t:1527030595369};\\\", \\\"{x:603,y:520,t:1527030595386};\\\", \\\"{x:604,y:520,t:1527030595403};\\\", \\\"{x:604,y:519,t:1527030595424};\\\", \\\"{x:606,y:519,t:1527030595436};\\\", \\\"{x:607,y:519,t:1527030595453};\\\", \\\"{x:609,y:517,t:1527030595470};\\\", \\\"{x:610,y:516,t:1527030595486};\\\", \\\"{x:611,y:515,t:1527030595502};\\\", \\\"{x:612,y:514,t:1527030595520};\\\", \\\"{x:613,y:514,t:1527030595536};\\\", \\\"{x:613,y:513,t:1527030595569};\\\", \\\"{x:612,y:512,t:1527030595585};\\\", \\\"{x:611,y:511,t:1527030595615};\\\", \\\"{x:609,y:511,t:1527030595640};\\\", \\\"{x:604,y:511,t:1527030596761};\\\", \\\"{x:583,y:515,t:1527030596776};\\\", \\\"{x:535,y:528,t:1527030596807};\\\", \\\"{x:501,y:537,t:1527030596820};\\\", \\\"{x:458,y:547,t:1527030596837};\\\", \\\"{x:425,y:557,t:1527030596853};\\\", \\\"{x:400,y:564,t:1527030596870};\\\", \\\"{x:382,y:570,t:1527030596887};\\\", \\\"{x:370,y:575,t:1527030596903};\\\", \\\"{x:358,y:581,t:1527030596920};\\\", \\\"{x:356,y:584,t:1527030596936};\\\", \\\"{x:355,y:584,t:1527030596959};\\\", \\\"{x:354,y:584,t:1527030597016};\\\", \\\"{x:354,y:585,t:1527030597024};\\\", \\\"{x:353,y:585,t:1527030597055};\\\", \\\"{x:354,y:585,t:1527030597137};\\\", \\\"{x:362,y:584,t:1527030597154};\\\", \\\"{x:372,y:579,t:1527030597170};\\\", \\\"{x:384,y:568,t:1527030597188};\\\", \\\"{x:398,y:559,t:1527030597204};\\\", \\\"{x:406,y:553,t:1527030597221};\\\", \\\"{x:408,y:551,t:1527030597237};\\\", \\\"{x:409,y:551,t:1527030597253};\\\", \\\"{x:409,y:550,t:1527030597320};\\\", \\\"{x:408,y:550,t:1527030597336};\\\", \\\"{x:403,y:549,t:1527030597354};\\\", \\\"{x:396,y:549,t:1527030597371};\\\", \\\"{x:387,y:549,t:1527030597387};\\\", \\\"{x:375,y:553,t:1527030597404};\\\", \\\"{x:360,y:555,t:1527030597425};\\\", \\\"{x:357,y:555,t:1527030597437};\\\", \\\"{x:351,y:558,t:1527030597454};\\\", \\\"{x:347,y:558,t:1527030597471};\\\", \\\"{x:345,y:558,t:1527030597487};\\\", \\\"{x:340,y:559,t:1527030597504};\\\", \\\"{x:334,y:559,t:1527030597520};\\\", \\\"{x:327,y:562,t:1527030597537};\\\", \\\"{x:320,y:562,t:1527030597553};\\\", \\\"{x:315,y:565,t:1527030597571};\\\", \\\"{x:313,y:565,t:1527030597587};\\\", \\\"{x:313,y:566,t:1527030597604};\\\", \\\"{x:316,y:566,t:1527030597655};\\\", \\\"{x:323,y:566,t:1527030597671};\\\", \\\"{x:344,y:566,t:1527030597687};\\\", \\\"{x:383,y:564,t:1527030597704};\\\", \\\"{x:414,y:559,t:1527030597722};\\\", \\\"{x:458,y:554,t:1527030597737};\\\", \\\"{x:506,y:547,t:1527030597755};\\\", \\\"{x:563,y:542,t:1527030597771};\\\", \\\"{x:620,y:539,t:1527030597787};\\\", \\\"{x:671,y:539,t:1527030597804};\\\", \\\"{x:713,y:539,t:1527030597821};\\\", \\\"{x:747,y:539,t:1527030597838};\\\", \\\"{x:768,y:539,t:1527030597854};\\\", \\\"{x:777,y:539,t:1527030597870};\\\", \\\"{x:778,y:538,t:1527030597888};\\\", \\\"{x:781,y:538,t:1527030598120};\\\", \\\"{x:782,y:538,t:1527030598128};\\\", \\\"{x:784,y:538,t:1527030598139};\\\", \\\"{x:788,y:538,t:1527030598155};\\\", \\\"{x:791,y:538,t:1527030598171};\\\", \\\"{x:795,y:538,t:1527030598189};\\\", \\\"{x:802,y:538,t:1527030598205};\\\", \\\"{x:806,y:538,t:1527030598221};\\\", \\\"{x:811,y:538,t:1527030598239};\\\", \\\"{x:818,y:539,t:1527030598255};\\\", \\\"{x:821,y:542,t:1527030598272};\\\", \\\"{x:822,y:542,t:1527030598289};\\\", \\\"{x:824,y:542,t:1527030598586};\\\", \\\"{x:823,y:544,t:1527030599449};\\\", \\\"{x:820,y:545,t:1527030599455};\\\", \\\"{x:804,y:547,t:1527030599471};\\\", \\\"{x:786,y:551,t:1527030599489};\\\", \\\"{x:775,y:552,t:1527030599504};\\\", \\\"{x:771,y:553,t:1527030599521};\\\", \\\"{x:767,y:555,t:1527030601400};\\\", \\\"{x:759,y:556,t:1527030601409};\\\", \\\"{x:746,y:558,t:1527030601423};\\\", \\\"{x:704,y:564,t:1527030601440};\\\", \\\"{x:674,y:568,t:1527030601457};\\\", \\\"{x:643,y:573,t:1527030601473};\\\", \\\"{x:613,y:577,t:1527030601491};\\\", \\\"{x:595,y:580,t:1527030601507};\\\", \\\"{x:586,y:580,t:1527030601524};\\\", \\\"{x:584,y:581,t:1527030601539};\\\", \\\"{x:582,y:577,t:1527030601856};\\\", \\\"{x:560,y:575,t:1527030601874};\\\", \\\"{x:535,y:575,t:1527030601891};\\\", \\\"{x:511,y:575,t:1527030601906};\\\", \\\"{x:487,y:583,t:1527030601925};\\\", \\\"{x:465,y:589,t:1527030601941};\\\", \\\"{x:446,y:594,t:1527030601958};\\\", \\\"{x:427,y:600,t:1527030601974};\\\", \\\"{x:417,y:601,t:1527030601992};\\\", \\\"{x:410,y:601,t:1527030602007};\\\", \\\"{x:405,y:601,t:1527030602024};\\\", \\\"{x:402,y:601,t:1527030602041};\\\", \\\"{x:400,y:603,t:1527030602240};\\\", \\\"{x:399,y:606,t:1527030602258};\\\", \\\"{x:399,y:609,t:1527030602274};\\\", \\\"{x:398,y:610,t:1527030602290};\\\", \\\"{x:398,y:611,t:1527030602307};\\\", \\\"{x:398,y:610,t:1527030606449};\\\", \\\"{x:398,y:607,t:1527030606462};\\\", \\\"{x:400,y:600,t:1527030606480};\\\", \\\"{x:404,y:589,t:1527030606496};\\\", \\\"{x:405,y:583,t:1527030606512};\\\", \\\"{x:405,y:581,t:1527030606527};\\\", \\\"{x:405,y:579,t:1527030606544};\\\", \\\"{x:405,y:578,t:1527030606568};\\\", \\\"{x:405,y:577,t:1527030606578};\\\", \\\"{x:403,y:575,t:1527030606594};\\\", \\\"{x:395,y:571,t:1527030606611};\\\", \\\"{x:385,y:568,t:1527030606629};\\\", \\\"{x:379,y:566,t:1527030606644};\\\", \\\"{x:371,y:565,t:1527030606662};\\\", \\\"{x:365,y:564,t:1527030606678};\\\", \\\"{x:357,y:562,t:1527030606694};\\\", \\\"{x:350,y:559,t:1527030606711};\\\", \\\"{x:348,y:558,t:1527030606728};\\\", \\\"{x:347,y:556,t:1527030606744};\\\", \\\"{x:349,y:552,t:1527030606762};\\\", \\\"{x:358,y:547,t:1527030606778};\\\", \\\"{x:378,y:538,t:1527030606795};\\\", \\\"{x:401,y:532,t:1527030606811};\\\", \\\"{x:426,y:525,t:1527030606829};\\\", \\\"{x:447,y:520,t:1527030606845};\\\", \\\"{x:463,y:518,t:1527030606862};\\\", \\\"{x:473,y:517,t:1527030606879};\\\", \\\"{x:477,y:517,t:1527030606895};\\\", \\\"{x:483,y:517,t:1527030606912};\\\", \\\"{x:487,y:517,t:1527030606929};\\\", \\\"{x:502,y:522,t:1527030606945};\\\", \\\"{x:519,y:531,t:1527030606962};\\\", \\\"{x:540,y:539,t:1527030606978};\\\", \\\"{x:557,y:543,t:1527030606995};\\\", \\\"{x:568,y:547,t:1527030607012};\\\", \\\"{x:575,y:548,t:1527030607028};\\\", \\\"{x:578,y:548,t:1527030607045};\\\", \\\"{x:580,y:548,t:1527030607061};\\\", \\\"{x:582,y:548,t:1527030607078};\\\", \\\"{x:585,y:548,t:1527030607095};\\\", \\\"{x:589,y:548,t:1527030607111};\\\", \\\"{x:596,y:548,t:1527030607128};\\\", \\\"{x:603,y:548,t:1527030607146};\\\", \\\"{x:609,y:548,t:1527030607162};\\\", \\\"{x:610,y:548,t:1527030607671};\\\", \\\"{x:608,y:548,t:1527030608664};\\\", \\\"{x:607,y:548,t:1527030608688};\\\", \\\"{x:606,y:548,t:1527030608696};\\\", \\\"{x:605,y:548,t:1527030608713};\\\", \\\"{x:601,y:548,t:1527030608730};\\\", \\\"{x:594,y:548,t:1527030608748};\\\", \\\"{x:586,y:548,t:1527030608762};\\\", \\\"{x:575,y:548,t:1527030608780};\\\", \\\"{x:558,y:548,t:1527030608796};\\\", \\\"{x:544,y:548,t:1527030608813};\\\", \\\"{x:531,y:548,t:1527030608829};\\\", \\\"{x:521,y:548,t:1527030608847};\\\", \\\"{x:514,y:548,t:1527030608863};\\\", \\\"{x:503,y:548,t:1527030608880};\\\", \\\"{x:497,y:549,t:1527030608896};\\\", \\\"{x:488,y:552,t:1527030608913};\\\", \\\"{x:477,y:556,t:1527030608930};\\\", \\\"{x:466,y:559,t:1527030608946};\\\", \\\"{x:455,y:562,t:1527030608963};\\\", \\\"{x:446,y:565,t:1527030608980};\\\", \\\"{x:443,y:565,t:1527030608996};\\\", \\\"{x:440,y:565,t:1527030609013};\\\", \\\"{x:439,y:566,t:1527030609111};\\\", \\\"{x:439,y:567,t:1527030609127};\\\", \\\"{x:439,y:570,t:1527030609135};\\\", \\\"{x:439,y:572,t:1527030609146};\\\", \\\"{x:438,y:576,t:1527030609163};\\\", \\\"{x:437,y:581,t:1527030609179};\\\", \\\"{x:437,y:584,t:1527030609196};\\\", \\\"{x:437,y:593,t:1527030609213};\\\", \\\"{x:438,y:608,t:1527030609230};\\\", \\\"{x:450,y:628,t:1527030609246};\\\", \\\"{x:475,y:658,t:1527030609263};\\\", \\\"{x:499,y:665,t:1527030609280};\\\", \\\"{x:527,y:665,t:1527030609296};\\\", \\\"{x:563,y:653,t:1527030609313};\\\", \\\"{x:597,y:635,t:1527030609330};\\\", \\\"{x:638,y:604,t:1527030609347};\\\", \\\"{x:665,y:582,t:1527030609364};\\\", \\\"{x:683,y:568,t:1527030609380};\\\", \\\"{x:690,y:560,t:1527030609397};\\\", \\\"{x:690,y:557,t:1527030609413};\\\", \\\"{x:692,y:549,t:1527030609431};\\\", \\\"{x:689,y:549,t:1527030609664};\\\", \\\"{x:674,y:560,t:1527030609682};\\\", \\\"{x:654,y:572,t:1527030609698};\\\", \\\"{x:618,y:584,t:1527030609715};\\\", \\\"{x:573,y:597,t:1527030609731};\\\", \\\"{x:528,y:609,t:1527030609748};\\\", \\\"{x:499,y:621,t:1527030609764};\\\", \\\"{x:469,y:630,t:1527030609781};\\\", \\\"{x:446,y:637,t:1527030609798};\\\", \\\"{x:421,y:645,t:1527030609814};\\\", \\\"{x:395,y:652,t:1527030609831};\\\", \\\"{x:353,y:665,t:1527030609848};\\\", \\\"{x:324,y:674,t:1527030609864};\\\", \\\"{x:287,y:680,t:1527030609880};\\\", \\\"{x:263,y:683,t:1527030609897};\\\", \\\"{x:252,y:685,t:1527030609913};\\\", \\\"{x:247,y:685,t:1527030609931};\\\", \\\"{x:246,y:685,t:1527030609951};\\\", \\\"{x:245,y:685,t:1527030609963};\\\", \\\"{x:245,y:683,t:1527030609980};\\\", \\\"{x:241,y:674,t:1527030609998};\\\", \\\"{x:235,y:663,t:1527030610014};\\\", \\\"{x:227,y:652,t:1527030610031};\\\", \\\"{x:222,y:646,t:1527030610047};\\\", \\\"{x:220,y:643,t:1527030610063};\\\", \\\"{x:219,y:641,t:1527030610081};\\\", \\\"{x:216,y:636,t:1527030610098};\\\", \\\"{x:211,y:629,t:1527030610115};\\\", \\\"{x:206,y:623,t:1527030610130};\\\", \\\"{x:200,y:620,t:1527030610147};\\\", \\\"{x:196,y:618,t:1527030610165};\\\", \\\"{x:195,y:618,t:1527030610180};\\\", \\\"{x:193,y:618,t:1527030610207};\\\", \\\"{x:191,y:618,t:1527030610873};\\\", \\\"{x:183,y:620,t:1527030610882};\\\", \\\"{x:160,y:628,t:1527030610898};\\\", \\\"{x:135,y:631,t:1527030610914};\\\", \\\"{x:121,y:633,t:1527030610932};\\\", \\\"{x:117,y:633,t:1527030610949};\\\", \\\"{x:116,y:633,t:1527030610964};\\\", \\\"{x:115,y:634,t:1527030610981};\\\", \\\"{x:116,y:632,t:1527030611040};\\\", \\\"{x:118,y:631,t:1527030611049};\\\", \\\"{x:121,y:630,t:1527030611064};\\\", \\\"{x:125,y:627,t:1527030611082};\\\", \\\"{x:128,y:626,t:1527030611098};\\\", \\\"{x:134,y:624,t:1527030611114};\\\", \\\"{x:135,y:623,t:1527030611131};\\\", \\\"{x:136,y:623,t:1527030611148};\\\", \\\"{x:137,y:622,t:1527030611164};\\\", \\\"{x:138,y:622,t:1527030611192};\\\", \\\"{x:141,y:622,t:1527030611199};\\\", \\\"{x:142,y:622,t:1527030611214};\\\", \\\"{x:145,y:622,t:1527030611232};\\\", \\\"{x:147,y:620,t:1527030611249};\\\", \\\"{x:148,y:619,t:1527030611272};\\\", \\\"{x:150,y:619,t:1527030611288};\\\", \\\"{x:152,y:618,t:1527030611311};\\\", \\\"{x:153,y:617,t:1527030611327};\\\", \\\"{x:154,y:616,t:1527030611335};\\\", \\\"{x:155,y:616,t:1527030611349};\\\", \\\"{x:157,y:615,t:1527030611364};\\\", \\\"{x:159,y:613,t:1527030611382};\\\", \\\"{x:160,y:613,t:1527030611398};\\\", \\\"{x:164,y:613,t:1527030612072};\\\", \\\"{x:175,y:613,t:1527030612083};\\\", \\\"{x:195,y:611,t:1527030612100};\\\", \\\"{x:218,y:603,t:1527030612115};\\\", \\\"{x:244,y:596,t:1527030612133};\\\", \\\"{x:272,y:588,t:1527030612150};\\\", \\\"{x:299,y:578,t:1527030612166};\\\", \\\"{x:329,y:570,t:1527030612182};\\\", \\\"{x:352,y:564,t:1527030612199};\\\", \\\"{x:372,y:559,t:1527030612215};\\\", \\\"{x:379,y:557,t:1527030612232};\\\", \\\"{x:384,y:556,t:1527030612249};\\\", \\\"{x:386,y:556,t:1527030612265};\\\", \\\"{x:391,y:556,t:1527030612283};\\\", \\\"{x:397,y:556,t:1527030612298};\\\", \\\"{x:398,y:556,t:1527030612316};\\\", \\\"{x:400,y:556,t:1527030612335};\\\", \\\"{x:401,y:556,t:1527030612352};\\\", \\\"{x:403,y:556,t:1527030612448};\\\", \\\"{x:404,y:556,t:1527030612466};\\\", \\\"{x:410,y:556,t:1527030612483};\\\", \\\"{x:416,y:555,t:1527030612501};\\\", \\\"{x:430,y:555,t:1527030612515};\\\", \\\"{x:445,y:555,t:1527030612532};\\\", \\\"{x:455,y:555,t:1527030612549};\\\", \\\"{x:463,y:555,t:1527030612566};\\\", \\\"{x:469,y:555,t:1527030612583};\\\", \\\"{x:483,y:555,t:1527030612599};\\\", \\\"{x:498,y:555,t:1527030612616};\\\", \\\"{x:519,y:555,t:1527030612633};\\\", \\\"{x:540,y:555,t:1527030612649};\\\", \\\"{x:559,y:555,t:1527030612666};\\\", \\\"{x:573,y:555,t:1527030612682};\\\", \\\"{x:582,y:555,t:1527030612700};\\\", \\\"{x:584,y:555,t:1527030612716};\\\", \\\"{x:586,y:555,t:1527030612733};\\\", \\\"{x:587,y:556,t:1527030612760};\\\", \\\"{x:588,y:557,t:1527030612776};\\\", \\\"{x:589,y:558,t:1527030612784};\\\", \\\"{x:592,y:563,t:1527030612800};\\\", \\\"{x:596,y:569,t:1527030612816};\\\", \\\"{x:598,y:571,t:1527030612832};\\\", \\\"{x:600,y:574,t:1527030612850};\\\", \\\"{x:602,y:576,t:1527030612866};\\\", \\\"{x:604,y:579,t:1527030612882};\\\", \\\"{x:606,y:581,t:1527030612900};\\\", \\\"{x:607,y:582,t:1527030612919};\\\", \\\"{x:608,y:582,t:1527030612932};\\\", \\\"{x:606,y:582,t:1527030612983};\\\", \\\"{x:600,y:581,t:1527030613000};\\\", \\\"{x:597,y:580,t:1527030613018};\\\", \\\"{x:595,y:580,t:1527030613033};\\\", \\\"{x:589,y:584,t:1527030613049};\\\", \\\"{x:579,y:590,t:1527030613066};\\\", \\\"{x:563,y:598,t:1527030613085};\\\", \\\"{x:547,y:606,t:1527030613100};\\\", \\\"{x:531,y:613,t:1527030613117};\\\", \\\"{x:514,y:621,t:1527030613134};\\\", \\\"{x:495,y:629,t:1527030613151};\\\", \\\"{x:474,y:638,t:1527030613167};\\\", \\\"{x:453,y:643,t:1527030613183};\\\", \\\"{x:430,y:644,t:1527030613199};\\\", \\\"{x:419,y:641,t:1527030613216};\\\", \\\"{x:403,y:634,t:1527030613233};\\\", \\\"{x:392,y:629,t:1527030613250};\\\", \\\"{x:391,y:628,t:1527030613268};\\\", \\\"{x:390,y:628,t:1527030613296};\\\", \\\"{x:390,y:626,t:1527030613312};\\\", \\\"{x:390,y:624,t:1527030613319};\\\", \\\"{x:389,y:621,t:1527030613334};\\\", \\\"{x:387,y:616,t:1527030613350};\\\", \\\"{x:385,y:612,t:1527030613367};\\\", \\\"{x:385,y:608,t:1527030613383};\\\", \\\"{x:385,y:607,t:1527030613399};\\\", \\\"{x:385,y:604,t:1527030613417};\\\", \\\"{x:385,y:602,t:1527030613435};\\\", \\\"{x:386,y:597,t:1527030613450};\\\", \\\"{x:386,y:592,t:1527030613467};\\\", \\\"{x:386,y:588,t:1527030613484};\\\", \\\"{x:386,y:585,t:1527030613500};\\\", \\\"{x:386,y:582,t:1527030613517};\\\", \\\"{x:387,y:581,t:1527030613534};\\\", \\\"{x:387,y:580,t:1527030613551};\\\", \\\"{x:388,y:579,t:1527030613567};\\\", \\\"{x:388,y:574,t:1527030613583};\\\", \\\"{x:389,y:572,t:1527030613601};\\\", \\\"{x:389,y:570,t:1527030613617};\\\", \\\"{x:389,y:569,t:1527030613633};\\\", \\\"{x:390,y:568,t:1527030613943};\\\", \\\"{x:394,y:572,t:1527030613960};\\\", \\\"{x:399,y:584,t:1527030613967};\\\", \\\"{x:412,y:608,t:1527030613984};\\\", \\\"{x:425,y:631,t:1527030614002};\\\", \\\"{x:439,y:655,t:1527030614018};\\\", \\\"{x:458,y:683,t:1527030614034};\\\", \\\"{x:495,y:706,t:1527030614050};\\\", \\\"{x:547,y:729,t:1527030614068};\\\", \\\"{x:604,y:749,t:1527030614083};\\\", \\\"{x:663,y:759,t:1527030614100};\\\", \\\"{x:724,y:767,t:1527030614116};\\\", \\\"{x:773,y:770,t:1527030614134};\\\", \\\"{x:821,y:770,t:1527030614150};\\\", \\\"{x:871,y:770,t:1527030614167};\\\", \\\"{x:919,y:770,t:1527030614184};\\\", \\\"{x:941,y:770,t:1527030614200};\\\", \\\"{x:955,y:770,t:1527030614217};\\\", \\\"{x:958,y:770,t:1527030614233};\\\", \\\"{x:957,y:770,t:1527030614553};\\\", \\\"{x:955,y:770,t:1527030614592};\\\", \\\"{x:955,y:769,t:1527030614615};\\\", \\\"{x:953,y:769,t:1527030614632};\\\", \\\"{x:952,y:768,t:1527030614664};\\\", \\\"{x:951,y:768,t:1527030614672};\\\", \\\"{x:950,y:768,t:1527030614688};\\\", \\\"{x:949,y:768,t:1527030614701};\\\", \\\"{x:946,y:768,t:1527030614717};\\\", \\\"{x:940,y:769,t:1527030614734};\\\", \\\"{x:934,y:770,t:1527030614751};\\\", \\\"{x:915,y:775,t:1527030614768};\\\", \\\"{x:901,y:779,t:1527030614784};\\\", \\\"{x:880,y:784,t:1527030614801};\\\", \\\"{x:857,y:786,t:1527030614817};\\\", \\\"{x:832,y:789,t:1527030614834};\\\", \\\"{x:809,y:790,t:1527030614851};\\\", \\\"{x:784,y:790,t:1527030614867};\\\", \\\"{x:773,y:790,t:1527030614884};\\\", \\\"{x:753,y:792,t:1527030614902};\\\", \\\"{x:738,y:793,t:1527030614917};\\\", \\\"{x:729,y:794,t:1527030614934};\\\", \\\"{x:719,y:795,t:1527030614952};\\\", \\\"{x:718,y:795,t:1527030614967};\\\", \\\"{x:710,y:795,t:1527030614984};\\\", \\\"{x:708,y:795,t:1527030615015};\\\", \\\"{x:707,y:795,t:1527030615056};\\\", \\\"{x:706,y:795,t:1527030615072};\\\", \\\"{x:705,y:795,t:1527030615084};\\\", \\\"{x:703,y:795,t:1527030615101};\\\", \\\"{x:702,y:795,t:1527030615152};\\\", \\\"{x:701,y:794,t:1527030615167};\\\", \\\"{x:700,y:794,t:1527030615240};\\\", \\\"{x:699,y:794,t:1527030615272};\\\", \\\"{x:698,y:794,t:1527030615304};\\\", \\\"{x:697,y:794,t:1527030615317};\\\", \\\"{x:692,y:794,t:1527030615334};\\\", \\\"{x:687,y:794,t:1527030615352};\\\", \\\"{x:681,y:794,t:1527030615367};\\\", \\\"{x:672,y:794,t:1527030615384};\\\", \\\"{x:665,y:791,t:1527030615401};\\\", \\\"{x:661,y:790,t:1527030615417};\\\", \\\"{x:657,y:787,t:1527030615434};\\\", \\\"{x:655,y:787,t:1527030615456};\\\", \\\"{x:654,y:787,t:1527030615467};\\\", \\\"{x:653,y:787,t:1527030615512};\\\", \\\"{x:651,y:786,t:1527030615528};\\\", \\\"{x:650,y:785,t:1527030615544};\\\", \\\"{x:648,y:785,t:1527030615551};\\\", \\\"{x:647,y:785,t:1527030615568};\\\", \\\"{x:644,y:784,t:1527030615584};\\\", \\\"{x:642,y:784,t:1527030615601};\\\", \\\"{x:641,y:784,t:1527030615617};\\\", \\\"{x:640,y:784,t:1527030615634};\\\", \\\"{x:638,y:784,t:1527030615651};\\\", \\\"{x:635,y:784,t:1527030615667};\\\", \\\"{x:633,y:784,t:1527030615684};\\\", \\\"{x:631,y:784,t:1527030615701};\\\", \\\"{x:627,y:784,t:1527030615717};\\\", \\\"{x:624,y:784,t:1527030615734};\\\", \\\"{x:621,y:784,t:1527030615751};\\\", \\\"{x:617,y:784,t:1527030615767};\\\", \\\"{x:615,y:784,t:1527030615784};\\\", \\\"{x:614,y:783,t:1527030615800};\\\", \\\"{x:611,y:780,t:1527030615856};\\\", \\\"{x:610,y:780,t:1527030615867};\\\", \\\"{x:605,y:775,t:1527030615884};\\\", \\\"{x:595,y:770,t:1527030615901};\\\", \\\"{x:578,y:767,t:1527030615917};\\\", \\\"{x:565,y:762,t:1527030615934};\\\", \\\"{x:560,y:761,t:1527030615951};\\\", \\\"{x:558,y:760,t:1527030615966};\\\", \\\"{x:557,y:760,t:1527030615984};\\\", \\\"{x:557,y:759,t:1527030616065};\\\", \\\"{x:557,y:757,t:1527030616072};\\\", \\\"{x:557,y:756,t:1527030616084};\\\", \\\"{x:557,y:752,t:1527030616102};\\\", \\\"{x:557,y:749,t:1527030616117};\\\", \\\"{x:557,y:744,t:1527030616133};\\\", \\\"{x:555,y:740,t:1527030616147};\\\", \\\"{x:554,y:737,t:1527030616165};\\\", \\\"{x:554,y:734,t:1527030616181};\\\", \\\"{x:552,y:732,t:1527030616198};\\\", \\\"{x:552,y:731,t:1527030616214};\\\", \\\"{x:552,y:730,t:1527030616231};\\\", \\\"{x:551,y:729,t:1527030616263};\\\" ] }, { \\\"rt\\\": 24019, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 555600, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:549,y:728,t:1527030622112};\\\", \\\"{x:539,y:724,t:1527030622121};\\\", \\\"{x:495,y:669,t:1527030622138};\\\", \\\"{x:446,y:619,t:1527030622154};\\\", \\\"{x:392,y:555,t:1527030622171};\\\", \\\"{x:337,y:462,t:1527030622191};\\\", \\\"{x:245,y:331,t:1527030622207};\\\", \\\"{x:202,y:300,t:1527030622223};\\\", \\\"{x:199,y:299,t:1527030622240};\\\", \\\"{x:198,y:299,t:1527030622257};\\\", \\\"{x:198,y:298,t:1527030622274};\\\", \\\"{x:198,y:297,t:1527030622319};\\\", \\\"{x:201,y:298,t:1527030622327};\\\", \\\"{x:204,y:300,t:1527030622340};\\\", \\\"{x:214,y:305,t:1527030622356};\\\", \\\"{x:230,y:320,t:1527030622374};\\\", \\\"{x:264,y:351,t:1527030622390};\\\", \\\"{x:317,y:389,t:1527030622407};\\\", \\\"{x:405,y:442,t:1527030622424};\\\", \\\"{x:455,y:468,t:1527030622441};\\\", \\\"{x:493,y:490,t:1527030622458};\\\", \\\"{x:508,y:500,t:1527030622475};\\\", \\\"{x:514,y:503,t:1527030622491};\\\", \\\"{x:514,y:504,t:1527030622508};\\\", \\\"{x:513,y:504,t:1527030622567};\\\", \\\"{x:512,y:504,t:1527030622575};\\\", \\\"{x:509,y:504,t:1527030622590};\\\", \\\"{x:497,y:505,t:1527030622608};\\\", \\\"{x:481,y:507,t:1527030622625};\\\", \\\"{x:458,y:507,t:1527030622641};\\\", \\\"{x:429,y:507,t:1527030622656};\\\", \\\"{x:391,y:507,t:1527030622675};\\\", \\\"{x:361,y:504,t:1527030622692};\\\", \\\"{x:335,y:501,t:1527030622708};\\\", \\\"{x:315,y:497,t:1527030622724};\\\", \\\"{x:311,y:495,t:1527030622741};\\\", \\\"{x:311,y:494,t:1527030622784};\\\", \\\"{x:311,y:492,t:1527030622791};\\\", \\\"{x:312,y:492,t:1527030622808};\\\", \\\"{x:316,y:490,t:1527030622824};\\\", \\\"{x:319,y:488,t:1527030622841};\\\", \\\"{x:323,y:486,t:1527030622858};\\\", \\\"{x:327,y:484,t:1527030622874};\\\", \\\"{x:333,y:481,t:1527030622891};\\\", \\\"{x:336,y:480,t:1527030622908};\\\", \\\"{x:340,y:477,t:1527030622923};\\\", \\\"{x:343,y:475,t:1527030622941};\\\", \\\"{x:345,y:473,t:1527030622958};\\\", \\\"{x:347,y:471,t:1527030622975};\\\", \\\"{x:348,y:470,t:1527030623216};\\\", \\\"{x:350,y:470,t:1527030623232};\\\", \\\"{x:353,y:470,t:1527030623242};\\\", \\\"{x:362,y:470,t:1527030623258};\\\", \\\"{x:377,y:470,t:1527030623275};\\\", \\\"{x:391,y:470,t:1527030623292};\\\", \\\"{x:407,y:467,t:1527030623308};\\\", \\\"{x:421,y:466,t:1527030623325};\\\", \\\"{x:426,y:465,t:1527030623342};\\\", \\\"{x:429,y:464,t:1527030623358};\\\", \\\"{x:433,y:464,t:1527030623832};\\\", \\\"{x:437,y:464,t:1527030623842};\\\", \\\"{x:444,y:464,t:1527030623859};\\\", \\\"{x:448,y:464,t:1527030623877};\\\", \\\"{x:452,y:464,t:1527030623892};\\\", \\\"{x:454,y:464,t:1527030623909};\\\", \\\"{x:455,y:464,t:1527030623926};\\\", \\\"{x:456,y:464,t:1527030624112};\\\", \\\"{x:459,y:464,t:1527030624126};\\\", \\\"{x:466,y:464,t:1527030624144};\\\", \\\"{x:472,y:464,t:1527030624159};\\\", \\\"{x:477,y:463,t:1527030624176};\\\", \\\"{x:481,y:462,t:1527030624193};\\\", \\\"{x:484,y:462,t:1527030624210};\\\", \\\"{x:486,y:462,t:1527030624656};\\\", \\\"{x:492,y:462,t:1527030624663};\\\", \\\"{x:499,y:462,t:1527030624677};\\\", \\\"{x:519,y:462,t:1527030624694};\\\", \\\"{x:538,y:462,t:1527030624710};\\\", \\\"{x:564,y:462,t:1527030624727};\\\", \\\"{x:570,y:462,t:1527030624744};\\\", \\\"{x:572,y:462,t:1527030624760};\\\", \\\"{x:574,y:462,t:1527030625344};\\\", \\\"{x:588,y:462,t:1527030625362};\\\", \\\"{x:606,y:461,t:1527030625378};\\\", \\\"{x:621,y:461,t:1527030625395};\\\", \\\"{x:639,y:457,t:1527030625411};\\\", \\\"{x:648,y:457,t:1527030625429};\\\", \\\"{x:658,y:456,t:1527030625445};\\\", \\\"{x:667,y:456,t:1527030625462};\\\", \\\"{x:672,y:456,t:1527030625478};\\\", \\\"{x:674,y:456,t:1527030625495};\\\", \\\"{x:675,y:456,t:1527030625511};\\\", \\\"{x:676,y:456,t:1527030625529};\\\", \\\"{x:677,y:456,t:1527030625568};\\\", \\\"{x:678,y:456,t:1527030625578};\\\", \\\"{x:679,y:456,t:1527030625596};\\\", \\\"{x:680,y:456,t:1527030626109};\\\", \\\"{x:681,y:456,t:1527030626127};\\\", \\\"{x:683,y:456,t:1527030626143};\\\", \\\"{x:684,y:456,t:1527030626160};\\\", \\\"{x:686,y:458,t:1527030626176};\\\", \\\"{x:690,y:462,t:1527030626193};\\\", \\\"{x:707,y:480,t:1527030626210};\\\", \\\"{x:751,y:511,t:1527030626228};\\\", \\\"{x:849,y:582,t:1527030626245};\\\", \\\"{x:981,y:665,t:1527030626260};\\\", \\\"{x:1309,y:838,t:1527030626290};\\\", \\\"{x:1490,y:919,t:1527030626307};\\\", \\\"{x:1756,y:998,t:1527030626324};\\\", \\\"{x:1899,y:1033,t:1527030626341};\\\", \\\"{x:1916,y:1012,t:1527030626582};\\\", \\\"{x:1904,y:1011,t:1527030626590};\\\", \\\"{x:1885,y:1009,t:1527030626607};\\\", \\\"{x:1869,y:1006,t:1527030626624};\\\", \\\"{x:1858,y:1006,t:1527030626641};\\\", \\\"{x:1852,y:1005,t:1527030626658};\\\", \\\"{x:1849,y:1004,t:1527030626675};\\\", \\\"{x:1848,y:1004,t:1527030626716};\\\", \\\"{x:1847,y:1004,t:1527030626725};\\\", \\\"{x:1847,y:1003,t:1527030626742};\\\", \\\"{x:1846,y:1003,t:1527030626759};\\\", \\\"{x:1845,y:1002,t:1527030626775};\\\", \\\"{x:1844,y:1002,t:1527030626797};\\\", \\\"{x:1843,y:1002,t:1527030626808};\\\", \\\"{x:1838,y:1002,t:1527030626825};\\\", \\\"{x:1830,y:1002,t:1527030626841};\\\", \\\"{x:1816,y:1002,t:1527030626858};\\\", \\\"{x:1801,y:1002,t:1527030626874};\\\", \\\"{x:1785,y:1002,t:1527030626892};\\\", \\\"{x:1761,y:1002,t:1527030626909};\\\", \\\"{x:1738,y:1002,t:1527030626925};\\\", \\\"{x:1715,y:1002,t:1527030626941};\\\", \\\"{x:1693,y:1002,t:1527030626959};\\\", \\\"{x:1673,y:1002,t:1527030626975};\\\", \\\"{x:1656,y:1002,t:1527030626992};\\\", \\\"{x:1640,y:1002,t:1527030627008};\\\", \\\"{x:1624,y:1002,t:1527030627025};\\\", \\\"{x:1610,y:1002,t:1527030627041};\\\", \\\"{x:1596,y:1002,t:1527030627059};\\\", \\\"{x:1581,y:1002,t:1527030627075};\\\", \\\"{x:1566,y:1002,t:1527030627092};\\\", \\\"{x:1548,y:1002,t:1527030627109};\\\", \\\"{x:1537,y:1002,t:1527030627125};\\\", \\\"{x:1523,y:1002,t:1527030627142};\\\", \\\"{x:1508,y:1002,t:1527030627159};\\\", \\\"{x:1487,y:1002,t:1527030627175};\\\", \\\"{x:1467,y:1001,t:1527030627191};\\\", \\\"{x:1449,y:1001,t:1527030627208};\\\", \\\"{x:1435,y:1000,t:1527030627226};\\\", \\\"{x:1418,y:998,t:1527030627242};\\\", \\\"{x:1396,y:995,t:1527030627259};\\\", \\\"{x:1374,y:991,t:1527030627276};\\\", \\\"{x:1348,y:986,t:1527030627292};\\\", \\\"{x:1326,y:985,t:1527030627308};\\\", \\\"{x:1316,y:984,t:1527030627325};\\\", \\\"{x:1308,y:982,t:1527030627342};\\\", \\\"{x:1306,y:982,t:1527030627359};\\\", \\\"{x:1305,y:982,t:1527030627375};\\\", \\\"{x:1305,y:978,t:1527030629549};\\\", \\\"{x:1305,y:974,t:1527030629561};\\\", \\\"{x:1306,y:965,t:1527030629578};\\\", \\\"{x:1310,y:956,t:1527030629595};\\\", \\\"{x:1314,y:943,t:1527030629612};\\\", \\\"{x:1321,y:925,t:1527030629627};\\\", \\\"{x:1331,y:901,t:1527030629644};\\\", \\\"{x:1360,y:846,t:1527030629661};\\\", \\\"{x:1377,y:809,t:1527030629677};\\\", \\\"{x:1390,y:776,t:1527030629694};\\\", \\\"{x:1402,y:755,t:1527030629712};\\\", \\\"{x:1410,y:739,t:1527030629727};\\\", \\\"{x:1411,y:737,t:1527030629745};\\\", \\\"{x:1411,y:736,t:1527030629761};\\\", \\\"{x:1411,y:735,t:1527030629781};\\\", \\\"{x:1410,y:735,t:1527030629797};\\\", \\\"{x:1409,y:734,t:1527030629812};\\\", \\\"{x:1407,y:733,t:1527030629828};\\\", \\\"{x:1404,y:732,t:1527030629844};\\\", \\\"{x:1399,y:730,t:1527030629861};\\\", \\\"{x:1397,y:729,t:1527030629878};\\\", \\\"{x:1395,y:728,t:1527030629894};\\\", \\\"{x:1394,y:728,t:1527030629925};\\\", \\\"{x:1394,y:727,t:1527030629933};\\\", \\\"{x:1392,y:727,t:1527030629957};\\\", \\\"{x:1390,y:726,t:1527030629964};\\\", \\\"{x:1390,y:725,t:1527030629980};\\\", \\\"{x:1388,y:725,t:1527030630012};\\\", \\\"{x:1386,y:724,t:1527030630029};\\\", \\\"{x:1385,y:723,t:1527030630044};\\\", \\\"{x:1380,y:719,t:1527030630060};\\\", \\\"{x:1376,y:715,t:1527030630078};\\\", \\\"{x:1374,y:712,t:1527030630094};\\\", \\\"{x:1372,y:710,t:1527030630111};\\\", \\\"{x:1372,y:709,t:1527030630127};\\\", \\\"{x:1372,y:708,t:1527030630165};\\\", \\\"{x:1372,y:707,t:1527030630178};\\\", \\\"{x:1372,y:705,t:1527030630195};\\\", \\\"{x:1372,y:704,t:1527030630211};\\\", \\\"{x:1372,y:702,t:1527030630228};\\\", \\\"{x:1372,y:701,t:1527030630253};\\\", \\\"{x:1371,y:700,t:1527030630438};\\\", \\\"{x:1371,y:699,t:1527030630445};\\\", \\\"{x:1370,y:699,t:1527030630461};\\\", \\\"{x:1368,y:699,t:1527030630478};\\\", \\\"{x:1366,y:698,t:1527030630495};\\\", \\\"{x:1365,y:697,t:1527030630511};\\\", \\\"{x:1364,y:696,t:1527030630982};\\\", \\\"{x:1363,y:696,t:1527030630995};\\\", \\\"{x:1361,y:695,t:1527030631012};\\\", \\\"{x:1359,y:694,t:1527030631029};\\\", \\\"{x:1358,y:694,t:1527030631053};\\\", \\\"{x:1358,y:693,t:1527030631069};\\\", \\\"{x:1357,y:693,t:1527030631079};\\\", \\\"{x:1355,y:693,t:1527030631095};\\\", \\\"{x:1354,y:693,t:1527030631112};\\\", \\\"{x:1353,y:693,t:1527030631129};\\\", \\\"{x:1352,y:693,t:1527030631146};\\\", \\\"{x:1351,y:693,t:1527030631317};\\\", \\\"{x:1351,y:695,t:1527030631333};\\\", \\\"{x:1351,y:697,t:1527030631345};\\\", \\\"{x:1351,y:700,t:1527030631362};\\\", \\\"{x:1351,y:703,t:1527030631379};\\\", \\\"{x:1351,y:705,t:1527030631395};\\\", \\\"{x:1351,y:709,t:1527030631412};\\\", \\\"{x:1351,y:715,t:1527030631429};\\\", \\\"{x:1351,y:720,t:1527030631446};\\\", \\\"{x:1351,y:727,t:1527030631462};\\\", \\\"{x:1351,y:734,t:1527030631478};\\\", \\\"{x:1351,y:741,t:1527030631496};\\\", \\\"{x:1351,y:748,t:1527030631511};\\\", \\\"{x:1351,y:753,t:1527030631529};\\\", \\\"{x:1351,y:757,t:1527030631546};\\\", \\\"{x:1351,y:761,t:1527030631562};\\\", \\\"{x:1351,y:763,t:1527030631578};\\\", \\\"{x:1351,y:765,t:1527030631596};\\\", \\\"{x:1351,y:767,t:1527030631611};\\\", \\\"{x:1351,y:770,t:1527030631629};\\\", \\\"{x:1351,y:773,t:1527030631645};\\\", \\\"{x:1351,y:774,t:1527030631669};\\\", \\\"{x:1351,y:775,t:1527030631679};\\\", \\\"{x:1351,y:773,t:1527030632406};\\\", \\\"{x:1351,y:772,t:1527030632413};\\\", \\\"{x:1351,y:769,t:1527030632429};\\\", \\\"{x:1350,y:766,t:1527030632446};\\\", \\\"{x:1348,y:761,t:1527030632463};\\\", \\\"{x:1347,y:759,t:1527030632480};\\\", \\\"{x:1347,y:754,t:1527030632497};\\\", \\\"{x:1347,y:753,t:1527030632513};\\\", \\\"{x:1347,y:749,t:1527030632530};\\\", \\\"{x:1345,y:748,t:1527030632546};\\\", \\\"{x:1345,y:746,t:1527030632563};\\\", \\\"{x:1345,y:744,t:1527030632580};\\\", \\\"{x:1345,y:742,t:1527030632597};\\\", \\\"{x:1344,y:736,t:1527030632613};\\\", \\\"{x:1344,y:735,t:1527030632630};\\\", \\\"{x:1344,y:731,t:1527030632646};\\\", \\\"{x:1344,y:729,t:1527030632663};\\\", \\\"{x:1344,y:728,t:1527030632681};\\\", \\\"{x:1344,y:725,t:1527030632696};\\\", \\\"{x:1344,y:721,t:1527030632714};\\\", \\\"{x:1344,y:718,t:1527030632731};\\\", \\\"{x:1344,y:715,t:1527030632746};\\\", \\\"{x:1344,y:714,t:1527030632763};\\\", \\\"{x:1344,y:712,t:1527030632781};\\\", \\\"{x:1344,y:710,t:1527030633502};\\\", \\\"{x:1344,y:708,t:1527030633514};\\\", \\\"{x:1344,y:704,t:1527030633530};\\\", \\\"{x:1344,y:701,t:1527030633546};\\\", \\\"{x:1344,y:698,t:1527030633564};\\\", \\\"{x:1344,y:697,t:1527030633580};\\\", \\\"{x:1344,y:696,t:1527030633597};\\\", \\\"{x:1344,y:695,t:1527030633628};\\\", \\\"{x:1344,y:698,t:1527030634181};\\\", \\\"{x:1344,y:705,t:1527030634199};\\\", \\\"{x:1344,y:715,t:1527030634214};\\\", \\\"{x:1343,y:721,t:1527030634232};\\\", \\\"{x:1343,y:726,t:1527030634248};\\\", \\\"{x:1343,y:729,t:1527030634264};\\\", \\\"{x:1343,y:731,t:1527030634281};\\\", \\\"{x:1343,y:735,t:1527030634299};\\\", \\\"{x:1343,y:740,t:1527030634314};\\\", \\\"{x:1343,y:744,t:1527030634332};\\\", \\\"{x:1343,y:749,t:1527030634348};\\\", \\\"{x:1343,y:751,t:1527030634364};\\\", \\\"{x:1343,y:754,t:1527030634381};\\\", \\\"{x:1343,y:757,t:1527030634398};\\\", \\\"{x:1343,y:759,t:1527030634415};\\\", \\\"{x:1343,y:761,t:1527030634432};\\\", \\\"{x:1343,y:762,t:1527030634464};\\\", \\\"{x:1343,y:763,t:1527030634481};\\\", \\\"{x:1343,y:764,t:1527030634498};\\\", \\\"{x:1343,y:765,t:1527030636629};\\\", \\\"{x:1340,y:765,t:1527030637086};\\\", \\\"{x:1325,y:760,t:1527030637101};\\\", \\\"{x:1273,y:745,t:1527030637117};\\\", \\\"{x:1117,y:730,t:1527030637134};\\\", \\\"{x:1007,y:720,t:1527030637150};\\\", \\\"{x:907,y:706,t:1527030637167};\\\", \\\"{x:816,y:695,t:1527030637184};\\\", \\\"{x:745,y:682,t:1527030637201};\\\", \\\"{x:711,y:678,t:1527030637218};\\\", \\\"{x:694,y:674,t:1527030637233};\\\", \\\"{x:690,y:671,t:1527030637251};\\\", \\\"{x:691,y:670,t:1527030637267};\\\", \\\"{x:691,y:669,t:1527030637283};\\\", \\\"{x:685,y:668,t:1527030637645};\\\", \\\"{x:667,y:665,t:1527030637653};\\\", \\\"{x:648,y:660,t:1527030637667};\\\", \\\"{x:607,y:650,t:1527030637684};\\\", \\\"{x:567,y:630,t:1527030637700};\\\", \\\"{x:514,y:602,t:1527030637716};\\\", \\\"{x:469,y:582,t:1527030637733};\\\", \\\"{x:444,y:574,t:1527030637749};\\\", \\\"{x:428,y:568,t:1527030637765};\\\", \\\"{x:416,y:561,t:1527030637783};\\\", \\\"{x:414,y:560,t:1527030637799};\\\", \\\"{x:411,y:556,t:1527030637816};\\\", \\\"{x:407,y:552,t:1527030637835};\\\", \\\"{x:406,y:550,t:1527030637850};\\\", \\\"{x:404,y:549,t:1527030637867};\\\", \\\"{x:402,y:549,t:1527030637884};\\\", \\\"{x:390,y:549,t:1527030637900};\\\", \\\"{x:377,y:549,t:1527030637917};\\\", \\\"{x:358,y:549,t:1527030637934};\\\", \\\"{x:340,y:550,t:1527030637951};\\\", \\\"{x:328,y:558,t:1527030637968};\\\", \\\"{x:328,y:569,t:1527030637984};\\\", \\\"{x:339,y:587,t:1527030638001};\\\", \\\"{x:364,y:599,t:1527030638017};\\\", \\\"{x:393,y:602,t:1527030638034};\\\", \\\"{x:422,y:602,t:1527030638050};\\\", \\\"{x:450,y:602,t:1527030638066};\\\", \\\"{x:491,y:595,t:1527030638084};\\\", \\\"{x:551,y:587,t:1527030638101};\\\", \\\"{x:583,y:580,t:1527030638116};\\\", \\\"{x:608,y:574,t:1527030638134};\\\", \\\"{x:627,y:568,t:1527030638151};\\\", \\\"{x:645,y:561,t:1527030638168};\\\", \\\"{x:658,y:558,t:1527030638183};\\\", \\\"{x:662,y:555,t:1527030638202};\\\", \\\"{x:666,y:551,t:1527030638217};\\\", \\\"{x:667,y:551,t:1527030638234};\\\", \\\"{x:669,y:550,t:1527030638251};\\\", \\\"{x:669,y:549,t:1527030638266};\\\", \\\"{x:669,y:548,t:1527030638283};\\\", \\\"{x:669,y:546,t:1527030638300};\\\", \\\"{x:659,y:540,t:1527030638317};\\\", \\\"{x:649,y:539,t:1527030638334};\\\", \\\"{x:637,y:538,t:1527030638351};\\\", \\\"{x:631,y:538,t:1527030638367};\\\", \\\"{x:629,y:538,t:1527030638384};\\\", \\\"{x:627,y:538,t:1527030638401};\\\", \\\"{x:624,y:540,t:1527030638418};\\\", \\\"{x:622,y:542,t:1527030638434};\\\", \\\"{x:620,y:545,t:1527030638451};\\\", \\\"{x:619,y:547,t:1527030638468};\\\", \\\"{x:619,y:550,t:1527030638484};\\\", \\\"{x:619,y:551,t:1527030638501};\\\", \\\"{x:620,y:553,t:1527030638519};\\\", \\\"{x:627,y:555,t:1527030638534};\\\", \\\"{x:642,y:555,t:1527030638551};\\\", \\\"{x:666,y:555,t:1527030638568};\\\", \\\"{x:695,y:552,t:1527030638584};\\\", \\\"{x:734,y:545,t:1527030638601};\\\", \\\"{x:771,y:533,t:1527030638618};\\\", \\\"{x:799,y:526,t:1527030638634};\\\", \\\"{x:821,y:519,t:1527030638651};\\\", \\\"{x:832,y:516,t:1527030638668};\\\", \\\"{x:837,y:514,t:1527030638684};\\\", \\\"{x:839,y:514,t:1527030638701};\\\", \\\"{x:840,y:512,t:1527030638733};\\\", \\\"{x:841,y:512,t:1527030638750};\\\", \\\"{x:846,y:510,t:1527030638767};\\\", \\\"{x:849,y:507,t:1527030638784};\\\", \\\"{x:854,y:504,t:1527030638800};\\\", \\\"{x:856,y:503,t:1527030638817};\\\", \\\"{x:857,y:502,t:1527030638834};\\\", \\\"{x:857,y:501,t:1527030638949};\\\", \\\"{x:856,y:501,t:1527030638973};\\\", \\\"{x:855,y:501,t:1527030638985};\\\", \\\"{x:853,y:502,t:1527030639001};\\\", \\\"{x:852,y:503,t:1527030639018};\\\", \\\"{x:851,y:504,t:1527030639037};\\\", \\\"{x:850,y:504,t:1527030639061};\\\", \\\"{x:849,y:505,t:1527030639069};\\\", \\\"{x:848,y:506,t:1527030639085};\\\", \\\"{x:846,y:507,t:1527030639101};\\\", \\\"{x:844,y:507,t:1527030639119};\\\", \\\"{x:844,y:508,t:1527030639135};\\\", \\\"{x:843,y:509,t:1527030639151};\\\", \\\"{x:842,y:510,t:1527030639169};\\\", \\\"{x:840,y:511,t:1527030639516};\\\", \\\"{x:836,y:511,t:1527030639524};\\\", \\\"{x:832,y:512,t:1527030639535};\\\", \\\"{x:816,y:518,t:1527030639553};\\\", \\\"{x:796,y:528,t:1527030639568};\\\", \\\"{x:767,y:545,t:1527030639584};\\\", \\\"{x:719,y:571,t:1527030639603};\\\", \\\"{x:660,y:599,t:1527030639619};\\\", \\\"{x:603,y:619,t:1527030639635};\\\", \\\"{x:531,y:633,t:1527030639653};\\\", \\\"{x:499,y:638,t:1527030639668};\\\", \\\"{x:483,y:640,t:1527030639685};\\\", \\\"{x:481,y:640,t:1527030639701};\\\", \\\"{x:480,y:640,t:1527030639719};\\\", \\\"{x:479,y:640,t:1527030639805};\\\", \\\"{x:476,y:640,t:1527030639819};\\\", \\\"{x:471,y:639,t:1527030639836};\\\", \\\"{x:466,y:646,t:1527030639852};\\\", \\\"{x:458,y:654,t:1527030639869};\\\", \\\"{x:442,y:665,t:1527030639886};\\\", \\\"{x:427,y:671,t:1527030639904};\\\", \\\"{x:415,y:674,t:1527030639919};\\\", \\\"{x:404,y:675,t:1527030639935};\\\", \\\"{x:400,y:675,t:1527030639952};\\\", \\\"{x:395,y:675,t:1527030639968};\\\", \\\"{x:392,y:674,t:1527030639985};\\\", \\\"{x:389,y:672,t:1527030640001};\\\", \\\"{x:384,y:665,t:1527030640019};\\\", \\\"{x:379,y:657,t:1527030640034};\\\", \\\"{x:365,y:640,t:1527030640052};\\\", \\\"{x:354,y:631,t:1527030640069};\\\", \\\"{x:342,y:621,t:1527030640086};\\\", \\\"{x:335,y:618,t:1527030640102};\\\", \\\"{x:331,y:617,t:1527030640119};\\\", \\\"{x:329,y:617,t:1527030640136};\\\", \\\"{x:323,y:617,t:1527030640152};\\\", \\\"{x:307,y:618,t:1527030640169};\\\", \\\"{x:286,y:625,t:1527030640186};\\\", \\\"{x:260,y:631,t:1527030640203};\\\", \\\"{x:238,y:638,t:1527030640219};\\\", \\\"{x:223,y:642,t:1527030640236};\\\", \\\"{x:211,y:643,t:1527030640251};\\\", \\\"{x:206,y:643,t:1527030640269};\\\", \\\"{x:200,y:643,t:1527030640286};\\\", \\\"{x:193,y:643,t:1527030640302};\\\", \\\"{x:185,y:643,t:1527030640319};\\\", \\\"{x:178,y:643,t:1527030640336};\\\", \\\"{x:172,y:643,t:1527030640352};\\\", \\\"{x:166,y:643,t:1527030640369};\\\", \\\"{x:161,y:643,t:1527030640385};\\\", \\\"{x:158,y:643,t:1527030640402};\\\", \\\"{x:157,y:643,t:1527030640419};\\\", \\\"{x:156,y:643,t:1527030640436};\\\", \\\"{x:155,y:643,t:1527030640452};\\\", \\\"{x:154,y:634,t:1527030640470};\\\", \\\"{x:154,y:627,t:1527030640486};\\\", \\\"{x:154,y:620,t:1527030640503};\\\", \\\"{x:157,y:615,t:1527030640519};\\\", \\\"{x:160,y:609,t:1527030640536};\\\", \\\"{x:164,y:601,t:1527030640553};\\\", \\\"{x:168,y:594,t:1527030640570};\\\", \\\"{x:172,y:589,t:1527030640586};\\\", \\\"{x:173,y:586,t:1527030640602};\\\", \\\"{x:174,y:583,t:1527030640618};\\\", \\\"{x:174,y:580,t:1527030640635};\\\", \\\"{x:174,y:579,t:1527030640660};\\\", \\\"{x:174,y:578,t:1527030640692};\\\", \\\"{x:174,y:577,t:1527030640702};\\\", \\\"{x:174,y:575,t:1527030640719};\\\", \\\"{x:174,y:572,t:1527030640736};\\\", \\\"{x:174,y:566,t:1527030640752};\\\", \\\"{x:174,y:560,t:1527030640769};\\\", \\\"{x:174,y:557,t:1527030640785};\\\", \\\"{x:174,y:555,t:1527030640803};\\\", \\\"{x:174,y:554,t:1527030640819};\\\", \\\"{x:174,y:553,t:1527030640868};\\\", \\\"{x:174,y:552,t:1527030640876};\\\", \\\"{x:174,y:551,t:1527030640886};\\\", \\\"{x:174,y:548,t:1527030640904};\\\", \\\"{x:175,y:545,t:1527030640919};\\\", \\\"{x:175,y:540,t:1527030640936};\\\", \\\"{x:175,y:538,t:1527030640953};\\\", \\\"{x:177,y:537,t:1527030641284};\\\", \\\"{x:183,y:539,t:1527030641292};\\\", \\\"{x:193,y:545,t:1527030641303};\\\", \\\"{x:226,y:568,t:1527030641321};\\\", \\\"{x:278,y:600,t:1527030641336};\\\", \\\"{x:329,y:626,t:1527030641353};\\\", \\\"{x:361,y:644,t:1527030641371};\\\", \\\"{x:391,y:657,t:1527030641387};\\\", \\\"{x:425,y:674,t:1527030641404};\\\", \\\"{x:484,y:698,t:1527030641420};\\\", \\\"{x:518,y:713,t:1527030641436};\\\", \\\"{x:539,y:722,t:1527030641453};\\\", \\\"{x:554,y:730,t:1527030641470};\\\", \\\"{x:559,y:734,t:1527030641486};\\\", \\\"{x:560,y:734,t:1527030641508};\\\", \\\"{x:559,y:735,t:1527030641997};\\\", \\\"{x:558,y:736,t:1527030642004};\\\", \\\"{x:557,y:736,t:1527030642019};\\\", \\\"{x:552,y:738,t:1527030642037};\\\", \\\"{x:551,y:738,t:1527030642054};\\\", \\\"{x:550,y:738,t:1527030642093};\\\" ] }, { \\\"rt\\\": 42904, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 599788, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-X -G -E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:739,t:1527030645126};\\\", \\\"{x:542,y:738,t:1527030645137};\\\", \\\"{x:514,y:729,t:1527030645154};\\\", \\\"{x:464,y:714,t:1527030645171};\\\", \\\"{x:377,y:688,t:1527030645186};\\\", \\\"{x:267,y:657,t:1527030645204};\\\", \\\"{x:171,y:614,t:1527030645224};\\\", \\\"{x:164,y:593,t:1527030645241};\\\", \\\"{x:170,y:574,t:1527030645256};\\\", \\\"{x:182,y:560,t:1527030645273};\\\", \\\"{x:191,y:546,t:1527030645289};\\\", \\\"{x:205,y:527,t:1527030645306};\\\", \\\"{x:215,y:503,t:1527030645324};\\\", \\\"{x:223,y:476,t:1527030645340};\\\", \\\"{x:228,y:466,t:1527030645356};\\\", \\\"{x:230,y:464,t:1527030645373};\\\", \\\"{x:231,y:463,t:1527030645390};\\\", \\\"{x:232,y:463,t:1527030645436};\\\", \\\"{x:233,y:463,t:1527030645444};\\\", \\\"{x:235,y:463,t:1527030645456};\\\", \\\"{x:238,y:463,t:1527030645473};\\\", \\\"{x:242,y:463,t:1527030645490};\\\", \\\"{x:245,y:464,t:1527030645507};\\\", \\\"{x:254,y:464,t:1527030645524};\\\", \\\"{x:269,y:464,t:1527030645540};\\\", \\\"{x:277,y:464,t:1527030645557};\\\", \\\"{x:287,y:461,t:1527030645574};\\\", \\\"{x:293,y:461,t:1527030645590};\\\", \\\"{x:300,y:461,t:1527030645607};\\\", \\\"{x:304,y:461,t:1527030645623};\\\", \\\"{x:306,y:461,t:1527030645640};\\\", \\\"{x:308,y:461,t:1527030645656};\\\", \\\"{x:310,y:461,t:1527030645673};\\\", \\\"{x:311,y:461,t:1527030645690};\\\", \\\"{x:312,y:461,t:1527030645706};\\\", \\\"{x:315,y:461,t:1527030645723};\\\", \\\"{x:320,y:461,t:1527030645740};\\\", \\\"{x:325,y:461,t:1527030645757};\\\", \\\"{x:331,y:461,t:1527030645773};\\\", \\\"{x:338,y:461,t:1527030645790};\\\", \\\"{x:347,y:461,t:1527030645806};\\\", \\\"{x:361,y:461,t:1527030645823};\\\", \\\"{x:376,y:461,t:1527030645840};\\\", \\\"{x:391,y:461,t:1527030645856};\\\", \\\"{x:409,y:461,t:1527030645873};\\\", \\\"{x:424,y:461,t:1527030645890};\\\", \\\"{x:435,y:461,t:1527030645906};\\\", \\\"{x:445,y:461,t:1527030645924};\\\", \\\"{x:458,y:461,t:1527030645940};\\\", \\\"{x:467,y:462,t:1527030645957};\\\", \\\"{x:473,y:464,t:1527030645973};\\\", \\\"{x:479,y:465,t:1527030645991};\\\", \\\"{x:482,y:465,t:1527030646007};\\\", \\\"{x:485,y:465,t:1527030646024};\\\", \\\"{x:487,y:465,t:1527030646041};\\\", \\\"{x:491,y:465,t:1527030646057};\\\", \\\"{x:493,y:465,t:1527030646073};\\\", \\\"{x:497,y:465,t:1527030646090};\\\", \\\"{x:498,y:465,t:1527030646107};\\\", \\\"{x:501,y:465,t:1527030646124};\\\", \\\"{x:503,y:465,t:1527030646140};\\\", \\\"{x:505,y:465,t:1527030646157};\\\", \\\"{x:507,y:465,t:1527030646174};\\\", \\\"{x:508,y:465,t:1527030646197};\\\", \\\"{x:510,y:465,t:1527030646613};\\\", \\\"{x:513,y:465,t:1527030646624};\\\", \\\"{x:521,y:465,t:1527030646640};\\\", \\\"{x:534,y:465,t:1527030646658};\\\", \\\"{x:548,y:465,t:1527030646674};\\\", \\\"{x:567,y:465,t:1527030646691};\\\", \\\"{x:579,y:465,t:1527030646708};\\\", \\\"{x:593,y:465,t:1527030646724};\\\", \\\"{x:606,y:465,t:1527030646741};\\\", \\\"{x:609,y:464,t:1527030646758};\\\", \\\"{x:610,y:464,t:1527030646774};\\\", \\\"{x:611,y:464,t:1527030646791};\\\", \\\"{x:612,y:464,t:1527030646949};\\\", \\\"{x:613,y:464,t:1527030646965};\\\", \\\"{x:614,y:464,t:1527030646975};\\\", \\\"{x:618,y:464,t:1527030646991};\\\", \\\"{x:619,y:464,t:1527030647008};\\\", \\\"{x:621,y:464,t:1527030647024};\\\", \\\"{x:623,y:464,t:1527030647041};\\\", \\\"{x:624,y:464,t:1527030647076};\\\", \\\"{x:625,y:465,t:1527030648373};\\\", \\\"{x:633,y:466,t:1527030648380};\\\", \\\"{x:640,y:469,t:1527030648391};\\\", \\\"{x:658,y:472,t:1527030648409};\\\", \\\"{x:686,y:476,t:1527030648425};\\\", \\\"{x:717,y:477,t:1527030648441};\\\", \\\"{x:751,y:477,t:1527030648458};\\\", \\\"{x:787,y:477,t:1527030648475};\\\", \\\"{x:816,y:477,t:1527030648492};\\\", \\\"{x:836,y:477,t:1527030648509};\\\", \\\"{x:839,y:477,t:1527030648524};\\\", \\\"{x:838,y:477,t:1527030648662};\\\", \\\"{x:838,y:476,t:1527030648674};\\\", \\\"{x:837,y:476,t:1527030648693};\\\", \\\"{x:839,y:476,t:1527030648813};\\\", \\\"{x:843,y:476,t:1527030648824};\\\", \\\"{x:857,y:476,t:1527030648842};\\\", \\\"{x:877,y:476,t:1527030648858};\\\", \\\"{x:907,y:475,t:1527030648875};\\\", \\\"{x:949,y:475,t:1527030648891};\\\", \\\"{x:1030,y:475,t:1527030648909};\\\", \\\"{x:1094,y:475,t:1527030648925};\\\", \\\"{x:1155,y:475,t:1527030648942};\\\", \\\"{x:1214,y:475,t:1527030648959};\\\", \\\"{x:1267,y:475,t:1527030648975};\\\", \\\"{x:1303,y:475,t:1527030648992};\\\", \\\"{x:1330,y:475,t:1527030649009};\\\", \\\"{x:1351,y:475,t:1527030649025};\\\", \\\"{x:1360,y:475,t:1527030649041};\\\", \\\"{x:1364,y:475,t:1527030649059};\\\", \\\"{x:1366,y:476,t:1527030649075};\\\", \\\"{x:1367,y:477,t:1527030649092};\\\", \\\"{x:1369,y:478,t:1527030649109};\\\", \\\"{x:1372,y:481,t:1527030649125};\\\", \\\"{x:1374,y:483,t:1527030649142};\\\", \\\"{x:1379,y:487,t:1527030649159};\\\", \\\"{x:1387,y:493,t:1527030649176};\\\", \\\"{x:1390,y:496,t:1527030649192};\\\", \\\"{x:1390,y:497,t:1527030649209};\\\", \\\"{x:1391,y:497,t:1527030649226};\\\", \\\"{x:1392,y:498,t:1527030649253};\\\", \\\"{x:1393,y:498,t:1527030649341};\\\", \\\"{x:1394,y:499,t:1527030649365};\\\", \\\"{x:1395,y:499,t:1527030649381};\\\", \\\"{x:1396,y:499,t:1527030649397};\\\", \\\"{x:1397,y:499,t:1527030649413};\\\", \\\"{x:1398,y:499,t:1527030649429};\\\", \\\"{x:1399,y:499,t:1527030649445};\\\", \\\"{x:1400,y:499,t:1527030649484};\\\", \\\"{x:1401,y:499,t:1527030649500};\\\", \\\"{x:1402,y:499,t:1527030649516};\\\", \\\"{x:1403,y:498,t:1527030649555};\\\", \\\"{x:1404,y:497,t:1527030649572};\\\", \\\"{x:1405,y:497,t:1527030649604};\\\", \\\"{x:1405,y:496,t:1527030649733};\\\", \\\"{x:1405,y:495,t:1527030649742};\\\", \\\"{x:1405,y:494,t:1527030649758};\\\", \\\"{x:1405,y:492,t:1527030649780};\\\", \\\"{x:1405,y:491,t:1527030649805};\\\", \\\"{x:1405,y:489,t:1527030649837};\\\", \\\"{x:1405,y:488,t:1527030649862};\\\", \\\"{x:1404,y:487,t:1527030649901};\\\", \\\"{x:1404,y:486,t:1527030649916};\\\", \\\"{x:1404,y:485,t:1527030649932};\\\", \\\"{x:1403,y:484,t:1527030650037};\\\", \\\"{x:1402,y:483,t:1527030650069};\\\", \\\"{x:1402,y:482,t:1527030650157};\\\", \\\"{x:1401,y:480,t:1527030650180};\\\", \\\"{x:1399,y:478,t:1527030650197};\\\", \\\"{x:1399,y:477,t:1527030650209};\\\", \\\"{x:1397,y:473,t:1527030650226};\\\", \\\"{x:1396,y:472,t:1527030650243};\\\", \\\"{x:1394,y:467,t:1527030650259};\\\", \\\"{x:1392,y:465,t:1527030650276};\\\", \\\"{x:1391,y:463,t:1527030650292};\\\", \\\"{x:1389,y:462,t:1527030650309};\\\", \\\"{x:1389,y:461,t:1527030650333};\\\", \\\"{x:1390,y:466,t:1527030651165};\\\", \\\"{x:1399,y:496,t:1527030651176};\\\", \\\"{x:1431,y:615,t:1527030651193};\\\", \\\"{x:1462,y:744,t:1527030651210};\\\", \\\"{x:1487,y:867,t:1527030651226};\\\", \\\"{x:1504,y:978,t:1527030651243};\\\", \\\"{x:1521,y:1045,t:1527030651260};\\\", \\\"{x:1542,y:1076,t:1527030651277};\\\", \\\"{x:1548,y:1080,t:1527030651293};\\\", \\\"{x:1550,y:1080,t:1527030651310};\\\", \\\"{x:1555,y:1074,t:1527030651327};\\\", \\\"{x:1558,y:1055,t:1527030651343};\\\", \\\"{x:1558,y:1038,t:1527030651361};\\\", \\\"{x:1558,y:1022,t:1527030651377};\\\", \\\"{x:1558,y:1001,t:1527030651393};\\\", \\\"{x:1557,y:985,t:1527030651410};\\\", \\\"{x:1553,y:971,t:1527030651427};\\\", \\\"{x:1548,y:960,t:1527030651444};\\\", \\\"{x:1543,y:953,t:1527030651460};\\\", \\\"{x:1543,y:948,t:1527030651477};\\\", \\\"{x:1542,y:948,t:1527030651492};\\\", \\\"{x:1540,y:946,t:1527030651510};\\\", \\\"{x:1536,y:944,t:1527030651527};\\\", \\\"{x:1521,y:934,t:1527030651543};\\\", \\\"{x:1484,y:910,t:1527030651560};\\\", \\\"{x:1447,y:885,t:1527030651576};\\\", \\\"{x:1437,y:878,t:1527030651593};\\\", \\\"{x:1437,y:877,t:1527030651611};\\\", \\\"{x:1437,y:874,t:1527030651627};\\\", \\\"{x:1437,y:872,t:1527030651643};\\\", \\\"{x:1437,y:869,t:1527030651659};\\\", \\\"{x:1437,y:859,t:1527030651676};\\\", \\\"{x:1443,y:850,t:1527030651692};\\\", \\\"{x:1452,y:838,t:1527030651709};\\\", \\\"{x:1463,y:830,t:1527030651727};\\\", \\\"{x:1475,y:822,t:1527030651742};\\\", \\\"{x:1480,y:818,t:1527030651759};\\\", \\\"{x:1482,y:817,t:1527030651777};\\\", \\\"{x:1484,y:816,t:1527030651792};\\\", \\\"{x:1483,y:815,t:1527030651909};\\\", \\\"{x:1482,y:815,t:1527030651957};\\\", \\\"{x:1480,y:815,t:1527030651973};\\\", \\\"{x:1479,y:815,t:1527030651989};\\\", \\\"{x:1477,y:815,t:1527030652021};\\\", \\\"{x:1476,y:816,t:1527030653125};\\\", \\\"{x:1470,y:814,t:1527030654292};\\\", \\\"{x:1461,y:810,t:1527030654300};\\\", \\\"{x:1457,y:808,t:1527030654310};\\\", \\\"{x:1441,y:802,t:1527030654327};\\\", \\\"{x:1431,y:798,t:1527030654344};\\\", \\\"{x:1420,y:790,t:1527030654360};\\\", \\\"{x:1403,y:778,t:1527030654378};\\\", \\\"{x:1379,y:759,t:1527030654395};\\\", \\\"{x:1354,y:735,t:1527030654411};\\\", \\\"{x:1321,y:710,t:1527030654428};\\\", \\\"{x:1250,y:642,t:1527030654444};\\\", \\\"{x:1202,y:605,t:1527030654461};\\\", \\\"{x:1187,y:590,t:1527030654477};\\\", \\\"{x:1187,y:589,t:1527030654494};\\\", \\\"{x:1187,y:588,t:1527030654557};\\\", \\\"{x:1190,y:588,t:1527030654573};\\\", \\\"{x:1192,y:588,t:1527030654588};\\\", \\\"{x:1193,y:588,t:1527030654597};\\\", \\\"{x:1197,y:588,t:1527030654611};\\\", \\\"{x:1205,y:588,t:1527030654628};\\\", \\\"{x:1213,y:585,t:1527030654645};\\\", \\\"{x:1220,y:581,t:1527030654662};\\\", \\\"{x:1230,y:576,t:1527030654678};\\\", \\\"{x:1243,y:571,t:1527030654695};\\\", \\\"{x:1258,y:566,t:1527030654711};\\\", \\\"{x:1273,y:559,t:1527030654728};\\\", \\\"{x:1289,y:554,t:1527030654745};\\\", \\\"{x:1302,y:550,t:1527030654760};\\\", \\\"{x:1309,y:548,t:1527030654778};\\\", \\\"{x:1316,y:546,t:1527030654795};\\\", \\\"{x:1324,y:546,t:1527030654811};\\\", \\\"{x:1332,y:545,t:1527030654828};\\\", \\\"{x:1344,y:545,t:1527030654844};\\\", \\\"{x:1349,y:546,t:1527030654862};\\\", \\\"{x:1354,y:546,t:1527030654878};\\\", \\\"{x:1360,y:546,t:1527030654895};\\\", \\\"{x:1368,y:546,t:1527030654911};\\\", \\\"{x:1382,y:546,t:1527030654927};\\\", \\\"{x:1397,y:546,t:1527030654945};\\\", \\\"{x:1421,y:545,t:1527030654962};\\\", \\\"{x:1447,y:543,t:1527030654978};\\\", \\\"{x:1467,y:540,t:1527030654995};\\\", \\\"{x:1485,y:540,t:1527030655012};\\\", \\\"{x:1497,y:538,t:1527030655028};\\\", \\\"{x:1516,y:537,t:1527030655045};\\\", \\\"{x:1524,y:535,t:1527030655063};\\\", \\\"{x:1532,y:534,t:1527030655078};\\\", \\\"{x:1537,y:533,t:1527030655095};\\\", \\\"{x:1544,y:532,t:1527030655112};\\\", \\\"{x:1547,y:532,t:1527030655128};\\\", \\\"{x:1550,y:531,t:1527030655145};\\\", \\\"{x:1551,y:531,t:1527030655162};\\\", \\\"{x:1552,y:531,t:1527030655178};\\\", \\\"{x:1551,y:531,t:1527030656676};\\\", \\\"{x:1549,y:531,t:1527030656684};\\\", \\\"{x:1548,y:531,t:1527030656696};\\\", \\\"{x:1546,y:531,t:1527030656712};\\\", \\\"{x:1544,y:532,t:1527030656733};\\\", \\\"{x:1543,y:532,t:1527030656773};\\\", \\\"{x:1542,y:532,t:1527030656780};\\\", \\\"{x:1541,y:533,t:1527030656813};\\\", \\\"{x:1541,y:534,t:1527030658126};\\\", \\\"{x:1539,y:534,t:1527030658133};\\\", \\\"{x:1538,y:534,t:1527030658148};\\\", \\\"{x:1538,y:535,t:1527030658164};\\\", \\\"{x:1533,y:537,t:1527030658180};\\\", \\\"{x:1532,y:537,t:1527030658197};\\\", \\\"{x:1529,y:537,t:1527030658214};\\\", \\\"{x:1527,y:537,t:1527030658231};\\\", \\\"{x:1524,y:539,t:1527030658247};\\\", \\\"{x:1521,y:540,t:1527030658264};\\\", \\\"{x:1517,y:542,t:1527030658281};\\\", \\\"{x:1514,y:544,t:1527030658296};\\\", \\\"{x:1510,y:545,t:1527030658314};\\\", \\\"{x:1508,y:545,t:1527030658330};\\\", \\\"{x:1506,y:545,t:1527030658346};\\\", \\\"{x:1504,y:547,t:1527030658364};\\\", \\\"{x:1503,y:547,t:1527030658380};\\\", \\\"{x:1501,y:548,t:1527030658397};\\\", \\\"{x:1498,y:548,t:1527030658429};\\\", \\\"{x:1497,y:548,t:1527030658453};\\\", \\\"{x:1496,y:548,t:1527030658463};\\\", \\\"{x:1494,y:550,t:1527030658479};\\\", \\\"{x:1493,y:550,t:1527030658500};\\\", \\\"{x:1492,y:550,t:1527030658515};\\\", \\\"{x:1491,y:550,t:1527030658548};\\\", \\\"{x:1489,y:550,t:1527030658563};\\\", \\\"{x:1488,y:550,t:1527030658589};\\\", \\\"{x:1488,y:551,t:1527030658605};\\\", \\\"{x:1487,y:551,t:1527030658613};\\\", \\\"{x:1486,y:551,t:1527030658630};\\\", \\\"{x:1484,y:552,t:1527030658647};\\\", \\\"{x:1482,y:552,t:1527030658663};\\\", \\\"{x:1482,y:553,t:1527030658680};\\\", \\\"{x:1480,y:553,t:1527030658697};\\\", \\\"{x:1479,y:554,t:1527030658716};\\\", \\\"{x:1478,y:554,t:1527030658730};\\\", \\\"{x:1477,y:554,t:1527030658748};\\\", \\\"{x:1477,y:555,t:1527030658763};\\\", \\\"{x:1475,y:555,t:1527030658781};\\\", \\\"{x:1475,y:556,t:1527030658804};\\\", \\\"{x:1474,y:556,t:1527030658820};\\\", \\\"{x:1473,y:556,t:1527030658852};\\\", \\\"{x:1472,y:557,t:1527030658868};\\\", \\\"{x:1471,y:557,t:1527030658893};\\\", \\\"{x:1470,y:557,t:1527030658917};\\\", \\\"{x:1469,y:558,t:1527030658930};\\\", \\\"{x:1468,y:558,t:1527030658956};\\\", \\\"{x:1467,y:558,t:1527030658989};\\\", \\\"{x:1466,y:558,t:1527030659005};\\\", \\\"{x:1465,y:558,t:1527030659021};\\\", \\\"{x:1464,y:559,t:1527030659045};\\\", \\\"{x:1463,y:559,t:1527030659117};\\\", \\\"{x:1462,y:559,t:1527030659140};\\\", \\\"{x:1461,y:559,t:1527030659197};\\\", \\\"{x:1460,y:559,t:1527030659213};\\\", \\\"{x:1459,y:559,t:1527030659231};\\\", \\\"{x:1458,y:559,t:1527030659268};\\\", \\\"{x:1457,y:559,t:1527030659285};\\\", \\\"{x:1456,y:559,t:1527030659301};\\\", \\\"{x:1455,y:560,t:1527030659314};\\\", \\\"{x:1454,y:560,t:1527030659333};\\\", \\\"{x:1453,y:560,t:1527030659349};\\\", \\\"{x:1452,y:560,t:1527030659373};\\\", \\\"{x:1450,y:561,t:1527030659389};\\\", \\\"{x:1449,y:561,t:1527030659429};\\\", \\\"{x:1448,y:561,t:1527030659573};\\\", \\\"{x:1446,y:561,t:1527030660678};\\\", \\\"{x:1443,y:561,t:1527030660685};\\\", \\\"{x:1440,y:561,t:1527030660698};\\\", \\\"{x:1434,y:563,t:1527030660715};\\\", \\\"{x:1428,y:564,t:1527030660731};\\\", \\\"{x:1424,y:566,t:1527030660749};\\\", \\\"{x:1423,y:566,t:1527030660845};\\\", \\\"{x:1422,y:566,t:1527030660863};\\\", \\\"{x:1421,y:566,t:1527030660869};\\\", \\\"{x:1420,y:566,t:1527030660882};\\\", \\\"{x:1414,y:566,t:1527030660901};\\\", \\\"{x:1405,y:566,t:1527030660914};\\\", \\\"{x:1394,y:566,t:1527030660931};\\\", \\\"{x:1377,y:566,t:1527030660948};\\\", \\\"{x:1368,y:566,t:1527030660964};\\\", \\\"{x:1359,y:566,t:1527030660981};\\\", \\\"{x:1352,y:566,t:1527030660998};\\\", \\\"{x:1343,y:566,t:1527030661014};\\\", \\\"{x:1334,y:568,t:1527030661031};\\\", \\\"{x:1326,y:569,t:1527030661048};\\\", \\\"{x:1319,y:571,t:1527030661064};\\\", \\\"{x:1317,y:572,t:1527030661081};\\\", \\\"{x:1314,y:572,t:1527030661098};\\\", \\\"{x:1313,y:572,t:1527030661115};\\\", \\\"{x:1311,y:572,t:1527030661131};\\\", \\\"{x:1307,y:572,t:1527030661148};\\\", \\\"{x:1301,y:573,t:1527030661164};\\\", \\\"{x:1297,y:573,t:1527030661181};\\\", \\\"{x:1289,y:575,t:1527030661198};\\\", \\\"{x:1283,y:575,t:1527030661215};\\\", \\\"{x:1281,y:575,t:1527030661231};\\\", \\\"{x:1279,y:575,t:1527030661333};\\\", \\\"{x:1278,y:575,t:1527030661413};\\\", \\\"{x:1277,y:575,t:1527030661421};\\\", \\\"{x:1275,y:573,t:1527030661432};\\\", \\\"{x:1273,y:569,t:1527030661448};\\\", \\\"{x:1269,y:564,t:1527030661465};\\\", \\\"{x:1268,y:561,t:1527030661481};\\\", \\\"{x:1267,y:560,t:1527030661498};\\\", \\\"{x:1266,y:559,t:1527030661515};\\\", \\\"{x:1267,y:559,t:1527030664573};\\\", \\\"{x:1269,y:559,t:1527030664583};\\\", \\\"{x:1270,y:559,t:1527030664600};\\\", \\\"{x:1271,y:559,t:1527030664616};\\\", \\\"{x:1272,y:559,t:1527030664645};\\\", \\\"{x:1273,y:560,t:1527030665037};\\\", \\\"{x:1274,y:561,t:1527030665050};\\\", \\\"{x:1275,y:561,t:1527030665066};\\\", \\\"{x:1276,y:561,t:1527030665085};\\\", \\\"{x:1278,y:561,t:1527030665837};\\\", \\\"{x:1279,y:561,t:1527030665850};\\\", \\\"{x:1280,y:561,t:1527030665949};\\\", \\\"{x:1281,y:561,t:1527030665957};\\\", \\\"{x:1282,y:561,t:1527030665968};\\\", \\\"{x:1283,y:561,t:1527030665984};\\\", \\\"{x:1286,y:561,t:1527030666000};\\\", \\\"{x:1287,y:561,t:1527030666021};\\\", \\\"{x:1288,y:562,t:1527030666262};\\\", \\\"{x:1288,y:563,t:1527030666277};\\\", \\\"{x:1287,y:563,t:1527030666301};\\\", \\\"{x:1286,y:564,t:1527030666357};\\\", \\\"{x:1285,y:564,t:1527030666372};\\\", \\\"{x:1283,y:564,t:1527030666396};\\\", \\\"{x:1283,y:565,t:1527030666404};\\\", \\\"{x:1282,y:565,t:1527030666436};\\\", \\\"{x:1282,y:566,t:1527030666525};\\\", \\\"{x:1281,y:566,t:1527030666541};\\\", \\\"{x:1281,y:567,t:1527030674963};\\\", \\\"{x:1282,y:567,t:1527030674979};\\\", \\\"{x:1283,y:567,t:1527030674988};\\\", \\\"{x:1284,y:567,t:1527030675019};\\\", \\\"{x:1285,y:567,t:1527030675285};\\\", \\\"{x:1288,y:567,t:1527030675293};\\\", \\\"{x:1289,y:567,t:1527030675304};\\\", \\\"{x:1295,y:567,t:1527030675321};\\\", \\\"{x:1301,y:566,t:1527030675338};\\\", \\\"{x:1308,y:565,t:1527030675354};\\\", \\\"{x:1313,y:564,t:1527030675372};\\\", \\\"{x:1314,y:564,t:1527030675404};\\\", \\\"{x:1316,y:564,t:1527030675422};\\\", \\\"{x:1318,y:564,t:1527030675438};\\\", \\\"{x:1319,y:564,t:1527030675455};\\\", \\\"{x:1321,y:564,t:1527030675472};\\\", \\\"{x:1325,y:564,t:1527030675489};\\\", \\\"{x:1327,y:564,t:1527030675505};\\\", \\\"{x:1328,y:564,t:1527030675522};\\\", \\\"{x:1329,y:564,t:1527030675539};\\\", \\\"{x:1332,y:564,t:1527030675555};\\\", \\\"{x:1334,y:564,t:1527030675572};\\\", \\\"{x:1342,y:564,t:1527030675588};\\\", \\\"{x:1347,y:563,t:1527030675606};\\\", \\\"{x:1350,y:562,t:1527030675622};\\\", \\\"{x:1350,y:561,t:1527030675885};\\\", \\\"{x:1347,y:560,t:1527030675893};\\\", \\\"{x:1346,y:560,t:1527030675905};\\\", \\\"{x:1344,y:559,t:1527030675923};\\\", \\\"{x:1343,y:558,t:1527030675939};\\\", \\\"{x:1345,y:559,t:1527030676909};\\\", \\\"{x:1346,y:560,t:1527030676925};\\\", \\\"{x:1347,y:560,t:1527030676940};\\\", \\\"{x:1350,y:561,t:1527030676956};\\\", \\\"{x:1352,y:562,t:1527030676973};\\\", \\\"{x:1353,y:563,t:1527030677004};\\\", \\\"{x:1356,y:564,t:1527030677013};\\\", \\\"{x:1358,y:564,t:1527030677053};\\\", \\\"{x:1358,y:565,t:1527030677062};\\\", \\\"{x:1359,y:566,t:1527030677076};\\\", \\\"{x:1360,y:566,t:1527030677108};\\\", \\\"{x:1361,y:566,t:1527030677123};\\\", \\\"{x:1362,y:566,t:1527030677140};\\\", \\\"{x:1363,y:566,t:1527030677365};\\\", \\\"{x:1363,y:567,t:1527030677372};\\\", \\\"{x:1364,y:567,t:1527030677390};\\\", \\\"{x:1365,y:567,t:1527030677406};\\\", \\\"{x:1366,y:567,t:1527030677429};\\\", \\\"{x:1367,y:567,t:1527030677440};\\\", \\\"{x:1368,y:567,t:1527030677456};\\\", \\\"{x:1369,y:567,t:1527030677473};\\\", \\\"{x:1371,y:567,t:1527030677489};\\\", \\\"{x:1373,y:567,t:1527030677505};\\\", \\\"{x:1375,y:567,t:1527030677522};\\\", \\\"{x:1378,y:567,t:1527030677539};\\\", \\\"{x:1380,y:566,t:1527030677555};\\\", \\\"{x:1381,y:566,t:1527030677573};\\\", \\\"{x:1384,y:565,t:1527030677589};\\\", \\\"{x:1387,y:565,t:1527030677605};\\\", \\\"{x:1388,y:565,t:1527030677623};\\\", \\\"{x:1391,y:564,t:1527030677639};\\\", \\\"{x:1393,y:564,t:1527030677656};\\\", \\\"{x:1394,y:564,t:1527030677673};\\\", \\\"{x:1396,y:564,t:1527030677690};\\\", \\\"{x:1397,y:564,t:1527030677708};\\\", \\\"{x:1399,y:564,t:1527030677724};\\\", \\\"{x:1401,y:562,t:1527030677740};\\\", \\\"{x:1403,y:562,t:1527030677756};\\\", \\\"{x:1405,y:562,t:1527030677772};\\\", \\\"{x:1407,y:562,t:1527030677790};\\\", \\\"{x:1408,y:562,t:1527030677806};\\\", \\\"{x:1409,y:562,t:1527030677823};\\\", \\\"{x:1411,y:562,t:1527030677839};\\\", \\\"{x:1412,y:562,t:1527030677856};\\\", \\\"{x:1413,y:562,t:1527030677873};\\\", \\\"{x:1415,y:562,t:1527030677889};\\\", \\\"{x:1417,y:562,t:1527030677908};\\\", \\\"{x:1418,y:562,t:1527030677932};\\\", \\\"{x:1419,y:562,t:1527030677948};\\\", \\\"{x:1420,y:562,t:1527030677956};\\\", \\\"{x:1421,y:562,t:1527030678270};\\\", \\\"{x:1421,y:561,t:1527030678277};\\\", \\\"{x:1425,y:561,t:1527030679781};\\\", \\\"{x:1428,y:561,t:1527030679791};\\\", \\\"{x:1432,y:561,t:1527030679807};\\\", \\\"{x:1437,y:561,t:1527030679824};\\\", \\\"{x:1441,y:561,t:1527030679841};\\\", \\\"{x:1444,y:561,t:1527030679856};\\\", \\\"{x:1445,y:561,t:1527030679873};\\\", \\\"{x:1446,y:561,t:1527030679891};\\\", \\\"{x:1448,y:561,t:1527030679916};\\\", \\\"{x:1449,y:561,t:1527030679932};\\\", \\\"{x:1450,y:561,t:1527030679997};\\\", \\\"{x:1451,y:561,t:1527030680012};\\\", \\\"{x:1452,y:561,t:1527030680025};\\\", \\\"{x:1452,y:560,t:1527030680052};\\\", \\\"{x:1453,y:560,t:1527030680069};\\\", \\\"{x:1454,y:560,t:1527030680076};\\\", \\\"{x:1455,y:560,t:1527030680109};\\\", \\\"{x:1457,y:560,t:1527030680132};\\\", \\\"{x:1458,y:560,t:1527030680141};\\\", \\\"{x:1461,y:560,t:1527030680158};\\\", \\\"{x:1464,y:560,t:1527030680175};\\\", \\\"{x:1465,y:560,t:1527030680191};\\\", \\\"{x:1466,y:560,t:1527030680207};\\\", \\\"{x:1467,y:560,t:1527030680224};\\\", \\\"{x:1468,y:559,t:1527030680241};\\\", \\\"{x:1470,y:559,t:1527030680257};\\\", \\\"{x:1474,y:559,t:1527030680275};\\\", \\\"{x:1476,y:559,t:1527030680291};\\\", \\\"{x:1477,y:558,t:1527030680308};\\\", \\\"{x:1478,y:558,t:1527030680333};\\\", \\\"{x:1479,y:558,t:1527030680348};\\\", \\\"{x:1480,y:558,t:1527030680359};\\\", \\\"{x:1481,y:558,t:1527030680388};\\\", \\\"{x:1482,y:558,t:1527030680404};\\\", \\\"{x:1483,y:558,t:1527030680421};\\\", \\\"{x:1485,y:558,t:1527030681629};\\\", \\\"{x:1490,y:558,t:1527030681642};\\\", \\\"{x:1503,y:559,t:1527030681658};\\\", \\\"{x:1513,y:561,t:1527030681675};\\\", \\\"{x:1520,y:563,t:1527030681691};\\\", \\\"{x:1525,y:564,t:1527030681707};\\\", \\\"{x:1527,y:564,t:1527030681725};\\\", \\\"{x:1528,y:564,t:1527030681742};\\\", \\\"{x:1530,y:564,t:1527030681757};\\\", \\\"{x:1532,y:564,t:1527030681775};\\\", \\\"{x:1533,y:564,t:1527030681791};\\\", \\\"{x:1536,y:564,t:1527030681808};\\\", \\\"{x:1537,y:564,t:1527030681825};\\\", \\\"{x:1540,y:564,t:1527030681842};\\\", \\\"{x:1541,y:564,t:1527030681858};\\\", \\\"{x:1542,y:564,t:1527030681874};\\\", \\\"{x:1545,y:564,t:1527030681891};\\\", \\\"{x:1547,y:564,t:1527030681908};\\\", \\\"{x:1549,y:564,t:1527030681926};\\\", \\\"{x:1552,y:564,t:1527030681942};\\\", \\\"{x:1553,y:563,t:1527030681959};\\\", \\\"{x:1554,y:563,t:1527030682453};\\\", \\\"{x:1554,y:564,t:1527030682766};\\\", \\\"{x:1553,y:564,t:1527030682781};\\\", \\\"{x:1552,y:564,t:1527030682792};\\\", \\\"{x:1550,y:564,t:1527030682809};\\\", \\\"{x:1547,y:564,t:1527030682825};\\\", \\\"{x:1541,y:564,t:1527030682843};\\\", \\\"{x:1530,y:561,t:1527030682859};\\\", \\\"{x:1517,y:558,t:1527030682875};\\\", \\\"{x:1500,y:557,t:1527030682891};\\\", \\\"{x:1492,y:558,t:1527030682909};\\\", \\\"{x:1473,y:564,t:1527030682924};\\\", \\\"{x:1449,y:571,t:1527030682941};\\\", \\\"{x:1418,y:576,t:1527030682959};\\\", \\\"{x:1382,y:581,t:1527030682975};\\\", \\\"{x:1345,y:583,t:1527030682992};\\\", \\\"{x:1320,y:584,t:1527030683008};\\\", \\\"{x:1304,y:585,t:1527030683024};\\\", \\\"{x:1296,y:585,t:1527030683041};\\\", \\\"{x:1293,y:585,t:1527030683058};\\\", \\\"{x:1292,y:585,t:1527030683237};\\\", \\\"{x:1292,y:584,t:1527030683244};\\\", \\\"{x:1292,y:583,t:1527030683259};\\\", \\\"{x:1289,y:578,t:1527030683275};\\\", \\\"{x:1285,y:574,t:1527030683292};\\\", \\\"{x:1284,y:572,t:1527030683309};\\\", \\\"{x:1283,y:572,t:1527030683326};\\\", \\\"{x:1281,y:572,t:1527030683342};\\\", \\\"{x:1280,y:571,t:1527030683359};\\\", \\\"{x:1277,y:570,t:1527030683376};\\\", \\\"{x:1264,y:569,t:1527030683392};\\\", \\\"{x:1242,y:567,t:1527030683409};\\\", \\\"{x:1193,y:567,t:1527030683426};\\\", \\\"{x:1097,y:557,t:1527030683442};\\\", \\\"{x:965,y:551,t:1527030683460};\\\", \\\"{x:714,y:529,t:1527030683476};\\\", \\\"{x:544,y:518,t:1527030683492};\\\", \\\"{x:400,y:518,t:1527030683508};\\\", \\\"{x:347,y:518,t:1527030683519};\\\", \\\"{x:270,y:518,t:1527030683536};\\\", \\\"{x:241,y:518,t:1527030683552};\\\", \\\"{x:233,y:518,t:1527030683570};\\\", \\\"{x:232,y:518,t:1527030683586};\\\", \\\"{x:236,y:518,t:1527030683660};\\\", \\\"{x:246,y:518,t:1527030683669};\\\", \\\"{x:269,y:518,t:1527030683686};\\\", \\\"{x:308,y:518,t:1527030683703};\\\", \\\"{x:353,y:518,t:1527030683719};\\\", \\\"{x:401,y:518,t:1527030683737};\\\", \\\"{x:448,y:518,t:1527030683753};\\\", \\\"{x:480,y:518,t:1527030683770};\\\", \\\"{x:495,y:518,t:1527030683786};\\\", \\\"{x:499,y:518,t:1527030683804};\\\", \\\"{x:501,y:519,t:1527030683853};\\\", \\\"{x:503,y:519,t:1527030683863};\\\", \\\"{x:505,y:520,t:1527030683871};\\\", \\\"{x:510,y:523,t:1527030683887};\\\", \\\"{x:514,y:523,t:1527030683904};\\\", \\\"{x:519,y:523,t:1527030683921};\\\", \\\"{x:523,y:523,t:1527030683937};\\\", \\\"{x:526,y:523,t:1527030683955};\\\", \\\"{x:532,y:522,t:1527030683971};\\\", \\\"{x:538,y:522,t:1527030683987};\\\", \\\"{x:549,y:517,t:1527030684006};\\\", \\\"{x:555,y:516,t:1527030684020};\\\", \\\"{x:564,y:516,t:1527030684038};\\\", \\\"{x:576,y:514,t:1527030684055};\\\", \\\"{x:591,y:514,t:1527030684070};\\\", \\\"{x:603,y:514,t:1527030684088};\\\", \\\"{x:613,y:513,t:1527030684105};\\\", \\\"{x:618,y:511,t:1527030684122};\\\", \\\"{x:622,y:509,t:1527030684138};\\\", \\\"{x:624,y:508,t:1527030684155};\\\", \\\"{x:623,y:508,t:1527030684763};\\\", \\\"{x:623,y:510,t:1527030684771};\\\", \\\"{x:623,y:521,t:1527030684788};\\\", \\\"{x:622,y:537,t:1527030684805};\\\", \\\"{x:619,y:557,t:1527030684823};\\\", \\\"{x:617,y:580,t:1527030684838};\\\", \\\"{x:612,y:604,t:1527030684855};\\\", \\\"{x:609,y:629,t:1527030684872};\\\", \\\"{x:606,y:651,t:1527030684889};\\\", \\\"{x:604,y:665,t:1527030684905};\\\", \\\"{x:603,y:673,t:1527030684922};\\\", \\\"{x:603,y:680,t:1527030684938};\\\", \\\"{x:603,y:683,t:1527030684955};\\\", \\\"{x:603,y:686,t:1527030684972};\\\", \\\"{x:602,y:687,t:1527030684989};\\\", \\\"{x:600,y:687,t:1527030685108};\\\", \\\"{x:597,y:687,t:1527030685122};\\\", \\\"{x:593,y:687,t:1527030685140};\\\", \\\"{x:588,y:687,t:1527030685155};\\\", \\\"{x:577,y:709,t:1527030685172};\\\", \\\"{x:572,y:722,t:1527030685189};\\\", \\\"{x:564,y:729,t:1527030685205};\\\", \\\"{x:561,y:730,t:1527030685222};\\\", \\\"{x:557,y:730,t:1527030685239};\\\" ] }, { \\\"rt\\\": 23810, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 624959, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:556,y:730,t:1527030687777};\\\", \\\"{x:551,y:728,t:1527030687788};\\\", \\\"{x:534,y:713,t:1527030687806};\\\", \\\"{x:512,y:665,t:1527030687823};\\\", \\\"{x:478,y:590,t:1527030687838};\\\", \\\"{x:428,y:502,t:1527030687855};\\\", \\\"{x:379,y:440,t:1527030687872};\\\", \\\"{x:355,y:409,t:1527030687888};\\\", \\\"{x:351,y:404,t:1527030687904};\\\", \\\"{x:351,y:402,t:1527030687922};\\\", \\\"{x:353,y:401,t:1527030688033};\\\", \\\"{x:356,y:400,t:1527030688040};\\\", \\\"{x:361,y:400,t:1527030688056};\\\", \\\"{x:376,y:400,t:1527030688071};\\\", \\\"{x:392,y:405,t:1527030688088};\\\", \\\"{x:416,y:415,t:1527030688105};\\\", \\\"{x:436,y:424,t:1527030688122};\\\", \\\"{x:454,y:433,t:1527030688138};\\\", \\\"{x:465,y:437,t:1527030688155};\\\", \\\"{x:470,y:438,t:1527030688172};\\\", \\\"{x:474,y:438,t:1527030688189};\\\", \\\"{x:476,y:438,t:1527030688205};\\\", \\\"{x:477,y:438,t:1527030688222};\\\", \\\"{x:477,y:440,t:1527030688377};\\\", \\\"{x:477,y:445,t:1527030688388};\\\", \\\"{x:477,y:460,t:1527030688406};\\\", \\\"{x:477,y:479,t:1527030688421};\\\", \\\"{x:480,y:495,t:1527030688438};\\\", \\\"{x:490,y:508,t:1527030688455};\\\", \\\"{x:497,y:511,t:1527030688471};\\\", \\\"{x:499,y:512,t:1527030688489};\\\", \\\"{x:500,y:512,t:1527030688505};\\\", \\\"{x:502,y:512,t:1527030688529};\\\", \\\"{x:503,y:511,t:1527030688545};\\\", \\\"{x:504,y:509,t:1527030688555};\\\", \\\"{x:506,y:506,t:1527030688572};\\\", \\\"{x:507,y:506,t:1527030688588};\\\", \\\"{x:507,y:505,t:1527030688641};\\\", \\\"{x:506,y:503,t:1527030688655};\\\", \\\"{x:490,y:496,t:1527030688673};\\\", \\\"{x:469,y:487,t:1527030688689};\\\", \\\"{x:441,y:475,t:1527030688706};\\\", \\\"{x:425,y:470,t:1527030688722};\\\", \\\"{x:412,y:470,t:1527030688738};\\\", \\\"{x:399,y:470,t:1527030688755};\\\", \\\"{x:381,y:470,t:1527030688772};\\\", \\\"{x:366,y:470,t:1527030688789};\\\", \\\"{x:352,y:470,t:1527030688805};\\\", \\\"{x:347,y:470,t:1527030688822};\\\", \\\"{x:344,y:470,t:1527030688839};\\\", \\\"{x:345,y:470,t:1527030689042};\\\", \\\"{x:352,y:470,t:1527030689056};\\\", \\\"{x:370,y:470,t:1527030689072};\\\", \\\"{x:407,y:470,t:1527030689090};\\\", \\\"{x:423,y:470,t:1527030689106};\\\", \\\"{x:433,y:469,t:1527030689123};\\\", \\\"{x:437,y:467,t:1527030689139};\\\", \\\"{x:441,y:466,t:1527030689155};\\\", \\\"{x:442,y:466,t:1527030689173};\\\", \\\"{x:443,y:466,t:1527030689189};\\\", \\\"{x:444,y:466,t:1527030689210};\\\", \\\"{x:445,y:466,t:1527030689225};\\\", \\\"{x:447,y:466,t:1527030689241};\\\", \\\"{x:448,y:466,t:1527030689256};\\\", \\\"{x:449,y:466,t:1527030689273};\\\", \\\"{x:452,y:467,t:1527030689289};\\\", \\\"{x:454,y:468,t:1527030689306};\\\", \\\"{x:456,y:469,t:1527030689322};\\\", \\\"{x:460,y:471,t:1527030689340};\\\", \\\"{x:462,y:472,t:1527030689357};\\\", \\\"{x:467,y:474,t:1527030689373};\\\", \\\"{x:471,y:476,t:1527030689389};\\\", \\\"{x:475,y:478,t:1527030689407};\\\", \\\"{x:477,y:478,t:1527030689423};\\\", \\\"{x:477,y:479,t:1527030689439};\\\", \\\"{x:480,y:479,t:1527030690658};\\\", \\\"{x:492,y:474,t:1527030690674};\\\", \\\"{x:507,y:471,t:1527030690691};\\\", \\\"{x:530,y:467,t:1527030690708};\\\", \\\"{x:557,y:467,t:1527030690724};\\\", \\\"{x:584,y:467,t:1527030690741};\\\", \\\"{x:606,y:467,t:1527030690758};\\\", \\\"{x:623,y:467,t:1527030690774};\\\", \\\"{x:644,y:467,t:1527030690791};\\\", \\\"{x:653,y:467,t:1527030690808};\\\", \\\"{x:656,y:467,t:1527030690825};\\\", \\\"{x:659,y:467,t:1527030691498};\\\", \\\"{x:665,y:467,t:1527030691508};\\\", \\\"{x:680,y:467,t:1527030691525};\\\", \\\"{x:702,y:467,t:1527030691542};\\\", \\\"{x:731,y:469,t:1527030691558};\\\", \\\"{x:762,y:474,t:1527030691575};\\\", \\\"{x:801,y:478,t:1527030691592};\\\", \\\"{x:848,y:482,t:1527030691609};\\\", \\\"{x:903,y:482,t:1527030691625};\\\", \\\"{x:988,y:484,t:1527030691642};\\\", \\\"{x:1038,y:484,t:1527030691658};\\\", \\\"{x:1077,y:484,t:1527030691675};\\\", \\\"{x:1104,y:484,t:1527030691692};\\\", \\\"{x:1120,y:484,t:1527030691709};\\\", \\\"{x:1129,y:484,t:1527030691724};\\\", \\\"{x:1136,y:485,t:1527030691742};\\\", \\\"{x:1140,y:486,t:1527030691759};\\\", \\\"{x:1148,y:488,t:1527030691775};\\\", \\\"{x:1166,y:494,t:1527030691792};\\\", \\\"{x:1204,y:501,t:1527030691808};\\\", \\\"{x:1262,y:518,t:1527030691825};\\\", \\\"{x:1387,y:554,t:1527030691841};\\\", \\\"{x:1480,y:575,t:1527030691859};\\\", \\\"{x:1573,y:594,t:1527030691875};\\\", \\\"{x:1657,y:607,t:1527030691892};\\\", \\\"{x:1725,y:621,t:1527030691909};\\\", \\\"{x:1775,y:629,t:1527030691925};\\\", \\\"{x:1806,y:634,t:1527030691942};\\\", \\\"{x:1833,y:639,t:1527030691959};\\\", \\\"{x:1853,y:644,t:1527030691976};\\\", \\\"{x:1858,y:648,t:1527030691992};\\\", \\\"{x:1859,y:648,t:1527030692009};\\\", \\\"{x:1858,y:648,t:1527030692513};\\\", \\\"{x:1857,y:648,t:1527030692529};\\\", \\\"{x:1856,y:648,t:1527030692640};\\\", \\\"{x:1854,y:649,t:1527030692689};\\\", \\\"{x:1853,y:650,t:1527030692697};\\\", \\\"{x:1853,y:653,t:1527030692709};\\\", \\\"{x:1853,y:657,t:1527030692725};\\\", \\\"{x:1850,y:664,t:1527030692743};\\\", \\\"{x:1848,y:674,t:1527030692759};\\\", \\\"{x:1845,y:683,t:1527030692775};\\\", \\\"{x:1839,y:694,t:1527030692792};\\\", \\\"{x:1829,y:707,t:1527030692809};\\\", \\\"{x:1820,y:718,t:1527030692826};\\\", \\\"{x:1809,y:725,t:1527030692843};\\\", \\\"{x:1801,y:730,t:1527030692859};\\\", \\\"{x:1794,y:732,t:1527030692876};\\\", \\\"{x:1789,y:734,t:1527030692893};\\\", \\\"{x:1786,y:735,t:1527030692910};\\\", \\\"{x:1782,y:735,t:1527030692926};\\\", \\\"{x:1769,y:734,t:1527030692943};\\\", \\\"{x:1753,y:732,t:1527030692960};\\\", \\\"{x:1731,y:732,t:1527030692976};\\\", \\\"{x:1702,y:732,t:1527030692992};\\\", \\\"{x:1648,y:732,t:1527030693009};\\\", \\\"{x:1586,y:728,t:1527030693026};\\\", \\\"{x:1505,y:717,t:1527030693042};\\\", \\\"{x:1445,y:714,t:1527030693059};\\\", \\\"{x:1395,y:714,t:1527030693076};\\\", \\\"{x:1363,y:714,t:1527030693093};\\\", \\\"{x:1343,y:714,t:1527030693110};\\\", \\\"{x:1333,y:714,t:1527030693126};\\\", \\\"{x:1328,y:714,t:1527030693143};\\\", \\\"{x:1327,y:714,t:1527030693160};\\\", \\\"{x:1326,y:715,t:1527030693234};\\\", \\\"{x:1324,y:717,t:1527030693243};\\\", \\\"{x:1322,y:720,t:1527030693260};\\\", \\\"{x:1319,y:723,t:1527030693277};\\\", \\\"{x:1316,y:727,t:1527030693293};\\\", \\\"{x:1313,y:730,t:1527030693310};\\\", \\\"{x:1312,y:732,t:1527030693329};\\\", \\\"{x:1311,y:732,t:1527030693345};\\\", \\\"{x:1311,y:733,t:1527030693360};\\\", \\\"{x:1311,y:734,t:1527030693377};\\\", \\\"{x:1309,y:737,t:1527030693393};\\\", \\\"{x:1307,y:739,t:1527030693410};\\\", \\\"{x:1305,y:742,t:1527030693427};\\\", \\\"{x:1302,y:744,t:1527030693443};\\\", \\\"{x:1299,y:748,t:1527030693460};\\\", \\\"{x:1295,y:753,t:1527030693477};\\\", \\\"{x:1290,y:758,t:1527030693494};\\\", \\\"{x:1283,y:763,t:1527030693510};\\\", \\\"{x:1271,y:768,t:1527030693527};\\\", \\\"{x:1262,y:770,t:1527030693544};\\\", \\\"{x:1257,y:771,t:1527030693560};\\\", \\\"{x:1252,y:772,t:1527030693577};\\\", \\\"{x:1250,y:773,t:1527030693594};\\\", \\\"{x:1249,y:773,t:1527030693625};\\\", \\\"{x:1250,y:773,t:1527030697273};\\\", \\\"{x:1266,y:780,t:1527030697281};\\\", \\\"{x:1307,y:797,t:1527030697297};\\\", \\\"{x:1334,y:809,t:1527030697313};\\\", \\\"{x:1351,y:815,t:1527030697330};\\\", \\\"{x:1363,y:817,t:1527030697347};\\\", \\\"{x:1369,y:817,t:1527030697364};\\\", \\\"{x:1374,y:817,t:1527030697380};\\\", \\\"{x:1375,y:817,t:1527030697397};\\\", \\\"{x:1376,y:821,t:1527030697474};\\\", \\\"{x:1376,y:823,t:1527030697481};\\\", \\\"{x:1377,y:828,t:1527030697497};\\\", \\\"{x:1377,y:830,t:1527030697513};\\\", \\\"{x:1377,y:831,t:1527030697538};\\\", \\\"{x:1377,y:832,t:1527030697547};\\\", \\\"{x:1377,y:834,t:1527030697564};\\\", \\\"{x:1377,y:837,t:1527030697580};\\\", \\\"{x:1377,y:841,t:1527030697596};\\\", \\\"{x:1377,y:844,t:1527030697614};\\\", \\\"{x:1377,y:848,t:1527030697629};\\\", \\\"{x:1377,y:850,t:1527030697646};\\\", \\\"{x:1375,y:850,t:1527030698033};\\\", \\\"{x:1371,y:848,t:1527030698047};\\\", \\\"{x:1368,y:848,t:1527030698063};\\\", \\\"{x:1347,y:848,t:1527030698081};\\\", \\\"{x:1326,y:854,t:1527030698097};\\\", \\\"{x:1305,y:859,t:1527030698114};\\\", \\\"{x:1289,y:863,t:1527030698131};\\\", \\\"{x:1275,y:864,t:1527030698148};\\\", \\\"{x:1267,y:864,t:1527030698164};\\\", \\\"{x:1261,y:864,t:1527030698180};\\\", \\\"{x:1255,y:864,t:1527030698198};\\\", \\\"{x:1251,y:864,t:1527030698214};\\\", \\\"{x:1247,y:864,t:1527030698231};\\\", \\\"{x:1244,y:864,t:1527030698247};\\\", \\\"{x:1243,y:864,t:1527030698322};\\\", \\\"{x:1242,y:863,t:1527030698331};\\\", \\\"{x:1240,y:860,t:1527030698348};\\\", \\\"{x:1237,y:857,t:1527030698365};\\\", \\\"{x:1236,y:855,t:1527030698381};\\\", \\\"{x:1234,y:855,t:1527030698458};\\\", \\\"{x:1232,y:850,t:1527030698465};\\\", \\\"{x:1225,y:841,t:1527030698481};\\\", \\\"{x:1221,y:836,t:1527030698498};\\\", \\\"{x:1220,y:836,t:1527030698515};\\\", \\\"{x:1220,y:835,t:1527030698618};\\\", \\\"{x:1218,y:835,t:1527030698666};\\\", \\\"{x:1218,y:834,t:1527030698925};\\\", \\\"{x:1218,y:832,t:1527030698948};\\\", \\\"{x:1217,y:830,t:1527030698964};\\\", \\\"{x:1216,y:830,t:1527030698982};\\\", \\\"{x:1215,y:830,t:1527030699000};\\\", \\\"{x:1214,y:829,t:1527030699032};\\\", \\\"{x:1213,y:828,t:1527030699081};\\\", \\\"{x:1212,y:827,t:1527030699098};\\\", \\\"{x:1212,y:824,t:1527030699891};\\\", \\\"{x:1211,y:818,t:1527030699899};\\\", \\\"{x:1211,y:810,t:1527030699917};\\\", \\\"{x:1209,y:797,t:1527030699932};\\\", \\\"{x:1206,y:784,t:1527030699950};\\\", \\\"{x:1200,y:772,t:1527030699967};\\\", \\\"{x:1193,y:763,t:1527030699984};\\\", \\\"{x:1190,y:762,t:1527030700000};\\\", \\\"{x:1189,y:761,t:1527030700017};\\\", \\\"{x:1188,y:761,t:1527030700090};\\\", \\\"{x:1187,y:761,t:1527030704938};\\\", \\\"{x:1185,y:760,t:1527030704954};\\\", \\\"{x:1183,y:760,t:1527030705057};\\\", \\\"{x:1181,y:760,t:1527030705097};\\\", \\\"{x:1177,y:760,t:1527030708010};\\\", \\\"{x:1169,y:760,t:1527030708024};\\\", \\\"{x:1150,y:755,t:1527030708040};\\\", \\\"{x:1116,y:743,t:1527030708056};\\\", \\\"{x:1037,y:719,t:1527030708073};\\\", \\\"{x:969,y:696,t:1527030708090};\\\", \\\"{x:897,y:676,t:1527030708106};\\\", \\\"{x:811,y:649,t:1527030708123};\\\", \\\"{x:723,y:626,t:1527030708141};\\\", \\\"{x:631,y:599,t:1527030708156};\\\", \\\"{x:546,y:578,t:1527030708173};\\\", \\\"{x:449,y:562,t:1527030708197};\\\", \\\"{x:410,y:557,t:1527030708214};\\\", \\\"{x:376,y:556,t:1527030708238};\\\", \\\"{x:362,y:554,t:1527030708254};\\\", \\\"{x:357,y:552,t:1527030708271};\\\", \\\"{x:359,y:551,t:1527030708433};\\\", \\\"{x:360,y:550,t:1527030708441};\\\", \\\"{x:361,y:550,t:1527030708457};\\\", \\\"{x:362,y:549,t:1527030708471};\\\", \\\"{x:364,y:548,t:1527030708489};\\\", \\\"{x:364,y:547,t:1527030708810};\\\", \\\"{x:364,y:546,t:1527030708823};\\\", \\\"{x:362,y:545,t:1527030708839};\\\", \\\"{x:360,y:545,t:1527030708855};\\\", \\\"{x:358,y:544,t:1527030708872};\\\", \\\"{x:357,y:544,t:1527030708890};\\\", \\\"{x:357,y:543,t:1527030708985};\\\", \\\"{x:360,y:541,t:1527030708993};\\\", \\\"{x:371,y:537,t:1527030709006};\\\", \\\"{x:399,y:530,t:1527030709024};\\\", \\\"{x:428,y:521,t:1527030709040};\\\", \\\"{x:446,y:515,t:1527030709055};\\\", \\\"{x:457,y:512,t:1527030709072};\\\", \\\"{x:462,y:510,t:1527030709088};\\\", \\\"{x:463,y:509,t:1527030709105};\\\", \\\"{x:462,y:509,t:1527030709201};\\\", \\\"{x:460,y:509,t:1527030709216};\\\", \\\"{x:457,y:510,t:1527030709224};\\\", \\\"{x:455,y:511,t:1527030709240};\\\", \\\"{x:453,y:513,t:1527030709255};\\\", \\\"{x:445,y:519,t:1527030709273};\\\", \\\"{x:433,y:528,t:1527030709289};\\\", \\\"{x:408,y:542,t:1527030709306};\\\", \\\"{x:385,y:552,t:1527030709322};\\\", \\\"{x:366,y:558,t:1527030709340};\\\", \\\"{x:352,y:563,t:1527030709356};\\\", \\\"{x:347,y:563,t:1527030709372};\\\", \\\"{x:346,y:563,t:1527030709425};\\\", \\\"{x:346,y:561,t:1527030709441};\\\", \\\"{x:347,y:559,t:1527030709455};\\\", \\\"{x:351,y:558,t:1527030709472};\\\", \\\"{x:354,y:556,t:1527030709488};\\\", \\\"{x:353,y:556,t:1527030709553};\\\", \\\"{x:348,y:559,t:1527030709560};\\\", \\\"{x:342,y:562,t:1527030709572};\\\", \\\"{x:322,y:571,t:1527030709589};\\\", \\\"{x:294,y:582,t:1527030709605};\\\", \\\"{x:270,y:587,t:1527030709623};\\\", \\\"{x:253,y:587,t:1527030709639};\\\", \\\"{x:247,y:586,t:1527030709655};\\\", \\\"{x:243,y:583,t:1527030709672};\\\", \\\"{x:240,y:577,t:1527030709689};\\\", \\\"{x:239,y:571,t:1527030709705};\\\", \\\"{x:239,y:564,t:1527030709722};\\\", \\\"{x:239,y:556,t:1527030709740};\\\", \\\"{x:236,y:545,t:1527030709756};\\\", \\\"{x:233,y:530,t:1527030709772};\\\", \\\"{x:225,y:512,t:1527030709790};\\\", \\\"{x:215,y:495,t:1527030709805};\\\", \\\"{x:209,y:485,t:1527030709822};\\\", \\\"{x:208,y:483,t:1527030709839};\\\", \\\"{x:206,y:481,t:1527030709856};\\\", \\\"{x:203,y:481,t:1527030709872};\\\", \\\"{x:201,y:481,t:1527030709889};\\\", \\\"{x:199,y:480,t:1527030709906};\\\", \\\"{x:197,y:479,t:1527030709922};\\\", \\\"{x:196,y:479,t:1527030709939};\\\", \\\"{x:195,y:479,t:1527030709968};\\\", \\\"{x:194,y:479,t:1527030709976};\\\", \\\"{x:191,y:479,t:1527030709989};\\\", \\\"{x:190,y:479,t:1527030710006};\\\", \\\"{x:185,y:482,t:1527030710023};\\\", \\\"{x:179,y:486,t:1527030710040};\\\", \\\"{x:173,y:491,t:1527030710057};\\\", \\\"{x:167,y:495,t:1527030710073};\\\", \\\"{x:162,y:499,t:1527030710089};\\\", \\\"{x:160,y:499,t:1527030710106};\\\", \\\"{x:159,y:501,t:1527030710440};\\\", \\\"{x:171,y:512,t:1527030710456};\\\", \\\"{x:197,y:532,t:1527030710473};\\\", \\\"{x:247,y:577,t:1527030710490};\\\", \\\"{x:337,y:648,t:1527030710507};\\\", \\\"{x:435,y:721,t:1527030710523};\\\", \\\"{x:506,y:777,t:1527030710539};\\\", \\\"{x:539,y:798,t:1527030710556};\\\", \\\"{x:557,y:808,t:1527030710573};\\\", \\\"{x:569,y:815,t:1527030710589};\\\", \\\"{x:580,y:822,t:1527030710606};\\\", \\\"{x:581,y:822,t:1527030710623};\\\", \\\"{x:582,y:822,t:1527030710640};\\\", \\\"{x:581,y:819,t:1527030710746};\\\", \\\"{x:580,y:818,t:1527030710756};\\\", \\\"{x:576,y:811,t:1527030710773};\\\", \\\"{x:568,y:803,t:1527030710791};\\\", \\\"{x:556,y:790,t:1527030710807};\\\", \\\"{x:540,y:773,t:1527030710824};\\\", \\\"{x:526,y:760,t:1527030710840};\\\", \\\"{x:516,y:752,t:1527030710858};\\\", \\\"{x:510,y:748,t:1527030710873};\\\", \\\"{x:508,y:744,t:1527030710890};\\\", \\\"{x:507,y:744,t:1527030710906};\\\", \\\"{x:506,y:743,t:1527030710961};\\\" ] }, { \\\"rt\\\": 60980, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 687138, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H -F -F -F -Z -Z -B -M -X -04 PM-F -F -F -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:742,t:1527030715529};\\\", \\\"{x:523,y:736,t:1527030715541};\\\", \\\"{x:624,y:717,t:1527030715563};\\\", \\\"{x:675,y:711,t:1527030715575};\\\", \\\"{x:818,y:699,t:1527030715590};\\\", \\\"{x:1048,y:673,t:1527030715611};\\\", \\\"{x:1190,y:651,t:1527030715626};\\\", \\\"{x:1323,y:630,t:1527030715644};\\\", \\\"{x:1426,y:612,t:1527030715660};\\\", \\\"{x:1509,y:601,t:1527030715676};\\\", \\\"{x:1545,y:597,t:1527030715693};\\\", \\\"{x:1562,y:596,t:1527030715710};\\\", \\\"{x:1564,y:596,t:1527030715727};\\\", \\\"{x:1566,y:597,t:1527030715833};\\\", \\\"{x:1572,y:602,t:1527030715843};\\\", \\\"{x:1577,y:607,t:1527030715860};\\\", \\\"{x:1580,y:613,t:1527030715877};\\\", \\\"{x:1584,y:618,t:1527030715893};\\\", \\\"{x:1584,y:622,t:1527030715911};\\\", \\\"{x:1586,y:624,t:1527030715928};\\\", \\\"{x:1586,y:625,t:1527030715943};\\\", \\\"{x:1586,y:628,t:1527030715962};\\\", \\\"{x:1586,y:630,t:1527030715977};\\\", \\\"{x:1586,y:632,t:1527030715993};\\\", \\\"{x:1583,y:636,t:1527030716011};\\\", \\\"{x:1576,y:644,t:1527030716028};\\\", \\\"{x:1567,y:655,t:1527030716043};\\\", \\\"{x:1559,y:665,t:1527030716061};\\\", \\\"{x:1551,y:675,t:1527030716077};\\\", \\\"{x:1542,y:684,t:1527030716094};\\\", \\\"{x:1539,y:687,t:1527030716111};\\\", \\\"{x:1539,y:688,t:1527030716128};\\\", \\\"{x:1539,y:689,t:1527030716145};\\\", \\\"{x:1539,y:690,t:1527030716161};\\\", \\\"{x:1536,y:694,t:1527030716177};\\\", \\\"{x:1536,y:697,t:1527030716194};\\\", \\\"{x:1535,y:701,t:1527030716210};\\\", \\\"{x:1535,y:706,t:1527030716228};\\\", \\\"{x:1534,y:710,t:1527030716244};\\\", \\\"{x:1534,y:711,t:1527030716260};\\\", \\\"{x:1534,y:713,t:1527030716278};\\\", \\\"{x:1532,y:716,t:1527030716294};\\\", \\\"{x:1530,y:719,t:1527030716310};\\\", \\\"{x:1522,y:723,t:1527030716328};\\\", \\\"{x:1506,y:727,t:1527030716344};\\\", \\\"{x:1466,y:731,t:1527030716361};\\\", \\\"{x:1439,y:731,t:1527030716377};\\\", \\\"{x:1421,y:731,t:1527030716394};\\\", \\\"{x:1418,y:731,t:1527030716411};\\\", \\\"{x:1417,y:731,t:1527030716428};\\\", \\\"{x:1416,y:731,t:1527030716554};\\\", \\\"{x:1413,y:729,t:1527030716561};\\\", \\\"{x:1403,y:716,t:1527030716578};\\\", \\\"{x:1392,y:704,t:1527030716595};\\\", \\\"{x:1387,y:699,t:1527030716610};\\\", \\\"{x:1386,y:699,t:1527030716689};\\\", \\\"{x:1385,y:699,t:1527030716720};\\\", \\\"{x:1384,y:698,t:1527030716728};\\\", \\\"{x:1383,y:697,t:1527030716752};\\\", \\\"{x:1382,y:697,t:1527030716825};\\\", \\\"{x:1381,y:697,t:1527030716857};\\\", \\\"{x:1380,y:697,t:1527030716865};\\\", \\\"{x:1378,y:697,t:1527030716878};\\\", \\\"{x:1376,y:698,t:1527030716895};\\\", \\\"{x:1375,y:699,t:1527030716911};\\\", \\\"{x:1373,y:699,t:1527030717160};\\\", \\\"{x:1372,y:699,t:1527030717169};\\\", \\\"{x:1371,y:699,t:1527030717177};\\\", \\\"{x:1369,y:699,t:1527030717194};\\\", \\\"{x:1368,y:699,t:1527030717212};\\\", \\\"{x:1367,y:698,t:1527030717228};\\\", \\\"{x:1366,y:698,t:1527030717256};\\\", \\\"{x:1365,y:698,t:1527030717425};\\\", \\\"{x:1363,y:698,t:1527030717433};\\\", \\\"{x:1362,y:698,t:1527030717444};\\\", \\\"{x:1361,y:698,t:1527030717464};\\\", \\\"{x:1359,y:697,t:1527030717633};\\\", \\\"{x:1357,y:697,t:1527030717645};\\\", \\\"{x:1353,y:697,t:1527030717663};\\\", \\\"{x:1348,y:697,t:1527030717679};\\\", \\\"{x:1343,y:697,t:1527030717694};\\\", \\\"{x:1340,y:698,t:1527030717712};\\\", \\\"{x:1338,y:699,t:1527030717729};\\\", \\\"{x:1340,y:700,t:1527030717978};\\\", \\\"{x:1342,y:701,t:1527030717985};\\\", \\\"{x:1344,y:702,t:1527030717995};\\\", \\\"{x:1348,y:703,t:1527030718012};\\\", \\\"{x:1350,y:703,t:1527030718028};\\\", \\\"{x:1350,y:704,t:1527030718045};\\\", \\\"{x:1351,y:704,t:1527030718062};\\\", \\\"{x:1350,y:704,t:1527030718497};\\\", \\\"{x:1349,y:704,t:1527030718521};\\\", \\\"{x:1348,y:704,t:1527030718529};\\\", \\\"{x:1349,y:702,t:1527030719042};\\\", \\\"{x:1350,y:702,t:1527030719065};\\\", \\\"{x:1351,y:701,t:1527030719080};\\\", \\\"{x:1352,y:701,t:1527030719307};\\\", \\\"{x:1353,y:701,t:1527030719313};\\\", \\\"{x:1354,y:701,t:1527030719329};\\\", \\\"{x:1355,y:701,t:1527030724578};\\\", \\\"{x:1359,y:701,t:1527030724585};\\\", \\\"{x:1364,y:699,t:1527030724601};\\\", \\\"{x:1373,y:697,t:1527030724617};\\\", \\\"{x:1388,y:697,t:1527030724633};\\\", \\\"{x:1399,y:697,t:1527030724651};\\\", \\\"{x:1407,y:699,t:1527030724666};\\\", \\\"{x:1416,y:702,t:1527030724684};\\\", \\\"{x:1420,y:702,t:1527030724700};\\\", \\\"{x:1422,y:702,t:1527030724716};\\\", \\\"{x:1423,y:702,t:1527030724984};\\\", \\\"{x:1422,y:701,t:1527030725000};\\\", \\\"{x:1421,y:701,t:1527030725017};\\\", \\\"{x:1419,y:700,t:1527030725033};\\\", \\\"{x:1418,y:700,t:1527030725050};\\\", \\\"{x:1417,y:700,t:1527030725121};\\\", \\\"{x:1416,y:700,t:1527030725133};\\\", \\\"{x:1415,y:699,t:1527030725151};\\\", \\\"{x:1414,y:699,t:1527030725513};\\\", \\\"{x:1413,y:698,t:1527030725554};\\\", \\\"{x:1412,y:698,t:1527030725625};\\\", \\\"{x:1412,y:711,t:1527030726586};\\\", \\\"{x:1412,y:741,t:1527030726601};\\\", \\\"{x:1414,y:773,t:1527030726618};\\\", \\\"{x:1414,y:805,t:1527030726635};\\\", \\\"{x:1414,y:832,t:1527030726651};\\\", \\\"{x:1414,y:858,t:1527030726668};\\\", \\\"{x:1417,y:874,t:1527030726684};\\\", \\\"{x:1419,y:890,t:1527030726702};\\\", \\\"{x:1422,y:907,t:1527030726718};\\\", \\\"{x:1426,y:922,t:1527030726735};\\\", \\\"{x:1427,y:938,t:1527030726751};\\\", \\\"{x:1431,y:949,t:1527030726768};\\\", \\\"{x:1433,y:954,t:1527030726784};\\\", \\\"{x:1431,y:950,t:1527030727209};\\\", \\\"{x:1429,y:945,t:1527030727218};\\\", \\\"{x:1425,y:936,t:1527030727235};\\\", \\\"{x:1421,y:924,t:1527030727251};\\\", \\\"{x:1417,y:914,t:1527030727269};\\\", \\\"{x:1413,y:906,t:1527030727286};\\\", \\\"{x:1413,y:900,t:1527030727302};\\\", \\\"{x:1412,y:893,t:1527030727318};\\\", \\\"{x:1412,y:879,t:1527030727335};\\\", \\\"{x:1412,y:862,t:1527030727351};\\\", \\\"{x:1408,y:840,t:1527030727369};\\\", \\\"{x:1401,y:800,t:1527030727385};\\\", \\\"{x:1400,y:780,t:1527030727401};\\\", \\\"{x:1400,y:763,t:1527030727419};\\\", \\\"{x:1400,y:748,t:1527030727436};\\\", \\\"{x:1400,y:732,t:1527030727452};\\\", \\\"{x:1400,y:721,t:1527030727468};\\\", \\\"{x:1400,y:713,t:1527030727485};\\\", \\\"{x:1402,y:705,t:1527030727502};\\\", \\\"{x:1403,y:697,t:1527030727519};\\\", \\\"{x:1406,y:693,t:1527030727535};\\\", \\\"{x:1407,y:691,t:1527030727552};\\\", \\\"{x:1407,y:690,t:1527030727568};\\\", \\\"{x:1408,y:690,t:1527030727802};\\\", \\\"{x:1408,y:691,t:1527030727841};\\\", \\\"{x:1408,y:692,t:1527030727984};\\\", \\\"{x:1408,y:694,t:1527030727992};\\\", \\\"{x:1408,y:697,t:1527030728002};\\\", \\\"{x:1407,y:705,t:1527030728019};\\\", \\\"{x:1404,y:716,t:1527030728035};\\\", \\\"{x:1402,y:732,t:1527030728052};\\\", \\\"{x:1398,y:751,t:1527030728069};\\\", \\\"{x:1396,y:773,t:1527030728085};\\\", \\\"{x:1393,y:798,t:1527030728102};\\\", \\\"{x:1393,y:825,t:1527030728119};\\\", \\\"{x:1392,y:846,t:1527030728135};\\\", \\\"{x:1389,y:871,t:1527030728152};\\\", \\\"{x:1389,y:886,t:1527030728168};\\\", \\\"{x:1388,y:901,t:1527030728185};\\\", \\\"{x:1388,y:913,t:1527030728203};\\\", \\\"{x:1388,y:927,t:1527030728219};\\\", \\\"{x:1388,y:940,t:1527030728235};\\\", \\\"{x:1388,y:945,t:1527030728252};\\\", \\\"{x:1387,y:948,t:1527030728269};\\\", \\\"{x:1387,y:946,t:1527030728489};\\\", \\\"{x:1389,y:939,t:1527030728502};\\\", \\\"{x:1390,y:924,t:1527030728520};\\\", \\\"{x:1394,y:903,t:1527030728536};\\\", \\\"{x:1399,y:877,t:1527030728553};\\\", \\\"{x:1405,y:845,t:1527030728569};\\\", \\\"{x:1411,y:825,t:1527030728586};\\\", \\\"{x:1415,y:814,t:1527030728602};\\\", \\\"{x:1418,y:799,t:1527030728620};\\\", \\\"{x:1420,y:787,t:1527030728636};\\\", \\\"{x:1422,y:767,t:1527030728652};\\\", \\\"{x:1425,y:749,t:1527030728670};\\\", \\\"{x:1428,y:738,t:1527030728686};\\\", \\\"{x:1433,y:729,t:1527030728702};\\\", \\\"{x:1437,y:724,t:1527030728719};\\\", \\\"{x:1439,y:721,t:1527030728737};\\\", \\\"{x:1440,y:720,t:1527030728753};\\\", \\\"{x:1443,y:716,t:1527030728769};\\\", \\\"{x:1444,y:714,t:1527030728786};\\\", \\\"{x:1447,y:712,t:1527030728802};\\\", \\\"{x:1450,y:709,t:1527030728819};\\\", \\\"{x:1454,y:705,t:1527030728836};\\\", \\\"{x:1461,y:702,t:1527030728852};\\\", \\\"{x:1463,y:700,t:1527030728869};\\\", \\\"{x:1465,y:699,t:1527030728886};\\\", \\\"{x:1467,y:698,t:1527030728902};\\\", \\\"{x:1468,y:698,t:1527030728919};\\\", \\\"{x:1471,y:696,t:1527030728936};\\\", \\\"{x:1472,y:695,t:1527030728952};\\\", \\\"{x:1473,y:695,t:1527030728976};\\\", \\\"{x:1474,y:695,t:1527030729488};\\\", \\\"{x:1475,y:695,t:1527030729503};\\\", \\\"{x:1476,y:695,t:1527030729519};\\\", \\\"{x:1478,y:695,t:1527030729536};\\\", \\\"{x:1479,y:695,t:1527030729553};\\\", \\\"{x:1480,y:695,t:1527030729592};\\\", \\\"{x:1480,y:696,t:1527030729648};\\\", \\\"{x:1482,y:696,t:1527030729689};\\\", \\\"{x:1483,y:697,t:1527030729704};\\\", \\\"{x:1484,y:697,t:1527030729769};\\\", \\\"{x:1486,y:698,t:1527030729800};\\\", \\\"{x:1487,y:699,t:1527030729841};\\\", \\\"{x:1489,y:699,t:1527030730041};\\\", \\\"{x:1490,y:699,t:1527030730081};\\\", \\\"{x:1491,y:700,t:1527030730088};\\\", \\\"{x:1488,y:698,t:1527030730385};\\\", \\\"{x:1483,y:694,t:1527030730393};\\\", \\\"{x:1479,y:693,t:1527030730404};\\\", \\\"{x:1472,y:686,t:1527030730421};\\\", \\\"{x:1471,y:686,t:1527030730438};\\\", \\\"{x:1470,y:686,t:1527030730454};\\\", \\\"{x:1469,y:685,t:1527030730470};\\\", \\\"{x:1468,y:685,t:1527030730545};\\\", \\\"{x:1467,y:685,t:1527030730585};\\\", \\\"{x:1463,y:687,t:1527030730721};\\\", \\\"{x:1451,y:692,t:1527030730737};\\\", \\\"{x:1439,y:698,t:1527030730755};\\\", \\\"{x:1424,y:705,t:1527030730770};\\\", \\\"{x:1411,y:711,t:1527030730787};\\\", \\\"{x:1401,y:713,t:1527030730805};\\\", \\\"{x:1399,y:715,t:1527030730821};\\\", \\\"{x:1400,y:715,t:1527030730993};\\\", \\\"{x:1402,y:714,t:1527030731005};\\\", \\\"{x:1407,y:710,t:1527030731021};\\\", \\\"{x:1411,y:707,t:1527030731038};\\\", \\\"{x:1412,y:706,t:1527030731055};\\\", \\\"{x:1412,y:705,t:1527030731070};\\\", \\\"{x:1412,y:704,t:1527030731178};\\\", \\\"{x:1412,y:702,t:1527030731188};\\\", \\\"{x:1412,y:698,t:1527030731204};\\\", \\\"{x:1412,y:695,t:1527030731221};\\\", \\\"{x:1415,y:694,t:1527030733114};\\\", \\\"{x:1419,y:694,t:1527030733123};\\\", \\\"{x:1431,y:694,t:1527030733139};\\\", \\\"{x:1452,y:695,t:1527030733156};\\\", \\\"{x:1472,y:696,t:1527030733173};\\\", \\\"{x:1494,y:699,t:1527030733190};\\\", \\\"{x:1516,y:700,t:1527030733206};\\\", \\\"{x:1530,y:701,t:1527030733223};\\\", \\\"{x:1535,y:701,t:1527030733239};\\\", \\\"{x:1531,y:701,t:1527030733425};\\\", \\\"{x:1527,y:701,t:1527030733440};\\\", \\\"{x:1521,y:701,t:1527030733456};\\\", \\\"{x:1515,y:702,t:1527030733473};\\\", \\\"{x:1515,y:703,t:1527030733489};\\\", \\\"{x:1514,y:703,t:1527030733633};\\\", \\\"{x:1513,y:703,t:1527030733641};\\\", \\\"{x:1511,y:702,t:1527030733655};\\\", \\\"{x:1503,y:698,t:1527030733673};\\\", \\\"{x:1500,y:696,t:1527030733689};\\\", \\\"{x:1498,y:696,t:1527030733706};\\\", \\\"{x:1497,y:695,t:1527030733723};\\\", \\\"{x:1496,y:695,t:1527030733739};\\\", \\\"{x:1495,y:695,t:1527030733921};\\\", \\\"{x:1491,y:695,t:1527030733940};\\\", \\\"{x:1490,y:695,t:1527030733957};\\\", \\\"{x:1489,y:695,t:1527030733973};\\\", \\\"{x:1488,y:695,t:1527030734001};\\\", \\\"{x:1487,y:695,t:1527030734097};\\\", \\\"{x:1486,y:695,t:1527030734121};\\\", \\\"{x:1485,y:695,t:1527030734386};\\\", \\\"{x:1484,y:695,t:1527030734393};\\\", \\\"{x:1483,y:696,t:1527030734425};\\\", \\\"{x:1482,y:697,t:1527030734465};\\\", \\\"{x:1484,y:697,t:1527030735898};\\\", \\\"{x:1485,y:699,t:1527030735921};\\\", \\\"{x:1487,y:699,t:1527030735929};\\\", \\\"{x:1488,y:699,t:1527030735944};\\\", \\\"{x:1489,y:699,t:1527030735957};\\\", \\\"{x:1491,y:699,t:1527030735974};\\\", \\\"{x:1494,y:699,t:1527030735990};\\\", \\\"{x:1496,y:699,t:1527030736007};\\\", \\\"{x:1500,y:699,t:1527030736024};\\\", \\\"{x:1505,y:699,t:1527030736040};\\\", \\\"{x:1511,y:699,t:1527030736057};\\\", \\\"{x:1516,y:699,t:1527030736074};\\\", \\\"{x:1521,y:697,t:1527030736090};\\\", \\\"{x:1523,y:697,t:1527030736107};\\\", \\\"{x:1525,y:695,t:1527030736124};\\\", \\\"{x:1526,y:695,t:1527030736141};\\\", \\\"{x:1527,y:695,t:1527030736157};\\\", \\\"{x:1528,y:695,t:1527030736174};\\\", \\\"{x:1529,y:694,t:1527030736190};\\\", \\\"{x:1531,y:694,t:1527030736224};\\\", \\\"{x:1532,y:694,t:1527030736321};\\\", \\\"{x:1536,y:694,t:1527030736329};\\\", \\\"{x:1539,y:694,t:1527030736341};\\\", \\\"{x:1544,y:694,t:1527030736358};\\\", \\\"{x:1547,y:694,t:1527030736375};\\\", \\\"{x:1549,y:694,t:1527030736392};\\\", \\\"{x:1549,y:695,t:1527030736409};\\\", \\\"{x:1552,y:695,t:1527030736753};\\\", \\\"{x:1554,y:695,t:1527030736761};\\\", \\\"{x:1557,y:696,t:1527030736774};\\\", \\\"{x:1564,y:697,t:1527030736792};\\\", \\\"{x:1570,y:697,t:1527030736808};\\\", \\\"{x:1580,y:697,t:1527030736824};\\\", \\\"{x:1584,y:697,t:1527030736842};\\\", \\\"{x:1587,y:697,t:1527030736859};\\\", \\\"{x:1592,y:696,t:1527030736875};\\\", \\\"{x:1599,y:695,t:1527030736892};\\\", \\\"{x:1605,y:694,t:1527030736909};\\\", \\\"{x:1611,y:694,t:1527030736925};\\\", \\\"{x:1617,y:694,t:1527030736942};\\\", \\\"{x:1621,y:694,t:1527030736959};\\\", \\\"{x:1622,y:694,t:1527030736975};\\\", \\\"{x:1624,y:694,t:1527030736992};\\\", \\\"{x:1624,y:695,t:1527030737153};\\\", \\\"{x:1623,y:696,t:1527030737169};\\\", \\\"{x:1622,y:696,t:1527030737176};\\\", \\\"{x:1621,y:697,t:1527030737192};\\\", \\\"{x:1617,y:699,t:1527030737208};\\\", \\\"{x:1615,y:700,t:1527030737224};\\\", \\\"{x:1614,y:700,t:1527030737241};\\\", \\\"{x:1613,y:700,t:1527030737258};\\\", \\\"{x:1610,y:700,t:1527030741505};\\\", \\\"{x:1602,y:700,t:1527030741514};\\\", \\\"{x:1590,y:702,t:1527030741528};\\\", \\\"{x:1548,y:714,t:1527030741543};\\\", \\\"{x:1525,y:723,t:1527030741562};\\\", \\\"{x:1501,y:733,t:1527030741577};\\\", \\\"{x:1484,y:740,t:1527030741594};\\\", \\\"{x:1474,y:743,t:1527030741611};\\\", \\\"{x:1470,y:744,t:1527030741627};\\\", \\\"{x:1469,y:744,t:1527030741644};\\\", \\\"{x:1468,y:744,t:1527030741661};\\\", \\\"{x:1465,y:744,t:1527030741678};\\\", \\\"{x:1458,y:744,t:1527030741695};\\\", \\\"{x:1447,y:745,t:1527030741712};\\\", \\\"{x:1435,y:750,t:1527030741727};\\\", \\\"{x:1408,y:763,t:1527030741745};\\\", \\\"{x:1390,y:772,t:1527030741762};\\\", \\\"{x:1377,y:779,t:1527030741778};\\\", \\\"{x:1368,y:781,t:1527030741795};\\\", \\\"{x:1364,y:781,t:1527030741812};\\\", \\\"{x:1363,y:781,t:1527030741833};\\\", \\\"{x:1361,y:781,t:1527030741845};\\\", \\\"{x:1358,y:780,t:1527030741861};\\\", \\\"{x:1354,y:779,t:1527030741877};\\\", \\\"{x:1353,y:779,t:1527030741895};\\\", \\\"{x:1352,y:779,t:1527030741911};\\\", \\\"{x:1350,y:777,t:1527030741992};\\\", \\\"{x:1349,y:775,t:1527030742000};\\\", \\\"{x:1349,y:773,t:1527030742012};\\\", \\\"{x:1349,y:772,t:1527030742029};\\\", \\\"{x:1349,y:771,t:1527030742045};\\\", \\\"{x:1349,y:770,t:1527030742072};\\\", \\\"{x:1351,y:769,t:1527030742088};\\\", \\\"{x:1353,y:769,t:1527030742096};\\\", \\\"{x:1355,y:768,t:1527030742112};\\\", \\\"{x:1358,y:766,t:1527030742128};\\\", \\\"{x:1359,y:765,t:1527030742337};\\\", \\\"{x:1356,y:763,t:1527030742352};\\\", \\\"{x:1354,y:763,t:1527030742362};\\\", \\\"{x:1352,y:763,t:1527030742379};\\\", \\\"{x:1351,y:763,t:1527030742394};\\\", \\\"{x:1353,y:763,t:1527030742593};\\\", \\\"{x:1354,y:762,t:1527030742602};\\\", \\\"{x:1357,y:761,t:1527030742612};\\\", \\\"{x:1359,y:761,t:1527030742628};\\\", \\\"{x:1361,y:760,t:1527030742646};\\\", \\\"{x:1362,y:760,t:1527030742662};\\\", \\\"{x:1364,y:760,t:1527030742681};\\\", \\\"{x:1364,y:763,t:1527030743073};\\\", \\\"{x:1364,y:771,t:1527030743081};\\\", \\\"{x:1364,y:783,t:1527030743096};\\\", \\\"{x:1366,y:820,t:1527030743112};\\\", \\\"{x:1369,y:841,t:1527030743129};\\\", \\\"{x:1371,y:855,t:1527030743146};\\\", \\\"{x:1376,y:865,t:1527030743163};\\\", \\\"{x:1378,y:871,t:1527030743179};\\\", \\\"{x:1378,y:872,t:1527030743196};\\\", \\\"{x:1379,y:873,t:1527030743213};\\\", \\\"{x:1379,y:874,t:1527030743265};\\\", \\\"{x:1379,y:875,t:1527030743281};\\\", \\\"{x:1379,y:876,t:1527030743353};\\\", \\\"{x:1377,y:875,t:1527030743369};\\\", \\\"{x:1375,y:873,t:1527030743379};\\\", \\\"{x:1375,y:870,t:1527030743395};\\\", \\\"{x:1375,y:869,t:1527030743416};\\\", \\\"{x:1374,y:867,t:1527030743440};\\\", \\\"{x:1374,y:865,t:1527030743456};\\\", \\\"{x:1373,y:864,t:1527030743464};\\\", \\\"{x:1373,y:862,t:1527030743478};\\\", \\\"{x:1373,y:859,t:1527030743496};\\\", \\\"{x:1372,y:853,t:1527030743512};\\\", \\\"{x:1371,y:849,t:1527030743529};\\\", \\\"{x:1371,y:848,t:1527030743545};\\\", \\\"{x:1369,y:848,t:1527030743706};\\\", \\\"{x:1367,y:850,t:1527030743713};\\\", \\\"{x:1364,y:855,t:1527030743730};\\\", \\\"{x:1360,y:860,t:1527030743746};\\\", \\\"{x:1357,y:861,t:1527030743763};\\\", \\\"{x:1356,y:861,t:1527030744041};\\\", \\\"{x:1356,y:860,t:1527030744049};\\\", \\\"{x:1356,y:859,t:1527030744257};\\\", \\\"{x:1356,y:858,t:1527030744265};\\\", \\\"{x:1356,y:857,t:1527030744289};\\\", \\\"{x:1356,y:856,t:1527030744457};\\\", \\\"{x:1356,y:855,t:1527030744473};\\\", \\\"{x:1355,y:854,t:1527030744545};\\\", \\\"{x:1354,y:854,t:1527030744553};\\\", \\\"{x:1355,y:858,t:1527030745937};\\\", \\\"{x:1358,y:863,t:1527030745949};\\\", \\\"{x:1362,y:868,t:1527030745965};\\\", \\\"{x:1364,y:871,t:1527030745982};\\\", \\\"{x:1365,y:872,t:1527030745997};\\\", \\\"{x:1365,y:874,t:1527030746079};\\\", \\\"{x:1365,y:876,t:1527030746097};\\\", \\\"{x:1365,y:877,t:1527030746112};\\\", \\\"{x:1365,y:879,t:1527030746223};\\\", \\\"{x:1365,y:880,t:1527030746231};\\\", \\\"{x:1365,y:882,t:1527030746247};\\\", \\\"{x:1365,y:886,t:1527030746263};\\\", \\\"{x:1366,y:887,t:1527030746280};\\\", \\\"{x:1368,y:887,t:1527030746392};\\\", \\\"{x:1370,y:888,t:1527030746399};\\\", \\\"{x:1371,y:890,t:1527030746414};\\\", \\\"{x:1377,y:892,t:1527030746430};\\\", \\\"{x:1380,y:893,t:1527030746446};\\\", \\\"{x:1383,y:893,t:1527030746463};\\\", \\\"{x:1385,y:895,t:1527030746527};\\\", \\\"{x:1387,y:896,t:1527030746536};\\\", \\\"{x:1391,y:900,t:1527030746546};\\\", \\\"{x:1393,y:903,t:1527030746563};\\\", \\\"{x:1395,y:905,t:1527030746579};\\\", \\\"{x:1395,y:906,t:1527030746596};\\\", \\\"{x:1395,y:905,t:1527030746879};\\\", \\\"{x:1395,y:904,t:1527030746897};\\\", \\\"{x:1394,y:904,t:1527030746914};\\\", \\\"{x:1394,y:903,t:1527030746930};\\\", \\\"{x:1393,y:903,t:1527030746946};\\\", \\\"{x:1393,y:902,t:1527030746967};\\\", \\\"{x:1393,y:901,t:1527030747007};\\\", \\\"{x:1392,y:901,t:1527030747032};\\\", \\\"{x:1392,y:900,t:1527030747071};\\\", \\\"{x:1392,y:899,t:1527030747102};\\\", \\\"{x:1395,y:896,t:1527030747680};\\\", \\\"{x:1405,y:893,t:1527030747698};\\\", \\\"{x:1418,y:889,t:1527030747713};\\\", \\\"{x:1430,y:883,t:1527030747730};\\\", \\\"{x:1441,y:876,t:1527030747747};\\\", \\\"{x:1446,y:873,t:1527030747763};\\\", \\\"{x:1448,y:869,t:1527030747781};\\\", \\\"{x:1449,y:866,t:1527030747797};\\\", \\\"{x:1449,y:862,t:1527030747813};\\\", \\\"{x:1449,y:860,t:1527030747830};\\\", \\\"{x:1449,y:858,t:1527030747848};\\\", \\\"{x:1449,y:857,t:1527030747864};\\\", \\\"{x:1449,y:855,t:1527030747880};\\\", \\\"{x:1452,y:851,t:1527030747897};\\\", \\\"{x:1456,y:848,t:1527030747914};\\\", \\\"{x:1463,y:844,t:1527030747930};\\\", \\\"{x:1471,y:839,t:1527030747947};\\\", \\\"{x:1478,y:835,t:1527030747965};\\\", \\\"{x:1482,y:833,t:1527030747980};\\\", \\\"{x:1485,y:831,t:1527030747997};\\\", \\\"{x:1485,y:830,t:1527030748127};\\\", \\\"{x:1485,y:829,t:1527030748134};\\\", \\\"{x:1484,y:829,t:1527030748150};\\\", \\\"{x:1483,y:828,t:1527030748199};\\\", \\\"{x:1482,y:828,t:1527030748222};\\\", \\\"{x:1481,y:828,t:1527030748230};\\\", \\\"{x:1481,y:827,t:1527030748247};\\\", \\\"{x:1480,y:827,t:1527030748264};\\\", \\\"{x:1479,y:827,t:1527030748286};\\\", \\\"{x:1478,y:826,t:1527030748297};\\\", \\\"{x:1482,y:826,t:1527030750263};\\\", \\\"{x:1483,y:826,t:1527030750270};\\\", \\\"{x:1487,y:826,t:1527030750283};\\\", \\\"{x:1492,y:828,t:1527030750298};\\\", \\\"{x:1499,y:830,t:1527030750316};\\\", \\\"{x:1507,y:832,t:1527030750333};\\\", \\\"{x:1511,y:832,t:1527030750349};\\\", \\\"{x:1513,y:832,t:1527030750366};\\\", \\\"{x:1514,y:832,t:1527030750383};\\\", \\\"{x:1515,y:832,t:1527030750447};\\\", \\\"{x:1517,y:832,t:1527030750454};\\\", \\\"{x:1518,y:832,t:1527030750466};\\\", \\\"{x:1520,y:832,t:1527030750487};\\\", \\\"{x:1521,y:832,t:1527030750500};\\\", \\\"{x:1527,y:832,t:1527030750516};\\\", \\\"{x:1533,y:831,t:1527030750533};\\\", \\\"{x:1538,y:831,t:1527030750549};\\\", \\\"{x:1542,y:831,t:1527030750566};\\\", \\\"{x:1545,y:830,t:1527030750583};\\\", \\\"{x:1547,y:829,t:1527030750599};\\\", \\\"{x:1549,y:829,t:1527030750615};\\\", \\\"{x:1550,y:829,t:1527030750632};\\\", \\\"{x:1552,y:828,t:1527030750649};\\\", \\\"{x:1553,y:828,t:1527030750686};\\\", \\\"{x:1555,y:828,t:1527030751871};\\\", \\\"{x:1563,y:828,t:1527030751884};\\\", \\\"{x:1586,y:830,t:1527030751899};\\\", \\\"{x:1609,y:832,t:1527030751916};\\\", \\\"{x:1632,y:836,t:1527030751933};\\\", \\\"{x:1650,y:838,t:1527030751949};\\\", \\\"{x:1659,y:839,t:1527030751966};\\\", \\\"{x:1657,y:839,t:1527030752185};\\\", \\\"{x:1654,y:839,t:1527030752200};\\\", \\\"{x:1653,y:839,t:1527030752217};\\\", \\\"{x:1651,y:838,t:1527030752233};\\\", \\\"{x:1650,y:838,t:1527030752250};\\\", \\\"{x:1649,y:837,t:1527030752266};\\\", \\\"{x:1647,y:836,t:1527030752302};\\\", \\\"{x:1646,y:836,t:1527030752317};\\\", \\\"{x:1642,y:834,t:1527030752334};\\\", \\\"{x:1639,y:833,t:1527030752351};\\\", \\\"{x:1637,y:832,t:1527030752390};\\\", \\\"{x:1635,y:831,t:1527030752406};\\\", \\\"{x:1634,y:831,t:1527030752422};\\\", \\\"{x:1633,y:830,t:1527030752433};\\\", \\\"{x:1632,y:830,t:1527030752663};\\\", \\\"{x:1631,y:830,t:1527030752679};\\\", \\\"{x:1630,y:830,t:1527030752687};\\\", \\\"{x:1629,y:830,t:1527030752700};\\\", \\\"{x:1627,y:830,t:1527030752718};\\\", \\\"{x:1626,y:830,t:1527030752847};\\\", \\\"{x:1624,y:830,t:1527030752879};\\\", \\\"{x:1623,y:830,t:1527030752927};\\\", \\\"{x:1621,y:830,t:1527030752951};\\\", \\\"{x:1620,y:830,t:1527030753519};\\\", \\\"{x:1619,y:830,t:1527030753535};\\\", \\\"{x:1618,y:830,t:1527030753552};\\\", \\\"{x:1617,y:829,t:1527030753568};\\\", \\\"{x:1616,y:828,t:1527030753991};\\\", \\\"{x:1610,y:825,t:1527030754002};\\\", \\\"{x:1585,y:819,t:1527030754018};\\\", \\\"{x:1531,y:811,t:1527030754035};\\\", \\\"{x:1442,y:796,t:1527030754052};\\\", \\\"{x:1347,y:782,t:1527030754067};\\\", \\\"{x:1247,y:766,t:1527030754085};\\\", \\\"{x:1162,y:759,t:1527030754102};\\\", \\\"{x:1081,y:757,t:1527030754119};\\\", \\\"{x:1044,y:757,t:1527030754134};\\\", \\\"{x:1020,y:756,t:1527030754152};\\\", \\\"{x:1004,y:753,t:1527030754169};\\\", \\\"{x:993,y:751,t:1527030754185};\\\", \\\"{x:981,y:747,t:1527030754202};\\\", \\\"{x:966,y:743,t:1527030754219};\\\", \\\"{x:952,y:737,t:1527030754235};\\\", \\\"{x:942,y:727,t:1527030754251};\\\", \\\"{x:934,y:718,t:1527030754268};\\\", \\\"{x:923,y:704,t:1527030754284};\\\", \\\"{x:913,y:692,t:1527030754302};\\\", \\\"{x:896,y:674,t:1527030754318};\\\", \\\"{x:861,y:652,t:1527030754334};\\\", \\\"{x:796,y:616,t:1527030754353};\\\", \\\"{x:698,y:567,t:1527030754369};\\\", \\\"{x:602,y:525,t:1527030754385};\\\", \\\"{x:508,y:500,t:1527030754406};\\\", \\\"{x:494,y:499,t:1527030754424};\\\", \\\"{x:497,y:499,t:1527030754462};\\\", \\\"{x:503,y:497,t:1527030754474};\\\", \\\"{x:511,y:494,t:1527030754490};\\\", \\\"{x:520,y:490,t:1527030754506};\\\", \\\"{x:527,y:487,t:1527030754523};\\\", \\\"{x:531,y:486,t:1527030754541};\\\", \\\"{x:535,y:486,t:1527030754556};\\\", \\\"{x:540,y:486,t:1527030754573};\\\", \\\"{x:546,y:492,t:1527030754591};\\\", \\\"{x:546,y:499,t:1527030754608};\\\", \\\"{x:546,y:505,t:1527030754623};\\\", \\\"{x:538,y:513,t:1527030754640};\\\", \\\"{x:533,y:519,t:1527030754657};\\\", \\\"{x:533,y:525,t:1527030754674};\\\", \\\"{x:532,y:534,t:1527030754690};\\\", \\\"{x:532,y:540,t:1527030754707};\\\", \\\"{x:532,y:546,t:1527030754723};\\\", \\\"{x:532,y:551,t:1527030754740};\\\", \\\"{x:533,y:558,t:1527030754757};\\\", \\\"{x:537,y:566,t:1527030754774};\\\", \\\"{x:543,y:573,t:1527030754790};\\\", \\\"{x:547,y:577,t:1527030754807};\\\", \\\"{x:551,y:579,t:1527030754823};\\\", \\\"{x:553,y:579,t:1527030754840};\\\", \\\"{x:557,y:579,t:1527030754857};\\\", \\\"{x:560,y:579,t:1527030754873};\\\", \\\"{x:565,y:579,t:1527030754890};\\\", \\\"{x:571,y:577,t:1527030754907};\\\", \\\"{x:576,y:577,t:1527030754923};\\\", \\\"{x:582,y:576,t:1527030754941};\\\", \\\"{x:583,y:576,t:1527030754957};\\\", \\\"{x:586,y:576,t:1527030755151};\\\", \\\"{x:589,y:576,t:1527030755158};\\\", \\\"{x:591,y:576,t:1527030755174};\\\", \\\"{x:598,y:576,t:1527030755191};\\\", \\\"{x:601,y:576,t:1527030755728};\\\", \\\"{x:603,y:576,t:1527030755740};\\\", \\\"{x:609,y:576,t:1527030755757};\\\", \\\"{x:622,y:577,t:1527030755774};\\\", \\\"{x:626,y:577,t:1527030755791};\\\", \\\"{x:627,y:577,t:1527030755808};\\\", \\\"{x:628,y:578,t:1527030755911};\\\", \\\"{x:628,y:579,t:1527030755925};\\\", \\\"{x:626,y:579,t:1527030755941};\\\", \\\"{x:622,y:581,t:1527030755958};\\\", \\\"{x:621,y:581,t:1527030755975};\\\", \\\"{x:621,y:582,t:1527030755991};\\\", \\\"{x:619,y:583,t:1527030756009};\\\", \\\"{x:618,y:583,t:1527030756026};\\\", \\\"{x:617,y:584,t:1527030756043};\\\", \\\"{x:616,y:584,t:1527030756058};\\\", \\\"{x:620,y:584,t:1527030756646};\\\", \\\"{x:630,y:589,t:1527030756659};\\\", \\\"{x:660,y:602,t:1527030756676};\\\", \\\"{x:707,y:624,t:1527030756691};\\\", \\\"{x:777,y:657,t:1527030756709};\\\", \\\"{x:865,y:694,t:1527030756725};\\\", \\\"{x:967,y:735,t:1527030756741};\\\", \\\"{x:1126,y:790,t:1527030756758};\\\", \\\"{x:1243,y:832,t:1527030756775};\\\", \\\"{x:1347,y:873,t:1527030756792};\\\", \\\"{x:1441,y:910,t:1527030756809};\\\", \\\"{x:1529,y:950,t:1527030756825};\\\", \\\"{x:1604,y:983,t:1527030756843};\\\", \\\"{x:1656,y:1003,t:1527030756860};\\\", \\\"{x:1698,y:1016,t:1527030756875};\\\", \\\"{x:1712,y:1021,t:1527030756892};\\\", \\\"{x:1714,y:1021,t:1527030756909};\\\", \\\"{x:1715,y:1021,t:1527030756926};\\\", \\\"{x:1716,y:1021,t:1527030756959};\\\", \\\"{x:1716,y:1020,t:1527030756982};\\\", \\\"{x:1716,y:1018,t:1527030756993};\\\", \\\"{x:1716,y:1017,t:1527030757014};\\\", \\\"{x:1716,y:1016,t:1527030757026};\\\", \\\"{x:1716,y:1010,t:1527030757042};\\\", \\\"{x:1707,y:1004,t:1527030757059};\\\", \\\"{x:1698,y:998,t:1527030757076};\\\", \\\"{x:1692,y:995,t:1527030757093};\\\", \\\"{x:1687,y:993,t:1527030757108};\\\", \\\"{x:1680,y:989,t:1527030757125};\\\", \\\"{x:1642,y:969,t:1527030757142};\\\", \\\"{x:1606,y:954,t:1527030757160};\\\", \\\"{x:1580,y:943,t:1527030757176};\\\", \\\"{x:1566,y:936,t:1527030757192};\\\", \\\"{x:1564,y:934,t:1527030757209};\\\", \\\"{x:1562,y:933,t:1527030757225};\\\", \\\"{x:1561,y:932,t:1527030757246};\\\", \\\"{x:1560,y:932,t:1527030757278};\\\", \\\"{x:1559,y:931,t:1527030757856};\\\", \\\"{x:1558,y:926,t:1527030758359};\\\", \\\"{x:1555,y:916,t:1527030758366};\\\", \\\"{x:1554,y:911,t:1527030758376};\\\", \\\"{x:1554,y:896,t:1527030758393};\\\", \\\"{x:1556,y:881,t:1527030758411};\\\", \\\"{x:1560,y:868,t:1527030758427};\\\", \\\"{x:1566,y:850,t:1527030758444};\\\", \\\"{x:1567,y:831,t:1527030758460};\\\", \\\"{x:1567,y:818,t:1527030758477};\\\", \\\"{x:1570,y:809,t:1527030758493};\\\", \\\"{x:1571,y:807,t:1527030758511};\\\", \\\"{x:1572,y:807,t:1527030758607};\\\", \\\"{x:1573,y:806,t:1527030758623};\\\", \\\"{x:1575,y:805,t:1527030758639};\\\", \\\"{x:1577,y:805,t:1527030758646};\\\", \\\"{x:1577,y:804,t:1527030758661};\\\", \\\"{x:1579,y:803,t:1527030758677};\\\", \\\"{x:1581,y:803,t:1527030758694};\\\", \\\"{x:1581,y:801,t:1527030759031};\\\", \\\"{x:1580,y:799,t:1527030759046};\\\", \\\"{x:1578,y:796,t:1527030759061};\\\", \\\"{x:1573,y:790,t:1527030759077};\\\", \\\"{x:1566,y:783,t:1527030759094};\\\", \\\"{x:1560,y:780,t:1527030759111};\\\", \\\"{x:1550,y:775,t:1527030759128};\\\", \\\"{x:1536,y:770,t:1527030759144};\\\", \\\"{x:1518,y:768,t:1527030759161};\\\", \\\"{x:1497,y:764,t:1527030759177};\\\", \\\"{x:1476,y:763,t:1527030759195};\\\", \\\"{x:1459,y:762,t:1527030759211};\\\", \\\"{x:1450,y:762,t:1527030759228};\\\", \\\"{x:1447,y:762,t:1527030759245};\\\", \\\"{x:1445,y:762,t:1527030759261};\\\", \\\"{x:1443,y:761,t:1527030759414};\\\", \\\"{x:1442,y:756,t:1527030759428};\\\", \\\"{x:1438,y:742,t:1527030759444};\\\", \\\"{x:1436,y:726,t:1527030759461};\\\", \\\"{x:1428,y:708,t:1527030759478};\\\", \\\"{x:1415,y:686,t:1527030759494};\\\", \\\"{x:1408,y:682,t:1527030759511};\\\", \\\"{x:1407,y:682,t:1527030759566};\\\", \\\"{x:1406,y:682,t:1527030759590};\\\", \\\"{x:1405,y:681,t:1527030759598};\\\", \\\"{x:1402,y:681,t:1527030759612};\\\", \\\"{x:1398,y:681,t:1527030759628};\\\", \\\"{x:1393,y:681,t:1527030759645};\\\", \\\"{x:1386,y:681,t:1527030759662};\\\", \\\"{x:1378,y:681,t:1527030759677};\\\", \\\"{x:1371,y:681,t:1527030759694};\\\", \\\"{x:1367,y:681,t:1527030759711};\\\", \\\"{x:1366,y:681,t:1527030759727};\\\", \\\"{x:1365,y:681,t:1527030759750};\\\", \\\"{x:1364,y:681,t:1527030759775};\\\", \\\"{x:1363,y:681,t:1527030759790};\\\", \\\"{x:1362,y:681,t:1527030759798};\\\", \\\"{x:1361,y:681,t:1527030759812};\\\", \\\"{x:1357,y:682,t:1527030759828};\\\", \\\"{x:1353,y:682,t:1527030759845};\\\", \\\"{x:1349,y:683,t:1527030759862};\\\", \\\"{x:1347,y:683,t:1527030759878};\\\", \\\"{x:1345,y:684,t:1527030759894};\\\", \\\"{x:1344,y:684,t:1527030760263};\\\", \\\"{x:1345,y:686,t:1527030760279};\\\", \\\"{x:1347,y:687,t:1527030760296};\\\", \\\"{x:1348,y:687,t:1527030760312};\\\", \\\"{x:1349,y:687,t:1527030760329};\\\", \\\"{x:1350,y:687,t:1527030762600};\\\", \\\"{x:1350,y:689,t:1527030762614};\\\", \\\"{x:1349,y:693,t:1527030762631};\\\", \\\"{x:1349,y:694,t:1527030762648};\\\", \\\"{x:1348,y:695,t:1527030762664};\\\", \\\"{x:1348,y:696,t:1527030762681};\\\", \\\"{x:1347,y:696,t:1527030763887};\\\", \\\"{x:1345,y:686,t:1527030763900};\\\", \\\"{x:1337,y:670,t:1527030763916};\\\", \\\"{x:1333,y:662,t:1527030763932};\\\", \\\"{x:1332,y:660,t:1527030763949};\\\", \\\"{x:1331,y:658,t:1527030763965};\\\", \\\"{x:1331,y:656,t:1527030764143};\\\", \\\"{x:1331,y:651,t:1527030764151};\\\", \\\"{x:1329,y:637,t:1527030764167};\\\", \\\"{x:1327,y:617,t:1527030764183};\\\", \\\"{x:1322,y:598,t:1527030764199};\\\", \\\"{x:1319,y:591,t:1527030764216};\\\", \\\"{x:1317,y:589,t:1527030764232};\\\", \\\"{x:1316,y:586,t:1527030764250};\\\", \\\"{x:1314,y:585,t:1527030764266};\\\", \\\"{x:1314,y:583,t:1527030764282};\\\", \\\"{x:1313,y:582,t:1527030764299};\\\", \\\"{x:1312,y:581,t:1527030764316};\\\", \\\"{x:1311,y:581,t:1527030764332};\\\", \\\"{x:1311,y:579,t:1527030764349};\\\", \\\"{x:1309,y:574,t:1527030764366};\\\", \\\"{x:1307,y:569,t:1527030764381};\\\", \\\"{x:1305,y:561,t:1527030764399};\\\", \\\"{x:1303,y:556,t:1527030764415};\\\", \\\"{x:1303,y:554,t:1527030764433};\\\", \\\"{x:1302,y:552,t:1527030764449};\\\", \\\"{x:1301,y:552,t:1527030764466};\\\", \\\"{x:1301,y:551,t:1527030764482};\\\", \\\"{x:1301,y:550,t:1527030764499};\\\", \\\"{x:1298,y:549,t:1527030764516};\\\", \\\"{x:1293,y:548,t:1527030764533};\\\", \\\"{x:1286,y:548,t:1527030764549};\\\", \\\"{x:1280,y:547,t:1527030764566};\\\", \\\"{x:1276,y:547,t:1527030764582};\\\", \\\"{x:1273,y:547,t:1527030764598};\\\", \\\"{x:1271,y:547,t:1527030764616};\\\", \\\"{x:1270,y:547,t:1527030764633};\\\", \\\"{x:1269,y:548,t:1527030764649};\\\", \\\"{x:1266,y:549,t:1527030764666};\\\", \\\"{x:1265,y:550,t:1527030764683};\\\", \\\"{x:1264,y:551,t:1527030764702};\\\", \\\"{x:1265,y:552,t:1527030764991};\\\", \\\"{x:1265,y:553,t:1527030765007};\\\", \\\"{x:1266,y:553,t:1527030765023};\\\", \\\"{x:1266,y:554,t:1527030765054};\\\", \\\"{x:1268,y:554,t:1527030765543};\\\", \\\"{x:1270,y:555,t:1527030765559};\\\", \\\"{x:1270,y:556,t:1527030765567};\\\", \\\"{x:1271,y:556,t:1527030765584};\\\", \\\"{x:1272,y:556,t:1527030765601};\\\", \\\"{x:1273,y:556,t:1527030765618};\\\", \\\"{x:1278,y:558,t:1527030765634};\\\", \\\"{x:1281,y:559,t:1527030765650};\\\", \\\"{x:1284,y:559,t:1527030765667};\\\", \\\"{x:1288,y:561,t:1527030765685};\\\", \\\"{x:1292,y:561,t:1527030765700};\\\", \\\"{x:1294,y:561,t:1527030765717};\\\", \\\"{x:1298,y:564,t:1527030765734};\\\", \\\"{x:1299,y:564,t:1527030765751};\\\", \\\"{x:1300,y:564,t:1527030765767};\\\", \\\"{x:1301,y:564,t:1527030765791};\\\", \\\"{x:1302,y:564,t:1527030765839};\\\", \\\"{x:1300,y:564,t:1527030766247};\\\", \\\"{x:1299,y:564,t:1527030766271};\\\", \\\"{x:1297,y:564,t:1527030766311};\\\", \\\"{x:1296,y:563,t:1527030766336};\\\", \\\"{x:1294,y:563,t:1527030766367};\\\", \\\"{x:1293,y:563,t:1527030766390};\\\", \\\"{x:1293,y:562,t:1527030766415};\\\", \\\"{x:1291,y:562,t:1527030766527};\\\", \\\"{x:1294,y:562,t:1527030766783};\\\", \\\"{x:1295,y:562,t:1527030766791};\\\", \\\"{x:1297,y:562,t:1527030766801};\\\", \\\"{x:1304,y:563,t:1527030766818};\\\", \\\"{x:1309,y:564,t:1527030766835};\\\", \\\"{x:1313,y:564,t:1527030766851};\\\", \\\"{x:1320,y:565,t:1527030766868};\\\", \\\"{x:1324,y:566,t:1527030766885};\\\", \\\"{x:1327,y:566,t:1527030766900};\\\", \\\"{x:1329,y:566,t:1527030766918};\\\", \\\"{x:1331,y:566,t:1527030766935};\\\", \\\"{x:1332,y:566,t:1527030766951};\\\", \\\"{x:1334,y:566,t:1527030766968};\\\", \\\"{x:1335,y:566,t:1527030766985};\\\", \\\"{x:1337,y:566,t:1527030767001};\\\", \\\"{x:1339,y:566,t:1527030767018};\\\", \\\"{x:1342,y:566,t:1527030767034};\\\", \\\"{x:1344,y:566,t:1527030767051};\\\", \\\"{x:1345,y:566,t:1527030767068};\\\", \\\"{x:1346,y:566,t:1527030767087};\\\", \\\"{x:1347,y:566,t:1527030767103};\\\", \\\"{x:1348,y:566,t:1527030767134};\\\", \\\"{x:1347,y:566,t:1527030768895};\\\", \\\"{x:1346,y:566,t:1527030768904};\\\", \\\"{x:1345,y:565,t:1527030768921};\\\", \\\"{x:1343,y:564,t:1527030768937};\\\", \\\"{x:1341,y:564,t:1527030768953};\\\", \\\"{x:1337,y:564,t:1527030768971};\\\", \\\"{x:1331,y:564,t:1527030768987};\\\", \\\"{x:1325,y:564,t:1527030769004};\\\", \\\"{x:1317,y:564,t:1527030769020};\\\", \\\"{x:1309,y:564,t:1527030769038};\\\", \\\"{x:1302,y:564,t:1527030769054};\\\", \\\"{x:1292,y:564,t:1527030769070};\\\", \\\"{x:1289,y:564,t:1527030769087};\\\", \\\"{x:1286,y:564,t:1527030769104};\\\", \\\"{x:1285,y:564,t:1527030769120};\\\", \\\"{x:1284,y:563,t:1527030769311};\\\", \\\"{x:1283,y:563,t:1527030769646};\\\", \\\"{x:1281,y:563,t:1527030769655};\\\", \\\"{x:1275,y:566,t:1527030769672};\\\", \\\"{x:1265,y:574,t:1527030769687};\\\", \\\"{x:1256,y:587,t:1527030769704};\\\", \\\"{x:1249,y:599,t:1527030769720};\\\", \\\"{x:1243,y:610,t:1527030769737};\\\", \\\"{x:1238,y:624,t:1527030769755};\\\", \\\"{x:1230,y:639,t:1527030769771};\\\", \\\"{x:1224,y:652,t:1527030769788};\\\", \\\"{x:1220,y:662,t:1527030769805};\\\", \\\"{x:1219,y:669,t:1527030769822};\\\", \\\"{x:1216,y:682,t:1527030769838};\\\", \\\"{x:1209,y:715,t:1527030769854};\\\", \\\"{x:1204,y:743,t:1527030769871};\\\", \\\"{x:1198,y:765,t:1527030769888};\\\", \\\"{x:1192,y:785,t:1527030769905};\\\", \\\"{x:1186,y:797,t:1527030769922};\\\", \\\"{x:1179,y:806,t:1527030769936};\\\", \\\"{x:1177,y:809,t:1527030769954};\\\", \\\"{x:1176,y:810,t:1527030770087};\\\", \\\"{x:1175,y:810,t:1527030770094};\\\", \\\"{x:1174,y:810,t:1527030770104};\\\", \\\"{x:1171,y:810,t:1527030770121};\\\", \\\"{x:1169,y:809,t:1527030770138};\\\", \\\"{x:1169,y:808,t:1527030770154};\\\", \\\"{x:1167,y:807,t:1527030770171};\\\", \\\"{x:1166,y:806,t:1527030770188};\\\", \\\"{x:1165,y:805,t:1527030770222};\\\", \\\"{x:1165,y:804,t:1527030770238};\\\", \\\"{x:1165,y:802,t:1527030770254};\\\", \\\"{x:1161,y:796,t:1527030770271};\\\", \\\"{x:1160,y:792,t:1527030770288};\\\", \\\"{x:1157,y:788,t:1527030770304};\\\", \\\"{x:1156,y:786,t:1527030770321};\\\", \\\"{x:1155,y:784,t:1527030770342};\\\", \\\"{x:1155,y:783,t:1527030770374};\\\", \\\"{x:1154,y:781,t:1527030770389};\\\", \\\"{x:1154,y:780,t:1527030770414};\\\", \\\"{x:1154,y:779,t:1527030770421};\\\", \\\"{x:1154,y:778,t:1527030770438};\\\", \\\"{x:1154,y:776,t:1527030770455};\\\", \\\"{x:1154,y:775,t:1527030770471};\\\", \\\"{x:1154,y:774,t:1527030770494};\\\", \\\"{x:1157,y:772,t:1527030770504};\\\", \\\"{x:1160,y:771,t:1527030770521};\\\", \\\"{x:1166,y:771,t:1527030770538};\\\", \\\"{x:1170,y:771,t:1527030770555};\\\", \\\"{x:1176,y:771,t:1527030770571};\\\", \\\"{x:1179,y:771,t:1527030770588};\\\", \\\"{x:1180,y:771,t:1527030770605};\\\", \\\"{x:1181,y:771,t:1527030770621};\\\", \\\"{x:1183,y:771,t:1527030770638};\\\", \\\"{x:1186,y:771,t:1527030770656};\\\", \\\"{x:1188,y:771,t:1527030770671};\\\", \\\"{x:1192,y:771,t:1527030770688};\\\", \\\"{x:1196,y:771,t:1527030770705};\\\", \\\"{x:1201,y:771,t:1527030770721};\\\", \\\"{x:1207,y:771,t:1527030770738};\\\", \\\"{x:1213,y:771,t:1527030770755};\\\", \\\"{x:1225,y:771,t:1527030770771};\\\", \\\"{x:1240,y:771,t:1527030770788};\\\", \\\"{x:1256,y:771,t:1527030770805};\\\", \\\"{x:1277,y:771,t:1527030770821};\\\", \\\"{x:1311,y:771,t:1527030770838};\\\", \\\"{x:1331,y:771,t:1527030770856};\\\", \\\"{x:1348,y:771,t:1527030770871};\\\", \\\"{x:1363,y:771,t:1527030770888};\\\", \\\"{x:1371,y:771,t:1527030770905};\\\", \\\"{x:1379,y:771,t:1527030770922};\\\", \\\"{x:1383,y:771,t:1527030770938};\\\", \\\"{x:1386,y:773,t:1527030770955};\\\", \\\"{x:1387,y:773,t:1527030770973};\\\", \\\"{x:1388,y:774,t:1527030770989};\\\", \\\"{x:1387,y:775,t:1527030771463};\\\", \\\"{x:1381,y:775,t:1527030771473};\\\", \\\"{x:1359,y:775,t:1527030771489};\\\", \\\"{x:1331,y:775,t:1527030771506};\\\", \\\"{x:1297,y:775,t:1527030771522};\\\", \\\"{x:1253,y:775,t:1527030771540};\\\", \\\"{x:1208,y:775,t:1527030771556};\\\", \\\"{x:1163,y:775,t:1527030771572};\\\", \\\"{x:1121,y:775,t:1527030771590};\\\", \\\"{x:1078,y:774,t:1527030771606};\\\", \\\"{x:1028,y:769,t:1527030771622};\\\", \\\"{x:1007,y:769,t:1527030771640};\\\", \\\"{x:994,y:769,t:1527030771656};\\\", \\\"{x:988,y:769,t:1527030771673};\\\", \\\"{x:983,y:769,t:1527030771689};\\\", \\\"{x:978,y:769,t:1527030771706};\\\", \\\"{x:974,y:769,t:1527030771722};\\\", \\\"{x:967,y:769,t:1527030771739};\\\", \\\"{x:957,y:769,t:1527030771756};\\\", \\\"{x:942,y:769,t:1527030771772};\\\", \\\"{x:923,y:769,t:1527030771789};\\\", \\\"{x:889,y:769,t:1527030771806};\\\", \\\"{x:872,y:769,t:1527030771822};\\\", \\\"{x:860,y:769,t:1527030771840};\\\", \\\"{x:855,y:768,t:1527030771857};\\\", \\\"{x:850,y:767,t:1527030771873};\\\", \\\"{x:848,y:765,t:1527030771889};\\\", \\\"{x:848,y:764,t:1527030771906};\\\", \\\"{x:849,y:764,t:1527030771922};\\\", \\\"{x:850,y:762,t:1527030772510};\\\", \\\"{x:850,y:760,t:1527030772526};\\\", \\\"{x:850,y:758,t:1527030772540};\\\", \\\"{x:850,y:756,t:1527030772556};\\\", \\\"{x:849,y:750,t:1527030772573};\\\", \\\"{x:846,y:743,t:1527030772591};\\\", \\\"{x:839,y:733,t:1527030772606};\\\", \\\"{x:825,y:724,t:1527030772624};\\\", \\\"{x:802,y:712,t:1527030772641};\\\", \\\"{x:772,y:700,t:1527030772656};\\\", \\\"{x:731,y:691,t:1527030772674};\\\", \\\"{x:694,y:685,t:1527030772691};\\\", \\\"{x:657,y:685,t:1527030772706};\\\", \\\"{x:618,y:685,t:1527030772723};\\\", \\\"{x:576,y:685,t:1527030772741};\\\", \\\"{x:539,y:685,t:1527030772757};\\\", \\\"{x:505,y:685,t:1527030772773};\\\", \\\"{x:472,y:688,t:1527030772791};\\\", \\\"{x:461,y:692,t:1527030772807};\\\", \\\"{x:460,y:693,t:1527030772824};\\\", \\\"{x:459,y:694,t:1527030772840};\\\", \\\"{x:459,y:696,t:1527030772858};\\\", \\\"{x:458,y:697,t:1527030772874};\\\", \\\"{x:458,y:700,t:1527030772891};\\\", \\\"{x:458,y:701,t:1527030772910};\\\", \\\"{x:458,y:703,t:1527030772927};\\\", \\\"{x:458,y:704,t:1527030772941};\\\", \\\"{x:460,y:711,t:1527030772958};\\\", \\\"{x:463,y:717,t:1527030772973};\\\", \\\"{x:467,y:722,t:1527030772990};\\\", \\\"{x:468,y:724,t:1527030773007};\\\", \\\"{x:470,y:724,t:1527030773023};\\\", \\\"{x:471,y:726,t:1527030773038};\\\" ] }, { \\\"rt\\\": 16063, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 704753, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-03 PM-04 PM-05 PM-06 PM-07 PM-08 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:473,y:725,t:1527030777149};\\\", \\\"{x:497,y:715,t:1527030777157};\\\", \\\"{x:539,y:701,t:1527030777171};\\\", \\\"{x:663,y:668,t:1527030777189};\\\", \\\"{x:915,y:614,t:1527030777208};\\\", \\\"{x:1114,y:589,t:1527030777226};\\\", \\\"{x:1316,y:557,t:1527030777242};\\\", \\\"{x:1510,y:525,t:1527030777258};\\\", \\\"{x:1684,y:503,t:1527030777275};\\\", \\\"{x:1835,y:492,t:1527030777291};\\\", \\\"{x:1893,y:488,t:1527030777302};\\\", \\\"{x:1908,y:507,t:1527030777389};\\\", \\\"{x:1870,y:514,t:1527030777408};\\\", \\\"{x:1834,y:518,t:1527030777425};\\\", \\\"{x:1812,y:520,t:1527030777442};\\\", \\\"{x:1796,y:520,t:1527030777458};\\\", \\\"{x:1786,y:520,t:1527030777476};\\\", \\\"{x:1772,y:516,t:1527030777493};\\\", \\\"{x:1759,y:511,t:1527030777508};\\\", \\\"{x:1741,y:506,t:1527030777525};\\\", \\\"{x:1708,y:502,t:1527030777542};\\\", \\\"{x:1684,y:501,t:1527030777559};\\\", \\\"{x:1656,y:501,t:1527030777575};\\\", \\\"{x:1626,y:499,t:1527030777592};\\\", \\\"{x:1599,y:490,t:1527030777608};\\\", \\\"{x:1583,y:482,t:1527030777625};\\\", \\\"{x:1571,y:472,t:1527030777643};\\\", \\\"{x:1564,y:462,t:1527030777658};\\\", \\\"{x:1561,y:452,t:1527030777676};\\\", \\\"{x:1557,y:443,t:1527030777693};\\\", \\\"{x:1554,y:427,t:1527030777708};\\\", \\\"{x:1546,y:401,t:1527030777725};\\\", \\\"{x:1537,y:371,t:1527030777742};\\\", \\\"{x:1531,y:343,t:1527030777759};\\\", \\\"{x:1523,y:306,t:1527030777776};\\\", \\\"{x:1514,y:260,t:1527030777793};\\\", \\\"{x:1506,y:225,t:1527030777808};\\\", \\\"{x:1492,y:184,t:1527030777826};\\\", \\\"{x:1481,y:155,t:1527030777844};\\\", \\\"{x:1465,y:126,t:1527030777860};\\\", \\\"{x:1451,y:108,t:1527030777876};\\\", \\\"{x:1440,y:97,t:1527030777893};\\\", \\\"{x:1438,y:96,t:1527030777909};\\\", \\\"{x:1437,y:94,t:1527030777925};\\\", \\\"{x:1435,y:94,t:1527030777941};\\\", \\\"{x:1434,y:94,t:1527030777982};\\\", \\\"{x:1433,y:94,t:1527030777992};\\\", \\\"{x:1431,y:99,t:1527030778009};\\\", \\\"{x:1431,y:114,t:1527030778025};\\\", \\\"{x:1431,y:139,t:1527030778042};\\\", \\\"{x:1431,y:167,t:1527030778059};\\\", \\\"{x:1431,y:203,t:1527030778075};\\\", \\\"{x:1431,y:237,t:1527030778092};\\\", \\\"{x:1431,y:260,t:1527030778109};\\\", \\\"{x:1431,y:277,t:1527030778126};\\\", \\\"{x:1432,y:289,t:1527030778142};\\\", \\\"{x:1436,y:297,t:1527030778159};\\\", \\\"{x:1437,y:299,t:1527030778198};\\\", \\\"{x:1438,y:300,t:1527030778214};\\\", \\\"{x:1439,y:301,t:1527030778271};\\\", \\\"{x:1439,y:302,t:1527030778279};\\\", \\\"{x:1439,y:303,t:1527030778295};\\\", \\\"{x:1440,y:306,t:1527030778309};\\\", \\\"{x:1440,y:311,t:1527030778325};\\\", \\\"{x:1441,y:319,t:1527030778342};\\\", \\\"{x:1443,y:332,t:1527030778359};\\\", \\\"{x:1443,y:343,t:1527030778376};\\\", \\\"{x:1443,y:353,t:1527030778392};\\\", \\\"{x:1443,y:364,t:1527030778409};\\\", \\\"{x:1442,y:381,t:1527030778426};\\\", \\\"{x:1438,y:404,t:1527030778442};\\\", \\\"{x:1435,y:431,t:1527030778459};\\\", \\\"{x:1430,y:469,t:1527030778477};\\\", \\\"{x:1425,y:527,t:1527030778492};\\\", \\\"{x:1415,y:583,t:1527030778510};\\\", \\\"{x:1395,y:665,t:1527030778526};\\\", \\\"{x:1375,y:712,t:1527030778542};\\\", \\\"{x:1367,y:732,t:1527030778559};\\\", \\\"{x:1360,y:748,t:1527030778577};\\\", \\\"{x:1354,y:768,t:1527030778592};\\\", \\\"{x:1346,y:796,t:1527030778609};\\\", \\\"{x:1345,y:809,t:1527030778627};\\\", \\\"{x:1342,y:816,t:1527030778642};\\\", \\\"{x:1341,y:821,t:1527030778660};\\\", \\\"{x:1339,y:825,t:1527030778676};\\\", \\\"{x:1338,y:825,t:1527030778694};\\\", \\\"{x:1337,y:826,t:1527030778767};\\\", \\\"{x:1336,y:826,t:1527030778791};\\\", \\\"{x:1336,y:827,t:1527030778799};\\\", \\\"{x:1336,y:828,t:1527030778810};\\\", \\\"{x:1336,y:832,t:1527030778827};\\\", \\\"{x:1336,y:837,t:1527030778843};\\\", \\\"{x:1336,y:844,t:1527030778860};\\\", \\\"{x:1336,y:855,t:1527030778876};\\\", \\\"{x:1336,y:870,t:1527030778892};\\\", \\\"{x:1336,y:888,t:1527030778910};\\\", \\\"{x:1339,y:921,t:1527030778927};\\\", \\\"{x:1342,y:939,t:1527030778943};\\\", \\\"{x:1344,y:955,t:1527030778960};\\\", \\\"{x:1348,y:968,t:1527030778978};\\\", \\\"{x:1349,y:972,t:1527030778994};\\\", \\\"{x:1350,y:975,t:1527030779009};\\\", \\\"{x:1351,y:976,t:1527030779027};\\\", \\\"{x:1351,y:977,t:1527030779043};\\\", \\\"{x:1352,y:981,t:1527030779060};\\\", \\\"{x:1353,y:988,t:1527030779078};\\\", \\\"{x:1354,y:995,t:1527030779094};\\\", \\\"{x:1355,y:1002,t:1527030779110};\\\", \\\"{x:1355,y:1009,t:1527030779127};\\\", \\\"{x:1355,y:1012,t:1527030779144};\\\", \\\"{x:1357,y:1013,t:1527030779391};\\\", \\\"{x:1359,y:1013,t:1527030779399};\\\", \\\"{x:1362,y:1013,t:1527030779410};\\\", \\\"{x:1369,y:1013,t:1527030779426};\\\", \\\"{x:1381,y:1015,t:1527030779443};\\\", \\\"{x:1389,y:1019,t:1527030779460};\\\", \\\"{x:1396,y:1021,t:1527030779477};\\\", \\\"{x:1401,y:1023,t:1527030779493};\\\", \\\"{x:1406,y:1025,t:1527030779511};\\\", \\\"{x:1409,y:1026,t:1527030779526};\\\", \\\"{x:1413,y:1027,t:1527030779544};\\\", \\\"{x:1415,y:1027,t:1527030779561};\\\", \\\"{x:1418,y:1027,t:1527030779577};\\\", \\\"{x:1421,y:1027,t:1527030779594};\\\", \\\"{x:1425,y:1027,t:1527030779611};\\\", \\\"{x:1429,y:1027,t:1527030779627};\\\", \\\"{x:1436,y:1027,t:1527030779643};\\\", \\\"{x:1443,y:1027,t:1527030779661};\\\", \\\"{x:1448,y:1027,t:1527030779676};\\\", \\\"{x:1451,y:1027,t:1527030779693};\\\", \\\"{x:1454,y:1027,t:1527030779710};\\\", \\\"{x:1455,y:1027,t:1527030779734};\\\", \\\"{x:1457,y:1027,t:1527030779767};\\\", \\\"{x:1459,y:1027,t:1527030779783};\\\", \\\"{x:1459,y:1026,t:1527030779794};\\\", \\\"{x:1460,y:1025,t:1527030779810};\\\", \\\"{x:1462,y:1024,t:1527030779827};\\\", \\\"{x:1464,y:1023,t:1527030779843};\\\", \\\"{x:1465,y:1022,t:1527030779861};\\\", \\\"{x:1466,y:1022,t:1527030779877};\\\", \\\"{x:1467,y:1021,t:1527030779894};\\\", \\\"{x:1468,y:1020,t:1527030779910};\\\", \\\"{x:1469,y:1020,t:1527030779926};\\\", \\\"{x:1470,y:1019,t:1527030779944};\\\", \\\"{x:1471,y:1019,t:1527030779960};\\\", \\\"{x:1474,y:1017,t:1527030779978};\\\", \\\"{x:1476,y:1016,t:1527030779993};\\\", \\\"{x:1480,y:1014,t:1527030780010};\\\", \\\"{x:1484,y:1011,t:1527030780028};\\\", \\\"{x:1488,y:1008,t:1527030780044};\\\", \\\"{x:1493,y:1005,t:1527030780060};\\\", \\\"{x:1499,y:1002,t:1527030780077};\\\", \\\"{x:1503,y:1000,t:1527030780093};\\\", \\\"{x:1509,y:995,t:1527030780110};\\\", \\\"{x:1512,y:993,t:1527030780128};\\\", \\\"{x:1515,y:990,t:1527030780144};\\\", \\\"{x:1517,y:989,t:1527030780161};\\\", \\\"{x:1520,y:986,t:1527030780178};\\\", \\\"{x:1523,y:983,t:1527030780194};\\\", \\\"{x:1524,y:982,t:1527030780210};\\\", \\\"{x:1526,y:981,t:1527030780228};\\\", \\\"{x:1526,y:980,t:1527030780244};\\\", \\\"{x:1528,y:979,t:1527030780260};\\\", \\\"{x:1529,y:978,t:1527030780294};\\\", \\\"{x:1529,y:977,t:1527030780325};\\\", \\\"{x:1531,y:977,t:1527030780583};\\\", \\\"{x:1534,y:976,t:1527030780595};\\\", \\\"{x:1539,y:974,t:1527030780611};\\\", \\\"{x:1546,y:973,t:1527030780628};\\\", \\\"{x:1559,y:972,t:1527030780645};\\\", \\\"{x:1573,y:972,t:1527030780661};\\\", \\\"{x:1589,y:972,t:1527030780678};\\\", \\\"{x:1619,y:972,t:1527030780694};\\\", \\\"{x:1642,y:972,t:1527030780712};\\\", \\\"{x:1663,y:972,t:1527030780728};\\\", \\\"{x:1682,y:972,t:1527030780745};\\\", \\\"{x:1701,y:972,t:1527030780761};\\\", \\\"{x:1720,y:972,t:1527030780778};\\\", \\\"{x:1742,y:972,t:1527030780795};\\\", \\\"{x:1761,y:972,t:1527030780811};\\\", \\\"{x:1775,y:974,t:1527030780828};\\\", \\\"{x:1786,y:975,t:1527030780845};\\\", \\\"{x:1798,y:979,t:1527030780861};\\\", \\\"{x:1805,y:980,t:1527030780879};\\\", \\\"{x:1807,y:981,t:1527030780903};\\\", \\\"{x:1808,y:981,t:1527030780999};\\\", \\\"{x:1810,y:981,t:1527030781215};\\\", \\\"{x:1812,y:981,t:1527030781228};\\\", \\\"{x:1813,y:981,t:1527030781245};\\\", \\\"{x:1817,y:981,t:1527030781262};\\\", \\\"{x:1822,y:980,t:1527030781278};\\\", \\\"{x:1832,y:976,t:1527030781295};\\\", \\\"{x:1838,y:975,t:1527030781313};\\\", \\\"{x:1841,y:974,t:1527030781328};\\\", \\\"{x:1846,y:973,t:1527030781345};\\\", \\\"{x:1850,y:973,t:1527030781362};\\\", \\\"{x:1852,y:972,t:1527030781378};\\\", \\\"{x:1856,y:972,t:1527030781395};\\\", \\\"{x:1858,y:971,t:1527030781412};\\\", \\\"{x:1859,y:971,t:1527030781428};\\\", \\\"{x:1861,y:971,t:1527030781445};\\\", \\\"{x:1862,y:971,t:1527030781462};\\\", \\\"{x:1862,y:967,t:1527030781768};\\\", \\\"{x:1858,y:963,t:1527030781779};\\\", \\\"{x:1854,y:959,t:1527030781795};\\\", \\\"{x:1844,y:947,t:1527030781813};\\\", \\\"{x:1818,y:920,t:1527030781829};\\\", \\\"{x:1753,y:866,t:1527030781845};\\\", \\\"{x:1627,y:776,t:1527030781863};\\\", \\\"{x:1579,y:744,t:1527030781878};\\\", \\\"{x:1557,y:730,t:1527030781895};\\\", \\\"{x:1540,y:718,t:1527030781912};\\\", \\\"{x:1526,y:707,t:1527030781929};\\\", \\\"{x:1516,y:700,t:1527030781945};\\\", \\\"{x:1513,y:698,t:1527030781963};\\\", \\\"{x:1512,y:696,t:1527030781979};\\\", \\\"{x:1511,y:696,t:1527030781995};\\\", \\\"{x:1511,y:695,t:1527030782012};\\\", \\\"{x:1508,y:692,t:1527030782029};\\\", \\\"{x:1503,y:688,t:1527030782045};\\\", \\\"{x:1495,y:681,t:1527030782062};\\\", \\\"{x:1481,y:668,t:1527030782078};\\\", \\\"{x:1470,y:659,t:1527030782096};\\\", \\\"{x:1455,y:648,t:1527030782112};\\\", \\\"{x:1432,y:629,t:1527030782129};\\\", \\\"{x:1412,y:615,t:1527030782146};\\\", \\\"{x:1397,y:604,t:1527030782162};\\\", \\\"{x:1385,y:596,t:1527030782179};\\\", \\\"{x:1375,y:587,t:1527030782196};\\\", \\\"{x:1362,y:578,t:1527030782212};\\\", \\\"{x:1351,y:568,t:1527030782228};\\\", \\\"{x:1338,y:553,t:1527030782246};\\\", \\\"{x:1336,y:550,t:1527030782262};\\\", \\\"{x:1334,y:546,t:1527030782279};\\\", \\\"{x:1333,y:545,t:1527030782295};\\\", \\\"{x:1333,y:544,t:1527030782317};\\\", \\\"{x:1333,y:543,t:1527030782328};\\\", \\\"{x:1333,y:542,t:1527030782346};\\\", \\\"{x:1329,y:537,t:1527030782361};\\\", \\\"{x:1319,y:520,t:1527030782378};\\\", \\\"{x:1293,y:486,t:1527030782395};\\\", \\\"{x:1245,y:418,t:1527030782411};\\\", \\\"{x:1187,y:333,t:1527030782429};\\\", \\\"{x:1125,y:249,t:1527030782446};\\\", \\\"{x:1046,y:137,t:1527030782462};\\\", \\\"{x:1003,y:78,t:1527030782478};\\\", \\\"{x:975,y:40,t:1527030782496};\\\", \\\"{x:952,y:11,t:1527030782511};\\\", \\\"{x:941,y:0,t:1527030782529};\\\", \\\"{x:936,y:0,t:1527030782546};\\\", \\\"{x:935,y:0,t:1527030782561};\\\", \\\"{x:935,y:1,t:1527030782799};\\\", \\\"{x:935,y:8,t:1527030782813};\\\", \\\"{x:944,y:20,t:1527030782828};\\\", \\\"{x:954,y:41,t:1527030782845};\\\", \\\"{x:960,y:50,t:1527030782862};\\\", \\\"{x:966,y:61,t:1527030782878};\\\", \\\"{x:972,y:73,t:1527030782895};\\\", \\\"{x:976,y:83,t:1527030782912};\\\", \\\"{x:982,y:95,t:1527030782928};\\\", \\\"{x:990,y:111,t:1527030782946};\\\", \\\"{x:1006,y:137,t:1527030782962};\\\", \\\"{x:1024,y:183,t:1527030782979};\\\", \\\"{x:1062,y:274,t:1527030782995};\\\", \\\"{x:1106,y:386,t:1527030783013};\\\", \\\"{x:1136,y:489,t:1527030783028};\\\", \\\"{x:1188,y:635,t:1527030783046};\\\", \\\"{x:1234,y:726,t:1527030783062};\\\", \\\"{x:1286,y:819,t:1527030783079};\\\", \\\"{x:1353,y:909,t:1527030783096};\\\", \\\"{x:1419,y:988,t:1527030783112};\\\", \\\"{x:1482,y:1055,t:1527030783129};\\\", \\\"{x:1535,y:1103,t:1527030783145};\\\", \\\"{x:1584,y:1144,t:1527030783162};\\\", \\\"{x:1619,y:1163,t:1527030783179};\\\", \\\"{x:1636,y:1169,t:1527030783195};\\\", \\\"{x:1648,y:1173,t:1527030783213};\\\", \\\"{x:1653,y:1173,t:1527030783230};\\\", \\\"{x:1658,y:1174,t:1527030783245};\\\", \\\"{x:1660,y:1175,t:1527030783263};\\\", \\\"{x:1661,y:1175,t:1527030783280};\\\", \\\"{x:1662,y:1175,t:1527030783295};\\\", \\\"{x:1662,y:1176,t:1527030783334};\\\", \\\"{x:1663,y:1176,t:1527030783345};\\\", \\\"{x:1666,y:1175,t:1527030783363};\\\", \\\"{x:1672,y:1166,t:1527030783379};\\\", \\\"{x:1676,y:1160,t:1527030783396};\\\", \\\"{x:1679,y:1154,t:1527030783413};\\\", \\\"{x:1685,y:1141,t:1527030783430};\\\", \\\"{x:1690,y:1132,t:1527030783446};\\\", \\\"{x:1693,y:1123,t:1527030783462};\\\", \\\"{x:1694,y:1116,t:1527030783480};\\\", \\\"{x:1694,y:1111,t:1527030783495};\\\", \\\"{x:1694,y:1108,t:1527030783512};\\\", \\\"{x:1695,y:1106,t:1527030783529};\\\", \\\"{x:1695,y:1104,t:1527030783545};\\\", \\\"{x:1695,y:1103,t:1527030783563};\\\", \\\"{x:1696,y:1100,t:1527030783580};\\\", \\\"{x:1696,y:1098,t:1527030783596};\\\", \\\"{x:1696,y:1094,t:1527030783613};\\\", \\\"{x:1697,y:1089,t:1527030783630};\\\", \\\"{x:1697,y:1086,t:1527030783646};\\\", \\\"{x:1697,y:1084,t:1527030783662};\\\", \\\"{x:1697,y:1078,t:1527030783680};\\\", \\\"{x:1695,y:1070,t:1527030783695};\\\", \\\"{x:1686,y:1057,t:1527030783713};\\\", \\\"{x:1681,y:1052,t:1527030783730};\\\", \\\"{x:1678,y:1051,t:1527030783747};\\\", \\\"{x:1678,y:1050,t:1527030783763};\\\", \\\"{x:1677,y:1050,t:1527030783779};\\\", \\\"{x:1672,y:1047,t:1527030783796};\\\", \\\"{x:1660,y:1041,t:1527030783813};\\\", \\\"{x:1621,y:1024,t:1527030783830};\\\", \\\"{x:1595,y:1012,t:1527030783846};\\\", \\\"{x:1575,y:1005,t:1527030783862};\\\", \\\"{x:1561,y:1001,t:1527030783879};\\\", \\\"{x:1541,y:994,t:1527030783896};\\\", \\\"{x:1529,y:989,t:1527030783912};\\\", \\\"{x:1514,y:984,t:1527030783930};\\\", \\\"{x:1501,y:977,t:1527030783947};\\\", \\\"{x:1485,y:969,t:1527030783963};\\\", \\\"{x:1472,y:962,t:1527030783980};\\\", \\\"{x:1466,y:960,t:1527030783997};\\\", \\\"{x:1463,y:959,t:1527030784013};\\\", \\\"{x:1460,y:958,t:1527030784030};\\\", \\\"{x:1457,y:956,t:1527030784047};\\\", \\\"{x:1451,y:954,t:1527030784063};\\\", \\\"{x:1444,y:951,t:1527030784080};\\\", \\\"{x:1435,y:950,t:1527030784097};\\\", \\\"{x:1424,y:948,t:1527030784114};\\\", \\\"{x:1415,y:948,t:1527030784130};\\\", \\\"{x:1406,y:947,t:1527030784147};\\\", \\\"{x:1398,y:947,t:1527030784163};\\\", \\\"{x:1392,y:947,t:1527030784180};\\\", \\\"{x:1389,y:947,t:1527030784196};\\\", \\\"{x:1384,y:948,t:1527030784213};\\\", \\\"{x:1381,y:948,t:1527030784229};\\\", \\\"{x:1379,y:949,t:1527030784247};\\\", \\\"{x:1376,y:950,t:1527030784264};\\\", \\\"{x:1373,y:952,t:1527030784280};\\\", \\\"{x:1369,y:952,t:1527030784296};\\\", \\\"{x:1367,y:952,t:1527030784314};\\\", \\\"{x:1364,y:950,t:1527030784615};\\\", \\\"{x:1355,y:932,t:1527030784631};\\\", \\\"{x:1341,y:903,t:1527030784647};\\\", \\\"{x:1334,y:882,t:1527030784664};\\\", \\\"{x:1333,y:870,t:1527030784680};\\\", \\\"{x:1333,y:855,t:1527030784697};\\\", \\\"{x:1333,y:840,t:1527030784714};\\\", \\\"{x:1333,y:822,t:1527030784731};\\\", \\\"{x:1333,y:806,t:1527030784746};\\\", \\\"{x:1333,y:786,t:1527030784764};\\\", \\\"{x:1333,y:769,t:1527030784781};\\\", \\\"{x:1336,y:756,t:1527030784797};\\\", \\\"{x:1338,y:747,t:1527030784814};\\\", \\\"{x:1338,y:745,t:1527030784830};\\\", \\\"{x:1339,y:744,t:1527030784854};\\\", \\\"{x:1339,y:743,t:1527030785047};\\\", \\\"{x:1339,y:742,t:1527030785071};\\\", \\\"{x:1340,y:742,t:1527030785081};\\\", \\\"{x:1341,y:741,t:1527030785097};\\\", \\\"{x:1342,y:739,t:1527030785114};\\\", \\\"{x:1342,y:737,t:1527030785131};\\\", \\\"{x:1344,y:734,t:1527030785147};\\\", \\\"{x:1345,y:730,t:1527030785164};\\\", \\\"{x:1348,y:723,t:1527030785181};\\\", \\\"{x:1349,y:716,t:1527030785197};\\\", \\\"{x:1353,y:693,t:1527030785215};\\\", \\\"{x:1354,y:671,t:1527030785231};\\\", \\\"{x:1354,y:651,t:1527030785248};\\\", \\\"{x:1354,y:643,t:1527030785264};\\\", \\\"{x:1355,y:638,t:1527030785281};\\\", \\\"{x:1355,y:636,t:1527030785299};\\\", \\\"{x:1355,y:634,t:1527030785315};\\\", \\\"{x:1355,y:633,t:1527030785331};\\\", \\\"{x:1355,y:631,t:1527030785348};\\\", \\\"{x:1355,y:630,t:1527030785366};\\\", \\\"{x:1355,y:628,t:1527030785390};\\\", \\\"{x:1355,y:627,t:1527030785406};\\\", \\\"{x:1354,y:625,t:1527030785414};\\\", \\\"{x:1347,y:620,t:1527030785430};\\\", \\\"{x:1334,y:615,t:1527030785447};\\\", \\\"{x:1318,y:609,t:1527030785463};\\\", \\\"{x:1297,y:601,t:1527030785480};\\\", \\\"{x:1272,y:592,t:1527030785497};\\\", \\\"{x:1226,y:578,t:1527030785514};\\\", \\\"{x:1163,y:561,t:1527030785531};\\\", \\\"{x:1075,y:540,t:1527030785547};\\\", \\\"{x:992,y:519,t:1527030785564};\\\", \\\"{x:921,y:502,t:1527030785581};\\\", \\\"{x:857,y:485,t:1527030785598};\\\", \\\"{x:841,y:482,t:1527030785614};\\\", \\\"{x:836,y:482,t:1527030785626};\\\", \\\"{x:828,y:481,t:1527030785642};\\\", \\\"{x:825,y:481,t:1527030785659};\\\", \\\"{x:824,y:482,t:1527030785678};\\\", \\\"{x:827,y:486,t:1527030785692};\\\", \\\"{x:854,y:493,t:1527030785710};\\\", \\\"{x:855,y:493,t:1527030785725};\\\", \\\"{x:850,y:494,t:1527030785990};\\\", \\\"{x:842,y:496,t:1527030785999};\\\", \\\"{x:831,y:497,t:1527030786015};\\\", \\\"{x:806,y:506,t:1527030786033};\\\", \\\"{x:776,y:520,t:1527030786048};\\\", \\\"{x:754,y:535,t:1527030786066};\\\", \\\"{x:734,y:550,t:1527030786083};\\\", \\\"{x:709,y:567,t:1527030786099};\\\", \\\"{x:683,y:576,t:1527030786115};\\\", \\\"{x:656,y:582,t:1527030786133};\\\", \\\"{x:634,y:584,t:1527030786149};\\\", \\\"{x:619,y:584,t:1527030786166};\\\", \\\"{x:616,y:583,t:1527030786182};\\\", \\\"{x:614,y:583,t:1527030786198};\\\", \\\"{x:611,y:581,t:1527030786215};\\\", \\\"{x:608,y:580,t:1527030786232};\\\", \\\"{x:605,y:579,t:1527030786249};\\\", \\\"{x:602,y:577,t:1527030786265};\\\", \\\"{x:599,y:576,t:1527030786283};\\\", \\\"{x:599,y:575,t:1527030786326};\\\", \\\"{x:600,y:571,t:1527030786334};\\\", \\\"{x:601,y:569,t:1527030786349};\\\", \\\"{x:609,y:558,t:1527030786366};\\\", \\\"{x:611,y:553,t:1527030786383};\\\", \\\"{x:616,y:546,t:1527030786398};\\\", \\\"{x:616,y:542,t:1527030786415};\\\", \\\"{x:616,y:538,t:1527030786432};\\\", \\\"{x:616,y:534,t:1527030786450};\\\", \\\"{x:599,y:526,t:1527030786466};\\\", \\\"{x:569,y:516,t:1527030786483};\\\", \\\"{x:510,y:506,t:1527030786500};\\\", \\\"{x:451,y:506,t:1527030786516};\\\", \\\"{x:390,y:506,t:1527030786533};\\\", \\\"{x:330,y:506,t:1527030786550};\\\", \\\"{x:310,y:506,t:1527030786565};\\\", \\\"{x:306,y:506,t:1527030786582};\\\", \\\"{x:304,y:508,t:1527030786702};\\\", \\\"{x:304,y:516,t:1527030786716};\\\", \\\"{x:304,y:541,t:1527030786735};\\\", \\\"{x:304,y:571,t:1527030786750};\\\", \\\"{x:305,y:578,t:1527030786767};\\\", \\\"{x:311,y:581,t:1527030786783};\\\", \\\"{x:327,y:583,t:1527030786799};\\\", \\\"{x:367,y:587,t:1527030786817};\\\", \\\"{x:420,y:589,t:1527030786833};\\\", \\\"{x:486,y:586,t:1527030786849};\\\", \\\"{x:554,y:572,t:1527030786867};\\\", \\\"{x:616,y:550,t:1527030786884};\\\", \\\"{x:675,y:533,t:1527030786899};\\\", \\\"{x:722,y:519,t:1527030786918};\\\", \\\"{x:755,y:511,t:1527030786933};\\\", \\\"{x:771,y:508,t:1527030786949};\\\", \\\"{x:772,y:508,t:1527030787070};\\\", \\\"{x:775,y:508,t:1527030787082};\\\", \\\"{x:780,y:506,t:1527030787099};\\\", \\\"{x:785,y:504,t:1527030787116};\\\", \\\"{x:788,y:503,t:1527030787319};\\\", \\\"{x:791,y:502,t:1527030787333};\\\", \\\"{x:800,y:498,t:1527030787350};\\\", \\\"{x:804,y:496,t:1527030787366};\\\", \\\"{x:804,y:495,t:1527030787384};\\\", \\\"{x:803,y:496,t:1527030787734};\\\", \\\"{x:801,y:496,t:1527030787750};\\\", \\\"{x:800,y:497,t:1527030787767};\\\", \\\"{x:800,y:499,t:1527030787784};\\\", \\\"{x:803,y:508,t:1527030787800};\\\", \\\"{x:812,y:518,t:1527030787818};\\\", \\\"{x:816,y:522,t:1527030787834};\\\", \\\"{x:819,y:522,t:1527030787850};\\\", \\\"{x:820,y:522,t:1527030787877};\\\", \\\"{x:821,y:522,t:1527030787886};\\\", \\\"{x:822,y:522,t:1527030787900};\\\", \\\"{x:823,y:522,t:1527030787917};\\\", \\\"{x:824,y:522,t:1527030787933};\\\", \\\"{x:825,y:522,t:1527030787950};\\\", \\\"{x:826,y:522,t:1527030787981};\\\", \\\"{x:827,y:522,t:1527030788119};\\\", \\\"{x:828,y:521,t:1527030788133};\\\", \\\"{x:830,y:509,t:1527030788151};\\\", \\\"{x:832,y:500,t:1527030788165};\\\", \\\"{x:833,y:493,t:1527030788183};\\\", \\\"{x:836,y:490,t:1527030788200};\\\", \\\"{x:836,y:489,t:1527030788558};\\\", \\\"{x:832,y:489,t:1527030788567};\\\", \\\"{x:816,y:497,t:1527030788584};\\\", \\\"{x:789,y:506,t:1527030788601};\\\", \\\"{x:743,y:521,t:1527030788618};\\\", \\\"{x:684,y:533,t:1527030788634};\\\", \\\"{x:620,y:541,t:1527030788651};\\\", \\\"{x:544,y:554,t:1527030788668};\\\", \\\"{x:475,y:562,t:1527030788685};\\\", \\\"{x:419,y:570,t:1527030788701};\\\", \\\"{x:392,y:573,t:1527030788717};\\\", \\\"{x:391,y:573,t:1527030788734};\\\", \\\"{x:390,y:574,t:1527030788773};\\\", \\\"{x:389,y:575,t:1527030788789};\\\", \\\"{x:389,y:576,t:1527030788800};\\\", \\\"{x:388,y:578,t:1527030788817};\\\", \\\"{x:387,y:582,t:1527030788835};\\\", \\\"{x:387,y:584,t:1527030788851};\\\", \\\"{x:385,y:586,t:1527030788868};\\\", \\\"{x:383,y:588,t:1527030788885};\\\", \\\"{x:380,y:588,t:1527030788900};\\\", \\\"{x:372,y:589,t:1527030788919};\\\", \\\"{x:369,y:589,t:1527030788935};\\\", \\\"{x:365,y:590,t:1527030788951};\\\", \\\"{x:360,y:590,t:1527030788967};\\\", \\\"{x:353,y:590,t:1527030788985};\\\", \\\"{x:339,y:590,t:1527030789002};\\\", \\\"{x:317,y:590,t:1527030789018};\\\", \\\"{x:290,y:587,t:1527030789035};\\\", \\\"{x:259,y:584,t:1527030789052};\\\", \\\"{x:236,y:581,t:1527030789068};\\\", \\\"{x:219,y:581,t:1527030789085};\\\", \\\"{x:204,y:581,t:1527030789101};\\\", \\\"{x:200,y:583,t:1527030789118};\\\", \\\"{x:197,y:585,t:1527030789135};\\\", \\\"{x:194,y:591,t:1527030789152};\\\", \\\"{x:194,y:600,t:1527030789168};\\\", \\\"{x:194,y:611,t:1527030789186};\\\", \\\"{x:194,y:625,t:1527030789202};\\\", \\\"{x:194,y:632,t:1527030789219};\\\", \\\"{x:194,y:634,t:1527030789235};\\\", \\\"{x:194,y:630,t:1527030789280};\\\", \\\"{x:194,y:622,t:1527030789286};\\\", \\\"{x:189,y:597,t:1527030789301};\\\", \\\"{x:186,y:576,t:1527030789318};\\\", \\\"{x:183,y:563,t:1527030789335};\\\", \\\"{x:182,y:557,t:1527030789352};\\\", \\\"{x:182,y:553,t:1527030789370};\\\", \\\"{x:182,y:550,t:1527030789385};\\\", \\\"{x:182,y:547,t:1527030789402};\\\", \\\"{x:182,y:546,t:1527030789418};\\\", \\\"{x:182,y:544,t:1527030789437};\\\", \\\"{x:182,y:543,t:1527030789453};\\\", \\\"{x:181,y:543,t:1527030789469};\\\", \\\"{x:180,y:542,t:1527030789484};\\\", \\\"{x:180,y:541,t:1527030789502};\\\", \\\"{x:180,y:542,t:1527030789967};\\\", \\\"{x:188,y:546,t:1527030789974};\\\", \\\"{x:200,y:555,t:1527030789986};\\\", \\\"{x:235,y:590,t:1527030790002};\\\", \\\"{x:292,y:633,t:1527030790019};\\\", \\\"{x:340,y:667,t:1527030790037};\\\", \\\"{x:383,y:699,t:1527030790052};\\\", \\\"{x:411,y:726,t:1527030790069};\\\", \\\"{x:436,y:753,t:1527030790085};\\\", \\\"{x:445,y:769,t:1527030790102};\\\", \\\"{x:445,y:774,t:1527030790118};\\\", \\\"{x:445,y:775,t:1527030790136};\\\", \\\"{x:445,y:778,t:1527030790153};\\\", \\\"{x:445,y:779,t:1527030790169};\\\", \\\"{x:445,y:780,t:1527030790185};\\\", \\\"{x:445,y:782,t:1527030790204};\\\", \\\"{x:444,y:784,t:1527030790218};\\\", \\\"{x:443,y:788,t:1527030790236};\\\", \\\"{x:440,y:793,t:1527030790253};\\\", \\\"{x:436,y:797,t:1527030790269};\\\", \\\"{x:427,y:811,t:1527030790285};\\\", \\\"{x:423,y:821,t:1527030790303};\\\", \\\"{x:423,y:826,t:1527030790320};\\\", \\\"{x:421,y:829,t:1527030790336};\\\", \\\"{x:421,y:831,t:1527030790354};\\\", \\\"{x:420,y:832,t:1527030790370};\\\", \\\"{x:420,y:833,t:1527030790439};\\\", \\\"{x:420,y:834,t:1527030790494};\\\", \\\"{x:423,y:834,t:1527030790509};\\\", \\\"{x:427,y:830,t:1527030790520};\\\", \\\"{x:435,y:819,t:1527030790537};\\\", \\\"{x:446,y:803,t:1527030790552};\\\", \\\"{x:461,y:778,t:1527030790570};\\\", \\\"{x:474,y:754,t:1527030790588};\\\", \\\"{x:478,y:738,t:1527030790604};\\\", \\\"{x:480,y:734,t:1527030790619};\\\", \\\"{x:482,y:731,t:1527030790635};\\\" ] }, { \\\"rt\\\": 10780, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 716850, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:731,t:1527030793342};\\\", \\\"{x:503,y:736,t:1527030793360};\\\", \\\"{x:523,y:742,t:1527030793373};\\\", \\\"{x:555,y:748,t:1527030793391};\\\", \\\"{x:611,y:758,t:1527030793407};\\\", \\\"{x:678,y:767,t:1527030793424};\\\", \\\"{x:747,y:775,t:1527030793438};\\\", \\\"{x:814,y:775,t:1527030793455};\\\", \\\"{x:870,y:775,t:1527030793470};\\\", \\\"{x:907,y:775,t:1527030793488};\\\", \\\"{x:931,y:775,t:1527030793505};\\\", \\\"{x:940,y:775,t:1527030793521};\\\", \\\"{x:941,y:775,t:1527030793538};\\\", \\\"{x:938,y:772,t:1527030798431};\\\", \\\"{x:919,y:764,t:1527030798441};\\\", \\\"{x:837,y:736,t:1527030798458};\\\", \\\"{x:730,y:688,t:1527030798475};\\\", \\\"{x:639,y:629,t:1527030798492};\\\", \\\"{x:594,y:597,t:1527030798509};\\\", \\\"{x:570,y:581,t:1527030798525};\\\", \\\"{x:567,y:576,t:1527030798557};\\\", \\\"{x:566,y:575,t:1527030798662};\\\", \\\"{x:566,y:574,t:1527030798685};\\\", \\\"{x:566,y:573,t:1527030798693};\\\", \\\"{x:566,y:572,t:1527030798750};\\\", \\\"{x:567,y:572,t:1527030798759};\\\", \\\"{x:576,y:575,t:1527030798775};\\\", \\\"{x:584,y:578,t:1527030798792};\\\", \\\"{x:592,y:582,t:1527030798810};\\\", \\\"{x:596,y:584,t:1527030798825};\\\", \\\"{x:600,y:585,t:1527030798843};\\\", \\\"{x:603,y:587,t:1527030798859};\\\", \\\"{x:608,y:589,t:1527030798875};\\\", \\\"{x:612,y:590,t:1527030798892};\\\", \\\"{x:618,y:593,t:1527030798909};\\\", \\\"{x:621,y:594,t:1527030798925};\\\", \\\"{x:621,y:595,t:1527030798942};\\\", \\\"{x:617,y:595,t:1527030799021};\\\", \\\"{x:613,y:595,t:1527030799029};\\\", \\\"{x:610,y:593,t:1527030799043};\\\", \\\"{x:608,y:592,t:1527030799059};\\\", \\\"{x:607,y:591,t:1527030799118};\\\", \\\"{x:607,y:589,t:1527030799127};\\\", \\\"{x:607,y:584,t:1527030799143};\\\", \\\"{x:607,y:579,t:1527030799159};\\\", \\\"{x:606,y:573,t:1527030799176};\\\", \\\"{x:602,y:569,t:1527030799193};\\\", \\\"{x:600,y:566,t:1527030799209};\\\", \\\"{x:596,y:563,t:1527030799227};\\\", \\\"{x:594,y:562,t:1527030799244};\\\", \\\"{x:590,y:560,t:1527030799259};\\\", \\\"{x:584,y:558,t:1527030799276};\\\", \\\"{x:571,y:554,t:1527030799294};\\\", \\\"{x:564,y:552,t:1527030799309};\\\", \\\"{x:551,y:551,t:1527030799326};\\\", \\\"{x:548,y:551,t:1527030799344};\\\", \\\"{x:542,y:551,t:1527030799359};\\\", \\\"{x:533,y:551,t:1527030799376};\\\", \\\"{x:514,y:551,t:1527030799394};\\\", \\\"{x:486,y:552,t:1527030799411};\\\", \\\"{x:454,y:556,t:1527030799427};\\\", \\\"{x:412,y:561,t:1527030799443};\\\", \\\"{x:375,y:568,t:1527030799461};\\\", \\\"{x:347,y:573,t:1527030799476};\\\", \\\"{x:327,y:579,t:1527030799493};\\\", \\\"{x:321,y:582,t:1527030799509};\\\", \\\"{x:318,y:584,t:1527030799526};\\\", \\\"{x:316,y:587,t:1527030799543};\\\", \\\"{x:315,y:589,t:1527030799560};\\\", \\\"{x:314,y:596,t:1527030799578};\\\", \\\"{x:312,y:604,t:1527030799593};\\\", \\\"{x:311,y:612,t:1527030799609};\\\", \\\"{x:307,y:618,t:1527030799626};\\\", \\\"{x:307,y:622,t:1527030799643};\\\", \\\"{x:307,y:624,t:1527030799659};\\\", \\\"{x:307,y:625,t:1527030799693};\\\", \\\"{x:310,y:626,t:1527030799709};\\\", \\\"{x:313,y:627,t:1527030799725};\\\", \\\"{x:319,y:627,t:1527030799742};\\\", \\\"{x:325,y:627,t:1527030799759};\\\", \\\"{x:332,y:622,t:1527030799777};\\\", \\\"{x:338,y:619,t:1527030799792};\\\", \\\"{x:342,y:613,t:1527030799809};\\\", \\\"{x:344,y:607,t:1527030799826};\\\", \\\"{x:345,y:600,t:1527030799844};\\\", \\\"{x:345,y:592,t:1527030799860};\\\", \\\"{x:345,y:583,t:1527030799878};\\\", \\\"{x:343,y:574,t:1527030799893};\\\", \\\"{x:344,y:563,t:1527030799909};\\\", \\\"{x:344,y:552,t:1527030799928};\\\", \\\"{x:348,y:543,t:1527030799943};\\\", \\\"{x:353,y:536,t:1527030799960};\\\", \\\"{x:356,y:534,t:1527030799977};\\\", \\\"{x:361,y:532,t:1527030799993};\\\", \\\"{x:366,y:530,t:1527030800010};\\\", \\\"{x:385,y:529,t:1527030800027};\\\", \\\"{x:415,y:529,t:1527030800043};\\\", \\\"{x:444,y:532,t:1527030800061};\\\", \\\"{x:470,y:532,t:1527030800077};\\\", \\\"{x:480,y:532,t:1527030800094};\\\", \\\"{x:486,y:532,t:1527030800110};\\\", \\\"{x:487,y:532,t:1527030800127};\\\", \\\"{x:488,y:532,t:1527030800149};\\\", \\\"{x:489,y:531,t:1527030800160};\\\", \\\"{x:494,y:531,t:1527030800179};\\\", \\\"{x:509,y:531,t:1527030800195};\\\", \\\"{x:533,y:531,t:1527030800210};\\\", \\\"{x:552,y:531,t:1527030800227};\\\", \\\"{x:565,y:531,t:1527030800243};\\\", \\\"{x:572,y:531,t:1527030800260};\\\", \\\"{x:579,y:531,t:1527030800277};\\\", \\\"{x:581,y:531,t:1527030800293};\\\", \\\"{x:584,y:531,t:1527030800310};\\\", \\\"{x:596,y:532,t:1527030800327};\\\", \\\"{x:606,y:536,t:1527030800345};\\\", \\\"{x:618,y:539,t:1527030800360};\\\", \\\"{x:638,y:547,t:1527030800378};\\\", \\\"{x:661,y:552,t:1527030800394};\\\", \\\"{x:685,y:559,t:1527030800411};\\\", \\\"{x:704,y:561,t:1527030800427};\\\", \\\"{x:720,y:563,t:1527030800445};\\\", \\\"{x:731,y:564,t:1527030800461};\\\", \\\"{x:745,y:564,t:1527030800477};\\\", \\\"{x:755,y:564,t:1527030800493};\\\", \\\"{x:772,y:567,t:1527030800510};\\\", \\\"{x:790,y:570,t:1527030800527};\\\", \\\"{x:812,y:572,t:1527030800544};\\\", \\\"{x:830,y:574,t:1527030800561};\\\", \\\"{x:840,y:575,t:1527030800578};\\\", \\\"{x:841,y:575,t:1527030800594};\\\", \\\"{x:842,y:575,t:1527030800610};\\\", \\\"{x:838,y:574,t:1527030800629};\\\", \\\"{x:827,y:570,t:1527030800644};\\\", \\\"{x:794,y:555,t:1527030800662};\\\", \\\"{x:752,y:540,t:1527030800677};\\\", \\\"{x:735,y:537,t:1527030800693};\\\", \\\"{x:715,y:537,t:1527030800711};\\\", \\\"{x:683,y:545,t:1527030800727};\\\", \\\"{x:630,y:561,t:1527030800744};\\\", \\\"{x:561,y:578,t:1527030800760};\\\", \\\"{x:494,y:598,t:1527030800778};\\\", \\\"{x:424,y:608,t:1527030800794};\\\", \\\"{x:368,y:616,t:1527030800810};\\\", \\\"{x:326,y:628,t:1527030800827};\\\", \\\"{x:303,y:633,t:1527030800845};\\\", \\\"{x:288,y:637,t:1527030800862};\\\", \\\"{x:287,y:637,t:1527030800877};\\\", \\\"{x:286,y:637,t:1527030800901};\\\", \\\"{x:284,y:637,t:1527030800910};\\\", \\\"{x:279,y:637,t:1527030800927};\\\", \\\"{x:269,y:637,t:1527030800944};\\\", \\\"{x:251,y:639,t:1527030800961};\\\", \\\"{x:237,y:642,t:1527030800977};\\\", \\\"{x:229,y:643,t:1527030800994};\\\", \\\"{x:223,y:643,t:1527030801011};\\\", \\\"{x:220,y:643,t:1527030801027};\\\", \\\"{x:219,y:643,t:1527030801046};\\\", \\\"{x:215,y:638,t:1527030801062};\\\", \\\"{x:206,y:627,t:1527030801079};\\\", \\\"{x:195,y:613,t:1527030801094};\\\", \\\"{x:190,y:603,t:1527030801111};\\\", \\\"{x:189,y:598,t:1527030801127};\\\", \\\"{x:189,y:593,t:1527030801144};\\\", \\\"{x:189,y:588,t:1527030801161};\\\", \\\"{x:189,y:584,t:1527030801178};\\\", \\\"{x:189,y:581,t:1527030801194};\\\", \\\"{x:189,y:577,t:1527030801211};\\\", \\\"{x:189,y:574,t:1527030801228};\\\", \\\"{x:189,y:571,t:1527030801244};\\\", \\\"{x:189,y:570,t:1527030801261};\\\", \\\"{x:189,y:569,t:1527030801285};\\\", \\\"{x:189,y:568,t:1527030801317};\\\", \\\"{x:189,y:567,t:1527030801333};\\\", \\\"{x:188,y:565,t:1527030801345};\\\", \\\"{x:188,y:564,t:1527030801361};\\\", \\\"{x:188,y:561,t:1527030801378};\\\", \\\"{x:187,y:558,t:1527030801394};\\\", \\\"{x:186,y:554,t:1527030801413};\\\", \\\"{x:186,y:552,t:1527030801428};\\\", \\\"{x:185,y:551,t:1527030801444};\\\", \\\"{x:185,y:550,t:1527030801462};\\\", \\\"{x:185,y:548,t:1527030801478};\\\", \\\"{x:188,y:550,t:1527030801861};\\\", \\\"{x:194,y:557,t:1527030801879};\\\", \\\"{x:198,y:564,t:1527030801896};\\\", \\\"{x:202,y:570,t:1527030801911};\\\", \\\"{x:207,y:575,t:1527030801928};\\\", \\\"{x:211,y:581,t:1527030801946};\\\", \\\"{x:218,y:586,t:1527030801961};\\\", \\\"{x:225,y:591,t:1527030801978};\\\", \\\"{x:229,y:595,t:1527030801996};\\\", \\\"{x:231,y:597,t:1527030802011};\\\", \\\"{x:232,y:599,t:1527030802028};\\\", \\\"{x:234,y:603,t:1527030802046};\\\", \\\"{x:234,y:607,t:1527030802061};\\\", \\\"{x:236,y:609,t:1527030802079};\\\", \\\"{x:237,y:613,t:1527030802095};\\\", \\\"{x:238,y:616,t:1527030802113};\\\", \\\"{x:240,y:619,t:1527030802128};\\\", \\\"{x:242,y:625,t:1527030802146};\\\", \\\"{x:247,y:635,t:1527030802163};\\\", \\\"{x:260,y:654,t:1527030802179};\\\", \\\"{x:276,y:672,t:1527030802196};\\\", \\\"{x:295,y:692,t:1527030802212};\\\", \\\"{x:317,y:709,t:1527030802228};\\\", \\\"{x:346,y:728,t:1527030802245};\\\", \\\"{x:362,y:734,t:1527030802261};\\\", \\\"{x:376,y:738,t:1527030802278};\\\", \\\"{x:391,y:744,t:1527030802295};\\\", \\\"{x:409,y:749,t:1527030802312};\\\", \\\"{x:426,y:753,t:1527030802329};\\\", \\\"{x:440,y:754,t:1527030802345};\\\", \\\"{x:453,y:755,t:1527030802362};\\\", \\\"{x:463,y:758,t:1527030802378};\\\", \\\"{x:467,y:758,t:1527030802396};\\\", \\\"{x:469,y:758,t:1527030802412};\\\", \\\"{x:470,y:758,t:1527030802429};\\\", \\\"{x:472,y:757,t:1527030802446};\\\", \\\"{x:473,y:755,t:1527030802462};\\\", \\\"{x:474,y:755,t:1527030802479};\\\", \\\"{x:475,y:753,t:1527030802496};\\\", \\\"{x:476,y:752,t:1527030802513};\\\", \\\"{x:477,y:752,t:1527030802529};\\\", \\\"{x:477,y:751,t:1527030802545};\\\", \\\"{x:477,y:750,t:1527030802563};\\\", \\\"{x:478,y:749,t:1527030802580};\\\", \\\"{x:479,y:748,t:1527030802596};\\\", \\\"{x:480,y:746,t:1527030802613};\\\", \\\"{x:481,y:740,t:1527030802630};\\\", \\\"{x:483,y:736,t:1527030802646};\\\", \\\"{x:484,y:735,t:1527030802662};\\\", \\\"{x:484,y:732,t:1527030802679};\\\", \\\"{x:484,y:731,t:1527030802702};\\\", \\\"{x:484,y:730,t:1527030802713};\\\", \\\"{x:484,y:729,t:1527030802729};\\\", \\\"{x:485,y:727,t:1527030802747};\\\", \\\"{x:485,y:726,t:1527030802763};\\\" ] }, { \\\"rt\\\": 50459, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 768584, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -04 PM-B -Z -Z -N -Z -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:720,t:1527030815277};\\\", \\\"{x:523,y:711,t:1527030815293};\\\", \\\"{x:680,y:687,t:1527030815308};\\\", \\\"{x:742,y:681,t:1527030815323};\\\", \\\"{x:880,y:666,t:1527030815336};\\\", \\\"{x:1010,y:664,t:1527030815351};\\\", \\\"{x:1134,y:656,t:1527030815369};\\\", \\\"{x:1239,y:654,t:1527030815386};\\\", \\\"{x:1331,y:654,t:1527030815403};\\\", \\\"{x:1388,y:662,t:1527030815418};\\\", \\\"{x:1409,y:669,t:1527030815435};\\\", \\\"{x:1411,y:670,t:1527030815453};\\\", \\\"{x:1411,y:671,t:1527030815469};\\\", \\\"{x:1405,y:675,t:1527030815486};\\\", \\\"{x:1389,y:679,t:1527030815502};\\\", \\\"{x:1372,y:688,t:1527030815519};\\\", \\\"{x:1356,y:698,t:1527030815536};\\\", \\\"{x:1342,y:712,t:1527030815553};\\\", \\\"{x:1333,y:727,t:1527030815569};\\\", \\\"{x:1329,y:749,t:1527030815586};\\\", \\\"{x:1329,y:771,t:1527030815603};\\\", \\\"{x:1336,y:791,t:1527030815618};\\\", \\\"{x:1351,y:804,t:1527030815636};\\\", \\\"{x:1383,y:814,t:1527030815652};\\\", \\\"{x:1414,y:814,t:1527030815669};\\\", \\\"{x:1458,y:812,t:1527030815685};\\\", \\\"{x:1504,y:795,t:1527030815703};\\\", \\\"{x:1552,y:772,t:1527030815719};\\\", \\\"{x:1589,y:738,t:1527030815735};\\\", \\\"{x:1610,y:686,t:1527030815753};\\\", \\\"{x:1615,y:631,t:1527030815769};\\\", \\\"{x:1608,y:575,t:1527030815786};\\\", \\\"{x:1594,y:525,t:1527030815803};\\\", \\\"{x:1574,y:484,t:1527030815819};\\\", \\\"{x:1549,y:460,t:1527030815836};\\\", \\\"{x:1516,y:442,t:1527030815852};\\\", \\\"{x:1500,y:430,t:1527030815870};\\\", \\\"{x:1488,y:418,t:1527030815886};\\\", \\\"{x:1480,y:410,t:1527030815903};\\\", \\\"{x:1476,y:406,t:1527030815919};\\\", \\\"{x:1475,y:403,t:1527030815935};\\\", \\\"{x:1474,y:403,t:1527030815981};\\\", \\\"{x:1473,y:402,t:1527030816004};\\\", \\\"{x:1471,y:402,t:1527030816019};\\\", \\\"{x:1465,y:402,t:1527030816036};\\\", \\\"{x:1425,y:437,t:1527030816052};\\\", \\\"{x:1372,y:495,t:1527030816071};\\\", \\\"{x:1330,y:550,t:1527030816087};\\\", \\\"{x:1299,y:599,t:1527030816102};\\\", \\\"{x:1283,y:637,t:1527030816120};\\\", \\\"{x:1278,y:669,t:1527030816136};\\\", \\\"{x:1278,y:702,t:1527030816152};\\\", \\\"{x:1298,y:757,t:1527030816170};\\\", \\\"{x:1329,y:809,t:1527030816186};\\\", \\\"{x:1367,y:865,t:1527030816202};\\\", \\\"{x:1401,y:917,t:1527030816220};\\\", \\\"{x:1430,y:957,t:1527030816235};\\\", \\\"{x:1463,y:991,t:1527030816253};\\\", \\\"{x:1483,y:1001,t:1527030816269};\\\", \\\"{x:1506,y:1006,t:1527030816286};\\\", \\\"{x:1532,y:1007,t:1527030816303};\\\", \\\"{x:1553,y:1007,t:1527030816320};\\\", \\\"{x:1572,y:1007,t:1527030816335};\\\", \\\"{x:1583,y:1004,t:1527030816353};\\\", \\\"{x:1588,y:998,t:1527030816370};\\\", \\\"{x:1593,y:987,t:1527030816386};\\\", \\\"{x:1601,y:970,t:1527030816403};\\\", \\\"{x:1603,y:944,t:1527030816420};\\\", \\\"{x:1603,y:897,t:1527030816436};\\\", \\\"{x:1583,y:857,t:1527030816452};\\\", \\\"{x:1565,y:823,t:1527030816469};\\\", \\\"{x:1554,y:797,t:1527030816486};\\\", \\\"{x:1544,y:772,t:1527030816503};\\\", \\\"{x:1529,y:744,t:1527030816520};\\\", \\\"{x:1514,y:719,t:1527030816536};\\\", \\\"{x:1499,y:682,t:1527030816553};\\\", \\\"{x:1473,y:603,t:1527030816570};\\\", \\\"{x:1442,y:493,t:1527030816586};\\\", \\\"{x:1415,y:377,t:1527030816603};\\\", \\\"{x:1404,y:281,t:1527030816620};\\\", \\\"{x:1404,y:229,t:1527030816636};\\\", \\\"{x:1406,y:215,t:1527030816653};\\\", \\\"{x:1407,y:208,t:1527030816670};\\\", \\\"{x:1410,y:208,t:1527030816846};\\\", \\\"{x:1414,y:215,t:1527030816853};\\\", \\\"{x:1417,y:230,t:1527030816871};\\\", \\\"{x:1420,y:242,t:1527030816888};\\\", \\\"{x:1423,y:250,t:1527030816903};\\\", \\\"{x:1423,y:256,t:1527030816919};\\\", \\\"{x:1424,y:260,t:1527030816937};\\\", \\\"{x:1424,y:263,t:1527030816953};\\\", \\\"{x:1425,y:265,t:1527030816970};\\\", \\\"{x:1427,y:271,t:1527030816987};\\\", \\\"{x:1428,y:277,t:1527030817004};\\\", \\\"{x:1434,y:294,t:1527030817019};\\\", \\\"{x:1445,y:344,t:1527030817037};\\\", \\\"{x:1451,y:374,t:1527030817053};\\\", \\\"{x:1454,y:396,t:1527030817070};\\\", \\\"{x:1454,y:411,t:1527030817087};\\\", \\\"{x:1457,y:421,t:1527030817102};\\\", \\\"{x:1462,y:431,t:1527030817120};\\\", \\\"{x:1467,y:436,t:1527030817136};\\\", \\\"{x:1468,y:436,t:1527030817153};\\\", \\\"{x:1469,y:436,t:1527030817170};\\\", \\\"{x:1471,y:436,t:1527030817187};\\\", \\\"{x:1475,y:432,t:1527030817204};\\\", \\\"{x:1478,y:415,t:1527030817220};\\\", \\\"{x:1480,y:394,t:1527030817237};\\\", \\\"{x:1482,y:366,t:1527030817253};\\\", \\\"{x:1483,y:340,t:1527030817269};\\\", \\\"{x:1483,y:323,t:1527030817286};\\\", \\\"{x:1483,y:316,t:1527030817304};\\\", \\\"{x:1483,y:313,t:1527030817319};\\\", \\\"{x:1480,y:317,t:1527030817397};\\\", \\\"{x:1474,y:331,t:1527030817405};\\\", \\\"{x:1461,y:376,t:1527030817421};\\\", \\\"{x:1442,y:435,t:1527030817437};\\\", \\\"{x:1421,y:518,t:1527030817455};\\\", \\\"{x:1395,y:594,t:1527030817470};\\\", \\\"{x:1376,y:666,t:1527030817487};\\\", \\\"{x:1359,y:722,t:1527030817505};\\\", \\\"{x:1348,y:761,t:1527030817522};\\\", \\\"{x:1337,y:785,t:1527030817537};\\\", \\\"{x:1330,y:801,t:1527030817554};\\\", \\\"{x:1321,y:809,t:1527030817570};\\\", \\\"{x:1311,y:813,t:1527030817587};\\\", \\\"{x:1301,y:813,t:1527030817604};\\\", \\\"{x:1299,y:813,t:1527030817620};\\\", \\\"{x:1297,y:813,t:1527030817637};\\\", \\\"{x:1296,y:811,t:1527030817668};\\\", \\\"{x:1296,y:805,t:1527030817676};\\\", \\\"{x:1293,y:799,t:1527030817687};\\\", \\\"{x:1290,y:787,t:1527030817704};\\\", \\\"{x:1286,y:766,t:1527030817720};\\\", \\\"{x:1281,y:744,t:1527030817737};\\\", \\\"{x:1279,y:726,t:1527030817754};\\\", \\\"{x:1277,y:716,t:1527030817770};\\\", \\\"{x:1277,y:712,t:1527030817787};\\\", \\\"{x:1279,y:706,t:1527030817804};\\\", \\\"{x:1284,y:702,t:1527030817820};\\\", \\\"{x:1289,y:702,t:1527030817837};\\\", \\\"{x:1300,y:702,t:1527030817854};\\\", \\\"{x:1321,y:705,t:1527030817870};\\\", \\\"{x:1360,y:728,t:1527030817887};\\\", \\\"{x:1422,y:772,t:1527030817904};\\\", \\\"{x:1473,y:811,t:1527030817921};\\\", \\\"{x:1516,y:843,t:1527030817936};\\\", \\\"{x:1549,y:862,t:1527030817954};\\\", \\\"{x:1570,y:871,t:1527030817971};\\\", \\\"{x:1577,y:871,t:1527030817987};\\\", \\\"{x:1580,y:871,t:1527030818004};\\\", \\\"{x:1580,y:870,t:1527030818021};\\\", \\\"{x:1582,y:868,t:1527030818037};\\\", \\\"{x:1582,y:862,t:1527030818054};\\\", \\\"{x:1582,y:853,t:1527030818071};\\\", \\\"{x:1582,y:841,t:1527030818087};\\\", \\\"{x:1582,y:822,t:1527030818104};\\\", \\\"{x:1577,y:798,t:1527030818121};\\\", \\\"{x:1570,y:771,t:1527030818137};\\\", \\\"{x:1565,y:750,t:1527030818153};\\\", \\\"{x:1560,y:733,t:1527030818171};\\\", \\\"{x:1560,y:723,t:1527030818187};\\\", \\\"{x:1558,y:714,t:1527030818204};\\\", \\\"{x:1557,y:706,t:1527030818220};\\\", \\\"{x:1556,y:699,t:1527030818237};\\\", \\\"{x:1556,y:692,t:1527030818254};\\\", \\\"{x:1556,y:686,t:1527030818271};\\\", \\\"{x:1556,y:684,t:1527030818287};\\\", \\\"{x:1559,y:688,t:1527030818373};\\\", \\\"{x:1567,y:700,t:1527030818387};\\\", \\\"{x:1583,y:726,t:1527030818405};\\\", \\\"{x:1590,y:735,t:1527030818420};\\\", \\\"{x:1592,y:738,t:1527030818437};\\\", \\\"{x:1593,y:738,t:1527030818454};\\\", \\\"{x:1595,y:738,t:1527030818472};\\\", \\\"{x:1596,y:739,t:1527030818493};\\\", \\\"{x:1597,y:739,t:1527030818505};\\\", \\\"{x:1602,y:737,t:1527030818521};\\\", \\\"{x:1606,y:726,t:1527030818538};\\\", \\\"{x:1609,y:714,t:1527030818555};\\\", \\\"{x:1613,y:701,t:1527030818571};\\\", \\\"{x:1616,y:685,t:1527030818589};\\\", \\\"{x:1616,y:681,t:1527030818604};\\\", \\\"{x:1616,y:680,t:1527030818621};\\\", \\\"{x:1616,y:681,t:1527030818941};\\\", \\\"{x:1616,y:682,t:1527030818954};\\\", \\\"{x:1615,y:684,t:1527030818973};\\\", \\\"{x:1615,y:685,t:1527030818988};\\\", \\\"{x:1615,y:686,t:1527030819005};\\\", \\\"{x:1613,y:687,t:1527030819021};\\\", \\\"{x:1613,y:688,t:1527030819052};\\\", \\\"{x:1607,y:689,t:1527030836629};\\\", \\\"{x:1540,y:668,t:1527030836648};\\\", \\\"{x:1416,y:634,t:1527030836665};\\\", \\\"{x:1266,y:590,t:1527030836681};\\\", \\\"{x:1122,y:549,t:1527030836697};\\\", \\\"{x:979,y:507,t:1527030836714};\\\", \\\"{x:845,y:484,t:1527030836730};\\\", \\\"{x:724,y:467,t:1527030836748};\\\", \\\"{x:695,y:467,t:1527030836764};\\\", \\\"{x:682,y:469,t:1527030836780};\\\", \\\"{x:674,y:476,t:1527030836797};\\\", \\\"{x:671,y:485,t:1527030836815};\\\", \\\"{x:670,y:496,t:1527030836831};\\\", \\\"{x:669,y:514,t:1527030836847};\\\", \\\"{x:665,y:539,t:1527030836865};\\\", \\\"{x:653,y:603,t:1527030836889};\\\", \\\"{x:647,y:638,t:1527030836905};\\\", \\\"{x:642,y:656,t:1527030836921};\\\", \\\"{x:635,y:667,t:1527030836939};\\\", \\\"{x:625,y:671,t:1527030836955};\\\", \\\"{x:613,y:671,t:1527030836972};\\\", \\\"{x:584,y:666,t:1527030836988};\\\", \\\"{x:539,y:646,t:1527030837005};\\\", \\\"{x:504,y:631,t:1527030837023};\\\", \\\"{x:480,y:622,t:1527030837039};\\\", \\\"{x:470,y:620,t:1527030837055};\\\", \\\"{x:468,y:619,t:1527030837072};\\\", \\\"{x:466,y:618,t:1527030837089};\\\", \\\"{x:466,y:617,t:1527030837105};\\\", \\\"{x:470,y:605,t:1527030837121};\\\", \\\"{x:482,y:586,t:1527030837140};\\\", \\\"{x:504,y:554,t:1527030837156};\\\", \\\"{x:541,y:526,t:1527030837171};\\\", \\\"{x:588,y:495,t:1527030837189};\\\", \\\"{x:613,y:486,t:1527030837206};\\\", \\\"{x:632,y:486,t:1527030837222};\\\", \\\"{x:643,y:486,t:1527030837239};\\\", \\\"{x:654,y:505,t:1527030837256};\\\", \\\"{x:655,y:531,t:1527030837273};\\\", \\\"{x:647,y:563,t:1527030837290};\\\", \\\"{x:620,y:599,t:1527030837306};\\\", \\\"{x:569,y:636,t:1527030837322};\\\", \\\"{x:476,y:676,t:1527030837339};\\\", \\\"{x:430,y:687,t:1527030837356};\\\", \\\"{x:398,y:689,t:1527030837372};\\\", \\\"{x:375,y:682,t:1527030837390};\\\", \\\"{x:362,y:672,t:1527030837405};\\\", \\\"{x:355,y:662,t:1527030837423};\\\", \\\"{x:352,y:653,t:1527030837439};\\\", \\\"{x:352,y:642,t:1527030837456};\\\", \\\"{x:352,y:636,t:1527030837473};\\\", \\\"{x:352,y:635,t:1527030837516};\\\", \\\"{x:352,y:636,t:1527030837532};\\\", \\\"{x:352,y:637,t:1527030837540};\\\", \\\"{x:353,y:643,t:1527030837556};\\\", \\\"{x:354,y:645,t:1527030837572};\\\", \\\"{x:355,y:645,t:1527030837590};\\\", \\\"{x:357,y:645,t:1527030837606};\\\", \\\"{x:362,y:645,t:1527030837623};\\\", \\\"{x:367,y:642,t:1527030837639};\\\", \\\"{x:377,y:634,t:1527030837656};\\\", \\\"{x:386,y:628,t:1527030837673};\\\", \\\"{x:396,y:620,t:1527030837690};\\\", \\\"{x:404,y:613,t:1527030837705};\\\", \\\"{x:411,y:607,t:1527030837723};\\\", \\\"{x:414,y:604,t:1527030837740};\\\", \\\"{x:414,y:603,t:1527030837756};\\\", \\\"{x:414,y:602,t:1527030837844};\\\", \\\"{x:412,y:601,t:1527030837856};\\\", \\\"{x:404,y:601,t:1527030837872};\\\", \\\"{x:387,y:601,t:1527030837890};\\\", \\\"{x:367,y:604,t:1527030837907};\\\", \\\"{x:342,y:606,t:1527030837923};\\\", \\\"{x:303,y:606,t:1527030837939};\\\", \\\"{x:275,y:606,t:1527030837956};\\\", \\\"{x:255,y:606,t:1527030837973};\\\", \\\"{x:245,y:606,t:1527030837989};\\\", \\\"{x:241,y:606,t:1527030838007};\\\", \\\"{x:239,y:605,t:1527030838023};\\\", \\\"{x:238,y:605,t:1527030838040};\\\", \\\"{x:237,y:604,t:1527030838056};\\\", \\\"{x:234,y:602,t:1527030838072};\\\", \\\"{x:226,y:600,t:1527030838090};\\\", \\\"{x:217,y:597,t:1527030838107};\\\", \\\"{x:208,y:592,t:1527030838124};\\\", \\\"{x:195,y:587,t:1527030838139};\\\", \\\"{x:187,y:583,t:1527030838156};\\\", \\\"{x:182,y:581,t:1527030838174};\\\", \\\"{x:179,y:580,t:1527030838189};\\\", \\\"{x:176,y:580,t:1527030838206};\\\", \\\"{x:173,y:580,t:1527030838222};\\\", \\\"{x:170,y:580,t:1527030838240};\\\", \\\"{x:164,y:580,t:1527030838257};\\\", \\\"{x:160,y:580,t:1527030838273};\\\", \\\"{x:152,y:580,t:1527030838290};\\\", \\\"{x:148,y:582,t:1527030838307};\\\", \\\"{x:142,y:585,t:1527030838324};\\\", \\\"{x:137,y:589,t:1527030838339};\\\", \\\"{x:132,y:593,t:1527030838357};\\\", \\\"{x:128,y:600,t:1527030838374};\\\", \\\"{x:126,y:606,t:1527030838391};\\\", \\\"{x:121,y:618,t:1527030838406};\\\", \\\"{x:118,y:629,t:1527030838423};\\\", \\\"{x:115,y:637,t:1527030838440};\\\", \\\"{x:115,y:642,t:1527030838457};\\\", \\\"{x:115,y:646,t:1527030838473};\\\", \\\"{x:116,y:648,t:1527030838490};\\\", \\\"{x:117,y:652,t:1527030838506};\\\", \\\"{x:117,y:653,t:1527030838523};\\\", \\\"{x:118,y:654,t:1527030838572};\\\", \\\"{x:120,y:654,t:1527030838604};\\\", \\\"{x:123,y:650,t:1527030838612};\\\", \\\"{x:126,y:647,t:1527030838623};\\\", \\\"{x:138,y:639,t:1527030838640};\\\", \\\"{x:153,y:629,t:1527030838657};\\\", \\\"{x:170,y:615,t:1527030838673};\\\", \\\"{x:190,y:600,t:1527030838691};\\\", \\\"{x:215,y:586,t:1527030838707};\\\", \\\"{x:267,y:555,t:1527030838724};\\\", \\\"{x:316,y:527,t:1527030838741};\\\", \\\"{x:363,y:507,t:1527030838757};\\\", \\\"{x:397,y:489,t:1527030838773};\\\", \\\"{x:428,y:482,t:1527030838791};\\\", \\\"{x:450,y:481,t:1527030838806};\\\", \\\"{x:465,y:481,t:1527030838824};\\\", \\\"{x:475,y:484,t:1527030838840};\\\", \\\"{x:485,y:493,t:1527030838857};\\\", \\\"{x:491,y:505,t:1527030838874};\\\", \\\"{x:494,y:517,t:1527030838891};\\\", \\\"{x:494,y:533,t:1527030838908};\\\", \\\"{x:494,y:540,t:1527030838923};\\\", \\\"{x:495,y:544,t:1527030838941};\\\", \\\"{x:495,y:547,t:1527030838957};\\\", \\\"{x:495,y:548,t:1527030838974};\\\", \\\"{x:497,y:549,t:1527030839012};\\\", \\\"{x:499,y:551,t:1527030839025};\\\", \\\"{x:510,y:555,t:1527030839040};\\\", \\\"{x:528,y:557,t:1527030839057};\\\", \\\"{x:555,y:557,t:1527030839073};\\\", \\\"{x:589,y:553,t:1527030839090};\\\", \\\"{x:631,y:539,t:1527030839107};\\\", \\\"{x:681,y:521,t:1527030839124};\\\", \\\"{x:702,y:512,t:1527030839141};\\\", \\\"{x:720,y:505,t:1527030839156};\\\", \\\"{x:727,y:502,t:1527030839176};\\\", \\\"{x:730,y:501,t:1527030839190};\\\", \\\"{x:732,y:501,t:1527030839207};\\\", \\\"{x:733,y:501,t:1527030839224};\\\", \\\"{x:740,y:502,t:1527030839240};\\\", \\\"{x:744,y:506,t:1527030839257};\\\", \\\"{x:754,y:512,t:1527030839273};\\\", \\\"{x:765,y:522,t:1527030839291};\\\", \\\"{x:779,y:535,t:1527030839308};\\\", \\\"{x:789,y:544,t:1527030839323};\\\", \\\"{x:800,y:555,t:1527030839340};\\\", \\\"{x:810,y:564,t:1527030839357};\\\", \\\"{x:823,y:575,t:1527030839373};\\\", \\\"{x:834,y:587,t:1527030839391};\\\", \\\"{x:840,y:595,t:1527030839409};\\\", \\\"{x:841,y:598,t:1527030839423};\\\", \\\"{x:841,y:602,t:1527030839441};\\\", \\\"{x:841,y:604,t:1527030839458};\\\", \\\"{x:836,y:606,t:1527030839474};\\\", \\\"{x:819,y:609,t:1527030839490};\\\", \\\"{x:780,y:614,t:1527030839507};\\\", \\\"{x:750,y:617,t:1527030839524};\\\", \\\"{x:720,y:623,t:1527030839542};\\\", \\\"{x:687,y:632,t:1527030839558};\\\", \\\"{x:644,y:639,t:1527030839573};\\\", \\\"{x:591,y:647,t:1527030839590};\\\", \\\"{x:541,y:655,t:1527030839608};\\\", \\\"{x:511,y:657,t:1527030839624};\\\", \\\"{x:496,y:657,t:1527030839641};\\\", \\\"{x:492,y:657,t:1527030839658};\\\", \\\"{x:491,y:656,t:1527030839756};\\\", \\\"{x:490,y:652,t:1527030839764};\\\", \\\"{x:490,y:649,t:1527030839775};\\\", \\\"{x:486,y:644,t:1527030839790};\\\", \\\"{x:486,y:641,t:1527030839932};\\\", \\\"{x:486,y:639,t:1527030839940};\\\", \\\"{x:486,y:631,t:1527030839959};\\\", \\\"{x:500,y:621,t:1527030839975};\\\", \\\"{x:521,y:615,t:1527030839990};\\\", \\\"{x:558,y:609,t:1527030840007};\\\", \\\"{x:605,y:609,t:1527030840025};\\\", \\\"{x:653,y:609,t:1527030840042};\\\", \\\"{x:683,y:609,t:1527030840058};\\\", \\\"{x:702,y:609,t:1527030840074};\\\", \\\"{x:714,y:605,t:1527030840091};\\\", \\\"{x:717,y:602,t:1527030840107};\\\", \\\"{x:717,y:600,t:1527030840125};\\\", \\\"{x:715,y:598,t:1527030840141};\\\", \\\"{x:713,y:596,t:1527030840158};\\\", \\\"{x:711,y:595,t:1527030840175};\\\", \\\"{x:709,y:594,t:1527030840191};\\\", \\\"{x:704,y:592,t:1527030840208};\\\", \\\"{x:700,y:591,t:1527030840224};\\\", \\\"{x:697,y:588,t:1527030840241};\\\", \\\"{x:693,y:588,t:1527030840257};\\\", \\\"{x:690,y:588,t:1527030840275};\\\", \\\"{x:684,y:588,t:1527030840291};\\\", \\\"{x:680,y:588,t:1527030840307};\\\", \\\"{x:675,y:588,t:1527030840324};\\\", \\\"{x:671,y:588,t:1527030840342};\\\", \\\"{x:666,y:588,t:1527030840358};\\\", \\\"{x:659,y:590,t:1527030840375};\\\", \\\"{x:650,y:593,t:1527030840391};\\\", \\\"{x:639,y:594,t:1527030840410};\\\", \\\"{x:629,y:594,t:1527030840425};\\\", \\\"{x:623,y:594,t:1527030840442};\\\", \\\"{x:620,y:592,t:1527030840458};\\\", \\\"{x:618,y:589,t:1527030840476};\\\", \\\"{x:615,y:583,t:1527030840491};\\\", \\\"{x:614,y:581,t:1527030840508};\\\", \\\"{x:614,y:580,t:1527030840524};\\\", \\\"{x:614,y:579,t:1527030840541};\\\", \\\"{x:621,y:579,t:1527030840868};\\\", \\\"{x:635,y:582,t:1527030840876};\\\", \\\"{x:693,y:598,t:1527030840891};\\\", \\\"{x:784,y:625,t:1527030840909};\\\", \\\"{x:895,y:655,t:1527030840925};\\\", \\\"{x:1014,y:689,t:1527030840942};\\\", \\\"{x:1148,y:717,t:1527030840959};\\\", \\\"{x:1265,y:735,t:1527030840975};\\\", \\\"{x:1380,y:747,t:1527030840992};\\\", \\\"{x:1468,y:755,t:1527030841009};\\\", \\\"{x:1549,y:755,t:1527030841025};\\\", \\\"{x:1616,y:755,t:1527030841042};\\\", \\\"{x:1655,y:755,t:1527030841059};\\\", \\\"{x:1687,y:755,t:1527030841076};\\\", \\\"{x:1690,y:755,t:1527030841092};\\\", \\\"{x:1691,y:761,t:1527030841165};\\\", \\\"{x:1691,y:776,t:1527030841176};\\\", \\\"{x:1691,y:802,t:1527030841192};\\\", \\\"{x:1691,y:821,t:1527030841209};\\\", \\\"{x:1691,y:828,t:1527030841226};\\\", \\\"{x:1691,y:832,t:1527030841242};\\\", \\\"{x:1691,y:835,t:1527030841259};\\\", \\\"{x:1691,y:836,t:1527030841276};\\\", \\\"{x:1690,y:837,t:1527030841300};\\\", \\\"{x:1688,y:837,t:1527030841341};\\\", \\\"{x:1687,y:837,t:1527030841349};\\\", \\\"{x:1683,y:829,t:1527030841360};\\\", \\\"{x:1675,y:808,t:1527030841378};\\\", \\\"{x:1665,y:785,t:1527030841393};\\\", \\\"{x:1660,y:768,t:1527030841409};\\\", \\\"{x:1658,y:754,t:1527030841426};\\\", \\\"{x:1654,y:746,t:1527030841443};\\\", \\\"{x:1653,y:741,t:1527030841459};\\\", \\\"{x:1652,y:734,t:1527030841475};\\\", \\\"{x:1652,y:727,t:1527030841492};\\\", \\\"{x:1652,y:721,t:1527030841509};\\\", \\\"{x:1651,y:713,t:1527030841526};\\\", \\\"{x:1647,y:705,t:1527030841543};\\\", \\\"{x:1646,y:702,t:1527030841559};\\\", \\\"{x:1645,y:701,t:1527030841613};\\\", \\\"{x:1643,y:701,t:1527030841626};\\\", \\\"{x:1638,y:698,t:1527030841643};\\\", \\\"{x:1633,y:698,t:1527030841659};\\\", \\\"{x:1622,y:698,t:1527030841677};\\\", \\\"{x:1620,y:698,t:1527030841693};\\\", \\\"{x:1620,y:699,t:1527030841797};\\\", \\\"{x:1620,y:703,t:1527030841809};\\\", \\\"{x:1619,y:710,t:1527030841827};\\\", \\\"{x:1616,y:719,t:1527030841844};\\\", \\\"{x:1615,y:726,t:1527030841859};\\\", \\\"{x:1613,y:729,t:1527030841877};\\\", \\\"{x:1611,y:732,t:1527030841894};\\\", \\\"{x:1608,y:738,t:1527030841909};\\\", \\\"{x:1605,y:745,t:1527030841926};\\\", \\\"{x:1600,y:759,t:1527030841944};\\\", \\\"{x:1595,y:772,t:1527030841961};\\\", \\\"{x:1589,y:788,t:1527030841976};\\\", \\\"{x:1583,y:804,t:1527030841993};\\\", \\\"{x:1580,y:811,t:1527030842010};\\\", \\\"{x:1579,y:813,t:1527030842026};\\\", \\\"{x:1579,y:814,t:1527030842181};\\\", \\\"{x:1579,y:820,t:1527030842194};\\\", \\\"{x:1579,y:840,t:1527030842210};\\\", \\\"{x:1579,y:857,t:1527030842226};\\\", \\\"{x:1577,y:869,t:1527030842243};\\\", \\\"{x:1577,y:874,t:1527030842261};\\\", \\\"{x:1577,y:875,t:1527030842276};\\\", \\\"{x:1575,y:874,t:1527030842316};\\\", \\\"{x:1574,y:871,t:1527030842327};\\\", \\\"{x:1571,y:867,t:1527030842343};\\\", \\\"{x:1568,y:863,t:1527030842361};\\\", \\\"{x:1566,y:861,t:1527030842377};\\\", \\\"{x:1560,y:857,t:1527030842393};\\\", \\\"{x:1553,y:852,t:1527030842411};\\\", \\\"{x:1546,y:848,t:1527030842427};\\\", \\\"{x:1539,y:845,t:1527030842444};\\\", \\\"{x:1534,y:841,t:1527030842460};\\\", \\\"{x:1532,y:841,t:1527030842478};\\\", \\\"{x:1531,y:841,t:1527030842516};\\\", \\\"{x:1530,y:840,t:1527030842532};\\\", \\\"{x:1529,y:840,t:1527030842543};\\\", \\\"{x:1527,y:838,t:1527030842561};\\\", \\\"{x:1526,y:838,t:1527030842581};\\\", \\\"{x:1526,y:837,t:1527030842773};\\\", \\\"{x:1526,y:836,t:1527030842780};\\\", \\\"{x:1528,y:836,t:1527030842793};\\\", \\\"{x:1530,y:835,t:1527030842810};\\\", \\\"{x:1531,y:834,t:1527030842827};\\\", \\\"{x:1532,y:833,t:1527030842844};\\\", \\\"{x:1532,y:832,t:1527030842892};\\\", \\\"{x:1533,y:831,t:1527030843005};\\\", \\\"{x:1535,y:831,t:1527030843013};\\\", \\\"{x:1538,y:832,t:1527030843028};\\\", \\\"{x:1541,y:833,t:1527030843044};\\\", \\\"{x:1543,y:834,t:1527030843059};\\\", \\\"{x:1544,y:834,t:1527030843077};\\\", \\\"{x:1545,y:834,t:1527030843100};\\\", \\\"{x:1546,y:834,t:1527030843220};\\\", \\\"{x:1547,y:834,t:1527030843525};\\\", \\\"{x:1549,y:834,t:1527030843532};\\\", \\\"{x:1552,y:836,t:1527030843544};\\\", \\\"{x:1557,y:837,t:1527030843561};\\\", \\\"{x:1559,y:838,t:1527030843578};\\\", \\\"{x:1560,y:839,t:1527030843652};\\\", \\\"{x:1561,y:839,t:1527030843661};\\\", \\\"{x:1562,y:840,t:1527030843701};\\\", \\\"{x:1564,y:840,t:1527030843732};\\\", \\\"{x:1565,y:840,t:1527030843745};\\\", \\\"{x:1566,y:840,t:1527030843762};\\\", \\\"{x:1569,y:840,t:1527030843777};\\\", \\\"{x:1573,y:840,t:1527030843794};\\\", \\\"{x:1576,y:840,t:1527030843812};\\\", \\\"{x:1582,y:839,t:1527030843828};\\\", \\\"{x:1583,y:839,t:1527030843844};\\\", \\\"{x:1587,y:839,t:1527030843862};\\\", \\\"{x:1592,y:839,t:1527030843879};\\\", \\\"{x:1594,y:839,t:1527030843895};\\\", \\\"{x:1596,y:839,t:1527030843911};\\\", \\\"{x:1597,y:839,t:1527030843928};\\\", \\\"{x:1598,y:839,t:1527030844029};\\\", \\\"{x:1599,y:839,t:1527030844052};\\\", \\\"{x:1600,y:839,t:1527030844062};\\\", \\\"{x:1602,y:837,t:1527030844079};\\\", \\\"{x:1604,y:835,t:1527030844094};\\\", \\\"{x:1605,y:834,t:1527030844111};\\\", \\\"{x:1605,y:833,t:1527030844128};\\\", \\\"{x:1606,y:833,t:1527030844144};\\\", \\\"{x:1601,y:829,t:1527030847605};\\\", \\\"{x:1588,y:823,t:1527030847613};\\\", \\\"{x:1559,y:805,t:1527030847631};\\\", \\\"{x:1528,y:789,t:1527030847647};\\\", \\\"{x:1491,y:756,t:1527030847665};\\\", \\\"{x:1461,y:718,t:1527030847681};\\\", \\\"{x:1432,y:685,t:1527030847698};\\\", \\\"{x:1412,y:658,t:1527030847714};\\\", \\\"{x:1405,y:644,t:1527030847731};\\\", \\\"{x:1400,y:637,t:1527030847748};\\\", \\\"{x:1397,y:629,t:1527030847764};\\\", \\\"{x:1393,y:623,t:1527030847780};\\\", \\\"{x:1388,y:613,t:1527030847797};\\\", \\\"{x:1380,y:600,t:1527030847814};\\\", \\\"{x:1371,y:587,t:1527030847831};\\\", \\\"{x:1360,y:576,t:1527030847848};\\\", \\\"{x:1355,y:572,t:1527030847864};\\\", \\\"{x:1352,y:569,t:1527030847881};\\\", \\\"{x:1351,y:568,t:1527030847897};\\\", \\\"{x:1349,y:568,t:1527030847914};\\\", \\\"{x:1348,y:566,t:1527030847930};\\\", \\\"{x:1344,y:566,t:1527030847947};\\\", \\\"{x:1343,y:565,t:1527030847964};\\\", \\\"{x:1342,y:564,t:1527030847996};\\\", \\\"{x:1342,y:563,t:1527030848027};\\\", \\\"{x:1342,y:560,t:1527030848036};\\\", \\\"{x:1342,y:559,t:1527030848047};\\\", \\\"{x:1342,y:558,t:1527030848067};\\\", \\\"{x:1342,y:557,t:1527030848080};\\\", \\\"{x:1345,y:557,t:1527030848097};\\\", \\\"{x:1349,y:557,t:1527030848114};\\\", \\\"{x:1349,y:558,t:1527030848130};\\\", \\\"{x:1348,y:558,t:1527030848173};\\\", \\\"{x:1345,y:558,t:1527030848181};\\\", \\\"{x:1342,y:561,t:1527030848198};\\\", \\\"{x:1342,y:563,t:1527030848215};\\\", \\\"{x:1342,y:564,t:1527030848232};\\\", \\\"{x:1342,y:566,t:1527030848247};\\\", \\\"{x:1342,y:567,t:1527030848265};\\\", \\\"{x:1343,y:568,t:1527030848281};\\\", \\\"{x:1345,y:568,t:1527030848298};\\\", \\\"{x:1346,y:568,t:1527030848315};\\\", \\\"{x:1349,y:567,t:1527030848332};\\\", \\\"{x:1350,y:566,t:1527030848348};\\\", \\\"{x:1352,y:565,t:1527030848564};\\\", \\\"{x:1357,y:562,t:1527030848581};\\\", \\\"{x:1364,y:559,t:1527030848598};\\\", \\\"{x:1367,y:558,t:1527030848615};\\\", \\\"{x:1372,y:556,t:1527030848631};\\\", \\\"{x:1374,y:556,t:1527030848648};\\\", \\\"{x:1375,y:555,t:1527030848664};\\\", \\\"{x:1377,y:555,t:1527030848699};\\\", \\\"{x:1378,y:555,t:1527030848714};\\\", \\\"{x:1383,y:555,t:1527030848731};\\\", \\\"{x:1387,y:556,t:1527030848747};\\\", \\\"{x:1389,y:557,t:1527030848764};\\\", \\\"{x:1390,y:558,t:1527030848781};\\\", \\\"{x:1391,y:558,t:1527030848798};\\\", \\\"{x:1392,y:559,t:1527030848814};\\\", \\\"{x:1394,y:559,t:1527030848831};\\\", \\\"{x:1397,y:560,t:1527030848848};\\\", \\\"{x:1398,y:562,t:1527030848864};\\\", \\\"{x:1399,y:562,t:1527030848884};\\\", \\\"{x:1400,y:562,t:1527030848924};\\\", \\\"{x:1401,y:563,t:1527030848932};\\\", \\\"{x:1403,y:564,t:1527030848947};\\\", \\\"{x:1406,y:565,t:1527030848964};\\\", \\\"{x:1408,y:566,t:1527030848982};\\\", \\\"{x:1409,y:566,t:1527030848998};\\\", \\\"{x:1412,y:567,t:1527030849308};\\\", \\\"{x:1417,y:570,t:1527030849332};\\\", \\\"{x:1423,y:572,t:1527030849348};\\\", \\\"{x:1424,y:573,t:1527030849365};\\\", \\\"{x:1427,y:574,t:1527030849381};\\\", \\\"{x:1432,y:574,t:1527030849398};\\\", \\\"{x:1436,y:574,t:1527030849415};\\\", \\\"{x:1440,y:574,t:1527030849431};\\\", \\\"{x:1444,y:574,t:1527030849448};\\\", \\\"{x:1448,y:574,t:1527030849465};\\\", \\\"{x:1452,y:574,t:1527030849481};\\\", \\\"{x:1458,y:574,t:1527030849498};\\\", \\\"{x:1463,y:574,t:1527030849515};\\\", \\\"{x:1467,y:573,t:1527030849531};\\\", \\\"{x:1468,y:572,t:1527030849563};\\\", \\\"{x:1469,y:572,t:1527030849580};\\\", \\\"{x:1469,y:571,t:1527030849619};\\\", \\\"{x:1470,y:570,t:1527030849675};\\\", \\\"{x:1472,y:569,t:1527030849683};\\\", \\\"{x:1474,y:568,t:1527030849699};\\\", \\\"{x:1475,y:567,t:1527030849715};\\\", \\\"{x:1480,y:563,t:1527030849731};\\\", \\\"{x:1481,y:563,t:1527030849748};\\\", \\\"{x:1484,y:563,t:1527030850037};\\\", \\\"{x:1488,y:563,t:1527030850049};\\\", \\\"{x:1496,y:563,t:1527030850065};\\\", \\\"{x:1504,y:564,t:1527030850082};\\\", \\\"{x:1509,y:564,t:1527030850099};\\\", \\\"{x:1516,y:564,t:1527030850115};\\\", \\\"{x:1522,y:564,t:1527030850131};\\\", \\\"{x:1524,y:564,t:1527030850149};\\\", \\\"{x:1525,y:564,t:1527030850165};\\\", \\\"{x:1528,y:564,t:1527030850182};\\\", \\\"{x:1529,y:564,t:1527030850203};\\\", \\\"{x:1530,y:564,t:1527030850220};\\\", \\\"{x:1531,y:564,t:1527030850236};\\\", \\\"{x:1532,y:564,t:1527030850252};\\\", \\\"{x:1534,y:564,t:1527030850266};\\\", \\\"{x:1536,y:564,t:1527030850282};\\\", \\\"{x:1539,y:564,t:1527030850299};\\\", \\\"{x:1545,y:564,t:1527030850315};\\\", \\\"{x:1555,y:564,t:1527030850332};\\\", \\\"{x:1558,y:564,t:1527030850349};\\\", \\\"{x:1560,y:564,t:1527030850365};\\\", \\\"{x:1560,y:565,t:1527030850668};\\\", \\\"{x:1559,y:565,t:1527030850691};\\\", \\\"{x:1559,y:566,t:1527030850699};\\\", \\\"{x:1558,y:566,t:1527030850715};\\\", \\\"{x:1559,y:567,t:1527030851156};\\\", \\\"{x:1563,y:567,t:1527030851166};\\\", \\\"{x:1570,y:567,t:1527030851184};\\\", \\\"{x:1580,y:567,t:1527030851199};\\\", \\\"{x:1590,y:567,t:1527030851217};\\\", \\\"{x:1595,y:566,t:1527030851233};\\\", \\\"{x:1597,y:566,t:1527030851250};\\\", \\\"{x:1599,y:565,t:1527030851267};\\\", \\\"{x:1601,y:565,t:1527030851284};\\\", \\\"{x:1605,y:565,t:1527030851300};\\\", \\\"{x:1608,y:565,t:1527030851316};\\\", \\\"{x:1609,y:564,t:1527030851333};\\\", \\\"{x:1605,y:564,t:1527030853309};\\\", \\\"{x:1597,y:568,t:1527030853318};\\\", \\\"{x:1579,y:579,t:1527030853334};\\\", \\\"{x:1556,y:591,t:1527030853351};\\\", \\\"{x:1533,y:601,t:1527030853368};\\\", \\\"{x:1507,y:612,t:1527030853384};\\\", \\\"{x:1475,y:626,t:1527030853401};\\\", \\\"{x:1441,y:641,t:1527030853418};\\\", \\\"{x:1392,y:661,t:1527030853434};\\\", \\\"{x:1299,y:717,t:1527030853451};\\\", \\\"{x:1233,y:757,t:1527030853467};\\\", \\\"{x:1181,y:789,t:1527030853484};\\\", \\\"{x:1154,y:803,t:1527030853501};\\\", \\\"{x:1145,y:809,t:1527030853519};\\\", \\\"{x:1143,y:811,t:1527030853534};\\\", \\\"{x:1142,y:811,t:1527030853596};\\\", \\\"{x:1141,y:811,t:1527030853604};\\\", \\\"{x:1139,y:811,t:1527030853619};\\\", \\\"{x:1135,y:810,t:1527030853635};\\\", \\\"{x:1126,y:807,t:1527030853651};\\\", \\\"{x:1112,y:806,t:1527030853668};\\\", \\\"{x:1100,y:800,t:1527030853685};\\\", \\\"{x:1080,y:789,t:1527030853702};\\\", \\\"{x:1054,y:768,t:1527030853719};\\\", \\\"{x:1012,y:718,t:1527030853734};\\\", \\\"{x:952,y:637,t:1527030853752};\\\", \\\"{x:879,y:539,t:1527030853769};\\\", \\\"{x:791,y:430,t:1527030853785};\\\", \\\"{x:567,y:225,t:1527030853818};\\\", \\\"{x:433,y:131,t:1527030853835};\\\", \\\"{x:406,y:118,t:1527030853852};\\\", \\\"{x:397,y:118,t:1527030853869};\\\", \\\"{x:394,y:124,t:1527030853886};\\\", \\\"{x:393,y:177,t:1527030853902};\\\", \\\"{x:391,y:291,t:1527030853920};\\\", \\\"{x:370,y:413,t:1527030853936};\\\", \\\"{x:350,y:514,t:1527030853953};\\\", \\\"{x:344,y:588,t:1527030853970};\\\", \\\"{x:345,y:639,t:1527030853986};\\\", \\\"{x:357,y:683,t:1527030854002};\\\", \\\"{x:369,y:711,t:1527030854019};\\\", \\\"{x:370,y:712,t:1527030854036};\\\", \\\"{x:373,y:714,t:1527030854052};\\\", \\\"{x:376,y:715,t:1527030854069};\\\", \\\"{x:381,y:718,t:1527030854086};\\\", \\\"{x:386,y:718,t:1527030854102};\\\", \\\"{x:391,y:718,t:1527030854119};\\\", \\\"{x:396,y:718,t:1527030854136};\\\", \\\"{x:405,y:717,t:1527030854152};\\\", \\\"{x:418,y:713,t:1527030854169};\\\", \\\"{x:432,y:707,t:1527030854186};\\\", \\\"{x:460,y:696,t:1527030854204};\\\", \\\"{x:473,y:691,t:1527030854220};\\\", \\\"{x:480,y:689,t:1527030854237};\\\", \\\"{x:482,y:687,t:1527030854254};\\\", \\\"{x:483,y:687,t:1527030854397};\\\", \\\"{x:484,y:687,t:1527030854404};\\\", \\\"{x:488,y:698,t:1527030854420};\\\", \\\"{x:494,y:714,t:1527030854437};\\\", \\\"{x:497,y:723,t:1527030854453};\\\", \\\"{x:500,y:726,t:1527030854470};\\\", \\\"{x:501,y:726,t:1527030854516};\\\", \\\"{x:502,y:726,t:1527030854540};\\\", \\\"{x:503,y:726,t:1527030854552};\\\" ] }, { \\\"rt\\\": 43712, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 813511, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -J -I -O -B -B -03 PM-F -Z -G -E -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:723,t:1527030856659};\\\", \\\"{x:503,y:705,t:1527030856672};\\\", \\\"{x:503,y:675,t:1527030856688};\\\", \\\"{x:509,y:644,t:1527030856704};\\\", \\\"{x:519,y:619,t:1527030856722};\\\", \\\"{x:525,y:602,t:1527030856738};\\\", \\\"{x:530,y:589,t:1527030856755};\\\", \\\"{x:540,y:574,t:1527030856771};\\\", \\\"{x:545,y:565,t:1527030856789};\\\", \\\"{x:550,y:558,t:1527030856805};\\\", \\\"{x:554,y:552,t:1527030856822};\\\", \\\"{x:558,y:546,t:1527030856838};\\\", \\\"{x:563,y:537,t:1527030856854};\\\", \\\"{x:566,y:529,t:1527030856872};\\\", \\\"{x:566,y:521,t:1527030856889};\\\", \\\"{x:569,y:515,t:1527030856906};\\\", \\\"{x:570,y:511,t:1527030856921};\\\", \\\"{x:571,y:509,t:1527030856938};\\\", \\\"{x:573,y:505,t:1527030856955};\\\", \\\"{x:574,y:502,t:1527030856971};\\\", \\\"{x:576,y:498,t:1527030856988};\\\", \\\"{x:585,y:493,t:1527030857005};\\\", \\\"{x:595,y:491,t:1527030857021};\\\", \\\"{x:603,y:490,t:1527030857039};\\\", \\\"{x:614,y:490,t:1527030857055};\\\", \\\"{x:628,y:491,t:1527030857071};\\\", \\\"{x:641,y:495,t:1527030857088};\\\", \\\"{x:650,y:495,t:1527030857106};\\\", \\\"{x:660,y:497,t:1527030857121};\\\", \\\"{x:669,y:499,t:1527030857139};\\\", \\\"{x:682,y:500,t:1527030857155};\\\", \\\"{x:687,y:500,t:1527030857172};\\\", \\\"{x:692,y:500,t:1527030857188};\\\", \\\"{x:694,y:500,t:1527030857206};\\\", \\\"{x:697,y:500,t:1527030857222};\\\", \\\"{x:700,y:500,t:1527030857238};\\\", \\\"{x:707,y:498,t:1527030857255};\\\", \\\"{x:715,y:496,t:1527030857271};\\\", \\\"{x:725,y:496,t:1527030857289};\\\", \\\"{x:737,y:494,t:1527030857305};\\\", \\\"{x:747,y:492,t:1527030857321};\\\", \\\"{x:758,y:491,t:1527030857339};\\\", \\\"{x:772,y:490,t:1527030857355};\\\", \\\"{x:782,y:490,t:1527030857372};\\\", \\\"{x:796,y:490,t:1527030857388};\\\", \\\"{x:812,y:490,t:1527030857405};\\\", \\\"{x:840,y:491,t:1527030857423};\\\", \\\"{x:872,y:498,t:1527030857439};\\\", \\\"{x:911,y:504,t:1527030857455};\\\", \\\"{x:958,y:510,t:1527030857472};\\\", \\\"{x:1014,y:516,t:1527030857488};\\\", \\\"{x:1062,y:524,t:1527030857505};\\\", \\\"{x:1091,y:527,t:1527030857521};\\\", \\\"{x:1118,y:527,t:1527030857538};\\\", \\\"{x:1151,y:528,t:1527030857555};\\\", \\\"{x:1174,y:533,t:1527030857571};\\\", \\\"{x:1195,y:535,t:1527030857588};\\\", \\\"{x:1211,y:538,t:1527030857605};\\\", \\\"{x:1223,y:538,t:1527030857621};\\\", \\\"{x:1230,y:538,t:1527030857639};\\\", \\\"{x:1233,y:538,t:1527030857656};\\\", \\\"{x:1236,y:538,t:1527030857671};\\\", \\\"{x:1241,y:538,t:1527030857688};\\\", \\\"{x:1245,y:539,t:1527030857704};\\\", \\\"{x:1251,y:539,t:1527030857722};\\\", \\\"{x:1256,y:539,t:1527030857739};\\\", \\\"{x:1260,y:540,t:1527030858084};\\\", \\\"{x:1262,y:542,t:1527030858091};\\\", \\\"{x:1267,y:543,t:1527030858104};\\\", \\\"{x:1270,y:545,t:1527030858120};\\\", \\\"{x:1275,y:547,t:1527030858137};\\\", \\\"{x:1278,y:547,t:1527030858155};\\\", \\\"{x:1281,y:549,t:1527030858170};\\\", \\\"{x:1283,y:549,t:1527030858187};\\\", \\\"{x:1284,y:549,t:1527030858301};\\\", \\\"{x:1286,y:550,t:1527030858308};\\\", \\\"{x:1289,y:552,t:1527030858321};\\\", \\\"{x:1295,y:558,t:1527030858338};\\\", \\\"{x:1304,y:567,t:1527030858355};\\\", \\\"{x:1318,y:581,t:1527030858371};\\\", \\\"{x:1342,y:609,t:1527030858389};\\\", \\\"{x:1373,y:640,t:1527030858404};\\\", \\\"{x:1403,y:666,t:1527030858421};\\\", \\\"{x:1428,y:691,t:1527030858438};\\\", \\\"{x:1453,y:716,t:1527030858454};\\\", \\\"{x:1465,y:730,t:1527030858471};\\\", \\\"{x:1470,y:737,t:1527030858488};\\\", \\\"{x:1472,y:743,t:1527030858505};\\\", \\\"{x:1473,y:746,t:1527030858521};\\\", \\\"{x:1473,y:749,t:1527030858537};\\\", \\\"{x:1474,y:750,t:1527030858554};\\\", \\\"{x:1477,y:750,t:1527030858605};\\\", \\\"{x:1477,y:753,t:1527030858621};\\\", \\\"{x:1478,y:753,t:1527030858652};\\\", \\\"{x:1478,y:754,t:1527030858676};\\\", \\\"{x:1478,y:755,t:1527030858692};\\\", \\\"{x:1479,y:756,t:1527030858704};\\\", \\\"{x:1479,y:758,t:1527030858721};\\\", \\\"{x:1480,y:762,t:1527030858737};\\\", \\\"{x:1482,y:768,t:1527030858754};\\\", \\\"{x:1486,y:777,t:1527030858770};\\\", \\\"{x:1490,y:785,t:1527030858787};\\\", \\\"{x:1495,y:795,t:1527030858804};\\\", \\\"{x:1495,y:797,t:1527030858820};\\\", \\\"{x:1497,y:795,t:1527030858940};\\\", \\\"{x:1497,y:793,t:1527030858953};\\\", \\\"{x:1497,y:789,t:1527030858970};\\\", \\\"{x:1497,y:784,t:1527030858987};\\\", \\\"{x:1496,y:778,t:1527030859003};\\\", \\\"{x:1491,y:773,t:1527030859020};\\\", \\\"{x:1487,y:769,t:1527030859037};\\\", \\\"{x:1482,y:766,t:1527030859053};\\\", \\\"{x:1477,y:763,t:1527030859071};\\\", \\\"{x:1472,y:760,t:1527030859087};\\\", \\\"{x:1455,y:757,t:1527030859103};\\\", \\\"{x:1441,y:754,t:1527030859120};\\\", \\\"{x:1432,y:754,t:1527030859137};\\\", \\\"{x:1420,y:752,t:1527030859154};\\\", \\\"{x:1408,y:751,t:1527030859170};\\\", \\\"{x:1400,y:749,t:1527030859187};\\\", \\\"{x:1394,y:747,t:1527030859203};\\\", \\\"{x:1379,y:741,t:1527030859220};\\\", \\\"{x:1357,y:732,t:1527030859236};\\\", \\\"{x:1328,y:721,t:1527030859253};\\\", \\\"{x:1304,y:711,t:1527030859270};\\\", \\\"{x:1289,y:710,t:1527030859286};\\\", \\\"{x:1276,y:709,t:1527030859303};\\\", \\\"{x:1268,y:707,t:1527030859320};\\\", \\\"{x:1263,y:706,t:1527030859336};\\\", \\\"{x:1261,y:706,t:1527030859353};\\\", \\\"{x:1259,y:705,t:1527030859369};\\\", \\\"{x:1257,y:705,t:1527030859387};\\\", \\\"{x:1256,y:705,t:1527030859403};\\\", \\\"{x:1254,y:705,t:1527030859419};\\\", \\\"{x:1249,y:706,t:1527030859436};\\\", \\\"{x:1243,y:712,t:1527030859453};\\\", \\\"{x:1234,y:728,t:1527030859468};\\\", \\\"{x:1222,y:750,t:1527030859486};\\\", \\\"{x:1208,y:779,t:1527030859503};\\\", \\\"{x:1197,y:804,t:1527030859519};\\\", \\\"{x:1188,y:826,t:1527030859536};\\\", \\\"{x:1181,y:845,t:1527030859552};\\\", \\\"{x:1175,y:859,t:1527030859568};\\\", \\\"{x:1173,y:863,t:1527030859585};\\\", \\\"{x:1173,y:865,t:1527030859601};\\\", \\\"{x:1173,y:866,t:1527030859618};\\\", \\\"{x:1182,y:866,t:1527030859635};\\\", \\\"{x:1194,y:859,t:1527030859651};\\\", \\\"{x:1201,y:853,t:1527030859669};\\\", \\\"{x:1205,y:846,t:1527030859685};\\\", \\\"{x:1210,y:838,t:1527030859701};\\\", \\\"{x:1213,y:833,t:1527030859719};\\\", \\\"{x:1214,y:832,t:1527030859736};\\\", \\\"{x:1216,y:830,t:1527030859751};\\\", \\\"{x:1218,y:828,t:1527030859768};\\\", \\\"{x:1219,y:827,t:1527030859784};\\\", \\\"{x:1220,y:825,t:1527030859802};\\\", \\\"{x:1222,y:820,t:1527030859819};\\\", \\\"{x:1224,y:812,t:1527030859835};\\\", \\\"{x:1228,y:801,t:1527030859851};\\\", \\\"{x:1231,y:794,t:1527030859869};\\\", \\\"{x:1232,y:790,t:1527030859884};\\\", \\\"{x:1232,y:784,t:1527030859902};\\\", \\\"{x:1232,y:778,t:1527030859918};\\\", \\\"{x:1230,y:772,t:1527030859935};\\\", \\\"{x:1227,y:768,t:1527030859952};\\\", \\\"{x:1226,y:766,t:1527030859969};\\\", \\\"{x:1225,y:764,t:1527030859984};\\\", \\\"{x:1224,y:764,t:1527030860060};\\\", \\\"{x:1223,y:764,t:1527030860068};\\\", \\\"{x:1217,y:764,t:1527030860085};\\\", \\\"{x:1208,y:765,t:1527030860101};\\\", \\\"{x:1201,y:768,t:1527030860118};\\\", \\\"{x:1198,y:769,t:1527030860134};\\\", \\\"{x:1196,y:770,t:1527030860152};\\\", \\\"{x:1195,y:771,t:1527030860168};\\\", \\\"{x:1194,y:771,t:1527030860332};\\\", \\\"{x:1193,y:771,t:1527030860340};\\\", \\\"{x:1192,y:769,t:1527030860351};\\\", \\\"{x:1192,y:768,t:1527030860404};\\\", \\\"{x:1191,y:767,t:1527030860509};\\\", \\\"{x:1189,y:767,t:1527030860629};\\\", \\\"{x:1188,y:767,t:1527030860636};\\\", \\\"{x:1186,y:767,t:1527030860652};\\\", \\\"{x:1182,y:767,t:1527030860667};\\\", \\\"{x:1181,y:769,t:1527030860684};\\\", \\\"{x:1181,y:768,t:1527030861132};\\\", \\\"{x:1181,y:767,t:1527030861150};\\\", \\\"{x:1181,y:766,t:1527030861171};\\\", \\\"{x:1181,y:765,t:1527030861182};\\\", \\\"{x:1181,y:764,t:1527030861199};\\\", \\\"{x:1181,y:763,t:1527030869254};\\\", \\\"{x:1187,y:764,t:1527030869263};\\\", \\\"{x:1231,y:778,t:1527030869280};\\\", \\\"{x:1279,y:786,t:1527030869297};\\\", \\\"{x:1351,y:786,t:1527030869313};\\\", \\\"{x:1435,y:786,t:1527030869329};\\\", \\\"{x:1507,y:785,t:1527030869346};\\\", \\\"{x:1539,y:784,t:1527030869364};\\\", \\\"{x:1553,y:780,t:1527030869380};\\\", \\\"{x:1556,y:778,t:1527030869397};\\\", \\\"{x:1556,y:779,t:1527030869534};\\\", \\\"{x:1555,y:781,t:1527030869548};\\\", \\\"{x:1554,y:784,t:1527030869563};\\\", \\\"{x:1554,y:786,t:1527030869580};\\\", \\\"{x:1553,y:788,t:1527030869597};\\\", \\\"{x:1553,y:789,t:1527030869734};\\\", \\\"{x:1553,y:792,t:1527030869746};\\\", \\\"{x:1553,y:797,t:1527030869764};\\\", \\\"{x:1553,y:803,t:1527030869780};\\\", \\\"{x:1553,y:809,t:1527030869796};\\\", \\\"{x:1552,y:816,t:1527030869813};\\\", \\\"{x:1552,y:824,t:1527030869829};\\\", \\\"{x:1552,y:834,t:1527030869846};\\\", \\\"{x:1552,y:840,t:1527030869863};\\\", \\\"{x:1552,y:841,t:1527030869879};\\\", \\\"{x:1551,y:841,t:1527030869966};\\\", \\\"{x:1547,y:838,t:1527030869979};\\\", \\\"{x:1542,y:829,t:1527030869996};\\\", \\\"{x:1539,y:822,t:1527030870013};\\\", \\\"{x:1535,y:815,t:1527030870029};\\\", \\\"{x:1533,y:811,t:1527030870046};\\\", \\\"{x:1533,y:809,t:1527030870063};\\\", \\\"{x:1532,y:809,t:1527030870079};\\\", \\\"{x:1531,y:808,t:1527030870096};\\\", \\\"{x:1530,y:807,t:1527030870112};\\\", \\\"{x:1529,y:806,t:1527030870129};\\\", \\\"{x:1528,y:806,t:1527030870146};\\\", \\\"{x:1527,y:806,t:1527030870182};\\\", \\\"{x:1525,y:805,t:1527030870238};\\\", \\\"{x:1525,y:804,t:1527030870245};\\\", \\\"{x:1521,y:798,t:1527030870262};\\\", \\\"{x:1517,y:791,t:1527030870279};\\\", \\\"{x:1515,y:784,t:1527030870297};\\\", \\\"{x:1515,y:781,t:1527030870312};\\\", \\\"{x:1515,y:779,t:1527030870329};\\\", \\\"{x:1514,y:777,t:1527030870345};\\\", \\\"{x:1514,y:776,t:1527030870362};\\\", \\\"{x:1514,y:774,t:1527030870379};\\\", \\\"{x:1514,y:773,t:1527030870398};\\\", \\\"{x:1514,y:772,t:1527030870503};\\\", \\\"{x:1514,y:770,t:1527030870513};\\\", \\\"{x:1514,y:768,t:1527030870528};\\\", \\\"{x:1515,y:767,t:1527030870545};\\\", \\\"{x:1515,y:765,t:1527030870562};\\\", \\\"{x:1516,y:764,t:1527030870578};\\\", \\\"{x:1516,y:762,t:1527030874462};\\\", \\\"{x:1510,y:761,t:1527030874472};\\\", \\\"{x:1497,y:761,t:1527030874490};\\\", \\\"{x:1486,y:761,t:1527030874506};\\\", \\\"{x:1477,y:761,t:1527030874523};\\\", \\\"{x:1472,y:762,t:1527030874540};\\\", \\\"{x:1468,y:764,t:1527030874556};\\\", \\\"{x:1466,y:764,t:1527030874782};\\\", \\\"{x:1464,y:764,t:1527030874789};\\\", \\\"{x:1460,y:764,t:1527030874805};\\\", \\\"{x:1458,y:764,t:1527030874821};\\\", \\\"{x:1456,y:764,t:1527030875038};\\\", \\\"{x:1455,y:764,t:1527030875056};\\\", \\\"{x:1454,y:764,t:1527030875077};\\\", \\\"{x:1454,y:763,t:1527030875941};\\\", \\\"{x:1453,y:763,t:1527030876118};\\\", \\\"{x:1451,y:763,t:1527030876125};\\\", \\\"{x:1447,y:763,t:1527030876136};\\\", \\\"{x:1435,y:765,t:1527030876152};\\\", \\\"{x:1418,y:772,t:1527030876170};\\\", \\\"{x:1397,y:776,t:1527030876186};\\\", \\\"{x:1378,y:777,t:1527030876203};\\\", \\\"{x:1366,y:780,t:1527030876219};\\\", \\\"{x:1364,y:780,t:1527030876236};\\\", \\\"{x:1364,y:778,t:1527030876390};\\\", \\\"{x:1364,y:777,t:1527030876403};\\\", \\\"{x:1370,y:775,t:1527030876420};\\\", \\\"{x:1373,y:773,t:1527030876436};\\\", \\\"{x:1378,y:769,t:1527030876451};\\\", \\\"{x:1381,y:768,t:1527030876468};\\\", \\\"{x:1381,y:767,t:1527030876598};\\\", \\\"{x:1380,y:765,t:1527030876782};\\\", \\\"{x:1377,y:763,t:1527030876790};\\\", \\\"{x:1374,y:762,t:1527030876803};\\\", \\\"{x:1364,y:757,t:1527030876819};\\\", \\\"{x:1353,y:754,t:1527030876835};\\\", \\\"{x:1344,y:754,t:1527030876852};\\\", \\\"{x:1341,y:754,t:1527030876868};\\\", \\\"{x:1339,y:754,t:1527030876885};\\\", \\\"{x:1338,y:754,t:1527030877085};\\\", \\\"{x:1340,y:754,t:1527030877118};\\\", \\\"{x:1342,y:756,t:1527030877136};\\\", \\\"{x:1344,y:758,t:1527030877151};\\\", \\\"{x:1344,y:759,t:1527030877174};\\\", \\\"{x:1344,y:760,t:1527030877213};\\\", \\\"{x:1344,y:761,t:1527030877229};\\\", \\\"{x:1344,y:762,t:1527030877245};\\\", \\\"{x:1344,y:763,t:1527030877294};\\\", \\\"{x:1335,y:763,t:1527030878359};\\\", \\\"{x:1313,y:760,t:1527030878366};\\\", \\\"{x:1257,y:748,t:1527030878384};\\\", \\\"{x:1160,y:735,t:1527030878400};\\\", \\\"{x:1046,y:718,t:1527030878416};\\\", \\\"{x:921,y:702,t:1527030878433};\\\", \\\"{x:802,y:683,t:1527030878450};\\\", \\\"{x:702,y:669,t:1527030878466};\\\", \\\"{x:613,y:658,t:1527030878483};\\\", \\\"{x:537,y:644,t:1527030878499};\\\", \\\"{x:495,y:638,t:1527030878517};\\\", \\\"{x:472,y:635,t:1527030878532};\\\", \\\"{x:457,y:632,t:1527030878549};\\\", \\\"{x:455,y:631,t:1527030878567};\\\", \\\"{x:454,y:631,t:1527030878628};\\\", \\\"{x:455,y:628,t:1527030878636};\\\", \\\"{x:457,y:623,t:1527030878647};\\\", \\\"{x:464,y:612,t:1527030878665};\\\", \\\"{x:477,y:599,t:1527030878682};\\\", \\\"{x:493,y:587,t:1527030878698};\\\", \\\"{x:513,y:574,t:1527030878715};\\\", \\\"{x:531,y:560,t:1527030878732};\\\", \\\"{x:545,y:548,t:1527030878749};\\\", \\\"{x:545,y:544,t:1527030878766};\\\", \\\"{x:545,y:539,t:1527030878782};\\\", \\\"{x:535,y:533,t:1527030878799};\\\", \\\"{x:516,y:526,t:1527030878815};\\\", \\\"{x:494,y:522,t:1527030878833};\\\", \\\"{x:474,y:521,t:1527030878849};\\\", \\\"{x:462,y:521,t:1527030878866};\\\", \\\"{x:458,y:521,t:1527030878882};\\\", \\\"{x:454,y:522,t:1527030878899};\\\", \\\"{x:452,y:524,t:1527030878916};\\\", \\\"{x:448,y:526,t:1527030878934};\\\", \\\"{x:447,y:527,t:1527030878948};\\\", \\\"{x:446,y:529,t:1527030878964};\\\", \\\"{x:446,y:530,t:1527030878982};\\\", \\\"{x:446,y:532,t:1527030878999};\\\", \\\"{x:446,y:533,t:1527030879015};\\\", \\\"{x:446,y:534,t:1527030879032};\\\", \\\"{x:446,y:535,t:1527030879077};\\\", \\\"{x:445,y:535,t:1527030879165};\\\", \\\"{x:443,y:537,t:1527030879183};\\\", \\\"{x:441,y:538,t:1527030879199};\\\", \\\"{x:440,y:539,t:1527030879216};\\\", \\\"{x:439,y:539,t:1527030879233};\\\", \\\"{x:438,y:539,t:1527030879326};\\\", \\\"{x:437,y:539,t:1527030879341};\\\", \\\"{x:436,y:540,t:1527030879350};\\\", \\\"{x:434,y:541,t:1527030879366};\\\", \\\"{x:432,y:541,t:1527030879383};\\\", \\\"{x:431,y:542,t:1527030879399};\\\", \\\"{x:427,y:544,t:1527030879417};\\\", \\\"{x:426,y:544,t:1527030879432};\\\", \\\"{x:421,y:546,t:1527030879448};\\\", \\\"{x:418,y:548,t:1527030879466};\\\", \\\"{x:413,y:550,t:1527030879482};\\\", \\\"{x:407,y:555,t:1527030879499};\\\", \\\"{x:400,y:560,t:1527030879516};\\\", \\\"{x:393,y:568,t:1527030879533};\\\", \\\"{x:390,y:573,t:1527030879549};\\\", \\\"{x:387,y:579,t:1527030879566};\\\", \\\"{x:386,y:584,t:1527030879583};\\\", \\\"{x:386,y:591,t:1527030879600};\\\", \\\"{x:386,y:595,t:1527030879616};\\\", \\\"{x:386,y:596,t:1527030879633};\\\", \\\"{x:386,y:595,t:1527030879757};\\\", \\\"{x:388,y:589,t:1527030879768};\\\", \\\"{x:389,y:581,t:1527030879783};\\\", \\\"{x:390,y:570,t:1527030879799};\\\", \\\"{x:391,y:558,t:1527030879817};\\\", \\\"{x:394,y:545,t:1527030879833};\\\", \\\"{x:395,y:538,t:1527030879850};\\\", \\\"{x:395,y:533,t:1527030879866};\\\", \\\"{x:395,y:525,t:1527030879883};\\\", \\\"{x:395,y:520,t:1527030879900};\\\", \\\"{x:386,y:502,t:1527030879917};\\\", \\\"{x:385,y:501,t:1527030879933};\\\", \\\"{x:384,y:500,t:1527030879950};\\\", \\\"{x:386,y:500,t:1527030879973};\\\", \\\"{x:392,y:500,t:1527030879983};\\\", \\\"{x:408,y:507,t:1527030880001};\\\", \\\"{x:429,y:516,t:1527030880016};\\\", \\\"{x:457,y:526,t:1527030880034};\\\", \\\"{x:486,y:532,t:1527030880049};\\\", \\\"{x:517,y:532,t:1527030880067};\\\", \\\"{x:557,y:532,t:1527030880083};\\\", \\\"{x:589,y:532,t:1527030880100};\\\", \\\"{x:618,y:527,t:1527030880116};\\\", \\\"{x:626,y:522,t:1527030880134};\\\", \\\"{x:628,y:520,t:1527030880150};\\\", \\\"{x:629,y:519,t:1527030880167};\\\", \\\"{x:631,y:514,t:1527030880185};\\\", \\\"{x:631,y:512,t:1527030880200};\\\", \\\"{x:632,y:510,t:1527030880216};\\\", \\\"{x:632,y:508,t:1527030880232};\\\", \\\"{x:632,y:507,t:1527030880250};\\\", \\\"{x:632,y:504,t:1527030880266};\\\", \\\"{x:624,y:500,t:1527030880283};\\\", \\\"{x:602,y:496,t:1527030880300};\\\", \\\"{x:549,y:495,t:1527030880316};\\\", \\\"{x:494,y:495,t:1527030880334};\\\", \\\"{x:438,y:502,t:1527030880350};\\\", \\\"{x:393,y:515,t:1527030880367};\\\", \\\"{x:357,y:530,t:1527030880383};\\\", \\\"{x:337,y:539,t:1527030880400};\\\", \\\"{x:332,y:541,t:1527030880417};\\\", \\\"{x:331,y:542,t:1527030880433};\\\", \\\"{x:330,y:543,t:1527030880534};\\\", \\\"{x:326,y:549,t:1527030880550};\\\", \\\"{x:318,y:554,t:1527030880567};\\\", \\\"{x:302,y:562,t:1527030880586};\\\", \\\"{x:282,y:571,t:1527030880600};\\\", \\\"{x:266,y:574,t:1527030880618};\\\", \\\"{x:258,y:576,t:1527030880634};\\\", \\\"{x:254,y:576,t:1527030880650};\\\", \\\"{x:252,y:576,t:1527030880667};\\\", \\\"{x:251,y:576,t:1527030880684};\\\", \\\"{x:247,y:574,t:1527030880700};\\\", \\\"{x:244,y:566,t:1527030880717};\\\", \\\"{x:240,y:560,t:1527030880735};\\\", \\\"{x:235,y:552,t:1527030880750};\\\", \\\"{x:231,y:545,t:1527030880767};\\\", \\\"{x:225,y:540,t:1527030880784};\\\", \\\"{x:215,y:535,t:1527030880801};\\\", \\\"{x:211,y:534,t:1527030880817};\\\", \\\"{x:208,y:534,t:1527030880834};\\\", \\\"{x:208,y:533,t:1527030880851};\\\", \\\"{x:207,y:533,t:1527030880867};\\\", \\\"{x:205,y:533,t:1527030880884};\\\", \\\"{x:203,y:533,t:1527030880900};\\\", \\\"{x:202,y:533,t:1527030880917};\\\", \\\"{x:201,y:533,t:1527030880934};\\\", \\\"{x:200,y:533,t:1527030880957};\\\", \\\"{x:198,y:534,t:1527030880989};\\\", \\\"{x:197,y:535,t:1527030881014};\\\", \\\"{x:196,y:535,t:1527030881029};\\\", \\\"{x:195,y:536,t:1527030881053};\\\", \\\"{x:193,y:536,t:1527030881630};\\\", \\\"{x:191,y:536,t:1527030881638};\\\", \\\"{x:188,y:536,t:1527030881652};\\\", \\\"{x:183,y:536,t:1527030881667};\\\", \\\"{x:172,y:539,t:1527030881685};\\\", \\\"{x:171,y:539,t:1527030881701};\\\", \\\"{x:170,y:539,t:1527030881718};\\\", \\\"{x:169,y:539,t:1527030882141};\\\", \\\"{x:169,y:540,t:1527030882151};\\\", \\\"{x:172,y:542,t:1527030882169};\\\", \\\"{x:176,y:542,t:1527030882185};\\\", \\\"{x:186,y:542,t:1527030882201};\\\", \\\"{x:199,y:542,t:1527030882219};\\\", \\\"{x:217,y:542,t:1527030882235};\\\", \\\"{x:244,y:547,t:1527030882251};\\\", \\\"{x:300,y:555,t:1527030882269};\\\", \\\"{x:467,y:577,t:1527030882286};\\\", \\\"{x:606,y:599,t:1527030882303};\\\", \\\"{x:751,y:607,t:1527030882318};\\\", \\\"{x:906,y:611,t:1527030882335};\\\", \\\"{x:1050,y:611,t:1527030882353};\\\", \\\"{x:1194,y:611,t:1527030882368};\\\", \\\"{x:1332,y:611,t:1527030882385};\\\", \\\"{x:1465,y:611,t:1527030882401};\\\", \\\"{x:1590,y:611,t:1527030882418};\\\", \\\"{x:1712,y:611,t:1527030882435};\\\", \\\"{x:1815,y:617,t:1527030882451};\\\", \\\"{x:1900,y:625,t:1527030882468};\\\", \\\"{x:1918,y:658,t:1527030882669};\\\", \\\"{x:1909,y:664,t:1527030882684};\\\", \\\"{x:1875,y:682,t:1527030882703};\\\", \\\"{x:1854,y:692,t:1527030882720};\\\", \\\"{x:1836,y:703,t:1527030882736};\\\", \\\"{x:1821,y:711,t:1527030882753};\\\", \\\"{x:1812,y:717,t:1527030882770};\\\", \\\"{x:1802,y:724,t:1527030882785};\\\", \\\"{x:1792,y:734,t:1527030882802};\\\", \\\"{x:1782,y:746,t:1527030882819};\\\", \\\"{x:1770,y:763,t:1527030882836};\\\", \\\"{x:1757,y:782,t:1527030882853};\\\", \\\"{x:1728,y:818,t:1527030882869};\\\", \\\"{x:1709,y:841,t:1527030882886};\\\", \\\"{x:1688,y:865,t:1527030882903};\\\", \\\"{x:1673,y:881,t:1527030882919};\\\", \\\"{x:1659,y:892,t:1527030882936};\\\", \\\"{x:1648,y:898,t:1527030882953};\\\", \\\"{x:1643,y:899,t:1527030882970};\\\", \\\"{x:1641,y:900,t:1527030882985};\\\", \\\"{x:1640,y:900,t:1527030883028};\\\", \\\"{x:1639,y:900,t:1527030883036};\\\", \\\"{x:1638,y:899,t:1527030883060};\\\", \\\"{x:1638,y:898,t:1527030883069};\\\", \\\"{x:1636,y:896,t:1527030883086};\\\", \\\"{x:1635,y:894,t:1527030883102};\\\", \\\"{x:1633,y:890,t:1527030883119};\\\", \\\"{x:1630,y:885,t:1527030883136};\\\", \\\"{x:1626,y:880,t:1527030883151};\\\", \\\"{x:1620,y:876,t:1527030883169};\\\", \\\"{x:1617,y:874,t:1527030883186};\\\", \\\"{x:1611,y:872,t:1527030883202};\\\", \\\"{x:1609,y:872,t:1527030883219};\\\", \\\"{x:1605,y:872,t:1527030883236};\\\", \\\"{x:1604,y:871,t:1527030883252};\\\", \\\"{x:1599,y:871,t:1527030883269};\\\", \\\"{x:1594,y:871,t:1527030883286};\\\", \\\"{x:1588,y:873,t:1527030883303};\\\", \\\"{x:1582,y:878,t:1527030883319};\\\", \\\"{x:1579,y:883,t:1527030883335};\\\", \\\"{x:1575,y:891,t:1527030883352};\\\", \\\"{x:1572,y:903,t:1527030883369};\\\", \\\"{x:1568,y:913,t:1527030883386};\\\", \\\"{x:1565,y:926,t:1527030883402};\\\", \\\"{x:1563,y:936,t:1527030883419};\\\", \\\"{x:1561,y:946,t:1527030883436};\\\", \\\"{x:1560,y:954,t:1527030883453};\\\", \\\"{x:1559,y:959,t:1527030883469};\\\", \\\"{x:1558,y:964,t:1527030883486};\\\", \\\"{x:1557,y:968,t:1527030883503};\\\", \\\"{x:1557,y:969,t:1527030883519};\\\", \\\"{x:1556,y:970,t:1527030883536};\\\", \\\"{x:1555,y:970,t:1527030883604};\\\", \\\"{x:1555,y:969,t:1527030883620};\\\", \\\"{x:1554,y:969,t:1527030883636};\\\", \\\"{x:1554,y:968,t:1527030883653};\\\", \\\"{x:1553,y:968,t:1527030883669};\\\", \\\"{x:1551,y:968,t:1527030883686};\\\", \\\"{x:1551,y:966,t:1527030883901};\\\", \\\"{x:1551,y:964,t:1527030883908};\\\", \\\"{x:1551,y:960,t:1527030883921};\\\", \\\"{x:1550,y:954,t:1527030883936};\\\", \\\"{x:1550,y:949,t:1527030883953};\\\", \\\"{x:1550,y:945,t:1527030883970};\\\", \\\"{x:1550,y:939,t:1527030883986};\\\", \\\"{x:1550,y:936,t:1527030884003};\\\", \\\"{x:1550,y:933,t:1527030884020};\\\", \\\"{x:1550,y:931,t:1527030884036};\\\", \\\"{x:1550,y:928,t:1527030884053};\\\", \\\"{x:1550,y:924,t:1527030884070};\\\", \\\"{x:1550,y:921,t:1527030884086};\\\", \\\"{x:1550,y:917,t:1527030884103};\\\", \\\"{x:1550,y:914,t:1527030884120};\\\", \\\"{x:1550,y:911,t:1527030884136};\\\", \\\"{x:1550,y:908,t:1527030884153};\\\", \\\"{x:1550,y:907,t:1527030884276};\\\", \\\"{x:1550,y:905,t:1527030884287};\\\", \\\"{x:1550,y:903,t:1527030884303};\\\", \\\"{x:1550,y:901,t:1527030884320};\\\", \\\"{x:1550,y:898,t:1527030884337};\\\", \\\"{x:1550,y:895,t:1527030884353};\\\", \\\"{x:1549,y:892,t:1527030884370};\\\", \\\"{x:1549,y:891,t:1527030884387};\\\", \\\"{x:1549,y:890,t:1527030884403};\\\", \\\"{x:1549,y:889,t:1527030884420};\\\", \\\"{x:1549,y:888,t:1527030884437};\\\", \\\"{x:1549,y:887,t:1527030884453};\\\", \\\"{x:1549,y:886,t:1527030884470};\\\", \\\"{x:1549,y:884,t:1527030884487};\\\", \\\"{x:1549,y:881,t:1527030884504};\\\", \\\"{x:1549,y:877,t:1527030884520};\\\", \\\"{x:1549,y:875,t:1527030884537};\\\", \\\"{x:1549,y:872,t:1527030884554};\\\", \\\"{x:1549,y:870,t:1527030884570};\\\", \\\"{x:1549,y:865,t:1527030884587};\\\", \\\"{x:1549,y:858,t:1527030884604};\\\", \\\"{x:1549,y:853,t:1527030884620};\\\", \\\"{x:1550,y:845,t:1527030884637};\\\", \\\"{x:1550,y:841,t:1527030884654};\\\", \\\"{x:1550,y:839,t:1527030884670};\\\", \\\"{x:1550,y:837,t:1527030884687};\\\", \\\"{x:1550,y:835,t:1527030884704};\\\", \\\"{x:1550,y:833,t:1527030884720};\\\", \\\"{x:1551,y:832,t:1527030884737};\\\", \\\"{x:1551,y:830,t:1527030884754};\\\", \\\"{x:1552,y:828,t:1527030884771};\\\", \\\"{x:1553,y:825,t:1527030884787};\\\", \\\"{x:1554,y:824,t:1527030884804};\\\", \\\"{x:1554,y:823,t:1527030884820};\\\", \\\"{x:1554,y:819,t:1527030884837};\\\", \\\"{x:1554,y:816,t:1527030884855};\\\", \\\"{x:1554,y:812,t:1527030884870};\\\", \\\"{x:1555,y:809,t:1527030884887};\\\", \\\"{x:1555,y:804,t:1527030884904};\\\", \\\"{x:1555,y:800,t:1527030884921};\\\", \\\"{x:1555,y:797,t:1527030884937};\\\", \\\"{x:1555,y:793,t:1527030884954};\\\", \\\"{x:1555,y:790,t:1527030884971};\\\", \\\"{x:1555,y:788,t:1527030884987};\\\", \\\"{x:1555,y:786,t:1527030885004};\\\", \\\"{x:1555,y:785,t:1527030885021};\\\", \\\"{x:1555,y:782,t:1527030885037};\\\", \\\"{x:1555,y:780,t:1527030885060};\\\", \\\"{x:1555,y:779,t:1527030885071};\\\", \\\"{x:1555,y:777,t:1527030885087};\\\", \\\"{x:1555,y:776,t:1527030885104};\\\", \\\"{x:1555,y:774,t:1527030885121};\\\", \\\"{x:1555,y:772,t:1527030885137};\\\", \\\"{x:1554,y:770,t:1527030885155};\\\", \\\"{x:1553,y:766,t:1527030885172};\\\", \\\"{x:1553,y:760,t:1527030885187};\\\", \\\"{x:1552,y:758,t:1527030885204};\\\", \\\"{x:1551,y:756,t:1527030885221};\\\", \\\"{x:1550,y:754,t:1527030885237};\\\", \\\"{x:1550,y:752,t:1527030885254};\\\", \\\"{x:1549,y:748,t:1527030885271};\\\", \\\"{x:1549,y:746,t:1527030885287};\\\", \\\"{x:1549,y:745,t:1527030885305};\\\", \\\"{x:1549,y:743,t:1527030885322};\\\", \\\"{x:1549,y:742,t:1527030885338};\\\", \\\"{x:1549,y:740,t:1527030885354};\\\", \\\"{x:1549,y:738,t:1527030885371};\\\", \\\"{x:1549,y:737,t:1527030885388};\\\", \\\"{x:1549,y:735,t:1527030885404};\\\", \\\"{x:1549,y:733,t:1527030885421};\\\", \\\"{x:1549,y:731,t:1527030885438};\\\", \\\"{x:1549,y:729,t:1527030885454};\\\", \\\"{x:1549,y:727,t:1527030885472};\\\", \\\"{x:1550,y:724,t:1527030885488};\\\", \\\"{x:1550,y:722,t:1527030885504};\\\", \\\"{x:1550,y:720,t:1527030885521};\\\", \\\"{x:1550,y:718,t:1527030885538};\\\", \\\"{x:1551,y:716,t:1527030885554};\\\", \\\"{x:1551,y:714,t:1527030885571};\\\", \\\"{x:1552,y:711,t:1527030885588};\\\", \\\"{x:1552,y:709,t:1527030885604};\\\", \\\"{x:1553,y:707,t:1527030885621};\\\", \\\"{x:1553,y:706,t:1527030885638};\\\", \\\"{x:1553,y:705,t:1527030885669};\\\", \\\"{x:1553,y:704,t:1527030885708};\\\", \\\"{x:1553,y:703,t:1527030885740};\\\", \\\"{x:1553,y:702,t:1527030885772};\\\", \\\"{x:1553,y:701,t:1527030885788};\\\", \\\"{x:1553,y:700,t:1527030885804};\\\", \\\"{x:1553,y:698,t:1527030885836};\\\", \\\"{x:1553,y:697,t:1527030885861};\\\", \\\"{x:1553,y:696,t:1527030885885};\\\", \\\"{x:1553,y:695,t:1527030885974};\\\", \\\"{x:1553,y:696,t:1527030886213};\\\", \\\"{x:1553,y:699,t:1527030886222};\\\", \\\"{x:1553,y:701,t:1527030886238};\\\", \\\"{x:1553,y:703,t:1527030886255};\\\", \\\"{x:1553,y:704,t:1527030886272};\\\", \\\"{x:1553,y:705,t:1527030886288};\\\", \\\"{x:1552,y:705,t:1527030887429};\\\", \\\"{x:1551,y:705,t:1527030887439};\\\", \\\"{x:1546,y:704,t:1527030887457};\\\", \\\"{x:1544,y:703,t:1527030887474};\\\", \\\"{x:1543,y:702,t:1527030887489};\\\", \\\"{x:1542,y:702,t:1527030887506};\\\", \\\"{x:1541,y:702,t:1527030887628};\\\", \\\"{x:1539,y:702,t:1527030887639};\\\", \\\"{x:1535,y:702,t:1527030887657};\\\", \\\"{x:1530,y:702,t:1527030887674};\\\", \\\"{x:1526,y:701,t:1527030887690};\\\", \\\"{x:1524,y:701,t:1527030887706};\\\", \\\"{x:1522,y:701,t:1527030887723};\\\", \\\"{x:1521,y:701,t:1527030887748};\\\", \\\"{x:1520,y:701,t:1527030887756};\\\", \\\"{x:1519,y:701,t:1527030887773};\\\", \\\"{x:1515,y:701,t:1527030887790};\\\", \\\"{x:1512,y:701,t:1527030887806};\\\", \\\"{x:1510,y:700,t:1527030887823};\\\", \\\"{x:1509,y:699,t:1527030887841};\\\", \\\"{x:1507,y:698,t:1527030887856};\\\", \\\"{x:1504,y:697,t:1527030887873};\\\", \\\"{x:1501,y:696,t:1527030887890};\\\", \\\"{x:1497,y:694,t:1527030887906};\\\", \\\"{x:1493,y:693,t:1527030887924};\\\", \\\"{x:1491,y:693,t:1527030887948};\\\", \\\"{x:1490,y:694,t:1527030888421};\\\", \\\"{x:1482,y:696,t:1527030888428};\\\", \\\"{x:1475,y:697,t:1527030888440};\\\", \\\"{x:1451,y:699,t:1527030888457};\\\", \\\"{x:1426,y:701,t:1527030888474};\\\", \\\"{x:1404,y:701,t:1527030888490};\\\", \\\"{x:1389,y:701,t:1527030888507};\\\", \\\"{x:1380,y:703,t:1527030888524};\\\", \\\"{x:1379,y:703,t:1527030888540};\\\", \\\"{x:1379,y:702,t:1527030888685};\\\", \\\"{x:1381,y:702,t:1527030888692};\\\", \\\"{x:1384,y:701,t:1527030888708};\\\", \\\"{x:1390,y:697,t:1527030888724};\\\", \\\"{x:1396,y:695,t:1527030888740};\\\", \\\"{x:1397,y:694,t:1527030888758};\\\", \\\"{x:1396,y:694,t:1527030888989};\\\", \\\"{x:1387,y:694,t:1527030888997};\\\", \\\"{x:1375,y:694,t:1527030889008};\\\", \\\"{x:1351,y:694,t:1527030889024};\\\", \\\"{x:1329,y:693,t:1527030889042};\\\", \\\"{x:1312,y:693,t:1527030889057};\\\", \\\"{x:1306,y:693,t:1527030889074};\\\", \\\"{x:1305,y:693,t:1527030889091};\\\", \\\"{x:1306,y:693,t:1527030889156};\\\", \\\"{x:1311,y:693,t:1527030889164};\\\", \\\"{x:1320,y:693,t:1527030889174};\\\", \\\"{x:1340,y:693,t:1527030889191};\\\", \\\"{x:1368,y:693,t:1527030889208};\\\", \\\"{x:1413,y:693,t:1527030889225};\\\", \\\"{x:1467,y:693,t:1527030889241};\\\", \\\"{x:1520,y:693,t:1527030889259};\\\", \\\"{x:1574,y:695,t:1527030889275};\\\", \\\"{x:1607,y:699,t:1527030889291};\\\", \\\"{x:1622,y:702,t:1527030889308};\\\", \\\"{x:1624,y:702,t:1527030889324};\\\", \\\"{x:1624,y:701,t:1527030889404};\\\", \\\"{x:1624,y:699,t:1527030889413};\\\", \\\"{x:1624,y:697,t:1527030889424};\\\", \\\"{x:1620,y:694,t:1527030889441};\\\", \\\"{x:1615,y:691,t:1527030889459};\\\", \\\"{x:1613,y:691,t:1527030889474};\\\", \\\"{x:1610,y:690,t:1527030889491};\\\", \\\"{x:1596,y:690,t:1527030889509};\\\", \\\"{x:1585,y:690,t:1527030889524};\\\", \\\"{x:1574,y:690,t:1527030889542};\\\", \\\"{x:1564,y:690,t:1527030889559};\\\", \\\"{x:1553,y:691,t:1527030889576};\\\", \\\"{x:1547,y:693,t:1527030889591};\\\", \\\"{x:1544,y:693,t:1527030889608};\\\", \\\"{x:1542,y:694,t:1527030889626};\\\", \\\"{x:1541,y:695,t:1527030889641};\\\", \\\"{x:1541,y:696,t:1527030889659};\\\", \\\"{x:1538,y:697,t:1527030889676};\\\", \\\"{x:1538,y:698,t:1527030889691};\\\", \\\"{x:1537,y:699,t:1527030889708};\\\", \\\"{x:1537,y:698,t:1527030889845};\\\", \\\"{x:1537,y:696,t:1527030889858};\\\", \\\"{x:1537,y:694,t:1527030889876};\\\", \\\"{x:1538,y:688,t:1527030889892};\\\", \\\"{x:1538,y:685,t:1527030889908};\\\", \\\"{x:1538,y:684,t:1527030889926};\\\", \\\"{x:1538,y:681,t:1527030889942};\\\", \\\"{x:1538,y:678,t:1527030889958};\\\", \\\"{x:1538,y:675,t:1527030889975};\\\", \\\"{x:1538,y:674,t:1527030889993};\\\", \\\"{x:1538,y:672,t:1527030890009};\\\", \\\"{x:1537,y:671,t:1527030890025};\\\", \\\"{x:1536,y:669,t:1527030890043};\\\", \\\"{x:1536,y:668,t:1527030890058};\\\", \\\"{x:1535,y:668,t:1527030890075};\\\", \\\"{x:1535,y:666,t:1527030890092};\\\", \\\"{x:1534,y:665,t:1527030890108};\\\", \\\"{x:1534,y:663,t:1527030890268};\\\", \\\"{x:1534,y:661,t:1527030890276};\\\", \\\"{x:1534,y:658,t:1527030890292};\\\", \\\"{x:1535,y:654,t:1527030890309};\\\", \\\"{x:1535,y:651,t:1527030890325};\\\", \\\"{x:1535,y:647,t:1527030890342};\\\", \\\"{x:1535,y:643,t:1527030890359};\\\", \\\"{x:1535,y:638,t:1527030890376};\\\", \\\"{x:1535,y:633,t:1527030890392};\\\", \\\"{x:1534,y:630,t:1527030890410};\\\", \\\"{x:1534,y:625,t:1527030890425};\\\", \\\"{x:1533,y:623,t:1527030890442};\\\", \\\"{x:1531,y:618,t:1527030890460};\\\", \\\"{x:1530,y:614,t:1527030890475};\\\", \\\"{x:1527,y:607,t:1527030890492};\\\", \\\"{x:1527,y:605,t:1527030890509};\\\", \\\"{x:1527,y:604,t:1527030890526};\\\", \\\"{x:1527,y:603,t:1527030890543};\\\", \\\"{x:1527,y:602,t:1527030890588};\\\", \\\"{x:1525,y:605,t:1527030890757};\\\", \\\"{x:1525,y:610,t:1527030890765};\\\", \\\"{x:1523,y:619,t:1527030890776};\\\", \\\"{x:1523,y:634,t:1527030890793};\\\", \\\"{x:1523,y:648,t:1527030890809};\\\", \\\"{x:1523,y:654,t:1527030890827};\\\", \\\"{x:1523,y:656,t:1527030890842};\\\", \\\"{x:1524,y:657,t:1527030890981};\\\", \\\"{x:1524,y:661,t:1527030890992};\\\", \\\"{x:1528,y:672,t:1527030891010};\\\", \\\"{x:1533,y:686,t:1527030891026};\\\", \\\"{x:1539,y:698,t:1527030891042};\\\", \\\"{x:1544,y:706,t:1527030891060};\\\", \\\"{x:1549,y:713,t:1527030891076};\\\", \\\"{x:1550,y:714,t:1527030891092};\\\", \\\"{x:1550,y:716,t:1527030891109};\\\", \\\"{x:1551,y:719,t:1527030891126};\\\", \\\"{x:1552,y:723,t:1527030891144};\\\", \\\"{x:1553,y:725,t:1527030891159};\\\", \\\"{x:1553,y:726,t:1527030891176};\\\", \\\"{x:1554,y:728,t:1527030891193};\\\", \\\"{x:1554,y:727,t:1527030891317};\\\", \\\"{x:1554,y:726,t:1527030891333};\\\", \\\"{x:1554,y:725,t:1527030891365};\\\", \\\"{x:1554,y:724,t:1527030891377};\\\", \\\"{x:1554,y:723,t:1527030891394};\\\", \\\"{x:1554,y:722,t:1527030891420};\\\", \\\"{x:1554,y:721,t:1527030891461};\\\", \\\"{x:1554,y:720,t:1527030891476};\\\", \\\"{x:1554,y:719,t:1527030891494};\\\", \\\"{x:1554,y:718,t:1527030891510};\\\", \\\"{x:1555,y:716,t:1527030891526};\\\", \\\"{x:1555,y:714,t:1527030891543};\\\", \\\"{x:1555,y:713,t:1527030891560};\\\", \\\"{x:1555,y:710,t:1527030891577};\\\", \\\"{x:1555,y:707,t:1527030891594};\\\", \\\"{x:1555,y:705,t:1527030891611};\\\", \\\"{x:1555,y:704,t:1527030891626};\\\", \\\"{x:1555,y:703,t:1527030891643};\\\", \\\"{x:1555,y:701,t:1527030891660};\\\", \\\"{x:1555,y:700,t:1527030891684};\\\", \\\"{x:1555,y:699,t:1527030891701};\\\", \\\"{x:1556,y:698,t:1527030891710};\\\", \\\"{x:1556,y:697,t:1527030891741};\\\", \\\"{x:1556,y:696,t:1527030891748};\\\", \\\"{x:1556,y:695,t:1527030891761};\\\", \\\"{x:1556,y:693,t:1527030891781};\\\", \\\"{x:1556,y:692,t:1527030891793};\\\", \\\"{x:1556,y:691,t:1527030891811};\\\", \\\"{x:1556,y:688,t:1527030891828};\\\", \\\"{x:1556,y:686,t:1527030891843};\\\", \\\"{x:1556,y:685,t:1527030891861};\\\", \\\"{x:1556,y:683,t:1527030891877};\\\", \\\"{x:1556,y:682,t:1527030891894};\\\", \\\"{x:1556,y:681,t:1527030891910};\\\", \\\"{x:1556,y:680,t:1527030891927};\\\", \\\"{x:1556,y:679,t:1527030891944};\\\", \\\"{x:1555,y:677,t:1527030891960};\\\", \\\"{x:1555,y:676,t:1527030891988};\\\", \\\"{x:1555,y:675,t:1527030891997};\\\", \\\"{x:1555,y:674,t:1527030892012};\\\", \\\"{x:1555,y:673,t:1527030892028};\\\", \\\"{x:1553,y:671,t:1527030892053};\\\", \\\"{x:1553,y:670,t:1527030892069};\\\", \\\"{x:1553,y:668,t:1527030892084};\\\", \\\"{x:1552,y:666,t:1527030892100};\\\", \\\"{x:1552,y:665,t:1527030892116};\\\", \\\"{x:1552,y:664,t:1527030892127};\\\", \\\"{x:1551,y:663,t:1527030892144};\\\", \\\"{x:1551,y:661,t:1527030892160};\\\", \\\"{x:1550,y:660,t:1527030892178};\\\", \\\"{x:1549,y:657,t:1527030892194};\\\", \\\"{x:1549,y:655,t:1527030892211};\\\", \\\"{x:1549,y:654,t:1527030892228};\\\", \\\"{x:1548,y:652,t:1527030892245};\\\", \\\"{x:1547,y:649,t:1527030892260};\\\", \\\"{x:1547,y:647,t:1527030892277};\\\", \\\"{x:1546,y:645,t:1527030892294};\\\", \\\"{x:1546,y:642,t:1527030892311};\\\", \\\"{x:1546,y:638,t:1527030892328};\\\", \\\"{x:1545,y:635,t:1527030892345};\\\", \\\"{x:1545,y:630,t:1527030892361};\\\", \\\"{x:1545,y:626,t:1527030892377};\\\", \\\"{x:1543,y:622,t:1527030892394};\\\", \\\"{x:1543,y:619,t:1527030892411};\\\", \\\"{x:1543,y:616,t:1527030892427};\\\", \\\"{x:1542,y:610,t:1527030892444};\\\", \\\"{x:1542,y:606,t:1527030892460};\\\", \\\"{x:1541,y:602,t:1527030892477};\\\", \\\"{x:1541,y:599,t:1527030892494};\\\", \\\"{x:1541,y:595,t:1527030892510};\\\", \\\"{x:1541,y:592,t:1527030892528};\\\", \\\"{x:1541,y:588,t:1527030892544};\\\", \\\"{x:1541,y:584,t:1527030892561};\\\", \\\"{x:1541,y:579,t:1527030892578};\\\", \\\"{x:1541,y:575,t:1527030892594};\\\", \\\"{x:1541,y:572,t:1527030892611};\\\", \\\"{x:1541,y:570,t:1527030892628};\\\", \\\"{x:1541,y:568,t:1527030892645};\\\", \\\"{x:1541,y:567,t:1527030892668};\\\", \\\"{x:1541,y:565,t:1527030892820};\\\", \\\"{x:1539,y:563,t:1527030892828};\\\", \\\"{x:1539,y:561,t:1527030892844};\\\", \\\"{x:1539,y:559,t:1527030892861};\\\", \\\"{x:1538,y:558,t:1527030892877};\\\", \\\"{x:1538,y:557,t:1527030892956};\\\", \\\"{x:1537,y:557,t:1527030892988};\\\", \\\"{x:1535,y:557,t:1527030893380};\\\", \\\"{x:1533,y:557,t:1527030893395};\\\", \\\"{x:1532,y:558,t:1527030893412};\\\", \\\"{x:1529,y:558,t:1527030893428};\\\", \\\"{x:1527,y:558,t:1527030893445};\\\", \\\"{x:1526,y:558,t:1527030893580};\\\", \\\"{x:1523,y:559,t:1527030893596};\\\", \\\"{x:1515,y:560,t:1527030893611};\\\", \\\"{x:1500,y:563,t:1527030893629};\\\", \\\"{x:1493,y:563,t:1527030893645};\\\", \\\"{x:1488,y:564,t:1527030893662};\\\", \\\"{x:1485,y:564,t:1527030893679};\\\", \\\"{x:1483,y:564,t:1527030893696};\\\", \\\"{x:1481,y:565,t:1527030893749};\\\", \\\"{x:1480,y:565,t:1527030893762};\\\", \\\"{x:1479,y:565,t:1527030893778};\\\", \\\"{x:1475,y:566,t:1527030893795};\\\", \\\"{x:1471,y:566,t:1527030893812};\\\", \\\"{x:1467,y:567,t:1527030893828};\\\", \\\"{x:1462,y:567,t:1527030893845};\\\", \\\"{x:1460,y:567,t:1527030893862};\\\", \\\"{x:1459,y:567,t:1527030893884};\\\", \\\"{x:1458,y:567,t:1527030894349};\\\", \\\"{x:1457,y:567,t:1527030894362};\\\", \\\"{x:1452,y:567,t:1527030894379};\\\", \\\"{x:1450,y:567,t:1527030894396};\\\", \\\"{x:1449,y:567,t:1527030894412};\\\", \\\"{x:1448,y:567,t:1527030894484};\\\", \\\"{x:1446,y:567,t:1527030894500};\\\", \\\"{x:1445,y:567,t:1527030894512};\\\", \\\"{x:1443,y:567,t:1527030894529};\\\", \\\"{x:1442,y:567,t:1527030894546};\\\", \\\"{x:1441,y:567,t:1527030894563};\\\", \\\"{x:1438,y:567,t:1527030894579};\\\", \\\"{x:1433,y:567,t:1527030894596};\\\", \\\"{x:1428,y:567,t:1527030894612};\\\", \\\"{x:1427,y:567,t:1527030894629};\\\", \\\"{x:1424,y:566,t:1527030894646};\\\", \\\"{x:1422,y:566,t:1527030894844};\\\", \\\"{x:1421,y:565,t:1527030894868};\\\", \\\"{x:1420,y:565,t:1527030894884};\\\", \\\"{x:1418,y:565,t:1527030895061};\\\", \\\"{x:1414,y:563,t:1527030895079};\\\", \\\"{x:1408,y:562,t:1527030895096};\\\", \\\"{x:1398,y:561,t:1527030895114};\\\", \\\"{x:1388,y:560,t:1527030895130};\\\", \\\"{x:1378,y:557,t:1527030895147};\\\", \\\"{x:1369,y:556,t:1527030895164};\\\", \\\"{x:1363,y:556,t:1527030895180};\\\", \\\"{x:1361,y:556,t:1527030895196};\\\", \\\"{x:1359,y:556,t:1527030895213};\\\", \\\"{x:1358,y:555,t:1527030895230};\\\", \\\"{x:1357,y:555,t:1527030895452};\\\", \\\"{x:1356,y:556,t:1527030895464};\\\", \\\"{x:1352,y:559,t:1527030895481};\\\", \\\"{x:1349,y:562,t:1527030895496};\\\", \\\"{x:1346,y:564,t:1527030895513};\\\", \\\"{x:1345,y:565,t:1527030895531};\\\", \\\"{x:1341,y:565,t:1527030895812};\\\", \\\"{x:1328,y:565,t:1527030895820};\\\", \\\"{x:1315,y:565,t:1527030895830};\\\", \\\"{x:1286,y:565,t:1527030895848};\\\", \\\"{x:1259,y:565,t:1527030895864};\\\", \\\"{x:1238,y:565,t:1527030895881};\\\", \\\"{x:1222,y:565,t:1527030895897};\\\", \\\"{x:1214,y:565,t:1527030895914};\\\", \\\"{x:1209,y:566,t:1527030895931};\\\", \\\"{x:1206,y:566,t:1527030895948};\\\", \\\"{x:1202,y:569,t:1527030895964};\\\", \\\"{x:1197,y:572,t:1527030895980};\\\", \\\"{x:1191,y:576,t:1527030895998};\\\", \\\"{x:1181,y:582,t:1527030896014};\\\", \\\"{x:1171,y:587,t:1527030896031};\\\", \\\"{x:1165,y:589,t:1527030896048};\\\", \\\"{x:1161,y:590,t:1527030896064};\\\", \\\"{x:1157,y:591,t:1527030896081};\\\", \\\"{x:1153,y:591,t:1527030896098};\\\", \\\"{x:1149,y:590,t:1527030896114};\\\", \\\"{x:1148,y:586,t:1527030896130};\\\", \\\"{x:1148,y:585,t:1527030896148};\\\", \\\"{x:1146,y:585,t:1527030896453};\\\", \\\"{x:1143,y:587,t:1527030896508};\\\", \\\"{x:1138,y:588,t:1527030896516};\\\", \\\"{x:1126,y:588,t:1527030896532};\\\", \\\"{x:1088,y:588,t:1527030896548};\\\", \\\"{x:969,y:588,t:1527030896565};\\\", \\\"{x:842,y:588,t:1527030896582};\\\", \\\"{x:687,y:588,t:1527030896598};\\\", \\\"{x:465,y:577,t:1527030896615};\\\", \\\"{x:354,y:575,t:1527030896623};\\\", \\\"{x:134,y:554,t:1527030896641};\\\", \\\"{x:0,y:554,t:1527030896657};\\\", \\\"{x:3,y:554,t:1527030896772};\\\", \\\"{x:8,y:557,t:1527030896780};\\\", \\\"{x:26,y:566,t:1527030896797};\\\", \\\"{x:39,y:574,t:1527030896814};\\\", \\\"{x:49,y:581,t:1527030896831};\\\", \\\"{x:53,y:584,t:1527030896846};\\\", \\\"{x:54,y:585,t:1527030896864};\\\", \\\"{x:56,y:589,t:1527030896879};\\\", \\\"{x:57,y:591,t:1527030896897};\\\", \\\"{x:59,y:593,t:1527030896914};\\\", \\\"{x:61,y:595,t:1527030896931};\\\", \\\"{x:63,y:596,t:1527030896946};\\\", \\\"{x:65,y:596,t:1527030896963};\\\", \\\"{x:66,y:596,t:1527030896979};\\\", \\\"{x:67,y:598,t:1527030896996};\\\", \\\"{x:68,y:598,t:1527030897228};\\\", \\\"{x:71,y:599,t:1527030897236};\\\", \\\"{x:82,y:602,t:1527030897247};\\\", \\\"{x:110,y:609,t:1527030897263};\\\", \\\"{x:149,y:619,t:1527030897281};\\\", \\\"{x:183,y:629,t:1527030897297};\\\", \\\"{x:225,y:635,t:1527030897313};\\\", \\\"{x:283,y:640,t:1527030897331};\\\", \\\"{x:373,y:649,t:1527030897346};\\\", \\\"{x:449,y:662,t:1527030897363};\\\", \\\"{x:600,y:684,t:1527030897380};\\\", \\\"{x:731,y:703,t:1527030897396};\\\", \\\"{x:894,y:725,t:1527030897413};\\\", \\\"{x:1061,y:738,t:1527030897430};\\\", \\\"{x:1227,y:740,t:1527030897448};\\\", \\\"{x:1401,y:740,t:1527030897463};\\\", \\\"{x:1591,y:725,t:1527030897480};\\\", \\\"{x:1774,y:698,t:1527030897497};\\\", \\\"{x:1863,y:687,t:1527030897508};\\\", \\\"{x:1913,y:336,t:1527030898125};\\\", \\\"{x:1892,y:327,t:1527030898132};\\\", \\\"{x:1880,y:322,t:1527030898147};\\\", \\\"{x:1854,y:314,t:1527030898163};\\\", \\\"{x:1820,y:307,t:1527030898180};\\\", \\\"{x:1796,y:303,t:1527030898196};\\\", \\\"{x:1773,y:299,t:1527030898213};\\\", \\\"{x:1756,y:297,t:1527030898230};\\\", \\\"{x:1750,y:295,t:1527030898246};\\\", \\\"{x:1747,y:295,t:1527030898264};\\\", \\\"{x:1746,y:295,t:1527030898280};\\\", \\\"{x:1743,y:295,t:1527030898296};\\\", \\\"{x:1732,y:295,t:1527030898314};\\\", \\\"{x:1710,y:295,t:1527030898330};\\\", \\\"{x:1684,y:295,t:1527030898348};\\\", \\\"{x:1648,y:299,t:1527030898364};\\\", \\\"{x:1606,y:310,t:1527030898380};\\\", \\\"{x:1584,y:318,t:1527030898397};\\\", \\\"{x:1562,y:329,t:1527030898414};\\\", \\\"{x:1541,y:343,t:1527030898430};\\\", \\\"{x:1525,y:361,t:1527030898447};\\\", \\\"{x:1517,y:379,t:1527030898463};\\\", \\\"{x:1510,y:399,t:1527030898480};\\\", \\\"{x:1507,y:421,t:1527030898496};\\\", \\\"{x:1505,y:439,t:1527030898513};\\\", \\\"{x:1501,y:459,t:1527030898530};\\\", \\\"{x:1501,y:472,t:1527030898546};\\\", \\\"{x:1504,y:484,t:1527030898564};\\\", \\\"{x:1530,y:490,t:1527030898580};\\\", \\\"{x:1581,y:490,t:1527030898597};\\\", \\\"{x:1593,y:490,t:1527030898614};\\\", \\\"{x:1594,y:490,t:1527030898631};\\\", \\\"{x:1571,y:490,t:1527030898884};\\\", \\\"{x:1529,y:492,t:1527030898898};\\\", \\\"{x:1487,y:497,t:1527030898913};\\\", \\\"{x:1434,y:504,t:1527030898930};\\\", \\\"{x:1370,y:515,t:1527030898948};\\\", \\\"{x:1284,y:536,t:1527030898963};\\\", \\\"{x:1138,y:575,t:1527030898980};\\\", \\\"{x:1024,y:591,t:1527030898998};\\\", \\\"{x:899,y:610,t:1527030899013};\\\", \\\"{x:778,y:625,t:1527030899030};\\\", \\\"{x:672,y:640,t:1527030899048};\\\", \\\"{x:599,y:653,t:1527030899064};\\\", \\\"{x:572,y:660,t:1527030899080};\\\", \\\"{x:564,y:663,t:1527030899098};\\\", \\\"{x:563,y:663,t:1527030899124};\\\", \\\"{x:560,y:663,t:1527030899172};\\\", \\\"{x:557,y:663,t:1527030899180};\\\", \\\"{x:542,y:666,t:1527030899197};\\\", \\\"{x:518,y:676,t:1527030899214};\\\", \\\"{x:497,y:686,t:1527030899231};\\\", \\\"{x:487,y:692,t:1527030899248};\\\", \\\"{x:486,y:692,t:1527030899264};\\\", \\\"{x:487,y:692,t:1527030899324};\\\", \\\"{x:490,y:694,t:1527030899332};\\\", \\\"{x:492,y:695,t:1527030899348};\\\", \\\"{x:499,y:699,t:1527030899363};\\\", \\\"{x:507,y:707,t:1527030899380};\\\", \\\"{x:510,y:712,t:1527030899398};\\\", \\\"{x:510,y:716,t:1527030899413};\\\", \\\"{x:510,y:717,t:1527030899431};\\\", \\\"{x:510,y:718,t:1527030899448};\\\", \\\"{x:510,y:720,t:1527030899468};\\\", \\\"{x:510,y:724,t:1527030899480};\\\", \\\"{x:507,y:728,t:1527030899498};\\\", \\\"{x:503,y:736,t:1527030899516};\\\", \\\"{x:502,y:741,t:1527030899531};\\\", \\\"{x:500,y:742,t:1527030899548};\\\" ] }, { \\\"rt\\\": 45746, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 860449, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-X -03 PM-02 PM-02 PM-M -X -01 PM-X -X -02 PM-G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:742,t:1527030901268};\\\", \\\"{x:493,y:742,t:1527030901284};\\\", \\\"{x:487,y:742,t:1527030901300};\\\", \\\"{x:467,y:741,t:1527030901377};\\\", \\\"{x:466,y:740,t:1527030901500};\\\", \\\"{x:460,y:731,t:1527030901517};\\\", \\\"{x:443,y:706,t:1527030901534};\\\", \\\"{x:420,y:660,t:1527030901551};\\\", \\\"{x:380,y:590,t:1527030901568};\\\", \\\"{x:338,y:521,t:1527030901585};\\\", \\\"{x:305,y:456,t:1527030901601};\\\", \\\"{x:286,y:405,t:1527030901617};\\\", \\\"{x:281,y:358,t:1527030901634};\\\", \\\"{x:281,y:302,t:1527030901650};\\\", \\\"{x:290,y:241,t:1527030901667};\\\", \\\"{x:309,y:201,t:1527030901684};\\\", \\\"{x:328,y:186,t:1527030901700};\\\", \\\"{x:339,y:185,t:1527030901717};\\\", \\\"{x:346,y:185,t:1527030901734};\\\", \\\"{x:350,y:185,t:1527030901750};\\\", \\\"{x:354,y:189,t:1527030901767};\\\", \\\"{x:363,y:203,t:1527030901784};\\\", \\\"{x:375,y:223,t:1527030901801};\\\", \\\"{x:396,y:247,t:1527030901817};\\\", \\\"{x:425,y:280,t:1527030901834};\\\", \\\"{x:449,y:304,t:1527030901850};\\\", \\\"{x:484,y:334,t:1527030901868};\\\", \\\"{x:515,y:360,t:1527030901883};\\\", \\\"{x:548,y:386,t:1527030901901};\\\", \\\"{x:563,y:399,t:1527030901917};\\\", \\\"{x:570,y:406,t:1527030901933};\\\", \\\"{x:575,y:412,t:1527030901950};\\\", \\\"{x:578,y:416,t:1527030901968};\\\", \\\"{x:579,y:418,t:1527030902028};\\\", \\\"{x:580,y:419,t:1527030902037};\\\", \\\"{x:581,y:421,t:1527030902051};\\\", \\\"{x:582,y:422,t:1527030902067};\\\", \\\"{x:582,y:424,t:1527030902084};\\\", \\\"{x:582,y:425,t:1527030902101};\\\", \\\"{x:584,y:427,t:1527030902118};\\\", \\\"{x:587,y:431,t:1527030902134};\\\", \\\"{x:591,y:435,t:1527030902151};\\\", \\\"{x:596,y:438,t:1527030902168};\\\", \\\"{x:599,y:439,t:1527030902184};\\\", \\\"{x:602,y:441,t:1527030902201};\\\", \\\"{x:605,y:443,t:1527030902218};\\\", \\\"{x:610,y:446,t:1527030902234};\\\", \\\"{x:615,y:449,t:1527030902251};\\\", \\\"{x:625,y:454,t:1527030902267};\\\", \\\"{x:643,y:465,t:1527030902283};\\\", \\\"{x:654,y:469,t:1527030902300};\\\", \\\"{x:660,y:470,t:1527030902318};\\\", \\\"{x:667,y:474,t:1527030902334};\\\", \\\"{x:672,y:476,t:1527030902351};\\\", \\\"{x:673,y:477,t:1527030902371};\\\", \\\"{x:674,y:477,t:1527030902731};\\\", \\\"{x:676,y:478,t:1527030902739};\\\", \\\"{x:679,y:482,t:1527030902751};\\\", \\\"{x:681,y:485,t:1527030902767};\\\", \\\"{x:682,y:485,t:1527030902785};\\\", \\\"{x:683,y:486,t:1527030902802};\\\", \\\"{x:684,y:486,t:1527030902817};\\\", \\\"{x:684,y:487,t:1527030902908};\\\", \\\"{x:682,y:487,t:1527030903276};\\\", \\\"{x:677,y:487,t:1527030903284};\\\", \\\"{x:655,y:486,t:1527030903302};\\\", \\\"{x:633,y:486,t:1527030903319};\\\", \\\"{x:617,y:486,t:1527030903335};\\\", \\\"{x:608,y:486,t:1527030903352};\\\", \\\"{x:605,y:486,t:1527030903369};\\\", \\\"{x:602,y:487,t:1527030903386};\\\", \\\"{x:601,y:488,t:1527030903402};\\\", \\\"{x:600,y:488,t:1527030903418};\\\", \\\"{x:599,y:488,t:1527030903436};\\\", \\\"{x:598,y:488,t:1527030903460};\\\", \\\"{x:596,y:488,t:1527030903468};\\\", \\\"{x:595,y:488,t:1527030903486};\\\", \\\"{x:593,y:488,t:1527030903501};\\\", \\\"{x:592,y:488,t:1527030904036};\\\", \\\"{x:592,y:487,t:1527030904053};\\\", \\\"{x:598,y:488,t:1527030904069};\\\", \\\"{x:607,y:491,t:1527030904086};\\\", \\\"{x:613,y:494,t:1527030904103};\\\", \\\"{x:615,y:495,t:1527030904119};\\\", \\\"{x:617,y:496,t:1527030904136};\\\", \\\"{x:615,y:495,t:1527030904916};\\\", \\\"{x:607,y:494,t:1527030904924};\\\", \\\"{x:600,y:493,t:1527030904937};\\\", \\\"{x:584,y:493,t:1527030904953};\\\", \\\"{x:564,y:493,t:1527030904970};\\\", \\\"{x:547,y:493,t:1527030904986};\\\", \\\"{x:531,y:493,t:1527030905004};\\\", \\\"{x:530,y:493,t:1527030905020};\\\", \\\"{x:529,y:493,t:1527030905733};\\\", \\\"{x:531,y:493,t:1527030905740};\\\", \\\"{x:543,y:495,t:1527030905754};\\\", \\\"{x:576,y:501,t:1527030905771};\\\", \\\"{x:639,y:510,t:1527030905789};\\\", \\\"{x:663,y:512,t:1527030905804};\\\", \\\"{x:721,y:519,t:1527030905819};\\\", \\\"{x:780,y:527,t:1527030905835};\\\", \\\"{x:882,y:546,t:1527030905852};\\\", \\\"{x:952,y:566,t:1527030905871};\\\", \\\"{x:1005,y:580,t:1527030905887};\\\", \\\"{x:1042,y:594,t:1527030905904};\\\", \\\"{x:1070,y:606,t:1527030905921};\\\", \\\"{x:1094,y:620,t:1527030905936};\\\", \\\"{x:1112,y:631,t:1527030905953};\\\", \\\"{x:1123,y:642,t:1527030905971};\\\", \\\"{x:1131,y:650,t:1527030905987};\\\", \\\"{x:1138,y:667,t:1527030906004};\\\", \\\"{x:1142,y:681,t:1527030906021};\\\", \\\"{x:1143,y:686,t:1527030906037};\\\", \\\"{x:1143,y:701,t:1527030906054};\\\", \\\"{x:1138,y:712,t:1527030906070};\\\", \\\"{x:1139,y:712,t:1527030906572};\\\", \\\"{x:1141,y:716,t:1527030906587};\\\", \\\"{x:1155,y:761,t:1527030906604};\\\", \\\"{x:1178,y:816,t:1527030906621};\\\", \\\"{x:1233,y:894,t:1527030906637};\\\", \\\"{x:1277,y:985,t:1527030906654};\\\", \\\"{x:1314,y:1081,t:1527030906671};\\\", \\\"{x:1352,y:1172,t:1527030906687};\\\", \\\"{x:1381,y:1199,t:1527030906704};\\\", \\\"{x:1399,y:1199,t:1527030906720};\\\", \\\"{x:1403,y:1199,t:1527030906736};\\\", \\\"{x:1405,y:1199,t:1527030906753};\\\", \\\"{x:1406,y:1199,t:1527030906828};\\\", \\\"{x:1407,y:1199,t:1527030906836};\\\", \\\"{x:1416,y:1180,t:1527030906854};\\\", \\\"{x:1423,y:1163,t:1527030906871};\\\", \\\"{x:1432,y:1145,t:1527030906888};\\\", \\\"{x:1443,y:1121,t:1527030906905};\\\", \\\"{x:1456,y:1089,t:1527030906921};\\\", \\\"{x:1468,y:1045,t:1527030906938};\\\", \\\"{x:1474,y:1003,t:1527030906955};\\\", \\\"{x:1485,y:965,t:1527030906971};\\\", \\\"{x:1498,y:943,t:1527030906988};\\\", \\\"{x:1501,y:939,t:1527030907005};\\\", \\\"{x:1501,y:942,t:1527030907076};\\\", \\\"{x:1501,y:950,t:1527030907088};\\\", \\\"{x:1501,y:962,t:1527030907105};\\\", \\\"{x:1501,y:970,t:1527030907121};\\\", \\\"{x:1502,y:975,t:1527030907138};\\\", \\\"{x:1503,y:977,t:1527030907155};\\\", \\\"{x:1501,y:977,t:1527030907397};\\\", \\\"{x:1498,y:977,t:1527030907405};\\\", \\\"{x:1493,y:977,t:1527030907422};\\\", \\\"{x:1491,y:977,t:1527030907438};\\\", \\\"{x:1490,y:976,t:1527030907548};\\\", \\\"{x:1490,y:974,t:1527030907564};\\\", \\\"{x:1491,y:972,t:1527030907571};\\\", \\\"{x:1492,y:969,t:1527030907588};\\\", \\\"{x:1493,y:968,t:1527030907606};\\\", \\\"{x:1494,y:966,t:1527030907622};\\\", \\\"{x:1494,y:964,t:1527030907972};\\\", \\\"{x:1494,y:958,t:1527030907989};\\\", \\\"{x:1494,y:951,t:1527030908005};\\\", \\\"{x:1494,y:944,t:1527030908022};\\\", \\\"{x:1495,y:938,t:1527030908039};\\\", \\\"{x:1496,y:932,t:1527030908055};\\\", \\\"{x:1498,y:928,t:1527030908072};\\\", \\\"{x:1498,y:925,t:1527030908089};\\\", \\\"{x:1499,y:922,t:1527030908106};\\\", \\\"{x:1500,y:920,t:1527030908122};\\\", \\\"{x:1500,y:916,t:1527030908139};\\\", \\\"{x:1500,y:902,t:1527030908155};\\\", \\\"{x:1500,y:891,t:1527030908172};\\\", \\\"{x:1500,y:882,t:1527030908189};\\\", \\\"{x:1501,y:875,t:1527030908206};\\\", \\\"{x:1502,y:871,t:1527030908222};\\\", \\\"{x:1503,y:867,t:1527030908239};\\\", \\\"{x:1503,y:865,t:1527030908256};\\\", \\\"{x:1503,y:863,t:1527030908272};\\\", \\\"{x:1503,y:861,t:1527030908288};\\\", \\\"{x:1503,y:857,t:1527030908306};\\\", \\\"{x:1503,y:854,t:1527030908322};\\\", \\\"{x:1502,y:850,t:1527030908339};\\\", \\\"{x:1501,y:846,t:1527030908356};\\\", \\\"{x:1499,y:844,t:1527030908372};\\\", \\\"{x:1492,y:840,t:1527030908388};\\\", \\\"{x:1486,y:838,t:1527030908406};\\\", \\\"{x:1479,y:835,t:1527030908424};\\\", \\\"{x:1474,y:834,t:1527030908439};\\\", \\\"{x:1473,y:832,t:1527030908456};\\\", \\\"{x:1473,y:831,t:1527030908852};\\\", \\\"{x:1474,y:829,t:1527030908877};\\\", \\\"{x:1475,y:828,t:1527030909724};\\\", \\\"{x:1475,y:827,t:1527030909740};\\\", \\\"{x:1474,y:826,t:1527030909757};\\\", \\\"{x:1473,y:825,t:1527030909774};\\\", \\\"{x:1471,y:825,t:1527030909790};\\\", \\\"{x:1470,y:824,t:1527030909807};\\\", \\\"{x:1467,y:824,t:1527030911548};\\\", \\\"{x:1462,y:824,t:1527030911558};\\\", \\\"{x:1450,y:826,t:1527030911575};\\\", \\\"{x:1438,y:828,t:1527030911592};\\\", \\\"{x:1426,y:828,t:1527030911608};\\\", \\\"{x:1421,y:828,t:1527030911625};\\\", \\\"{x:1420,y:828,t:1527030912220};\\\", \\\"{x:1418,y:828,t:1527030912228};\\\", \\\"{x:1416,y:828,t:1527030912242};\\\", \\\"{x:1409,y:828,t:1527030912259};\\\", \\\"{x:1398,y:828,t:1527030912275};\\\", \\\"{x:1383,y:828,t:1527030912292};\\\", \\\"{x:1376,y:828,t:1527030912309};\\\", \\\"{x:1369,y:828,t:1527030912325};\\\", \\\"{x:1363,y:828,t:1527030912342};\\\", \\\"{x:1355,y:828,t:1527030912359};\\\", \\\"{x:1348,y:828,t:1527030912376};\\\", \\\"{x:1340,y:829,t:1527030912392};\\\", \\\"{x:1336,y:829,t:1527030912409};\\\", \\\"{x:1332,y:831,t:1527030912426};\\\", \\\"{x:1333,y:830,t:1527030912652};\\\", \\\"{x:1335,y:829,t:1527030912668};\\\", \\\"{x:1336,y:829,t:1527030912700};\\\", \\\"{x:1338,y:829,t:1527030912845};\\\", \\\"{x:1340,y:829,t:1527030912860};\\\", \\\"{x:1350,y:833,t:1527030912876};\\\", \\\"{x:1364,y:845,t:1527030912892};\\\", \\\"{x:1394,y:872,t:1527030912909};\\\", \\\"{x:1443,y:915,t:1527030912926};\\\", \\\"{x:1488,y:956,t:1527030912943};\\\", \\\"{x:1513,y:979,t:1527030912960};\\\", \\\"{x:1533,y:998,t:1527030912976};\\\", \\\"{x:1546,y:1009,t:1527030912993};\\\", \\\"{x:1547,y:1009,t:1527030913009};\\\", \\\"{x:1548,y:1008,t:1527030913076};\\\", \\\"{x:1548,y:1004,t:1527030913093};\\\", \\\"{x:1545,y:998,t:1527030913109};\\\", \\\"{x:1540,y:992,t:1527030913127};\\\", \\\"{x:1530,y:984,t:1527030913144};\\\", \\\"{x:1519,y:980,t:1527030913160};\\\", \\\"{x:1513,y:977,t:1527030913176};\\\", \\\"{x:1509,y:976,t:1527030913193};\\\", \\\"{x:1506,y:974,t:1527030913209};\\\", \\\"{x:1506,y:973,t:1527030913226};\\\", \\\"{x:1505,y:972,t:1527030913243};\\\", \\\"{x:1504,y:971,t:1527030913259};\\\", \\\"{x:1504,y:968,t:1527030913276};\\\", \\\"{x:1503,y:966,t:1527030913293};\\\", \\\"{x:1500,y:962,t:1527030913309};\\\", \\\"{x:1500,y:961,t:1527030913326};\\\", \\\"{x:1499,y:959,t:1527030913344};\\\", \\\"{x:1499,y:957,t:1527030913360};\\\", \\\"{x:1498,y:954,t:1527030913376};\\\", \\\"{x:1497,y:951,t:1527030913393};\\\", \\\"{x:1495,y:948,t:1527030913411};\\\", \\\"{x:1493,y:944,t:1527030913426};\\\", \\\"{x:1492,y:941,t:1527030913443};\\\", \\\"{x:1491,y:940,t:1527030913460};\\\", \\\"{x:1491,y:939,t:1527030913476};\\\", \\\"{x:1490,y:939,t:1527030913493};\\\", \\\"{x:1489,y:938,t:1527030913548};\\\", \\\"{x:1489,y:937,t:1527030913560};\\\", \\\"{x:1487,y:937,t:1527030913576};\\\", \\\"{x:1484,y:944,t:1527030913594};\\\", \\\"{x:1479,y:953,t:1527030913610};\\\", \\\"{x:1476,y:965,t:1527030913626};\\\", \\\"{x:1471,y:976,t:1527030913643};\\\", \\\"{x:1466,y:990,t:1527030913660};\\\", \\\"{x:1465,y:994,t:1527030913676};\\\", \\\"{x:1466,y:994,t:1527030913756};\\\", \\\"{x:1466,y:993,t:1527030913780};\\\", \\\"{x:1467,y:992,t:1527030913793};\\\", \\\"{x:1467,y:987,t:1527030913811};\\\", \\\"{x:1467,y:983,t:1527030913827};\\\", \\\"{x:1467,y:978,t:1527030913843};\\\", \\\"{x:1467,y:970,t:1527030913860};\\\", \\\"{x:1467,y:965,t:1527030913877};\\\", \\\"{x:1467,y:960,t:1527030913893};\\\", \\\"{x:1467,y:956,t:1527030913910};\\\", \\\"{x:1467,y:953,t:1527030913927};\\\", \\\"{x:1467,y:950,t:1527030913943};\\\", \\\"{x:1467,y:948,t:1527030913961};\\\", \\\"{x:1467,y:946,t:1527030913977};\\\", \\\"{x:1467,y:943,t:1527030913993};\\\", \\\"{x:1468,y:940,t:1527030914010};\\\", \\\"{x:1468,y:935,t:1527030914027};\\\", \\\"{x:1470,y:931,t:1527030914043};\\\", \\\"{x:1470,y:920,t:1527030914060};\\\", \\\"{x:1470,y:916,t:1527030914078};\\\", \\\"{x:1470,y:913,t:1527030914093};\\\", \\\"{x:1470,y:912,t:1527030914110};\\\", \\\"{x:1470,y:910,t:1527030914128};\\\", \\\"{x:1470,y:908,t:1527030916269};\\\", \\\"{x:1469,y:907,t:1527030916279};\\\", \\\"{x:1468,y:906,t:1527030916296};\\\", \\\"{x:1467,y:905,t:1527030916313};\\\", \\\"{x:1466,y:904,t:1527030916597};\\\", \\\"{x:1464,y:904,t:1527030916621};\\\", \\\"{x:1463,y:903,t:1527030916645};\\\", \\\"{x:1461,y:902,t:1527030917014};\\\", \\\"{x:1460,y:902,t:1527030917031};\\\", \\\"{x:1459,y:901,t:1527030917270};\\\", \\\"{x:1458,y:901,t:1527030917285};\\\", \\\"{x:1457,y:901,t:1527030917297};\\\", \\\"{x:1457,y:900,t:1527030917314};\\\", \\\"{x:1456,y:899,t:1527030917331};\\\", \\\"{x:1456,y:898,t:1527030917373};\\\", \\\"{x:1456,y:897,t:1527030917381};\\\", \\\"{x:1456,y:894,t:1527030917397};\\\", \\\"{x:1457,y:892,t:1527030917413};\\\", \\\"{x:1458,y:889,t:1527030917430};\\\", \\\"{x:1459,y:889,t:1527030917447};\\\", \\\"{x:1460,y:888,t:1527030917465};\\\", \\\"{x:1461,y:888,t:1527030917621};\\\", \\\"{x:1461,y:889,t:1527030917630};\\\", \\\"{x:1461,y:894,t:1527030917647};\\\", \\\"{x:1462,y:898,t:1527030917664};\\\", \\\"{x:1464,y:902,t:1527030917680};\\\", \\\"{x:1464,y:904,t:1527030917697};\\\", \\\"{x:1464,y:906,t:1527030917805};\\\", \\\"{x:1464,y:907,t:1527030917821};\\\", \\\"{x:1464,y:909,t:1527030917831};\\\", \\\"{x:1458,y:909,t:1527030917847};\\\", \\\"{x:1449,y:909,t:1527030917864};\\\", \\\"{x:1438,y:909,t:1527030917880};\\\", \\\"{x:1426,y:907,t:1527030917896};\\\", \\\"{x:1423,y:906,t:1527030917914};\\\", \\\"{x:1421,y:906,t:1527030917931};\\\", \\\"{x:1419,y:905,t:1527030918494};\\\", \\\"{x:1418,y:905,t:1527030918694};\\\", \\\"{x:1415,y:903,t:1527030918701};\\\", \\\"{x:1412,y:902,t:1527030918715};\\\", \\\"{x:1407,y:900,t:1527030918731};\\\", \\\"{x:1404,y:898,t:1527030918748};\\\", \\\"{x:1403,y:898,t:1527030918765};\\\", \\\"{x:1401,y:898,t:1527030918789};\\\", \\\"{x:1399,y:896,t:1527030919005};\\\", \\\"{x:1398,y:896,t:1527030919021};\\\", \\\"{x:1397,y:896,t:1527030919037};\\\", \\\"{x:1396,y:896,t:1527030919077};\\\", \\\"{x:1395,y:896,t:1527030919109};\\\", \\\"{x:1394,y:895,t:1527030919438};\\\", \\\"{x:1393,y:894,t:1527030919453};\\\", \\\"{x:1392,y:894,t:1527030919465};\\\", \\\"{x:1391,y:894,t:1527030919482};\\\", \\\"{x:1390,y:894,t:1527030919501};\\\", \\\"{x:1389,y:894,t:1527030919515};\\\", \\\"{x:1387,y:894,t:1527030919533};\\\", \\\"{x:1386,y:894,t:1527030919550};\\\", \\\"{x:1385,y:894,t:1527030919565};\\\", \\\"{x:1384,y:894,t:1527030920005};\\\", \\\"{x:1383,y:894,t:1527030920016};\\\", \\\"{x:1382,y:894,t:1527030920045};\\\", \\\"{x:1385,y:894,t:1527030921045};\\\", \\\"{x:1386,y:893,t:1527030921054};\\\", \\\"{x:1389,y:893,t:1527030921066};\\\", \\\"{x:1393,y:892,t:1527030921083};\\\", \\\"{x:1396,y:892,t:1527030921100};\\\", \\\"{x:1399,y:891,t:1527030921116};\\\", \\\"{x:1402,y:891,t:1527030921133};\\\", \\\"{x:1403,y:891,t:1527030921151};\\\", \\\"{x:1405,y:891,t:1527030921166};\\\", \\\"{x:1407,y:891,t:1527030921183};\\\", \\\"{x:1409,y:891,t:1527030921200};\\\", \\\"{x:1413,y:891,t:1527030921216};\\\", \\\"{x:1416,y:891,t:1527030921233};\\\", \\\"{x:1425,y:891,t:1527030921250};\\\", \\\"{x:1437,y:891,t:1527030921266};\\\", \\\"{x:1438,y:891,t:1527030921283};\\\", \\\"{x:1439,y:891,t:1527030921470};\\\", \\\"{x:1439,y:892,t:1527030921485};\\\", \\\"{x:1438,y:892,t:1527030921500};\\\", \\\"{x:1435,y:894,t:1527030921517};\\\", \\\"{x:1433,y:895,t:1527030921533};\\\", \\\"{x:1431,y:895,t:1527030921550};\\\", \\\"{x:1431,y:896,t:1527030921567};\\\", \\\"{x:1430,y:896,t:1527030921589};\\\", \\\"{x:1429,y:896,t:1527030921613};\\\", \\\"{x:1428,y:896,t:1527030921628};\\\", \\\"{x:1428,y:897,t:1527030921822};\\\", \\\"{x:1430,y:897,t:1527030921834};\\\", \\\"{x:1438,y:900,t:1527030921851};\\\", \\\"{x:1450,y:900,t:1527030921868};\\\", \\\"{x:1464,y:900,t:1527030921885};\\\", \\\"{x:1474,y:900,t:1527030921900};\\\", \\\"{x:1483,y:897,t:1527030921917};\\\", \\\"{x:1486,y:896,t:1527030921935};\\\", \\\"{x:1487,y:896,t:1527030921950};\\\", \\\"{x:1487,y:893,t:1527030922028};\\\", \\\"{x:1487,y:891,t:1527030922035};\\\", \\\"{x:1487,y:887,t:1527030922050};\\\", \\\"{x:1487,y:878,t:1527030922067};\\\", \\\"{x:1485,y:865,t:1527030922084};\\\", \\\"{x:1484,y:852,t:1527030922100};\\\", \\\"{x:1484,y:848,t:1527030922117};\\\", \\\"{x:1484,y:845,t:1527030922134};\\\", \\\"{x:1484,y:844,t:1527030922180};\\\", \\\"{x:1485,y:843,t:1527030922221};\\\", \\\"{x:1485,y:841,t:1527030922236};\\\", \\\"{x:1486,y:841,t:1527030922251};\\\", \\\"{x:1487,y:839,t:1527030922267};\\\", \\\"{x:1488,y:837,t:1527030922284};\\\", \\\"{x:1489,y:835,t:1527030922301};\\\", \\\"{x:1489,y:834,t:1527030922461};\\\", \\\"{x:1489,y:833,t:1527030922469};\\\", \\\"{x:1489,y:832,t:1527030922485};\\\", \\\"{x:1489,y:828,t:1527030922501};\\\", \\\"{x:1489,y:827,t:1527030922518};\\\", \\\"{x:1488,y:825,t:1527030922534};\\\", \\\"{x:1488,y:823,t:1527030922551};\\\", \\\"{x:1488,y:822,t:1527030922573};\\\", \\\"{x:1487,y:821,t:1527030922605};\\\", \\\"{x:1487,y:820,t:1527030922701};\\\", \\\"{x:1486,y:819,t:1527030922733};\\\", \\\"{x:1485,y:819,t:1527030922752};\\\", \\\"{x:1483,y:818,t:1527030922768};\\\", \\\"{x:1480,y:818,t:1527030922784};\\\", \\\"{x:1479,y:818,t:1527030922804};\\\", \\\"{x:1477,y:818,t:1527030922821};\\\", \\\"{x:1476,y:819,t:1527030922837};\\\", \\\"{x:1476,y:820,t:1527030922853};\\\", \\\"{x:1476,y:821,t:1527030922868};\\\", \\\"{x:1475,y:823,t:1527030922885};\\\", \\\"{x:1473,y:825,t:1527030922901};\\\", \\\"{x:1473,y:826,t:1527030922919};\\\", \\\"{x:1473,y:828,t:1527030923014};\\\", \\\"{x:1472,y:829,t:1527030923036};\\\", \\\"{x:1472,y:831,t:1527030923061};\\\", \\\"{x:1472,y:830,t:1527030923430};\\\", \\\"{x:1472,y:825,t:1527030923437};\\\", \\\"{x:1472,y:821,t:1527030923451};\\\", \\\"{x:1473,y:812,t:1527030923468};\\\", \\\"{x:1473,y:798,t:1527030923485};\\\", \\\"{x:1473,y:793,t:1527030923502};\\\", \\\"{x:1474,y:787,t:1527030923518};\\\", \\\"{x:1474,y:786,t:1527030923535};\\\", \\\"{x:1474,y:782,t:1527030923552};\\\", \\\"{x:1474,y:779,t:1527030923568};\\\", \\\"{x:1474,y:777,t:1527030923585};\\\", \\\"{x:1474,y:774,t:1527030923602};\\\", \\\"{x:1474,y:770,t:1527030923617};\\\", \\\"{x:1474,y:767,t:1527030923635};\\\", \\\"{x:1474,y:762,t:1527030923652};\\\", \\\"{x:1474,y:760,t:1527030923668};\\\", \\\"{x:1474,y:756,t:1527030923685};\\\", \\\"{x:1474,y:755,t:1527030923708};\\\", \\\"{x:1474,y:754,t:1527030923724};\\\", \\\"{x:1474,y:753,t:1527030923756};\\\", \\\"{x:1474,y:752,t:1527030923797};\\\", \\\"{x:1474,y:749,t:1527030924269};\\\", \\\"{x:1474,y:743,t:1527030924285};\\\", \\\"{x:1474,y:738,t:1527030924302};\\\", \\\"{x:1474,y:735,t:1527030924320};\\\", \\\"{x:1474,y:731,t:1527030924335};\\\", \\\"{x:1474,y:727,t:1527030924352};\\\", \\\"{x:1474,y:725,t:1527030924369};\\\", \\\"{x:1474,y:722,t:1527030924385};\\\", \\\"{x:1474,y:720,t:1527030924403};\\\", \\\"{x:1474,y:719,t:1527030924420};\\\", \\\"{x:1474,y:717,t:1527030924437};\\\", \\\"{x:1474,y:716,t:1527030924469};\\\", \\\"{x:1474,y:715,t:1527030924517};\\\", \\\"{x:1474,y:714,t:1527030924525};\\\", \\\"{x:1474,y:713,t:1527030924540};\\\", \\\"{x:1474,y:712,t:1527030924557};\\\", \\\"{x:1474,y:711,t:1527030924569};\\\", \\\"{x:1475,y:710,t:1527030924586};\\\", \\\"{x:1475,y:708,t:1527030924603};\\\", \\\"{x:1476,y:705,t:1527030924619};\\\", \\\"{x:1476,y:703,t:1527030924636};\\\", \\\"{x:1476,y:701,t:1527030924653};\\\", \\\"{x:1476,y:699,t:1527030924669};\\\", \\\"{x:1477,y:698,t:1527030924686};\\\", \\\"{x:1477,y:696,t:1527030924702};\\\", \\\"{x:1477,y:695,t:1527030924720};\\\", \\\"{x:1477,y:694,t:1527030924736};\\\", \\\"{x:1477,y:693,t:1527030924752};\\\", \\\"{x:1477,y:692,t:1527030927487};\\\", \\\"{x:1474,y:692,t:1527030927498};\\\", \\\"{x:1469,y:692,t:1527030927514};\\\", \\\"{x:1465,y:692,t:1527030927531};\\\", \\\"{x:1462,y:693,t:1527030927547};\\\", \\\"{x:1460,y:693,t:1527030927565};\\\", \\\"{x:1459,y:693,t:1527030927583};\\\", \\\"{x:1458,y:694,t:1527030927606};\\\", \\\"{x:1456,y:694,t:1527030927622};\\\", \\\"{x:1454,y:694,t:1527030927638};\\\", \\\"{x:1452,y:695,t:1527030927648};\\\", \\\"{x:1448,y:695,t:1527030927664};\\\", \\\"{x:1441,y:695,t:1527030927680};\\\", \\\"{x:1437,y:695,t:1527030927698};\\\", \\\"{x:1434,y:695,t:1527030927714};\\\", \\\"{x:1433,y:695,t:1527030927734};\\\", \\\"{x:1433,y:696,t:1527030927750};\\\", \\\"{x:1432,y:697,t:1527030927765};\\\", \\\"{x:1431,y:697,t:1527030927799};\\\", \\\"{x:1430,y:696,t:1527030927838};\\\", \\\"{x:1429,y:696,t:1527030927848};\\\", \\\"{x:1428,y:696,t:1527030927865};\\\", \\\"{x:1427,y:696,t:1527030927881};\\\", \\\"{x:1425,y:695,t:1527030927898};\\\", \\\"{x:1424,y:694,t:1527030927915};\\\", \\\"{x:1423,y:694,t:1527030927932};\\\", \\\"{x:1422,y:694,t:1527030927948};\\\", \\\"{x:1421,y:694,t:1527030927964};\\\", \\\"{x:1419,y:694,t:1527030927982};\\\", \\\"{x:1418,y:693,t:1527030928038};\\\", \\\"{x:1417,y:693,t:1527030928111};\\\", \\\"{x:1416,y:693,t:1527030928118};\\\", \\\"{x:1415,y:693,t:1527030928150};\\\", \\\"{x:1415,y:692,t:1527030928164};\\\", \\\"{x:1411,y:692,t:1527030928181};\\\", \\\"{x:1403,y:692,t:1527030928198};\\\", \\\"{x:1389,y:692,t:1527030928214};\\\", \\\"{x:1364,y:692,t:1527030928232};\\\", \\\"{x:1318,y:692,t:1527030928247};\\\", \\\"{x:1238,y:682,t:1527030928264};\\\", \\\"{x:1144,y:671,t:1527030928281};\\\", \\\"{x:1044,y:659,t:1527030928297};\\\", \\\"{x:939,y:643,t:1527030928315};\\\", \\\"{x:836,y:629,t:1527030928331};\\\", \\\"{x:737,y:619,t:1527030928349};\\\", \\\"{x:640,y:608,t:1527030928364};\\\", \\\"{x:557,y:595,t:1527030928381};\\\", \\\"{x:477,y:584,t:1527030928399};\\\", \\\"{x:457,y:580,t:1527030928414};\\\", \\\"{x:450,y:579,t:1527030928432};\\\", \\\"{x:447,y:578,t:1527030928448};\\\", \\\"{x:445,y:577,t:1527030928469};\\\", \\\"{x:443,y:576,t:1527030928486};\\\", \\\"{x:440,y:576,t:1527030928499};\\\", \\\"{x:435,y:574,t:1527030928515};\\\", \\\"{x:426,y:572,t:1527030928531};\\\", \\\"{x:418,y:571,t:1527030928548};\\\", \\\"{x:407,y:570,t:1527030928565};\\\", \\\"{x:404,y:569,t:1527030928581};\\\", \\\"{x:403,y:569,t:1527030928632};\\\", \\\"{x:401,y:569,t:1527030928649};\\\", \\\"{x:396,y:571,t:1527030928665};\\\", \\\"{x:389,y:577,t:1527030928682};\\\", \\\"{x:383,y:581,t:1527030928699};\\\", \\\"{x:375,y:584,t:1527030928715};\\\", \\\"{x:370,y:587,t:1527030928732};\\\", \\\"{x:366,y:590,t:1527030928748};\\\", \\\"{x:361,y:592,t:1527030928765};\\\", \\\"{x:359,y:592,t:1527030928782};\\\", \\\"{x:353,y:592,t:1527030928799};\\\", \\\"{x:348,y:592,t:1527030928815};\\\", \\\"{x:336,y:592,t:1527030928833};\\\", \\\"{x:322,y:591,t:1527030928848};\\\", \\\"{x:310,y:590,t:1527030928865};\\\", \\\"{x:294,y:586,t:1527030928882};\\\", \\\"{x:275,y:584,t:1527030928898};\\\", \\\"{x:257,y:581,t:1527030928916};\\\", \\\"{x:237,y:579,t:1527030928933};\\\", \\\"{x:216,y:576,t:1527030928949};\\\", \\\"{x:196,y:576,t:1527030928965};\\\", \\\"{x:187,y:576,t:1527030928982};\\\", \\\"{x:183,y:576,t:1527030928998};\\\", \\\"{x:180,y:576,t:1527030929015};\\\", \\\"{x:180,y:577,t:1527030929038};\\\", \\\"{x:179,y:577,t:1527030929048};\\\", \\\"{x:176,y:578,t:1527030929066};\\\", \\\"{x:175,y:580,t:1527030929082};\\\", \\\"{x:172,y:583,t:1527030929098};\\\", \\\"{x:167,y:587,t:1527030929116};\\\", \\\"{x:164,y:591,t:1527030929133};\\\", \\\"{x:161,y:596,t:1527030929148};\\\", \\\"{x:156,y:602,t:1527030929165};\\\", \\\"{x:153,y:606,t:1527030929183};\\\", \\\"{x:151,y:610,t:1527030929201};\\\", \\\"{x:149,y:613,t:1527030929215};\\\", \\\"{x:147,y:617,t:1527030929234};\\\", \\\"{x:146,y:617,t:1527030929250};\\\", \\\"{x:150,y:614,t:1527030929343};\\\", \\\"{x:157,y:609,t:1527030929349};\\\", \\\"{x:175,y:599,t:1527030929365};\\\", \\\"{x:202,y:583,t:1527030929382};\\\", \\\"{x:224,y:572,t:1527030929400};\\\", \\\"{x:244,y:563,t:1527030929416};\\\", \\\"{x:258,y:558,t:1527030929433};\\\", \\\"{x:269,y:554,t:1527030929449};\\\", \\\"{x:278,y:551,t:1527030929466};\\\", \\\"{x:283,y:550,t:1527030929483};\\\", \\\"{x:289,y:546,t:1527030929498};\\\", \\\"{x:299,y:542,t:1527030929515};\\\", \\\"{x:314,y:536,t:1527030929533};\\\", \\\"{x:330,y:530,t:1527030929549};\\\", \\\"{x:349,y:524,t:1527030929565};\\\", \\\"{x:361,y:519,t:1527030929582};\\\", \\\"{x:377,y:511,t:1527030929600};\\\", \\\"{x:403,y:509,t:1527030929616};\\\", \\\"{x:456,y:509,t:1527030929633};\\\", \\\"{x:531,y:517,t:1527030929650};\\\", \\\"{x:597,y:533,t:1527030929666};\\\", \\\"{x:630,y:540,t:1527030929683};\\\", \\\"{x:649,y:545,t:1527030929700};\\\", \\\"{x:668,y:550,t:1527030929716};\\\", \\\"{x:683,y:556,t:1527030929733};\\\", \\\"{x:693,y:562,t:1527030929749};\\\", \\\"{x:694,y:563,t:1527030929765};\\\", \\\"{x:694,y:564,t:1527030929789};\\\", \\\"{x:695,y:564,t:1527030929805};\\\", \\\"{x:695,y:565,t:1527030929816};\\\", \\\"{x:696,y:566,t:1527030929832};\\\", \\\"{x:697,y:567,t:1527030929942};\\\", \\\"{x:702,y:564,t:1527030929950};\\\", \\\"{x:716,y:558,t:1527030929966};\\\", \\\"{x:734,y:550,t:1527030929983};\\\", \\\"{x:752,y:543,t:1527030930000};\\\", \\\"{x:772,y:533,t:1527030930017};\\\", \\\"{x:790,y:523,t:1527030930034};\\\", \\\"{x:802,y:516,t:1527030930049};\\\", \\\"{x:811,y:511,t:1527030930067};\\\", \\\"{x:811,y:510,t:1527030930083};\\\", \\\"{x:816,y:512,t:1527030931222};\\\", \\\"{x:826,y:518,t:1527030931234};\\\", \\\"{x:849,y:534,t:1527030931251};\\\", \\\"{x:887,y:560,t:1527030931267};\\\", \\\"{x:924,y:587,t:1527030931284};\\\", \\\"{x:961,y:620,t:1527030931301};\\\", \\\"{x:1030,y:685,t:1527030931317};\\\", \\\"{x:1091,y:743,t:1527030931333};\\\", \\\"{x:1154,y:795,t:1527030931350};\\\", \\\"{x:1213,y:840,t:1527030931368};\\\", \\\"{x:1275,y:883,t:1527030931383};\\\", \\\"{x:1317,y:913,t:1527030931401};\\\", \\\"{x:1350,y:932,t:1527030931417};\\\", \\\"{x:1378,y:949,t:1527030931433};\\\", \\\"{x:1395,y:958,t:1527030931450};\\\", \\\"{x:1407,y:965,t:1527030931467};\\\", \\\"{x:1415,y:968,t:1527030931483};\\\", \\\"{x:1418,y:969,t:1527030931500};\\\", \\\"{x:1419,y:969,t:1527030931518};\\\", \\\"{x:1421,y:969,t:1527030931533};\\\", \\\"{x:1422,y:969,t:1527030931551};\\\", \\\"{x:1428,y:969,t:1527030931568};\\\", \\\"{x:1438,y:966,t:1527030931585};\\\", \\\"{x:1452,y:961,t:1527030931601};\\\", \\\"{x:1464,y:956,t:1527030931618};\\\", \\\"{x:1475,y:949,t:1527030931635};\\\", \\\"{x:1485,y:940,t:1527030931651};\\\", \\\"{x:1490,y:930,t:1527030931668};\\\", \\\"{x:1491,y:915,t:1527030931685};\\\", \\\"{x:1491,y:903,t:1527030931701};\\\", \\\"{x:1491,y:893,t:1527030931718};\\\", \\\"{x:1492,y:888,t:1527030931735};\\\", \\\"{x:1493,y:887,t:1527030931751};\\\", \\\"{x:1493,y:888,t:1527030931910};\\\", \\\"{x:1493,y:890,t:1527030931918};\\\", \\\"{x:1493,y:899,t:1527030931935};\\\", \\\"{x:1493,y:911,t:1527030931951};\\\", \\\"{x:1493,y:921,t:1527030931968};\\\", \\\"{x:1492,y:934,t:1527030931985};\\\", \\\"{x:1491,y:944,t:1527030932001};\\\", \\\"{x:1490,y:948,t:1527030932017};\\\", \\\"{x:1490,y:945,t:1527030932134};\\\", \\\"{x:1490,y:929,t:1527030932152};\\\", \\\"{x:1488,y:908,t:1527030932168};\\\", \\\"{x:1482,y:890,t:1527030932185};\\\", \\\"{x:1482,y:876,t:1527030932202};\\\", \\\"{x:1482,y:863,t:1527030932218};\\\", \\\"{x:1482,y:852,t:1527030932234};\\\", \\\"{x:1482,y:844,t:1527030932252};\\\", \\\"{x:1482,y:835,t:1527030932267};\\\", \\\"{x:1482,y:828,t:1527030932285};\\\", \\\"{x:1481,y:819,t:1527030932302};\\\", \\\"{x:1481,y:813,t:1527030932317};\\\", \\\"{x:1481,y:809,t:1527030932334};\\\", \\\"{x:1481,y:805,t:1527030932352};\\\", \\\"{x:1481,y:800,t:1527030932368};\\\", \\\"{x:1480,y:794,t:1527030932384};\\\", \\\"{x:1477,y:786,t:1527030932402};\\\", \\\"{x:1477,y:778,t:1527030932418};\\\", \\\"{x:1474,y:766,t:1527030932434};\\\", \\\"{x:1473,y:757,t:1527030932452};\\\", \\\"{x:1470,y:748,t:1527030932468};\\\", \\\"{x:1468,y:745,t:1527030932485};\\\", \\\"{x:1465,y:738,t:1527030932501};\\\", \\\"{x:1464,y:734,t:1527030932519};\\\", \\\"{x:1463,y:730,t:1527030932535};\\\", \\\"{x:1462,y:725,t:1527030932552};\\\", \\\"{x:1462,y:723,t:1527030932569};\\\", \\\"{x:1462,y:722,t:1527030932590};\\\", \\\"{x:1462,y:721,t:1527030932686};\\\", \\\"{x:1462,y:719,t:1527030932702};\\\", \\\"{x:1462,y:717,t:1527030932719};\\\", \\\"{x:1462,y:715,t:1527030932735};\\\", \\\"{x:1462,y:713,t:1527030932751};\\\", \\\"{x:1462,y:712,t:1527030932782};\\\", \\\"{x:1462,y:711,t:1527030932798};\\\", \\\"{x:1462,y:710,t:1527030932806};\\\", \\\"{x:1463,y:708,t:1527030932822};\\\", \\\"{x:1464,y:707,t:1527030932838};\\\", \\\"{x:1465,y:705,t:1527030932853};\\\", \\\"{x:1467,y:701,t:1527030932869};\\\", \\\"{x:1470,y:695,t:1527030932885};\\\", \\\"{x:1471,y:688,t:1527030932902};\\\", \\\"{x:1471,y:685,t:1527030932918};\\\", \\\"{x:1471,y:683,t:1527030932935};\\\", \\\"{x:1471,y:682,t:1527030933071};\\\", \\\"{x:1471,y:681,t:1527030933087};\\\", \\\"{x:1473,y:679,t:1527030933103};\\\", \\\"{x:1474,y:678,t:1527030933120};\\\", \\\"{x:1475,y:677,t:1527030933136};\\\", \\\"{x:1476,y:676,t:1527030933166};\\\", \\\"{x:1475,y:676,t:1527030933302};\\\", \\\"{x:1455,y:675,t:1527030933319};\\\", \\\"{x:1420,y:668,t:1527030933335};\\\", \\\"{x:1342,y:658,t:1527030933352};\\\", \\\"{x:1246,y:638,t:1527030933369};\\\", \\\"{x:1133,y:607,t:1527030933386};\\\", \\\"{x:1039,y:580,t:1527030933401};\\\", \\\"{x:969,y:558,t:1527030933418};\\\", \\\"{x:915,y:539,t:1527030933437};\\\", \\\"{x:895,y:527,t:1527030933453};\\\", \\\"{x:880,y:518,t:1527030933464};\\\", \\\"{x:871,y:512,t:1527030933480};\\\", \\\"{x:866,y:507,t:1527030933497};\\\", \\\"{x:863,y:506,t:1527030933513};\\\", \\\"{x:861,y:506,t:1527030933529};\\\", \\\"{x:860,y:506,t:1527030933553};\\\", \\\"{x:858,y:506,t:1527030933581};\\\", \\\"{x:857,y:506,t:1527030933645};\\\", \\\"{x:855,y:506,t:1527030933678};\\\", \\\"{x:855,y:507,t:1527030933685};\\\", \\\"{x:853,y:508,t:1527030933702};\\\", \\\"{x:851,y:508,t:1527030933718};\\\", \\\"{x:851,y:509,t:1527030933736};\\\", \\\"{x:857,y:509,t:1527030934005};\\\", \\\"{x:874,y:511,t:1527030934020};\\\", \\\"{x:925,y:519,t:1527030934037};\\\", \\\"{x:1047,y:555,t:1527030934053};\\\", \\\"{x:1260,y:598,t:1527030934069};\\\", \\\"{x:1412,y:638,t:1527030934086};\\\", \\\"{x:1542,y:674,t:1527030934103};\\\", \\\"{x:1639,y:702,t:1527030934120};\\\", \\\"{x:1685,y:720,t:1527030934135};\\\", \\\"{x:1703,y:732,t:1527030934153};\\\", \\\"{x:1706,y:739,t:1527030934170};\\\", \\\"{x:1706,y:748,t:1527030934187};\\\", \\\"{x:1703,y:754,t:1527030934203};\\\", \\\"{x:1701,y:758,t:1527030934219};\\\", \\\"{x:1700,y:763,t:1527030934237};\\\", \\\"{x:1699,y:766,t:1527030934252};\\\", \\\"{x:1697,y:768,t:1527030934269};\\\", \\\"{x:1695,y:769,t:1527030934287};\\\", \\\"{x:1689,y:769,t:1527030934303};\\\", \\\"{x:1679,y:770,t:1527030934319};\\\", \\\"{x:1658,y:770,t:1527030934337};\\\", \\\"{x:1633,y:770,t:1527030934353};\\\", \\\"{x:1611,y:770,t:1527030934370};\\\", \\\"{x:1597,y:773,t:1527030934387};\\\", \\\"{x:1588,y:775,t:1527030934403};\\\", \\\"{x:1581,y:776,t:1527030934420};\\\", \\\"{x:1574,y:779,t:1527030934437};\\\", \\\"{x:1566,y:784,t:1527030934453};\\\", \\\"{x:1545,y:803,t:1527030934470};\\\", \\\"{x:1531,y:816,t:1527030934487};\\\", \\\"{x:1517,y:827,t:1527030934502};\\\", \\\"{x:1508,y:836,t:1527030934520};\\\", \\\"{x:1501,y:840,t:1527030934537};\\\", \\\"{x:1499,y:841,t:1527030934553};\\\", \\\"{x:1497,y:841,t:1527030934614};\\\", \\\"{x:1496,y:841,t:1527030934623};\\\", \\\"{x:1494,y:841,t:1527030934637};\\\", \\\"{x:1492,y:840,t:1527030934653};\\\", \\\"{x:1491,y:840,t:1527030934670};\\\", \\\"{x:1488,y:843,t:1527030934687};\\\", \\\"{x:1484,y:853,t:1527030934704};\\\", \\\"{x:1476,y:865,t:1527030934720};\\\", \\\"{x:1474,y:874,t:1527030934737};\\\", \\\"{x:1471,y:888,t:1527030934753};\\\", \\\"{x:1469,y:905,t:1527030934769};\\\", \\\"{x:1465,y:924,t:1527030934787};\\\", \\\"{x:1463,y:946,t:1527030934803};\\\", \\\"{x:1460,y:972,t:1527030934820};\\\", \\\"{x:1455,y:1003,t:1527030934836};\\\", \\\"{x:1453,y:1022,t:1527030934853};\\\", \\\"{x:1450,y:1038,t:1527030934870};\\\", \\\"{x:1450,y:1039,t:1527030934886};\\\", \\\"{x:1452,y:1039,t:1527030934925};\\\", \\\"{x:1453,y:1039,t:1527030934937};\\\", \\\"{x:1454,y:1033,t:1527030934954};\\\", \\\"{x:1454,y:1029,t:1527030934969};\\\", \\\"{x:1454,y:1028,t:1527030934987};\\\", \\\"{x:1454,y:1025,t:1527030935005};\\\", \\\"{x:1454,y:1023,t:1527030935020};\\\", \\\"{x:1454,y:1021,t:1527030935037};\\\", \\\"{x:1456,y:1017,t:1527030935054};\\\", \\\"{x:1463,y:1011,t:1527030935070};\\\", \\\"{x:1469,y:1002,t:1527030935087};\\\", \\\"{x:1477,y:990,t:1527030935104};\\\", \\\"{x:1485,y:977,t:1527030935120};\\\", \\\"{x:1486,y:966,t:1527030935137};\\\", \\\"{x:1486,y:962,t:1527030935154};\\\", \\\"{x:1486,y:958,t:1527030935170};\\\", \\\"{x:1485,y:955,t:1527030935187};\\\", \\\"{x:1485,y:954,t:1527030935239};\\\", \\\"{x:1485,y:949,t:1527030935254};\\\", \\\"{x:1485,y:943,t:1527030935270};\\\", \\\"{x:1487,y:936,t:1527030935287};\\\", \\\"{x:1489,y:929,t:1527030935304};\\\", \\\"{x:1491,y:922,t:1527030935321};\\\", \\\"{x:1491,y:914,t:1527030935337};\\\", \\\"{x:1492,y:906,t:1527030935354};\\\", \\\"{x:1493,y:898,t:1527030935370};\\\", \\\"{x:1494,y:888,t:1527030935387};\\\", \\\"{x:1494,y:877,t:1527030935404};\\\", \\\"{x:1495,y:871,t:1527030935420};\\\", \\\"{x:1496,y:864,t:1527030935436};\\\", \\\"{x:1496,y:853,t:1527030935453};\\\", \\\"{x:1498,y:849,t:1527030935469};\\\", \\\"{x:1498,y:847,t:1527030935486};\\\", \\\"{x:1498,y:844,t:1527030935504};\\\", \\\"{x:1498,y:843,t:1527030935526};\\\", \\\"{x:1498,y:842,t:1527030935536};\\\", \\\"{x:1498,y:839,t:1527030935554};\\\", \\\"{x:1498,y:838,t:1527030935571};\\\", \\\"{x:1499,y:833,t:1527030935587};\\\", \\\"{x:1499,y:829,t:1527030935603};\\\", \\\"{x:1500,y:825,t:1527030935621};\\\", \\\"{x:1500,y:820,t:1527030935637};\\\", \\\"{x:1500,y:813,t:1527030935653};\\\", \\\"{x:1500,y:807,t:1527030935671};\\\", \\\"{x:1500,y:802,t:1527030935687};\\\", \\\"{x:1500,y:797,t:1527030935704};\\\", \\\"{x:1500,y:789,t:1527030935721};\\\", \\\"{x:1500,y:783,t:1527030935737};\\\", \\\"{x:1500,y:779,t:1527030935754};\\\", \\\"{x:1500,y:776,t:1527030935771};\\\", \\\"{x:1500,y:773,t:1527030935786};\\\", \\\"{x:1500,y:771,t:1527030935804};\\\", \\\"{x:1498,y:763,t:1527030935821};\\\", \\\"{x:1497,y:760,t:1527030935837};\\\", \\\"{x:1497,y:750,t:1527030935854};\\\", \\\"{x:1497,y:743,t:1527030935871};\\\", \\\"{x:1497,y:736,t:1527030935887};\\\", \\\"{x:1497,y:730,t:1527030935904};\\\", \\\"{x:1497,y:725,t:1527030935921};\\\", \\\"{x:1497,y:722,t:1527030935937};\\\", \\\"{x:1496,y:720,t:1527030935954};\\\", \\\"{x:1495,y:719,t:1527030935971};\\\", \\\"{x:1495,y:718,t:1527030935988};\\\", \\\"{x:1494,y:717,t:1527030936279};\\\", \\\"{x:1493,y:715,t:1527030936289};\\\", \\\"{x:1493,y:714,t:1527030936304};\\\", \\\"{x:1493,y:713,t:1527030936350};\\\", \\\"{x:1493,y:712,t:1527030936374};\\\", \\\"{x:1491,y:711,t:1527030936389};\\\", \\\"{x:1490,y:708,t:1527030936404};\\\", \\\"{x:1487,y:704,t:1527030936421};\\\", \\\"{x:1482,y:696,t:1527030936439};\\\", \\\"{x:1480,y:693,t:1527030936454};\\\", \\\"{x:1478,y:690,t:1527030936471};\\\", \\\"{x:1477,y:689,t:1527030936488};\\\", \\\"{x:1475,y:688,t:1527030936505};\\\", \\\"{x:1475,y:687,t:1527030936522};\\\", \\\"{x:1474,y:685,t:1527030936538};\\\", \\\"{x:1472,y:683,t:1527030936555};\\\", \\\"{x:1472,y:682,t:1527030936571};\\\", \\\"{x:1472,y:681,t:1527030936588};\\\", \\\"{x:1473,y:681,t:1527030936935};\\\", \\\"{x:1473,y:682,t:1527030936943};\\\", \\\"{x:1474,y:682,t:1527030937037};\\\", \\\"{x:1474,y:680,t:1527030937839};\\\", \\\"{x:1474,y:676,t:1527030937855};\\\", \\\"{x:1477,y:668,t:1527030937872};\\\", \\\"{x:1477,y:664,t:1527030937888};\\\", \\\"{x:1478,y:657,t:1527030937905};\\\", \\\"{x:1478,y:654,t:1527030937922};\\\", \\\"{x:1481,y:649,t:1527030937939};\\\", \\\"{x:1482,y:645,t:1527030937956};\\\", \\\"{x:1484,y:642,t:1527030937973};\\\", \\\"{x:1486,y:637,t:1527030937988};\\\", \\\"{x:1489,y:630,t:1527030938006};\\\", \\\"{x:1489,y:621,t:1527030938023};\\\", \\\"{x:1491,y:611,t:1527030938038};\\\", \\\"{x:1492,y:604,t:1527030938056};\\\", \\\"{x:1493,y:596,t:1527030938072};\\\", \\\"{x:1493,y:590,t:1527030938089};\\\", \\\"{x:1493,y:587,t:1527030938106};\\\", \\\"{x:1493,y:585,t:1527030938123};\\\", \\\"{x:1493,y:582,t:1527030938139};\\\", \\\"{x:1493,y:580,t:1527030938155};\\\", \\\"{x:1493,y:579,t:1527030938172};\\\", \\\"{x:1492,y:576,t:1527030938189};\\\", \\\"{x:1491,y:574,t:1527030938206};\\\", \\\"{x:1490,y:572,t:1527030938222};\\\", \\\"{x:1490,y:571,t:1527030938239};\\\", \\\"{x:1489,y:571,t:1527030938255};\\\", \\\"{x:1489,y:570,t:1527030938273};\\\", \\\"{x:1488,y:569,t:1527030938290};\\\", \\\"{x:1488,y:567,t:1527030938306};\\\", \\\"{x:1486,y:565,t:1527030938323};\\\", \\\"{x:1485,y:563,t:1527030938340};\\\", \\\"{x:1485,y:562,t:1527030938355};\\\", \\\"{x:1483,y:560,t:1527030938372};\\\", \\\"{x:1482,y:560,t:1527030938389};\\\", \\\"{x:1481,y:559,t:1527030938406};\\\", \\\"{x:1480,y:557,t:1527030938422};\\\", \\\"{x:1479,y:556,t:1527030938494};\\\", \\\"{x:1478,y:556,t:1527030940015};\\\", \\\"{x:1477,y:556,t:1527030940023};\\\", \\\"{x:1472,y:556,t:1527030940041};\\\", \\\"{x:1466,y:556,t:1527030940056};\\\", \\\"{x:1458,y:557,t:1527030940073};\\\", \\\"{x:1455,y:558,t:1527030940091};\\\", \\\"{x:1453,y:558,t:1527030940107};\\\", \\\"{x:1452,y:558,t:1527030940123};\\\", \\\"{x:1451,y:558,t:1527030940140};\\\", \\\"{x:1450,y:558,t:1527030940157};\\\", \\\"{x:1447,y:558,t:1527030940174};\\\", \\\"{x:1444,y:558,t:1527030940190};\\\", \\\"{x:1440,y:557,t:1527030940206};\\\", \\\"{x:1438,y:557,t:1527030940223};\\\", \\\"{x:1437,y:556,t:1527030940262};\\\", \\\"{x:1436,y:556,t:1527030940294};\\\", \\\"{x:1435,y:556,t:1527030940306};\\\", \\\"{x:1433,y:556,t:1527030940323};\\\", \\\"{x:1431,y:556,t:1527030940341};\\\", \\\"{x:1429,y:556,t:1527030940357};\\\", \\\"{x:1428,y:556,t:1527030940373};\\\", \\\"{x:1426,y:556,t:1527030940390};\\\", \\\"{x:1425,y:556,t:1527030940406};\\\", \\\"{x:1424,y:556,t:1527030940430};\\\", \\\"{x:1422,y:556,t:1527030940441};\\\", \\\"{x:1420,y:556,t:1527030940457};\\\", \\\"{x:1417,y:557,t:1527030940474};\\\", \\\"{x:1416,y:557,t:1527030940493};\\\", \\\"{x:1415,y:558,t:1527030940506};\\\", \\\"{x:1412,y:559,t:1527030940523};\\\", \\\"{x:1411,y:559,t:1527030940540};\\\", \\\"{x:1409,y:559,t:1527030940556};\\\", \\\"{x:1408,y:560,t:1527030940573};\\\", \\\"{x:1406,y:561,t:1527030940590};\\\", \\\"{x:1405,y:561,t:1527030940942};\\\", \\\"{x:1399,y:561,t:1527030940957};\\\", \\\"{x:1390,y:561,t:1527030940974};\\\", \\\"{x:1380,y:561,t:1527030940990};\\\", \\\"{x:1368,y:561,t:1527030941007};\\\", \\\"{x:1359,y:561,t:1527030941023};\\\", \\\"{x:1357,y:561,t:1527030941040};\\\", \\\"{x:1355,y:561,t:1527030941238};\\\", \\\"{x:1352,y:561,t:1527030941254};\\\", \\\"{x:1348,y:561,t:1527030941262};\\\", \\\"{x:1345,y:561,t:1527030941273};\\\", \\\"{x:1334,y:561,t:1527030941290};\\\", \\\"{x:1319,y:561,t:1527030941307};\\\", \\\"{x:1310,y:561,t:1527030941324};\\\", \\\"{x:1307,y:561,t:1527030941340};\\\", \\\"{x:1308,y:561,t:1527030941574};\\\", \\\"{x:1311,y:561,t:1527030941590};\\\", \\\"{x:1313,y:561,t:1527030941607};\\\", \\\"{x:1314,y:561,t:1527030941625};\\\", \\\"{x:1316,y:561,t:1527030941640};\\\", \\\"{x:1317,y:561,t:1527030941670};\\\", \\\"{x:1318,y:561,t:1527030941710};\\\", \\\"{x:1319,y:561,t:1527030941724};\\\", \\\"{x:1320,y:562,t:1527030941740};\\\", \\\"{x:1322,y:563,t:1527030941758};\\\", \\\"{x:1320,y:563,t:1527030941846};\\\", \\\"{x:1316,y:564,t:1527030941858};\\\", \\\"{x:1297,y:564,t:1527030941875};\\\", \\\"{x:1271,y:564,t:1527030941890};\\\", \\\"{x:1239,y:564,t:1527030941908};\\\", \\\"{x:1211,y:564,t:1527030941924};\\\", \\\"{x:1191,y:559,t:1527030941940};\\\", \\\"{x:1178,y:557,t:1527030941958};\\\", \\\"{x:1180,y:557,t:1527030942102};\\\", \\\"{x:1181,y:557,t:1527030942109};\\\", \\\"{x:1184,y:557,t:1527030942124};\\\", \\\"{x:1189,y:557,t:1527030942141};\\\", \\\"{x:1190,y:557,t:1527030942165};\\\", \\\"{x:1188,y:557,t:1527030942230};\\\", \\\"{x:1182,y:557,t:1527030942242};\\\", \\\"{x:1165,y:557,t:1527030942257};\\\", \\\"{x:1140,y:557,t:1527030942274};\\\", \\\"{x:1110,y:557,t:1527030942291};\\\", \\\"{x:1078,y:557,t:1527030942307};\\\", \\\"{x:1041,y:564,t:1527030942324};\\\", \\\"{x:963,y:593,t:1527030942341};\\\", \\\"{x:929,y:607,t:1527030942358};\\\", \\\"{x:911,y:615,t:1527030942375};\\\", \\\"{x:901,y:619,t:1527030942390};\\\", \\\"{x:898,y:620,t:1527030942410};\\\", \\\"{x:896,y:621,t:1527030942426};\\\", \\\"{x:892,y:620,t:1527030942443};\\\", \\\"{x:887,y:616,t:1527030942460};\\\", \\\"{x:883,y:611,t:1527030942476};\\\", \\\"{x:878,y:605,t:1527030942494};\\\", \\\"{x:865,y:600,t:1527030942511};\\\", \\\"{x:845,y:598,t:1527030942526};\\\", \\\"{x:821,y:598,t:1527030942543};\\\", \\\"{x:785,y:603,t:1527030942560};\\\", \\\"{x:730,y:617,t:1527030942577};\\\", \\\"{x:687,y:624,t:1527030942593};\\\", \\\"{x:649,y:628,t:1527030942610};\\\", \\\"{x:609,y:635,t:1527030942626};\\\", \\\"{x:580,y:638,t:1527030942644};\\\", \\\"{x:564,y:638,t:1527030942660};\\\", \\\"{x:562,y:637,t:1527030942675};\\\", \\\"{x:562,y:634,t:1527030942701};\\\", \\\"{x:564,y:630,t:1527030942710};\\\", \\\"{x:566,y:624,t:1527030942726};\\\", \\\"{x:569,y:617,t:1527030942743};\\\", \\\"{x:570,y:606,t:1527030942761};\\\", \\\"{x:570,y:596,t:1527030942776};\\\", \\\"{x:571,y:587,t:1527030942793};\\\", \\\"{x:573,y:579,t:1527030942810};\\\", \\\"{x:577,y:573,t:1527030942828};\\\", \\\"{x:583,y:564,t:1527030942844};\\\", \\\"{x:589,y:557,t:1527030942860};\\\", \\\"{x:598,y:546,t:1527030942877};\\\", \\\"{x:600,y:539,t:1527030942893};\\\", \\\"{x:602,y:535,t:1527030942911};\\\", \\\"{x:603,y:532,t:1527030942927};\\\", \\\"{x:604,y:531,t:1527030942944};\\\", \\\"{x:605,y:530,t:1527030942959};\\\", \\\"{x:607,y:529,t:1527030942976};\\\", \\\"{x:608,y:527,t:1527030942994};\\\", \\\"{x:612,y:525,t:1527030943010};\\\", \\\"{x:614,y:523,t:1527030943027};\\\", \\\"{x:617,y:520,t:1527030943042};\\\", \\\"{x:617,y:519,t:1527030943060};\\\", \\\"{x:617,y:518,t:1527030943077};\\\", \\\"{x:626,y:519,t:1527030943469};\\\", \\\"{x:646,y:527,t:1527030943478};\\\", \\\"{x:737,y:566,t:1527030943494};\\\", \\\"{x:878,y:626,t:1527030943511};\\\", \\\"{x:1037,y:684,t:1527030943528};\\\", \\\"{x:1213,y:734,t:1527030943544};\\\", \\\"{x:1396,y:786,t:1527030943560};\\\", \\\"{x:1572,y:831,t:1527030943577};\\\", \\\"{x:1726,y:869,t:1527030943594};\\\", \\\"{x:1832,y:885,t:1527030943610};\\\", \\\"{x:1888,y:892,t:1527030943627};\\\", \\\"{x:1906,y:895,t:1527030943644};\\\", \\\"{x:1906,y:896,t:1527030943660};\\\", \\\"{x:1895,y:891,t:1527030943677};\\\", \\\"{x:1876,y:884,t:1527030943694};\\\", \\\"{x:1854,y:874,t:1527030943711};\\\", \\\"{x:1836,y:864,t:1527030943727};\\\", \\\"{x:1821,y:857,t:1527030943744};\\\", \\\"{x:1811,y:852,t:1527030943761};\\\", \\\"{x:1807,y:848,t:1527030943777};\\\", \\\"{x:1806,y:846,t:1527030943794};\\\", \\\"{x:1805,y:842,t:1527030943811};\\\", \\\"{x:1803,y:840,t:1527030943828};\\\", \\\"{x:1798,y:837,t:1527030943844};\\\", \\\"{x:1793,y:836,t:1527030943861};\\\", \\\"{x:1789,y:836,t:1527030943878};\\\", \\\"{x:1778,y:844,t:1527030943894};\\\", \\\"{x:1764,y:867,t:1527030943911};\\\", \\\"{x:1739,y:907,t:1527030943927};\\\", \\\"{x:1734,y:915,t:1527030943945};\\\", \\\"{x:1728,y:919,t:1527030943961};\\\", \\\"{x:1730,y:916,t:1527030944118};\\\", \\\"{x:1731,y:915,t:1527030944128};\\\", \\\"{x:1733,y:914,t:1527030944150};\\\", \\\"{x:1733,y:912,t:1527030944165};\\\", \\\"{x:1733,y:911,t:1527030944181};\\\", \\\"{x:1733,y:910,t:1527030944194};\\\", \\\"{x:1733,y:908,t:1527030944211};\\\", \\\"{x:1733,y:906,t:1527030944227};\\\", \\\"{x:1733,y:902,t:1527030944244};\\\", \\\"{x:1727,y:899,t:1527030944261};\\\", \\\"{x:1718,y:899,t:1527030944278};\\\", \\\"{x:1702,y:899,t:1527030944294};\\\", \\\"{x:1679,y:899,t:1527030944311};\\\", \\\"{x:1651,y:903,t:1527030944329};\\\", \\\"{x:1619,y:908,t:1527030944345};\\\", \\\"{x:1586,y:913,t:1527030944362};\\\", \\\"{x:1559,y:915,t:1527030944378};\\\", \\\"{x:1541,y:915,t:1527030944395};\\\", \\\"{x:1529,y:915,t:1527030944412};\\\", \\\"{x:1519,y:915,t:1527030944428};\\\", \\\"{x:1515,y:915,t:1527030944445};\\\", \\\"{x:1518,y:914,t:1527030944485};\\\", \\\"{x:1529,y:911,t:1527030944495};\\\", \\\"{x:1567,y:905,t:1527030944512};\\\", \\\"{x:1609,y:897,t:1527030944528};\\\", \\\"{x:1615,y:887,t:1527030944546};\\\", \\\"{x:1615,y:885,t:1527030945183};\\\", \\\"{x:1616,y:884,t:1527030945196};\\\", \\\"{x:1616,y:883,t:1527030945247};\\\", \\\"{x:1616,y:881,t:1527030945263};\\\", \\\"{x:1616,y:878,t:1527030945280};\\\", \\\"{x:1617,y:872,t:1527030945295};\\\", \\\"{x:1617,y:867,t:1527030945312};\\\", \\\"{x:1617,y:864,t:1527030945330};\\\", \\\"{x:1617,y:862,t:1527030945346};\\\", \\\"{x:1617,y:853,t:1527030945362};\\\", \\\"{x:1615,y:849,t:1527030945379};\\\", \\\"{x:1612,y:843,t:1527030945396};\\\", \\\"{x:1608,y:839,t:1527030945412};\\\", \\\"{x:1604,y:831,t:1527030945429};\\\", \\\"{x:1603,y:829,t:1527030945445};\\\", \\\"{x:1601,y:826,t:1527030945462};\\\", \\\"{x:1596,y:824,t:1527030945479};\\\", \\\"{x:1581,y:817,t:1527030945495};\\\", \\\"{x:1559,y:808,t:1527030945513};\\\", \\\"{x:1535,y:798,t:1527030945529};\\\", \\\"{x:1511,y:791,t:1527030945545};\\\", \\\"{x:1482,y:782,t:1527030945562};\\\", \\\"{x:1441,y:772,t:1527030945579};\\\", \\\"{x:1388,y:764,t:1527030945596};\\\", \\\"{x:1307,y:753,t:1527030945613};\\\", \\\"{x:1138,y:737,t:1527030945629};\\\", \\\"{x:1003,y:737,t:1527030945645};\\\", \\\"{x:859,y:737,t:1527030945663};\\\", \\\"{x:718,y:737,t:1527030945679};\\\", \\\"{x:585,y:737,t:1527030945696};\\\", \\\"{x:477,y:737,t:1527030945713};\\\", \\\"{x:396,y:737,t:1527030945730};\\\", \\\"{x:360,y:737,t:1527030945746};\\\", \\\"{x:342,y:737,t:1527030945761};\\\", \\\"{x:324,y:737,t:1527030945778};\\\", \\\"{x:323,y:737,t:1527030945805};\\\", \\\"{x:326,y:737,t:1527030945933};\\\", \\\"{x:327,y:737,t:1527030945949};\\\", \\\"{x:328,y:737,t:1527030945962};\\\", \\\"{x:330,y:737,t:1527030946022};\\\", \\\"{x:331,y:737,t:1527030946030};\\\", \\\"{x:333,y:738,t:1527030946045};\\\", \\\"{x:341,y:740,t:1527030946062};\\\", \\\"{x:349,y:742,t:1527030946078};\\\", \\\"{x:362,y:745,t:1527030946094};\\\", \\\"{x:374,y:746,t:1527030946112};\\\", \\\"{x:387,y:748,t:1527030946129};\\\", \\\"{x:404,y:750,t:1527030946144};\\\", \\\"{x:422,y:750,t:1527030946161};\\\", \\\"{x:443,y:750,t:1527030946178};\\\", \\\"{x:465,y:750,t:1527030946194};\\\", \\\"{x:484,y:752,t:1527030946211};\\\", \\\"{x:507,y:756,t:1527030946229};\\\", \\\"{x:520,y:760,t:1527030946246};\\\", \\\"{x:529,y:762,t:1527030946262};\\\", \\\"{x:532,y:763,t:1527030946279};\\\", \\\"{x:533,y:763,t:1527030946502};\\\" ] }, { \\\"rt\\\": 56869, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 918563, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I look at the x,y axes. if there is a shift dot above the x axes point of 12pm I determine that is what starts at 12. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7422, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"25\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 926992, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 20419, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 948428, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 28223, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 977986, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"AS12V\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"AS12V\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 128, dom: 751, initialDom: 833",
  "javascriptErrors": []
}