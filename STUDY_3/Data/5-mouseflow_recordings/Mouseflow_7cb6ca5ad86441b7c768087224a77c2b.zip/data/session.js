var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7cb6ca5ad86441b7c768087224a77c2b",
  "created": "2018-05-22T16:15:47.4251801-07:00",
  "lastActivity": "2018-05-22T16:17:46.6256929-07:00",
  "pageViews": [
    {
      "id": "052247111d800e71ba9271301e04cf6ae64f72d3",
      "startTime": "2018-05-22T16:15:47.4251801-07:00",
      "endTime": "2018-05-22T16:17:46.6256929-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 119234,
      "engagementTime": 108388,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 119234,
  "engagementTime": 108388,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=AS12V",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4391f90578c3db8819a577aee6a8dbbd",
  "gdpr": false
}