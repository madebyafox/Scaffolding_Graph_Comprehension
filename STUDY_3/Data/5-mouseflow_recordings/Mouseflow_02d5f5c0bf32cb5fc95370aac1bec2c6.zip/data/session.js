var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "02d5f5c0bf32cb5fc95370aac1bec2c6",
  "created": "2018-05-22T13:07:39.7596455-07:00",
  "lastActivity": "2018-05-22T13:07:52.3995296-07:00",
  "pageViews": [
    {
      "id": "05223985472d2d0f44871c546b29891f421ed3e4",
      "startTime": "2018-05-22T13:07:39.8912966-07:00",
      "endTime": "2018-05-22T13:07:52.3995296-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 12553,
      "engagementTime": 12553,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12553,
  "engagementTime": 12553,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YNEMQ",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0fd93047da933127f15b06b446b40fd0",
  "gdpr": false
}