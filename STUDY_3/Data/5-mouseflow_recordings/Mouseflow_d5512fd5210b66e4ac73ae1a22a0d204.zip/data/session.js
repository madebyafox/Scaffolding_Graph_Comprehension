var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d5512fd5210b66e4ac73ae1a22a0d204",
  "created": "2018-05-22T13:11:12.4750185-07:00",
  "lastActivity": "2018-05-22T13:12:16.6362505-07:00",
  "pageViews": [
    {
      "id": "052212885d685113c7fa7d4780fa92e57f477a2d",
      "startTime": "2018-05-22T13:11:12.4750185-07:00",
      "endTime": "2018-05-22T13:12:16.6362505-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 64453,
      "engagementTime": 46885,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 64453,
  "engagementTime": 46885,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "35ae73d409c80188cda1c4f4ebf8469c",
  "gdpr": false
}