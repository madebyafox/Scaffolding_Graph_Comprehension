var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052212885d685113c7fa7d4780fa92e57f477a2d"] = {
  "startTime": "2018-05-22T20:11:12.4750185Z",
  "websitePageUrl": "/",
  "visitTime": 64453,
  "engagementTime": 46885,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "d5512fd5210b66e4ac73ae1a22a0d204",
    "created": "2018-05-22T20:11:12.4750185+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "35ae73d409c80188cda1c4f4ebf8469c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d5512fd5210b66e4ac73ae1a22a0d204/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 262,
      "e": 262,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 465,
      "y": 42
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 425,
      "y": 399
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 30637,
      "y": 22609,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 404,
      "y": 703
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 410,
      "y": 787
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 29927,
      "y": 54557,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 413,
      "y": 788
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 414,
      "y": 783
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 413,
      "y": 783
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 29982,
      "y": 54066,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 517,
      "y": 783
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 35661,
      "y": 54066,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 2,
      "x": 796,
      "y": 786
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 819,
      "y": 774
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 53793,
      "y": 51854,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2302,
      "e": 2302,
      "ty": 2,
      "x": 897,
      "y": 735
    },
    {
      "t": 2311,
      "e": 2311,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2402,
      "e": 2402,
      "ty": 2,
      "x": 922,
      "y": 729
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 0,
      "x": 971,
      "y": 1047
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 0,
      "x": 1476,
      "y": 1047
    },
    {
      "t": 3402,
      "e": 3402,
      "ty": 0,
      "x": 1519,
      "y": 1047
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1437,
      "y": 731
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1051,
      "y": 727
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 41833,
      "y": 52182,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 863,
      "y": 778
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 823,
      "y": 787
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 2,
      "x": 789,
      "y": 792
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 34405,
      "y": 54803,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4602,
      "e": 4602,
      "ty": 2,
      "x": 786,
      "y": 789
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 34242,
      "y": 54312,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4802,
      "e": 4802,
      "ty": 2,
      "x": 786,
      "y": 782
    },
    {
      "t": 4902,
      "e": 4902,
      "ty": 2,
      "x": 789,
      "y": 777
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 34405,
      "y": 53574,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 795,
      "y": 789
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 2,
      "x": 797,
      "y": 794
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 34842,
      "y": 54967,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5602,
      "e": 5602,
      "ty": 2,
      "x": 800,
      "y": 800
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 801,
      "y": 802
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 35170,
      "y": 55704,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5802,
      "e": 5802,
      "ty": 2,
      "x": 804,
      "y": 803
    },
    {
      "t": 5902,
      "e": 5902,
      "ty": 2,
      "x": 805,
      "y": 805
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 808,
      "y": 805
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 35443,
      "y": 55868,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 808,
      "y": 806
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 35443,
      "y": 55950,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7202,
      "e": 7202,
      "ty": 2,
      "x": 808,
      "y": 805
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 35443,
      "y": 55868,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8102,
      "e": 8102,
      "ty": 2,
      "x": 808,
      "y": 803
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 35443,
      "y": 55704,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8702,
      "e": 8702,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 826,
      "y": 898
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 25476,
      "y": 57220,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 2,
      "x": 851,
      "y": 851
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 41,
      "x": 26842,
      "y": 53370,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10079,
      "e": 10079,
      "ty": 3,
      "x": 865,
      "y": 838,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10102,
      "e": 10102,
      "ty": 2,
      "x": 865,
      "y": 838
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 4,
      "x": 27606,
      "y": 52305,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 5,
      "x": 865,
      "y": 838,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10252,
      "e": 10252,
      "ty": 41,
      "x": 27661,
      "y": 51977,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 2,
      "x": 870,
      "y": 757
    },
    {
      "t": 10402,
      "e": 10402,
      "ty": 2,
      "x": 869,
      "y": 569
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 2,
      "x": 852,
      "y": 551
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 41,
      "x": 26896,
      "y": 28794,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 3,
      "x": 852,
      "y": 551,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10631,
      "e": 10631,
      "ty": 4,
      "x": 26896,
      "y": 28794,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10631,
      "e": 10631,
      "ty": 5,
      "x": 852,
      "y": 551,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10752,
      "e": 10752,
      "ty": 41,
      "x": 26842,
      "y": 32071,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10802,
      "e": 10802,
      "ty": 2,
      "x": 852,
      "y": 639
    },
    {
      "t": 10870,
      "e": 10870,
      "ty": 3,
      "x": 854,
      "y": 645,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10901,
      "e": 10901,
      "ty": 2,
      "x": 854,
      "y": 645
    },
    {
      "t": 11004,
      "e": 11004,
      "ty": 2,
      "x": 862,
      "y": 645
    },
    {
      "t": 11004,
      "e": 11004,
      "ty": 41,
      "x": 27442,
      "y": 36494,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11073,
      "e": 11073,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 11102,
      "e": 11102,
      "ty": 2,
      "x": 1051,
      "y": 617
    },
    {
      "t": 11158,
      "e": 11158,
      "ty": 3,
      "x": 1267,
      "y": 567,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11201,
      "e": 11201,
      "ty": 2,
      "x": 1269,
      "y": 566
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 49888,
      "y": 30023,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11255,
      "e": 11255,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 11302,
      "e": 11302,
      "ty": 2,
      "x": 1325,
      "y": 550
    },
    {
      "t": 11342,
      "e": 11342,
      "ty": 3,
      "x": 1348,
      "y": 542,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 2,
      "x": 1339,
      "y": 547
    },
    {
      "t": 11502,
      "e": 11502,
      "ty": 2,
      "x": 662,
      "y": 618
    },
    {
      "t": 11502,
      "e": 11502,
      "ty": 41,
      "x": 16520,
      "y": 34282,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11534,
      "e": 11534,
      "ty": 3,
      "x": 642,
      "y": 622,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11602,
      "e": 11602,
      "ty": 2,
      "x": 641,
      "y": 623
    },
    {
      "t": 11639,
      "e": 11639,
      "ty": 4,
      "x": 15373,
      "y": 34692,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11639,
      "e": 11639,
      "ty": 5,
      "x": 641,
      "y": 623,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11752,
      "e": 11752,
      "ty": 41,
      "x": 15373,
      "y": 34692,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11802,
      "e": 11802,
      "ty": 2,
      "x": 647,
      "y": 627
    },
    {
      "t": 11895,
      "e": 11895,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 11902,
      "e": 11902,
      "ty": 2,
      "x": 761,
      "y": 633
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 2,
      "x": 894,
      "y": 649
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 41,
      "x": 30511,
      "y": 35509,
      "ta": "html > body"
    },
    {
      "t": 12102,
      "e": 12102,
      "ty": 2,
      "x": 1059,
      "y": 680
    },
    {
      "t": 12102,
      "e": 12102,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 12201,
      "e": 12201,
      "ty": 2,
      "x": 1096,
      "y": 688
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 41,
      "x": 37468,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 12976,
      "e": 12976,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 16701,
      "e": 16701,
      "ty": 2,
      "x": 1053,
      "y": 702
    },
    {
      "t": 16751,
      "e": 16751,
      "ty": 41,
      "x": 34366,
      "y": 30902,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 16801,
      "e": 16801,
      "ty": 2,
      "x": 983,
      "y": 846
    },
    {
      "t": 16901,
      "e": 16901,
      "ty": 2,
      "x": 1064,
      "y": 988
    },
    {
      "t": 17001,
      "e": 17001,
      "ty": 2,
      "x": 951,
      "y": 1041
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 41,
      "x": 32349,
      "y": 63340,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 17101,
      "e": 17101,
      "ty": 2,
      "x": 838,
      "y": 954
    },
    {
      "t": 17201,
      "e": 17201,
      "ty": 2,
      "x": 751,
      "y": 919
    },
    {
      "t": 17252,
      "e": 17252,
      "ty": 41,
      "x": 22362,
      "y": 20373,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 17301,
      "e": 17301,
      "ty": 2,
      "x": 771,
      "y": 905
    },
    {
      "t": 17401,
      "e": 17401,
      "ty": 2,
      "x": 809,
      "y": 901
    },
    {
      "t": 17495,
      "e": 17495,
      "ty": 3,
      "x": 816,
      "y": 904,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 2,
      "x": 816,
      "y": 904
    },
    {
      "t": 17502,
      "e": 17502,
      "ty": 41,
      "x": 25707,
      "y": 62430,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 17583,
      "e": 17583,
      "ty": 4,
      "x": 25756,
      "y": 35,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 17584,
      "e": 17584,
      "ty": 5,
      "x": 817,
      "y": 905,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 17601,
      "e": 17601,
      "ty": 2,
      "x": 817,
      "y": 905
    },
    {
      "t": 17701,
      "e": 17701,
      "ty": 2,
      "x": 817,
      "y": 912
    },
    {
      "t": 17734,
      "e": 17734,
      "ty": 3,
      "x": 817,
      "y": 912,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 17751,
      "e": 17751,
      "ty": 41,
      "x": 44440,
      "y": 3327,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 17830,
      "e": 17830,
      "ty": 4,
      "x": 44440,
      "y": 3327,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 17831,
      "e": 17831,
      "ty": 5,
      "x": 817,
      "y": 912,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 17832,
      "e": 17832,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 17836,
      "e": 17836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 17901,
      "e": 17901,
      "ty": 2,
      "x": 839,
      "y": 931
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 2,
      "x": 976,
      "y": 1027
    },
    {
      "t": 18002,
      "e": 18002,
      "ty": 41,
      "x": 33579,
      "y": 62371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 18101,
      "e": 18101,
      "ty": 2,
      "x": 996,
      "y": 1065
    },
    {
      "t": 18157,
      "e": 18157,
      "ty": 6,
      "x": 992,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 18202,
      "e": 18202,
      "ty": 2,
      "x": 986,
      "y": 1082
    },
    {
      "t": 18251,
      "e": 18251,
      "ty": 41,
      "x": 35771,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 18287,
      "e": 18287,
      "ty": 3,
      "x": 975,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 18287,
      "e": 18287,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 18288,
      "e": 18288,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 18301,
      "e": 18301,
      "ty": 2,
      "x": 975,
      "y": 1104
    },
    {
      "t": 18366,
      "e": 18366,
      "ty": 4,
      "x": 35771,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 18367,
      "e": 18367,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 18367,
      "e": 18367,
      "ty": 5,
      "x": 975,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 18368,
      "e": 18368,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 18501,
      "e": 18501,
      "ty": 41,
      "x": 33301,
      "y": 60715,
      "ta": "html > body"
    },
    {
      "t": 18601,
      "e": 18601,
      "ty": 2,
      "x": 973,
      "y": 1096
    },
    {
      "t": 18701,
      "e": 18701,
      "ty": 2,
      "x": 973,
      "y": 1093
    },
    {
      "t": 18751,
      "e": 18751,
      "ty": 41,
      "x": 33163,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 18801,
      "e": 18801,
      "ty": 2,
      "x": 941,
      "y": 1076
    },
    {
      "t": 18901,
      "e": 18901,
      "ty": 2,
      "x": 869,
      "y": 968
    },
    {
      "t": 19001,
      "e": 19001,
      "ty": 2,
      "x": 726,
      "y": 626
    },
    {
      "t": 19001,
      "e": 19001,
      "ty": 41,
      "x": 24726,
      "y": 34235,
      "ta": "html > body"
    },
    {
      "t": 19101,
      "e": 19101,
      "ty": 2,
      "x": 715,
      "y": 607
    },
    {
      "t": 19252,
      "e": 19252,
      "ty": 41,
      "x": 24347,
      "y": 33182,
      "ta": "html > body"
    },
    {
      "t": 19375,
      "e": 19375,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20202,
      "e": 20202,
      "ty": 2,
      "x": 767,
      "y": 600
    },
    {
      "t": 20206,
      "e": 20206,
      "ty": 6,
      "x": 833,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20242,
      "e": 20242,
      "ty": 7,
      "x": 936,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20251,
      "e": 20251,
      "ty": 41,
      "x": 27684,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 20301,
      "e": 20301,
      "ty": 2,
      "x": 974,
      "y": 577
    },
    {
      "t": 20402,
      "e": 20402,
      "ty": 2,
      "x": 974,
      "y": 578
    },
    {
      "t": 20501,
      "e": 20501,
      "ty": 2,
      "x": 972,
      "y": 585
    },
    {
      "t": 20502,
      "e": 20502,
      "ty": 41,
      "x": 35471,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 20534,
      "e": 20534,
      "ty": 6,
      "x": 972,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20602,
      "e": 20602,
      "ty": 2,
      "x": 968,
      "y": 603
    },
    {
      "t": 20695,
      "e": 20695,
      "ty": 3,
      "x": 968,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20696,
      "e": 20696,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20701,
      "e": 20701,
      "ty": 2,
      "x": 968,
      "y": 605
    },
    {
      "t": 20751,
      "e": 20751,
      "ty": 41,
      "x": 34605,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20790,
      "e": 20790,
      "ty": 4,
      "x": 34605,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20790,
      "e": 20790,
      "ty": 5,
      "x": 968,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25906,
      "e": 25790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "71"
    },
    {
      "t": 25907,
      "e": 25791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26050,
      "e": 25934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "g"
    },
    {
      "t": 26674,
      "e": 26558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 26674,
      "e": 26558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26807,
      "e": 26691,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "go"
    },
    {
      "t": 26826,
      "e": 26710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "go"
    },
    {
      "t": 28250,
      "e": 28134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 28251,
      "e": 28135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28338,
      "e": 28222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "go1"
    },
    {
      "t": 28602,
      "e": 28486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 28602,
      "e": 28486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28682,
      "e": 28566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "go1f"
    },
    {
      "t": 28906,
      "e": 28790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 28906,
      "e": 28790,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "go1f"
    },
    {
      "t": 28906,
      "e": 28790,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28907,
      "e": 28791,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29034,
      "e": 28918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 29266,
      "e": 29150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 29267,
      "e": 29151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29379,
      "e": 29263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 29379,
      "e": 29263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29442,
      "e": 29326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 29506,
      "e": 29390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 29538,
      "e": 29422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 29538,
      "e": 29422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29658,
      "e": 29542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 29778,
      "e": 29662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 29778,
      "e": 29662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29882,
      "e": 29766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12**"
    },
    {
      "t": 30002,
      "e": 29886,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30818,
      "e": 30702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 30818,
      "e": 30702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30874,
      "e": 30758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 31006,
      "e": 30890,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12**\n"
    },
    {
      "t": 31601,
      "e": 31485,
      "ty": 2,
      "x": 951,
      "y": 602
    },
    {
      "t": 31622,
      "e": 31506,
      "ty": 7,
      "x": 951,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31701,
      "e": 31585,
      "ty": 2,
      "x": 965,
      "y": 677
    },
    {
      "t": 31717,
      "e": 31601,
      "ty": 6,
      "x": 966,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31734,
      "e": 31618,
      "ty": 7,
      "x": 966,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31751,
      "e": 31635,
      "ty": 41,
      "x": 33957,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 31801,
      "e": 31685,
      "ty": 2,
      "x": 963,
      "y": 706
    },
    {
      "t": 32001,
      "e": 31885,
      "ty": 41,
      "x": 33524,
      "y": 64125,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 32402,
      "e": 32286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 32530,
      "e": 32414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12**"
    },
    {
      "t": 32585,
      "e": 32469,
      "ty": 6,
      "x": 954,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32601,
      "e": 32485,
      "ty": 2,
      "x": 949,
      "y": 686
    },
    {
      "t": 32635,
      "e": 32519,
      "ty": 7,
      "x": 936,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32702,
      "e": 32586,
      "ty": 2,
      "x": 898,
      "y": 651
    },
    {
      "t": 32751,
      "e": 32635,
      "ty": 41,
      "x": 15572,
      "y": 11702,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 32802,
      "e": 32686,
      "ty": 2,
      "x": 860,
      "y": 627
    },
    {
      "t": 32869,
      "e": 32753,
      "ty": 6,
      "x": 833,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32902,
      "e": 32786,
      "ty": 2,
      "x": 831,
      "y": 601
    },
    {
      "t": 33002,
      "e": 32886,
      "ty": 2,
      "x": 827,
      "y": 593
    },
    {
      "t": 33002,
      "e": 32886,
      "ty": 41,
      "x": 4109,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33102,
      "e": 32986,
      "ty": 2,
      "x": 832,
      "y": 593
    },
    {
      "t": 33185,
      "e": 33069,
      "ty": 7,
      "x": 850,
      "y": 613,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33201,
      "e": 33085,
      "ty": 2,
      "x": 850,
      "y": 613
    },
    {
      "t": 33252,
      "e": 33136,
      "ty": 41,
      "x": 14274,
      "y": 49151,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 33269,
      "e": 33153,
      "ty": 6,
      "x": 897,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33302,
      "e": 33186,
      "ty": 2,
      "x": 903,
      "y": 699
    },
    {
      "t": 33302,
      "e": 33186,
      "ty": 7,
      "x": 906,
      "y": 706,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33319,
      "e": 33203,
      "ty": 6,
      "x": 909,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33402,
      "e": 33286,
      "ty": 2,
      "x": 914,
      "y": 718
    },
    {
      "t": 33501,
      "e": 33385,
      "ty": 2,
      "x": 929,
      "y": 732
    },
    {
      "t": 33501,
      "e": 33385,
      "ty": 41,
      "x": 17048,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33602,
      "e": 33486,
      "ty": 2,
      "x": 936,
      "y": 733
    },
    {
      "t": 33701,
      "e": 33585,
      "ty": 2,
      "x": 936,
      "y": 732
    },
    {
      "t": 33752,
      "e": 33636,
      "ty": 41,
      "x": 16017,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33771,
      "e": 33655,
      "ty": 7,
      "x": 910,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33786,
      "e": 33670,
      "ty": 6,
      "x": 903,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33802,
      "e": 33686,
      "ty": 2,
      "x": 903,
      "y": 695
    },
    {
      "t": 33902,
      "e": 33786,
      "ty": 2,
      "x": 896,
      "y": 692
    },
    {
      "t": 34002,
      "e": 33886,
      "ty": 2,
      "x": 889,
      "y": 689
    },
    {
      "t": 34002,
      "e": 33886,
      "ty": 41,
      "x": 17519,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34402,
      "e": 34286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 34570,
      "e": 34454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 35702,
      "e": 35586,
      "ty": 2,
      "x": 891,
      "y": 691
    },
    {
      "t": 35720,
      "e": 35604,
      "ty": 7,
      "x": 909,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35752,
      "e": 35636,
      "ty": 41,
      "x": 22926,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 35802,
      "e": 35686,
      "ty": 2,
      "x": 919,
      "y": 707
    },
    {
      "t": 35806,
      "e": 35690,
      "ty": 6,
      "x": 919,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35902,
      "e": 35786,
      "ty": 2,
      "x": 927,
      "y": 725
    },
    {
      "t": 36002,
      "e": 35886,
      "ty": 2,
      "x": 939,
      "y": 732
    },
    {
      "t": 36002,
      "e": 35886,
      "ty": 41,
      "x": 22202,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36302,
      "e": 36186,
      "ty": 3,
      "x": 939,
      "y": 732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36303,
      "e": 36187,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 36303,
      "e": 36187,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36304,
      "e": 36188,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36446,
      "e": 36330,
      "ty": 4,
      "x": 22202,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36447,
      "e": 36331,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36447,
      "e": 36331,
      "ty": 5,
      "x": 939,
      "y": 732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36448,
      "e": 36332,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 36902,
      "e": 36786,
      "ty": 2,
      "x": 940,
      "y": 732
    },
    {
      "t": 37002,
      "e": 36886,
      "ty": 41,
      "x": 32095,
      "y": 40107,
      "ta": "html > body"
    },
    {
      "t": 37534,
      "e": 37418,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 37564,
      "e": 37448,
      "ty": 6,
      "x": 940,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38001,
      "e": 37885,
      "ty": 2,
      "x": 940,
      "y": 734
    },
    {
      "t": 38002,
      "e": 37886,
      "ty": 41,
      "x": 30802,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38201,
      "e": 38085,
      "ty": 2,
      "x": 937,
      "y": 745
    },
    {
      "t": 38206,
      "e": 38090,
      "ty": 7,
      "x": 926,
      "y": 776,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38207,
      "e": 38091,
      "ty": 6,
      "x": 926,
      "y": 776,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 38222,
      "e": 38106,
      "ty": 7,
      "x": 914,
      "y": 820,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 38252,
      "e": 38136,
      "ty": 41,
      "x": 30135,
      "y": 51568,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 38300,
      "e": 38184,
      "ty": 2,
      "x": 890,
      "y": 1018
    },
    {
      "t": 38400,
      "e": 38284,
      "ty": 2,
      "x": 890,
      "y": 1102
    },
    {
      "t": 38501,
      "e": 38385,
      "ty": 2,
      "x": 917,
      "y": 1131
    },
    {
      "t": 38502,
      "e": 38386,
      "ty": 41,
      "x": 12872,
      "y": 32304,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 38601,
      "e": 38485,
      "ty": 2,
      "x": 941,
      "y": 1133
    },
    {
      "t": 38657,
      "e": 38541,
      "ty": 6,
      "x": 970,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 38701,
      "e": 38585,
      "ty": 2,
      "x": 977,
      "y": 1098
    },
    {
      "t": 38751,
      "e": 38635,
      "ty": 41,
      "x": 37409,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 38801,
      "e": 38685,
      "ty": 2,
      "x": 980,
      "y": 1093
    },
    {
      "t": 38901,
      "e": 38785,
      "ty": 2,
      "x": 984,
      "y": 1085
    },
    {
      "t": 38982,
      "e": 38866,
      "ty": 3,
      "x": 984,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 38982,
      "e": 38866,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 39001,
      "e": 38885,
      "ty": 41,
      "x": 40686,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 39526,
      "e": 39410,
      "ty": 4,
      "x": 40686,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 39526,
      "e": 39410,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 39527,
      "e": 39411,
      "ty": 5,
      "x": 984,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 39528,
      "e": 39412,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 40001,
      "e": 39885,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40528,
      "e": 40412,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 41101,
      "e": 40985,
      "ty": 2,
      "x": 992,
      "y": 1063
    },
    {
      "t": 41201,
      "e": 41085,
      "ty": 2,
      "x": 997,
      "y": 1028
    },
    {
      "t": 41251,
      "e": 41135,
      "ty": 41,
      "x": 45338,
      "y": 19894,
      "ta": "> p"
    },
    {
      "t": 41301,
      "e": 41185,
      "ty": 2,
      "x": 994,
      "y": 1013
    },
    {
      "t": 41501,
      "e": 41385,
      "ty": 2,
      "x": 989,
      "y": 1017
    },
    {
      "t": 41501,
      "e": 41385,
      "ty": 41,
      "x": 43214,
      "y": 22235,
      "ta": "> p"
    },
    {
      "t": 41601,
      "e": 41485,
      "ty": 2,
      "x": 984,
      "y": 1025
    },
    {
      "t": 41701,
      "e": 41585,
      "ty": 2,
      "x": 974,
      "y": 1040
    },
    {
      "t": 41751,
      "e": 41635,
      "ty": 41,
      "x": 33232,
      "y": 57225,
      "ta": "html > body"
    },
    {
      "t": 41801,
      "e": 41685,
      "ty": 2,
      "x": 973,
      "y": 1041
    },
    {
      "t": 41901,
      "e": 41785,
      "ty": 2,
      "x": 971,
      "y": 1041
    },
    {
      "t": 42001,
      "e": 41885,
      "ty": 41,
      "x": 33163,
      "y": 57225,
      "ta": "html > body"
    },
    {
      "t": 50002,
      "e": 46885,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 63448,
      "e": 46885,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 64453,
      "e": 46885,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 105, dom: 1469, initialDom: 1474",
  "javascriptErrors": []
}