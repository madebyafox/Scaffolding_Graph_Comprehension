var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "11dd1412c32e0b31a8a39e12406f05ba",
  "created": "2018-05-25T11:17:12.3681014-07:00",
  "lastActivity": "2018-05-25T11:17:35.4485776-07:00",
  "pageViews": [
    {
      "id": "052512347168069e241b7ffcf4c9810ced555ceb",
      "startTime": "2018-05-25T11:17:12.4375776-07:00",
      "endTime": "2018-05-25T11:17:35.4485776-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 23011,
      "engagementTime": 20911,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 23011,
  "engagementTime": 20911,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CKU4L",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "db901512f44ffeed4dfeb3d6f9e88f53",
  "gdpr": false
}