var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0515227364eaa1b9aa937c1ec2b67c3b9520c0fa"] = {
  "startTime": "2018-05-15T17:06:22.8008135Z",
  "websitePageUrl": "/",
  "visitTime": 138355,
  "engagementTime": 64856,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "60c547593c38259779e6a7c8f688068e",
    "created": "2018-05-15T17:06:22.8008135+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.170",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6a2d896d08472410cdfe197cf4c83fbe",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/60c547593c38259779e6a7c8f688068e/play"
  },
  "events": [
    {
      "t": 8,
      "e": 8,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 3985,
      "e": 3985,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 2,
      "x": 705,
      "y": 10
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 24003,
      "y": 110,
      "ta": "html > body"
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 707,
      "y": 11
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 937,
      "y": 583
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 31538,
      "y": 31415,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1121,
      "y": 854
    },
    {
      "t": 5203,
      "e": 5203,
      "ty": 2,
      "x": 1129,
      "y": 859
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 42024,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10015,
      "e": 10015,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 26804,
      "e": 10251,
      "ty": 2,
      "x": 1117,
      "y": 848
    },
    {
      "t": 26901,
      "e": 10348,
      "ty": 2,
      "x": 842,
      "y": 772
    },
    {
      "t": 27001,
      "e": 10448,
      "ty": 2,
      "x": 800,
      "y": 789
    },
    {
      "t": 27002,
      "e": 10449,
      "ty": 41,
      "x": 24056,
      "y": 48291,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 27101,
      "e": 10548,
      "ty": 2,
      "x": 800,
      "y": 791
    },
    {
      "t": 27202,
      "e": 10649,
      "ty": 2,
      "x": 803,
      "y": 795
    },
    {
      "t": 27251,
      "e": 10698,
      "ty": 41,
      "x": 24220,
      "y": 48782,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40002,
      "e": 15698,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50601,
      "e": 15698,
      "ty": 2,
      "x": 899,
      "y": 788
    },
    {
      "t": 50701,
      "e": 15798,
      "ty": 2,
      "x": 1044,
      "y": 842
    },
    {
      "t": 50754,
      "e": 15851,
      "ty": 41,
      "x": 37600,
      "y": 52796,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50817,
      "e": 15914,
      "ty": 2,
      "x": 1048,
      "y": 844
    },
    {
      "t": 51924,
      "e": 17021,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 53036,
      "e": 18133,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 54701,
      "e": 19798,
      "ty": 2,
      "x": 853,
      "y": 825
    },
    {
      "t": 54752,
      "e": 19849,
      "ty": 41,
      "x": 26347,
      "y": 7039,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 54809,
      "e": 19906,
      "ty": 2,
      "x": 828,
      "y": 838
    },
    {
      "t": 54902,
      "e": 19999,
      "ty": 2,
      "x": 825,
      "y": 846
    },
    {
      "t": 55001,
      "e": 20098,
      "ty": 2,
      "x": 832,
      "y": 883
    },
    {
      "t": 55002,
      "e": 20099,
      "ty": 41,
      "x": 26494,
      "y": 60872,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 55101,
      "e": 20198,
      "ty": 2,
      "x": 848,
      "y": 902
    },
    {
      "t": 55202,
      "e": 20299,
      "ty": 2,
      "x": 863,
      "y": 907
    },
    {
      "t": 55251,
      "e": 20348,
      "ty": 41,
      "x": 14186,
      "y": 6004,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 55309,
      "e": 20406,
      "ty": 2,
      "x": 873,
      "y": 910
    },
    {
      "t": 55402,
      "e": 20499,
      "ty": 2,
      "x": 876,
      "y": 913
    },
    {
      "t": 55501,
      "e": 20598,
      "ty": 2,
      "x": 879,
      "y": 921
    },
    {
      "t": 55502,
      "e": 20599,
      "ty": 41,
      "x": 15866,
      "y": 38771,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 55600,
      "e": 20697,
      "ty": 2,
      "x": 882,
      "y": 928
    },
    {
      "t": 55701,
      "e": 20798,
      "ty": 2,
      "x": 885,
      "y": 936
    },
    {
      "t": 55762,
      "e": 20859,
      "ty": 41,
      "x": 29102,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 55809,
      "e": 20906,
      "ty": 2,
      "x": 885,
      "y": 937
    },
    {
      "t": 55901,
      "e": 20998,
      "ty": 2,
      "x": 881,
      "y": 940
    },
    {
      "t": 56001,
      "e": 21098,
      "ty": 2,
      "x": 869,
      "y": 938
    },
    {
      "t": 56002,
      "e": 21099,
      "ty": 41,
      "x": 28315,
      "y": 56208,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56101,
      "e": 21198,
      "ty": 2,
      "x": 842,
      "y": 930
    },
    {
      "t": 56202,
      "e": 21299,
      "ty": 2,
      "x": 821,
      "y": 923
    },
    {
      "t": 56252,
      "e": 21349,
      "ty": 41,
      "x": 34610,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 56301,
      "e": 21398,
      "ty": 2,
      "x": 812,
      "y": 921
    },
    {
      "t": 56349,
      "e": 21446,
      "ty": 3,
      "x": 812,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 56450,
      "e": 21547,
      "ty": 4,
      "x": 28057,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 56451,
      "e": 21548,
      "ty": 5,
      "x": 812,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 56451,
      "e": 21548,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 56456,
      "e": 21553,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 56501,
      "e": 21598,
      "ty": 41,
      "x": 28057,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 60014,
      "e": 25111,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 91902,
      "e": 26598,
      "ty": 2,
      "x": 902,
      "y": 965
    },
    {
      "t": 92003,
      "e": 26699,
      "ty": 2,
      "x": 1064,
      "y": 1045
    },
    {
      "t": 92003,
      "e": 26699,
      "ty": 41,
      "x": 37908,
      "y": 63617,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92102,
      "e": 26798,
      "ty": 2,
      "x": 1077,
      "y": 1073
    },
    {
      "t": 92203,
      "e": 26899,
      "ty": 2,
      "x": 1013,
      "y": 1123
    },
    {
      "t": 92254,
      "e": 26950,
      "ty": 41,
      "x": 45640,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 92305,
      "e": 27001,
      "ty": 2,
      "x": 987,
      "y": 1126
    },
    {
      "t": 92403,
      "e": 27099,
      "ty": 2,
      "x": 976,
      "y": 1115
    },
    {
      "t": 92440,
      "e": 27136,
      "ty": 6,
      "x": 973,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 92503,
      "e": 27199,
      "ty": 2,
      "x": 972,
      "y": 1100
    },
    {
      "t": 92504,
      "e": 27200,
      "ty": 41,
      "x": 34132,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 92606,
      "e": 27302,
      "ty": 2,
      "x": 972,
      "y": 1093
    },
    {
      "t": 92637,
      "e": 27333,
      "ty": 3,
      "x": 972,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 92637,
      "e": 27333,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 92637,
      "e": 27333,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92740,
      "e": 27436,
      "ty": 4,
      "x": 34132,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 92742,
      "e": 27438,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92742,
      "e": 27438,
      "ty": 5,
      "x": 972,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 92743,
      "e": 27439,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 92754,
      "e": 27450,
      "ty": 41,
      "x": 33197,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 93004,
      "e": 27700,
      "ty": 2,
      "x": 972,
      "y": 1088
    },
    {
      "t": 93004,
      "e": 27700,
      "ty": 41,
      "x": 33197,
      "y": 59829,
      "ta": "html > body"
    },
    {
      "t": 93106,
      "e": 27802,
      "ty": 2,
      "x": 972,
      "y": 1085
    },
    {
      "t": 93254,
      "e": 27950,
      "ty": 41,
      "x": 33921,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 93304,
      "e": 28000,
      "ty": 2,
      "x": 998,
      "y": 1012
    },
    {
      "t": 93405,
      "e": 28101,
      "ty": 2,
      "x": 998,
      "y": 1006
    },
    {
      "t": 93516,
      "e": 28212,
      "ty": 41,
      "x": 34093,
      "y": 55286,
      "ta": "html > body"
    },
    {
      "t": 93756,
      "e": 28452,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 94004,
      "e": 28700,
      "ty": 2,
      "x": 998,
      "y": 1013
    },
    {
      "t": 94004,
      "e": 28700,
      "ty": 41,
      "x": 34093,
      "y": 55674,
      "ta": "html > body"
    },
    {
      "t": 94103,
      "e": 28799,
      "ty": 2,
      "x": 984,
      "y": 1123
    },
    {
      "t": 94203,
      "e": 28899,
      "ty": 2,
      "x": 984,
      "y": 1163
    },
    {
      "t": 94253,
      "e": 28949,
      "ty": 41,
      "x": 33611,
      "y": 64427,
      "ta": "html > body"
    },
    {
      "t": 94307,
      "e": 29003,
      "ty": 2,
      "x": 984,
      "y": 1171
    },
    {
      "t": 94603,
      "e": 29299,
      "ty": 2,
      "x": 1007,
      "y": 1116
    },
    {
      "t": 94703,
      "e": 29399,
      "ty": 2,
      "x": 1183,
      "y": 807
    },
    {
      "t": 94753,
      "e": 29449,
      "ty": 41,
      "x": 44803,
      "y": 31576,
      "ta": "html > body"
    },
    {
      "t": 94803,
      "e": 29499,
      "ty": 2,
      "x": 1459,
      "y": 363
    },
    {
      "t": 94903,
      "e": 29599,
      "ty": 2,
      "x": 1465,
      "y": 298
    },
    {
      "t": 95003,
      "e": 29699,
      "ty": 2,
      "x": 1251,
      "y": 439
    },
    {
      "t": 95003,
      "e": 29699,
      "ty": 41,
      "x": 42806,
      "y": 23876,
      "ta": "html > body"
    },
    {
      "t": 95104,
      "e": 29800,
      "ty": 2,
      "x": 1178,
      "y": 489
    },
    {
      "t": 95203,
      "e": 29899,
      "ty": 2,
      "x": 1157,
      "y": 533
    },
    {
      "t": 95253,
      "e": 29949,
      "ty": 41,
      "x": 39155,
      "y": 30302,
      "ta": "html > body"
    },
    {
      "t": 95303,
      "e": 29999,
      "ty": 2,
      "x": 1125,
      "y": 583
    },
    {
      "t": 95393,
      "e": 30089,
      "ty": 6,
      "x": 1107,
      "y": 592,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95403,
      "e": 30099,
      "ty": 2,
      "x": 1107,
      "y": 592
    },
    {
      "t": 95503,
      "e": 30199,
      "ty": 2,
      "x": 1089,
      "y": 595
    },
    {
      "t": 95503,
      "e": 30199,
      "ty": 41,
      "x": 60776,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95709,
      "e": 30405,
      "ty": 3,
      "x": 1087,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95710,
      "e": 30406,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95713,
      "e": 30409,
      "ty": 2,
      "x": 1087,
      "y": 596
    },
    {
      "t": 95761,
      "e": 30457,
      "ty": 41,
      "x": 60344,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95787,
      "e": 30483,
      "ty": 4,
      "x": 60344,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95787,
      "e": 30483,
      "ty": 5,
      "x": 1087,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96104,
      "e": 30800,
      "ty": 2,
      "x": 1110,
      "y": 606
    },
    {
      "t": 96254,
      "e": 30950,
      "ty": 41,
      "x": 65318,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96601,
      "e": 31297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 96602,
      "e": 31298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96695,
      "e": 31391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 96696,
      "e": 31392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96744,
      "e": 31440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fk"
    },
    {
      "t": 96800,
      "e": 31496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 96800,
      "e": 31496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96864,
      "e": 31560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fki"
    },
    {
      "t": 96921,
      "e": 31617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "87"
    },
    {
      "t": 96921,
      "e": 31617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96984,
      "e": 31680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fkiw"
    },
    {
      "t": 97008,
      "e": 31704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 97009,
      "e": 31705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97135,
      "e": 31831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||e"
    },
    {
      "t": 97152,
      "e": 31848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 97272,
      "e": 31968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 97335,
      "e": 32031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fkiw"
    },
    {
      "t": 97424,
      "e": 32120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 97464,
      "e": 32160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fki"
    },
    {
      "t": 97553,
      "e": 32249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 97576,
      "e": 32272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fk"
    },
    {
      "t": 97664,
      "e": 32360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 97720,
      "e": 32416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "f"
    },
    {
      "t": 97822,
      "e": 32518,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "f"
    },
    {
      "t": 97864,
      "e": 32560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 97866,
      "e": 32562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97992,
      "e": 32688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fl"
    },
    {
      "t": 98208,
      "e": 32904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 98263,
      "e": 32959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "f"
    },
    {
      "t": 98359,
      "e": 33055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 98399,
      "e": 33095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 98487,
      "e": 33183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 98560,
      "e": 33256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 98657,
      "e": 33353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 98752,
      "e": 33448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 98753,
      "e": 33449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98888,
      "e": 33584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "F"
    },
    {
      "t": 99056,
      "e": 33752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "F"
    },
    {
      "t": 99592,
      "e": 34288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 99744,
      "e": 34440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "F"
    },
    {
      "t": 99784,
      "e": 34480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 99786,
      "e": 34482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99879,
      "e": 34575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 99879,
      "e": 34575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99960,
      "e": 34656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "FLO"
    },
    {
      "t": 99975,
      "e": 34671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "87"
    },
    {
      "t": 99976,
      "e": 34672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99992,
      "e": 34688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "FLOW"
    },
    {
      "t": 100003,
      "e": 34699,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100072,
      "e": 34768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 100072,
      "e": 34768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100183,
      "e": 34879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 100215,
      "e": 34911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 100216,
      "e": 34912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100312,
      "e": 35008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 100360,
      "e": 35056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 100528,
      "e": 35224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 100529,
      "e": 35225,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "FLOWER"
    },
    {
      "t": 100530,
      "e": 35226,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100531,
      "e": 35227,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100648,
      "e": 35344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 101520,
      "e": 36216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 101672,
      "e": 36368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 102825,
      "e": 37521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 102826,
      "e": 37522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102959,
      "e": 37655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 102960,
      "e": 37656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102968,
      "e": 37664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 103137,
      "e": 37833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 103137,
      "e": 37833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103152,
      "e": 37848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 103280,
      "e": 37976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 103797,
      "e": 38493,
      "ty": 7,
      "x": 1110,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103804,
      "e": 38500,
      "ty": 2,
      "x": 1110,
      "y": 609
    },
    {
      "t": 103867,
      "e": 38563,
      "ty": 6,
      "x": 1033,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103883,
      "e": 38579,
      "ty": 7,
      "x": 1028,
      "y": 710,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103903,
      "e": 38599,
      "ty": 2,
      "x": 1025,
      "y": 720
    },
    {
      "t": 103916,
      "e": 38612,
      "ty": 6,
      "x": 1022,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104015,
      "e": 38711,
      "ty": 2,
      "x": 1022,
      "y": 726
    },
    {
      "t": 104015,
      "e": 38711,
      "ty": 41,
      "x": 64979,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104636,
      "e": 39332,
      "ty": 3,
      "x": 1022,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104637,
      "e": 39333,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 104637,
      "e": 39333,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104637,
      "e": 39333,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104748,
      "e": 39444,
      "ty": 4,
      "x": 64979,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104752,
      "e": 39448,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104754,
      "e": 39450,
      "ty": 5,
      "x": 1022,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104755,
      "e": 39451,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 105874,
      "e": 40570,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 105906,
      "e": 40602,
      "ty": 6,
      "x": 1022,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 110014,
      "e": 44710,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110843,
      "e": 45539,
      "ty": 7,
      "x": 1029,
      "y": 651,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 110903,
      "e": 45599,
      "ty": 2,
      "x": 1073,
      "y": 475
    },
    {
      "t": 111003,
      "e": 45699,
      "ty": 2,
      "x": 1235,
      "y": 293
    },
    {
      "t": 111003,
      "e": 45699,
      "ty": 41,
      "x": 46321,
      "y": 11543,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 111103,
      "e": 45799,
      "ty": 2,
      "x": 1348,
      "y": 274
    },
    {
      "t": 111203,
      "e": 45899,
      "ty": 2,
      "x": 1367,
      "y": 328
    },
    {
      "t": 111253,
      "e": 45949,
      "ty": 41,
      "x": 53258,
      "y": 15837,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 111304,
      "e": 46000,
      "ty": 2,
      "x": 1384,
      "y": 373
    },
    {
      "t": 111404,
      "e": 46100,
      "ty": 2,
      "x": 1399,
      "y": 380
    },
    {
      "t": 111503,
      "e": 46199,
      "ty": 2,
      "x": 1449,
      "y": 401
    },
    {
      "t": 111504,
      "e": 46200,
      "ty": 41,
      "x": 56849,
      "y": 19022,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 111603,
      "e": 46299,
      "ty": 2,
      "x": 1491,
      "y": 424
    },
    {
      "t": 111704,
      "e": 46400,
      "ty": 2,
      "x": 1417,
      "y": 453
    },
    {
      "t": 111754,
      "e": 46450,
      "ty": 41,
      "x": 47600,
      "y": 9296,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 111803,
      "e": 46499,
      "ty": 2,
      "x": 1135,
      "y": 532
    },
    {
      "t": 111903,
      "e": 46599,
      "ty": 2,
      "x": 1009,
      "y": 553
    },
    {
      "t": 112003,
      "e": 46699,
      "ty": 2,
      "x": 899,
      "y": 560
    },
    {
      "t": 112004,
      "e": 46700,
      "ty": 41,
      "x": 61669,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 112103,
      "e": 46799,
      "ty": 2,
      "x": 840,
      "y": 569
    },
    {
      "t": 112203,
      "e": 46899,
      "ty": 2,
      "x": 813,
      "y": 580
    },
    {
      "t": 112254,
      "e": 46950,
      "ty": 41,
      "x": 57973,
      "y": 51,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 112307,
      "e": 47003,
      "ty": 2,
      "x": 806,
      "y": 584
    },
    {
      "t": 112511,
      "e": 47207,
      "ty": 41,
      "x": 57850,
      "y": 3327,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 112817,
      "e": 47513,
      "ty": 2,
      "x": 805,
      "y": 584
    },
    {
      "t": 113004,
      "e": 47700,
      "ty": 41,
      "x": 57728,
      "y": 3327,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 113103,
      "e": 47799,
      "ty": 2,
      "x": 804,
      "y": 592
    },
    {
      "t": 113204,
      "e": 47900,
      "ty": 2,
      "x": 801,
      "y": 598
    },
    {
      "t": 113257,
      "e": 47953,
      "ty": 41,
      "x": 57238,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 113308,
      "e": 48004,
      "ty": 2,
      "x": 801,
      "y": 601
    },
    {
      "t": 113404,
      "e": 48100,
      "ty": 2,
      "x": 801,
      "y": 602
    },
    {
      "t": 113508,
      "e": 48204,
      "ty": 2,
      "x": 801,
      "y": 605
    },
    {
      "t": 113510,
      "e": 48206,
      "ty": 41,
      "x": 50982,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td"
    },
    {
      "t": 113608,
      "e": 48304,
      "ty": 2,
      "x": 800,
      "y": 607
    },
    {
      "t": 113765,
      "e": 48461,
      "ty": 41,
      "x": 24920,
      "y": 31143,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 113904,
      "e": 48600,
      "ty": 2,
      "x": 800,
      "y": 608
    },
    {
      "t": 114006,
      "e": 48702,
      "ty": 2,
      "x": 800,
      "y": 610
    },
    {
      "t": 114006,
      "e": 48702,
      "ty": 41,
      "x": 24920,
      "y": 31607,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 114210,
      "e": 48906,
      "ty": 2,
      "x": 799,
      "y": 611
    },
    {
      "t": 114253,
      "e": 48949,
      "ty": 41,
      "x": 24772,
      "y": 31917,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 114309,
      "e": 49005,
      "ty": 2,
      "x": 796,
      "y": 613
    },
    {
      "t": 114403,
      "e": 49099,
      "ty": 2,
      "x": 790,
      "y": 617
    },
    {
      "t": 114503,
      "e": 49199,
      "ty": 2,
      "x": 775,
      "y": 626
    },
    {
      "t": 114504,
      "e": 49200,
      "ty": 41,
      "x": 23690,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 114604,
      "e": 49300,
      "ty": 2,
      "x": 749,
      "y": 642
    },
    {
      "t": 114676,
      "e": 49372,
      "ty": 6,
      "x": 680,
      "y": 674,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 114703,
      "e": 49399,
      "ty": 2,
      "x": 662,
      "y": 680
    },
    {
      "t": 114742,
      "e": 49438,
      "ty": 7,
      "x": 599,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 114743,
      "e": 49439,
      "ty": 6,
      "x": 599,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 114753,
      "e": 49449,
      "ty": 41,
      "x": 13526,
      "y": 14079,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 114803,
      "e": 49499,
      "ty": 2,
      "x": 542,
      "y": 721
    },
    {
      "t": 114826,
      "e": 49522,
      "ty": 7,
      "x": 520,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 114826,
      "e": 49522,
      "ty": 6,
      "x": 520,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 114904,
      "e": 49600,
      "ty": 2,
      "x": 493,
      "y": 735
    },
    {
      "t": 115008,
      "e": 49704,
      "ty": 2,
      "x": 490,
      "y": 736
    },
    {
      "t": 115009,
      "e": 49705,
      "ty": 41,
      "x": 8004,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 116103,
      "e": 50799,
      "ty": 2,
      "x": 494,
      "y": 753
    },
    {
      "t": 116110,
      "e": 50806,
      "ty": 7,
      "x": 495,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 116111,
      "e": 50807,
      "ty": 6,
      "x": 495,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116203,
      "e": 50899,
      "ty": 2,
      "x": 500,
      "y": 761
    },
    {
      "t": 116253,
      "e": 50949,
      "ty": 41,
      "x": 8561,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116303,
      "e": 50999,
      "ty": 2,
      "x": 501,
      "y": 764
    },
    {
      "t": 116403,
      "e": 51099,
      "ty": 2,
      "x": 502,
      "y": 766
    },
    {
      "t": 116509,
      "e": 51205,
      "ty": 2,
      "x": 504,
      "y": 770
    },
    {
      "t": 116510,
      "e": 51206,
      "ty": 41,
      "x": 8713,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116603,
      "e": 51299,
      "ty": 2,
      "x": 506,
      "y": 773
    },
    {
      "t": 116708,
      "e": 51404,
      "ty": 2,
      "x": 507,
      "y": 775
    },
    {
      "t": 116761,
      "e": 51457,
      "ty": 41,
      "x": 8916,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116811,
      "e": 51507,
      "ty": 2,
      "x": 509,
      "y": 776
    },
    {
      "t": 116905,
      "e": 51601,
      "ty": 2,
      "x": 509,
      "y": 777
    },
    {
      "t": 117003,
      "e": 51699,
      "ty": 2,
      "x": 511,
      "y": 779
    },
    {
      "t": 117003,
      "e": 51699,
      "ty": 41,
      "x": 9067,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 117108,
      "e": 51804,
      "ty": 2,
      "x": 513,
      "y": 782
    },
    {
      "t": 117109,
      "e": 51805,
      "ty": 7,
      "x": 514,
      "y": 783,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 117211,
      "e": 51907,
      "ty": 2,
      "x": 515,
      "y": 784
    },
    {
      "t": 117258,
      "e": 51954,
      "ty": 41,
      "x": 10899,
      "y": 58565,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 117305,
      "e": 52001,
      "ty": 2,
      "x": 516,
      "y": 785
    },
    {
      "t": 117404,
      "e": 52100,
      "ty": 2,
      "x": 520,
      "y": 789
    },
    {
      "t": 117503,
      "e": 52199,
      "ty": 2,
      "x": 522,
      "y": 791
    },
    {
      "t": 117503,
      "e": 52199,
      "ty": 41,
      "x": 11243,
      "y": 59650,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 117603,
      "e": 52299,
      "ty": 2,
      "x": 527,
      "y": 798
    },
    {
      "t": 117702,
      "e": 52398,
      "ty": 2,
      "x": 539,
      "y": 805
    },
    {
      "t": 117753,
      "e": 52449,
      "ty": 41,
      "x": 12670,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 117803,
      "e": 52499,
      "ty": 2,
      "x": 579,
      "y": 825
    },
    {
      "t": 117903,
      "e": 52499,
      "ty": 2,
      "x": 731,
      "y": 880
    },
    {
      "t": 118002,
      "e": 52598,
      "ty": 2,
      "x": 833,
      "y": 918
    },
    {
      "t": 118002,
      "e": 52598,
      "ty": 41,
      "x": 26544,
      "y": 54823,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 118103,
      "e": 52699,
      "ty": 2,
      "x": 873,
      "y": 956
    },
    {
      "t": 118203,
      "e": 52799,
      "ty": 2,
      "x": 943,
      "y": 1018
    },
    {
      "t": 118253,
      "e": 52849,
      "ty": 41,
      "x": 32939,
      "y": 62648,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 118302,
      "e": 52898,
      "ty": 2,
      "x": 970,
      "y": 1038
    },
    {
      "t": 118404,
      "e": 53000,
      "ty": 2,
      "x": 970,
      "y": 1043
    },
    {
      "t": 118506,
      "e": 53102,
      "ty": 2,
      "x": 972,
      "y": 1056
    },
    {
      "t": 118507,
      "e": 53103,
      "ty": 41,
      "x": 33382,
      "y": 64379,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 118606,
      "e": 53202,
      "ty": 2,
      "x": 981,
      "y": 1071
    },
    {
      "t": 118615,
      "e": 53211,
      "ty": 6,
      "x": 984,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 118714,
      "e": 53310,
      "ty": 2,
      "x": 987,
      "y": 1076
    },
    {
      "t": 118756,
      "e": 53352,
      "ty": 41,
      "x": 43416,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 118812,
      "e": 53408,
      "ty": 2,
      "x": 989,
      "y": 1079
    },
    {
      "t": 118992,
      "e": 53588,
      "ty": 3,
      "x": 989,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 118993,
      "e": 53589,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 119014,
      "e": 53610,
      "ty": 2,
      "x": 989,
      "y": 1081
    },
    {
      "t": 119014,
      "e": 53610,
      "ty": 41,
      "x": 43416,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 119125,
      "e": 53721,
      "ty": 4,
      "x": 43416,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 119126,
      "e": 53722,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 119127,
      "e": 53723,
      "ty": 5,
      "x": 989,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 119128,
      "e": 53724,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 119510,
      "e": 54106,
      "ty": 2,
      "x": 988,
      "y": 1074
    },
    {
      "t": 119511,
      "e": 54107,
      "ty": 41,
      "x": 33748,
      "y": 59053,
      "ta": "html > body"
    },
    {
      "t": 119606,
      "e": 54202,
      "ty": 2,
      "x": 972,
      "y": 1018
    },
    {
      "t": 119705,
      "e": 54301,
      "ty": 2,
      "x": 941,
      "y": 936
    },
    {
      "t": 119756,
      "e": 54352,
      "ty": 41,
      "x": 31476,
      "y": 48971,
      "ta": "html > body"
    },
    {
      "t": 119806,
      "e": 54402,
      "ty": 2,
      "x": 859,
      "y": 768
    },
    {
      "t": 119905,
      "e": 54501,
      "ty": 2,
      "x": 814,
      "y": 639
    },
    {
      "t": 120005,
      "e": 54601,
      "ty": 2,
      "x": 813,
      "y": 605
    },
    {
      "t": 120006,
      "e": 54602,
      "ty": 41,
      "x": 27722,
      "y": 33072,
      "ta": "html > body"
    },
    {
      "t": 120114,
      "e": 54710,
      "ty": 2,
      "x": 813,
      "y": 602
    },
    {
      "t": 120132,
      "e": 54728,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 120263,
      "e": 54859,
      "ty": 41,
      "x": 25655,
      "y": 35446,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120406,
      "e": 55002,
      "ty": 2,
      "x": 812,
      "y": 602
    },
    {
      "t": 120512,
      "e": 55108,
      "ty": 41,
      "x": 25607,
      "y": 35446,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120757,
      "e": 55353,
      "ty": 41,
      "x": 25461,
      "y": 35446,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120806,
      "e": 55402,
      "ty": 2,
      "x": 808,
      "y": 604
    },
    {
      "t": 120917,
      "e": 55513,
      "ty": 2,
      "x": 806,
      "y": 606
    },
    {
      "t": 121018,
      "e": 55614,
      "ty": 2,
      "x": 804,
      "y": 608
    },
    {
      "t": 121018,
      "e": 55614,
      "ty": 41,
      "x": 25218,
      "y": 35912,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 121106,
      "e": 55702,
      "ty": 2,
      "x": 803,
      "y": 610
    },
    {
      "t": 121206,
      "e": 55802,
      "ty": 2,
      "x": 801,
      "y": 611
    },
    {
      "t": 121266,
      "e": 55862,
      "ty": 41,
      "x": 25073,
      "y": 36222,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 121312,
      "e": 55908,
      "ty": 2,
      "x": 801,
      "y": 612
    },
    {
      "t": 124269,
      "e": 58865,
      "ty": 41,
      "x": 25024,
      "y": 36378,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 124306,
      "e": 58902,
      "ty": 2,
      "x": 800,
      "y": 616
    },
    {
      "t": 124416,
      "e": 59012,
      "ty": 2,
      "x": 800,
      "y": 617
    },
    {
      "t": 124506,
      "e": 59102,
      "ty": 2,
      "x": 800,
      "y": 619
    },
    {
      "t": 124507,
      "e": 59103,
      "ty": 41,
      "x": 25024,
      "y": 36766,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 124910,
      "e": 59506,
      "ty": 2,
      "x": 800,
      "y": 622
    },
    {
      "t": 125006,
      "e": 59602,
      "ty": 2,
      "x": 801,
      "y": 623
    },
    {
      "t": 125007,
      "e": 59603,
      "ty": 41,
      "x": 25073,
      "y": 37076,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 125118,
      "e": 59714,
      "ty": 2,
      "x": 801,
      "y": 626
    },
    {
      "t": 125260,
      "e": 59856,
      "ty": 41,
      "x": 25073,
      "y": 37309,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 130010,
      "e": 64606,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 137341,
      "e": 64856,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 138355,
      "e": 64856,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 270, dom: 1238, initialDom: 1308",
  "javascriptErrors": []
}