var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "23cea5ae518d0efcba45e7d9903a879e",
  "created": "2018-06-04T12:07:35.8090184-07:00",
  "lastActivity": "2018-06-04T12:12:41.6918909-07:00",
  "pageViews": [
    {
      "id": "06043587f5036c5507906d5a3b4b003fa8702cbd",
      "startTime": "2018-06-04T12:07:35.8090184-07:00",
      "endTime": "2018-06-04T12:12:41.6918909-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 305978,
      "engagementTime": 65660,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 305978,
  "engagementTime": 65660,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "39022471ae7dc12bf203701cfaa1aa08",
  "gdpr": false
}