var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ce2fb9479a068a20897faa9bdbfd338e",
  "created": "2018-05-21T12:07:56.327326-07:00",
  "lastActivity": "2018-05-21T12:10:49.0694269-07:00",
  "pageViews": [
    {
      "id": "05215682117339d6c93489a95aaa7c7187e9c6e0",
      "startTime": "2018-05-21T12:07:56.327326-07:00",
      "endTime": "2018-05-21T12:10:49.0694269-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 172897,
      "engagementTime": 62465,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 172897,
  "engagementTime": 62465,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f70d53cacc3c0a048ff9f17b22fe3964",
  "gdpr": false
}