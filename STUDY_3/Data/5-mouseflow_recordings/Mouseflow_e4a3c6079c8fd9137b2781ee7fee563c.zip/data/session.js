var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e4a3c6079c8fd9137b2781ee7fee563c",
  "created": "2018-06-04T13:16:41.2763194-07:00",
  "lastActivity": "2018-06-04T13:17:13.6957786-07:00",
  "pageViews": [
    {
      "id": "0604413506971ca8c91af4bd38fc89263d3b455e",
      "startTime": "2018-06-04T13:16:41.2917786-07:00",
      "endTime": "2018-06-04T13:17:13.6957786-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 32404,
      "engagementTime": 26106,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32404,
  "engagementTime": 26106,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K0CNH",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1fcda9803590e3f2045796fcb6d5da30",
  "gdpr": false
}