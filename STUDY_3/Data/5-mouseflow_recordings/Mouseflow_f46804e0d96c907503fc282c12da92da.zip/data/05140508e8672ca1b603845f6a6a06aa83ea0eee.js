var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05140508e8672ca1b603845f6a6a06aa83ea0eee"] = {
  "startTime": "2018-05-14T20:14:05.4244927Z",
  "websitePageUrl": "/15",
  "visitTime": 80386,
  "engagementTime": 75960,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f46804e0d96c907503fc282c12da92da",
    "created": "2018-05-14T20:14:05.4244927+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.170",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=4FETN",
      "CONDITION=121",
      "TRI_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f6a260a0f3210e95fe18db5ec156b117",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f46804e0d96c907503fc282c12da92da/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 336,
      "e": 336,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1372,
      "y": 527
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1666,
      "y": 1060
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1686,
      "y": 1192
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1680,
      "y": 1199
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1448,
      "y": 1199
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1361,
      "y": 1187
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1238,
      "y": 1089
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1182,
      "y": 947
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 14164,
      "y": 57942,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1280,
      "y": 841
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1449,
      "y": 731
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1551,
      "y": 693
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1672,
      "y": 707
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1736,
      "y": 718
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 53203,
      "y": 41541,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1737,
      "y": 718
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 60292,
      "y": 5324,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[17]"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1738,
      "y": 717
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1744,
      "y": 707
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1747,
      "y": 702
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 53978,
      "y": 40395,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1749,
      "y": 672
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1716,
      "y": 650
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 47424,
      "y": 33519,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1628,
      "y": 594
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1551,
      "y": 574
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1550,
      "y": 574
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 40096,
      "y": 31227,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1613,
      "y": 776
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1684,
      "y": 894
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 49820,
      "y": 54719,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 1689,
      "y": 905
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1693,
      "y": 919
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1701,
      "y": 944
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 50736,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 1699,
      "y": 979
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1546,
      "y": 1069
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 51140,
      "y": 59773,
      "ta": "> div.stimulus"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1493,
      "y": 1088
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1486,
      "y": 1088
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 1471,
      "y": 1036
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 41,
      "x": 31949,
      "y": 29490,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1468,
      "y": 1022
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1468,
      "y": 1018
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 34317,
      "y": 61452,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 1468,
      "y": 956
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1466,
      "y": 825
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 1466,
      "y": 800
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 42597,
      "y": 42644,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[12]"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 2,
      "x": 1466,
      "y": 794
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1466,
      "y": 791
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 34458,
      "y": 46340,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8800,
      "e": 8800,
      "ty": 2,
      "x": 1477,
      "y": 775
    },
    {
      "t": 8900,
      "e": 8900,
      "ty": 2,
      "x": 1487,
      "y": 741
    },
    {
      "t": 9000,
      "e": 9000,
      "ty": 2,
      "x": 1500,
      "y": 697
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 36572,
      "y": 40037,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9100,
      "e": 9100,
      "ty": 2,
      "x": 1508,
      "y": 649
    },
    {
      "t": 9200,
      "e": 9200,
      "ty": 2,
      "x": 1508,
      "y": 588
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 37136,
      "y": 29938,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 1508,
      "y": 503
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 2,
      "x": 1508,
      "y": 390
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 2,
      "x": 1490,
      "y": 334
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 41,
      "x": 35868,
      "y": 14038,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9600,
      "e": 9600,
      "ty": 2,
      "x": 1483,
      "y": 330
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 35374,
      "y": 13751,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 2,
      "x": 1482,
      "y": 308
    },
    {
      "t": 10250,
      "e": 10250,
      "ty": 41,
      "x": 38228,
      "y": 58253,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[11] > circle"
    },
    {
      "t": 10300,
      "e": 10300,
      "ty": 2,
      "x": 1480,
      "y": 286
    },
    {
      "t": 10400,
      "e": 10400,
      "ty": 2,
      "x": 1478,
      "y": 278
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 2,
      "x": 1475,
      "y": 262
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 41,
      "x": 34811,
      "y": 8881,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 1475,
      "y": 255
    },
    {
      "t": 10700,
      "e": 10700,
      "ty": 2,
      "x": 1477,
      "y": 248
    },
    {
      "t": 10750,
      "e": 10750,
      "ty": 41,
      "x": 34952,
      "y": 7878,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 2,
      "x": 1478,
      "y": 242
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 2,
      "x": 1481,
      "y": 233
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 2,
      "x": 1481,
      "y": 232
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 41,
      "x": 35233,
      "y": 6732,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12101,
      "e": 12101,
      "ty": 2,
      "x": 1482,
      "y": 248
    },
    {
      "t": 12200,
      "e": 12200,
      "ty": 2,
      "x": 1199,
      "y": 680
    },
    {
      "t": 12250,
      "e": 12250,
      "ty": 41,
      "x": 1127,
      "y": 51855,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12300,
      "e": 12300,
      "ty": 2,
      "x": 968,
      "y": 885
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 2,
      "x": 700,
      "y": 829
    },
    {
      "t": 12412,
      "e": 12412,
      "ty": 6,
      "x": 532,
      "y": 752,
      "ta": "#start"
    },
    {
      "t": 12429,
      "e": 12429,
      "ty": 7,
      "x": 405,
      "y": 696,
      "ta": "#start"
    },
    {
      "t": 12446,
      "e": 12446,
      "ty": 6,
      "x": 261,
      "y": 627,
      "ta": "#bigset.midpoint > ul > li:[13]"
    },
    {
      "t": 12463,
      "e": 12463,
      "ty": 7,
      "x": 103,
      "y": 546,
      "ta": "#bigset.midpoint > ul > li:[13]"
    },
    {
      "t": 12463,
      "e": 12463,
      "ty": 6,
      "x": 103,
      "y": 546,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 12480,
      "e": 12480,
      "ty": 7,
      "x": 0,
      "y": 473,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 12500,
      "e": 12500,
      "ty": 2,
      "x": 0,
      "y": 416
    },
    {
      "t": 12500,
      "e": 12500,
      "ty": 41,
      "x": 0,
      "y": 23045,
      "ta": "html"
    },
    {
      "t": 12600,
      "e": 12600,
      "ty": 2,
      "x": 0,
      "y": 365
    },
    {
      "t": 12700,
      "e": 12700,
      "ty": 2,
      "x": 8,
      "y": 326
    },
    {
      "t": 12751,
      "e": 12751,
      "ty": 41,
      "x": 2896,
      "y": 15345,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 12801,
      "e": 12801,
      "ty": 2,
      "x": 116,
      "y": 258
    },
    {
      "t": 12900,
      "e": 12900,
      "ty": 2,
      "x": 187,
      "y": 248
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 2,
      "x": 402,
      "y": 425
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 41,
      "x": 26537,
      "y": 5856,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 13028,
      "e": 13028,
      "ty": 6,
      "x": 487,
      "y": 549,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 13044,
      "e": 13044,
      "ty": 7,
      "x": 513,
      "y": 573,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 13063,
      "e": 13063,
      "ty": 6,
      "x": 524,
      "y": 583,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 13100,
      "e": 13100,
      "ty": 2,
      "x": 539,
      "y": 591
    },
    {
      "t": 13200,
      "e": 13200,
      "ty": 2,
      "x": 524,
      "y": 592
    },
    {
      "t": 13213,
      "e": 13213,
      "ty": 7,
      "x": 494,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 13213,
      "e": 13213,
      "ty": 6,
      "x": 494,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 13250,
      "e": 13250,
      "ty": 41,
      "x": 51536,
      "y": 45669,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 13300,
      "e": 13300,
      "ty": 2,
      "x": 447,
      "y": 599
    },
    {
      "t": 13500,
      "e": 13500,
      "ty": 2,
      "x": 361,
      "y": 591
    },
    {
      "t": 13500,
      "e": 13500,
      "ty": 41,
      "x": 25391,
      "y": 30378,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 13600,
      "e": 13600,
      "ty": 2,
      "x": 352,
      "y": 590
    },
    {
      "t": 13669,
      "e": 13669,
      "ty": 3,
      "x": 352,
      "y": 590,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 13750,
      "e": 13750,
      "ty": 41,
      "x": 22777,
      "y": 28193,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 13812,
      "e": 13812,
      "ty": 4,
      "x": 22777,
      "y": 28193,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 13900,
      "e": 13900,
      "ty": 2,
      "x": 353,
      "y": 590
    },
    {
      "t": 14000,
      "e": 14000,
      "ty": 2,
      "x": 400,
      "y": 598
    },
    {
      "t": 14000,
      "e": 14000,
      "ty": 41,
      "x": 39141,
      "y": 53340,
      "ta": "#bigset.midpoint > ul > li:[10] > label"
    },
    {
      "t": 14100,
      "e": 14100,
      "ty": 2,
      "x": 408,
      "y": 599
    },
    {
      "t": 14250,
      "e": 14250,
      "ty": 41,
      "x": 51528,
      "y": 56319,
      "ta": "#bigset.midpoint > ul > li:[10] > label"
    },
    {
      "t": 14324,
      "e": 14324,
      "ty": 3,
      "x": 408,
      "y": 599,
      "ta": "#bigset.midpoint > ul > li:[10] > label"
    },
    {
      "t": 14436,
      "e": 14436,
      "ty": 4,
      "x": 51528,
      "y": 56319,
      "ta": "#bigset.midpoint > ul > li:[10] > label"
    },
    {
      "t": 14436,
      "e": 14436,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > label > input"
    },
    {
      "t": 14439,
      "e": 14439,
      "ty": 5,
      "x": 408,
      "y": 599,
      "ta": "#bigset.midpoint > ul > li:[10] > label > input"
    },
    {
      "t": 14439,
      "e": 14439,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > label > input",
      "v": "K"
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 2,
      "x": 411,
      "y": 597
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 41,
      "x": 56172,
      "y": 50361,
      "ta": "#bigset.midpoint > ul > li:[10] > label"
    },
    {
      "t": 14600,
      "e": 14600,
      "ty": 2,
      "x": 463,
      "y": 580
    },
    {
      "t": 14681,
      "e": 14681,
      "ty": 7,
      "x": 470,
      "y": 576,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 14700,
      "e": 14700,
      "ty": 2,
      "x": 482,
      "y": 572
    },
    {
      "t": 14748,
      "e": 14748,
      "ty": 6,
      "x": 540,
      "y": 566,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 14750,
      "e": 14750,
      "ty": 41,
      "x": 11856,
      "y": 58776,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 14800,
      "e": 14800,
      "ty": 2,
      "x": 588,
      "y": 566
    },
    {
      "t": 14900,
      "e": 14900,
      "ty": 2,
      "x": 619,
      "y": 569
    },
    {
      "t": 14972,
      "e": 14972,
      "ty": 7,
      "x": 619,
      "y": 571,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 15000,
      "e": 15000,
      "ty": 2,
      "x": 619,
      "y": 575
    },
    {
      "t": 15000,
      "e": 15000,
      "ty": 41,
      "x": 41153,
      "y": 38279,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 15015,
      "e": 15015,
      "ty": 6,
      "x": 615,
      "y": 580,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 15100,
      "e": 15100,
      "ty": 2,
      "x": 612,
      "y": 589
    },
    {
      "t": 15200,
      "e": 15200,
      "ty": 2,
      "x": 612,
      "y": 594
    },
    {
      "t": 15251,
      "e": 15251,
      "ty": 41,
      "x": 38297,
      "y": 35737,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 15293,
      "e": 15293,
      "ty": 3,
      "x": 612,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 15293,
      "e": 15293,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > label > input"
    },
    {
      "t": 15468,
      "e": 15468,
      "ty": 4,
      "x": 38297,
      "y": 35737,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 15469,
      "e": 15469,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 15472,
      "e": 15472,
      "ty": 5,
      "x": 612,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 15473,
      "e": 15473,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input",
      "v": "X"
    },
    {
      "t": 15548,
      "e": 15548,
      "ty": 3,
      "x": 612,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 15548,
      "e": 15548,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 15596,
      "e": 15596,
      "ty": 4,
      "x": 38297,
      "y": 35737,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 15599,
      "e": 15599,
      "ty": 5,
      "x": 612,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 15600,
      "e": 15600,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input",
      "v": ""
    },
    {
      "t": 16765,
      "e": 16765,
      "ty": 3,
      "x": 612,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 16869,
      "e": 16869,
      "ty": 4,
      "x": 38297,
      "y": 35737,
      "ta": "#bigset.midpoint > ul > li:[11] > label > div"
    },
    {
      "t": 16870,
      "e": 16870,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 16876,
      "e": 16876,
      "ty": 5,
      "x": 612,
      "y": 594,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 16877,
      "e": 16877,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input",
      "v": "X"
    },
    {
      "t": 17037,
      "e": 17037,
      "ty": 7,
      "x": 612,
      "y": 612,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 17050,
      "e": 17050,
      "ty": 6,
      "x": 604,
      "y": 625,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 17066,
      "e": 17066,
      "ty": 7,
      "x": 587,
      "y": 650,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 17100,
      "e": 17100,
      "ty": 2,
      "x": 541,
      "y": 703
    },
    {
      "t": 17151,
      "e": 17151,
      "ty": 6,
      "x": 478,
      "y": 734,
      "ta": "#start"
    },
    {
      "t": 17200,
      "e": 17200,
      "ty": 2,
      "x": 466,
      "y": 737
    },
    {
      "t": 17251,
      "e": 17251,
      "ty": 41,
      "x": 11741,
      "y": 5601,
      "ta": "#start"
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 2,
      "x": 472,
      "y": 744
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 41,
      "x": 15018,
      "y": 19094,
      "ta": "#start"
    },
    {
      "t": 17601,
      "e": 17601,
      "ty": 2,
      "x": 481,
      "y": 749
    },
    {
      "t": 17750,
      "e": 17750,
      "ty": 41,
      "x": 19933,
      "y": 28731,
      "ta": "#start"
    },
    {
      "t": 18860,
      "e": 18860,
      "ty": 3,
      "x": 481,
      "y": 749,
      "ta": "#start"
    },
    {
      "t": 18861,
      "e": 18861,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > label > input"
    },
    {
      "t": 18861,
      "e": 18861,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 18988,
      "e": 18988,
      "ty": 4,
      "x": 19933,
      "y": 28731,
      "ta": "#start"
    },
    {
      "t": 19000,
      "e": 19000,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 19001,
      "e": 19001,
      "ty": 5,
      "x": 481,
      "y": 749,
      "ta": "#start"
    },
    {
      "t": 19006,
      "e": 19006,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 19400,
      "e": 19400,
      "ty": 2,
      "x": 483,
      "y": 749
    },
    {
      "t": 19501,
      "e": 19501,
      "ty": 2,
      "x": 756,
      "y": 687
    },
    {
      "t": 19501,
      "e": 19501,
      "ty": 41,
      "x": 25759,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 19600,
      "e": 19600,
      "ty": 2,
      "x": 1122,
      "y": 579
    },
    {
      "t": 19700,
      "e": 19700,
      "ty": 2,
      "x": 1172,
      "y": 544
    },
    {
      "t": 19750,
      "e": 19750,
      "ty": 41,
      "x": 40188,
      "y": 29415,
      "ta": "html > body"
    },
    {
      "t": 19801,
      "e": 19801,
      "ty": 2,
      "x": 1181,
      "y": 535
    },
    {
      "t": 19901,
      "e": 19901,
      "ty": 2,
      "x": 1194,
      "y": 520
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 2,
      "x": 1201,
      "y": 514
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 41,
      "x": 41084,
      "y": 28031,
      "ta": "html > body"
    },
    {
      "t": 20005,
      "e": 20005,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 20101,
      "e": 20101,
      "ty": 2,
      "x": 1206,
      "y": 509
    },
    {
      "t": 20200,
      "e": 20200,
      "ty": 2,
      "x": 1208,
      "y": 508
    },
    {
      "t": 20251,
      "e": 20251,
      "ty": 41,
      "x": 41359,
      "y": 27643,
      "ta": "html > body"
    },
    {
      "t": 20300,
      "e": 20300,
      "ty": 2,
      "x": 1209,
      "y": 507
    },
    {
      "t": 20569,
      "e": 20569,
      "ty": 6,
      "x": 997,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20600,
      "e": 20600,
      "ty": 2,
      "x": 922,
      "y": 571
    },
    {
      "t": 20701,
      "e": 20701,
      "ty": 2,
      "x": 886,
      "y": 573
    },
    {
      "t": 20751,
      "e": 20751,
      "ty": 41,
      "x": 16870,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20800,
      "e": 20800,
      "ty": 2,
      "x": 886,
      "y": 574
    },
    {
      "t": 20924,
      "e": 20924,
      "ty": 3,
      "x": 886,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20924,
      "e": 20924,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20979,
      "e": 20979,
      "ty": 4,
      "x": 16870,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20980,
      "e": 20980,
      "ty": 5,
      "x": 886,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 22008,
      "e": 22008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 22008,
      "e": 22008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 22079,
      "e": 22079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 22080,
      "e": 22080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 22104,
      "e": 22104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 22184,
      "e": 22184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 23100,
      "e": 23100,
      "ty": 2,
      "x": 886,
      "y": 572
    },
    {
      "t": 23121,
      "e": 23121,
      "ty": 7,
      "x": 820,
      "y": 532,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23200,
      "e": 23200,
      "ty": 2,
      "x": 766,
      "y": 508
    },
    {
      "t": 23251,
      "e": 23251,
      "ty": 41,
      "x": 26103,
      "y": 27698,
      "ta": "html > body"
    },
    {
      "t": 23600,
      "e": 23600,
      "ty": 2,
      "x": 782,
      "y": 543
    },
    {
      "t": 23605,
      "e": 23605,
      "ty": 6,
      "x": 847,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23621,
      "e": 23621,
      "ty": 7,
      "x": 921,
      "y": 761,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23701,
      "e": 23701,
      "ty": 2,
      "x": 959,
      "y": 791
    },
    {
      "t": 23750,
      "e": 23750,
      "ty": 41,
      "x": 32991,
      "y": 43154,
      "ta": "html > body"
    },
    {
      "t": 23788,
      "e": 23788,
      "ty": 6,
      "x": 983,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23801,
      "e": 23801,
      "ty": 2,
      "x": 983,
      "y": 698
    },
    {
      "t": 23838,
      "e": 23838,
      "ty": 7,
      "x": 957,
      "y": 670,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23855,
      "e": 23855,
      "ty": 6,
      "x": 948,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23900,
      "e": 23900,
      "ty": 2,
      "x": 944,
      "y": 663
    },
    {
      "t": 24000,
      "e": 24000,
      "ty": 2,
      "x": 928,
      "y": 656
    },
    {
      "t": 24000,
      "e": 24000,
      "ty": 41,
      "x": 25954,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24061,
      "e": 24061,
      "ty": 3,
      "x": 928,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24061,
      "e": 24061,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 24061,
      "e": 24061,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24061,
      "e": 24061,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24124,
      "e": 24124,
      "ty": 4,
      "x": 25954,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24124,
      "e": 24124,
      "ty": 5,
      "x": 928,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24300,
      "e": 24300,
      "ty": 2,
      "x": 926,
      "y": 656
    },
    {
      "t": 24501,
      "e": 24501,
      "ty": 41,
      "x": 25521,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26063,
      "e": 26063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 26151,
      "e": 26151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 26223,
      "e": 26223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 26223,
      "e": 26223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26311,
      "e": 26311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 26328,
      "e": 26328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 26408,
      "e": 26408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 26441,
      "e": 26441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 26442,
      "e": 26442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26543,
      "e": 26543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 26544,
      "e": 26544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26576,
      "e": 26576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uNI"
    },
    {
      "t": 26600,
      "e": 26600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 26600,
      "e": 26600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26640,
      "e": 26640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uNIT"
    },
    {
      "t": 26680,
      "e": 26680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 26768,
      "e": 26768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 26769,
      "e": 26769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26864,
      "e": 26864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||E"
    },
    {
      "t": 27161,
      "e": 27161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 27224,
      "e": 27224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uNIT"
    },
    {
      "t": 27297,
      "e": 27297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 27344,
      "e": 27344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uNI"
    },
    {
      "t": 27440,
      "e": 27440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 27488,
      "e": 27488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uN"
    },
    {
      "t": 27584,
      "e": 27584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 27632,
      "e": 27632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 27719,
      "e": 27719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 27808,
      "e": 27808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 28008,
      "e": 28008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 28008,
      "e": 28008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28120,
      "e": 28120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 28321,
      "e": 28321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 28385,
      "e": 28385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 28488,
      "e": 28488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "74"
    },
    {
      "t": 28488,
      "e": 28488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28543,
      "e": 28543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 28543,
      "e": 28543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28584,
      "e": 28544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uji"
    },
    {
      "t": 28655,
      "e": 28615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uji"
    },
    {
      "t": 28960,
      "e": 28920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 29009,
      "e": 28969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uj"
    },
    {
      "t": 29103,
      "e": 29063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 29159,
      "e": 29119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 29825,
      "e": 29785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 29825,
      "e": 29785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29911,
      "e": 29871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 29911,
      "e": 29871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29936,
      "e": 29896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 29960,
      "e": 29920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 29960,
      "e": 29920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29991,
      "e": 29951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 30056,
      "e": 30016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 30104,
      "e": 30064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 30104,
      "e": 30064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30199,
      "e": 30159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 30279,
      "e": 30239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 30279,
      "e": 30239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30360,
      "e": 30320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 30440,
      "e": 30400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 30440,
      "e": 30400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30503,
      "e": 30463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 30655,
      "e": 30615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 30760,
      "e": 30720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 30760,
      "e": 30720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30776,
      "e": 30736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 30864,
      "e": 30824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 30880,
      "e": 30840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 30992,
      "e": 30952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 30992,
      "e": 30952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30999,
      "e": 30959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 31096,
      "e": 31056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 31136,
      "e": 31096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 31136,
      "e": 31096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31215,
      "e": 31175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 31216,
      "e": 31176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31247,
      "e": 31207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 31328,
      "e": 31288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 31367,
      "e": 31327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 31368,
      "e": 31328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31487,
      "e": 31447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 31487,
      "e": 31447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 31488,
      "e": 31448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31584,
      "e": 31544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 32600,
      "e": 32560,
      "ty": 2,
      "x": 930,
      "y": 657
    },
    {
      "t": 32704,
      "e": 32664,
      "ty": 2,
      "x": 932,
      "y": 658
    },
    {
      "t": 32733,
      "e": 32693,
      "ty": 7,
      "x": 938,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32751,
      "e": 32711,
      "ty": 6,
      "x": 945,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32755,
      "e": 32715,
      "ty": 41,
      "x": 25294,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32782,
      "e": 32742,
      "ty": 7,
      "x": 949,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32804,
      "e": 32764,
      "ty": 2,
      "x": 949,
      "y": 712
    },
    {
      "t": 32905,
      "e": 32865,
      "ty": 2,
      "x": 946,
      "y": 712
    },
    {
      "t": 32984,
      "e": 32944,
      "ty": 6,
      "x": 945,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33003,
      "e": 32963,
      "ty": 2,
      "x": 945,
      "y": 702
    },
    {
      "t": 33004,
      "e": 32964,
      "ty": 41,
      "x": 25294,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33104,
      "e": 33064,
      "ty": 2,
      "x": 948,
      "y": 689
    },
    {
      "t": 33204,
      "e": 33164,
      "ty": 2,
      "x": 952,
      "y": 682
    },
    {
      "t": 33254,
      "e": 33214,
      "ty": 41,
      "x": 28902,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33287,
      "e": 33247,
      "ty": 3,
      "x": 952,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33287,
      "e": 33247,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 33287,
      "e": 33247,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33288,
      "e": 33248,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33376,
      "e": 33336,
      "ty": 4,
      "x": 28902,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33376,
      "e": 33336,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33377,
      "e": 33337,
      "ty": 5,
      "x": 952,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33377,
      "e": 33337,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 33604,
      "e": 33564,
      "ty": 2,
      "x": 1022,
      "y": 681
    },
    {
      "t": 33705,
      "e": 33665,
      "ty": 2,
      "x": 1137,
      "y": 711
    },
    {
      "t": 33754,
      "e": 33714,
      "ty": 41,
      "x": 39121,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 33804,
      "e": 33764,
      "ty": 2,
      "x": 1145,
      "y": 711
    },
    {
      "t": 34004,
      "e": 33964,
      "ty": 41,
      "x": 39155,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 34393,
      "e": 34353,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 35104,
      "e": 35064,
      "ty": 2,
      "x": 528,
      "y": 471
    },
    {
      "t": 35203,
      "e": 35163,
      "ty": 2,
      "x": 598,
      "y": 374
    },
    {
      "t": 35254,
      "e": 35214,
      "ty": 41,
      "x": 20628,
      "y": 18668,
      "ta": "html > body"
    },
    {
      "t": 35304,
      "e": 35264,
      "ty": 2,
      "x": 627,
      "y": 320
    },
    {
      "t": 35404,
      "e": 35364,
      "ty": 2,
      "x": 649,
      "y": 250
    },
    {
      "t": 35504,
      "e": 35464,
      "ty": 2,
      "x": 1075,
      "y": 289
    },
    {
      "t": 35504,
      "e": 35464,
      "ty": 41,
      "x": 60180,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 35604,
      "e": 35564,
      "ty": 2,
      "x": 1033,
      "y": 263
    },
    {
      "t": 35703,
      "e": 35663,
      "ty": 2,
      "x": 987,
      "y": 254
    },
    {
      "t": 35754,
      "e": 35714,
      "ty": 41,
      "x": 32413,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 35804,
      "e": 35764,
      "ty": 2,
      "x": 947,
      "y": 241
    },
    {
      "t": 35904,
      "e": 35864,
      "ty": 2,
      "x": 850,
      "y": 240
    },
    {
      "t": 36003,
      "e": 35963,
      "ty": 2,
      "x": 856,
      "y": 249
    },
    {
      "t": 36003,
      "e": 35963,
      "ty": 41,
      "x": 8206,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 36104,
      "e": 36064,
      "ty": 2,
      "x": 858,
      "y": 250
    },
    {
      "t": 36254,
      "e": 36214,
      "ty": 41,
      "x": 8680,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 36352,
      "e": 36312,
      "ty": 6,
      "x": 832,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36404,
      "e": 36364,
      "ty": 2,
      "x": 830,
      "y": 243
    },
    {
      "t": 36504,
      "e": 36464,
      "ty": 41,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36575,
      "e": 36535,
      "ty": 3,
      "x": 830,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36576,
      "e": 36536,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36696,
      "e": 36656,
      "ty": 4,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36696,
      "e": 36656,
      "ty": 5,
      "x": 830,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36697,
      "e": 36657,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 36848,
      "e": 36808,
      "ty": 7,
      "x": 830,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36869,
      "e": 36829,
      "ty": 6,
      "x": 835,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 36885,
      "e": 36845,
      "ty": 7,
      "x": 840,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 36904,
      "e": 36864,
      "ty": 2,
      "x": 842,
      "y": 289
    },
    {
      "t": 37004,
      "e": 36964,
      "ty": 2,
      "x": 844,
      "y": 334
    },
    {
      "t": 37004,
      "e": 36964,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 37104,
      "e": 37064,
      "ty": 2,
      "x": 903,
      "y": 524
    },
    {
      "t": 37204,
      "e": 37164,
      "ty": 2,
      "x": 899,
      "y": 556
    },
    {
      "t": 37253,
      "e": 37213,
      "ty": 41,
      "x": 15088,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 37304,
      "e": 37264,
      "ty": 2,
      "x": 856,
      "y": 466
    },
    {
      "t": 37403,
      "e": 37363,
      "ty": 2,
      "x": 845,
      "y": 426
    },
    {
      "t": 37504,
      "e": 37464,
      "ty": 2,
      "x": 843,
      "y": 419
    },
    {
      "t": 37504,
      "e": 37464,
      "ty": 41,
      "x": 25259,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 38004,
      "e": 37964,
      "ty": 2,
      "x": 888,
      "y": 458
    },
    {
      "t": 38004,
      "e": 37964,
      "ty": 41,
      "x": 15800,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 38303,
      "e": 38263,
      "ty": 2,
      "x": 880,
      "y": 458
    },
    {
      "t": 38404,
      "e": 38364,
      "ty": 2,
      "x": 872,
      "y": 434
    },
    {
      "t": 38504,
      "e": 38464,
      "ty": 2,
      "x": 871,
      "y": 430
    },
    {
      "t": 38504,
      "e": 38464,
      "ty": 41,
      "x": 11766,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 39754,
      "e": 39714,
      "ty": 41,
      "x": 11766,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 39804,
      "e": 39764,
      "ty": 2,
      "x": 866,
      "y": 413
    },
    {
      "t": 39904,
      "e": 39864,
      "ty": 2,
      "x": 858,
      "y": 390
    },
    {
      "t": 40004,
      "e": 39964,
      "ty": 2,
      "x": 849,
      "y": 353
    },
    {
      "t": 40005,
      "e": 39965,
      "ty": 41,
      "x": 6544,
      "y": 14347,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 40104,
      "e": 40064,
      "ty": 2,
      "x": 848,
      "y": 351
    },
    {
      "t": 40255,
      "e": 40215,
      "ty": 41,
      "x": 6307,
      "y": 14198,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 40404,
      "e": 40364,
      "ty": 2,
      "x": 860,
      "y": 357
    },
    {
      "t": 40504,
      "e": 40464,
      "ty": 2,
      "x": 902,
      "y": 366
    },
    {
      "t": 40504,
      "e": 40464,
      "ty": 41,
      "x": 19123,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 40604,
      "e": 40564,
      "ty": 2,
      "x": 960,
      "y": 374
    },
    {
      "t": 40704,
      "e": 40664,
      "ty": 2,
      "x": 995,
      "y": 377
    },
    {
      "t": 40754,
      "e": 40714,
      "ty": 41,
      "x": 42381,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 40804,
      "e": 40764,
      "ty": 2,
      "x": 1003,
      "y": 379
    },
    {
      "t": 41005,
      "e": 40965,
      "ty": 41,
      "x": 43092,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 44204,
      "e": 44164,
      "ty": 2,
      "x": 957,
      "y": 421
    },
    {
      "t": 44255,
      "e": 44215,
      "ty": 41,
      "x": 28141,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 44305,
      "e": 44265,
      "ty": 2,
      "x": 925,
      "y": 470
    },
    {
      "t": 44404,
      "e": 44364,
      "ty": 2,
      "x": 863,
      "y": 573
    },
    {
      "t": 44504,
      "e": 44464,
      "ty": 2,
      "x": 820,
      "y": 617
    },
    {
      "t": 44504,
      "e": 44464,
      "ty": 41,
      "x": 27963,
      "y": 33736,
      "ta": "html > body"
    },
    {
      "t": 44604,
      "e": 44564,
      "ty": 2,
      "x": 817,
      "y": 617
    },
    {
      "t": 44705,
      "e": 44665,
      "ty": 2,
      "x": 799,
      "y": 546
    },
    {
      "t": 44754,
      "e": 44714,
      "ty": 41,
      "x": 27205,
      "y": 28972,
      "ta": "html > body"
    },
    {
      "t": 44804,
      "e": 44764,
      "ty": 2,
      "x": 798,
      "y": 526
    },
    {
      "t": 44905,
      "e": 44865,
      "ty": 2,
      "x": 809,
      "y": 510
    },
    {
      "t": 44992,
      "e": 44952,
      "ty": 6,
      "x": 826,
      "y": 503,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45004,
      "e": 44964,
      "ty": 2,
      "x": 826,
      "y": 503
    },
    {
      "t": 45004,
      "e": 44964,
      "ty": 41,
      "x": 0,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45104,
      "e": 45064,
      "ty": 2,
      "x": 837,
      "y": 500
    },
    {
      "t": 45204,
      "e": 45164,
      "ty": 2,
      "x": 839,
      "y": 499
    },
    {
      "t": 45255,
      "e": 45215,
      "ty": 41,
      "x": 63408,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45496,
      "e": 45456,
      "ty": 3,
      "x": 839,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45497,
      "e": 45457,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45498,
      "e": 45458,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45663,
      "e": 45623,
      "ty": 4,
      "x": 63408,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45664,
      "e": 45624,
      "ty": 5,
      "x": 839,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 45664,
      "e": 45624,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 46254,
      "e": 46214,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46259,
      "e": 46219,
      "ty": 7,
      "x": 840,
      "y": 510,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46304,
      "e": 46264,
      "ty": 2,
      "x": 841,
      "y": 519
    },
    {
      "t": 46404,
      "e": 46364,
      "ty": 2,
      "x": 852,
      "y": 555
    },
    {
      "t": 46504,
      "e": 46464,
      "ty": 2,
      "x": 859,
      "y": 581
    },
    {
      "t": 46504,
      "e": 46464,
      "ty": 41,
      "x": 37304,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 46605,
      "e": 46565,
      "ty": 2,
      "x": 862,
      "y": 607
    },
    {
      "t": 46704,
      "e": 46664,
      "ty": 2,
      "x": 860,
      "y": 613
    },
    {
      "t": 46754,
      "e": 46714,
      "ty": 41,
      "x": 8918,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 46804,
      "e": 46764,
      "ty": 2,
      "x": 859,
      "y": 616
    },
    {
      "t": 46904,
      "e": 46864,
      "ty": 2,
      "x": 858,
      "y": 617
    },
    {
      "t": 47005,
      "e": 46965,
      "ty": 41,
      "x": 8680,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 47904,
      "e": 47864,
      "ty": 2,
      "x": 845,
      "y": 665
    },
    {
      "t": 47929,
      "e": 47865,
      "ty": 6,
      "x": 826,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 47945,
      "e": 47881,
      "ty": 7,
      "x": 822,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48004,
      "e": 47940,
      "ty": 2,
      "x": 817,
      "y": 725
    },
    {
      "t": 48004,
      "e": 47940,
      "ty": 41,
      "x": 27860,
      "y": 39719,
      "ta": "html > body"
    },
    {
      "t": 48504,
      "e": 48440,
      "ty": 2,
      "x": 820,
      "y": 717
    },
    {
      "t": 48504,
      "e": 48440,
      "ty": 41,
      "x": 27963,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 48605,
      "e": 48541,
      "ty": 2,
      "x": 820,
      "y": 711
    },
    {
      "t": 48705,
      "e": 48641,
      "ty": 2,
      "x": 820,
      "y": 707
    },
    {
      "t": 48755,
      "e": 48691,
      "ty": 41,
      "x": 0,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 48804,
      "e": 48740,
      "ty": 2,
      "x": 823,
      "y": 703
    },
    {
      "t": 48863,
      "e": 48799,
      "ty": 6,
      "x": 826,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48904,
      "e": 48840,
      "ty": 2,
      "x": 828,
      "y": 700
    },
    {
      "t": 49004,
      "e": 48940,
      "ty": 2,
      "x": 829,
      "y": 700
    },
    {
      "t": 49004,
      "e": 48940,
      "ty": 41,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49055,
      "e": 48991,
      "ty": 3,
      "x": 829,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49056,
      "e": 48992,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 49056,
      "e": 48992,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49288,
      "e": 49224,
      "ty": 4,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49288,
      "e": 49224,
      "ty": 5,
      "x": 829,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49290,
      "e": 49226,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 51976,
      "e": 51912,
      "ty": 7,
      "x": 830,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52004,
      "e": 51940,
      "ty": 2,
      "x": 830,
      "y": 739
    },
    {
      "t": 52005,
      "e": 51941,
      "ty": 41,
      "x": 2152,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 52064,
      "e": 52000,
      "ty": 6,
      "x": 839,
      "y": 814,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 52081,
      "e": 52017,
      "ty": 7,
      "x": 840,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 52104,
      "e": 52040,
      "ty": 2,
      "x": 840,
      "y": 826
    },
    {
      "t": 52204,
      "e": 52140,
      "ty": 2,
      "x": 840,
      "y": 856
    },
    {
      "t": 52255,
      "e": 52191,
      "ty": 41,
      "x": 2510,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 52305,
      "e": 52241,
      "ty": 2,
      "x": 805,
      "y": 935
    },
    {
      "t": 52404,
      "e": 52340,
      "ty": 2,
      "x": 794,
      "y": 964
    },
    {
      "t": 52504,
      "e": 52440,
      "ty": 2,
      "x": 795,
      "y": 974
    },
    {
      "t": 52504,
      "e": 52440,
      "ty": 41,
      "x": 27102,
      "y": 53513,
      "ta": "html > body"
    },
    {
      "t": 52704,
      "e": 52640,
      "ty": 2,
      "x": 829,
      "y": 923
    },
    {
      "t": 52755,
      "e": 52691,
      "ty": 41,
      "x": 3222,
      "y": 20668,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 52804,
      "e": 52740,
      "ty": 2,
      "x": 842,
      "y": 913
    },
    {
      "t": 52904,
      "e": 52840,
      "ty": 2,
      "x": 844,
      "y": 914
    },
    {
      "t": 52931,
      "e": 52867,
      "ty": 6,
      "x": 839,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 53004,
      "e": 52940,
      "ty": 2,
      "x": 838,
      "y": 939
    },
    {
      "t": 53005,
      "e": 52941,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 53015,
      "e": 52951,
      "ty": 7,
      "x": 838,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 53105,
      "e": 53041,
      "ty": 2,
      "x": 838,
      "y": 949
    },
    {
      "t": 53255,
      "e": 53191,
      "ty": 41,
      "x": 3934,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 53403,
      "e": 53339,
      "ty": 2,
      "x": 838,
      "y": 954
    },
    {
      "t": 53432,
      "e": 53368,
      "ty": 6,
      "x": 837,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53505,
      "e": 53441,
      "ty": 2,
      "x": 836,
      "y": 960
    },
    {
      "t": 53505,
      "e": 53441,
      "ty": 41,
      "x": 48284,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53605,
      "e": 53541,
      "ty": 2,
      "x": 836,
      "y": 961
    },
    {
      "t": 53656,
      "e": 53592,
      "ty": 3,
      "x": 836,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53658,
      "e": 53594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 53658,
      "e": 53594,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53728,
      "e": 53664,
      "ty": 4,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53729,
      "e": 53665,
      "ty": 5,
      "x": 836,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53729,
      "e": 53665,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 53755,
      "e": 53691,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53888,
      "e": 53824,
      "ty": 7,
      "x": 843,
      "y": 980,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53905,
      "e": 53841,
      "ty": 2,
      "x": 850,
      "y": 992
    },
    {
      "t": 53916,
      "e": 53841,
      "ty": 6,
      "x": 861,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 53949,
      "e": 53874,
      "ty": 7,
      "x": 885,
      "y": 1050,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54004,
      "e": 53929,
      "ty": 2,
      "x": 888,
      "y": 1056
    },
    {
      "t": 54005,
      "e": 53930,
      "ty": 41,
      "x": 30305,
      "y": 58056,
      "ta": "html > body"
    },
    {
      "t": 54105,
      "e": 54030,
      "ty": 2,
      "x": 888,
      "y": 1054
    },
    {
      "t": 54166,
      "e": 54091,
      "ty": 6,
      "x": 889,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54204,
      "e": 54129,
      "ty": 2,
      "x": 889,
      "y": 1032
    },
    {
      "t": 54254,
      "e": 54179,
      "ty": 41,
      "x": 30705,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54304,
      "e": 54229,
      "ty": 2,
      "x": 890,
      "y": 1026
    },
    {
      "t": 54505,
      "e": 54430,
      "ty": 41,
      "x": 31221,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54600,
      "e": 54525,
      "ty": 3,
      "x": 890,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54600,
      "e": 54525,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 54600,
      "e": 54525,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54695,
      "e": 54620,
      "ty": 4,
      "x": 31221,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54695,
      "e": 54620,
      "ty": 5,
      "x": 890,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54698,
      "e": 54623,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54699,
      "e": 54624,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54700,
      "e": 54625,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 55104,
      "e": 55029,
      "ty": 2,
      "x": 907,
      "y": 1011
    },
    {
      "t": 55205,
      "e": 55130,
      "ty": 2,
      "x": 1000,
      "y": 772
    },
    {
      "t": 55255,
      "e": 55180,
      "ty": 41,
      "x": 33094,
      "y": 32130,
      "ta": "html > body"
    },
    {
      "t": 55305,
      "e": 55230,
      "ty": 2,
      "x": 983,
      "y": 531
    },
    {
      "t": 55405,
      "e": 55330,
      "ty": 2,
      "x": 1034,
      "y": 428
    },
    {
      "t": 55505,
      "e": 55430,
      "ty": 2,
      "x": 1037,
      "y": 414
    },
    {
      "t": 55505,
      "e": 55430,
      "ty": 41,
      "x": 35436,
      "y": 22491,
      "ta": "html > body"
    },
    {
      "t": 55605,
      "e": 55530,
      "ty": 2,
      "x": 1039,
      "y": 411
    },
    {
      "t": 55705,
      "e": 55630,
      "ty": 2,
      "x": 1040,
      "y": 409
    },
    {
      "t": 55755,
      "e": 55680,
      "ty": 41,
      "x": 35539,
      "y": 22214,
      "ta": "html > body"
    },
    {
      "t": 55790,
      "e": 55715,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 55804,
      "e": 55729,
      "ty": 2,
      "x": 1040,
      "y": 408
    },
    {
      "t": 56003,
      "e": 55928,
      "ty": 2,
      "x": 1041,
      "y": 406
    },
    {
      "t": 56004,
      "e": 55929,
      "ty": 41,
      "x": 36777,
      "y": 19906,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 56503,
      "e": 56428,
      "ty": 2,
      "x": 1035,
      "y": 391
    },
    {
      "t": 56504,
      "e": 56429,
      "ty": 41,
      "x": 36481,
      "y": 8204,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 56604,
      "e": 56529,
      "ty": 2,
      "x": 1031,
      "y": 385
    },
    {
      "t": 56755,
      "e": 56680,
      "ty": 41,
      "x": 36285,
      "y": 3522,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 57003,
      "e": 56928,
      "ty": 2,
      "x": 310,
      "y": 302
    },
    {
      "t": 57004,
      "e": 56929,
      "ty": 41,
      "x": 814,
      "y": 12166,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57104,
      "e": 57029,
      "ty": 2,
      "x": 0,
      "y": 228
    },
    {
      "t": 57204,
      "e": 57129,
      "ty": 2,
      "x": 1,
      "y": 228
    },
    {
      "t": 57255,
      "e": 57180,
      "ty": 41,
      "x": 1480,
      "y": 12852,
      "ta": "> div.masterdiv"
    },
    {
      "t": 57304,
      "e": 57229,
      "ty": 2,
      "x": 101,
      "y": 250
    },
    {
      "t": 57505,
      "e": 57430,
      "ty": 2,
      "x": 102,
      "y": 250
    },
    {
      "t": 57505,
      "e": 57430,
      "ty": 41,
      "x": 3237,
      "y": 13406,
      "ta": "> div.masterdiv"
    },
    {
      "t": 57604,
      "e": 57529,
      "ty": 2,
      "x": 98,
      "y": 245
    },
    {
      "t": 57704,
      "e": 57629,
      "ty": 2,
      "x": 95,
      "y": 239
    },
    {
      "t": 57755,
      "e": 57680,
      "ty": 41,
      "x": 2996,
      "y": 12353,
      "ta": "> div.masterdiv"
    },
    {
      "t": 57804,
      "e": 57729,
      "ty": 2,
      "x": 97,
      "y": 216
    },
    {
      "t": 58004,
      "e": 57929,
      "ty": 41,
      "x": 3064,
      "y": 11522,
      "ta": "> div.masterdiv"
    },
    {
      "t": 58204,
      "e": 58129,
      "ty": 2,
      "x": 98,
      "y": 215
    },
    {
      "t": 58254,
      "e": 58179,
      "ty": 41,
      "x": 3133,
      "y": 11467,
      "ta": "> div.masterdiv"
    },
    {
      "t": 58304,
      "e": 58229,
      "ty": 2,
      "x": 99,
      "y": 215
    },
    {
      "t": 58603,
      "e": 58528,
      "ty": 2,
      "x": 102,
      "y": 217
    },
    {
      "t": 58704,
      "e": 58629,
      "ty": 2,
      "x": 104,
      "y": 223
    },
    {
      "t": 58754,
      "e": 58679,
      "ty": 41,
      "x": 3374,
      "y": 12187,
      "ta": "> div.masterdiv"
    },
    {
      "t": 58804,
      "e": 58729,
      "ty": 2,
      "x": 106,
      "y": 229
    },
    {
      "t": 58903,
      "e": 58828,
      "ty": 2,
      "x": 113,
      "y": 235
    },
    {
      "t": 59004,
      "e": 58929,
      "ty": 2,
      "x": 128,
      "y": 243
    },
    {
      "t": 59004,
      "e": 58929,
      "ty": 41,
      "x": 4132,
      "y": 13018,
      "ta": "> div.masterdiv"
    },
    {
      "t": 59105,
      "e": 59030,
      "ty": 2,
      "x": 136,
      "y": 256
    },
    {
      "t": 59204,
      "e": 59129,
      "ty": 2,
      "x": 165,
      "y": 277
    },
    {
      "t": 59254,
      "e": 59179,
      "ty": 41,
      "x": 5406,
      "y": 14957,
      "ta": "> div.masterdiv"
    },
    {
      "t": 59304,
      "e": 59229,
      "ty": 2,
      "x": 162,
      "y": 280
    },
    {
      "t": 59504,
      "e": 59429,
      "ty": 41,
      "x": 5303,
      "y": 15068,
      "ta": "> div.masterdiv"
    },
    {
      "t": 59803,
      "e": 59728,
      "ty": 2,
      "x": 163,
      "y": 280
    },
    {
      "t": 60004,
      "e": 59929,
      "ty": 41,
      "x": 5337,
      "y": 15068,
      "ta": "> div.masterdiv"
    },
    {
      "t": 60004,
      "e": 59929,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60404,
      "e": 60329,
      "ty": 2,
      "x": 164,
      "y": 281
    },
    {
      "t": 60505,
      "e": 60430,
      "ty": 41,
      "x": 5372,
      "y": 15123,
      "ta": "> div.masterdiv"
    },
    {
      "t": 60704,
      "e": 60629,
      "ty": 2,
      "x": 165,
      "y": 285
    },
    {
      "t": 60754,
      "e": 60679,
      "ty": 41,
      "x": 5441,
      "y": 15788,
      "ta": "> div.masterdiv"
    },
    {
      "t": 60804,
      "e": 60729,
      "ty": 2,
      "x": 166,
      "y": 295
    },
    {
      "t": 60904,
      "e": 60829,
      "ty": 2,
      "x": 167,
      "y": 296
    },
    {
      "t": 61004,
      "e": 60929,
      "ty": 41,
      "x": 5475,
      "y": 15954,
      "ta": "> div.masterdiv"
    },
    {
      "t": 62104,
      "e": 62029,
      "ty": 2,
      "x": 167,
      "y": 301
    },
    {
      "t": 62204,
      "e": 62129,
      "ty": 2,
      "x": 167,
      "y": 302
    },
    {
      "t": 62254,
      "e": 62179,
      "ty": 41,
      "x": 5475,
      "y": 16342,
      "ta": "> div.masterdiv"
    },
    {
      "t": 62304,
      "e": 62229,
      "ty": 2,
      "x": 167,
      "y": 303
    },
    {
      "t": 62504,
      "e": 62429,
      "ty": 2,
      "x": 169,
      "y": 311
    },
    {
      "t": 62504,
      "e": 62429,
      "ty": 41,
      "x": 5544,
      "y": 16785,
      "ta": "> div.masterdiv"
    },
    {
      "t": 62604,
      "e": 62529,
      "ty": 2,
      "x": 170,
      "y": 312
    },
    {
      "t": 62754,
      "e": 62679,
      "ty": 41,
      "x": 5578,
      "y": 16840,
      "ta": "> div.masterdiv"
    },
    {
      "t": 65004,
      "e": 64929,
      "ty": 2,
      "x": 170,
      "y": 313
    },
    {
      "t": 65004,
      "e": 64929,
      "ty": 41,
      "x": 5578,
      "y": 16896,
      "ta": "> div.masterdiv"
    },
    {
      "t": 65104,
      "e": 65029,
      "ty": 2,
      "x": 171,
      "y": 314
    },
    {
      "t": 65254,
      "e": 65179,
      "ty": 41,
      "x": 5613,
      "y": 16951,
      "ta": "> div.masterdiv"
    },
    {
      "t": 70004,
      "e": 69929,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 74605,
      "e": 70179,
      "ty": 2,
      "x": 171,
      "y": 315
    },
    {
      "t": 74755,
      "e": 70329,
      "ty": 41,
      "x": 5613,
      "y": 17006,
      "ta": "> div.masterdiv"
    },
    {
      "t": 74805,
      "e": 70379,
      "ty": 2,
      "x": 179,
      "y": 335
    },
    {
      "t": 74904,
      "e": 70478,
      "ty": 2,
      "x": 356,
      "y": 631
    },
    {
      "t": 75004,
      "e": 70578,
      "ty": 2,
      "x": 567,
      "y": 858
    },
    {
      "t": 75004,
      "e": 70578,
      "ty": 41,
      "x": 13457,
      "y": 60615,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 75105,
      "e": 70679,
      "ty": 2,
      "x": 859,
      "y": 1129
    },
    {
      "t": 75205,
      "e": 70779,
      "ty": 2,
      "x": 890,
      "y": 1199
    },
    {
      "t": 75304,
      "e": 70878,
      "ty": 2,
      "x": 982,
      "y": 1199
    },
    {
      "t": 75404,
      "e": 70978,
      "ty": 2,
      "x": 993,
      "y": 1195
    },
    {
      "t": 75500,
      "e": 71074,
      "ty": 6,
      "x": 993,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 75505,
      "e": 71079,
      "ty": 2,
      "x": 993,
      "y": 1106
    },
    {
      "t": 75505,
      "e": 71079,
      "ty": 41,
      "x": 45601,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 75533,
      "e": 71107,
      "ty": 7,
      "x": 984,
      "y": 1045,
      "ta": "#start"
    },
    {
      "t": 75605,
      "e": 71179,
      "ty": 2,
      "x": 1012,
      "y": 992
    },
    {
      "t": 75704,
      "e": 71278,
      "ty": 2,
      "x": 989,
      "y": 1007
    },
    {
      "t": 75755,
      "e": 71329,
      "ty": 41,
      "x": 33874,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75767,
      "e": 71341,
      "ty": 6,
      "x": 982,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 75804,
      "e": 71378,
      "ty": 2,
      "x": 987,
      "y": 1096
    },
    {
      "t": 75905,
      "e": 71479,
      "ty": 2,
      "x": 1003,
      "y": 1102
    },
    {
      "t": 76004,
      "e": 71578,
      "ty": 41,
      "x": 51062,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 76204,
      "e": 71778,
      "ty": 2,
      "x": 984,
      "y": 1091
    },
    {
      "t": 76255,
      "e": 71829,
      "ty": 41,
      "x": 40686,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 76505,
      "e": 72079,
      "ty": 2,
      "x": 983,
      "y": 1091
    },
    {
      "t": 76505,
      "e": 72079,
      "ty": 41,
      "x": 40140,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 77559,
      "e": 73133,
      "ty": 3,
      "x": 983,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 77559,
      "e": 73133,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 77703,
      "e": 73277,
      "ty": 4,
      "x": 39594,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 77704,
      "e": 73278,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 77704,
      "e": 73278,
      "ty": 5,
      "x": 982,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 77705,
      "e": 73279,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 77707,
      "e": 73281,
      "ty": 2,
      "x": 982,
      "y": 1090
    },
    {
      "t": 77755,
      "e": 73329,
      "ty": 41,
      "x": 33542,
      "y": 59939,
      "ta": "html > body"
    },
    {
      "t": 78104,
      "e": 73678,
      "ty": 2,
      "x": 990,
      "y": 1071
    },
    {
      "t": 78205,
      "e": 73779,
      "ty": 2,
      "x": 993,
      "y": 1068
    },
    {
      "t": 78255,
      "e": 73829,
      "ty": 41,
      "x": 33921,
      "y": 58721,
      "ta": "html > body"
    },
    {
      "t": 78404,
      "e": 73978,
      "ty": 2,
      "x": 994,
      "y": 1063
    },
    {
      "t": 78505,
      "e": 74079,
      "ty": 2,
      "x": 997,
      "y": 1049
    },
    {
      "t": 78505,
      "e": 74079,
      "ty": 41,
      "x": 34058,
      "y": 57668,
      "ta": "html > body"
    },
    {
      "t": 78604,
      "e": 74178,
      "ty": 2,
      "x": 997,
      "y": 1048
    },
    {
      "t": 78744,
      "e": 74318,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 79767,
      "e": 75341,
      "ty": 41,
      "x": 34908,
      "y": 32848,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 79904,
      "e": 75478,
      "ty": 2,
      "x": 1009,
      "y": 1044
    },
    {
      "t": 80005,
      "e": 75579,
      "ty": 41,
      "x": 35593,
      "y": 32847,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 80005,
      "e": 75579,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80386,
      "e": 75960,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"nodeType\":3,\"id\":2585,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2582},{\"id\":2583},{\"nodeType\":3,\"id\":2586,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2584}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2587,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2588,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2587},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2589,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2588},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2589},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2591,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2588}},{\"nodeType\":1,\"id\":2592,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2591},\"parentNode\":{\"id\":2588}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2591}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2589}},{\"nodeType\":1,\"id\":2595,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2594},\"parentNode\":{\"id\":2589}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2594}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2590}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2587},{\"id\":2588},{\"id\":2591},{\"id\":2593},{\"id\":2592},{\"id\":2589},{\"id\":2594},{\"id\":2596},{\"id\":2595},{\"id\":2590},{\"id\":2597}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2610,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2614,\"textContent\":\"English\",\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2617,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":3,\"id\":2620,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2623,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2624,\"textContent\":\"*\",\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2635}},{\"nodeType\":3,\"id\":2637,\"textContent\":\"First\",\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2635}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":3,\"id\":2640,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":3,\"id\":2646,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2651},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2655,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"*\",\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2657},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2660},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2663},\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2667}},{\"nodeType\":3,\"id\":2669,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2667}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2659}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":3,\"id\":2672,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":3,\"id\":2678,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2662}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2683},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2687,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2686},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"*\",\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2689},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2603}},{\"nodeType\":3,\"id\":2693,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2691}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"*\",\"parentNode\":{\"id\":2694}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"id\":2605},{\"id\":2610},{\"id\":2611},{\"id\":2624},{\"id\":2606},{\"id\":2612},{\"id\":2613},{\"id\":2614},{\"id\":2607},{\"id\":2615},{\"id\":2616},{\"id\":2617},{\"id\":2608},{\"id\":2618},{\"id\":2619},{\"id\":2620},{\"id\":2609},{\"id\":2621},{\"id\":2622},{\"id\":2623},{\"id\":2601},{\"id\":2625},{\"id\":2633},{\"id\":2634},{\"id\":2656},{\"id\":2626},{\"id\":2635},{\"id\":2636},{\"id\":2637},{\"id\":2627},{\"id\":2638},{\"id\":2639},{\"id\":2640},{\"id\":2628},{\"id\":2641},{\"id\":2642},{\"id\":2643},{\"id\":2629},{\"id\":2644},{\"id\":2645},{\"id\":2646},{\"id\":2630},{\"id\":2647},{\"id\":2648},{\"id\":2649},{\"id\":2631},{\"id\":2650},{\"id\":2651},{\"id\":2652},{\"id\":2632},{\"id\":2653},{\"id\":2654},{\"id\":2655},{\"id\":2602},{\"id\":2657},{\"id\":2665},{\"id\":2666},{\"id\":2688},{\"id\":2658},{\"id\":2667},{\"id\":2668},{\"id\":2669},{\"id\":2659},{\"id\":2670},{\"id\":2671},{\"id\":2672},{\"id\":2660},{\"id\":2673},{\"id\":2674},{\"id\":2675},{\"id\":2661},{\"id\":2676},{\"id\":2677},{\"id\":2678},{\"id\":2662},{\"id\":2679},{\"id\":2680},{\"id\":2681},{\"id\":2663},{\"id\":2682},{\"id\":2683},{\"id\":2684},{\"id\":2664},{\"id\":2685},{\"id\":2686},{\"id\":2687},{\"id\":2603},{\"id\":2689},{\"id\":2693},{\"id\":2694},{\"id\":2704},{\"id\":2690},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2691},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2692},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2604}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2706,\"textContent\":\" \",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2707,\"textContent\":\" \",\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2709,\"textContent\":\" \",\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2711,\"textContent\":\" \",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2711},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2713,\"textContent\":\" \",\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2714,\"textContent\":\" \",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2714},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2716,\"textContent\":\" \",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"parentNode\":{\"id\":2715}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":2715}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2715}},{\"nodeType\":3,\"id\":2720,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2725,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2728,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2732,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2736,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2725}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2740,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"parentNode\":{\"id\":2728}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2744,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2742}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2732}},{\"nodeType\":3,\"id\":2749,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"parentNode\":{\"id\":2712}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2753,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2751}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2705},{\"id\":2707},{\"id\":2708},{\"id\":2714},{\"id\":2715},{\"id\":2717},{\"id\":2718},{\"id\":2720},{\"id\":2719},{\"id\":2716},{\"id\":2709},{\"id\":2710},{\"id\":2721},{\"id\":2722},{\"id\":2724},{\"id\":2725},{\"id\":2736},{\"id\":2726},{\"id\":2737},{\"id\":2738},{\"id\":2740},{\"id\":2739},{\"id\":2727},{\"id\":2728},{\"id\":2741},{\"id\":2742},{\"id\":2744},{\"id\":2743},{\"id\":2729},{\"id\":2730},{\"id\":2745},{\"id\":2747},{\"id\":2746},{\"id\":2731},{\"id\":2732},{\"id\":2748},{\"id\":2733},{\"id\":2734},{\"id\":2749},{\"id\":2735},{\"id\":2723},{\"id\":2711},{\"id\":2712},{\"id\":2750},{\"id\":2751},{\"id\":2753},{\"id\":2752},{\"id\":2713},{\"id\":2706}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2754,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"[ { \\\"rt\\\": 94625, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 94627, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16557, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 112512, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 13318, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"TOO\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 126834, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 28237, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 156155, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 15656, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 172813, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 57191, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 231399, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-0-08:30-02 PM-11 AM-12 PM-12 PM-11 AM-12 PM-12 PM-01 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1078,y:913,t:1526328334513};\\\", \\\"{x:1075,y:913,t:1526328334524};\\\", \\\"{x:1073,y:913,t:1526328334542};\\\", \\\"{x:1069,y:914,t:1526328334559};\\\", \\\"{x:1067,y:914,t:1526328334574};\\\", \\\"{x:1065,y:915,t:1526328334592};\\\", \\\"{x:1063,y:916,t:1526328334608};\\\", \\\"{x:1062,y:916,t:1526328334624};\\\", \\\"{x:1061,y:916,t:1526328334770};\\\", \\\"{x:1060,y:916,t:1526328334785};\\\", \\\"{x:1059,y:916,t:1526328334794};\\\", \\\"{x:1059,y:917,t:1526328334809};\\\", \\\"{x:1056,y:918,t:1526328334825};\\\", \\\"{x:1051,y:919,t:1526328334842};\\\", \\\"{x:1049,y:920,t:1526328334859};\\\", \\\"{x:1043,y:923,t:1526328334875};\\\", \\\"{x:1035,y:925,t:1526328334891};\\\", \\\"{x:1020,y:928,t:1526328334908};\\\", \\\"{x:994,y:932,t:1526328334925};\\\", \\\"{x:950,y:940,t:1526328334941};\\\", \\\"{x:864,y:949,t:1526328334958};\\\", \\\"{x:739,y:970,t:1526328334975};\\\", \\\"{x:595,y:992,t:1526328334991};\\\", \\\"{x:450,y:1002,t:1526328335008};\\\", \\\"{x:278,y:1004,t:1526328335025};\\\", \\\"{x:175,y:1004,t:1526328335042};\\\", \\\"{x:100,y:1004,t:1526328335058};\\\", \\\"{x:52,y:1004,t:1526328335075};\\\", \\\"{x:16,y:1004,t:1526328335091};\\\", \\\"{x:0,y:1004,t:1526328335109};\\\", \\\"{x:0,y:1003,t:1526328335162};\\\", \\\"{x:0,y:1001,t:1526328335176};\\\", \\\"{x:0,y:996,t:1526328335192};\\\", \\\"{x:0,y:981,t:1526328335208};\\\", \\\"{x:0,y:956,t:1526328335225};\\\", \\\"{x:0,y:944,t:1526328335242};\\\", \\\"{x:0,y:927,t:1526328335258};\\\", \\\"{x:0,y:915,t:1526328335276};\\\", \\\"{x:4,y:902,t:1526328335292};\\\", \\\"{x:12,y:888,t:1526328335309};\\\", \\\"{x:19,y:876,t:1526328335325};\\\", \\\"{x:24,y:869,t:1526328335342};\\\", \\\"{x:30,y:864,t:1526328335359};\\\", \\\"{x:34,y:861,t:1526328335375};\\\", \\\"{x:40,y:861,t:1526328335392};\\\", \\\"{x:61,y:861,t:1526328335409};\\\", \\\"{x:78,y:869,t:1526328335425};\\\", \\\"{x:80,y:869,t:1526328335442};\\\", \\\"{x:81,y:869,t:1526328336105};\\\", \\\"{x:83,y:870,t:1526328336185};\\\", \\\"{x:84,y:870,t:1526328336193};\\\", \\\"{x:85,y:871,t:1526328336210};\\\", \\\"{x:88,y:872,t:1526328336226};\\\", \\\"{x:89,y:872,t:1526328336242};\\\", \\\"{x:90,y:872,t:1526328336260};\\\", \\\"{x:95,y:872,t:1526328336277};\\\", \\\"{x:100,y:872,t:1526328336293};\\\", \\\"{x:103,y:872,t:1526328336309};\\\", \\\"{x:109,y:872,t:1526328336327};\\\", \\\"{x:117,y:872,t:1526328336342};\\\", \\\"{x:124,y:872,t:1526328336359};\\\", \\\"{x:129,y:872,t:1526328336376};\\\", \\\"{x:131,y:872,t:1526328336393};\\\", \\\"{x:134,y:872,t:1526328336409};\\\", \\\"{x:135,y:872,t:1526328336442};\\\", \\\"{x:136,y:872,t:1526328336466};\\\", \\\"{x:137,y:872,t:1526328336476};\\\", \\\"{x:139,y:872,t:1526328336493};\\\", \\\"{x:141,y:872,t:1526328336510};\\\", \\\"{x:144,y:871,t:1526328336526};\\\", \\\"{x:146,y:871,t:1526328336545};\\\", \\\"{x:148,y:871,t:1526328336562};\\\", \\\"{x:150,y:870,t:1526328336576};\\\", \\\"{x:153,y:870,t:1526328336592};\\\", \\\"{x:156,y:870,t:1526328336610};\\\", \\\"{x:158,y:869,t:1526328336627};\\\", \\\"{x:161,y:868,t:1526328336643};\\\", \\\"{x:163,y:867,t:1526328336660};\\\", \\\"{x:164,y:867,t:1526328336676};\\\", \\\"{x:165,y:867,t:1526328336693};\\\", \\\"{x:167,y:866,t:1526328336710};\\\", \\\"{x:169,y:865,t:1526328336727};\\\", \\\"{x:170,y:864,t:1526328336744};\\\", \\\"{x:171,y:864,t:1526328336760};\\\", \\\"{x:173,y:864,t:1526328336776};\\\", \\\"{x:175,y:862,t:1526328336793};\\\", \\\"{x:176,y:862,t:1526328336826};\\\", \\\"{x:177,y:862,t:1526328336849};\\\", \\\"{x:177,y:861,t:1526328336859};\\\", \\\"{x:178,y:861,t:1526328336897};\\\", \\\"{x:179,y:861,t:1526328336910};\\\", \\\"{x:180,y:861,t:1526328336926};\\\", \\\"{x:181,y:859,t:1526328336943};\\\", \\\"{x:182,y:859,t:1526328336959};\\\", \\\"{x:183,y:858,t:1526328336977};\\\", \\\"{x:185,y:857,t:1526328337017};\\\", \\\"{x:186,y:856,t:1526328337033};\\\", \\\"{x:187,y:855,t:1526328337058};\\\", \\\"{x:188,y:854,t:1526328337073};\\\", \\\"{x:190,y:853,t:1526328337082};\\\", \\\"{x:190,y:852,t:1526328337093};\\\", \\\"{x:193,y:848,t:1526328337110};\\\", \\\"{x:195,y:846,t:1526328337126};\\\", \\\"{x:197,y:844,t:1526328337143};\\\", \\\"{x:206,y:841,t:1526328338621};\\\", \\\"{x:223,y:838,t:1526328338630};\\\", \\\"{x:291,y:835,t:1526328338648};\\\", \\\"{x:399,y:835,t:1526328338664};\\\", \\\"{x:568,y:839,t:1526328338681};\\\", \\\"{x:789,y:869,t:1526328338698};\\\", \\\"{x:1005,y:904,t:1526328338714};\\\", \\\"{x:1223,y:934,t:1526328338731};\\\", \\\"{x:1408,y:963,t:1526328338748};\\\", \\\"{x:1580,y:976,t:1526328338765};\\\", \\\"{x:1638,y:976,t:1526328338781};\\\", \\\"{x:1667,y:976,t:1526328338797};\\\", \\\"{x:1682,y:975,t:1526328338814};\\\", \\\"{x:1696,y:972,t:1526328338831};\\\", \\\"{x:1716,y:966,t:1526328338847};\\\", \\\"{x:1746,y:953,t:1526328338864};\\\", \\\"{x:1793,y:933,t:1526328338881};\\\", \\\"{x:1846,y:906,t:1526328338898};\\\", \\\"{x:1898,y:876,t:1526328338915};\\\", \\\"{x:1919,y:849,t:1526328338931};\\\", \\\"{x:1919,y:819,t:1526328338947};\\\", \\\"{x:1919,y:787,t:1526328338964};\\\", \\\"{x:1919,y:762,t:1526328338981};\\\", \\\"{x:1899,y:725,t:1526328338998};\\\", \\\"{x:1864,y:688,t:1526328339015};\\\", \\\"{x:1816,y:655,t:1526328339031};\\\", \\\"{x:1761,y:630,t:1526328339049};\\\", \\\"{x:1706,y:617,t:1526328339065};\\\", \\\"{x:1631,y:599,t:1526328339082};\\\", \\\"{x:1539,y:584,t:1526328339098};\\\", \\\"{x:1440,y:570,t:1526328339114};\\\", \\\"{x:1346,y:560,t:1526328339132};\\\", \\\"{x:1225,y:554,t:1526328339148};\\\", \\\"{x:1150,y:555,t:1526328339165};\\\", \\\"{x:1087,y:558,t:1526328339181};\\\", \\\"{x:1028,y:568,t:1526328339199};\\\", \\\"{x:984,y:580,t:1526328339215};\\\", \\\"{x:954,y:592,t:1526328339232};\\\", \\\"{x:939,y:602,t:1526328339250};\\\", \\\"{x:935,y:619,t:1526328339265};\\\", \\\"{x:935,y:636,t:1526328339282};\\\", \\\"{x:947,y:657,t:1526328339299};\\\", \\\"{x:962,y:686,t:1526328339314};\\\", \\\"{x:987,y:718,t:1526328339332};\\\", \\\"{x:1012,y:755,t:1526328339348};\\\", \\\"{x:1024,y:772,t:1526328339366};\\\", \\\"{x:1032,y:784,t:1526328339382};\\\", \\\"{x:1039,y:794,t:1526328339399};\\\", \\\"{x:1043,y:800,t:1526328339416};\\\", \\\"{x:1044,y:803,t:1526328339432};\\\", \\\"{x:1044,y:806,t:1526328339448};\\\", \\\"{x:1045,y:806,t:1526328339466};\\\", \\\"{x:1045,y:810,t:1526328339482};\\\", \\\"{x:1045,y:817,t:1526328339499};\\\", \\\"{x:1045,y:831,t:1526328339516};\\\", \\\"{x:1045,y:849,t:1526328339531};\\\", \\\"{x:1037,y:893,t:1526328339549};\\\", \\\"{x:1028,y:921,t:1526328339565};\\\", \\\"{x:1026,y:935,t:1526328339583};\\\", \\\"{x:1029,y:946,t:1526328339599};\\\", \\\"{x:1037,y:955,t:1526328339616};\\\", \\\"{x:1044,y:958,t:1526328339632};\\\", \\\"{x:1053,y:964,t:1526328339648};\\\", \\\"{x:1057,y:967,t:1526328339666};\\\", \\\"{x:1059,y:968,t:1526328339683};\\\", \\\"{x:1061,y:969,t:1526328339699};\\\", \\\"{x:1063,y:969,t:1526328339780};\\\", \\\"{x:1065,y:969,t:1526328339789};\\\", \\\"{x:1070,y:969,t:1526328339799};\\\", \\\"{x:1077,y:964,t:1526328339816};\\\", \\\"{x:1082,y:960,t:1526328339832};\\\", \\\"{x:1090,y:956,t:1526328339849};\\\", \\\"{x:1092,y:955,t:1526328339865};\\\", \\\"{x:1092,y:954,t:1526328340373};\\\", \\\"{x:1092,y:952,t:1526328340396};\\\", \\\"{x:1091,y:952,t:1526328340421};\\\", \\\"{x:1090,y:951,t:1526328340434};\\\", \\\"{x:1088,y:951,t:1526328340541};\\\", \\\"{x:1087,y:950,t:1526328340621};\\\", \\\"{x:1085,y:949,t:1526328340686};\\\", \\\"{x:1083,y:948,t:1526328340741};\\\", \\\"{x:1082,y:948,t:1526328340813};\\\", \\\"{x:1082,y:947,t:1526328340820};\\\", \\\"{x:1081,y:947,t:1526328340852};\\\", \\\"{x:1080,y:946,t:1526328340868};\\\", \\\"{x:1079,y:945,t:1526328340883};\\\", \\\"{x:1078,y:944,t:1526328340901};\\\", \\\"{x:1077,y:942,t:1526328341237};\\\", \\\"{x:1077,y:939,t:1526328341251};\\\", \\\"{x:1077,y:932,t:1526328341268};\\\", \\\"{x:1077,y:921,t:1526328341284};\\\", \\\"{x:1076,y:917,t:1526328341302};\\\", \\\"{x:1076,y:915,t:1526328341317};\\\", \\\"{x:1076,y:913,t:1526328341335};\\\", \\\"{x:1075,y:913,t:1526328341356};\\\", \\\"{x:1075,y:912,t:1526328341405};\\\", \\\"{x:1075,y:911,t:1526328341429};\\\", \\\"{x:1075,y:910,t:1526328341437};\\\", \\\"{x:1075,y:909,t:1526328341452};\\\", \\\"{x:1075,y:908,t:1526328341469};\\\", \\\"{x:1075,y:905,t:1526328341485};\\\", \\\"{x:1075,y:903,t:1526328341510};\\\", \\\"{x:1075,y:902,t:1526328341519};\\\", \\\"{x:1075,y:898,t:1526328341535};\\\", \\\"{x:1075,y:886,t:1526328341552};\\\", \\\"{x:1075,y:873,t:1526328341569};\\\", \\\"{x:1075,y:860,t:1526328341585};\\\", \\\"{x:1075,y:848,t:1526328341602};\\\", \\\"{x:1075,y:839,t:1526328341619};\\\", \\\"{x:1076,y:833,t:1526328341635};\\\", \\\"{x:1076,y:827,t:1526328341652};\\\", \\\"{x:1076,y:819,t:1526328341669};\\\", \\\"{x:1076,y:812,t:1526328341685};\\\", \\\"{x:1076,y:805,t:1526328341702};\\\", \\\"{x:1076,y:795,t:1526328341719};\\\", \\\"{x:1076,y:784,t:1526328341735};\\\", \\\"{x:1076,y:771,t:1526328341752};\\\", \\\"{x:1076,y:756,t:1526328341775};\\\", \\\"{x:1076,y:752,t:1526328341785};\\\", \\\"{x:1077,y:739,t:1526328341802};\\\", \\\"{x:1079,y:729,t:1526328341819};\\\", \\\"{x:1079,y:722,t:1526328341835};\\\", \\\"{x:1079,y:716,t:1526328341851};\\\", \\\"{x:1080,y:709,t:1526328341868};\\\", \\\"{x:1080,y:703,t:1526328341886};\\\", \\\"{x:1080,y:697,t:1526328341902};\\\", \\\"{x:1080,y:692,t:1526328341919};\\\", \\\"{x:1080,y:688,t:1526328341936};\\\", \\\"{x:1080,y:685,t:1526328341952};\\\", \\\"{x:1080,y:684,t:1526328341988};\\\", \\\"{x:1081,y:683,t:1526328342002};\\\", \\\"{x:1081,y:682,t:1526328342019};\\\", \\\"{x:1081,y:694,t:1526328343133};\\\", \\\"{x:1081,y:708,t:1526328343141};\\\", \\\"{x:1081,y:729,t:1526328343153};\\\", \\\"{x:1084,y:767,t:1526328343171};\\\", \\\"{x:1084,y:815,t:1526328343186};\\\", \\\"{x:1084,y:857,t:1526328343204};\\\", \\\"{x:1085,y:891,t:1526328343221};\\\", \\\"{x:1087,y:906,t:1526328343237};\\\", \\\"{x:1091,y:913,t:1526328343254};\\\", \\\"{x:1095,y:921,t:1526328343271};\\\", \\\"{x:1100,y:931,t:1526328343288};\\\", \\\"{x:1110,y:946,t:1526328343305};\\\", \\\"{x:1114,y:957,t:1526328343321};\\\", \\\"{x:1116,y:966,t:1526328343338};\\\", \\\"{x:1116,y:974,t:1526328343354};\\\", \\\"{x:1118,y:976,t:1526328343371};\\\", \\\"{x:1118,y:974,t:1526328343429};\\\", \\\"{x:1117,y:971,t:1526328343438};\\\", \\\"{x:1114,y:966,t:1526328343454};\\\", \\\"{x:1110,y:963,t:1526328343471};\\\", \\\"{x:1102,y:961,t:1526328343488};\\\", \\\"{x:1098,y:960,t:1526328343504};\\\", \\\"{x:1091,y:960,t:1526328343521};\\\", \\\"{x:1086,y:961,t:1526328343539};\\\", \\\"{x:1079,y:964,t:1526328343555};\\\", \\\"{x:1075,y:965,t:1526328343571};\\\", \\\"{x:1074,y:966,t:1526328343588};\\\", \\\"{x:1074,y:967,t:1526328343702};\\\", \\\"{x:1074,y:968,t:1526328344685};\\\", \\\"{x:1078,y:971,t:1526328344700};\\\", \\\"{x:1085,y:976,t:1526328344708};\\\", \\\"{x:1095,y:978,t:1526328344723};\\\", \\\"{x:1116,y:986,t:1526328344740};\\\", \\\"{x:1149,y:996,t:1526328344755};\\\", \\\"{x:1180,y:1007,t:1526328344772};\\\", \\\"{x:1197,y:1010,t:1526328344790};\\\", \\\"{x:1209,y:1012,t:1526328344806};\\\", \\\"{x:1224,y:1017,t:1526328344823};\\\", \\\"{x:1247,y:1020,t:1526328344840};\\\", \\\"{x:1277,y:1026,t:1526328344856};\\\", \\\"{x:1321,y:1030,t:1526328344873};\\\", \\\"{x:1371,y:1038,t:1526328344890};\\\", \\\"{x:1404,y:1043,t:1526328344905};\\\", \\\"{x:1430,y:1044,t:1526328344923};\\\", \\\"{x:1445,y:1047,t:1526328344940};\\\", \\\"{x:1455,y:1047,t:1526328344956};\\\", \\\"{x:1463,y:1044,t:1526328344973};\\\", \\\"{x:1466,y:1042,t:1526328344990};\\\", \\\"{x:1467,y:1040,t:1526328345007};\\\", \\\"{x:1469,y:1036,t:1526328345024};\\\", \\\"{x:1471,y:1031,t:1526328345040};\\\", \\\"{x:1474,y:1026,t:1526328345057};\\\", \\\"{x:1478,y:1022,t:1526328345073};\\\", \\\"{x:1482,y:1019,t:1526328345090};\\\", \\\"{x:1483,y:1018,t:1526328345107};\\\", \\\"{x:1484,y:1017,t:1526328345123};\\\", \\\"{x:1484,y:1014,t:1526328345140};\\\", \\\"{x:1484,y:1011,t:1526328345157};\\\", \\\"{x:1484,y:1005,t:1526328345173};\\\", \\\"{x:1480,y:998,t:1526328345190};\\\", \\\"{x:1471,y:992,t:1526328345207};\\\", \\\"{x:1457,y:985,t:1526328345224};\\\", \\\"{x:1432,y:976,t:1526328345240};\\\", \\\"{x:1404,y:968,t:1526328345256};\\\", \\\"{x:1369,y:961,t:1526328345274};\\\", \\\"{x:1341,y:952,t:1526328345290};\\\", \\\"{x:1324,y:947,t:1526328345307};\\\", \\\"{x:1315,y:946,t:1526328345324};\\\", \\\"{x:1312,y:946,t:1526328345340};\\\", \\\"{x:1311,y:946,t:1526328345364};\\\", \\\"{x:1309,y:946,t:1526328345380};\\\", \\\"{x:1307,y:946,t:1526328345390};\\\", \\\"{x:1303,y:949,t:1526328345407};\\\", \\\"{x:1300,y:950,t:1526328345424};\\\", \\\"{x:1294,y:952,t:1526328345440};\\\", \\\"{x:1290,y:955,t:1526328345457};\\\", \\\"{x:1284,y:957,t:1526328345474};\\\", \\\"{x:1280,y:959,t:1526328345491};\\\", \\\"{x:1280,y:960,t:1526328345508};\\\", \\\"{x:1280,y:962,t:1526328345524};\\\", \\\"{x:1281,y:963,t:1526328345541};\\\", \\\"{x:1280,y:963,t:1526328346500};\\\", \\\"{x:1280,y:962,t:1526328346588};\\\", \\\"{x:1279,y:962,t:1526328346829};\\\", \\\"{x:1279,y:961,t:1526328346861};\\\", \\\"{x:1278,y:961,t:1526328346876};\\\", \\\"{x:1278,y:960,t:1526328346892};\\\", \\\"{x:1277,y:959,t:1526328346916};\\\", \\\"{x:1277,y:957,t:1526328346965};\\\", \\\"{x:1276,y:956,t:1526328347004};\\\", \\\"{x:1275,y:953,t:1526328347053};\\\", \\\"{x:1275,y:951,t:1526328348524};\\\", \\\"{x:1275,y:949,t:1526328348532};\\\", \\\"{x:1275,y:946,t:1526328348545};\\\", \\\"{x:1275,y:942,t:1526328348562};\\\", \\\"{x:1275,y:939,t:1526328348578};\\\", \\\"{x:1275,y:936,t:1526328348596};\\\", \\\"{x:1275,y:935,t:1526328348611};\\\", \\\"{x:1275,y:932,t:1526328348628};\\\", \\\"{x:1275,y:928,t:1526328348645};\\\", \\\"{x:1275,y:921,t:1526328348662};\\\", \\\"{x:1275,y:920,t:1526328348678};\\\", \\\"{x:1275,y:916,t:1526328348695};\\\", \\\"{x:1275,y:913,t:1526328348713};\\\", \\\"{x:1275,y:910,t:1526328348729};\\\", \\\"{x:1275,y:907,t:1526328348745};\\\", \\\"{x:1275,y:905,t:1526328348762};\\\", \\\"{x:1274,y:903,t:1526328348778};\\\", \\\"{x:1274,y:902,t:1526328348797};\\\", \\\"{x:1274,y:901,t:1526328348812};\\\", \\\"{x:1274,y:900,t:1526328348828};\\\", \\\"{x:1274,y:899,t:1526328348869};\\\", \\\"{x:1274,y:898,t:1526328348878};\\\", \\\"{x:1274,y:897,t:1526328348895};\\\", \\\"{x:1274,y:894,t:1526328348913};\\\", \\\"{x:1274,y:887,t:1526328348929};\\\", \\\"{x:1274,y:876,t:1526328348945};\\\", \\\"{x:1273,y:866,t:1526328348962};\\\", \\\"{x:1270,y:852,t:1526328348980};\\\", \\\"{x:1268,y:838,t:1526328348996};\\\", \\\"{x:1266,y:826,t:1526328349012};\\\", \\\"{x:1264,y:812,t:1526328349029};\\\", \\\"{x:1261,y:802,t:1526328349045};\\\", \\\"{x:1259,y:795,t:1526328349063};\\\", \\\"{x:1259,y:792,t:1526328349080};\\\", \\\"{x:1259,y:791,t:1526328349095};\\\", \\\"{x:1259,y:790,t:1526328349114};\\\", \\\"{x:1259,y:789,t:1526328349129};\\\", \\\"{x:1259,y:788,t:1526328349149};\\\", \\\"{x:1259,y:787,t:1526328349162};\\\", \\\"{x:1260,y:786,t:1526328349180};\\\", \\\"{x:1260,y:785,t:1526328349197};\\\", \\\"{x:1261,y:783,t:1526328349213};\\\", \\\"{x:1263,y:781,t:1526328349230};\\\", \\\"{x:1264,y:779,t:1526328349246};\\\", \\\"{x:1264,y:777,t:1526328349262};\\\", \\\"{x:1267,y:774,t:1526328349279};\\\", \\\"{x:1268,y:770,t:1526328349297};\\\", \\\"{x:1270,y:766,t:1526328349312};\\\", \\\"{x:1271,y:762,t:1526328349329};\\\", \\\"{x:1274,y:755,t:1526328349347};\\\", \\\"{x:1274,y:751,t:1526328349362};\\\", \\\"{x:1274,y:748,t:1526328349379};\\\", \\\"{x:1274,y:744,t:1526328349396};\\\", \\\"{x:1274,y:739,t:1526328349412};\\\", \\\"{x:1274,y:733,t:1526328349429};\\\", \\\"{x:1274,y:728,t:1526328349446};\\\", \\\"{x:1274,y:722,t:1526328349463};\\\", \\\"{x:1274,y:717,t:1526328349480};\\\", \\\"{x:1274,y:711,t:1526328349496};\\\", \\\"{x:1274,y:704,t:1526328349512};\\\", \\\"{x:1274,y:694,t:1526328349530};\\\", \\\"{x:1274,y:680,t:1526328349546};\\\", \\\"{x:1275,y:666,t:1526328349563};\\\", \\\"{x:1275,y:652,t:1526328349579};\\\", \\\"{x:1275,y:635,t:1526328349596};\\\", \\\"{x:1275,y:627,t:1526328349613};\\\", \\\"{x:1275,y:616,t:1526328349630};\\\", \\\"{x:1275,y:611,t:1526328349646};\\\", \\\"{x:1275,y:609,t:1526328349664};\\\", \\\"{x:1275,y:607,t:1526328349680};\\\", \\\"{x:1275,y:604,t:1526328349696};\\\", \\\"{x:1276,y:598,t:1526328349713};\\\", \\\"{x:1276,y:595,t:1526328349730};\\\", \\\"{x:1276,y:591,t:1526328349747};\\\", \\\"{x:1278,y:588,t:1526328349763};\\\", \\\"{x:1278,y:579,t:1526328349780};\\\", \\\"{x:1278,y:577,t:1526328349796};\\\", \\\"{x:1278,y:575,t:1526328349813};\\\", \\\"{x:1277,y:573,t:1526328349830};\\\", \\\"{x:1277,y:570,t:1526328349846};\\\", \\\"{x:1275,y:566,t:1526328349864};\\\", \\\"{x:1275,y:565,t:1526328349880};\\\", \\\"{x:1275,y:563,t:1526328349897};\\\", \\\"{x:1275,y:562,t:1526328349913};\\\", \\\"{x:1275,y:561,t:1526328349931};\\\", \\\"{x:1275,y:560,t:1526328349947};\\\", \\\"{x:1275,y:558,t:1526328349964};\\\", \\\"{x:1274,y:556,t:1526328349980};\\\", \\\"{x:1274,y:555,t:1526328350005};\\\", \\\"{x:1274,y:554,t:1526328350013};\\\", \\\"{x:1274,y:553,t:1526328350045};\\\", \\\"{x:1274,y:552,t:1526328350053};\\\", \\\"{x:1274,y:551,t:1526328350064};\\\", \\\"{x:1274,y:550,t:1526328350080};\\\", \\\"{x:1274,y:548,t:1526328350097};\\\", \\\"{x:1274,y:547,t:1526328350114};\\\", \\\"{x:1275,y:541,t:1526328350130};\\\", \\\"{x:1275,y:540,t:1526328350148};\\\", \\\"{x:1275,y:538,t:1526328350164};\\\", \\\"{x:1275,y:536,t:1526328350180};\\\", \\\"{x:1275,y:535,t:1526328350197};\\\", \\\"{x:1276,y:538,t:1526328350789};\\\", \\\"{x:1277,y:544,t:1526328350798};\\\", \\\"{x:1277,y:558,t:1526328350815};\\\", \\\"{x:1279,y:570,t:1526328350832};\\\", \\\"{x:1280,y:583,t:1526328350848};\\\", \\\"{x:1281,y:593,t:1526328350864};\\\", \\\"{x:1281,y:600,t:1526328350882};\\\", \\\"{x:1281,y:610,t:1526328350898};\\\", \\\"{x:1277,y:623,t:1526328350916};\\\", \\\"{x:1271,y:639,t:1526328350931};\\\", \\\"{x:1261,y:674,t:1526328350948};\\\", \\\"{x:1256,y:701,t:1526328350965};\\\", \\\"{x:1250,y:736,t:1526328350982};\\\", \\\"{x:1248,y:763,t:1526328350999};\\\", \\\"{x:1244,y:791,t:1526328351016};\\\", \\\"{x:1242,y:814,t:1526328351031};\\\", \\\"{x:1242,y:828,t:1526328351049};\\\", \\\"{x:1242,y:844,t:1526328351065};\\\", \\\"{x:1242,y:859,t:1526328351081};\\\", \\\"{x:1240,y:875,t:1526328351098};\\\", \\\"{x:1238,y:887,t:1526328351115};\\\", \\\"{x:1237,y:902,t:1526328351132};\\\", \\\"{x:1235,y:907,t:1526328351148};\\\", \\\"{x:1235,y:913,t:1526328351165};\\\", \\\"{x:1234,y:916,t:1526328351183};\\\", \\\"{x:1234,y:918,t:1526328351199};\\\", \\\"{x:1234,y:919,t:1526328351215};\\\", \\\"{x:1234,y:922,t:1526328351232};\\\", \\\"{x:1234,y:927,t:1526328351248};\\\", \\\"{x:1234,y:935,t:1526328351265};\\\", \\\"{x:1234,y:944,t:1526328351282};\\\", \\\"{x:1234,y:949,t:1526328351298};\\\", \\\"{x:1234,y:953,t:1526328351316};\\\", \\\"{x:1234,y:956,t:1526328351332};\\\", \\\"{x:1234,y:957,t:1526328351349};\\\", \\\"{x:1234,y:958,t:1526328351396};\\\", \\\"{x:1234,y:959,t:1526328351404};\\\", \\\"{x:1234,y:960,t:1526328351415};\\\", \\\"{x:1234,y:961,t:1526328351432};\\\", \\\"{x:1235,y:962,t:1526328351449};\\\", \\\"{x:1242,y:963,t:1526328356844};\\\", \\\"{x:1255,y:967,t:1526328356856};\\\", \\\"{x:1282,y:977,t:1526328356874};\\\", \\\"{x:1305,y:981,t:1526328356889};\\\", \\\"{x:1334,y:991,t:1526328356907};\\\", \\\"{x:1351,y:994,t:1526328356923};\\\", \\\"{x:1355,y:996,t:1526328356940};\\\", \\\"{x:1355,y:995,t:1526328357212};\\\", \\\"{x:1351,y:994,t:1526328357224};\\\", \\\"{x:1341,y:990,t:1526328357240};\\\", \\\"{x:1332,y:986,t:1526328357256};\\\", \\\"{x:1324,y:982,t:1526328357274};\\\", \\\"{x:1319,y:981,t:1526328357291};\\\", \\\"{x:1317,y:978,t:1526328357307};\\\", \\\"{x:1316,y:978,t:1526328357323};\\\", \\\"{x:1313,y:975,t:1526328357340};\\\", \\\"{x:1311,y:973,t:1526328357358};\\\", \\\"{x:1309,y:971,t:1526328357374};\\\", \\\"{x:1307,y:971,t:1526328357390};\\\", \\\"{x:1305,y:969,t:1526328357408};\\\", \\\"{x:1305,y:968,t:1526328357484};\\\", \\\"{x:1304,y:968,t:1526328357492};\\\", \\\"{x:1303,y:967,t:1526328357629};\\\", \\\"{x:1301,y:967,t:1526328358693};\\\", \\\"{x:1300,y:967,t:1526328358709};\\\", \\\"{x:1298,y:967,t:1526328358757};\\\", \\\"{x:1297,y:968,t:1526328358924};\\\", \\\"{x:1295,y:969,t:1526328358948};\\\", \\\"{x:1294,y:969,t:1526328358964};\\\", \\\"{x:1292,y:969,t:1526328358976};\\\", \\\"{x:1290,y:970,t:1526328358992};\\\", \\\"{x:1287,y:972,t:1526328359010};\\\", \\\"{x:1285,y:972,t:1526328359027};\\\", \\\"{x:1283,y:973,t:1526328359042};\\\", \\\"{x:1281,y:974,t:1526328359060};\\\", \\\"{x:1280,y:975,t:1526328359077};\\\", \\\"{x:1278,y:976,t:1526328359605};\\\", \\\"{x:1277,y:976,t:1526328359620};\\\", \\\"{x:1276,y:976,t:1526328359644};\\\", \\\"{x:1276,y:975,t:1526328360092};\\\", \\\"{x:1276,y:973,t:1526328360148};\\\", \\\"{x:1276,y:972,t:1526328360188};\\\", \\\"{x:1276,y:970,t:1526328360228};\\\", \\\"{x:1276,y:969,t:1526328360413};\\\", \\\"{x:1276,y:968,t:1526328360756};\\\", \\\"{x:1276,y:967,t:1526328360772};\\\", \\\"{x:1277,y:967,t:1526328362509};\\\", \\\"{x:1277,y:966,t:1526328362740};\\\", \\\"{x:1278,y:965,t:1526328362877};\\\", \\\"{x:1278,y:964,t:1526328362908};\\\", \\\"{x:1279,y:963,t:1526328362972};\\\", \\\"{x:1279,y:961,t:1526328364076};\\\", \\\"{x:1279,y:960,t:1526328364100};\\\", \\\"{x:1281,y:959,t:1526328364788};\\\", \\\"{x:1284,y:957,t:1526328364801};\\\", \\\"{x:1289,y:956,t:1526328364818};\\\", \\\"{x:1294,y:955,t:1526328364834};\\\", \\\"{x:1296,y:955,t:1526328364851};\\\", \\\"{x:1296,y:954,t:1526328364867};\\\", \\\"{x:1297,y:954,t:1526328364884};\\\", \\\"{x:1296,y:954,t:1526328365093};\\\", \\\"{x:1293,y:954,t:1526328365100};\\\", \\\"{x:1290,y:954,t:1526328365118};\\\", \\\"{x:1287,y:954,t:1526328365135};\\\", \\\"{x:1286,y:954,t:1526328365213};\\\", \\\"{x:1285,y:953,t:1526328366484};\\\", \\\"{x:1285,y:951,t:1526328367732};\\\", \\\"{x:1285,y:950,t:1526328367740};\\\", \\\"{x:1285,y:949,t:1526328367755};\\\", \\\"{x:1282,y:945,t:1526328367772};\\\", \\\"{x:1279,y:943,t:1526328367789};\\\", \\\"{x:1271,y:939,t:1526328367805};\\\", \\\"{x:1256,y:934,t:1526328367822};\\\", \\\"{x:1232,y:927,t:1526328367839};\\\", \\\"{x:1201,y:917,t:1526328367855};\\\", \\\"{x:1170,y:908,t:1526328367872};\\\", \\\"{x:1125,y:895,t:1526328367889};\\\", \\\"{x:1080,y:880,t:1526328367905};\\\", \\\"{x:1032,y:864,t:1526328367922};\\\", \\\"{x:979,y:850,t:1526328367939};\\\", \\\"{x:928,y:832,t:1526328367954};\\\", \\\"{x:841,y:805,t:1526328367972};\\\", \\\"{x:801,y:791,t:1526328367989};\\\", \\\"{x:747,y:775,t:1526328368005};\\\", \\\"{x:687,y:760,t:1526328368022};\\\", \\\"{x:631,y:745,t:1526328368039};\\\", \\\"{x:573,y:728,t:1526328368055};\\\", \\\"{x:529,y:716,t:1526328368074};\\\", \\\"{x:489,y:704,t:1526328368089};\\\", \\\"{x:442,y:691,t:1526328368106};\\\", \\\"{x:421,y:689,t:1526328368114};\\\", \\\"{x:382,y:677,t:1526328368131};\\\", \\\"{x:351,y:670,t:1526328368148};\\\", \\\"{x:337,y:667,t:1526328368164};\\\", \\\"{x:330,y:665,t:1526328368181};\\\", \\\"{x:328,y:664,t:1526328368197};\\\", \\\"{x:327,y:663,t:1526328372156};\\\", \\\"{x:328,y:653,t:1526328372167};\\\", \\\"{x:329,y:631,t:1526328372187};\\\", \\\"{x:329,y:606,t:1526328372203};\\\", \\\"{x:329,y:577,t:1526328372219};\\\", \\\"{x:326,y:547,t:1526328372238};\\\", \\\"{x:321,y:531,t:1526328372254};\\\", \\\"{x:319,y:519,t:1526328372274};\\\", \\\"{x:318,y:510,t:1526328372291};\\\", \\\"{x:316,y:501,t:1526328372308};\\\", \\\"{x:312,y:496,t:1526328372325};\\\", \\\"{x:311,y:494,t:1526328372341};\\\", \\\"{x:311,y:493,t:1526328372358};\\\", \\\"{x:311,y:492,t:1526328372388};\\\", \\\"{x:314,y:492,t:1526328372396};\\\", \\\"{x:324,y:497,t:1526328372408};\\\", \\\"{x:344,y:513,t:1526328372426};\\\", \\\"{x:385,y:536,t:1526328372441};\\\", \\\"{x:416,y:554,t:1526328372458};\\\", \\\"{x:444,y:561,t:1526328372475};\\\", \\\"{x:466,y:569,t:1526328372491};\\\", \\\"{x:483,y:575,t:1526328372508};\\\", \\\"{x:495,y:576,t:1526328372525};\\\", \\\"{x:507,y:577,t:1526328372541};\\\", \\\"{x:515,y:577,t:1526328372558};\\\", \\\"{x:525,y:577,t:1526328372574};\\\", \\\"{x:532,y:577,t:1526328372591};\\\", \\\"{x:538,y:577,t:1526328372608};\\\", \\\"{x:549,y:577,t:1526328372625};\\\", \\\"{x:567,y:574,t:1526328372641};\\\", \\\"{x:588,y:572,t:1526328372658};\\\", \\\"{x:610,y:566,t:1526328372675};\\\", \\\"{x:647,y:558,t:1526328372691};\\\", \\\"{x:675,y:550,t:1526328372708};\\\", \\\"{x:700,y:543,t:1526328372725};\\\", \\\"{x:724,y:538,t:1526328372742};\\\", \\\"{x:745,y:530,t:1526328372758};\\\", \\\"{x:760,y:529,t:1526328372775};\\\", \\\"{x:767,y:528,t:1526328372792};\\\", \\\"{x:769,y:528,t:1526328372808};\\\", \\\"{x:770,y:527,t:1526328372825};\\\", \\\"{x:768,y:527,t:1526328372948};\\\", \\\"{x:765,y:526,t:1526328372958};\\\", \\\"{x:749,y:523,t:1526328372975};\\\", \\\"{x:726,y:518,t:1526328372991};\\\", \\\"{x:699,y:517,t:1526328373009};\\\", \\\"{x:669,y:512,t:1526328373025};\\\", \\\"{x:643,y:507,t:1526328373042};\\\", \\\"{x:631,y:507,t:1526328373058};\\\", \\\"{x:628,y:506,t:1526328373075};\\\", \\\"{x:626,y:506,t:1526328376140};\\\", \\\"{x:625,y:506,t:1526328376196};\\\", \\\"{x:624,y:506,t:1526328377388};\\\", \\\"{x:624,y:507,t:1526328377564};\\\", \\\"{x:623,y:507,t:1526328377637};\\\", \\\"{x:622,y:507,t:1526328377853};\\\", \\\"{x:621,y:507,t:1526328378284};\\\", \\\"{x:621,y:506,t:1526328378604};\\\", \\\"{x:621,y:507,t:1526328378613};\\\", \\\"{x:627,y:511,t:1526328378630};\\\", \\\"{x:633,y:516,t:1526328378646};\\\", \\\"{x:646,y:523,t:1526328378662};\\\", \\\"{x:662,y:533,t:1526328378679};\\\", \\\"{x:682,y:539,t:1526328378696};\\\", \\\"{x:715,y:551,t:1526328378713};\\\", \\\"{x:746,y:565,t:1526328378731};\\\", \\\"{x:781,y:578,t:1526328378746};\\\", \\\"{x:838,y:600,t:1526328378763};\\\", \\\"{x:902,y:617,t:1526328378779};\\\", \\\"{x:997,y:645,t:1526328378797};\\\", \\\"{x:1058,y:664,t:1526328378814};\\\", \\\"{x:1117,y:680,t:1526328378830};\\\", \\\"{x:1167,y:694,t:1526328378847};\\\", \\\"{x:1200,y:702,t:1526328378863};\\\", \\\"{x:1223,y:706,t:1526328378880};\\\", \\\"{x:1237,y:711,t:1526328378897};\\\", \\\"{x:1246,y:713,t:1526328378913};\\\", \\\"{x:1248,y:713,t:1526328378930};\\\", \\\"{x:1251,y:714,t:1526328378948};\\\", \\\"{x:1253,y:716,t:1526328378964};\\\", \\\"{x:1274,y:736,t:1526328378981};\\\", \\\"{x:1295,y:760,t:1526328378998};\\\", \\\"{x:1320,y:799,t:1526328379015};\\\", \\\"{x:1339,y:845,t:1526328379030};\\\", \\\"{x:1350,y:897,t:1526328379048};\\\", \\\"{x:1353,y:946,t:1526328379064};\\\", \\\"{x:1349,y:995,t:1526328379081};\\\", \\\"{x:1330,y:1044,t:1526328379097};\\\", \\\"{x:1307,y:1080,t:1526328379114};\\\", \\\"{x:1291,y:1097,t:1526328379131};\\\", \\\"{x:1279,y:1106,t:1526328379147};\\\", \\\"{x:1275,y:1109,t:1526328379164};\\\", \\\"{x:1274,y:1110,t:1526328379181};\\\", \\\"{x:1273,y:1110,t:1526328379198};\\\", \\\"{x:1264,y:1110,t:1526328379214};\\\", \\\"{x:1243,y:1103,t:1526328379232};\\\", \\\"{x:1198,y:1071,t:1526328379248};\\\", \\\"{x:1111,y:1004,t:1526328379266};\\\", \\\"{x:1009,y:910,t:1526328379281};\\\", \\\"{x:909,y:816,t:1526328379299};\\\", \\\"{x:826,y:741,t:1526328379315};\\\", \\\"{x:786,y:688,t:1526328379331};\\\", \\\"{x:782,y:664,t:1526328379349};\\\", \\\"{x:786,y:653,t:1526328379365};\\\", \\\"{x:796,y:646,t:1526328379383};\\\", \\\"{x:813,y:640,t:1526328379399};\\\", \\\"{x:831,y:638,t:1526328379415};\\\", \\\"{x:843,y:636,t:1526328379432};\\\", \\\"{x:858,y:636,t:1526328379449};\\\", \\\"{x:873,y:639,t:1526328379465};\\\", \\\"{x:892,y:644,t:1526328379482};\\\", \\\"{x:910,y:648,t:1526328379499};\\\", \\\"{x:931,y:655,t:1526328379515};\\\", \\\"{x:965,y:668,t:1526328379533};\\\", \\\"{x:994,y:678,t:1526328379550};\\\", \\\"{x:1024,y:691,t:1526328379566};\\\", \\\"{x:1047,y:702,t:1526328379582};\\\", \\\"{x:1074,y:714,t:1526328379599};\\\", \\\"{x:1099,y:725,t:1526328379617};\\\", \\\"{x:1123,y:738,t:1526328379633};\\\", \\\"{x:1142,y:750,t:1526328379649};\\\", \\\"{x:1160,y:763,t:1526328379666};\\\", \\\"{x:1179,y:776,t:1526328379683};\\\", \\\"{x:1193,y:787,t:1526328379700};\\\", \\\"{x:1210,y:802,t:1526328379717};\\\", \\\"{x:1218,y:808,t:1526328379734};\\\", \\\"{x:1225,y:814,t:1526328379750};\\\", \\\"{x:1231,y:818,t:1526328379766};\\\", \\\"{x:1234,y:822,t:1526328379783};\\\", \\\"{x:1240,y:826,t:1526328379800};\\\", \\\"{x:1241,y:827,t:1526328379817};\\\", \\\"{x:1243,y:829,t:1526328379834};\\\", \\\"{x:1244,y:830,t:1526328379850};\\\", \\\"{x:1245,y:830,t:1526328379867};\\\", \\\"{x:1246,y:832,t:1526328379916};\\\", \\\"{x:1248,y:832,t:1526328379940};\\\", \\\"{x:1248,y:831,t:1526328380116};\\\", \\\"{x:1247,y:831,t:1526328380131};\\\", \\\"{x:1246,y:830,t:1526328380149};\\\", \\\"{x:1247,y:835,t:1526328380332};\\\", \\\"{x:1250,y:844,t:1526328380340};\\\", \\\"{x:1252,y:854,t:1526328380352};\\\", \\\"{x:1256,y:876,t:1526328380368};\\\", \\\"{x:1266,y:900,t:1526328380386};\\\", \\\"{x:1283,y:929,t:1526328380403};\\\", \\\"{x:1305,y:960,t:1526328380420};\\\", \\\"{x:1330,y:993,t:1526328380435};\\\", \\\"{x:1359,y:1023,t:1526328380452};\\\", \\\"{x:1375,y:1037,t:1526328380469};\\\", \\\"{x:1385,y:1045,t:1526328380486};\\\", \\\"{x:1388,y:1047,t:1526328380502};\\\", \\\"{x:1387,y:1047,t:1526328380588};\\\", \\\"{x:1386,y:1046,t:1526328380604};\\\", \\\"{x:1385,y:1045,t:1526328380620};\\\", \\\"{x:1381,y:1044,t:1526328380637};\\\", \\\"{x:1374,y:1044,t:1526328380653};\\\", \\\"{x:1365,y:1041,t:1526328380671};\\\", \\\"{x:1355,y:1040,t:1526328380686};\\\", \\\"{x:1346,y:1039,t:1526328380704};\\\", \\\"{x:1342,y:1036,t:1526328380720};\\\", \\\"{x:1337,y:1036,t:1526328380737};\\\", \\\"{x:1331,y:1032,t:1526328380754};\\\", \\\"{x:1329,y:1032,t:1526328380770};\\\", \\\"{x:1328,y:1032,t:1526328380787};\\\", \\\"{x:1329,y:1032,t:1526328381051};\\\", \\\"{x:1331,y:1032,t:1526328381060};\\\", \\\"{x:1333,y:1032,t:1526328381072};\\\", \\\"{x:1339,y:1032,t:1526328381088};\\\", \\\"{x:1346,y:1032,t:1526328381104};\\\", \\\"{x:1352,y:1032,t:1526328381121};\\\", \\\"{x:1361,y:1032,t:1526328381139};\\\", \\\"{x:1373,y:1032,t:1526328381155};\\\", \\\"{x:1389,y:1032,t:1526328381171};\\\", \\\"{x:1413,y:1035,t:1526328381188};\\\", \\\"{x:1426,y:1038,t:1526328381205};\\\", \\\"{x:1439,y:1039,t:1526328381221};\\\", \\\"{x:1449,y:1040,t:1526328381238};\\\", \\\"{x:1456,y:1041,t:1526328381255};\\\", \\\"{x:1461,y:1042,t:1526328381272};\\\", \\\"{x:1465,y:1043,t:1526328381288};\\\", \\\"{x:1468,y:1043,t:1526328381306};\\\", \\\"{x:1472,y:1043,t:1526328381322};\\\", \\\"{x:1479,y:1044,t:1526328381340};\\\", \\\"{x:1486,y:1047,t:1526328381356};\\\", \\\"{x:1494,y:1048,t:1526328381372};\\\", \\\"{x:1497,y:1048,t:1526328381390};\\\", \\\"{x:1500,y:1050,t:1526328381406};\\\", \\\"{x:1502,y:1050,t:1526328381423};\\\", \\\"{x:1504,y:1050,t:1526328381439};\\\", \\\"{x:1507,y:1050,t:1526328381456};\\\", \\\"{x:1510,y:1051,t:1526328381473};\\\", \\\"{x:1515,y:1052,t:1526328381490};\\\", \\\"{x:1520,y:1053,t:1526328381507};\\\", \\\"{x:1528,y:1054,t:1526328381524};\\\", \\\"{x:1534,y:1054,t:1526328381540};\\\", \\\"{x:1543,y:1055,t:1526328381557};\\\", \\\"{x:1547,y:1055,t:1526328381573};\\\", \\\"{x:1551,y:1056,t:1526328381590};\\\", \\\"{x:1553,y:1056,t:1526328381607};\\\", \\\"{x:1556,y:1056,t:1526328381624};\\\", \\\"{x:1560,y:1057,t:1526328381641};\\\", \\\"{x:1564,y:1057,t:1526328381657};\\\", \\\"{x:1569,y:1058,t:1526328381676};\\\", \\\"{x:1572,y:1058,t:1526328381690};\\\", \\\"{x:1578,y:1059,t:1526328381708};\\\", \\\"{x:1579,y:1059,t:1526328381724};\\\", \\\"{x:1583,y:1059,t:1526328381740};\\\", \\\"{x:1585,y:1059,t:1526328381757};\\\", \\\"{x:1586,y:1059,t:1526328381780};\\\", \\\"{x:1587,y:1059,t:1526328381795};\\\", \\\"{x:1588,y:1059,t:1526328381807};\\\", \\\"{x:1591,y:1059,t:1526328381824};\\\", \\\"{x:1593,y:1059,t:1526328381841};\\\", \\\"{x:1595,y:1059,t:1526328381858};\\\", \\\"{x:1598,y:1061,t:1526328381874};\\\", \\\"{x:1601,y:1061,t:1526328381892};\\\", \\\"{x:1604,y:1061,t:1526328381908};\\\", \\\"{x:1609,y:1062,t:1526328381924};\\\", \\\"{x:1615,y:1062,t:1526328381941};\\\", \\\"{x:1620,y:1062,t:1526328381957};\\\", \\\"{x:1624,y:1063,t:1526328381974};\\\", \\\"{x:1629,y:1064,t:1526328381991};\\\", \\\"{x:1632,y:1065,t:1526328382009};\\\", \\\"{x:1635,y:1065,t:1526328382024};\\\", \\\"{x:1636,y:1065,t:1526328382041};\\\", \\\"{x:1637,y:1065,t:1526328382058};\\\", \\\"{x:1633,y:1065,t:1526328382830};\\\", \\\"{x:1611,y:1065,t:1526328382845};\\\", \\\"{x:1575,y:1065,t:1526328382862};\\\", \\\"{x:1533,y:1065,t:1526328382878};\\\", \\\"{x:1477,y:1065,t:1526328382894};\\\", \\\"{x:1418,y:1065,t:1526328382912};\\\", \\\"{x:1378,y:1058,t:1526328382929};\\\", \\\"{x:1355,y:1051,t:1526328382944};\\\", \\\"{x:1343,y:1045,t:1526328382961};\\\", \\\"{x:1339,y:1043,t:1526328382978};\\\", \\\"{x:1338,y:1042,t:1526328382995};\\\", \\\"{x:1339,y:1042,t:1526328383284};\\\", \\\"{x:1341,y:1042,t:1526328383297};\\\", \\\"{x:1347,y:1042,t:1526328383313};\\\", \\\"{x:1355,y:1042,t:1526328383330};\\\", \\\"{x:1367,y:1042,t:1526328383346};\\\", \\\"{x:1381,y:1043,t:1526328383362};\\\", \\\"{x:1389,y:1043,t:1526328383380};\\\", \\\"{x:1401,y:1045,t:1526328383396};\\\", \\\"{x:1404,y:1045,t:1526328383413};\\\", \\\"{x:1405,y:1045,t:1526328383429};\\\", \\\"{x:1407,y:1045,t:1526328383452};\\\", \\\"{x:1409,y:1045,t:1526328383500};\\\", \\\"{x:1411,y:1045,t:1526328383514};\\\", \\\"{x:1413,y:1045,t:1526328383531};\\\", \\\"{x:1414,y:1045,t:1526328383548};\\\", \\\"{x:1417,y:1045,t:1526328383564};\\\", \\\"{x:1420,y:1045,t:1526328383580};\\\", \\\"{x:1421,y:1045,t:1526328383597};\\\", \\\"{x:1423,y:1045,t:1526328383614};\\\", \\\"{x:1424,y:1045,t:1526328383630};\\\", \\\"{x:1428,y:1045,t:1526328383647};\\\", \\\"{x:1430,y:1045,t:1526328383665};\\\", \\\"{x:1431,y:1045,t:1526328383681};\\\", \\\"{x:1434,y:1045,t:1526328383698};\\\", \\\"{x:1436,y:1045,t:1526328383714};\\\", \\\"{x:1439,y:1045,t:1526328383731};\\\", \\\"{x:1440,y:1045,t:1526328383748};\\\", \\\"{x:1441,y:1045,t:1526328383764};\\\", \\\"{x:1442,y:1045,t:1526328383781};\\\", \\\"{x:1443,y:1045,t:1526328383819};\\\", \\\"{x:1444,y:1045,t:1526328383831};\\\", \\\"{x:1445,y:1045,t:1526328383849};\\\", \\\"{x:1447,y:1045,t:1526328383865};\\\", \\\"{x:1449,y:1045,t:1526328383882};\\\", \\\"{x:1452,y:1045,t:1526328383899};\\\", \\\"{x:1453,y:1045,t:1526328383915};\\\", \\\"{x:1455,y:1045,t:1526328383931};\\\", \\\"{x:1461,y:1045,t:1526328383949};\\\", \\\"{x:1465,y:1045,t:1526328383966};\\\", \\\"{x:1470,y:1045,t:1526328383982};\\\", \\\"{x:1476,y:1045,t:1526328383999};\\\", \\\"{x:1481,y:1045,t:1526328384016};\\\", \\\"{x:1489,y:1045,t:1526328384032};\\\", \\\"{x:1499,y:1045,t:1526328384048};\\\", \\\"{x:1507,y:1045,t:1526328384066};\\\", \\\"{x:1518,y:1045,t:1526328384083};\\\", \\\"{x:1525,y:1045,t:1526328384099};\\\", \\\"{x:1528,y:1045,t:1526328384115};\\\", \\\"{x:1532,y:1045,t:1526328384133};\\\", \\\"{x:1533,y:1045,t:1526328384150};\\\", \\\"{x:1534,y:1045,t:1526328384166};\\\", \\\"{x:1538,y:1045,t:1526328384182};\\\", \\\"{x:1543,y:1045,t:1526328384200};\\\", \\\"{x:1550,y:1047,t:1526328384216};\\\", \\\"{x:1552,y:1047,t:1526328384233};\\\", \\\"{x:1554,y:1047,t:1526328384250};\\\", \\\"{x:1556,y:1047,t:1526328384266};\\\", \\\"{x:1557,y:1047,t:1526328384282};\\\", \\\"{x:1559,y:1047,t:1526328384299};\\\", \\\"{x:1561,y:1047,t:1526328384317};\\\", \\\"{x:1562,y:1047,t:1526328384333};\\\", \\\"{x:1564,y:1047,t:1526328384349};\\\", \\\"{x:1565,y:1047,t:1526328384372};\\\", \\\"{x:1567,y:1047,t:1526328384387};\\\", \\\"{x:1568,y:1047,t:1526328384404};\\\", \\\"{x:1570,y:1047,t:1526328384416};\\\", \\\"{x:1571,y:1047,t:1526328384433};\\\", \\\"{x:1573,y:1047,t:1526328384451};\\\", \\\"{x:1572,y:1046,t:1526328386420};\\\", \\\"{x:1569,y:1045,t:1526328386428};\\\", \\\"{x:1567,y:1044,t:1526328386441};\\\", \\\"{x:1558,y:1041,t:1526328386458};\\\", \\\"{x:1554,y:1039,t:1526328386474};\\\", \\\"{x:1553,y:1038,t:1526328386490};\\\", \\\"{x:1550,y:1037,t:1526328387173};\\\", \\\"{x:1546,y:1035,t:1526328387181};\\\", \\\"{x:1536,y:1031,t:1526328387194};\\\", \\\"{x:1498,y:1015,t:1526328387211};\\\", \\\"{x:1421,y:985,t:1526328387226};\\\", \\\"{x:1282,y:928,t:1526328387244};\\\", \\\"{x:1214,y:903,t:1526328387260};\\\", \\\"{x:1190,y:893,t:1526328387277};\\\", \\\"{x:1179,y:888,t:1526328387294};\\\", \\\"{x:1178,y:887,t:1526328387311};\\\", \\\"{x:1177,y:885,t:1526328387348};\\\", \\\"{x:1177,y:883,t:1526328387360};\\\", \\\"{x:1171,y:870,t:1526328387378};\\\", \\\"{x:1159,y:854,t:1526328387394};\\\", \\\"{x:1147,y:839,t:1526328387410};\\\", \\\"{x:1140,y:821,t:1526328387427};\\\", \\\"{x:1140,y:807,t:1526328387444};\\\", \\\"{x:1144,y:794,t:1526328387461};\\\", \\\"{x:1153,y:778,t:1526328387477};\\\", \\\"{x:1169,y:759,t:1526328387495};\\\", \\\"{x:1181,y:740,t:1526328387512};\\\", \\\"{x:1198,y:719,t:1526328387528};\\\", \\\"{x:1206,y:707,t:1526328387545};\\\", \\\"{x:1214,y:692,t:1526328387562};\\\", \\\"{x:1215,y:685,t:1526328387578};\\\", \\\"{x:1215,y:681,t:1526328387595};\\\", \\\"{x:1212,y:674,t:1526328387612};\\\", \\\"{x:1202,y:672,t:1526328387629};\\\", \\\"{x:1176,y:671,t:1526328387645};\\\", \\\"{x:1101,y:663,t:1526328387662};\\\", \\\"{x:975,y:654,t:1526328387679};\\\", \\\"{x:836,y:635,t:1526328387696};\\\", \\\"{x:689,y:611,t:1526328387713};\\\", \\\"{x:549,y:579,t:1526328387729};\\\", \\\"{x:431,y:548,t:1526328387746};\\\", \\\"{x:319,y:513,t:1526328387771};\\\", \\\"{x:305,y:506,t:1526328387786};\\\", \\\"{x:304,y:499,t:1526328387804};\\\", \\\"{x:309,y:491,t:1526328387820};\\\", \\\"{x:317,y:488,t:1526328387837};\\\", \\\"{x:335,y:486,t:1526328387854};\\\", \\\"{x:366,y:486,t:1526328387871};\\\", \\\"{x:391,y:487,t:1526328387887};\\\", \\\"{x:446,y:494,t:1526328387904};\\\", \\\"{x:535,y:506,t:1526328387921};\\\", \\\"{x:633,y:525,t:1526328387938};\\\", \\\"{x:734,y:545,t:1526328387954};\\\", \\\"{x:801,y:555,t:1526328387970};\\\", \\\"{x:841,y:562,t:1526328387987};\\\", \\\"{x:863,y:568,t:1526328388003};\\\", \\\"{x:864,y:568,t:1526328388021};\\\", \\\"{x:866,y:568,t:1526328388043};\\\", \\\"{x:867,y:568,t:1526328388067};\\\", \\\"{x:870,y:568,t:1526328388075};\\\", \\\"{x:871,y:568,t:1526328388087};\\\", \\\"{x:874,y:568,t:1526328388104};\\\", \\\"{x:874,y:566,t:1526328388121};\\\", \\\"{x:874,y:564,t:1526328388136};\\\", \\\"{x:866,y:557,t:1526328388154};\\\", \\\"{x:847,y:548,t:1526328388171};\\\", \\\"{x:815,y:535,t:1526328388188};\\\", \\\"{x:802,y:529,t:1526328388204};\\\", \\\"{x:797,y:525,t:1526328388221};\\\", \\\"{x:797,y:523,t:1526328388237};\\\", \\\"{x:798,y:521,t:1526328388254};\\\", \\\"{x:800,y:521,t:1526328388271};\\\", \\\"{x:802,y:520,t:1526328388288};\\\", \\\"{x:805,y:520,t:1526328388304};\\\", \\\"{x:809,y:520,t:1526328388321};\\\", \\\"{x:814,y:520,t:1526328388337};\\\", \\\"{x:818,y:520,t:1526328388354};\\\", \\\"{x:821,y:520,t:1526328388371};\\\", \\\"{x:824,y:520,t:1526328388387};\\\", \\\"{x:829,y:521,t:1526328388403};\\\", \\\"{x:830,y:522,t:1526328388421};\\\", \\\"{x:831,y:523,t:1526328388437};\\\", \\\"{x:832,y:523,t:1526328388455};\\\", \\\"{x:832,y:524,t:1526328388470};\\\", \\\"{x:833,y:524,t:1526328388488};\\\", \\\"{x:837,y:526,t:1526328388505};\\\", \\\"{x:839,y:526,t:1526328388521};\\\", \\\"{x:838,y:529,t:1526328388764};\\\", \\\"{x:831,y:532,t:1526328388772};\\\", \\\"{x:817,y:543,t:1526328388788};\\\", \\\"{x:806,y:552,t:1526328388805};\\\", \\\"{x:796,y:561,t:1526328388821};\\\", \\\"{x:787,y:567,t:1526328388837};\\\", \\\"{x:783,y:570,t:1526328388854};\\\", \\\"{x:777,y:574,t:1526328388870};\\\", \\\"{x:770,y:579,t:1526328388888};\\\", \\\"{x:761,y:588,t:1526328388905};\\\", \\\"{x:743,y:609,t:1526328388921};\\\", \\\"{x:717,y:633,t:1526328388938};\\\", \\\"{x:694,y:658,t:1526328388956};\\\", \\\"{x:678,y:679,t:1526328388970};\\\", \\\"{x:664,y:697,t:1526328388987};\\\", \\\"{x:661,y:705,t:1526328389005};\\\", \\\"{x:656,y:714,t:1526328389021};\\\", \\\"{x:653,y:723,t:1526328389038};\\\", \\\"{x:653,y:728,t:1526328389055};\\\", \\\"{x:653,y:732,t:1526328389072};\\\", \\\"{x:651,y:734,t:1526328389088};\\\", \\\"{x:650,y:736,t:1526328389105};\\\", \\\"{x:648,y:737,t:1526328389121};\\\", \\\"{x:644,y:737,t:1526328389137};\\\", \\\"{x:639,y:737,t:1526328389155};\\\", \\\"{x:626,y:732,t:1526328389172};\\\", \\\"{x:614,y:728,t:1526328389188};\\\", \\\"{x:601,y:725,t:1526328389205};\\\", \\\"{x:596,y:720,t:1526328389222};\\\", \\\"{x:582,y:719,t:1526328389238};\\\", \\\"{x:577,y:719,t:1526328389255};\\\", \\\"{x:575,y:719,t:1526328389271};\\\", \\\"{x:576,y:719,t:1526328389372};\\\", \\\"{x:577,y:719,t:1526328389388};\\\", \\\"{x:578,y:719,t:1526328389500};\\\", \\\"{x:577,y:721,t:1526328389516};\\\", \\\"{x:576,y:721,t:1526328389523};\\\", \\\"{x:573,y:721,t:1526328389538};\\\", \\\"{x:566,y:721,t:1526328389555};\\\", \\\"{x:554,y:721,t:1526328389572};\\\", \\\"{x:547,y:722,t:1526328389589};\\\", \\\"{x:540,y:722,t:1526328389605};\\\", \\\"{x:535,y:724,t:1526328389622};\\\", \\\"{x:533,y:725,t:1526328389638};\\\", \\\"{x:532,y:725,t:1526328389655};\\\", \\\"{x:534,y:725,t:1526328389940};\\\", \\\"{x:543,y:724,t:1526328389955};\\\", \\\"{x:584,y:724,t:1526328389972};\\\", \\\"{x:656,y:734,t:1526328389989};\\\", \\\"{x:761,y:748,t:1526328390005};\\\", \\\"{x:882,y:777,t:1526328390022};\\\", \\\"{x:987,y:791,t:1526328390039};\\\", \\\"{x:1071,y:804,t:1526328390056};\\\", \\\"{x:1140,y:813,t:1526328390071};\\\", \\\"{x:1178,y:821,t:1526328390088};\\\", \\\"{x:1208,y:827,t:1526328390106};\\\", \\\"{x:1234,y:833,t:1526328390122};\\\", \\\"{x:1260,y:835,t:1526328390138};\\\", \\\"{x:1297,y:840,t:1526328390156};\\\", \\\"{x:1319,y:846,t:1526328390172};\\\", \\\"{x:1340,y:850,t:1526328390189};\\\", \\\"{x:1352,y:853,t:1526328390206};\\\", \\\"{x:1357,y:854,t:1526328390222};\\\", \\\"{x:1358,y:854,t:1526328390239};\\\", \\\"{x:1359,y:854,t:1526328390259};\\\", \\\"{x:1360,y:854,t:1526328390533};\\\", \\\"{x:1361,y:854,t:1526328390876};\\\" ] }, { \\\"rt\\\": 46375, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 279023, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-05 PM-04 PM-02 PM-01 PM-O -9-D -K -K -11:30-11 AM-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1362,y:854,t:1526328393676};\\\", \\\"{x:1361,y:853,t:1526328395940};\\\", \\\"{x:1350,y:847,t:1526328395947};\\\", \\\"{x:1337,y:843,t:1526328395960};\\\", \\\"{x:1313,y:831,t:1526328395975};\\\", \\\"{x:1263,y:817,t:1526328395993};\\\", \\\"{x:1221,y:806,t:1526328396010};\\\", \\\"{x:1203,y:802,t:1526328396026};\\\", \\\"{x:1199,y:799,t:1526328396043};\\\", \\\"{x:1198,y:799,t:1526328396116};\\\", \\\"{x:1196,y:799,t:1526328396127};\\\", \\\"{x:1189,y:798,t:1526328396143};\\\", \\\"{x:1173,y:795,t:1526328396160};\\\", \\\"{x:1150,y:788,t:1526328396177};\\\", \\\"{x:1091,y:777,t:1526328396193};\\\", \\\"{x:1004,y:760,t:1526328396210};\\\", \\\"{x:891,y:731,t:1526328396227};\\\", \\\"{x:765,y:708,t:1526328396243};\\\", \\\"{x:535,y:662,t:1526328396260};\\\", \\\"{x:368,y:624,t:1526328396277};\\\", \\\"{x:202,y:580,t:1526328396293};\\\", \\\"{x:89,y:549,t:1526328396311};\\\", \\\"{x:26,y:522,t:1526328396344};\\\", \\\"{x:26,y:521,t:1526328396360};\\\", \\\"{x:26,y:519,t:1526328396388};\\\", \\\"{x:26,y:517,t:1526328396404};\\\", \\\"{x:28,y:514,t:1526328396411};\\\", \\\"{x:32,y:513,t:1526328396427};\\\", \\\"{x:57,y:504,t:1526328396443};\\\", \\\"{x:85,y:502,t:1526328396459};\\\", \\\"{x:126,y:498,t:1526328396477};\\\", \\\"{x:193,y:498,t:1526328396494};\\\", \\\"{x:266,y:502,t:1526328396510};\\\", \\\"{x:356,y:517,t:1526328396527};\\\", \\\"{x:413,y:528,t:1526328396544};\\\", \\\"{x:443,y:532,t:1526328396561};\\\", \\\"{x:460,y:534,t:1526328396577};\\\", \\\"{x:467,y:534,t:1526328396593};\\\", \\\"{x:468,y:534,t:1526328396652};\\\", \\\"{x:471,y:534,t:1526328396661};\\\", \\\"{x:480,y:534,t:1526328396677};\\\", \\\"{x:497,y:533,t:1526328396694};\\\", \\\"{x:513,y:530,t:1526328396712};\\\", \\\"{x:521,y:528,t:1526328396727};\\\", \\\"{x:525,y:527,t:1526328396744};\\\", \\\"{x:526,y:526,t:1526328396761};\\\", \\\"{x:527,y:526,t:1526328396777};\\\", \\\"{x:528,y:524,t:1526328396794};\\\", \\\"{x:534,y:521,t:1526328396811};\\\", \\\"{x:551,y:516,t:1526328396827};\\\", \\\"{x:578,y:508,t:1526328396843};\\\", \\\"{x:601,y:503,t:1526328396862};\\\", \\\"{x:622,y:497,t:1526328396877};\\\", \\\"{x:636,y:492,t:1526328396894};\\\", \\\"{x:640,y:492,t:1526328396911};\\\", \\\"{x:642,y:491,t:1526328396927};\\\", \\\"{x:644,y:491,t:1526328396996};\\\", \\\"{x:646,y:491,t:1526328397028};\\\", \\\"{x:652,y:491,t:1526328397799};\\\", \\\"{x:666,y:491,t:1526328397815};\\\", \\\"{x:762,y:503,t:1526328397832};\\\", \\\"{x:848,y:516,t:1526328397850};\\\", \\\"{x:934,y:528,t:1526328397866};\\\", \\\"{x:1002,y:533,t:1526328397882};\\\", \\\"{x:1047,y:539,t:1526328397899};\\\", \\\"{x:1083,y:543,t:1526328397915};\\\", \\\"{x:1126,y:550,t:1526328397932};\\\", \\\"{x:1153,y:553,t:1526328397949};\\\", \\\"{x:1179,y:558,t:1526328397965};\\\", \\\"{x:1202,y:561,t:1526328397981};\\\", \\\"{x:1220,y:563,t:1526328397999};\\\", \\\"{x:1239,y:566,t:1526328398015};\\\", \\\"{x:1249,y:566,t:1526328398032};\\\", \\\"{x:1255,y:569,t:1526328398049};\\\", \\\"{x:1263,y:569,t:1526328398066};\\\", \\\"{x:1268,y:570,t:1526328398082};\\\", \\\"{x:1272,y:570,t:1526328398099};\\\", \\\"{x:1279,y:570,t:1526328398115};\\\", \\\"{x:1287,y:570,t:1526328398132};\\\", \\\"{x:1298,y:570,t:1526328398148};\\\", \\\"{x:1309,y:568,t:1526328398166};\\\", \\\"{x:1319,y:566,t:1526328398182};\\\", \\\"{x:1326,y:561,t:1526328398199};\\\", \\\"{x:1334,y:557,t:1526328398215};\\\", \\\"{x:1340,y:554,t:1526328398231};\\\", \\\"{x:1350,y:549,t:1526328398249};\\\", \\\"{x:1362,y:543,t:1526328398266};\\\", \\\"{x:1377,y:535,t:1526328398281};\\\", \\\"{x:1389,y:526,t:1526328398298};\\\", \\\"{x:1395,y:520,t:1526328398316};\\\", \\\"{x:1400,y:516,t:1526328398331};\\\", \\\"{x:1403,y:515,t:1526328398348};\\\", \\\"{x:1404,y:514,t:1526328398366};\\\", \\\"{x:1405,y:513,t:1526328398382};\\\", \\\"{x:1405,y:514,t:1526328398471};\\\", \\\"{x:1405,y:515,t:1526328398483};\\\", \\\"{x:1405,y:518,t:1526328398498};\\\", \\\"{x:1405,y:520,t:1526328398515};\\\", \\\"{x:1403,y:525,t:1526328398533};\\\", \\\"{x:1403,y:527,t:1526328398548};\\\", \\\"{x:1399,y:529,t:1526328398565};\\\", \\\"{x:1396,y:532,t:1526328398583};\\\", \\\"{x:1393,y:534,t:1526328398599};\\\", \\\"{x:1391,y:535,t:1526328398816};\\\", \\\"{x:1389,y:536,t:1526328398847};\\\", \\\"{x:1390,y:538,t:1526328399096};\\\", \\\"{x:1391,y:538,t:1526328399127};\\\", \\\"{x:1391,y:539,t:1526328399135};\\\", \\\"{x:1391,y:540,t:1526328399150};\\\", \\\"{x:1392,y:540,t:1526328399166};\\\", \\\"{x:1392,y:542,t:1526328399183};\\\", \\\"{x:1392,y:544,t:1526328399200};\\\", \\\"{x:1393,y:546,t:1526328399216};\\\", \\\"{x:1393,y:550,t:1526328399233};\\\", \\\"{x:1393,y:552,t:1526328399250};\\\", \\\"{x:1395,y:557,t:1526328399267};\\\", \\\"{x:1396,y:560,t:1526328399283};\\\", \\\"{x:1396,y:563,t:1526328399300};\\\", \\\"{x:1397,y:566,t:1526328399316};\\\", \\\"{x:1399,y:569,t:1526328399333};\\\", \\\"{x:1399,y:570,t:1526328399352};\\\", \\\"{x:1400,y:571,t:1526328399425};\\\", \\\"{x:1400,y:572,t:1526328399463};\\\", \\\"{x:1400,y:573,t:1526328399488};\\\", \\\"{x:1401,y:573,t:1526328399504};\\\", \\\"{x:1402,y:574,t:1526328399640};\\\", \\\"{x:1403,y:574,t:1526328399703};\\\", \\\"{x:1403,y:575,t:1526328399717};\\\", \\\"{x:1403,y:576,t:1526328399733};\\\", \\\"{x:1403,y:578,t:1526328399750};\\\", \\\"{x:1404,y:580,t:1526328399767};\\\", \\\"{x:1405,y:582,t:1526328399784};\\\", \\\"{x:1406,y:582,t:1526328399800};\\\", \\\"{x:1406,y:583,t:1526328399888};\\\", \\\"{x:1406,y:584,t:1526328399975};\\\", \\\"{x:1406,y:585,t:1526328400264};\\\", \\\"{x:1406,y:586,t:1526328400271};\\\", \\\"{x:1406,y:588,t:1526328400288};\\\", \\\"{x:1406,y:589,t:1526328400301};\\\", \\\"{x:1407,y:591,t:1526328400317};\\\", \\\"{x:1407,y:592,t:1526328400334};\\\", \\\"{x:1407,y:593,t:1526328400352};\\\", \\\"{x:1407,y:594,t:1526328400367};\\\", \\\"{x:1408,y:595,t:1526328400384};\\\", \\\"{x:1408,y:596,t:1526328400401};\\\", \\\"{x:1408,y:597,t:1526328400417};\\\", \\\"{x:1408,y:598,t:1526328400440};\\\", \\\"{x:1408,y:599,t:1526328400451};\\\", \\\"{x:1409,y:600,t:1526328400467};\\\", \\\"{x:1409,y:601,t:1526328400484};\\\", \\\"{x:1409,y:604,t:1526328400501};\\\", \\\"{x:1409,y:605,t:1526328400519};\\\", \\\"{x:1409,y:606,t:1526328400535};\\\", \\\"{x:1409,y:607,t:1526328400656};\\\", \\\"{x:1409,y:608,t:1526328400680};\\\", \\\"{x:1409,y:609,t:1526328400697};\\\", \\\"{x:1409,y:610,t:1526328400704};\\\", \\\"{x:1409,y:611,t:1526328400727};\\\", \\\"{x:1409,y:612,t:1526328400735};\\\", \\\"{x:1409,y:613,t:1526328400751};\\\", \\\"{x:1409,y:614,t:1526328400768};\\\", \\\"{x:1409,y:615,t:1526328400783};\\\", \\\"{x:1409,y:616,t:1526328402792};\\\", \\\"{x:1408,y:617,t:1526328402831};\\\", \\\"{x:1403,y:622,t:1526328408088};\\\", \\\"{x:1383,y:636,t:1526328408095};\\\", \\\"{x:1343,y:653,t:1526328408107};\\\", \\\"{x:1256,y:688,t:1526328408123};\\\", \\\"{x:1171,y:716,t:1526328408140};\\\", \\\"{x:1111,y:738,t:1526328408158};\\\", \\\"{x:1070,y:762,t:1526328408173};\\\", \\\"{x:1046,y:784,t:1526328408190};\\\", \\\"{x:1027,y:820,t:1526328408207};\\\", \\\"{x:1020,y:838,t:1526328408223};\\\", \\\"{x:1018,y:848,t:1526328408240};\\\", \\\"{x:1018,y:853,t:1526328408257};\\\", \\\"{x:1018,y:859,t:1526328408273};\\\", \\\"{x:1020,y:869,t:1526328408290};\\\", \\\"{x:1022,y:887,t:1526328408307};\\\", \\\"{x:1029,y:916,t:1526328408323};\\\", \\\"{x:1049,y:965,t:1526328408340};\\\", \\\"{x:1061,y:989,t:1526328408357};\\\", \\\"{x:1083,y:1003,t:1526328408373};\\\", \\\"{x:1101,y:1011,t:1526328408390};\\\", \\\"{x:1126,y:1016,t:1526328408407};\\\", \\\"{x:1149,y:1016,t:1526328408424};\\\", \\\"{x:1176,y:1016,t:1526328408440};\\\", \\\"{x:1208,y:1016,t:1526328408457};\\\", \\\"{x:1236,y:1016,t:1526328408473};\\\", \\\"{x:1263,y:1016,t:1526328408491};\\\", \\\"{x:1285,y:1016,t:1526328408507};\\\", \\\"{x:1301,y:1016,t:1526328408525};\\\", \\\"{x:1314,y:1016,t:1526328408540};\\\", \\\"{x:1316,y:1015,t:1526328408557};\\\", \\\"{x:1317,y:1009,t:1526328408574};\\\", \\\"{x:1308,y:997,t:1526328408590};\\\", \\\"{x:1281,y:972,t:1526328408607};\\\", \\\"{x:1262,y:962,t:1526328408625};\\\", \\\"{x:1246,y:958,t:1526328408640};\\\", \\\"{x:1238,y:956,t:1526328408657};\\\", \\\"{x:1234,y:956,t:1526328408674};\\\", \\\"{x:1235,y:956,t:1526328408815};\\\", \\\"{x:1236,y:956,t:1526328408824};\\\", \\\"{x:1238,y:957,t:1526328408840};\\\", \\\"{x:1241,y:959,t:1526328408858};\\\", \\\"{x:1245,y:961,t:1526328408874};\\\", \\\"{x:1248,y:962,t:1526328408891};\\\", \\\"{x:1251,y:964,t:1526328408907};\\\", \\\"{x:1253,y:964,t:1526328409263};\\\", \\\"{x:1254,y:963,t:1526328409360};\\\", \\\"{x:1254,y:962,t:1526328409392};\\\", \\\"{x:1255,y:961,t:1526328410063};\\\", \\\"{x:1256,y:960,t:1526328410079};\\\", \\\"{x:1258,y:960,t:1526328410091};\\\", \\\"{x:1261,y:958,t:1526328410109};\\\", \\\"{x:1263,y:958,t:1526328410125};\\\", \\\"{x:1267,y:957,t:1526328410141};\\\", \\\"{x:1272,y:956,t:1526328410158};\\\", \\\"{x:1280,y:954,t:1526328410175};\\\", \\\"{x:1282,y:954,t:1526328410192};\\\", \\\"{x:1284,y:954,t:1526328410208};\\\", \\\"{x:1285,y:953,t:1526328410959};\\\", \\\"{x:1285,y:952,t:1526328410991};\\\", \\\"{x:1286,y:951,t:1526328411000};\\\", \\\"{x:1287,y:951,t:1526328411015};\\\", \\\"{x:1287,y:950,t:1526328411025};\\\", \\\"{x:1288,y:949,t:1526328411042};\\\", \\\"{x:1289,y:948,t:1526328411059};\\\", \\\"{x:1290,y:946,t:1526328411077};\\\", \\\"{x:1291,y:945,t:1526328411093};\\\", \\\"{x:1292,y:944,t:1526328411109};\\\", \\\"{x:1292,y:943,t:1526328411126};\\\", \\\"{x:1293,y:942,t:1526328411143};\\\", \\\"{x:1294,y:941,t:1526328411159};\\\", \\\"{x:1296,y:939,t:1526328411176};\\\", \\\"{x:1300,y:937,t:1526328411192};\\\", \\\"{x:1305,y:934,t:1526328411209};\\\", \\\"{x:1313,y:928,t:1526328411226};\\\", \\\"{x:1326,y:918,t:1526328411242};\\\", \\\"{x:1334,y:912,t:1526328411259};\\\", \\\"{x:1341,y:904,t:1526328411277};\\\", \\\"{x:1349,y:895,t:1526328411293};\\\", \\\"{x:1359,y:886,t:1526328411310};\\\", \\\"{x:1364,y:882,t:1526328411327};\\\", \\\"{x:1371,y:878,t:1526328411342};\\\", \\\"{x:1377,y:873,t:1526328411359};\\\", \\\"{x:1381,y:870,t:1526328411377};\\\", \\\"{x:1385,y:866,t:1526328411392};\\\", \\\"{x:1391,y:856,t:1526328411409};\\\", \\\"{x:1395,y:851,t:1526328411426};\\\", \\\"{x:1400,y:848,t:1526328411442};\\\", \\\"{x:1403,y:845,t:1526328411459};\\\", \\\"{x:1405,y:842,t:1526328411477};\\\", \\\"{x:1407,y:840,t:1526328411493};\\\", \\\"{x:1408,y:840,t:1526328411509};\\\", \\\"{x:1409,y:838,t:1526328411526};\\\", \\\"{x:1412,y:835,t:1526328411543};\\\", \\\"{x:1413,y:832,t:1526328411559};\\\", \\\"{x:1415,y:824,t:1526328411576};\\\", \\\"{x:1418,y:819,t:1526328411592};\\\", \\\"{x:1420,y:810,t:1526328411609};\\\", \\\"{x:1420,y:798,t:1526328411626};\\\", \\\"{x:1420,y:787,t:1526328411644};\\\", \\\"{x:1420,y:773,t:1526328411659};\\\", \\\"{x:1420,y:763,t:1526328411676};\\\", \\\"{x:1422,y:753,t:1526328411693};\\\", \\\"{x:1424,y:744,t:1526328411709};\\\", \\\"{x:1425,y:738,t:1526328411727};\\\", \\\"{x:1426,y:729,t:1526328411743};\\\", \\\"{x:1427,y:722,t:1526328411759};\\\", \\\"{x:1427,y:718,t:1526328411776};\\\", \\\"{x:1427,y:717,t:1526328411793};\\\", \\\"{x:1427,y:715,t:1526328411810};\\\", \\\"{x:1427,y:714,t:1526328411827};\\\", \\\"{x:1427,y:712,t:1526328411847};\\\", \\\"{x:1427,y:711,t:1526328411859};\\\", \\\"{x:1427,y:710,t:1526328412519};\\\", \\\"{x:1426,y:711,t:1526328412599};\\\", \\\"{x:1424,y:712,t:1526328412711};\\\", \\\"{x:1423,y:714,t:1526328412839};\\\", \\\"{x:1415,y:714,t:1526328416031};\\\", \\\"{x:1405,y:714,t:1526328416046};\\\", \\\"{x:1371,y:714,t:1526328416063};\\\", \\\"{x:1344,y:714,t:1526328416079};\\\", \\\"{x:1314,y:714,t:1526328416096};\\\", \\\"{x:1268,y:714,t:1526328416113};\\\", \\\"{x:1223,y:714,t:1526328416129};\\\", \\\"{x:1162,y:714,t:1526328416147};\\\", \\\"{x:1064,y:711,t:1526328416164};\\\", \\\"{x:939,y:690,t:1526328416180};\\\", \\\"{x:794,y:667,t:1526328416197};\\\", \\\"{x:655,y:636,t:1526328416213};\\\", \\\"{x:520,y:604,t:1526328416230};\\\", \\\"{x:399,y:575,t:1526328416247};\\\", \\\"{x:299,y:547,t:1526328416263};\\\", \\\"{x:285,y:543,t:1526328416280};\\\", \\\"{x:284,y:542,t:1526328416297};\\\", \\\"{x:289,y:542,t:1526328416351};\\\", \\\"{x:292,y:542,t:1526328416363};\\\", \\\"{x:300,y:542,t:1526328416380};\\\", \\\"{x:307,y:542,t:1526328416396};\\\", \\\"{x:322,y:542,t:1526328416413};\\\", \\\"{x:341,y:542,t:1526328416431};\\\", \\\"{x:377,y:548,t:1526328416447};\\\", \\\"{x:490,y:575,t:1526328416463};\\\", \\\"{x:611,y:602,t:1526328416480};\\\", \\\"{x:756,y:637,t:1526328416496};\\\", \\\"{x:952,y:690,t:1526328416514};\\\", \\\"{x:1183,y:742,t:1526328416530};\\\", \\\"{x:1409,y:803,t:1526328416547};\\\", \\\"{x:1600,y:861,t:1526328416563};\\\", \\\"{x:1728,y:910,t:1526328416580};\\\", \\\"{x:1777,y:936,t:1526328416596};\\\", \\\"{x:1790,y:953,t:1526328416614};\\\", \\\"{x:1790,y:964,t:1526328416630};\\\", \\\"{x:1778,y:977,t:1526328416647};\\\", \\\"{x:1700,y:986,t:1526328416663};\\\", \\\"{x:1623,y:986,t:1526328416680};\\\", \\\"{x:1539,y:976,t:1526328416697};\\\", \\\"{x:1474,y:964,t:1526328416714};\\\", \\\"{x:1409,y:952,t:1526328416730};\\\", \\\"{x:1365,y:937,t:1526328416748};\\\", \\\"{x:1331,y:931,t:1526328416764};\\\", \\\"{x:1311,y:930,t:1526328416781};\\\", \\\"{x:1307,y:930,t:1526328416797};\\\", \\\"{x:1305,y:930,t:1526328416813};\\\", \\\"{x:1304,y:930,t:1526328416831};\\\", \\\"{x:1303,y:932,t:1526328416846};\\\", \\\"{x:1303,y:936,t:1526328416863};\\\", \\\"{x:1303,y:938,t:1526328416880};\\\", \\\"{x:1303,y:939,t:1526328416919};\\\", \\\"{x:1303,y:940,t:1526328416930};\\\", \\\"{x:1305,y:942,t:1526328416947};\\\", \\\"{x:1315,y:946,t:1526328416964};\\\", \\\"{x:1328,y:947,t:1526328416980};\\\", \\\"{x:1340,y:950,t:1526328416997};\\\", \\\"{x:1353,y:950,t:1526328417014};\\\", \\\"{x:1364,y:950,t:1526328417030};\\\", \\\"{x:1378,y:950,t:1526328417047};\\\", \\\"{x:1400,y:951,t:1526328417063};\\\", \\\"{x:1410,y:951,t:1526328417080};\\\", \\\"{x:1421,y:951,t:1526328417096};\\\", \\\"{x:1440,y:953,t:1526328417114};\\\", \\\"{x:1454,y:953,t:1526328417130};\\\", \\\"{x:1469,y:953,t:1526328417147};\\\", \\\"{x:1484,y:955,t:1526328417163};\\\", \\\"{x:1497,y:956,t:1526328417180};\\\", \\\"{x:1506,y:957,t:1526328417197};\\\", \\\"{x:1509,y:958,t:1526328417213};\\\", \\\"{x:1510,y:959,t:1526328417271};\\\", \\\"{x:1510,y:961,t:1526328417281};\\\", \\\"{x:1505,y:964,t:1526328417298};\\\", \\\"{x:1499,y:968,t:1526328417314};\\\", \\\"{x:1488,y:974,t:1526328417330};\\\", \\\"{x:1477,y:977,t:1526328417347};\\\", \\\"{x:1463,y:980,t:1526328417364};\\\", \\\"{x:1446,y:983,t:1526328417380};\\\", \\\"{x:1423,y:983,t:1526328417397};\\\", \\\"{x:1388,y:983,t:1526328417414};\\\", \\\"{x:1340,y:979,t:1526328417430};\\\", \\\"{x:1213,y:956,t:1526328417447};\\\", \\\"{x:1146,y:948,t:1526328417464};\\\", \\\"{x:1112,y:946,t:1526328417480};\\\", \\\"{x:1090,y:945,t:1526328417498};\\\", \\\"{x:1075,y:945,t:1526328417514};\\\", \\\"{x:1068,y:945,t:1526328417531};\\\", \\\"{x:1065,y:945,t:1526328417548};\\\", \\\"{x:1061,y:946,t:1526328417563};\\\", \\\"{x:1058,y:946,t:1526328417580};\\\", \\\"{x:1054,y:947,t:1526328417598};\\\", \\\"{x:1052,y:948,t:1526328417614};\\\", \\\"{x:1051,y:948,t:1526328417631};\\\", \\\"{x:1050,y:948,t:1526328417655};\\\", \\\"{x:1050,y:946,t:1526328417695};\\\", \\\"{x:1051,y:943,t:1526328417702};\\\", \\\"{x:1055,y:940,t:1526328417714};\\\", \\\"{x:1060,y:933,t:1526328417731};\\\", \\\"{x:1070,y:924,t:1526328417748};\\\", \\\"{x:1082,y:916,t:1526328417764};\\\", \\\"{x:1096,y:906,t:1526328417781};\\\", \\\"{x:1116,y:891,t:1526328417798};\\\", \\\"{x:1147,y:864,t:1526328417815};\\\", \\\"{x:1200,y:828,t:1526328417830};\\\", \\\"{x:1245,y:806,t:1526328417847};\\\", \\\"{x:1250,y:803,t:1526328417864};\\\", \\\"{x:1270,y:790,t:1526328417881};\\\", \\\"{x:1293,y:775,t:1526328417898};\\\", \\\"{x:1299,y:769,t:1526328417914};\\\", \\\"{x:1305,y:762,t:1526328417931};\\\", \\\"{x:1307,y:756,t:1526328417947};\\\", \\\"{x:1312,y:735,t:1526328417965};\\\", \\\"{x:1316,y:707,t:1526328417981};\\\", \\\"{x:1317,y:684,t:1526328417998};\\\", \\\"{x:1310,y:674,t:1526328418015};\\\", \\\"{x:1292,y:655,t:1526328418031};\\\", \\\"{x:1253,y:631,t:1526328418050};\\\", \\\"{x:1192,y:603,t:1526328418065};\\\", \\\"{x:1125,y:570,t:1526328418081};\\\", \\\"{x:1059,y:532,t:1526328418097};\\\", \\\"{x:975,y:470,t:1526328418115};\\\", \\\"{x:894,y:411,t:1526328418131};\\\", \\\"{x:851,y:370,t:1526328418147};\\\", \\\"{x:834,y:350,t:1526328418164};\\\", \\\"{x:826,y:336,t:1526328418180};\\\", \\\"{x:821,y:324,t:1526328418198};\\\", \\\"{x:820,y:317,t:1526328418215};\\\", \\\"{x:820,y:316,t:1526328418231};\\\", \\\"{x:820,y:315,t:1526328418248};\\\", \\\"{x:837,y:309,t:1526328418264};\\\", \\\"{x:860,y:302,t:1526328418281};\\\", \\\"{x:881,y:296,t:1526328418297};\\\", \\\"{x:906,y:291,t:1526328418315};\\\", \\\"{x:933,y:291,t:1526328418330};\\\", \\\"{x:959,y:295,t:1526328418348};\\\", \\\"{x:983,y:306,t:1526328418364};\\\", \\\"{x:1014,y:327,t:1526328418381};\\\", \\\"{x:1043,y:348,t:1526328418397};\\\", \\\"{x:1061,y:368,t:1526328418415};\\\", \\\"{x:1066,y:375,t:1526328418432};\\\", \\\"{x:1072,y:390,t:1526328418447};\\\", \\\"{x:1075,y:398,t:1526328418464};\\\", \\\"{x:1078,y:411,t:1526328418482};\\\", \\\"{x:1082,y:431,t:1526328418498};\\\", \\\"{x:1085,y:461,t:1526328418515};\\\", \\\"{x:1088,y:493,t:1526328418532};\\\", \\\"{x:1088,y:513,t:1526328418547};\\\", \\\"{x:1088,y:528,t:1526328418565};\\\", \\\"{x:1088,y:541,t:1526328418581};\\\", \\\"{x:1086,y:556,t:1526328418598};\\\", \\\"{x:1082,y:583,t:1526328418615};\\\", \\\"{x:1077,y:608,t:1526328418631};\\\", \\\"{x:1072,y:638,t:1526328418647};\\\", \\\"{x:1070,y:672,t:1526328418665};\\\", \\\"{x:1070,y:714,t:1526328418682};\\\", \\\"{x:1073,y:748,t:1526328418697};\\\", \\\"{x:1075,y:766,t:1526328418715};\\\", \\\"{x:1077,y:775,t:1526328418732};\\\", \\\"{x:1078,y:781,t:1526328418748};\\\", \\\"{x:1079,y:786,t:1526328418765};\\\", \\\"{x:1079,y:789,t:1526328418782};\\\", \\\"{x:1079,y:794,t:1526328418797};\\\", \\\"{x:1079,y:803,t:1526328418815};\\\", \\\"{x:1078,y:824,t:1526328418831};\\\", \\\"{x:1076,y:839,t:1526328418847};\\\", \\\"{x:1076,y:858,t:1526328418865};\\\", \\\"{x:1076,y:876,t:1526328418881};\\\", \\\"{x:1076,y:891,t:1526328418897};\\\", \\\"{x:1080,y:908,t:1526328418915};\\\", \\\"{x:1085,y:923,t:1526328418931};\\\", \\\"{x:1093,y:933,t:1526328418948};\\\", \\\"{x:1098,y:941,t:1526328418965};\\\", \\\"{x:1103,y:952,t:1526328418982};\\\", \\\"{x:1107,y:960,t:1526328418999};\\\", \\\"{x:1111,y:975,t:1526328419015};\\\", \\\"{x:1113,y:999,t:1526328419031};\\\", \\\"{x:1116,y:1012,t:1526328419048};\\\", \\\"{x:1116,y:1018,t:1526328419064};\\\", \\\"{x:1117,y:1021,t:1526328419081};\\\", \\\"{x:1117,y:1020,t:1526328419183};\\\", \\\"{x:1117,y:1019,t:1526328419199};\\\", \\\"{x:1117,y:1018,t:1526328419215};\\\", \\\"{x:1117,y:1016,t:1526328419232};\\\", \\\"{x:1117,y:1015,t:1526328419287};\\\", \\\"{x:1118,y:1013,t:1526328419303};\\\", \\\"{x:1118,y:1012,t:1526328419335};\\\", \\\"{x:1118,y:1011,t:1526328419348};\\\", \\\"{x:1119,y:1010,t:1526328419365};\\\", \\\"{x:1120,y:1009,t:1526328419424};\\\", \\\"{x:1120,y:1008,t:1526328419464};\\\", \\\"{x:1120,y:1007,t:1526328419487};\\\", \\\"{x:1121,y:1005,t:1526328419519};\\\", \\\"{x:1122,y:1004,t:1526328419720};\\\", \\\"{x:1123,y:1004,t:1526328419831};\\\", \\\"{x:1123,y:1003,t:1526328419863};\\\", \\\"{x:1123,y:1002,t:1526328419887};\\\", \\\"{x:1123,y:1001,t:1526328419927};\\\", \\\"{x:1123,y:1000,t:1526328419967};\\\", \\\"{x:1123,y:999,t:1526328419982};\\\", \\\"{x:1123,y:998,t:1526328419999};\\\", \\\"{x:1123,y:997,t:1526328420023};\\\", \\\"{x:1123,y:996,t:1526328420039};\\\", \\\"{x:1123,y:995,t:1526328420049};\\\", \\\"{x:1123,y:994,t:1526328420079};\\\", \\\"{x:1123,y:993,t:1526328420087};\\\", \\\"{x:1123,y:992,t:1526328420111};\\\", \\\"{x:1123,y:991,t:1526328420135};\\\", \\\"{x:1123,y:990,t:1526328420149};\\\", \\\"{x:1123,y:989,t:1526328420165};\\\", \\\"{x:1123,y:988,t:1526328420191};\\\", \\\"{x:1123,y:987,t:1526328420207};\\\", \\\"{x:1123,y:986,t:1526328420216};\\\", \\\"{x:1123,y:984,t:1526328420232};\\\", \\\"{x:1123,y:983,t:1526328420249};\\\", \\\"{x:1123,y:982,t:1526328420265};\\\", \\\"{x:1123,y:980,t:1526328420283};\\\", \\\"{x:1124,y:979,t:1526328420303};\\\", \\\"{x:1124,y:978,t:1526328420318};\\\", \\\"{x:1124,y:977,t:1526328420332};\\\", \\\"{x:1124,y:976,t:1526328420348};\\\", \\\"{x:1124,y:974,t:1526328420366};\\\", \\\"{x:1124,y:970,t:1526328420382};\\\", \\\"{x:1124,y:967,t:1526328420399};\\\", \\\"{x:1124,y:964,t:1526328420416};\\\", \\\"{x:1124,y:961,t:1526328420433};\\\", \\\"{x:1124,y:960,t:1526328420449};\\\", \\\"{x:1124,y:958,t:1526328420466};\\\", \\\"{x:1124,y:957,t:1526328420631};\\\", \\\"{x:1124,y:955,t:1526328420647};\\\", \\\"{x:1124,y:953,t:1526328420662};\\\", \\\"{x:1124,y:950,t:1526328420670};\\\", \\\"{x:1124,y:947,t:1526328420682};\\\", \\\"{x:1124,y:943,t:1526328420699};\\\", \\\"{x:1124,y:939,t:1526328420716};\\\", \\\"{x:1124,y:936,t:1526328420733};\\\", \\\"{x:1124,y:933,t:1526328420750};\\\", \\\"{x:1124,y:931,t:1526328420766};\\\", \\\"{x:1126,y:926,t:1526328420783};\\\", \\\"{x:1127,y:922,t:1526328420799};\\\", \\\"{x:1127,y:918,t:1526328420816};\\\", \\\"{x:1131,y:911,t:1526328420833};\\\", \\\"{x:1132,y:905,t:1526328420850};\\\", \\\"{x:1135,y:902,t:1526328420866};\\\", \\\"{x:1136,y:896,t:1526328420883};\\\", \\\"{x:1140,y:892,t:1526328420900};\\\", \\\"{x:1143,y:884,t:1526328420916};\\\", \\\"{x:1148,y:871,t:1526328420932};\\\", \\\"{x:1152,y:849,t:1526328420949};\\\", \\\"{x:1156,y:820,t:1526328420965};\\\", \\\"{x:1161,y:777,t:1526328420983};\\\", \\\"{x:1171,y:747,t:1526328420999};\\\", \\\"{x:1182,y:716,t:1526328421015};\\\", \\\"{x:1192,y:691,t:1526328421033};\\\", \\\"{x:1206,y:665,t:1526328421049};\\\", \\\"{x:1213,y:641,t:1526328421066};\\\", \\\"{x:1220,y:619,t:1526328421083};\\\", \\\"{x:1232,y:593,t:1526328421100};\\\", \\\"{x:1242,y:568,t:1526328421116};\\\", \\\"{x:1256,y:531,t:1526328421133};\\\", \\\"{x:1275,y:489,t:1526328421149};\\\", \\\"{x:1303,y:438,t:1526328421165};\\\", \\\"{x:1362,y:372,t:1526328421182};\\\", \\\"{x:1392,y:349,t:1526328421199};\\\", \\\"{x:1406,y:339,t:1526328421216};\\\", \\\"{x:1406,y:334,t:1526328421232};\\\", \\\"{x:1407,y:334,t:1526328421250};\\\", \\\"{x:1406,y:332,t:1526328421311};\\\", \\\"{x:1402,y:328,t:1526328421319};\\\", \\\"{x:1397,y:325,t:1526328421332};\\\", \\\"{x:1392,y:323,t:1526328421350};\\\", \\\"{x:1390,y:322,t:1526328421366};\\\", \\\"{x:1395,y:315,t:1526328421575};\\\", \\\"{x:1407,y:301,t:1526328421582};\\\", \\\"{x:1434,y:282,t:1526328421600};\\\", \\\"{x:1451,y:273,t:1526328421617};\\\", \\\"{x:1468,y:265,t:1526328421633};\\\", \\\"{x:1490,y:253,t:1526328421649};\\\", \\\"{x:1508,y:236,t:1526328421667};\\\", \\\"{x:1520,y:210,t:1526328421683};\\\", \\\"{x:1530,y:180,t:1526328421700};\\\", \\\"{x:1532,y:169,t:1526328421716};\\\", \\\"{x:1533,y:164,t:1526328421733};\\\", \\\"{x:1533,y:156,t:1526328421749};\\\", \\\"{x:1531,y:147,t:1526328421767};\\\", \\\"{x:1530,y:143,t:1526328421783};\\\", \\\"{x:1529,y:143,t:1526328421831};\\\", \\\"{x:1526,y:151,t:1526328421838};\\\", \\\"{x:1524,y:161,t:1526328421850};\\\", \\\"{x:1520,y:176,t:1526328421867};\\\", \\\"{x:1517,y:204,t:1526328421883};\\\", \\\"{x:1515,y:229,t:1526328421900};\\\", \\\"{x:1515,y:239,t:1526328421917};\\\", \\\"{x:1515,y:249,t:1526328421933};\\\", \\\"{x:1516,y:265,t:1526328421949};\\\", \\\"{x:1521,y:297,t:1526328421967};\\\", \\\"{x:1524,y:319,t:1526328421983};\\\", \\\"{x:1529,y:337,t:1526328422000};\\\", \\\"{x:1533,y:353,t:1526328422017};\\\", \\\"{x:1541,y:371,t:1526328422034};\\\", \\\"{x:1554,y:390,t:1526328422049};\\\", \\\"{x:1568,y:411,t:1526328422067};\\\", \\\"{x:1582,y:428,t:1526328422083};\\\", \\\"{x:1601,y:438,t:1526328422100};\\\", \\\"{x:1622,y:447,t:1526328422117};\\\", \\\"{x:1647,y:454,t:1526328422133};\\\", \\\"{x:1666,y:457,t:1526328422150};\\\", \\\"{x:1686,y:459,t:1526328422167};\\\", \\\"{x:1693,y:456,t:1526328422184};\\\", \\\"{x:1695,y:447,t:1526328422200};\\\", \\\"{x:1695,y:433,t:1526328422217};\\\", \\\"{x:1690,y:421,t:1526328422234};\\\", \\\"{x:1683,y:413,t:1526328422250};\\\", \\\"{x:1676,y:407,t:1526328422266};\\\", \\\"{x:1673,y:405,t:1526328422284};\\\", \\\"{x:1669,y:402,t:1526328422299};\\\", \\\"{x:1668,y:402,t:1526328422317};\\\", \\\"{x:1667,y:402,t:1526328422358};\\\", \\\"{x:1666,y:402,t:1526328422366};\\\", \\\"{x:1664,y:402,t:1526328422558};\\\", \\\"{x:1661,y:403,t:1526328422567};\\\", \\\"{x:1650,y:410,t:1526328422583};\\\", \\\"{x:1634,y:425,t:1526328422600};\\\", \\\"{x:1619,y:435,t:1526328422617};\\\", \\\"{x:1612,y:440,t:1526328422634};\\\", \\\"{x:1607,y:443,t:1526328422651};\\\", \\\"{x:1604,y:445,t:1526328422667};\\\", \\\"{x:1603,y:446,t:1526328422686};\\\", \\\"{x:1605,y:445,t:1526328422871};\\\", \\\"{x:1606,y:444,t:1526328422884};\\\", \\\"{x:1608,y:441,t:1526328422900};\\\", \\\"{x:1609,y:440,t:1526328422917};\\\", \\\"{x:1610,y:439,t:1526328422933};\\\", \\\"{x:1612,y:437,t:1526328422951};\\\", \\\"{x:1613,y:436,t:1526328422967};\\\", \\\"{x:1614,y:435,t:1526328423007};\\\", \\\"{x:1614,y:433,t:1526328423016};\\\", \\\"{x:1616,y:432,t:1526328423034};\\\", \\\"{x:1616,y:431,t:1526328423050};\\\", \\\"{x:1617,y:430,t:1526328423078};\\\", \\\"{x:1615,y:430,t:1526328423279};\\\", \\\"{x:1614,y:431,t:1526328423286};\\\", \\\"{x:1613,y:431,t:1526328423301};\\\", \\\"{x:1612,y:431,t:1526328423327};\\\", \\\"{x:1611,y:432,t:1526328423343};\\\", \\\"{x:1611,y:433,t:1526328423399};\\\", \\\"{x:1611,y:435,t:1526328423407};\\\", \\\"{x:1610,y:437,t:1526328423439};\\\", \\\"{x:1610,y:438,t:1526328423455};\\\", \\\"{x:1609,y:439,t:1526328423468};\\\", \\\"{x:1606,y:445,t:1526328423484};\\\", \\\"{x:1601,y:453,t:1526328423501};\\\", \\\"{x:1597,y:461,t:1526328423517};\\\", \\\"{x:1589,y:475,t:1526328423535};\\\", \\\"{x:1585,y:483,t:1526328423550};\\\", \\\"{x:1581,y:492,t:1526328423568};\\\", \\\"{x:1577,y:502,t:1526328423585};\\\", \\\"{x:1575,y:505,t:1526328423601};\\\", \\\"{x:1573,y:515,t:1526328423618};\\\", \\\"{x:1566,y:531,t:1526328423635};\\\", \\\"{x:1560,y:548,t:1526328423651};\\\", \\\"{x:1551,y:567,t:1526328423668};\\\", \\\"{x:1541,y:586,t:1526328423685};\\\", \\\"{x:1530,y:606,t:1526328423701};\\\", \\\"{x:1517,y:632,t:1526328423718};\\\", \\\"{x:1491,y:678,t:1526328423735};\\\", \\\"{x:1478,y:702,t:1526328423750};\\\", \\\"{x:1466,y:725,t:1526328423768};\\\", \\\"{x:1450,y:744,t:1526328423785};\\\", \\\"{x:1437,y:759,t:1526328423801};\\\", \\\"{x:1421,y:771,t:1526328423817};\\\", \\\"{x:1409,y:784,t:1526328423835};\\\", \\\"{x:1391,y:802,t:1526328423851};\\\", \\\"{x:1379,y:817,t:1526328423867};\\\", \\\"{x:1368,y:832,t:1526328423884};\\\", \\\"{x:1358,y:847,t:1526328423901};\\\", \\\"{x:1353,y:858,t:1526328423917};\\\", \\\"{x:1350,y:867,t:1526328423935};\\\", \\\"{x:1350,y:872,t:1526328423951};\\\", \\\"{x:1349,y:877,t:1526328423967};\\\", \\\"{x:1348,y:885,t:1526328423985};\\\", \\\"{x:1346,y:895,t:1526328424001};\\\", \\\"{x:1345,y:906,t:1526328424018};\\\", \\\"{x:1343,y:919,t:1526328424035};\\\", \\\"{x:1339,y:937,t:1526328424051};\\\", \\\"{x:1339,y:948,t:1526328424068};\\\", \\\"{x:1336,y:961,t:1526328424085};\\\", \\\"{x:1335,y:967,t:1526328424101};\\\", \\\"{x:1333,y:972,t:1526328424117};\\\", \\\"{x:1326,y:983,t:1526328424134};\\\", \\\"{x:1324,y:988,t:1526328424151};\\\", \\\"{x:1320,y:994,t:1526328424167};\\\", \\\"{x:1313,y:1009,t:1526328424185};\\\", \\\"{x:1310,y:1017,t:1526328424201};\\\", \\\"{x:1306,y:1024,t:1526328424218};\\\", \\\"{x:1298,y:1036,t:1526328424235};\\\", \\\"{x:1295,y:1041,t:1526328424252};\\\", \\\"{x:1293,y:1044,t:1526328424268};\\\", \\\"{x:1291,y:1044,t:1526328424285};\\\", \\\"{x:1289,y:1045,t:1526328424302};\\\", \\\"{x:1287,y:1046,t:1526328424317};\\\", \\\"{x:1276,y:1046,t:1526328424335};\\\", \\\"{x:1252,y:1035,t:1526328424352};\\\", \\\"{x:1188,y:1005,t:1526328424367};\\\", \\\"{x:1089,y:948,t:1526328424385};\\\", \\\"{x:990,y:890,t:1526328424402};\\\", \\\"{x:871,y:806,t:1526328424417};\\\", \\\"{x:741,y:715,t:1526328424434};\\\", \\\"{x:628,y:640,t:1526328424452};\\\", \\\"{x:544,y:585,t:1526328424469};\\\", \\\"{x:473,y:544,t:1526328424485};\\\", \\\"{x:368,y:486,t:1526328424503};\\\", \\\"{x:311,y:455,t:1526328424519};\\\", \\\"{x:261,y:432,t:1526328424536};\\\", \\\"{x:233,y:425,t:1526328424553};\\\", \\\"{x:221,y:423,t:1526328424570};\\\", \\\"{x:219,y:422,t:1526328424586};\\\", \\\"{x:221,y:423,t:1526328424639};\\\", \\\"{x:223,y:424,t:1526328424653};\\\", \\\"{x:228,y:426,t:1526328424669};\\\", \\\"{x:249,y:442,t:1526328424686};\\\", \\\"{x:269,y:464,t:1526328424703};\\\", \\\"{x:301,y:500,t:1526328424720};\\\", \\\"{x:338,y:537,t:1526328424737};\\\", \\\"{x:368,y:566,t:1526328424755};\\\", \\\"{x:385,y:586,t:1526328424771};\\\", \\\"{x:400,y:602,t:1526328424786};\\\", \\\"{x:412,y:614,t:1526328424802};\\\", \\\"{x:423,y:623,t:1526328424820};\\\", \\\"{x:431,y:629,t:1526328424837};\\\", \\\"{x:433,y:630,t:1526328424852};\\\", \\\"{x:434,y:630,t:1526328424879};\\\", \\\"{x:435,y:631,t:1526328424886};\\\", \\\"{x:436,y:632,t:1526328424902};\\\", \\\"{x:436,y:634,t:1526328424920};\\\", \\\"{x:435,y:636,t:1526328424937};\\\", \\\"{x:430,y:636,t:1526328424953};\\\", \\\"{x:418,y:631,t:1526328424970};\\\", \\\"{x:407,y:623,t:1526328424987};\\\", \\\"{x:389,y:605,t:1526328425004};\\\", \\\"{x:364,y:584,t:1526328425020};\\\", \\\"{x:347,y:577,t:1526328425037};\\\", \\\"{x:338,y:576,t:1526328425053};\\\", \\\"{x:333,y:574,t:1526328425070};\\\", \\\"{x:329,y:574,t:1526328425086};\\\", \\\"{x:329,y:577,t:1526328425119};\\\", \\\"{x:343,y:584,t:1526328425137};\\\", \\\"{x:359,y:592,t:1526328425153};\\\", \\\"{x:364,y:599,t:1526328425170};\\\", \\\"{x:383,y:603,t:1526328425187};\\\", \\\"{x:392,y:604,t:1526328425204};\\\", \\\"{x:395,y:606,t:1526328425220};\\\", \\\"{x:396,y:607,t:1526328425237};\\\", \\\"{x:395,y:607,t:1526328425263};\\\", \\\"{x:393,y:607,t:1526328425270};\\\", \\\"{x:389,y:607,t:1526328425286};\\\", \\\"{x:384,y:604,t:1526328425303};\\\", \\\"{x:376,y:601,t:1526328425320};\\\", \\\"{x:370,y:599,t:1526328425336};\\\", \\\"{x:367,y:597,t:1526328425354};\\\", \\\"{x:365,y:597,t:1526328425370};\\\", \\\"{x:365,y:596,t:1526328425386};\\\", \\\"{x:364,y:596,t:1526328425607};\\\", \\\"{x:364,y:597,t:1526328425621};\\\", \\\"{x:365,y:598,t:1526328425636};\\\", \\\"{x:367,y:598,t:1526328425654};\\\", \\\"{x:368,y:598,t:1526328425678};\\\", \\\"{x:369,y:598,t:1526328426263};\\\", \\\"{x:370,y:598,t:1526328426271};\\\", \\\"{x:370,y:599,t:1526328426302};\\\", \\\"{x:371,y:600,t:1526328426311};\\\", \\\"{x:375,y:606,t:1526328426321};\\\", \\\"{x:391,y:628,t:1526328426339};\\\", \\\"{x:418,y:652,t:1526328426355};\\\", \\\"{x:450,y:677,t:1526328426371};\\\", \\\"{x:477,y:688,t:1526328426387};\\\", \\\"{x:495,y:692,t:1526328426404};\\\", \\\"{x:505,y:693,t:1526328426421};\\\", \\\"{x:508,y:693,t:1526328426438};\\\", \\\"{x:508,y:694,t:1526328426583};\\\", \\\"{x:508,y:695,t:1526328426590};\\\", \\\"{x:508,y:696,t:1526328426605};\\\", \\\"{x:504,y:691,t:1526328426687};\\\", \\\"{x:499,y:686,t:1526328426695};\\\", \\\"{x:491,y:675,t:1526328426705};\\\", \\\"{x:484,y:656,t:1526328426721};\\\", \\\"{x:470,y:646,t:1526328426738};\\\", \\\"{x:465,y:641,t:1526328426754};\\\", \\\"{x:463,y:639,t:1526328426770};\\\", \\\"{x:462,y:638,t:1526328426787};\\\", \\\"{x:459,y:638,t:1526328426919};\\\", \\\"{x:450,y:636,t:1526328426926};\\\", \\\"{x:444,y:633,t:1526328426938};\\\", \\\"{x:429,y:622,t:1526328426955};\\\", \\\"{x:413,y:613,t:1526328426972};\\\", \\\"{x:398,y:604,t:1526328426988};\\\", \\\"{x:387,y:599,t:1526328427005};\\\", \\\"{x:386,y:597,t:1526328427022};\\\", \\\"{x:385,y:598,t:1526328428176};\\\", \\\"{x:385,y:605,t:1526328428189};\\\", \\\"{x:394,y:628,t:1526328428207};\\\", \\\"{x:417,y:682,t:1526328428224};\\\", \\\"{x:432,y:711,t:1526328428239};\\\", \\\"{x:442,y:731,t:1526328428256};\\\", \\\"{x:447,y:742,t:1526328428272};\\\", \\\"{x:450,y:744,t:1526328428289};\\\", \\\"{x:451,y:745,t:1526328428306};\\\", \\\"{x:452,y:746,t:1526328428322};\\\", \\\"{x:453,y:746,t:1526328428343};\\\", \\\"{x:455,y:746,t:1526328428662};\\\", \\\"{x:472,y:748,t:1526328429119};\\\", \\\"{x:518,y:758,t:1526328429127};\\\", \\\"{x:566,y:762,t:1526328429139};\\\", \\\"{x:700,y:790,t:1526328429156};\\\", \\\"{x:842,y:835,t:1526328429174};\\\", \\\"{x:963,y:869,t:1526328429189};\\\", \\\"{x:1051,y:904,t:1526328429207};\\\", \\\"{x:1096,y:926,t:1526328429223};\\\", \\\"{x:1103,y:930,t:1526328429239};\\\", \\\"{x:1103,y:931,t:1526328429257};\\\", \\\"{x:1103,y:934,t:1526328429272};\\\", \\\"{x:1095,y:945,t:1526328429289};\\\", \\\"{x:1092,y:953,t:1526328429306};\\\", \\\"{x:1092,y:959,t:1526328429323};\\\", \\\"{x:1092,y:961,t:1526328429339};\\\", \\\"{x:1094,y:967,t:1526328429356};\\\", \\\"{x:1094,y:966,t:1526328429399};\\\", \\\"{x:1100,y:967,t:1526328429406};\\\", \\\"{x:1126,y:966,t:1526328429423};\\\", \\\"{x:1189,y:952,t:1526328429439};\\\", \\\"{x:1273,y:937,t:1526328429456};\\\", \\\"{x:1361,y:902,t:1526328429473};\\\", \\\"{x:1437,y:872,t:1526328429489};\\\", \\\"{x:1506,y:845,t:1526328429506};\\\", \\\"{x:1560,y:823,t:1526328429523};\\\", \\\"{x:1607,y:805,t:1526328429539};\\\", \\\"{x:1650,y:788,t:1526328429556};\\\", \\\"{x:1700,y:766,t:1526328429574};\\\", \\\"{x:1772,y:736,t:1526328429589};\\\", \\\"{x:1887,y:690,t:1526328429606};\\\", \\\"{x:1919,y:569,t:1526328429623};\\\", \\\"{x:1919,y:445,t:1526328429638};\\\", \\\"{x:1919,y:306,t:1526328429657};\\\", \\\"{x:1919,y:190,t:1526328429674};\\\", \\\"{x:1910,y:151,t:1526328429691};\\\", \\\"{x:1895,y:143,t:1526328429707};\\\", \\\"{x:1861,y:137,t:1526328429724};\\\", \\\"{x:1799,y:138,t:1526328429741};\\\", \\\"{x:1736,y:155,t:1526328429757};\\\", \\\"{x:1711,y:168,t:1526328429774};\\\", \\\"{x:1694,y:186,t:1526328429790};\\\", \\\"{x:1678,y:205,t:1526328429807};\\\", \\\"{x:1671,y:207,t:1526328429824};\\\", \\\"{x:1668,y:210,t:1526328429840};\\\", \\\"{x:1656,y:222,t:1526328429857};\\\", \\\"{x:1643,y:246,t:1526328429874};\\\", \\\"{x:1631,y:270,t:1526328429890};\\\", \\\"{x:1617,y:311,t:1526328429907};\\\", \\\"{x:1605,y:360,t:1526328429924};\\\", \\\"{x:1599,y:396,t:1526328429940};\\\", \\\"{x:1597,y:404,t:1526328429957};\\\", \\\"{x:1595,y:408,t:1526328429974};\\\", \\\"{x:1594,y:416,t:1526328429990};\\\", \\\"{x:1594,y:423,t:1526328430007};\\\", \\\"{x:1594,y:429,t:1526328430024};\\\", \\\"{x:1590,y:434,t:1526328430041};\\\", \\\"{x:1581,y:444,t:1526328430057};\\\", \\\"{x:1572,y:451,t:1526328430074};\\\", \\\"{x:1569,y:454,t:1526328430092};\\\", \\\"{x:1568,y:456,t:1526328430107};\\\", \\\"{x:1567,y:457,t:1526328430124};\\\", \\\"{x:1567,y:458,t:1526328430175};\\\", \\\"{x:1572,y:458,t:1526328430191};\\\", \\\"{x:1589,y:457,t:1526328430208};\\\", \\\"{x:1610,y:453,t:1526328430224};\\\", \\\"{x:1634,y:450,t:1526328430241};\\\", \\\"{x:1656,y:448,t:1526328430257};\\\", \\\"{x:1674,y:446,t:1526328430274};\\\", \\\"{x:1684,y:446,t:1526328430291};\\\", \\\"{x:1700,y:450,t:1526328430308};\\\", \\\"{x:1713,y:455,t:1526328430324};\\\", \\\"{x:1723,y:460,t:1526328430341};\\\", \\\"{x:1728,y:463,t:1526328430357};\\\", \\\"{x:1731,y:466,t:1526328430375};\\\", \\\"{x:1731,y:468,t:1526328430391};\\\", \\\"{x:1731,y:470,t:1526328430409};\\\", \\\"{x:1731,y:473,t:1526328430424};\\\", \\\"{x:1729,y:477,t:1526328430441};\\\", \\\"{x:1721,y:486,t:1526328430458};\\\", \\\"{x:1709,y:500,t:1526328430474};\\\", \\\"{x:1687,y:518,t:1526328430491};\\\", \\\"{x:1643,y:556,t:1526328430508};\\\", \\\"{x:1608,y:583,t:1526328430524};\\\", \\\"{x:1595,y:595,t:1526328430541};\\\", \\\"{x:1590,y:602,t:1526328430558};\\\", \\\"{x:1587,y:607,t:1526328430574};\\\", \\\"{x:1586,y:614,t:1526328430591};\\\", \\\"{x:1586,y:621,t:1526328430608};\\\", \\\"{x:1587,y:625,t:1526328430624};\\\", \\\"{x:1589,y:626,t:1526328430641};\\\", \\\"{x:1590,y:627,t:1526328430659};\\\", \\\"{x:1590,y:628,t:1526328431207};\\\", \\\"{x:1588,y:633,t:1526328431215};\\\", \\\"{x:1578,y:639,t:1526328431226};\\\", \\\"{x:1567,y:650,t:1526328431242};\\\", \\\"{x:1562,y:656,t:1526328431258};\\\", \\\"{x:1560,y:658,t:1526328431275};\\\", \\\"{x:1559,y:658,t:1526328431406};\\\", \\\"{x:1557,y:659,t:1526328431415};\\\", \\\"{x:1554,y:660,t:1526328431425};\\\", \\\"{x:1548,y:662,t:1526328431442};\\\", \\\"{x:1537,y:663,t:1526328431458};\\\", \\\"{x:1529,y:664,t:1526328431475};\\\", \\\"{x:1523,y:664,t:1526328431492};\\\", \\\"{x:1519,y:664,t:1526328431509};\\\", \\\"{x:1517,y:664,t:1526328431695};\\\", \\\"{x:1516,y:664,t:1526328431759};\\\", \\\"{x:1516,y:662,t:1526328431783};\\\", \\\"{x:1514,y:661,t:1526328431799};\\\", \\\"{x:1513,y:660,t:1526328431809};\\\", \\\"{x:1513,y:659,t:1526328431826};\\\", \\\"{x:1512,y:659,t:1526328431843};\\\", \\\"{x:1512,y:657,t:1526328431860};\\\", \\\"{x:1512,y:656,t:1526328431875};\\\", \\\"{x:1512,y:654,t:1526328431895};\\\", \\\"{x:1512,y:653,t:1526328431919};\\\", \\\"{x:1512,y:651,t:1526328431935};\\\", \\\"{x:1512,y:650,t:1526328431951};\\\", \\\"{x:1512,y:648,t:1526328431959};\\\", \\\"{x:1512,y:646,t:1526328431976};\\\", \\\"{x:1512,y:644,t:1526328431992};\\\", \\\"{x:1512,y:643,t:1526328432009};\\\", \\\"{x:1512,y:642,t:1526328432026};\\\", \\\"{x:1512,y:641,t:1526328432042};\\\", \\\"{x:1512,y:640,t:1526328432071};\\\", \\\"{x:1512,y:639,t:1526328432078};\\\", \\\"{x:1512,y:638,t:1526328432095};\\\", \\\"{x:1512,y:637,t:1526328432109};\\\", \\\"{x:1513,y:634,t:1526328432125};\\\", \\\"{x:1513,y:632,t:1526328432159};\\\", \\\"{x:1510,y:632,t:1526328432319};\\\", \\\"{x:1508,y:633,t:1526328432336};\\\", \\\"{x:1507,y:635,t:1526328432343};\\\", \\\"{x:1502,y:639,t:1526328432359};\\\", \\\"{x:1499,y:642,t:1526328432376};\\\", \\\"{x:1497,y:644,t:1526328432392};\\\", \\\"{x:1494,y:648,t:1526328432409};\\\", \\\"{x:1490,y:654,t:1526328432426};\\\", \\\"{x:1485,y:659,t:1526328432442};\\\", \\\"{x:1479,y:668,t:1526328432459};\\\", \\\"{x:1473,y:675,t:1526328432476};\\\", \\\"{x:1464,y:686,t:1526328432492};\\\", \\\"{x:1457,y:695,t:1526328432509};\\\", \\\"{x:1448,y:706,t:1526328432526};\\\", \\\"{x:1439,y:715,t:1526328432543};\\\", \\\"{x:1423,y:730,t:1526328432559};\\\", \\\"{x:1415,y:736,t:1526328432576};\\\", \\\"{x:1406,y:746,t:1526328432593};\\\", \\\"{x:1398,y:756,t:1526328432609};\\\", \\\"{x:1392,y:766,t:1526328432626};\\\", \\\"{x:1385,y:776,t:1526328432642};\\\", \\\"{x:1379,y:785,t:1526328432659};\\\", \\\"{x:1377,y:793,t:1526328432677};\\\", \\\"{x:1376,y:797,t:1526328432692};\\\", \\\"{x:1376,y:800,t:1526328432709};\\\", \\\"{x:1375,y:804,t:1526328432726};\\\", \\\"{x:1374,y:806,t:1526328432743};\\\", \\\"{x:1374,y:809,t:1526328432760};\\\", \\\"{x:1373,y:812,t:1526328432776};\\\", \\\"{x:1373,y:818,t:1526328432793};\\\", \\\"{x:1371,y:825,t:1526328432809};\\\", \\\"{x:1369,y:835,t:1526328432827};\\\", \\\"{x:1368,y:848,t:1526328432843};\\\", \\\"{x:1366,y:861,t:1526328432859};\\\", \\\"{x:1363,y:870,t:1526328432876};\\\", \\\"{x:1363,y:884,t:1526328432893};\\\", \\\"{x:1363,y:887,t:1526328432910};\\\", \\\"{x:1363,y:889,t:1526328432926};\\\", \\\"{x:1363,y:892,t:1526328432942};\\\", \\\"{x:1363,y:894,t:1526328432959};\\\", \\\"{x:1363,y:898,t:1526328432977};\\\", \\\"{x:1360,y:903,t:1526328432994};\\\", \\\"{x:1355,y:910,t:1526328433009};\\\", \\\"{x:1347,y:926,t:1526328433027};\\\", \\\"{x:1340,y:935,t:1526328433043};\\\", \\\"{x:1327,y:953,t:1526328433060};\\\", \\\"{x:1319,y:964,t:1526328433076};\\\", \\\"{x:1315,y:971,t:1526328433093};\\\", \\\"{x:1309,y:980,t:1526328433110};\\\", \\\"{x:1306,y:986,t:1526328433126};\\\", \\\"{x:1305,y:987,t:1526328433143};\\\", \\\"{x:1303,y:988,t:1526328433319};\\\", \\\"{x:1301,y:988,t:1526328433327};\\\", \\\"{x:1286,y:986,t:1526328433343};\\\", \\\"{x:1241,y:985,t:1526328433361};\\\", \\\"{x:1136,y:985,t:1526328433376};\\\", \\\"{x:993,y:997,t:1526328433394};\\\", \\\"{x:824,y:1028,t:1526328433410};\\\", \\\"{x:634,y:1048,t:1526328433427};\\\", \\\"{x:463,y:1068,t:1526328433443};\\\", \\\"{x:311,y:1068,t:1526328433460};\\\", \\\"{x:178,y:1068,t:1526328433477};\\\", \\\"{x:67,y:1068,t:1526328433493};\\\", \\\"{x:0,y:1068,t:1526328433511};\\\", \\\"{x:0,y:1070,t:1526328433526};\\\", \\\"{x:0,y:1073,t:1526328433542};\\\", \\\"{x:0,y:1076,t:1526328433560};\\\", \\\"{x:0,y:1074,t:1526328433646};\\\", \\\"{x:0,y:1059,t:1526328433661};\\\", \\\"{x:0,y:989,t:1526328433676};\\\", \\\"{x:0,y:904,t:1526328433693};\\\", \\\"{x:0,y:827,t:1526328433711};\\\", \\\"{x:0,y:769,t:1526328433727};\\\", \\\"{x:0,y:763,t:1526328433743};\\\", \\\"{x:0,y:762,t:1526328433760};\\\", \\\"{x:7,y:762,t:1526328433871};\\\", \\\"{x:18,y:758,t:1526328433879};\\\", \\\"{x:30,y:756,t:1526328433893};\\\", \\\"{x:61,y:752,t:1526328433911};\\\", \\\"{x:135,y:750,t:1526328433927};\\\", \\\"{x:191,y:742,t:1526328433943};\\\", \\\"{x:246,y:730,t:1526328433960};\\\", \\\"{x:286,y:727,t:1526328433977};\\\", \\\"{x:318,y:722,t:1526328433993};\\\", \\\"{x:340,y:719,t:1526328434010};\\\", \\\"{x:350,y:719,t:1526328434027};\\\", \\\"{x:357,y:719,t:1526328434043};\\\", \\\"{x:358,y:719,t:1526328434071};\\\", \\\"{x:359,y:719,t:1526328434087};\\\", \\\"{x:360,y:719,t:1526328434095};\\\", \\\"{x:362,y:719,t:1526328434111};\\\", \\\"{x:368,y:721,t:1526328434127};\\\", \\\"{x:377,y:727,t:1526328434143};\\\", \\\"{x:398,y:734,t:1526328434160};\\\", \\\"{x:420,y:739,t:1526328434177};\\\", \\\"{x:437,y:742,t:1526328434194};\\\", \\\"{x:443,y:743,t:1526328434210};\\\", \\\"{x:445,y:743,t:1526328434227};\\\", \\\"{x:447,y:743,t:1526328434246};\\\", \\\"{x:451,y:743,t:1526328434261};\\\", \\\"{x:470,y:737,t:1526328434277};\\\", \\\"{x:492,y:732,t:1526328434295};\\\", \\\"{x:535,y:723,t:1526328434310};\\\", \\\"{x:556,y:719,t:1526328434327};\\\", \\\"{x:571,y:717,t:1526328434345};\\\", \\\"{x:581,y:717,t:1526328434360};\\\", \\\"{x:584,y:717,t:1526328434377};\\\", \\\"{x:586,y:717,t:1526328434394};\\\", \\\"{x:587,y:716,t:1526328435391};\\\", \\\"{x:588,y:716,t:1526328435958};\\\", \\\"{x:589,y:717,t:1526328436838};\\\", \\\"{x:589,y:718,t:1526328436878};\\\", \\\"{x:589,y:719,t:1526328436886};\\\", \\\"{x:588,y:719,t:1526328436897};\\\", \\\"{x:584,y:720,t:1526328436912};\\\", \\\"{x:580,y:722,t:1526328436929};\\\", \\\"{x:577,y:722,t:1526328436946};\\\", \\\"{x:574,y:722,t:1526328436962};\\\", \\\"{x:569,y:722,t:1526328436980};\\\", \\\"{x:566,y:722,t:1526328436996};\\\", \\\"{x:563,y:722,t:1526328437013};\\\", \\\"{x:562,y:722,t:1526328437028};\\\", \\\"{x:560,y:722,t:1526328437046};\\\", \\\"{x:558,y:723,t:1526328437062};\\\", \\\"{x:554,y:723,t:1526328437079};\\\", \\\"{x:551,y:724,t:1526328437096};\\\", \\\"{x:546,y:724,t:1526328437113};\\\", \\\"{x:540,y:725,t:1526328437129};\\\", \\\"{x:535,y:725,t:1526328437147};\\\", \\\"{x:530,y:726,t:1526328437163};\\\", \\\"{x:523,y:727,t:1526328437179};\\\", \\\"{x:517,y:727,t:1526328437196};\\\", \\\"{x:509,y:729,t:1526328437213};\\\", \\\"{x:505,y:729,t:1526328437229};\\\", \\\"{x:503,y:730,t:1526328437246};\\\", \\\"{x:510,y:731,t:1526328437615};\\\", \\\"{x:540,y:735,t:1526328437630};\\\", \\\"{x:575,y:737,t:1526328437646};\\\", \\\"{x:600,y:738,t:1526328437663};\\\", \\\"{x:609,y:738,t:1526328437680};\\\", \\\"{x:612,y:738,t:1526328437696};\\\", \\\"{x:613,y:738,t:1526328437726};\\\", \\\"{x:617,y:738,t:1526328437734};\\\", \\\"{x:625,y:740,t:1526328437746};\\\", \\\"{x:640,y:742,t:1526328437763};\\\", \\\"{x:666,y:748,t:1526328437780};\\\", \\\"{x:718,y:757,t:1526328437796};\\\", \\\"{x:782,y:765,t:1526328437813};\\\", \\\"{x:891,y:782,t:1526328437830};\\\", \\\"{x:960,y:796,t:1526328437846};\\\", \\\"{x:1008,y:803,t:1526328437863};\\\", \\\"{x:1045,y:810,t:1526328437881};\\\", \\\"{x:1069,y:812,t:1526328437896};\\\", \\\"{x:1084,y:815,t:1526328437913};\\\", \\\"{x:1091,y:816,t:1526328437930};\\\", \\\"{x:1096,y:816,t:1526328437947};\\\", \\\"{x:1098,y:816,t:1526328437963};\\\", \\\"{x:1100,y:816,t:1526328437980};\\\", \\\"{x:1102,y:816,t:1526328437997};\\\" ] }, { \\\"rt\\\": 24353, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 305803, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-3-3-C -C -11 AM-10 AM-08 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1100,y:815,t:1526328441279};\\\", \\\"{x:1076,y:806,t:1526328441287};\\\", \\\"{x:1038,y:799,t:1526328441299};\\\", \\\"{x:940,y:779,t:1526328441317};\\\", \\\"{x:816,y:750,t:1526328441332};\\\", \\\"{x:687,y:720,t:1526328441349};\\\", \\\"{x:486,y:667,t:1526328441366};\\\", \\\"{x:367,y:635,t:1526328441383};\\\", \\\"{x:267,y:603,t:1526328441400};\\\", \\\"{x:198,y:576,t:1526328441417};\\\", \\\"{x:173,y:563,t:1526328441433};\\\", \\\"{x:163,y:556,t:1526328441450};\\\", \\\"{x:161,y:552,t:1526328441466};\\\", \\\"{x:161,y:545,t:1526328441484};\\\", \\\"{x:166,y:533,t:1526328441500};\\\", \\\"{x:176,y:520,t:1526328441517};\\\", \\\"{x:195,y:505,t:1526328441533};\\\", \\\"{x:224,y:492,t:1526328441549};\\\", \\\"{x:270,y:472,t:1526328441566};\\\", \\\"{x:291,y:463,t:1526328441583};\\\", \\\"{x:302,y:457,t:1526328441599};\\\", \\\"{x:306,y:455,t:1526328441616};\\\", \\\"{x:307,y:454,t:1526328441671};\\\", \\\"{x:311,y:453,t:1526328441684};\\\", \\\"{x:324,y:452,t:1526328441700};\\\", \\\"{x:339,y:452,t:1526328441716};\\\", \\\"{x:363,y:452,t:1526328441733};\\\", \\\"{x:400,y:457,t:1526328441750};\\\", \\\"{x:429,y:464,t:1526328441767};\\\", \\\"{x:462,y:476,t:1526328441783};\\\", \\\"{x:511,y:493,t:1526328441800};\\\", \\\"{x:553,y:506,t:1526328441817};\\\", \\\"{x:593,y:513,t:1526328441833};\\\", \\\"{x:612,y:513,t:1526328441850};\\\", \\\"{x:621,y:513,t:1526328441867};\\\", \\\"{x:627,y:513,t:1526328441884};\\\", \\\"{x:632,y:513,t:1526328441900};\\\", \\\"{x:636,y:512,t:1526328441916};\\\", \\\"{x:641,y:512,t:1526328441933};\\\", \\\"{x:660,y:512,t:1526328441950};\\\", \\\"{x:675,y:512,t:1526328441966};\\\", \\\"{x:700,y:512,t:1526328441983};\\\", \\\"{x:723,y:513,t:1526328442000};\\\", \\\"{x:738,y:515,t:1526328442017};\\\", \\\"{x:752,y:515,t:1526328442034};\\\", \\\"{x:762,y:515,t:1526328442050};\\\", \\\"{x:767,y:515,t:1526328442066};\\\", \\\"{x:771,y:515,t:1526328442083};\\\", \\\"{x:773,y:515,t:1526328442100};\\\", \\\"{x:775,y:515,t:1526328442117};\\\", \\\"{x:777,y:515,t:1526328442134};\\\", \\\"{x:784,y:515,t:1526328442150};\\\", \\\"{x:789,y:515,t:1526328442166};\\\", \\\"{x:795,y:516,t:1526328442183};\\\", \\\"{x:798,y:517,t:1526328442200};\\\", \\\"{x:799,y:517,t:1526328442255};\\\", \\\"{x:800,y:516,t:1526328442687};\\\", \\\"{x:805,y:513,t:1526328442700};\\\", \\\"{x:823,y:508,t:1526328442717};\\\", \\\"{x:863,y:505,t:1526328442734};\\\", \\\"{x:996,y:496,t:1526328442750};\\\", \\\"{x:1097,y:490,t:1526328442767};\\\", \\\"{x:1196,y:490,t:1526328442785};\\\", \\\"{x:1277,y:490,t:1526328442800};\\\", \\\"{x:1330,y:490,t:1526328442817};\\\", \\\"{x:1373,y:492,t:1526328442834};\\\", \\\"{x:1397,y:496,t:1526328442851};\\\", \\\"{x:1411,y:498,t:1526328442867};\\\", \\\"{x:1416,y:500,t:1526328442885};\\\", \\\"{x:1423,y:501,t:1526328442900};\\\", \\\"{x:1433,y:504,t:1526328442917};\\\", \\\"{x:1458,y:506,t:1526328442934};\\\", \\\"{x:1479,y:507,t:1526328442951};\\\", \\\"{x:1495,y:509,t:1526328442968};\\\", \\\"{x:1506,y:511,t:1526328442985};\\\", \\\"{x:1510,y:512,t:1526328443001};\\\", \\\"{x:1511,y:512,t:1526328443018};\\\", \\\"{x:1511,y:513,t:1526328443038};\\\", \\\"{x:1511,y:514,t:1526328443054};\\\", \\\"{x:1511,y:519,t:1526328443068};\\\", \\\"{x:1500,y:531,t:1526328443085};\\\", \\\"{x:1461,y:558,t:1526328443102};\\\", \\\"{x:1370,y:614,t:1526328443117};\\\", \\\"{x:1233,y:697,t:1526328443134};\\\", \\\"{x:1183,y:729,t:1526328443151};\\\", \\\"{x:1166,y:737,t:1526328443167};\\\", \\\"{x:1150,y:746,t:1526328443184};\\\", \\\"{x:1134,y:752,t:1526328443201};\\\", \\\"{x:1121,y:757,t:1526328443218};\\\", \\\"{x:1104,y:768,t:1526328443235};\\\", \\\"{x:1082,y:798,t:1526328443251};\\\", \\\"{x:1044,y:864,t:1526328443267};\\\", \\\"{x:998,y:938,t:1526328443284};\\\", \\\"{x:969,y:987,t:1526328443301};\\\", \\\"{x:960,y:1009,t:1526328443317};\\\", \\\"{x:958,y:1026,t:1526328443334};\\\", \\\"{x:965,y:1041,t:1526328443352};\\\", \\\"{x:983,y:1057,t:1526328443367};\\\", \\\"{x:1007,y:1071,t:1526328443384};\\\", \\\"{x:1035,y:1084,t:1526328443402};\\\", \\\"{x:1068,y:1100,t:1526328443418};\\\", \\\"{x:1109,y:1110,t:1526328443435};\\\", \\\"{x:1142,y:1117,t:1526328443451};\\\", \\\"{x:1181,y:1123,t:1526328443467};\\\", \\\"{x:1215,y:1128,t:1526328443484};\\\", \\\"{x:1238,y:1129,t:1526328443502};\\\", \\\"{x:1255,y:1129,t:1526328443517};\\\", \\\"{x:1265,y:1120,t:1526328443534};\\\", \\\"{x:1266,y:1106,t:1526328443552};\\\", \\\"{x:1266,y:1081,t:1526328443568};\\\", \\\"{x:1259,y:1048,t:1526328443585};\\\", \\\"{x:1252,y:1019,t:1526328443601};\\\", \\\"{x:1247,y:997,t:1526328443619};\\\", \\\"{x:1246,y:976,t:1526328443634};\\\", \\\"{x:1246,y:956,t:1526328443652};\\\", \\\"{x:1246,y:937,t:1526328443668};\\\", \\\"{x:1248,y:919,t:1526328443685};\\\", \\\"{x:1252,y:906,t:1526328443701};\\\", \\\"{x:1252,y:901,t:1526328443719};\\\", \\\"{x:1253,y:899,t:1526328443734};\\\", \\\"{x:1254,y:894,t:1526328443751};\\\", \\\"{x:1254,y:885,t:1526328443768};\\\", \\\"{x:1257,y:875,t:1526328443784};\\\", \\\"{x:1257,y:865,t:1526328443801};\\\", \\\"{x:1257,y:855,t:1526328443818};\\\", \\\"{x:1255,y:851,t:1526328443834};\\\", \\\"{x:1252,y:846,t:1526328443851};\\\", \\\"{x:1251,y:845,t:1526328443868};\\\", \\\"{x:1250,y:844,t:1526328443885};\\\", \\\"{x:1249,y:844,t:1526328444007};\\\", \\\"{x:1248,y:845,t:1526328444023};\\\", \\\"{x:1248,y:850,t:1526328444036};\\\", \\\"{x:1248,y:864,t:1526328444051};\\\", \\\"{x:1253,y:880,t:1526328444068};\\\", \\\"{x:1263,y:896,t:1526328444086};\\\", \\\"{x:1272,y:911,t:1526328444102};\\\", \\\"{x:1287,y:929,t:1526328444118};\\\", \\\"{x:1296,y:937,t:1526328444135};\\\", \\\"{x:1303,y:945,t:1526328444152};\\\", \\\"{x:1309,y:952,t:1526328444169};\\\", \\\"{x:1314,y:960,t:1526328444186};\\\", \\\"{x:1319,y:966,t:1526328444202};\\\", \\\"{x:1324,y:972,t:1526328444219};\\\", \\\"{x:1331,y:979,t:1526328444235};\\\", \\\"{x:1337,y:984,t:1526328444252};\\\", \\\"{x:1342,y:991,t:1526328444268};\\\", \\\"{x:1343,y:994,t:1526328444285};\\\", \\\"{x:1345,y:1001,t:1526328444302};\\\", \\\"{x:1345,y:1015,t:1526328444318};\\\", \\\"{x:1345,y:1030,t:1526328444335};\\\", \\\"{x:1345,y:1038,t:1526328444351};\\\", \\\"{x:1345,y:1042,t:1526328444368};\\\", \\\"{x:1346,y:1043,t:1526328444385};\\\", \\\"{x:1346,y:1042,t:1526328444695};\\\", \\\"{x:1345,y:1041,t:1526328444798};\\\", \\\"{x:1342,y:1038,t:1526328445830};\\\", \\\"{x:1340,y:1038,t:1526328445838};\\\", \\\"{x:1335,y:1034,t:1526328445854};\\\", \\\"{x:1323,y:1027,t:1526328445870};\\\", \\\"{x:1295,y:1011,t:1526328445887};\\\", \\\"{x:1266,y:989,t:1526328445904};\\\", \\\"{x:1234,y:967,t:1526328445920};\\\", \\\"{x:1201,y:945,t:1526328445937};\\\", \\\"{x:1160,y:914,t:1526328445954};\\\", \\\"{x:1127,y:891,t:1526328445969};\\\", \\\"{x:1101,y:873,t:1526328445986};\\\", \\\"{x:1089,y:860,t:1526328446004};\\\", \\\"{x:1083,y:847,t:1526328446020};\\\", \\\"{x:1080,y:832,t:1526328446036};\\\", \\\"{x:1077,y:814,t:1526328446054};\\\", \\\"{x:1075,y:797,t:1526328446069};\\\", \\\"{x:1066,y:772,t:1526328446086};\\\", \\\"{x:1063,y:760,t:1526328446103};\\\", \\\"{x:1061,y:752,t:1526328446120};\\\", \\\"{x:1061,y:748,t:1526328446137};\\\", \\\"{x:1061,y:746,t:1526328446154};\\\", \\\"{x:1061,y:745,t:1526328446169};\\\", \\\"{x:1061,y:744,t:1526328446207};\\\", \\\"{x:1062,y:744,t:1526328446223};\\\", \\\"{x:1064,y:742,t:1526328446239};\\\", \\\"{x:1065,y:741,t:1526328446254};\\\", \\\"{x:1067,y:740,t:1526328446271};\\\", \\\"{x:1070,y:737,t:1526328446287};\\\", \\\"{x:1072,y:736,t:1526328446303};\\\", \\\"{x:1073,y:734,t:1526328446320};\\\", \\\"{x:1074,y:733,t:1526328446337};\\\", \\\"{x:1075,y:732,t:1526328446354};\\\", \\\"{x:1077,y:731,t:1526328446370};\\\", \\\"{x:1079,y:730,t:1526328446387};\\\", \\\"{x:1080,y:730,t:1526328446403};\\\", \\\"{x:1081,y:729,t:1526328446421};\\\", \\\"{x:1082,y:729,t:1526328447014};\\\", \\\"{x:1083,y:728,t:1526328448071};\\\", \\\"{x:1084,y:728,t:1526328448078};\\\", \\\"{x:1085,y:728,t:1526328448094};\\\", \\\"{x:1085,y:729,t:1526328449199};\\\", \\\"{x:1085,y:732,t:1526328449214};\\\", \\\"{x:1085,y:735,t:1526328449222};\\\", \\\"{x:1077,y:741,t:1526328449239};\\\", \\\"{x:1059,y:761,t:1526328449256};\\\", \\\"{x:1035,y:806,t:1526328449273};\\\", \\\"{x:1004,y:881,t:1526328449290};\\\", \\\"{x:979,y:946,t:1526328449306};\\\", \\\"{x:967,y:990,t:1526328449323};\\\", \\\"{x:969,y:1010,t:1526328449339};\\\", \\\"{x:988,y:1015,t:1526328449356};\\\", \\\"{x:1008,y:1017,t:1526328449373};\\\", \\\"{x:1034,y:1023,t:1526328449389};\\\", \\\"{x:1057,y:1029,t:1526328449406};\\\", \\\"{x:1091,y:1042,t:1526328449422};\\\", \\\"{x:1110,y:1050,t:1526328449440};\\\", \\\"{x:1134,y:1060,t:1526328449455};\\\", \\\"{x:1162,y:1068,t:1526328449473};\\\", \\\"{x:1190,y:1073,t:1526328449490};\\\", \\\"{x:1213,y:1074,t:1526328449506};\\\", \\\"{x:1235,y:1074,t:1526328449523};\\\", \\\"{x:1254,y:1072,t:1526328449539};\\\", \\\"{x:1259,y:1062,t:1526328449555};\\\", \\\"{x:1259,y:1043,t:1526328449573};\\\", \\\"{x:1251,y:1017,t:1526328449590};\\\", \\\"{x:1237,y:995,t:1526328449606};\\\", \\\"{x:1220,y:966,t:1526328449622};\\\", \\\"{x:1212,y:951,t:1526328449640};\\\", \\\"{x:1207,y:944,t:1526328449655};\\\", \\\"{x:1202,y:936,t:1526328449673};\\\", \\\"{x:1201,y:933,t:1526328449690};\\\", \\\"{x:1201,y:930,t:1526328449707};\\\", \\\"{x:1199,y:928,t:1526328449722};\\\", \\\"{x:1199,y:927,t:1526328449742};\\\", \\\"{x:1198,y:926,t:1526328449766};\\\", \\\"{x:1198,y:925,t:1526328449774};\\\", \\\"{x:1197,y:924,t:1526328449790};\\\", \\\"{x:1195,y:920,t:1526328449806};\\\", \\\"{x:1193,y:916,t:1526328449823};\\\", \\\"{x:1186,y:910,t:1526328449840};\\\", \\\"{x:1179,y:906,t:1526328449857};\\\", \\\"{x:1172,y:900,t:1526328449873};\\\", \\\"{x:1166,y:899,t:1526328449890};\\\", \\\"{x:1162,y:897,t:1526328449907};\\\", \\\"{x:1160,y:896,t:1526328449923};\\\", \\\"{x:1157,y:896,t:1526328449940};\\\", \\\"{x:1156,y:896,t:1526328449957};\\\", \\\"{x:1155,y:896,t:1526328450006};\\\", \\\"{x:1155,y:897,t:1526328450078};\\\", \\\"{x:1156,y:897,t:1526328450090};\\\", \\\"{x:1164,y:895,t:1526328450107};\\\", \\\"{x:1176,y:885,t:1526328450122};\\\", \\\"{x:1187,y:878,t:1526328450140};\\\", \\\"{x:1194,y:870,t:1526328450157};\\\", \\\"{x:1197,y:850,t:1526328450174};\\\", \\\"{x:1201,y:833,t:1526328450190};\\\", \\\"{x:1205,y:822,t:1526328450206};\\\", \\\"{x:1207,y:820,t:1526328450224};\\\", \\\"{x:1207,y:819,t:1526328450279};\\\", \\\"{x:1208,y:819,t:1526328450289};\\\", \\\"{x:1211,y:822,t:1526328450306};\\\", \\\"{x:1213,y:825,t:1526328450325};\\\", \\\"{x:1216,y:827,t:1526328450340};\\\", \\\"{x:1216,y:828,t:1526328450357};\\\", \\\"{x:1217,y:829,t:1526328450431};\\\", \\\"{x:1219,y:829,t:1526328450446};\\\", \\\"{x:1221,y:828,t:1526328450458};\\\", \\\"{x:1225,y:828,t:1526328450473};\\\", \\\"{x:1231,y:830,t:1526328450490};\\\", \\\"{x:1242,y:840,t:1526328450507};\\\", \\\"{x:1253,y:855,t:1526328450523};\\\", \\\"{x:1264,y:878,t:1526328450539};\\\", \\\"{x:1276,y:901,t:1526328450557};\\\", \\\"{x:1287,y:921,t:1526328450574};\\\", \\\"{x:1300,y:946,t:1526328450591};\\\", \\\"{x:1306,y:958,t:1526328450607};\\\", \\\"{x:1310,y:972,t:1526328450624};\\\", \\\"{x:1316,y:989,t:1526328450640};\\\", \\\"{x:1318,y:1010,t:1526328450657};\\\", \\\"{x:1321,y:1019,t:1526328450674};\\\", \\\"{x:1323,y:1025,t:1526328450691};\\\", \\\"{x:1326,y:1029,t:1526328450707};\\\", \\\"{x:1326,y:1030,t:1526328450724};\\\", \\\"{x:1327,y:1030,t:1526328450775};\\\", \\\"{x:1327,y:1029,t:1526328450791};\\\", \\\"{x:1327,y:1024,t:1526328450807};\\\", \\\"{x:1327,y:1011,t:1526328450824};\\\", \\\"{x:1322,y:995,t:1526328450841};\\\", \\\"{x:1316,y:974,t:1526328450857};\\\", \\\"{x:1311,y:961,t:1526328450874};\\\", \\\"{x:1307,y:948,t:1526328450890};\\\", \\\"{x:1302,y:933,t:1526328450907};\\\", \\\"{x:1301,y:922,t:1526328450924};\\\", \\\"{x:1299,y:914,t:1526328450941};\\\", \\\"{x:1298,y:906,t:1526328450957};\\\", \\\"{x:1296,y:899,t:1526328450974};\\\", \\\"{x:1293,y:891,t:1526328450990};\\\", \\\"{x:1291,y:885,t:1526328451006};\\\", \\\"{x:1289,y:881,t:1526328451024};\\\", \\\"{x:1288,y:869,t:1526328451041};\\\", \\\"{x:1286,y:856,t:1526328451058};\\\", \\\"{x:1283,y:843,t:1526328451074};\\\", \\\"{x:1281,y:833,t:1526328451091};\\\", \\\"{x:1281,y:818,t:1526328451108};\\\", \\\"{x:1281,y:809,t:1526328451124};\\\", \\\"{x:1281,y:804,t:1526328451141};\\\", \\\"{x:1281,y:802,t:1526328451158};\\\", \\\"{x:1283,y:802,t:1526328451182};\\\", \\\"{x:1283,y:801,t:1526328451326};\\\", \\\"{x:1283,y:799,t:1526328451351};\\\", \\\"{x:1285,y:793,t:1526328451359};\\\", \\\"{x:1288,y:786,t:1526328451374};\\\", \\\"{x:1302,y:750,t:1526328451391};\\\", \\\"{x:1314,y:708,t:1526328451408};\\\", \\\"{x:1317,y:680,t:1526328451424};\\\", \\\"{x:1323,y:657,t:1526328451440};\\\", \\\"{x:1327,y:643,t:1526328451458};\\\", \\\"{x:1328,y:635,t:1526328451475};\\\", \\\"{x:1329,y:632,t:1526328451491};\\\", \\\"{x:1329,y:630,t:1526328451508};\\\", \\\"{x:1329,y:627,t:1526328451525};\\\", \\\"{x:1329,y:625,t:1526328451541};\\\", \\\"{x:1329,y:623,t:1526328451558};\\\", \\\"{x:1329,y:620,t:1526328451575};\\\", \\\"{x:1329,y:618,t:1526328451591};\\\", \\\"{x:1327,y:616,t:1526328452054};\\\", \\\"{x:1320,y:614,t:1526328452062};\\\", \\\"{x:1314,y:612,t:1526328452075};\\\", \\\"{x:1303,y:611,t:1526328452092};\\\", \\\"{x:1295,y:609,t:1526328452108};\\\", \\\"{x:1291,y:609,t:1526328452125};\\\", \\\"{x:1287,y:609,t:1526328452142};\\\", \\\"{x:1281,y:613,t:1526328452158};\\\", \\\"{x:1272,y:640,t:1526328452175};\\\", \\\"{x:1255,y:686,t:1526328452192};\\\", \\\"{x:1236,y:756,t:1526328452207};\\\", \\\"{x:1229,y:811,t:1526328452225};\\\", \\\"{x:1231,y:855,t:1526328452242};\\\", \\\"{x:1241,y:883,t:1526328452258};\\\", \\\"{x:1255,y:903,t:1526328452275};\\\", \\\"{x:1265,y:910,t:1526328452291};\\\", \\\"{x:1273,y:911,t:1526328452308};\\\", \\\"{x:1275,y:911,t:1526328452325};\\\", \\\"{x:1276,y:902,t:1526328452342};\\\", \\\"{x:1276,y:893,t:1526328452358};\\\", \\\"{x:1276,y:889,t:1526328452375};\\\", \\\"{x:1274,y:885,t:1526328452392};\\\", \\\"{x:1273,y:883,t:1526328452409};\\\", \\\"{x:1273,y:880,t:1526328452425};\\\", \\\"{x:1272,y:876,t:1526328452441};\\\", \\\"{x:1272,y:870,t:1526328452459};\\\", \\\"{x:1272,y:868,t:1526328452475};\\\", \\\"{x:1272,y:866,t:1526328452492};\\\", \\\"{x:1272,y:863,t:1526328452509};\\\", \\\"{x:1272,y:861,t:1526328452525};\\\", \\\"{x:1274,y:857,t:1526328452542};\\\", \\\"{x:1274,y:856,t:1526328452559};\\\", \\\"{x:1275,y:855,t:1526328452623};\\\", \\\"{x:1276,y:860,t:1526328452638};\\\", \\\"{x:1277,y:870,t:1526328452646};\\\", \\\"{x:1280,y:882,t:1526328452659};\\\", \\\"{x:1282,y:904,t:1526328452675};\\\", \\\"{x:1284,y:919,t:1526328452692};\\\", \\\"{x:1288,y:930,t:1526328452709};\\\", \\\"{x:1292,y:941,t:1526328452725};\\\", \\\"{x:1294,y:947,t:1526328452742};\\\", \\\"{x:1298,y:953,t:1526328452759};\\\", \\\"{x:1299,y:954,t:1526328452775};\\\", \\\"{x:1300,y:956,t:1526328452814};\\\", \\\"{x:1299,y:956,t:1526328453158};\\\", \\\"{x:1297,y:957,t:1526328453176};\\\", \\\"{x:1293,y:959,t:1526328453193};\\\", \\\"{x:1286,y:961,t:1526328453209};\\\", \\\"{x:1282,y:962,t:1526328453226};\\\", \\\"{x:1280,y:963,t:1526328453243};\\\", \\\"{x:1279,y:963,t:1526328453259};\\\", \\\"{x:1278,y:963,t:1526328453326};\\\", \\\"{x:1279,y:965,t:1526328453359};\\\", \\\"{x:1281,y:967,t:1526328453374};\\\", \\\"{x:1281,y:968,t:1526328453382};\\\", \\\"{x:1282,y:968,t:1526328453393};\\\", \\\"{x:1282,y:969,t:1526328453446};\\\", \\\"{x:1281,y:969,t:1526328454686};\\\", \\\"{x:1261,y:973,t:1526328454694};\\\", \\\"{x:1199,y:987,t:1526328454711};\\\", \\\"{x:1151,y:1001,t:1526328454727};\\\", \\\"{x:1120,y:1011,t:1526328454744};\\\", \\\"{x:1102,y:1017,t:1526328454760};\\\", \\\"{x:1099,y:1019,t:1526328454777};\\\", \\\"{x:1099,y:1021,t:1526328454794};\\\", \\\"{x:1099,y:1023,t:1526328454810};\\\", \\\"{x:1097,y:1024,t:1526328454902};\\\", \\\"{x:1095,y:1024,t:1526328454910};\\\", \\\"{x:1082,y:1021,t:1526328454927};\\\", \\\"{x:1067,y:1016,t:1526328454944};\\\", \\\"{x:1059,y:1014,t:1526328454960};\\\", \\\"{x:1058,y:1013,t:1526328454977};\\\", \\\"{x:1057,y:1013,t:1526328454998};\\\", \\\"{x:1056,y:1012,t:1526328455011};\\\", \\\"{x:1058,y:1009,t:1526328455027};\\\", \\\"{x:1066,y:1005,t:1526328455044};\\\", \\\"{x:1087,y:992,t:1526328455062};\\\", \\\"{x:1120,y:979,t:1526328455077};\\\", \\\"{x:1191,y:933,t:1526328455094};\\\", \\\"{x:1215,y:921,t:1526328455110};\\\", \\\"{x:1230,y:917,t:1526328455128};\\\", \\\"{x:1233,y:916,t:1526328455145};\\\", \\\"{x:1234,y:916,t:1526328455174};\\\", \\\"{x:1231,y:917,t:1526328455238};\\\", \\\"{x:1228,y:920,t:1526328455246};\\\", \\\"{x:1226,y:922,t:1526328455261};\\\", \\\"{x:1220,y:926,t:1526328455277};\\\", \\\"{x:1212,y:930,t:1526328455294};\\\", \\\"{x:1210,y:930,t:1526328455311};\\\", \\\"{x:1208,y:931,t:1526328455342};\\\", \\\"{x:1207,y:933,t:1526328455358};\\\", \\\"{x:1205,y:934,t:1526328455367};\\\", \\\"{x:1202,y:937,t:1526328455377};\\\", \\\"{x:1200,y:938,t:1526328455394};\\\", \\\"{x:1198,y:939,t:1526328455411};\\\", \\\"{x:1199,y:936,t:1526328455471};\\\", \\\"{x:1199,y:932,t:1526328455478};\\\", \\\"{x:1204,y:920,t:1526328455494};\\\", \\\"{x:1208,y:902,t:1526328455511};\\\", \\\"{x:1225,y:846,t:1526328455528};\\\", \\\"{x:1230,y:791,t:1526328455544};\\\", \\\"{x:1238,y:756,t:1526328455561};\\\", \\\"{x:1242,y:740,t:1526328455578};\\\", \\\"{x:1243,y:737,t:1526328455594};\\\", \\\"{x:1244,y:734,t:1526328455611};\\\", \\\"{x:1245,y:733,t:1526328455629};\\\", \\\"{x:1247,y:731,t:1526328455644};\\\", \\\"{x:1247,y:730,t:1526328455661};\\\", \\\"{x:1248,y:730,t:1526328455743};\\\", \\\"{x:1250,y:730,t:1526328455750};\\\", \\\"{x:1252,y:733,t:1526328455761};\\\", \\\"{x:1260,y:754,t:1526328455778};\\\", \\\"{x:1269,y:774,t:1526328455794};\\\", \\\"{x:1283,y:798,t:1526328455811};\\\", \\\"{x:1298,y:819,t:1526328455828};\\\", \\\"{x:1307,y:832,t:1526328455844};\\\", \\\"{x:1313,y:841,t:1526328455861};\\\", \\\"{x:1322,y:867,t:1526328455878};\\\", \\\"{x:1324,y:894,t:1526328455894};\\\", \\\"{x:1327,y:923,t:1526328455911};\\\", \\\"{x:1327,y:951,t:1526328455928};\\\", \\\"{x:1327,y:969,t:1526328455945};\\\", \\\"{x:1327,y:978,t:1526328455962};\\\", \\\"{x:1327,y:980,t:1526328455978};\\\", \\\"{x:1327,y:977,t:1526328456238};\\\", \\\"{x:1327,y:974,t:1526328456246};\\\", \\\"{x:1327,y:972,t:1526328456261};\\\", \\\"{x:1320,y:953,t:1526328456278};\\\", \\\"{x:1313,y:941,t:1526328456295};\\\", \\\"{x:1308,y:936,t:1526328456311};\\\", \\\"{x:1307,y:934,t:1526328456328};\\\", \\\"{x:1307,y:935,t:1526328456678};\\\", \\\"{x:1307,y:937,t:1526328456696};\\\", \\\"{x:1307,y:938,t:1526328456712};\\\", \\\"{x:1306,y:938,t:1526328456728};\\\", \\\"{x:1306,y:940,t:1526328456870};\\\", \\\"{x:1306,y:941,t:1526328458082};\\\", \\\"{x:1306,y:943,t:1526328458090};\\\", \\\"{x:1306,y:944,t:1526328458113};\\\", \\\"{x:1306,y:946,t:1526328458194};\\\", \\\"{x:1305,y:948,t:1526328458209};\\\", \\\"{x:1303,y:950,t:1526328458218};\\\", \\\"{x:1300,y:955,t:1526328458234};\\\", \\\"{x:1295,y:961,t:1526328458249};\\\", \\\"{x:1288,y:969,t:1526328458266};\\\", \\\"{x:1280,y:976,t:1526328458284};\\\", \\\"{x:1275,y:981,t:1526328458300};\\\", \\\"{x:1271,y:984,t:1526328458317};\\\", \\\"{x:1270,y:985,t:1526328458334};\\\", \\\"{x:1269,y:984,t:1526328458386};\\\", \\\"{x:1269,y:983,t:1526328458410};\\\", \\\"{x:1269,y:982,t:1526328458426};\\\", \\\"{x:1269,y:981,t:1526328458434};\\\", \\\"{x:1269,y:980,t:1526328458465};\\\", \\\"{x:1270,y:978,t:1526328458482};\\\", \\\"{x:1270,y:977,t:1526328458522};\\\", \\\"{x:1270,y:976,t:1526328458534};\\\", \\\"{x:1270,y:975,t:1526328458578};\\\", \\\"{x:1271,y:974,t:1526328458594};\\\", \\\"{x:1271,y:973,t:1526328458601};\\\", \\\"{x:1271,y:972,t:1526328458618};\\\", \\\"{x:1272,y:966,t:1526328458634};\\\", \\\"{x:1273,y:961,t:1526328458650};\\\", \\\"{x:1280,y:945,t:1526328458667};\\\", \\\"{x:1293,y:927,t:1526328458684};\\\", \\\"{x:1312,y:905,t:1526328458701};\\\", \\\"{x:1325,y:889,t:1526328458717};\\\", \\\"{x:1335,y:871,t:1526328458735};\\\", \\\"{x:1344,y:860,t:1526328458751};\\\", \\\"{x:1346,y:857,t:1526328458766};\\\", \\\"{x:1347,y:854,t:1526328458783};\\\", \\\"{x:1348,y:851,t:1526328458801};\\\", \\\"{x:1349,y:846,t:1526328458817};\\\", \\\"{x:1350,y:830,t:1526328458834};\\\", \\\"{x:1350,y:815,t:1526328458851};\\\", \\\"{x:1350,y:798,t:1526328458866};\\\", \\\"{x:1350,y:791,t:1526328458883};\\\", \\\"{x:1350,y:784,t:1526328458901};\\\", \\\"{x:1350,y:780,t:1526328458917};\\\", \\\"{x:1350,y:778,t:1526328458935};\\\", \\\"{x:1350,y:773,t:1526328458951};\\\", \\\"{x:1350,y:764,t:1526328458968};\\\", \\\"{x:1352,y:754,t:1526328458984};\\\", \\\"{x:1354,y:746,t:1526328459001};\\\", \\\"{x:1359,y:721,t:1526328459018};\\\", \\\"{x:1363,y:703,t:1526328459034};\\\", \\\"{x:1368,y:687,t:1526328459051};\\\", \\\"{x:1373,y:678,t:1526328459068};\\\", \\\"{x:1373,y:676,t:1526328459084};\\\", \\\"{x:1375,y:675,t:1526328459226};\\\", \\\"{x:1376,y:673,t:1526328459234};\\\", \\\"{x:1377,y:672,t:1526328459250};\\\", \\\"{x:1379,y:670,t:1526328459268};\\\", \\\"{x:1380,y:670,t:1526328459284};\\\", \\\"{x:1381,y:668,t:1526328459300};\\\", \\\"{x:1382,y:667,t:1526328459318};\\\", \\\"{x:1382,y:666,t:1526328459334};\\\", \\\"{x:1382,y:665,t:1526328459353};\\\", \\\"{x:1381,y:661,t:1526328459368};\\\", \\\"{x:1380,y:661,t:1526328459385};\\\", \\\"{x:1379,y:660,t:1526328459401};\\\", \\\"{x:1369,y:663,t:1526328460170};\\\", \\\"{x:1358,y:669,t:1526328460185};\\\", \\\"{x:1243,y:724,t:1526328460201};\\\", \\\"{x:1108,y:785,t:1526328460218};\\\", \\\"{x:940,y:858,t:1526328460235};\\\", \\\"{x:766,y:931,t:1526328460251};\\\", \\\"{x:609,y:1000,t:1526328460269};\\\", \\\"{x:438,y:1080,t:1526328460285};\\\", \\\"{x:285,y:1156,t:1526328460302};\\\", \\\"{x:140,y:1199,t:1526328460319};\\\", \\\"{x:18,y:1199,t:1526328460335};\\\", \\\"{x:0,y:1199,t:1526328460352};\\\", \\\"{x:0,y:1198,t:1526328460402};\\\", \\\"{x:0,y:1180,t:1526328460418};\\\", \\\"{x:0,y:1144,t:1526328460435};\\\", \\\"{x:0,y:1071,t:1526328460452};\\\", \\\"{x:0,y:985,t:1526328460469};\\\", \\\"{x:0,y:879,t:1526328460485};\\\", \\\"{x:0,y:772,t:1526328460502};\\\", \\\"{x:0,y:671,t:1526328460519};\\\", \\\"{x:0,y:604,t:1526328460535};\\\", \\\"{x:0,y:580,t:1526328460552};\\\", \\\"{x:0,y:567,t:1526328460569};\\\", \\\"{x:1,y:556,t:1526328460585};\\\", \\\"{x:14,y:539,t:1526328460601};\\\", \\\"{x:28,y:529,t:1526328460618};\\\", \\\"{x:56,y:516,t:1526328460635};\\\", \\\"{x:104,y:502,t:1526328460652};\\\", \\\"{x:136,y:494,t:1526328460668};\\\", \\\"{x:163,y:486,t:1526328460685};\\\", \\\"{x:190,y:480,t:1526328460701};\\\", \\\"{x:213,y:476,t:1526328460719};\\\", \\\"{x:233,y:471,t:1526328460735};\\\", \\\"{x:255,y:465,t:1526328460752};\\\", \\\"{x:268,y:459,t:1526328460769};\\\", \\\"{x:278,y:455,t:1526328460784};\\\", \\\"{x:293,y:454,t:1526328460802};\\\", \\\"{x:311,y:457,t:1526328460819};\\\", \\\"{x:332,y:471,t:1526328460835};\\\", \\\"{x:353,y:488,t:1526328460851};\\\", \\\"{x:369,y:502,t:1526328460869};\\\", \\\"{x:377,y:510,t:1526328460886};\\\", \\\"{x:379,y:515,t:1526328460901};\\\", \\\"{x:379,y:524,t:1526328460919};\\\", \\\"{x:378,y:535,t:1526328460935};\\\", \\\"{x:374,y:546,t:1526328460952};\\\", \\\"{x:372,y:551,t:1526328460969};\\\", \\\"{x:372,y:557,t:1526328460986};\\\", \\\"{x:372,y:559,t:1526328461002};\\\", \\\"{x:372,y:562,t:1526328461019};\\\", \\\"{x:372,y:566,t:1526328461036};\\\", \\\"{x:372,y:572,t:1526328461052};\\\", \\\"{x:372,y:576,t:1526328461069};\\\", \\\"{x:374,y:580,t:1526328461086};\\\", \\\"{x:375,y:581,t:1526328461101};\\\", \\\"{x:376,y:583,t:1526328461120};\\\", \\\"{x:376,y:582,t:1526328461210};\\\", \\\"{x:376,y:581,t:1526328461219};\\\", \\\"{x:376,y:580,t:1526328461322};\\\", \\\"{x:377,y:578,t:1526328461335};\\\", \\\"{x:378,y:573,t:1526328461353};\\\", \\\"{x:380,y:570,t:1526328461369};\\\", \\\"{x:381,y:566,t:1526328461385};\\\", \\\"{x:384,y:566,t:1526328461753};\\\", \\\"{x:388,y:565,t:1526328461769};\\\", \\\"{x:396,y:565,t:1526328461786};\\\", \\\"{x:404,y:565,t:1526328461803};\\\", \\\"{x:421,y:570,t:1526328461820};\\\", \\\"{x:452,y:588,t:1526328461836};\\\", \\\"{x:505,y:626,t:1526328461853};\\\", \\\"{x:567,y:673,t:1526328461869};\\\", \\\"{x:631,y:729,t:1526328461886};\\\", \\\"{x:680,y:783,t:1526328461903};\\\", \\\"{x:714,y:826,t:1526328461920};\\\", \\\"{x:735,y:852,t:1526328461936};\\\", \\\"{x:742,y:864,t:1526328461953};\\\", \\\"{x:743,y:867,t:1526328461970};\\\", \\\"{x:739,y:867,t:1526328462090};\\\", \\\"{x:731,y:867,t:1526328462103};\\\", \\\"{x:716,y:866,t:1526328462120};\\\", \\\"{x:699,y:864,t:1526328462137};\\\", \\\"{x:680,y:861,t:1526328462153};\\\", \\\"{x:664,y:859,t:1526328462170};\\\", \\\"{x:659,y:858,t:1526328462187};\\\", \\\"{x:658,y:858,t:1526328462202};\\\", \\\"{x:656,y:856,t:1526328462946};\\\", \\\"{x:656,y:855,t:1526328462961};\\\", \\\"{x:656,y:854,t:1526328462977};\\\", \\\"{x:656,y:853,t:1526328462988};\\\", \\\"{x:655,y:851,t:1526328463003};\\\", \\\"{x:654,y:849,t:1526328463020};\\\", \\\"{x:653,y:847,t:1526328463038};\\\", \\\"{x:652,y:845,t:1526328463054};\\\", \\\"{x:652,y:844,t:1526328463071};\\\", \\\"{x:651,y:843,t:1526328463089};\\\", \\\"{x:650,y:843,t:1526328463105};\\\", \\\"{x:649,y:843,t:1526328463153};\\\", \\\"{x:649,y:842,t:1526328463162};\\\", \\\"{x:648,y:842,t:1526328463193};\\\", \\\"{x:647,y:841,t:1526328463218};\\\", \\\"{x:646,y:840,t:1526328463233};\\\", \\\"{x:644,y:839,t:1526328463249};\\\", \\\"{x:643,y:837,t:1526328463266};\\\", \\\"{x:641,y:836,t:1526328463273};\\\", \\\"{x:640,y:834,t:1526328463288};\\\", \\\"{x:639,y:831,t:1526328463305};\\\", \\\"{x:632,y:824,t:1526328463321};\\\", \\\"{x:622,y:810,t:1526328463338};\\\", \\\"{x:598,y:792,t:1526328463354};\\\", \\\"{x:542,y:756,t:1526328463372};\\\", \\\"{x:480,y:724,t:1526328463388};\\\", \\\"{x:447,y:711,t:1526328463404};\\\", \\\"{x:432,y:706,t:1526328463419};\\\", \\\"{x:429,y:705,t:1526328463436};\\\", \\\"{x:429,y:704,t:1526328463594};\\\", \\\"{x:430,y:704,t:1526328463617};\\\", \\\"{x:434,y:704,t:1526328463625};\\\", \\\"{x:438,y:706,t:1526328463638};\\\", \\\"{x:445,y:706,t:1526328463654};\\\", \\\"{x:451,y:706,t:1526328463671};\\\", \\\"{x:462,y:706,t:1526328463687};\\\", \\\"{x:473,y:706,t:1526328463704};\\\", \\\"{x:479,y:706,t:1526328463721};\\\", \\\"{x:486,y:706,t:1526328463737};\\\", \\\"{x:492,y:707,t:1526328463754};\\\", \\\"{x:493,y:707,t:1526328463793};\\\", \\\"{x:494,y:707,t:1526328463818};\\\", \\\"{x:495,y:707,t:1526328463850};\\\" ] }, { \\\"rt\\\": 24346, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 331586, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-11 AM-04 PM-04 PM-04 PM-04 PM-04:30-04:30\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:708,t:1526328466642};\\\", \\\"{x:404,y:641,t:1526328466658};\\\", \\\"{x:279,y:556,t:1526328466675};\\\", \\\"{x:198,y:496,t:1526328466690};\\\", \\\"{x:166,y:473,t:1526328466707};\\\", \\\"{x:156,y:464,t:1526328466723};\\\", \\\"{x:156,y:461,t:1526328466740};\\\", \\\"{x:156,y:460,t:1526328466756};\\\", \\\"{x:156,y:458,t:1526328466773};\\\", \\\"{x:157,y:458,t:1526328466790};\\\", \\\"{x:159,y:456,t:1526328466807};\\\", \\\"{x:168,y:454,t:1526328466823};\\\", \\\"{x:183,y:452,t:1526328466840};\\\", \\\"{x:211,y:446,t:1526328466858};\\\", \\\"{x:261,y:446,t:1526328466874};\\\", \\\"{x:364,y:446,t:1526328466890};\\\", \\\"{x:426,y:446,t:1526328466908};\\\", \\\"{x:482,y:445,t:1526328466923};\\\", \\\"{x:529,y:440,t:1526328466941};\\\", \\\"{x:562,y:434,t:1526328466957};\\\", \\\"{x:586,y:429,t:1526328466973};\\\", \\\"{x:600,y:427,t:1526328466990};\\\", \\\"{x:608,y:424,t:1526328467007};\\\", \\\"{x:613,y:422,t:1526328467023};\\\", \\\"{x:615,y:421,t:1526328467040};\\\", \\\"{x:617,y:420,t:1526328467057};\\\", \\\"{x:618,y:420,t:1526328467074};\\\", \\\"{x:619,y:420,t:1526328467098};\\\", \\\"{x:620,y:420,t:1526328467153};\\\", \\\"{x:620,y:421,t:1526328467193};\\\", \\\"{x:620,y:423,t:1526328467207};\\\", \\\"{x:620,y:428,t:1526328467224};\\\", \\\"{x:620,y:431,t:1526328467240};\\\", \\\"{x:620,y:433,t:1526328467257};\\\", \\\"{x:619,y:437,t:1526328467275};\\\", \\\"{x:618,y:440,t:1526328467290};\\\", \\\"{x:618,y:441,t:1526328467313};\\\", \\\"{x:618,y:442,t:1526328467330};\\\", \\\"{x:618,y:443,t:1526328467354};\\\", \\\"{x:618,y:444,t:1526328467530};\\\", \\\"{x:616,y:446,t:1526328467540};\\\", \\\"{x:616,y:448,t:1526328467557};\\\", \\\"{x:616,y:449,t:1526328467633};\\\", \\\"{x:617,y:449,t:1526328467642};\\\", \\\"{x:619,y:449,t:1526328467657};\\\", \\\"{x:630,y:449,t:1526328467674};\\\", \\\"{x:642,y:449,t:1526328467691};\\\", \\\"{x:658,y:454,t:1526328467707};\\\", \\\"{x:676,y:459,t:1526328467725};\\\", \\\"{x:697,y:471,t:1526328467741};\\\", \\\"{x:716,y:484,t:1526328467757};\\\", \\\"{x:731,y:502,t:1526328467774};\\\", \\\"{x:746,y:524,t:1526328467792};\\\", \\\"{x:753,y:540,t:1526328467808};\\\", \\\"{x:755,y:546,t:1526328467825};\\\", \\\"{x:760,y:556,t:1526328467841};\\\", \\\"{x:772,y:571,t:1526328467857};\\\", \\\"{x:784,y:580,t:1526328467874};\\\", \\\"{x:796,y:590,t:1526328467892};\\\", \\\"{x:806,y:600,t:1526328467907};\\\", \\\"{x:811,y:606,t:1526328467924};\\\", \\\"{x:812,y:609,t:1526328467941};\\\", \\\"{x:812,y:610,t:1526328467957};\\\", \\\"{x:813,y:611,t:1526328467974};\\\", \\\"{x:814,y:611,t:1526328467992};\\\", \\\"{x:814,y:614,t:1526328468008};\\\", \\\"{x:814,y:618,t:1526328468024};\\\", \\\"{x:814,y:621,t:1526328468041};\\\", \\\"{x:814,y:623,t:1526328468058};\\\", \\\"{x:814,y:624,t:1526328468226};\\\", \\\"{x:809,y:623,t:1526328468241};\\\", \\\"{x:766,y:576,t:1526328468258};\\\", \\\"{x:700,y:519,t:1526328468276};\\\", \\\"{x:618,y:458,t:1526328468292};\\\", \\\"{x:535,y:398,t:1526328468309};\\\", \\\"{x:472,y:362,t:1526328468324};\\\", \\\"{x:435,y:343,t:1526328468341};\\\", \\\"{x:407,y:336,t:1526328468358};\\\", \\\"{x:398,y:334,t:1526328468375};\\\", \\\"{x:397,y:334,t:1526328468391};\\\", \\\"{x:397,y:335,t:1526328468409};\\\", \\\"{x:400,y:339,t:1526328468425};\\\", \\\"{x:409,y:344,t:1526328468441};\\\", \\\"{x:417,y:355,t:1526328468458};\\\", \\\"{x:426,y:368,t:1526328468475};\\\", \\\"{x:432,y:380,t:1526328468491};\\\", \\\"{x:443,y:396,t:1526328468508};\\\", \\\"{x:458,y:420,t:1526328468525};\\\", \\\"{x:476,y:444,t:1526328468541};\\\", \\\"{x:489,y:461,t:1526328468558};\\\", \\\"{x:493,y:467,t:1526328468575};\\\", \\\"{x:495,y:471,t:1526328468591};\\\", \\\"{x:496,y:472,t:1526328468608};\\\", \\\"{x:496,y:474,t:1526328468625};\\\", \\\"{x:496,y:475,t:1526328468641};\\\", \\\"{x:493,y:479,t:1526328468658};\\\", \\\"{x:488,y:482,t:1526328468675};\\\", \\\"{x:480,y:485,t:1526328468692};\\\", \\\"{x:475,y:489,t:1526328468708};\\\", \\\"{x:466,y:492,t:1526328468725};\\\", \\\"{x:459,y:493,t:1526328468742};\\\", \\\"{x:452,y:493,t:1526328468758};\\\", \\\"{x:441,y:493,t:1526328468775};\\\", \\\"{x:433,y:493,t:1526328468792};\\\", \\\"{x:425,y:491,t:1526328468808};\\\", \\\"{x:418,y:489,t:1526328468825};\\\", \\\"{x:408,y:486,t:1526328468842};\\\", \\\"{x:405,y:486,t:1526328468858};\\\", \\\"{x:404,y:486,t:1526328468897};\\\", \\\"{x:403,y:486,t:1526328468921};\\\", \\\"{x:407,y:487,t:1526328469026};\\\", \\\"{x:418,y:488,t:1526328469042};\\\", \\\"{x:454,y:493,t:1526328469060};\\\", \\\"{x:480,y:494,t:1526328469076};\\\", \\\"{x:502,y:494,t:1526328469092};\\\", \\\"{x:522,y:494,t:1526328469109};\\\", \\\"{x:542,y:490,t:1526328469125};\\\", \\\"{x:555,y:487,t:1526328469142};\\\", \\\"{x:564,y:484,t:1526328469159};\\\", \\\"{x:568,y:481,t:1526328469176};\\\", \\\"{x:570,y:480,t:1526328469192};\\\", \\\"{x:570,y:479,t:1526328470194};\\\", \\\"{x:568,y:479,t:1526328471193};\\\", \\\"{x:567,y:479,t:1526328471211};\\\", \\\"{x:567,y:478,t:1526328472994};\\\", \\\"{x:567,y:477,t:1526328473249};\\\", \\\"{x:564,y:476,t:1526328473914};\\\", \\\"{x:547,y:476,t:1526328473931};\\\", \\\"{x:534,y:476,t:1526328473947};\\\", \\\"{x:522,y:478,t:1526328473963};\\\", \\\"{x:518,y:479,t:1526328473980};\\\", \\\"{x:516,y:479,t:1526328474033};\\\", \\\"{x:514,y:479,t:1526328474049};\\\", \\\"{x:513,y:479,t:1526328474063};\\\", \\\"{x:512,y:480,t:1526328474081};\\\", \\\"{x:511,y:480,t:1526328474097};\\\", \\\"{x:510,y:480,t:1526328474113};\\\", \\\"{x:510,y:481,t:1526328474170};\\\", \\\"{x:510,y:482,t:1526328474185};\\\", \\\"{x:510,y:483,t:1526328474201};\\\", \\\"{x:510,y:485,t:1526328474217};\\\", \\\"{x:512,y:488,t:1526328474231};\\\", \\\"{x:521,y:495,t:1526328474248};\\\", \\\"{x:540,y:505,t:1526328474263};\\\", \\\"{x:567,y:517,t:1526328474281};\\\", \\\"{x:616,y:531,t:1526328474298};\\\", \\\"{x:654,y:541,t:1526328474314};\\\", \\\"{x:680,y:550,t:1526328474331};\\\", \\\"{x:700,y:557,t:1526328474347};\\\", \\\"{x:714,y:562,t:1526328474363};\\\", \\\"{x:721,y:565,t:1526328474379};\\\", \\\"{x:729,y:570,t:1526328474397};\\\", \\\"{x:736,y:571,t:1526328474413};\\\", \\\"{x:742,y:575,t:1526328474430};\\\", \\\"{x:754,y:579,t:1526328474446};\\\", \\\"{x:766,y:581,t:1526328474463};\\\", \\\"{x:776,y:584,t:1526328474481};\\\", \\\"{x:796,y:589,t:1526328474496};\\\", \\\"{x:811,y:590,t:1526328474512};\\\", \\\"{x:836,y:594,t:1526328474530};\\\", \\\"{x:852,y:594,t:1526328474547};\\\", \\\"{x:864,y:595,t:1526328474563};\\\", \\\"{x:876,y:595,t:1526328474579};\\\", \\\"{x:890,y:593,t:1526328474597};\\\", \\\"{x:905,y:589,t:1526328474613};\\\", \\\"{x:919,y:586,t:1526328474629};\\\", \\\"{x:936,y:580,t:1526328474647};\\\", \\\"{x:952,y:575,t:1526328474663};\\\", \\\"{x:971,y:565,t:1526328474680};\\\", \\\"{x:985,y:557,t:1526328474697};\\\", \\\"{x:1009,y:544,t:1526328474713};\\\", \\\"{x:1026,y:534,t:1526328474730};\\\", \\\"{x:1049,y:523,t:1526328474746};\\\", \\\"{x:1083,y:505,t:1526328474763};\\\", \\\"{x:1141,y:480,t:1526328474780};\\\", \\\"{x:1260,y:446,t:1526328474796};\\\", \\\"{x:1432,y:413,t:1526328474814};\\\", \\\"{x:1609,y:413,t:1526328474829};\\\", \\\"{x:1738,y:403,t:1526328474846};\\\", \\\"{x:1830,y:391,t:1526328474863};\\\", \\\"{x:1864,y:386,t:1526328474880};\\\", \\\"{x:1876,y:385,t:1526328474896};\\\", \\\"{x:1877,y:385,t:1526328474913};\\\", \\\"{x:1874,y:382,t:1526328475058};\\\", \\\"{x:1867,y:381,t:1526328475065};\\\", \\\"{x:1856,y:380,t:1526328475081};\\\", \\\"{x:1833,y:380,t:1526328475097};\\\", \\\"{x:1767,y:409,t:1526328475114};\\\", \\\"{x:1690,y:458,t:1526328475131};\\\", \\\"{x:1642,y:496,t:1526328475147};\\\", \\\"{x:1616,y:518,t:1526328475164};\\\", \\\"{x:1603,y:532,t:1526328475181};\\\", \\\"{x:1594,y:538,t:1526328475197};\\\", \\\"{x:1581,y:547,t:1526328475214};\\\", \\\"{x:1554,y:562,t:1526328475231};\\\", \\\"{x:1489,y:598,t:1526328475247};\\\", \\\"{x:1397,y:649,t:1526328475264};\\\", \\\"{x:1329,y:685,t:1526328475280};\\\", \\\"{x:1294,y:709,t:1526328475297};\\\", \\\"{x:1284,y:713,t:1526328475313};\\\", \\\"{x:1276,y:714,t:1526328475331};\\\", \\\"{x:1272,y:714,t:1526328475348};\\\", \\\"{x:1265,y:716,t:1526328475364};\\\", \\\"{x:1252,y:718,t:1526328475381};\\\", \\\"{x:1232,y:721,t:1526328475398};\\\", \\\"{x:1214,y:722,t:1526328475414};\\\", \\\"{x:1189,y:731,t:1526328475431};\\\", \\\"{x:1173,y:737,t:1526328475448};\\\", \\\"{x:1164,y:739,t:1526328475465};\\\", \\\"{x:1160,y:740,t:1526328475481};\\\", \\\"{x:1158,y:740,t:1526328475498};\\\", \\\"{x:1156,y:740,t:1526328475530};\\\", \\\"{x:1154,y:740,t:1526328475538};\\\", \\\"{x:1153,y:740,t:1526328475548};\\\", \\\"{x:1151,y:740,t:1526328475565};\\\", \\\"{x:1147,y:739,t:1526328475580};\\\", \\\"{x:1144,y:737,t:1526328475597};\\\", \\\"{x:1142,y:732,t:1526328475614};\\\", \\\"{x:1141,y:727,t:1526328475631};\\\", \\\"{x:1144,y:721,t:1526328475648};\\\", \\\"{x:1151,y:717,t:1526328475664};\\\", \\\"{x:1154,y:712,t:1526328475681};\\\", \\\"{x:1157,y:709,t:1526328475697};\\\", \\\"{x:1157,y:708,t:1526328475714};\\\", \\\"{x:1158,y:707,t:1526328475731};\\\", \\\"{x:1155,y:705,t:1526328475945};\\\", \\\"{x:1150,y:703,t:1526328475953};\\\", \\\"{x:1143,y:703,t:1526328475964};\\\", \\\"{x:1138,y:702,t:1526328475982};\\\", \\\"{x:1137,y:702,t:1526328475999};\\\", \\\"{x:1136,y:702,t:1526328476014};\\\", \\\"{x:1138,y:701,t:1526328476146};\\\", \\\"{x:1140,y:701,t:1526328476178};\\\", \\\"{x:1142,y:701,t:1526328476185};\\\", \\\"{x:1145,y:701,t:1526328476199};\\\", \\\"{x:1152,y:701,t:1526328476215};\\\", \\\"{x:1156,y:701,t:1526328476232};\\\", \\\"{x:1159,y:700,t:1526328476248};\\\", \\\"{x:1160,y:700,t:1526328476266};\\\", \\\"{x:1163,y:699,t:1526328476281};\\\", \\\"{x:1166,y:699,t:1526328476298};\\\", \\\"{x:1171,y:698,t:1526328476315};\\\", \\\"{x:1181,y:697,t:1526328476332};\\\", \\\"{x:1187,y:697,t:1526328476348};\\\", \\\"{x:1198,y:697,t:1526328476365};\\\", \\\"{x:1210,y:697,t:1526328476382};\\\", \\\"{x:1221,y:697,t:1526328476398};\\\", \\\"{x:1234,y:698,t:1526328476415};\\\", \\\"{x:1247,y:701,t:1526328476431};\\\", \\\"{x:1261,y:703,t:1526328476448};\\\", \\\"{x:1278,y:706,t:1526328476465};\\\", \\\"{x:1287,y:707,t:1526328476481};\\\", \\\"{x:1289,y:707,t:1526328476499};\\\", \\\"{x:1293,y:707,t:1526328476516};\\\", \\\"{x:1298,y:707,t:1526328476532};\\\", \\\"{x:1301,y:707,t:1526328476549};\\\", \\\"{x:1302,y:707,t:1526328476565};\\\", \\\"{x:1303,y:707,t:1526328476582};\\\", \\\"{x:1304,y:707,t:1526328476599};\\\", \\\"{x:1309,y:707,t:1526328476616};\\\", \\\"{x:1311,y:707,t:1526328476633};\\\", \\\"{x:1316,y:707,t:1526328476648};\\\", \\\"{x:1320,y:707,t:1526328476666};\\\", \\\"{x:1323,y:707,t:1526328476683};\\\", \\\"{x:1326,y:707,t:1526328476699};\\\", \\\"{x:1330,y:708,t:1526328476716};\\\", \\\"{x:1334,y:708,t:1526328476733};\\\", \\\"{x:1341,y:709,t:1526328476749};\\\", \\\"{x:1345,y:710,t:1526328476766};\\\", \\\"{x:1351,y:710,t:1526328476783};\\\", \\\"{x:1356,y:711,t:1526328476800};\\\", \\\"{x:1361,y:711,t:1526328476815};\\\", \\\"{x:1368,y:711,t:1526328476832};\\\", \\\"{x:1376,y:711,t:1526328476850};\\\", \\\"{x:1377,y:711,t:1526328476866};\\\", \\\"{x:1378,y:711,t:1526328476882};\\\", \\\"{x:1379,y:711,t:1526328476900};\\\", \\\"{x:1380,y:711,t:1526328476916};\\\", \\\"{x:1381,y:711,t:1526328476932};\\\", \\\"{x:1382,y:711,t:1526328476949};\\\", \\\"{x:1385,y:711,t:1526328476965};\\\", \\\"{x:1386,y:711,t:1526328476982};\\\", \\\"{x:1388,y:711,t:1526328477000};\\\", \\\"{x:1389,y:711,t:1526328477025};\\\", \\\"{x:1390,y:711,t:1526328477033};\\\", \\\"{x:1391,y:712,t:1526328477049};\\\", \\\"{x:1391,y:714,t:1526328477074};\\\", \\\"{x:1391,y:716,t:1526328477083};\\\", \\\"{x:1391,y:721,t:1526328477100};\\\", \\\"{x:1391,y:729,t:1526328477116};\\\", \\\"{x:1391,y:742,t:1526328477133};\\\", \\\"{x:1391,y:757,t:1526328477150};\\\", \\\"{x:1391,y:764,t:1526328477167};\\\", \\\"{x:1392,y:768,t:1526328477183};\\\", \\\"{x:1393,y:770,t:1526328477199};\\\", \\\"{x:1395,y:772,t:1526328477217};\\\", \\\"{x:1397,y:775,t:1526328477233};\\\", \\\"{x:1410,y:787,t:1526328477249};\\\", \\\"{x:1424,y:799,t:1526328477266};\\\", \\\"{x:1439,y:815,t:1526328477282};\\\", \\\"{x:1448,y:832,t:1526328477300};\\\", \\\"{x:1457,y:850,t:1526328477316};\\\", \\\"{x:1461,y:863,t:1526328477333};\\\", \\\"{x:1463,y:871,t:1526328477349};\\\", \\\"{x:1463,y:877,t:1526328477366};\\\", \\\"{x:1463,y:882,t:1526328477383};\\\", \\\"{x:1463,y:884,t:1526328477400};\\\", \\\"{x:1463,y:886,t:1526328477417};\\\", \\\"{x:1462,y:892,t:1526328477433};\\\", \\\"{x:1462,y:896,t:1526328477450};\\\", \\\"{x:1462,y:902,t:1526328477467};\\\", \\\"{x:1463,y:907,t:1526328477484};\\\", \\\"{x:1465,y:910,t:1526328477500};\\\", \\\"{x:1466,y:912,t:1526328477517};\\\", \\\"{x:1468,y:914,t:1526328477534};\\\", \\\"{x:1470,y:917,t:1526328477550};\\\", \\\"{x:1474,y:925,t:1526328477567};\\\", \\\"{x:1479,y:937,t:1526328477584};\\\", \\\"{x:1484,y:949,t:1526328477600};\\\", \\\"{x:1489,y:957,t:1526328477616};\\\", \\\"{x:1495,y:968,t:1526328477633};\\\", \\\"{x:1497,y:971,t:1526328477651};\\\", \\\"{x:1499,y:979,t:1526328477666};\\\", \\\"{x:1503,y:988,t:1526328477683};\\\", \\\"{x:1507,y:995,t:1526328477701};\\\", \\\"{x:1507,y:998,t:1526328477717};\\\", \\\"{x:1508,y:999,t:1526328477733};\\\", \\\"{x:1509,y:999,t:1526328477751};\\\", \\\"{x:1509,y:1000,t:1526328477767};\\\", \\\"{x:1510,y:1001,t:1526328477783};\\\", \\\"{x:1510,y:1003,t:1526328477801};\\\", \\\"{x:1510,y:1006,t:1526328477817};\\\", \\\"{x:1511,y:1006,t:1526328477834};\\\", \\\"{x:1511,y:1007,t:1526328477874};\\\", \\\"{x:1504,y:1007,t:1526328477889};\\\", \\\"{x:1497,y:1007,t:1526328477901};\\\", \\\"{x:1471,y:1007,t:1526328477918};\\\", \\\"{x:1450,y:1006,t:1526328477933};\\\", \\\"{x:1438,y:1007,t:1526328477950};\\\", \\\"{x:1436,y:1007,t:1526328477968};\\\", \\\"{x:1438,y:1007,t:1526328477985};\\\", \\\"{x:1448,y:1007,t:1526328478001};\\\", \\\"{x:1500,y:1007,t:1526328478017};\\\", \\\"{x:1537,y:1009,t:1526328478034};\\\", \\\"{x:1568,y:1009,t:1526328478051};\\\", \\\"{x:1586,y:1009,t:1526328478067};\\\", \\\"{x:1588,y:1009,t:1526328478084};\\\", \\\"{x:1588,y:1007,t:1526328478122};\\\", \\\"{x:1587,y:1007,t:1526328478135};\\\", \\\"{x:1574,y:1007,t:1526328478151};\\\", \\\"{x:1558,y:1007,t:1526328478167};\\\", \\\"{x:1535,y:1006,t:1526328478184};\\\", \\\"{x:1504,y:1001,t:1526328478201};\\\", \\\"{x:1465,y:996,t:1526328478218};\\\", \\\"{x:1446,y:995,t:1526328478234};\\\", \\\"{x:1433,y:992,t:1526328478250};\\\", \\\"{x:1420,y:990,t:1526328478268};\\\", \\\"{x:1408,y:990,t:1526328478284};\\\", \\\"{x:1397,y:990,t:1526328478301};\\\", \\\"{x:1386,y:990,t:1526328478318};\\\", \\\"{x:1368,y:990,t:1526328478335};\\\", \\\"{x:1357,y:990,t:1526328478351};\\\", \\\"{x:1344,y:990,t:1526328478368};\\\", \\\"{x:1332,y:990,t:1526328478384};\\\", \\\"{x:1325,y:990,t:1526328478401};\\\", \\\"{x:1317,y:991,t:1526328478418};\\\", \\\"{x:1314,y:991,t:1526328478434};\\\", \\\"{x:1310,y:991,t:1526328478452};\\\", \\\"{x:1305,y:991,t:1526328478468};\\\", \\\"{x:1298,y:993,t:1526328478484};\\\", \\\"{x:1293,y:995,t:1526328478502};\\\", \\\"{x:1291,y:997,t:1526328478518};\\\", \\\"{x:1293,y:999,t:1526328478534};\\\", \\\"{x:1316,y:1000,t:1526328478552};\\\", \\\"{x:1361,y:1004,t:1526328478568};\\\", \\\"{x:1453,y:1006,t:1526328478585};\\\", \\\"{x:1581,y:1006,t:1526328478601};\\\", \\\"{x:1653,y:1006,t:1526328478618};\\\", \\\"{x:1706,y:1006,t:1526328478635};\\\", \\\"{x:1733,y:1005,t:1526328478651};\\\", \\\"{x:1742,y:1004,t:1526328478669};\\\", \\\"{x:1746,y:1003,t:1526328478685};\\\", \\\"{x:1747,y:1003,t:1526328478721};\\\", \\\"{x:1748,y:1003,t:1526328478738};\\\", \\\"{x:1749,y:1003,t:1526328478752};\\\", \\\"{x:1751,y:1003,t:1526328478769};\\\", \\\"{x:1752,y:1003,t:1526328478785};\\\", \\\"{x:1749,y:1003,t:1526328478897};\\\", \\\"{x:1746,y:1003,t:1526328478905};\\\", \\\"{x:1740,y:1003,t:1526328478918};\\\", \\\"{x:1727,y:1003,t:1526328478935};\\\", \\\"{x:1710,y:1003,t:1526328478952};\\\", \\\"{x:1688,y:1001,t:1526328478969};\\\", \\\"{x:1653,y:1001,t:1526328478985};\\\", \\\"{x:1631,y:1001,t:1526328479002};\\\", \\\"{x:1612,y:1001,t:1526328479019};\\\", \\\"{x:1601,y:1001,t:1526328479036};\\\", \\\"{x:1595,y:1001,t:1526328479051};\\\", \\\"{x:1595,y:1000,t:1526328479098};\\\", \\\"{x:1595,y:998,t:1526328479122};\\\", \\\"{x:1597,y:996,t:1526328479136};\\\", \\\"{x:1601,y:993,t:1526328479152};\\\", \\\"{x:1605,y:989,t:1526328479168};\\\", \\\"{x:1611,y:986,t:1526328479186};\\\", \\\"{x:1612,y:985,t:1526328479203};\\\", \\\"{x:1614,y:985,t:1526328479281};\\\", \\\"{x:1615,y:984,t:1526328479482};\\\", \\\"{x:1615,y:983,t:1526328479490};\\\", \\\"{x:1615,y:980,t:1526328479503};\\\", \\\"{x:1616,y:972,t:1526328479520};\\\", \\\"{x:1616,y:970,t:1526328479536};\\\", \\\"{x:1617,y:968,t:1526328479553};\\\", \\\"{x:1618,y:967,t:1526328479570};\\\", \\\"{x:1618,y:965,t:1526328479945};\\\", \\\"{x:1617,y:965,t:1526328479961};\\\", \\\"{x:1616,y:964,t:1526328479970};\\\", \\\"{x:1615,y:962,t:1526328479986};\\\", \\\"{x:1611,y:959,t:1526328480004};\\\", \\\"{x:1609,y:957,t:1526328480020};\\\", \\\"{x:1607,y:953,t:1526328480037};\\\", \\\"{x:1603,y:950,t:1526328480054};\\\", \\\"{x:1600,y:947,t:1526328480070};\\\", \\\"{x:1594,y:942,t:1526328480087};\\\", \\\"{x:1591,y:940,t:1526328480104};\\\", \\\"{x:1583,y:933,t:1526328480119};\\\", \\\"{x:1574,y:928,t:1526328480136};\\\", \\\"{x:1568,y:924,t:1526328480154};\\\", \\\"{x:1568,y:923,t:1526328480170};\\\", \\\"{x:1567,y:922,t:1526328480187};\\\", \\\"{x:1566,y:919,t:1526328480204};\\\", \\\"{x:1563,y:915,t:1526328480219};\\\", \\\"{x:1561,y:912,t:1526328480237};\\\", \\\"{x:1559,y:909,t:1526328480254};\\\", \\\"{x:1558,y:904,t:1526328480270};\\\", \\\"{x:1553,y:888,t:1526328480287};\\\", \\\"{x:1547,y:879,t:1526328480303};\\\", \\\"{x:1545,y:874,t:1526328480320};\\\", \\\"{x:1538,y:864,t:1526328480337};\\\", \\\"{x:1536,y:858,t:1526328480353};\\\", \\\"{x:1531,y:849,t:1526328480371};\\\", \\\"{x:1520,y:830,t:1526328480387};\\\", \\\"{x:1511,y:813,t:1526328480403};\\\", \\\"{x:1507,y:803,t:1526328480420};\\\", \\\"{x:1506,y:798,t:1526328480436};\\\", \\\"{x:1503,y:792,t:1526328480454};\\\", \\\"{x:1498,y:782,t:1526328480471};\\\", \\\"{x:1492,y:770,t:1526328480486};\\\", \\\"{x:1488,y:758,t:1526328480503};\\\", \\\"{x:1482,y:746,t:1526328480521};\\\", \\\"{x:1479,y:739,t:1526328480537};\\\", \\\"{x:1475,y:731,t:1526328480554};\\\", \\\"{x:1473,y:723,t:1526328480570};\\\", \\\"{x:1469,y:716,t:1526328480588};\\\", \\\"{x:1463,y:703,t:1526328480604};\\\", \\\"{x:1455,y:685,t:1526328480621};\\\", \\\"{x:1444,y:668,t:1526328480637};\\\", \\\"{x:1433,y:648,t:1526328480654};\\\", \\\"{x:1421,y:625,t:1526328480670};\\\", \\\"{x:1409,y:605,t:1526328480688};\\\", \\\"{x:1400,y:587,t:1526328480704};\\\", \\\"{x:1398,y:577,t:1526328480721};\\\", \\\"{x:1393,y:561,t:1526328480737};\\\", \\\"{x:1389,y:547,t:1526328480754};\\\", \\\"{x:1388,y:538,t:1526328480771};\\\", \\\"{x:1388,y:531,t:1526328480788};\\\", \\\"{x:1388,y:527,t:1526328480804};\\\", \\\"{x:1388,y:523,t:1526328480821};\\\", \\\"{x:1388,y:519,t:1526328480837};\\\", \\\"{x:1386,y:515,t:1526328480855};\\\", \\\"{x:1385,y:511,t:1526328480871};\\\", \\\"{x:1385,y:509,t:1526328480888};\\\", \\\"{x:1385,y:508,t:1526328480905};\\\", \\\"{x:1385,y:507,t:1526328480921};\\\", \\\"{x:1385,y:506,t:1526328480938};\\\", \\\"{x:1385,y:505,t:1526328480955};\\\", \\\"{x:1384,y:505,t:1526328480970};\\\", \\\"{x:1384,y:502,t:1526328480988};\\\", \\\"{x:1384,y:500,t:1526328481005};\\\", \\\"{x:1384,y:499,t:1526328481020};\\\", \\\"{x:1382,y:495,t:1526328481038};\\\", \\\"{x:1381,y:493,t:1526328481055};\\\", \\\"{x:1380,y:487,t:1526328481071};\\\", \\\"{x:1378,y:482,t:1526328481088};\\\", \\\"{x:1376,y:476,t:1526328481105};\\\", \\\"{x:1373,y:469,t:1526328481122};\\\", \\\"{x:1370,y:463,t:1526328481137};\\\", \\\"{x:1368,y:459,t:1526328481154};\\\", \\\"{x:1365,y:454,t:1526328481171};\\\", \\\"{x:1362,y:450,t:1526328481188};\\\", \\\"{x:1358,y:445,t:1526328481205};\\\", \\\"{x:1356,y:441,t:1526328481222};\\\", \\\"{x:1354,y:438,t:1526328481238};\\\", \\\"{x:1353,y:433,t:1526328481255};\\\", \\\"{x:1351,y:430,t:1526328481272};\\\", \\\"{x:1351,y:428,t:1526328481288};\\\", \\\"{x:1350,y:427,t:1526328481305};\\\", \\\"{x:1349,y:425,t:1526328481321};\\\", \\\"{x:1349,y:424,t:1526328481361};\\\", \\\"{x:1348,y:423,t:1526328481371};\\\", \\\"{x:1348,y:422,t:1526328481418};\\\", \\\"{x:1347,y:422,t:1526328481649};\\\", \\\"{x:1336,y:430,t:1526328481994};\\\", \\\"{x:1310,y:453,t:1526328482005};\\\", \\\"{x:1253,y:482,t:1526328482022};\\\", \\\"{x:1161,y:511,t:1526328482039};\\\", \\\"{x:1049,y:536,t:1526328482056};\\\", \\\"{x:930,y:552,t:1526328482073};\\\", \\\"{x:815,y:558,t:1526328482088};\\\", \\\"{x:630,y:573,t:1526328482106};\\\", \\\"{x:569,y:575,t:1526328482116};\\\", \\\"{x:422,y:594,t:1526328482133};\\\", \\\"{x:265,y:616,t:1526328482150};\\\", \\\"{x:79,y:645,t:1526328482169};\\\", \\\"{x:0,y:674,t:1526328482186};\\\", \\\"{x:0,y:670,t:1526328482201};\\\", \\\"{x:0,y:666,t:1526328482218};\\\", \\\"{x:0,y:665,t:1526328482235};\\\", \\\"{x:0,y:664,t:1526328482258};\\\", \\\"{x:1,y:664,t:1526328482314};\\\", \\\"{x:2,y:666,t:1526328482337};\\\", \\\"{x:5,y:672,t:1526328482353};\\\", \\\"{x:7,y:675,t:1526328482369};\\\", \\\"{x:9,y:677,t:1526328482385};\\\", \\\"{x:11,y:679,t:1526328482402};\\\", \\\"{x:15,y:680,t:1526328482419};\\\", \\\"{x:20,y:680,t:1526328482435};\\\", \\\"{x:32,y:680,t:1526328482452};\\\", \\\"{x:51,y:680,t:1526328482468};\\\", \\\"{x:74,y:680,t:1526328482485};\\\", \\\"{x:95,y:678,t:1526328482501};\\\", \\\"{x:116,y:675,t:1526328482519};\\\", \\\"{x:136,y:673,t:1526328482536};\\\", \\\"{x:157,y:670,t:1526328482552};\\\", \\\"{x:181,y:662,t:1526328482568};\\\", \\\"{x:208,y:648,t:1526328482586};\\\", \\\"{x:225,y:637,t:1526328482602};\\\", \\\"{x:246,y:628,t:1526328482618};\\\", \\\"{x:275,y:626,t:1526328482636};\\\", \\\"{x:302,y:626,t:1526328482653};\\\", \\\"{x:328,y:629,t:1526328482669};\\\", \\\"{x:360,y:641,t:1526328482685};\\\", \\\"{x:401,y:665,t:1526328482703};\\\", \\\"{x:449,y:698,t:1526328482720};\\\", \\\"{x:503,y:727,t:1526328482736};\\\", \\\"{x:533,y:739,t:1526328482753};\\\", \\\"{x:561,y:745,t:1526328482769};\\\", \\\"{x:578,y:749,t:1526328482786};\\\", \\\"{x:586,y:752,t:1526328482802};\\\", \\\"{x:589,y:754,t:1526328482820};\\\", \\\"{x:592,y:756,t:1526328482835};\\\", \\\"{x:594,y:757,t:1526328482852};\\\", \\\"{x:596,y:760,t:1526328482870};\\\", \\\"{x:599,y:760,t:1526328482885};\\\", \\\"{x:601,y:761,t:1526328482902};\\\", \\\"{x:603,y:762,t:1526328482920};\\\", \\\"{x:604,y:762,t:1526328482937};\\\", \\\"{x:606,y:762,t:1526328482953};\\\", \\\"{x:607,y:758,t:1526328482969};\\\", \\\"{x:607,y:746,t:1526328482986};\\\", \\\"{x:607,y:731,t:1526328483003};\\\", \\\"{x:607,y:714,t:1526328483020};\\\", \\\"{x:607,y:693,t:1526328483036};\\\", \\\"{x:599,y:670,t:1526328483053};\\\", \\\"{x:593,y:649,t:1526328483071};\\\", \\\"{x:589,y:633,t:1526328483086};\\\", \\\"{x:586,y:618,t:1526328483103};\\\", \\\"{x:582,y:607,t:1526328483121};\\\", \\\"{x:577,y:597,t:1526328483137};\\\", \\\"{x:559,y:581,t:1526328483153};\\\", \\\"{x:506,y:562,t:1526328483172};\\\", \\\"{x:484,y:561,t:1526328483187};\\\", \\\"{x:466,y:561,t:1526328483202};\\\", \\\"{x:456,y:564,t:1526328483220};\\\", \\\"{x:452,y:567,t:1526328483237};\\\", \\\"{x:454,y:570,t:1526328483252};\\\", \\\"{x:466,y:576,t:1526328483270};\\\", \\\"{x:483,y:583,t:1526328483286};\\\", \\\"{x:501,y:586,t:1526328483304};\\\", \\\"{x:520,y:586,t:1526328483320};\\\", \\\"{x:539,y:586,t:1526328483337};\\\", \\\"{x:555,y:584,t:1526328483353};\\\", \\\"{x:567,y:579,t:1526328483370};\\\", \\\"{x:573,y:575,t:1526328483387};\\\", \\\"{x:574,y:568,t:1526328483403};\\\", \\\"{x:574,y:562,t:1526328483420};\\\", \\\"{x:578,y:555,t:1526328483437};\\\", \\\"{x:579,y:552,t:1526328483452};\\\", \\\"{x:580,y:550,t:1526328483469};\\\", \\\"{x:581,y:549,t:1526328483487};\\\", \\\"{x:581,y:548,t:1526328483601};\\\", \\\"{x:582,y:548,t:1526328483609};\\\", \\\"{x:583,y:548,t:1526328483620};\\\", \\\"{x:586,y:548,t:1526328483637};\\\", \\\"{x:588,y:549,t:1526328483654};\\\", \\\"{x:593,y:550,t:1526328483670};\\\", \\\"{x:595,y:550,t:1526328483687};\\\", \\\"{x:598,y:550,t:1526328483704};\\\", \\\"{x:599,y:550,t:1526328483720};\\\", \\\"{x:600,y:550,t:1526328483736};\\\", \\\"{x:602,y:550,t:1526328483754};\\\", \\\"{x:604,y:550,t:1526328483771};\\\", \\\"{x:605,y:550,t:1526328483786};\\\", \\\"{x:606,y:550,t:1526328483804};\\\", \\\"{x:605,y:551,t:1526328484121};\\\", \\\"{x:604,y:552,t:1526328484137};\\\", \\\"{x:600,y:558,t:1526328484153};\\\", \\\"{x:597,y:561,t:1526328484171};\\\", \\\"{x:597,y:563,t:1526328484187};\\\", \\\"{x:597,y:564,t:1526328484203};\\\", \\\"{x:597,y:566,t:1526328484221};\\\", \\\"{x:597,y:567,t:1526328484237};\\\", \\\"{x:597,y:570,t:1526328484254};\\\", \\\"{x:597,y:573,t:1526328484271};\\\", \\\"{x:601,y:583,t:1526328484288};\\\", \\\"{x:608,y:596,t:1526328484304};\\\", \\\"{x:620,y:619,t:1526328484321};\\\", \\\"{x:648,y:665,t:1526328484337};\\\", \\\"{x:694,y:774,t:1526328484354};\\\", \\\"{x:723,y:864,t:1526328484371};\\\", \\\"{x:740,y:959,t:1526328484387};\\\", \\\"{x:746,y:1043,t:1526328484403};\\\", \\\"{x:746,y:1105,t:1526328484421};\\\", \\\"{x:746,y:1139,t:1526328484437};\\\", \\\"{x:746,y:1164,t:1526328484454};\\\", \\\"{x:739,y:1187,t:1526328484470};\\\", \\\"{x:729,y:1199,t:1526328484487};\\\", \\\"{x:711,y:1199,t:1526328484503};\\\", \\\"{x:678,y:1199,t:1526328484519};\\\", \\\"{x:624,y:1199,t:1526328484536};\\\", \\\"{x:558,y:1199,t:1526328484553};\\\", \\\"{x:537,y:1199,t:1526328484570};\\\", \\\"{x:518,y:1199,t:1526328484587};\\\", \\\"{x:493,y:1199,t:1526328484604};\\\", \\\"{x:464,y:1189,t:1526328484620};\\\", \\\"{x:433,y:1167,t:1526328484637};\\\", \\\"{x:407,y:1132,t:1526328484652};\\\", \\\"{x:383,y:1067,t:1526328484671};\\\", \\\"{x:365,y:993,t:1526328484688};\\\", \\\"{x:347,y:924,t:1526328484704};\\\", \\\"{x:342,y:863,t:1526328484721};\\\", \\\"{x:347,y:794,t:1526328484737};\\\", \\\"{x:361,y:756,t:1526328484754};\\\", \\\"{x:374,y:731,t:1526328484771};\\\", \\\"{x:379,y:714,t:1526328484788};\\\", \\\"{x:388,y:702,t:1526328484804};\\\", \\\"{x:390,y:697,t:1526328484820};\\\", \\\"{x:393,y:693,t:1526328484838};\\\", \\\"{x:396,y:690,t:1526328484855};\\\", \\\"{x:399,y:687,t:1526328484870};\\\", \\\"{x:402,y:685,t:1526328484888};\\\", \\\"{x:406,y:682,t:1526328484904};\\\", \\\"{x:409,y:682,t:1526328484921};\\\", \\\"{x:429,y:682,t:1526328484937};\\\", \\\"{x:485,y:682,t:1526328484955};\\\", \\\"{x:579,y:706,t:1526328484971};\\\", \\\"{x:705,y:736,t:1526328484988};\\\", \\\"{x:873,y:783,t:1526328485005};\\\", \\\"{x:1079,y:855,t:1526328485021};\\\", \\\"{x:1290,y:930,t:1526328485038};\\\", \\\"{x:1490,y:1004,t:1526328485055};\\\", \\\"{x:1677,y:1081,t:1526328485071};\\\", \\\"{x:1830,y:1136,t:1526328485088};\\\", \\\"{x:1919,y:1166,t:1526328485105};\\\", \\\"{x:1919,y:1172,t:1526328485121};\\\", \\\"{x:1919,y:1171,t:1526328485146};\\\", \\\"{x:1909,y:1163,t:1526328485154};\\\", \\\"{x:1854,y:1129,t:1526328485171};\\\", \\\"{x:1786,y:1092,t:1526328485188};\\\", \\\"{x:1738,y:1068,t:1526328485205};\\\", \\\"{x:1709,y:1052,t:1526328485221};\\\", \\\"{x:1686,y:1038,t:1526328485238};\\\", \\\"{x:1669,y:1026,t:1526328485255};\\\", \\\"{x:1650,y:1016,t:1526328485270};\\\", \\\"{x:1639,y:1001,t:1526328485288};\\\", \\\"{x:1629,y:988,t:1526328485305};\\\", \\\"{x:1625,y:981,t:1526328485321};\\\", \\\"{x:1621,y:973,t:1526328485338};\\\", \\\"{x:1618,y:969,t:1526328485355};\\\", \\\"{x:1616,y:965,t:1526328485371};\\\", \\\"{x:1616,y:963,t:1526328485387};\\\", \\\"{x:1616,y:962,t:1526328485490};\\\", \\\"{x:1616,y:961,t:1526328485505};\\\", \\\"{x:1615,y:954,t:1526328485522};\\\", \\\"{x:1614,y:951,t:1526328485538};\\\", \\\"{x:1612,y:947,t:1526328485556};\\\", \\\"{x:1611,y:946,t:1526328485572};\\\", \\\"{x:1610,y:946,t:1526328485588};\\\", \\\"{x:1607,y:948,t:1526328485605};\\\", \\\"{x:1605,y:961,t:1526328485622};\\\", \\\"{x:1600,y:973,t:1526328485638};\\\", \\\"{x:1595,y:990,t:1526328485655};\\\", \\\"{x:1595,y:1004,t:1526328485673};\\\", \\\"{x:1595,y:1013,t:1526328485688};\\\", \\\"{x:1595,y:1012,t:1526328485723};\\\", \\\"{x:1600,y:998,t:1526328485739};\\\", \\\"{x:1604,y:994,t:1526328485756};\\\", \\\"{x:1607,y:989,t:1526328485773};\\\", \\\"{x:1609,y:987,t:1526328485789};\\\", \\\"{x:1613,y:982,t:1526328485805};\\\", \\\"{x:1619,y:976,t:1526328485822};\\\", \\\"{x:1630,y:966,t:1526328485838};\\\", \\\"{x:1637,y:960,t:1526328485855};\\\", \\\"{x:1638,y:945,t:1526328485873};\\\", \\\"{x:1629,y:930,t:1526328485890};\\\", \\\"{x:1621,y:924,t:1526328485906};\\\", \\\"{x:1618,y:923,t:1526328485922};\\\", \\\"{x:1617,y:926,t:1526328486009};\\\", \\\"{x:1617,y:928,t:1526328486022};\\\", \\\"{x:1615,y:932,t:1526328486039};\\\", \\\"{x:1615,y:933,t:1526328486297};\\\", \\\"{x:1614,y:935,t:1526328486305};\\\", \\\"{x:1612,y:940,t:1526328486322};\\\", \\\"{x:1609,y:947,t:1526328486339};\\\", \\\"{x:1605,y:956,t:1526328486355};\\\", \\\"{x:1599,y:969,t:1526328486372};\\\", \\\"{x:1598,y:974,t:1526328486389};\\\", \\\"{x:1598,y:975,t:1526328486409};\\\", \\\"{x:1601,y:974,t:1526328486433};\\\", \\\"{x:1603,y:971,t:1526328486449};\\\", \\\"{x:1604,y:968,t:1526328486457};\\\", \\\"{x:1605,y:968,t:1526328486472};\\\", \\\"{x:1605,y:965,t:1526328486489};\\\", \\\"{x:1605,y:963,t:1526328486506};\\\", \\\"{x:1605,y:961,t:1526328486522};\\\", \\\"{x:1604,y:960,t:1526328486539};\\\", \\\"{x:1604,y:959,t:1526328486649};\\\", \\\"{x:1603,y:959,t:1526328486674};\\\", \\\"{x:1601,y:959,t:1526328486817};\\\", \\\"{x:1600,y:958,t:1526328486826};\\\", \\\"{x:1599,y:958,t:1526328486838};\\\", \\\"{x:1597,y:958,t:1526328486856};\\\", \\\"{x:1596,y:958,t:1526328486881};\\\", \\\"{x:1595,y:958,t:1526328486905};\\\", \\\"{x:1594,y:958,t:1526328487227};\\\", \\\"{x:1595,y:958,t:1526328487786};\\\", \\\"{x:1599,y:958,t:1526328487794};\\\", \\\"{x:1603,y:959,t:1526328487807};\\\", \\\"{x:1614,y:963,t:1526328487823};\\\", \\\"{x:1627,y:969,t:1526328487840};\\\", \\\"{x:1639,y:973,t:1526328487857};\\\", \\\"{x:1648,y:976,t:1526328487873};\\\", \\\"{x:1649,y:977,t:1526328487890};\\\", \\\"{x:1650,y:977,t:1526328487977};\\\", \\\"{x:1650,y:978,t:1526328487990};\\\", \\\"{x:1648,y:977,t:1526328488074};\\\", \\\"{x:1634,y:970,t:1526328488091};\\\", \\\"{x:1622,y:966,t:1526328488107};\\\", \\\"{x:1614,y:961,t:1526328488124};\\\", \\\"{x:1608,y:959,t:1526328488140};\\\", \\\"{x:1606,y:958,t:1526328488195};\\\", \\\"{x:1605,y:956,t:1526328488208};\\\", \\\"{x:1599,y:948,t:1526328488224};\\\", \\\"{x:1594,y:932,t:1526328488240};\\\", \\\"{x:1583,y:918,t:1526328488258};\\\", \\\"{x:1575,y:890,t:1526328488274};\\\", \\\"{x:1572,y:888,t:1526328488290};\\\", \\\"{x:1570,y:888,t:1526328488308};\\\", \\\"{x:1568,y:888,t:1526328488362};\\\", \\\"{x:1566,y:885,t:1526328488433};\\\", \\\"{x:1558,y:882,t:1526328488441};\\\", \\\"{x:1557,y:882,t:1526328488457};\\\", \\\"{x:1554,y:880,t:1526328488474};\\\", \\\"{x:1554,y:878,t:1526328488491};\\\", \\\"{x:1554,y:870,t:1526328488507};\\\", \\\"{x:1552,y:860,t:1526328488524};\\\", \\\"{x:1551,y:850,t:1526328488541};\\\", \\\"{x:1549,y:843,t:1526328488557};\\\", \\\"{x:1547,y:839,t:1526328488574};\\\", \\\"{x:1545,y:837,t:1526328488591};\\\", \\\"{x:1544,y:834,t:1526328488607};\\\", \\\"{x:1543,y:834,t:1526328488738};\\\", \\\"{x:1542,y:844,t:1526328488745};\\\", \\\"{x:1540,y:864,t:1526328488757};\\\", \\\"{x:1528,y:929,t:1526328488774};\\\", \\\"{x:1512,y:994,t:1526328488791};\\\", \\\"{x:1502,y:1023,t:1526328488807};\\\", \\\"{x:1500,y:1032,t:1526328488825};\\\", \\\"{x:1491,y:1049,t:1526328488842};\\\", \\\"{x:1462,y:1062,t:1526328488858};\\\", \\\"{x:1404,y:1059,t:1526328488874};\\\", \\\"{x:1279,y:1041,t:1526328488891};\\\", \\\"{x:1173,y:1027,t:1526328488908};\\\", \\\"{x:1122,y:1008,t:1526328488924};\\\", \\\"{x:962,y:956,t:1526328488941};\\\", \\\"{x:768,y:892,t:1526328488958};\\\", \\\"{x:620,y:834,t:1526328488974};\\\", \\\"{x:519,y:798,t:1526328488991};\\\", \\\"{x:502,y:795,t:1526328489008};\\\", \\\"{x:501,y:795,t:1526328489033};\\\", \\\"{x:500,y:795,t:1526328489065};\\\", \\\"{x:499,y:795,t:1526328489082};\\\", \\\"{x:497,y:795,t:1526328489091};\\\", \\\"{x:493,y:794,t:1526328489108};\\\", \\\"{x:485,y:787,t:1526328489124};\\\", \\\"{x:473,y:772,t:1526328489140};\\\", \\\"{x:466,y:763,t:1526328489158};\\\", \\\"{x:466,y:762,t:1526328489202};\\\", \\\"{x:467,y:759,t:1526328489210};\\\", \\\"{x:476,y:754,t:1526328489225};\\\", \\\"{x:485,y:748,t:1526328489241};\\\", \\\"{x:511,y:727,t:1526328489258};\\\", \\\"{x:529,y:713,t:1526328489274};\\\", \\\"{x:543,y:703,t:1526328489291};\\\", \\\"{x:549,y:700,t:1526328489308};\\\", \\\"{x:551,y:699,t:1526328489324};\\\", \\\"{x:553,y:700,t:1526328489681};\\\", \\\"{x:554,y:702,t:1526328489692};\\\", \\\"{x:557,y:705,t:1526328489708};\\\", \\\"{x:558,y:707,t:1526328489725};\\\", \\\"{x:559,y:709,t:1526328489741};\\\", \\\"{x:560,y:711,t:1526328489758};\\\", \\\"{x:560,y:713,t:1526328489774};\\\", \\\"{x:562,y:715,t:1526328489791};\\\", \\\"{x:566,y:716,t:1526328490233};\\\", \\\"{x:576,y:720,t:1526328490241};\\\", \\\"{x:602,y:732,t:1526328490258};\\\", \\\"{x:657,y:764,t:1526328490275};\\\", \\\"{x:759,y:831,t:1526328490292};\\\", \\\"{x:893,y:941,t:1526328490309};\\\", \\\"{x:1027,y:1075,t:1526328490325};\\\", \\\"{x:1155,y:1199,t:1526328490342};\\\", \\\"{x:1267,y:1199,t:1526328490359};\\\", \\\"{x:1344,y:1199,t:1526328490375};\\\", \\\"{x:1376,y:1199,t:1526328490392};\\\", \\\"{x:1389,y:1199,t:1526328490409};\\\", \\\"{x:1386,y:1199,t:1526328490442};\\\", \\\"{x:1381,y:1199,t:1526328490449};\\\", \\\"{x:1368,y:1199,t:1526328490459};\\\", \\\"{x:1322,y:1199,t:1526328490475};\\\", \\\"{x:1259,y:1199,t:1526328490492};\\\", \\\"{x:1186,y:1199,t:1526328490509};\\\", \\\"{x:1142,y:1199,t:1526328490525};\\\", \\\"{x:1120,y:1199,t:1526328490542};\\\", \\\"{x:1109,y:1199,t:1526328490559};\\\", \\\"{x:1084,y:1199,t:1526328490575};\\\", \\\"{x:1009,y:1199,t:1526328490591};\\\", \\\"{x:967,y:1191,t:1526328490610};\\\" ] }, { \\\"rt\\\": 29416, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 362309, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-09 AM-H -J -I -0-I -03 PM-03 PM-I -11 AM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:990,y:1037,t:1526328491374};\\\", \\\"{x:992,y:837,t:1526328491400};\\\", \\\"{x:1008,y:710,t:1526328491409};\\\", \\\"{x:1025,y:646,t:1526328491426};\\\", \\\"{x:1035,y:626,t:1526328491443};\\\", \\\"{x:1045,y:610,t:1526328491460};\\\", \\\"{x:1058,y:589,t:1526328491476};\\\", \\\"{x:1069,y:575,t:1526328491493};\\\", \\\"{x:1082,y:558,t:1526328491510};\\\", \\\"{x:1131,y:489,t:1526328491538};\\\", \\\"{x:1150,y:465,t:1526328491555};\\\", \\\"{x:1155,y:459,t:1526328491561};\\\", \\\"{x:1156,y:458,t:1526328491576};\\\", \\\"{x:1135,y:457,t:1526328492034};\\\", \\\"{x:1080,y:458,t:1526328492043};\\\", \\\"{x:936,y:475,t:1526328492060};\\\", \\\"{x:761,y:489,t:1526328492078};\\\", \\\"{x:595,y:506,t:1526328492093};\\\", \\\"{x:439,y:517,t:1526328492110};\\\", \\\"{x:333,y:519,t:1526328492127};\\\", \\\"{x:296,y:519,t:1526328492143};\\\", \\\"{x:282,y:519,t:1526328492160};\\\", \\\"{x:281,y:519,t:1526328492178};\\\", \\\"{x:283,y:519,t:1526328492273};\\\", \\\"{x:287,y:519,t:1526328492281};\\\", \\\"{x:294,y:518,t:1526328492293};\\\", \\\"{x:317,y:512,t:1526328492310};\\\", \\\"{x:349,y:504,t:1526328492328};\\\", \\\"{x:386,y:498,t:1526328492343};\\\", \\\"{x:427,y:493,t:1526328492360};\\\", \\\"{x:488,y:484,t:1526328492377};\\\", \\\"{x:512,y:482,t:1526328492393};\\\", \\\"{x:526,y:481,t:1526328492410};\\\", \\\"{x:530,y:481,t:1526328492427};\\\", \\\"{x:531,y:481,t:1526328492444};\\\", \\\"{x:530,y:481,t:1526328493713};\\\", \\\"{x:527,y:481,t:1526328493728};\\\", \\\"{x:516,y:481,t:1526328493744};\\\", \\\"{x:485,y:484,t:1526328493761};\\\", \\\"{x:454,y:488,t:1526328493778};\\\", \\\"{x:427,y:493,t:1526328493795};\\\", \\\"{x:407,y:493,t:1526328493811};\\\", \\\"{x:396,y:495,t:1526328493828};\\\", \\\"{x:394,y:495,t:1526328493844};\\\", \\\"{x:393,y:496,t:1526328493897};\\\", \\\"{x:392,y:496,t:1526328493911};\\\", \\\"{x:390,y:497,t:1526328493928};\\\", \\\"{x:387,y:498,t:1526328493945};\\\", \\\"{x:383,y:500,t:1526328493962};\\\", \\\"{x:382,y:500,t:1526328493978};\\\", \\\"{x:381,y:501,t:1526328493994};\\\", \\\"{x:381,y:502,t:1526328494169};\\\", \\\"{x:381,y:503,t:1526328494257};\\\", \\\"{x:381,y:504,t:1526328494482};\\\", \\\"{x:381,y:505,t:1526328494513};\\\", \\\"{x:381,y:506,t:1526328494585};\\\", \\\"{x:383,y:506,t:1526328494617};\\\", \\\"{x:384,y:507,t:1526328494628};\\\", \\\"{x:387,y:508,t:1526328494645};\\\", \\\"{x:395,y:508,t:1526328494662};\\\", \\\"{x:399,y:509,t:1526328494678};\\\", \\\"{x:409,y:509,t:1526328494695};\\\", \\\"{x:418,y:510,t:1526328494713};\\\", \\\"{x:427,y:510,t:1526328494728};\\\", \\\"{x:436,y:510,t:1526328494746};\\\", \\\"{x:441,y:511,t:1526328494762};\\\", \\\"{x:445,y:511,t:1526328494779};\\\", \\\"{x:449,y:511,t:1526328494795};\\\", \\\"{x:452,y:511,t:1526328494813};\\\", \\\"{x:453,y:511,t:1526328494829};\\\", \\\"{x:455,y:511,t:1526328494845};\\\", \\\"{x:456,y:511,t:1526328495665};\\\", \\\"{x:457,y:512,t:1526328495721};\\\", \\\"{x:458,y:513,t:1526328495729};\\\", \\\"{x:459,y:513,t:1526328495873};\\\", \\\"{x:460,y:514,t:1526328496233};\\\", \\\"{x:461,y:515,t:1526328496246};\\\", \\\"{x:462,y:517,t:1526328496263};\\\", \\\"{x:462,y:519,t:1526328496279};\\\", \\\"{x:463,y:522,t:1526328496297};\\\", \\\"{x:463,y:525,t:1526328496313};\\\", \\\"{x:463,y:527,t:1526328496330};\\\", \\\"{x:463,y:529,t:1526328496346};\\\", \\\"{x:463,y:530,t:1526328496363};\\\", \\\"{x:463,y:531,t:1526328496380};\\\", \\\"{x:463,y:532,t:1526328496398};\\\", \\\"{x:463,y:533,t:1526328496490};\\\", \\\"{x:463,y:535,t:1526328496506};\\\", \\\"{x:462,y:535,t:1526328496513};\\\", \\\"{x:461,y:537,t:1526328496530};\\\", \\\"{x:460,y:538,t:1526328496561};\\\", \\\"{x:460,y:540,t:1526328496897};\\\", \\\"{x:460,y:552,t:1526328496914};\\\", \\\"{x:464,y:572,t:1526328496931};\\\", \\\"{x:472,y:602,t:1526328496948};\\\", \\\"{x:493,y:649,t:1526328496965};\\\", \\\"{x:520,y:741,t:1526328496981};\\\", \\\"{x:566,y:833,t:1526328496998};\\\", \\\"{x:605,y:931,t:1526328497015};\\\", \\\"{x:614,y:941,t:1526328497030};\\\", \\\"{x:615,y:941,t:1526328497048};\\\", \\\"{x:615,y:942,t:1526328497065};\\\", \\\"{x:617,y:944,t:1526328497089};\\\", \\\"{x:620,y:949,t:1526328497098};\\\", \\\"{x:633,y:956,t:1526328497115};\\\", \\\"{x:645,y:962,t:1526328497131};\\\", \\\"{x:655,y:968,t:1526328497147};\\\", \\\"{x:657,y:969,t:1526328497165};\\\", \\\"{x:658,y:969,t:1526328497203};\\\", \\\"{x:658,y:970,t:1526328497226};\\\", \\\"{x:659,y:970,t:1526328499369};\\\", \\\"{x:660,y:970,t:1526328499409};\\\", \\\"{x:663,y:971,t:1526328499466};\\\", \\\"{x:667,y:971,t:1526328499482};\\\", \\\"{x:681,y:971,t:1526328499499};\\\", \\\"{x:710,y:971,t:1526328499516};\\\", \\\"{x:743,y:971,t:1526328499533};\\\", \\\"{x:788,y:971,t:1526328499550};\\\", \\\"{x:847,y:971,t:1526328499566};\\\", \\\"{x:930,y:971,t:1526328499582};\\\", \\\"{x:1030,y:971,t:1526328499600};\\\", \\\"{x:1134,y:981,t:1526328499616};\\\", \\\"{x:1321,y:1002,t:1526328499634};\\\", \\\"{x:1467,y:1023,t:1526328499649};\\\", \\\"{x:1598,y:1042,t:1526328499667};\\\", \\\"{x:1720,y:1061,t:1526328499683};\\\", \\\"{x:1829,y:1081,t:1526328499699};\\\", \\\"{x:1917,y:1092,t:1526328499717};\\\", \\\"{x:1919,y:1102,t:1526328499733};\\\", \\\"{x:1919,y:1107,t:1526328499749};\\\", \\\"{x:1919,y:1108,t:1526328499766};\\\", \\\"{x:1919,y:1111,t:1526328499784};\\\", \\\"{x:1919,y:1112,t:1526328499841};\\\", \\\"{x:1919,y:1110,t:1526328500097};\\\", \\\"{x:1919,y:1109,t:1526328500105};\\\", \\\"{x:1919,y:1107,t:1526328500116};\\\", \\\"{x:1919,y:1102,t:1526328500133};\\\", \\\"{x:1919,y:1090,t:1526328500150};\\\", \\\"{x:1919,y:1072,t:1526328500168};\\\", \\\"{x:1913,y:1052,t:1526328500183};\\\", \\\"{x:1890,y:1015,t:1526328500201};\\\", \\\"{x:1828,y:965,t:1526328500217};\\\", \\\"{x:1754,y:937,t:1526328500233};\\\", \\\"{x:1658,y:899,t:1526328500250};\\\", \\\"{x:1536,y:866,t:1526328500266};\\\", \\\"{x:1410,y:839,t:1526328500283};\\\", \\\"{x:1293,y:816,t:1526328500300};\\\", \\\"{x:1182,y:802,t:1526328500316};\\\", \\\"{x:1099,y:789,t:1526328500333};\\\", \\\"{x:1040,y:781,t:1526328500349};\\\", \\\"{x:1009,y:780,t:1526328500366};\\\", \\\"{x:997,y:780,t:1526328500383};\\\", \\\"{x:993,y:780,t:1526328500401};\\\", \\\"{x:993,y:782,t:1526328500433};\\\", \\\"{x:993,y:783,t:1526328500450};\\\", \\\"{x:993,y:786,t:1526328500466};\\\", \\\"{x:992,y:787,t:1526328500483};\\\", \\\"{x:991,y:788,t:1526328500500};\\\", \\\"{x:991,y:791,t:1526328500517};\\\", \\\"{x:991,y:796,t:1526328500533};\\\", \\\"{x:995,y:803,t:1526328500551};\\\", \\\"{x:996,y:808,t:1526328500566};\\\", \\\"{x:999,y:816,t:1526328500583};\\\", \\\"{x:1002,y:826,t:1526328500600};\\\", \\\"{x:1006,y:839,t:1526328500616};\\\", \\\"{x:1011,y:857,t:1526328500634};\\\", \\\"{x:1015,y:868,t:1526328500650};\\\", \\\"{x:1016,y:878,t:1526328500666};\\\", \\\"{x:1018,y:888,t:1526328500684};\\\", \\\"{x:1018,y:898,t:1526328500701};\\\", \\\"{x:1018,y:913,t:1526328500717};\\\", \\\"{x:1017,y:929,t:1526328500733};\\\", \\\"{x:1015,y:947,t:1526328500751};\\\", \\\"{x:1012,y:961,t:1526328500767};\\\", \\\"{x:1011,y:976,t:1526328500784};\\\", \\\"{x:1011,y:990,t:1526328500800};\\\", \\\"{x:1011,y:1000,t:1526328500816};\\\", \\\"{x:1011,y:1009,t:1526328500834};\\\", \\\"{x:1011,y:1014,t:1526328500850};\\\", \\\"{x:1010,y:1019,t:1526328500867};\\\", \\\"{x:1010,y:1024,t:1526328500884};\\\", \\\"{x:1009,y:1026,t:1526328500901};\\\", \\\"{x:1008,y:1030,t:1526328500916};\\\", \\\"{x:1008,y:1033,t:1526328500934};\\\", \\\"{x:1008,y:1038,t:1526328500951};\\\", \\\"{x:1009,y:1043,t:1526328500968};\\\", \\\"{x:1009,y:1047,t:1526328500983};\\\", \\\"{x:1010,y:1050,t:1526328501001};\\\", \\\"{x:1010,y:1053,t:1526328501018};\\\", \\\"{x:1011,y:1055,t:1526328501042};\\\", \\\"{x:1012,y:1057,t:1526328501058};\\\", \\\"{x:1013,y:1058,t:1526328501074};\\\", \\\"{x:1013,y:1059,t:1526328501084};\\\", \\\"{x:1013,y:1060,t:1526328501101};\\\", \\\"{x:1013,y:1062,t:1526328501117};\\\", \\\"{x:1014,y:1063,t:1526328501133};\\\", \\\"{x:1014,y:1064,t:1526328501151};\\\", \\\"{x:1015,y:1066,t:1526328501167};\\\", \\\"{x:1016,y:1067,t:1526328501193};\\\", \\\"{x:1017,y:1067,t:1526328501218};\\\", \\\"{x:1017,y:1068,t:1526328501234};\\\", \\\"{x:1018,y:1069,t:1526328501282};\\\", \\\"{x:1019,y:1070,t:1526328501297};\\\", \\\"{x:1022,y:1070,t:1526328501305};\\\", \\\"{x:1026,y:1070,t:1526328501318};\\\", \\\"{x:1037,y:1070,t:1526328501333};\\\", \\\"{x:1058,y:1066,t:1526328501350};\\\", \\\"{x:1080,y:1055,t:1526328501367};\\\", \\\"{x:1107,y:1032,t:1526328501385};\\\", \\\"{x:1138,y:985,t:1526328501401};\\\", \\\"{x:1176,y:898,t:1526328501417};\\\", \\\"{x:1184,y:839,t:1526328501434};\\\", \\\"{x:1184,y:783,t:1526328501451};\\\", \\\"{x:1167,y:749,t:1526328501468};\\\", \\\"{x:1138,y:713,t:1526328501484};\\\", \\\"{x:1114,y:694,t:1526328501500};\\\", \\\"{x:1097,y:677,t:1526328501517};\\\", \\\"{x:1078,y:667,t:1526328501534};\\\", \\\"{x:1068,y:661,t:1526328501550};\\\", \\\"{x:1060,y:656,t:1526328501568};\\\", \\\"{x:1049,y:652,t:1526328501584};\\\", \\\"{x:1032,y:644,t:1526328501600};\\\", \\\"{x:992,y:626,t:1526328501617};\\\", \\\"{x:948,y:608,t:1526328501635};\\\", \\\"{x:905,y:593,t:1526328501651};\\\", \\\"{x:850,y:580,t:1526328501668};\\\", \\\"{x:772,y:567,t:1526328501685};\\\", \\\"{x:673,y:548,t:1526328501701};\\\", \\\"{x:549,y:531,t:1526328501717};\\\", \\\"{x:400,y:514,t:1526328501735};\\\", \\\"{x:259,y:497,t:1526328501751};\\\", \\\"{x:141,y:486,t:1526328501768};\\\", \\\"{x:39,y:475,t:1526328501785};\\\", \\\"{x:0,y:460,t:1526328501801};\\\", \\\"{x:0,y:459,t:1526328501825};\\\", \\\"{x:0,y:458,t:1526328501897};\\\", \\\"{x:1,y:457,t:1526328501905};\\\", \\\"{x:6,y:456,t:1526328501917};\\\", \\\"{x:22,y:453,t:1526328501935};\\\", \\\"{x:41,y:453,t:1526328501951};\\\", \\\"{x:65,y:453,t:1526328501969};\\\", \\\"{x:99,y:453,t:1526328501985};\\\", \\\"{x:160,y:463,t:1526328502001};\\\", \\\"{x:191,y:471,t:1526328502019};\\\", \\\"{x:207,y:477,t:1526328502034};\\\", \\\"{x:209,y:477,t:1526328502052};\\\", \\\"{x:211,y:477,t:1526328502721};\\\", \\\"{x:221,y:481,t:1526328502735};\\\", \\\"{x:281,y:498,t:1526328502752};\\\", \\\"{x:454,y:542,t:1526328502770};\\\", \\\"{x:596,y:563,t:1526328502786};\\\", \\\"{x:742,y:582,t:1526328502803};\\\", \\\"{x:857,y:588,t:1526328502818};\\\", \\\"{x:935,y:588,t:1526328502835};\\\", \\\"{x:976,y:588,t:1526328502852};\\\", \\\"{x:981,y:588,t:1526328502868};\\\", \\\"{x:982,y:588,t:1526328502897};\\\", \\\"{x:979,y:586,t:1526328502905};\\\", \\\"{x:975,y:582,t:1526328502918};\\\", \\\"{x:966,y:577,t:1526328502935};\\\", \\\"{x:957,y:572,t:1526328502951};\\\", \\\"{x:946,y:568,t:1526328502968};\\\", \\\"{x:926,y:558,t:1526328502985};\\\", \\\"{x:907,y:553,t:1526328503003};\\\", \\\"{x:892,y:550,t:1526328503019};\\\", \\\"{x:877,y:542,t:1526328503035};\\\", \\\"{x:867,y:541,t:1526328503052};\\\", \\\"{x:863,y:540,t:1526328503068};\\\", \\\"{x:862,y:538,t:1526328503086};\\\", \\\"{x:863,y:538,t:1526328503177};\\\", \\\"{x:867,y:538,t:1526328503185};\\\", \\\"{x:882,y:538,t:1526328503203};\\\", \\\"{x:907,y:540,t:1526328503218};\\\", \\\"{x:934,y:540,t:1526328503236};\\\", \\\"{x:991,y:544,t:1526328503253};\\\", \\\"{x:1100,y:546,t:1526328503269};\\\", \\\"{x:1240,y:559,t:1526328503285};\\\", \\\"{x:1417,y:559,t:1526328503303};\\\", \\\"{x:1611,y:556,t:1526328503319};\\\", \\\"{x:1840,y:556,t:1526328503335};\\\", \\\"{x:1919,y:556,t:1526328503352};\\\", \\\"{x:1919,y:557,t:1526328503433};\\\", \\\"{x:1916,y:554,t:1526328503497};\\\", \\\"{x:1905,y:552,t:1526328503505};\\\", \\\"{x:1890,y:546,t:1526328503520};\\\", \\\"{x:1828,y:526,t:1526328503536};\\\", \\\"{x:1718,y:504,t:1526328503553};\\\", \\\"{x:1542,y:473,t:1526328503569};\\\", \\\"{x:1453,y:461,t:1526328503586};\\\", \\\"{x:1392,y:453,t:1526328503603};\\\", \\\"{x:1359,y:448,t:1526328503620};\\\", \\\"{x:1348,y:448,t:1526328503636};\\\", \\\"{x:1347,y:448,t:1526328503652};\\\", \\\"{x:1349,y:451,t:1526328503761};\\\", \\\"{x:1350,y:452,t:1526328503769};\\\", \\\"{x:1361,y:456,t:1526328503785};\\\", \\\"{x:1371,y:458,t:1526328503803};\\\", \\\"{x:1382,y:460,t:1526328503819};\\\", \\\"{x:1392,y:460,t:1526328503836};\\\", \\\"{x:1401,y:460,t:1526328503852};\\\", \\\"{x:1410,y:460,t:1526328503869};\\\", \\\"{x:1418,y:460,t:1526328503885};\\\", \\\"{x:1425,y:456,t:1526328503903};\\\", \\\"{x:1428,y:455,t:1526328503920};\\\", \\\"{x:1434,y:452,t:1526328503935};\\\", \\\"{x:1442,y:447,t:1526328503953};\\\", \\\"{x:1455,y:439,t:1526328503969};\\\", \\\"{x:1461,y:435,t:1526328503986};\\\", \\\"{x:1463,y:431,t:1526328504002};\\\", \\\"{x:1463,y:430,t:1526328504020};\\\", \\\"{x:1464,y:428,t:1526328504036};\\\", \\\"{x:1464,y:427,t:1526328504057};\\\", \\\"{x:1464,y:425,t:1526328504070};\\\", \\\"{x:1461,y:425,t:1526328504086};\\\", \\\"{x:1455,y:425,t:1526328504102};\\\", \\\"{x:1450,y:425,t:1526328504119};\\\", \\\"{x:1443,y:425,t:1526328504137};\\\", \\\"{x:1435,y:425,t:1526328504152};\\\", \\\"{x:1427,y:425,t:1526328504169};\\\", \\\"{x:1419,y:425,t:1526328504186};\\\", \\\"{x:1411,y:425,t:1526328504202};\\\", \\\"{x:1396,y:425,t:1526328504219};\\\", \\\"{x:1373,y:425,t:1526328504236};\\\", \\\"{x:1350,y:425,t:1526328504253};\\\", \\\"{x:1321,y:431,t:1526328504269};\\\", \\\"{x:1296,y:438,t:1526328504286};\\\", \\\"{x:1281,y:446,t:1526328504302};\\\", \\\"{x:1278,y:455,t:1526328504319};\\\", \\\"{x:1276,y:462,t:1526328504336};\\\", \\\"{x:1284,y:483,t:1526328504352};\\\", \\\"{x:1289,y:495,t:1526328504369};\\\", \\\"{x:1292,y:499,t:1526328504386};\\\", \\\"{x:1295,y:500,t:1526328504402};\\\", \\\"{x:1298,y:500,t:1526328504419};\\\", \\\"{x:1299,y:501,t:1526328504436};\\\", \\\"{x:1301,y:501,t:1526328504452};\\\", \\\"{x:1302,y:503,t:1526328504481};\\\", \\\"{x:1303,y:503,t:1526328504489};\\\", \\\"{x:1304,y:504,t:1526328504503};\\\", \\\"{x:1308,y:504,t:1526328504520};\\\", \\\"{x:1310,y:504,t:1526328504536};\\\", \\\"{x:1310,y:505,t:1526328504552};\\\", \\\"{x:1311,y:506,t:1526328504569};\\\", \\\"{x:1311,y:504,t:1526328504642};\\\", \\\"{x:1311,y:503,t:1526328504653};\\\", \\\"{x:1312,y:502,t:1526328504669};\\\", \\\"{x:1313,y:500,t:1526328504687};\\\", \\\"{x:1313,y:499,t:1526328504793};\\\", \\\"{x:1315,y:499,t:1526328504809};\\\", \\\"{x:1315,y:498,t:1526328504824};\\\", \\\"{x:1316,y:497,t:1526328504837};\\\", \\\"{x:1315,y:499,t:1526328505137};\\\", \\\"{x:1312,y:502,t:1526328505154};\\\", \\\"{x:1309,y:507,t:1526328505169};\\\", \\\"{x:1305,y:510,t:1526328505187};\\\", \\\"{x:1303,y:512,t:1526328505203};\\\", \\\"{x:1299,y:516,t:1526328505220};\\\", \\\"{x:1296,y:520,t:1526328505237};\\\", \\\"{x:1293,y:523,t:1526328505254};\\\", \\\"{x:1289,y:527,t:1526328505271};\\\", \\\"{x:1286,y:530,t:1526328505287};\\\", \\\"{x:1284,y:535,t:1526328505303};\\\", \\\"{x:1280,y:542,t:1526328505320};\\\", \\\"{x:1276,y:554,t:1526328505336};\\\", \\\"{x:1266,y:574,t:1526328505354};\\\", \\\"{x:1264,y:580,t:1526328505371};\\\", \\\"{x:1263,y:584,t:1526328505387};\\\", \\\"{x:1263,y:585,t:1526328505403};\\\", \\\"{x:1263,y:586,t:1526328505420};\\\", \\\"{x:1263,y:587,t:1526328505437};\\\", \\\"{x:1263,y:588,t:1526328505453};\\\", \\\"{x:1263,y:589,t:1526328505471};\\\", \\\"{x:1263,y:593,t:1526328505487};\\\", \\\"{x:1263,y:598,t:1526328505503};\\\", \\\"{x:1263,y:601,t:1526328505521};\\\", \\\"{x:1262,y:604,t:1526328505536};\\\", \\\"{x:1262,y:607,t:1526328505554};\\\", \\\"{x:1261,y:614,t:1526328505571};\\\", \\\"{x:1261,y:622,t:1526328505587};\\\", \\\"{x:1258,y:636,t:1526328505603};\\\", \\\"{x:1252,y:655,t:1526328505620};\\\", \\\"{x:1245,y:665,t:1526328505636};\\\", \\\"{x:1241,y:674,t:1526328505653};\\\", \\\"{x:1237,y:682,t:1526328505671};\\\", \\\"{x:1231,y:689,t:1526328505687};\\\", \\\"{x:1225,y:696,t:1526328505704};\\\", \\\"{x:1219,y:702,t:1526328505721};\\\", \\\"{x:1206,y:712,t:1526328505737};\\\", \\\"{x:1192,y:722,t:1526328505753};\\\", \\\"{x:1179,y:732,t:1526328505771};\\\", \\\"{x:1167,y:744,t:1526328505787};\\\", \\\"{x:1154,y:758,t:1526328505804};\\\", \\\"{x:1146,y:769,t:1526328505821};\\\", \\\"{x:1138,y:780,t:1526328505838};\\\", \\\"{x:1132,y:791,t:1526328505853};\\\", \\\"{x:1126,y:798,t:1526328505871};\\\", \\\"{x:1123,y:804,t:1526328505887};\\\", \\\"{x:1122,y:810,t:1526328505903};\\\", \\\"{x:1122,y:815,t:1526328505921};\\\", \\\"{x:1122,y:817,t:1526328505938};\\\", \\\"{x:1122,y:818,t:1526328505954};\\\", \\\"{x:1122,y:820,t:1526328505970};\\\", \\\"{x:1123,y:820,t:1526328506001};\\\", \\\"{x:1123,y:822,t:1526328506017};\\\", \\\"{x:1123,y:823,t:1526328506033};\\\", \\\"{x:1123,y:826,t:1526328506049};\\\", \\\"{x:1123,y:827,t:1526328506065};\\\", \\\"{x:1122,y:829,t:1526328506177};\\\", \\\"{x:1120,y:830,t:1526328506188};\\\", \\\"{x:1111,y:833,t:1526328506205};\\\", \\\"{x:1105,y:838,t:1526328506221};\\\", \\\"{x:1094,y:850,t:1526328506238};\\\", \\\"{x:1090,y:859,t:1526328506254};\\\", \\\"{x:1085,y:868,t:1526328506271};\\\", \\\"{x:1080,y:879,t:1526328506288};\\\", \\\"{x:1078,y:886,t:1526328506304};\\\", \\\"{x:1073,y:900,t:1526328506322};\\\", \\\"{x:1070,y:914,t:1526328506338};\\\", \\\"{x:1066,y:925,t:1526328506355};\\\", \\\"{x:1063,y:938,t:1526328506372};\\\", \\\"{x:1061,y:948,t:1526328506388};\\\", \\\"{x:1058,y:955,t:1526328506404};\\\", \\\"{x:1058,y:960,t:1526328506421};\\\", \\\"{x:1058,y:965,t:1526328506438};\\\", \\\"{x:1058,y:968,t:1526328506453};\\\", \\\"{x:1059,y:972,t:1526328506471};\\\", \\\"{x:1060,y:975,t:1526328506488};\\\", \\\"{x:1060,y:976,t:1526328506504};\\\", \\\"{x:1060,y:977,t:1526328506520};\\\", \\\"{x:1060,y:978,t:1526328506538};\\\", \\\"{x:1063,y:976,t:1526328506818};\\\", \\\"{x:1067,y:971,t:1526328506824};\\\", \\\"{x:1074,y:963,t:1526328506838};\\\", \\\"{x:1097,y:936,t:1526328506855};\\\", \\\"{x:1153,y:873,t:1526328506871};\\\", \\\"{x:1204,y:795,t:1526328506888};\\\", \\\"{x:1311,y:655,t:1526328506905};\\\", \\\"{x:1379,y:583,t:1526328506921};\\\", \\\"{x:1442,y:535,t:1526328506938};\\\", \\\"{x:1478,y:498,t:1526328506955};\\\", \\\"{x:1501,y:471,t:1526328506971};\\\", \\\"{x:1511,y:452,t:1526328506987};\\\", \\\"{x:1514,y:434,t:1526328507005};\\\", \\\"{x:1514,y:425,t:1526328507021};\\\", \\\"{x:1514,y:423,t:1526328507038};\\\", \\\"{x:1514,y:422,t:1526328507055};\\\", \\\"{x:1513,y:421,t:1526328507072};\\\", \\\"{x:1506,y:421,t:1526328507088};\\\", \\\"{x:1494,y:421,t:1526328507105};\\\", \\\"{x:1460,y:436,t:1526328507121};\\\", \\\"{x:1439,y:452,t:1526328507138};\\\", \\\"{x:1423,y:458,t:1526328507155};\\\", \\\"{x:1409,y:466,t:1526328507172};\\\", \\\"{x:1406,y:468,t:1526328507188};\\\", \\\"{x:1405,y:468,t:1526328507204};\\\", \\\"{x:1403,y:466,t:1526328507258};\\\", \\\"{x:1401,y:464,t:1526328507271};\\\", \\\"{x:1398,y:461,t:1526328507288};\\\", \\\"{x:1397,y:458,t:1526328507305};\\\", \\\"{x:1395,y:454,t:1526328507321};\\\", \\\"{x:1395,y:453,t:1526328507338};\\\", \\\"{x:1395,y:450,t:1526328507355};\\\", \\\"{x:1392,y:449,t:1526328507372};\\\", \\\"{x:1377,y:449,t:1526328507388};\\\", \\\"{x:1343,y:449,t:1526328507405};\\\", \\\"{x:1313,y:451,t:1526328507421};\\\", \\\"{x:1285,y:460,t:1526328507437};\\\", \\\"{x:1269,y:464,t:1526328507455};\\\", \\\"{x:1260,y:468,t:1526328507472};\\\", \\\"{x:1262,y:468,t:1526328507537};\\\", \\\"{x:1263,y:469,t:1526328507561};\\\", \\\"{x:1263,y:470,t:1526328507594};\\\", \\\"{x:1263,y:472,t:1526328507605};\\\", \\\"{x:1267,y:472,t:1526328507622};\\\", \\\"{x:1284,y:473,t:1526328507639};\\\", \\\"{x:1300,y:478,t:1526328507655};\\\", \\\"{x:1312,y:480,t:1526328507672};\\\", \\\"{x:1330,y:487,t:1526328507689};\\\", \\\"{x:1335,y:489,t:1526328507705};\\\", \\\"{x:1340,y:492,t:1526328507722};\\\", \\\"{x:1341,y:492,t:1526328507739};\\\", \\\"{x:1337,y:492,t:1526328507858};\\\", \\\"{x:1334,y:491,t:1526328507871};\\\", \\\"{x:1331,y:488,t:1526328507889};\\\", \\\"{x:1328,y:487,t:1526328507905};\\\", \\\"{x:1325,y:484,t:1526328507922};\\\", \\\"{x:1321,y:482,t:1526328507939};\\\", \\\"{x:1319,y:481,t:1526328507955};\\\", \\\"{x:1317,y:481,t:1526328507971};\\\", \\\"{x:1317,y:482,t:1526328508137};\\\", \\\"{x:1317,y:484,t:1526328508145};\\\", \\\"{x:1317,y:485,t:1526328508155};\\\", \\\"{x:1320,y:492,t:1526328508172};\\\", \\\"{x:1321,y:496,t:1526328508189};\\\", \\\"{x:1325,y:502,t:1526328508205};\\\", \\\"{x:1329,y:511,t:1526328508222};\\\", \\\"{x:1333,y:519,t:1526328508239};\\\", \\\"{x:1336,y:525,t:1526328508256};\\\", \\\"{x:1338,y:530,t:1526328508272};\\\", \\\"{x:1338,y:538,t:1526328508289};\\\", \\\"{x:1340,y:546,t:1526328508305};\\\", \\\"{x:1343,y:554,t:1526328508322};\\\", \\\"{x:1343,y:555,t:1526328508339};\\\", \\\"{x:1346,y:558,t:1526328508356};\\\", \\\"{x:1348,y:560,t:1526328508372};\\\", \\\"{x:1351,y:562,t:1526328508389};\\\", \\\"{x:1351,y:564,t:1526328508405};\\\", \\\"{x:1352,y:567,t:1526328508422};\\\", \\\"{x:1355,y:570,t:1526328508439};\\\", \\\"{x:1356,y:571,t:1526328508529};\\\", \\\"{x:1356,y:572,t:1526328508538};\\\", \\\"{x:1358,y:573,t:1526328508556};\\\", \\\"{x:1359,y:579,t:1526328508572};\\\", \\\"{x:1362,y:585,t:1526328508589};\\\", \\\"{x:1364,y:590,t:1526328508606};\\\", \\\"{x:1367,y:596,t:1526328508622};\\\", \\\"{x:1371,y:603,t:1526328508639};\\\", \\\"{x:1372,y:608,t:1526328508656};\\\", \\\"{x:1376,y:617,t:1526328508671};\\\", \\\"{x:1380,y:630,t:1526328508688};\\\", \\\"{x:1384,y:642,t:1526328508705};\\\", \\\"{x:1386,y:654,t:1526328508722};\\\", \\\"{x:1392,y:668,t:1526328508739};\\\", \\\"{x:1399,y:682,t:1526328508756};\\\", \\\"{x:1408,y:698,t:1526328508772};\\\", \\\"{x:1412,y:712,t:1526328508789};\\\", \\\"{x:1418,y:729,t:1526328508806};\\\", \\\"{x:1421,y:749,t:1526328508823};\\\", \\\"{x:1423,y:764,t:1526328508839};\\\", \\\"{x:1427,y:782,t:1526328508856};\\\", \\\"{x:1435,y:820,t:1526328508873};\\\", \\\"{x:1445,y:835,t:1526328508889};\\\", \\\"{x:1460,y:853,t:1526328508906};\\\", \\\"{x:1473,y:867,t:1526328508923};\\\", \\\"{x:1487,y:878,t:1526328508939};\\\", \\\"{x:1501,y:892,t:1526328508956};\\\", \\\"{x:1509,y:905,t:1526328508973};\\\", \\\"{x:1518,y:930,t:1526328508989};\\\", \\\"{x:1525,y:953,t:1526328509006};\\\", \\\"{x:1531,y:970,t:1526328509022};\\\", \\\"{x:1536,y:982,t:1526328509039};\\\", \\\"{x:1542,y:995,t:1526328509055};\\\", \\\"{x:1551,y:1011,t:1526328509073};\\\", \\\"{x:1556,y:1019,t:1526328509089};\\\", \\\"{x:1557,y:1020,t:1526328509106};\\\", \\\"{x:1558,y:1021,t:1526328509128};\\\", \\\"{x:1559,y:1021,t:1526328509177};\\\", \\\"{x:1558,y:1011,t:1526328509729};\\\", \\\"{x:1552,y:993,t:1526328509739};\\\", \\\"{x:1543,y:964,t:1526328509756};\\\", \\\"{x:1530,y:940,t:1526328509773};\\\", \\\"{x:1513,y:915,t:1526328509790};\\\", \\\"{x:1495,y:886,t:1526328509806};\\\", \\\"{x:1485,y:870,t:1526328509823};\\\", \\\"{x:1479,y:859,t:1526328509839};\\\", \\\"{x:1476,y:855,t:1526328509857};\\\", \\\"{x:1475,y:855,t:1526328509881};\\\", \\\"{x:1475,y:853,t:1526328509913};\\\", \\\"{x:1475,y:852,t:1526328509922};\\\", \\\"{x:1475,y:848,t:1526328509940};\\\", \\\"{x:1475,y:841,t:1526328509957};\\\", \\\"{x:1475,y:835,t:1526328509973};\\\", \\\"{x:1473,y:822,t:1526328509990};\\\", \\\"{x:1461,y:795,t:1526328510007};\\\", \\\"{x:1422,y:739,t:1526328510023};\\\", \\\"{x:1365,y:656,t:1526328510040};\\\", \\\"{x:1301,y:571,t:1526328510057};\\\", \\\"{x:1283,y:550,t:1526328510073};\\\", \\\"{x:1275,y:543,t:1526328510090};\\\", \\\"{x:1270,y:538,t:1526328510106};\\\", \\\"{x:1266,y:531,t:1526328510123};\\\", \\\"{x:1263,y:526,t:1526328510140};\\\", \\\"{x:1261,y:522,t:1526328510157};\\\", \\\"{x:1259,y:518,t:1526328510172};\\\", \\\"{x:1257,y:515,t:1526328510190};\\\", \\\"{x:1254,y:501,t:1526328510207};\\\", \\\"{x:1253,y:488,t:1526328510223};\\\", \\\"{x:1253,y:484,t:1526328510240};\\\", \\\"{x:1256,y:477,t:1526328510257};\\\", \\\"{x:1260,y:473,t:1526328510273};\\\", \\\"{x:1265,y:470,t:1526328510290};\\\", \\\"{x:1274,y:466,t:1526328510307};\\\", \\\"{x:1285,y:458,t:1526328510323};\\\", \\\"{x:1292,y:454,t:1526328510340};\\\", \\\"{x:1301,y:443,t:1526328510357};\\\", \\\"{x:1305,y:439,t:1526328510373};\\\", \\\"{x:1305,y:438,t:1526328510390};\\\", \\\"{x:1305,y:440,t:1526328510441};\\\", \\\"{x:1305,y:463,t:1526328510457};\\\", \\\"{x:1309,y:493,t:1526328510473};\\\", \\\"{x:1313,y:509,t:1526328510490};\\\", \\\"{x:1313,y:512,t:1526328510507};\\\", \\\"{x:1313,y:513,t:1526328510529};\\\", \\\"{x:1313,y:514,t:1526328510561};\\\", \\\"{x:1312,y:514,t:1526328510650};\\\", \\\"{x:1312,y:513,t:1526328510658};\\\", \\\"{x:1312,y:510,t:1526328510673};\\\", \\\"{x:1313,y:508,t:1526328510690};\\\", \\\"{x:1313,y:507,t:1526328510707};\\\", \\\"{x:1314,y:507,t:1526328510881};\\\", \\\"{x:1314,y:508,t:1526328511018};\\\", \\\"{x:1314,y:510,t:1526328511026};\\\", \\\"{x:1314,y:511,t:1526328511040};\\\", \\\"{x:1317,y:517,t:1526328511057};\\\", \\\"{x:1319,y:528,t:1526328511074};\\\", \\\"{x:1324,y:541,t:1526328511090};\\\", \\\"{x:1329,y:551,t:1526328511107};\\\", \\\"{x:1331,y:554,t:1526328511124};\\\", \\\"{x:1331,y:555,t:1526328511140};\\\", \\\"{x:1332,y:555,t:1526328511185};\\\", \\\"{x:1332,y:554,t:1526328511193};\\\", \\\"{x:1332,y:550,t:1526328511207};\\\", \\\"{x:1332,y:538,t:1526328511223};\\\", \\\"{x:1328,y:508,t:1526328511241};\\\", \\\"{x:1319,y:484,t:1526328511257};\\\", \\\"{x:1318,y:482,t:1526328511274};\\\", \\\"{x:1318,y:481,t:1526328511291};\\\", \\\"{x:1318,y:480,t:1526328511307};\\\", \\\"{x:1318,y:479,t:1526328511337};\\\", \\\"{x:1318,y:478,t:1526328511400};\\\", \\\"{x:1317,y:479,t:1526328511513};\\\", \\\"{x:1317,y:482,t:1526328511523};\\\", \\\"{x:1313,y:491,t:1526328511541};\\\", \\\"{x:1309,y:498,t:1526328511557};\\\", \\\"{x:1308,y:505,t:1526328511574};\\\", \\\"{x:1306,y:514,t:1526328511591};\\\", \\\"{x:1305,y:520,t:1526328511608};\\\", \\\"{x:1305,y:524,t:1526328511624};\\\", \\\"{x:1305,y:527,t:1526328511641};\\\", \\\"{x:1306,y:527,t:1526328511657};\\\", \\\"{x:1307,y:528,t:1526328511674};\\\", \\\"{x:1308,y:529,t:1526328511713};\\\", \\\"{x:1308,y:530,t:1526328511724};\\\", \\\"{x:1308,y:533,t:1526328511741};\\\", \\\"{x:1308,y:538,t:1526328511758};\\\", \\\"{x:1308,y:543,t:1526328511774};\\\", \\\"{x:1308,y:548,t:1526328511791};\\\", \\\"{x:1308,y:553,t:1526328511808};\\\", \\\"{x:1307,y:556,t:1526328511824};\\\", \\\"{x:1305,y:564,t:1526328511841};\\\", \\\"{x:1303,y:570,t:1526328511858};\\\", \\\"{x:1301,y:575,t:1526328511874};\\\", \\\"{x:1299,y:585,t:1526328511891};\\\", \\\"{x:1296,y:594,t:1526328511908};\\\", \\\"{x:1295,y:606,t:1526328511924};\\\", \\\"{x:1295,y:616,t:1526328511941};\\\", \\\"{x:1295,y:620,t:1526328511958};\\\", \\\"{x:1296,y:629,t:1526328511974};\\\", \\\"{x:1296,y:635,t:1526328511991};\\\", \\\"{x:1296,y:642,t:1526328512008};\\\", \\\"{x:1297,y:648,t:1526328512024};\\\", \\\"{x:1297,y:658,t:1526328512041};\\\", \\\"{x:1298,y:663,t:1526328512058};\\\", \\\"{x:1298,y:668,t:1526328512074};\\\", \\\"{x:1295,y:677,t:1526328512091};\\\", \\\"{x:1290,y:698,t:1526328512108};\\\", \\\"{x:1285,y:712,t:1526328512124};\\\", \\\"{x:1283,y:724,t:1526328512141};\\\", \\\"{x:1283,y:736,t:1526328512158};\\\", \\\"{x:1283,y:746,t:1526328512174};\\\", \\\"{x:1288,y:760,t:1526328512191};\\\", \\\"{x:1291,y:770,t:1526328512208};\\\", \\\"{x:1293,y:777,t:1526328512224};\\\", \\\"{x:1296,y:783,t:1526328512241};\\\", \\\"{x:1298,y:788,t:1526328512259};\\\", \\\"{x:1299,y:791,t:1526328512275};\\\", \\\"{x:1301,y:795,t:1526328512291};\\\", \\\"{x:1301,y:798,t:1526328512309};\\\", \\\"{x:1304,y:802,t:1526328512325};\\\", \\\"{x:1308,y:809,t:1526328512342};\\\", \\\"{x:1310,y:810,t:1526328512359};\\\", \\\"{x:1310,y:813,t:1526328512375};\\\", \\\"{x:1310,y:815,t:1526328512391};\\\", \\\"{x:1310,y:816,t:1526328512408};\\\", \\\"{x:1306,y:827,t:1526328512425};\\\", \\\"{x:1303,y:835,t:1526328512440};\\\", \\\"{x:1302,y:839,t:1526328512458};\\\", \\\"{x:1299,y:848,t:1526328512475};\\\", \\\"{x:1295,y:859,t:1526328512491};\\\", \\\"{x:1293,y:865,t:1526328512508};\\\", \\\"{x:1293,y:872,t:1526328512525};\\\", \\\"{x:1293,y:884,t:1526328512541};\\\", \\\"{x:1293,y:889,t:1526328512558};\\\", \\\"{x:1293,y:893,t:1526328512575};\\\", \\\"{x:1293,y:903,t:1526328512591};\\\", \\\"{x:1293,y:905,t:1526328512608};\\\", \\\"{x:1293,y:908,t:1526328512625};\\\", \\\"{x:1293,y:910,t:1526328512641};\\\", \\\"{x:1293,y:912,t:1526328512658};\\\", \\\"{x:1293,y:918,t:1526328512675};\\\", \\\"{x:1295,y:922,t:1526328512691};\\\", \\\"{x:1297,y:925,t:1526328512709};\\\", \\\"{x:1299,y:928,t:1526328512725};\\\", \\\"{x:1300,y:929,t:1526328512742};\\\", \\\"{x:1300,y:934,t:1526328512758};\\\", \\\"{x:1300,y:936,t:1526328512774};\\\", \\\"{x:1301,y:944,t:1526328512792};\\\", \\\"{x:1301,y:947,t:1526328512808};\\\", \\\"{x:1301,y:960,t:1526328512824};\\\", \\\"{x:1301,y:963,t:1526328512843};\\\", \\\"{x:1301,y:967,t:1526328512858};\\\", \\\"{x:1301,y:972,t:1526328512875};\\\", \\\"{x:1301,y:975,t:1526328512892};\\\", \\\"{x:1301,y:977,t:1526328512907};\\\", \\\"{x:1301,y:980,t:1526328512925};\\\", \\\"{x:1301,y:982,t:1526328512941};\\\", \\\"{x:1301,y:983,t:1526328512958};\\\", \\\"{x:1301,y:984,t:1526328512975};\\\", \\\"{x:1301,y:985,t:1526328513434};\\\", \\\"{x:1301,y:986,t:1526328513449};\\\", \\\"{x:1301,y:987,t:1526328513465};\\\", \\\"{x:1300,y:987,t:1526328513601};\\\", \\\"{x:1296,y:987,t:1526328513609};\\\", \\\"{x:1288,y:987,t:1526328513625};\\\", \\\"{x:1270,y:987,t:1526328513642};\\\", \\\"{x:1234,y:983,t:1526328513659};\\\", \\\"{x:1180,y:976,t:1526328513675};\\\", \\\"{x:1139,y:970,t:1526328513692};\\\", \\\"{x:1089,y:958,t:1526328513709};\\\", \\\"{x:994,y:943,t:1526328513725};\\\", \\\"{x:913,y:930,t:1526328513742};\\\", \\\"{x:870,y:930,t:1526328513759};\\\", \\\"{x:855,y:930,t:1526328513775};\\\", \\\"{x:853,y:930,t:1526328513792};\\\", \\\"{x:854,y:929,t:1526328513873};\\\", \\\"{x:855,y:928,t:1526328513881};\\\", \\\"{x:856,y:928,t:1526328513892};\\\", \\\"{x:859,y:926,t:1526328513909};\\\", \\\"{x:860,y:925,t:1526328513925};\\\", \\\"{x:861,y:923,t:1526328513942};\\\", \\\"{x:858,y:916,t:1526328513959};\\\", \\\"{x:842,y:909,t:1526328513976};\\\", \\\"{x:831,y:904,t:1526328513992};\\\", \\\"{x:819,y:900,t:1526328514009};\\\", \\\"{x:803,y:899,t:1526328514026};\\\", \\\"{x:785,y:896,t:1526328514042};\\\", \\\"{x:763,y:894,t:1526328514059};\\\", \\\"{x:738,y:894,t:1526328514076};\\\", \\\"{x:717,y:894,t:1526328514092};\\\", \\\"{x:693,y:896,t:1526328514109};\\\", \\\"{x:664,y:905,t:1526328514126};\\\", \\\"{x:639,y:911,t:1526328514142};\\\", \\\"{x:616,y:913,t:1526328514159};\\\", \\\"{x:587,y:913,t:1526328514176};\\\", \\\"{x:560,y:916,t:1526328514192};\\\", \\\"{x:506,y:917,t:1526328514209};\\\", \\\"{x:464,y:917,t:1526328514226};\\\", \\\"{x:430,y:917,t:1526328514242};\\\", \\\"{x:398,y:917,t:1526328514259};\\\", \\\"{x:371,y:914,t:1526328514276};\\\", \\\"{x:350,y:908,t:1526328514292};\\\", \\\"{x:328,y:900,t:1526328514309};\\\", \\\"{x:309,y:893,t:1526328514326};\\\", \\\"{x:289,y:883,t:1526328514342};\\\", \\\"{x:266,y:870,t:1526328514359};\\\", \\\"{x:248,y:864,t:1526328514376};\\\", \\\"{x:232,y:859,t:1526328514392};\\\", \\\"{x:222,y:857,t:1526328514409};\\\", \\\"{x:222,y:856,t:1526328514456};\\\", \\\"{x:221,y:856,t:1526328514464};\\\", \\\"{x:220,y:856,t:1526328514489};\\\", \\\"{x:220,y:855,t:1526328514497};\\\", \\\"{x:219,y:855,t:1526328514509};\\\", \\\"{x:219,y:854,t:1526328514526};\\\", \\\"{x:212,y:837,t:1526328514542};\\\", \\\"{x:204,y:809,t:1526328514559};\\\", \\\"{x:193,y:782,t:1526328514576};\\\", \\\"{x:182,y:752,t:1526328514592};\\\", \\\"{x:175,y:732,t:1526328514609};\\\", \\\"{x:164,y:713,t:1526328514626};\\\", \\\"{x:154,y:697,t:1526328514643};\\\", \\\"{x:145,y:683,t:1526328514659};\\\", \\\"{x:129,y:669,t:1526328514676};\\\", \\\"{x:111,y:659,t:1526328514694};\\\", \\\"{x:96,y:650,t:1526328514709};\\\", \\\"{x:79,y:646,t:1526328514726};\\\", \\\"{x:55,y:642,t:1526328514745};\\\", \\\"{x:48,y:641,t:1526328514761};\\\", \\\"{x:46,y:639,t:1526328514779};\\\", \\\"{x:45,y:639,t:1526328514795};\\\", \\\"{x:44,y:639,t:1526328514873};\\\", \\\"{x:48,y:643,t:1526328514897};\\\", \\\"{x:57,y:649,t:1526328514911};\\\", \\\"{x:100,y:663,t:1526328514928};\\\", \\\"{x:246,y:684,t:1526328514945};\\\", \\\"{x:368,y:703,t:1526328514961};\\\", \\\"{x:483,y:711,t:1526328514978};\\\", \\\"{x:574,y:723,t:1526328514995};\\\", \\\"{x:618,y:724,t:1526328515012};\\\", \\\"{x:626,y:724,t:1526328515028};\\\", \\\"{x:625,y:724,t:1526328515096};\\\", \\\"{x:620,y:722,t:1526328515112};\\\", \\\"{x:600,y:710,t:1526328515128};\\\", \\\"{x:525,y:662,t:1526328515145};\\\", \\\"{x:466,y:619,t:1526328515162};\\\", \\\"{x:429,y:594,t:1526328515178};\\\", \\\"{x:409,y:581,t:1526328515195};\\\", \\\"{x:402,y:574,t:1526328515212};\\\", \\\"{x:400,y:571,t:1526328515228};\\\", \\\"{x:398,y:566,t:1526328515245};\\\", \\\"{x:397,y:559,t:1526328515262};\\\", \\\"{x:394,y:555,t:1526328515280};\\\", \\\"{x:394,y:553,t:1526328515295};\\\", \\\"{x:393,y:551,t:1526328515312};\\\", \\\"{x:393,y:549,t:1526328515513};\\\", \\\"{x:393,y:548,t:1526328515529};\\\", \\\"{x:393,y:546,t:1526328515545};\\\", \\\"{x:393,y:545,t:1526328515593};\\\", \\\"{x:393,y:543,t:1526328515625};\\\", \\\"{x:393,y:542,t:1526328516025};\\\", \\\"{x:396,y:542,t:1526328516033};\\\", \\\"{x:411,y:552,t:1526328516046};\\\", \\\"{x:459,y:585,t:1526328516062};\\\", \\\"{x:500,y:622,t:1526328516080};\\\", \\\"{x:532,y:645,t:1526328516097};\\\", \\\"{x:549,y:662,t:1526328516112};\\\", \\\"{x:569,y:693,t:1526328516129};\\\", \\\"{x:577,y:711,t:1526328516147};\\\", \\\"{x:586,y:731,t:1526328516163};\\\", \\\"{x:591,y:748,t:1526328516179};\\\", \\\"{x:597,y:763,t:1526328516196};\\\", \\\"{x:598,y:774,t:1526328516212};\\\", \\\"{x:598,y:783,t:1526328516229};\\\", \\\"{x:598,y:789,t:1526328516246};\\\", \\\"{x:598,y:792,t:1526328516262};\\\", \\\"{x:598,y:793,t:1526328516279};\\\", \\\"{x:595,y:796,t:1526328516295};\\\", \\\"{x:592,y:796,t:1526328516312};\\\", \\\"{x:585,y:797,t:1526328516328};\\\", \\\"{x:569,y:798,t:1526328516345};\\\", \\\"{x:556,y:798,t:1526328516362};\\\", \\\"{x:550,y:798,t:1526328516378};\\\", \\\"{x:547,y:798,t:1526328516395};\\\", \\\"{x:546,y:798,t:1526328516449};\\\", \\\"{x:544,y:798,t:1526328516473};\\\", \\\"{x:542,y:797,t:1526328516481};\\\", \\\"{x:541,y:795,t:1526328516496};\\\", \\\"{x:535,y:786,t:1526328516511};\\\", \\\"{x:524,y:768,t:1526328516528};\\\", \\\"{x:511,y:748,t:1526328516544};\\\", \\\"{x:497,y:728,t:1526328516561};\\\", \\\"{x:492,y:720,t:1526328516579};\\\", \\\"{x:491,y:719,t:1526328516596};\\\", \\\"{x:490,y:719,t:1526328516665};\\\", \\\"{x:489,y:719,t:1526328516680};\\\", \\\"{x:486,y:719,t:1526328516696};\\\", \\\"{x:481,y:721,t:1526328516713};\\\", \\\"{x:480,y:722,t:1526328516730};\\\", \\\"{x:479,y:722,t:1526328517425};\\\", \\\"{x:479,y:723,t:1526328517433};\\\", \\\"{x:480,y:727,t:1526328517448};\\\", \\\"{x:486,y:731,t:1526328517464};\\\", \\\"{x:488,y:733,t:1526328517482};\\\", \\\"{x:489,y:734,t:1526328517498};\\\", \\\"{x:490,y:734,t:1526328517515};\\\", \\\"{x:491,y:734,t:1526328517932};\\\", \\\"{x:492,y:734,t:1526328517940};\\\", \\\"{x:493,y:734,t:1526328517952};\\\", \\\"{x:495,y:734,t:1526328517970};\\\", \\\"{x:496,y:733,t:1526328517987};\\\", \\\"{x:497,y:733,t:1526328518004};\\\", \\\"{x:498,y:733,t:1526328518020};\\\", \\\"{x:499,y:732,t:1526328518077};\\\", \\\"{x:500,y:731,t:1526328518204};\\\", \\\"{x:505,y:731,t:1526328520036};\\\", \\\"{x:517,y:731,t:1526328520045};\\\", \\\"{x:531,y:731,t:1526328520058};\\\", \\\"{x:566,y:728,t:1526328520076};\\\", \\\"{x:597,y:722,t:1526328520092};\\\", \\\"{x:611,y:721,t:1526328520107};\\\", \\\"{x:612,y:721,t:1526328520118};\\\", \\\"{x:613,y:721,t:1526328520188};\\\", \\\"{x:612,y:723,t:1526328520203};\\\", \\\"{x:612,y:727,t:1526328520219};\\\", \\\"{x:609,y:733,t:1526328520235};\\\", \\\"{x:604,y:739,t:1526328520253};\\\", \\\"{x:599,y:744,t:1526328520269};\\\", \\\"{x:588,y:749,t:1526328520286};\\\", \\\"{x:574,y:752,t:1526328520303};\\\", \\\"{x:559,y:752,t:1526328520319};\\\", \\\"{x:534,y:750,t:1526328520335};\\\", \\\"{x:518,y:743,t:1526328520353};\\\", \\\"{x:514,y:742,t:1526328520369};\\\", \\\"{x:514,y:741,t:1526328520404};\\\", \\\"{x:514,y:740,t:1526328520644};\\\", \\\"{x:521,y:741,t:1526328521052};\\\", \\\"{x:552,y:748,t:1526328521069};\\\", \\\"{x:610,y:762,t:1526328521086};\\\", \\\"{x:701,y:787,t:1526328521103};\\\", \\\"{x:800,y:811,t:1526328521119};\\\", \\\"{x:909,y:831,t:1526328521137};\\\", \\\"{x:1032,y:856,t:1526328521153};\\\", \\\"{x:1150,y:883,t:1526328521169};\\\", \\\"{x:1258,y:895,t:1526328521187};\\\", \\\"{x:1356,y:912,t:1526328521202};\\\", \\\"{x:1439,y:923,t:1526328521219};\\\", \\\"{x:1511,y:934,t:1526328521236};\\\", \\\"{x:1548,y:940,t:1526328521252};\\\", \\\"{x:1568,y:940,t:1526328521269};\\\", \\\"{x:1588,y:943,t:1526328521287};\\\", \\\"{x:1606,y:943,t:1526328521303};\\\", \\\"{x:1625,y:943,t:1526328521320};\\\", \\\"{x:1640,y:943,t:1526328521336};\\\", \\\"{x:1649,y:943,t:1526328521354};\\\", \\\"{x:1658,y:943,t:1526328521369};\\\", \\\"{x:1664,y:943,t:1526328521386};\\\", \\\"{x:1669,y:943,t:1526328521403};\\\", \\\"{x:1670,y:943,t:1526328521420};\\\" ] }, { \\\"rt\\\": 10231, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 373853, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1669,y:943,t:1526328522668};\\\", \\\"{x:1659,y:942,t:1526328522676};\\\", \\\"{x:1642,y:941,t:1526328522687};\\\", \\\"{x:1558,y:928,t:1526328522705};\\\", \\\"{x:1439,y:911,t:1526328522720};\\\", \\\"{x:1285,y:881,t:1526328522738};\\\", \\\"{x:1120,y:841,t:1526328522754};\\\", \\\"{x:982,y:797,t:1526328522770};\\\", \\\"{x:880,y:757,t:1526328522788};\\\", \\\"{x:795,y:718,t:1526328522804};\\\", \\\"{x:765,y:699,t:1526328522821};\\\", \\\"{x:754,y:693,t:1526328522838};\\\", \\\"{x:747,y:686,t:1526328522855};\\\", \\\"{x:742,y:672,t:1526328522871};\\\", \\\"{x:731,y:642,t:1526328522888};\\\", \\\"{x:713,y:598,t:1526328522905};\\\", \\\"{x:690,y:548,t:1526328522921};\\\", \\\"{x:664,y:495,t:1526328522938};\\\", \\\"{x:639,y:444,t:1526328522955};\\\", \\\"{x:629,y:418,t:1526328522971};\\\", \\\"{x:620,y:401,t:1526328522988};\\\", \\\"{x:617,y:392,t:1526328523004};\\\", \\\"{x:617,y:391,t:1526328523022};\\\", \\\"{x:616,y:391,t:1526328523228};\\\", \\\"{x:616,y:392,t:1526328523238};\\\", \\\"{x:615,y:396,t:1526328523255};\\\", \\\"{x:614,y:399,t:1526328523272};\\\", \\\"{x:613,y:400,t:1526328523288};\\\", \\\"{x:613,y:401,t:1526328523396};\\\", \\\"{x:613,y:404,t:1526328523725};\\\", \\\"{x:614,y:412,t:1526328523739};\\\", \\\"{x:626,y:439,t:1526328523755};\\\", \\\"{x:655,y:481,t:1526328523772};\\\", \\\"{x:724,y:560,t:1526328523788};\\\", \\\"{x:783,y:603,t:1526328523805};\\\", \\\"{x:853,y:636,t:1526328523822};\\\", \\\"{x:930,y:670,t:1526328523838};\\\", \\\"{x:991,y:696,t:1526328523855};\\\", \\\"{x:1053,y:720,t:1526328523870};\\\", \\\"{x:1105,y:738,t:1526328523888};\\\", \\\"{x:1163,y:755,t:1526328523905};\\\", \\\"{x:1243,y:777,t:1526328523921};\\\", \\\"{x:1306,y:791,t:1526328523938};\\\", \\\"{x:1352,y:800,t:1526328523954};\\\", \\\"{x:1385,y:808,t:1526328523971};\\\", \\\"{x:1401,y:811,t:1526328523987};\\\", \\\"{x:1406,y:811,t:1526328524005};\\\", \\\"{x:1404,y:808,t:1526328524036};\\\", \\\"{x:1391,y:797,t:1526328524044};\\\", \\\"{x:1371,y:782,t:1526328524054};\\\", \\\"{x:1306,y:744,t:1526328524070};\\\", \\\"{x:1252,y:713,t:1526328524088};\\\", \\\"{x:1204,y:689,t:1526328524104};\\\", \\\"{x:1145,y:663,t:1526328524121};\\\", \\\"{x:1118,y:649,t:1526328524137};\\\", \\\"{x:1110,y:643,t:1526328524155};\\\", \\\"{x:1109,y:642,t:1526328524172};\\\", \\\"{x:1109,y:639,t:1526328524187};\\\", \\\"{x:1106,y:633,t:1526328524205};\\\", \\\"{x:1099,y:614,t:1526328524221};\\\", \\\"{x:1091,y:594,t:1526328524238};\\\", \\\"{x:1087,y:573,t:1526328524255};\\\", \\\"{x:1084,y:557,t:1526328524271};\\\", \\\"{x:1084,y:540,t:1526328524288};\\\", \\\"{x:1084,y:528,t:1526328524305};\\\", \\\"{x:1084,y:523,t:1526328524321};\\\", \\\"{x:1084,y:521,t:1526328524338};\\\", \\\"{x:1084,y:523,t:1526328524420};\\\", \\\"{x:1088,y:530,t:1526328524428};\\\", \\\"{x:1094,y:537,t:1526328524437};\\\", \\\"{x:1111,y:554,t:1526328524455};\\\", \\\"{x:1136,y:571,t:1526328524471};\\\", \\\"{x:1164,y:588,t:1526328524488};\\\", \\\"{x:1181,y:596,t:1526328524505};\\\", \\\"{x:1190,y:599,t:1526328524520};\\\", \\\"{x:1197,y:599,t:1526328524538};\\\", \\\"{x:1203,y:599,t:1526328524554};\\\", \\\"{x:1207,y:599,t:1526328524570};\\\", \\\"{x:1214,y:597,t:1526328524588};\\\", \\\"{x:1222,y:594,t:1526328524605};\\\", \\\"{x:1226,y:594,t:1526328524621};\\\", \\\"{x:1230,y:594,t:1526328524638};\\\", \\\"{x:1238,y:593,t:1526328524655};\\\", \\\"{x:1250,y:593,t:1526328524671};\\\", \\\"{x:1263,y:593,t:1526328524688};\\\", \\\"{x:1280,y:593,t:1526328524705};\\\", \\\"{x:1294,y:593,t:1526328524720};\\\", \\\"{x:1307,y:593,t:1526328524737};\\\", \\\"{x:1319,y:591,t:1526328524755};\\\", \\\"{x:1328,y:591,t:1526328524770};\\\", \\\"{x:1334,y:591,t:1526328524787};\\\", \\\"{x:1351,y:591,t:1526328524805};\\\", \\\"{x:1366,y:591,t:1526328524821};\\\", \\\"{x:1376,y:591,t:1526328524837};\\\", \\\"{x:1388,y:591,t:1526328524855};\\\", \\\"{x:1395,y:591,t:1526328524871};\\\", \\\"{x:1403,y:591,t:1526328524888};\\\", \\\"{x:1409,y:591,t:1526328524904};\\\", \\\"{x:1414,y:591,t:1526328524921};\\\", \\\"{x:1420,y:591,t:1526328524938};\\\", \\\"{x:1427,y:591,t:1526328524954};\\\", \\\"{x:1438,y:591,t:1526328524970};\\\", \\\"{x:1455,y:591,t:1526328524988};\\\", \\\"{x:1466,y:591,t:1526328525005};\\\", \\\"{x:1473,y:591,t:1526328525020};\\\", \\\"{x:1483,y:591,t:1526328525038};\\\", \\\"{x:1494,y:591,t:1526328525055};\\\", \\\"{x:1506,y:591,t:1526328525070};\\\", \\\"{x:1523,y:591,t:1526328525088};\\\", \\\"{x:1535,y:591,t:1526328525105};\\\", \\\"{x:1536,y:591,t:1526328525121};\\\", \\\"{x:1521,y:591,t:1526328525172};\\\", \\\"{x:1471,y:591,t:1526328525187};\\\", \\\"{x:1385,y:603,t:1526328525204};\\\", \\\"{x:1273,y:621,t:1526328525221};\\\", \\\"{x:1157,y:623,t:1526328525238};\\\", \\\"{x:1054,y:623,t:1526328525254};\\\", \\\"{x:946,y:623,t:1526328525271};\\\", \\\"{x:827,y:623,t:1526328525288};\\\", \\\"{x:710,y:618,t:1526328525308};\\\", \\\"{x:588,y:604,t:1526328525323};\\\", \\\"{x:463,y:585,t:1526328525340};\\\", \\\"{x:308,y:557,t:1526328525356};\\\", \\\"{x:259,y:546,t:1526328525374};\\\", \\\"{x:239,y:540,t:1526328525389};\\\", \\\"{x:237,y:539,t:1526328525407};\\\", \\\"{x:237,y:541,t:1526328525524};\\\", \\\"{x:237,y:547,t:1526328525540};\\\", \\\"{x:237,y:550,t:1526328525556};\\\", \\\"{x:237,y:555,t:1526328525574};\\\", \\\"{x:237,y:560,t:1526328525591};\\\", \\\"{x:237,y:567,t:1526328525609};\\\", \\\"{x:242,y:575,t:1526328525623};\\\", \\\"{x:250,y:585,t:1526328525639};\\\", \\\"{x:260,y:594,t:1526328525656};\\\", \\\"{x:273,y:603,t:1526328525673};\\\", \\\"{x:283,y:608,t:1526328525690};\\\", \\\"{x:294,y:614,t:1526328525707};\\\", \\\"{x:303,y:618,t:1526328525724};\\\", \\\"{x:314,y:622,t:1526328525740};\\\", \\\"{x:319,y:623,t:1526328525756};\\\", \\\"{x:323,y:625,t:1526328525773};\\\", \\\"{x:327,y:626,t:1526328525790};\\\", \\\"{x:333,y:626,t:1526328525806};\\\", \\\"{x:342,y:627,t:1526328525824};\\\", \\\"{x:348,y:628,t:1526328525840};\\\", \\\"{x:354,y:629,t:1526328525857};\\\", \\\"{x:359,y:630,t:1526328525873};\\\", \\\"{x:362,y:630,t:1526328525890};\\\", \\\"{x:364,y:631,t:1526328525907};\\\", \\\"{x:369,y:631,t:1526328525924};\\\", \\\"{x:380,y:631,t:1526328525940};\\\", \\\"{x:386,y:629,t:1526328525957};\\\", \\\"{x:391,y:624,t:1526328525974};\\\", \\\"{x:396,y:612,t:1526328525990};\\\", \\\"{x:400,y:595,t:1526328526006};\\\", \\\"{x:401,y:580,t:1526328526023};\\\", \\\"{x:405,y:573,t:1526328526040};\\\", \\\"{x:413,y:565,t:1526328526057};\\\", \\\"{x:424,y:561,t:1526328526074};\\\", \\\"{x:445,y:560,t:1526328526090};\\\", \\\"{x:472,y:560,t:1526328526107};\\\", \\\"{x:513,y:558,t:1526328526124};\\\", \\\"{x:611,y:568,t:1526328526141};\\\", \\\"{x:667,y:575,t:1526328526157};\\\", \\\"{x:719,y:580,t:1526328526174};\\\", \\\"{x:767,y:583,t:1526328526191};\\\", \\\"{x:798,y:583,t:1526328526207};\\\", \\\"{x:820,y:583,t:1526328526224};\\\", \\\"{x:838,y:583,t:1526328526241};\\\", \\\"{x:851,y:576,t:1526328526257};\\\", \\\"{x:856,y:565,t:1526328526274};\\\", \\\"{x:856,y:553,t:1526328526292};\\\", \\\"{x:844,y:536,t:1526328526307};\\\", \\\"{x:814,y:515,t:1526328526325};\\\", \\\"{x:784,y:505,t:1526328526341};\\\", \\\"{x:755,y:499,t:1526328526357};\\\", \\\"{x:739,y:497,t:1526328526374};\\\", \\\"{x:737,y:497,t:1526328526391};\\\", \\\"{x:735,y:498,t:1526328526460};\\\", \\\"{x:735,y:499,t:1526328526476};\\\", \\\"{x:735,y:502,t:1526328526491};\\\", \\\"{x:734,y:508,t:1526328526506};\\\", \\\"{x:728,y:514,t:1526328526524};\\\", \\\"{x:722,y:519,t:1526328526542};\\\", \\\"{x:712,y:522,t:1526328526557};\\\", \\\"{x:699,y:524,t:1526328526574};\\\", \\\"{x:685,y:524,t:1526328526591};\\\", \\\"{x:677,y:524,t:1526328526608};\\\", \\\"{x:669,y:524,t:1526328526624};\\\", \\\"{x:664,y:524,t:1526328526641};\\\", \\\"{x:659,y:524,t:1526328526658};\\\", \\\"{x:651,y:522,t:1526328526674};\\\", \\\"{x:645,y:521,t:1526328526691};\\\", \\\"{x:632,y:516,t:1526328526708};\\\", \\\"{x:626,y:513,t:1526328526725};\\\", \\\"{x:623,y:512,t:1526328526741};\\\", \\\"{x:623,y:511,t:1526328526758};\\\", \\\"{x:622,y:510,t:1526328526774};\\\", \\\"{x:620,y:509,t:1526328526791};\\\", \\\"{x:613,y:506,t:1526328526807};\\\", \\\"{x:602,y:502,t:1526328526824};\\\", \\\"{x:593,y:500,t:1526328526842};\\\", \\\"{x:589,y:498,t:1526328526858};\\\", \\\"{x:587,y:497,t:1526328526873};\\\", \\\"{x:589,y:497,t:1526328527284};\\\", \\\"{x:590,y:497,t:1526328527300};\\\", \\\"{x:592,y:497,t:1526328527308};\\\", \\\"{x:593,y:497,t:1526328527332};\\\", \\\"{x:594,y:497,t:1526328527364};\\\", \\\"{x:596,y:497,t:1526328527404};\\\", \\\"{x:598,y:497,t:1526328527436};\\\", \\\"{x:605,y:499,t:1526328527708};\\\", \\\"{x:631,y:505,t:1526328527726};\\\", \\\"{x:665,y:510,t:1526328527742};\\\", \\\"{x:701,y:515,t:1526328527757};\\\", \\\"{x:755,y:523,t:1526328527775};\\\", \\\"{x:787,y:527,t:1526328527793};\\\", \\\"{x:799,y:529,t:1526328527808};\\\", \\\"{x:805,y:530,t:1526328527824};\\\", \\\"{x:806,y:530,t:1526328527842};\\\", \\\"{x:806,y:531,t:1526328528260};\\\", \\\"{x:812,y:533,t:1526328528275};\\\", \\\"{x:827,y:536,t:1526328528292};\\\", \\\"{x:839,y:540,t:1526328528308};\\\", \\\"{x:840,y:540,t:1526328528325};\\\", \\\"{x:839,y:538,t:1526328528373};\\\", \\\"{x:838,y:537,t:1526328528388};\\\", \\\"{x:837,y:537,t:1526328528404};\\\", \\\"{x:836,y:536,t:1526328528412};\\\", \\\"{x:835,y:536,t:1526328528724};\\\", \\\"{x:829,y:536,t:1526328528732};\\\", \\\"{x:823,y:536,t:1526328528742};\\\", \\\"{x:814,y:536,t:1526328528759};\\\", \\\"{x:790,y:532,t:1526328528775};\\\", \\\"{x:754,y:527,t:1526328528792};\\\", \\\"{x:731,y:523,t:1526328528809};\\\", \\\"{x:717,y:518,t:1526328528826};\\\", \\\"{x:706,y:516,t:1526328528843};\\\", \\\"{x:700,y:513,t:1526328528859};\\\", \\\"{x:693,y:509,t:1526328528876};\\\", \\\"{x:688,y:508,t:1526328528892};\\\", \\\"{x:683,y:505,t:1526328528909};\\\", \\\"{x:676,y:502,t:1526328528926};\\\", \\\"{x:672,y:500,t:1526328528943};\\\", \\\"{x:669,y:498,t:1526328528959};\\\", \\\"{x:668,y:497,t:1526328528979};\\\", \\\"{x:667,y:497,t:1526328529003};\\\", \\\"{x:664,y:495,t:1526328529011};\\\", \\\"{x:660,y:493,t:1526328529026};\\\", \\\"{x:647,y:488,t:1526328529043};\\\", \\\"{x:635,y:482,t:1526328529059};\\\", \\\"{x:615,y:476,t:1526328529076};\\\", \\\"{x:606,y:474,t:1526328529093};\\\", \\\"{x:604,y:474,t:1526328529108};\\\", \\\"{x:603,y:474,t:1526328529132};\\\", \\\"{x:603,y:476,t:1526328529143};\\\", \\\"{x:603,y:477,t:1526328529159};\\\", \\\"{x:603,y:479,t:1526328529176};\\\", \\\"{x:603,y:480,t:1526328529244};\\\", \\\"{x:603,y:482,t:1526328529259};\\\", \\\"{x:603,y:486,t:1526328529276};\\\", \\\"{x:603,y:489,t:1526328529293};\\\", \\\"{x:605,y:494,t:1526328529310};\\\", \\\"{x:605,y:496,t:1526328529326};\\\", \\\"{x:607,y:498,t:1526328529342};\\\", \\\"{x:610,y:500,t:1526328529360};\\\", \\\"{x:611,y:502,t:1526328529376};\\\", \\\"{x:612,y:502,t:1526328529392};\\\", \\\"{x:612,y:503,t:1526328529409};\\\", \\\"{x:615,y:504,t:1526328529684};\\\", \\\"{x:619,y:505,t:1526328529693};\\\", \\\"{x:642,y:513,t:1526328529710};\\\", \\\"{x:668,y:519,t:1526328529727};\\\", \\\"{x:714,y:528,t:1526328529743};\\\", \\\"{x:798,y:545,t:1526328529761};\\\", \\\"{x:910,y:565,t:1526328529777};\\\", \\\"{x:1062,y:587,t:1526328529793};\\\", \\\"{x:1257,y:623,t:1526328529810};\\\", \\\"{x:1420,y:646,t:1526328529827};\\\", \\\"{x:1533,y:658,t:1526328529842};\\\", \\\"{x:1586,y:658,t:1526328529859};\\\", \\\"{x:1590,y:658,t:1526328529877};\\\", \\\"{x:1591,y:656,t:1526328529932};\\\", \\\"{x:1592,y:654,t:1526328529943};\\\", \\\"{x:1592,y:651,t:1526328529959};\\\", \\\"{x:1592,y:648,t:1526328529977};\\\", \\\"{x:1581,y:640,t:1526328529993};\\\", \\\"{x:1565,y:631,t:1526328530010};\\\", \\\"{x:1548,y:623,t:1526328530027};\\\", \\\"{x:1517,y:610,t:1526328530043};\\\", \\\"{x:1458,y:593,t:1526328530059};\\\", \\\"{x:1417,y:583,t:1526328530076};\\\", \\\"{x:1374,y:576,t:1526328530093};\\\", \\\"{x:1332,y:570,t:1526328530110};\\\", \\\"{x:1298,y:569,t:1526328530127};\\\", \\\"{x:1276,y:569,t:1526328530143};\\\", \\\"{x:1264,y:569,t:1526328530160};\\\", \\\"{x:1255,y:569,t:1526328530177};\\\", \\\"{x:1248,y:569,t:1526328530194};\\\", \\\"{x:1244,y:569,t:1526328530209};\\\", \\\"{x:1236,y:568,t:1526328530227};\\\", \\\"{x:1217,y:561,t:1526328530244};\\\", \\\"{x:1200,y:555,t:1526328530259};\\\", \\\"{x:1176,y:548,t:1526328530276};\\\", \\\"{x:1158,y:543,t:1526328530294};\\\", \\\"{x:1151,y:540,t:1526328530310};\\\", \\\"{x:1149,y:540,t:1526328530327};\\\", \\\"{x:1152,y:540,t:1526328530356};\\\", \\\"{x:1157,y:540,t:1526328530363};\\\", \\\"{x:1167,y:541,t:1526328530377};\\\", \\\"{x:1178,y:541,t:1526328530393};\\\", \\\"{x:1200,y:545,t:1526328530410};\\\", \\\"{x:1233,y:547,t:1526328530427};\\\", \\\"{x:1276,y:552,t:1526328530444};\\\", \\\"{x:1301,y:557,t:1526328530460};\\\", \\\"{x:1323,y:559,t:1526328530477};\\\", \\\"{x:1339,y:562,t:1526328530493};\\\", \\\"{x:1351,y:564,t:1526328530510};\\\", \\\"{x:1364,y:566,t:1526328530527};\\\", \\\"{x:1374,y:567,t:1526328530544};\\\", \\\"{x:1381,y:567,t:1526328530560};\\\", \\\"{x:1384,y:567,t:1526328530577};\\\", \\\"{x:1385,y:567,t:1526328530636};\\\", \\\"{x:1384,y:567,t:1526328530844};\\\", \\\"{x:1373,y:569,t:1526328530861};\\\", \\\"{x:1349,y:572,t:1526328530877};\\\", \\\"{x:1315,y:573,t:1526328530894};\\\", \\\"{x:1240,y:573,t:1526328530911};\\\", \\\"{x:1145,y:575,t:1526328530927};\\\", \\\"{x:1053,y:575,t:1526328530944};\\\", \\\"{x:987,y:584,t:1526328530961};\\\", \\\"{x:957,y:586,t:1526328530977};\\\", \\\"{x:946,y:588,t:1526328530994};\\\", \\\"{x:941,y:590,t:1526328531011};\\\", \\\"{x:938,y:592,t:1526328531027};\\\", \\\"{x:933,y:594,t:1526328531043};\\\", \\\"{x:927,y:598,t:1526328531060};\\\", \\\"{x:920,y:600,t:1526328531077};\\\", \\\"{x:914,y:603,t:1526328531094};\\\", \\\"{x:909,y:606,t:1526328531111};\\\", \\\"{x:905,y:611,t:1526328531128};\\\", \\\"{x:902,y:614,t:1526328531144};\\\", \\\"{x:894,y:619,t:1526328531161};\\\", \\\"{x:884,y:624,t:1526328531178};\\\", \\\"{x:862,y:634,t:1526328531195};\\\", \\\"{x:823,y:645,t:1526328531211};\\\", \\\"{x:757,y:667,t:1526328531228};\\\", \\\"{x:728,y:678,t:1526328531244};\\\", \\\"{x:708,y:684,t:1526328531261};\\\", \\\"{x:692,y:692,t:1526328531279};\\\", \\\"{x:677,y:695,t:1526328531294};\\\", \\\"{x:658,y:700,t:1526328531311};\\\", \\\"{x:640,y:706,t:1526328531328};\\\", \\\"{x:624,y:710,t:1526328531344};\\\", \\\"{x:609,y:714,t:1526328531361};\\\", \\\"{x:598,y:716,t:1526328531378};\\\", \\\"{x:586,y:719,t:1526328531394};\\\", \\\"{x:578,y:719,t:1526328531411};\\\", \\\"{x:573,y:720,t:1526328531428};\\\", \\\"{x:571,y:720,t:1526328531460};\\\", \\\"{x:570,y:720,t:1526328531467};\\\", \\\"{x:570,y:719,t:1526328531478};\\\", \\\"{x:570,y:718,t:1526328531494};\\\", \\\"{x:569,y:725,t:1526328531636};\\\", \\\"{x:567,y:740,t:1526328531644};\\\", \\\"{x:560,y:757,t:1526328531661};\\\", \\\"{x:552,y:767,t:1526328531678};\\\", \\\"{x:547,y:768,t:1526328531695};\\\", \\\"{x:544,y:768,t:1526328531710};\\\", \\\"{x:542,y:768,t:1526328531732};\\\", \\\"{x:540,y:765,t:1526328531747};\\\", \\\"{x:538,y:760,t:1526328531761};\\\", \\\"{x:534,y:755,t:1526328531778};\\\", \\\"{x:532,y:753,t:1526328531796};\\\", \\\"{x:530,y:752,t:1526328531812};\\\", \\\"{x:529,y:751,t:1526328531859};\\\", \\\"{x:529,y:750,t:1526328531875};\\\", \\\"{x:528,y:750,t:1526328531892};\\\", \\\"{x:528,y:749,t:1526328531940};\\\", \\\"{x:527,y:749,t:1526328531980};\\\", \\\"{x:527,y:748,t:1526328532020};\\\", \\\"{x:527,y:747,t:1526328532036};\\\", \\\"{x:526,y:746,t:1526328532045};\\\", \\\"{x:526,y:745,t:1526328532556};\\\", \\\"{x:526,y:743,t:1526328532564};\\\", \\\"{x:527,y:742,t:1526328532660};\\\", \\\"{x:531,y:742,t:1526328532668};\\\", \\\"{x:538,y:742,t:1526328532679};\\\", \\\"{x:550,y:742,t:1526328532695};\\\", \\\"{x:583,y:742,t:1526328532712};\\\", \\\"{x:658,y:742,t:1526328532729};\\\", \\\"{x:763,y:742,t:1526328532745};\\\", \\\"{x:885,y:742,t:1526328532762};\\\", \\\"{x:1004,y:742,t:1526328532779};\\\", \\\"{x:1146,y:738,t:1526328532796};\\\", \\\"{x:1223,y:733,t:1526328532812};\\\", \\\"{x:1271,y:725,t:1526328532829};\\\", \\\"{x:1304,y:718,t:1526328532846};\\\", \\\"{x:1337,y:710,t:1526328532862};\\\", \\\"{x:1363,y:701,t:1526328532879};\\\", \\\"{x:1377,y:695,t:1526328532896};\\\", \\\"{x:1386,y:691,t:1526328532912};\\\", \\\"{x:1391,y:688,t:1526328532929};\\\", \\\"{x:1392,y:688,t:1526328532946};\\\", \\\"{x:1393,y:687,t:1526328532972};\\\", \\\"{x:1393,y:686,t:1526328532988};\\\" ] }, { \\\"rt\\\": 53428, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 428586, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-M -01 PM-01 PM-01 PM-O -O -O -X -M -01 PM-I -F -01 PM-09 AM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1393,y:683,t:1526328533638};\\\", \\\"{x:1392,y:682,t:1526328533683};\\\", \\\"{x:1391,y:682,t:1526328533716};\\\", \\\"{x:1390,y:682,t:1526328533740};\\\", \\\"{x:1389,y:682,t:1526328533788};\\\", \\\"{x:1388,y:681,t:1526328533804};\\\", \\\"{x:1387,y:681,t:1526328533819};\\\", \\\"{x:1386,y:681,t:1526328533844};\\\", \\\"{x:1385,y:681,t:1526328533924};\\\", \\\"{x:1382,y:680,t:1526328534029};\\\", \\\"{x:1381,y:680,t:1526328534047};\\\", \\\"{x:1380,y:680,t:1526328534068};\\\", \\\"{x:1378,y:680,t:1526328534080};\\\", \\\"{x:1376,y:679,t:1526328534096};\\\", \\\"{x:1371,y:678,t:1526328534113};\\\", \\\"{x:1364,y:675,t:1526328534130};\\\", \\\"{x:1356,y:673,t:1526328534147};\\\", \\\"{x:1341,y:669,t:1526328534163};\\\", \\\"{x:1316,y:662,t:1526328534180};\\\", \\\"{x:1297,y:656,t:1526328534197};\\\", \\\"{x:1284,y:651,t:1526328534213};\\\", \\\"{x:1273,y:646,t:1526328534230};\\\", \\\"{x:1263,y:643,t:1526328534247};\\\", \\\"{x:1249,y:633,t:1526328534263};\\\", \\\"{x:1233,y:622,t:1526328534280};\\\", \\\"{x:1206,y:605,t:1526328534297};\\\", \\\"{x:1178,y:585,t:1526328534313};\\\", \\\"{x:1139,y:562,t:1526328534330};\\\", \\\"{x:1085,y:536,t:1526328534347};\\\", \\\"{x:1021,y:517,t:1526328534363};\\\", \\\"{x:922,y:481,t:1526328534380};\\\", \\\"{x:866,y:465,t:1526328534397};\\\", \\\"{x:820,y:455,t:1526328534413};\\\", \\\"{x:773,y:444,t:1526328534430};\\\", \\\"{x:732,y:433,t:1526328534447};\\\", \\\"{x:688,y:428,t:1526328534463};\\\", \\\"{x:642,y:421,t:1526328534480};\\\", \\\"{x:593,y:417,t:1526328534497};\\\", \\\"{x:534,y:407,t:1526328534513};\\\", \\\"{x:494,y:405,t:1526328534529};\\\", \\\"{x:465,y:405,t:1526328534547};\\\", \\\"{x:445,y:405,t:1526328534563};\\\", \\\"{x:434,y:405,t:1526328534580};\\\", \\\"{x:433,y:405,t:1526328534604};\\\", \\\"{x:432,y:405,t:1526328534756};\\\", \\\"{x:431,y:405,t:1526328534764};\\\", \\\"{x:424,y:405,t:1526328534780};\\\", \\\"{x:409,y:405,t:1526328534797};\\\", \\\"{x:380,y:405,t:1526328534814};\\\", \\\"{x:338,y:405,t:1526328534830};\\\", \\\"{x:320,y:405,t:1526328534847};\\\", \\\"{x:286,y:405,t:1526328534864};\\\", \\\"{x:247,y:405,t:1526328534880};\\\", \\\"{x:227,y:405,t:1526328534897};\\\", \\\"{x:218,y:405,t:1526328534914};\\\", \\\"{x:216,y:405,t:1526328534930};\\\", \\\"{x:215,y:406,t:1526328534963};\\\", \\\"{x:215,y:409,t:1526328534980};\\\", \\\"{x:215,y:413,t:1526328534997};\\\", \\\"{x:216,y:415,t:1526328535014};\\\", \\\"{x:218,y:418,t:1526328535030};\\\", \\\"{x:220,y:420,t:1526328535047};\\\", \\\"{x:222,y:422,t:1526328535064};\\\", \\\"{x:224,y:425,t:1526328535080};\\\", \\\"{x:228,y:429,t:1526328535097};\\\", \\\"{x:230,y:432,t:1526328535115};\\\", \\\"{x:236,y:440,t:1526328535132};\\\", \\\"{x:239,y:444,t:1526328535147};\\\", \\\"{x:242,y:450,t:1526328535163};\\\", \\\"{x:242,y:451,t:1526328535181};\\\", \\\"{x:243,y:451,t:1526328535261};\\\", \\\"{x:244,y:451,t:1526328535268};\\\", \\\"{x:246,y:452,t:1526328535281};\\\", \\\"{x:254,y:455,t:1526328535297};\\\", \\\"{x:266,y:457,t:1526328535314};\\\", \\\"{x:281,y:462,t:1526328535331};\\\", \\\"{x:293,y:466,t:1526328535347};\\\", \\\"{x:309,y:468,t:1526328535364};\\\", \\\"{x:314,y:469,t:1526328535381};\\\", \\\"{x:318,y:469,t:1526328535397};\\\", \\\"{x:321,y:470,t:1526328535414};\\\", \\\"{x:327,y:470,t:1526328535432};\\\", \\\"{x:332,y:470,t:1526328535447};\\\", \\\"{x:341,y:470,t:1526328535464};\\\", \\\"{x:351,y:470,t:1526328535481};\\\", \\\"{x:357,y:470,t:1526328535497};\\\", \\\"{x:358,y:470,t:1526328535514};\\\", \\\"{x:360,y:470,t:1526328535532};\\\", \\\"{x:360,y:469,t:1526328535556};\\\", \\\"{x:360,y:468,t:1526328535580};\\\", \\\"{x:360,y:467,t:1526328535588};\\\", \\\"{x:360,y:466,t:1526328535604};\\\", \\\"{x:360,y:465,t:1526328535615};\\\", \\\"{x:359,y:464,t:1526328535631};\\\", \\\"{x:357,y:462,t:1526328535648};\\\", \\\"{x:356,y:462,t:1526328535668};\\\", \\\"{x:355,y:460,t:1526328535692};\\\", \\\"{x:355,y:459,t:1526328535748};\\\", \\\"{x:357,y:459,t:1526328535764};\\\", \\\"{x:362,y:459,t:1526328535781};\\\", \\\"{x:369,y:459,t:1526328535798};\\\", \\\"{x:378,y:459,t:1526328535814};\\\", \\\"{x:385,y:459,t:1526328535831};\\\", \\\"{x:389,y:459,t:1526328535848};\\\", \\\"{x:391,y:459,t:1526328535864};\\\", \\\"{x:392,y:459,t:1526328535881};\\\", \\\"{x:394,y:459,t:1526328535898};\\\", \\\"{x:395,y:459,t:1526328535972};\\\", \\\"{x:397,y:458,t:1526328535988};\\\", \\\"{x:398,y:458,t:1526328535998};\\\", \\\"{x:399,y:458,t:1526328536028};\\\", \\\"{x:400,y:457,t:1526328536044};\\\", \\\"{x:401,y:457,t:1526328536148};\\\", \\\"{x:404,y:456,t:1526328536164};\\\", \\\"{x:408,y:456,t:1526328536181};\\\", \\\"{x:413,y:455,t:1526328536199};\\\", \\\"{x:418,y:455,t:1526328536215};\\\", \\\"{x:423,y:455,t:1526328536231};\\\", \\\"{x:427,y:455,t:1526328536248};\\\", \\\"{x:430,y:455,t:1526328536265};\\\", \\\"{x:439,y:455,t:1526328536282};\\\", \\\"{x:447,y:455,t:1526328536298};\\\", \\\"{x:456,y:455,t:1526328536315};\\\", \\\"{x:463,y:455,t:1526328536332};\\\", \\\"{x:470,y:455,t:1526328536347};\\\", \\\"{x:476,y:455,t:1526328536365};\\\", \\\"{x:481,y:455,t:1526328536382};\\\", \\\"{x:484,y:456,t:1526328536398};\\\", \\\"{x:486,y:456,t:1526328536415};\\\", \\\"{x:488,y:456,t:1526328536431};\\\", \\\"{x:489,y:456,t:1526328536448};\\\", \\\"{x:491,y:456,t:1526328536468};\\\", \\\"{x:492,y:456,t:1526328536484};\\\", \\\"{x:495,y:456,t:1526328536499};\\\", \\\"{x:505,y:457,t:1526328536515};\\\", \\\"{x:519,y:459,t:1526328536532};\\\", \\\"{x:537,y:462,t:1526328536548};\\\", \\\"{x:548,y:463,t:1526328536565};\\\", \\\"{x:554,y:463,t:1526328536582};\\\", \\\"{x:559,y:463,t:1526328536598};\\\", \\\"{x:563,y:465,t:1526328536615};\\\", \\\"{x:567,y:466,t:1526328536632};\\\", \\\"{x:574,y:467,t:1526328536648};\\\", \\\"{x:584,y:467,t:1526328536666};\\\", \\\"{x:596,y:467,t:1526328536682};\\\", \\\"{x:607,y:468,t:1526328536699};\\\", \\\"{x:621,y:468,t:1526328536715};\\\", \\\"{x:634,y:468,t:1526328536732};\\\", \\\"{x:638,y:468,t:1526328536749};\\\", \\\"{x:640,y:468,t:1526328536765};\\\", \\\"{x:641,y:468,t:1526328536860};\\\", \\\"{x:641,y:469,t:1526328536868};\\\", \\\"{x:643,y:469,t:1526328536883};\\\", \\\"{x:644,y:469,t:1526328536899};\\\", \\\"{x:647,y:469,t:1526328536915};\\\", \\\"{x:650,y:470,t:1526328536932};\\\", \\\"{x:652,y:470,t:1526328536948};\\\", \\\"{x:653,y:470,t:1526328536966};\\\", \\\"{x:655,y:470,t:1526328536982};\\\", \\\"{x:657,y:470,t:1526328536998};\\\", \\\"{x:659,y:470,t:1526328537016};\\\", \\\"{x:664,y:471,t:1526328537032};\\\", \\\"{x:668,y:472,t:1526328537050};\\\", \\\"{x:675,y:473,t:1526328537066};\\\", \\\"{x:680,y:473,t:1526328537082};\\\", \\\"{x:686,y:475,t:1526328537099};\\\", \\\"{x:692,y:475,t:1526328537116};\\\", \\\"{x:699,y:477,t:1526328537133};\\\", \\\"{x:707,y:478,t:1526328537150};\\\", \\\"{x:714,y:478,t:1526328537165};\\\", \\\"{x:723,y:481,t:1526328537182};\\\", \\\"{x:729,y:481,t:1526328537199};\\\", \\\"{x:737,y:483,t:1526328537215};\\\", \\\"{x:744,y:483,t:1526328537232};\\\", \\\"{x:751,y:485,t:1526328537249};\\\", \\\"{x:758,y:486,t:1526328537265};\\\", \\\"{x:766,y:487,t:1526328537283};\\\", \\\"{x:770,y:487,t:1526328537300};\\\", \\\"{x:775,y:487,t:1526328537315};\\\", \\\"{x:778,y:487,t:1526328537332};\\\", \\\"{x:779,y:487,t:1526328537349};\\\", \\\"{x:780,y:487,t:1526328537365};\\\", \\\"{x:781,y:487,t:1526328537396};\\\", \\\"{x:782,y:487,t:1526328537403};\\\", \\\"{x:783,y:487,t:1526328537420};\\\", \\\"{x:784,y:487,t:1526328537443};\\\", \\\"{x:785,y:487,t:1526328537451};\\\", \\\"{x:786,y:489,t:1526328537466};\\\", \\\"{x:788,y:489,t:1526328537482};\\\", \\\"{x:791,y:489,t:1526328537500};\\\", \\\"{x:793,y:490,t:1526328537516};\\\", \\\"{x:795,y:490,t:1526328537532};\\\", \\\"{x:796,y:490,t:1526328537556};\\\", \\\"{x:797,y:490,t:1526328537566};\\\", \\\"{x:798,y:490,t:1526328537583};\\\", \\\"{x:800,y:491,t:1526328537599};\\\", \\\"{x:801,y:491,t:1526328537616};\\\", \\\"{x:802,y:491,t:1526328537632};\\\", \\\"{x:803,y:491,t:1526328537772};\\\", \\\"{x:805,y:491,t:1526328537788};\\\", \\\"{x:805,y:492,t:1526328537799};\\\", \\\"{x:807,y:492,t:1526328537828};\\\", \\\"{x:808,y:492,t:1526328537836};\\\", \\\"{x:810,y:492,t:1526328537860};\\\", \\\"{x:812,y:493,t:1526328537868};\\\", \\\"{x:815,y:493,t:1526328537882};\\\", \\\"{x:825,y:494,t:1526328537900};\\\", \\\"{x:851,y:497,t:1526328537917};\\\", \\\"{x:873,y:497,t:1526328537932};\\\", \\\"{x:892,y:499,t:1526328537950};\\\", \\\"{x:907,y:499,t:1526328537966};\\\", \\\"{x:925,y:499,t:1526328537984};\\\", \\\"{x:951,y:499,t:1526328538000};\\\", \\\"{x:980,y:499,t:1526328538016};\\\", \\\"{x:1004,y:499,t:1526328538034};\\\", \\\"{x:1030,y:496,t:1526328538049};\\\", \\\"{x:1054,y:490,t:1526328538066};\\\", \\\"{x:1075,y:480,t:1526328538083};\\\", \\\"{x:1093,y:470,t:1526328538100};\\\", \\\"{x:1102,y:463,t:1526328538116};\\\", \\\"{x:1103,y:460,t:1526328538133};\\\", \\\"{x:1103,y:463,t:1526328538388};\\\", \\\"{x:1103,y:473,t:1526328538400};\\\", \\\"{x:1103,y:499,t:1526328538416};\\\", \\\"{x:1103,y:527,t:1526328538433};\\\", \\\"{x:1096,y:565,t:1526328538450};\\\", \\\"{x:1088,y:621,t:1526328538466};\\\", \\\"{x:1082,y:671,t:1526328538483};\\\", \\\"{x:1077,y:733,t:1526328538500};\\\", \\\"{x:1074,y:762,t:1526328538516};\\\", \\\"{x:1070,y:789,t:1526328538533};\\\", \\\"{x:1066,y:815,t:1526328538550};\\\", \\\"{x:1064,y:832,t:1526328538566};\\\", \\\"{x:1064,y:842,t:1526328538584};\\\", \\\"{x:1064,y:851,t:1526328538601};\\\", \\\"{x:1064,y:860,t:1526328538616};\\\", \\\"{x:1064,y:865,t:1526328538634};\\\", \\\"{x:1064,y:869,t:1526328538650};\\\", \\\"{x:1064,y:870,t:1526328538676};\\\", \\\"{x:1064,y:872,t:1526328538700};\\\", \\\"{x:1064,y:873,t:1526328538716};\\\", \\\"{x:1065,y:875,t:1526328538733};\\\", \\\"{x:1068,y:877,t:1526328538750};\\\", \\\"{x:1071,y:877,t:1526328538767};\\\", \\\"{x:1072,y:877,t:1526328538783};\\\", \\\"{x:1076,y:877,t:1526328538800};\\\", \\\"{x:1079,y:877,t:1526328538817};\\\", \\\"{x:1082,y:877,t:1526328538834};\\\", \\\"{x:1085,y:877,t:1526328538850};\\\", \\\"{x:1088,y:875,t:1526328538867};\\\", \\\"{x:1091,y:875,t:1526328538883};\\\", \\\"{x:1093,y:872,t:1526328538900};\\\", \\\"{x:1094,y:872,t:1526328538916};\\\", \\\"{x:1095,y:872,t:1526328539164};\\\", \\\"{x:1095,y:870,t:1526328539180};\\\", \\\"{x:1095,y:869,t:1526328539187};\\\", \\\"{x:1095,y:867,t:1526328539204};\\\", \\\"{x:1095,y:866,t:1526328539220};\\\", \\\"{x:1095,y:864,t:1526328539260};\\\", \\\"{x:1096,y:860,t:1526328539509};\\\", \\\"{x:1092,y:854,t:1526328539517};\\\", \\\"{x:1077,y:837,t:1526328539535};\\\", \\\"{x:1057,y:820,t:1526328539551};\\\", \\\"{x:1020,y:795,t:1526328539567};\\\", \\\"{x:968,y:765,t:1526328539584};\\\", \\\"{x:891,y:733,t:1526328539600};\\\", \\\"{x:817,y:700,t:1526328539618};\\\", \\\"{x:758,y:674,t:1526328539634};\\\", \\\"{x:721,y:658,t:1526328539651};\\\", \\\"{x:705,y:648,t:1526328539667};\\\", \\\"{x:702,y:648,t:1526328539684};\\\", \\\"{x:703,y:646,t:1526328539756};\\\", \\\"{x:705,y:645,t:1526328539768};\\\", \\\"{x:725,y:644,t:1526328539783};\\\", \\\"{x:764,y:644,t:1526328539800};\\\", \\\"{x:822,y:650,t:1526328539817};\\\", \\\"{x:870,y:657,t:1526328539834};\\\", \\\"{x:928,y:672,t:1526328539851};\\\", \\\"{x:968,y:687,t:1526328539867};\\\", \\\"{x:984,y:697,t:1526328539884};\\\", \\\"{x:991,y:702,t:1526328539901};\\\", \\\"{x:991,y:703,t:1526328539932};\\\", \\\"{x:991,y:704,t:1526328539948};\\\", \\\"{x:994,y:705,t:1526328540740};\\\", \\\"{x:1003,y:711,t:1526328540751};\\\", \\\"{x:1024,y:726,t:1526328540768};\\\", \\\"{x:1043,y:743,t:1526328540784};\\\", \\\"{x:1068,y:757,t:1526328540800};\\\", \\\"{x:1093,y:768,t:1526328540817};\\\", \\\"{x:1113,y:774,t:1526328540834};\\\", \\\"{x:1122,y:779,t:1526328540851};\\\", \\\"{x:1130,y:783,t:1526328540868};\\\", \\\"{x:1148,y:794,t:1526328540884};\\\", \\\"{x:1165,y:803,t:1526328540900};\\\", \\\"{x:1178,y:813,t:1526328540918};\\\", \\\"{x:1187,y:819,t:1526328540934};\\\", \\\"{x:1192,y:823,t:1526328540951};\\\", \\\"{x:1191,y:823,t:1526328541092};\\\", \\\"{x:1186,y:823,t:1526328541101};\\\", \\\"{x:1161,y:811,t:1526328541118};\\\", \\\"{x:1127,y:797,t:1526328541135};\\\", \\\"{x:1089,y:781,t:1526328541151};\\\", \\\"{x:1065,y:771,t:1526328541167};\\\", \\\"{x:1055,y:764,t:1526328541185};\\\", \\\"{x:1053,y:764,t:1526328541200};\\\", \\\"{x:1053,y:766,t:1526328541452};\\\", \\\"{x:1054,y:771,t:1526328541468};\\\", \\\"{x:1062,y:783,t:1526328541485};\\\", \\\"{x:1064,y:790,t:1526328541501};\\\", \\\"{x:1070,y:800,t:1526328541518};\\\", \\\"{x:1072,y:805,t:1526328541534};\\\", \\\"{x:1075,y:809,t:1526328541551};\\\", \\\"{x:1078,y:812,t:1526328541567};\\\", \\\"{x:1078,y:813,t:1526328541584};\\\", \\\"{x:1079,y:814,t:1526328541601};\\\", \\\"{x:1080,y:815,t:1526328541617};\\\", \\\"{x:1080,y:816,t:1526328541634};\\\", \\\"{x:1081,y:816,t:1526328541652};\\\", \\\"{x:1083,y:816,t:1526328541692};\\\", \\\"{x:1084,y:816,t:1526328541702};\\\", \\\"{x:1086,y:815,t:1526328541718};\\\", \\\"{x:1088,y:815,t:1526328541735};\\\", \\\"{x:1090,y:813,t:1526328541751};\\\", \\\"{x:1092,y:812,t:1526328541768};\\\", \\\"{x:1095,y:810,t:1526328541785};\\\", \\\"{x:1098,y:809,t:1526328541801};\\\", \\\"{x:1099,y:807,t:1526328541818};\\\", \\\"{x:1101,y:805,t:1526328541834};\\\", \\\"{x:1101,y:804,t:1526328541852};\\\", \\\"{x:1101,y:803,t:1526328541868};\\\", \\\"{x:1101,y:802,t:1526328541884};\\\", \\\"{x:1103,y:800,t:1526328541902};\\\", \\\"{x:1104,y:800,t:1526328541932};\\\", \\\"{x:1104,y:799,t:1526328541940};\\\", \\\"{x:1104,y:798,t:1526328542005};\\\", \\\"{x:1104,y:797,t:1526328542018};\\\", \\\"{x:1104,y:796,t:1526328542035};\\\", \\\"{x:1105,y:791,t:1526328542051};\\\", \\\"{x:1106,y:787,t:1526328542068};\\\", \\\"{x:1106,y:780,t:1526328542084};\\\", \\\"{x:1106,y:772,t:1526328542102};\\\", \\\"{x:1106,y:761,t:1526328542118};\\\", \\\"{x:1101,y:745,t:1526328542135};\\\", \\\"{x:1094,y:714,t:1526328542176};\\\", \\\"{x:1094,y:711,t:1526328542185};\\\", \\\"{x:1093,y:704,t:1526328542201};\\\", \\\"{x:1093,y:700,t:1526328542217};\\\", \\\"{x:1093,y:696,t:1526328542235};\\\", \\\"{x:1093,y:694,t:1526328542251};\\\", \\\"{x:1093,y:689,t:1526328542268};\\\", \\\"{x:1093,y:683,t:1526328542285};\\\", \\\"{x:1093,y:678,t:1526328542302};\\\", \\\"{x:1093,y:672,t:1526328542319};\\\", \\\"{x:1094,y:668,t:1526328542335};\\\", \\\"{x:1094,y:667,t:1526328542352};\\\", \\\"{x:1094,y:664,t:1526328542436};\\\", \\\"{x:1094,y:662,t:1526328542452};\\\", \\\"{x:1094,y:648,t:1526328542468};\\\", \\\"{x:1094,y:637,t:1526328542485};\\\", \\\"{x:1092,y:623,t:1526328542502};\\\", \\\"{x:1091,y:618,t:1526328542518};\\\", \\\"{x:1091,y:613,t:1526328542535};\\\", \\\"{x:1089,y:610,t:1526328542552};\\\", \\\"{x:1089,y:609,t:1526328542604};\\\", \\\"{x:1091,y:609,t:1526328542619};\\\", \\\"{x:1096,y:609,t:1526328542635};\\\", \\\"{x:1101,y:612,t:1526328542651};\\\", \\\"{x:1104,y:612,t:1526328542669};\\\", \\\"{x:1106,y:613,t:1526328542803};\\\", \\\"{x:1107,y:613,t:1526328542819};\\\", \\\"{x:1108,y:614,t:1526328542835};\\\", \\\"{x:1113,y:616,t:1526328542851};\\\", \\\"{x:1116,y:618,t:1526328542868};\\\", \\\"{x:1117,y:618,t:1526328542885};\\\", \\\"{x:1120,y:619,t:1526328542901};\\\", \\\"{x:1121,y:620,t:1526328542918};\\\", \\\"{x:1122,y:620,t:1526328542935};\\\", \\\"{x:1123,y:620,t:1526328542951};\\\", \\\"{x:1115,y:620,t:1526328555180};\\\", \\\"{x:1090,y:620,t:1526328555190};\\\", \\\"{x:1049,y:617,t:1526328555206};\\\", \\\"{x:988,y:617,t:1526328555223};\\\", \\\"{x:957,y:616,t:1526328555240};\\\", \\\"{x:952,y:616,t:1526328555256};\\\", \\\"{x:957,y:617,t:1526328555292};\\\", \\\"{x:961,y:620,t:1526328555306};\\\", \\\"{x:966,y:622,t:1526328555323};\\\", \\\"{x:970,y:624,t:1526328555339};\\\", \\\"{x:974,y:625,t:1526328555356};\\\", \\\"{x:983,y:629,t:1526328555373};\\\", \\\"{x:993,y:629,t:1526328555390};\\\", \\\"{x:1004,y:630,t:1526328555406};\\\", \\\"{x:1018,y:630,t:1526328555423};\\\", \\\"{x:1029,y:630,t:1526328555440};\\\", \\\"{x:1040,y:630,t:1526328555456};\\\", \\\"{x:1049,y:630,t:1526328555473};\\\", \\\"{x:1055,y:630,t:1526328555490};\\\", \\\"{x:1063,y:631,t:1526328555506};\\\", \\\"{x:1070,y:631,t:1526328555523};\\\", \\\"{x:1085,y:634,t:1526328555540};\\\", \\\"{x:1094,y:635,t:1526328555556};\\\", \\\"{x:1103,y:637,t:1526328555573};\\\", \\\"{x:1106,y:637,t:1526328555590};\\\", \\\"{x:1110,y:637,t:1526328555606};\\\", \\\"{x:1113,y:637,t:1526328555623};\\\", \\\"{x:1117,y:637,t:1526328555640};\\\", \\\"{x:1120,y:637,t:1526328555656};\\\", \\\"{x:1127,y:637,t:1526328555673};\\\", \\\"{x:1135,y:637,t:1526328555690};\\\", \\\"{x:1146,y:637,t:1526328555706};\\\", \\\"{x:1160,y:637,t:1526328555723};\\\", \\\"{x:1179,y:637,t:1526328555740};\\\", \\\"{x:1189,y:637,t:1526328555756};\\\", \\\"{x:1203,y:637,t:1526328555773};\\\", \\\"{x:1213,y:637,t:1526328555790};\\\", \\\"{x:1222,y:637,t:1526328555806};\\\", \\\"{x:1236,y:637,t:1526328555823};\\\", \\\"{x:1245,y:637,t:1526328555840};\\\", \\\"{x:1256,y:637,t:1526328555856};\\\", \\\"{x:1262,y:637,t:1526328555873};\\\", \\\"{x:1271,y:637,t:1526328555890};\\\", \\\"{x:1279,y:637,t:1526328555905};\\\", \\\"{x:1288,y:637,t:1526328555923};\\\", \\\"{x:1300,y:637,t:1526328555940};\\\", \\\"{x:1307,y:637,t:1526328555957};\\\", \\\"{x:1313,y:636,t:1526328555973};\\\", \\\"{x:1318,y:636,t:1526328555990};\\\", \\\"{x:1321,y:635,t:1526328556006};\\\", \\\"{x:1322,y:634,t:1526328556023};\\\", \\\"{x:1324,y:634,t:1526328556044};\\\", \\\"{x:1324,y:633,t:1526328556068};\\\", \\\"{x:1318,y:636,t:1526328556460};\\\", \\\"{x:1301,y:643,t:1526328556474};\\\", \\\"{x:1258,y:666,t:1526328556490};\\\", \\\"{x:1186,y:714,t:1526328556507};\\\", \\\"{x:1127,y:757,t:1526328556523};\\\", \\\"{x:1080,y:811,t:1526328556539};\\\", \\\"{x:1070,y:828,t:1526328556557};\\\", \\\"{x:1067,y:835,t:1526328556573};\\\", \\\"{x:1067,y:839,t:1526328556591};\\\", \\\"{x:1066,y:839,t:1526328556607};\\\", \\\"{x:1067,y:839,t:1526328556699};\\\", \\\"{x:1072,y:839,t:1526328556708};\\\", \\\"{x:1082,y:835,t:1526328556723};\\\", \\\"{x:1104,y:819,t:1526328556740};\\\", \\\"{x:1120,y:808,t:1526328556757};\\\", \\\"{x:1129,y:800,t:1526328556773};\\\", \\\"{x:1134,y:792,t:1526328556790};\\\", \\\"{x:1139,y:786,t:1526328556807};\\\", \\\"{x:1144,y:778,t:1526328556823};\\\", \\\"{x:1146,y:775,t:1526328556840};\\\", \\\"{x:1150,y:769,t:1526328556857};\\\", \\\"{x:1154,y:763,t:1526328556873};\\\", \\\"{x:1160,y:756,t:1526328556890};\\\", \\\"{x:1165,y:750,t:1526328556907};\\\", \\\"{x:1169,y:746,t:1526328556923};\\\", \\\"{x:1177,y:737,t:1526328556940};\\\", \\\"{x:1181,y:736,t:1526328556957};\\\", \\\"{x:1184,y:733,t:1526328556973};\\\", \\\"{x:1188,y:732,t:1526328556990};\\\", \\\"{x:1193,y:730,t:1526328557007};\\\", \\\"{x:1202,y:728,t:1526328557024};\\\", \\\"{x:1213,y:727,t:1526328557040};\\\", \\\"{x:1229,y:723,t:1526328557057};\\\", \\\"{x:1255,y:716,t:1526328557074};\\\", \\\"{x:1288,y:706,t:1526328557091};\\\", \\\"{x:1341,y:691,t:1526328557107};\\\", \\\"{x:1394,y:675,t:1526328557123};\\\", \\\"{x:1425,y:665,t:1526328557140};\\\", \\\"{x:1445,y:663,t:1526328557157};\\\", \\\"{x:1454,y:662,t:1526328557175};\\\", \\\"{x:1461,y:660,t:1526328557190};\\\", \\\"{x:1462,y:660,t:1526328557207};\\\", \\\"{x:1464,y:660,t:1526328557300};\\\", \\\"{x:1464,y:661,t:1526328557324};\\\", \\\"{x:1457,y:676,t:1526328557340};\\\", \\\"{x:1442,y:692,t:1526328557358};\\\", \\\"{x:1430,y:704,t:1526328557374};\\\", \\\"{x:1416,y:718,t:1526328557391};\\\", \\\"{x:1402,y:730,t:1526328557407};\\\", \\\"{x:1386,y:745,t:1526328557424};\\\", \\\"{x:1370,y:759,t:1526328557441};\\\", \\\"{x:1353,y:773,t:1526328557457};\\\", \\\"{x:1337,y:788,t:1526328557474};\\\", \\\"{x:1320,y:806,t:1526328557491};\\\", \\\"{x:1297,y:828,t:1526328557507};\\\", \\\"{x:1252,y:864,t:1526328557524};\\\", \\\"{x:1234,y:880,t:1526328557540};\\\", \\\"{x:1218,y:895,t:1526328557557};\\\", \\\"{x:1205,y:904,t:1526328557574};\\\", \\\"{x:1199,y:910,t:1526328557590};\\\", \\\"{x:1197,y:914,t:1526328557608};\\\", \\\"{x:1195,y:915,t:1526328557624};\\\", \\\"{x:1195,y:916,t:1526328557692};\\\", \\\"{x:1196,y:917,t:1526328557708};\\\", \\\"{x:1202,y:919,t:1526328557724};\\\", \\\"{x:1207,y:919,t:1526328557740};\\\", \\\"{x:1219,y:917,t:1526328557757};\\\", \\\"{x:1231,y:908,t:1526328557774};\\\", \\\"{x:1241,y:895,t:1526328557791};\\\", \\\"{x:1248,y:875,t:1526328557808};\\\", \\\"{x:1254,y:860,t:1526328557824};\\\", \\\"{x:1258,y:855,t:1526328557841};\\\", \\\"{x:1259,y:850,t:1526328557858};\\\", \\\"{x:1261,y:850,t:1526328558005};\\\", \\\"{x:1264,y:850,t:1526328558012};\\\", \\\"{x:1269,y:850,t:1526328558025};\\\", \\\"{x:1278,y:850,t:1526328558041};\\\", \\\"{x:1291,y:850,t:1526328558058};\\\", \\\"{x:1306,y:853,t:1526328558075};\\\", \\\"{x:1321,y:855,t:1526328558092};\\\", \\\"{x:1330,y:855,t:1526328558108};\\\", \\\"{x:1348,y:856,t:1526328558125};\\\", \\\"{x:1361,y:857,t:1526328558141};\\\", \\\"{x:1377,y:858,t:1526328558158};\\\", \\\"{x:1391,y:859,t:1526328558175};\\\", \\\"{x:1404,y:862,t:1526328558191};\\\", \\\"{x:1415,y:863,t:1526328558208};\\\", \\\"{x:1427,y:866,t:1526328558225};\\\", \\\"{x:1431,y:867,t:1526328558241};\\\", \\\"{x:1434,y:869,t:1526328558258};\\\", \\\"{x:1434,y:870,t:1526328558275};\\\", \\\"{x:1434,y:873,t:1526328558293};\\\", \\\"{x:1434,y:886,t:1526328558309};\\\", \\\"{x:1431,y:900,t:1526328558324};\\\", \\\"{x:1425,y:915,t:1526328558341};\\\", \\\"{x:1419,y:928,t:1526328558357};\\\", \\\"{x:1414,y:939,t:1526328558374};\\\", \\\"{x:1409,y:945,t:1526328558392};\\\", \\\"{x:1407,y:947,t:1526328558407};\\\", \\\"{x:1406,y:948,t:1526328558425};\\\", \\\"{x:1405,y:948,t:1526328558484};\\\", \\\"{x:1404,y:948,t:1526328558492};\\\", \\\"{x:1400,y:946,t:1526328558507};\\\", \\\"{x:1393,y:934,t:1526328558525};\\\", \\\"{x:1390,y:929,t:1526328558542};\\\", \\\"{x:1389,y:924,t:1526328558557};\\\", \\\"{x:1387,y:917,t:1526328558575};\\\", \\\"{x:1387,y:910,t:1526328558591};\\\", \\\"{x:1387,y:901,t:1526328558607};\\\", \\\"{x:1387,y:889,t:1526328558625};\\\", \\\"{x:1387,y:883,t:1526328558641};\\\", \\\"{x:1387,y:882,t:1526328558657};\\\", \\\"{x:1387,y:886,t:1526328558740};\\\", \\\"{x:1381,y:894,t:1526328558748};\\\", \\\"{x:1377,y:899,t:1526328558758};\\\", \\\"{x:1370,y:907,t:1526328558775};\\\", \\\"{x:1357,y:921,t:1526328558791};\\\", \\\"{x:1344,y:934,t:1526328558807};\\\", \\\"{x:1334,y:948,t:1526328558824};\\\", \\\"{x:1329,y:959,t:1526328558841};\\\", \\\"{x:1327,y:965,t:1526328558857};\\\", \\\"{x:1326,y:967,t:1526328558874};\\\", \\\"{x:1326,y:968,t:1526328558892};\\\", \\\"{x:1330,y:968,t:1526328558940};\\\", \\\"{x:1339,y:965,t:1526328558947};\\\", \\\"{x:1345,y:959,t:1526328558957};\\\", \\\"{x:1361,y:945,t:1526328558974};\\\", \\\"{x:1373,y:932,t:1526328558991};\\\", \\\"{x:1380,y:923,t:1526328559009};\\\", \\\"{x:1382,y:921,t:1526328559024};\\\", \\\"{x:1382,y:920,t:1526328559041};\\\", \\\"{x:1382,y:919,t:1526328559058};\\\", \\\"{x:1382,y:918,t:1526328559074};\\\", \\\"{x:1382,y:916,t:1526328559132};\\\", \\\"{x:1384,y:916,t:1526328559148};\\\", \\\"{x:1384,y:915,t:1526328559158};\\\", \\\"{x:1384,y:914,t:1526328559174};\\\", \\\"{x:1385,y:913,t:1526328559191};\\\", \\\"{x:1386,y:911,t:1526328559208};\\\", \\\"{x:1387,y:909,t:1526328559225};\\\", \\\"{x:1388,y:907,t:1526328559242};\\\", \\\"{x:1391,y:908,t:1526328559436};\\\", \\\"{x:1395,y:914,t:1526328559443};\\\", \\\"{x:1400,y:919,t:1526328559458};\\\", \\\"{x:1408,y:931,t:1526328559474};\\\", \\\"{x:1416,y:943,t:1526328559491};\\\", \\\"{x:1425,y:953,t:1526328559507};\\\", \\\"{x:1425,y:954,t:1526328559524};\\\", \\\"{x:1427,y:954,t:1526328564619};\\\", \\\"{x:1429,y:954,t:1526328564627};\\\", \\\"{x:1440,y:954,t:1526328564643};\\\", \\\"{x:1451,y:954,t:1526328564660};\\\", \\\"{x:1460,y:951,t:1526328564677};\\\", \\\"{x:1468,y:946,t:1526328564694};\\\", \\\"{x:1472,y:943,t:1526328564710};\\\", \\\"{x:1475,y:940,t:1526328564727};\\\", \\\"{x:1477,y:938,t:1526328564744};\\\", \\\"{x:1481,y:935,t:1526328564761};\\\", \\\"{x:1485,y:933,t:1526328564777};\\\", \\\"{x:1491,y:930,t:1526328564794};\\\", \\\"{x:1508,y:921,t:1526328564809};\\\", \\\"{x:1519,y:917,t:1526328564827};\\\", \\\"{x:1540,y:904,t:1526328564844};\\\", \\\"{x:1543,y:901,t:1526328564860};\\\", \\\"{x:1545,y:900,t:1526328564877};\\\", \\\"{x:1544,y:900,t:1526328564940};\\\", \\\"{x:1537,y:903,t:1526328564948};\\\", \\\"{x:1517,y:916,t:1526328564961};\\\", \\\"{x:1473,y:934,t:1526328564976};\\\", \\\"{x:1447,y:947,t:1526328564993};\\\", \\\"{x:1431,y:956,t:1526328565010};\\\", \\\"{x:1423,y:960,t:1526328565027};\\\", \\\"{x:1418,y:965,t:1526328565043};\\\", \\\"{x:1412,y:973,t:1526328565060};\\\", \\\"{x:1406,y:982,t:1526328565076};\\\", \\\"{x:1402,y:988,t:1526328565093};\\\", \\\"{x:1397,y:994,t:1526328565111};\\\", \\\"{x:1395,y:998,t:1526328565127};\\\", \\\"{x:1394,y:1000,t:1526328565144};\\\", \\\"{x:1393,y:1002,t:1526328565160};\\\", \\\"{x:1391,y:1009,t:1526328565177};\\\", \\\"{x:1389,y:1014,t:1526328565193};\\\", \\\"{x:1389,y:1018,t:1526328565210};\\\", \\\"{x:1389,y:1019,t:1526328565227};\\\", \\\"{x:1389,y:1018,t:1526328565324};\\\", \\\"{x:1390,y:1013,t:1526328565332};\\\", \\\"{x:1392,y:1007,t:1526328565344};\\\", \\\"{x:1397,y:998,t:1526328565360};\\\", \\\"{x:1400,y:993,t:1526328565377};\\\", \\\"{x:1401,y:991,t:1526328565394};\\\", \\\"{x:1403,y:988,t:1526328565411};\\\", \\\"{x:1403,y:987,t:1526328565427};\\\", \\\"{x:1407,y:983,t:1526328565443};\\\", \\\"{x:1410,y:980,t:1526328565460};\\\", \\\"{x:1414,y:976,t:1526328565477};\\\", \\\"{x:1415,y:975,t:1526328565493};\\\", \\\"{x:1419,y:972,t:1526328565511};\\\", \\\"{x:1425,y:965,t:1526328565527};\\\", \\\"{x:1432,y:957,t:1526328565543};\\\", \\\"{x:1439,y:947,t:1526328565561};\\\", \\\"{x:1447,y:930,t:1526328565577};\\\", \\\"{x:1450,y:924,t:1526328565593};\\\", \\\"{x:1455,y:911,t:1526328565611};\\\", \\\"{x:1456,y:907,t:1526328565627};\\\", \\\"{x:1463,y:883,t:1526328565644};\\\", \\\"{x:1470,y:867,t:1526328565660};\\\", \\\"{x:1482,y:837,t:1526328565677};\\\", \\\"{x:1489,y:816,t:1526328565693};\\\", \\\"{x:1494,y:800,t:1526328565710};\\\", \\\"{x:1496,y:792,t:1526328565727};\\\", \\\"{x:1498,y:789,t:1526328565744};\\\", \\\"{x:1498,y:787,t:1526328565761};\\\", \\\"{x:1499,y:784,t:1526328565776};\\\", \\\"{x:1500,y:782,t:1526328565794};\\\", \\\"{x:1501,y:777,t:1526328565810};\\\", \\\"{x:1505,y:768,t:1526328565827};\\\", \\\"{x:1510,y:761,t:1526328565844};\\\", \\\"{x:1511,y:757,t:1526328565861};\\\", \\\"{x:1514,y:753,t:1526328565876};\\\", \\\"{x:1515,y:750,t:1526328565893};\\\", \\\"{x:1517,y:748,t:1526328565910};\\\", \\\"{x:1517,y:747,t:1526328565931};\\\", \\\"{x:1517,y:746,t:1526328565943};\\\", \\\"{x:1518,y:743,t:1526328565961};\\\", \\\"{x:1519,y:743,t:1526328565977};\\\", \\\"{x:1520,y:741,t:1526328565993};\\\", \\\"{x:1520,y:740,t:1526328566010};\\\", \\\"{x:1522,y:738,t:1526328566027};\\\", \\\"{x:1522,y:737,t:1526328566044};\\\", \\\"{x:1522,y:738,t:1526328570172};\\\", \\\"{x:1516,y:752,t:1526328570179};\\\", \\\"{x:1506,y:767,t:1526328570195};\\\", \\\"{x:1493,y:785,t:1526328570212};\\\", \\\"{x:1480,y:811,t:1526328570228};\\\", \\\"{x:1463,y:841,t:1526328570246};\\\", \\\"{x:1446,y:868,t:1526328570262};\\\", \\\"{x:1419,y:903,t:1526328570279};\\\", \\\"{x:1402,y:927,t:1526328570296};\\\", \\\"{x:1384,y:952,t:1526328570312};\\\", \\\"{x:1366,y:974,t:1526328570329};\\\", \\\"{x:1348,y:996,t:1526328570346};\\\", \\\"{x:1303,y:1035,t:1526328570362};\\\", \\\"{x:1259,y:1062,t:1526328570379};\\\", \\\"{x:1237,y:1077,t:1526328570396};\\\", \\\"{x:1235,y:1077,t:1526328570412};\\\", \\\"{x:1235,y:1074,t:1526328570668};\\\", \\\"{x:1235,y:1073,t:1526328570679};\\\", \\\"{x:1235,y:1071,t:1526328570696};\\\", \\\"{x:1235,y:1069,t:1526328570711};\\\", \\\"{x:1235,y:1065,t:1526328570729};\\\", \\\"{x:1234,y:1062,t:1526328570746};\\\", \\\"{x:1231,y:1057,t:1526328570762};\\\", \\\"{x:1226,y:1052,t:1526328570780};\\\", \\\"{x:1208,y:1041,t:1526328570796};\\\", \\\"{x:1189,y:1030,t:1526328570812};\\\", \\\"{x:1162,y:1019,t:1526328570828};\\\", \\\"{x:1117,y:1006,t:1526328570846};\\\", \\\"{x:1060,y:987,t:1526328570863};\\\", \\\"{x:1011,y:968,t:1526328570879};\\\", \\\"{x:966,y:955,t:1526328570896};\\\", \\\"{x:924,y:942,t:1526328570912};\\\", \\\"{x:903,y:936,t:1526328570928};\\\", \\\"{x:894,y:934,t:1526328570946};\\\", \\\"{x:893,y:934,t:1526328570971};\\\", \\\"{x:893,y:933,t:1526328571027};\\\", \\\"{x:894,y:933,t:1526328571036};\\\", \\\"{x:900,y:933,t:1526328571045};\\\", \\\"{x:921,y:933,t:1526328571063};\\\", \\\"{x:950,y:928,t:1526328571079};\\\", \\\"{x:976,y:928,t:1526328571096};\\\", \\\"{x:1010,y:925,t:1526328571113};\\\", \\\"{x:1038,y:925,t:1526328571128};\\\", \\\"{x:1064,y:925,t:1526328571146};\\\", \\\"{x:1085,y:921,t:1526328571163};\\\", \\\"{x:1107,y:919,t:1526328571179};\\\", \\\"{x:1133,y:914,t:1526328571195};\\\", \\\"{x:1143,y:913,t:1526328571213};\\\", \\\"{x:1159,y:909,t:1526328571228};\\\", \\\"{x:1180,y:906,t:1526328571246};\\\", \\\"{x:1199,y:904,t:1526328571262};\\\", \\\"{x:1227,y:899,t:1526328571278};\\\", \\\"{x:1263,y:897,t:1526328571295};\\\", \\\"{x:1318,y:890,t:1526328571313};\\\", \\\"{x:1379,y:882,t:1526328571329};\\\", \\\"{x:1457,y:873,t:1526328571346};\\\", \\\"{x:1554,y:858,t:1526328571363};\\\", \\\"{x:1664,y:848,t:1526328571378};\\\", \\\"{x:1816,y:824,t:1526328571396};\\\", \\\"{x:1869,y:817,t:1526328571413};\\\", \\\"{x:1876,y:816,t:1526328571429};\\\", \\\"{x:1877,y:816,t:1526328571507};\\\", \\\"{x:1876,y:816,t:1526328571515};\\\", \\\"{x:1864,y:816,t:1526328571529};\\\", \\\"{x:1830,y:833,t:1526328571546};\\\", \\\"{x:1742,y:874,t:1526328571563};\\\", \\\"{x:1637,y:922,t:1526328571579};\\\", \\\"{x:1549,y:959,t:1526328571595};\\\", \\\"{x:1529,y:971,t:1526328571613};\\\", \\\"{x:1518,y:979,t:1526328571629};\\\", \\\"{x:1507,y:987,t:1526328571646};\\\", \\\"{x:1502,y:994,t:1526328571663};\\\", \\\"{x:1490,y:1006,t:1526328571679};\\\", \\\"{x:1475,y:1020,t:1526328571696};\\\", \\\"{x:1457,y:1032,t:1526328571713};\\\", \\\"{x:1449,y:1038,t:1526328571728};\\\", \\\"{x:1447,y:1038,t:1526328571746};\\\", \\\"{x:1445,y:1038,t:1526328571843};\\\", \\\"{x:1442,y:1037,t:1526328571851};\\\", \\\"{x:1439,y:1036,t:1526328571863};\\\", \\\"{x:1436,y:1034,t:1526328571880};\\\", \\\"{x:1433,y:1031,t:1526328571895};\\\", \\\"{x:1430,y:1029,t:1526328571913};\\\", \\\"{x:1428,y:1027,t:1526328571929};\\\", \\\"{x:1427,y:1026,t:1526328571946};\\\", \\\"{x:1425,y:1024,t:1526328571963};\\\", \\\"{x:1423,y:1018,t:1526328571979};\\\", \\\"{x:1421,y:1013,t:1526328571996};\\\", \\\"{x:1417,y:1005,t:1526328572012};\\\", \\\"{x:1413,y:994,t:1526328572030};\\\", \\\"{x:1410,y:987,t:1526328572046};\\\", \\\"{x:1408,y:982,t:1526328572063};\\\", \\\"{x:1407,y:977,t:1526328572080};\\\", \\\"{x:1406,y:975,t:1526328572096};\\\", \\\"{x:1406,y:973,t:1526328572156};\\\", \\\"{x:1407,y:973,t:1526328572164};\\\", \\\"{x:1413,y:971,t:1526328572180};\\\", \\\"{x:1425,y:967,t:1526328572196};\\\", \\\"{x:1431,y:967,t:1526328572212};\\\", \\\"{x:1444,y:966,t:1526328572230};\\\", \\\"{x:1455,y:966,t:1526328572245};\\\", \\\"{x:1458,y:966,t:1526328572263};\\\", \\\"{x:1460,y:966,t:1526328572280};\\\", \\\"{x:1459,y:966,t:1526328572507};\\\", \\\"{x:1457,y:966,t:1526328572515};\\\", \\\"{x:1455,y:966,t:1526328572532};\\\", \\\"{x:1452,y:966,t:1526328572546};\\\", \\\"{x:1446,y:967,t:1526328572563};\\\", \\\"{x:1437,y:970,t:1526328572579};\\\", \\\"{x:1433,y:972,t:1526328572596};\\\", \\\"{x:1431,y:972,t:1526328572612};\\\", \\\"{x:1430,y:972,t:1526328572629};\\\", \\\"{x:1428,y:972,t:1526328572740};\\\", \\\"{x:1426,y:972,t:1526328572747};\\\", \\\"{x:1423,y:972,t:1526328572763};\\\", \\\"{x:1411,y:972,t:1526328572779};\\\", \\\"{x:1404,y:971,t:1526328572797};\\\", \\\"{x:1400,y:970,t:1526328572813};\\\", \\\"{x:1399,y:970,t:1526328572830};\\\", \\\"{x:1396,y:967,t:1526328572847};\\\", \\\"{x:1390,y:960,t:1526328572862};\\\", \\\"{x:1377,y:947,t:1526328572880};\\\", \\\"{x:1353,y:922,t:1526328572897};\\\", \\\"{x:1321,y:891,t:1526328572913};\\\", \\\"{x:1290,y:869,t:1526328572930};\\\", \\\"{x:1270,y:856,t:1526328572946};\\\", \\\"{x:1258,y:850,t:1526328572963};\\\", \\\"{x:1256,y:849,t:1526328572980};\\\", \\\"{x:1255,y:848,t:1526328572997};\\\", \\\"{x:1254,y:848,t:1526328573019};\\\", \\\"{x:1252,y:846,t:1526328573030};\\\", \\\"{x:1240,y:835,t:1526328573047};\\\", \\\"{x:1226,y:819,t:1526328573063};\\\", \\\"{x:1218,y:808,t:1526328573080};\\\", \\\"{x:1209,y:794,t:1526328573097};\\\", \\\"{x:1199,y:778,t:1526328573113};\\\", \\\"{x:1185,y:759,t:1526328573130};\\\", \\\"{x:1170,y:734,t:1526328573148};\\\", \\\"{x:1155,y:716,t:1526328573163};\\\", \\\"{x:1141,y:698,t:1526328573180};\\\", \\\"{x:1140,y:696,t:1526328573196};\\\", \\\"{x:1140,y:695,t:1526328573459};\\\", \\\"{x:1146,y:695,t:1526328573468};\\\", \\\"{x:1151,y:695,t:1526328573480};\\\", \\\"{x:1165,y:698,t:1526328573497};\\\", \\\"{x:1176,y:698,t:1526328573513};\\\", \\\"{x:1194,y:700,t:1526328573530};\\\", \\\"{x:1209,y:700,t:1526328573547};\\\", \\\"{x:1221,y:700,t:1526328573563};\\\", \\\"{x:1232,y:700,t:1526328573579};\\\", \\\"{x:1233,y:700,t:1526328573597};\\\", \\\"{x:1234,y:700,t:1526328573613};\\\", \\\"{x:1235,y:700,t:1526328573636};\\\", \\\"{x:1236,y:700,t:1526328573647};\\\", \\\"{x:1239,y:700,t:1526328573663};\\\", \\\"{x:1243,y:699,t:1526328573680};\\\", \\\"{x:1246,y:698,t:1526328573697};\\\", \\\"{x:1251,y:698,t:1526328573713};\\\", \\\"{x:1257,y:698,t:1526328573730};\\\", \\\"{x:1269,y:698,t:1526328573747};\\\", \\\"{x:1282,y:698,t:1526328573763};\\\", \\\"{x:1308,y:698,t:1526328573780};\\\", \\\"{x:1326,y:698,t:1526328573797};\\\", \\\"{x:1335,y:698,t:1526328573813};\\\", \\\"{x:1343,y:696,t:1526328573830};\\\", \\\"{x:1347,y:694,t:1526328573847};\\\", \\\"{x:1352,y:693,t:1526328573863};\\\", \\\"{x:1360,y:690,t:1526328573880};\\\", \\\"{x:1370,y:689,t:1526328573897};\\\", \\\"{x:1379,y:689,t:1526328573914};\\\", \\\"{x:1383,y:689,t:1526328573930};\\\", \\\"{x:1389,y:689,t:1526328573947};\\\", \\\"{x:1393,y:690,t:1526328573963};\\\", \\\"{x:1394,y:690,t:1526328574299};\\\", \\\"{x:1395,y:691,t:1526328574314};\\\", \\\"{x:1402,y:692,t:1526328574330};\\\", \\\"{x:1418,y:697,t:1526328574347};\\\", \\\"{x:1442,y:702,t:1526328574364};\\\", \\\"{x:1462,y:706,t:1526328574380};\\\", \\\"{x:1476,y:707,t:1526328574397};\\\", \\\"{x:1481,y:709,t:1526328574414};\\\", \\\"{x:1484,y:709,t:1526328574430};\\\", \\\"{x:1485,y:709,t:1526328574447};\\\", \\\"{x:1487,y:709,t:1526328574508};\\\", \\\"{x:1488,y:709,t:1526328574523};\\\", \\\"{x:1490,y:709,t:1526328574531};\\\", \\\"{x:1491,y:709,t:1526328574546};\\\", \\\"{x:1499,y:709,t:1526328574563};\\\", \\\"{x:1502,y:709,t:1526328574580};\\\", \\\"{x:1510,y:709,t:1526328574597};\\\", \\\"{x:1525,y:709,t:1526328574614};\\\", \\\"{x:1549,y:709,t:1526328574630};\\\", \\\"{x:1576,y:709,t:1526328574647};\\\", \\\"{x:1597,y:709,t:1526328574664};\\\", \\\"{x:1610,y:709,t:1526328574680};\\\", \\\"{x:1618,y:709,t:1526328574697};\\\", \\\"{x:1624,y:709,t:1526328574714};\\\", \\\"{x:1628,y:708,t:1526328574730};\\\", \\\"{x:1630,y:708,t:1526328574747};\\\", \\\"{x:1631,y:707,t:1526328574868};\\\", \\\"{x:1631,y:706,t:1526328574881};\\\", \\\"{x:1631,y:705,t:1526328574897};\\\", \\\"{x:1632,y:704,t:1526328574914};\\\", \\\"{x:1632,y:701,t:1526328574931};\\\", \\\"{x:1632,y:697,t:1526328574947};\\\", \\\"{x:1634,y:692,t:1526328574963};\\\", \\\"{x:1635,y:689,t:1526328574981};\\\", \\\"{x:1635,y:685,t:1526328574997};\\\", \\\"{x:1635,y:684,t:1526328575028};\\\", \\\"{x:1635,y:685,t:1526328575115};\\\", \\\"{x:1635,y:686,t:1526328575131};\\\", \\\"{x:1628,y:698,t:1526328575147};\\\", \\\"{x:1605,y:721,t:1526328575163};\\\", \\\"{x:1584,y:749,t:1526328575181};\\\", \\\"{x:1557,y:778,t:1526328575197};\\\", \\\"{x:1527,y:813,t:1526328575214};\\\", \\\"{x:1499,y:848,t:1526328575231};\\\", \\\"{x:1473,y:879,t:1526328575247};\\\", \\\"{x:1460,y:899,t:1526328575264};\\\", \\\"{x:1446,y:920,t:1526328575281};\\\", \\\"{x:1441,y:932,t:1526328575297};\\\", \\\"{x:1438,y:950,t:1526328575314};\\\", \\\"{x:1429,y:969,t:1526328575331};\\\", \\\"{x:1424,y:981,t:1526328575347};\\\", \\\"{x:1419,y:990,t:1526328575364};\\\", \\\"{x:1419,y:992,t:1526328575381};\\\", \\\"{x:1420,y:990,t:1526328575412};\\\", \\\"{x:1422,y:983,t:1526328575420};\\\", \\\"{x:1426,y:970,t:1526328575431};\\\", \\\"{x:1434,y:939,t:1526328575447};\\\", \\\"{x:1445,y:882,t:1526328575464};\\\", \\\"{x:1448,y:809,t:1526328575481};\\\", \\\"{x:1448,y:761,t:1526328575497};\\\", \\\"{x:1448,y:731,t:1526328575514};\\\", \\\"{x:1448,y:716,t:1526328575531};\\\", \\\"{x:1448,y:707,t:1526328575547};\\\", \\\"{x:1447,y:702,t:1526328575564};\\\", \\\"{x:1446,y:701,t:1526328575604};\\\", \\\"{x:1441,y:699,t:1526328575620};\\\", \\\"{x:1438,y:698,t:1526328575631};\\\", \\\"{x:1424,y:692,t:1526328575647};\\\", \\\"{x:1412,y:687,t:1526328575664};\\\", \\\"{x:1407,y:683,t:1526328575681};\\\", \\\"{x:1406,y:682,t:1526328575697};\\\", \\\"{x:1405,y:682,t:1526328575714};\\\", \\\"{x:1405,y:681,t:1526328575731};\\\", \\\"{x:1404,y:681,t:1526328575747};\\\", \\\"{x:1392,y:686,t:1526328575764};\\\", \\\"{x:1379,y:695,t:1526328575781};\\\", \\\"{x:1370,y:701,t:1526328575798};\\\", \\\"{x:1365,y:701,t:1526328575814};\\\", \\\"{x:1364,y:701,t:1526328575843};\\\", \\\"{x:1363,y:702,t:1526328575948};\\\", \\\"{x:1347,y:715,t:1526328575964};\\\", \\\"{x:1303,y:745,t:1526328575981};\\\", \\\"{x:1215,y:799,t:1526328575998};\\\", \\\"{x:1126,y:859,t:1526328576014};\\\", \\\"{x:1066,y:907,t:1526328576031};\\\", \\\"{x:1038,y:936,t:1526328576048};\\\", \\\"{x:1026,y:951,t:1526328576064};\\\", \\\"{x:1022,y:955,t:1526328576081};\\\", \\\"{x:1022,y:959,t:1526328576098};\\\", \\\"{x:1020,y:962,t:1526328576114};\\\", \\\"{x:1024,y:956,t:1526328576188};\\\", \\\"{x:1028,y:950,t:1526328576198};\\\", \\\"{x:1038,y:927,t:1526328576214};\\\", \\\"{x:1058,y:885,t:1526328576231};\\\", \\\"{x:1083,y:832,t:1526328576248};\\\", \\\"{x:1105,y:775,t:1526328576264};\\\", \\\"{x:1121,y:753,t:1526328576281};\\\", \\\"{x:1136,y:734,t:1526328576298};\\\", \\\"{x:1146,y:721,t:1526328576314};\\\", \\\"{x:1153,y:712,t:1526328576331};\\\", \\\"{x:1161,y:703,t:1526328576347};\\\", \\\"{x:1164,y:701,t:1526328576364};\\\", \\\"{x:1166,y:699,t:1526328576381};\\\", \\\"{x:1166,y:697,t:1526328576398};\\\", \\\"{x:1157,y:709,t:1526328576475};\\\", \\\"{x:1142,y:729,t:1526328576483};\\\", \\\"{x:1124,y:752,t:1526328576498};\\\", \\\"{x:1081,y:821,t:1526328576515};\\\", \\\"{x:1050,y:877,t:1526328576531};\\\", \\\"{x:1047,y:887,t:1526328576547};\\\", \\\"{x:1048,y:888,t:1526328576564};\\\", \\\"{x:1052,y:888,t:1526328576581};\\\", \\\"{x:1066,y:887,t:1526328576597};\\\", \\\"{x:1083,y:877,t:1526328576614};\\\", \\\"{x:1112,y:858,t:1526328576631};\\\", \\\"{x:1156,y:831,t:1526328576648};\\\", \\\"{x:1217,y:794,t:1526328576664};\\\", \\\"{x:1268,y:766,t:1526328576681};\\\", \\\"{x:1296,y:748,t:1526328576698};\\\", \\\"{x:1303,y:744,t:1526328576714};\\\", \\\"{x:1299,y:748,t:1526328576740};\\\", \\\"{x:1287,y:766,t:1526328576748};\\\", \\\"{x:1233,y:856,t:1526328576765};\\\", \\\"{x:1144,y:994,t:1526328576781};\\\", \\\"{x:1056,y:1113,t:1526328576799};\\\", \\\"{x:1011,y:1195,t:1526328576815};\\\", \\\"{x:1006,y:1199,t:1526328576830};\\\", \\\"{x:1007,y:1199,t:1526328576844};\\\", \\\"{x:1015,y:1199,t:1526328576861};\\\", \\\"{x:1030,y:1199,t:1526328576877};\\\", \\\"{x:1037,y:1199,t:1526328576894};\\\", \\\"{x:1041,y:1199,t:1526328576911};\\\", \\\"{x:1059,y:1197,t:1526328576927};\\\", \\\"{x:1110,y:1173,t:1526328576945};\\\", \\\"{x:1206,y:1122,t:1526328576961};\\\", \\\"{x:1337,y:1025,t:1526328576982};\\\", \\\"{x:1404,y:953,t:1526328576997};\\\", \\\"{x:1454,y:873,t:1526328577014};\\\", \\\"{x:1484,y:811,t:1526328577031};\\\", \\\"{x:1503,y:767,t:1526328577047};\\\", \\\"{x:1509,y:742,t:1526328577065};\\\", \\\"{x:1511,y:729,t:1526328577081};\\\", \\\"{x:1511,y:722,t:1526328577098};\\\", \\\"{x:1511,y:719,t:1526328577114};\\\", \\\"{x:1511,y:718,t:1526328577131};\\\", \\\"{x:1511,y:717,t:1526328577180};\\\", \\\"{x:1511,y:716,t:1526328577195};\\\", \\\"{x:1511,y:715,t:1526328577211};\\\", \\\"{x:1511,y:714,t:1526328577219};\\\", \\\"{x:1511,y:713,t:1526328577231};\\\", \\\"{x:1513,y:711,t:1526328577259};\\\", \\\"{x:1513,y:718,t:1526328577299};\\\", \\\"{x:1510,y:732,t:1526328577314};\\\", \\\"{x:1466,y:849,t:1526328577331};\\\", \\\"{x:1400,y:976,t:1526328577347};\\\", \\\"{x:1327,y:1095,t:1526328577364};\\\", \\\"{x:1285,y:1158,t:1526328577381};\\\", \\\"{x:1275,y:1172,t:1526328577398};\\\", \\\"{x:1273,y:1174,t:1526328577414};\\\", \\\"{x:1273,y:1176,t:1526328577431};\\\", \\\"{x:1268,y:1173,t:1526328577492};\\\", \\\"{x:1260,y:1166,t:1526328577500};\\\", \\\"{x:1244,y:1151,t:1526328577514};\\\", \\\"{x:1177,y:1104,t:1526328577531};\\\", \\\"{x:1012,y:1005,t:1526328577547};\\\", \\\"{x:854,y:921,t:1526328577564};\\\", \\\"{x:697,y:849,t:1526328577581};\\\", \\\"{x:546,y:789,t:1526328577598};\\\", \\\"{x:423,y:745,t:1526328577614};\\\", \\\"{x:345,y:711,t:1526328577631};\\\", \\\"{x:313,y:696,t:1526328577648};\\\", \\\"{x:298,y:689,t:1526328577665};\\\", \\\"{x:296,y:687,t:1526328577681};\\\", \\\"{x:296,y:686,t:1526328577698};\\\", \\\"{x:297,y:685,t:1526328577715};\\\", \\\"{x:298,y:684,t:1526328577731};\\\", \\\"{x:298,y:683,t:1526328577748};\\\", \\\"{x:299,y:683,t:1526328577771};\\\", \\\"{x:299,y:682,t:1526328577781};\\\", \\\"{x:299,y:678,t:1526328577798};\\\", \\\"{x:299,y:669,t:1526328577815};\\\", \\\"{x:299,y:663,t:1526328577831};\\\", \\\"{x:299,y:662,t:1526328577848};\\\", \\\"{x:301,y:659,t:1526328577867};\\\", \\\"{x:304,y:659,t:1526328577881};\\\", \\\"{x:315,y:658,t:1526328577902};\\\", \\\"{x:339,y:654,t:1526328577917};\\\", \\\"{x:384,y:652,t:1526328577935};\\\", \\\"{x:460,y:650,t:1526328577952};\\\", \\\"{x:491,y:646,t:1526328577969};\\\", \\\"{x:504,y:641,t:1526328577985};\\\", \\\"{x:512,y:637,t:1526328578001};\\\", \\\"{x:518,y:632,t:1526328578019};\\\", \\\"{x:519,y:631,t:1526328578037};\\\", \\\"{x:520,y:628,t:1526328578052};\\\", \\\"{x:520,y:624,t:1526328578069};\\\", \\\"{x:519,y:613,t:1526328578086};\\\", \\\"{x:515,y:604,t:1526328578102};\\\", \\\"{x:512,y:588,t:1526328578119};\\\", \\\"{x:507,y:578,t:1526328578135};\\\", \\\"{x:502,y:559,t:1526328578152};\\\", \\\"{x:498,y:552,t:1526328578169};\\\", \\\"{x:498,y:547,t:1526328578186};\\\", \\\"{x:498,y:546,t:1526328578202};\\\", \\\"{x:500,y:541,t:1526328578220};\\\", \\\"{x:502,y:538,t:1526328578236};\\\", \\\"{x:516,y:533,t:1526328578251};\\\", \\\"{x:540,y:532,t:1526328578269};\\\", \\\"{x:566,y:531,t:1526328578285};\\\", \\\"{x:620,y:531,t:1526328578303};\\\", \\\"{x:633,y:531,t:1526328578318};\\\", \\\"{x:639,y:531,t:1526328578335};\\\", \\\"{x:640,y:531,t:1526328578367};\\\", \\\"{x:640,y:532,t:1526328578375};\\\", \\\"{x:640,y:535,t:1526328578386};\\\", \\\"{x:637,y:545,t:1526328578402};\\\", \\\"{x:635,y:562,t:1526328578419};\\\", \\\"{x:632,y:581,t:1526328578436};\\\", \\\"{x:633,y:587,t:1526328578451};\\\", \\\"{x:633,y:588,t:1526328578469};\\\", \\\"{x:635,y:588,t:1526328578485};\\\", \\\"{x:630,y:585,t:1526328578519};\\\", \\\"{x:601,y:578,t:1526328578536};\\\", \\\"{x:570,y:569,t:1526328578552};\\\", \\\"{x:552,y:566,t:1526328578568};\\\", \\\"{x:548,y:564,t:1526328578585};\\\", \\\"{x:548,y:563,t:1526328578601};\\\", \\\"{x:551,y:563,t:1526328578639};\\\", \\\"{x:554,y:563,t:1526328578652};\\\", \\\"{x:572,y:565,t:1526328578669};\\\", \\\"{x:590,y:570,t:1526328578684};\\\", \\\"{x:604,y:570,t:1526328578702};\\\", \\\"{x:611,y:571,t:1526328578718};\\\", \\\"{x:612,y:571,t:1526328578751};\\\", \\\"{x:613,y:571,t:1526328578775};\\\", \\\"{x:614,y:571,t:1526328578791};\\\", \\\"{x:616,y:572,t:1526328578803};\\\", \\\"{x:617,y:572,t:1526328578820};\\\", \\\"{x:618,y:572,t:1526328578836};\\\", \\\"{x:626,y:573,t:1526328579103};\\\", \\\"{x:652,y:576,t:1526328579120};\\\", \\\"{x:683,y:576,t:1526328579135};\\\", \\\"{x:711,y:576,t:1526328579152};\\\", \\\"{x:733,y:576,t:1526328579170};\\\", \\\"{x:744,y:576,t:1526328579186};\\\", \\\"{x:750,y:576,t:1526328579202};\\\", \\\"{x:754,y:576,t:1526328579220};\\\", \\\"{x:757,y:574,t:1526328579236};\\\", \\\"{x:758,y:574,t:1526328579252};\\\", \\\"{x:761,y:574,t:1526328579270};\\\", \\\"{x:765,y:573,t:1526328579287};\\\", \\\"{x:765,y:572,t:1526328579303};\\\", \\\"{x:768,y:572,t:1526328579320};\\\", \\\"{x:770,y:570,t:1526328579337};\\\", \\\"{x:772,y:569,t:1526328579353};\\\", \\\"{x:779,y:567,t:1526328579370};\\\", \\\"{x:788,y:566,t:1526328579387};\\\", \\\"{x:797,y:566,t:1526328579403};\\\", \\\"{x:803,y:566,t:1526328579420};\\\", \\\"{x:804,y:566,t:1526328579437};\\\", \\\"{x:806,y:566,t:1526328579560};\\\", \\\"{x:807,y:566,t:1526328579590};\\\", \\\"{x:808,y:566,t:1526328579603};\\\", \\\"{x:810,y:567,t:1526328579647};\\\", \\\"{x:812,y:567,t:1526328579663};\\\", \\\"{x:814,y:568,t:1526328579671};\\\", \\\"{x:818,y:570,t:1526328579686};\\\", \\\"{x:820,y:570,t:1526328579704};\\\", \\\"{x:821,y:570,t:1526328579719};\\\", \\\"{x:821,y:571,t:1526328579823};\\\", \\\"{x:822,y:573,t:1526328579837};\\\", \\\"{x:825,y:574,t:1526328579854};\\\", \\\"{x:828,y:575,t:1526328579871};\\\", \\\"{x:829,y:575,t:1526328580160};\\\", \\\"{x:827,y:577,t:1526328580170};\\\", \\\"{x:819,y:580,t:1526328580187};\\\", \\\"{x:805,y:586,t:1526328580204};\\\", \\\"{x:785,y:598,t:1526328580220};\\\", \\\"{x:760,y:620,t:1526328580237};\\\", \\\"{x:740,y:647,t:1526328580254};\\\", \\\"{x:706,y:695,t:1526328580270};\\\", \\\"{x:695,y:708,t:1526328580286};\\\", \\\"{x:689,y:713,t:1526328580303};\\\", \\\"{x:688,y:714,t:1526328580321};\\\", \\\"{x:685,y:716,t:1526328580337};\\\", \\\"{x:682,y:716,t:1526328580354};\\\", \\\"{x:669,y:716,t:1526328580371};\\\", \\\"{x:652,y:716,t:1526328580387};\\\", \\\"{x:632,y:714,t:1526328580404};\\\", \\\"{x:614,y:713,t:1526328580421};\\\", \\\"{x:600,y:711,t:1526328580437};\\\", \\\"{x:591,y:710,t:1526328580454};\\\", \\\"{x:573,y:705,t:1526328580471};\\\", \\\"{x:554,y:699,t:1526328580488};\\\", \\\"{x:534,y:694,t:1526328580504};\\\", \\\"{x:508,y:686,t:1526328580521};\\\", \\\"{x:476,y:679,t:1526328580538};\\\", \\\"{x:449,y:675,t:1526328580553};\\\", \\\"{x:426,y:675,t:1526328580570};\\\", \\\"{x:408,y:675,t:1526328580588};\\\", \\\"{x:396,y:675,t:1526328580603};\\\", \\\"{x:384,y:678,t:1526328580620};\\\", \\\"{x:372,y:683,t:1526328580638};\\\", \\\"{x:353,y:696,t:1526328580654};\\\", \\\"{x:335,y:713,t:1526328580671};\\\", \\\"{x:334,y:718,t:1526328580687};\\\", \\\"{x:334,y:720,t:1526328580704};\\\", \\\"{x:341,y:721,t:1526328580720};\\\", \\\"{x:347,y:722,t:1526328580738};\\\", \\\"{x:356,y:722,t:1526328580753};\\\", \\\"{x:370,y:724,t:1526328580771};\\\", \\\"{x:389,y:727,t:1526328580788};\\\", \\\"{x:403,y:732,t:1526328580803};\\\", \\\"{x:425,y:741,t:1526328580821};\\\", \\\"{x:453,y:750,t:1526328580839};\\\", \\\"{x:485,y:766,t:1526328580855};\\\", \\\"{x:502,y:770,t:1526328580870};\\\", \\\"{x:511,y:772,t:1526328580887};\\\", \\\"{x:514,y:772,t:1526328580904};\\\", \\\"{x:514,y:771,t:1526328581119};\\\", \\\"{x:514,y:770,t:1526328581127};\\\", \\\"{x:513,y:767,t:1526328581137};\\\", \\\"{x:513,y:763,t:1526328581154};\\\", \\\"{x:511,y:760,t:1526328581171};\\\", \\\"{x:511,y:759,t:1526328581295};\\\", \\\"{x:511,y:757,t:1526328581304};\\\", \\\"{x:511,y:754,t:1526328581322};\\\", \\\"{x:511,y:753,t:1526328581338};\\\", \\\"{x:510,y:750,t:1526328581354};\\\", \\\"{x:509,y:749,t:1526328581370};\\\", \\\"{x:506,y:746,t:1526328581387};\\\", \\\"{x:506,y:745,t:1526328581407};\\\", \\\"{x:505,y:743,t:1526328581421};\\\", \\\"{x:499,y:732,t:1526328581437};\\\", \\\"{x:496,y:728,t:1526328581454};\\\", \\\"{x:494,y:721,t:1526328581471};\\\", \\\"{x:493,y:718,t:1526328581487};\\\", \\\"{x:493,y:722,t:1526328585480};\\\", \\\"{x:496,y:742,t:1526328585491};\\\", \\\"{x:506,y:773,t:1526328585508};\\\", \\\"{x:508,y:780,t:1526328585524};\\\", \\\"{x:509,y:780,t:1526328585567};\\\", \\\"{x:511,y:779,t:1526328585582};\\\", \\\"{x:512,y:777,t:1526328585591};\\\", \\\"{x:514,y:773,t:1526328585608};\\\", \\\"{x:517,y:767,t:1526328585625};\\\", \\\"{x:521,y:762,t:1526328585641};\\\", \\\"{x:524,y:756,t:1526328585658};\\\", \\\"{x:526,y:754,t:1526328585675};\\\", \\\"{x:527,y:747,t:1526328585691};\\\", \\\"{x:528,y:745,t:1526328585708};\\\", \\\"{x:528,y:741,t:1526328585725};\\\", \\\"{x:529,y:738,t:1526328585741};\\\", \\\"{x:529,y:737,t:1526328585758};\\\", \\\"{x:529,y:734,t:1526328585774};\\\", \\\"{x:529,y:733,t:1526328585792};\\\", \\\"{x:529,y:731,t:1526328585808};\\\", \\\"{x:529,y:730,t:1526328585847};\\\", \\\"{x:529,y:729,t:1526328585943};\\\", \\\"{x:532,y:728,t:1526328587239};\\\", \\\"{x:534,y:728,t:1526328587246};\\\", \\\"{x:535,y:729,t:1526328587259};\\\", \\\"{x:536,y:729,t:1526328587279};\\\", \\\"{x:538,y:729,t:1526328587293};\\\", \\\"{x:539,y:731,t:1526328587309};\\\", \\\"{x:541,y:731,t:1526328587326};\\\", \\\"{x:551,y:740,t:1526328587342};\\\", \\\"{x:569,y:751,t:1526328587359};\\\", \\\"{x:597,y:763,t:1526328587376};\\\", \\\"{x:635,y:779,t:1526328587393};\\\", \\\"{x:665,y:786,t:1526328587409};\\\", \\\"{x:684,y:790,t:1526328587426};\\\", \\\"{x:693,y:794,t:1526328587443};\\\", \\\"{x:697,y:795,t:1526328587459};\\\", \\\"{x:698,y:795,t:1526328587476};\\\", \\\"{x:701,y:795,t:1526328587493};\\\", \\\"{x:703,y:795,t:1526328587509};\\\", \\\"{x:704,y:795,t:1526328587526};\\\", \\\"{x:705,y:796,t:1526328587543};\\\", \\\"{x:706,y:797,t:1526328587623};\\\" ] }, { \\\"rt\\\": 51390, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 481202, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -O -C -C -C -G -G -G -F -10 AM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:698,y:793,t:1526328600383};\\\", \\\"{x:673,y:787,t:1526328600399};\\\", \\\"{x:659,y:784,t:1526328600406};\\\", \\\"{x:648,y:780,t:1526328600419};\\\", \\\"{x:618,y:773,t:1526328600435};\\\", \\\"{x:583,y:761,t:1526328600453};\\\", \\\"{x:553,y:753,t:1526328600469};\\\", \\\"{x:524,y:744,t:1526328600485};\\\", \\\"{x:485,y:731,t:1526328600495};\\\", \\\"{x:430,y:711,t:1526328600512};\\\", \\\"{x:355,y:685,t:1526328600528};\\\", \\\"{x:293,y:665,t:1526328600546};\\\", \\\"{x:232,y:649,t:1526328600562};\\\", \\\"{x:151,y:627,t:1526328600587};\\\", \\\"{x:129,y:621,t:1526328600604};\\\", \\\"{x:122,y:619,t:1526328600620};\\\", \\\"{x:122,y:618,t:1526328600639};\\\", \\\"{x:122,y:617,t:1526328600654};\\\", \\\"{x:121,y:616,t:1526328600670};\\\", \\\"{x:120,y:615,t:1526328600687};\\\", \\\"{x:120,y:612,t:1526328600711};\\\", \\\"{x:120,y:610,t:1526328600720};\\\", \\\"{x:124,y:598,t:1526328600737};\\\", \\\"{x:132,y:586,t:1526328600754};\\\", \\\"{x:141,y:575,t:1526328600770};\\\", \\\"{x:151,y:561,t:1526328600787};\\\", \\\"{x:165,y:550,t:1526328600804};\\\", \\\"{x:192,y:527,t:1526328600820};\\\", \\\"{x:208,y:516,t:1526328600837};\\\", \\\"{x:223,y:505,t:1526328600854};\\\", \\\"{x:240,y:494,t:1526328600870};\\\", \\\"{x:252,y:485,t:1526328600887};\\\", \\\"{x:266,y:471,t:1526328600903};\\\", \\\"{x:270,y:467,t:1526328600920};\\\", \\\"{x:273,y:467,t:1526328600959};\\\", \\\"{x:274,y:467,t:1526328600970};\\\", \\\"{x:281,y:467,t:1526328600987};\\\", \\\"{x:285,y:467,t:1526328601003};\\\", \\\"{x:287,y:467,t:1526328601021};\\\", \\\"{x:288,y:468,t:1526328601319};\\\", \\\"{x:290,y:468,t:1526328601415};\\\", \\\"{x:293,y:468,t:1526328601423};\\\", \\\"{x:295,y:468,t:1526328601438};\\\", \\\"{x:299,y:466,t:1526328601453};\\\", \\\"{x:302,y:466,t:1526328601471};\\\", \\\"{x:303,y:466,t:1526328601511};\\\", \\\"{x:304,y:466,t:1526328601527};\\\", \\\"{x:305,y:466,t:1526328601542};\\\", \\\"{x:306,y:466,t:1526328601558};\\\", \\\"{x:308,y:466,t:1526328601570};\\\", \\\"{x:311,y:466,t:1526328601588};\\\", \\\"{x:315,y:466,t:1526328601604};\\\", \\\"{x:320,y:466,t:1526328601621};\\\", \\\"{x:332,y:466,t:1526328601638};\\\", \\\"{x:341,y:466,t:1526328601653};\\\", \\\"{x:362,y:466,t:1526328601670};\\\", \\\"{x:377,y:466,t:1526328601688};\\\", \\\"{x:390,y:466,t:1526328601704};\\\", \\\"{x:399,y:466,t:1526328601721};\\\", \\\"{x:409,y:466,t:1526328601738};\\\", \\\"{x:416,y:467,t:1526328601754};\\\", \\\"{x:423,y:467,t:1526328601771};\\\", \\\"{x:429,y:467,t:1526328601788};\\\", \\\"{x:435,y:467,t:1526328601805};\\\", \\\"{x:442,y:467,t:1526328601820};\\\", \\\"{x:449,y:467,t:1526328601838};\\\", \\\"{x:455,y:467,t:1526328601855};\\\", \\\"{x:459,y:467,t:1526328601871};\\\", \\\"{x:464,y:467,t:1526328601888};\\\", \\\"{x:466,y:467,t:1526328601904};\\\", \\\"{x:468,y:468,t:1526328601921};\\\", \\\"{x:470,y:468,t:1526328601938};\\\", \\\"{x:473,y:469,t:1526328601955};\\\", \\\"{x:474,y:469,t:1526328601971};\\\", \\\"{x:477,y:469,t:1526328601988};\\\", \\\"{x:479,y:469,t:1526328602005};\\\", \\\"{x:483,y:469,t:1526328602020};\\\", \\\"{x:486,y:469,t:1526328602038};\\\", \\\"{x:493,y:471,t:1526328602055};\\\", \\\"{x:498,y:472,t:1526328602071};\\\", \\\"{x:503,y:472,t:1526328602088};\\\", \\\"{x:508,y:473,t:1526328602104};\\\", \\\"{x:512,y:473,t:1526328602120};\\\", \\\"{x:516,y:475,t:1526328602138};\\\", \\\"{x:519,y:475,t:1526328602155};\\\", \\\"{x:523,y:475,t:1526328602171};\\\", \\\"{x:525,y:475,t:1526328602188};\\\", \\\"{x:528,y:475,t:1526328602205};\\\", \\\"{x:530,y:476,t:1526328602222};\\\", \\\"{x:532,y:476,t:1526328602238};\\\", \\\"{x:536,y:477,t:1526328602254};\\\", \\\"{x:540,y:477,t:1526328602271};\\\", \\\"{x:540,y:478,t:1526328602288};\\\", \\\"{x:542,y:478,t:1526328602305};\\\", \\\"{x:542,y:479,t:1526328602322};\\\", \\\"{x:545,y:479,t:1526328606479};\\\", \\\"{x:553,y:479,t:1526328606492};\\\", \\\"{x:570,y:479,t:1526328606508};\\\", \\\"{x:584,y:479,t:1526328606525};\\\", \\\"{x:593,y:479,t:1526328606541};\\\", \\\"{x:597,y:479,t:1526328606558};\\\", \\\"{x:600,y:479,t:1526328606575};\\\", \\\"{x:603,y:479,t:1526328606592};\\\", \\\"{x:607,y:479,t:1526328606607};\\\", \\\"{x:612,y:479,t:1526328606624};\\\", \\\"{x:622,y:479,t:1526328606641};\\\", \\\"{x:631,y:479,t:1526328606658};\\\", \\\"{x:640,y:479,t:1526328606675};\\\", \\\"{x:646,y:479,t:1526328606692};\\\", \\\"{x:653,y:479,t:1526328606708};\\\", \\\"{x:661,y:478,t:1526328606725};\\\", \\\"{x:670,y:478,t:1526328606741};\\\", \\\"{x:691,y:478,t:1526328606758};\\\", \\\"{x:709,y:478,t:1526328606775};\\\", \\\"{x:720,y:478,t:1526328606791};\\\", \\\"{x:727,y:478,t:1526328606809};\\\", \\\"{x:730,y:478,t:1526328606825};\\\", \\\"{x:731,y:478,t:1526328606846};\\\", \\\"{x:733,y:478,t:1526328606878};\\\", \\\"{x:734,y:478,t:1526328606892};\\\", \\\"{x:736,y:478,t:1526328606909};\\\", \\\"{x:737,y:478,t:1526328606924};\\\", \\\"{x:738,y:478,t:1526328606942};\\\", \\\"{x:740,y:477,t:1526328606966};\\\", \\\"{x:741,y:477,t:1526328607006};\\\", \\\"{x:743,y:476,t:1526328607039};\\\", \\\"{x:744,y:475,t:1526328607046};\\\", \\\"{x:746,y:475,t:1526328607558};\\\", \\\"{x:748,y:473,t:1526328607575};\\\", \\\"{x:750,y:473,t:1526328607598};\\\", \\\"{x:750,y:472,t:1526328607609};\\\", \\\"{x:751,y:471,t:1526328607630};\\\", \\\"{x:752,y:471,t:1526328607671};\\\", \\\"{x:753,y:470,t:1526328607727};\\\", \\\"{x:755,y:469,t:1526328607759};\\\", \\\"{x:755,y:468,t:1526328607774};\\\", \\\"{x:756,y:468,t:1526328607782};\\\", \\\"{x:757,y:468,t:1526328607793};\\\", \\\"{x:757,y:467,t:1526328607809};\\\", \\\"{x:759,y:465,t:1526328607825};\\\", \\\"{x:762,y:464,t:1526328607843};\\\", \\\"{x:765,y:461,t:1526328607859};\\\", \\\"{x:769,y:456,t:1526328607876};\\\", \\\"{x:772,y:454,t:1526328607893};\\\", \\\"{x:775,y:451,t:1526328607910};\\\", \\\"{x:778,y:448,t:1526328607926};\\\", \\\"{x:780,y:446,t:1526328607943};\\\", \\\"{x:782,y:445,t:1526328607960};\\\", \\\"{x:783,y:444,t:1526328607975};\\\", \\\"{x:784,y:443,t:1526328607993};\\\", \\\"{x:785,y:440,t:1526328608010};\\\", \\\"{x:788,y:437,t:1526328608026};\\\", \\\"{x:791,y:433,t:1526328608042};\\\", \\\"{x:795,y:429,t:1526328608060};\\\", \\\"{x:799,y:423,t:1526328608076};\\\", \\\"{x:803,y:419,t:1526328608093};\\\", \\\"{x:806,y:414,t:1526328608110};\\\", \\\"{x:811,y:409,t:1526328608126};\\\", \\\"{x:816,y:403,t:1526328608143};\\\", \\\"{x:819,y:398,t:1526328608159};\\\", \\\"{x:821,y:397,t:1526328608176};\\\", \\\"{x:824,y:395,t:1526328608193};\\\", \\\"{x:830,y:392,t:1526328608210};\\\", \\\"{x:834,y:390,t:1526328608226};\\\", \\\"{x:839,y:388,t:1526328608243};\\\", \\\"{x:846,y:385,t:1526328608260};\\\", \\\"{x:853,y:383,t:1526328608276};\\\", \\\"{x:860,y:381,t:1526328608292};\\\", \\\"{x:862,y:380,t:1526328608310};\\\", \\\"{x:865,y:379,t:1526328608326};\\\", \\\"{x:866,y:379,t:1526328608350};\\\", \\\"{x:868,y:379,t:1526328608398};\\\", \\\"{x:869,y:379,t:1526328608422};\\\", \\\"{x:870,y:379,t:1526328608454};\\\", \\\"{x:872,y:380,t:1526328608462};\\\", \\\"{x:873,y:382,t:1526328608476};\\\", \\\"{x:877,y:389,t:1526328608493};\\\", \\\"{x:880,y:396,t:1526328608510};\\\", \\\"{x:885,y:411,t:1526328608527};\\\", \\\"{x:887,y:422,t:1526328608542};\\\", \\\"{x:890,y:431,t:1526328608560};\\\", \\\"{x:893,y:438,t:1526328608577};\\\", \\\"{x:898,y:444,t:1526328608592};\\\", \\\"{x:905,y:456,t:1526328608609};\\\", \\\"{x:908,y:462,t:1526328608627};\\\", \\\"{x:911,y:465,t:1526328608642};\\\", \\\"{x:913,y:466,t:1526328608659};\\\", \\\"{x:914,y:466,t:1526328608677};\\\", \\\"{x:915,y:466,t:1526328608694};\\\", \\\"{x:915,y:467,t:1526328608710};\\\", \\\"{x:915,y:474,t:1526328608726};\\\", \\\"{x:915,y:475,t:1526328608798};\\\", \\\"{x:913,y:476,t:1526328608814};\\\", \\\"{x:910,y:478,t:1526328608827};\\\", \\\"{x:909,y:487,t:1526328608845};\\\", \\\"{x:905,y:496,t:1526328608860};\\\", \\\"{x:905,y:504,t:1526328608877};\\\", \\\"{x:905,y:508,t:1526328608892};\\\", \\\"{x:905,y:509,t:1526328608910};\\\", \\\"{x:905,y:510,t:1526328608927};\\\", \\\"{x:907,y:508,t:1526328609038};\\\", \\\"{x:909,y:504,t:1526328609054};\\\", \\\"{x:911,y:502,t:1526328609062};\\\", \\\"{x:914,y:498,t:1526328609077};\\\", \\\"{x:916,y:494,t:1526328609092};\\\", \\\"{x:918,y:491,t:1526328609110};\\\", \\\"{x:919,y:487,t:1526328609126};\\\", \\\"{x:920,y:486,t:1526328609143};\\\", \\\"{x:920,y:485,t:1526328609160};\\\", \\\"{x:921,y:484,t:1526328609190};\\\", \\\"{x:921,y:483,t:1526328609206};\\\", \\\"{x:922,y:483,t:1526328609214};\\\", \\\"{x:923,y:482,t:1526328609227};\\\", \\\"{x:925,y:482,t:1526328609246};\\\", \\\"{x:926,y:482,t:1526328609260};\\\", \\\"{x:930,y:482,t:1526328609276};\\\", \\\"{x:932,y:482,t:1526328609293};\\\", \\\"{x:933,y:482,t:1526328609310};\\\", \\\"{x:936,y:483,t:1526328609326};\\\", \\\"{x:938,y:484,t:1526328609342};\\\", \\\"{x:939,y:484,t:1526328609360};\\\", \\\"{x:941,y:485,t:1526328609376};\\\", \\\"{x:942,y:486,t:1526328609393};\\\", \\\"{x:943,y:486,t:1526328609410};\\\", \\\"{x:945,y:487,t:1526328609427};\\\", \\\"{x:946,y:487,t:1526328609447};\\\", \\\"{x:948,y:487,t:1526328609460};\\\", \\\"{x:950,y:489,t:1526328609477};\\\", \\\"{x:952,y:490,t:1526328609494};\\\", \\\"{x:957,y:493,t:1526328609510};\\\", \\\"{x:958,y:494,t:1526328609527};\\\", \\\"{x:960,y:495,t:1526328609543};\\\", \\\"{x:961,y:495,t:1526328609639};\\\", \\\"{x:962,y:495,t:1526328609686};\\\", \\\"{x:963,y:495,t:1526328609983};\\\", \\\"{x:966,y:493,t:1526328609993};\\\", \\\"{x:971,y:487,t:1526328610011};\\\", \\\"{x:974,y:483,t:1526328610027};\\\", \\\"{x:976,y:481,t:1526328610044};\\\", \\\"{x:977,y:480,t:1526328610061};\\\", \\\"{x:978,y:480,t:1526328610430};\\\", \\\"{x:979,y:480,t:1526328610710};\\\", \\\"{x:980,y:483,t:1526328610728};\\\", \\\"{x:981,y:488,t:1526328610744};\\\", \\\"{x:981,y:491,t:1526328610761};\\\", \\\"{x:982,y:493,t:1526328610778};\\\", \\\"{x:982,y:494,t:1526328611127};\\\", \\\"{x:984,y:494,t:1526328611310};\\\", \\\"{x:985,y:494,t:1526328611542};\\\", \\\"{x:987,y:494,t:1526328611551};\\\", \\\"{x:989,y:496,t:1526328611562};\\\", \\\"{x:996,y:505,t:1526328611578};\\\", \\\"{x:1007,y:520,t:1526328611595};\\\", \\\"{x:1019,y:539,t:1526328611612};\\\", \\\"{x:1031,y:563,t:1526328611628};\\\", \\\"{x:1045,y:587,t:1526328611645};\\\", \\\"{x:1062,y:620,t:1526328611662};\\\", \\\"{x:1077,y:656,t:1526328611678};\\\", \\\"{x:1099,y:696,t:1526328611695};\\\", \\\"{x:1106,y:711,t:1526328611712};\\\", \\\"{x:1110,y:717,t:1526328611729};\\\", \\\"{x:1111,y:718,t:1526328611745};\\\", \\\"{x:1112,y:718,t:1526328611798};\\\", \\\"{x:1113,y:719,t:1526328611830};\\\", \\\"{x:1119,y:721,t:1526328611845};\\\", \\\"{x:1127,y:727,t:1526328611862};\\\", \\\"{x:1151,y:740,t:1526328611878};\\\", \\\"{x:1168,y:750,t:1526328611896};\\\", \\\"{x:1178,y:755,t:1526328611912};\\\", \\\"{x:1182,y:758,t:1526328611930};\\\", \\\"{x:1184,y:759,t:1526328611945};\\\", \\\"{x:1186,y:759,t:1526328611967};\\\", \\\"{x:1188,y:761,t:1526328612007};\\\", \\\"{x:1191,y:762,t:1526328612015};\\\", \\\"{x:1194,y:762,t:1526328612029};\\\", \\\"{x:1206,y:765,t:1526328612045};\\\", \\\"{x:1221,y:766,t:1526328612063};\\\", \\\"{x:1242,y:767,t:1526328612079};\\\", \\\"{x:1253,y:767,t:1526328612095};\\\", \\\"{x:1259,y:767,t:1526328612112};\\\", \\\"{x:1261,y:767,t:1526328612129};\\\", \\\"{x:1265,y:766,t:1526328612145};\\\", \\\"{x:1268,y:765,t:1526328612162};\\\", \\\"{x:1274,y:765,t:1526328612180};\\\", \\\"{x:1277,y:765,t:1526328612196};\\\", \\\"{x:1282,y:765,t:1526328612213};\\\", \\\"{x:1285,y:765,t:1526328612229};\\\", \\\"{x:1289,y:765,t:1526328612246};\\\", \\\"{x:1290,y:765,t:1526328612262};\\\", \\\"{x:1291,y:765,t:1526328612279};\\\", \\\"{x:1293,y:766,t:1526328613206};\\\", \\\"{x:1295,y:766,t:1526328613407};\\\", \\\"{x:1297,y:771,t:1526328613415};\\\", \\\"{x:1297,y:779,t:1526328613431};\\\", \\\"{x:1301,y:799,t:1526328613446};\\\", \\\"{x:1302,y:809,t:1526328613463};\\\", \\\"{x:1306,y:820,t:1526328613480};\\\", \\\"{x:1313,y:830,t:1526328613497};\\\", \\\"{x:1317,y:835,t:1526328613514};\\\", \\\"{x:1320,y:840,t:1526328613531};\\\", \\\"{x:1324,y:845,t:1526328613548};\\\", \\\"{x:1324,y:848,t:1526328613563};\\\", \\\"{x:1324,y:850,t:1526328613581};\\\", \\\"{x:1324,y:851,t:1526328613598};\\\", \\\"{x:1324,y:853,t:1526328613639};\\\", \\\"{x:1324,y:854,t:1526328613655};\\\", \\\"{x:1323,y:855,t:1526328613663};\\\", \\\"{x:1323,y:856,t:1526328613687};\\\", \\\"{x:1322,y:856,t:1526328613880};\\\", \\\"{x:1320,y:856,t:1526328613897};\\\", \\\"{x:1319,y:856,t:1526328613927};\\\", \\\"{x:1318,y:856,t:1526328613943};\\\", \\\"{x:1317,y:856,t:1526328613959};\\\", \\\"{x:1318,y:856,t:1526328614015};\\\", \\\"{x:1318,y:855,t:1526328614454};\\\", \\\"{x:1318,y:853,t:1526328614470};\\\", \\\"{x:1318,y:852,t:1526328614519};\\\", \\\"{x:1319,y:852,t:1526328614655};\\\", \\\"{x:1320,y:852,t:1526328614678};\\\", \\\"{x:1320,y:851,t:1526328614686};\\\", \\\"{x:1323,y:850,t:1526328614702};\\\", \\\"{x:1325,y:849,t:1526328614718};\\\", \\\"{x:1326,y:848,t:1526328614731};\\\", \\\"{x:1329,y:846,t:1526328614747};\\\", \\\"{x:1330,y:846,t:1526328614766};\\\", \\\"{x:1331,y:845,t:1526328614781};\\\", \\\"{x:1333,y:844,t:1526328614797};\\\", \\\"{x:1335,y:843,t:1526328614814};\\\", \\\"{x:1336,y:841,t:1526328614831};\\\", \\\"{x:1338,y:840,t:1526328614848};\\\", \\\"{x:1340,y:837,t:1526328614864};\\\", \\\"{x:1345,y:831,t:1526328614881};\\\", \\\"{x:1349,y:827,t:1526328614898};\\\", \\\"{x:1351,y:824,t:1526328614914};\\\", \\\"{x:1355,y:817,t:1526328614932};\\\", \\\"{x:1358,y:812,t:1526328614948};\\\", \\\"{x:1360,y:807,t:1526328614964};\\\", \\\"{x:1363,y:801,t:1526328614981};\\\", \\\"{x:1366,y:796,t:1526328614999};\\\", \\\"{x:1367,y:796,t:1526328615014};\\\", \\\"{x:1367,y:794,t:1526328615031};\\\", \\\"{x:1367,y:793,t:1526328615070};\\\", \\\"{x:1367,y:791,t:1526328615150};\\\", \\\"{x:1367,y:790,t:1526328615164};\\\", \\\"{x:1367,y:785,t:1526328615181};\\\", \\\"{x:1367,y:780,t:1526328615198};\\\", \\\"{x:1367,y:777,t:1526328615214};\\\", \\\"{x:1367,y:773,t:1526328615231};\\\", \\\"{x:1367,y:770,t:1526328615248};\\\", \\\"{x:1367,y:765,t:1526328615265};\\\", \\\"{x:1367,y:758,t:1526328615281};\\\", \\\"{x:1368,y:749,t:1526328615298};\\\", \\\"{x:1371,y:743,t:1526328615315};\\\", \\\"{x:1371,y:737,t:1526328615331};\\\", \\\"{x:1372,y:733,t:1526328615348};\\\", \\\"{x:1374,y:730,t:1526328615365};\\\", \\\"{x:1374,y:729,t:1526328615381};\\\", \\\"{x:1375,y:729,t:1526328615398};\\\", \\\"{x:1379,y:729,t:1526328615566};\\\", \\\"{x:1387,y:735,t:1526328615581};\\\", \\\"{x:1411,y:751,t:1526328615598};\\\", \\\"{x:1429,y:764,t:1526328615615};\\\", \\\"{x:1450,y:783,t:1526328615632};\\\", \\\"{x:1472,y:802,t:1526328615648};\\\", \\\"{x:1493,y:820,t:1526328615665};\\\", \\\"{x:1509,y:832,t:1526328615682};\\\", \\\"{x:1521,y:838,t:1526328615698};\\\", \\\"{x:1529,y:842,t:1526328615715};\\\", \\\"{x:1534,y:846,t:1526328615732};\\\", \\\"{x:1538,y:849,t:1526328615748};\\\", \\\"{x:1544,y:854,t:1526328615765};\\\", \\\"{x:1548,y:857,t:1526328615782};\\\", \\\"{x:1549,y:858,t:1526328615798};\\\", \\\"{x:1549,y:856,t:1526328615943};\\\", \\\"{x:1550,y:853,t:1526328615950};\\\", \\\"{x:1551,y:851,t:1526328615966};\\\", \\\"{x:1556,y:840,t:1526328615982};\\\", \\\"{x:1559,y:833,t:1526328615998};\\\", \\\"{x:1562,y:833,t:1526328616238};\\\", \\\"{x:1562,y:838,t:1526328616249};\\\", \\\"{x:1565,y:857,t:1526328616265};\\\", \\\"{x:1567,y:869,t:1526328616282};\\\", \\\"{x:1568,y:881,t:1526328616300};\\\", \\\"{x:1569,y:889,t:1526328616315};\\\", \\\"{x:1571,y:893,t:1526328616332};\\\", \\\"{x:1572,y:894,t:1526328616349};\\\", \\\"{x:1572,y:896,t:1526328616606};\\\", \\\"{x:1573,y:898,t:1526328616616};\\\", \\\"{x:1576,y:903,t:1526328616632};\\\", \\\"{x:1577,y:910,t:1526328616649};\\\", \\\"{x:1579,y:916,t:1526328616666};\\\", \\\"{x:1579,y:920,t:1526328616682};\\\", \\\"{x:1579,y:923,t:1526328616700};\\\", \\\"{x:1579,y:924,t:1526328616718};\\\", \\\"{x:1579,y:925,t:1526328616758};\\\", \\\"{x:1579,y:926,t:1526328616782};\\\", \\\"{x:1579,y:927,t:1526328616799};\\\", \\\"{x:1579,y:929,t:1526328616886};\\\", \\\"{x:1579,y:930,t:1526328616902};\\\", \\\"{x:1580,y:931,t:1526328616916};\\\", \\\"{x:1580,y:932,t:1526328616934};\\\", \\\"{x:1581,y:933,t:1526328616950};\\\", \\\"{x:1581,y:934,t:1526328616974};\\\", \\\"{x:1582,y:935,t:1526328616982};\\\", \\\"{x:1582,y:936,t:1526328617000};\\\", \\\"{x:1582,y:937,t:1526328617016};\\\", \\\"{x:1582,y:938,t:1526328617033};\\\", \\\"{x:1582,y:939,t:1526328617079};\\\", \\\"{x:1582,y:940,t:1526328617222};\\\", \\\"{x:1581,y:941,t:1526328617310};\\\", \\\"{x:1580,y:941,t:1526328617318};\\\", \\\"{x:1579,y:942,t:1526328617333};\\\", \\\"{x:1577,y:943,t:1526328617349};\\\", \\\"{x:1570,y:947,t:1526328617366};\\\", \\\"{x:1563,y:950,t:1526328617383};\\\", \\\"{x:1555,y:952,t:1526328617400};\\\", \\\"{x:1546,y:955,t:1526328617416};\\\", \\\"{x:1535,y:959,t:1526328617433};\\\", \\\"{x:1533,y:959,t:1526328617450};\\\", \\\"{x:1531,y:960,t:1526328617466};\\\", \\\"{x:1530,y:960,t:1526328617542};\\\", \\\"{x:1529,y:960,t:1526328617551};\\\", \\\"{x:1529,y:955,t:1526328617566};\\\", \\\"{x:1528,y:952,t:1526328617583};\\\", \\\"{x:1528,y:947,t:1526328617600};\\\", \\\"{x:1528,y:944,t:1526328617616};\\\", \\\"{x:1528,y:943,t:1526328617633};\\\", \\\"{x:1528,y:940,t:1526328617651};\\\", \\\"{x:1528,y:939,t:1526328617666};\\\", \\\"{x:1528,y:938,t:1526328617683};\\\", \\\"{x:1528,y:937,t:1526328617700};\\\", \\\"{x:1528,y:936,t:1526328617870};\\\", \\\"{x:1528,y:934,t:1526328617883};\\\", \\\"{x:1528,y:930,t:1526328617900};\\\", \\\"{x:1528,y:926,t:1526328617918};\\\", \\\"{x:1528,y:921,t:1526328617933};\\\", \\\"{x:1528,y:909,t:1526328617950};\\\", \\\"{x:1528,y:902,t:1526328617967};\\\", \\\"{x:1528,y:897,t:1526328617984};\\\", \\\"{x:1528,y:889,t:1526328618001};\\\", \\\"{x:1528,y:876,t:1526328618017};\\\", \\\"{x:1528,y:869,t:1526328618034};\\\", \\\"{x:1528,y:858,t:1526328618050};\\\", \\\"{x:1528,y:849,t:1526328618067};\\\", \\\"{x:1528,y:840,t:1526328618083};\\\", \\\"{x:1528,y:831,t:1526328618101};\\\", \\\"{x:1528,y:823,t:1526328618117};\\\", \\\"{x:1528,y:815,t:1526328618133};\\\", \\\"{x:1525,y:801,t:1526328618150};\\\", \\\"{x:1525,y:793,t:1526328618167};\\\", \\\"{x:1521,y:782,t:1526328618183};\\\", \\\"{x:1517,y:774,t:1526328618201};\\\", \\\"{x:1516,y:772,t:1526328618217};\\\", \\\"{x:1515,y:768,t:1526328618234};\\\", \\\"{x:1513,y:764,t:1526328618250};\\\", \\\"{x:1512,y:762,t:1526328618267};\\\", \\\"{x:1511,y:760,t:1526328618286};\\\", \\\"{x:1511,y:759,t:1526328618366};\\\", \\\"{x:1511,y:758,t:1526328618374};\\\", \\\"{x:1511,y:757,t:1526328618385};\\\", \\\"{x:1511,y:755,t:1526328618401};\\\", \\\"{x:1511,y:753,t:1526328618417};\\\", \\\"{x:1511,y:751,t:1526328618434};\\\", \\\"{x:1511,y:748,t:1526328618451};\\\", \\\"{x:1511,y:744,t:1526328618467};\\\", \\\"{x:1511,y:742,t:1526328618485};\\\", \\\"{x:1510,y:740,t:1526328618500};\\\", \\\"{x:1509,y:737,t:1526328618518};\\\", \\\"{x:1508,y:732,t:1526328618534};\\\", \\\"{x:1508,y:731,t:1526328618551};\\\", \\\"{x:1506,y:729,t:1526328618567};\\\", \\\"{x:1505,y:724,t:1526328618584};\\\", \\\"{x:1500,y:714,t:1526328618600};\\\", \\\"{x:1497,y:709,t:1526328618618};\\\", \\\"{x:1494,y:705,t:1526328618634};\\\", \\\"{x:1490,y:700,t:1526328618650};\\\", \\\"{x:1478,y:681,t:1526328618667};\\\", \\\"{x:1474,y:676,t:1526328618684};\\\", \\\"{x:1472,y:673,t:1526328618701};\\\", \\\"{x:1469,y:670,t:1526328618717};\\\", \\\"{x:1465,y:665,t:1526328618734};\\\", \\\"{x:1462,y:662,t:1526328618751};\\\", \\\"{x:1462,y:661,t:1526328618767};\\\", \\\"{x:1460,y:658,t:1526328618785};\\\", \\\"{x:1460,y:657,t:1526328618801};\\\", \\\"{x:1460,y:656,t:1526328618817};\\\", \\\"{x:1460,y:654,t:1526328618879};\\\", \\\"{x:1460,y:653,t:1526328618894};\\\", \\\"{x:1460,y:651,t:1526328618902};\\\", \\\"{x:1459,y:651,t:1526328618917};\\\", \\\"{x:1458,y:649,t:1526328618934};\\\", \\\"{x:1457,y:647,t:1526328618951};\\\", \\\"{x:1457,y:646,t:1526328618968};\\\", \\\"{x:1456,y:643,t:1526328618984};\\\", \\\"{x:1453,y:639,t:1526328619001};\\\", \\\"{x:1453,y:637,t:1526328619017};\\\", \\\"{x:1452,y:635,t:1526328619034};\\\", \\\"{x:1451,y:632,t:1526328619051};\\\", \\\"{x:1451,y:627,t:1526328619068};\\\", \\\"{x:1451,y:625,t:1526328619084};\\\", \\\"{x:1451,y:623,t:1526328619101};\\\", \\\"{x:1451,y:620,t:1526328619117};\\\", \\\"{x:1452,y:620,t:1526328619134};\\\", \\\"{x:1452,y:619,t:1526328621191};\\\", \\\"{x:1451,y:619,t:1526328621215};\\\", \\\"{x:1451,y:618,t:1526328621262};\\\", \\\"{x:1450,y:615,t:1526328621286};\\\", \\\"{x:1449,y:613,t:1526328621303};\\\", \\\"{x:1449,y:611,t:1526328621319};\\\", \\\"{x:1447,y:607,t:1526328621337};\\\", \\\"{x:1446,y:603,t:1526328621353};\\\", \\\"{x:1444,y:599,t:1526328621370};\\\", \\\"{x:1443,y:597,t:1526328621387};\\\", \\\"{x:1442,y:595,t:1526328621403};\\\", \\\"{x:1440,y:591,t:1526328621420};\\\", \\\"{x:1438,y:589,t:1526328621436};\\\", \\\"{x:1436,y:588,t:1526328621454};\\\", \\\"{x:1434,y:585,t:1526328621469};\\\", \\\"{x:1432,y:583,t:1526328621486};\\\", \\\"{x:1431,y:583,t:1526328621503};\\\", \\\"{x:1429,y:582,t:1526328621519};\\\", \\\"{x:1429,y:581,t:1526328621606};\\\", \\\"{x:1429,y:580,t:1526328621703};\\\", \\\"{x:1428,y:578,t:1526328621711};\\\", \\\"{x:1427,y:577,t:1526328621719};\\\", \\\"{x:1425,y:574,t:1526328621736};\\\", \\\"{x:1422,y:570,t:1526328621754};\\\", \\\"{x:1415,y:562,t:1526328621771};\\\", \\\"{x:1409,y:557,t:1526328621787};\\\", \\\"{x:1406,y:554,t:1526328621804};\\\", \\\"{x:1405,y:554,t:1526328621951};\\\", \\\"{x:1405,y:558,t:1526328622103};\\\", \\\"{x:1405,y:561,t:1526328622110};\\\", \\\"{x:1406,y:566,t:1526328622120};\\\", \\\"{x:1407,y:573,t:1526328622136};\\\", \\\"{x:1408,y:577,t:1526328622153};\\\", \\\"{x:1409,y:578,t:1526328622170};\\\", \\\"{x:1409,y:577,t:1526328622350};\\\", \\\"{x:1409,y:576,t:1526328622358};\\\", \\\"{x:1409,y:574,t:1526328622370};\\\", \\\"{x:1409,y:572,t:1526328622387};\\\", \\\"{x:1410,y:571,t:1526328622403};\\\", \\\"{x:1411,y:570,t:1526328622462};\\\", \\\"{x:1412,y:570,t:1526328622511};\\\", \\\"{x:1412,y:569,t:1526328622598};\\\", \\\"{x:1413,y:568,t:1526328622614};\\\", \\\"{x:1411,y:571,t:1526328630015};\\\", \\\"{x:1404,y:586,t:1526328630027};\\\", \\\"{x:1391,y:619,t:1526328630043};\\\", \\\"{x:1373,y:653,t:1526328630059};\\\", \\\"{x:1357,y:690,t:1526328630077};\\\", \\\"{x:1341,y:719,t:1526328630093};\\\", \\\"{x:1329,y:748,t:1526328630109};\\\", \\\"{x:1312,y:786,t:1526328630127};\\\", \\\"{x:1303,y:808,t:1526328630144};\\\", \\\"{x:1294,y:828,t:1526328630160};\\\", \\\"{x:1288,y:843,t:1526328630177};\\\", \\\"{x:1284,y:852,t:1526328630193};\\\", \\\"{x:1281,y:859,t:1526328630210};\\\", \\\"{x:1279,y:863,t:1526328630227};\\\", \\\"{x:1276,y:867,t:1526328630244};\\\", \\\"{x:1271,y:875,t:1526328630259};\\\", \\\"{x:1265,y:890,t:1526328630276};\\\", \\\"{x:1256,y:917,t:1526328630293};\\\", \\\"{x:1251,y:933,t:1526328630310};\\\", \\\"{x:1250,y:939,t:1526328630327};\\\", \\\"{x:1250,y:940,t:1526328630344};\\\", \\\"{x:1250,y:941,t:1526328630359};\\\", \\\"{x:1251,y:941,t:1526328630646};\\\", \\\"{x:1252,y:941,t:1526328630661};\\\", \\\"{x:1253,y:940,t:1526328630676};\\\", \\\"{x:1274,y:900,t:1526328630694};\\\", \\\"{x:1321,y:838,t:1526328630710};\\\", \\\"{x:1404,y:737,t:1526328630727};\\\", \\\"{x:1499,y:637,t:1526328630744};\\\", \\\"{x:1575,y:539,t:1526328630761};\\\", \\\"{x:1585,y:509,t:1526328630776};\\\", \\\"{x:1593,y:488,t:1526328630794};\\\", \\\"{x:1602,y:469,t:1526328630811};\\\", \\\"{x:1602,y:467,t:1526328630826};\\\", \\\"{x:1602,y:466,t:1526328630844};\\\", \\\"{x:1600,y:466,t:1526328630861};\\\", \\\"{x:1596,y:466,t:1526328630876};\\\", \\\"{x:1592,y:468,t:1526328630894};\\\", \\\"{x:1588,y:471,t:1526328630910};\\\", \\\"{x:1575,y:481,t:1526328630927};\\\", \\\"{x:1553,y:500,t:1526328630944};\\\", \\\"{x:1511,y:532,t:1526328630960};\\\", \\\"{x:1437,y:594,t:1526328630977};\\\", \\\"{x:1351,y:652,t:1526328630994};\\\", \\\"{x:1292,y:691,t:1526328631011};\\\", \\\"{x:1259,y:713,t:1526328631028};\\\", \\\"{x:1249,y:719,t:1526328631044};\\\", \\\"{x:1249,y:713,t:1526328631094};\\\", \\\"{x:1252,y:696,t:1526328631111};\\\", \\\"{x:1260,y:678,t:1526328631128};\\\", \\\"{x:1271,y:660,t:1526328631144};\\\", \\\"{x:1283,y:642,t:1526328631160};\\\", \\\"{x:1297,y:624,t:1526328631178};\\\", \\\"{x:1308,y:609,t:1526328631194};\\\", \\\"{x:1313,y:603,t:1526328631210};\\\", \\\"{x:1315,y:599,t:1526328631228};\\\", \\\"{x:1317,y:597,t:1526328631244};\\\", \\\"{x:1319,y:594,t:1526328631260};\\\", \\\"{x:1320,y:593,t:1526328631278};\\\", \\\"{x:1321,y:592,t:1526328631294};\\\", \\\"{x:1322,y:592,t:1526328631310};\\\", \\\"{x:1322,y:591,t:1526328631328};\\\", \\\"{x:1323,y:589,t:1526328631343};\\\", \\\"{x:1325,y:587,t:1526328631361};\\\", \\\"{x:1333,y:585,t:1526328631378};\\\", \\\"{x:1354,y:578,t:1526328631394};\\\", \\\"{x:1368,y:572,t:1526328631411};\\\", \\\"{x:1387,y:570,t:1526328631428};\\\", \\\"{x:1402,y:567,t:1526328631445};\\\", \\\"{x:1411,y:564,t:1526328631461};\\\", \\\"{x:1419,y:561,t:1526328631478};\\\", \\\"{x:1421,y:559,t:1526328631495};\\\", \\\"{x:1421,y:566,t:1526328631622};\\\", \\\"{x:1421,y:578,t:1526328631630};\\\", \\\"{x:1421,y:599,t:1526328631644};\\\", \\\"{x:1407,y:659,t:1526328631660};\\\", \\\"{x:1346,y:799,t:1526328631678};\\\", \\\"{x:1312,y:871,t:1526328631694};\\\", \\\"{x:1309,y:876,t:1526328631711};\\\", \\\"{x:1309,y:872,t:1526328631742};\\\", \\\"{x:1309,y:865,t:1526328631750};\\\", \\\"{x:1309,y:856,t:1526328631761};\\\", \\\"{x:1309,y:843,t:1526328631778};\\\", \\\"{x:1309,y:833,t:1526328631794};\\\", \\\"{x:1313,y:817,t:1526328631810};\\\", \\\"{x:1314,y:803,t:1526328631828};\\\", \\\"{x:1317,y:790,t:1526328631845};\\\", \\\"{x:1317,y:773,t:1526328631861};\\\", \\\"{x:1317,y:763,t:1526328631878};\\\", \\\"{x:1317,y:756,t:1526328631895};\\\", \\\"{x:1318,y:747,t:1526328631912};\\\", \\\"{x:1319,y:744,t:1526328631928};\\\", \\\"{x:1321,y:741,t:1526328631945};\\\", \\\"{x:1322,y:738,t:1526328631962};\\\", \\\"{x:1322,y:736,t:1526328631978};\\\", \\\"{x:1324,y:735,t:1526328631994};\\\", \\\"{x:1328,y:731,t:1526328632012};\\\", \\\"{x:1332,y:726,t:1526328632028};\\\", \\\"{x:1336,y:717,t:1526328632045};\\\", \\\"{x:1349,y:690,t:1526328632062};\\\", \\\"{x:1353,y:679,t:1526328632078};\\\", \\\"{x:1354,y:678,t:1526328632094};\\\", \\\"{x:1354,y:677,t:1526328632112};\\\", \\\"{x:1355,y:677,t:1526328632190};\\\", \\\"{x:1355,y:678,t:1526328632206};\\\", \\\"{x:1355,y:681,t:1526328632214};\\\", \\\"{x:1356,y:686,t:1526328632228};\\\", \\\"{x:1356,y:708,t:1526328632245};\\\", \\\"{x:1346,y:782,t:1526328632262};\\\", \\\"{x:1324,y:865,t:1526328632278};\\\", \\\"{x:1289,y:932,t:1526328632295};\\\", \\\"{x:1254,y:989,t:1526328632312};\\\", \\\"{x:1217,y:1050,t:1526328632329};\\\", \\\"{x:1184,y:1098,t:1526328632345};\\\", \\\"{x:1167,y:1121,t:1526328632362};\\\", \\\"{x:1162,y:1126,t:1526328632379};\\\", \\\"{x:1162,y:1128,t:1526328632395};\\\", \\\"{x:1162,y:1129,t:1526328632414};\\\", \\\"{x:1163,y:1129,t:1526328632454};\\\", \\\"{x:1165,y:1129,t:1526328632486};\\\", \\\"{x:1166,y:1129,t:1526328632495};\\\", \\\"{x:1173,y:1120,t:1526328632511};\\\", \\\"{x:1178,y:1103,t:1526328632529};\\\", \\\"{x:1183,y:1082,t:1526328632545};\\\", \\\"{x:1193,y:1060,t:1526328632562};\\\", \\\"{x:1198,y:1043,t:1526328632579};\\\", \\\"{x:1202,y:1027,t:1526328632595};\\\", \\\"{x:1205,y:1003,t:1526328632612};\\\", \\\"{x:1214,y:975,t:1526328632629};\\\", \\\"{x:1222,y:946,t:1526328632645};\\\", \\\"{x:1242,y:893,t:1526328632662};\\\", \\\"{x:1254,y:871,t:1526328632679};\\\", \\\"{x:1265,y:851,t:1526328632695};\\\", \\\"{x:1278,y:832,t:1526328632711};\\\", \\\"{x:1284,y:825,t:1526328632729};\\\", \\\"{x:1285,y:825,t:1526328632774};\\\", \\\"{x:1287,y:824,t:1526328632782};\\\", \\\"{x:1289,y:823,t:1526328632796};\\\", \\\"{x:1292,y:820,t:1526328632812};\\\", \\\"{x:1301,y:811,t:1526328632829};\\\", \\\"{x:1322,y:790,t:1526328632845};\\\", \\\"{x:1335,y:775,t:1526328632862};\\\", \\\"{x:1341,y:766,t:1526328632879};\\\", \\\"{x:1343,y:766,t:1526328632896};\\\", \\\"{x:1344,y:764,t:1526328632912};\\\", \\\"{x:1346,y:761,t:1526328632929};\\\", \\\"{x:1348,y:759,t:1526328632946};\\\", \\\"{x:1351,y:754,t:1526328632962};\\\", \\\"{x:1354,y:751,t:1526328632979};\\\", \\\"{x:1356,y:750,t:1526328632996};\\\", \\\"{x:1357,y:744,t:1526328633383};\\\", \\\"{x:1357,y:734,t:1526328633396};\\\", \\\"{x:1354,y:725,t:1526328633413};\\\", \\\"{x:1353,y:720,t:1526328633429};\\\", \\\"{x:1353,y:712,t:1526328633446};\\\", \\\"{x:1353,y:710,t:1526328633463};\\\", \\\"{x:1353,y:709,t:1526328633486};\\\", \\\"{x:1356,y:708,t:1526328633606};\\\", \\\"{x:1368,y:712,t:1526328633613};\\\", \\\"{x:1392,y:726,t:1526328633629};\\\", \\\"{x:1472,y:791,t:1526328633646};\\\", \\\"{x:1529,y:857,t:1526328633663};\\\", \\\"{x:1574,y:900,t:1526328633679};\\\", \\\"{x:1609,y:930,t:1526328633695};\\\", \\\"{x:1631,y:943,t:1526328633713};\\\", \\\"{x:1634,y:944,t:1526328633730};\\\", \\\"{x:1632,y:934,t:1526328633750};\\\", \\\"{x:1628,y:920,t:1526328633763};\\\", \\\"{x:1611,y:883,t:1526328633780};\\\", \\\"{x:1590,y:843,t:1526328633796};\\\", \\\"{x:1568,y:798,t:1526328633813};\\\", \\\"{x:1531,y:743,t:1526328633829};\\\", \\\"{x:1517,y:722,t:1526328633846};\\\", \\\"{x:1508,y:708,t:1526328633863};\\\", \\\"{x:1502,y:693,t:1526328633879};\\\", \\\"{x:1499,y:685,t:1526328633895};\\\", \\\"{x:1498,y:677,t:1526328633913};\\\", \\\"{x:1496,y:666,t:1526328633930};\\\", \\\"{x:1491,y:651,t:1526328633946};\\\", \\\"{x:1486,y:635,t:1526328633963};\\\", \\\"{x:1476,y:612,t:1526328633980};\\\", \\\"{x:1456,y:583,t:1526328633995};\\\", \\\"{x:1440,y:560,t:1526328634013};\\\", \\\"{x:1425,y:546,t:1526328634030};\\\", \\\"{x:1418,y:543,t:1526328634046};\\\", \\\"{x:1415,y:541,t:1526328634063};\\\", \\\"{x:1414,y:541,t:1526328634080};\\\", \\\"{x:1413,y:541,t:1526328634097};\\\", \\\"{x:1408,y:542,t:1526328634113};\\\", \\\"{x:1404,y:542,t:1526328634129};\\\", \\\"{x:1400,y:542,t:1526328634147};\\\", \\\"{x:1399,y:542,t:1526328634162};\\\", \\\"{x:1399,y:543,t:1526328634206};\\\", \\\"{x:1400,y:545,t:1526328634214};\\\", \\\"{x:1401,y:549,t:1526328634230};\\\", \\\"{x:1403,y:552,t:1526328634247};\\\", \\\"{x:1403,y:556,t:1526328634262};\\\", \\\"{x:1403,y:557,t:1526328634280};\\\", \\\"{x:1403,y:559,t:1526328634297};\\\", \\\"{x:1403,y:560,t:1526328634313};\\\", \\\"{x:1403,y:561,t:1526328634342};\\\", \\\"{x:1403,y:563,t:1526328634358};\\\", \\\"{x:1403,y:566,t:1526328634366};\\\", \\\"{x:1403,y:569,t:1526328634380};\\\", \\\"{x:1403,y:579,t:1526328634396};\\\", \\\"{x:1402,y:596,t:1526328634413};\\\", \\\"{x:1392,y:637,t:1526328634430};\\\", \\\"{x:1388,y:664,t:1526328634447};\\\", \\\"{x:1384,y:686,t:1526328634462};\\\", \\\"{x:1380,y:697,t:1526328634480};\\\", \\\"{x:1379,y:698,t:1526328634497};\\\", \\\"{x:1379,y:700,t:1526328634513};\\\", \\\"{x:1377,y:703,t:1526328634530};\\\", \\\"{x:1377,y:707,t:1526328634547};\\\", \\\"{x:1375,y:717,t:1526328634564};\\\", \\\"{x:1369,y:732,t:1526328634580};\\\", \\\"{x:1364,y:747,t:1526328634597};\\\", \\\"{x:1356,y:768,t:1526328634614};\\\", \\\"{x:1351,y:782,t:1526328634630};\\\", \\\"{x:1346,y:791,t:1526328634647};\\\", \\\"{x:1343,y:801,t:1526328634664};\\\", \\\"{x:1340,y:806,t:1526328634680};\\\", \\\"{x:1335,y:819,t:1526328634697};\\\", \\\"{x:1328,y:834,t:1526328634714};\\\", \\\"{x:1319,y:851,t:1526328634730};\\\", \\\"{x:1305,y:876,t:1526328634747};\\\", \\\"{x:1298,y:892,t:1526328634764};\\\", \\\"{x:1289,y:909,t:1526328634780};\\\", \\\"{x:1283,y:925,t:1526328634797};\\\", \\\"{x:1272,y:947,t:1526328634814};\\\", \\\"{x:1267,y:962,t:1526328634830};\\\", \\\"{x:1262,y:971,t:1526328634847};\\\", \\\"{x:1258,y:983,t:1526328634864};\\\", \\\"{x:1256,y:991,t:1526328634880};\\\", \\\"{x:1253,y:999,t:1526328634897};\\\", \\\"{x:1252,y:1006,t:1526328634914};\\\", \\\"{x:1252,y:1009,t:1526328634930};\\\", \\\"{x:1257,y:999,t:1526328634998};\\\", \\\"{x:1276,y:947,t:1526328635014};\\\", \\\"{x:1306,y:866,t:1526328635031};\\\", \\\"{x:1353,y:766,t:1526328635047};\\\", \\\"{x:1398,y:664,t:1526328635064};\\\", \\\"{x:1442,y:575,t:1526328635081};\\\", \\\"{x:1468,y:511,t:1526328635097};\\\", \\\"{x:1481,y:479,t:1526328635114};\\\", \\\"{x:1484,y:462,t:1526328635131};\\\", \\\"{x:1484,y:452,t:1526328635147};\\\", \\\"{x:1484,y:447,t:1526328635164};\\\", \\\"{x:1484,y:444,t:1526328635181};\\\", \\\"{x:1484,y:445,t:1526328635247};\\\", \\\"{x:1484,y:448,t:1526328635254};\\\", \\\"{x:1484,y:453,t:1526328635264};\\\", \\\"{x:1496,y:476,t:1526328635281};\\\", \\\"{x:1510,y:506,t:1526328635297};\\\", \\\"{x:1529,y:548,t:1526328635314};\\\", \\\"{x:1541,y:576,t:1526328635331};\\\", \\\"{x:1555,y:608,t:1526328635347};\\\", \\\"{x:1573,y:662,t:1526328635364};\\\", \\\"{x:1594,y:729,t:1526328635381};\\\", \\\"{x:1598,y:786,t:1526328635397};\\\", \\\"{x:1606,y:875,t:1526328635414};\\\", \\\"{x:1610,y:905,t:1526328635431};\\\", \\\"{x:1613,y:922,t:1526328635448};\\\", \\\"{x:1619,y:938,t:1526328635464};\\\", \\\"{x:1625,y:951,t:1526328635481};\\\", \\\"{x:1628,y:963,t:1526328635498};\\\", \\\"{x:1634,y:979,t:1526328635514};\\\", \\\"{x:1638,y:996,t:1526328635531};\\\", \\\"{x:1639,y:1008,t:1526328635547};\\\", \\\"{x:1642,y:1018,t:1526328635564};\\\", \\\"{x:1643,y:1023,t:1526328635580};\\\", \\\"{x:1645,y:1027,t:1526328635598};\\\", \\\"{x:1645,y:1029,t:1526328635614};\\\", \\\"{x:1637,y:1029,t:1526328635631};\\\", \\\"{x:1599,y:1022,t:1526328635648};\\\", \\\"{x:1507,y:973,t:1526328635664};\\\", \\\"{x:1373,y:896,t:1526328635681};\\\", \\\"{x:1219,y:801,t:1526328635698};\\\", \\\"{x:1091,y:713,t:1526328635714};\\\", \\\"{x:1011,y:674,t:1526328635731};\\\", \\\"{x:973,y:662,t:1526328635748};\\\", \\\"{x:949,y:656,t:1526328635764};\\\", \\\"{x:939,y:656,t:1526328635781};\\\", \\\"{x:934,y:657,t:1526328635798};\\\", \\\"{x:926,y:671,t:1526328635813};\\\", \\\"{x:920,y:690,t:1526328635831};\\\", \\\"{x:910,y:706,t:1526328635848};\\\", \\\"{x:908,y:709,t:1526328635865};\\\", \\\"{x:907,y:709,t:1526328635881};\\\", \\\"{x:896,y:708,t:1526328635898};\\\", \\\"{x:877,y:697,t:1526328635915};\\\", \\\"{x:835,y:687,t:1526328635931};\\\", \\\"{x:762,y:666,t:1526328635948};\\\", \\\"{x:663,y:640,t:1526328635965};\\\", \\\"{x:569,y:617,t:1526328635981};\\\", \\\"{x:482,y:588,t:1526328635998};\\\", \\\"{x:466,y:580,t:1526328636013};\\\", \\\"{x:440,y:562,t:1526328636030};\\\", \\\"{x:437,y:559,t:1526328636047};\\\", \\\"{x:437,y:558,t:1526328636064};\\\", \\\"{x:437,y:555,t:1526328636082};\\\", \\\"{x:439,y:549,t:1526328636098};\\\", \\\"{x:444,y:542,t:1526328636115};\\\", \\\"{x:454,y:537,t:1526328636131};\\\", \\\"{x:472,y:532,t:1526328636147};\\\", \\\"{x:493,y:531,t:1526328636165};\\\", \\\"{x:510,y:531,t:1526328636182};\\\", \\\"{x:534,y:532,t:1526328636198};\\\", \\\"{x:547,y:539,t:1526328636215};\\\", \\\"{x:568,y:552,t:1526328636231};\\\", \\\"{x:608,y:575,t:1526328636249};\\\", \\\"{x:647,y:594,t:1526328636265};\\\", \\\"{x:698,y:613,t:1526328636281};\\\", \\\"{x:711,y:614,t:1526328636298};\\\", \\\"{x:713,y:614,t:1526328636315};\\\", \\\"{x:713,y:606,t:1526328636331};\\\", \\\"{x:705,y:590,t:1526328636348};\\\", \\\"{x:681,y:576,t:1526328636365};\\\", \\\"{x:646,y:565,t:1526328636381};\\\", \\\"{x:601,y:563,t:1526328636398};\\\", \\\"{x:577,y:563,t:1526328636415};\\\", \\\"{x:555,y:563,t:1526328636431};\\\", \\\"{x:541,y:566,t:1526328636448};\\\", \\\"{x:530,y:570,t:1526328636465};\\\", \\\"{x:527,y:571,t:1526328636481};\\\", \\\"{x:524,y:571,t:1526328636498};\\\", \\\"{x:523,y:572,t:1526328636526};\\\", \\\"{x:522,y:572,t:1526328636534};\\\", \\\"{x:520,y:573,t:1526328636548};\\\", \\\"{x:516,y:574,t:1526328636565};\\\", \\\"{x:503,y:576,t:1526328636582};\\\", \\\"{x:491,y:576,t:1526328636598};\\\", \\\"{x:474,y:576,t:1526328636615};\\\", \\\"{x:447,y:572,t:1526328636632};\\\", \\\"{x:404,y:565,t:1526328636648};\\\", \\\"{x:359,y:559,t:1526328636665};\\\", \\\"{x:327,y:557,t:1526328636682};\\\", \\\"{x:307,y:557,t:1526328636698};\\\", \\\"{x:300,y:557,t:1526328636715};\\\", \\\"{x:298,y:557,t:1526328636732};\\\", \\\"{x:297,y:557,t:1526328636750};\\\", \\\"{x:294,y:557,t:1526328636766};\\\", \\\"{x:289,y:558,t:1526328636782};\\\", \\\"{x:274,y:565,t:1526328636798};\\\", \\\"{x:256,y:569,t:1526328636815};\\\", \\\"{x:238,y:570,t:1526328636832};\\\", \\\"{x:217,y:570,t:1526328636848};\\\", \\\"{x:200,y:569,t:1526328636865};\\\", \\\"{x:178,y:562,t:1526328636883};\\\", \\\"{x:167,y:559,t:1526328636898};\\\", \\\"{x:158,y:556,t:1526328636915};\\\", \\\"{x:150,y:554,t:1526328636932};\\\", \\\"{x:148,y:554,t:1526328636948};\\\", \\\"{x:147,y:554,t:1526328636965};\\\", \\\"{x:144,y:554,t:1526328636982};\\\", \\\"{x:143,y:557,t:1526328636998};\\\", \\\"{x:144,y:566,t:1526328637015};\\\", \\\"{x:148,y:574,t:1526328637033};\\\", \\\"{x:149,y:579,t:1526328637049};\\\", \\\"{x:150,y:582,t:1526328637066};\\\", \\\"{x:150,y:583,t:1526328637082};\\\", \\\"{x:150,y:585,t:1526328637099};\\\", \\\"{x:150,y:588,t:1526328637115};\\\", \\\"{x:150,y:593,t:1526328637132};\\\", \\\"{x:147,y:600,t:1526328637149};\\\", \\\"{x:146,y:613,t:1526328637166};\\\", \\\"{x:146,y:628,t:1526328637182};\\\", \\\"{x:147,y:640,t:1526328637200};\\\", \\\"{x:148,y:643,t:1526328637215};\\\", \\\"{x:149,y:645,t:1526328637233};\\\", \\\"{x:150,y:646,t:1526328637249};\\\", \\\"{x:152,y:646,t:1526328637278};\\\", \\\"{x:155,y:646,t:1526328637286};\\\", \\\"{x:160,y:649,t:1526328637298};\\\", \\\"{x:170,y:652,t:1526328637315};\\\", \\\"{x:185,y:658,t:1526328637332};\\\", \\\"{x:203,y:664,t:1526328637350};\\\", \\\"{x:245,y:681,t:1526328637366};\\\", \\\"{x:272,y:690,t:1526328637382};\\\", \\\"{x:303,y:696,t:1526328637399};\\\", \\\"{x:336,y:702,t:1526328637415};\\\", \\\"{x:361,y:702,t:1526328637432};\\\", \\\"{x:381,y:700,t:1526328637449};\\\", \\\"{x:401,y:695,t:1526328637465};\\\", \\\"{x:418,y:691,t:1526328637482};\\\", \\\"{x:430,y:686,t:1526328637499};\\\", \\\"{x:438,y:682,t:1526328637515};\\\", \\\"{x:443,y:680,t:1526328637532};\\\", \\\"{x:452,y:674,t:1526328637549};\\\", \\\"{x:465,y:668,t:1526328637566};\\\", \\\"{x:486,y:655,t:1526328637582};\\\", \\\"{x:502,y:644,t:1526328637600};\\\", \\\"{x:513,y:636,t:1526328637615};\\\", \\\"{x:523,y:629,t:1526328637632};\\\", \\\"{x:531,y:624,t:1526328637649};\\\", \\\"{x:545,y:619,t:1526328637666};\\\", \\\"{x:561,y:614,t:1526328637682};\\\", \\\"{x:576,y:610,t:1526328637699};\\\", \\\"{x:591,y:607,t:1526328637716};\\\", \\\"{x:608,y:604,t:1526328637732};\\\", \\\"{x:620,y:603,t:1526328637749};\\\", \\\"{x:639,y:600,t:1526328637767};\\\", \\\"{x:649,y:600,t:1526328637782};\\\", \\\"{x:660,y:600,t:1526328637799};\\\", \\\"{x:675,y:600,t:1526328637816};\\\", \\\"{x:690,y:600,t:1526328637832};\\\", \\\"{x:712,y:600,t:1526328637849};\\\", \\\"{x:731,y:598,t:1526328637866};\\\", \\\"{x:755,y:588,t:1526328637883};\\\", \\\"{x:783,y:571,t:1526328637899};\\\", \\\"{x:802,y:557,t:1526328637920};\\\", \\\"{x:816,y:545,t:1526328637937};\\\", \\\"{x:820,y:541,t:1526328637953};\\\", \\\"{x:820,y:540,t:1526328637970};\\\", \\\"{x:820,y:538,t:1526328638041};\\\", \\\"{x:820,y:533,t:1526328638053};\\\", \\\"{x:813,y:530,t:1526328638070};\\\", \\\"{x:808,y:526,t:1526328638086};\\\", \\\"{x:806,y:525,t:1526328638102};\\\", \\\"{x:807,y:525,t:1526328638209};\\\", \\\"{x:810,y:526,t:1526328638220};\\\", \\\"{x:814,y:528,t:1526328638236};\\\", \\\"{x:815,y:528,t:1526328638252};\\\", \\\"{x:816,y:529,t:1526328638282};\\\", \\\"{x:817,y:529,t:1526328638297};\\\", \\\"{x:818,y:530,t:1526328638313};\\\", \\\"{x:820,y:530,t:1526328638393};\\\", \\\"{x:820,y:531,t:1526328638404};\\\", \\\"{x:824,y:532,t:1526328638420};\\\", \\\"{x:827,y:534,t:1526328638437};\\\", \\\"{x:831,y:536,t:1526328638454};\\\", \\\"{x:833,y:536,t:1526328638470};\\\", \\\"{x:834,y:537,t:1526328638489};\\\", \\\"{x:828,y:542,t:1526328638721};\\\", \\\"{x:817,y:548,t:1526328638737};\\\", \\\"{x:788,y:566,t:1526328638754};\\\", \\\"{x:769,y:578,t:1526328638770};\\\", \\\"{x:755,y:588,t:1526328638786};\\\", \\\"{x:748,y:595,t:1526328638804};\\\", \\\"{x:740,y:600,t:1526328638821};\\\", \\\"{x:732,y:606,t:1526328638838};\\\", \\\"{x:720,y:613,t:1526328638854};\\\", \\\"{x:700,y:623,t:1526328638871};\\\", \\\"{x:669,y:640,t:1526328638887};\\\", \\\"{x:618,y:657,t:1526328638903};\\\", \\\"{x:567,y:675,t:1526328638921};\\\", \\\"{x:543,y:685,t:1526328638937};\\\", \\\"{x:528,y:692,t:1526328638953};\\\", \\\"{x:527,y:693,t:1526328638970};\\\", \\\"{x:527,y:694,t:1526328638987};\\\", \\\"{x:527,y:695,t:1526328639003};\\\", \\\"{x:528,y:695,t:1526328639025};\\\", \\\"{x:528,y:696,t:1526328639036};\\\", \\\"{x:528,y:697,t:1526328639058};\\\", \\\"{x:528,y:699,t:1526328639089};\\\", \\\"{x:528,y:700,t:1526328639113};\\\", \\\"{x:528,y:701,t:1526328639153};\\\", \\\"{x:528,y:703,t:1526328639171};\\\", \\\"{x:525,y:708,t:1526328639187};\\\", \\\"{x:523,y:720,t:1526328639203};\\\", \\\"{x:520,y:732,t:1526328639221};\\\", \\\"{x:515,y:746,t:1526328639236};\\\", \\\"{x:512,y:753,t:1526328639254};\\\", \\\"{x:510,y:757,t:1526328639271};\\\", \\\"{x:509,y:759,t:1526328639287};\\\", \\\"{x:507,y:759,t:1526328639378};\\\", \\\"{x:506,y:758,t:1526328639393};\\\", \\\"{x:505,y:755,t:1526328639409};\\\", \\\"{x:503,y:753,t:1526328639421};\\\", \\\"{x:503,y:745,t:1526328639438};\\\", \\\"{x:502,y:739,t:1526328639454};\\\", \\\"{x:502,y:731,t:1526328639470};\\\", \\\"{x:502,y:727,t:1526328639487};\\\", \\\"{x:502,y:726,t:1526328639504};\\\", \\\"{x:502,y:725,t:1526328639594};\\\", \\\"{x:502,y:725,t:1526328639698};\\\", \\\"{x:503,y:725,t:1526328639985};\\\", \\\"{x:512,y:725,t:1526328639993};\\\", \\\"{x:534,y:728,t:1526328640004};\\\", \\\"{x:612,y:739,t:1526328640021};\\\", \\\"{x:701,y:750,t:1526328640038};\\\", \\\"{x:819,y:761,t:1526328640054};\\\", \\\"{x:939,y:767,t:1526328640071};\\\", \\\"{x:1055,y:767,t:1526328640087};\\\", \\\"{x:1163,y:767,t:1526328640104};\\\", \\\"{x:1266,y:749,t:1526328640122};\\\", \\\"{x:1317,y:731,t:1526328640138};\\\", \\\"{x:1356,y:708,t:1526328640155};\\\", \\\"{x:1389,y:671,t:1526328640172};\\\", \\\"{x:1406,y:645,t:1526328640188};\\\", \\\"{x:1418,y:624,t:1526328640204};\\\", \\\"{x:1426,y:608,t:1526328640222};\\\", \\\"{x:1433,y:597,t:1526328640238};\\\", \\\"{x:1435,y:591,t:1526328640254};\\\", \\\"{x:1436,y:588,t:1526328640271};\\\", \\\"{x:1436,y:583,t:1526328640288};\\\", \\\"{x:1436,y:577,t:1526328640304};\\\", \\\"{x:1436,y:569,t:1526328640321};\\\", \\\"{x:1436,y:568,t:1526328640337};\\\", \\\"{x:1436,y:566,t:1526328640355};\\\" ] }, { \\\"rt\\\": 119385, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 601807, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-B -E -N -4-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1437,y:565,t:1526328640937};\\\", \\\"{x:1438,y:564,t:1526328640945};\\\", \\\"{x:1438,y:563,t:1526328640955};\\\", \\\"{x:1439,y:561,t:1526328640971};\\\", \\\"{x:1440,y:559,t:1526328640998};\\\", \\\"{x:1440,y:558,t:1526328641026};\\\", \\\"{x:1437,y:555,t:1526328641594};\\\", \\\"{x:1428,y:553,t:1526328641606};\\\", \\\"{x:1403,y:548,t:1526328641623};\\\", \\\"{x:1371,y:542,t:1526328641638};\\\", \\\"{x:1304,y:533,t:1526328641656};\\\", \\\"{x:1201,y:517,t:1526328641673};\\\", \\\"{x:1065,y:498,t:1526328641689};\\\", \\\"{x:851,y:466,t:1526328641706};\\\", \\\"{x:743,y:452,t:1526328641723};\\\", \\\"{x:680,y:439,t:1526328641738};\\\", \\\"{x:661,y:434,t:1526328641756};\\\", \\\"{x:660,y:433,t:1526328641773};\\\", \\\"{x:659,y:432,t:1526328641833};\\\", \\\"{x:658,y:432,t:1526328641841};\\\", \\\"{x:656,y:432,t:1526328641855};\\\", \\\"{x:649,y:430,t:1526328641873};\\\", \\\"{x:630,y:429,t:1526328641889};\\\", \\\"{x:616,y:429,t:1526328641905};\\\", \\\"{x:607,y:430,t:1526328641923};\\\", \\\"{x:602,y:432,t:1526328641939};\\\", \\\"{x:602,y:433,t:1526328642001};\\\", \\\"{x:601,y:434,t:1526328642009};\\\", \\\"{x:597,y:434,t:1526328642023};\\\", \\\"{x:579,y:439,t:1526328642040};\\\", \\\"{x:560,y:439,t:1526328642055};\\\", \\\"{x:538,y:439,t:1526328642073};\\\", \\\"{x:494,y:439,t:1526328642089};\\\", \\\"{x:453,y:436,t:1526328642105};\\\", \\\"{x:402,y:428,t:1526328642122};\\\", \\\"{x:350,y:414,t:1526328642139};\\\", \\\"{x:290,y:402,t:1526328642156};\\\", \\\"{x:250,y:389,t:1526328642173};\\\", \\\"{x:221,y:381,t:1526328642190};\\\", \\\"{x:204,y:381,t:1526328642206};\\\", \\\"{x:203,y:381,t:1526328642222};\\\", \\\"{x:202,y:381,t:1526328642289};\\\", \\\"{x:205,y:383,t:1526328642307};\\\", \\\"{x:222,y:393,t:1526328642323};\\\", \\\"{x:247,y:406,t:1526328642340};\\\", \\\"{x:291,y:424,t:1526328642357};\\\", \\\"{x:344,y:447,t:1526328642373};\\\", \\\"{x:399,y:471,t:1526328642390};\\\", \\\"{x:425,y:483,t:1526328642407};\\\", \\\"{x:432,y:484,t:1526328642423};\\\", \\\"{x:433,y:485,t:1526328642440};\\\", \\\"{x:432,y:486,t:1526328642482};\\\", \\\"{x:431,y:486,t:1526328642497};\\\", \\\"{x:431,y:484,t:1526328642642};\\\", \\\"{x:431,y:482,t:1526328642658};\\\", \\\"{x:433,y:479,t:1526328642673};\\\", \\\"{x:437,y:473,t:1526328642689};\\\", \\\"{x:440,y:468,t:1526328642708};\\\", \\\"{x:443,y:462,t:1526328642723};\\\", \\\"{x:445,y:458,t:1526328642740};\\\", \\\"{x:447,y:455,t:1526328642756};\\\", \\\"{x:448,y:452,t:1526328642773};\\\", \\\"{x:448,y:451,t:1526328642790};\\\", \\\"{x:447,y:455,t:1526328642930};\\\", \\\"{x:446,y:456,t:1526328642939};\\\", \\\"{x:443,y:461,t:1526328642957};\\\", \\\"{x:442,y:464,t:1526328642974};\\\", \\\"{x:442,y:466,t:1526328643114};\\\", \\\"{x:442,y:468,t:1526328643129};\\\", \\\"{x:443,y:468,t:1526328643140};\\\", \\\"{x:445,y:468,t:1526328643234};\\\", \\\"{x:446,y:467,t:1526328643250};\\\", \\\"{x:447,y:467,t:1526328643290};\\\", \\\"{x:448,y:467,t:1526328643298};\\\", \\\"{x:450,y:467,t:1526328643314};\\\", \\\"{x:452,y:467,t:1526328643330};\\\", \\\"{x:454,y:467,t:1526328643341};\\\", \\\"{x:461,y:467,t:1526328643357};\\\", \\\"{x:471,y:467,t:1526328643374};\\\", \\\"{x:482,y:467,t:1526328643391};\\\", \\\"{x:485,y:467,t:1526328643407};\\\", \\\"{x:489,y:467,t:1526328643424};\\\", \\\"{x:490,y:467,t:1526328643441};\\\", \\\"{x:492,y:468,t:1526328643530};\\\", \\\"{x:493,y:468,t:1526328643545};\\\", \\\"{x:494,y:468,t:1526328643562};\\\", \\\"{x:497,y:468,t:1526328643573};\\\", \\\"{x:501,y:468,t:1526328643590};\\\", \\\"{x:508,y:468,t:1526328643607};\\\", \\\"{x:518,y:469,t:1526328643624};\\\", \\\"{x:525,y:469,t:1526328643641};\\\", \\\"{x:542,y:469,t:1526328643657};\\\", \\\"{x:552,y:469,t:1526328643673};\\\", \\\"{x:567,y:469,t:1526328643691};\\\", \\\"{x:581,y:470,t:1526328643708};\\\", \\\"{x:595,y:473,t:1526328643724};\\\", \\\"{x:607,y:473,t:1526328643741};\\\", \\\"{x:617,y:473,t:1526328643758};\\\", \\\"{x:623,y:473,t:1526328643774};\\\", \\\"{x:624,y:473,t:1526328643791};\\\", \\\"{x:628,y:473,t:1526328644066};\\\", \\\"{x:638,y:473,t:1526328644074};\\\", \\\"{x:666,y:473,t:1526328644091};\\\", \\\"{x:705,y:473,t:1526328644107};\\\", \\\"{x:739,y:473,t:1526328644125};\\\", \\\"{x:767,y:473,t:1526328644141};\\\", \\\"{x:791,y:473,t:1526328644158};\\\", \\\"{x:801,y:473,t:1526328644175};\\\", \\\"{x:805,y:473,t:1526328644191};\\\", \\\"{x:808,y:473,t:1526328644208};\\\", \\\"{x:809,y:473,t:1526328644225};\\\", \\\"{x:811,y:473,t:1526328644241};\\\", \\\"{x:819,y:475,t:1526328644258};\\\", \\\"{x:825,y:475,t:1526328644275};\\\", \\\"{x:832,y:477,t:1526328644290};\\\", \\\"{x:840,y:478,t:1526328644308};\\\", \\\"{x:844,y:478,t:1526328644325};\\\", \\\"{x:846,y:478,t:1526328644341};\\\", \\\"{x:847,y:478,t:1526328644358};\\\", \\\"{x:847,y:479,t:1526328644377};\\\", \\\"{x:849,y:479,t:1526328644962};\\\", \\\"{x:850,y:479,t:1526328644977};\\\", \\\"{x:852,y:479,t:1526328644991};\\\", \\\"{x:860,y:479,t:1526328645008};\\\", \\\"{x:883,y:479,t:1526328645024};\\\", \\\"{x:997,y:486,t:1526328645042};\\\", \\\"{x:1103,y:506,t:1526328645058};\\\", \\\"{x:1219,y:520,t:1526328645074};\\\", \\\"{x:1312,y:536,t:1526328645092};\\\", \\\"{x:1384,y:544,t:1526328645109};\\\", \\\"{x:1421,y:551,t:1526328645125};\\\", \\\"{x:1442,y:552,t:1526328645142};\\\", \\\"{x:1451,y:553,t:1526328645159};\\\", \\\"{x:1455,y:553,t:1526328645175};\\\", \\\"{x:1461,y:553,t:1526328645192};\\\", \\\"{x:1468,y:553,t:1526328645209};\\\", \\\"{x:1478,y:553,t:1526328645225};\\\", \\\"{x:1493,y:553,t:1526328645242};\\\", \\\"{x:1501,y:553,t:1526328645259};\\\", \\\"{x:1507,y:553,t:1526328645275};\\\", \\\"{x:1509,y:553,t:1526328645292};\\\", \\\"{x:1511,y:550,t:1526328645626};\\\", \\\"{x:1521,y:547,t:1526328645642};\\\", \\\"{x:1532,y:544,t:1526328645658};\\\", \\\"{x:1539,y:542,t:1526328645676};\\\", \\\"{x:1543,y:540,t:1526328645692};\\\", \\\"{x:1546,y:540,t:1526328645708};\\\", \\\"{x:1547,y:540,t:1526328645729};\\\", \\\"{x:1545,y:540,t:1526328646514};\\\", \\\"{x:1542,y:540,t:1526328646526};\\\", \\\"{x:1540,y:542,t:1526328646543};\\\", \\\"{x:1539,y:550,t:1526328646560};\\\", \\\"{x:1539,y:562,t:1526328646576};\\\", \\\"{x:1546,y:578,t:1526328646593};\\\", \\\"{x:1549,y:579,t:1526328646610};\\\", \\\"{x:1549,y:580,t:1526328646641};\\\", \\\"{x:1549,y:584,t:1526328646649};\\\", \\\"{x:1549,y:592,t:1526328646660};\\\", \\\"{x:1541,y:602,t:1526328646676};\\\", \\\"{x:1534,y:608,t:1526328646693};\\\", \\\"{x:1527,y:612,t:1526328646710};\\\", \\\"{x:1525,y:613,t:1526328646726};\\\", \\\"{x:1522,y:615,t:1526328646746};\\\", \\\"{x:1518,y:617,t:1526328646760};\\\", \\\"{x:1507,y:628,t:1526328646777};\\\", \\\"{x:1488,y:650,t:1526328646793};\\\", \\\"{x:1451,y:693,t:1526328646810};\\\", \\\"{x:1423,y:718,t:1526328646827};\\\", \\\"{x:1379,y:745,t:1526328646842};\\\", \\\"{x:1337,y:773,t:1526328646861};\\\", \\\"{x:1299,y:805,t:1526328646877};\\\", \\\"{x:1275,y:822,t:1526328646894};\\\", \\\"{x:1257,y:837,t:1526328646910};\\\", \\\"{x:1246,y:846,t:1526328646927};\\\", \\\"{x:1233,y:855,t:1526328646943};\\\", \\\"{x:1221,y:861,t:1526328646960};\\\", \\\"{x:1208,y:866,t:1526328646977};\\\", \\\"{x:1198,y:867,t:1526328646993};\\\", \\\"{x:1189,y:869,t:1526328647010};\\\", \\\"{x:1188,y:869,t:1526328647027};\\\", \\\"{x:1189,y:869,t:1526328647226};\\\", \\\"{x:1191,y:869,t:1526328647233};\\\", \\\"{x:1194,y:867,t:1526328647244};\\\", \\\"{x:1201,y:863,t:1526328647260};\\\", \\\"{x:1209,y:858,t:1526328647277};\\\", \\\"{x:1215,y:856,t:1526328647294};\\\", \\\"{x:1217,y:854,t:1526328647310};\\\", \\\"{x:1219,y:853,t:1526328647327};\\\", \\\"{x:1208,y:843,t:1526328647666};\\\", \\\"{x:1169,y:820,t:1526328647678};\\\", \\\"{x:1060,y:757,t:1526328647695};\\\", \\\"{x:919,y:670,t:1526328647712};\\\", \\\"{x:771,y:578,t:1526328647728};\\\", \\\"{x:655,y:508,t:1526328647745};\\\", \\\"{x:599,y:467,t:1526328647761};\\\", \\\"{x:584,y:453,t:1526328647777};\\\", \\\"{x:579,y:445,t:1526328647794};\\\", \\\"{x:579,y:441,t:1526328647811};\\\", \\\"{x:577,y:437,t:1526328647828};\\\", \\\"{x:573,y:433,t:1526328647844};\\\", \\\"{x:564,y:428,t:1526328647861};\\\", \\\"{x:545,y:418,t:1526328647877};\\\", \\\"{x:525,y:410,t:1526328647894};\\\", \\\"{x:517,y:408,t:1526328647911};\\\", \\\"{x:515,y:408,t:1526328647969};\\\", \\\"{x:512,y:409,t:1526328647978};\\\", \\\"{x:500,y:419,t:1526328647995};\\\", \\\"{x:486,y:432,t:1526328648011};\\\", \\\"{x:470,y:448,t:1526328648028};\\\", \\\"{x:457,y:463,t:1526328648044};\\\", \\\"{x:447,y:472,t:1526328648062};\\\", \\\"{x:440,y:478,t:1526328648077};\\\", \\\"{x:437,y:479,t:1526328648094};\\\", \\\"{x:435,y:479,t:1526328648138};\\\", \\\"{x:432,y:479,t:1526328648146};\\\", \\\"{x:431,y:479,t:1526328648418};\\\", \\\"{x:431,y:478,t:1526328648433};\\\", \\\"{x:432,y:478,t:1526328648444};\\\", \\\"{x:434,y:478,t:1526328648461};\\\", \\\"{x:436,y:477,t:1526328648478};\\\", \\\"{x:439,y:477,t:1526328648495};\\\", \\\"{x:441,y:477,t:1526328648511};\\\", \\\"{x:442,y:477,t:1526328648528};\\\", \\\"{x:444,y:476,t:1526328648544};\\\", \\\"{x:451,y:476,t:1526328648562};\\\", \\\"{x:464,y:476,t:1526328648578};\\\", \\\"{x:483,y:476,t:1526328648594};\\\", \\\"{x:504,y:476,t:1526328648611};\\\", \\\"{x:519,y:476,t:1526328648628};\\\", \\\"{x:532,y:476,t:1526328648645};\\\", \\\"{x:536,y:476,t:1526328648661};\\\", \\\"{x:539,y:475,t:1526328648986};\\\", \\\"{x:542,y:474,t:1526328648995};\\\", \\\"{x:550,y:473,t:1526328649012};\\\", \\\"{x:557,y:472,t:1526328649028};\\\", \\\"{x:561,y:472,t:1526328649044};\\\", \\\"{x:562,y:472,t:1526328649060};\\\", \\\"{x:562,y:471,t:1526328649297};\\\", \\\"{x:564,y:471,t:1526328649312};\\\", \\\"{x:568,y:471,t:1526328649329};\\\", \\\"{x:572,y:471,t:1526328649346};\\\", \\\"{x:574,y:471,t:1526328649362};\\\", \\\"{x:577,y:472,t:1526328649379};\\\", \\\"{x:579,y:472,t:1526328649395};\\\", \\\"{x:582,y:472,t:1526328649412};\\\", \\\"{x:584,y:472,t:1526328649428};\\\", \\\"{x:585,y:472,t:1526328649753};\\\", \\\"{x:587,y:472,t:1526328649762};\\\", \\\"{x:599,y:475,t:1526328649779};\\\", \\\"{x:612,y:476,t:1526328649795};\\\", \\\"{x:626,y:476,t:1526328649812};\\\", \\\"{x:636,y:476,t:1526328649829};\\\", \\\"{x:642,y:476,t:1526328649845};\\\", \\\"{x:647,y:476,t:1526328649862};\\\", \\\"{x:651,y:476,t:1526328649879};\\\", \\\"{x:654,y:476,t:1526328649895};\\\", \\\"{x:656,y:476,t:1526328649912};\\\", \\\"{x:661,y:476,t:1526328649929};\\\", \\\"{x:662,y:476,t:1526328649977};\\\", \\\"{x:663,y:476,t:1526328655642};\\\", \\\"{x:658,y:476,t:1526328656170};\\\", \\\"{x:649,y:474,t:1526328656183};\\\", \\\"{x:640,y:472,t:1526328656200};\\\", \\\"{x:639,y:472,t:1526328656216};\\\", \\\"{x:634,y:469,t:1526328656233};\\\", \\\"{x:628,y:468,t:1526328656250};\\\", \\\"{x:623,y:468,t:1526328656267};\\\", \\\"{x:614,y:468,t:1526328656283};\\\", \\\"{x:603,y:468,t:1526328656301};\\\", \\\"{x:592,y:468,t:1526328656317};\\\", \\\"{x:586,y:470,t:1526328656333};\\\", \\\"{x:583,y:470,t:1526328656350};\\\", \\\"{x:582,y:471,t:1526328656369};\\\", \\\"{x:581,y:471,t:1526328656393};\\\", \\\"{x:580,y:471,t:1526328656401};\\\", \\\"{x:576,y:473,t:1526328656417};\\\", \\\"{x:568,y:474,t:1526328656433};\\\", \\\"{x:563,y:474,t:1526328656451};\\\", \\\"{x:555,y:474,t:1526328656467};\\\", \\\"{x:548,y:474,t:1526328656483};\\\", \\\"{x:539,y:474,t:1526328656500};\\\", \\\"{x:524,y:474,t:1526328656518};\\\", \\\"{x:498,y:474,t:1526328656533};\\\", \\\"{x:481,y:474,t:1526328656551};\\\", \\\"{x:458,y:472,t:1526328656568};\\\", \\\"{x:447,y:472,t:1526328656583};\\\", \\\"{x:445,y:471,t:1526328656600};\\\", \\\"{x:441,y:471,t:1526328656617};\\\", \\\"{x:436,y:471,t:1526328656633};\\\", \\\"{x:430,y:471,t:1526328656651};\\\", \\\"{x:423,y:471,t:1526328656667};\\\", \\\"{x:417,y:469,t:1526328656684};\\\", \\\"{x:416,y:469,t:1526328656701};\\\", \\\"{x:418,y:469,t:1526328656874};\\\", \\\"{x:420,y:469,t:1526328656885};\\\", \\\"{x:431,y:467,t:1526328656900};\\\", \\\"{x:439,y:466,t:1526328656918};\\\", \\\"{x:445,y:464,t:1526328656934};\\\", \\\"{x:452,y:464,t:1526328656950};\\\", \\\"{x:453,y:464,t:1526328656968};\\\", \\\"{x:461,y:463,t:1526328656984};\\\", \\\"{x:469,y:463,t:1526328657000};\\\", \\\"{x:487,y:463,t:1526328657017};\\\", \\\"{x:497,y:463,t:1526328657034};\\\", \\\"{x:504,y:463,t:1526328657050};\\\", \\\"{x:508,y:463,t:1526328657067};\\\", \\\"{x:513,y:463,t:1526328657085};\\\", \\\"{x:519,y:463,t:1526328657101};\\\", \\\"{x:523,y:463,t:1526328657117};\\\", \\\"{x:528,y:463,t:1526328657134};\\\", \\\"{x:532,y:463,t:1526328657151};\\\", \\\"{x:534,y:463,t:1526328657167};\\\", \\\"{x:537,y:463,t:1526328657184};\\\", \\\"{x:539,y:464,t:1526328657200};\\\", \\\"{x:544,y:465,t:1526328657217};\\\", \\\"{x:547,y:465,t:1526328657234};\\\", \\\"{x:550,y:466,t:1526328657251};\\\", \\\"{x:551,y:466,t:1526328657267};\\\", \\\"{x:553,y:466,t:1526328657284};\\\", \\\"{x:556,y:467,t:1526328657302};\\\", \\\"{x:557,y:467,t:1526328657321};\\\", \\\"{x:559,y:467,t:1526328657334};\\\", \\\"{x:560,y:467,t:1526328657351};\\\", \\\"{x:562,y:467,t:1526328657367};\\\", \\\"{x:564,y:468,t:1526328657385};\\\", \\\"{x:566,y:468,t:1526328657610};\\\", \\\"{x:567,y:468,t:1526328657618};\\\", \\\"{x:571,y:469,t:1526328657634};\\\", \\\"{x:573,y:470,t:1526328657651};\\\", \\\"{x:574,y:470,t:1526328657667};\\\", \\\"{x:577,y:471,t:1526328657684};\\\", \\\"{x:580,y:471,t:1526328657701};\\\", \\\"{x:582,y:472,t:1526328657718};\\\", \\\"{x:586,y:474,t:1526328657734};\\\", \\\"{x:588,y:474,t:1526328657751};\\\", \\\"{x:590,y:475,t:1526328657768};\\\", \\\"{x:591,y:475,t:1526328657785};\\\", \\\"{x:592,y:475,t:1526328657801};\\\", \\\"{x:593,y:476,t:1526328657819};\\\", \\\"{x:594,y:476,t:1526328657835};\\\", \\\"{x:597,y:477,t:1526328657852};\\\", \\\"{x:599,y:478,t:1526328657868};\\\", \\\"{x:600,y:478,t:1526328657885};\\\", \\\"{x:604,y:478,t:1526328657901};\\\", \\\"{x:608,y:478,t:1526328657918};\\\", \\\"{x:613,y:479,t:1526328657934};\\\", \\\"{x:619,y:482,t:1526328657952};\\\", \\\"{x:628,y:483,t:1526328657968};\\\", \\\"{x:635,y:486,t:1526328657985};\\\", \\\"{x:645,y:488,t:1526328658001};\\\", \\\"{x:647,y:489,t:1526328658018};\\\", \\\"{x:648,y:490,t:1526328658146};\\\", \\\"{x:649,y:492,t:1526328658169};\\\", \\\"{x:650,y:492,t:1526328658185};\\\", \\\"{x:651,y:492,t:1526328658199};\\\", \\\"{x:654,y:493,t:1526328658215};\\\", \\\"{x:658,y:494,t:1526328658233};\\\", \\\"{x:660,y:494,t:1526328658248};\\\", \\\"{x:663,y:494,t:1526328658265};\\\", \\\"{x:666,y:495,t:1526328658282};\\\", \\\"{x:667,y:496,t:1526328658300};\\\", \\\"{x:669,y:496,t:1526328658315};\\\", \\\"{x:670,y:497,t:1526328658332};\\\", \\\"{x:672,y:497,t:1526328658349};\\\", \\\"{x:673,y:499,t:1526328658366};\\\", \\\"{x:675,y:499,t:1526328658382};\\\", \\\"{x:677,y:499,t:1526328658399};\\\", \\\"{x:679,y:500,t:1526328658415};\\\", \\\"{x:684,y:501,t:1526328658433};\\\", \\\"{x:688,y:503,t:1526328658449};\\\", \\\"{x:691,y:504,t:1526328658467};\\\", \\\"{x:697,y:504,t:1526328658482};\\\", \\\"{x:702,y:507,t:1526328658500};\\\", \\\"{x:707,y:507,t:1526328658517};\\\", \\\"{x:710,y:510,t:1526328658533};\\\", \\\"{x:713,y:510,t:1526328658549};\\\", \\\"{x:716,y:511,t:1526328658566};\\\", \\\"{x:718,y:512,t:1526328658593};\\\", \\\"{x:720,y:512,t:1526328658601};\\\", \\\"{x:723,y:513,t:1526328658617};\\\", \\\"{x:735,y:516,t:1526328658634};\\\", \\\"{x:746,y:519,t:1526328658649};\\\", \\\"{x:762,y:521,t:1526328658670};\\\", \\\"{x:777,y:525,t:1526328658686};\\\", \\\"{x:793,y:526,t:1526328658703};\\\", \\\"{x:811,y:530,t:1526328658719};\\\", \\\"{x:830,y:532,t:1526328658735};\\\", \\\"{x:851,y:535,t:1526328658752};\\\", \\\"{x:873,y:537,t:1526328658769};\\\", \\\"{x:896,y:541,t:1526328658786};\\\", \\\"{x:923,y:545,t:1526328658802};\\\", \\\"{x:950,y:548,t:1526328658820};\\\", \\\"{x:979,y:553,t:1526328658837};\\\", \\\"{x:1011,y:563,t:1526328658852};\\\", \\\"{x:1035,y:570,t:1526328658869};\\\", \\\"{x:1055,y:581,t:1526328658887};\\\", \\\"{x:1079,y:593,t:1526328658903};\\\", \\\"{x:1103,y:613,t:1526328658919};\\\", \\\"{x:1126,y:638,t:1526328658937};\\\", \\\"{x:1160,y:677,t:1526328658952};\\\", \\\"{x:1200,y:722,t:1526328658969};\\\", \\\"{x:1218,y:743,t:1526328658986};\\\", \\\"{x:1232,y:763,t:1526328659003};\\\", \\\"{x:1241,y:781,t:1526328659019};\\\", \\\"{x:1247,y:799,t:1526328659037};\\\", \\\"{x:1257,y:825,t:1526328659052};\\\", \\\"{x:1260,y:840,t:1526328659070};\\\", \\\"{x:1270,y:860,t:1526328659086};\\\", \\\"{x:1279,y:870,t:1526328659103};\\\", \\\"{x:1293,y:876,t:1526328659120};\\\", \\\"{x:1303,y:881,t:1526328659136};\\\", \\\"{x:1304,y:881,t:1526328659152};\\\", \\\"{x:1311,y:883,t:1526328659169};\\\", \\\"{x:1318,y:887,t:1526328659186};\\\", \\\"{x:1323,y:887,t:1526328659203};\\\", \\\"{x:1325,y:889,t:1526328659220};\\\", \\\"{x:1326,y:889,t:1526328659237};\\\", \\\"{x:1324,y:889,t:1526328659385};\\\", \\\"{x:1322,y:888,t:1526328659393};\\\", \\\"{x:1319,y:888,t:1526328659404};\\\", \\\"{x:1305,y:888,t:1526328659420};\\\", \\\"{x:1281,y:888,t:1526328659437};\\\", \\\"{x:1257,y:888,t:1526328659454};\\\", \\\"{x:1245,y:888,t:1526328659469};\\\", \\\"{x:1238,y:890,t:1526328659486};\\\", \\\"{x:1236,y:890,t:1526328659546};\\\", \\\"{x:1234,y:890,t:1526328659562};\\\", \\\"{x:1233,y:890,t:1526328659586};\\\", \\\"{x:1232,y:889,t:1526328659594};\\\", \\\"{x:1231,y:888,t:1526328659665};\\\", \\\"{x:1229,y:886,t:1526328659673};\\\", \\\"{x:1228,y:885,t:1526328659686};\\\", \\\"{x:1219,y:882,t:1526328659703};\\\", \\\"{x:1207,y:876,t:1526328659720};\\\", \\\"{x:1195,y:871,t:1526328659737};\\\", \\\"{x:1180,y:865,t:1526328659753};\\\", \\\"{x:1172,y:863,t:1526328659770};\\\", \\\"{x:1170,y:863,t:1526328659786};\\\", \\\"{x:1169,y:862,t:1526328659865};\\\", \\\"{x:1169,y:861,t:1526328660001};\\\", \\\"{x:1170,y:856,t:1526328660009};\\\", \\\"{x:1174,y:852,t:1526328660020};\\\", \\\"{x:1183,y:841,t:1526328660037};\\\", \\\"{x:1193,y:830,t:1526328660053};\\\", \\\"{x:1200,y:819,t:1526328660070};\\\", \\\"{x:1209,y:806,t:1526328660087};\\\", \\\"{x:1210,y:804,t:1526328660103};\\\", \\\"{x:1210,y:800,t:1526328660377};\\\", \\\"{x:1208,y:791,t:1526328660386};\\\", \\\"{x:1200,y:770,t:1526328660404};\\\", \\\"{x:1197,y:748,t:1526328660420};\\\", \\\"{x:1197,y:730,t:1526328660438};\\\", \\\"{x:1199,y:720,t:1526328660453};\\\", \\\"{x:1199,y:714,t:1526328660470};\\\", \\\"{x:1200,y:714,t:1526328660529};\\\", \\\"{x:1202,y:714,t:1526328660545};\\\", \\\"{x:1203,y:714,t:1526328660561};\\\", \\\"{x:1203,y:715,t:1526328660571};\\\", \\\"{x:1203,y:716,t:1526328660588};\\\", \\\"{x:1203,y:718,t:1526328660604};\\\", \\\"{x:1203,y:719,t:1526328660621};\\\", \\\"{x:1203,y:721,t:1526328660638};\\\", \\\"{x:1203,y:723,t:1526328660654};\\\", \\\"{x:1204,y:725,t:1526328660673};\\\", \\\"{x:1204,y:726,t:1526328660753};\\\", \\\"{x:1205,y:726,t:1526328660857};\\\", \\\"{x:1205,y:727,t:1526328667481};\\\", \\\"{x:1203,y:724,t:1526328669602};\\\", \\\"{x:1198,y:719,t:1526328669609};\\\", \\\"{x:1196,y:717,t:1526328669626};\\\", \\\"{x:1182,y:706,t:1526328669643};\\\", \\\"{x:1156,y:704,t:1526328669659};\\\", \\\"{x:1155,y:704,t:1526328669682};\\\", \\\"{x:1154,y:704,t:1526328673145};\\\", \\\"{x:1156,y:704,t:1526328674033};\\\", \\\"{x:1158,y:704,t:1526328674045};\\\", \\\"{x:1161,y:701,t:1526328674062};\\\", \\\"{x:1165,y:698,t:1526328674079};\\\", \\\"{x:1170,y:694,t:1526328674095};\\\", \\\"{x:1176,y:690,t:1526328674112};\\\", \\\"{x:1189,y:681,t:1526328674129};\\\", \\\"{x:1202,y:673,t:1526328674145};\\\", \\\"{x:1215,y:665,t:1526328674162};\\\", \\\"{x:1223,y:659,t:1526328674179};\\\", \\\"{x:1238,y:650,t:1526328674195};\\\", \\\"{x:1252,y:639,t:1526328674212};\\\", \\\"{x:1267,y:630,t:1526328674229};\\\", \\\"{x:1277,y:622,t:1526328674245};\\\", \\\"{x:1287,y:615,t:1526328674262};\\\", \\\"{x:1291,y:610,t:1526328674280};\\\", \\\"{x:1293,y:608,t:1526328674296};\\\", \\\"{x:1295,y:606,t:1526328674313};\\\", \\\"{x:1296,y:604,t:1526328674330};\\\", \\\"{x:1297,y:603,t:1526328674346};\\\", \\\"{x:1298,y:602,t:1526328674362};\\\", \\\"{x:1299,y:600,t:1526328674380};\\\", \\\"{x:1299,y:598,t:1526328674396};\\\", \\\"{x:1301,y:595,t:1526328674413};\\\", \\\"{x:1301,y:593,t:1526328674429};\\\", \\\"{x:1301,y:591,t:1526328674446};\\\", \\\"{x:1301,y:587,t:1526328674463};\\\", \\\"{x:1301,y:584,t:1526328674479};\\\", \\\"{x:1301,y:580,t:1526328674496};\\\", \\\"{x:1301,y:576,t:1526328674512};\\\", \\\"{x:1301,y:571,t:1526328674529};\\\", \\\"{x:1301,y:569,t:1526328674546};\\\", \\\"{x:1301,y:566,t:1526328674563};\\\", \\\"{x:1301,y:564,t:1526328674579};\\\", \\\"{x:1301,y:562,t:1526328674596};\\\", \\\"{x:1301,y:561,t:1526328674613};\\\", \\\"{x:1301,y:558,t:1526328674629};\\\", \\\"{x:1301,y:557,t:1526328674649};\\\", \\\"{x:1301,y:556,t:1526328674662};\\\", \\\"{x:1301,y:555,t:1526328674679};\\\", \\\"{x:1301,y:554,t:1526328674696};\\\", \\\"{x:1301,y:553,t:1526328674712};\\\", \\\"{x:1300,y:553,t:1526328674953};\\\", \\\"{x:1300,y:554,t:1526328674963};\\\", \\\"{x:1300,y:557,t:1526328674979};\\\", \\\"{x:1298,y:561,t:1526328674996};\\\", \\\"{x:1296,y:569,t:1526328675013};\\\", \\\"{x:1293,y:575,t:1526328675029};\\\", \\\"{x:1290,y:583,t:1526328675046};\\\", \\\"{x:1288,y:588,t:1526328675064};\\\", \\\"{x:1285,y:594,t:1526328675080};\\\", \\\"{x:1284,y:601,t:1526328675096};\\\", \\\"{x:1282,y:608,t:1526328675113};\\\", \\\"{x:1282,y:610,t:1526328675129};\\\", \\\"{x:1281,y:613,t:1526328675147};\\\", \\\"{x:1281,y:619,t:1526328675163};\\\", \\\"{x:1281,y:622,t:1526328675179};\\\", \\\"{x:1281,y:624,t:1526328675196};\\\", \\\"{x:1281,y:626,t:1526328675213};\\\", \\\"{x:1281,y:627,t:1526328675233};\\\", \\\"{x:1281,y:628,t:1526328675457};\\\", \\\"{x:1281,y:629,t:1526328675513};\\\", \\\"{x:1281,y:630,t:1526328675554};\\\", \\\"{x:1280,y:630,t:1526328675649};\\\", \\\"{x:1280,y:631,t:1526328675993};\\\", \\\"{x:1280,y:632,t:1526328676009};\\\", \\\"{x:1280,y:633,t:1526328676025};\\\", \\\"{x:1280,y:635,t:1526328676040};\\\", \\\"{x:1280,y:636,t:1526328676049};\\\", \\\"{x:1280,y:638,t:1526328676066};\\\", \\\"{x:1280,y:642,t:1526328676080};\\\", \\\"{x:1295,y:677,t:1526328676097};\\\", \\\"{x:1312,y:714,t:1526328676113};\\\", \\\"{x:1337,y:755,t:1526328676131};\\\", \\\"{x:1368,y:816,t:1526328676147};\\\", \\\"{x:1405,y:884,t:1526328676164};\\\", \\\"{x:1436,y:932,t:1526328676181};\\\", \\\"{x:1460,y:950,t:1526328676198};\\\", \\\"{x:1466,y:955,t:1526328676214};\\\", \\\"{x:1466,y:954,t:1526328676289};\\\", \\\"{x:1468,y:950,t:1526328676297};\\\", \\\"{x:1475,y:944,t:1526328676313};\\\", \\\"{x:1482,y:940,t:1526328676330};\\\", \\\"{x:1485,y:937,t:1526328676347};\\\", \\\"{x:1486,y:936,t:1526328676363};\\\", \\\"{x:1483,y:936,t:1526328676490};\\\", \\\"{x:1480,y:936,t:1526328676504};\\\", \\\"{x:1479,y:936,t:1526328676514};\\\", \\\"{x:1476,y:936,t:1526328676531};\\\", \\\"{x:1476,y:937,t:1526328676548};\\\", \\\"{x:1474,y:938,t:1526328676563};\\\", \\\"{x:1473,y:939,t:1526328676580};\\\", \\\"{x:1473,y:940,t:1526328676597};\\\", \\\"{x:1473,y:943,t:1526328676614};\\\", \\\"{x:1472,y:945,t:1526328676630};\\\", \\\"{x:1472,y:947,t:1526328676649};\\\", \\\"{x:1472,y:949,t:1526328676665};\\\", \\\"{x:1472,y:951,t:1526328676680};\\\", \\\"{x:1474,y:954,t:1526328676697};\\\", \\\"{x:1475,y:955,t:1526328676715};\\\", \\\"{x:1476,y:956,t:1526328676730};\\\", \\\"{x:1477,y:957,t:1526328676748};\\\", \\\"{x:1477,y:958,t:1526328676785};\\\", \\\"{x:1476,y:958,t:1526328687705};\\\", \\\"{x:1458,y:954,t:1526328687720};\\\", \\\"{x:1406,y:942,t:1526328687738};\\\", \\\"{x:1285,y:927,t:1526328687754};\\\", \\\"{x:1095,y:909,t:1526328687771};\\\", \\\"{x:869,y:884,t:1526328687788};\\\", \\\"{x:671,y:833,t:1526328687803};\\\", \\\"{x:488,y:748,t:1526328687822};\\\", \\\"{x:283,y:670,t:1526328687838};\\\", \\\"{x:176,y:615,t:1526328687854};\\\", \\\"{x:170,y:603,t:1526328687876};\\\", \\\"{x:161,y:594,t:1526328687893};\\\", \\\"{x:141,y:584,t:1526328687910};\\\", \\\"{x:94,y:566,t:1526328687926};\\\", \\\"{x:17,y:532,t:1526328687943};\\\", \\\"{x:0,y:486,t:1526328687960};\\\", \\\"{x:0,y:436,t:1526328687975};\\\", \\\"{x:0,y:345,t:1526328687993};\\\", \\\"{x:0,y:294,t:1526328688008};\\\", \\\"{x:0,y:270,t:1526328688026};\\\", \\\"{x:0,y:252,t:1526328688042};\\\", \\\"{x:18,y:237,t:1526328688060};\\\", \\\"{x:64,y:221,t:1526328688075};\\\", \\\"{x:170,y:201,t:1526328688092};\\\", \\\"{x:292,y:184,t:1526328688110};\\\", \\\"{x:414,y:182,t:1526328688126};\\\", \\\"{x:492,y:182,t:1526328688142};\\\", \\\"{x:519,y:182,t:1526328688160};\\\", \\\"{x:528,y:184,t:1526328688176};\\\", \\\"{x:546,y:194,t:1526328688192};\\\", \\\"{x:562,y:210,t:1526328688210};\\\", \\\"{x:568,y:230,t:1526328688226};\\\", \\\"{x:572,y:240,t:1526328688243};\\\", \\\"{x:572,y:243,t:1526328688260};\\\", \\\"{x:571,y:245,t:1526328688280};\\\", \\\"{x:570,y:248,t:1526328688293};\\\", \\\"{x:561,y:276,t:1526328688310};\\\", \\\"{x:560,y:330,t:1526328688326};\\\", \\\"{x:571,y:395,t:1526328688342};\\\", \\\"{x:589,y:454,t:1526328688360};\\\", \\\"{x:615,y:484,t:1526328688376};\\\", \\\"{x:647,y:504,t:1526328688393};\\\", \\\"{x:667,y:507,t:1526328688410};\\\", \\\"{x:680,y:507,t:1526328688426};\\\", \\\"{x:683,y:507,t:1526328688443};\\\", \\\"{x:685,y:508,t:1526328688459};\\\", \\\"{x:687,y:509,t:1526328688475};\\\", \\\"{x:688,y:511,t:1526328688492};\\\", \\\"{x:690,y:515,t:1526328688508};\\\", \\\"{x:690,y:516,t:1526328688552};\\\", \\\"{x:688,y:516,t:1526328688568};\\\", \\\"{x:686,y:514,t:1526328688577};\\\", \\\"{x:682,y:512,t:1526328688592};\\\", \\\"{x:666,y:497,t:1526328688608};\\\", \\\"{x:654,y:483,t:1526328688626};\\\", \\\"{x:650,y:475,t:1526328688641};\\\", \\\"{x:648,y:471,t:1526328688660};\\\", \\\"{x:648,y:470,t:1526328688677};\\\", \\\"{x:648,y:469,t:1526328688713};\\\", \\\"{x:648,y:468,t:1526328688737};\\\", \\\"{x:648,y:467,t:1526328688777};\\\", \\\"{x:647,y:467,t:1526328688793};\\\", \\\"{x:647,y:466,t:1526328688809};\\\", \\\"{x:646,y:465,t:1526328689041};\\\", \\\"{x:647,y:463,t:1526328689049};\\\", \\\"{x:648,y:463,t:1526328689064};\\\", \\\"{x:648,y:464,t:1526328689217};\\\", \\\"{x:648,y:463,t:1526328689800};\\\", \\\"{x:648,y:462,t:1526328689810};\\\", \\\"{x:648,y:461,t:1526328689833};\\\", \\\"{x:648,y:460,t:1526328690241};\\\", \\\"{x:649,y:458,t:1526328690249};\\\", \\\"{x:655,y:458,t:1526328690261};\\\", \\\"{x:667,y:458,t:1526328690277};\\\", \\\"{x:683,y:458,t:1526328690294};\\\", \\\"{x:694,y:458,t:1526328690311};\\\", \\\"{x:699,y:458,t:1526328690328};\\\", \\\"{x:701,y:458,t:1526328690344};\\\", \\\"{x:702,y:458,t:1526328690361};\\\", \\\"{x:704,y:459,t:1526328690378};\\\", \\\"{x:705,y:459,t:1526328690394};\\\", \\\"{x:696,y:459,t:1526328694921};\\\", \\\"{x:681,y:459,t:1526328694931};\\\", \\\"{x:633,y:454,t:1526328694947};\\\", \\\"{x:586,y:448,t:1526328694963};\\\", \\\"{x:564,y:446,t:1526328694982};\\\", \\\"{x:562,y:446,t:1526328694997};\\\", \\\"{x:561,y:445,t:1526328695257};\\\", \\\"{x:563,y:443,t:1526328695273};\\\", \\\"{x:564,y:443,t:1526328695280};\\\", \\\"{x:566,y:442,t:1526328695298};\\\", \\\"{x:570,y:440,t:1526328695314};\\\", \\\"{x:571,y:439,t:1526328695331};\\\", \\\"{x:573,y:434,t:1526328695348};\\\", \\\"{x:573,y:430,t:1526328695364};\\\", \\\"{x:572,y:429,t:1526328695384};\\\", \\\"{x:564,y:429,t:1526328695398};\\\", \\\"{x:539,y:429,t:1526328695414};\\\", \\\"{x:510,y:433,t:1526328695431};\\\", \\\"{x:466,y:449,t:1526328695448};\\\", \\\"{x:447,y:459,t:1526328695464};\\\", \\\"{x:443,y:462,t:1526328695481};\\\", \\\"{x:442,y:463,t:1526328695505};\\\", \\\"{x:438,y:463,t:1526328695537};\\\", \\\"{x:434,y:461,t:1526328695548};\\\", \\\"{x:418,y:458,t:1526328695564};\\\", \\\"{x:405,y:455,t:1526328695581};\\\", \\\"{x:400,y:455,t:1526328695598};\\\", \\\"{x:399,y:455,t:1526328695614};\\\", \\\"{x:400,y:455,t:1526328695753};\\\", \\\"{x:408,y:455,t:1526328695764};\\\", \\\"{x:434,y:455,t:1526328695781};\\\", \\\"{x:464,y:455,t:1526328695798};\\\", \\\"{x:484,y:455,t:1526328695815};\\\", \\\"{x:490,y:455,t:1526328695831};\\\", \\\"{x:491,y:455,t:1526328695848};\\\", \\\"{x:494,y:455,t:1526328695945};\\\", \\\"{x:499,y:455,t:1526328695953};\\\", \\\"{x:504,y:455,t:1526328695965};\\\", \\\"{x:524,y:455,t:1526328695981};\\\", \\\"{x:535,y:455,t:1526328695998};\\\", \\\"{x:545,y:457,t:1526328696016};\\\", \\\"{x:547,y:458,t:1526328696031};\\\", \\\"{x:548,y:458,t:1526328696048};\\\", \\\"{x:550,y:458,t:1526328696129};\\\", \\\"{x:552,y:458,t:1526328696137};\\\", \\\"{x:554,y:458,t:1526328696148};\\\", \\\"{x:564,y:458,t:1526328696166};\\\", \\\"{x:578,y:461,t:1526328696181};\\\", \\\"{x:588,y:461,t:1526328696198};\\\", \\\"{x:597,y:462,t:1526328696215};\\\", \\\"{x:606,y:465,t:1526328696232};\\\", \\\"{x:612,y:465,t:1526328696248};\\\", \\\"{x:620,y:466,t:1526328696265};\\\", \\\"{x:624,y:466,t:1526328696281};\\\", \\\"{x:631,y:466,t:1526328696298};\\\", \\\"{x:638,y:466,t:1526328696315};\\\", \\\"{x:642,y:466,t:1526328696333};\\\", \\\"{x:646,y:466,t:1526328696349};\\\", \\\"{x:647,y:466,t:1526328696473};\\\", \\\"{x:647,y:465,t:1526328696489};\\\", \\\"{x:647,y:464,t:1526328696498};\\\", \\\"{x:645,y:461,t:1526328696515};\\\", \\\"{x:639,y:459,t:1526328696532};\\\", \\\"{x:628,y:457,t:1526328696548};\\\", \\\"{x:614,y:456,t:1526328696565};\\\", \\\"{x:599,y:454,t:1526328696582};\\\", \\\"{x:583,y:454,t:1526328696598};\\\", \\\"{x:570,y:454,t:1526328696615};\\\", \\\"{x:566,y:454,t:1526328696633};\\\", \\\"{x:565,y:454,t:1526328696648};\\\", \\\"{x:568,y:454,t:1526328696753};\\\", \\\"{x:569,y:454,t:1526328696765};\\\", \\\"{x:576,y:454,t:1526328696782};\\\", \\\"{x:580,y:454,t:1526328696798};\\\", \\\"{x:584,y:454,t:1526328696815};\\\", \\\"{x:585,y:454,t:1526328696832};\\\", \\\"{x:587,y:454,t:1526328696873};\\\", \\\"{x:588,y:454,t:1526328696889};\\\", \\\"{x:591,y:454,t:1526328696899};\\\", \\\"{x:600,y:454,t:1526328696915};\\\", \\\"{x:609,y:454,t:1526328696933};\\\", \\\"{x:614,y:454,t:1526328696949};\\\", \\\"{x:618,y:454,t:1526328696966};\\\", \\\"{x:619,y:454,t:1526328696982};\\\", \\\"{x:620,y:454,t:1526328696999};\\\", \\\"{x:621,y:454,t:1526328697016};\\\", \\\"{x:622,y:455,t:1526328697032};\\\", \\\"{x:624,y:455,t:1526328697049};\\\", \\\"{x:626,y:455,t:1526328697065};\\\", \\\"{x:628,y:455,t:1526328697082};\\\", \\\"{x:631,y:455,t:1526328697100};\\\", \\\"{x:636,y:457,t:1526328697115};\\\", \\\"{x:638,y:457,t:1526328697353};\\\", \\\"{x:640,y:457,t:1526328697366};\\\", \\\"{x:651,y:457,t:1526328697382};\\\", \\\"{x:662,y:457,t:1526328697399};\\\", \\\"{x:672,y:457,t:1526328697416};\\\", \\\"{x:681,y:457,t:1526328697432};\\\", \\\"{x:683,y:457,t:1526328697449};\\\", \\\"{x:686,y:457,t:1526328697466};\\\", \\\"{x:688,y:457,t:1526328697482};\\\", \\\"{x:691,y:457,t:1526328697499};\\\", \\\"{x:695,y:458,t:1526328697516};\\\", \\\"{x:699,y:458,t:1526328697532};\\\", \\\"{x:703,y:459,t:1526328697549};\\\", \\\"{x:706,y:459,t:1526328697566};\\\", \\\"{x:706,y:449,t:1526328715732};\\\", \\\"{x:683,y:387,t:1526328715749};\\\", \\\"{x:666,y:323,t:1526328715766};\\\", \\\"{x:659,y:275,t:1526328715782};\\\", \\\"{x:641,y:230,t:1526328715798};\\\", \\\"{x:606,y:186,t:1526328715815};\\\", \\\"{x:512,y:142,t:1526328715832};\\\", \\\"{x:392,y:106,t:1526328715848};\\\", \\\"{x:244,y:76,t:1526328715866};\\\", \\\"{x:89,y:67,t:1526328715881};\\\", \\\"{x:0,y:82,t:1526328715898};\\\", \\\"{x:0,y:118,t:1526328715916};\\\", \\\"{x:0,y:158,t:1526328715932};\\\", \\\"{x:0,y:202,t:1526328715949};\\\", \\\"{x:0,y:212,t:1526328715965};\\\", \\\"{x:0,y:223,t:1526328715981};\\\", \\\"{x:0,y:236,t:1526328715998};\\\", \\\"{x:0,y:264,t:1526328716015};\\\", \\\"{x:2,y:283,t:1526328716031};\\\", \\\"{x:5,y:296,t:1526328716048};\\\", \\\"{x:11,y:311,t:1526328716065};\\\", \\\"{x:25,y:330,t:1526328716082};\\\", \\\"{x:56,y:366,t:1526328716098};\\\", \\\"{x:100,y:414,t:1526328716116};\\\", \\\"{x:175,y:474,t:1526328716131};\\\", \\\"{x:244,y:517,t:1526328716149};\\\", \\\"{x:329,y:551,t:1526328716166};\\\", \\\"{x:409,y:586,t:1526328716183};\\\", \\\"{x:483,y:613,t:1526328716202};\\\", \\\"{x:534,y:624,t:1526328716219};\\\", \\\"{x:579,y:630,t:1526328716236};\\\", \\\"{x:608,y:630,t:1526328716251};\\\", \\\"{x:656,y:622,t:1526328716268};\\\", \\\"{x:692,y:607,t:1526328716285};\\\", \\\"{x:711,y:596,t:1526328716302};\\\", \\\"{x:736,y:584,t:1526328716319};\\\", \\\"{x:755,y:570,t:1526328716335};\\\", \\\"{x:770,y:555,t:1526328716352};\\\", \\\"{x:782,y:543,t:1526328716368};\\\", \\\"{x:788,y:528,t:1526328716386};\\\", \\\"{x:795,y:516,t:1526328716403};\\\", \\\"{x:798,y:507,t:1526328716419};\\\", \\\"{x:801,y:500,t:1526328716435};\\\", \\\"{x:802,y:494,t:1526328716452};\\\", \\\"{x:802,y:491,t:1526328716468};\\\", \\\"{x:802,y:489,t:1526328716486};\\\", \\\"{x:801,y:488,t:1526328716503};\\\", \\\"{x:801,y:486,t:1526328716519};\\\", \\\"{x:801,y:485,t:1526328716536};\\\", \\\"{x:802,y:482,t:1526328716552};\\\", \\\"{x:802,y:480,t:1526328716568};\\\", \\\"{x:802,y:479,t:1526328716585};\\\", \\\"{x:804,y:476,t:1526328716602};\\\", \\\"{x:805,y:475,t:1526328716618};\\\", \\\"{x:805,y:473,t:1526328716635};\\\", \\\"{x:807,y:471,t:1526328716652};\\\", \\\"{x:808,y:470,t:1526328717252};\\\", \\\"{x:809,y:469,t:1526328717259};\\\", \\\"{x:810,y:468,t:1526328717270};\\\", \\\"{x:813,y:467,t:1526328717286};\\\", \\\"{x:817,y:466,t:1526328717302};\\\", \\\"{x:820,y:465,t:1526328717319};\\\", \\\"{x:822,y:465,t:1526328717336};\\\", \\\"{x:823,y:465,t:1526328717353};\\\", \\\"{x:824,y:464,t:1526328717369};\\\", \\\"{x:825,y:464,t:1526328717387};\\\", \\\"{x:827,y:463,t:1526328717404};\\\", \\\"{x:828,y:463,t:1526328717451};\\\", \\\"{x:833,y:463,t:1526328718212};\\\", \\\"{x:838,y:462,t:1526328718220};\\\", \\\"{x:850,y:461,t:1526328718236};\\\", \\\"{x:871,y:461,t:1526328718253};\\\", \\\"{x:899,y:463,t:1526328718270};\\\", \\\"{x:963,y:482,t:1526328718286};\\\", \\\"{x:1060,y:508,t:1526328718303};\\\", \\\"{x:1165,y:541,t:1526328718321};\\\", \\\"{x:1286,y:587,t:1526328718337};\\\", \\\"{x:1420,y:662,t:1526328718353};\\\", \\\"{x:1525,y:734,t:1526328718371};\\\", \\\"{x:1572,y:776,t:1526328718386};\\\", \\\"{x:1597,y:809,t:1526328718403};\\\", \\\"{x:1602,y:821,t:1526328718420};\\\", \\\"{x:1603,y:827,t:1526328718437};\\\", \\\"{x:1603,y:837,t:1526328718454};\\\", \\\"{x:1603,y:854,t:1526328718470};\\\", \\\"{x:1604,y:879,t:1526328718486};\\\", \\\"{x:1606,y:900,t:1526328718503};\\\", \\\"{x:1607,y:912,t:1526328718521};\\\", \\\"{x:1607,y:919,t:1526328718536};\\\", \\\"{x:1607,y:922,t:1526328718554};\\\", \\\"{x:1601,y:923,t:1526328718570};\\\", \\\"{x:1575,y:923,t:1526328718587};\\\", \\\"{x:1525,y:920,t:1526328718604};\\\", \\\"{x:1407,y:904,t:1526328718620};\\\", \\\"{x:1330,y:888,t:1526328718638};\\\", \\\"{x:1284,y:875,t:1526328718654};\\\", \\\"{x:1274,y:870,t:1526328718670};\\\", \\\"{x:1272,y:869,t:1526328718688};\\\", \\\"{x:1272,y:868,t:1526328718704};\\\", \\\"{x:1274,y:864,t:1526328718720};\\\", \\\"{x:1278,y:858,t:1526328718737};\\\", \\\"{x:1288,y:847,t:1526328718753};\\\", \\\"{x:1301,y:831,t:1526328718770};\\\", \\\"{x:1316,y:814,t:1526328718788};\\\", \\\"{x:1331,y:799,t:1526328718804};\\\", \\\"{x:1348,y:783,t:1526328718820};\\\", \\\"{x:1352,y:779,t:1526328718838};\\\", \\\"{x:1354,y:777,t:1526328718853};\\\", \\\"{x:1359,y:774,t:1526328718871};\\\", \\\"{x:1361,y:773,t:1526328718887};\\\", \\\"{x:1363,y:773,t:1526328718904};\\\", \\\"{x:1364,y:771,t:1526328718920};\\\", \\\"{x:1366,y:770,t:1526328718964};\\\", \\\"{x:1367,y:769,t:1526328718972};\\\", \\\"{x:1368,y:768,t:1526328718988};\\\", \\\"{x:1369,y:768,t:1526328719003};\\\", \\\"{x:1368,y:768,t:1526328719172};\\\", \\\"{x:1366,y:768,t:1526328719188};\\\", \\\"{x:1364,y:768,t:1526328719205};\\\", \\\"{x:1362,y:768,t:1526328719220};\\\", \\\"{x:1361,y:768,t:1526328719238};\\\", \\\"{x:1360,y:769,t:1526328719259};\\\", \\\"{x:1359,y:769,t:1526328719292};\\\", \\\"{x:1359,y:770,t:1526328719348};\\\", \\\"{x:1358,y:770,t:1526328719380};\\\", \\\"{x:1358,y:766,t:1526328719387};\\\", \\\"{x:1358,y:763,t:1526328719404};\\\", \\\"{x:1358,y:759,t:1526328719421};\\\", \\\"{x:1358,y:758,t:1526328719437};\\\", \\\"{x:1358,y:757,t:1526328719455};\\\", \\\"{x:1356,y:761,t:1526328719580};\\\", \\\"{x:1353,y:763,t:1526328719589};\\\", \\\"{x:1349,y:768,t:1526328719604};\\\", \\\"{x:1340,y:774,t:1526328719621};\\\", \\\"{x:1331,y:791,t:1526328719637};\\\", \\\"{x:1328,y:806,t:1526328719655};\\\", \\\"{x:1325,y:820,t:1526328719671};\\\", \\\"{x:1324,y:832,t:1526328719688};\\\", \\\"{x:1324,y:838,t:1526328719705};\\\", \\\"{x:1324,y:845,t:1526328719722};\\\", \\\"{x:1324,y:859,t:1526328719738};\\\", \\\"{x:1325,y:873,t:1526328719755};\\\", \\\"{x:1325,y:903,t:1526328719772};\\\", \\\"{x:1325,y:916,t:1526328719788};\\\", \\\"{x:1325,y:928,t:1526328719805};\\\", \\\"{x:1325,y:937,t:1526328719822};\\\", \\\"{x:1325,y:948,t:1526328719838};\\\", \\\"{x:1325,y:955,t:1526328719854};\\\", \\\"{x:1325,y:958,t:1526328719871};\\\", \\\"{x:1326,y:959,t:1526328719932};\\\", \\\"{x:1326,y:958,t:1526328719940};\\\", \\\"{x:1329,y:955,t:1526328719954};\\\", \\\"{x:1338,y:937,t:1526328719972};\\\", \\\"{x:1349,y:912,t:1526328719988};\\\", \\\"{x:1366,y:849,t:1526328720005};\\\", \\\"{x:1379,y:757,t:1526328720022};\\\", \\\"{x:1383,y:678,t:1526328720039};\\\", \\\"{x:1384,y:640,t:1526328720054};\\\", \\\"{x:1386,y:625,t:1526328720071};\\\", \\\"{x:1386,y:624,t:1526328720089};\\\", \\\"{x:1386,y:629,t:1526328720140};\\\", \\\"{x:1380,y:640,t:1526328720155};\\\", \\\"{x:1366,y:679,t:1526328720172};\\\", \\\"{x:1366,y:691,t:1526328720187};\\\", \\\"{x:1374,y:699,t:1526328720205};\\\", \\\"{x:1382,y:715,t:1526328720222};\\\", \\\"{x:1396,y:727,t:1526328720239};\\\", \\\"{x:1412,y:740,t:1526328720254};\\\", \\\"{x:1421,y:747,t:1526328720272};\\\", \\\"{x:1423,y:753,t:1526328720289};\\\", \\\"{x:1426,y:760,t:1526328720304};\\\", \\\"{x:1426,y:764,t:1526328720321};\\\", \\\"{x:1427,y:766,t:1526328720339};\\\", \\\"{x:1427,y:767,t:1526328720356};\\\", \\\"{x:1428,y:769,t:1526328720484};\\\", \\\"{x:1429,y:769,t:1526328720708};\\\", \\\"{x:1429,y:768,t:1526328721100};\\\", \\\"{x:1429,y:767,t:1526328721268};\\\", \\\"{x:1430,y:766,t:1526328721348};\\\", \\\"{x:1431,y:765,t:1526328721428};\\\", \\\"{x:1431,y:764,t:1526328721440};\\\", \\\"{x:1436,y:764,t:1526328721455};\\\", \\\"{x:1444,y:763,t:1526328721473};\\\", \\\"{x:1463,y:758,t:1526328721489};\\\", \\\"{x:1487,y:744,t:1526328721506};\\\", \\\"{x:1521,y:719,t:1526328721523};\\\", \\\"{x:1608,y:641,t:1526328721540};\\\", \\\"{x:1716,y:564,t:1526328721556};\\\", \\\"{x:1853,y:489,t:1526328721573};\\\", \\\"{x:1919,y:425,t:1526328721589};\\\", \\\"{x:1919,y:362,t:1526328721607};\\\", \\\"{x:1919,y:317,t:1526328721623};\\\", \\\"{x:1919,y:301,t:1526328721639};\\\", \\\"{x:1919,y:290,t:1526328721656};\\\", \\\"{x:1919,y:287,t:1526328721673};\\\", \\\"{x:1919,y:284,t:1526328721689};\\\", \\\"{x:1919,y:283,t:1526328721706};\\\", \\\"{x:1919,y:280,t:1526328721828};\\\", \\\"{x:1919,y:279,t:1526328721840};\\\", \\\"{x:1918,y:274,t:1526328721857};\\\", \\\"{x:1899,y:261,t:1526328721873};\\\", \\\"{x:1833,y:233,t:1526328721890};\\\", \\\"{x:1684,y:189,t:1526328721907};\\\", \\\"{x:1464,y:163,t:1526328721923};\\\", \\\"{x:1056,y:106,t:1526328721939};\\\", \\\"{x:772,y:60,t:1526328721957};\\\", \\\"{x:528,y:20,t:1526328721973};\\\", \\\"{x:335,y:0,t:1526328721989};\\\", \\\"{x:200,y:0,t:1526328722006};\\\", \\\"{x:128,y:0,t:1526328722022};\\\", \\\"{x:84,y:0,t:1526328722039};\\\", \\\"{x:63,y:0,t:1526328722057};\\\", \\\"{x:50,y:0,t:1526328722073};\\\", \\\"{x:45,y:0,t:1526328722089};\\\", \\\"{x:42,y:0,t:1526328722107};\\\", \\\"{x:39,y:0,t:1526328722122};\\\", \\\"{x:38,y:14,t:1526328722140};\\\", \\\"{x:38,y:33,t:1526328722157};\\\", \\\"{x:42,y:57,t:1526328722173};\\\", \\\"{x:52,y:78,t:1526328722189};\\\", \\\"{x:63,y:96,t:1526328722207};\\\", \\\"{x:78,y:112,t:1526328722224};\\\", \\\"{x:85,y:121,t:1526328722239};\\\", \\\"{x:90,y:123,t:1526328722257};\\\", \\\"{x:94,y:126,t:1526328722274};\\\", \\\"{x:97,y:126,t:1526328722290};\\\", \\\"{x:101,y:126,t:1526328722307};\\\", \\\"{x:106,y:126,t:1526328722324};\\\", \\\"{x:114,y:126,t:1526328722339};\\\", \\\"{x:128,y:124,t:1526328722357};\\\", \\\"{x:142,y:122,t:1526328722374};\\\", \\\"{x:151,y:120,t:1526328722390};\\\", \\\"{x:157,y:119,t:1526328722406};\\\", \\\"{x:161,y:118,t:1526328722423};\\\", \\\"{x:165,y:116,t:1526328722440};\\\", \\\"{x:170,y:116,t:1526328722456};\\\", \\\"{x:176,y:116,t:1526328722474};\\\", \\\"{x:185,y:115,t:1526328722489};\\\", \\\"{x:188,y:114,t:1526328722507};\\\", \\\"{x:189,y:114,t:1526328722523};\\\", \\\"{x:191,y:114,t:1526328723484};\\\", \\\"{x:194,y:112,t:1526328723492};\\\", \\\"{x:202,y:112,t:1526328723508};\\\", \\\"{x:207,y:112,t:1526328723524};\\\", \\\"{x:211,y:111,t:1526328723541};\\\", \\\"{x:211,y:110,t:1526328723558};\\\", \\\"{x:213,y:110,t:1526328724131};\\\", \\\"{x:223,y:110,t:1526328724141};\\\", \\\"{x:246,y:110,t:1526328724157};\\\", \\\"{x:269,y:110,t:1526328724175};\\\", \\\"{x:295,y:110,t:1526328724192};\\\", \\\"{x:315,y:110,t:1526328724207};\\\", \\\"{x:337,y:107,t:1526328724225};\\\", \\\"{x:361,y:105,t:1526328724241};\\\", \\\"{x:385,y:100,t:1526328724258};\\\", \\\"{x:413,y:97,t:1526328724275};\\\", \\\"{x:454,y:90,t:1526328724292};\\\", \\\"{x:479,y:84,t:1526328724308};\\\", \\\"{x:498,y:79,t:1526328724325};\\\", \\\"{x:515,y:75,t:1526328724342};\\\", \\\"{x:534,y:68,t:1526328724358};\\\", \\\"{x:557,y:65,t:1526328724375};\\\", \\\"{x:579,y:58,t:1526328724391};\\\", \\\"{x:595,y:55,t:1526328724407};\\\", \\\"{x:602,y:51,t:1526328724425};\\\", \\\"{x:608,y:49,t:1526328724441};\\\", \\\"{x:612,y:47,t:1526328724458};\\\", \\\"{x:615,y:46,t:1526328724475};\\\", \\\"{x:617,y:45,t:1526328724492};\\\", \\\"{x:618,y:44,t:1526328724508};\\\", \\\"{x:619,y:44,t:1526328724732};\\\", \\\"{x:620,y:44,t:1526328724742};\\\", \\\"{x:621,y:44,t:1526328724852};\\\", \\\"{x:622,y:44,t:1526328724859};\\\", \\\"{x:624,y:43,t:1526328724874};\\\", \\\"{x:625,y:42,t:1526328724891};\\\", \\\"{x:626,y:42,t:1526328724915};\\\", \\\"{x:628,y:42,t:1526328724925};\\\", \\\"{x:630,y:42,t:1526328724942};\\\", \\\"{x:632,y:42,t:1526328724959};\\\", \\\"{x:635,y:41,t:1526328724974};\\\", \\\"{x:638,y:41,t:1526328724992};\\\", \\\"{x:640,y:40,t:1526328725008};\\\", \\\"{x:641,y:40,t:1526328725026};\\\", \\\"{x:643,y:40,t:1526328725041};\\\", \\\"{x:644,y:40,t:1526328725059};\\\", \\\"{x:645,y:40,t:1526328725075};\\\", \\\"{x:647,y:40,t:1526328725091};\\\", \\\"{x:649,y:40,t:1526328725108};\\\", \\\"{x:652,y:40,t:1526328725126};\\\", \\\"{x:654,y:40,t:1526328725142};\\\", \\\"{x:656,y:40,t:1526328725159};\\\", \\\"{x:657,y:40,t:1526328725175};\\\", \\\"{x:658,y:40,t:1526328725192};\\\", \\\"{x:659,y:40,t:1526328725228};\\\", \\\"{x:660,y:40,t:1526328725260};\\\", \\\"{x:661,y:40,t:1526328725275};\\\", \\\"{x:655,y:47,t:1526328725796};\\\", \\\"{x:644,y:68,t:1526328725809};\\\", \\\"{x:593,y:146,t:1526328725826};\\\", \\\"{x:539,y:224,t:1526328725843};\\\", \\\"{x:494,y:280,t:1526328725859};\\\", \\\"{x:472,y:326,t:1526328725876};\\\", \\\"{x:469,y:335,t:1526328725893};\\\", \\\"{x:469,y:338,t:1526328725908};\\\", \\\"{x:469,y:339,t:1526328725926};\\\", \\\"{x:469,y:340,t:1526328725943};\\\", \\\"{x:469,y:341,t:1526328725987};\\\", \\\"{x:469,y:340,t:1526328726740};\\\", \\\"{x:470,y:339,t:1526328726748};\\\", \\\"{x:473,y:337,t:1526328726759};\\\", \\\"{x:477,y:334,t:1526328726777};\\\", \\\"{x:480,y:333,t:1526328726793};\\\", \\\"{x:485,y:330,t:1526328726809};\\\", \\\"{x:486,y:330,t:1526328726828};\\\", \\\"{x:484,y:330,t:1526328727476};\\\", \\\"{x:474,y:330,t:1526328727483};\\\", \\\"{x:467,y:332,t:1526328727494};\\\", \\\"{x:425,y:343,t:1526328727510};\\\", \\\"{x:386,y:354,t:1526328727527};\\\", \\\"{x:353,y:366,t:1526328727544};\\\", \\\"{x:341,y:370,t:1526328727560};\\\", \\\"{x:338,y:370,t:1526328727577};\\\", \\\"{x:338,y:371,t:1526328727594};\\\", \\\"{x:337,y:371,t:1526328727611};\\\", \\\"{x:331,y:373,t:1526328727627};\\\", \\\"{x:316,y:381,t:1526328727644};\\\", \\\"{x:310,y:385,t:1526328727661};\\\", \\\"{x:307,y:389,t:1526328727677};\\\", \\\"{x:304,y:393,t:1526328727694};\\\", \\\"{x:304,y:397,t:1526328727711};\\\", \\\"{x:304,y:400,t:1526328727727};\\\", \\\"{x:304,y:404,t:1526328727744};\\\", \\\"{x:304,y:405,t:1526328727761};\\\", \\\"{x:304,y:407,t:1526328727777};\\\", \\\"{x:308,y:409,t:1526328733972};\\\", \\\"{x:319,y:413,t:1526328733982};\\\", \\\"{x:343,y:424,t:1526328733997};\\\", \\\"{x:382,y:425,t:1526328734015};\\\", \\\"{x:438,y:425,t:1526328734032};\\\", \\\"{x:522,y:425,t:1526328734048};\\\", \\\"{x:616,y:425,t:1526328734065};\\\", \\\"{x:702,y:425,t:1526328734082};\\\", \\\"{x:772,y:425,t:1526328734099};\\\", \\\"{x:816,y:425,t:1526328734115};\\\", \\\"{x:877,y:428,t:1526328734132};\\\", \\\"{x:926,y:439,t:1526328734149};\\\", \\\"{x:964,y:443,t:1526328734165};\\\", \\\"{x:1006,y:448,t:1526328734182};\\\", \\\"{x:1046,y:454,t:1526328734199};\\\", \\\"{x:1088,y:455,t:1526328734215};\\\", \\\"{x:1114,y:455,t:1526328734233};\\\", \\\"{x:1138,y:455,t:1526328734249};\\\", \\\"{x:1154,y:455,t:1526328734265};\\\", \\\"{x:1164,y:452,t:1526328734282};\\\", \\\"{x:1168,y:449,t:1526328734299};\\\", \\\"{x:1169,y:449,t:1526328734315};\\\", \\\"{x:1169,y:443,t:1526328734333};\\\", \\\"{x:1166,y:438,t:1526328734349};\\\", \\\"{x:1155,y:432,t:1526328734365};\\\", \\\"{x:1147,y:428,t:1526328734382};\\\", \\\"{x:1133,y:422,t:1526328734399};\\\", \\\"{x:1119,y:416,t:1526328734415};\\\", \\\"{x:1104,y:408,t:1526328734432};\\\", \\\"{x:1083,y:403,t:1526328734449};\\\", \\\"{x:1058,y:399,t:1526328734465};\\\", \\\"{x:1036,y:396,t:1526328734482};\\\", \\\"{x:1016,y:394,t:1526328734499};\\\", \\\"{x:1001,y:389,t:1526328734515};\\\", \\\"{x:998,y:388,t:1526328734532};\\\", \\\"{x:997,y:387,t:1526328734549};\\\", \\\"{x:997,y:384,t:1526328734565};\\\", \\\"{x:990,y:374,t:1526328734582};\\\", \\\"{x:980,y:361,t:1526328734599};\\\", \\\"{x:970,y:340,t:1526328734616};\\\", \\\"{x:958,y:317,t:1526328734632};\\\", \\\"{x:942,y:291,t:1526328734649};\\\", \\\"{x:930,y:270,t:1526328734666};\\\", \\\"{x:922,y:258,t:1526328734682};\\\", \\\"{x:908,y:240,t:1526328734699};\\\", \\\"{x:885,y:212,t:1526328734716};\\\", \\\"{x:867,y:189,t:1526328734732};\\\", \\\"{x:850,y:162,t:1526328734749};\\\", \\\"{x:838,y:133,t:1526328734766};\\\", \\\"{x:820,y:95,t:1526328734782};\\\", \\\"{x:808,y:66,t:1526328734799};\\\", \\\"{x:801,y:45,t:1526328734816};\\\", \\\"{x:796,y:30,t:1526328734832};\\\", \\\"{x:794,y:21,t:1526328734849};\\\", \\\"{x:792,y:15,t:1526328734866};\\\", \\\"{x:792,y:12,t:1526328734882};\\\", \\\"{x:792,y:7,t:1526328734899};\\\", \\\"{x:791,y:0,t:1526328734916};\\\", \\\"{x:788,y:0,t:1526328734932};\\\", \\\"{x:787,y:0,t:1526328734949};\\\", \\\"{x:786,y:0,t:1526328734979};\\\", \\\"{x:784,y:0,t:1526328734987};\\\", \\\"{x:785,y:0,t:1526328736788};\\\", \\\"{x:806,y:15,t:1526328736800};\\\", \\\"{x:880,y:93,t:1526328736817};\\\", \\\"{x:988,y:192,t:1526328736834};\\\", \\\"{x:1130,y:302,t:1526328736850};\\\", \\\"{x:1276,y:392,t:1526328736868};\\\", \\\"{x:1470,y:478,t:1526328736884};\\\", \\\"{x:1534,y:497,t:1526328736900};\\\", \\\"{x:1551,y:502,t:1526328736918};\\\", \\\"{x:1556,y:504,t:1526328736934};\\\", \\\"{x:1561,y:509,t:1526328736951};\\\", \\\"{x:1576,y:519,t:1526328736968};\\\", \\\"{x:1591,y:524,t:1526328736984};\\\", \\\"{x:1609,y:532,t:1526328737002};\\\", \\\"{x:1628,y:537,t:1526328737017};\\\", \\\"{x:1638,y:539,t:1526328737035};\\\", \\\"{x:1647,y:543,t:1526328737051};\\\", \\\"{x:1658,y:548,t:1526328737067};\\\", \\\"{x:1665,y:554,t:1526328737084};\\\", \\\"{x:1667,y:555,t:1526328737102};\\\", \\\"{x:1668,y:558,t:1526328737117};\\\", \\\"{x:1668,y:573,t:1526328737134};\\\", \\\"{x:1667,y:603,t:1526328737152};\\\", \\\"{x:1649,y:649,t:1526328737167};\\\", \\\"{x:1628,y:696,t:1526328737184};\\\", \\\"{x:1614,y:729,t:1526328737201};\\\", \\\"{x:1596,y:759,t:1526328737217};\\\", \\\"{x:1578,y:783,t:1526328737234};\\\", \\\"{x:1555,y:807,t:1526328737251};\\\", \\\"{x:1541,y:820,t:1526328737267};\\\", \\\"{x:1536,y:827,t:1526328737284};\\\", \\\"{x:1528,y:834,t:1526328737301};\\\", \\\"{x:1520,y:838,t:1526328737317};\\\", \\\"{x:1513,y:841,t:1526328737334};\\\", \\\"{x:1509,y:841,t:1526328737352};\\\", \\\"{x:1504,y:844,t:1526328737367};\\\", \\\"{x:1503,y:844,t:1526328737388};\\\", \\\"{x:1502,y:844,t:1526328737402};\\\", \\\"{x:1496,y:844,t:1526328737418};\\\", \\\"{x:1476,y:846,t:1526328737434};\\\", \\\"{x:1423,y:856,t:1526328737451};\\\", \\\"{x:1391,y:859,t:1526328737467};\\\", \\\"{x:1375,y:862,t:1526328737484};\\\", \\\"{x:1371,y:863,t:1526328737501};\\\", \\\"{x:1370,y:863,t:1526328737518};\\\", \\\"{x:1367,y:862,t:1526328737579};\\\", \\\"{x:1364,y:857,t:1526328737588};\\\", \\\"{x:1357,y:846,t:1526328737601};\\\", \\\"{x:1339,y:815,t:1526328737618};\\\", \\\"{x:1328,y:786,t:1526328737634};\\\", \\\"{x:1319,y:756,t:1526328737651};\\\", \\\"{x:1317,y:741,t:1526328737668};\\\", \\\"{x:1317,y:719,t:1526328737685};\\\", \\\"{x:1319,y:695,t:1526328737701};\\\", \\\"{x:1325,y:675,t:1526328737719};\\\", \\\"{x:1328,y:665,t:1526328737735};\\\", \\\"{x:1329,y:656,t:1526328737752};\\\", \\\"{x:1331,y:649,t:1526328737768};\\\", \\\"{x:1333,y:641,t:1526328737784};\\\", \\\"{x:1336,y:637,t:1526328737801};\\\", \\\"{x:1340,y:627,t:1526328737818};\\\", \\\"{x:1341,y:615,t:1526328737834};\\\", \\\"{x:1344,y:598,t:1526328737851};\\\", \\\"{x:1338,y:584,t:1526328737868};\\\", \\\"{x:1330,y:573,t:1526328737885};\\\", \\\"{x:1324,y:566,t:1526328737902};\\\", \\\"{x:1318,y:562,t:1526328737918};\\\", \\\"{x:1312,y:558,t:1526328737935};\\\", \\\"{x:1308,y:555,t:1526328737951};\\\", \\\"{x:1306,y:554,t:1526328737969};\\\", \\\"{x:1304,y:554,t:1526328738092};\\\", \\\"{x:1304,y:555,t:1526328738102};\\\", \\\"{x:1304,y:556,t:1526328738119};\\\", \\\"{x:1303,y:556,t:1526328738332};\\\", \\\"{x:1300,y:556,t:1526328738340};\\\", \\\"{x:1298,y:555,t:1526328738352};\\\", \\\"{x:1289,y:551,t:1526328738368};\\\", \\\"{x:1281,y:549,t:1526328738385};\\\", \\\"{x:1278,y:549,t:1526328738402};\\\", \\\"{x:1276,y:548,t:1526328738418};\\\", \\\"{x:1276,y:547,t:1526328738435};\\\", \\\"{x:1276,y:548,t:1526328738524};\\\", \\\"{x:1276,y:550,t:1526328738536};\\\", \\\"{x:1274,y:554,t:1526328738552};\\\", \\\"{x:1274,y:557,t:1526328738569};\\\", \\\"{x:1274,y:561,t:1526328738585};\\\", \\\"{x:1274,y:576,t:1526328738602};\\\", \\\"{x:1274,y:607,t:1526328738618};\\\", \\\"{x:1282,y:670,t:1526328738635};\\\", \\\"{x:1291,y:702,t:1526328738652};\\\", \\\"{x:1297,y:723,t:1526328738668};\\\", \\\"{x:1299,y:734,t:1526328738685};\\\", \\\"{x:1299,y:745,t:1526328738702};\\\", \\\"{x:1299,y:754,t:1526328738718};\\\", \\\"{x:1299,y:764,t:1526328738736};\\\", \\\"{x:1299,y:780,t:1526328738753};\\\", \\\"{x:1297,y:795,t:1526328738768};\\\", \\\"{x:1297,y:803,t:1526328738785};\\\", \\\"{x:1297,y:804,t:1526328738802};\\\", \\\"{x:1296,y:804,t:1526328738820};\\\", \\\"{x:1296,y:802,t:1526328738891};\\\", \\\"{x:1296,y:792,t:1526328738902};\\\", \\\"{x:1296,y:790,t:1526328738919};\\\", \\\"{x:1297,y:789,t:1526328738940};\\\", \\\"{x:1298,y:787,t:1526328738955};\\\", \\\"{x:1299,y:786,t:1526328738971};\\\", \\\"{x:1299,y:785,t:1526328738985};\\\", \\\"{x:1303,y:778,t:1526328739002};\\\", \\\"{x:1319,y:748,t:1526328739020};\\\", \\\"{x:1325,y:727,t:1526328739036};\\\", \\\"{x:1330,y:711,t:1526328739053};\\\", \\\"{x:1332,y:701,t:1526328739069};\\\", \\\"{x:1332,y:692,t:1526328739085};\\\", \\\"{x:1326,y:670,t:1526328739102};\\\", \\\"{x:1316,y:646,t:1526328739119};\\\", \\\"{x:1306,y:627,t:1526328739135};\\\", \\\"{x:1300,y:611,t:1526328739153};\\\", \\\"{x:1296,y:600,t:1526328739169};\\\", \\\"{x:1295,y:591,t:1526328739185};\\\", \\\"{x:1294,y:586,t:1526328739202};\\\", \\\"{x:1293,y:584,t:1526328739219};\\\", \\\"{x:1293,y:582,t:1526328739235};\\\", \\\"{x:1293,y:581,t:1526328739252};\\\", \\\"{x:1293,y:579,t:1526328739269};\\\", \\\"{x:1292,y:579,t:1526328739411};\\\", \\\"{x:1290,y:579,t:1526328739420};\\\", \\\"{x:1289,y:580,t:1526328739437};\\\", \\\"{x:1293,y:582,t:1526328740195};\\\", \\\"{x:1331,y:609,t:1526328740203};\\\", \\\"{x:1454,y:685,t:1526328740219};\\\", \\\"{x:1573,y:755,t:1526328740236};\\\", \\\"{x:1692,y:815,t:1526328740253};\\\", \\\"{x:1784,y:859,t:1526328740270};\\\", \\\"{x:1817,y:872,t:1526328740286};\\\", \\\"{x:1823,y:877,t:1526328740304};\\\", \\\"{x:1822,y:877,t:1526328740460};\\\", \\\"{x:1818,y:877,t:1526328740470};\\\", \\\"{x:1803,y:876,t:1526328740486};\\\", \\\"{x:1787,y:871,t:1526328740503};\\\", \\\"{x:1773,y:867,t:1526328740521};\\\", \\\"{x:1764,y:863,t:1526328740536};\\\", \\\"{x:1761,y:862,t:1526328740553};\\\", \\\"{x:1760,y:861,t:1526328740570};\\\", \\\"{x:1759,y:861,t:1526328740603};\\\", \\\"{x:1758,y:860,t:1526328740643};\\\", \\\"{x:1757,y:860,t:1526328740667};\\\", \\\"{x:1757,y:859,t:1526328740715};\\\", \\\"{x:1755,y:857,t:1526328740827};\\\", \\\"{x:1755,y:855,t:1526328740837};\\\", \\\"{x:1752,y:849,t:1526328740854};\\\", \\\"{x:1752,y:847,t:1526328740870};\\\", \\\"{x:1751,y:844,t:1526328740887};\\\", \\\"{x:1751,y:842,t:1526328740903};\\\", \\\"{x:1751,y:841,t:1526328740920};\\\", \\\"{x:1750,y:841,t:1526328740939};\\\", \\\"{x:1749,y:841,t:1526328740953};\\\", \\\"{x:1746,y:841,t:1526328740970};\\\", \\\"{x:1738,y:837,t:1526328740987};\\\", \\\"{x:1735,y:837,t:1526328741003};\\\", \\\"{x:1735,y:836,t:1526328741124};\\\", \\\"{x:1730,y:835,t:1526328741138};\\\", \\\"{x:1719,y:830,t:1526328741154};\\\", \\\"{x:1706,y:828,t:1526328741170};\\\", \\\"{x:1680,y:824,t:1526328741187};\\\", \\\"{x:1648,y:816,t:1526328741204};\\\", \\\"{x:1567,y:802,t:1526328741221};\\\", \\\"{x:1453,y:787,t:1526328741237};\\\", \\\"{x:1320,y:766,t:1526328741254};\\\", \\\"{x:1202,y:739,t:1526328741270};\\\", \\\"{x:1109,y:718,t:1526328741287};\\\", \\\"{x:1065,y:704,t:1526328741304};\\\", \\\"{x:1053,y:700,t:1526328741320};\\\", \\\"{x:1052,y:699,t:1526328741355};\\\", \\\"{x:1052,y:698,t:1526328741412};\\\", \\\"{x:1055,y:696,t:1526328741421};\\\", \\\"{x:1063,y:692,t:1526328741438};\\\", \\\"{x:1069,y:689,t:1526328741455};\\\", \\\"{x:1076,y:685,t:1526328741470};\\\", \\\"{x:1083,y:682,t:1526328741488};\\\", \\\"{x:1087,y:680,t:1526328741505};\\\", \\\"{x:1089,y:678,t:1526328741520};\\\", \\\"{x:1091,y:676,t:1526328741537};\\\", \\\"{x:1097,y:671,t:1526328741555};\\\", \\\"{x:1104,y:665,t:1526328741570};\\\", \\\"{x:1116,y:658,t:1526328741588};\\\", \\\"{x:1130,y:654,t:1526328741605};\\\", \\\"{x:1146,y:652,t:1526328741620};\\\", \\\"{x:1162,y:652,t:1526328741637};\\\", \\\"{x:1179,y:652,t:1526328741654};\\\", \\\"{x:1201,y:656,t:1526328741670};\\\", \\\"{x:1222,y:666,t:1526328741687};\\\", \\\"{x:1248,y:677,t:1526328741705};\\\", \\\"{x:1282,y:693,t:1526328741721};\\\", \\\"{x:1349,y:724,t:1526328741738};\\\", \\\"{x:1411,y:746,t:1526328741754};\\\", \\\"{x:1464,y:771,t:1526328741771};\\\", \\\"{x:1470,y:777,t:1526328741787};\\\", \\\"{x:1470,y:787,t:1526328741804};\\\", \\\"{x:1458,y:798,t:1526328741821};\\\", \\\"{x:1441,y:813,t:1526328741837};\\\", \\\"{x:1415,y:829,t:1526328741854};\\\", \\\"{x:1405,y:835,t:1526328741872};\\\", \\\"{x:1402,y:839,t:1526328741887};\\\", \\\"{x:1402,y:840,t:1526328741907};\\\", \\\"{x:1401,y:840,t:1526328741921};\\\", \\\"{x:1402,y:840,t:1526328741947};\\\", \\\"{x:1403,y:840,t:1526328741956};\\\", \\\"{x:1403,y:839,t:1526328742083};\\\", \\\"{x:1402,y:838,t:1526328742091};\\\", \\\"{x:1401,y:837,t:1526328742105};\\\", \\\"{x:1397,y:834,t:1526328742121};\\\", \\\"{x:1394,y:833,t:1526328742137};\\\", \\\"{x:1390,y:832,t:1526328742154};\\\", \\\"{x:1369,y:832,t:1526328742171};\\\", \\\"{x:1342,y:833,t:1526328742189};\\\", \\\"{x:1294,y:847,t:1526328742205};\\\", \\\"{x:1232,y:868,t:1526328742221};\\\", \\\"{x:1177,y:891,t:1526328742239};\\\", \\\"{x:1144,y:906,t:1526328742254};\\\", \\\"{x:1127,y:917,t:1526328742271};\\\", \\\"{x:1122,y:921,t:1526328742288};\\\", \\\"{x:1124,y:919,t:1526328742460};\\\", \\\"{x:1127,y:915,t:1526328742471};\\\", \\\"{x:1135,y:902,t:1526328742489};\\\", \\\"{x:1147,y:886,t:1526328742504};\\\", \\\"{x:1157,y:874,t:1526328742521};\\\", \\\"{x:1160,y:872,t:1526328742538};\\\", \\\"{x:1161,y:871,t:1526328742587};\\\", \\\"{x:1162,y:871,t:1526328742595};\\\", \\\"{x:1166,y:866,t:1526328742604};\\\", \\\"{x:1172,y:858,t:1526328742621};\\\", \\\"{x:1178,y:852,t:1526328742638};\\\", \\\"{x:1182,y:846,t:1526328742655};\\\", \\\"{x:1185,y:842,t:1526328742671};\\\", \\\"{x:1189,y:840,t:1526328742688};\\\", \\\"{x:1191,y:838,t:1526328742705};\\\", \\\"{x:1192,y:838,t:1526328743411};\\\", \\\"{x:1193,y:838,t:1526328743422};\\\", \\\"{x:1194,y:838,t:1526328746452};\\\", \\\"{x:1195,y:838,t:1526328747108};\\\", \\\"{x:1203,y:833,t:1526328747115};\\\", \\\"{x:1216,y:825,t:1526328747125};\\\", \\\"{x:1235,y:811,t:1526328747142};\\\", \\\"{x:1250,y:801,t:1526328747159};\\\", \\\"{x:1257,y:794,t:1526328747174};\\\", \\\"{x:1262,y:790,t:1526328747191};\\\", \\\"{x:1262,y:788,t:1526328747532};\\\", \\\"{x:1260,y:784,t:1526328747542};\\\", \\\"{x:1244,y:768,t:1526328747559};\\\", \\\"{x:1221,y:752,t:1526328747575};\\\", \\\"{x:1187,y:729,t:1526328747592};\\\", \\\"{x:1131,y:702,t:1526328747609};\\\", \\\"{x:1060,y:676,t:1526328747625};\\\", \\\"{x:977,y:656,t:1526328747641};\\\", \\\"{x:872,y:640,t:1526328747658};\\\", \\\"{x:707,y:620,t:1526328747676};\\\", \\\"{x:593,y:618,t:1526328747692};\\\", \\\"{x:490,y:614,t:1526328747709};\\\", \\\"{x:387,y:614,t:1526328747726};\\\", \\\"{x:318,y:614,t:1526328747742};\\\", \\\"{x:265,y:614,t:1526328747760};\\\", \\\"{x:243,y:614,t:1526328747777};\\\", \\\"{x:230,y:615,t:1526328747794};\\\", \\\"{x:223,y:622,t:1526328747810};\\\", \\\"{x:213,y:633,t:1526328747827};\\\", \\\"{x:209,y:659,t:1526328747844};\\\", \\\"{x:206,y:679,t:1526328747861};\\\", \\\"{x:205,y:693,t:1526328747877};\\\", \\\"{x:209,y:704,t:1526328747894};\\\", \\\"{x:221,y:719,t:1526328747910};\\\", \\\"{x:235,y:731,t:1526328747927};\\\", \\\"{x:247,y:741,t:1526328747944};\\\", \\\"{x:254,y:748,t:1526328747960};\\\", \\\"{x:259,y:752,t:1526328747977};\\\", \\\"{x:263,y:755,t:1526328747994};\\\", \\\"{x:264,y:757,t:1526328748011};\\\", \\\"{x:267,y:758,t:1526328748027};\\\", \\\"{x:271,y:759,t:1526328748043};\\\", \\\"{x:277,y:761,t:1526328748060};\\\", \\\"{x:282,y:761,t:1526328748077};\\\", \\\"{x:288,y:761,t:1526328748094};\\\", \\\"{x:290,y:761,t:1526328748111};\\\", \\\"{x:292,y:761,t:1526328748127};\\\", \\\"{x:293,y:761,t:1526328748144};\\\", \\\"{x:294,y:761,t:1526328748172};\\\", \\\"{x:295,y:761,t:1526328748204};\\\", \\\"{x:296,y:761,t:1526328748211};\\\", \\\"{x:297,y:761,t:1526328748235};\\\", \\\"{x:298,y:760,t:1526328748244};\\\", \\\"{x:299,y:760,t:1526328748260};\\\", \\\"{x:301,y:760,t:1526328748277};\\\", \\\"{x:302,y:760,t:1526328748604};\\\", \\\"{x:304,y:760,t:1526328748611};\\\", \\\"{x:305,y:760,t:1526328748627};\\\", \\\"{x:307,y:760,t:1526328748643};\\\", \\\"{x:308,y:760,t:1526328748700};\\\", \\\"{x:308,y:759,t:1526328748771};\\\", \\\"{x:309,y:759,t:1526328750268};\\\", \\\"{x:309,y:748,t:1526328757196};\\\", \\\"{x:309,y:730,t:1526328757203};\\\", \\\"{x:311,y:724,t:1526328757217};\\\", \\\"{x:311,y:722,t:1526328757233};\\\", \\\"{x:304,y:716,t:1526328757250};\\\", \\\"{x:297,y:710,t:1526328757267};\\\", \\\"{x:294,y:705,t:1526328757284};\\\", \\\"{x:294,y:704,t:1526328757300};\\\", \\\"{x:294,y:710,t:1526328757396};\\\", \\\"{x:295,y:721,t:1526328757403};\\\", \\\"{x:299,y:731,t:1526328757417};\\\", \\\"{x:304,y:747,t:1526328757434};\\\", \\\"{x:319,y:759,t:1526328757451};\\\", \\\"{x:343,y:759,t:1526328757467};\\\", \\\"{x:400,y:754,t:1526328757484};\\\", \\\"{x:497,y:728,t:1526328757501};\\\", \\\"{x:601,y:688,t:1526328757518};\\\", \\\"{x:684,y:653,t:1526328757534};\\\", \\\"{x:718,y:632,t:1526328757548};\\\", \\\"{x:728,y:623,t:1526328757564};\\\", \\\"{x:731,y:616,t:1526328757581};\\\", \\\"{x:732,y:612,t:1526328757601};\\\", \\\"{x:732,y:609,t:1526328757618};\\\", \\\"{x:732,y:605,t:1526328757635};\\\", \\\"{x:731,y:599,t:1526328757651};\\\", \\\"{x:718,y:587,t:1526328757669};\\\", \\\"{x:706,y:579,t:1526328757685};\\\", \\\"{x:692,y:569,t:1526328757701};\\\", \\\"{x:683,y:564,t:1526328757718};\\\", \\\"{x:679,y:561,t:1526328757735};\\\", \\\"{x:676,y:560,t:1526328757751};\\\", \\\"{x:673,y:555,t:1526328757768};\\\", \\\"{x:673,y:552,t:1526328757785};\\\", \\\"{x:671,y:546,t:1526328757801};\\\", \\\"{x:670,y:542,t:1526328757818};\\\", \\\"{x:665,y:530,t:1526328757835};\\\", \\\"{x:659,y:525,t:1526328757851};\\\", \\\"{x:656,y:524,t:1526328757869};\\\", \\\"{x:650,y:520,t:1526328757885};\\\", \\\"{x:636,y:510,t:1526328757901};\\\", \\\"{x:626,y:506,t:1526328757918};\\\", \\\"{x:617,y:505,t:1526328757935};\\\", \\\"{x:607,y:505,t:1526328757951};\\\", \\\"{x:601,y:505,t:1526328757968};\\\", \\\"{x:599,y:505,t:1526328757985};\\\", \\\"{x:599,y:504,t:1526328758099};\\\", \\\"{x:599,y:503,t:1526328758111};\\\", \\\"{x:599,y:502,t:1526328758121};\\\", \\\"{x:599,y:501,t:1526328758139};\\\", \\\"{x:599,y:500,t:1526328758159};\\\", \\\"{x:599,y:504,t:1526328758351};\\\", \\\"{x:597,y:524,t:1526328758359};\\\", \\\"{x:597,y:560,t:1526328758372};\\\", \\\"{x:588,y:640,t:1526328758389};\\\", \\\"{x:571,y:709,t:1526328758406};\\\", \\\"{x:549,y:754,t:1526328758422};\\\", \\\"{x:533,y:773,t:1526328758440};\\\", \\\"{x:527,y:774,t:1526328758456};\\\", \\\"{x:517,y:775,t:1526328758472};\\\", \\\"{x:502,y:775,t:1526328758489};\\\", \\\"{x:489,y:775,t:1526328758506};\\\", \\\"{x:483,y:775,t:1526328758523};\\\", \\\"{x:480,y:775,t:1526328758539};\\\", \\\"{x:478,y:775,t:1526328758556};\\\", \\\"{x:480,y:770,t:1526328758623};\\\", \\\"{x:494,y:753,t:1526328758639};\\\", \\\"{x:516,y:736,t:1526328758656};\\\", \\\"{x:549,y:711,t:1526328758674};\\\", \\\"{x:578,y:690,t:1526328758690};\\\", \\\"{x:600,y:672,t:1526328758706};\\\", \\\"{x:612,y:661,t:1526328758723};\\\", \\\"{x:618,y:648,t:1526328758738};\\\", \\\"{x:623,y:631,t:1526328758756};\\\", \\\"{x:625,y:624,t:1526328758773};\\\", \\\"{x:626,y:618,t:1526328758789};\\\", \\\"{x:626,y:616,t:1526328758806};\\\", \\\"{x:626,y:605,t:1526328758822};\\\", \\\"{x:627,y:600,t:1526328758839};\\\", \\\"{x:630,y:593,t:1526328758857};\\\", \\\"{x:631,y:588,t:1526328758873};\\\", \\\"{x:631,y:571,t:1526328758889};\\\", \\\"{x:631,y:551,t:1526328758906};\\\", \\\"{x:631,y:536,t:1526328758923};\\\", \\\"{x:629,y:531,t:1526328758939};\\\", \\\"{x:629,y:525,t:1526328758959};\\\", \\\"{x:629,y:518,t:1526328758973};\\\", \\\"{x:629,y:510,t:1526328758990};\\\", \\\"{x:629,y:506,t:1526328759006};\\\", \\\"{x:630,y:499,t:1526328759023};\\\", \\\"{x:631,y:496,t:1526328759040};\\\", \\\"{x:630,y:495,t:1526328759239};\\\", \\\"{x:628,y:495,t:1526328759247};\\\", \\\"{x:625,y:495,t:1526328759257};\\\", \\\"{x:623,y:495,t:1526328759273};\\\", \\\"{x:623,y:498,t:1526328759607};\\\", \\\"{x:621,y:504,t:1526328759623};\\\", \\\"{x:615,y:513,t:1526328759640};\\\", \\\"{x:607,y:524,t:1526328759658};\\\", \\\"{x:592,y:538,t:1526328759673};\\\", \\\"{x:562,y:569,t:1526328759690};\\\", \\\"{x:518,y:628,t:1526328759707};\\\", \\\"{x:468,y:718,t:1526328759723};\\\", \\\"{x:435,y:818,t:1526328759740};\\\", \\\"{x:417,y:901,t:1526328759757};\\\", \\\"{x:412,y:942,t:1526328759773};\\\", \\\"{x:412,y:947,t:1526328759790};\\\", \\\"{x:414,y:948,t:1526328759807};\\\", \\\"{x:415,y:948,t:1526328759847};\\\", \\\"{x:416,y:947,t:1526328759857};\\\", \\\"{x:425,y:927,t:1526328759873};\\\", \\\"{x:448,y:881,t:1526328759890};\\\", \\\"{x:486,y:825,t:1526328759907};\\\", \\\"{x:521,y:779,t:1526328759924};\\\", \\\"{x:544,y:748,t:1526328759940};\\\", \\\"{x:552,y:739,t:1526328759957};\\\", \\\"{x:553,y:738,t:1526328759974};\\\", \\\"{x:554,y:738,t:1526328760015};\\\", \\\"{x:555,y:738,t:1526328760024};\\\", \\\"{x:556,y:738,t:1526328760055};\\\", \\\"{x:557,y:738,t:1526328760327};\\\", \\\"{x:558,y:738,t:1526328760340};\\\", \\\"{x:560,y:738,t:1526328760357};\\\", \\\"{x:565,y:740,t:1526328760373};\\\", \\\"{x:572,y:743,t:1526328760391};\\\", \\\"{x:578,y:746,t:1526328760407};\\\", \\\"{x:588,y:753,t:1526328760424};\\\", \\\"{x:597,y:760,t:1526328760441};\\\", \\\"{x:608,y:771,t:1526328760457};\\\", \\\"{x:625,y:781,t:1526328760474};\\\", \\\"{x:647,y:798,t:1526328760491};\\\", \\\"{x:685,y:825,t:1526328760507};\\\", \\\"{x:752,y:870,t:1526328760524};\\\", \\\"{x:856,y:932,t:1526328760541};\\\", \\\"{x:968,y:991,t:1526328760557};\\\", \\\"{x:1070,y:1041,t:1526328760574};\\\", \\\"{x:1192,y:1084,t:1526328760591};\\\", \\\"{x:1228,y:1095,t:1526328760607};\\\", \\\"{x:1244,y:1099,t:1526328760624};\\\", \\\"{x:1247,y:1100,t:1526328760641};\\\", \\\"{x:1251,y:1101,t:1526328760695};\\\", \\\"{x:1251,y:1102,t:1526328760707};\\\", \\\"{x:1257,y:1102,t:1526328760723};\\\", \\\"{x:1262,y:1102,t:1526328760740};\\\", \\\"{x:1264,y:1102,t:1526328760757};\\\", \\\"{x:1265,y:1102,t:1526328760799};\\\" ] }, { \\\"rt\\\": 11543, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 614942, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1259,y:1094,t:1526328762335};\\\", \\\"{x:1253,y:1088,t:1526328762343};\\\", \\\"{x:1215,y:1049,t:1526328762359};\\\", \\\"{x:1143,y:969,t:1526328762375};\\\", \\\"{x:1024,y:859,t:1526328762392};\\\", \\\"{x:901,y:757,t:1526328762409};\\\", \\\"{x:784,y:680,t:1526328762425};\\\", \\\"{x:698,y:634,t:1526328762442};\\\", \\\"{x:636,y:604,t:1526328762459};\\\", \\\"{x:575,y:575,t:1526328762475};\\\", \\\"{x:513,y:554,t:1526328762492};\\\", \\\"{x:444,y:525,t:1526328762509};\\\", \\\"{x:394,y:502,t:1526328762527};\\\", \\\"{x:362,y:489,t:1526328762542};\\\", \\\"{x:344,y:476,t:1526328762559};\\\", \\\"{x:329,y:464,t:1526328762576};\\\", \\\"{x:306,y:452,t:1526328762592};\\\", \\\"{x:260,y:436,t:1526328762609};\\\", \\\"{x:194,y:418,t:1526328762625};\\\", \\\"{x:138,y:410,t:1526328762642};\\\", \\\"{x:100,y:407,t:1526328762659};\\\", \\\"{x:78,y:410,t:1526328762676};\\\", \\\"{x:65,y:413,t:1526328762692};\\\", \\\"{x:57,y:416,t:1526328762709};\\\", \\\"{x:54,y:419,t:1526328762726};\\\", \\\"{x:53,y:420,t:1526328762742};\\\", \\\"{x:53,y:422,t:1526328762759};\\\", \\\"{x:53,y:423,t:1526328762776};\\\", \\\"{x:52,y:427,t:1526328762793};\\\", \\\"{x:49,y:435,t:1526328762809};\\\", \\\"{x:45,y:449,t:1526328762826};\\\", \\\"{x:38,y:470,t:1526328762843};\\\", \\\"{x:33,y:494,t:1526328762859};\\\", \\\"{x:32,y:517,t:1526328762876};\\\", \\\"{x:33,y:540,t:1526328762893};\\\", \\\"{x:40,y:557,t:1526328762909};\\\", \\\"{x:48,y:568,t:1526328762927};\\\", \\\"{x:53,y:572,t:1526328762943};\\\", \\\"{x:54,y:573,t:1526328762967};\\\", \\\"{x:56,y:573,t:1526328763015};\\\", \\\"{x:58,y:573,t:1526328763026};\\\", \\\"{x:69,y:563,t:1526328763043};\\\", \\\"{x:84,y:546,t:1526328763060};\\\", \\\"{x:102,y:527,t:1526328763076};\\\", \\\"{x:116,y:514,t:1526328763093};\\\", \\\"{x:126,y:503,t:1526328763109};\\\", \\\"{x:131,y:497,t:1526328763126};\\\", \\\"{x:135,y:490,t:1526328763143};\\\", \\\"{x:137,y:487,t:1526328763159};\\\", \\\"{x:138,y:487,t:1526328763176};\\\", \\\"{x:140,y:487,t:1526328763199};\\\", \\\"{x:141,y:487,t:1526328763271};\\\", \\\"{x:143,y:487,t:1526328766143};\\\", \\\"{x:148,y:487,t:1526328766623};\\\", \\\"{x:171,y:487,t:1526328766631};\\\", \\\"{x:210,y:489,t:1526328766645};\\\", \\\"{x:343,y:489,t:1526328766663};\\\", \\\"{x:670,y:496,t:1526328766680};\\\", \\\"{x:938,y:501,t:1526328766696};\\\", \\\"{x:1175,y:503,t:1526328766713};\\\", \\\"{x:1344,y:503,t:1526328766729};\\\", \\\"{x:1439,y:507,t:1526328766745};\\\", \\\"{x:1468,y:511,t:1526328766762};\\\", \\\"{x:1484,y:511,t:1526328766780};\\\", \\\"{x:1509,y:511,t:1526328766795};\\\", \\\"{x:1537,y:513,t:1526328766812};\\\", \\\"{x:1565,y:513,t:1526328766829};\\\", \\\"{x:1585,y:513,t:1526328766845};\\\", \\\"{x:1592,y:515,t:1526328766862};\\\", \\\"{x:1593,y:515,t:1526328766935};\\\", \\\"{x:1594,y:520,t:1526328766947};\\\", \\\"{x:1594,y:535,t:1526328766963};\\\", \\\"{x:1594,y:553,t:1526328766979};\\\", \\\"{x:1593,y:566,t:1526328766996};\\\", \\\"{x:1592,y:578,t:1526328767012};\\\", \\\"{x:1591,y:589,t:1526328767029};\\\", \\\"{x:1587,y:604,t:1526328767046};\\\", \\\"{x:1579,y:625,t:1526328767063};\\\", \\\"{x:1551,y:664,t:1526328767079};\\\", \\\"{x:1529,y:681,t:1526328767097};\\\", \\\"{x:1505,y:693,t:1526328767113};\\\", \\\"{x:1471,y:703,t:1526328767129};\\\", \\\"{x:1438,y:706,t:1526328767146};\\\", \\\"{x:1404,y:706,t:1526328767162};\\\", \\\"{x:1381,y:706,t:1526328767179};\\\", \\\"{x:1367,y:706,t:1526328767196};\\\", \\\"{x:1365,y:706,t:1526328767212};\\\", \\\"{x:1364,y:706,t:1526328767239};\\\", \\\"{x:1363,y:706,t:1526328767255};\\\", \\\"{x:1363,y:705,t:1526328767271};\\\", \\\"{x:1363,y:703,t:1526328767279};\\\", \\\"{x:1363,y:700,t:1526328767296};\\\", \\\"{x:1363,y:696,t:1526328767312};\\\", \\\"{x:1363,y:695,t:1526328767329};\\\", \\\"{x:1363,y:692,t:1526328767346};\\\", \\\"{x:1362,y:691,t:1526328767631};\\\", \\\"{x:1360,y:692,t:1526328767646};\\\", \\\"{x:1359,y:694,t:1526328767663};\\\", \\\"{x:1359,y:695,t:1526328767687};\\\", \\\"{x:1359,y:698,t:1526328767943};\\\", \\\"{x:1361,y:703,t:1526328767951};\\\", \\\"{x:1361,y:706,t:1526328767963};\\\", \\\"{x:1363,y:708,t:1526328767980};\\\", \\\"{x:1366,y:712,t:1526328767996};\\\", \\\"{x:1367,y:714,t:1526328768014};\\\", \\\"{x:1367,y:715,t:1526328768030};\\\", \\\"{x:1368,y:715,t:1526328768367};\\\", \\\"{x:1368,y:714,t:1526328768380};\\\", \\\"{x:1368,y:712,t:1526328768399};\\\", \\\"{x:1367,y:710,t:1526328768413};\\\", \\\"{x:1366,y:710,t:1526328768430};\\\", \\\"{x:1365,y:709,t:1526328768447};\\\", \\\"{x:1364,y:710,t:1526328768544};\\\", \\\"{x:1364,y:711,t:1526328768551};\\\", \\\"{x:1362,y:712,t:1526328768563};\\\", \\\"{x:1362,y:714,t:1526328768647};\\\", \\\"{x:1363,y:716,t:1526328768664};\\\", \\\"{x:1370,y:725,t:1526328768680};\\\", \\\"{x:1378,y:733,t:1526328768697};\\\", \\\"{x:1385,y:742,t:1526328768714};\\\", \\\"{x:1392,y:753,t:1526328768730};\\\", \\\"{x:1400,y:764,t:1526328768747};\\\", \\\"{x:1410,y:778,t:1526328768763};\\\", \\\"{x:1418,y:790,t:1526328768780};\\\", \\\"{x:1429,y:805,t:1526328768797};\\\", \\\"{x:1438,y:818,t:1526328768814};\\\", \\\"{x:1448,y:830,t:1526328768831};\\\", \\\"{x:1453,y:844,t:1526328768847};\\\", \\\"{x:1457,y:851,t:1526328768865};\\\", \\\"{x:1457,y:852,t:1526328768880};\\\", \\\"{x:1458,y:853,t:1526328768911};\\\", \\\"{x:1458,y:846,t:1526328768951};\\\", \\\"{x:1458,y:838,t:1526328768964};\\\", \\\"{x:1450,y:806,t:1526328768980};\\\", \\\"{x:1415,y:736,t:1526328768997};\\\", \\\"{x:1349,y:645,t:1526328769014};\\\", \\\"{x:1277,y:564,t:1526328769031};\\\", \\\"{x:1211,y:508,t:1526328769048};\\\", \\\"{x:1197,y:503,t:1526328769065};\\\", \\\"{x:1196,y:503,t:1526328769080};\\\", \\\"{x:1196,y:502,t:1526328769098};\\\", \\\"{x:1195,y:502,t:1526328769127};\\\", \\\"{x:1192,y:503,t:1526328769134};\\\", \\\"{x:1190,y:506,t:1526328769147};\\\", \\\"{x:1183,y:514,t:1526328769164};\\\", \\\"{x:1174,y:522,t:1526328769180};\\\", \\\"{x:1169,y:524,t:1526328769197};\\\", \\\"{x:1166,y:525,t:1526328769214};\\\", \\\"{x:1164,y:527,t:1526328769231};\\\", \\\"{x:1143,y:535,t:1526328769248};\\\", \\\"{x:1110,y:545,t:1526328769264};\\\", \\\"{x:1044,y:559,t:1526328769281};\\\", \\\"{x:975,y:574,t:1526328769297};\\\", \\\"{x:902,y:579,t:1526328769315};\\\", \\\"{x:845,y:585,t:1526328769331};\\\", \\\"{x:780,y:599,t:1526328769346};\\\", \\\"{x:685,y:603,t:1526328769363};\\\", \\\"{x:679,y:602,t:1526328769381};\\\", \\\"{x:672,y:601,t:1526328769398};\\\", \\\"{x:668,y:601,t:1526328769415};\\\", \\\"{x:663,y:605,t:1526328769430};\\\", \\\"{x:662,y:606,t:1526328769448};\\\", \\\"{x:660,y:606,t:1526328769464};\\\", \\\"{x:657,y:605,t:1526328769481};\\\", \\\"{x:656,y:604,t:1526328769497};\\\", \\\"{x:656,y:605,t:1526328769543};\\\", \\\"{x:663,y:599,t:1526328769551};\\\", \\\"{x:668,y:595,t:1526328769565};\\\", \\\"{x:683,y:582,t:1526328769582};\\\", \\\"{x:689,y:578,t:1526328769599};\\\", \\\"{x:690,y:576,t:1526328769614};\\\", \\\"{x:693,y:573,t:1526328769632};\\\", \\\"{x:695,y:569,t:1526328769648};\\\", \\\"{x:696,y:562,t:1526328769665};\\\", \\\"{x:696,y:550,t:1526328769682};\\\", \\\"{x:695,y:536,t:1526328769698};\\\", \\\"{x:688,y:523,t:1526328769715};\\\", \\\"{x:679,y:516,t:1526328769732};\\\", \\\"{x:669,y:510,t:1526328769749};\\\", \\\"{x:660,y:501,t:1526328769765};\\\", \\\"{x:646,y:496,t:1526328769782};\\\", \\\"{x:637,y:494,t:1526328769799};\\\", \\\"{x:635,y:494,t:1526328769814};\\\", \\\"{x:631,y:501,t:1526328770231};\\\", \\\"{x:619,y:526,t:1526328770249};\\\", \\\"{x:601,y:552,t:1526328770265};\\\", \\\"{x:574,y:577,t:1526328770282};\\\", \\\"{x:552,y:594,t:1526328770299};\\\", \\\"{x:533,y:602,t:1526328770316};\\\", \\\"{x:514,y:608,t:1526328770332};\\\", \\\"{x:493,y:611,t:1526328770349};\\\", \\\"{x:473,y:615,t:1526328770366};\\\", \\\"{x:456,y:625,t:1526328770381};\\\", \\\"{x:446,y:638,t:1526328770399};\\\", \\\"{x:438,y:674,t:1526328770415};\\\", \\\"{x:438,y:703,t:1526328770432};\\\", \\\"{x:438,y:726,t:1526328770449};\\\", \\\"{x:438,y:739,t:1526328770465};\\\", \\\"{x:439,y:743,t:1526328770481};\\\", \\\"{x:440,y:743,t:1526328770535};\\\", \\\"{x:441,y:743,t:1526328770559};\\\", \\\"{x:445,y:743,t:1526328770567};\\\", \\\"{x:446,y:743,t:1526328770582};\\\", \\\"{x:450,y:743,t:1526328770598};\\\", \\\"{x:459,y:743,t:1526328770615};\\\", \\\"{x:464,y:743,t:1526328770633};\\\", \\\"{x:466,y:743,t:1526328770649};\\\", \\\"{x:467,y:743,t:1526328770665};\\\", \\\"{x:468,y:743,t:1526328770711};\\\", \\\"{x:470,y:743,t:1526328770718};\\\", \\\"{x:474,y:742,t:1526328770733};\\\", \\\"{x:479,y:742,t:1526328770748};\\\", \\\"{x:482,y:740,t:1526328770766};\\\", \\\"{x:485,y:740,t:1526328770783};\\\", \\\"{x:486,y:740,t:1526328770799};\\\", \\\"{x:488,y:740,t:1526328772415};\\\", \\\"{x:488,y:739,t:1526328772422};\\\", \\\"{x:489,y:739,t:1526328772433};\\\", \\\"{x:490,y:739,t:1526328772451};\\\", \\\"{x:491,y:738,t:1526328772503};\\\", \\\"{x:490,y:740,t:1526328772759};\\\", \\\"{x:490,y:741,t:1526328772767};\\\", \\\"{x:486,y:747,t:1526328772784};\\\", \\\"{x:485,y:749,t:1526328772800};\\\", \\\"{x:487,y:749,t:1526328773663};\\\", \\\"{x:488,y:749,t:1526328773671};\\\", \\\"{x:489,y:749,t:1526328773684};\\\", \\\"{x:492,y:748,t:1526328773702};\\\", \\\"{x:494,y:747,t:1526328773718};\\\", \\\"{x:495,y:747,t:1526328774399};\\\", \\\"{x:496,y:746,t:1526328774455};\\\", \\\"{x:498,y:745,t:1526328774470};\\\", \\\"{x:500,y:745,t:1526328774494};\\\", \\\"{x:500,y:744,t:1526328774503};\\\" ] }, { \\\"rt\\\": 9947, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 626089, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:744,t:1526328774621};\\\", \\\"{x:503,y:744,t:1526328774927};\\\", \\\"{x:504,y:744,t:1526328774991};\\\", \\\"{x:504,y:745,t:1526328775311};\\\", \\\"{x:505,y:745,t:1526328776231};\\\", \\\"{x:506,y:745,t:1526328776246};\\\", \\\"{x:507,y:745,t:1526328777432};\\\", \\\"{x:507,y:743,t:1526328777471};\\\", \\\"{x:508,y:743,t:1526328777488};\\\", \\\"{x:509,y:742,t:1526328777510};\\\", \\\"{x:510,y:742,t:1526328777521};\\\", \\\"{x:512,y:740,t:1526328779823};\\\", \\\"{x:516,y:740,t:1526328779840};\\\", \\\"{x:516,y:739,t:1526328779935};\\\", \\\"{x:518,y:735,t:1526328779967};\\\", \\\"{x:521,y:730,t:1526328779975};\\\", \\\"{x:525,y:726,t:1526328779990};\\\", \\\"{x:537,y:714,t:1526328780006};\\\", \\\"{x:582,y:694,t:1526328780023};\\\", \\\"{x:613,y:686,t:1526328780040};\\\", \\\"{x:630,y:686,t:1526328780055};\\\", \\\"{x:639,y:690,t:1526328780073};\\\", \\\"{x:642,y:695,t:1526328780089};\\\", \\\"{x:646,y:698,t:1526328780106};\\\", \\\"{x:653,y:701,t:1526328780123};\\\", \\\"{x:663,y:703,t:1526328780139};\\\", \\\"{x:671,y:701,t:1526328780156};\\\", \\\"{x:673,y:691,t:1526328780173};\\\", \\\"{x:670,y:661,t:1526328780189};\\\", \\\"{x:648,y:622,t:1526328780206};\\\", \\\"{x:556,y:544,t:1526328780223};\\\", \\\"{x:503,y:519,t:1526328780240};\\\", \\\"{x:462,y:503,t:1526328780257};\\\", \\\"{x:444,y:494,t:1526328780273};\\\", \\\"{x:437,y:493,t:1526328780289};\\\", \\\"{x:431,y:493,t:1526328780307};\\\", \\\"{x:418,y:493,t:1526328780322};\\\", \\\"{x:397,y:493,t:1526328780340};\\\", \\\"{x:357,y:499,t:1526328780357};\\\", \\\"{x:322,y:510,t:1526328780373};\\\", \\\"{x:310,y:513,t:1526328780390};\\\", \\\"{x:309,y:513,t:1526328780406};\\\", \\\"{x:308,y:514,t:1526328780463};\\\", \\\"{x:309,y:515,t:1526328780472};\\\", \\\"{x:318,y:518,t:1526328780490};\\\", \\\"{x:333,y:525,t:1526328780507};\\\", \\\"{x:347,y:530,t:1526328780523};\\\", \\\"{x:353,y:533,t:1526328780540};\\\", \\\"{x:354,y:534,t:1526328780557};\\\", \\\"{x:355,y:534,t:1526328780711};\\\", \\\"{x:356,y:534,t:1526328780726};\\\", \\\"{x:358,y:534,t:1526328780740};\\\", \\\"{x:362,y:534,t:1526328780757};\\\", \\\"{x:372,y:534,t:1526328780773};\\\", \\\"{x:380,y:534,t:1526328780790};\\\", \\\"{x:386,y:534,t:1526328780807};\\\", \\\"{x:387,y:535,t:1526328781103};\\\", \\\"{x:387,y:537,t:1526328781110};\\\", \\\"{x:387,y:544,t:1526328781124};\\\", \\\"{x:389,y:559,t:1526328781141};\\\", \\\"{x:389,y:563,t:1526328781158};\\\", \\\"{x:389,y:567,t:1526328781174};\\\", \\\"{x:386,y:570,t:1526328781191};\\\", \\\"{x:384,y:573,t:1526328781207};\\\", \\\"{x:382,y:583,t:1526328781224};\\\", \\\"{x:379,y:589,t:1526328781241};\\\", \\\"{x:379,y:594,t:1526328781257};\\\", \\\"{x:379,y:595,t:1526328781274};\\\", \\\"{x:379,y:596,t:1526328781334};\\\", \\\"{x:379,y:597,t:1526328781351};\\\", \\\"{x:379,y:598,t:1526328781407};\\\", \\\"{x:379,y:601,t:1526328781424};\\\", \\\"{x:381,y:618,t:1526328781442};\\\", \\\"{x:384,y:627,t:1526328781457};\\\", \\\"{x:385,y:634,t:1526328781474};\\\", \\\"{x:386,y:639,t:1526328781492};\\\", \\\"{x:387,y:640,t:1526328781508};\\\", \\\"{x:387,y:639,t:1526328781567};\\\", \\\"{x:387,y:637,t:1526328781575};\\\", \\\"{x:387,y:636,t:1526328781591};\\\", \\\"{x:387,y:634,t:1526328781608};\\\", \\\"{x:387,y:633,t:1526328781624};\\\", \\\"{x:387,y:631,t:1526328781642};\\\", \\\"{x:388,y:631,t:1526328781658};\\\", \\\"{x:388,y:630,t:1526328781743};\\\", \\\"{x:388,y:628,t:1526328781759};\\\", \\\"{x:388,y:627,t:1526328781775};\\\", \\\"{x:389,y:626,t:1526328781791};\\\", \\\"{x:391,y:626,t:1526328783903};\\\", \\\"{x:397,y:628,t:1526328783919};\\\", \\\"{x:409,y:634,t:1526328783927};\\\", \\\"{x:423,y:639,t:1526328783942};\\\", \\\"{x:457,y:652,t:1526328783959};\\\", \\\"{x:474,y:657,t:1526328783976};\\\", \\\"{x:478,y:659,t:1526328783993};\\\", \\\"{x:479,y:659,t:1526328784022};\\\", \\\"{x:480,y:659,t:1526328784038};\\\", \\\"{x:480,y:660,t:1526328784087};\\\", \\\"{x:480,y:661,t:1526328784103};\\\", \\\"{x:480,y:663,t:1526328784110};\\\", \\\"{x:482,y:667,t:1526328784126};\\\", \\\"{x:489,y:691,t:1526328784144};\\\", \\\"{x:495,y:705,t:1526328784159};\\\", \\\"{x:499,y:712,t:1526328784176};\\\", \\\"{x:502,y:716,t:1526328784193};\\\", \\\"{x:502,y:717,t:1526328784210};\\\", \\\"{x:502,y:718,t:1526328784239};\\\", \\\"{x:502,y:719,t:1526328784247};\\\", \\\"{x:502,y:720,t:1526328784261};\\\", \\\"{x:502,y:727,t:1526328784277};\\\", \\\"{x:502,y:742,t:1526328784293};\\\", \\\"{x:502,y:743,t:1526328784311};\\\", \\\"{x:503,y:743,t:1526328784326};\\\", \\\"{x:503,y:744,t:1526328784358};\\\", \\\"{x:504,y:744,t:1526328784415};\\\", \\\"{x:504,y:745,t:1526328784431};\\\", \\\"{x:505,y:745,t:1526328784455};\\\", \\\"{x:506,y:745,t:1526328784703};\\\", \\\"{x:508,y:745,t:1526328784710};\\\", \\\"{x:513,y:744,t:1526328784727};\\\", \\\"{x:529,y:742,t:1526328784743};\\\", \\\"{x:548,y:741,t:1526328784760};\\\", \\\"{x:571,y:740,t:1526328784776};\\\", \\\"{x:598,y:739,t:1526328784793};\\\", \\\"{x:628,y:739,t:1526328784810};\\\", \\\"{x:659,y:739,t:1526328784827};\\\", \\\"{x:697,y:739,t:1526328784843};\\\", \\\"{x:750,y:739,t:1526328784860};\\\", \\\"{x:818,y:725,t:1526328784877};\\\", \\\"{x:874,y:717,t:1526328784893};\\\", \\\"{x:933,y:709,t:1526328784911};\\\", \\\"{x:986,y:698,t:1526328784927};\\\", \\\"{x:1014,y:691,t:1526328784943};\\\", \\\"{x:1028,y:689,t:1526328784961};\\\", \\\"{x:1029,y:689,t:1526328784977};\\\", \\\"{x:1030,y:689,t:1526328784993};\\\", \\\"{x:1030,y:687,t:1526328785054};\\\", \\\"{x:1031,y:687,t:1526328785118};\\\", \\\"{x:1032,y:686,t:1526328785167};\\\", \\\"{x:1033,y:684,t:1526328785343};\\\", \\\"{x:1034,y:683,t:1526328785415};\\\" ] }, { \\\"rt\\\": 23204, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 650524, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1034,y:682,t:1526328789607};\\\", \\\"{x:1032,y:674,t:1526328790734};\\\", \\\"{x:1024,y:664,t:1526328790748};\\\", \\\"{x:1003,y:637,t:1526328790765};\\\", \\\"{x:947,y:575,t:1526328790782};\\\", \\\"{x:809,y:484,t:1526328790799};\\\", \\\"{x:719,y:432,t:1526328790815};\\\", \\\"{x:651,y:397,t:1526328790832};\\\", \\\"{x:613,y:382,t:1526328790848};\\\", \\\"{x:600,y:375,t:1526328790866};\\\", \\\"{x:598,y:375,t:1526328790882};\\\", \\\"{x:594,y:373,t:1526328790926};\\\", \\\"{x:587,y:372,t:1526328790935};\\\", \\\"{x:573,y:369,t:1526328790948};\\\", \\\"{x:543,y:366,t:1526328790965};\\\", \\\"{x:513,y:365,t:1526328790981};\\\", \\\"{x:497,y:365,t:1526328790999};\\\", \\\"{x:479,y:365,t:1526328791015};\\\", \\\"{x:470,y:365,t:1526328791032};\\\", \\\"{x:452,y:375,t:1526328791048};\\\", \\\"{x:436,y:385,t:1526328791066};\\\", \\\"{x:423,y:390,t:1526328791081};\\\", \\\"{x:411,y:395,t:1526328791099};\\\", \\\"{x:403,y:400,t:1526328791115};\\\", \\\"{x:394,y:405,t:1526328791133};\\\", \\\"{x:386,y:409,t:1526328791149};\\\", \\\"{x:376,y:415,t:1526328791166};\\\", \\\"{x:364,y:422,t:1526328791183};\\\", \\\"{x:346,y:429,t:1526328791199};\\\", \\\"{x:340,y:432,t:1526328791215};\\\", \\\"{x:339,y:433,t:1526328791232};\\\", \\\"{x:338,y:434,t:1526328791249};\\\", \\\"{x:338,y:435,t:1526328791304};\\\", \\\"{x:338,y:439,t:1526328791316};\\\", \\\"{x:340,y:443,t:1526328791333};\\\", \\\"{x:342,y:444,t:1526328791349};\\\", \\\"{x:344,y:447,t:1526328791366};\\\", \\\"{x:345,y:448,t:1526328791383};\\\", \\\"{x:346,y:448,t:1526328791407};\\\", \\\"{x:347,y:449,t:1526328791415};\\\", \\\"{x:348,y:449,t:1526328791463};\\\", \\\"{x:350,y:449,t:1526328791527};\\\", \\\"{x:351,y:449,t:1526328791551};\\\", \\\"{x:353,y:449,t:1526328791566};\\\", \\\"{x:358,y:449,t:1526328791583};\\\", \\\"{x:361,y:449,t:1526328791599};\\\", \\\"{x:362,y:449,t:1526328791616};\\\", \\\"{x:363,y:449,t:1526328791647};\\\", \\\"{x:364,y:449,t:1526328791662};\\\", \\\"{x:365,y:449,t:1526328791671};\\\", \\\"{x:367,y:449,t:1526328791683};\\\", \\\"{x:371,y:449,t:1526328791700};\\\", \\\"{x:373,y:449,t:1526328791716};\\\", \\\"{x:375,y:449,t:1526328791733};\\\", \\\"{x:378,y:449,t:1526328791750};\\\", \\\"{x:380,y:449,t:1526328791766};\\\", \\\"{x:383,y:449,t:1526328791783};\\\", \\\"{x:385,y:449,t:1526328791799};\\\", \\\"{x:386,y:449,t:1526328791815};\\\", \\\"{x:387,y:449,t:1526328791847};\\\", \\\"{x:388,y:449,t:1526328791855};\\\", \\\"{x:389,y:449,t:1526328791866};\\\", \\\"{x:391,y:449,t:1526328791882};\\\", \\\"{x:393,y:449,t:1526328791900};\\\", \\\"{x:397,y:449,t:1526328791916};\\\", \\\"{x:400,y:449,t:1526328791933};\\\", \\\"{x:404,y:449,t:1526328791949};\\\", \\\"{x:407,y:448,t:1526328791967};\\\", \\\"{x:408,y:448,t:1526328791983};\\\", \\\"{x:411,y:448,t:1526328792000};\\\", \\\"{x:414,y:448,t:1526328792016};\\\", \\\"{x:416,y:448,t:1526328792032};\\\", \\\"{x:420,y:448,t:1526328792050};\\\", \\\"{x:423,y:448,t:1526328792067};\\\", \\\"{x:426,y:448,t:1526328792082};\\\", \\\"{x:429,y:448,t:1526328792099};\\\", \\\"{x:433,y:448,t:1526328792116};\\\", \\\"{x:434,y:448,t:1526328792132};\\\", \\\"{x:437,y:448,t:1526328792150};\\\", \\\"{x:438,y:448,t:1526328792166};\\\", \\\"{x:440,y:448,t:1526328792183};\\\", \\\"{x:441,y:448,t:1526328792206};\\\", \\\"{x:443,y:448,t:1526328792263};\\\", \\\"{x:444,y:448,t:1526328792311};\\\", \\\"{x:446,y:448,t:1526328792711};\\\", \\\"{x:453,y:448,t:1526328792719};\\\", \\\"{x:462,y:448,t:1526328792733};\\\", \\\"{x:486,y:450,t:1526328792751};\\\", \\\"{x:493,y:451,t:1526328792766};\\\", \\\"{x:494,y:451,t:1526328792784};\\\", \\\"{x:495,y:451,t:1526328792831};\\\", \\\"{x:497,y:451,t:1526328792846};\\\", \\\"{x:499,y:451,t:1526328792854};\\\", \\\"{x:502,y:451,t:1526328792866};\\\", \\\"{x:508,y:451,t:1526328792884};\\\", \\\"{x:519,y:451,t:1526328792901};\\\", \\\"{x:526,y:451,t:1526328792917};\\\", \\\"{x:532,y:451,t:1526328792933};\\\", \\\"{x:539,y:451,t:1526328792951};\\\", \\\"{x:545,y:451,t:1526328792966};\\\", \\\"{x:551,y:451,t:1526328792983};\\\", \\\"{x:557,y:451,t:1526328793001};\\\", \\\"{x:562,y:451,t:1526328793018};\\\", \\\"{x:565,y:451,t:1526328793033};\\\", \\\"{x:567,y:451,t:1526328793055};\\\", \\\"{x:568,y:451,t:1526328793087};\\\", \\\"{x:570,y:451,t:1526328793103};\\\", \\\"{x:571,y:451,t:1526328793118};\\\", \\\"{x:574,y:451,t:1526328793133};\\\", \\\"{x:580,y:451,t:1526328793151};\\\", \\\"{x:583,y:451,t:1526328793167};\\\", \\\"{x:587,y:451,t:1526328793183};\\\", \\\"{x:591,y:451,t:1526328793201};\\\", \\\"{x:594,y:452,t:1526328793218};\\\", \\\"{x:596,y:452,t:1526328793234};\\\", \\\"{x:599,y:452,t:1526328793250};\\\", \\\"{x:602,y:452,t:1526328793267};\\\", \\\"{x:605,y:452,t:1526328793283};\\\", \\\"{x:608,y:452,t:1526328793300};\\\", \\\"{x:610,y:452,t:1526328793319};\\\", \\\"{x:611,y:452,t:1526328793335};\\\", \\\"{x:614,y:452,t:1526328793351};\\\", \\\"{x:618,y:452,t:1526328793367};\\\", \\\"{x:621,y:452,t:1526328793384};\\\", \\\"{x:622,y:452,t:1526328793400};\\\", \\\"{x:624,y:452,t:1526328793418};\\\", \\\"{x:625,y:452,t:1526328794879};\\\", \\\"{x:625,y:454,t:1526328804695};\\\", \\\"{x:619,y:468,t:1526328804712};\\\", \\\"{x:618,y:478,t:1526328804729};\\\", \\\"{x:618,y:486,t:1526328804745};\\\", \\\"{x:618,y:490,t:1526328804763};\\\", \\\"{x:618,y:493,t:1526328804779};\\\", \\\"{x:618,y:498,t:1526328804795};\\\", \\\"{x:618,y:501,t:1526328804804};\\\", \\\"{x:615,y:507,t:1526328804820};\\\", \\\"{x:610,y:521,t:1526328804837};\\\", \\\"{x:605,y:541,t:1526328804855};\\\", \\\"{x:593,y:561,t:1526328804877};\\\", \\\"{x:585,y:573,t:1526328804894};\\\", \\\"{x:576,y:584,t:1526328804910};\\\", \\\"{x:569,y:591,t:1526328804926};\\\", \\\"{x:558,y:600,t:1526328804943};\\\", \\\"{x:551,y:604,t:1526328804960};\\\", \\\"{x:539,y:609,t:1526328804975};\\\", \\\"{x:526,y:612,t:1526328804993};\\\", \\\"{x:512,y:616,t:1526328805009};\\\", \\\"{x:505,y:619,t:1526328805026};\\\", \\\"{x:502,y:619,t:1526328805043};\\\", \\\"{x:501,y:619,t:1526328805111};\\\", \\\"{x:500,y:619,t:1526328805126};\\\", \\\"{x:500,y:616,t:1526328805142};\\\", \\\"{x:500,y:609,t:1526328805160};\\\", \\\"{x:500,y:600,t:1526328805177};\\\", \\\"{x:500,y:595,t:1526328805193};\\\", \\\"{x:503,y:585,t:1526328805210};\\\", \\\"{x:508,y:573,t:1526328805227};\\\", \\\"{x:519,y:560,t:1526328805244};\\\", \\\"{x:536,y:551,t:1526328805260};\\\", \\\"{x:549,y:545,t:1526328805276};\\\", \\\"{x:564,y:540,t:1526328805293};\\\", \\\"{x:574,y:536,t:1526328805310};\\\", \\\"{x:581,y:535,t:1526328805326};\\\", \\\"{x:589,y:532,t:1526328805343};\\\", \\\"{x:597,y:531,t:1526328805360};\\\", \\\"{x:608,y:531,t:1526328805376};\\\", \\\"{x:622,y:531,t:1526328805393};\\\", \\\"{x:637,y:531,t:1526328805410};\\\", \\\"{x:652,y:531,t:1526328805428};\\\", \\\"{x:666,y:531,t:1526328805443};\\\", \\\"{x:681,y:531,t:1526328805460};\\\", \\\"{x:697,y:531,t:1526328805476};\\\", \\\"{x:726,y:531,t:1526328805493};\\\", \\\"{x:763,y:531,t:1526328805510};\\\", \\\"{x:798,y:531,t:1526328805526};\\\", \\\"{x:809,y:531,t:1526328805542};\\\", \\\"{x:812,y:531,t:1526328805560};\\\", \\\"{x:816,y:531,t:1526328805577};\\\", \\\"{x:820,y:531,t:1526328805593};\\\", \\\"{x:825,y:531,t:1526328805610};\\\", \\\"{x:827,y:531,t:1526328805627};\\\", \\\"{x:831,y:531,t:1526328805643};\\\", \\\"{x:832,y:531,t:1526328805663};\\\", \\\"{x:833,y:531,t:1526328805677};\\\", \\\"{x:834,y:531,t:1526328805693};\\\", \\\"{x:836,y:531,t:1526328805710};\\\", \\\"{x:837,y:531,t:1526328805726};\\\", \\\"{x:838,y:531,t:1526328805743};\\\", \\\"{x:840,y:531,t:1526328805760};\\\", \\\"{x:841,y:532,t:1526328805854};\\\", \\\"{x:842,y:533,t:1526328806206};\\\", \\\"{x:842,y:533,t:1526328806260};\\\", \\\"{x:842,y:535,t:1526328806815};\\\", \\\"{x:839,y:538,t:1526328806827};\\\", \\\"{x:822,y:549,t:1526328806844};\\\", \\\"{x:802,y:563,t:1526328806861};\\\", \\\"{x:760,y:587,t:1526328806877};\\\", \\\"{x:715,y:609,t:1526328806895};\\\", \\\"{x:677,y:625,t:1526328806911};\\\", \\\"{x:651,y:639,t:1526328806929};\\\", \\\"{x:634,y:649,t:1526328806945};\\\", \\\"{x:622,y:659,t:1526328806962};\\\", \\\"{x:613,y:667,t:1526328806978};\\\", \\\"{x:610,y:669,t:1526328806994};\\\", \\\"{x:607,y:674,t:1526328807011};\\\", \\\"{x:607,y:682,t:1526328807028};\\\", \\\"{x:606,y:687,t:1526328807044};\\\", \\\"{x:601,y:694,t:1526328807062};\\\", \\\"{x:599,y:699,t:1526328807078};\\\", \\\"{x:598,y:700,t:1526328807094};\\\", \\\"{x:596,y:703,t:1526328807183};\\\", \\\"{x:593,y:706,t:1526328807195};\\\", \\\"{x:583,y:719,t:1526328807211};\\\", \\\"{x:568,y:732,t:1526328807229};\\\", \\\"{x:549,y:744,t:1526328807245};\\\", \\\"{x:537,y:751,t:1526328807261};\\\", \\\"{x:529,y:757,t:1526328807279};\\\", \\\"{x:528,y:758,t:1526328807295};\\\", \\\"{x:527,y:759,t:1526328807391};\\\", \\\"{x:526,y:759,t:1526328807415};\\\", \\\"{x:525,y:759,t:1526328807447};\\\", \\\"{x:524,y:758,t:1526328807461};\\\", \\\"{x:523,y:758,t:1526328807502};\\\", \\\"{x:522,y:758,t:1526328807535};\\\", \\\"{x:521,y:757,t:1526328807545};\\\", \\\"{x:521,y:756,t:1526328807567};\\\", \\\"{x:521,y:755,t:1526328807578};\\\", \\\"{x:520,y:754,t:1526328807596};\\\", \\\"{x:520,y:753,t:1526328807611};\\\", \\\"{x:520,y:751,t:1526328807628};\\\", \\\"{x:520,y:750,t:1526328807645};\\\", \\\"{x:519,y:749,t:1526328807661};\\\", \\\"{x:519,y:748,t:1526328807678};\\\", \\\"{x:519,y:747,t:1526328807694};\\\", \\\"{x:519,y:746,t:1526328807711};\\\", \\\"{x:519,y:744,t:1526328807728};\\\", \\\"{x:519,y:737,t:1526328807745};\\\", \\\"{x:518,y:733,t:1526328807761};\\\", \\\"{x:518,y:732,t:1526328807778};\\\", \\\"{x:518,y:729,t:1526328807795};\\\", \\\"{x:518,y:723,t:1526328807812};\\\", \\\"{x:519,y:718,t:1526328807829};\\\", \\\"{x:520,y:718,t:1526328808615};\\\", \\\"{x:520,y:721,t:1526328808631};\\\", \\\"{x:521,y:725,t:1526328808645};\\\", \\\"{x:521,y:728,t:1526328808663};\\\", \\\"{x:521,y:731,t:1526328808679};\\\", \\\"{x:521,y:732,t:1526328808696};\\\", \\\"{x:523,y:733,t:1526328809182};\\\", \\\"{x:527,y:733,t:1526328809196};\\\", \\\"{x:543,y:730,t:1526328809213};\\\", \\\"{x:568,y:730,t:1526328809229};\\\", \\\"{x:600,y:730,t:1526328809246};\\\", \\\"{x:657,y:729,t:1526328809263};\\\", \\\"{x:701,y:725,t:1526328809279};\\\", \\\"{x:757,y:717,t:1526328809296};\\\", \\\"{x:842,y:694,t:1526328809314};\\\", \\\"{x:914,y:674,t:1526328809329};\\\", \\\"{x:986,y:643,t:1526328809346};\\\", \\\"{x:1044,y:617,t:1526328809363};\\\", \\\"{x:1095,y:591,t:1526328809379};\\\", \\\"{x:1139,y:566,t:1526328809396};\\\", \\\"{x:1186,y:544,t:1526328809413};\\\", \\\"{x:1226,y:523,t:1526328809429};\\\", \\\"{x:1257,y:511,t:1526328809446};\\\", \\\"{x:1280,y:501,t:1526328809463};\\\", \\\"{x:1290,y:499,t:1526328809480};\\\", \\\"{x:1298,y:494,t:1526328809496};\\\", \\\"{x:1305,y:490,t:1526328809513};\\\", \\\"{x:1311,y:486,t:1526328809530};\\\", \\\"{x:1313,y:484,t:1526328809547};\\\", \\\"{x:1314,y:483,t:1526328809564};\\\" ] }, { \\\"rt\\\": 15134, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 666897, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -04 PM-01 PM-F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1314,y:482,t:1526328810766};\\\", \\\"{x:1310,y:482,t:1526328810780};\\\", \\\"{x:1305,y:480,t:1526328810798};\\\", \\\"{x:1303,y:479,t:1526328810814};\\\", \\\"{x:1308,y:480,t:1526328814030};\\\", \\\"{x:1324,y:493,t:1526328814038};\\\", \\\"{x:1346,y:515,t:1526328814050};\\\", \\\"{x:1389,y:567,t:1526328814066};\\\", \\\"{x:1445,y:630,t:1526328814084};\\\", \\\"{x:1492,y:679,t:1526328814101};\\\", \\\"{x:1525,y:708,t:1526328814116};\\\", \\\"{x:1539,y:722,t:1526328814133};\\\", \\\"{x:1551,y:737,t:1526328814150};\\\", \\\"{x:1561,y:747,t:1526328814166};\\\", \\\"{x:1573,y:762,t:1526328814183};\\\", \\\"{x:1585,y:777,t:1526328814201};\\\", \\\"{x:1601,y:796,t:1526328814216};\\\", \\\"{x:1611,y:814,t:1526328814233};\\\", \\\"{x:1617,y:831,t:1526328814250};\\\", \\\"{x:1622,y:852,t:1526328814268};\\\", \\\"{x:1626,y:871,t:1526328814283};\\\", \\\"{x:1629,y:895,t:1526328814300};\\\", \\\"{x:1631,y:921,t:1526328814317};\\\", \\\"{x:1636,y:943,t:1526328814333};\\\", \\\"{x:1638,y:968,t:1526328814350};\\\", \\\"{x:1641,y:978,t:1526328814367};\\\", \\\"{x:1641,y:984,t:1526328814384};\\\", \\\"{x:1641,y:987,t:1526328814400};\\\", \\\"{x:1638,y:988,t:1526328814417};\\\", \\\"{x:1632,y:988,t:1526328814433};\\\", \\\"{x:1625,y:990,t:1526328814450};\\\", \\\"{x:1612,y:993,t:1526328814467};\\\", \\\"{x:1597,y:998,t:1526328814483};\\\", \\\"{x:1582,y:1006,t:1526328814500};\\\", \\\"{x:1567,y:1011,t:1526328814517};\\\", \\\"{x:1549,y:1016,t:1526328814533};\\\", \\\"{x:1515,y:1018,t:1526328814551};\\\", \\\"{x:1490,y:1018,t:1526328814567};\\\", \\\"{x:1461,y:1011,t:1526328814583};\\\", \\\"{x:1425,y:999,t:1526328814600};\\\", \\\"{x:1397,y:995,t:1526328814617};\\\", \\\"{x:1385,y:995,t:1526328814633};\\\", \\\"{x:1382,y:995,t:1526328814650};\\\", \\\"{x:1381,y:995,t:1526328814668};\\\", \\\"{x:1380,y:995,t:1526328814687};\\\", \\\"{x:1379,y:995,t:1526328814700};\\\", \\\"{x:1376,y:997,t:1526328814717};\\\", \\\"{x:1374,y:997,t:1526328814734};\\\", \\\"{x:1372,y:998,t:1526328814750};\\\", \\\"{x:1371,y:998,t:1526328814768};\\\", \\\"{x:1370,y:998,t:1526328814783};\\\", \\\"{x:1369,y:998,t:1526328814831};\\\", \\\"{x:1375,y:989,t:1526328814942};\\\", \\\"{x:1384,y:975,t:1526328814951};\\\", \\\"{x:1402,y:946,t:1526328814968};\\\", \\\"{x:1428,y:914,t:1526328814985};\\\", \\\"{x:1459,y:878,t:1526328815001};\\\", \\\"{x:1486,y:841,t:1526328815017};\\\", \\\"{x:1505,y:802,t:1526328815035};\\\", \\\"{x:1516,y:774,t:1526328815050};\\\", \\\"{x:1528,y:747,t:1526328815068};\\\", \\\"{x:1538,y:722,t:1526328815084};\\\", \\\"{x:1544,y:698,t:1526328815101};\\\", \\\"{x:1547,y:683,t:1526328815117};\\\", \\\"{x:1552,y:668,t:1526328815135};\\\", \\\"{x:1554,y:662,t:1526328815150};\\\", \\\"{x:1555,y:658,t:1526328815167};\\\", \\\"{x:1555,y:656,t:1526328815185};\\\", \\\"{x:1557,y:654,t:1526328815200};\\\", \\\"{x:1557,y:651,t:1526328815217};\\\", \\\"{x:1559,y:645,t:1526328815234};\\\", \\\"{x:1562,y:639,t:1526328815250};\\\", \\\"{x:1564,y:637,t:1526328815267};\\\", \\\"{x:1565,y:636,t:1526328815287};\\\", \\\"{x:1566,y:636,t:1526328815301};\\\", \\\"{x:1567,y:636,t:1526328815334};\\\", \\\"{x:1573,y:636,t:1526328815352};\\\", \\\"{x:1586,y:640,t:1526328815368};\\\", \\\"{x:1606,y:653,t:1526328815385};\\\", \\\"{x:1633,y:676,t:1526328815401};\\\", \\\"{x:1663,y:699,t:1526328815417};\\\", \\\"{x:1684,y:713,t:1526328815435};\\\", \\\"{x:1698,y:722,t:1526328815452};\\\", \\\"{x:1702,y:725,t:1526328815467};\\\", \\\"{x:1703,y:725,t:1526328815484};\\\", \\\"{x:1704,y:726,t:1526328815543};\\\", \\\"{x:1704,y:728,t:1526328815552};\\\", \\\"{x:1703,y:735,t:1526328815567};\\\", \\\"{x:1700,y:740,t:1526328815585};\\\", \\\"{x:1699,y:742,t:1526328815601};\\\", \\\"{x:1698,y:744,t:1526328815618};\\\", \\\"{x:1697,y:744,t:1526328815634};\\\", \\\"{x:1696,y:746,t:1526328815654};\\\", \\\"{x:1695,y:746,t:1526328815671};\\\", \\\"{x:1693,y:747,t:1526328815685};\\\", \\\"{x:1689,y:749,t:1526328815701};\\\", \\\"{x:1684,y:751,t:1526328815719};\\\", \\\"{x:1683,y:751,t:1526328815734};\\\", \\\"{x:1681,y:750,t:1526328815807};\\\", \\\"{x:1679,y:749,t:1526328815819};\\\", \\\"{x:1672,y:741,t:1526328815835};\\\", \\\"{x:1665,y:732,t:1526328815852};\\\", \\\"{x:1657,y:724,t:1526328815869};\\\", \\\"{x:1649,y:716,t:1526328815885};\\\", \\\"{x:1647,y:712,t:1526328815902};\\\", \\\"{x:1643,y:706,t:1526328815920};\\\", \\\"{x:1640,y:702,t:1526328815935};\\\", \\\"{x:1638,y:697,t:1526328815952};\\\", \\\"{x:1635,y:693,t:1526328815970};\\\", \\\"{x:1634,y:690,t:1526328815985};\\\", \\\"{x:1633,y:690,t:1526328816002};\\\", \\\"{x:1633,y:689,t:1526328816019};\\\", \\\"{x:1632,y:689,t:1526328816400};\\\", \\\"{x:1630,y:690,t:1526328816504};\\\", \\\"{x:1630,y:693,t:1526328816520};\\\", \\\"{x:1629,y:697,t:1526328816536};\\\", \\\"{x:1629,y:699,t:1526328816553};\\\", \\\"{x:1629,y:701,t:1526328816569};\\\", \\\"{x:1627,y:704,t:1526328816587};\\\", \\\"{x:1627,y:705,t:1526328816615};\\\", \\\"{x:1627,y:707,t:1526328816639};\\\", \\\"{x:1626,y:707,t:1526328816653};\\\", \\\"{x:1625,y:708,t:1526328816669};\\\", \\\"{x:1624,y:709,t:1526328816696};\\\", \\\"{x:1624,y:710,t:1526328816728};\\\", \\\"{x:1622,y:711,t:1526328816736};\\\", \\\"{x:1621,y:712,t:1526328816753};\\\", \\\"{x:1620,y:713,t:1526328816770};\\\", \\\"{x:1620,y:714,t:1526328816799};\\\", \\\"{x:1620,y:716,t:1526328816912};\\\", \\\"{x:1620,y:717,t:1526328816920};\\\", \\\"{x:1620,y:720,t:1526328816936};\\\", \\\"{x:1620,y:723,t:1526328816953};\\\", \\\"{x:1620,y:726,t:1526328816969};\\\", \\\"{x:1620,y:727,t:1526328816986};\\\", \\\"{x:1620,y:729,t:1526328817004};\\\", \\\"{x:1620,y:730,t:1526328817023};\\\", \\\"{x:1620,y:732,t:1526328817038};\\\", \\\"{x:1619,y:733,t:1526328817071};\\\", \\\"{x:1619,y:734,t:1526328817086};\\\", \\\"{x:1615,y:736,t:1526328817102};\\\", \\\"{x:1613,y:738,t:1526328817120};\\\", \\\"{x:1610,y:739,t:1526328817136};\\\", \\\"{x:1607,y:741,t:1526328817153};\\\", \\\"{x:1601,y:743,t:1526328817170};\\\", \\\"{x:1598,y:745,t:1526328817186};\\\", \\\"{x:1595,y:746,t:1526328817203};\\\", \\\"{x:1593,y:747,t:1526328817220};\\\", \\\"{x:1588,y:749,t:1526328817237};\\\", \\\"{x:1580,y:753,t:1526328817254};\\\", \\\"{x:1576,y:756,t:1526328817271};\\\", \\\"{x:1571,y:763,t:1526328817286};\\\", \\\"{x:1564,y:771,t:1526328817304};\\\", \\\"{x:1560,y:773,t:1526328817320};\\\", \\\"{x:1560,y:774,t:1526328817336};\\\", \\\"{x:1560,y:775,t:1526328817432};\\\", \\\"{x:1559,y:776,t:1526328817456};\\\", \\\"{x:1558,y:778,t:1526328817470};\\\", \\\"{x:1557,y:779,t:1526328817487};\\\", \\\"{x:1557,y:781,t:1526328817504};\\\", \\\"{x:1557,y:786,t:1526328817521};\\\", \\\"{x:1557,y:790,t:1526328817537};\\\", \\\"{x:1557,y:792,t:1526328817553};\\\", \\\"{x:1557,y:793,t:1526328817570};\\\", \\\"{x:1557,y:796,t:1526328817587};\\\", \\\"{x:1557,y:800,t:1526328817603};\\\", \\\"{x:1556,y:807,t:1526328817620};\\\", \\\"{x:1551,y:817,t:1526328817638};\\\", \\\"{x:1546,y:828,t:1526328817653};\\\", \\\"{x:1541,y:840,t:1526328817670};\\\", \\\"{x:1536,y:855,t:1526328817686};\\\", \\\"{x:1532,y:860,t:1526328817703};\\\", \\\"{x:1531,y:863,t:1526328817719};\\\", \\\"{x:1531,y:864,t:1526328817737};\\\", \\\"{x:1529,y:866,t:1526328817752};\\\", \\\"{x:1528,y:870,t:1526328817770};\\\", \\\"{x:1525,y:879,t:1526328817787};\\\", \\\"{x:1523,y:884,t:1526328817802};\\\", \\\"{x:1520,y:893,t:1526328817819};\\\", \\\"{x:1520,y:899,t:1526328817836};\\\", \\\"{x:1519,y:905,t:1526328817853};\\\", \\\"{x:1519,y:911,t:1526328817870};\\\", \\\"{x:1519,y:921,t:1526328817886};\\\", \\\"{x:1520,y:924,t:1526328817903};\\\", \\\"{x:1520,y:926,t:1526328817934};\\\", \\\"{x:1520,y:927,t:1526328817951};\\\", \\\"{x:1517,y:932,t:1526328817959};\\\", \\\"{x:1509,y:936,t:1526328817970};\\\", \\\"{x:1500,y:942,t:1526328817986};\\\", \\\"{x:1488,y:948,t:1526328818004};\\\", \\\"{x:1483,y:951,t:1526328818020};\\\", \\\"{x:1481,y:952,t:1526328818037};\\\", \\\"{x:1479,y:953,t:1526328818111};\\\", \\\"{x:1476,y:956,t:1526328818123};\\\", \\\"{x:1472,y:959,t:1526328818139};\\\", \\\"{x:1470,y:960,t:1526328818157};\\\", \\\"{x:1469,y:962,t:1526328818172};\\\", \\\"{x:1468,y:963,t:1526328818226};\\\", \\\"{x:1469,y:963,t:1526328818755};\\\", \\\"{x:1469,y:964,t:1526328818875};\\\", \\\"{x:1469,y:963,t:1526328819634};\\\", \\\"{x:1467,y:959,t:1526328819649};\\\", \\\"{x:1466,y:953,t:1526328819657};\\\", \\\"{x:1461,y:943,t:1526328819674};\\\", \\\"{x:1459,y:939,t:1526328819691};\\\", \\\"{x:1458,y:938,t:1526328819737};\\\", \\\"{x:1458,y:937,t:1526328819753};\\\", \\\"{x:1456,y:934,t:1526328819762};\\\", \\\"{x:1455,y:932,t:1526328819775};\\\", \\\"{x:1451,y:927,t:1526328819791};\\\", \\\"{x:1445,y:914,t:1526328819808};\\\", \\\"{x:1436,y:895,t:1526328819825};\\\", \\\"{x:1425,y:871,t:1526328819841};\\\", \\\"{x:1399,y:802,t:1526328819858};\\\", \\\"{x:1389,y:786,t:1526328819875};\\\", \\\"{x:1385,y:779,t:1526328819891};\\\", \\\"{x:1384,y:776,t:1526328819908};\\\", \\\"{x:1384,y:775,t:1526328819946};\\\", \\\"{x:1383,y:774,t:1526328819958};\\\", \\\"{x:1382,y:772,t:1526328819975};\\\", \\\"{x:1381,y:770,t:1526328819991};\\\", \\\"{x:1379,y:767,t:1526328820008};\\\", \\\"{x:1373,y:753,t:1526328820025};\\\", \\\"{x:1367,y:739,t:1526328820041};\\\", \\\"{x:1361,y:727,t:1526328820058};\\\", \\\"{x:1360,y:725,t:1526328820075};\\\", \\\"{x:1360,y:724,t:1526328820114};\\\", \\\"{x:1360,y:723,t:1526328820130};\\\", \\\"{x:1360,y:722,t:1526328820145};\\\", \\\"{x:1360,y:721,t:1526328820158};\\\", \\\"{x:1359,y:720,t:1526328820175};\\\", \\\"{x:1359,y:718,t:1526328820191};\\\", \\\"{x:1354,y:711,t:1526328820208};\\\", \\\"{x:1354,y:709,t:1526328820225};\\\", \\\"{x:1352,y:707,t:1526328820315};\\\", \\\"{x:1352,y:706,t:1526328820330};\\\", \\\"{x:1351,y:702,t:1526328820342};\\\", \\\"{x:1343,y:689,t:1526328820358};\\\", \\\"{x:1340,y:684,t:1526328820376};\\\", \\\"{x:1336,y:677,t:1526328820392};\\\", \\\"{x:1332,y:669,t:1526328820409};\\\", \\\"{x:1328,y:658,t:1526328820425};\\\", \\\"{x:1323,y:645,t:1526328820443};\\\", \\\"{x:1320,y:640,t:1526328820459};\\\", \\\"{x:1318,y:635,t:1526328820476};\\\", \\\"{x:1315,y:625,t:1526328820492};\\\", \\\"{x:1310,y:615,t:1526328820508};\\\", \\\"{x:1304,y:604,t:1526328820525};\\\", \\\"{x:1297,y:587,t:1526328820543};\\\", \\\"{x:1291,y:573,t:1526328820559};\\\", \\\"{x:1287,y:564,t:1526328820576};\\\", \\\"{x:1284,y:556,t:1526328820592};\\\", \\\"{x:1280,y:550,t:1526328820609};\\\", \\\"{x:1275,y:542,t:1526328820626};\\\", \\\"{x:1271,y:536,t:1526328820643};\\\", \\\"{x:1270,y:534,t:1526328820660};\\\", \\\"{x:1268,y:531,t:1526328820676};\\\", \\\"{x:1263,y:521,t:1526328820693};\\\", \\\"{x:1259,y:515,t:1526328820710};\\\", \\\"{x:1257,y:512,t:1526328820725};\\\", \\\"{x:1254,y:506,t:1526328820743};\\\", \\\"{x:1252,y:502,t:1526328820759};\\\", \\\"{x:1251,y:499,t:1526328820775};\\\", \\\"{x:1250,y:499,t:1526328820793};\\\", \\\"{x:1250,y:498,t:1526328820819};\\\", \\\"{x:1249,y:498,t:1526328820929};\\\", \\\"{x:1246,y:498,t:1526328821217};\\\", \\\"{x:1220,y:501,t:1526328821225};\\\", \\\"{x:1126,y:526,t:1526328821241};\\\", \\\"{x:1024,y:567,t:1526328821259};\\\", \\\"{x:956,y:608,t:1526328821276};\\\", \\\"{x:910,y:642,t:1526328821293};\\\", \\\"{x:853,y:686,t:1526328821309};\\\", \\\"{x:800,y:722,t:1526328821326};\\\", \\\"{x:773,y:746,t:1526328821342};\\\", \\\"{x:756,y:765,t:1526328821359};\\\", \\\"{x:745,y:780,t:1526328821376};\\\", \\\"{x:736,y:791,t:1526328821393};\\\", \\\"{x:726,y:797,t:1526328821408};\\\", \\\"{x:716,y:803,t:1526328821425};\\\", \\\"{x:713,y:803,t:1526328821442};\\\", \\\"{x:710,y:803,t:1526328821458};\\\", \\\"{x:705,y:801,t:1526328821475};\\\", \\\"{x:686,y:780,t:1526328821493};\\\", \\\"{x:662,y:748,t:1526328821509};\\\", \\\"{x:644,y:718,t:1526328821526};\\\", \\\"{x:636,y:693,t:1526328821543};\\\", \\\"{x:630,y:662,t:1526328821559};\\\", \\\"{x:618,y:627,t:1526328821577};\\\", \\\"{x:609,y:608,t:1526328821593};\\\", \\\"{x:593,y:586,t:1526328821609};\\\", \\\"{x:578,y:566,t:1526328821626};\\\", \\\"{x:573,y:558,t:1526328821643};\\\", \\\"{x:573,y:553,t:1526328821659};\\\", \\\"{x:573,y:548,t:1526328821676};\\\", \\\"{x:573,y:543,t:1526328821693};\\\", \\\"{x:574,y:534,t:1526328821710};\\\", \\\"{x:576,y:527,t:1526328821726};\\\", \\\"{x:582,y:522,t:1526328821743};\\\", \\\"{x:585,y:521,t:1526328821760};\\\", \\\"{x:589,y:518,t:1526328821776};\\\", \\\"{x:591,y:517,t:1526328821794};\\\", \\\"{x:594,y:515,t:1526328821809};\\\", \\\"{x:595,y:511,t:1526328821826};\\\", \\\"{x:597,y:510,t:1526328821842};\\\", \\\"{x:597,y:509,t:1526328821873};\\\", \\\"{x:597,y:508,t:1526328821905};\\\", \\\"{x:600,y:507,t:1526328822122};\\\", \\\"{x:610,y:507,t:1526328822129};\\\", \\\"{x:626,y:503,t:1526328822142};\\\", \\\"{x:659,y:503,t:1526328822161};\\\", \\\"{x:691,y:503,t:1526328822176};\\\", \\\"{x:712,y:503,t:1526328822193};\\\", \\\"{x:719,y:503,t:1526328822209};\\\", \\\"{x:720,y:503,t:1526328822226};\\\", \\\"{x:721,y:503,t:1526328822258};\\\", \\\"{x:723,y:502,t:1526328822265};\\\", \\\"{x:725,y:502,t:1526328822282};\\\", \\\"{x:726,y:502,t:1526328822298};\\\", \\\"{x:728,y:502,t:1526328822310};\\\", \\\"{x:735,y:501,t:1526328822327};\\\", \\\"{x:744,y:501,t:1526328822343};\\\", \\\"{x:755,y:501,t:1526328822360};\\\", \\\"{x:769,y:501,t:1526328822377};\\\", \\\"{x:780,y:501,t:1526328822393};\\\", \\\"{x:805,y:501,t:1526328822410};\\\", \\\"{x:818,y:501,t:1526328822427};\\\", \\\"{x:832,y:501,t:1526328822443};\\\", \\\"{x:839,y:501,t:1526328822460};\\\", \\\"{x:848,y:501,t:1526328822477};\\\", \\\"{x:850,y:501,t:1526328822493};\\\", \\\"{x:852,y:501,t:1526328822510};\\\", \\\"{x:854,y:501,t:1526328822527};\\\", \\\"{x:855,y:501,t:1526328822657};\\\", \\\"{x:856,y:501,t:1526328822682};\\\", \\\"{x:857,y:501,t:1526328822713};\\\", \\\"{x:857,y:502,t:1526328822970};\\\", \\\"{x:856,y:502,t:1526328822994};\\\", \\\"{x:854,y:503,t:1526328823115};\\\", \\\"{x:852,y:503,t:1526328823130};\\\", \\\"{x:849,y:503,t:1526328823144};\\\", \\\"{x:837,y:503,t:1526328823161};\\\", \\\"{x:818,y:503,t:1526328823179};\\\", \\\"{x:757,y:503,t:1526328823194};\\\", \\\"{x:729,y:503,t:1526328823210};\\\", \\\"{x:712,y:503,t:1526328823228};\\\", \\\"{x:705,y:503,t:1526328823244};\\\", \\\"{x:703,y:505,t:1526328823260};\\\", \\\"{x:702,y:505,t:1526328823277};\\\", \\\"{x:699,y:506,t:1526328823294};\\\", \\\"{x:696,y:506,t:1526328823311};\\\", \\\"{x:692,y:506,t:1526328823327};\\\", \\\"{x:691,y:506,t:1526328823378};\\\", \\\"{x:689,y:506,t:1526328823403};\\\", \\\"{x:685,y:506,t:1526328823411};\\\", \\\"{x:675,y:507,t:1526328823427};\\\", \\\"{x:663,y:507,t:1526328823444};\\\", \\\"{x:653,y:507,t:1526328823461};\\\", \\\"{x:646,y:510,t:1526328823477};\\\", \\\"{x:644,y:510,t:1526328823495};\\\", \\\"{x:642,y:510,t:1526328823538};\\\", \\\"{x:639,y:511,t:1526328823545};\\\", \\\"{x:635,y:511,t:1526328823560};\\\", \\\"{x:622,y:515,t:1526328823577};\\\", \\\"{x:609,y:515,t:1526328823594};\\\", \\\"{x:608,y:515,t:1526328823697};\\\", \\\"{x:608,y:514,t:1526328823714};\\\", \\\"{x:608,y:512,t:1526328823730};\\\", \\\"{x:609,y:510,t:1526328823753};\\\", \\\"{x:606,y:512,t:1526328823969};\\\", \\\"{x:603,y:520,t:1526328823978};\\\", \\\"{x:599,y:548,t:1526328823994};\\\", \\\"{x:593,y:635,t:1526328824012};\\\", \\\"{x:593,y:697,t:1526328824027};\\\", \\\"{x:589,y:736,t:1526328824044};\\\", \\\"{x:585,y:748,t:1526328824061};\\\", \\\"{x:582,y:751,t:1526328824078};\\\", \\\"{x:578,y:755,t:1526328824095};\\\", \\\"{x:573,y:760,t:1526328824111};\\\", \\\"{x:569,y:765,t:1526328824128};\\\", \\\"{x:561,y:771,t:1526328824144};\\\", \\\"{x:558,y:772,t:1526328824161};\\\", \\\"{x:552,y:775,t:1526328824178};\\\", \\\"{x:550,y:776,t:1526328824195};\\\", \\\"{x:548,y:776,t:1526328824225};\\\", \\\"{x:547,y:776,t:1526328824346};\\\", \\\"{x:545,y:776,t:1526328824409};\\\", \\\"{x:544,y:774,t:1526328824417};\\\", \\\"{x:542,y:773,t:1526328824441};\\\", \\\"{x:541,y:771,t:1526328824449};\\\", \\\"{x:540,y:770,t:1526328824466};\\\", \\\"{x:540,y:769,t:1526328824478};\\\", \\\"{x:537,y:766,t:1526328824495};\\\", \\\"{x:534,y:763,t:1526328824511};\\\", \\\"{x:533,y:763,t:1526328824528};\\\", \\\"{x:532,y:761,t:1526328824545};\\\", \\\"{x:530,y:759,t:1526328824561};\\\", \\\"{x:530,y:758,t:1526328824706};\\\", \\\"{x:530,y:754,t:1526328824714};\\\", \\\"{x:530,y:753,t:1526328824728};\\\", \\\"{x:529,y:747,t:1526328824745};\\\", \\\"{x:526,y:739,t:1526328824763};\\\", \\\"{x:525,y:735,t:1526328824779};\\\", \\\"{x:525,y:732,t:1526328824795};\\\", \\\"{x:523,y:730,t:1526328824812};\\\", \\\"{x:523,y:728,t:1526328824830};\\\", \\\"{x:524,y:727,t:1526328825810};\\\", \\\"{x:525,y:727,t:1526328825817};\\\", \\\"{x:526,y:726,t:1526328825829};\\\", \\\"{x:527,y:726,t:1526328825846};\\\", \\\"{x:528,y:726,t:1526328825866};\\\", \\\"{x:529,y:726,t:1526328825906};\\\", \\\"{x:530,y:726,t:1526328825929};\\\", \\\"{x:531,y:726,t:1526328825969};\\\", \\\"{x:532,y:726,t:1526328826354};\\\" ] }, { \\\"rt\\\": 17910, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 686004, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:726,t:1526328826573};\\\", \\\"{x:535,y:726,t:1526328832441};\\\", \\\"{x:536,y:726,t:1526328832482};\\\", \\\"{x:537,y:726,t:1526328832787};\\\", \\\"{x:538,y:726,t:1526328832810};\\\", \\\"{x:526,y:726,t:1526328833754};\\\", \\\"{x:500,y:726,t:1526328833769};\\\", \\\"{x:378,y:726,t:1526328833787};\\\", \\\"{x:309,y:726,t:1526328833801};\\\", \\\"{x:271,y:726,t:1526328833818};\\\", \\\"{x:258,y:726,t:1526328833836};\\\", \\\"{x:256,y:726,t:1526328833852};\\\", \\\"{x:254,y:726,t:1526328833890};\\\", \\\"{x:252,y:724,t:1526328833903};\\\", \\\"{x:244,y:720,t:1526328833919};\\\", \\\"{x:238,y:716,t:1526328833935};\\\", \\\"{x:233,y:713,t:1526328833952};\\\", \\\"{x:228,y:710,t:1526328833970};\\\", \\\"{x:224,y:708,t:1526328833986};\\\", \\\"{x:217,y:703,t:1526328834003};\\\", \\\"{x:198,y:686,t:1526328834020};\\\", \\\"{x:186,y:668,t:1526328834036};\\\", \\\"{x:181,y:659,t:1526328834053};\\\", \\\"{x:176,y:647,t:1526328834070};\\\", \\\"{x:172,y:635,t:1526328834086};\\\", \\\"{x:168,y:626,t:1526328834103};\\\", \\\"{x:165,y:618,t:1526328834119};\\\", \\\"{x:163,y:616,t:1526328834135};\\\", \\\"{x:161,y:613,t:1526328834153};\\\", \\\"{x:156,y:607,t:1526328834170};\\\", \\\"{x:154,y:604,t:1526328834186};\\\", \\\"{x:153,y:603,t:1526328834202};\\\", \\\"{x:153,y:600,t:1526328834220};\\\", \\\"{x:153,y:596,t:1526328834236};\\\", \\\"{x:154,y:591,t:1526328834253};\\\", \\\"{x:158,y:587,t:1526328834270};\\\", \\\"{x:163,y:584,t:1526328834287};\\\", \\\"{x:167,y:582,t:1526328834302};\\\", \\\"{x:172,y:578,t:1526328834319};\\\", \\\"{x:174,y:576,t:1526328834336};\\\", \\\"{x:177,y:576,t:1526328834352};\\\", \\\"{x:180,y:574,t:1526328834369};\\\", \\\"{x:186,y:570,t:1526328834386};\\\", \\\"{x:195,y:567,t:1526328834403};\\\", \\\"{x:202,y:564,t:1526328834420};\\\", \\\"{x:203,y:564,t:1526328834436};\\\", \\\"{x:203,y:563,t:1526328834481};\\\", \\\"{x:204,y:562,t:1526328834498};\\\", \\\"{x:205,y:561,t:1526328834505};\\\", \\\"{x:207,y:559,t:1526328834520};\\\", \\\"{x:209,y:553,t:1526328834536};\\\", \\\"{x:210,y:552,t:1526328834552};\\\", \\\"{x:211,y:550,t:1526328834569};\\\", \\\"{x:212,y:547,t:1526328834587};\\\", \\\"{x:213,y:546,t:1526328834609};\\\", \\\"{x:213,y:545,t:1526328834619};\\\", \\\"{x:214,y:541,t:1526328834637};\\\", \\\"{x:217,y:538,t:1526328834653};\\\", \\\"{x:218,y:537,t:1526328834850};\\\", \\\"{x:219,y:536,t:1526328835722};\\\", \\\"{x:221,y:534,t:1526328835737};\\\", \\\"{x:222,y:534,t:1526328835755};\\\", \\\"{x:223,y:533,t:1526328835771};\\\", \\\"{x:225,y:533,t:1526328835850};\\\", \\\"{x:226,y:532,t:1526328835866};\\\", \\\"{x:227,y:531,t:1526328835874};\\\", \\\"{x:228,y:531,t:1526328835890};\\\", \\\"{x:229,y:530,t:1526328835905};\\\", \\\"{x:233,y:529,t:1526328835921};\\\", \\\"{x:240,y:527,t:1526328835938};\\\", \\\"{x:249,y:526,t:1526328835955};\\\", \\\"{x:275,y:526,t:1526328835972};\\\", \\\"{x:333,y:526,t:1526328835988};\\\", \\\"{x:430,y:526,t:1526328836004};\\\", \\\"{x:552,y:526,t:1526328836020};\\\", \\\"{x:674,y:526,t:1526328836036};\\\", \\\"{x:804,y:526,t:1526328836054};\\\", \\\"{x:921,y:524,t:1526328836070};\\\", \\\"{x:1026,y:524,t:1526328836087};\\\", \\\"{x:1123,y:524,t:1526328836105};\\\", \\\"{x:1218,y:520,t:1526328836121};\\\", \\\"{x:1368,y:520,t:1526328836137};\\\", \\\"{x:1454,y:520,t:1526328836154};\\\", \\\"{x:1515,y:520,t:1526328836171};\\\", \\\"{x:1556,y:522,t:1526328836187};\\\", \\\"{x:1591,y:534,t:1526328836204};\\\", \\\"{x:1633,y:553,t:1526328836222};\\\", \\\"{x:1676,y:587,t:1526328836237};\\\", \\\"{x:1729,y:648,t:1526328836255};\\\", \\\"{x:1789,y:734,t:1526328836272};\\\", \\\"{x:1831,y:808,t:1526328836287};\\\", \\\"{x:1861,y:862,t:1526328836304};\\\", \\\"{x:1881,y:907,t:1526328836322};\\\", \\\"{x:1891,y:929,t:1526328836337};\\\", \\\"{x:1897,y:950,t:1526328836354};\\\", \\\"{x:1898,y:966,t:1526328836372};\\\", \\\"{x:1897,y:982,t:1526328836389};\\\", \\\"{x:1890,y:1005,t:1526328836405};\\\", \\\"{x:1874,y:1029,t:1526328836422};\\\", \\\"{x:1860,y:1052,t:1526328836438};\\\", \\\"{x:1845,y:1079,t:1526328836455};\\\", \\\"{x:1830,y:1098,t:1526328836472};\\\", \\\"{x:1821,y:1112,t:1526328836489};\\\", \\\"{x:1815,y:1120,t:1526328836505};\\\", \\\"{x:1813,y:1122,t:1526328836522};\\\", \\\"{x:1812,y:1123,t:1526328836539};\\\", \\\"{x:1811,y:1123,t:1526328836594};\\\", \\\"{x:1804,y:1121,t:1526328836606};\\\", \\\"{x:1786,y:1112,t:1526328836621};\\\", \\\"{x:1757,y:1099,t:1526328836639};\\\", \\\"{x:1715,y:1080,t:1526328836655};\\\", \\\"{x:1660,y:1056,t:1526328836672};\\\", \\\"{x:1618,y:1045,t:1526328836689};\\\", \\\"{x:1562,y:1027,t:1526328836705};\\\", \\\"{x:1534,y:1016,t:1526328836723};\\\", \\\"{x:1516,y:1007,t:1526328836739};\\\", \\\"{x:1502,y:1002,t:1526328836756};\\\", \\\"{x:1497,y:1000,t:1526328836773};\\\", \\\"{x:1496,y:999,t:1526328836788};\\\", \\\"{x:1496,y:998,t:1526328836850};\\\", \\\"{x:1496,y:996,t:1526328836890};\\\", \\\"{x:1497,y:994,t:1526328836906};\\\", \\\"{x:1506,y:984,t:1526328836923};\\\", \\\"{x:1513,y:975,t:1526328836940};\\\", \\\"{x:1521,y:968,t:1526328836956};\\\", \\\"{x:1523,y:966,t:1526328836972};\\\", \\\"{x:1525,y:965,t:1526328836990};\\\", \\\"{x:1526,y:964,t:1526328837006};\\\", \\\"{x:1527,y:962,t:1526328837022};\\\", \\\"{x:1528,y:960,t:1526328837040};\\\", \\\"{x:1532,y:956,t:1526328837056};\\\", \\\"{x:1533,y:951,t:1526328837073};\\\", \\\"{x:1534,y:949,t:1526328837090};\\\", \\\"{x:1534,y:948,t:1526328838921};\\\", \\\"{x:1531,y:943,t:1526328838930};\\\", \\\"{x:1520,y:936,t:1526328838943};\\\", \\\"{x:1481,y:896,t:1526328838961};\\\", \\\"{x:1436,y:854,t:1526328838977};\\\", \\\"{x:1375,y:821,t:1526328838993};\\\", \\\"{x:1311,y:792,t:1526328839011};\\\", \\\"{x:1230,y:764,t:1526328839028};\\\", \\\"{x:1107,y:745,t:1526328839044};\\\", \\\"{x:969,y:726,t:1526328839061};\\\", \\\"{x:837,y:716,t:1526328839077};\\\", \\\"{x:743,y:716,t:1526328839094};\\\", \\\"{x:704,y:716,t:1526328839111};\\\", \\\"{x:685,y:716,t:1526328839128};\\\", \\\"{x:671,y:716,t:1526328839143};\\\", \\\"{x:657,y:716,t:1526328839161};\\\", \\\"{x:621,y:721,t:1526328839177};\\\", \\\"{x:594,y:723,t:1526328839195};\\\", \\\"{x:566,y:727,t:1526328839211};\\\", \\\"{x:546,y:732,t:1526328839228};\\\", \\\"{x:536,y:732,t:1526328839244};\\\", \\\"{x:530,y:734,t:1526328839257};\\\", \\\"{x:519,y:734,t:1526328839273};\\\", \\\"{x:504,y:734,t:1526328839290};\\\", \\\"{x:479,y:734,t:1526328839307};\\\", \\\"{x:455,y:734,t:1526328839324};\\\", \\\"{x:442,y:734,t:1526328839339};\\\", \\\"{x:427,y:737,t:1526328839357};\\\", \\\"{x:412,y:739,t:1526328839373};\\\", \\\"{x:389,y:744,t:1526328839390};\\\", \\\"{x:362,y:749,t:1526328839406};\\\", \\\"{x:324,y:754,t:1526328839423};\\\", \\\"{x:298,y:757,t:1526328839439};\\\", \\\"{x:277,y:763,t:1526328839457};\\\", \\\"{x:247,y:765,t:1526328839473};\\\", \\\"{x:229,y:766,t:1526328839490};\\\", \\\"{x:214,y:766,t:1526328839506};\\\", \\\"{x:210,y:766,t:1526328839524};\\\", \\\"{x:210,y:763,t:1526328839553};\\\", \\\"{x:210,y:759,t:1526328839561};\\\", \\\"{x:210,y:757,t:1526328839574};\\\", \\\"{x:214,y:746,t:1526328839590};\\\", \\\"{x:222,y:735,t:1526328839607};\\\", \\\"{x:232,y:721,t:1526328839624};\\\", \\\"{x:247,y:697,t:1526328839640};\\\", \\\"{x:276,y:664,t:1526328839657};\\\", \\\"{x:358,y:605,t:1526328839674};\\\", \\\"{x:421,y:577,t:1526328839691};\\\", \\\"{x:462,y:562,t:1526328839707};\\\", \\\"{x:479,y:556,t:1526328839724};\\\", \\\"{x:489,y:552,t:1526328839741};\\\", \\\"{x:493,y:551,t:1526328839756};\\\", \\\"{x:497,y:551,t:1526328839774};\\\", \\\"{x:506,y:550,t:1526328839791};\\\", \\\"{x:517,y:547,t:1526328839806};\\\", \\\"{x:521,y:547,t:1526328839823};\\\", \\\"{x:526,y:547,t:1526328839841};\\\", \\\"{x:528,y:547,t:1526328839857};\\\", \\\"{x:531,y:547,t:1526328839873};\\\", \\\"{x:535,y:547,t:1526328839890};\\\", \\\"{x:541,y:547,t:1526328839907};\\\", \\\"{x:549,y:548,t:1526328839924};\\\", \\\"{x:565,y:553,t:1526328839940};\\\", \\\"{x:579,y:555,t:1526328839958};\\\", \\\"{x:593,y:556,t:1526328839974};\\\", \\\"{x:602,y:557,t:1526328839991};\\\", \\\"{x:605,y:558,t:1526328840007};\\\", \\\"{x:600,y:560,t:1526328840081};\\\", \\\"{x:591,y:564,t:1526328840091};\\\", \\\"{x:574,y:570,t:1526328840107};\\\", \\\"{x:566,y:573,t:1526328840124};\\\", \\\"{x:564,y:574,t:1526328840140};\\\", \\\"{x:565,y:574,t:1526328840209};\\\", \\\"{x:570,y:574,t:1526328840223};\\\", \\\"{x:593,y:574,t:1526328840241};\\\", \\\"{x:626,y:574,t:1526328840258};\\\", \\\"{x:632,y:574,t:1526328840274};\\\", \\\"{x:634,y:575,t:1526328840737};\\\", \\\"{x:633,y:578,t:1526328840745};\\\", \\\"{x:628,y:582,t:1526328840757};\\\", \\\"{x:616,y:588,t:1526328840774};\\\", \\\"{x:609,y:593,t:1526328840791};\\\", \\\"{x:604,y:596,t:1526328840808};\\\", \\\"{x:601,y:598,t:1526328840824};\\\", \\\"{x:598,y:600,t:1526328840840};\\\", \\\"{x:583,y:609,t:1526328840858};\\\", \\\"{x:564,y:615,t:1526328840875};\\\", \\\"{x:537,y:627,t:1526328840891};\\\", \\\"{x:508,y:639,t:1526328840908};\\\", \\\"{x:480,y:656,t:1526328840925};\\\", \\\"{x:466,y:674,t:1526328840941};\\\", \\\"{x:456,y:688,t:1526328840958};\\\", \\\"{x:451,y:700,t:1526328840975};\\\", \\\"{x:451,y:715,t:1526328840992};\\\", \\\"{x:451,y:718,t:1526328841008};\\\", \\\"{x:451,y:722,t:1526328841025};\\\", \\\"{x:451,y:724,t:1526328841041};\\\", \\\"{x:451,y:727,t:1526328841057};\\\", \\\"{x:451,y:728,t:1526328841075};\\\", \\\"{x:452,y:729,t:1526328841105};\\\", \\\"{x:452,y:730,t:1526328841145};\\\", \\\"{x:453,y:730,t:1526328841158};\\\", \\\"{x:456,y:730,t:1526328841175};\\\", \\\"{x:460,y:731,t:1526328841192};\\\", \\\"{x:468,y:735,t:1526328841207};\\\", \\\"{x:475,y:736,t:1526328841225};\\\", \\\"{x:480,y:738,t:1526328841241};\\\", \\\"{x:482,y:739,t:1526328841257};\\\", \\\"{x:483,y:739,t:1526328841673};\\\", \\\"{x:484,y:738,t:1526328842225};\\\", \\\"{x:485,y:737,t:1526328842242};\\\", \\\"{x:487,y:736,t:1526328842297};\\\", \\\"{x:487,y:735,t:1526328842329};\\\", \\\"{x:488,y:735,t:1526328842345};\\\", \\\"{x:489,y:735,t:1526328842369};\\\", \\\"{x:489,y:734,t:1526328842393};\\\", \\\"{x:491,y:734,t:1526328844561};\\\", \\\"{x:492,y:734,t:1526328844593};\\\", \\\"{x:493,y:734,t:1526328844601};\\\", \\\"{x:494,y:734,t:1526328844611};\\\", \\\"{x:496,y:734,t:1526328844632};\\\", \\\"{x:496,y:733,t:1526328844673};\\\", \\\"{x:497,y:732,t:1526328844769};\\\", \\\"{x:499,y:732,t:1526328844793};\\\", \\\"{x:501,y:731,t:1526328844801};\\\", \\\"{x:502,y:731,t:1526328844811};\\\", \\\"{x:510,y:729,t:1526328844828};\\\", \\\"{x:526,y:726,t:1526328844843};\\\", \\\"{x:553,y:723,t:1526328844861};\\\", \\\"{x:595,y:716,t:1526328844878};\\\", \\\"{x:651,y:708,t:1526328844894};\\\", \\\"{x:717,y:699,t:1526328844911};\\\", \\\"{x:781,y:691,t:1526328844928};\\\", \\\"{x:851,y:680,t:1526328844944};\\\", \\\"{x:939,y:667,t:1526328844961};\\\", \\\"{x:984,y:660,t:1526328844978};\\\", \\\"{x:1015,y:653,t:1526328844994};\\\", \\\"{x:1047,y:644,t:1526328845010};\\\", \\\"{x:1085,y:632,t:1526328845028};\\\", \\\"{x:1126,y:617,t:1526328845045};\\\", \\\"{x:1155,y:605,t:1526328845060};\\\", \\\"{x:1195,y:592,t:1526328845078};\\\", \\\"{x:1239,y:574,t:1526328845094};\\\", \\\"{x:1266,y:563,t:1526328845110};\\\", \\\"{x:1292,y:552,t:1526328845128};\\\", \\\"{x:1318,y:546,t:1526328845145};\\\", \\\"{x:1323,y:544,t:1526328845161};\\\", \\\"{x:1339,y:537,t:1526328845178};\\\", \\\"{x:1348,y:535,t:1526328845195};\\\", \\\"{x:1356,y:532,t:1526328845211};\\\", \\\"{x:1363,y:529,t:1526328845228};\\\", \\\"{x:1367,y:527,t:1526328845245};\\\", \\\"{x:1369,y:527,t:1526328845261};\\\", \\\"{x:1370,y:527,t:1526328845402};\\\" ] }, { \\\"rt\\\": 18654, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 706021, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 4.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -05 PM-02 PM-K -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1372,y:527,t:1526328849297};\\\", \\\"{x:1390,y:558,t:1526328849315};\\\", \\\"{x:1466,y:702,t:1526328849331};\\\", \\\"{x:1532,y:825,t:1526328849348};\\\", \\\"{x:1600,y:935,t:1526328849364};\\\", \\\"{x:1652,y:1025,t:1526328849381};\\\", \\\"{x:1666,y:1060,t:1526328849399};\\\", \\\"{x:1667,y:1076,t:1526328849414};\\\", \\\"{x:1667,y:1085,t:1526328849431};\\\", \\\"{x:1666,y:1100,t:1526328849448};\\\", \\\"{x:1666,y:1125,t:1526328849464};\\\", \\\"{x:1678,y:1162,t:1526328849481};\\\", \\\"{x:1686,y:1192,t:1526328849498};\\\", \\\"{x:1690,y:1199,t:1526328849514};\\\", \\\"{x:1691,y:1199,t:1526328849531};\\\", \\\"{x:1688,y:1199,t:1526328849553};\\\", \\\"{x:1687,y:1199,t:1526328849565};\\\", \\\"{x:1685,y:1199,t:1526328849581};\\\", \\\"{x:1680,y:1199,t:1526328849598};\\\", \\\"{x:1669,y:1199,t:1526328849615};\\\", \\\"{x:1649,y:1199,t:1526328849631};\\\", \\\"{x:1614,y:1199,t:1526328849648};\\\", \\\"{x:1535,y:1199,t:1526328849665};\\\", \\\"{x:1487,y:1199,t:1526328849681};\\\", \\\"{x:1448,y:1199,t:1526328849698};\\\", \\\"{x:1426,y:1199,t:1526328849715};\\\", \\\"{x:1413,y:1199,t:1526328849732};\\\", \\\"{x:1405,y:1199,t:1526328849748};\\\", \\\"{x:1398,y:1199,t:1526328849765};\\\", \\\"{x:1381,y:1195,t:1526328849782};\\\", \\\"{x:1361,y:1187,t:1526328849798};\\\", \\\"{x:1329,y:1173,t:1526328849815};\\\", \\\"{x:1301,y:1155,t:1526328849832};\\\", \\\"{x:1278,y:1140,t:1526328849848};\\\", \\\"{x:1256,y:1124,t:1526328849865};\\\", \\\"{x:1248,y:1112,t:1526328849882};\\\", \\\"{x:1238,y:1089,t:1526328849898};\\\", \\\"{x:1221,y:1056,t:1526328849915};\\\", \\\"{x:1205,y:1022,t:1526328849932};\\\", \\\"{x:1195,y:998,t:1526328849948};\\\", \\\"{x:1186,y:975,t:1526328849966};\\\", \\\"{x:1182,y:956,t:1526328849982};\\\", \\\"{x:1182,y:947,t:1526328849999};\\\", \\\"{x:1187,y:935,t:1526328850015};\\\", \\\"{x:1201,y:919,t:1526328850033};\\\", \\\"{x:1219,y:898,t:1526328850048};\\\", \\\"{x:1243,y:870,t:1526328850065};\\\", \\\"{x:1262,y:855,t:1526328850082};\\\", \\\"{x:1280,y:841,t:1526328850098};\\\", \\\"{x:1303,y:825,t:1526328850116};\\\", \\\"{x:1336,y:804,t:1526328850132};\\\", \\\"{x:1363,y:784,t:1526328850148};\\\", \\\"{x:1397,y:766,t:1526328850166};\\\", \\\"{x:1421,y:749,t:1526328850182};\\\", \\\"{x:1449,y:731,t:1526328850198};\\\", \\\"{x:1474,y:712,t:1526328850216};\\\", \\\"{x:1492,y:702,t:1526328850232};\\\", \\\"{x:1504,y:696,t:1526328850249};\\\", \\\"{x:1524,y:693,t:1526328850266};\\\", \\\"{x:1536,y:693,t:1526328850282};\\\", \\\"{x:1551,y:693,t:1526328850299};\\\", \\\"{x:1564,y:693,t:1526328850315};\\\", \\\"{x:1577,y:693,t:1526328850332};\\\", \\\"{x:1591,y:693,t:1526328850349};\\\", \\\"{x:1613,y:694,t:1526328850366};\\\", \\\"{x:1642,y:700,t:1526328850382};\\\", \\\"{x:1672,y:707,t:1526328850400};\\\", \\\"{x:1701,y:712,t:1526328850415};\\\", \\\"{x:1723,y:716,t:1526328850432};\\\", \\\"{x:1735,y:718,t:1526328850449};\\\", \\\"{x:1736,y:718,t:1526328850465};\\\", \\\"{x:1737,y:718,t:1526328850533};\\\", \\\"{x:1738,y:718,t:1526328851793};\\\", \\\"{x:1738,y:717,t:1526328851801};\\\", \\\"{x:1740,y:715,t:1526328851817};\\\", \\\"{x:1741,y:714,t:1526328851833};\\\", \\\"{x:1741,y:712,t:1526328851850};\\\", \\\"{x:1742,y:710,t:1526328851866};\\\", \\\"{x:1743,y:708,t:1526328851883};\\\", \\\"{x:1744,y:707,t:1526328851900};\\\", \\\"{x:1745,y:706,t:1526328851917};\\\", \\\"{x:1746,y:705,t:1526328851938};\\\", \\\"{x:1746,y:704,t:1526328851969};\\\", \\\"{x:1746,y:703,t:1526328851984};\\\", \\\"{x:1747,y:702,t:1526328852000};\\\", \\\"{x:1747,y:698,t:1526328852016};\\\", \\\"{x:1750,y:690,t:1526328852033};\\\", \\\"{x:1750,y:686,t:1526328852051};\\\", \\\"{x:1750,y:680,t:1526328852067};\\\", \\\"{x:1750,y:675,t:1526328852083};\\\", \\\"{x:1749,y:672,t:1526328852100};\\\", \\\"{x:1747,y:668,t:1526328852117};\\\", \\\"{x:1743,y:665,t:1526328852133};\\\", \\\"{x:1739,y:663,t:1526328852150};\\\", \\\"{x:1733,y:660,t:1526328852167};\\\", \\\"{x:1725,y:655,t:1526328852183};\\\", \\\"{x:1716,y:650,t:1526328852201};\\\", \\\"{x:1698,y:635,t:1526328852217};\\\", \\\"{x:1670,y:617,t:1526328852233};\\\", \\\"{x:1654,y:606,t:1526328852250};\\\", \\\"{x:1644,y:603,t:1526328852268};\\\", \\\"{x:1638,y:598,t:1526328852283};\\\", \\\"{x:1628,y:594,t:1526328852300};\\\", \\\"{x:1614,y:588,t:1526328852317};\\\", \\\"{x:1596,y:582,t:1526328852333};\\\", \\\"{x:1578,y:577,t:1526328852351};\\\", \\\"{x:1563,y:575,t:1526328852367};\\\", \\\"{x:1551,y:574,t:1526328852383};\\\", \\\"{x:1550,y:574,t:1526328852441};\\\", \\\"{x:1550,y:575,t:1526328852513};\\\", \\\"{x:1550,y:582,t:1526328852521};\\\", \\\"{x:1551,y:591,t:1526328852534};\\\", \\\"{x:1556,y:623,t:1526328852551};\\\", \\\"{x:1564,y:663,t:1526328852568};\\\", \\\"{x:1588,y:721,t:1526328852583};\\\", \\\"{x:1613,y:776,t:1526328852600};\\\", \\\"{x:1644,y:833,t:1526328852617};\\\", \\\"{x:1660,y:858,t:1526328852633};\\\", \\\"{x:1674,y:874,t:1526328852650};\\\", \\\"{x:1682,y:885,t:1526328852667};\\\", \\\"{x:1683,y:890,t:1526328852685};\\\", \\\"{x:1684,y:894,t:1526328852701};\\\", \\\"{x:1686,y:898,t:1526328852717};\\\", \\\"{x:1688,y:901,t:1526328852734};\\\", \\\"{x:1688,y:902,t:1526328852750};\\\", \\\"{x:1689,y:903,t:1526328852767};\\\", \\\"{x:1689,y:904,t:1526328852786};\\\", \\\"{x:1689,y:905,t:1526328852809};\\\", \\\"{x:1689,y:906,t:1526328852817};\\\", \\\"{x:1690,y:911,t:1526328852834};\\\", \\\"{x:1691,y:914,t:1526328852851};\\\", \\\"{x:1692,y:917,t:1526328852868};\\\", \\\"{x:1692,y:918,t:1526328852885};\\\", \\\"{x:1693,y:919,t:1526328852901};\\\", \\\"{x:1693,y:921,t:1526328852918};\\\", \\\"{x:1694,y:924,t:1526328852934};\\\", \\\"{x:1697,y:930,t:1526328852950};\\\", \\\"{x:1698,y:934,t:1526328852968};\\\", \\\"{x:1700,y:939,t:1526328852985};\\\", \\\"{x:1701,y:944,t:1526328853000};\\\", \\\"{x:1701,y:953,t:1526328853018};\\\", \\\"{x:1701,y:959,t:1526328853034};\\\", \\\"{x:1701,y:964,t:1526328853051};\\\", \\\"{x:1701,y:972,t:1526328853067};\\\", \\\"{x:1700,y:976,t:1526328853084};\\\", \\\"{x:1699,y:979,t:1526328853100};\\\", \\\"{x:1694,y:987,t:1526328853117};\\\", \\\"{x:1685,y:997,t:1526328853135};\\\", \\\"{x:1668,y:1013,t:1526328853151};\\\", \\\"{x:1647,y:1027,t:1526328853167};\\\", \\\"{x:1606,y:1049,t:1526328853184};\\\", \\\"{x:1546,y:1069,t:1526328853201};\\\", \\\"{x:1509,y:1081,t:1526328853217};\\\", \\\"{x:1496,y:1086,t:1526328853234};\\\", \\\"{x:1493,y:1087,t:1526328853251};\\\", \\\"{x:1493,y:1088,t:1526328853267};\\\", \\\"{x:1491,y:1088,t:1526328853377};\\\", \\\"{x:1489,y:1088,t:1526328853393};\\\", \\\"{x:1486,y:1088,t:1526328853401};\\\", \\\"{x:1478,y:1080,t:1526328853417};\\\", \\\"{x:1478,y:1076,t:1526328853434};\\\", \\\"{x:1474,y:1064,t:1526328853451};\\\", \\\"{x:1473,y:1054,t:1526328853467};\\\", \\\"{x:1472,y:1043,t:1526328853484};\\\", \\\"{x:1471,y:1036,t:1526328853501};\\\", \\\"{x:1470,y:1032,t:1526328853518};\\\", \\\"{x:1470,y:1028,t:1526328853534};\\\", \\\"{x:1470,y:1026,t:1526328853551};\\\", \\\"{x:1469,y:1023,t:1526328853568};\\\", \\\"{x:1468,y:1022,t:1526328853584};\\\", \\\"{x:1468,y:1021,t:1526328853641};\\\", \\\"{x:1468,y:1018,t:1526328853705};\\\", \\\"{x:1468,y:1014,t:1526328853718};\\\", \\\"{x:1468,y:1007,t:1526328853734};\\\", \\\"{x:1468,y:996,t:1526328853752};\\\", \\\"{x:1468,y:986,t:1526328853769};\\\", \\\"{x:1468,y:976,t:1526328853785};\\\", \\\"{x:1468,y:956,t:1526328853801};\\\", \\\"{x:1468,y:939,t:1526328853819};\\\", \\\"{x:1468,y:919,t:1526328853834};\\\", \\\"{x:1468,y:889,t:1526328853852};\\\", \\\"{x:1468,y:863,t:1526328853868};\\\", \\\"{x:1468,y:844,t:1526328853885};\\\", \\\"{x:1466,y:825,t:1526328853901};\\\", \\\"{x:1466,y:816,t:1526328853918};\\\", \\\"{x:1466,y:810,t:1526328853934};\\\", \\\"{x:1466,y:807,t:1526328853952};\\\", \\\"{x:1466,y:805,t:1526328853968};\\\", \\\"{x:1466,y:802,t:1526328853984};\\\", \\\"{x:1466,y:800,t:1526328854001};\\\", \\\"{x:1466,y:799,t:1526328854025};\\\", \\\"{x:1466,y:797,t:1526328854066};\\\", \\\"{x:1466,y:796,t:1526328854073};\\\", \\\"{x:1466,y:795,t:1526328854084};\\\", \\\"{x:1466,y:794,t:1526328854105};\\\", \\\"{x:1466,y:793,t:1526328854178};\\\", \\\"{x:1466,y:792,t:1526328854186};\\\", \\\"{x:1466,y:791,t:1526328854202};\\\", \\\"{x:1468,y:790,t:1526328854219};\\\", \\\"{x:1469,y:788,t:1526328854236};\\\", \\\"{x:1470,y:785,t:1526328854252};\\\", \\\"{x:1473,y:782,t:1526328854269};\\\", \\\"{x:1474,y:779,t:1526328854286};\\\", \\\"{x:1477,y:775,t:1526328854302};\\\", \\\"{x:1479,y:768,t:1526328854319};\\\", \\\"{x:1480,y:764,t:1526328854336};\\\", \\\"{x:1482,y:758,t:1526328854352};\\\", \\\"{x:1483,y:753,t:1526328854369};\\\", \\\"{x:1486,y:745,t:1526328854386};\\\", \\\"{x:1487,y:741,t:1526328854402};\\\", \\\"{x:1489,y:734,t:1526328854419};\\\", \\\"{x:1491,y:726,t:1526328854436};\\\", \\\"{x:1493,y:720,t:1526328854453};\\\", \\\"{x:1495,y:713,t:1526328854470};\\\", \\\"{x:1497,y:702,t:1526328854486};\\\", \\\"{x:1500,y:697,t:1526328854502};\\\", \\\"{x:1500,y:692,t:1526328854519};\\\", \\\"{x:1503,y:684,t:1526328854536};\\\", \\\"{x:1504,y:675,t:1526328854553};\\\", \\\"{x:1505,y:665,t:1526328854569};\\\", \\\"{x:1506,y:655,t:1526328854586};\\\", \\\"{x:1508,y:649,t:1526328854602};\\\", \\\"{x:1508,y:645,t:1526328854619};\\\", \\\"{x:1508,y:632,t:1526328854636};\\\", \\\"{x:1508,y:623,t:1526328854653};\\\", \\\"{x:1508,y:618,t:1526328854669};\\\", \\\"{x:1508,y:603,t:1526328854687};\\\", \\\"{x:1508,y:588,t:1526328854703};\\\", \\\"{x:1508,y:575,t:1526328854719};\\\", \\\"{x:1508,y:567,t:1526328854736};\\\", \\\"{x:1508,y:556,t:1526328854754};\\\", \\\"{x:1508,y:546,t:1526328854769};\\\", \\\"{x:1508,y:525,t:1526328854786};\\\", \\\"{x:1508,y:503,t:1526328854803};\\\", \\\"{x:1508,y:479,t:1526328854818};\\\", \\\"{x:1508,y:456,t:1526328854835};\\\", \\\"{x:1508,y:435,t:1526328854852};\\\", \\\"{x:1508,y:420,t:1526328854869};\\\", \\\"{x:1508,y:405,t:1526328854885};\\\", \\\"{x:1508,y:390,t:1526328854902};\\\", \\\"{x:1505,y:376,t:1526328854919};\\\", \\\"{x:1500,y:366,t:1526328854936};\\\", \\\"{x:1495,y:356,t:1526328854952};\\\", \\\"{x:1491,y:343,t:1526328854969};\\\", \\\"{x:1490,y:335,t:1526328854985};\\\", \\\"{x:1490,y:334,t:1526328855002};\\\", \\\"{x:1489,y:333,t:1526328855018};\\\", \\\"{x:1488,y:333,t:1526328855036};\\\", \\\"{x:1487,y:332,t:1526328855053};\\\", \\\"{x:1486,y:332,t:1526328855069};\\\", \\\"{x:1485,y:331,t:1526328855085};\\\", \\\"{x:1483,y:330,t:1526328855103};\\\", \\\"{x:1482,y:328,t:1526328855675};\\\", \\\"{x:1482,y:322,t:1526328855687};\\\", \\\"{x:1482,y:308,t:1526328855703};\\\", \\\"{x:1482,y:304,t:1526328855720};\\\", \\\"{x:1482,y:302,t:1526328855738};\\\", \\\"{x:1482,y:301,t:1526328855753};\\\", \\\"{x:1481,y:289,t:1526328855769};\\\", \\\"{x:1480,y:287,t:1526328855786};\\\", \\\"{x:1480,y:286,t:1526328855802};\\\", \\\"{x:1479,y:284,t:1526328855819};\\\", \\\"{x:1478,y:282,t:1526328855874};\\\", \\\"{x:1478,y:280,t:1526328855887};\\\", \\\"{x:1478,y:278,t:1526328855903};\\\", \\\"{x:1477,y:273,t:1526328855920};\\\", \\\"{x:1475,y:270,t:1526328855936};\\\", \\\"{x:1475,y:267,t:1526328855953};\\\", \\\"{x:1475,y:264,t:1526328855970};\\\", \\\"{x:1475,y:262,t:1526328855994};\\\", \\\"{x:1475,y:261,t:1526328856058};\\\", \\\"{x:1475,y:260,t:1526328856070};\\\", \\\"{x:1475,y:258,t:1526328856087};\\\", \\\"{x:1475,y:255,t:1526328856104};\\\", \\\"{x:1475,y:252,t:1526328856120};\\\", \\\"{x:1477,y:248,t:1526328856137};\\\", \\\"{x:1478,y:245,t:1526328856274};\\\", \\\"{x:1478,y:244,t:1526328856290};\\\", \\\"{x:1478,y:242,t:1526328856306};\\\", \\\"{x:1479,y:241,t:1526328856321};\\\", \\\"{x:1479,y:240,t:1526328856336};\\\", \\\"{x:1479,y:238,t:1526328856353};\\\", \\\"{x:1480,y:235,t:1526328856370};\\\", \\\"{x:1480,y:234,t:1526328856393};\\\", \\\"{x:1481,y:233,t:1526328856409};\\\", \\\"{x:1481,y:232,t:1526328856420};\\\", \\\"{x:1482,y:238,t:1526328857593};\\\", \\\"{x:1482,y:248,t:1526328857605};\\\", \\\"{x:1482,y:275,t:1526328857620};\\\", \\\"{x:1482,y:320,t:1526328857637};\\\", \\\"{x:1459,y:387,t:1526328857654};\\\", \\\"{x:1400,y:478,t:1526328857671};\\\", \\\"{x:1307,y:578,t:1526328857688};\\\", \\\"{x:1199,y:680,t:1526328857705};\\\", \\\"{x:1074,y:796,t:1526328857721};\\\", \\\"{x:1002,y:852,t:1526328857737};\\\", \\\"{x:997,y:862,t:1526328857755};\\\", \\\"{x:973,y:881,t:1526328857771};\\\", \\\"{x:972,y:883,t:1526328857788};\\\", \\\"{x:968,y:885,t:1526328857804};\\\", \\\"{x:960,y:891,t:1526328857820};\\\", \\\"{x:949,y:893,t:1526328857838};\\\", \\\"{x:921,y:893,t:1526328857855};\\\", \\\"{x:870,y:887,t:1526328857871};\\\", \\\"{x:798,y:863,t:1526328857888};\\\", \\\"{x:700,y:829,t:1526328857905};\\\", \\\"{x:532,y:752,t:1526328857922};\\\", \\\"{x:405,y:696,t:1526328857938};\\\", \\\"{x:261,y:627,t:1526328857955};\\\", \\\"{x:103,y:546,t:1526328857972};\\\", \\\"{x:0,y:473,t:1526328857989};\\\", \\\"{x:0,y:416,t:1526328858004};\\\", \\\"{x:0,y:388,t:1526328858021};\\\", \\\"{x:0,y:379,t:1526328858037};\\\", \\\"{x:0,y:374,t:1526328858054};\\\", \\\"{x:0,y:372,t:1526328858071};\\\", \\\"{x:0,y:369,t:1526328858087};\\\", \\\"{x:0,y:365,t:1526328858104};\\\", \\\"{x:0,y:360,t:1526328858121};\\\", \\\"{x:0,y:357,t:1526328858137};\\\", \\\"{x:0,y:356,t:1526328858155};\\\", \\\"{x:0,y:352,t:1526328858172};\\\", \\\"{x:0,y:344,t:1526328858188};\\\", \\\"{x:8,y:326,t:1526328858204};\\\", \\\"{x:19,y:310,t:1526328858221};\\\", \\\"{x:33,y:297,t:1526328858237};\\\", \\\"{x:51,y:285,t:1526328858254};\\\", \\\"{x:74,y:271,t:1526328858270};\\\", \\\"{x:98,y:262,t:1526328858288};\\\", \\\"{x:116,y:258,t:1526328858305};\\\", \\\"{x:125,y:257,t:1526328858321};\\\", \\\"{x:131,y:254,t:1526328858337};\\\", \\\"{x:133,y:253,t:1526328858354};\\\", \\\"{x:144,y:249,t:1526328858370};\\\", \\\"{x:161,y:248,t:1526328858388};\\\", \\\"{x:187,y:248,t:1526328858404};\\\", \\\"{x:228,y:260,t:1526328858421};\\\", \\\"{x:262,y:277,t:1526328858438};\\\", \\\"{x:311,y:306,t:1526328858454};\\\", \\\"{x:347,y:339,t:1526328858471};\\\", \\\"{x:375,y:374,t:1526328858487};\\\", \\\"{x:402,y:425,t:1526328858503};\\\", \\\"{x:439,y:483,t:1526328858521};\\\", \\\"{x:487,y:549,t:1526328858537};\\\", \\\"{x:513,y:573,t:1526328858554};\\\", \\\"{x:524,y:583,t:1526328858572};\\\", \\\"{x:532,y:588,t:1526328858588};\\\", \\\"{x:539,y:591,t:1526328858605};\\\", \\\"{x:540,y:591,t:1526328858622};\\\", \\\"{x:541,y:591,t:1526328858638};\\\", \\\"{x:535,y:591,t:1526328858697};\\\", \\\"{x:524,y:592,t:1526328858705};\\\", \\\"{x:494,y:594,t:1526328858723};\\\", \\\"{x:466,y:596,t:1526328858739};\\\", \\\"{x:451,y:598,t:1526328858755};\\\", \\\"{x:447,y:599,t:1526328858773};\\\", \\\"{x:444,y:599,t:1526328858937};\\\", \\\"{x:439,y:599,t:1526328858945};\\\", \\\"{x:430,y:599,t:1526328858957};\\\", \\\"{x:408,y:599,t:1526328858974};\\\", \\\"{x:383,y:597,t:1526328858989};\\\", \\\"{x:361,y:591,t:1526328859005};\\\", \\\"{x:352,y:590,t:1526328859023};\\\", \\\"{x:353,y:590,t:1526328859409};\\\", \\\"{x:356,y:591,t:1526328859425};\\\", \\\"{x:360,y:591,t:1526328859439};\\\", \\\"{x:369,y:594,t:1526328859455};\\\", \\\"{x:378,y:594,t:1526328859472};\\\", \\\"{x:392,y:596,t:1526328859489};\\\", \\\"{x:400,y:598,t:1526328859506};\\\", \\\"{x:407,y:599,t:1526328859522};\\\", \\\"{x:408,y:599,t:1526328859539};\\\", \\\"{x:411,y:597,t:1526328860009};\\\", \\\"{x:417,y:595,t:1526328860023};\\\", \\\"{x:427,y:593,t:1526328860040};\\\", \\\"{x:446,y:587,t:1526328860056};\\\", \\\"{x:454,y:584,t:1526328860073};\\\", \\\"{x:459,y:581,t:1526328860089};\\\", \\\"{x:463,y:580,t:1526328860106};\\\", \\\"{x:465,y:579,t:1526328860123};\\\", \\\"{x:467,y:577,t:1526328860169};\\\", \\\"{x:468,y:577,t:1526328860177};\\\", \\\"{x:470,y:576,t:1526328860190};\\\", \\\"{x:482,y:572,t:1526328860207};\\\", \\\"{x:501,y:570,t:1526328860224};\\\", \\\"{x:518,y:570,t:1526328860239};\\\", \\\"{x:540,y:566,t:1526328860258};\\\", \\\"{x:554,y:566,t:1526328860273};\\\", \\\"{x:570,y:566,t:1526328860289};\\\", \\\"{x:588,y:566,t:1526328860307};\\\", \\\"{x:604,y:567,t:1526328860323};\\\", \\\"{x:615,y:568,t:1526328860340};\\\", \\\"{x:619,y:569,t:1526328860356};\\\", \\\"{x:619,y:571,t:1526328860481};\\\", \\\"{x:619,y:574,t:1526328860497};\\\", \\\"{x:619,y:575,t:1526328860507};\\\", \\\"{x:615,y:580,t:1526328860524};\\\", \\\"{x:614,y:583,t:1526328860540};\\\", \\\"{x:612,y:586,t:1526328860557};\\\", \\\"{x:612,y:587,t:1526328860574};\\\", \\\"{x:612,y:588,t:1526328860590};\\\", \\\"{x:612,y:589,t:1526328860608};\\\", \\\"{x:612,y:591,t:1526328860623};\\\", \\\"{x:612,y:592,t:1526328860641};\\\", \\\"{x:612,y:594,t:1526328860656};\\\", \\\"{x:612,y:612,t:1526328862546};\\\", \\\"{x:604,y:625,t:1526328862559};\\\", \\\"{x:587,y:650,t:1526328862575};\\\", \\\"{x:564,y:682,t:1526328862592};\\\", \\\"{x:541,y:703,t:1526328862609};\\\", \\\"{x:520,y:718,t:1526328862624};\\\", \\\"{x:494,y:729,t:1526328862642};\\\", \\\"{x:478,y:734,t:1526328862660};\\\", \\\"{x:469,y:736,t:1526328862675};\\\", \\\"{x:466,y:737,t:1526328862692};\\\", \\\"{x:465,y:738,t:1526328862961};\\\", \\\"{x:466,y:739,t:1526328862978};\\\", \\\"{x:467,y:741,t:1526328862992};\\\", \\\"{x:472,y:744,t:1526328863009};\\\", \\\"{x:476,y:746,t:1526328863025};\\\", \\\"{x:480,y:748,t:1526328863042};\\\", \\\"{x:481,y:749,t:1526328863059};\\\", \\\"{x:483,y:749,t:1526328864874};\\\", \\\"{x:484,y:749,t:1526328864914};\\\", \\\"{x:488,y:749,t:1526328864927};\\\", \\\"{x:503,y:748,t:1526328864944};\\\", \\\"{x:533,y:740,t:1526328864960};\\\", \\\"{x:600,y:723,t:1526328864977};\\\", \\\"{x:756,y:687,t:1526328864994};\\\", \\\"{x:851,y:671,t:1526328865010};\\\", \\\"{x:926,y:647,t:1526328865027};\\\", \\\"{x:996,y:628,t:1526328865043};\\\", \\\"{x:1057,y:609,t:1526328865061};\\\", \\\"{x:1099,y:591,t:1526328865076};\\\", \\\"{x:1122,y:579,t:1526328865094};\\\", \\\"{x:1142,y:566,t:1526328865110};\\\", \\\"{x:1158,y:558,t:1526328865127};\\\", \\\"{x:1164,y:553,t:1526328865143};\\\", \\\"{x:1168,y:549,t:1526328865161};\\\", \\\"{x:1170,y:547,t:1526328865176};\\\", \\\"{x:1172,y:544,t:1526328865194};\\\", \\\"{x:1172,y:543,t:1526328865211};\\\", \\\"{x:1173,y:540,t:1526328865226};\\\", \\\"{x:1175,y:539,t:1526328865244};\\\", \\\"{x:1179,y:536,t:1526328865260};\\\", \\\"{x:1180,y:535,t:1526328865277};\\\", \\\"{x:1181,y:535,t:1526328865293};\\\", \\\"{x:1181,y:534,t:1526328865311};\\\", \\\"{x:1183,y:533,t:1526328865329};\\\", \\\"{x:1183,y:532,t:1526328865344};\\\", \\\"{x:1190,y:526,t:1526328865362};\\\", \\\"{x:1192,y:521,t:1526328865377};\\\", \\\"{x:1194,y:520,t:1526328865394};\\\", \\\"{x:1196,y:519,t:1526328865411};\\\", \\\"{x:1197,y:518,t:1526328865427};\\\", \\\"{x:1197,y:517,t:1526328865444};\\\", \\\"{x:1199,y:516,t:1526328865461};\\\", \\\"{x:1200,y:514,t:1526328865478};\\\", \\\"{x:1201,y:514,t:1526328865496};\\\", \\\"{x:1203,y:513,t:1526328865515};\\\", \\\"{x:1203,y:512,t:1526328865544};\\\", \\\"{x:1205,y:511,t:1526328865561};\\\", \\\"{x:1206,y:510,t:1526328865577};\\\", \\\"{x:1206,y:509,t:1526328865595};\\\", \\\"{x:1208,y:508,t:1526328865641};\\\", \\\"{x:1209,y:507,t:1526328865745};\\\", \\\"{x:1207,y:507,t:1526328866033};\\\", \\\"{x:1177,y:521,t:1526328866045};\\\", \\\"{x:1083,y:549,t:1526328866062};\\\", \\\"{x:997,y:562,t:1526328866078};\\\", \\\"{x:922,y:571,t:1526328866095};\\\", \\\"{x:896,y:573,t:1526328866111};\\\", \\\"{x:886,y:573,t:1526328866127};\\\", \\\"{x:886,y:574,t:1526328866233};\\\", \\\"{x:886,y:572,t:1526328868601};\\\", \\\"{x:879,y:562,t:1526328868612};\\\", \\\"{x:820,y:532,t:1526328868630};\\\", \\\"{x:776,y:514,t:1526328868646};\\\", \\\"{x:767,y:509,t:1526328868663};\\\", \\\"{x:766,y:508,t:1526328868680};\\\", \\\"{x:766,y:510,t:1526328869089};\\\", \\\"{x:782,y:543,t:1526328869096};\\\", \\\"{x:847,y:655,t:1526328869114};\\\", \\\"{x:921,y:761,t:1526328869130};\\\", \\\"{x:951,y:790,t:1526328869147};\\\", \\\"{x:958,y:791,t:1526328869164};\\\", \\\"{x:959,y:791,t:1526328869180};\\\", \\\"{x:961,y:791,t:1526328869241};\\\", \\\"{x:966,y:787,t:1526328869249};\\\", \\\"{x:972,y:778,t:1526328869263};\\\", \\\"{x:980,y:749,t:1526328869280};\\\", \\\"{x:983,y:698,t:1526328869297};\\\", \\\"{x:977,y:684,t:1526328869313};\\\", \\\"{x:969,y:678,t:1526328869331};\\\", \\\"{x:957,y:670,t:1526328869347};\\\", \\\"{x:948,y:665,t:1526328869365};\\\", \\\"{x:946,y:664,t:1526328869380};\\\", \\\"{x:944,y:663,t:1526328869396};\\\", \\\"{x:942,y:661,t:1526328869414};\\\", \\\"{x:936,y:658,t:1526328869431};\\\", \\\"{x:934,y:656,t:1526328869447};\\\", \\\"{x:931,y:656,t:1526328869464};\\\", \\\"{x:928,y:656,t:1526328869481};\\\", \\\"{x:926,y:656,t:1526328869809};\\\", \\\"{x:928,y:656,t:1526328878097};\\\", \\\"{x:930,y:657,t:1526328878105};\\\", \\\"{x:932,y:658,t:1526328878120};\\\", \\\"{x:933,y:658,t:1526328878222};\\\", \\\"{x:936,y:660,t:1526328878229};\\\", \\\"{x:938,y:671,t:1526328878242};\\\", \\\"{x:945,y:693,t:1526328878260};\\\", \\\"{x:949,y:706,t:1526328878274};\\\", \\\"{x:949,y:710,t:1526328878291};\\\", \\\"{x:949,y:712,t:1526328878308};\\\", \\\"{x:948,y:712,t:1526328878324};\\\", \\\"{x:946,y:712,t:1526328878341};\\\", \\\"{x:945,y:712,t:1526328878476};\\\", \\\"{x:945,y:706,t:1526328878493};\\\", \\\"{x:945,y:702,t:1526328878509};\\\", \\\"{x:946,y:701,t:1526328878524};\\\", \\\"{x:946,y:696,t:1526328878541};\\\", \\\"{x:946,y:694,t:1526328878558};\\\", \\\"{x:948,y:691,t:1526328878574};\\\", \\\"{x:948,y:689,t:1526328878608};\\\", \\\"{x:948,y:686,t:1526328878625};\\\", \\\"{x:949,y:684,t:1526328878641};\\\", \\\"{x:951,y:683,t:1526328878658};\\\", \\\"{x:952,y:682,t:1526328878684};\\\", \\\"{x:955,y:681,t:1526328879053};\\\", \\\"{x:960,y:681,t:1526328879061};\\\", \\\"{x:968,y:681,t:1526328879075};\\\", \\\"{x:1009,y:681,t:1526328879093};\\\", \\\"{x:1022,y:681,t:1526328879109};\\\", \\\"{x:1075,y:693,t:1526328879125};\\\", \\\"{x:1100,y:699,t:1526328879142};\\\", \\\"{x:1115,y:704,t:1526328879159};\\\", \\\"{x:1126,y:707,t:1526328879175};\\\", \\\"{x:1131,y:710,t:1526328879193};\\\", \\\"{x:1137,y:711,t:1526328879208};\\\", \\\"{x:1141,y:711,t:1526328879225};\\\", \\\"{x:1143,y:711,t:1526328879242};\\\", \\\"{x:1144,y:711,t:1526328879261};\\\", \\\"{x:1145,y:711,t:1526328879308};\\\", \\\"{x:1134,y:709,t:1526328880516};\\\", \\\"{x:1090,y:688,t:1526328880526};\\\", \\\"{x:991,y:643,t:1526328880543};\\\", \\\"{x:851,y:588,t:1526328880560};\\\", \\\"{x:690,y:537,t:1526328880576};\\\", \\\"{x:570,y:491,t:1526328880593};\\\", \\\"{x:528,y:471,t:1526328880610};\\\", \\\"{x:525,y:455,t:1526328880626};\\\", \\\"{x:546,y:437,t:1526328880643};\\\", \\\"{x:566,y:419,t:1526328880660};\\\", \\\"{x:592,y:396,t:1526328880676};\\\", \\\"{x:597,y:387,t:1526328880693};\\\", \\\"{x:598,y:374,t:1526328880710};\\\", \\\"{x:598,y:368,t:1526328880726};\\\", \\\"{x:600,y:356,t:1526328880744};\\\", \\\"{x:607,y:345,t:1526328880760};\\\", \\\"{x:613,y:338,t:1526328880776};\\\", \\\"{x:620,y:331,t:1526328880794};\\\", \\\"{x:627,y:320,t:1526328880811};\\\", \\\"{x:630,y:305,t:1526328880826};\\\", \\\"{x:632,y:283,t:1526328880844};\\\", \\\"{x:639,y:259,t:1526328880860};\\\", \\\"{x:642,y:255,t:1526328880877};\\\", \\\"{x:644,y:253,t:1526328880894};\\\", \\\"{x:649,y:250,t:1526328880911};\\\", \\\"{x:666,y:249,t:1526328880926};\\\", \\\"{x:718,y:249,t:1526328880943};\\\", \\\"{x:836,y:258,t:1526328880960};\\\", \\\"{x:956,y:281,t:1526328880978};\\\", \\\"{x:1046,y:289,t:1526328880993};\\\", \\\"{x:1075,y:289,t:1526328881009};\\\", \\\"{x:1084,y:289,t:1526328881026};\\\", \\\"{x:1085,y:289,t:1526328881052};\\\", \\\"{x:1080,y:283,t:1526328881060};\\\", \\\"{x:1053,y:270,t:1526328881077};\\\", \\\"{x:1037,y:263,t:1526328881093};\\\", \\\"{x:1033,y:263,t:1526328881110};\\\", \\\"{x:1030,y:263,t:1526328881128};\\\", \\\"{x:1026,y:263,t:1526328881143};\\\", \\\"{x:1021,y:262,t:1526328881160};\\\", \\\"{x:1011,y:261,t:1526328881177};\\\", \\\"{x:1001,y:259,t:1526328881193};\\\", \\\"{x:987,y:254,t:1526328881210};\\\", \\\"{x:973,y:248,t:1526328881227};\\\", \\\"{x:960,y:244,t:1526328881243};\\\", \\\"{x:958,y:244,t:1526328881260};\\\", \\\"{x:956,y:242,t:1526328881277};\\\", \\\"{x:952,y:241,t:1526328881293};\\\", \\\"{x:947,y:241,t:1526328881310};\\\", \\\"{x:943,y:241,t:1526328881327};\\\", \\\"{x:935,y:241,t:1526328881345};\\\", \\\"{x:906,y:241,t:1526328881360};\\\", \\\"{x:887,y:240,t:1526328881377};\\\", \\\"{x:862,y:240,t:1526328881395};\\\", \\\"{x:850,y:240,t:1526328881410};\\\", \\\"{x:844,y:240,t:1526328881427};\\\", \\\"{x:845,y:242,t:1526328881460};\\\", \\\"{x:848,y:245,t:1526328881477};\\\", \\\"{x:853,y:249,t:1526328881492};\\\", \\\"{x:856,y:249,t:1526328881509};\\\", \\\"{x:857,y:249,t:1526328881527};\\\", \\\"{x:858,y:250,t:1526328881556};\\\", \\\"{x:856,y:250,t:1526328881813};\\\", \\\"{x:852,y:249,t:1526328881827};\\\", \\\"{x:837,y:246,t:1526328881845};\\\", \\\"{x:832,y:244,t:1526328881861};\\\", \\\"{x:830,y:243,t:1526328881877};\\\", \\\"{x:830,y:248,t:1526328882357};\\\", \\\"{x:832,y:256,t:1526328882364};\\\", \\\"{x:835,y:260,t:1526328882378};\\\", \\\"{x:840,y:275,t:1526328882394};\\\", \\\"{x:842,y:289,t:1526328882411};\\\", \\\"{x:844,y:304,t:1526328882428};\\\", \\\"{x:844,y:307,t:1526328882444};\\\", \\\"{x:844,y:310,t:1526328882461};\\\", \\\"{x:844,y:313,t:1526328882478};\\\", \\\"{x:844,y:318,t:1526328882494};\\\", \\\"{x:844,y:334,t:1526328882511};\\\", \\\"{x:848,y:366,t:1526328882528};\\\", \\\"{x:860,y:413,t:1526328882544};\\\", \\\"{x:878,y:464,t:1526328882561};\\\", \\\"{x:896,y:504,t:1526328882579};\\\", \\\"{x:902,y:520,t:1526328882594};\\\", \\\"{x:903,y:524,t:1526328882611};\\\", \\\"{x:903,y:539,t:1526328882628};\\\", \\\"{x:902,y:551,t:1526328882645};\\\", \\\"{x:899,y:556,t:1526328882661};\\\", \\\"{x:898,y:556,t:1526328882732};\\\", \\\"{x:895,y:549,t:1526328882744};\\\", \\\"{x:885,y:528,t:1526328882761};\\\", \\\"{x:871,y:503,t:1526328882778};\\\", \\\"{x:858,y:476,t:1526328882795};\\\", \\\"{x:856,y:466,t:1526328882811};\\\", \\\"{x:852,y:455,t:1526328882828};\\\", \\\"{x:850,y:449,t:1526328882846};\\\", \\\"{x:848,y:443,t:1526328882861};\\\", \\\"{x:846,y:437,t:1526328882878};\\\", \\\"{x:846,y:431,t:1526328882896};\\\", \\\"{x:845,y:426,t:1526328882911};\\\", \\\"{x:844,y:421,t:1526328882928};\\\", \\\"{x:843,y:419,t:1526328882945};\\\", \\\"{x:847,y:425,t:1526328883420};\\\", \\\"{x:851,y:430,t:1526328883428};\\\", \\\"{x:862,y:438,t:1526328883445};\\\", \\\"{x:877,y:450,t:1526328883462};\\\", \\\"{x:885,y:456,t:1526328883478};\\\", \\\"{x:888,y:458,t:1526328883495};\\\", \\\"{x:886,y:458,t:1526328883772};\\\", \\\"{x:883,y:458,t:1526328883780};\\\", \\\"{x:880,y:458,t:1526328883797};\\\", \\\"{x:878,y:456,t:1526328883813};\\\", \\\"{x:875,y:453,t:1526328883829};\\\", \\\"{x:875,y:449,t:1526328883846};\\\", \\\"{x:875,y:444,t:1526328883863};\\\", \\\"{x:873,y:439,t:1526328883879};\\\", \\\"{x:873,y:437,t:1526328883895};\\\", \\\"{x:872,y:434,t:1526328883912};\\\", \\\"{x:872,y:433,t:1526328883929};\\\", \\\"{x:872,y:432,t:1526328883957};\\\", \\\"{x:871,y:430,t:1526328883980};\\\", \\\"{x:871,y:427,t:1526328885252};\\\", \\\"{x:868,y:422,t:1526328885264};\\\", \\\"{x:868,y:418,t:1526328885280};\\\", \\\"{x:866,y:413,t:1526328885296};\\\", \\\"{x:865,y:410,t:1526328885313};\\\", \\\"{x:863,y:407,t:1526328885330};\\\", \\\"{x:861,y:403,t:1526328885347};\\\", \\\"{x:861,y:400,t:1526328885364};\\\", \\\"{x:858,y:395,t:1526328885381};\\\", \\\"{x:858,y:390,t:1526328885397};\\\", \\\"{x:857,y:386,t:1526328885414};\\\", \\\"{x:854,y:376,t:1526328885431};\\\", \\\"{x:853,y:370,t:1526328885448};\\\", \\\"{x:853,y:365,t:1526328885463};\\\", \\\"{x:851,y:357,t:1526328885480};\\\", \\\"{x:849,y:353,t:1526328885497};\\\", \\\"{x:849,y:352,t:1526328885514};\\\", \\\"{x:848,y:351,t:1526328885531};\\\", \\\"{x:849,y:351,t:1526328885845};\\\", \\\"{x:850,y:351,t:1526328885853};\\\", \\\"{x:851,y:351,t:1526328885868};\\\", \\\"{x:853,y:353,t:1526328885880};\\\", \\\"{x:860,y:357,t:1526328885898};\\\", \\\"{x:865,y:358,t:1526328885914};\\\", \\\"{x:869,y:359,t:1526328885930};\\\", \\\"{x:875,y:361,t:1526328885948};\\\", \\\"{x:885,y:362,t:1526328885964};\\\", \\\"{x:892,y:363,t:1526328885981};\\\", \\\"{x:902,y:366,t:1526328885997};\\\", \\\"{x:912,y:367,t:1526328886014};\\\", \\\"{x:925,y:368,t:1526328886030};\\\", \\\"{x:935,y:370,t:1526328886047};\\\", \\\"{x:945,y:372,t:1526328886064};\\\", \\\"{x:953,y:372,t:1526328886080};\\\", \\\"{x:960,y:374,t:1526328886097};\\\", \\\"{x:970,y:374,t:1526328886114};\\\", \\\"{x:979,y:376,t:1526328886131};\\\", \\\"{x:985,y:376,t:1526328886147};\\\", \\\"{x:991,y:376,t:1526328886164};\\\", \\\"{x:994,y:377,t:1526328886182};\\\", \\\"{x:995,y:377,t:1526328886197};\\\", \\\"{x:997,y:377,t:1526328886214};\\\", \\\"{x:999,y:378,t:1526328886230};\\\", \\\"{x:1000,y:378,t:1526328886247};\\\", \\\"{x:1002,y:378,t:1526328886264};\\\", \\\"{x:1003,y:379,t:1526328886300};\\\", \\\"{x:1003,y:382,t:1526328889653};\\\", \\\"{x:994,y:390,t:1526328889668};\\\", \\\"{x:980,y:401,t:1526328889684};\\\", \\\"{x:957,y:421,t:1526328889700};\\\", \\\"{x:948,y:431,t:1526328889717};\\\", \\\"{x:943,y:438,t:1526328889733};\\\", \\\"{x:940,y:444,t:1526328889751};\\\", \\\"{x:934,y:452,t:1526328889767};\\\", \\\"{x:929,y:461,t:1526328889783};\\\", \\\"{x:925,y:470,t:1526328889801};\\\", \\\"{x:916,y:486,t:1526328889818};\\\", \\\"{x:908,y:502,t:1526328889834};\\\", \\\"{x:897,y:521,t:1526328889850};\\\", \\\"{x:883,y:546,t:1526328889868};\\\", \\\"{x:874,y:559,t:1526328889883};\\\", \\\"{x:863,y:573,t:1526328889900};\\\", \\\"{x:856,y:582,t:1526328889918};\\\", \\\"{x:851,y:588,t:1526328889934};\\\", \\\"{x:843,y:597,t:1526328889950};\\\", \\\"{x:831,y:607,t:1526328889968};\\\", \\\"{x:824,y:613,t:1526328889984};\\\", \\\"{x:820,y:617,t:1526328890000};\\\", \\\"{x:818,y:617,t:1526328890092};\\\", \\\"{x:817,y:617,t:1526328890101};\\\", \\\"{x:815,y:614,t:1526328890118};\\\", \\\"{x:811,y:601,t:1526328890134};\\\", \\\"{x:806,y:584,t:1526328890151};\\\", \\\"{x:802,y:568,t:1526328890168};\\\", \\\"{x:800,y:556,t:1526328890184};\\\", \\\"{x:799,y:546,t:1526328890201};\\\", \\\"{x:798,y:539,t:1526328890217};\\\", \\\"{x:798,y:535,t:1526328890235};\\\", \\\"{x:798,y:531,t:1526328890251};\\\", \\\"{x:798,y:528,t:1526328890267};\\\", \\\"{x:798,y:527,t:1526328890284};\\\", \\\"{x:798,y:526,t:1526328890301};\\\", \\\"{x:799,y:524,t:1526328890318};\\\", \\\"{x:801,y:522,t:1526328890335};\\\", \\\"{x:805,y:515,t:1526328890352};\\\", \\\"{x:806,y:513,t:1526328890369};\\\", \\\"{x:808,y:512,t:1526328890385};\\\", \\\"{x:809,y:510,t:1526328890402};\\\", \\\"{x:810,y:510,t:1526328890418};\\\", \\\"{x:811,y:507,t:1526328890436};\\\", \\\"{x:812,y:507,t:1526328890451};\\\", \\\"{x:817,y:505,t:1526328890468};\\\", \\\"{x:822,y:504,t:1526328890485};\\\", \\\"{x:826,y:503,t:1526328890501};\\\", \\\"{x:828,y:502,t:1526328890517};\\\", \\\"{x:830,y:502,t:1526328890534};\\\", \\\"{x:832,y:502,t:1526328890551};\\\", \\\"{x:836,y:500,t:1526328890568};\\\", \\\"{x:837,y:500,t:1526328890583};\\\", \\\"{x:838,y:500,t:1526328890685};\\\", \\\"{x:839,y:499,t:1526328890709};\\\", \\\"{x:839,y:499,t:1526328891018};\\\", \\\"{x:839,y:501,t:1526328891741};\\\", \\\"{x:839,y:504,t:1526328891751};\\\", \\\"{x:840,y:510,t:1526328891768};\\\", \\\"{x:841,y:514,t:1526328891786};\\\", \\\"{x:841,y:519,t:1526328891802};\\\", \\\"{x:842,y:523,t:1526328891818};\\\", \\\"{x:843,y:529,t:1526328891835};\\\", \\\"{x:844,y:534,t:1526328891851};\\\", \\\"{x:847,y:542,t:1526328891868};\\\", \\\"{x:850,y:551,t:1526328891885};\\\", \\\"{x:852,y:555,t:1526328891902};\\\", \\\"{x:854,y:560,t:1526328891918};\\\", \\\"{x:856,y:563,t:1526328891935};\\\", \\\"{x:857,y:568,t:1526328891952};\\\", \\\"{x:859,y:573,t:1526328891969};\\\", \\\"{x:859,y:576,t:1526328891985};\\\", \\\"{x:859,y:581,t:1526328892003};\\\", \\\"{x:860,y:588,t:1526328892019};\\\", \\\"{x:861,y:592,t:1526328892035};\\\", \\\"{x:862,y:595,t:1526328892052};\\\", \\\"{x:862,y:600,t:1526328892069};\\\", \\\"{x:862,y:604,t:1526328892085};\\\", \\\"{x:862,y:607,t:1526328892103};\\\", \\\"{x:861,y:609,t:1526328892118};\\\", \\\"{x:860,y:611,t:1526328892136};\\\", \\\"{x:860,y:613,t:1526328892204};\\\", \\\"{x:860,y:614,t:1526328892228};\\\", \\\"{x:859,y:615,t:1526328892261};\\\", \\\"{x:859,y:616,t:1526328892293};\\\", \\\"{x:859,y:617,t:1526328892317};\\\", \\\"{x:858,y:617,t:1526328892341};\\\", \\\"{x:858,y:619,t:1526328893332};\\\", \\\"{x:858,y:623,t:1526328893341};\\\", \\\"{x:858,y:629,t:1526328893354};\\\", \\\"{x:853,y:641,t:1526328893371};\\\", \\\"{x:850,y:651,t:1526328893387};\\\", \\\"{x:845,y:665,t:1526328893404};\\\", \\\"{x:832,y:692,t:1526328893421};\\\", \\\"{x:826,y:705,t:1526328893438};\\\", \\\"{x:822,y:715,t:1526328893454};\\\", \\\"{x:819,y:721,t:1526328893470};\\\", \\\"{x:817,y:725,t:1526328893486};\\\", \\\"{x:819,y:723,t:1526328893940};\\\", \\\"{x:819,y:721,t:1526328893956};\\\", \\\"{x:820,y:720,t:1526328893969};\\\", \\\"{x:820,y:718,t:1526328893988};\\\", \\\"{x:820,y:717,t:1526328894011};\\\", \\\"{x:820,y:715,t:1526328894020};\\\", \\\"{x:820,y:712,t:1526328894036};\\\", \\\"{x:820,y:711,t:1526328894053};\\\", \\\"{x:820,y:710,t:1526328894132};\\\", \\\"{x:820,y:708,t:1526328894140};\\\", \\\"{x:820,y:707,t:1526328894156};\\\", \\\"{x:821,y:705,t:1526328894252};\\\", \\\"{x:822,y:704,t:1526328894271};\\\", \\\"{x:823,y:703,t:1526328894308};\\\", \\\"{x:825,y:702,t:1526328894356};\\\", \\\"{x:826,y:701,t:1526328894372};\\\", \\\"{x:827,y:700,t:1526328894388};\\\", \\\"{x:828,y:700,t:1526328894404};\\\", \\\"{x:829,y:700,t:1526328894420};\\\", \\\"{x:829,y:700,t:1526328894565};\\\", \\\"{x:830,y:710,t:1526328897485};\\\", \\\"{x:830,y:722,t:1526328897492};\\\", \\\"{x:830,y:739,t:1526328897507};\\\", \\\"{x:830,y:767,t:1526328897523};\\\", \\\"{x:830,y:793,t:1526328897540};\\\", \\\"{x:835,y:805,t:1526328897557};\\\", \\\"{x:839,y:814,t:1526328897573};\\\", \\\"{x:840,y:822,t:1526328897590};\\\", \\\"{x:840,y:826,t:1526328897607};\\\", \\\"{x:840,y:833,t:1526328897623};\\\", \\\"{x:840,y:836,t:1526328897639};\\\", \\\"{x:840,y:843,t:1526328897656};\\\", \\\"{x:840,y:849,t:1526328897673};\\\", \\\"{x:840,y:852,t:1526328897689};\\\", \\\"{x:840,y:856,t:1526328897707};\\\", \\\"{x:838,y:861,t:1526328897724};\\\", \\\"{x:836,y:867,t:1526328897740};\\\", \\\"{x:832,y:880,t:1526328897756};\\\", \\\"{x:822,y:898,t:1526328897773};\\\", \\\"{x:816,y:914,t:1526328897790};\\\", \\\"{x:805,y:935,t:1526328897807};\\\", \\\"{x:795,y:952,t:1526328897823};\\\", \\\"{x:793,y:958,t:1526328897841};\\\", \\\"{x:793,y:961,t:1526328897857};\\\", \\\"{x:793,y:962,t:1526328897874};\\\", \\\"{x:793,y:963,t:1526328897891};\\\", \\\"{x:794,y:964,t:1526328897907};\\\", \\\"{x:795,y:966,t:1526328897924};\\\", \\\"{x:795,y:970,t:1526328897940};\\\", \\\"{x:795,y:974,t:1526328897958};\\\", \\\"{x:797,y:972,t:1526328898126};\\\", \\\"{x:802,y:963,t:1526328898141};\\\", \\\"{x:808,y:954,t:1526328898158};\\\", \\\"{x:815,y:940,t:1526328898175};\\\", \\\"{x:824,y:929,t:1526328898191};\\\", \\\"{x:829,y:923,t:1526328898208};\\\", \\\"{x:833,y:918,t:1526328898240};\\\", \\\"{x:835,y:916,t:1526328898256};\\\", \\\"{x:836,y:915,t:1526328898274};\\\", \\\"{x:839,y:914,t:1526328898290};\\\", \\\"{x:842,y:913,t:1526328898307};\\\", \\\"{x:843,y:911,t:1526328898323};\\\", \\\"{x:844,y:911,t:1526328898404};\\\", \\\"{x:844,y:914,t:1526328898412};\\\", \\\"{x:841,y:920,t:1526328898423};\\\", \\\"{x:839,y:929,t:1526328898440};\\\", \\\"{x:839,y:935,t:1526328898456};\\\", \\\"{x:838,y:937,t:1526328898473};\\\", \\\"{x:838,y:938,t:1526328898491};\\\", \\\"{x:838,y:939,t:1526328898507};\\\", \\\"{x:838,y:942,t:1526328898524};\\\", \\\"{x:838,y:945,t:1526328898541};\\\", \\\"{x:838,y:948,t:1526328898557};\\\", \\\"{x:838,y:949,t:1526328898604};\\\", \\\"{x:838,y:951,t:1526328898837};\\\", \\\"{x:838,y:952,t:1526328898886};\\\", \\\"{x:838,y:954,t:1526328898909};\\\", \\\"{x:838,y:955,t:1526328898924};\\\", \\\"{x:837,y:956,t:1526328898942};\\\", \\\"{x:837,y:957,t:1526328898973};\\\", \\\"{x:836,y:959,t:1526328898989};\\\", \\\"{x:836,y:960,t:1526328898996};\\\", \\\"{x:836,y:961,t:1526328899061};\\\", \\\"{x:836,y:961,t:1526328899168};\\\", \\\"{x:837,y:968,t:1526328899389};\\\", \\\"{x:843,y:980,t:1526328899397};\\\", \\\"{x:850,y:992,t:1526328899408};\\\", \\\"{x:861,y:1011,t:1526328899426};\\\", \\\"{x:875,y:1034,t:1526328899441};\\\", \\\"{x:885,y:1050,t:1526328899458};\\\", \\\"{x:887,y:1054,t:1526328899475};\\\", \\\"{x:888,y:1056,t:1526328899491};\\\", \\\"{x:888,y:1055,t:1526328899597};\\\", \\\"{x:888,y:1054,t:1526328899607};\\\", \\\"{x:888,y:1051,t:1526328899625};\\\", \\\"{x:888,y:1047,t:1526328899641};\\\", \\\"{x:888,y:1042,t:1526328899657};\\\", \\\"{x:889,y:1037,t:1526328899675};\\\", \\\"{x:889,y:1035,t:1526328899691};\\\", \\\"{x:889,y:1032,t:1526328899707};\\\", \\\"{x:889,y:1030,t:1526328899725};\\\", \\\"{x:889,y:1029,t:1526328899742};\\\", \\\"{x:889,y:1027,t:1526328899758};\\\", \\\"{x:890,y:1026,t:1526328899775};\\\", \\\"{x:890,y:1023,t:1526328900588};\\\", \\\"{x:897,y:1018,t:1526328900596};\\\", \\\"{x:907,y:1011,t:1526328900608};\\\", \\\"{x:932,y:995,t:1526328900626};\\\", \\\"{x:960,y:972,t:1526328900641};\\\", \\\"{x:980,y:937,t:1526328900659};\\\", \\\"{x:997,y:885,t:1526328900676};\\\", \\\"{x:1000,y:839,t:1526328900692};\\\", \\\"{x:1000,y:772,t:1526328900709};\\\", \\\"{x:986,y:688,t:1526328900725};\\\", \\\"{x:974,y:623,t:1526328900742};\\\", \\\"{x:969,y:588,t:1526328900758};\\\", \\\"{x:969,y:568,t:1526328900776};\\\", \\\"{x:973,y:549,t:1526328900792};\\\", \\\"{x:983,y:531,t:1526328900809};\\\", \\\"{x:994,y:510,t:1526328900826};\\\", \\\"{x:1006,y:490,t:1526328900842};\\\", \\\"{x:1017,y:469,t:1526328900859};\\\", \\\"{x:1028,y:443,t:1526328900876};\\\", \\\"{x:1032,y:436,t:1526328900892};\\\", \\\"{x:1034,y:428,t:1526328900908};\\\", \\\"{x:1035,y:424,t:1526328900926};\\\", \\\"{x:1035,y:420,t:1526328900943};\\\", \\\"{x:1036,y:417,t:1526328900959};\\\", \\\"{x:1036,y:416,t:1526328900976};\\\", \\\"{x:1037,y:414,t:1526328900993};\\\", \\\"{x:1037,y:413,t:1526328901019};\\\", \\\"{x:1038,y:412,t:1526328901027};\\\", \\\"{x:1038,y:411,t:1526328901060};\\\", \\\"{x:1039,y:411,t:1526328901076};\\\", \\\"{x:1040,y:409,t:1526328901157};\\\", \\\"{x:1040,y:408,t:1526328901305};\\\", \\\"{x:1041,y:406,t:1526328901493};\\\", \\\"{x:1041,y:404,t:1526328901972};\\\", \\\"{x:1041,y:401,t:1526328901980};\\\", \\\"{x:1040,y:399,t:1526328901993};\\\", \\\"{x:1035,y:391,t:1526328902010};\\\", \\\"{x:1032,y:385,t:1526328902027};\\\", \\\"{x:1031,y:385,t:1526328902043};\\\", \\\"{x:1030,y:383,t:1526328902420};\\\", \\\"{x:1027,y:382,t:1526328902428};\\\", \\\"{x:998,y:376,t:1526328902443};\\\", \\\"{x:913,y:366,t:1526328902460};\\\", \\\"{x:754,y:360,t:1526328902477};\\\", \\\"{x:558,y:330,t:1526328902494};\\\", \\\"{x:310,y:302,t:1526328902511};\\\", \\\"{x:48,y:261,t:1526328902527};\\\", \\\"{x:0,y:239,t:1526328902544};\\\", \\\"{x:0,y:229,t:1526328902561};\\\", \\\"{x:0,y:228,t:1526328902577};\\\", \\\"{x:1,y:228,t:1526328902709};\\\", \\\"{x:4,y:228,t:1526328902717};\\\", \\\"{x:9,y:229,t:1526328902728};\\\", \\\"{x:29,y:235,t:1526328902745};\\\", \\\"{x:51,y:240,t:1526328902762};\\\", \\\"{x:75,y:246,t:1526328902778};\\\", \\\"{x:94,y:249,t:1526328902794};\\\", \\\"{x:101,y:250,t:1526328902811};\\\", \\\"{x:102,y:250,t:1526328902940};\\\", \\\"{x:99,y:247,t:1526328903100};\\\", \\\"{x:98,y:245,t:1526328903111};\\\", \\\"{x:96,y:242,t:1526328903128};\\\", \\\"{x:95,y:241,t:1526328903144};\\\", \\\"{x:95,y:240,t:1526328903161};\\\", \\\"{x:95,y:239,t:1526328903177};\\\", \\\"{x:95,y:237,t:1526328903236};\\\", \\\"{x:95,y:235,t:1526328903244};\\\", \\\"{x:95,y:231,t:1526328903261};\\\", \\\"{x:95,y:225,t:1526328903277};\\\", \\\"{x:96,y:220,t:1526328903294};\\\", \\\"{x:97,y:216,t:1526328903311};\\\", \\\"{x:98,y:215,t:1526328903636};\\\", \\\"{x:99,y:215,t:1526328903726};\\\", \\\"{x:101,y:215,t:1526328904092};\\\", \\\"{x:101,y:216,t:1526328904099};\\\", \\\"{x:102,y:217,t:1526328904112};\\\", \\\"{x:102,y:219,t:1526328904132};\\\", \\\"{x:103,y:220,t:1526328904155};\\\", \\\"{x:103,y:221,t:1526328904180};\\\", \\\"{x:103,y:222,t:1526328904195};\\\", \\\"{x:104,y:223,t:1526328904212};\\\", \\\"{x:105,y:226,t:1526328904228};\\\", \\\"{x:106,y:227,t:1526328904245};\\\", \\\"{x:106,y:228,t:1526328904262};\\\", \\\"{x:106,y:229,t:1526328904278};\\\", \\\"{x:107,y:229,t:1526328904348};\\\", \\\"{x:109,y:231,t:1526328904363};\\\", \\\"{x:110,y:232,t:1526328904379};\\\", \\\"{x:112,y:233,t:1526328904395};\\\", \\\"{x:113,y:235,t:1526328904412};\\\", \\\"{x:115,y:238,t:1526328904429};\\\", \\\"{x:116,y:239,t:1526328904446};\\\", \\\"{x:119,y:241,t:1526328904462};\\\", \\\"{x:122,y:243,t:1526328904479};\\\", \\\"{x:126,y:243,t:1526328904495};\\\", \\\"{x:128,y:243,t:1526328904513};\\\", \\\"{x:129,y:243,t:1526328904530};\\\", \\\"{x:129,y:244,t:1526328904556};\\\", \\\"{x:129,y:245,t:1526328904564};\\\", \\\"{x:129,y:246,t:1526328904580};\\\", \\\"{x:130,y:248,t:1526328904596};\\\", \\\"{x:136,y:256,t:1526328904613};\\\", \\\"{x:144,y:262,t:1526328904629};\\\", \\\"{x:151,y:268,t:1526328904645};\\\", \\\"{x:161,y:274,t:1526328904663};\\\", \\\"{x:163,y:276,t:1526328904680};\\\", \\\"{x:165,y:277,t:1526328904696};\\\", \\\"{x:165,y:278,t:1526328904756};\\\", \\\"{x:165,y:279,t:1526328904764};\\\", \\\"{x:163,y:280,t:1526328904779};\\\", \\\"{x:162,y:280,t:1526328904796};\\\", \\\"{x:163,y:280,t:1526328905284};\\\", \\\"{x:164,y:281,t:1526328905860};\\\", \\\"{x:164,y:282,t:1526328906181};\\\", \\\"{x:165,y:285,t:1526328906197};\\\", \\\"{x:165,y:288,t:1526328906214};\\\", \\\"{x:165,y:291,t:1526328906231};\\\", \\\"{x:166,y:293,t:1526328906247};\\\", \\\"{x:166,y:295,t:1526328906263};\\\", \\\"{x:167,y:296,t:1526328906326};\\\", \\\"{x:167,y:298,t:1526328907548};\\\", \\\"{x:167,y:299,t:1526328907564};\\\", \\\"{x:167,y:300,t:1526328907581};\\\", \\\"{x:167,y:301,t:1526328907598};\\\", \\\"{x:167,y:302,t:1526328907614};\\\", \\\"{x:167,y:303,t:1526328907724};\\\", \\\"{x:167,y:305,t:1526328907956};\\\", \\\"{x:167,y:307,t:1526328907965};\\\", \\\"{x:169,y:309,t:1526328907981};\\\", \\\"{x:169,y:311,t:1526328907998};\\\", \\\"{x:170,y:312,t:1526328908020};\\\", \\\"{x:170,y:313,t:1526328910500};\\\", \\\"{x:171,y:314,t:1526328910516};\\\", \\\"{x:171,y:315,t:1526328920092};\\\", \\\"{x:172,y:316,t:1526328920268};\\\", \\\"{x:172,y:317,t:1526328920276};\\\", \\\"{x:172,y:322,t:1526328920291};\\\", \\\"{x:179,y:335,t:1526328920308};\\\", \\\"{x:188,y:353,t:1526328920325};\\\", \\\"{x:203,y:384,t:1526328920342};\\\", \\\"{x:232,y:440,t:1526328920358};\\\", \\\"{x:263,y:497,t:1526328920374};\\\", \\\"{x:304,y:566,t:1526328920392};\\\", \\\"{x:356,y:631,t:1526328920408};\\\", \\\"{x:408,y:694,t:1526328920425};\\\", \\\"{x:457,y:742,t:1526328920441};\\\", \\\"{x:497,y:775,t:1526328920457};\\\", \\\"{x:521,y:801,t:1526328920474};\\\", \\\"{x:546,y:832,t:1526328920491};\\\", \\\"{x:567,y:858,t:1526328920507};\\\", \\\"{x:603,y:889,t:1526328920525};\\\", \\\"{x:642,y:913,t:1526328920541};\\\", \\\"{x:702,y:939,t:1526328920558};\\\", \\\"{x:764,y:969,t:1526328920574};\\\", \\\"{x:827,y:1034,t:1526328920592};\\\", \\\"{x:859,y:1129,t:1526328920609};\\\", \\\"{x:867,y:1199,t:1526328920624};\\\", \\\"{x:864,y:1199,t:1526328920642};\\\", \\\"{x:866,y:1199,t:1526328920660};\\\", \\\"{x:867,y:1199,t:1526328920675};\\\", \\\"{x:876,y:1199,t:1526328920692};\\\", \\\"{x:890,y:1199,t:1526328920708};\\\", \\\"{x:907,y:1199,t:1526328920724};\\\", \\\"{x:924,y:1199,t:1526328920742};\\\", \\\"{x:943,y:1199,t:1526328920758};\\\", \\\"{x:961,y:1199,t:1526328920775};\\\", \\\"{x:975,y:1199,t:1526328920792};\\\", \\\"{x:982,y:1199,t:1526328920808};\\\", \\\"{x:986,y:1199,t:1526328920825};\\\", \\\"{x:989,y:1199,t:1526328920842};\\\", \\\"{x:990,y:1199,t:1526328920858};\\\", \\\"{x:991,y:1199,t:1526328920892};\\\", \\\"{x:993,y:1195,t:1526328920908};\\\", \\\"{x:995,y:1191,t:1526328920925};\\\", \\\"{x:998,y:1182,t:1526328920943};\\\", \\\"{x:999,y:1168,t:1526328920957};\\\", \\\"{x:999,y:1152,t:1526328920974};\\\", \\\"{x:999,y:1137,t:1526328920992};\\\", \\\"{x:993,y:1106,t:1526328921009};\\\", \\\"{x:987,y:1074,t:1526328921024};\\\", \\\"{x:984,y:1045,t:1526328921042};\\\", \\\"{x:1000,y:1009,t:1526328921059};\\\", \\\"{x:1010,y:997,t:1526328921075};\\\", \\\"{x:1012,y:992,t:1526328921092};\\\", \\\"{x:1011,y:992,t:1526328921148};\\\", \\\"{x:1008,y:993,t:1526328921159};\\\", \\\"{x:998,y:1000,t:1526328921174};\\\", \\\"{x:991,y:1005,t:1526328921191};\\\", \\\"{x:989,y:1007,t:1526328921208};\\\", \\\"{x:988,y:1020,t:1526328921225};\\\", \\\"{x:985,y:1044,t:1526328921242};\\\", \\\"{x:982,y:1066,t:1526328921259};\\\", \\\"{x:982,y:1086,t:1526328921276};\\\", \\\"{x:983,y:1093,t:1526328921291};\\\", \\\"{x:987,y:1096,t:1526328921309};\\\", \\\"{x:992,y:1099,t:1526328921326};\\\", \\\"{x:998,y:1101,t:1526328921342};\\\", \\\"{x:1002,y:1102,t:1526328921359};\\\", \\\"{x:1003,y:1102,t:1526328921376};\\\", \\\"{x:999,y:1097,t:1526328921651};\\\", \\\"{x:994,y:1095,t:1526328921659};\\\", \\\"{x:985,y:1092,t:1526328921675};\\\", \\\"{x:984,y:1091,t:1526328921693};\\\", \\\"{x:983,y:1091,t:1526328921939};\\\", \\\"{x:982,y:1090,t:1526328923211};\\\", \\\"{x:982,y:1090,t:1526328923215};\\\", \\\"{x:982,y:1088,t:1526328923541};\\\", \\\"{x:982,y:1085,t:1526328923548};\\\", \\\"{x:983,y:1085,t:1526328923561};\\\", \\\"{x:986,y:1080,t:1526328923577};\\\", \\\"{x:988,y:1074,t:1526328923594};\\\", \\\"{x:990,y:1071,t:1526328923611};\\\", \\\"{x:992,y:1069,t:1526328923626};\\\", \\\"{x:993,y:1069,t:1526328923644};\\\", \\\"{x:993,y:1068,t:1526328923661};\\\", \\\"{x:993,y:1067,t:1526328923892};\\\", \\\"{x:993,y:1065,t:1526328923899};\\\", \\\"{x:994,y:1063,t:1526328923910};\\\", \\\"{x:994,y:1059,t:1526328923927};\\\", \\\"{x:996,y:1052,t:1526328923944};\\\", \\\"{x:996,y:1051,t:1526328923963};\\\", \\\"{x:997,y:1050,t:1526328923976};\\\", \\\"{x:997,y:1049,t:1526328923994};\\\", \\\"{x:997,y:1048,t:1526328924035};\\\" ] }, { \\\"rt\\\": 13372, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 720397, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 20307, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 741719, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 21920, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 764724, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"4FETN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2754}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"4FETN\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2274},{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2276},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2281,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2288,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2289,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2290,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2291,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2292,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2293,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2294,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2295,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2296,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2297,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2298,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2300,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2301,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2303,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2305,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2307,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2308,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2309,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2310,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2311,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2313,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2315,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2317,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2319,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2321,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2323,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2325,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2327,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2329,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2331,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2333,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2335,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2337,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2339,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2341,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2345,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2346,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2349,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2350,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2353,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2354,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2357,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2358,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2361,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2362,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2365,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2366,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2369,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2370,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2373,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2374,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2377,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2378,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2381,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2382,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2385,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2386,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2389,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2390,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2394,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2400,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2401,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2404,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2405,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2406,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2407,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2408,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2413,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2414,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2425,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2427,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2431,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2433,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2439,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2443,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2444,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2447,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2451,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2459,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2460,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2461,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2463,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2464,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2465,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2466,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2467,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2470,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2471,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2475,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2478,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2500,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2502,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2504,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2505,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2506,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2508,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2509,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2510,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2512,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2513,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2514,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2516,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2517,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2518,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2520,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2521,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2522,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2524,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2526,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2528,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2530,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2532,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2534,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2536,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2538,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2540,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2544,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2548,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2552,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2553,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2556,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2557,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2560,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2561,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2564,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2565,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2568,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2569,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2572,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2573,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2576,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2577,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2578,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2579},{\"nodeType\":3,\"id\":2580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2581,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2582,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2583,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2584,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 143, dom: 1844, initialDom: 1858",
  "javascriptErrors": []
}