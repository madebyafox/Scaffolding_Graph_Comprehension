var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cc2d866f76a2a8095fbf63ff4062d381",
  "created": "2018-06-01T10:15:13.5110358-07:00",
  "lastActivity": "2018-06-01T10:15:25.1350358-07:00",
  "pageViews": [
    {
      "id": "06011382586fd8b89af2950b1f676a453e18e0f4",
      "startTime": "2018-06-01T10:15:13.5110358-07:00",
      "endTime": "2018-06-01T10:15:25.1350358-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 11624,
      "engagementTime": 11099,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11624,
  "engagementTime": 11099,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QGUGU",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6bd9b0b98564c435976cfffe33d083b0",
  "gdpr": false
}