var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b4fe66a3c79d38228525887ca6e5e453",
  "created": "2018-05-21T12:09:53.9608105-07:00",
  "lastActivity": "2018-05-21T12:11:44.501857-07:00",
  "pageViews": [
    {
      "id": "0521533486cdb80d240efcd336cc25957596ce24",
      "startTime": "2018-05-21T12:09:53.9608105-07:00",
      "endTime": "2018-05-21T12:11:44.501857-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 110662,
      "engagementTime": 110413,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 110662,
  "engagementTime": 110413,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "df5d8371fc12b0eda6d1e873e96f3e56",
  "gdpr": false
}