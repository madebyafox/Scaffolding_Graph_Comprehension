var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a22711d9f2f7893efc50de4068e57a2e",
  "created": "2018-05-22T12:20:46.2918143-07:00",
  "lastActivity": "2018-05-22T12:21:35.4808725-07:00",
  "pageViews": [
    {
      "id": "0522469993ced7fde903d6ee232ed59a9385a939",
      "startTime": "2018-05-22T12:20:46.2918143-07:00",
      "endTime": "2018-05-22T12:21:35.4808725-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 49270,
      "engagementTime": 49270,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 49270,
  "engagementTime": 49270,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6Y93F",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "cd9fe6db5143cbd3704707a8903ea473",
  "gdpr": false
}