var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8c78a4213f883f369a4ae8649f7cdd7c",
  "created": "2018-05-21T12:19:40.854879-07:00",
  "lastActivity": "2018-05-21T12:20:30.238158-07:00",
  "pageViews": [
    {
      "id": "05214132b800fba265f53653dba4b28afab4c6a5",
      "startTime": "2018-05-21T12:19:41.2030715-07:00",
      "endTime": "2018-05-21T12:20:30.238158-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 49476,
      "engagementTime": 48411,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 49476,
  "engagementTime": 48411,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=Q8EDD",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fba9c36fbbe3ea7b2fc6535bf36be9c5",
  "gdpr": false
}