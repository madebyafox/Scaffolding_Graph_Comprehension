var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05225568600a865ddc043287c085a50341e505ae"] = {
  "startTime": "2018-05-22T23:13:55.544064Z",
  "websitePageUrl": "/16",
  "visitTime": 110206,
  "engagementTime": 100023,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c3b32b39fe8ab44677eaa00c144afdd1",
    "created": "2018-05-22T23:13:55.544064+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=BEGT5",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "cd4b22a06522c49a5739727de442e5c4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c3b32b39fe8ab44677eaa00c144afdd1/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 182,
      "e": 182,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 549,
      "y": 699
    },
    {
      "t": 1003,
      "e": 1003,
      "ty": 41,
      "x": 50798,
      "y": 38279,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1104,
      "e": 1104,
      "ty": 2,
      "x": 549,
      "y": 631
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 543,
      "y": 614
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 50124,
      "y": 61573,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 545,
      "y": 608
    },
    {
      "t": 1334,
      "e": 1334,
      "ty": 6,
      "x": 549,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 554,
      "y": 597
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 556,
      "y": 596
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 51585,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 557,
      "y": 596
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 51698,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 3,
      "x": 557,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2904,
      "e": 2904,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3012,
      "e": 3012,
      "ty": 4,
      "x": 51698,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3012,
      "e": 3012,
      "ty": 5,
      "x": 557,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8489,
      "e": 8012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8672,
      "e": 8195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 8674,
      "e": 8197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8752,
      "e": 8275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 8776,
      "e": 8299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 8888,
      "e": 8411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8888,
      "e": 8411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8952,
      "e": 8475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 8952,
      "e": 8475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8976,
      "e": 8499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I f"
    },
    {
      "t": 9096,
      "e": 8619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I f"
    },
    {
      "t": 9160,
      "e": 8683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 9160,
      "e": 8683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9160,
      "e": 8683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 9160,
      "e": 8683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9224,
      "e": 8747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I fuy"
    },
    {
      "t": 9224,
      "e": 8747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9512,
      "e": 9035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9600,
      "e": 9123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I fu"
    },
    {
      "t": 9696,
      "e": 9219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9744,
      "e": 9267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I f"
    },
    {
      "t": 9833,
      "e": 9356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9888,
      "e": 9411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 9944,
      "e": 9467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9984,
      "e": 9507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 10001,
      "e": 9524,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10560,
      "e": 10083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 10562,
      "e": 10085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10648,
      "e": 10171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If"
    },
    {
      "t": 10801,
      "e": 10324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10802,
      "e": 10325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10928,
      "e": 10451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If "
    },
    {
      "t": 11121,
      "e": 10644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 11121,
      "e": 10644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11160,
      "e": 10683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If y"
    },
    {
      "t": 11296,
      "e": 10819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11297,
      "e": 10820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11402,
      "e": 10925,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If yo"
    },
    {
      "t": 11416,
      "e": 10939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11416,
      "e": 10939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11456,
      "e": 10979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 11488,
      "e": 11011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11488,
      "e": 11011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11536,
      "e": 11059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11577,
      "e": 11100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11577,
      "e": 11100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11607,
      "e": 11130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 11656,
      "e": 11179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11656,
      "e": 11179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11736,
      "e": 11259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11736,
      "e": 11259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11817,
      "e": 11340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11818,
      "e": 11341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11944,
      "e": 11467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11944,
      "e": 11467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11951,
      "e": 11474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 12065,
      "e": 11588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12120,
      "e": 11643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12122,
      "e": 11645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12191,
      "e": 11714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12192,
      "e": 11715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12216,
      "e": 11739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 12224,
      "e": 11747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12577,
      "e": 12100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12577,
      "e": 12100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12704,
      "e": 12227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12744,
      "e": 12267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12744,
      "e": 12267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12841,
      "e": 12364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12937,
      "e": 12460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 12938,
      "e": 12461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13008,
      "e": 12531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13009,
      "e": 12532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13040,
      "e": 12563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||do"
    },
    {
      "t": 13112,
      "e": 12635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13160,
      "e": 12683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13160,
      "e": 12683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13257,
      "e": 12780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13265,
      "e": 12788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13266,
      "e": 12789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13376,
      "e": 12899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14601,
      "e": 14124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 14602,
      "e": 14125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14760,
      "e": 14283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 14921,
      "e": 14444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14921,
      "e": 14444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15112,
      "e": 14635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15225,
      "e": 14748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15225,
      "e": 14748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15376,
      "e": 14899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15376,
      "e": 14899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15392,
      "e": 14915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ri"
    },
    {
      "t": 15400,
      "e": 14923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15400,
      "e": 14923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15448,
      "e": 14971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15536,
      "e": 15059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15657,
      "e": 15180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15657,
      "e": 15180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15752,
      "e": 15275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15929,
      "e": 15452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15984,
      "e": 15507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot verit"
    },
    {
      "t": 16056,
      "e": 15579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16129,
      "e": 15652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot veri"
    },
    {
      "t": 16240,
      "e": 15763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16304,
      "e": 15827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot ver"
    },
    {
      "t": 16305,
      "e": 15828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16306,
      "e": 15829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16408,
      "e": 15931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16464,
      "e": 15987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16465,
      "e": 15988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16569,
      "e": 16092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16672,
      "e": 16195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16673,
      "e": 16196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16760,
      "e": 16283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17089,
      "e": 16612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17143,
      "e": 16666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot verta"
    },
    {
      "t": 17215,
      "e": 16738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17312,
      "e": 16835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vert"
    },
    {
      "t": 17449,
      "e": 16972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17450,
      "e": 16973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17511,
      "e": 17034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17600,
      "e": 17123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17601,
      "e": 17124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17673,
      "e": 17196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 17673,
      "e": 17196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17688,
      "e": 17211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xc"
    },
    {
      "t": 17704,
      "e": 17227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18009,
      "e": 17532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18072,
      "e": 17595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertix"
    },
    {
      "t": 18160,
      "e": 17683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18184,
      "e": 17707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 18185,
      "e": 17708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18224,
      "e": 17747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertic"
    },
    {
      "t": 18280,
      "e": 17803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18281,
      "e": 17804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18313,
      "e": 17836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18376,
      "e": 17899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18378,
      "e": 17901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18393,
      "e": 17902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18472,
      "e": 17981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18552,
      "e": 18061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18552,
      "e": 18061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18616,
      "e": 18125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18793,
      "e": 18302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 18793,
      "e": 18302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18920,
      "e": 18429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 18960,
      "e": 18469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18960,
      "e": 18469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19111,
      "e": 18620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19233,
      "e": 18742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19233,
      "e": 18742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19280,
      "e": 18789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19403,
      "e": 18912,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically o"
    },
    {
      "t": 19593,
      "e": 19102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19672,
      "e": 19181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19672,
      "e": 19181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19680,
      "e": 19189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically a"
    },
    {
      "t": 19784,
      "e": 19293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19889,
      "e": 19398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 19889,
      "e": 19398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19976,
      "e": 19485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 19984,
      "e": 19493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19984,
      "e": 19493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20048,
      "e": 19557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20112,
      "e": 19621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 20113,
      "e": 19622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20216,
      "e": 19725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20216,
      "e": 19725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20223,
      "e": 19732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 20296,
      "e": 19805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20297,
      "e": 19806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20328,
      "e": 19837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20425,
      "e": 19934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20449,
      "e": 19958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20450,
      "e": 19959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20528,
      "e": 20037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20560,
      "e": 20069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20560,
      "e": 20069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20624,
      "e": 20133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20632,
      "e": 20141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20632,
      "e": 20141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20728,
      "e": 20237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20753,
      "e": 20262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20753,
      "e": 20262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20832,
      "e": 20341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21257,
      "e": 20766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 21258,
      "e": 20767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21320,
      "e": 20829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 21320,
      "e": 20829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21408,
      "e": 20917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 21473,
      "e": 20982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21577,
      "e": 21086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21578,
      "e": 21087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21688,
      "e": 21197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21849,
      "e": 21358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21849,
      "e": 21358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21944,
      "e": 21453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21945,
      "e": 21454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22031,
      "e": 21540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 22080,
      "e": 21589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22609,
      "e": 22118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 22609,
      "e": 22118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22680,
      "e": 22189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22680,
      "e": 22189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22696,
      "e": 22205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 22803,
      "e": 22312,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, "
    },
    {
      "t": 22816,
      "e": 22325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22929,
      "e": 22438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22929,
      "e": 22438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22985,
      "e": 22494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22985,
      "e": 22494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22992,
      "e": 22501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 23065,
      "e": 22574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23120,
      "e": 22629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23122,
      "e": 22631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23175,
      "e": 22684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23192,
      "e": 22701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23192,
      "e": 22701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23249,
      "e": 22758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23249,
      "e": 22758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23272,
      "e": 22781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 23328,
      "e": 22837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23328,
      "e": 22837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23344,
      "e": 22853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23416,
      "e": 22925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23448,
      "e": 22957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23448,
      "e": 22957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23497,
      "e": 23006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23520,
      "e": 23029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23521,
      "e": 23030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23631,
      "e": 23140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23632,
      "e": 23141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23663,
      "e": 23172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 23704,
      "e": 23213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23705,
      "e": 23214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23744,
      "e": 23253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23792,
      "e": 23301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23794,
      "e": 23303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23816,
      "e": 23325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23864,
      "e": 23373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23864,
      "e": 23373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23888,
      "e": 23397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23968,
      "e": 23477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23968,
      "e": 23477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23975,
      "e": 23484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24073,
      "e": 23582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24321,
      "e": 23830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24322,
      "e": 23831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24391,
      "e": 23900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24393,
      "e": 23902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24399,
      "e": 23908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 24480,
      "e": 23989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24504,
      "e": 24013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24505,
      "e": 24014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24601,
      "e": 24110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24602,
      "e": 24111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24608,
      "e": 24117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 24704,
      "e": 24118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24832,
      "e": 24246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24833,
      "e": 24247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24937,
      "e": 24351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24938,
      "e": 24352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24969,
      "e": 24383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 25040,
      "e": 24454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25120,
      "e": 24534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25120,
      "e": 24534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25200,
      "e": 24614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25200,
      "e": 24614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25256,
      "e": 24670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 25328,
      "e": 24742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25450,
      "e": 24864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25451,
      "e": 24865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25552,
      "e": 24966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25552,
      "e": 24966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25552,
      "e": 24966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25664,
      "e": 25078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25689,
      "e": 25103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25689,
      "e": 25103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25784,
      "e": 25198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25785,
      "e": 25199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25807,
      "e": 25221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 25879,
      "e": 25293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25880,
      "e": 25294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25928,
      "e": 25342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25952,
      "e": 25366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25952,
      "e": 25366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26000,
      "e": 25414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26072,
      "e": 25486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27402,
      "e": 26816,
      "ty": 2,
      "x": 507,
      "y": 594
    },
    {
      "t": 27440,
      "e": 26854,
      "ty": 7,
      "x": 465,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27489,
      "e": 26903,
      "ty": 6,
      "x": 443,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 27501,
      "e": 26915,
      "ty": 2,
      "x": 443,
      "y": 660
    },
    {
      "t": 27501,
      "e": 26915,
      "ty": 41,
      "x": 57018,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 27601,
      "e": 27015,
      "ty": 2,
      "x": 453,
      "y": 659
    },
    {
      "t": 27657,
      "e": 27071,
      "ty": 7,
      "x": 454,
      "y": 645,
      "ta": "#strategyButton"
    },
    {
      "t": 27701,
      "e": 27115,
      "ty": 2,
      "x": 409,
      "y": 634
    },
    {
      "t": 27752,
      "e": 27166,
      "ty": 41,
      "x": 35766,
      "y": 11315,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 27802,
      "e": 27216,
      "ty": 2,
      "x": 390,
      "y": 644
    },
    {
      "t": 27902,
      "e": 27316,
      "ty": 2,
      "x": 388,
      "y": 650
    },
    {
      "t": 27907,
      "e": 27321,
      "ty": 6,
      "x": 386,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 28002,
      "e": 27416,
      "ty": 2,
      "x": 386,
      "y": 666
    },
    {
      "t": 28002,
      "e": 27416,
      "ty": 41,
      "x": 25889,
      "y": 21714,
      "ta": "#strategyButton"
    },
    {
      "t": 28102,
      "e": 27516,
      "ty": 2,
      "x": 390,
      "y": 669
    },
    {
      "t": 28252,
      "e": 27666,
      "ty": 41,
      "x": 28074,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 28701,
      "e": 28115,
      "ty": 2,
      "x": 391,
      "y": 669
    },
    {
      "t": 28752,
      "e": 28166,
      "ty": 41,
      "x": 28620,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 29251,
      "e": 28665,
      "ty": 41,
      "x": 32443,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 29301,
      "e": 28715,
      "ty": 2,
      "x": 429,
      "y": 665
    },
    {
      "t": 29308,
      "e": 28722,
      "ty": 7,
      "x": 458,
      "y": 653,
      "ta": "#strategyButton"
    },
    {
      "t": 29400,
      "e": 28814,
      "ty": 2,
      "x": 523,
      "y": 623
    },
    {
      "t": 29457,
      "e": 28871,
      "ty": 6,
      "x": 582,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29501,
      "e": 28915,
      "ty": 2,
      "x": 594,
      "y": 596
    },
    {
      "t": 29501,
      "e": 28915,
      "ty": 41,
      "x": 55857,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29601,
      "e": 29015,
      "ty": 2,
      "x": 602,
      "y": 591
    },
    {
      "t": 29701,
      "e": 29115,
      "ty": 2,
      "x": 611,
      "y": 581
    },
    {
      "t": 29751,
      "e": 29165,
      "ty": 41,
      "x": 58105,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29801,
      "e": 29215,
      "ty": 2,
      "x": 614,
      "y": 575
    },
    {
      "t": 29900,
      "e": 29314,
      "ty": 2,
      "x": 621,
      "y": 566
    },
    {
      "t": 30001,
      "e": 29415,
      "ty": 2,
      "x": 620,
      "y": 558
    },
    {
      "t": 30001,
      "e": 29415,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30003,
      "e": 29417,
      "ty": 41,
      "x": 58779,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30100,
      "e": 29514,
      "ty": 2,
      "x": 597,
      "y": 551
    },
    {
      "t": 30201,
      "e": 29615,
      "ty": 2,
      "x": 540,
      "y": 539
    },
    {
      "t": 30250,
      "e": 29664,
      "ty": 41,
      "x": 49449,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30301,
      "e": 29715,
      "ty": 2,
      "x": 536,
      "y": 531
    },
    {
      "t": 30401,
      "e": 29815,
      "ty": 2,
      "x": 532,
      "y": 531
    },
    {
      "t": 30501,
      "e": 29915,
      "ty": 41,
      "x": 48887,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30701,
      "e": 30115,
      "ty": 2,
      "x": 537,
      "y": 533
    },
    {
      "t": 30751,
      "e": 30165,
      "ty": 41,
      "x": 50011,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30801,
      "e": 30215,
      "ty": 2,
      "x": 547,
      "y": 534
    },
    {
      "t": 30901,
      "e": 30315,
      "ty": 2,
      "x": 551,
      "y": 535
    },
    {
      "t": 31001,
      "e": 30415,
      "ty": 2,
      "x": 556,
      "y": 536
    },
    {
      "t": 31002,
      "e": 30416,
      "ty": 41,
      "x": 51585,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31101,
      "e": 30515,
      "ty": 2,
      "x": 562,
      "y": 536
    },
    {
      "t": 31200,
      "e": 30614,
      "ty": 2,
      "x": 563,
      "y": 536
    },
    {
      "t": 31251,
      "e": 30665,
      "ty": 41,
      "x": 52709,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31301,
      "e": 30715,
      "ty": 2,
      "x": 566,
      "y": 536
    },
    {
      "t": 31365,
      "e": 30779,
      "ty": 3,
      "x": 567,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31401,
      "e": 30815,
      "ty": 2,
      "x": 567,
      "y": 536
    },
    {
      "t": 31484,
      "e": 30898,
      "ty": 4,
      "x": 52822,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31485,
      "e": 30899,
      "ty": 5,
      "x": 567,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31501,
      "e": 30915,
      "ty": 41,
      "x": 52822,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32101,
      "e": 31515,
      "ty": 2,
      "x": 648,
      "y": 538
    },
    {
      "t": 32201,
      "e": 31615,
      "ty": 2,
      "x": 671,
      "y": 542
    },
    {
      "t": 32251,
      "e": 31665,
      "ty": 41,
      "x": 64512,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32445,
      "e": 31859,
      "ty": 3,
      "x": 671,
      "y": 542,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32500,
      "e": 31914,
      "ty": 4,
      "x": 64512,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32500,
      "e": 31914,
      "ty": 5,
      "x": 671,
      "y": 542,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33608,
      "e": 33022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33672,
      "e": 33086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the start tim"
    },
    {
      "t": 33776,
      "e": 33190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33823,
      "e": 33237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the start ti"
    },
    {
      "t": 33903,
      "e": 33317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33952,
      "e": 33366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the start t"
    },
    {
      "t": 34000,
      "e": 33414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34056,
      "e": 33470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the start "
    },
    {
      "t": 34136,
      "e": 33550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34176,
      "e": 33590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the start"
    },
    {
      "t": 34224,
      "e": 33638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34280,
      "e": 33694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the star"
    },
    {
      "t": 34361,
      "e": 33775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34408,
      "e": 33822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the sta"
    },
    {
      "t": 34489,
      "e": 33903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34536,
      "e": 33950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the st"
    },
    {
      "t": 34599,
      "e": 34013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34640,
      "e": 34054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the s"
    },
    {
      "t": 34712,
      "e": 34126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34761,
      "e": 34175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the "
    },
    {
      "t": 35392,
      "e": 34175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35392,
      "e": 34175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35624,
      "e": 34407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36265,
      "e": 35048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36265,
      "e": 35048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36329,
      "e": 35112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36329,
      "e": 35112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36399,
      "e": 35182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 36432,
      "e": 35215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 36432,
      "e": 35215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36439,
      "e": 35222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 36503,
      "e": 35286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36600,
      "e": 35383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36601,
      "e": 35384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36664,
      "e": 35447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36672,
      "e": 35455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36672,
      "e": 35455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36775,
      "e": 35558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36792,
      "e": 35575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36793,
      "e": 35576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36871,
      "e": 35654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36880,
      "e": 35663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36880,
      "e": 35663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36960,
      "e": 35743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36967,
      "e": 35750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36969,
      "e": 35752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37080,
      "e": 35863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37081,
      "e": 35864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37128,
      "e": 35911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 37248,
      "e": 36031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37433,
      "e": 36216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37433,
      "e": 36216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37513,
      "e": 36296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37552,
      "e": 36335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37554,
      "e": 36337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37680,
      "e": 36463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37681,
      "e": 36464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37704,
      "e": 36487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 37760,
      "e": 36543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37865,
      "e": 36648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37865,
      "e": 36648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37913,
      "e": 36696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37913,
      "e": 36696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38000,
      "e": 36783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 38017,
      "e": 36800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38120,
      "e": 36903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38122,
      "e": 36905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38207,
      "e": 36990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38207,
      "e": 36990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38248,
      "e": 37031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 38320,
      "e": 37103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38320,
      "e": 37103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38328,
      "e": 37111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38377,
      "e": 37160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38377,
      "e": 37160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38417,
      "e": 37200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38543,
      "e": 37326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38543,
      "e": 37326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38592,
      "e": 37375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 38656,
      "e": 37439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39032,
      "e": 37815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39087,
      "e": 37870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the shift that starts o"
    },
    {
      "t": 39184,
      "e": 37967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39256,
      "e": 38039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the shift that starts "
    },
    {
      "t": 39273,
      "e": 38056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39273,
      "e": 38056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39392,
      "e": 38175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39392,
      "e": 38175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39392,
      "e": 38175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39504,
      "e": 38287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39505,
      "e": 38288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39520,
      "e": 38303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 39632,
      "e": 38415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39673,
      "e": 38456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 39673,
      "e": 38456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39784,
      "e": 38567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 39784,
      "e": 38567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39888,
      "e": 38671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 39944,
      "e": 38727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41176,
      "e": 39959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41177,
      "e": 39960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41320,
      "e": 40103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41521,
      "e": 40304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 41521,
      "e": 40304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41584,
      "e": 40367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 41584,
      "e": 40367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41632,
      "e": 40415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 41752,
      "e": 40535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41992,
      "e": 40775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 41993,
      "e": 40776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42104,
      "e": 40887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 43202,
      "e": 41985,
      "ty": 2,
      "x": 647,
      "y": 546
    },
    {
      "t": 43252,
      "e": 42035,
      "ty": 41,
      "x": 61028,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43302,
      "e": 42085,
      "ty": 2,
      "x": 598,
      "y": 576
    },
    {
      "t": 43352,
      "e": 42135,
      "ty": 7,
      "x": 578,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43401,
      "e": 42184,
      "ty": 2,
      "x": 540,
      "y": 630
    },
    {
      "t": 43502,
      "e": 42285,
      "ty": 2,
      "x": 471,
      "y": 658
    },
    {
      "t": 43502,
      "e": 42285,
      "ty": 41,
      "x": 42030,
      "y": 36008,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43519,
      "e": 42302,
      "ty": 6,
      "x": 458,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 43601,
      "e": 42384,
      "ty": 2,
      "x": 455,
      "y": 667
    },
    {
      "t": 43700,
      "e": 42483,
      "ty": 3,
      "x": 434,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 43701,
      "e": 42483,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If you see the dot vertically above the 12 pm, then that is the shift that starts at 12 pm\n"
    },
    {
      "t": 43702,
      "e": 42484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43702,
      "e": 42484,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43704,
      "e": 42486,
      "ty": 2,
      "x": 434,
      "y": 671
    },
    {
      "t": 43751,
      "e": 42533,
      "ty": 41,
      "x": 52103,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 43764,
      "e": 42546,
      "ty": 4,
      "x": 52103,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 43778,
      "e": 42560,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43781,
      "e": 42563,
      "ty": 5,
      "x": 434,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 43784,
      "e": 42566,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 44701,
      "e": 43483,
      "ty": 2,
      "x": 435,
      "y": 668
    },
    {
      "t": 44751,
      "e": 43533,
      "ty": 41,
      "x": 14808,
      "y": 36396,
      "ta": "html > body"
    },
    {
      "t": 44785,
      "e": 43567,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 44801,
      "e": 43583,
      "ty": 2,
      "x": 440,
      "y": 661
    },
    {
      "t": 44902,
      "e": 43684,
      "ty": 2,
      "x": 440,
      "y": 659
    },
    {
      "t": 45002,
      "e": 43784,
      "ty": 41,
      "x": 14877,
      "y": 36063,
      "ta": "html > body"
    },
    {
      "t": 45401,
      "e": 44183,
      "ty": 2,
      "x": 441,
      "y": 659
    },
    {
      "t": 45501,
      "e": 44283,
      "ty": 2,
      "x": 540,
      "y": 626
    },
    {
      "t": 45501,
      "e": 44283,
      "ty": 41,
      "x": 18320,
      "y": 34235,
      "ta": "html > body"
    },
    {
      "t": 45601,
      "e": 44383,
      "ty": 2,
      "x": 765,
      "y": 551
    },
    {
      "t": 45701,
      "e": 44483,
      "ty": 2,
      "x": 845,
      "y": 547
    },
    {
      "t": 45751,
      "e": 44533,
      "ty": 41,
      "x": 19033,
      "y": 36643,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 45802,
      "e": 44584,
      "ty": 2,
      "x": 899,
      "y": 542
    },
    {
      "t": 45888,
      "e": 44670,
      "ty": 6,
      "x": 907,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45902,
      "e": 44684,
      "ty": 2,
      "x": 907,
      "y": 555
    },
    {
      "t": 46001,
      "e": 44783,
      "ty": 2,
      "x": 908,
      "y": 556
    },
    {
      "t": 46002,
      "e": 44784,
      "ty": 41,
      "x": 21628,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46037,
      "e": 44819,
      "ty": 3,
      "x": 908,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46037,
      "e": 44819,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46124,
      "e": 44906,
      "ty": 4,
      "x": 21628,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46124,
      "e": 44906,
      "ty": 5,
      "x": 908,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46816,
      "e": 45598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 46817,
      "e": 45599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46879,
      "e": 45661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 46879,
      "e": 45661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46936,
      "e": 45718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 47008,
      "e": 45790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 47489,
      "e": 46271,
      "ty": 7,
      "x": 1006,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47502,
      "e": 46284,
      "ty": 2,
      "x": 1006,
      "y": 597
    },
    {
      "t": 47502,
      "e": 46284,
      "ty": 41,
      "x": 42824,
      "y": 9865,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 47602,
      "e": 46384,
      "ty": 2,
      "x": 1052,
      "y": 621
    },
    {
      "t": 47702,
      "e": 46484,
      "ty": 2,
      "x": 1060,
      "y": 625
    },
    {
      "t": 47752,
      "e": 46534,
      "ty": 41,
      "x": 54720,
      "y": 35233,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 47773,
      "e": 46555,
      "ty": 6,
      "x": 1064,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47802,
      "e": 46584,
      "ty": 2,
      "x": 1064,
      "y": 650
    },
    {
      "t": 47972,
      "e": 46754,
      "ty": 3,
      "x": 1064,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47973,
      "e": 46755,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 47973,
      "e": 46755,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47973,
      "e": 46755,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48002,
      "e": 46784,
      "ty": 41,
      "x": 55369,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48084,
      "e": 46866,
      "ty": 4,
      "x": 55369,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48085,
      "e": 46867,
      "ty": 5,
      "x": 1064,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48712,
      "e": 47494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49212,
      "e": 47994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49245,
      "e": 48027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49278,
      "e": 48060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49311,
      "e": 48093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49348,
      "e": 48130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49380,
      "e": 48162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49413,
      "e": 48195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49446,
      "e": 48228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49479,
      "e": 48261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49512,
      "e": 48294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49545,
      "e": 48327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49579,
      "e": 48361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49612,
      "e": 48394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49644,
      "e": 48426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49678,
      "e": 48460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49711,
      "e": 48493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49716,
      "e": 48498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "75"
    },
    {
      "t": 49717,
      "e": 48499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49804,
      "e": 48586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "K"
    },
    {
      "t": 49836,
      "e": 48618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "K"
    },
    {
      "t": 50005,
      "e": 48787,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50228,
      "e": 49010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 50284,
      "e": 49066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 50395,
      "e": 49177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 50596,
      "e": 49378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 50597,
      "e": 49379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50708,
      "e": 49490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 50715,
      "e": 49497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 50852,
      "e": 49634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 50852,
      "e": 49634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50915,
      "e": 49697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 50915,
      "e": 49697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50972,
      "e": 49754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 51019,
      "e": 49801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 51035,
      "e": 49817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 51035,
      "e": 49817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51148,
      "e": 49930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sout"
    },
    {
      "t": 51172,
      "e": 49954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 51172,
      "e": 49954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51268,
      "e": 50050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||h"
    },
    {
      "t": 51339,
      "e": 50121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 51508,
      "e": 50290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 51508,
      "e": 50290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51644,
      "e": 50426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 51780,
      "e": 50562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "75"
    },
    {
      "t": 51780,
      "e": 50562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51875,
      "e": 50657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||K"
    },
    {
      "t": 51891,
      "e": 50673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 52060,
      "e": 50842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 52062,
      "e": 50844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52131,
      "e": 50913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 52155,
      "e": 50937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 52155,
      "e": 50937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52267,
      "e": 51049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 52268,
      "e": 51050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52340,
      "e": 51122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||re"
    },
    {
      "t": 52356,
      "e": 51138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 52357,
      "e": 51139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52451,
      "e": 51233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 52507,
      "e": 51289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 53404,
      "e": 52186,
      "ty": 2,
      "x": 1065,
      "y": 652
    },
    {
      "t": 53505,
      "e": 52287,
      "ty": 2,
      "x": 1028,
      "y": 667
    },
    {
      "t": 53505,
      "e": 52287,
      "ty": 41,
      "x": 47583,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53515,
      "e": 52297,
      "ty": 7,
      "x": 1021,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53531,
      "e": 52313,
      "ty": 6,
      "x": 1008,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53604,
      "e": 52386,
      "ty": 2,
      "x": 965,
      "y": 692
    },
    {
      "t": 53754,
      "e": 52536,
      "ty": 41,
      "x": 35602,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53761,
      "e": 52543,
      "ty": 3,
      "x": 965,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53762,
      "e": 52544,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "South Korea"
    },
    {
      "t": 53763,
      "e": 52545,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53763,
      "e": 52545,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53847,
      "e": 52629,
      "ty": 4,
      "x": 35602,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53848,
      "e": 52630,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53851,
      "e": 52633,
      "ty": 5,
      "x": 965,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53851,
      "e": 52633,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 54863,
      "e": 53645,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 55405,
      "e": 54187,
      "ty": 2,
      "x": 999,
      "y": 480
    },
    {
      "t": 55505,
      "e": 54287,
      "ty": 2,
      "x": 970,
      "y": 299
    },
    {
      "t": 55505,
      "e": 54287,
      "ty": 41,
      "x": 46564,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 55605,
      "e": 54387,
      "ty": 2,
      "x": 943,
      "y": 283
    },
    {
      "t": 55705,
      "e": 54487,
      "ty": 2,
      "x": 876,
      "y": 270
    },
    {
      "t": 55755,
      "e": 54537,
      "ty": 41,
      "x": 39282,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 55804,
      "e": 54586,
      "ty": 2,
      "x": 866,
      "y": 264
    },
    {
      "t": 55904,
      "e": 54686,
      "ty": 2,
      "x": 849,
      "y": 253
    },
    {
      "t": 56004,
      "e": 54786,
      "ty": 2,
      "x": 845,
      "y": 250
    },
    {
      "t": 56005,
      "e": 54787,
      "ty": 41,
      "x": 5595,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 56105,
      "e": 54887,
      "ty": 2,
      "x": 843,
      "y": 240
    },
    {
      "t": 56167,
      "e": 54949,
      "ty": 6,
      "x": 839,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56204,
      "e": 54986,
      "ty": 2,
      "x": 837,
      "y": 232
    },
    {
      "t": 56255,
      "e": 55037,
      "ty": 41,
      "x": 48284,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56305,
      "e": 55087,
      "ty": 2,
      "x": 836,
      "y": 232
    },
    {
      "t": 56605,
      "e": 55387,
      "ty": 2,
      "x": 837,
      "y": 235
    },
    {
      "t": 56650,
      "e": 55432,
      "ty": 7,
      "x": 840,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56705,
      "e": 55487,
      "ty": 2,
      "x": 842,
      "y": 245
    },
    {
      "t": 56755,
      "e": 55537,
      "ty": 41,
      "x": 5121,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 56805,
      "e": 55587,
      "ty": 2,
      "x": 844,
      "y": 260
    },
    {
      "t": 56905,
      "e": 55687,
      "ty": 2,
      "x": 848,
      "y": 272
    },
    {
      "t": 57005,
      "e": 55787,
      "ty": 41,
      "x": 20242,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 57104,
      "e": 55886,
      "ty": 2,
      "x": 843,
      "y": 288
    },
    {
      "t": 57205,
      "e": 55987,
      "ty": 2,
      "x": 840,
      "y": 299
    },
    {
      "t": 57255,
      "e": 56037,
      "ty": 41,
      "x": 5822,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 57304,
      "e": 56086,
      "ty": 2,
      "x": 839,
      "y": 306
    },
    {
      "t": 57405,
      "e": 56187,
      "ty": 2,
      "x": 835,
      "y": 311
    },
    {
      "t": 57505,
      "e": 56287,
      "ty": 41,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 57569,
      "e": 56351,
      "ty": 3,
      "x": 835,
      "y": 311,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 57656,
      "e": 56438,
      "ty": 4,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 57656,
      "e": 56438,
      "ty": 5,
      "x": 835,
      "y": 311,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 57756,
      "e": 56439,
      "ty": 41,
      "x": 13479,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 57805,
      "e": 56488,
      "ty": 2,
      "x": 835,
      "y": 315
    },
    {
      "t": 57887,
      "e": 56570,
      "ty": 6,
      "x": 835,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57896,
      "e": 56579,
      "ty": 3,
      "x": 835,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57896,
      "e": 56579,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57905,
      "e": 56588,
      "ty": 2,
      "x": 835,
      "y": 316
    },
    {
      "t": 58000,
      "e": 56683,
      "ty": 4,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58001,
      "e": 56684,
      "ty": 5,
      "x": 835,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58002,
      "e": 56685,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 58005,
      "e": 56688,
      "ty": 2,
      "x": 835,
      "y": 317
    },
    {
      "t": 58005,
      "e": 56688,
      "ty": 41,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58405,
      "e": 57088,
      "ty": 2,
      "x": 836,
      "y": 319
    },
    {
      "t": 58505,
      "e": 57188,
      "ty": 2,
      "x": 837,
      "y": 319
    },
    {
      "t": 58505,
      "e": 57188,
      "ty": 41,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58605,
      "e": 57288,
      "ty": 2,
      "x": 839,
      "y": 322
    },
    {
      "t": 58668,
      "e": 57351,
      "ty": 7,
      "x": 840,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58705,
      "e": 57388,
      "ty": 2,
      "x": 841,
      "y": 330
    },
    {
      "t": 58755,
      "e": 57438,
      "ty": 41,
      "x": 19435,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 58805,
      "e": 57488,
      "ty": 2,
      "x": 841,
      "y": 332
    },
    {
      "t": 58905,
      "e": 57588,
      "ty": 2,
      "x": 841,
      "y": 334
    },
    {
      "t": 59005,
      "e": 57688,
      "ty": 2,
      "x": 844,
      "y": 337
    },
    {
      "t": 59005,
      "e": 57688,
      "ty": 41,
      "x": 5358,
      "y": 13151,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 59104,
      "e": 57787,
      "ty": 2,
      "x": 845,
      "y": 337
    },
    {
      "t": 59255,
      "e": 57938,
      "ty": 41,
      "x": 5595,
      "y": 13151,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 59504,
      "e": 58187,
      "ty": 2,
      "x": 853,
      "y": 352
    },
    {
      "t": 59505,
      "e": 58188,
      "ty": 41,
      "x": 7494,
      "y": 14272,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 59605,
      "e": 58288,
      "ty": 2,
      "x": 862,
      "y": 411
    },
    {
      "t": 59705,
      "e": 58388,
      "ty": 2,
      "x": 862,
      "y": 416
    },
    {
      "t": 59755,
      "e": 58438,
      "ty": 41,
      "x": 47500,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59805,
      "e": 58488,
      "ty": 2,
      "x": 850,
      "y": 424
    },
    {
      "t": 59905,
      "e": 58588,
      "ty": 2,
      "x": 830,
      "y": 433
    },
    {
      "t": 60004,
      "e": 58687,
      "ty": 2,
      "x": 828,
      "y": 435
    },
    {
      "t": 60006,
      "e": 58689,
      "ty": 41,
      "x": 5254,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 60073,
      "e": 58756,
      "ty": 6,
      "x": 828,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60105,
      "e": 58788,
      "ty": 2,
      "x": 828,
      "y": 436
    },
    {
      "t": 60205,
      "e": 58888,
      "ty": 2,
      "x": 828,
      "y": 439
    },
    {
      "t": 60247,
      "e": 58930,
      "ty": 3,
      "x": 828,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60247,
      "e": 58930,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 60248,
      "e": 58931,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60255,
      "e": 58938,
      "ty": 41,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60384,
      "e": 59067,
      "ty": 4,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60385,
      "e": 59068,
      "ty": 5,
      "x": 828,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60385,
      "e": 59068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 60605,
      "e": 59288,
      "ty": 2,
      "x": 829,
      "y": 441
    },
    {
      "t": 60705,
      "e": 59388,
      "ty": 2,
      "x": 830,
      "y": 442
    },
    {
      "t": 60755,
      "e": 59438,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60805,
      "e": 59488,
      "ty": 2,
      "x": 835,
      "y": 443
    },
    {
      "t": 60904,
      "e": 59587,
      "ty": 2,
      "x": 836,
      "y": 444
    },
    {
      "t": 61005,
      "e": 59688,
      "ty": 2,
      "x": 838,
      "y": 447
    },
    {
      "t": 61005,
      "e": 59688,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61019,
      "e": 59702,
      "ty": 7,
      "x": 838,
      "y": 452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61054,
      "e": 59737,
      "ty": 6,
      "x": 838,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 61070,
      "e": 59753,
      "ty": 7,
      "x": 838,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 61105,
      "e": 59788,
      "ty": 2,
      "x": 839,
      "y": 511
    },
    {
      "t": 61120,
      "e": 59803,
      "ty": 6,
      "x": 839,
      "y": 522,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 61154,
      "e": 59837,
      "ty": 7,
      "x": 839,
      "y": 537,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 61206,
      "e": 59839,
      "ty": 6,
      "x": 838,
      "y": 548,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 61209,
      "e": 59842,
      "ty": 2,
      "x": 838,
      "y": 548
    },
    {
      "t": 61255,
      "e": 59888,
      "ty": 41,
      "x": 58367,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 61305,
      "e": 59938,
      "ty": 2,
      "x": 838,
      "y": 557
    },
    {
      "t": 61320,
      "e": 59953,
      "ty": 7,
      "x": 838,
      "y": 567,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 61387,
      "e": 60020,
      "ty": 6,
      "x": 838,
      "y": 576,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 61405,
      "e": 60038,
      "ty": 2,
      "x": 838,
      "y": 576
    },
    {
      "t": 61506,
      "e": 60139,
      "ty": 41,
      "x": 58367,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 61603,
      "e": 60236,
      "ty": 7,
      "x": 819,
      "y": 584,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 61604,
      "e": 60237,
      "ty": 2,
      "x": 819,
      "y": 584
    },
    {
      "t": 61755,
      "e": 60388,
      "ty": 41,
      "x": 27928,
      "y": 31908,
      "ta": "html > body"
    },
    {
      "t": 61969,
      "e": 60602,
      "ty": 6,
      "x": 828,
      "y": 587,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 62004,
      "e": 60637,
      "ty": 7,
      "x": 844,
      "y": 589,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 62004,
      "e": 60637,
      "ty": 2,
      "x": 844,
      "y": 589
    },
    {
      "t": 62004,
      "e": 60637,
      "ty": 41,
      "x": 22413,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 62105,
      "e": 60738,
      "ty": 2,
      "x": 850,
      "y": 592
    },
    {
      "t": 62205,
      "e": 60838,
      "ty": 2,
      "x": 850,
      "y": 623
    },
    {
      "t": 62255,
      "e": 60888,
      "ty": 41,
      "x": 7731,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 62304,
      "e": 60937,
      "ty": 2,
      "x": 852,
      "y": 674
    },
    {
      "t": 62405,
      "e": 61038,
      "ty": 2,
      "x": 851,
      "y": 688
    },
    {
      "t": 62504,
      "e": 61137,
      "ty": 2,
      "x": 853,
      "y": 705
    },
    {
      "t": 62505,
      "e": 61138,
      "ty": 41,
      "x": 7957,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62605,
      "e": 61238,
      "ty": 2,
      "x": 856,
      "y": 724
    },
    {
      "t": 62706,
      "e": 61339,
      "ty": 2,
      "x": 856,
      "y": 736
    },
    {
      "t": 62755,
      "e": 61388,
      "ty": 41,
      "x": 8678,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 62805,
      "e": 61438,
      "ty": 2,
      "x": 856,
      "y": 749
    },
    {
      "t": 62904,
      "e": 61537,
      "ty": 2,
      "x": 856,
      "y": 775
    },
    {
      "t": 63006,
      "e": 61639,
      "ty": 2,
      "x": 855,
      "y": 798
    },
    {
      "t": 63006,
      "e": 61639,
      "ty": 41,
      "x": 7968,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 63104,
      "e": 61737,
      "ty": 2,
      "x": 851,
      "y": 817
    },
    {
      "t": 63205,
      "e": 61838,
      "ty": 2,
      "x": 845,
      "y": 831
    },
    {
      "t": 63255,
      "e": 61888,
      "ty": 41,
      "x": 16612,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 63305,
      "e": 61938,
      "ty": 2,
      "x": 842,
      "y": 843
    },
    {
      "t": 63405,
      "e": 62038,
      "ty": 2,
      "x": 842,
      "y": 844
    },
    {
      "t": 63505,
      "e": 62138,
      "ty": 2,
      "x": 842,
      "y": 805
    },
    {
      "t": 63505,
      "e": 62138,
      "ty": 41,
      "x": 12146,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 63605,
      "e": 62238,
      "ty": 2,
      "x": 845,
      "y": 793
    },
    {
      "t": 63705,
      "e": 62338,
      "ty": 2,
      "x": 841,
      "y": 774
    },
    {
      "t": 63722,
      "e": 62355,
      "ty": 6,
      "x": 836,
      "y": 756,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 63741,
      "e": 62356,
      "ty": 7,
      "x": 836,
      "y": 748,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 63755,
      "e": 62370,
      "ty": 41,
      "x": 3459,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 63805,
      "e": 62420,
      "ty": 2,
      "x": 836,
      "y": 744
    },
    {
      "t": 63905,
      "e": 62520,
      "ty": 2,
      "x": 836,
      "y": 740
    },
    {
      "t": 64005,
      "e": 62620,
      "ty": 2,
      "x": 823,
      "y": 741
    },
    {
      "t": 64006,
      "e": 62621,
      "ty": 41,
      "x": 374,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 64105,
      "e": 62720,
      "ty": 2,
      "x": 811,
      "y": 751
    },
    {
      "t": 64256,
      "e": 62871,
      "ty": 41,
      "x": 27653,
      "y": 41160,
      "ta": "html > body"
    },
    {
      "t": 64405,
      "e": 63020,
      "ty": 2,
      "x": 811,
      "y": 749
    },
    {
      "t": 64505,
      "e": 63120,
      "ty": 2,
      "x": 811,
      "y": 744
    },
    {
      "t": 64506,
      "e": 63121,
      "ty": 41,
      "x": 27653,
      "y": 40772,
      "ta": "html > body"
    },
    {
      "t": 64606,
      "e": 63221,
      "ty": 2,
      "x": 811,
      "y": 741
    },
    {
      "t": 64705,
      "e": 63320,
      "ty": 2,
      "x": 813,
      "y": 740
    },
    {
      "t": 64755,
      "e": 63370,
      "ty": 41,
      "x": 27756,
      "y": 40440,
      "ta": "html > body"
    },
    {
      "t": 64805,
      "e": 63420,
      "ty": 2,
      "x": 815,
      "y": 738
    },
    {
      "t": 64906,
      "e": 63521,
      "ty": 2,
      "x": 816,
      "y": 734
    },
    {
      "t": 65005,
      "e": 63620,
      "ty": 2,
      "x": 816,
      "y": 731
    },
    {
      "t": 65006,
      "e": 63621,
      "ty": 41,
      "x": 27825,
      "y": 40052,
      "ta": "html > body"
    },
    {
      "t": 65105,
      "e": 63720,
      "ty": 2,
      "x": 818,
      "y": 721
    },
    {
      "t": 65205,
      "e": 63820,
      "ty": 2,
      "x": 822,
      "y": 721
    },
    {
      "t": 65256,
      "e": 63871,
      "ty": 41,
      "x": 647,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 65305,
      "e": 63920,
      "ty": 2,
      "x": 824,
      "y": 721
    },
    {
      "t": 65505,
      "e": 64120,
      "ty": 2,
      "x": 824,
      "y": 717
    },
    {
      "t": 65505,
      "e": 64120,
      "ty": 41,
      "x": 611,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 65605,
      "e": 64220,
      "ty": 2,
      "x": 826,
      "y": 711
    },
    {
      "t": 65664,
      "e": 64279,
      "ty": 6,
      "x": 827,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65705,
      "e": 64320,
      "ty": 2,
      "x": 828,
      "y": 704
    },
    {
      "t": 65755,
      "e": 64370,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65805,
      "e": 64420,
      "ty": 2,
      "x": 829,
      "y": 702
    },
    {
      "t": 65976,
      "e": 64591,
      "ty": 3,
      "x": 830,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65977,
      "e": 64592,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65978,
      "e": 64593,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66005,
      "e": 64620,
      "ty": 2,
      "x": 830,
      "y": 701
    },
    {
      "t": 66006,
      "e": 64621,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66048,
      "e": 64663,
      "ty": 4,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66048,
      "e": 64663,
      "ty": 5,
      "x": 830,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66050,
      "e": 64665,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 66255,
      "e": 64870,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66305,
      "e": 64920,
      "ty": 2,
      "x": 831,
      "y": 702
    },
    {
      "t": 66405,
      "e": 65020,
      "ty": 2,
      "x": 829,
      "y": 708
    },
    {
      "t": 66416,
      "e": 65031,
      "ty": 7,
      "x": 828,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66505,
      "e": 65120,
      "ty": 2,
      "x": 823,
      "y": 717
    },
    {
      "t": 66505,
      "e": 65120,
      "ty": 41,
      "x": 374,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 66605,
      "e": 65220,
      "ty": 2,
      "x": 768,
      "y": 771
    },
    {
      "t": 66705,
      "e": 65320,
      "ty": 2,
      "x": 732,
      "y": 886
    },
    {
      "t": 66755,
      "e": 65370,
      "ty": 41,
      "x": 24864,
      "y": 48805,
      "ta": "html > body"
    },
    {
      "t": 66805,
      "e": 65420,
      "ty": 2,
      "x": 730,
      "y": 889
    },
    {
      "t": 66906,
      "e": 65521,
      "ty": 2,
      "x": 730,
      "y": 884
    },
    {
      "t": 67005,
      "e": 65620,
      "ty": 2,
      "x": 731,
      "y": 881
    },
    {
      "t": 67006,
      "e": 65621,
      "ty": 41,
      "x": 24898,
      "y": 48361,
      "ta": "html > body"
    },
    {
      "t": 67105,
      "e": 65720,
      "ty": 2,
      "x": 732,
      "y": 879
    },
    {
      "t": 67255,
      "e": 65870,
      "ty": 41,
      "x": 24932,
      "y": 48251,
      "ta": "html > body"
    },
    {
      "t": 67706,
      "e": 66321,
      "ty": 2,
      "x": 739,
      "y": 867
    },
    {
      "t": 67756,
      "e": 66371,
      "ty": 41,
      "x": 25793,
      "y": 46810,
      "ta": "html > body"
    },
    {
      "t": 67805,
      "e": 66420,
      "ty": 2,
      "x": 760,
      "y": 851
    },
    {
      "t": 67906,
      "e": 66521,
      "ty": 2,
      "x": 788,
      "y": 867
    },
    {
      "t": 68005,
      "e": 66620,
      "ty": 2,
      "x": 844,
      "y": 935
    },
    {
      "t": 68005,
      "e": 66620,
      "ty": 41,
      "x": 24660,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68105,
      "e": 66720,
      "ty": 2,
      "x": 848,
      "y": 939
    },
    {
      "t": 68205,
      "e": 66820,
      "ty": 2,
      "x": 848,
      "y": 940
    },
    {
      "t": 68243,
      "e": 66858,
      "ty": 6,
      "x": 839,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68255,
      "e": 66870,
      "ty": 41,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68305,
      "e": 66920,
      "ty": 2,
      "x": 836,
      "y": 936
    },
    {
      "t": 68400,
      "e": 67015,
      "ty": 3,
      "x": 835,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68401,
      "e": 67016,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 68402,
      "e": 67017,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68410,
      "e": 67025,
      "ty": 2,
      "x": 835,
      "y": 936
    },
    {
      "t": 68495,
      "e": 67110,
      "ty": 4,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68495,
      "e": 67110,
      "ty": 5,
      "x": 835,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68495,
      "e": 67110,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 68505,
      "e": 67120,
      "ty": 41,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68605,
      "e": 67220,
      "ty": 2,
      "x": 836,
      "y": 939
    },
    {
      "t": 68609,
      "e": 67224,
      "ty": 7,
      "x": 837,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68693,
      "e": 67308,
      "ty": 6,
      "x": 879,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68705,
      "e": 67320,
      "ty": 2,
      "x": 879,
      "y": 1017
    },
    {
      "t": 68755,
      "e": 67370,
      "ty": 41,
      "x": 29159,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68806,
      "e": 67421,
      "ty": 2,
      "x": 886,
      "y": 1027
    },
    {
      "t": 68905,
      "e": 67520,
      "ty": 2,
      "x": 887,
      "y": 1027
    },
    {
      "t": 68960,
      "e": 67575,
      "ty": 3,
      "x": 888,
      "y": 1027,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68962,
      "e": 67577,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68962,
      "e": 67577,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69005,
      "e": 67620,
      "ty": 2,
      "x": 888,
      "y": 1027
    },
    {
      "t": 69006,
      "e": 67621,
      "ty": 41,
      "x": 30190,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69048,
      "e": 67663,
      "ty": 4,
      "x": 30190,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69048,
      "e": 67663,
      "ty": 5,
      "x": 888,
      "y": 1027,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69050,
      "e": 67665,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69050,
      "e": 67665,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 69051,
      "e": 67666,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 70005,
      "e": 68620,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70206,
      "e": 68823,
      "ty": 2,
      "x": 889,
      "y": 1023
    },
    {
      "t": 70256,
      "e": 68873,
      "ty": 41,
      "x": 30339,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 70306,
      "e": 68923,
      "ty": 2,
      "x": 889,
      "y": 1021
    },
    {
      "t": 70357,
      "e": 68974,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 70505,
      "e": 69122,
      "ty": 2,
      "x": 889,
      "y": 1018
    },
    {
      "t": 70506,
      "e": 69123,
      "ty": 41,
      "x": 29299,
      "y": 61748,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70605,
      "e": 69222,
      "ty": 2,
      "x": 889,
      "y": 1014
    },
    {
      "t": 70705,
      "e": 69322,
      "ty": 2,
      "x": 889,
      "y": 1012
    },
    {
      "t": 70756,
      "e": 69373,
      "ty": 41,
      "x": 29249,
      "y": 60917,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70805,
      "e": 69422,
      "ty": 2,
      "x": 888,
      "y": 981
    },
    {
      "t": 70905,
      "e": 69522,
      "ty": 2,
      "x": 876,
      "y": 895
    },
    {
      "t": 71005,
      "e": 69622,
      "ty": 2,
      "x": 867,
      "y": 825
    },
    {
      "t": 71006,
      "e": 69623,
      "ty": 41,
      "x": 28216,
      "y": 31030,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 71106,
      "e": 69723,
      "ty": 2,
      "x": 866,
      "y": 814
    },
    {
      "t": 71204,
      "e": 69821,
      "ty": 2,
      "x": 866,
      "y": 812
    },
    {
      "t": 71256,
      "e": 69873,
      "ty": 41,
      "x": 28167,
      "y": 15816,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 71605,
      "e": 70222,
      "ty": 2,
      "x": 866,
      "y": 811
    },
    {
      "t": 71755,
      "e": 70372,
      "ty": 41,
      "x": 28118,
      "y": 14646,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 71804,
      "e": 70421,
      "ty": 2,
      "x": 865,
      "y": 811
    },
    {
      "t": 72905,
      "e": 71522,
      "ty": 2,
      "x": 864,
      "y": 815
    },
    {
      "t": 73005,
      "e": 71622,
      "ty": 41,
      "x": 28069,
      "y": 19327,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 73904,
      "e": 72521,
      "ty": 2,
      "x": 866,
      "y": 815
    },
    {
      "t": 74005,
      "e": 72622,
      "ty": 2,
      "x": 885,
      "y": 803
    },
    {
      "t": 74005,
      "e": 72622,
      "ty": 41,
      "x": 29102,
      "y": 5284,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 74705,
      "e": 73322,
      "ty": 2,
      "x": 879,
      "y": 785
    },
    {
      "t": 74755,
      "e": 73372,
      "ty": 41,
      "x": 28807,
      "y": 51816,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 74804,
      "e": 73421,
      "ty": 2,
      "x": 879,
      "y": 782
    },
    {
      "t": 74905,
      "e": 73522,
      "ty": 2,
      "x": 879,
      "y": 781
    },
    {
      "t": 75005,
      "e": 73622,
      "ty": 41,
      "x": 28807,
      "y": 51700,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 76504,
      "e": 75121,
      "ty": 2,
      "x": 877,
      "y": 780
    },
    {
      "t": 76505,
      "e": 75122,
      "ty": 41,
      "x": 28708,
      "y": 65251,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 79905,
      "e": 78522,
      "ty": 2,
      "x": 880,
      "y": 779
    },
    {
      "t": 80005,
      "e": 78622,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80006,
      "e": 78623,
      "ty": 41,
      "x": 28856,
      "y": 64666,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 90005,
      "e": 83623,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90506,
      "e": 83623,
      "ty": 2,
      "x": 881,
      "y": 778
    },
    {
      "t": 90506,
      "e": 83623,
      "ty": 41,
      "x": 28905,
      "y": 64081,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 91755,
      "e": 84872,
      "ty": 41,
      "x": 29053,
      "y": 62911,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 91805,
      "e": 84922,
      "ty": 2,
      "x": 885,
      "y": 775
    },
    {
      "t": 92006,
      "e": 85123,
      "ty": 41,
      "x": 29102,
      "y": 62325,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 92106,
      "e": 85223,
      "ty": 2,
      "x": 887,
      "y": 774
    },
    {
      "t": 92206,
      "e": 85323,
      "ty": 2,
      "x": 887,
      "y": 773
    },
    {
      "t": 92255,
      "e": 85372,
      "ty": 41,
      "x": 29200,
      "y": 61155,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 93105,
      "e": 86222,
      "ty": 2,
      "x": 889,
      "y": 772
    },
    {
      "t": 93255,
      "e": 86372,
      "ty": 41,
      "x": 29348,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 93304,
      "e": 86421,
      "ty": 2,
      "x": 892,
      "y": 772
    },
    {
      "t": 93404,
      "e": 86521,
      "ty": 2,
      "x": 907,
      "y": 774
    },
    {
      "t": 93505,
      "e": 86622,
      "ty": 2,
      "x": 910,
      "y": 776
    },
    {
      "t": 93505,
      "e": 86622,
      "ty": 41,
      "x": 30332,
      "y": 62911,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 96704,
      "e": 89821,
      "ty": 2,
      "x": 911,
      "y": 781
    },
    {
      "t": 96755,
      "e": 89872,
      "ty": 41,
      "x": 30381,
      "y": 51931,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 96805,
      "e": 89922,
      "ty": 2,
      "x": 911,
      "y": 783
    },
    {
      "t": 100005,
      "e": 93122,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 105105,
      "e": 94922,
      "ty": 2,
      "x": 909,
      "y": 787
    },
    {
      "t": 105205,
      "e": 95022,
      "ty": 2,
      "x": 908,
      "y": 821
    },
    {
      "t": 105255,
      "e": 95072,
      "ty": 41,
      "x": 30430,
      "y": 53265,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 105305,
      "e": 95122,
      "ty": 2,
      "x": 915,
      "y": 860
    },
    {
      "t": 105405,
      "e": 95222,
      "ty": 2,
      "x": 917,
      "y": 867
    },
    {
      "t": 105505,
      "e": 95322,
      "ty": 2,
      "x": 936,
      "y": 950
    },
    {
      "t": 105505,
      "e": 95322,
      "ty": 41,
      "x": 31611,
      "y": 57039,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105605,
      "e": 95422,
      "ty": 2,
      "x": 953,
      "y": 995
    },
    {
      "t": 105705,
      "e": 95522,
      "ty": 2,
      "x": 962,
      "y": 1023
    },
    {
      "t": 105756,
      "e": 95573,
      "ty": 41,
      "x": 33284,
      "y": 63340,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105805,
      "e": 95622,
      "ty": 2,
      "x": 971,
      "y": 1049
    },
    {
      "t": 105905,
      "e": 95722,
      "ty": 2,
      "x": 973,
      "y": 1053
    },
    {
      "t": 106005,
      "e": 95822,
      "ty": 2,
      "x": 981,
      "y": 1065
    },
    {
      "t": 106006,
      "e": 95823,
      "ty": 41,
      "x": 33825,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106105,
      "e": 95922,
      "ty": 2,
      "x": 981,
      "y": 1066
    },
    {
      "t": 106206,
      "e": 96023,
      "ty": 2,
      "x": 981,
      "y": 1068
    },
    {
      "t": 106256,
      "e": 96073,
      "ty": 41,
      "x": 33677,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106256,
      "e": 96073,
      "ty": 6,
      "x": 978,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 106305,
      "e": 96122,
      "ty": 2,
      "x": 977,
      "y": 1073
    },
    {
      "t": 106405,
      "e": 96222,
      "ty": 2,
      "x": 975,
      "y": 1075
    },
    {
      "t": 106505,
      "e": 96322,
      "ty": 2,
      "x": 974,
      "y": 1076
    },
    {
      "t": 106505,
      "e": 96322,
      "ty": 41,
      "x": 35225,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 107105,
      "e": 96922,
      "ty": 2,
      "x": 973,
      "y": 1076
    },
    {
      "t": 107255,
      "e": 97072,
      "ty": 41,
      "x": 34678,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 107416,
      "e": 97233,
      "ty": 3,
      "x": 973,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 107417,
      "e": 97234,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 107559,
      "e": 97376,
      "ty": 4,
      "x": 34678,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 107559,
      "e": 97376,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 107560,
      "e": 97377,
      "ty": 5,
      "x": 973,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 107560,
      "e": 97377,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 108597,
      "e": 98414,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 109481,
      "e": 99298,
      "ty": 2,
      "x": 972,
      "y": 1076
    },
    {
      "t": 109481,
      "e": 99298,
      "ty": 41,
      "x": 33469,
      "y": 32864,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 109758,
      "e": 99575,
      "ty": 41,
      "x": 33413,
      "y": 32864,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 109808,
      "e": 99625,
      "ty": 2,
      "x": 970,
      "y": 1076
    },
    {
      "t": 109909,
      "e": 99726,
      "ty": 2,
      "x": 969,
      "y": 1075
    },
    {
      "t": 110009,
      "e": 99826,
      "ty": 2,
      "x": 967,
      "y": 1069
    },
    {
      "t": 110009,
      "e": 99826,
      "ty": 41,
      "x": 33188,
      "y": 32862,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 110108,
      "e": 99925,
      "ty": 2,
      "x": 962,
      "y": 1061
    },
    {
      "t": 110206,
      "e": 100023,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 226710, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 226716, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 25741, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 253782, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10571, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 265358, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 22067, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 288511, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12003, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 301518, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 46346, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 349207, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -12 PM-11 AM-A -F -U -05 PM-06 PM-02 PM-02 PM-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1116,y:966,t:1527030359733};\\\", \\\"{x:1158,y:936,t:1527030359740};\\\", \\\"{x:1245,y:891,t:1527030359757};\\\", \\\"{x:1307,y:868,t:1527030359774};\\\", \\\"{x:1340,y:858,t:1527030359790};\\\", \\\"{x:1344,y:857,t:1527030359806};\\\", \\\"{x:1344,y:855,t:1527030359980};\\\", \\\"{x:1343,y:855,t:1527030359991};\\\", \\\"{x:1341,y:855,t:1527030360006};\\\", \\\"{x:1339,y:854,t:1527030360029};\\\", \\\"{x:1338,y:854,t:1527030360041};\\\", \\\"{x:1335,y:852,t:1527030360056};\\\", \\\"{x:1331,y:851,t:1527030360073};\\\", \\\"{x:1327,y:849,t:1527030360091};\\\", \\\"{x:1324,y:849,t:1527030360107};\\\", \\\"{x:1319,y:848,t:1527030360124};\\\", \\\"{x:1315,y:846,t:1527030360140};\\\", \\\"{x:1313,y:845,t:1527030360157};\\\", \\\"{x:1312,y:845,t:1527030360180};\\\", \\\"{x:1310,y:845,t:1527030360260};\\\", \\\"{x:1309,y:845,t:1527030360277};\\\", \\\"{x:1307,y:845,t:1527030360291};\\\", \\\"{x:1306,y:845,t:1527030360307};\\\", \\\"{x:1301,y:843,t:1527030360324};\\\", \\\"{x:1294,y:842,t:1527030360340};\\\", \\\"{x:1292,y:841,t:1527030360357};\\\", \\\"{x:1291,y:841,t:1527030360373};\\\", \\\"{x:1290,y:841,t:1527030360389};\\\", \\\"{x:1289,y:841,t:1527030360407};\\\", \\\"{x:1288,y:841,t:1527030360459};\\\", \\\"{x:1287,y:841,t:1527030360475};\\\", \\\"{x:1286,y:841,t:1527030360564};\\\", \\\"{x:1285,y:840,t:1527030360573};\\\", \\\"{x:1285,y:839,t:1527030360590};\\\", \\\"{x:1284,y:839,t:1527030360608};\\\", \\\"{x:1283,y:838,t:1527030360628};\\\", \\\"{x:1282,y:836,t:1527030360640};\\\", \\\"{x:1282,y:834,t:1527030360660};\\\", \\\"{x:1282,y:835,t:1527030372492};\\\", \\\"{x:1282,y:836,t:1527030372502};\\\", \\\"{x:1282,y:840,t:1527030372516};\\\", \\\"{x:1282,y:845,t:1527030372532};\\\", \\\"{x:1282,y:849,t:1527030372549};\\\", \\\"{x:1282,y:852,t:1527030372566};\\\", \\\"{x:1282,y:856,t:1527030372583};\\\", \\\"{x:1282,y:862,t:1527030372599};\\\", \\\"{x:1282,y:868,t:1527030372616};\\\", \\\"{x:1282,y:874,t:1527030372633};\\\", \\\"{x:1282,y:879,t:1527030372649};\\\", \\\"{x:1282,y:881,t:1527030372666};\\\", \\\"{x:1282,y:882,t:1527030372683};\\\", \\\"{x:1282,y:884,t:1527030372700};\\\", \\\"{x:1283,y:889,t:1527030372716};\\\", \\\"{x:1283,y:893,t:1527030372733};\\\", \\\"{x:1283,y:896,t:1527030372749};\\\", \\\"{x:1283,y:898,t:1527030372767};\\\", \\\"{x:1283,y:899,t:1527030372783};\\\", \\\"{x:1283,y:897,t:1527030372933};\\\", \\\"{x:1283,y:887,t:1527030372951};\\\", \\\"{x:1282,y:877,t:1527030372967};\\\", \\\"{x:1277,y:865,t:1527030372984};\\\", \\\"{x:1262,y:846,t:1527030373000};\\\", \\\"{x:1242,y:830,t:1527030373017};\\\", \\\"{x:1197,y:811,t:1527030373034};\\\", \\\"{x:1126,y:793,t:1527030373050};\\\", \\\"{x:1046,y:784,t:1527030373066};\\\", \\\"{x:957,y:771,t:1527030373084};\\\", \\\"{x:800,y:751,t:1527030373099};\\\", \\\"{x:709,y:740,t:1527030373116};\\\", \\\"{x:631,y:731,t:1527030373133};\\\", \\\"{x:554,y:720,t:1527030373152};\\\", \\\"{x:478,y:709,t:1527030373166};\\\", \\\"{x:425,y:701,t:1527030373183};\\\", \\\"{x:373,y:690,t:1527030373201};\\\", \\\"{x:332,y:686,t:1527030373217};\\\", \\\"{x:300,y:681,t:1527030373234};\\\", \\\"{x:258,y:672,t:1527030373251};\\\", \\\"{x:234,y:666,t:1527030373267};\\\", \\\"{x:211,y:661,t:1527030373284};\\\", \\\"{x:187,y:654,t:1527030373301};\\\", \\\"{x:165,y:647,t:1527030373318};\\\", \\\"{x:143,y:638,t:1527030373334};\\\", \\\"{x:127,y:631,t:1527030373351};\\\", \\\"{x:117,y:621,t:1527030373368};\\\", \\\"{x:115,y:618,t:1527030373385};\\\", \\\"{x:113,y:611,t:1527030373402};\\\", \\\"{x:113,y:605,t:1527030373418};\\\", \\\"{x:112,y:597,t:1527030373435};\\\", \\\"{x:112,y:589,t:1527030373451};\\\", \\\"{x:112,y:586,t:1527030373467};\\\", \\\"{x:112,y:582,t:1527030373485};\\\", \\\"{x:112,y:579,t:1527030373502};\\\", \\\"{x:115,y:575,t:1527030373518};\\\", \\\"{x:122,y:570,t:1527030373536};\\\", \\\"{x:132,y:564,t:1527030373552};\\\", \\\"{x:139,y:559,t:1527030373568};\\\", \\\"{x:144,y:554,t:1527030373585};\\\", \\\"{x:145,y:553,t:1527030373602};\\\", \\\"{x:146,y:552,t:1527030373618};\\\", \\\"{x:148,y:550,t:1527030373634};\\\", \\\"{x:152,y:549,t:1527030373651};\\\", \\\"{x:156,y:547,t:1527030373668};\\\", \\\"{x:164,y:543,t:1527030373685};\\\", \\\"{x:181,y:536,t:1527030373702};\\\", \\\"{x:204,y:530,t:1527030373719};\\\", \\\"{x:244,y:524,t:1527030373735};\\\", \\\"{x:279,y:517,t:1527030373753};\\\", \\\"{x:314,y:514,t:1527030373769};\\\", \\\"{x:337,y:511,t:1527030373785};\\\", \\\"{x:357,y:508,t:1527030373802};\\\", \\\"{x:363,y:507,t:1527030373818};\\\", \\\"{x:365,y:507,t:1527030373835};\\\", \\\"{x:366,y:507,t:1527030373925};\\\", \\\"{x:368,y:507,t:1527030373936};\\\", \\\"{x:369,y:507,t:1527030373956};\\\", \\\"{x:372,y:508,t:1527030373969};\\\", \\\"{x:377,y:512,t:1527030373986};\\\", \\\"{x:380,y:516,t:1527030374003};\\\", \\\"{x:381,y:518,t:1527030374019};\\\", \\\"{x:384,y:520,t:1527030374035};\\\", \\\"{x:389,y:520,t:1527030374909};\\\", \\\"{x:405,y:516,t:1527030374919};\\\", \\\"{x:465,y:505,t:1527030374937};\\\", \\\"{x:536,y:498,t:1527030374952};\\\", \\\"{x:613,y:493,t:1527030374968};\\\", \\\"{x:680,y:491,t:1527030374986};\\\", \\\"{x:726,y:489,t:1527030375003};\\\", \\\"{x:764,y:496,t:1527030375019};\\\", \\\"{x:784,y:503,t:1527030375036};\\\", \\\"{x:802,y:508,t:1527030375054};\\\", \\\"{x:816,y:512,t:1527030375070};\\\", \\\"{x:825,y:517,t:1527030375086};\\\", \\\"{x:832,y:522,t:1527030375102};\\\", \\\"{x:837,y:537,t:1527030375120};\\\", \\\"{x:842,y:555,t:1527030375136};\\\", \\\"{x:851,y:585,t:1527030375154};\\\", \\\"{x:867,y:622,t:1527030375170};\\\", \\\"{x:893,y:668,t:1527030375185};\\\", \\\"{x:928,y:723,t:1527030375203};\\\", \\\"{x:950,y:748,t:1527030375219};\\\", \\\"{x:964,y:762,t:1527030375236};\\\", \\\"{x:975,y:770,t:1527030375253};\\\", \\\"{x:978,y:773,t:1527030375270};\\\", \\\"{x:979,y:773,t:1527030375286};\\\", \\\"{x:980,y:774,t:1527030375303};\\\", \\\"{x:981,y:775,t:1527030375320};\\\", \\\"{x:982,y:775,t:1527030375348};\\\", \\\"{x:983,y:776,t:1527030375364};\\\", \\\"{x:984,y:777,t:1527030375380};\\\", \\\"{x:985,y:777,t:1527030375396};\\\", \\\"{x:986,y:778,t:1527030375412};\\\", \\\"{x:987,y:779,t:1527030375420};\\\", \\\"{x:988,y:780,t:1527030375438};\\\", \\\"{x:989,y:780,t:1527030375460};\\\", \\\"{x:990,y:781,t:1527030375556};\\\", \\\"{x:990,y:782,t:1527030375570};\\\", \\\"{x:990,y:783,t:1527030375588};\\\", \\\"{x:991,y:783,t:1527030375603};\\\", \\\"{x:991,y:785,t:1527030375620};\\\", \\\"{x:992,y:785,t:1527030375652};\\\", \\\"{x:995,y:785,t:1527030377315};\\\", \\\"{x:997,y:785,t:1527030377323};\\\", \\\"{x:1003,y:782,t:1527030377337};\\\", \\\"{x:1021,y:777,t:1527030377355};\\\", \\\"{x:1046,y:769,t:1527030377370};\\\", \\\"{x:1089,y:763,t:1527030377388};\\\", \\\"{x:1103,y:762,t:1527030377405};\\\", \\\"{x:1107,y:760,t:1527030377421};\\\", \\\"{x:1107,y:762,t:1527030377492};\\\", \\\"{x:1107,y:766,t:1527030377506};\\\", \\\"{x:1114,y:788,t:1527030377521};\\\", \\\"{x:1141,y:825,t:1527030377538};\\\", \\\"{x:1161,y:862,t:1527030377556};\\\", \\\"{x:1179,y:890,t:1527030377572};\\\", \\\"{x:1202,y:908,t:1527030377589};\\\", \\\"{x:1220,y:912,t:1527030377606};\\\", \\\"{x:1243,y:913,t:1527030377621};\\\", \\\"{x:1270,y:913,t:1527030377639};\\\", \\\"{x:1296,y:915,t:1527030377656};\\\", \\\"{x:1325,y:918,t:1527030377671};\\\", \\\"{x:1351,y:924,t:1527030377689};\\\", \\\"{x:1356,y:929,t:1527030377705};\\\", \\\"{x:1356,y:934,t:1527030377722};\\\", \\\"{x:1356,y:940,t:1527030377738};\\\", \\\"{x:1354,y:944,t:1527030377756};\\\", \\\"{x:1351,y:947,t:1527030377771};\\\", \\\"{x:1343,y:953,t:1527030377788};\\\", \\\"{x:1341,y:962,t:1527030377806};\\\", \\\"{x:1334,y:972,t:1527030377822};\\\", \\\"{x:1330,y:977,t:1527030377838};\\\", \\\"{x:1329,y:978,t:1527030377856};\\\", \\\"{x:1329,y:979,t:1527030377873};\\\", \\\"{x:1329,y:981,t:1527030377888};\\\", \\\"{x:1328,y:982,t:1527030377905};\\\", \\\"{x:1327,y:983,t:1527030377923};\\\", \\\"{x:1326,y:984,t:1527030377939};\\\", \\\"{x:1322,y:984,t:1527030377955};\\\", \\\"{x:1317,y:984,t:1527030377972};\\\", \\\"{x:1309,y:984,t:1527030377989};\\\", \\\"{x:1298,y:983,t:1527030378005};\\\", \\\"{x:1289,y:981,t:1527030378023};\\\", \\\"{x:1286,y:981,t:1527030378039};\\\", \\\"{x:1285,y:981,t:1527030378056};\\\", \\\"{x:1284,y:981,t:1527030378073};\\\", \\\"{x:1282,y:980,t:1527030378171};\\\", \\\"{x:1281,y:978,t:1527030378188};\\\", \\\"{x:1281,y:977,t:1527030378205};\\\", \\\"{x:1279,y:974,t:1527030378221};\\\", \\\"{x:1279,y:972,t:1527030378239};\\\", \\\"{x:1279,y:967,t:1527030378255};\\\", \\\"{x:1278,y:964,t:1527030378272};\\\", \\\"{x:1277,y:958,t:1527030378288};\\\", \\\"{x:1277,y:954,t:1527030378305};\\\", \\\"{x:1276,y:950,t:1527030378322};\\\", \\\"{x:1275,y:940,t:1527030378339};\\\", \\\"{x:1275,y:924,t:1527030378356};\\\", \\\"{x:1275,y:903,t:1527030378372};\\\", \\\"{x:1275,y:892,t:1527030378389};\\\", \\\"{x:1275,y:883,t:1527030378405};\\\", \\\"{x:1275,y:872,t:1527030378422};\\\", \\\"{x:1273,y:863,t:1527030378439};\\\", \\\"{x:1273,y:860,t:1527030378455};\\\", \\\"{x:1273,y:858,t:1527030378472};\\\", \\\"{x:1273,y:857,t:1527030378489};\\\", \\\"{x:1273,y:855,t:1527030378505};\\\", \\\"{x:1275,y:852,t:1527030378522};\\\", \\\"{x:1275,y:851,t:1527030378539};\\\", \\\"{x:1275,y:850,t:1527030378555};\\\", \\\"{x:1275,y:848,t:1527030378587};\\\", \\\"{x:1275,y:847,t:1527030378595};\\\", \\\"{x:1275,y:845,t:1527030378605};\\\", \\\"{x:1275,y:839,t:1527030378622};\\\", \\\"{x:1275,y:837,t:1527030378639};\\\", \\\"{x:1275,y:836,t:1527030378655};\\\", \\\"{x:1275,y:834,t:1527030378672};\\\", \\\"{x:1275,y:831,t:1527030378690};\\\", \\\"{x:1275,y:830,t:1527030378706};\\\", \\\"{x:1275,y:828,t:1527030378723};\\\", \\\"{x:1276,y:826,t:1527030378739};\\\", \\\"{x:1276,y:825,t:1527030378757};\\\", \\\"{x:1276,y:821,t:1527030378772};\\\", \\\"{x:1277,y:821,t:1527030378789};\\\", \\\"{x:1277,y:819,t:1527030378806};\\\", \\\"{x:1278,y:815,t:1527030378822};\\\", \\\"{x:1278,y:814,t:1527030378839};\\\", \\\"{x:1278,y:811,t:1527030378857};\\\", \\\"{x:1278,y:808,t:1527030378873};\\\", \\\"{x:1278,y:805,t:1527030378890};\\\", \\\"{x:1278,y:802,t:1527030378907};\\\", \\\"{x:1278,y:801,t:1527030378924};\\\", \\\"{x:1278,y:799,t:1527030378949};\\\", \\\"{x:1278,y:798,t:1527030378980};\\\", \\\"{x:1278,y:796,t:1527030378996};\\\", \\\"{x:1278,y:794,t:1527030379020};\\\", \\\"{x:1278,y:793,t:1527030379028};\\\", \\\"{x:1278,y:792,t:1527030379040};\\\", \\\"{x:1278,y:790,t:1527030379057};\\\", \\\"{x:1278,y:789,t:1527030379073};\\\", \\\"{x:1278,y:788,t:1527030379090};\\\", \\\"{x:1278,y:787,t:1527030379107};\\\", \\\"{x:1278,y:786,t:1527030379124};\\\", \\\"{x:1279,y:786,t:1527030379140};\\\", \\\"{x:1279,y:785,t:1527030379267};\\\", \\\"{x:1279,y:784,t:1527030379291};\\\", \\\"{x:1280,y:782,t:1527030379476};\\\", \\\"{x:1281,y:782,t:1527030379508};\\\", \\\"{x:1282,y:781,t:1527030381084};\\\", \\\"{x:1282,y:779,t:1527030381092};\\\", \\\"{x:1284,y:775,t:1527030381108};\\\", \\\"{x:1285,y:772,t:1527030381125};\\\", \\\"{x:1286,y:770,t:1527030381142};\\\", \\\"{x:1287,y:768,t:1527030381158};\\\", \\\"{x:1288,y:766,t:1527030381175};\\\", \\\"{x:1290,y:760,t:1527030381191};\\\", \\\"{x:1292,y:753,t:1527030381208};\\\", \\\"{x:1294,y:746,t:1527030381225};\\\", \\\"{x:1296,y:741,t:1527030381242};\\\", \\\"{x:1297,y:737,t:1527030381257};\\\", \\\"{x:1297,y:733,t:1527030381275};\\\", \\\"{x:1300,y:726,t:1527030381292};\\\", \\\"{x:1300,y:723,t:1527030381308};\\\", \\\"{x:1300,y:720,t:1527030381325};\\\", \\\"{x:1300,y:718,t:1527030381341};\\\", \\\"{x:1300,y:712,t:1527030381358};\\\", \\\"{x:1300,y:710,t:1527030381375};\\\", \\\"{x:1300,y:706,t:1527030381392};\\\", \\\"{x:1300,y:705,t:1527030381408};\\\", \\\"{x:1300,y:700,t:1527030381425};\\\", \\\"{x:1299,y:696,t:1527030381442};\\\", \\\"{x:1298,y:692,t:1527030381458};\\\", \\\"{x:1295,y:687,t:1527030381475};\\\", \\\"{x:1292,y:682,t:1527030381492};\\\", \\\"{x:1291,y:679,t:1527030381508};\\\", \\\"{x:1290,y:676,t:1527030381525};\\\", \\\"{x:1288,y:668,t:1527030381541};\\\", \\\"{x:1285,y:658,t:1527030381557};\\\", \\\"{x:1280,y:645,t:1527030381575};\\\", \\\"{x:1272,y:629,t:1527030381592};\\\", \\\"{x:1267,y:613,t:1527030381608};\\\", \\\"{x:1262,y:596,t:1527030381625};\\\", \\\"{x:1261,y:583,t:1527030381641};\\\", \\\"{x:1260,y:572,t:1527030381658};\\\", \\\"{x:1258,y:565,t:1527030381675};\\\", \\\"{x:1256,y:545,t:1527030381692};\\\", \\\"{x:1253,y:528,t:1527030381708};\\\", \\\"{x:1251,y:511,t:1527030381725};\\\", \\\"{x:1250,y:502,t:1527030381742};\\\", \\\"{x:1248,y:498,t:1527030381759};\\\", \\\"{x:1248,y:491,t:1527030381775};\\\", \\\"{x:1248,y:483,t:1527030381791};\\\", \\\"{x:1248,y:478,t:1527030381808};\\\", \\\"{x:1248,y:471,t:1527030381825};\\\", \\\"{x:1248,y:464,t:1527030381842};\\\", \\\"{x:1248,y:459,t:1527030381860};\\\", \\\"{x:1248,y:451,t:1527030381874};\\\", \\\"{x:1248,y:443,t:1527030381891};\\\", \\\"{x:1248,y:440,t:1527030381908};\\\", \\\"{x:1248,y:435,t:1527030381924};\\\", \\\"{x:1248,y:431,t:1527030381941};\\\", \\\"{x:1249,y:427,t:1527030381958};\\\", \\\"{x:1250,y:420,t:1527030381974};\\\", \\\"{x:1251,y:413,t:1527030381991};\\\", \\\"{x:1252,y:407,t:1527030382008};\\\", \\\"{x:1252,y:404,t:1527030382025};\\\", \\\"{x:1252,y:402,t:1527030382041};\\\", \\\"{x:1252,y:401,t:1527030382140};\\\", \\\"{x:1250,y:402,t:1527030382164};\\\", \\\"{x:1246,y:407,t:1527030382176};\\\", \\\"{x:1228,y:433,t:1527030382192};\\\", \\\"{x:1189,y:484,t:1527030382209};\\\", \\\"{x:1139,y:559,t:1527030382226};\\\", \\\"{x:1077,y:640,t:1527030382242};\\\", \\\"{x:1005,y:723,t:1527030382258};\\\", \\\"{x:902,y:824,t:1527030382276};\\\", \\\"{x:839,y:875,t:1527030382292};\\\", \\\"{x:775,y:921,t:1527030382309};\\\", \\\"{x:722,y:957,t:1527030382325};\\\", \\\"{x:680,y:977,t:1527030382342};\\\", \\\"{x:649,y:987,t:1527030382359};\\\", \\\"{x:628,y:987,t:1527030382375};\\\", \\\"{x:605,y:987,t:1527030382391};\\\", \\\"{x:587,y:983,t:1527030382408};\\\", \\\"{x:566,y:977,t:1527030382425};\\\", \\\"{x:549,y:972,t:1527030382442};\\\", \\\"{x:531,y:964,t:1527030382459};\\\", \\\"{x:518,y:946,t:1527030382476};\\\", \\\"{x:510,y:927,t:1527030382491};\\\", \\\"{x:499,y:903,t:1527030382508};\\\", \\\"{x:490,y:883,t:1527030382525};\\\", \\\"{x:485,y:871,t:1527030382542};\\\", \\\"{x:483,y:865,t:1527030382558};\\\", \\\"{x:481,y:859,t:1527030382575};\\\", \\\"{x:481,y:849,t:1527030382593};\\\", \\\"{x:481,y:840,t:1527030382609};\\\", \\\"{x:481,y:832,t:1527030382625};\\\", \\\"{x:486,y:822,t:1527030382643};\\\", \\\"{x:490,y:814,t:1527030382659};\\\", \\\"{x:496,y:804,t:1527030382675};\\\", \\\"{x:507,y:794,t:1527030382691};\\\", \\\"{x:519,y:784,t:1527030382709};\\\", \\\"{x:534,y:774,t:1527030382725};\\\", \\\"{x:553,y:761,t:1527030382743};\\\", \\\"{x:576,y:749,t:1527030382759};\\\", \\\"{x:596,y:737,t:1527030382775};\\\", \\\"{x:609,y:730,t:1527030382793};\\\", \\\"{x:612,y:728,t:1527030382809};\\\", \\\"{x:616,y:727,t:1527030382826};\\\", \\\"{x:617,y:726,t:1527030382852};\\\", \\\"{x:619,y:725,t:1527030384084};\\\", \\\"{x:620,y:724,t:1527030384108};\\\", \\\"{x:621,y:724,t:1527030385340};\\\", \\\"{x:623,y:722,t:1527030385347};\\\", \\\"{x:626,y:721,t:1527030385360};\\\", \\\"{x:632,y:718,t:1527030385378};\\\", \\\"{x:640,y:715,t:1527030385393};\\\", \\\"{x:653,y:707,t:1527030385411};\\\", \\\"{x:678,y:695,t:1527030385428};\\\", \\\"{x:704,y:685,t:1527030385444};\\\", \\\"{x:751,y:672,t:1527030385461};\\\", \\\"{x:828,y:653,t:1527030385478};\\\", \\\"{x:905,y:648,t:1527030385495};\\\", \\\"{x:985,y:648,t:1527030385511};\\\", \\\"{x:1077,y:649,t:1527030385528};\\\", \\\"{x:1181,y:671,t:1527030385545};\\\", \\\"{x:1290,y:704,t:1527030385560};\\\", \\\"{x:1382,y:752,t:1527030385578};\\\", \\\"{x:1479,y:820,t:1527030385595};\\\", \\\"{x:1569,y:894,t:1527030385611};\\\", \\\"{x:1662,y:977,t:1527030385627};\\\", \\\"{x:1701,y:1003,t:1527030385644};\\\", \\\"{x:1725,y:1012,t:1527030385660};\\\", \\\"{x:1734,y:1013,t:1527030385677};\\\", \\\"{x:1737,y:1013,t:1527030385694};\\\", \\\"{x:1740,y:999,t:1527030385710};\\\", \\\"{x:1741,y:972,t:1527030385727};\\\", \\\"{x:1739,y:925,t:1527030385746};\\\", \\\"{x:1716,y:842,t:1527030385760};\\\", \\\"{x:1689,y:753,t:1527030385777};\\\", \\\"{x:1669,y:681,t:1527030385795};\\\", \\\"{x:1650,y:620,t:1527030385811};\\\", \\\"{x:1611,y:520,t:1527030385827};\\\", \\\"{x:1603,y:479,t:1527030385844};\\\", \\\"{x:1598,y:449,t:1527030385860};\\\", \\\"{x:1598,y:427,t:1527030385877};\\\", \\\"{x:1598,y:409,t:1527030385895};\\\", \\\"{x:1596,y:395,t:1527030385910};\\\", \\\"{x:1592,y:383,t:1527030385928};\\\", \\\"{x:1589,y:379,t:1527030385944};\\\", \\\"{x:1587,y:375,t:1527030385961};\\\", \\\"{x:1587,y:374,t:1527030385978};\\\", \\\"{x:1587,y:371,t:1527030385995};\\\", \\\"{x:1587,y:366,t:1527030386011};\\\", \\\"{x:1588,y:358,t:1527030386027};\\\", \\\"{x:1589,y:351,t:1527030386045};\\\", \\\"{x:1589,y:338,t:1527030386062};\\\", \\\"{x:1587,y:324,t:1527030386078};\\\", \\\"{x:1581,y:308,t:1527030386095};\\\", \\\"{x:1577,y:290,t:1527030386112};\\\", \\\"{x:1573,y:271,t:1527030386127};\\\", \\\"{x:1566,y:249,t:1527030386145};\\\", \\\"{x:1557,y:232,t:1527030386161};\\\", \\\"{x:1550,y:219,t:1527030386177};\\\", \\\"{x:1544,y:210,t:1527030386195};\\\", \\\"{x:1539,y:203,t:1527030386212};\\\", \\\"{x:1538,y:203,t:1527030386236};\\\", \\\"{x:1537,y:203,t:1527030386260};\\\", \\\"{x:1536,y:203,t:1527030386268};\\\", \\\"{x:1534,y:203,t:1527030386278};\\\", \\\"{x:1527,y:203,t:1527030386295};\\\", \\\"{x:1520,y:202,t:1527030386312};\\\", \\\"{x:1514,y:200,t:1527030386328};\\\", \\\"{x:1511,y:200,t:1527030386345};\\\", \\\"{x:1509,y:200,t:1527030386362};\\\", \\\"{x:1508,y:200,t:1527030386378};\\\", \\\"{x:1505,y:200,t:1527030386395};\\\", \\\"{x:1504,y:200,t:1527030386533};\\\", \\\"{x:1502,y:200,t:1527030386545};\\\", \\\"{x:1499,y:200,t:1527030386562};\\\", \\\"{x:1498,y:200,t:1527030386579};\\\", \\\"{x:1496,y:199,t:1527030386595};\\\", \\\"{x:1495,y:199,t:1527030386612};\\\", \\\"{x:1494,y:198,t:1527030386629};\\\", \\\"{x:1491,y:195,t:1527030386645};\\\", \\\"{x:1489,y:191,t:1527030386662};\\\", \\\"{x:1486,y:189,t:1527030386679};\\\", \\\"{x:1483,y:185,t:1527030386695};\\\", \\\"{x:1481,y:183,t:1527030386712};\\\", \\\"{x:1480,y:181,t:1527030386729};\\\", \\\"{x:1479,y:180,t:1527030386745};\\\", \\\"{x:1478,y:182,t:1527030386956};\\\", \\\"{x:1477,y:188,t:1527030386965};\\\", \\\"{x:1477,y:196,t:1527030386979};\\\", \\\"{x:1475,y:224,t:1527030386996};\\\", \\\"{x:1471,y:243,t:1527030387012};\\\", \\\"{x:1471,y:262,t:1527030387029};\\\", \\\"{x:1471,y:281,t:1527030387046};\\\", \\\"{x:1471,y:291,t:1527030387062};\\\", \\\"{x:1472,y:297,t:1527030387079};\\\", \\\"{x:1473,y:300,t:1527030387096};\\\", \\\"{x:1474,y:308,t:1527030387112};\\\", \\\"{x:1474,y:315,t:1527030387131};\\\", \\\"{x:1476,y:325,t:1527030387145};\\\", \\\"{x:1477,y:335,t:1527030387161};\\\", \\\"{x:1480,y:345,t:1527030387179};\\\", \\\"{x:1481,y:355,t:1527030387195};\\\", \\\"{x:1481,y:363,t:1527030387211};\\\", \\\"{x:1481,y:369,t:1527030387229};\\\", \\\"{x:1481,y:378,t:1527030387245};\\\", \\\"{x:1481,y:388,t:1527030387261};\\\", \\\"{x:1481,y:399,t:1527030387278};\\\", \\\"{x:1481,y:414,t:1527030387295};\\\", \\\"{x:1481,y:432,t:1527030387311};\\\", \\\"{x:1481,y:447,t:1527030387329};\\\", \\\"{x:1479,y:460,t:1527030387346};\\\", \\\"{x:1478,y:477,t:1527030387362};\\\", \\\"{x:1478,y:494,t:1527030387378};\\\", \\\"{x:1478,y:523,t:1527030387395};\\\", \\\"{x:1478,y:538,t:1527030387412};\\\", \\\"{x:1478,y:550,t:1527030387429};\\\", \\\"{x:1478,y:558,t:1527030387445};\\\", \\\"{x:1478,y:564,t:1527030387463};\\\", \\\"{x:1478,y:571,t:1527030387479};\\\", \\\"{x:1478,y:583,t:1527030387496};\\\", \\\"{x:1475,y:595,t:1527030387513};\\\", \\\"{x:1470,y:612,t:1527030387528};\\\", \\\"{x:1467,y:631,t:1527030387546};\\\", \\\"{x:1464,y:650,t:1527030387562};\\\", \\\"{x:1462,y:669,t:1527030387579};\\\", \\\"{x:1459,y:689,t:1527030387596};\\\", \\\"{x:1459,y:698,t:1527030387613};\\\", \\\"{x:1459,y:710,t:1527030387629};\\\", \\\"{x:1459,y:721,t:1527030387645};\\\", \\\"{x:1459,y:728,t:1527030387663};\\\", \\\"{x:1459,y:734,t:1527030387679};\\\", \\\"{x:1459,y:738,t:1527030387696};\\\", \\\"{x:1459,y:740,t:1527030387713};\\\", \\\"{x:1459,y:742,t:1527030387729};\\\", \\\"{x:1459,y:744,t:1527030387746};\\\", \\\"{x:1459,y:746,t:1527030387763};\\\", \\\"{x:1459,y:747,t:1527030387779};\\\", \\\"{x:1459,y:748,t:1527030387820};\\\", \\\"{x:1460,y:748,t:1527030387852};\\\", \\\"{x:1462,y:748,t:1527030387868};\\\", \\\"{x:1463,y:748,t:1527030387880};\\\", \\\"{x:1465,y:748,t:1527030387896};\\\", \\\"{x:1468,y:747,t:1527030387913};\\\", \\\"{x:1470,y:745,t:1527030387931};\\\", \\\"{x:1472,y:742,t:1527030387946};\\\", \\\"{x:1473,y:739,t:1527030387963};\\\", \\\"{x:1474,y:732,t:1527030387980};\\\", \\\"{x:1477,y:726,t:1527030387996};\\\", \\\"{x:1478,y:725,t:1527030388013};\\\", \\\"{x:1478,y:724,t:1527030388030};\\\", \\\"{x:1478,y:729,t:1527030388116};\\\", \\\"{x:1480,y:738,t:1527030388131};\\\", \\\"{x:1483,y:756,t:1527030388145};\\\", \\\"{x:1486,y:777,t:1527030388162};\\\", \\\"{x:1488,y:803,t:1527030388179};\\\", \\\"{x:1489,y:817,t:1527030388195};\\\", \\\"{x:1491,y:831,t:1527030388212};\\\", \\\"{x:1493,y:842,t:1527030388229};\\\", \\\"{x:1497,y:859,t:1527030388245};\\\", \\\"{x:1499,y:873,t:1527030388262};\\\", \\\"{x:1499,y:880,t:1527030388279};\\\", \\\"{x:1499,y:883,t:1527030388296};\\\", \\\"{x:1499,y:884,t:1527030388312};\\\", \\\"{x:1499,y:885,t:1527030388330};\\\", \\\"{x:1499,y:887,t:1527030388347};\\\", \\\"{x:1498,y:889,t:1527030388363};\\\", \\\"{x:1498,y:891,t:1527030388379};\\\", \\\"{x:1494,y:896,t:1527030388397};\\\", \\\"{x:1492,y:902,t:1527030388412};\\\", \\\"{x:1490,y:907,t:1527030388429};\\\", \\\"{x:1488,y:912,t:1527030388447};\\\", \\\"{x:1487,y:914,t:1527030388462};\\\", \\\"{x:1487,y:917,t:1527030388479};\\\", \\\"{x:1481,y:931,t:1527030388496};\\\", \\\"{x:1476,y:953,t:1527030388512};\\\", \\\"{x:1471,y:972,t:1527030388530};\\\", \\\"{x:1468,y:983,t:1527030388546};\\\", \\\"{x:1467,y:988,t:1527030388563};\\\", \\\"{x:1467,y:989,t:1527030388595};\\\", \\\"{x:1467,y:990,t:1527030388651};\\\", \\\"{x:1468,y:990,t:1527030388662};\\\", \\\"{x:1469,y:990,t:1527030388680};\\\", \\\"{x:1470,y:990,t:1527030388696};\\\", \\\"{x:1470,y:991,t:1527030388715};\\\", \\\"{x:1471,y:991,t:1527030388780};\\\", \\\"{x:1470,y:991,t:1527030388875};\\\", \\\"{x:1469,y:991,t:1527030388883};\\\", \\\"{x:1466,y:991,t:1527030388896};\\\", \\\"{x:1465,y:991,t:1527030388913};\\\", \\\"{x:1465,y:989,t:1527030390637};\\\", \\\"{x:1464,y:988,t:1527030390648};\\\", \\\"{x:1464,y:986,t:1527030390665};\\\", \\\"{x:1463,y:983,t:1527030390682};\\\", \\\"{x:1462,y:982,t:1527030391996};\\\", \\\"{x:1459,y:982,t:1527030392004};\\\", \\\"{x:1449,y:981,t:1527030392016};\\\", \\\"{x:1416,y:976,t:1527030392032};\\\", \\\"{x:1347,y:969,t:1527030392050};\\\", \\\"{x:1238,y:951,t:1527030392066};\\\", \\\"{x:1097,y:929,t:1527030392082};\\\", \\\"{x:921,y:884,t:1527030392100};\\\", \\\"{x:632,y:811,t:1527030392115};\\\", \\\"{x:454,y:782,t:1527030392133};\\\", \\\"{x:310,y:760,t:1527030392149};\\\", \\\"{x:221,y:756,t:1527030392166};\\\", \\\"{x:178,y:756,t:1527030392182};\\\", \\\"{x:161,y:758,t:1527030392199};\\\", \\\"{x:158,y:758,t:1527030392216};\\\", \\\"{x:159,y:758,t:1527030392244};\\\", \\\"{x:161,y:758,t:1527030392252};\\\", \\\"{x:163,y:758,t:1527030392266};\\\", \\\"{x:173,y:756,t:1527030392283};\\\", \\\"{x:223,y:736,t:1527030392299};\\\", \\\"{x:303,y:677,t:1527030392315};\\\", \\\"{x:316,y:659,t:1527030392333};\\\", \\\"{x:320,y:654,t:1527030392349};\\\", \\\"{x:323,y:654,t:1527030392366};\\\", \\\"{x:335,y:654,t:1527030392383};\\\", \\\"{x:357,y:670,t:1527030392399};\\\", \\\"{x:399,y:690,t:1527030392416};\\\", \\\"{x:455,y:706,t:1527030392434};\\\", \\\"{x:524,y:715,t:1527030392448};\\\", \\\"{x:589,y:718,t:1527030392466};\\\", \\\"{x:632,y:718,t:1527030392483};\\\", \\\"{x:633,y:718,t:1527030392500};\\\", \\\"{x:632,y:719,t:1527030392644};\\\", \\\"{x:632,y:720,t:1527030392651};\\\", \\\"{x:629,y:721,t:1527030392667};\\\", \\\"{x:615,y:727,t:1527030392684};\\\", \\\"{x:596,y:729,t:1527030392701};\\\", \\\"{x:579,y:729,t:1527030392717};\\\", \\\"{x:568,y:729,t:1527030392734};\\\", \\\"{x:563,y:729,t:1527030392752};\\\", \\\"{x:562,y:729,t:1527030392859};\\\", \\\"{x:561,y:729,t:1527030392875};\\\", \\\"{x:560,y:729,t:1527030392899};\\\", \\\"{x:559,y:729,t:1527030392907};\\\", \\\"{x:558,y:729,t:1527030392918};\\\", \\\"{x:555,y:728,t:1527030392935};\\\", \\\"{x:554,y:728,t:1527030392951};\\\", \\\"{x:552,y:728,t:1527030392968};\\\", \\\"{x:550,y:728,t:1527030392995};\\\", \\\"{x:548,y:727,t:1527030393004};\\\", \\\"{x:545,y:726,t:1527030393018};\\\", \\\"{x:542,y:725,t:1527030393035};\\\" ] }, { \\\"rt\\\": 20116, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 370560, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -01 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:724,t:1527030395138};\\\", \\\"{x:542,y:720,t:1527030395827};\\\", \\\"{x:545,y:714,t:1527030395837};\\\", \\\"{x:551,y:704,t:1527030395854};\\\", \\\"{x:556,y:693,t:1527030395873};\\\", \\\"{x:559,y:683,t:1527030395886};\\\", \\\"{x:566,y:668,t:1527030395903};\\\", \\\"{x:569,y:659,t:1527030395918};\\\", \\\"{x:572,y:648,t:1527030395936};\\\", \\\"{x:575,y:641,t:1527030395953};\\\", \\\"{x:576,y:633,t:1527030395970};\\\", \\\"{x:579,y:627,t:1527030395986};\\\", \\\"{x:579,y:621,t:1527030396002};\\\", \\\"{x:580,y:612,t:1527030396020};\\\", \\\"{x:580,y:611,t:1527030396037};\\\", \\\"{x:580,y:609,t:1527030396052};\\\", \\\"{x:580,y:608,t:1527030396069};\\\", \\\"{x:580,y:607,t:1527030396087};\\\", \\\"{x:580,y:606,t:1527030396102};\\\", \\\"{x:580,y:605,t:1527030396156};\\\", \\\"{x:580,y:604,t:1527030396170};\\\", \\\"{x:580,y:603,t:1527030396187};\\\", \\\"{x:580,y:602,t:1527030396203};\\\", \\\"{x:580,y:600,t:1527030396220};\\\", \\\"{x:580,y:598,t:1527030396236};\\\", \\\"{x:580,y:597,t:1527030396260};\\\", \\\"{x:580,y:595,t:1527030396283};\\\", \\\"{x:579,y:595,t:1527030396299};\\\", \\\"{x:579,y:594,t:1527030396308};\\\", \\\"{x:578,y:593,t:1527030396324};\\\", \\\"{x:578,y:592,t:1527030396339};\\\", \\\"{x:578,y:591,t:1527030396354};\\\", \\\"{x:575,y:587,t:1527030396370};\\\", \\\"{x:573,y:585,t:1527030396387};\\\", \\\"{x:568,y:579,t:1527030396405};\\\", \\\"{x:564,y:574,t:1527030396420};\\\", \\\"{x:561,y:570,t:1527030396436};\\\", \\\"{x:559,y:567,t:1527030396454};\\\", \\\"{x:558,y:566,t:1527030396469};\\\", \\\"{x:557,y:564,t:1527030396486};\\\", \\\"{x:557,y:560,t:1527030396504};\\\", \\\"{x:557,y:553,t:1527030396519};\\\", \\\"{x:557,y:549,t:1527030396537};\\\", \\\"{x:557,y:541,t:1527030396555};\\\", \\\"{x:557,y:535,t:1527030396571};\\\", \\\"{x:558,y:526,t:1527030396587};\\\", \\\"{x:559,y:517,t:1527030396603};\\\", \\\"{x:559,y:512,t:1527030396619};\\\", \\\"{x:561,y:510,t:1527030396637};\\\", \\\"{x:561,y:506,t:1527030396652};\\\", \\\"{x:561,y:504,t:1527030396671};\\\", \\\"{x:561,y:503,t:1527030396708};\\\", \\\"{x:561,y:502,t:1527030396731};\\\", \\\"{x:562,y:502,t:1527030396748};\\\", \\\"{x:562,y:501,t:1527030396892};\\\", \\\"{x:562,y:500,t:1527030396916};\\\", \\\"{x:562,y:499,t:1527030396932};\\\", \\\"{x:563,y:499,t:1527030396939};\\\", \\\"{x:563,y:498,t:1527030396953};\\\", \\\"{x:564,y:496,t:1527030396969};\\\", \\\"{x:565,y:496,t:1527030396986};\\\", \\\"{x:566,y:495,t:1527030397002};\\\", \\\"{x:567,y:493,t:1527030397019};\\\", \\\"{x:569,y:491,t:1527030397036};\\\", \\\"{x:570,y:491,t:1527030397060};\\\", \\\"{x:570,y:490,t:1527030397068};\\\", \\\"{x:572,y:489,t:1527030397086};\\\", \\\"{x:574,y:488,t:1527030397102};\\\", \\\"{x:576,y:488,t:1527030397118};\\\", \\\"{x:577,y:488,t:1527030397136};\\\", \\\"{x:577,y:487,t:1527030397152};\\\", \\\"{x:579,y:487,t:1527030397169};\\\", \\\"{x:579,y:486,t:1527030397187};\\\", \\\"{x:580,y:486,t:1527030397204};\\\", \\\"{x:582,y:485,t:1527030397219};\\\", \\\"{x:584,y:484,t:1527030397236};\\\", \\\"{x:587,y:484,t:1527030397252};\\\", \\\"{x:590,y:483,t:1527030397269};\\\", \\\"{x:597,y:481,t:1527030397285};\\\", \\\"{x:604,y:481,t:1527030397302};\\\", \\\"{x:609,y:480,t:1527030397318};\\\", \\\"{x:612,y:480,t:1527030397335};\\\", \\\"{x:613,y:479,t:1527030397352};\\\", \\\"{x:617,y:479,t:1527030397563};\\\", \\\"{x:627,y:479,t:1527030397571};\\\", \\\"{x:636,y:479,t:1527030397584};\\\", \\\"{x:660,y:479,t:1527030397601};\\\", \\\"{x:690,y:484,t:1527030397618};\\\", \\\"{x:741,y:493,t:1527030397634};\\\", \\\"{x:842,y:516,t:1527030397653};\\\", \\\"{x:917,y:536,t:1527030397667};\\\", \\\"{x:994,y:554,t:1527030397688};\\\", \\\"{x:1072,y:578,t:1527030397705};\\\", \\\"{x:1150,y:601,t:1527030397721};\\\", \\\"{x:1222,y:624,t:1527030397738};\\\", \\\"{x:1297,y:653,t:1527030397755};\\\", \\\"{x:1334,y:670,t:1527030397771};\\\", \\\"{x:1349,y:680,t:1527030397788};\\\", \\\"{x:1363,y:691,t:1527030397805};\\\", \\\"{x:1373,y:702,t:1527030397821};\\\", \\\"{x:1389,y:720,t:1527030397838};\\\", \\\"{x:1408,y:745,t:1527030397855};\\\", \\\"{x:1437,y:792,t:1527030397871};\\\", \\\"{x:1469,y:844,t:1527030397888};\\\", \\\"{x:1485,y:869,t:1527030397905};\\\", \\\"{x:1495,y:884,t:1527030397921};\\\", \\\"{x:1501,y:892,t:1527030397938};\\\", \\\"{x:1503,y:898,t:1527030397955};\\\", \\\"{x:1504,y:899,t:1527030397971};\\\", \\\"{x:1504,y:900,t:1527030397988};\\\", \\\"{x:1504,y:899,t:1527030398052};\\\", \\\"{x:1505,y:895,t:1527030398059};\\\", \\\"{x:1506,y:888,t:1527030398071};\\\", \\\"{x:1509,y:875,t:1527030398089};\\\", \\\"{x:1509,y:871,t:1527030398105};\\\", \\\"{x:1509,y:859,t:1527030398121};\\\", \\\"{x:1509,y:840,t:1527030398138};\\\", \\\"{x:1510,y:824,t:1527030398155};\\\", \\\"{x:1510,y:823,t:1527030398173};\\\", \\\"{x:1510,y:812,t:1527030398189};\\\", \\\"{x:1516,y:790,t:1527030398205};\\\", \\\"{x:1523,y:770,t:1527030398222};\\\", \\\"{x:1526,y:761,t:1527030398238};\\\", \\\"{x:1528,y:753,t:1527030398255};\\\", \\\"{x:1529,y:749,t:1527030398272};\\\", \\\"{x:1529,y:747,t:1527030398289};\\\", \\\"{x:1529,y:746,t:1527030398305};\\\", \\\"{x:1529,y:745,t:1527030398371};\\\", \\\"{x:1529,y:744,t:1527030398388};\\\", \\\"{x:1529,y:743,t:1527030398405};\\\", \\\"{x:1529,y:737,t:1527030398422};\\\", \\\"{x:1530,y:727,t:1527030398438};\\\", \\\"{x:1533,y:719,t:1527030398454};\\\", \\\"{x:1536,y:711,t:1527030398472};\\\", \\\"{x:1542,y:703,t:1527030398488};\\\", \\\"{x:1546,y:696,t:1527030398505};\\\", \\\"{x:1554,y:686,t:1527030398522};\\\", \\\"{x:1559,y:680,t:1527030398539};\\\", \\\"{x:1561,y:675,t:1527030398555};\\\", \\\"{x:1563,y:671,t:1527030398572};\\\", \\\"{x:1564,y:669,t:1527030398589};\\\", \\\"{x:1567,y:668,t:1527030398606};\\\", \\\"{x:1569,y:668,t:1527030398622};\\\", \\\"{x:1569,y:666,t:1527030399364};\\\", \\\"{x:1569,y:664,t:1527030399372};\\\", \\\"{x:1569,y:662,t:1527030399390};\\\", \\\"{x:1569,y:660,t:1527030399407};\\\", \\\"{x:1569,y:657,t:1527030399422};\\\", \\\"{x:1569,y:652,t:1527030399439};\\\", \\\"{x:1570,y:643,t:1527030399456};\\\", \\\"{x:1575,y:625,t:1527030399473};\\\", \\\"{x:1581,y:601,t:1527030399490};\\\", \\\"{x:1590,y:572,t:1527030399507};\\\", \\\"{x:1609,y:518,t:1527030399524};\\\", \\\"{x:1618,y:488,t:1527030399539};\\\", \\\"{x:1625,y:457,t:1527030399556};\\\", \\\"{x:1630,y:429,t:1527030399573};\\\", \\\"{x:1631,y:408,t:1527030399590};\\\", \\\"{x:1631,y:400,t:1527030399606};\\\", \\\"{x:1632,y:398,t:1527030399623};\\\", \\\"{x:1633,y:396,t:1527030399639};\\\", \\\"{x:1631,y:396,t:1527030399756};\\\", \\\"{x:1627,y:403,t:1527030399774};\\\", \\\"{x:1625,y:407,t:1527030399790};\\\", \\\"{x:1623,y:412,t:1527030399806};\\\", \\\"{x:1621,y:416,t:1527030399823};\\\", \\\"{x:1620,y:419,t:1527030399840};\\\", \\\"{x:1620,y:421,t:1527030399856};\\\", \\\"{x:1620,y:422,t:1527030399873};\\\", \\\"{x:1620,y:424,t:1527030399892};\\\", \\\"{x:1620,y:425,t:1527030399908};\\\", \\\"{x:1620,y:428,t:1527030399927};\\\", \\\"{x:1620,y:429,t:1527030399939};\\\", \\\"{x:1620,y:430,t:1527030400019};\\\", \\\"{x:1620,y:431,t:1527030400035};\\\", \\\"{x:1620,y:432,t:1527030400052};\\\", \\\"{x:1620,y:433,t:1527030400067};\\\", \\\"{x:1618,y:434,t:1527030400075};\\\", \\\"{x:1618,y:437,t:1527030400106};\\\", \\\"{x:1616,y:446,t:1527030400123};\\\", \\\"{x:1614,y:449,t:1527030400140};\\\", \\\"{x:1613,y:457,t:1527030400156};\\\", \\\"{x:1609,y:474,t:1527030400173};\\\", \\\"{x:1605,y:509,t:1527030400190};\\\", \\\"{x:1600,y:551,t:1527030400206};\\\", \\\"{x:1595,y:577,t:1527030400223};\\\", \\\"{x:1594,y:587,t:1527030400240};\\\", \\\"{x:1594,y:589,t:1527030400256};\\\", \\\"{x:1594,y:590,t:1527030400273};\\\", \\\"{x:1594,y:591,t:1527030400290};\\\", \\\"{x:1594,y:593,t:1527030400307};\\\", \\\"{x:1594,y:594,t:1527030400331};\\\", \\\"{x:1596,y:595,t:1527030400355};\\\", \\\"{x:1596,y:596,t:1527030400380};\\\", \\\"{x:1598,y:596,t:1527030400429};\\\", \\\"{x:1599,y:596,t:1527030400440};\\\", \\\"{x:1603,y:594,t:1527030400457};\\\", \\\"{x:1603,y:591,t:1527030400473};\\\", \\\"{x:1605,y:588,t:1527030400490};\\\", \\\"{x:1606,y:586,t:1527030400508};\\\", \\\"{x:1606,y:584,t:1527030400524};\\\", \\\"{x:1607,y:584,t:1527030400541};\\\", \\\"{x:1607,y:583,t:1527030400564};\\\", \\\"{x:1607,y:584,t:1527030400820};\\\", \\\"{x:1607,y:586,t:1527030400827};\\\", \\\"{x:1607,y:589,t:1527030400840};\\\", \\\"{x:1609,y:592,t:1527030400857};\\\", \\\"{x:1609,y:597,t:1527030400875};\\\", \\\"{x:1612,y:608,t:1527030400890};\\\", \\\"{x:1615,y:619,t:1527030400907};\\\", \\\"{x:1617,y:625,t:1527030400924};\\\", \\\"{x:1617,y:630,t:1527030400941};\\\", \\\"{x:1617,y:631,t:1527030400957};\\\", \\\"{x:1618,y:632,t:1527030401020};\\\", \\\"{x:1618,y:633,t:1527030401043};\\\", \\\"{x:1618,y:634,t:1527030401068};\\\", \\\"{x:1618,y:636,t:1527030401076};\\\", \\\"{x:1618,y:637,t:1527030401090};\\\", \\\"{x:1618,y:642,t:1527030401107};\\\", \\\"{x:1618,y:647,t:1527030401124};\\\", \\\"{x:1619,y:661,t:1527030401140};\\\", \\\"{x:1620,y:671,t:1527030401157};\\\", \\\"{x:1623,y:680,t:1527030401175};\\\", \\\"{x:1623,y:687,t:1527030401191};\\\", \\\"{x:1623,y:694,t:1527030401208};\\\", \\\"{x:1623,y:703,t:1527030401224};\\\", \\\"{x:1623,y:709,t:1527030401241};\\\", \\\"{x:1623,y:716,t:1527030401257};\\\", \\\"{x:1622,y:722,t:1527030401275};\\\", \\\"{x:1621,y:731,t:1527030401292};\\\", \\\"{x:1621,y:734,t:1527030401308};\\\", \\\"{x:1621,y:736,t:1527030401324};\\\", \\\"{x:1621,y:738,t:1527030401341};\\\", \\\"{x:1621,y:741,t:1527030401357};\\\", \\\"{x:1621,y:744,t:1527030401375};\\\", \\\"{x:1621,y:748,t:1527030401392};\\\", \\\"{x:1621,y:751,t:1527030401407};\\\", \\\"{x:1619,y:755,t:1527030401424};\\\", \\\"{x:1619,y:757,t:1527030401441};\\\", \\\"{x:1619,y:761,t:1527030401458};\\\", \\\"{x:1619,y:765,t:1527030401474};\\\", \\\"{x:1618,y:781,t:1527030401491};\\\", \\\"{x:1615,y:792,t:1527030401507};\\\", \\\"{x:1612,y:804,t:1527030401525};\\\", \\\"{x:1610,y:814,t:1527030401541};\\\", \\\"{x:1609,y:820,t:1527030401558};\\\", \\\"{x:1608,y:826,t:1527030401574};\\\", \\\"{x:1608,y:829,t:1527030401592};\\\", \\\"{x:1608,y:833,t:1527030401608};\\\", \\\"{x:1608,y:836,t:1527030401625};\\\", \\\"{x:1608,y:841,t:1527030401642};\\\", \\\"{x:1605,y:846,t:1527030401657};\\\", \\\"{x:1605,y:850,t:1527030401675};\\\", \\\"{x:1601,y:857,t:1527030401691};\\\", \\\"{x:1598,y:865,t:1527030401708};\\\", \\\"{x:1593,y:875,t:1527030401724};\\\", \\\"{x:1587,y:886,t:1527030401742};\\\", \\\"{x:1584,y:891,t:1527030401758};\\\", \\\"{x:1578,y:900,t:1527030401775};\\\", \\\"{x:1574,y:905,t:1527030401792};\\\", \\\"{x:1573,y:907,t:1527030401808};\\\", \\\"{x:1571,y:909,t:1527030401828};\\\", \\\"{x:1571,y:910,t:1527030401844};\\\", \\\"{x:1571,y:911,t:1527030401860};\\\", \\\"{x:1570,y:911,t:1527030401874};\\\", \\\"{x:1567,y:914,t:1527030401891};\\\", \\\"{x:1557,y:921,t:1527030401908};\\\", \\\"{x:1527,y:921,t:1527030401925};\\\", \\\"{x:1474,y:921,t:1527030401941};\\\", \\\"{x:1419,y:917,t:1527030401958};\\\", \\\"{x:1376,y:914,t:1527030401974};\\\", \\\"{x:1332,y:910,t:1527030401992};\\\", \\\"{x:1285,y:905,t:1527030402009};\\\", \\\"{x:1232,y:899,t:1527030402025};\\\", \\\"{x:1179,y:891,t:1527030402041};\\\", \\\"{x:1123,y:883,t:1527030402058};\\\", \\\"{x:1042,y:874,t:1527030402076};\\\", \\\"{x:979,y:862,t:1527030402092};\\\", \\\"{x:912,y:850,t:1527030402108};\\\", \\\"{x:830,y:831,t:1527030402125};\\\", \\\"{x:741,y:804,t:1527030402142};\\\", \\\"{x:661,y:787,t:1527030402159};\\\", \\\"{x:601,y:774,t:1527030402175};\\\", \\\"{x:541,y:750,t:1527030402191};\\\", \\\"{x:493,y:726,t:1527030402210};\\\", \\\"{x:462,y:706,t:1527030402225};\\\", \\\"{x:443,y:690,t:1527030402241};\\\", \\\"{x:430,y:679,t:1527030402253};\\\", \\\"{x:412,y:666,t:1527030402269};\\\", \\\"{x:400,y:657,t:1527030402286};\\\", \\\"{x:390,y:651,t:1527030402303};\\\", \\\"{x:379,y:644,t:1527030402320};\\\", \\\"{x:365,y:636,t:1527030402337};\\\", \\\"{x:352,y:631,t:1527030402358};\\\", \\\"{x:351,y:631,t:1527030402375};\\\", \\\"{x:351,y:630,t:1527030402410};\\\", \\\"{x:351,y:627,t:1527030402427};\\\", \\\"{x:351,y:623,t:1527030402441};\\\", \\\"{x:356,y:609,t:1527030402460};\\\", \\\"{x:358,y:603,t:1527030402474};\\\", \\\"{x:360,y:594,t:1527030402492};\\\", \\\"{x:361,y:591,t:1527030402507};\\\", \\\"{x:361,y:589,t:1527030402524};\\\", \\\"{x:361,y:588,t:1527030402619};\\\", \\\"{x:358,y:588,t:1527030402635};\\\", \\\"{x:355,y:587,t:1527030402643};\\\", \\\"{x:353,y:586,t:1527030402657};\\\", \\\"{x:343,y:585,t:1527030402674};\\\", \\\"{x:335,y:584,t:1527030402692};\\\", \\\"{x:324,y:580,t:1527030402709};\\\", \\\"{x:310,y:577,t:1527030402725};\\\", \\\"{x:297,y:575,t:1527030402742};\\\", \\\"{x:283,y:574,t:1527030402758};\\\", \\\"{x:268,y:572,t:1527030402776};\\\", \\\"{x:258,y:572,t:1527030402792};\\\", \\\"{x:254,y:570,t:1527030402808};\\\", \\\"{x:253,y:570,t:1527030402825};\\\", \\\"{x:252,y:570,t:1527030402842};\\\", \\\"{x:248,y:570,t:1527030402859};\\\", \\\"{x:242,y:570,t:1527030402875};\\\", \\\"{x:237,y:570,t:1527030402892};\\\", \\\"{x:231,y:571,t:1527030402909};\\\", \\\"{x:228,y:571,t:1527030402925};\\\", \\\"{x:225,y:573,t:1527030402943};\\\", \\\"{x:223,y:575,t:1527030402960};\\\", \\\"{x:220,y:578,t:1527030402975};\\\", \\\"{x:219,y:580,t:1527030402992};\\\", \\\"{x:218,y:583,t:1527030403009};\\\", \\\"{x:217,y:589,t:1527030403025};\\\", \\\"{x:215,y:601,t:1527030403041};\\\", \\\"{x:212,y:616,t:1527030403058};\\\", \\\"{x:212,y:622,t:1527030403075};\\\", \\\"{x:211,y:624,t:1527030403092};\\\", \\\"{x:211,y:626,t:1527030403108};\\\", \\\"{x:211,y:627,t:1527030403130};\\\", \\\"{x:210,y:627,t:1527030403146};\\\", \\\"{x:208,y:628,t:1527030403162};\\\", \\\"{x:205,y:630,t:1527030403178};\\\", \\\"{x:202,y:630,t:1527030403192};\\\", \\\"{x:193,y:632,t:1527030403209};\\\", \\\"{x:187,y:633,t:1527030403225};\\\", \\\"{x:183,y:633,t:1527030403242};\\\", \\\"{x:181,y:633,t:1527030403258};\\\", \\\"{x:174,y:633,t:1527030403275};\\\", \\\"{x:166,y:633,t:1527030403292};\\\", \\\"{x:163,y:633,t:1527030403308};\\\", \\\"{x:160,y:633,t:1527030403324};\\\", \\\"{x:160,y:634,t:1527030403342};\\\", \\\"{x:165,y:634,t:1527030403619};\\\", \\\"{x:182,y:634,t:1527030403627};\\\", \\\"{x:201,y:634,t:1527030403642};\\\", \\\"{x:318,y:636,t:1527030403659};\\\", \\\"{x:404,y:643,t:1527030403676};\\\", \\\"{x:467,y:660,t:1527030403693};\\\", \\\"{x:506,y:675,t:1527030403709};\\\", \\\"{x:523,y:684,t:1527030403726};\\\", \\\"{x:533,y:691,t:1527030403742};\\\", \\\"{x:538,y:696,t:1527030403759};\\\", \\\"{x:540,y:698,t:1527030403776};\\\", \\\"{x:540,y:699,t:1527030403811};\\\", \\\"{x:542,y:699,t:1527030403988};\\\", \\\"{x:542,y:700,t:1527030403995};\\\", \\\"{x:543,y:701,t:1527030404011};\\\", \\\"{x:543,y:702,t:1527030404026};\\\", \\\"{x:544,y:704,t:1527030404043};\\\", \\\"{x:544,y:706,t:1527030404060};\\\", \\\"{x:544,y:707,t:1527030404076};\\\", \\\"{x:544,y:709,t:1527030404092};\\\", \\\"{x:544,y:711,t:1527030404110};\\\", \\\"{x:544,y:712,t:1527030404130};\\\", \\\"{x:544,y:713,t:1527030404147};\\\", \\\"{x:544,y:715,t:1527030404179};\\\", \\\"{x:543,y:715,t:1527030404192};\\\", \\\"{x:543,y:716,t:1527030404210};\\\", \\\"{x:543,y:717,t:1527030404235};\\\", \\\"{x:543,y:718,t:1527030404767};\\\", \\\"{x:544,y:718,t:1527030405647};\\\", \\\"{x:545,y:718,t:1527030405703};\\\", \\\"{x:546,y:718,t:1527030407087};\\\", \\\"{x:549,y:718,t:1527030407095};\\\", \\\"{x:556,y:722,t:1527030407107};\\\", \\\"{x:594,y:740,t:1527030407125};\\\", \\\"{x:684,y:773,t:1527030407139};\\\", \\\"{x:813,y:824,t:1527030407156};\\\", \\\"{x:878,y:850,t:1527030407165};\\\", \\\"{x:1020,y:901,t:1527030407181};\\\", \\\"{x:1219,y:956,t:1527030407198};\\\", \\\"{x:1342,y:986,t:1527030407215};\\\", \\\"{x:1426,y:999,t:1527030407231};\\\", \\\"{x:1459,y:1004,t:1527030407248};\\\", \\\"{x:1465,y:1004,t:1527030407265};\\\", \\\"{x:1462,y:1004,t:1527030407294};\\\", \\\"{x:1456,y:1002,t:1527030407302};\\\", \\\"{x:1451,y:1001,t:1527030407315};\\\", \\\"{x:1441,y:997,t:1527030407331};\\\", \\\"{x:1428,y:995,t:1527030407348};\\\", \\\"{x:1411,y:990,t:1527030407365};\\\", \\\"{x:1383,y:986,t:1527030407382};\\\", \\\"{x:1371,y:985,t:1527030407398};\\\", \\\"{x:1365,y:985,t:1527030407415};\\\", \\\"{x:1364,y:985,t:1527030407433};\\\", \\\"{x:1363,y:985,t:1527030407449};\\\", \\\"{x:1363,y:986,t:1527030407471};\\\", \\\"{x:1364,y:988,t:1527030407483};\\\", \\\"{x:1371,y:991,t:1527030407499};\\\", \\\"{x:1377,y:996,t:1527030407516};\\\", \\\"{x:1385,y:1004,t:1527030407533};\\\", \\\"{x:1392,y:1009,t:1527030407549};\\\", \\\"{x:1403,y:1017,t:1527030407566};\\\", \\\"{x:1424,y:1030,t:1527030407583};\\\", \\\"{x:1434,y:1035,t:1527030407598};\\\", \\\"{x:1437,y:1037,t:1527030407616};\\\", \\\"{x:1441,y:1039,t:1527030407632};\\\", \\\"{x:1442,y:1040,t:1527030407649};\\\", \\\"{x:1443,y:1041,t:1527030407671};\\\", \\\"{x:1442,y:1041,t:1527030407815};\\\", \\\"{x:1441,y:1041,t:1527030407832};\\\", \\\"{x:1439,y:1041,t:1527030407849};\\\", \\\"{x:1438,y:1041,t:1527030407865};\\\", \\\"{x:1435,y:1041,t:1527030407882};\\\", \\\"{x:1434,y:1041,t:1527030407902};\\\", \\\"{x:1434,y:1040,t:1527030407916};\\\", \\\"{x:1433,y:1040,t:1527030407932};\\\", \\\"{x:1432,y:1040,t:1527030407949};\\\", \\\"{x:1430,y:1039,t:1527030407965};\\\", \\\"{x:1428,y:1039,t:1527030407990};\\\", \\\"{x:1428,y:1038,t:1527030408000};\\\", \\\"{x:1427,y:1038,t:1527030408015};\\\", \\\"{x:1426,y:1037,t:1527030408033};\\\", \\\"{x:1425,y:1037,t:1527030408054};\\\", \\\"{x:1424,y:1037,t:1527030408066};\\\", \\\"{x:1423,y:1036,t:1527030408103};\\\", \\\"{x:1422,y:1036,t:1527030408143};\\\", \\\"{x:1420,y:1035,t:1527030408151};\\\", \\\"{x:1419,y:1034,t:1527030408166};\\\", \\\"{x:1420,y:1034,t:1527030408430};\\\", \\\"{x:1422,y:1034,t:1527030408437};\\\", \\\"{x:1425,y:1034,t:1527030408450};\\\", \\\"{x:1433,y:1034,t:1527030408466};\\\", \\\"{x:1440,y:1034,t:1527030408482};\\\", \\\"{x:1449,y:1034,t:1527030408499};\\\", \\\"{x:1458,y:1034,t:1527030408517};\\\", \\\"{x:1467,y:1034,t:1527030408533};\\\", \\\"{x:1475,y:1034,t:1527030408549};\\\", \\\"{x:1478,y:1034,t:1527030408566};\\\", \\\"{x:1480,y:1034,t:1527030408631};\\\", \\\"{x:1482,y:1034,t:1527030408647};\\\", \\\"{x:1485,y:1034,t:1527030408654};\\\", \\\"{x:1487,y:1034,t:1527030408670};\\\", \\\"{x:1488,y:1034,t:1527030408686};\\\", \\\"{x:1490,y:1034,t:1527030408718};\\\", \\\"{x:1491,y:1034,t:1527030408742};\\\", \\\"{x:1491,y:1035,t:1527030408750};\\\", \\\"{x:1491,y:1035,t:1527030408871};\\\", \\\"{x:1492,y:1035,t:1527030408893};\\\", \\\"{x:1491,y:1035,t:1527030408942};\\\", \\\"{x:1490,y:1035,t:1527030408966};\\\", \\\"{x:1489,y:1035,t:1527030408982};\\\", \\\"{x:1488,y:1035,t:1527030408989};\\\", \\\"{x:1487,y:1036,t:1527030409014};\\\", \\\"{x:1488,y:1036,t:1527030409118};\\\", \\\"{x:1490,y:1036,t:1527030409133};\\\", \\\"{x:1491,y:1036,t:1527030409150};\\\", \\\"{x:1493,y:1036,t:1527030409167};\\\", \\\"{x:1494,y:1036,t:1527030409190};\\\", \\\"{x:1495,y:1036,t:1527030409287};\\\", \\\"{x:1496,y:1036,t:1527030409295};\\\", \\\"{x:1499,y:1034,t:1527030409318};\\\", \\\"{x:1500,y:1033,t:1527030409335};\\\", \\\"{x:1500,y:1033,t:1527030409399};\\\", \\\"{x:1498,y:1033,t:1527030409469};\\\", \\\"{x:1496,y:1033,t:1527030409486};\\\", \\\"{x:1494,y:1034,t:1527030409502};\\\", \\\"{x:1491,y:1035,t:1527030409518};\\\", \\\"{x:1487,y:1036,t:1527030409534};\\\", \\\"{x:1485,y:1037,t:1527030409552};\\\", \\\"{x:1484,y:1038,t:1527030409567};\\\", \\\"{x:1482,y:1041,t:1527030409584};\\\", \\\"{x:1479,y:1045,t:1527030409601};\\\", \\\"{x:1477,y:1047,t:1527030409618};\\\", \\\"{x:1474,y:1050,t:1527030409635};\\\", \\\"{x:1472,y:1052,t:1527030409651};\\\", \\\"{x:1470,y:1054,t:1527030409669};\\\", \\\"{x:1469,y:1056,t:1527030409684};\\\", \\\"{x:1469,y:1057,t:1527030409701};\\\", \\\"{x:1468,y:1058,t:1527030409718};\\\", \\\"{x:1468,y:1060,t:1527030410487};\\\", \\\"{x:1468,y:1062,t:1527030410502};\\\", \\\"{x:1469,y:1066,t:1527030410518};\\\", \\\"{x:1471,y:1066,t:1527030410535};\\\", \\\"{x:1471,y:1064,t:1527030410574};\\\", \\\"{x:1471,y:1057,t:1527030410585};\\\", \\\"{x:1471,y:1047,t:1527030410602};\\\", \\\"{x:1463,y:1031,t:1527030410618};\\\", \\\"{x:1454,y:1013,t:1527030410635};\\\", \\\"{x:1452,y:1009,t:1527030410652};\\\", \\\"{x:1448,y:1004,t:1527030410668};\\\", \\\"{x:1446,y:1002,t:1527030410684};\\\", \\\"{x:1445,y:1002,t:1527030410767};\\\", \\\"{x:1442,y:1005,t:1527030410785};\\\", \\\"{x:1442,y:1006,t:1527030410815};\\\", \\\"{x:1440,y:1005,t:1527030410927};\\\", \\\"{x:1439,y:1003,t:1527030410942};\\\", \\\"{x:1438,y:1002,t:1527030410951};\\\", \\\"{x:1437,y:998,t:1527030410968};\\\", \\\"{x:1436,y:996,t:1527030410984};\\\", \\\"{x:1436,y:993,t:1527030411002};\\\", \\\"{x:1436,y:991,t:1527030411018};\\\", \\\"{x:1435,y:988,t:1527030411034};\\\", \\\"{x:1434,y:988,t:1527030411054};\\\", \\\"{x:1433,y:985,t:1527030411990};\\\", \\\"{x:1430,y:983,t:1527030412003};\\\", \\\"{x:1420,y:979,t:1527030412018};\\\", \\\"{x:1415,y:976,t:1527030412035};\\\", \\\"{x:1410,y:976,t:1527030412052};\\\", \\\"{x:1408,y:975,t:1527030412069};\\\", \\\"{x:1407,y:975,t:1527030412085};\\\", \\\"{x:1407,y:974,t:1527030412198};\\\", \\\"{x:1408,y:973,t:1527030412214};\\\", \\\"{x:1408,y:972,t:1527030412222};\\\", \\\"{x:1408,y:970,t:1527030412236};\\\", \\\"{x:1408,y:963,t:1527030412253};\\\", \\\"{x:1408,y:958,t:1527030412270};\\\", \\\"{x:1408,y:953,t:1527030412286};\\\", \\\"{x:1408,y:943,t:1527030412302};\\\", \\\"{x:1403,y:939,t:1527030412319};\\\", \\\"{x:1392,y:932,t:1527030412336};\\\", \\\"{x:1385,y:927,t:1527030412353};\\\", \\\"{x:1381,y:925,t:1527030412369};\\\", \\\"{x:1380,y:924,t:1527030412397};\\\", \\\"{x:1378,y:924,t:1527030412422};\\\", \\\"{x:1375,y:922,t:1527030412435};\\\", \\\"{x:1369,y:920,t:1527030412452};\\\", \\\"{x:1360,y:915,t:1527030412469};\\\", \\\"{x:1356,y:914,t:1527030412485};\\\", \\\"{x:1354,y:913,t:1527030412502};\\\", \\\"{x:1353,y:913,t:1527030412519};\\\", \\\"{x:1351,y:913,t:1527030412606};\\\", \\\"{x:1348,y:913,t:1527030412619};\\\", \\\"{x:1344,y:913,t:1527030412637};\\\", \\\"{x:1342,y:913,t:1527030412652};\\\", \\\"{x:1342,y:914,t:1527030412718};\\\", \\\"{x:1335,y:917,t:1527030413391};\\\", \\\"{x:1324,y:918,t:1527030413404};\\\", \\\"{x:1297,y:919,t:1527030413420};\\\", \\\"{x:1264,y:919,t:1527030413437};\\\", \\\"{x:1208,y:906,t:1527030413454};\\\", \\\"{x:1069,y:875,t:1527030413471};\\\", \\\"{x:933,y:834,t:1527030413487};\\\", \\\"{x:799,y:788,t:1527030413504};\\\", \\\"{x:703,y:763,t:1527030413520};\\\", \\\"{x:676,y:761,t:1527030413537};\\\", \\\"{x:668,y:761,t:1527030413554};\\\", \\\"{x:662,y:763,t:1527030413571};\\\", \\\"{x:659,y:764,t:1527030413586};\\\", \\\"{x:658,y:765,t:1527030413604};\\\", \\\"{x:658,y:767,t:1527030413621};\\\", \\\"{x:658,y:768,t:1527030413639};\\\", \\\"{x:658,y:769,t:1527030413654};\\\", \\\"{x:658,y:770,t:1527030413671};\\\", \\\"{x:658,y:771,t:1527030413695};\\\", \\\"{x:657,y:771,t:1527030413704};\\\", \\\"{x:645,y:771,t:1527030413721};\\\", \\\"{x:602,y:755,t:1527030413737};\\\", \\\"{x:532,y:730,t:1527030413755};\\\", \\\"{x:481,y:716,t:1527030413770};\\\", \\\"{x:443,y:706,t:1527030413786};\\\", \\\"{x:420,y:699,t:1527030413804};\\\", \\\"{x:411,y:696,t:1527030413820};\\\", \\\"{x:410,y:696,t:1527030413837};\\\", \\\"{x:411,y:696,t:1527030413957};\\\", \\\"{x:414,y:696,t:1527030413973};\\\", \\\"{x:418,y:696,t:1527030413988};\\\", \\\"{x:432,y:698,t:1527030414004};\\\", \\\"{x:463,y:709,t:1527030414021};\\\", \\\"{x:506,y:725,t:1527030414038};\\\", \\\"{x:555,y:740,t:1527030414054};\\\", \\\"{x:571,y:745,t:1527030414071};\\\", \\\"{x:574,y:746,t:1527030414088};\\\", \\\"{x:572,y:746,t:1527030414182};\\\", \\\"{x:570,y:746,t:1527030414189};\\\", \\\"{x:569,y:746,t:1527030414204};\\\", \\\"{x:568,y:746,t:1527030414221};\\\", \\\"{x:566,y:745,t:1527030414237};\\\", \\\"{x:564,y:744,t:1527030414254};\\\", \\\"{x:562,y:744,t:1527030414271};\\\", \\\"{x:560,y:744,t:1527030414288};\\\", \\\"{x:558,y:743,t:1527030414304};\\\", \\\"{x:557,y:743,t:1527030414326};\\\", \\\"{x:556,y:743,t:1527030414342};\\\", \\\"{x:555,y:742,t:1527030414355};\\\", \\\"{x:553,y:742,t:1527030414371};\\\", \\\"{x:546,y:741,t:1527030414388};\\\", \\\"{x:539,y:740,t:1527030414404};\\\", \\\"{x:533,y:739,t:1527030414421};\\\", \\\"{x:528,y:738,t:1527030414438};\\\", \\\"{x:526,y:737,t:1527030414454};\\\", \\\"{x:525,y:737,t:1527030414470};\\\", \\\"{x:525,y:736,t:1527030414511};\\\", \\\"{x:524,y:735,t:1527030414521};\\\", \\\"{x:521,y:731,t:1527030414538};\\\", \\\"{x:517,y:727,t:1527030414554};\\\", \\\"{x:516,y:726,t:1527030414571};\\\", \\\"{x:516,y:725,t:1527030414588};\\\", \\\"{x:515,y:725,t:1527030414607};\\\" ] }, { \\\"rt\\\": 21808, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 393592, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:725,t:1527030417006};\\\", \\\"{x:514,y:726,t:1527030417023};\\\", \\\"{x:514,y:729,t:1527030417039};\\\", \\\"{x:513,y:731,t:1527030417056};\\\", \\\"{x:513,y:736,t:1527030417073};\\\", \\\"{x:512,y:740,t:1527030417090};\\\", \\\"{x:510,y:745,t:1527030417106};\\\", \\\"{x:506,y:752,t:1527030417122};\\\", \\\"{x:506,y:759,t:1527030417139};\\\", \\\"{x:505,y:764,t:1527030417157};\\\", \\\"{x:504,y:766,t:1527030417172};\\\", \\\"{x:504,y:767,t:1527030417190};\\\", \\\"{x:504,y:768,t:1527030417207};\\\", \\\"{x:504,y:769,t:1527030417246};\\\", \\\"{x:504,y:770,t:1527030417257};\\\", \\\"{x:504,y:771,t:1527030417273};\\\", \\\"{x:503,y:772,t:1527030417290};\\\", \\\"{x:502,y:773,t:1527030417307};\\\", \\\"{x:502,y:774,t:1527030417343};\\\", \\\"{x:502,y:773,t:1527030421191};\\\", \\\"{x:503,y:772,t:1527030421198};\\\", \\\"{x:505,y:771,t:1527030421213};\\\", \\\"{x:507,y:771,t:1527030421225};\\\", \\\"{x:515,y:769,t:1527030421243};\\\", \\\"{x:528,y:769,t:1527030421260};\\\", \\\"{x:543,y:769,t:1527030421275};\\\", \\\"{x:559,y:773,t:1527030421293};\\\", \\\"{x:592,y:777,t:1527030421309};\\\", \\\"{x:610,y:780,t:1527030421326};\\\", \\\"{x:626,y:786,t:1527030421342};\\\", \\\"{x:640,y:790,t:1527030421360};\\\", \\\"{x:656,y:796,t:1527030421377};\\\", \\\"{x:675,y:805,t:1527030421393};\\\", \\\"{x:699,y:815,t:1527030421410};\\\", \\\"{x:729,y:824,t:1527030421427};\\\", \\\"{x:751,y:831,t:1527030421443};\\\", \\\"{x:752,y:832,t:1527030421775};\\\", \\\"{x:759,y:835,t:1527030421782};\\\", \\\"{x:768,y:839,t:1527030421794};\\\", \\\"{x:786,y:849,t:1527030421810};\\\", \\\"{x:807,y:855,t:1527030421826};\\\", \\\"{x:821,y:856,t:1527030421844};\\\", \\\"{x:834,y:856,t:1527030421859};\\\", \\\"{x:848,y:856,t:1527030421877};\\\", \\\"{x:877,y:849,t:1527030421893};\\\", \\\"{x:916,y:834,t:1527030421909};\\\", \\\"{x:974,y:819,t:1527030421927};\\\", \\\"{x:1044,y:808,t:1527030421944};\\\", \\\"{x:1112,y:807,t:1527030421960};\\\", \\\"{x:1181,y:807,t:1527030421977};\\\", \\\"{x:1243,y:807,t:1527030421995};\\\", \\\"{x:1309,y:807,t:1527030422010};\\\", \\\"{x:1351,y:807,t:1527030422027};\\\", \\\"{x:1389,y:812,t:1527030422045};\\\", \\\"{x:1413,y:820,t:1527030422060};\\\", \\\"{x:1437,y:828,t:1527030422077};\\\", \\\"{x:1510,y:860,t:1527030422094};\\\", \\\"{x:1542,y:878,t:1527030422111};\\\", \\\"{x:1552,y:886,t:1527030422127};\\\", \\\"{x:1557,y:889,t:1527030422144};\\\", \\\"{x:1559,y:892,t:1527030422160};\\\", \\\"{x:1559,y:894,t:1527030422177};\\\", \\\"{x:1560,y:897,t:1527030422195};\\\", \\\"{x:1562,y:901,t:1527030422212};\\\", \\\"{x:1563,y:905,t:1527030422227};\\\", \\\"{x:1563,y:906,t:1527030422244};\\\", \\\"{x:1564,y:908,t:1527030422261};\\\", \\\"{x:1561,y:906,t:1527030422367};\\\", \\\"{x:1555,y:900,t:1527030422378};\\\", \\\"{x:1540,y:889,t:1527030422395};\\\", \\\"{x:1527,y:881,t:1527030422412};\\\", \\\"{x:1519,y:874,t:1527030422428};\\\", \\\"{x:1514,y:870,t:1527030422445};\\\", \\\"{x:1513,y:867,t:1527030422462};\\\", \\\"{x:1513,y:866,t:1527030422477};\\\", \\\"{x:1513,y:864,t:1527030422493};\\\", \\\"{x:1514,y:862,t:1527030422511};\\\", \\\"{x:1517,y:855,t:1527030422527};\\\", \\\"{x:1522,y:846,t:1527030422544};\\\", \\\"{x:1528,y:832,t:1527030422560};\\\", \\\"{x:1534,y:822,t:1527030422577};\\\", \\\"{x:1538,y:813,t:1527030422594};\\\", \\\"{x:1539,y:810,t:1527030422611};\\\", \\\"{x:1541,y:808,t:1527030422627};\\\", \\\"{x:1542,y:806,t:1527030422644};\\\", \\\"{x:1542,y:805,t:1527030422661};\\\", \\\"{x:1545,y:800,t:1527030422678};\\\", \\\"{x:1548,y:795,t:1527030422694};\\\", \\\"{x:1549,y:794,t:1527030422711};\\\", \\\"{x:1550,y:793,t:1527030422729};\\\", \\\"{x:1551,y:793,t:1527030422744};\\\", \\\"{x:1551,y:792,t:1527030422782};\\\", \\\"{x:1552,y:792,t:1527030422795};\\\", \\\"{x:1555,y:792,t:1527030422811};\\\", \\\"{x:1557,y:792,t:1527030422829};\\\", \\\"{x:1561,y:791,t:1527030422845};\\\", \\\"{x:1563,y:789,t:1527030422862};\\\", \\\"{x:1573,y:778,t:1527030422878};\\\", \\\"{x:1575,y:771,t:1527030422895};\\\", \\\"{x:1579,y:760,t:1527030422911};\\\", \\\"{x:1581,y:747,t:1527030422929};\\\", \\\"{x:1582,y:740,t:1527030422944};\\\", \\\"{x:1582,y:733,t:1527030422961};\\\", \\\"{x:1582,y:726,t:1527030422978};\\\", \\\"{x:1582,y:722,t:1527030422995};\\\", \\\"{x:1576,y:712,t:1527030423012};\\\", \\\"{x:1572,y:699,t:1527030423028};\\\", \\\"{x:1570,y:690,t:1527030423045};\\\", \\\"{x:1569,y:687,t:1527030423061};\\\", \\\"{x:1569,y:678,t:1527030423079};\\\", \\\"{x:1569,y:676,t:1527030423095};\\\", \\\"{x:1569,y:669,t:1527030423111};\\\", \\\"{x:1569,y:664,t:1527030423128};\\\", \\\"{x:1569,y:659,t:1527030423146};\\\", \\\"{x:1569,y:650,t:1527030423162};\\\", \\\"{x:1570,y:644,t:1527030423178};\\\", \\\"{x:1570,y:641,t:1527030423196};\\\", \\\"{x:1570,y:631,t:1527030423211};\\\", \\\"{x:1570,y:616,t:1527030423229};\\\", \\\"{x:1567,y:606,t:1527030423245};\\\", \\\"{x:1562,y:592,t:1527030423261};\\\", \\\"{x:1551,y:575,t:1527030423279};\\\", \\\"{x:1543,y:567,t:1527030423295};\\\", \\\"{x:1539,y:563,t:1527030423311};\\\", \\\"{x:1535,y:560,t:1527030423329};\\\", \\\"{x:1532,y:555,t:1527030423345};\\\", \\\"{x:1528,y:551,t:1527030423361};\\\", \\\"{x:1523,y:545,t:1527030423378};\\\", \\\"{x:1518,y:541,t:1527030423396};\\\", \\\"{x:1509,y:535,t:1527030423411};\\\", \\\"{x:1498,y:528,t:1527030423429};\\\", \\\"{x:1489,y:522,t:1527030423446};\\\", \\\"{x:1481,y:518,t:1527030423461};\\\", \\\"{x:1468,y:512,t:1527030423479};\\\", \\\"{x:1456,y:504,t:1527030423496};\\\", \\\"{x:1449,y:500,t:1527030423513};\\\", \\\"{x:1443,y:496,t:1527030423528};\\\", \\\"{x:1438,y:494,t:1527030423546};\\\", \\\"{x:1436,y:493,t:1527030423562};\\\", \\\"{x:1435,y:492,t:1527030423579};\\\", \\\"{x:1432,y:492,t:1527030423595};\\\", \\\"{x:1431,y:492,t:1527030423613};\\\", \\\"{x:1427,y:492,t:1527030423629};\\\", \\\"{x:1421,y:492,t:1527030423646};\\\", \\\"{x:1409,y:499,t:1527030423662};\\\", \\\"{x:1405,y:508,t:1527030423678};\\\", \\\"{x:1400,y:516,t:1527030423695};\\\", \\\"{x:1397,y:522,t:1527030423712};\\\", \\\"{x:1394,y:530,t:1527030423728};\\\", \\\"{x:1389,y:543,t:1527030423745};\\\", \\\"{x:1382,y:568,t:1527030423762};\\\", \\\"{x:1380,y:598,t:1527030423778};\\\", \\\"{x:1375,y:627,t:1527030423795};\\\", \\\"{x:1372,y:651,t:1527030423811};\\\", \\\"{x:1372,y:675,t:1527030423828};\\\", \\\"{x:1372,y:693,t:1527030423845};\\\", \\\"{x:1372,y:709,t:1527030423862};\\\", \\\"{x:1372,y:717,t:1527030423880};\\\", \\\"{x:1372,y:723,t:1527030423895};\\\", \\\"{x:1372,y:737,t:1527030423912};\\\", \\\"{x:1372,y:750,t:1527030423928};\\\", \\\"{x:1372,y:764,t:1527030423945};\\\", \\\"{x:1372,y:773,t:1527030423962};\\\", \\\"{x:1372,y:779,t:1527030423979};\\\", \\\"{x:1370,y:794,t:1527030423995};\\\", \\\"{x:1366,y:815,t:1527030424012};\\\", \\\"{x:1364,y:833,t:1527030424029};\\\", \\\"{x:1361,y:846,t:1527030424045};\\\", \\\"{x:1359,y:860,t:1527030424062};\\\", \\\"{x:1359,y:867,t:1527030424079};\\\", \\\"{x:1359,y:872,t:1527030424095};\\\", \\\"{x:1359,y:878,t:1527030424113};\\\", \\\"{x:1359,y:885,t:1527030424129};\\\", \\\"{x:1359,y:890,t:1527030424146};\\\", \\\"{x:1358,y:895,t:1527030424163};\\\", \\\"{x:1357,y:899,t:1527030424180};\\\", \\\"{x:1356,y:901,t:1527030424196};\\\", \\\"{x:1355,y:905,t:1527030424212};\\\", \\\"{x:1354,y:905,t:1527030424230};\\\", \\\"{x:1353,y:906,t:1527030424245};\\\", \\\"{x:1347,y:907,t:1527030424262};\\\", \\\"{x:1339,y:907,t:1527030424280};\\\", \\\"{x:1325,y:906,t:1527030424295};\\\", \\\"{x:1303,y:901,t:1527030424312};\\\", \\\"{x:1278,y:894,t:1527030424329};\\\", \\\"{x:1254,y:884,t:1527030424346};\\\", \\\"{x:1227,y:877,t:1527030424363};\\\", \\\"{x:1210,y:871,t:1527030424380};\\\", \\\"{x:1202,y:867,t:1527030424396};\\\", \\\"{x:1200,y:867,t:1527030424412};\\\", \\\"{x:1200,y:865,t:1527030424510};\\\", \\\"{x:1200,y:864,t:1527030424518};\\\", \\\"{x:1200,y:862,t:1527030424530};\\\", \\\"{x:1200,y:859,t:1527030424546};\\\", \\\"{x:1200,y:853,t:1527030424563};\\\", \\\"{x:1202,y:846,t:1527030424580};\\\", \\\"{x:1206,y:839,t:1527030424596};\\\", \\\"{x:1209,y:833,t:1527030424612};\\\", \\\"{x:1210,y:830,t:1527030424631};\\\", \\\"{x:1210,y:829,t:1527030424646};\\\", \\\"{x:1211,y:829,t:1527030427255};\\\", \\\"{x:1213,y:829,t:1527030427265};\\\", \\\"{x:1215,y:829,t:1527030427281};\\\", \\\"{x:1216,y:829,t:1527030427298};\\\", \\\"{x:1218,y:829,t:1527030427614};\\\", \\\"{x:1219,y:829,t:1527030427646};\\\", \\\"{x:1221,y:829,t:1527030427873};\\\", \\\"{x:1222,y:829,t:1527030427902};\\\", \\\"{x:1226,y:827,t:1527030427916};\\\", \\\"{x:1229,y:826,t:1527030427932};\\\", \\\"{x:1235,y:826,t:1527030427949};\\\", \\\"{x:1241,y:826,t:1527030427966};\\\", \\\"{x:1253,y:825,t:1527030427983};\\\", \\\"{x:1261,y:825,t:1527030427999};\\\", \\\"{x:1267,y:825,t:1527030428015};\\\", \\\"{x:1274,y:825,t:1527030428033};\\\", \\\"{x:1282,y:825,t:1527030428050};\\\", \\\"{x:1289,y:825,t:1527030428067};\\\", \\\"{x:1292,y:825,t:1527030428083};\\\", \\\"{x:1293,y:824,t:1527030428102};\\\", \\\"{x:1293,y:823,t:1527030428415};\\\", \\\"{x:1296,y:822,t:1527030428433};\\\", \\\"{x:1299,y:822,t:1527030428450};\\\", \\\"{x:1301,y:820,t:1527030428466};\\\", \\\"{x:1305,y:820,t:1527030428482};\\\", \\\"{x:1306,y:820,t:1527030428500};\\\", \\\"{x:1308,y:820,t:1527030428518};\\\", \\\"{x:1309,y:820,t:1527030428550};\\\", \\\"{x:1311,y:820,t:1527030428566};\\\", \\\"{x:1317,y:820,t:1527030428583};\\\", \\\"{x:1323,y:820,t:1527030428600};\\\", \\\"{x:1326,y:820,t:1527030428616};\\\", \\\"{x:1327,y:820,t:1527030428727};\\\", \\\"{x:1328,y:821,t:1527030428734};\\\", \\\"{x:1329,y:821,t:1527030428751};\\\", \\\"{x:1329,y:822,t:1527030428839};\\\", \\\"{x:1330,y:822,t:1527030428862};\\\", \\\"{x:1332,y:822,t:1527030428895};\\\", \\\"{x:1333,y:822,t:1527030428902};\\\", \\\"{x:1335,y:823,t:1527030428916};\\\", \\\"{x:1336,y:823,t:1527030428933};\\\", \\\"{x:1339,y:823,t:1527030428949};\\\", \\\"{x:1340,y:823,t:1527030428983};\\\", \\\"{x:1341,y:823,t:1527030428999};\\\", \\\"{x:1342,y:823,t:1527030429017};\\\", \\\"{x:1343,y:824,t:1527030429033};\\\", \\\"{x:1345,y:824,t:1527030429050};\\\", \\\"{x:1347,y:825,t:1527030429067};\\\", \\\"{x:1348,y:825,t:1527030429083};\\\", \\\"{x:1349,y:826,t:1527030429103};\\\", \\\"{x:1349,y:827,t:1527030429191};\\\", \\\"{x:1349,y:828,t:1527030429200};\\\", \\\"{x:1349,y:829,t:1527030429223};\\\", \\\"{x:1349,y:830,t:1527030429255};\\\", \\\"{x:1349,y:831,t:1527030429303};\\\", \\\"{x:1349,y:832,t:1527030429327};\\\", \\\"{x:1349,y:833,t:1527030429423};\\\", \\\"{x:1349,y:834,t:1527030429435};\\\", \\\"{x:1349,y:835,t:1527030429450};\\\", \\\"{x:1349,y:836,t:1527030429467};\\\", \\\"{x:1349,y:837,t:1527030429486};\\\", \\\"{x:1349,y:838,t:1527030429500};\\\", \\\"{x:1349,y:839,t:1527030429517};\\\", \\\"{x:1349,y:840,t:1527030429533};\\\", \\\"{x:1349,y:841,t:1527030429550};\\\", \\\"{x:1349,y:843,t:1527030429566};\\\", \\\"{x:1349,y:845,t:1527030429584};\\\", \\\"{x:1349,y:847,t:1527030429600};\\\", \\\"{x:1349,y:849,t:1527030429617};\\\", \\\"{x:1349,y:852,t:1527030429634};\\\", \\\"{x:1349,y:854,t:1527030429649};\\\", \\\"{x:1349,y:855,t:1527030429667};\\\", \\\"{x:1349,y:856,t:1527030429684};\\\", \\\"{x:1349,y:857,t:1527030429700};\\\", \\\"{x:1349,y:858,t:1527030429716};\\\", \\\"{x:1349,y:862,t:1527030429734};\\\", \\\"{x:1349,y:863,t:1527030429751};\\\", \\\"{x:1353,y:869,t:1527030429767};\\\", \\\"{x:1353,y:872,t:1527030429784};\\\", \\\"{x:1353,y:875,t:1527030429801};\\\", \\\"{x:1354,y:876,t:1527030429817};\\\", \\\"{x:1355,y:877,t:1527030429871};\\\", \\\"{x:1355,y:878,t:1527030429887};\\\", \\\"{x:1355,y:880,t:1527030429927};\\\", \\\"{x:1355,y:881,t:1527030429999};\\\", \\\"{x:1355,y:883,t:1527030430055};\\\", \\\"{x:1355,y:885,t:1527030430079};\\\", \\\"{x:1355,y:887,t:1527030430159};\\\", \\\"{x:1355,y:888,t:1527030430223};\\\", \\\"{x:1354,y:889,t:1527030430263};\\\", \\\"{x:1354,y:890,t:1527030430631};\\\", \\\"{x:1353,y:891,t:1527030430638};\\\", \\\"{x:1352,y:891,t:1527030430651};\\\", \\\"{x:1352,y:892,t:1527030430670};\\\", \\\"{x:1351,y:892,t:1527030430888};\\\", \\\"{x:1350,y:892,t:1527030430927};\\\", \\\"{x:1349,y:892,t:1527030431062};\\\", \\\"{x:1349,y:891,t:1527030431078};\\\", \\\"{x:1348,y:890,t:1527030431086};\\\", \\\"{x:1348,y:889,t:1527030431101};\\\", \\\"{x:1348,y:884,t:1527030431117};\\\", \\\"{x:1348,y:881,t:1527030431134};\\\", \\\"{x:1348,y:880,t:1527030431151};\\\", \\\"{x:1348,y:876,t:1527030431168};\\\", \\\"{x:1348,y:874,t:1527030431184};\\\", \\\"{x:1348,y:871,t:1527030431202};\\\", \\\"{x:1347,y:868,t:1527030431217};\\\", \\\"{x:1346,y:866,t:1527030431235};\\\", \\\"{x:1346,y:864,t:1527030431252};\\\", \\\"{x:1346,y:863,t:1527030431268};\\\", \\\"{x:1346,y:862,t:1527030431285};\\\", \\\"{x:1346,y:860,t:1527030431303};\\\", \\\"{x:1346,y:858,t:1527030431319};\\\", \\\"{x:1346,y:856,t:1527030431335};\\\", \\\"{x:1346,y:855,t:1527030431352};\\\", \\\"{x:1346,y:854,t:1527030431368};\\\", \\\"{x:1346,y:852,t:1527030431385};\\\", \\\"{x:1346,y:849,t:1527030431402};\\\", \\\"{x:1347,y:846,t:1527030431418};\\\", \\\"{x:1347,y:843,t:1527030431435};\\\", \\\"{x:1347,y:838,t:1527030431452};\\\", \\\"{x:1347,y:835,t:1527030431468};\\\", \\\"{x:1347,y:831,t:1527030431485};\\\", \\\"{x:1347,y:828,t:1527030431502};\\\", \\\"{x:1347,y:820,t:1527030431519};\\\", \\\"{x:1347,y:815,t:1527030431535};\\\", \\\"{x:1349,y:809,t:1527030431552};\\\", \\\"{x:1350,y:801,t:1527030431569};\\\", \\\"{x:1350,y:795,t:1527030431585};\\\", \\\"{x:1352,y:787,t:1527030431602};\\\", \\\"{x:1354,y:777,t:1527030431619};\\\", \\\"{x:1358,y:767,t:1527030431635};\\\", \\\"{x:1360,y:757,t:1527030431652};\\\", \\\"{x:1364,y:746,t:1527030431669};\\\", \\\"{x:1364,y:741,t:1527030431685};\\\", \\\"{x:1364,y:736,t:1527030431702};\\\", \\\"{x:1364,y:735,t:1527030431719};\\\", \\\"{x:1364,y:734,t:1527030431743};\\\", \\\"{x:1364,y:733,t:1527030431766};\\\", \\\"{x:1364,y:732,t:1527030431790};\\\", \\\"{x:1364,y:731,t:1527030431806};\\\", \\\"{x:1364,y:729,t:1527030431819};\\\", \\\"{x:1364,y:727,t:1527030431835};\\\", \\\"{x:1364,y:725,t:1527030431852};\\\", \\\"{x:1364,y:722,t:1527030431869};\\\", \\\"{x:1364,y:720,t:1527030431885};\\\", \\\"{x:1363,y:719,t:1527030431902};\\\", \\\"{x:1362,y:718,t:1527030432103};\\\", \\\"{x:1361,y:716,t:1527030432119};\\\", \\\"{x:1360,y:715,t:1527030432136};\\\", \\\"{x:1359,y:714,t:1527030432166};\\\", \\\"{x:1359,y:713,t:1527030432190};\\\", \\\"{x:1358,y:713,t:1527030432207};\\\", \\\"{x:1356,y:714,t:1527030432247};\\\", \\\"{x:1355,y:716,t:1527030432263};\\\", \\\"{x:1354,y:718,t:1527030432270};\\\", \\\"{x:1352,y:726,t:1527030432286};\\\", \\\"{x:1350,y:730,t:1527030432302};\\\", \\\"{x:1350,y:748,t:1527030432319};\\\", \\\"{x:1350,y:764,t:1527030432336};\\\", \\\"{x:1353,y:775,t:1527030432353};\\\", \\\"{x:1356,y:784,t:1527030432369};\\\", \\\"{x:1359,y:802,t:1527030432386};\\\", \\\"{x:1363,y:823,t:1527030432403};\\\", \\\"{x:1373,y:861,t:1527030432419};\\\", \\\"{x:1374,y:877,t:1527030432436};\\\", \\\"{x:1374,y:890,t:1527030432453};\\\", \\\"{x:1374,y:901,t:1527030432469};\\\", \\\"{x:1372,y:917,t:1527030432486};\\\", \\\"{x:1369,y:926,t:1527030432503};\\\", \\\"{x:1364,y:933,t:1527030432519};\\\", \\\"{x:1362,y:937,t:1527030432536};\\\", \\\"{x:1361,y:939,t:1527030432553};\\\", \\\"{x:1360,y:943,t:1527030432569};\\\", \\\"{x:1360,y:944,t:1527030432606};\\\", \\\"{x:1359,y:944,t:1527030432647};\\\", \\\"{x:1359,y:941,t:1527030432671};\\\", \\\"{x:1359,y:930,t:1527030432686};\\\", \\\"{x:1357,y:918,t:1527030432702};\\\", \\\"{x:1355,y:904,t:1527030432719};\\\", \\\"{x:1352,y:894,t:1527030432737};\\\", \\\"{x:1350,y:887,t:1527030432754};\\\", \\\"{x:1350,y:884,t:1527030432769};\\\", \\\"{x:1349,y:883,t:1527030432855};\\\", \\\"{x:1348,y:883,t:1527030432870};\\\", \\\"{x:1348,y:881,t:1527030433062};\\\", \\\"{x:1347,y:880,t:1527030433070};\\\", \\\"{x:1347,y:879,t:1527030433085};\\\", \\\"{x:1347,y:875,t:1527030433104};\\\", \\\"{x:1347,y:873,t:1527030433120};\\\", \\\"{x:1347,y:870,t:1527030433136};\\\", \\\"{x:1347,y:864,t:1527030433153};\\\", \\\"{x:1347,y:856,t:1527030433170};\\\", \\\"{x:1345,y:851,t:1527030433186};\\\", \\\"{x:1345,y:848,t:1527030433203};\\\", \\\"{x:1345,y:844,t:1527030433220};\\\", \\\"{x:1343,y:835,t:1527030433237};\\\", \\\"{x:1343,y:827,t:1527030433253};\\\", \\\"{x:1342,y:816,t:1527030433270};\\\", \\\"{x:1341,y:812,t:1527030433286};\\\", \\\"{x:1341,y:807,t:1527030433303};\\\", \\\"{x:1341,y:803,t:1527030433320};\\\", \\\"{x:1341,y:799,t:1527030433337};\\\", \\\"{x:1341,y:793,t:1527030433353};\\\", \\\"{x:1341,y:791,t:1527030433369};\\\", \\\"{x:1341,y:787,t:1527030433387};\\\", \\\"{x:1341,y:782,t:1527030433403};\\\", \\\"{x:1341,y:776,t:1527030433420};\\\", \\\"{x:1341,y:770,t:1527030433437};\\\", \\\"{x:1341,y:763,t:1527030433453};\\\", \\\"{x:1342,y:758,t:1527030433470};\\\", \\\"{x:1342,y:756,t:1527030433486};\\\", \\\"{x:1342,y:751,t:1527030433503};\\\", \\\"{x:1342,y:746,t:1527030433520};\\\", \\\"{x:1342,y:740,t:1527030433537};\\\", \\\"{x:1342,y:729,t:1527030433553};\\\", \\\"{x:1342,y:722,t:1527030433570};\\\", \\\"{x:1344,y:714,t:1527030433587};\\\", \\\"{x:1344,y:707,t:1527030433604};\\\", \\\"{x:1345,y:705,t:1527030433620};\\\", \\\"{x:1345,y:704,t:1527030433637};\\\", \\\"{x:1345,y:701,t:1527030433654};\\\", \\\"{x:1346,y:699,t:1527030433670};\\\", \\\"{x:1347,y:695,t:1527030433687};\\\", \\\"{x:1347,y:691,t:1527030433704};\\\", \\\"{x:1348,y:689,t:1527030433720};\\\", \\\"{x:1348,y:687,t:1527030433737};\\\", \\\"{x:1348,y:686,t:1527030433754};\\\", \\\"{x:1348,y:685,t:1527030433770};\\\", \\\"{x:1348,y:684,t:1527030433787};\\\", \\\"{x:1348,y:682,t:1527030433804};\\\", \\\"{x:1348,y:681,t:1527030433821};\\\", \\\"{x:1348,y:677,t:1527030433837};\\\", \\\"{x:1348,y:674,t:1527030433854};\\\", \\\"{x:1348,y:671,t:1527030433871};\\\", \\\"{x:1348,y:665,t:1527030433886};\\\", \\\"{x:1348,y:663,t:1527030433904};\\\", \\\"{x:1348,y:657,t:1527030433921};\\\", \\\"{x:1348,y:650,t:1527030433937};\\\", \\\"{x:1349,y:646,t:1527030433954};\\\", \\\"{x:1349,y:641,t:1527030433970};\\\", \\\"{x:1350,y:634,t:1527030433987};\\\", \\\"{x:1350,y:628,t:1527030434004};\\\", \\\"{x:1350,y:620,t:1527030434020};\\\", \\\"{x:1350,y:611,t:1527030434037};\\\", \\\"{x:1350,y:596,t:1527030434054};\\\", \\\"{x:1350,y:588,t:1527030434071};\\\", \\\"{x:1350,y:584,t:1527030434087};\\\", \\\"{x:1350,y:579,t:1527030434104};\\\", \\\"{x:1350,y:571,t:1527030434121};\\\", \\\"{x:1347,y:561,t:1527030434137};\\\", \\\"{x:1345,y:548,t:1527030434154};\\\", \\\"{x:1343,y:539,t:1527030434171};\\\", \\\"{x:1341,y:529,t:1527030434187};\\\", \\\"{x:1340,y:519,t:1527030434204};\\\", \\\"{x:1338,y:512,t:1527030434221};\\\", \\\"{x:1336,y:508,t:1527030434238};\\\", \\\"{x:1334,y:503,t:1527030434256};\\\", \\\"{x:1334,y:500,t:1527030434270};\\\", \\\"{x:1333,y:498,t:1527030434287};\\\", \\\"{x:1333,y:496,t:1527030434304};\\\", \\\"{x:1333,y:493,t:1527030434321};\\\", \\\"{x:1333,y:489,t:1527030434337};\\\", \\\"{x:1331,y:483,t:1527030434354};\\\", \\\"{x:1331,y:479,t:1527030434371};\\\", \\\"{x:1331,y:471,t:1527030434388};\\\", \\\"{x:1330,y:464,t:1527030434403};\\\", \\\"{x:1329,y:459,t:1527030434421};\\\", \\\"{x:1329,y:452,t:1527030434437};\\\", \\\"{x:1329,y:444,t:1527030434454};\\\", \\\"{x:1329,y:441,t:1527030434471};\\\", \\\"{x:1329,y:436,t:1527030434486};\\\", \\\"{x:1329,y:430,t:1527030434503};\\\", \\\"{x:1329,y:427,t:1527030434520};\\\", \\\"{x:1329,y:425,t:1527030434537};\\\", \\\"{x:1329,y:420,t:1527030434554};\\\", \\\"{x:1329,y:418,t:1527030434571};\\\", \\\"{x:1326,y:418,t:1527030434639};\\\", \\\"{x:1309,y:431,t:1527030434654};\\\", \\\"{x:1272,y:460,t:1527030434670};\\\", \\\"{x:1215,y:509,t:1527030434688};\\\", \\\"{x:1148,y:555,t:1527030434704};\\\", \\\"{x:1065,y:608,t:1527030434721};\\\", \\\"{x:985,y:657,t:1527030434738};\\\", \\\"{x:929,y:697,t:1527030434754};\\\", \\\"{x:878,y:735,t:1527030434770};\\\", \\\"{x:852,y:755,t:1527030434788};\\\", \\\"{x:832,y:762,t:1527030434804};\\\", \\\"{x:817,y:766,t:1527030434820};\\\", \\\"{x:803,y:764,t:1527030434838};\\\", \\\"{x:783,y:754,t:1527030434854};\\\", \\\"{x:755,y:740,t:1527030434870};\\\", \\\"{x:728,y:733,t:1527030434888};\\\", \\\"{x:707,y:723,t:1527030434903};\\\", \\\"{x:688,y:712,t:1527030434920};\\\", \\\"{x:669,y:694,t:1527030434938};\\\", \\\"{x:647,y:669,t:1527030434954};\\\", \\\"{x:622,y:647,t:1527030434972};\\\", \\\"{x:594,y:630,t:1527030434988};\\\", \\\"{x:558,y:618,t:1527030435005};\\\", \\\"{x:533,y:614,t:1527030435020};\\\", \\\"{x:515,y:614,t:1527030435038};\\\", \\\"{x:506,y:614,t:1527030435055};\\\", \\\"{x:492,y:620,t:1527030435071};\\\", \\\"{x:473,y:627,t:1527030435087};\\\", \\\"{x:449,y:634,t:1527030435104};\\\", \\\"{x:430,y:640,t:1527030435121};\\\", \\\"{x:414,y:645,t:1527030435138};\\\", \\\"{x:410,y:646,t:1527030435154};\\\", \\\"{x:409,y:647,t:1527030435230};\\\", \\\"{x:407,y:647,t:1527030435245};\\\", \\\"{x:406,y:647,t:1527030435255};\\\", \\\"{x:403,y:647,t:1527030435271};\\\", \\\"{x:398,y:647,t:1527030435287};\\\", \\\"{x:387,y:647,t:1527030435304};\\\", \\\"{x:369,y:646,t:1527030435322};\\\", \\\"{x:341,y:638,t:1527030435337};\\\", \\\"{x:310,y:629,t:1527030435354};\\\", \\\"{x:280,y:625,t:1527030435371};\\\", \\\"{x:243,y:621,t:1527030435388};\\\", \\\"{x:219,y:617,t:1527030435405};\\\", \\\"{x:214,y:617,t:1527030435421};\\\", \\\"{x:212,y:617,t:1527030435439};\\\", \\\"{x:210,y:617,t:1527030435455};\\\", \\\"{x:208,y:619,t:1527030435472};\\\", \\\"{x:214,y:616,t:1527030435575};\\\", \\\"{x:221,y:613,t:1527030435588};\\\", \\\"{x:242,y:602,t:1527030435608};\\\", \\\"{x:300,y:583,t:1527030435622};\\\", \\\"{x:344,y:565,t:1527030435639};\\\", \\\"{x:364,y:553,t:1527030435654};\\\", \\\"{x:372,y:549,t:1527030435671};\\\", \\\"{x:371,y:547,t:1527030435717};\\\", \\\"{x:361,y:545,t:1527030435725};\\\", \\\"{x:344,y:541,t:1527030435739};\\\", \\\"{x:306,y:540,t:1527030435754};\\\", \\\"{x:264,y:540,t:1527030435771};\\\", \\\"{x:222,y:540,t:1527030435789};\\\", \\\"{x:197,y:540,t:1527030435804};\\\", \\\"{x:192,y:540,t:1527030435822};\\\", \\\"{x:192,y:542,t:1527030435942};\\\", \\\"{x:192,y:544,t:1527030435956};\\\", \\\"{x:193,y:546,t:1527030435971};\\\", \\\"{x:193,y:555,t:1527030435989};\\\", \\\"{x:193,y:561,t:1527030436005};\\\", \\\"{x:192,y:567,t:1527030436021};\\\", \\\"{x:190,y:570,t:1527030436039};\\\", \\\"{x:189,y:571,t:1527030436055};\\\", \\\"{x:188,y:571,t:1527030436093};\\\", \\\"{x:186,y:571,t:1527030436105};\\\", \\\"{x:178,y:571,t:1527030436121};\\\", \\\"{x:168,y:571,t:1527030436138};\\\", \\\"{x:158,y:571,t:1527030436156};\\\", \\\"{x:149,y:567,t:1527030436172};\\\", \\\"{x:141,y:564,t:1527030436189};\\\", \\\"{x:136,y:560,t:1527030436206};\\\", \\\"{x:139,y:560,t:1527030436527};\\\", \\\"{x:149,y:564,t:1527030436540};\\\", \\\"{x:167,y:569,t:1527030436556};\\\", \\\"{x:183,y:573,t:1527030436572};\\\", \\\"{x:203,y:577,t:1527030436590};\\\", \\\"{x:211,y:580,t:1527030436605};\\\", \\\"{x:217,y:582,t:1527030436623};\\\", \\\"{x:225,y:586,t:1527030436639};\\\", \\\"{x:230,y:587,t:1527030436656};\\\", \\\"{x:232,y:588,t:1527030436672};\\\", \\\"{x:231,y:588,t:1527030436774};\\\", \\\"{x:228,y:588,t:1527030436789};\\\", \\\"{x:208,y:580,t:1527030436806};\\\", \\\"{x:199,y:575,t:1527030436822};\\\", \\\"{x:192,y:572,t:1527030436839};\\\", \\\"{x:190,y:571,t:1527030436855};\\\", \\\"{x:189,y:571,t:1527030436873};\\\", \\\"{x:187,y:570,t:1527030436926};\\\", \\\"{x:183,y:568,t:1527030436942};\\\", \\\"{x:181,y:567,t:1527030436958};\\\", \\\"{x:180,y:567,t:1527030436973};\\\", \\\"{x:177,y:567,t:1527030436990};\\\", \\\"{x:175,y:566,t:1527030437006};\\\", \\\"{x:174,y:566,t:1527030437038};\\\", \\\"{x:173,y:566,t:1527030437054};\\\", \\\"{x:172,y:566,t:1527030437070};\\\", \\\"{x:171,y:566,t:1527030437086};\\\", \\\"{x:170,y:566,t:1527030437094};\\\", \\\"{x:168,y:565,t:1527030437106};\\\", \\\"{x:167,y:565,t:1527030437123};\\\", \\\"{x:166,y:565,t:1527030437139};\\\", \\\"{x:165,y:565,t:1527030437166};\\\", \\\"{x:163,y:565,t:1527030437365};\\\", \\\"{x:160,y:564,t:1527030437373};\\\", \\\"{x:154,y:564,t:1527030437390};\\\", \\\"{x:151,y:564,t:1527030437406};\\\", \\\"{x:150,y:564,t:1527030437421};\\\", \\\"{x:150,y:564,t:1527030437427};\\\", \\\"{x:149,y:564,t:1527030437439};\\\", \\\"{x:148,y:564,t:1527030437501};\\\", \\\"{x:147,y:564,t:1527030437509};\\\", \\\"{x:146,y:564,t:1527030437522};\\\", \\\"{x:145,y:564,t:1527030437540};\\\", \\\"{x:143,y:564,t:1527030437556};\\\", \\\"{x:141,y:566,t:1527030437572};\\\", \\\"{x:142,y:568,t:1527030437693};\\\", \\\"{x:144,y:571,t:1527030437709};\\\", \\\"{x:146,y:573,t:1527030437722};\\\", \\\"{x:156,y:583,t:1527030437740};\\\", \\\"{x:177,y:602,t:1527030437757};\\\", \\\"{x:219,y:625,t:1527030437774};\\\", \\\"{x:312,y:663,t:1527030437789};\\\", \\\"{x:378,y:682,t:1527030437807};\\\", \\\"{x:450,y:698,t:1527030437823};\\\", \\\"{x:489,y:705,t:1527030437839};\\\", \\\"{x:499,y:708,t:1527030437856};\\\", \\\"{x:500,y:708,t:1527030437933};\\\", \\\"{x:501,y:709,t:1527030437941};\\\", \\\"{x:502,y:709,t:1527030437957};\\\", \\\"{x:503,y:709,t:1527030437974};\\\", \\\"{x:504,y:709,t:1527030437989};\\\", \\\"{x:504,y:710,t:1527030438070};\\\" ] }, { \\\"rt\\\": 54025, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 448822, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 7.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-05 PM-04 PM-U -04 PM-03 PM-02 PM-02 PM-04 PM-O -O -03 PM-04 PM-12 PM-01 PM-I -O -03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:650,t:1527030439889};\\\", \\\"{x:518,y:640,t:1527030439894};\\\", \\\"{x:519,y:637,t:1527030439908};\\\", \\\"{x:522,y:629,t:1527030439925};\\\", \\\"{x:530,y:615,t:1527030439941};\\\", \\\"{x:541,y:603,t:1527030439959};\\\", \\\"{x:546,y:595,t:1527030439975};\\\", \\\"{x:552,y:586,t:1527030439992};\\\", \\\"{x:556,y:580,t:1527030440008};\\\", \\\"{x:559,y:575,t:1527030440025};\\\", \\\"{x:560,y:573,t:1527030440042};\\\", \\\"{x:561,y:572,t:1527030440077};\\\", \\\"{x:562,y:572,t:1527030440092};\\\", \\\"{x:569,y:567,t:1527030440108};\\\", \\\"{x:582,y:559,t:1527030440125};\\\", \\\"{x:588,y:551,t:1527030440142};\\\", \\\"{x:590,y:547,t:1527030440159};\\\", \\\"{x:591,y:546,t:1527030440262};\\\", \\\"{x:592,y:544,t:1527030440278};\\\", \\\"{x:593,y:545,t:1527030440551};\\\", \\\"{x:596,y:550,t:1527030440559};\\\", \\\"{x:599,y:558,t:1527030440577};\\\", \\\"{x:600,y:569,t:1527030440592};\\\", \\\"{x:603,y:579,t:1527030440610};\\\", \\\"{x:603,y:583,t:1527030440626};\\\", \\\"{x:604,y:585,t:1527030440642};\\\", \\\"{x:605,y:585,t:1527030440692};\\\", \\\"{x:606,y:586,t:1527030440981};\\\", \\\"{x:607,y:586,t:1527030441061};\\\", \\\"{x:608,y:586,t:1527030441102};\\\", \\\"{x:609,y:586,t:1527030441118};\\\", \\\"{x:609,y:585,t:1527030441126};\\\", \\\"{x:609,y:583,t:1527030441144};\\\", \\\"{x:608,y:581,t:1527030441159};\\\", \\\"{x:607,y:577,t:1527030441176};\\\", \\\"{x:606,y:574,t:1527030441193};\\\", \\\"{x:605,y:572,t:1527030441208};\\\", \\\"{x:605,y:570,t:1527030441226};\\\", \\\"{x:603,y:567,t:1527030441243};\\\", \\\"{x:602,y:565,t:1527030441258};\\\", \\\"{x:602,y:563,t:1527030441276};\\\", \\\"{x:602,y:562,t:1527030441485};\\\", \\\"{x:602,y:561,t:1527030441493};\\\", \\\"{x:602,y:559,t:1527030441509};\\\", \\\"{x:602,y:557,t:1527030441526};\\\", \\\"{x:602,y:553,t:1527030441542};\\\", \\\"{x:602,y:548,t:1527030441560};\\\", \\\"{x:603,y:543,t:1527030441577};\\\", \\\"{x:603,y:542,t:1527030441593};\\\", \\\"{x:603,y:541,t:1527030441622};\\\", \\\"{x:603,y:539,t:1527030441670};\\\", \\\"{x:603,y:538,t:1527030441686};\\\", \\\"{x:603,y:537,t:1527030441694};\\\", \\\"{x:603,y:533,t:1527030441712};\\\", \\\"{x:603,y:532,t:1527030441725};\\\", \\\"{x:604,y:531,t:1527030441743};\\\", \\\"{x:604,y:529,t:1527030441774};\\\", \\\"{x:605,y:529,t:1527030441797};\\\", \\\"{x:606,y:528,t:1527030441893};\\\", \\\"{x:606,y:528,t:1527030441945};\\\", \\\"{x:606,y:530,t:1527030441989};\\\", \\\"{x:606,y:533,t:1527030441997};\\\", \\\"{x:606,y:536,t:1527030442010};\\\", \\\"{x:606,y:544,t:1527030442027};\\\", \\\"{x:606,y:549,t:1527030442042};\\\", \\\"{x:607,y:550,t:1527030442060};\\\", \\\"{x:607,y:552,t:1527030442077};\\\", \\\"{x:607,y:553,t:1527030442093};\\\", \\\"{x:608,y:555,t:1527030442109};\\\", \\\"{x:608,y:559,t:1527030442126};\\\", \\\"{x:608,y:562,t:1527030442143};\\\", \\\"{x:609,y:565,t:1527030442159};\\\", \\\"{x:609,y:566,t:1527030442176};\\\", \\\"{x:609,y:568,t:1527030442405};\\\", \\\"{x:610,y:570,t:1527030442413};\\\", \\\"{x:610,y:574,t:1527030442427};\\\", \\\"{x:613,y:587,t:1527030442444};\\\", \\\"{x:614,y:596,t:1527030442459};\\\", \\\"{x:614,y:598,t:1527030442477};\\\", \\\"{x:614,y:600,t:1527030442494};\\\", \\\"{x:616,y:600,t:1527030442533};\\\", \\\"{x:617,y:600,t:1527030442717};\\\", \\\"{x:617,y:597,t:1527030442727};\\\", \\\"{x:617,y:592,t:1527030442744};\\\", \\\"{x:617,y:582,t:1527030442761};\\\", \\\"{x:617,y:571,t:1527030442777};\\\", \\\"{x:617,y:560,t:1527030442794};\\\", \\\"{x:617,y:551,t:1527030442811};\\\", \\\"{x:617,y:544,t:1527030442827};\\\", \\\"{x:617,y:537,t:1527030442844};\\\", \\\"{x:618,y:531,t:1527030442862};\\\", \\\"{x:620,y:525,t:1527030442877};\\\", \\\"{x:620,y:524,t:1527030442894};\\\", \\\"{x:620,y:525,t:1527030443366};\\\", \\\"{x:620,y:527,t:1527030443378};\\\", \\\"{x:620,y:529,t:1527030443394};\\\", \\\"{x:620,y:530,t:1527030443411};\\\", \\\"{x:620,y:531,t:1527030443428};\\\", \\\"{x:619,y:532,t:1527030443445};\\\", \\\"{x:619,y:533,t:1527030443487};\\\", \\\"{x:618,y:534,t:1527030443502};\\\", \\\"{x:618,y:535,t:1527030443511};\\\", \\\"{x:617,y:537,t:1527030443528};\\\", \\\"{x:616,y:539,t:1527030443544};\\\", \\\"{x:615,y:542,t:1527030443561};\\\", \\\"{x:613,y:545,t:1527030443578};\\\", \\\"{x:613,y:549,t:1527030443594};\\\", \\\"{x:612,y:553,t:1527030443611};\\\", \\\"{x:612,y:556,t:1527030443628};\\\", \\\"{x:611,y:558,t:1527030443645};\\\", \\\"{x:611,y:560,t:1527030443661};\\\", \\\"{x:610,y:563,t:1527030443677};\\\", \\\"{x:609,y:564,t:1527030443830};\\\", \\\"{x:610,y:564,t:1527030444438};\\\", \\\"{x:620,y:566,t:1527030444446};\\\", \\\"{x:641,y:569,t:1527030444463};\\\", \\\"{x:650,y:570,t:1527030444480};\\\", \\\"{x:659,y:571,t:1527030444495};\\\", \\\"{x:674,y:574,t:1527030444512};\\\", \\\"{x:699,y:576,t:1527030444530};\\\", \\\"{x:733,y:581,t:1527030444546};\\\", \\\"{x:772,y:581,t:1527030444562};\\\", \\\"{x:816,y:581,t:1527030444579};\\\", \\\"{x:864,y:581,t:1527030444595};\\\", \\\"{x:900,y:581,t:1527030444612};\\\", \\\"{x:921,y:579,t:1527030444629};\\\", \\\"{x:930,y:575,t:1527030444645};\\\", \\\"{x:931,y:574,t:1527030444663};\\\", \\\"{x:932,y:574,t:1527030444679};\\\", \\\"{x:930,y:576,t:1527030444847};\\\", \\\"{x:930,y:594,t:1527030444862};\\\", \\\"{x:930,y:618,t:1527030444879};\\\", \\\"{x:946,y:648,t:1527030444895};\\\", \\\"{x:995,y:695,t:1527030444912};\\\", \\\"{x:1060,y:731,t:1527030444929};\\\", \\\"{x:1060,y:734,t:1527030445207};\\\", \\\"{x:1062,y:736,t:1527030445215};\\\", \\\"{x:1071,y:739,t:1527030445229};\\\", \\\"{x:1149,y:764,t:1527030445246};\\\", \\\"{x:1221,y:784,t:1527030445262};\\\", \\\"{x:1297,y:810,t:1527030445279};\\\", \\\"{x:1340,y:825,t:1527030445296};\\\", \\\"{x:1360,y:832,t:1527030445313};\\\", \\\"{x:1371,y:838,t:1527030445330};\\\", \\\"{x:1379,y:842,t:1527030445347};\\\", \\\"{x:1386,y:847,t:1527030445363};\\\", \\\"{x:1394,y:852,t:1527030445379};\\\", \\\"{x:1401,y:854,t:1527030445396};\\\", \\\"{x:1407,y:857,t:1527030445413};\\\", \\\"{x:1416,y:858,t:1527030445430};\\\", \\\"{x:1445,y:867,t:1527030445446};\\\", \\\"{x:1507,y:891,t:1527030445463};\\\", \\\"{x:1587,y:913,t:1527030445480};\\\", \\\"{x:1656,y:929,t:1527030445496};\\\", \\\"{x:1714,y:937,t:1527030445513};\\\", \\\"{x:1760,y:945,t:1527030445530};\\\", \\\"{x:1785,y:949,t:1527030445546};\\\", \\\"{x:1792,y:951,t:1527030445563};\\\", \\\"{x:1792,y:952,t:1527030445623};\\\", \\\"{x:1792,y:953,t:1527030445630};\\\", \\\"{x:1792,y:955,t:1527030445647};\\\", \\\"{x:1783,y:962,t:1527030445663};\\\", \\\"{x:1769,y:966,t:1527030445680};\\\", \\\"{x:1750,y:968,t:1527030445696};\\\", \\\"{x:1732,y:969,t:1527030445714};\\\", \\\"{x:1711,y:969,t:1527030445731};\\\", \\\"{x:1695,y:969,t:1527030445747};\\\", \\\"{x:1678,y:969,t:1527030445763};\\\", \\\"{x:1661,y:969,t:1527030445781};\\\", \\\"{x:1646,y:969,t:1527030445797};\\\", \\\"{x:1628,y:969,t:1527030445815};\\\", \\\"{x:1623,y:969,t:1527030445829};\\\", \\\"{x:1621,y:969,t:1527030445846};\\\", \\\"{x:1620,y:969,t:1527030445903};\\\", \\\"{x:1619,y:969,t:1527030445913};\\\", \\\"{x:1617,y:969,t:1527030445929};\\\", \\\"{x:1616,y:969,t:1527030446070};\\\", \\\"{x:1615,y:969,t:1527030446151};\\\", \\\"{x:1614,y:969,t:1527030446164};\\\", \\\"{x:1613,y:968,t:1527030446180};\\\", \\\"{x:1610,y:953,t:1527030446197};\\\", \\\"{x:1608,y:932,t:1527030446215};\\\", \\\"{x:1608,y:928,t:1527030446229};\\\", \\\"{x:1608,y:917,t:1527030446246};\\\", \\\"{x:1608,y:913,t:1527030446264};\\\", \\\"{x:1608,y:912,t:1527030446280};\\\", \\\"{x:1607,y:912,t:1527030446297};\\\", \\\"{x:1607,y:910,t:1527030446487};\\\", \\\"{x:1607,y:909,t:1527030446503};\\\", \\\"{x:1607,y:907,t:1527030446518};\\\", \\\"{x:1607,y:906,t:1527030446530};\\\", \\\"{x:1607,y:900,t:1527030446547};\\\", \\\"{x:1606,y:896,t:1527030446564};\\\", \\\"{x:1605,y:893,t:1527030446581};\\\", \\\"{x:1605,y:888,t:1527030446596};\\\", \\\"{x:1605,y:886,t:1527030446615};\\\", \\\"{x:1605,y:881,t:1527030446630};\\\", \\\"{x:1604,y:876,t:1527030446647};\\\", \\\"{x:1604,y:873,t:1527030446664};\\\", \\\"{x:1604,y:870,t:1527030446681};\\\", \\\"{x:1602,y:867,t:1527030446696};\\\", \\\"{x:1602,y:866,t:1527030446713};\\\", \\\"{x:1602,y:864,t:1527030446730};\\\", \\\"{x:1602,y:861,t:1527030446747};\\\", \\\"{x:1602,y:858,t:1527030446764};\\\", \\\"{x:1602,y:855,t:1527030446781};\\\", \\\"{x:1602,y:853,t:1527030446797};\\\", \\\"{x:1603,y:846,t:1527030446815};\\\", \\\"{x:1603,y:844,t:1527030446831};\\\", \\\"{x:1603,y:841,t:1527030446847};\\\", \\\"{x:1604,y:840,t:1527030446863};\\\", \\\"{x:1604,y:839,t:1527030446880};\\\", \\\"{x:1605,y:837,t:1527030446897};\\\", \\\"{x:1605,y:836,t:1527030446914};\\\", \\\"{x:1606,y:835,t:1527030446931};\\\", \\\"{x:1606,y:831,t:1527030446946};\\\", \\\"{x:1608,y:825,t:1527030446963};\\\", \\\"{x:1608,y:824,t:1527030446981};\\\", \\\"{x:1609,y:824,t:1527030447287};\\\", \\\"{x:1609,y:826,t:1527030447298};\\\", \\\"{x:1609,y:827,t:1527030447314};\\\", \\\"{x:1610,y:829,t:1527030447331};\\\", \\\"{x:1610,y:830,t:1527030447374};\\\", \\\"{x:1610,y:831,t:1527030447390};\\\", \\\"{x:1610,y:832,t:1527030447398};\\\", \\\"{x:1610,y:833,t:1527030447422};\\\", \\\"{x:1611,y:835,t:1527030447430};\\\", \\\"{x:1612,y:836,t:1527030447486};\\\", \\\"{x:1612,y:838,t:1527030447518};\\\", \\\"{x:1612,y:839,t:1527030447534};\\\", \\\"{x:1612,y:840,t:1527030447782};\\\", \\\"{x:1611,y:840,t:1527030447798};\\\", \\\"{x:1600,y:843,t:1527030447815};\\\", \\\"{x:1582,y:847,t:1527030447831};\\\", \\\"{x:1560,y:848,t:1527030447847};\\\", \\\"{x:1534,y:848,t:1527030447865};\\\", \\\"{x:1506,y:848,t:1527030447881};\\\", \\\"{x:1485,y:848,t:1527030447898};\\\", \\\"{x:1474,y:848,t:1527030447914};\\\", \\\"{x:1471,y:846,t:1527030447931};\\\", \\\"{x:1470,y:846,t:1527030447982};\\\", \\\"{x:1470,y:845,t:1527030448038};\\\", \\\"{x:1471,y:843,t:1527030448048};\\\", \\\"{x:1472,y:842,t:1527030448065};\\\", \\\"{x:1474,y:839,t:1527030448081};\\\", \\\"{x:1475,y:837,t:1527030448098};\\\", \\\"{x:1476,y:834,t:1527030448115};\\\", \\\"{x:1477,y:834,t:1527030448133};\\\", \\\"{x:1477,y:833,t:1527030448293};\\\", \\\"{x:1477,y:832,t:1527030448310};\\\", \\\"{x:1477,y:831,t:1527030448334};\\\", \\\"{x:1478,y:830,t:1527030448598};\\\", \\\"{x:1481,y:829,t:1527030448615};\\\", \\\"{x:1489,y:829,t:1527030448633};\\\", \\\"{x:1509,y:829,t:1527030448647};\\\", \\\"{x:1538,y:832,t:1527030448664};\\\", \\\"{x:1569,y:835,t:1527030448682};\\\", \\\"{x:1591,y:840,t:1527030448698};\\\", \\\"{x:1603,y:843,t:1527030448715};\\\", \\\"{x:1603,y:844,t:1527030448783};\\\", \\\"{x:1603,y:845,t:1527030448799};\\\", \\\"{x:1603,y:846,t:1527030448815};\\\", \\\"{x:1603,y:849,t:1527030448832};\\\", \\\"{x:1603,y:853,t:1527030448848};\\\", \\\"{x:1603,y:862,t:1527030448865};\\\", \\\"{x:1600,y:870,t:1527030448882};\\\", \\\"{x:1597,y:877,t:1527030448897};\\\", \\\"{x:1596,y:883,t:1527030448915};\\\", \\\"{x:1595,y:887,t:1527030448932};\\\", \\\"{x:1595,y:892,t:1527030448948};\\\", \\\"{x:1595,y:896,t:1527030448965};\\\", \\\"{x:1595,y:898,t:1527030448982};\\\", \\\"{x:1595,y:903,t:1527030448998};\\\", \\\"{x:1597,y:913,t:1527030449015};\\\", \\\"{x:1599,y:926,t:1527030449031};\\\", \\\"{x:1599,y:933,t:1527030449047};\\\", \\\"{x:1599,y:938,t:1527030449065};\\\", \\\"{x:1599,y:942,t:1527030449082};\\\", \\\"{x:1599,y:946,t:1527030449098};\\\", \\\"{x:1596,y:950,t:1527030449114};\\\", \\\"{x:1593,y:955,t:1527030449132};\\\", \\\"{x:1589,y:959,t:1527030449148};\\\", \\\"{x:1586,y:961,t:1527030449164};\\\", \\\"{x:1585,y:963,t:1527030449183};\\\", \\\"{x:1584,y:963,t:1527030449198};\\\", \\\"{x:1583,y:963,t:1527030449218};\\\", \\\"{x:1583,y:964,t:1527030449231};\\\", \\\"{x:1582,y:964,t:1527030449261};\\\", \\\"{x:1580,y:964,t:1527030449278};\\\", \\\"{x:1579,y:965,t:1527030449293};\\\", \\\"{x:1578,y:965,t:1527030449302};\\\", \\\"{x:1577,y:966,t:1527030449314};\\\", \\\"{x:1577,y:967,t:1527030449334};\\\", \\\"{x:1579,y:967,t:1527030449429};\\\", \\\"{x:1581,y:967,t:1527030449438};\\\", \\\"{x:1584,y:967,t:1527030449449};\\\", \\\"{x:1590,y:966,t:1527030449464};\\\", \\\"{x:1600,y:966,t:1527030449482};\\\", \\\"{x:1610,y:966,t:1527030449498};\\\", \\\"{x:1614,y:966,t:1527030449514};\\\", \\\"{x:1616,y:966,t:1527030449531};\\\", \\\"{x:1617,y:966,t:1527030449614};\\\", \\\"{x:1617,y:967,t:1527030449654};\\\", \\\"{x:1617,y:968,t:1527030449670};\\\", \\\"{x:1616,y:969,t:1527030449686};\\\", \\\"{x:1615,y:969,t:1527030449726};\\\", \\\"{x:1614,y:970,t:1527030450015};\\\", \\\"{x:1612,y:972,t:1527030450032};\\\", \\\"{x:1611,y:972,t:1527030450049};\\\", \\\"{x:1610,y:973,t:1527030450065};\\\", \\\"{x:1609,y:973,t:1527030450082};\\\", \\\"{x:1608,y:975,t:1527030450098};\\\", \\\"{x:1607,y:975,t:1527030450116};\\\", \\\"{x:1605,y:976,t:1527030450132};\\\", \\\"{x:1601,y:976,t:1527030450148};\\\", \\\"{x:1596,y:977,t:1527030450165};\\\", \\\"{x:1573,y:977,t:1527030450183};\\\", \\\"{x:1557,y:977,t:1527030450198};\\\", \\\"{x:1547,y:977,t:1527030450215};\\\", \\\"{x:1542,y:977,t:1527030450231};\\\", \\\"{x:1541,y:977,t:1527030450249};\\\", \\\"{x:1538,y:977,t:1527030450266};\\\", \\\"{x:1537,y:977,t:1527030450281};\\\", \\\"{x:1532,y:977,t:1527030450298};\\\", \\\"{x:1523,y:977,t:1527030450316};\\\", \\\"{x:1512,y:977,t:1527030450331};\\\", \\\"{x:1498,y:974,t:1527030450349};\\\", \\\"{x:1486,y:973,t:1527030450366};\\\", \\\"{x:1479,y:972,t:1527030450381};\\\", \\\"{x:1471,y:970,t:1527030450399};\\\", \\\"{x:1468,y:970,t:1527030450416};\\\", \\\"{x:1467,y:970,t:1527030450431};\\\", \\\"{x:1466,y:970,t:1527030450478};\\\", \\\"{x:1465,y:970,t:1527030450486};\\\", \\\"{x:1464,y:970,t:1527030450558};\\\", \\\"{x:1464,y:969,t:1527030450591};\\\", \\\"{x:1465,y:969,t:1527030450606};\\\", \\\"{x:1467,y:967,t:1527030450616};\\\", \\\"{x:1473,y:966,t:1527030450631};\\\", \\\"{x:1477,y:965,t:1527030450648};\\\", \\\"{x:1479,y:963,t:1527030450666};\\\", \\\"{x:1480,y:963,t:1527030450681};\\\", \\\"{x:1483,y:962,t:1527030450698};\\\", \\\"{x:1483,y:961,t:1527030450838};\\\", \\\"{x:1483,y:960,t:1527030450849};\\\", \\\"{x:1483,y:958,t:1527030450865};\\\", \\\"{x:1483,y:952,t:1527030450883};\\\", \\\"{x:1483,y:944,t:1527030450899};\\\", \\\"{x:1483,y:937,t:1527030450916};\\\", \\\"{x:1484,y:928,t:1527030450932};\\\", \\\"{x:1485,y:923,t:1527030450949};\\\", \\\"{x:1486,y:918,t:1527030450966};\\\", \\\"{x:1488,y:909,t:1527030450982};\\\", \\\"{x:1490,y:905,t:1527030450999};\\\", \\\"{x:1490,y:900,t:1527030451016};\\\", \\\"{x:1490,y:894,t:1527030451033};\\\", \\\"{x:1490,y:891,t:1527030451048};\\\", \\\"{x:1490,y:886,t:1527030451065};\\\", \\\"{x:1492,y:880,t:1527030451083};\\\", \\\"{x:1492,y:876,t:1527030451098};\\\", \\\"{x:1493,y:870,t:1527030451116};\\\", \\\"{x:1494,y:863,t:1527030451133};\\\", \\\"{x:1494,y:859,t:1527030451149};\\\", \\\"{x:1494,y:855,t:1527030451167};\\\", \\\"{x:1494,y:853,t:1527030451183};\\\", \\\"{x:1494,y:852,t:1527030451199};\\\", \\\"{x:1494,y:851,t:1527030451215};\\\", \\\"{x:1494,y:850,t:1527030451238};\\\", \\\"{x:1494,y:849,t:1527030451278};\\\", \\\"{x:1494,y:848,t:1527030451286};\\\", \\\"{x:1494,y:847,t:1527030451299};\\\", \\\"{x:1494,y:846,t:1527030451316};\\\", \\\"{x:1494,y:845,t:1527030451333};\\\", \\\"{x:1494,y:844,t:1527030451349};\\\", \\\"{x:1494,y:843,t:1527030451366};\\\", \\\"{x:1494,y:842,t:1527030451382};\\\", \\\"{x:1494,y:841,t:1527030451399};\\\", \\\"{x:1494,y:840,t:1527030451415};\\\", \\\"{x:1494,y:839,t:1527030451433};\\\", \\\"{x:1494,y:838,t:1527030452726};\\\", \\\"{x:1492,y:839,t:1527030452734};\\\", \\\"{x:1483,y:842,t:1527030452750};\\\", \\\"{x:1456,y:848,t:1527030452766};\\\", \\\"{x:1368,y:855,t:1527030452783};\\\", \\\"{x:1252,y:855,t:1527030452800};\\\", \\\"{x:1083,y:855,t:1527030452817};\\\", \\\"{x:915,y:855,t:1527030452833};\\\", \\\"{x:754,y:855,t:1527030452849};\\\", \\\"{x:611,y:844,t:1527030452866};\\\", \\\"{x:475,y:822,t:1527030452883};\\\", \\\"{x:367,y:804,t:1527030452900};\\\", \\\"{x:311,y:788,t:1527030452917};\\\", \\\"{x:286,y:778,t:1527030452932};\\\", \\\"{x:280,y:769,t:1527030452949};\\\", \\\"{x:280,y:759,t:1527030452966};\\\", \\\"{x:284,y:753,t:1527030452983};\\\", \\\"{x:287,y:746,t:1527030453000};\\\", \\\"{x:290,y:739,t:1527030453016};\\\", \\\"{x:294,y:728,t:1527030453033};\\\", \\\"{x:299,y:712,t:1527030453049};\\\", \\\"{x:306,y:698,t:1527030453066};\\\", \\\"{x:314,y:683,t:1527030453083};\\\", \\\"{x:317,y:671,t:1527030453099};\\\", \\\"{x:328,y:658,t:1527030453117};\\\", \\\"{x:415,y:633,t:1527030453136};\\\", \\\"{x:529,y:616,t:1527030453150};\\\", \\\"{x:657,y:595,t:1527030453167};\\\", \\\"{x:815,y:587,t:1527030453202};\\\", \\\"{x:834,y:585,t:1527030453219};\\\", \\\"{x:835,y:585,t:1527030453235};\\\", \\\"{x:832,y:585,t:1527030453277};\\\", \\\"{x:828,y:585,t:1527030453285};\\\", \\\"{x:823,y:585,t:1527030453303};\\\", \\\"{x:822,y:585,t:1527030453319};\\\", \\\"{x:819,y:585,t:1527030453335};\\\", \\\"{x:810,y:585,t:1527030453353};\\\", \\\"{x:795,y:581,t:1527030453369};\\\", \\\"{x:781,y:580,t:1527030453385};\\\", \\\"{x:761,y:578,t:1527030453402};\\\", \\\"{x:732,y:578,t:1527030453420};\\\", \\\"{x:704,y:580,t:1527030453435};\\\", \\\"{x:683,y:586,t:1527030453453};\\\", \\\"{x:673,y:590,t:1527030453469};\\\", \\\"{x:669,y:593,t:1527030453486};\\\", \\\"{x:661,y:598,t:1527030453503};\\\", \\\"{x:652,y:603,t:1527030453520};\\\", \\\"{x:647,y:605,t:1527030453535};\\\", \\\"{x:641,y:606,t:1527030453554};\\\", \\\"{x:636,y:606,t:1527030453570};\\\", \\\"{x:632,y:606,t:1527030453586};\\\", \\\"{x:631,y:606,t:1527030453662};\\\", \\\"{x:630,y:606,t:1527030453669};\\\", \\\"{x:627,y:605,t:1527030453686};\\\", \\\"{x:622,y:603,t:1527030453702};\\\", \\\"{x:621,y:602,t:1527030453720};\\\", \\\"{x:629,y:608,t:1527030453982};\\\", \\\"{x:643,y:614,t:1527030453990};\\\", \\\"{x:664,y:623,t:1527030454003};\\\", \\\"{x:714,y:646,t:1527030454019};\\\", \\\"{x:800,y:673,t:1527030454037};\\\", \\\"{x:886,y:695,t:1527030454053};\\\", \\\"{x:1019,y:734,t:1527030454069};\\\", \\\"{x:1105,y:759,t:1527030454086};\\\", \\\"{x:1192,y:788,t:1527030454104};\\\", \\\"{x:1268,y:816,t:1527030454120};\\\", \\\"{x:1320,y:835,t:1527030454136};\\\", \\\"{x:1359,y:854,t:1527030454154};\\\", \\\"{x:1387,y:869,t:1527030454169};\\\", \\\"{x:1399,y:880,t:1527030454188};\\\", \\\"{x:1405,y:886,t:1527030454204};\\\", \\\"{x:1410,y:892,t:1527030454220};\\\", \\\"{x:1417,y:904,t:1527030454237};\\\", \\\"{x:1444,y:940,t:1527030454254};\\\", \\\"{x:1465,y:961,t:1527030454270};\\\", \\\"{x:1481,y:973,t:1527030454287};\\\", \\\"{x:1489,y:978,t:1527030454304};\\\", \\\"{x:1492,y:979,t:1527030454320};\\\", \\\"{x:1495,y:981,t:1527030454337};\\\", \\\"{x:1496,y:981,t:1527030454358};\\\", \\\"{x:1497,y:981,t:1527030454370};\\\", \\\"{x:1499,y:981,t:1527030454387};\\\", \\\"{x:1502,y:978,t:1527030454404};\\\", \\\"{x:1507,y:975,t:1527030454420};\\\", \\\"{x:1511,y:974,t:1527030454437};\\\", \\\"{x:1520,y:968,t:1527030454454};\\\", \\\"{x:1528,y:963,t:1527030454471};\\\", \\\"{x:1539,y:956,t:1527030454487};\\\", \\\"{x:1545,y:950,t:1527030454503};\\\", \\\"{x:1548,y:948,t:1527030454521};\\\", \\\"{x:1549,y:947,t:1527030454536};\\\", \\\"{x:1549,y:946,t:1527030454783};\\\", \\\"{x:1551,y:946,t:1527030454790};\\\", \\\"{x:1551,y:945,t:1527030454803};\\\", \\\"{x:1552,y:945,t:1527030454821};\\\", \\\"{x:1553,y:944,t:1527030454838};\\\", \\\"{x:1556,y:944,t:1527030455046};\\\", \\\"{x:1565,y:948,t:1527030455054};\\\", \\\"{x:1571,y:950,t:1527030455071};\\\", \\\"{x:1581,y:954,t:1527030455088};\\\", \\\"{x:1587,y:957,t:1527030455106};\\\", \\\"{x:1591,y:958,t:1527030455121};\\\", \\\"{x:1594,y:960,t:1527030455138};\\\", \\\"{x:1597,y:962,t:1527030455155};\\\", \\\"{x:1599,y:964,t:1527030455171};\\\", \\\"{x:1601,y:966,t:1527030455188};\\\", \\\"{x:1602,y:967,t:1527030455205};\\\", \\\"{x:1602,y:968,t:1527030455221};\\\", \\\"{x:1603,y:969,t:1527030455238};\\\", \\\"{x:1603,y:970,t:1527030455254};\\\", \\\"{x:1603,y:971,t:1527030455271};\\\", \\\"{x:1604,y:972,t:1527030455502};\\\", \\\"{x:1605,y:973,t:1527030455518};\\\", \\\"{x:1606,y:974,t:1527030455542};\\\", \\\"{x:1607,y:974,t:1527030455566};\\\", \\\"{x:1609,y:974,t:1527030455582};\\\", \\\"{x:1610,y:974,t:1527030455598};\\\", \\\"{x:1614,y:973,t:1527030455615};\\\", \\\"{x:1616,y:972,t:1527030455646};\\\", \\\"{x:1617,y:972,t:1527030455655};\\\", \\\"{x:1618,y:971,t:1527030455672};\\\", \\\"{x:1619,y:971,t:1527030455689};\\\", \\\"{x:1620,y:970,t:1527030455705};\\\", \\\"{x:1613,y:958,t:1527030459823};\\\", \\\"{x:1589,y:927,t:1527030459830};\\\", \\\"{x:1547,y:879,t:1527030459843};\\\", \\\"{x:1441,y:750,t:1527030459860};\\\", \\\"{x:1317,y:575,t:1527030459877};\\\", \\\"{x:1218,y:465,t:1527030459893};\\\", \\\"{x:1169,y:410,t:1527030459910};\\\", \\\"{x:1169,y:406,t:1527030459926};\\\", \\\"{x:1169,y:401,t:1527030459943};\\\", \\\"{x:1173,y:399,t:1527030459960};\\\", \\\"{x:1173,y:398,t:1527030459976};\\\", \\\"{x:1174,y:398,t:1527030459994};\\\", \\\"{x:1176,y:398,t:1527030460022};\\\", \\\"{x:1177,y:398,t:1527030460030};\\\", \\\"{x:1179,y:398,t:1527030460043};\\\", \\\"{x:1186,y:400,t:1527030460061};\\\", \\\"{x:1200,y:406,t:1527030460077};\\\", \\\"{x:1215,y:416,t:1527030460093};\\\", \\\"{x:1230,y:423,t:1527030460110};\\\", \\\"{x:1242,y:428,t:1527030460127};\\\", \\\"{x:1254,y:432,t:1527030460144};\\\", \\\"{x:1265,y:437,t:1527030460160};\\\", \\\"{x:1273,y:442,t:1527030460178};\\\", \\\"{x:1278,y:446,t:1527030460193};\\\", \\\"{x:1284,y:456,t:1527030460211};\\\", \\\"{x:1286,y:464,t:1527030460228};\\\", \\\"{x:1295,y:481,t:1527030460243};\\\", \\\"{x:1303,y:495,t:1527030460261};\\\", \\\"{x:1307,y:501,t:1527030460278};\\\", \\\"{x:1307,y:502,t:1527030460294};\\\", \\\"{x:1307,y:504,t:1527030460318};\\\", \\\"{x:1307,y:505,t:1527030460334};\\\", \\\"{x:1307,y:507,t:1527030460344};\\\", \\\"{x:1307,y:509,t:1527030460360};\\\", \\\"{x:1307,y:511,t:1527030460377};\\\", \\\"{x:1307,y:512,t:1527030460394};\\\", \\\"{x:1307,y:513,t:1527030460410};\\\", \\\"{x:1307,y:514,t:1527030460471};\\\", \\\"{x:1307,y:515,t:1527030460519};\\\", \\\"{x:1307,y:516,t:1527030460527};\\\", \\\"{x:1307,y:517,t:1527030460544};\\\", \\\"{x:1307,y:524,t:1527030460560};\\\", \\\"{x:1307,y:529,t:1527030460577};\\\", \\\"{x:1307,y:538,t:1527030460594};\\\", \\\"{x:1307,y:546,t:1527030460610};\\\", \\\"{x:1307,y:553,t:1527030460627};\\\", \\\"{x:1307,y:558,t:1527030460644};\\\", \\\"{x:1307,y:560,t:1527030460661};\\\", \\\"{x:1307,y:561,t:1527030460677};\\\", \\\"{x:1307,y:563,t:1527030460694};\\\", \\\"{x:1307,y:565,t:1527030460711};\\\", \\\"{x:1306,y:566,t:1527030460728};\\\", \\\"{x:1306,y:567,t:1527030460744};\\\", \\\"{x:1305,y:569,t:1527030460761};\\\", \\\"{x:1305,y:570,t:1527030460926};\\\", \\\"{x:1306,y:573,t:1527030460945};\\\", \\\"{x:1307,y:575,t:1527030460961};\\\", \\\"{x:1308,y:578,t:1527030460979};\\\", \\\"{x:1308,y:579,t:1527030460995};\\\", \\\"{x:1308,y:586,t:1527030461011};\\\", \\\"{x:1310,y:593,t:1527030461029};\\\", \\\"{x:1310,y:598,t:1527030461045};\\\", \\\"{x:1310,y:599,t:1527030461062};\\\", \\\"{x:1310,y:604,t:1527030461078};\\\", \\\"{x:1310,y:605,t:1527030461095};\\\", \\\"{x:1310,y:606,t:1527030461111};\\\", \\\"{x:1311,y:607,t:1527030461128};\\\", \\\"{x:1312,y:607,t:1527030461174};\\\", \\\"{x:1313,y:607,t:1527030461182};\\\", \\\"{x:1314,y:608,t:1527030461194};\\\", \\\"{x:1314,y:612,t:1527030461211};\\\", \\\"{x:1314,y:613,t:1527030461228};\\\", \\\"{x:1314,y:615,t:1527030461245};\\\", \\\"{x:1314,y:616,t:1527030461261};\\\", \\\"{x:1315,y:618,t:1527030461279};\\\", \\\"{x:1315,y:620,t:1527030461294};\\\", \\\"{x:1315,y:621,t:1527030461318};\\\", \\\"{x:1315,y:622,t:1527030461374};\\\", \\\"{x:1315,y:623,t:1527030461534};\\\", \\\"{x:1315,y:624,t:1527030461550};\\\", \\\"{x:1315,y:626,t:1527030461591};\\\", \\\"{x:1315,y:627,t:1527030461646};\\\", \\\"{x:1315,y:628,t:1527030461686};\\\", \\\"{x:1315,y:629,t:1527030461695};\\\", \\\"{x:1315,y:631,t:1527030461713};\\\", \\\"{x:1315,y:638,t:1527030461730};\\\", \\\"{x:1315,y:643,t:1527030461745};\\\", \\\"{x:1315,y:648,t:1527030461762};\\\", \\\"{x:1315,y:652,t:1527030461779};\\\", \\\"{x:1315,y:653,t:1527030461795};\\\", \\\"{x:1315,y:654,t:1527030461811};\\\", \\\"{x:1315,y:655,t:1527030462007};\\\", \\\"{x:1314,y:655,t:1527030462047};\\\", \\\"{x:1314,y:656,t:1527030462118};\\\", \\\"{x:1314,y:657,t:1527030462129};\\\", \\\"{x:1314,y:658,t:1527030462146};\\\", \\\"{x:1314,y:659,t:1527030462218};\\\", \\\"{x:1314,y:660,t:1527030462229};\\\", \\\"{x:1313,y:666,t:1527030462245};\\\", \\\"{x:1313,y:672,t:1527030462262};\\\", \\\"{x:1313,y:679,t:1527030462279};\\\", \\\"{x:1313,y:684,t:1527030462296};\\\", \\\"{x:1313,y:688,t:1527030462312};\\\", \\\"{x:1313,y:693,t:1527030462328};\\\", \\\"{x:1313,y:697,t:1527030462346};\\\", \\\"{x:1313,y:702,t:1527030462362};\\\", \\\"{x:1312,y:708,t:1527030462379};\\\", \\\"{x:1311,y:711,t:1527030462396};\\\", \\\"{x:1311,y:714,t:1527030462412};\\\", \\\"{x:1311,y:715,t:1527030462429};\\\", \\\"{x:1311,y:718,t:1527030462445};\\\", \\\"{x:1311,y:721,t:1527030462462};\\\", \\\"{x:1311,y:725,t:1527030462479};\\\", \\\"{x:1311,y:733,t:1527030462496};\\\", \\\"{x:1311,y:740,t:1527030462512};\\\", \\\"{x:1312,y:745,t:1527030462530};\\\", \\\"{x:1314,y:750,t:1527030462546};\\\", \\\"{x:1314,y:753,t:1527030462563};\\\", \\\"{x:1316,y:756,t:1527030462580};\\\", \\\"{x:1316,y:760,t:1527030462597};\\\", \\\"{x:1316,y:766,t:1527030462616};\\\", \\\"{x:1316,y:767,t:1527030462629};\\\", \\\"{x:1316,y:769,t:1527030462653};\\\", \\\"{x:1316,y:770,t:1527030462663};\\\", \\\"{x:1316,y:772,t:1527030462685};\\\", \\\"{x:1316,y:773,t:1527030462709};\\\", \\\"{x:1316,y:774,t:1527030462717};\\\", \\\"{x:1316,y:775,t:1527030462729};\\\", \\\"{x:1315,y:777,t:1527030462745};\\\", \\\"{x:1315,y:781,t:1527030462763};\\\", \\\"{x:1314,y:787,t:1527030462779};\\\", \\\"{x:1314,y:796,t:1527030462795};\\\", \\\"{x:1314,y:805,t:1527030462813};\\\", \\\"{x:1314,y:807,t:1527030462829};\\\", \\\"{x:1314,y:808,t:1527030462846};\\\", \\\"{x:1314,y:810,t:1527030462863};\\\", \\\"{x:1313,y:812,t:1527030462880};\\\", \\\"{x:1313,y:817,t:1527030462896};\\\", \\\"{x:1311,y:822,t:1527030462913};\\\", \\\"{x:1311,y:824,t:1527030462931};\\\", \\\"{x:1311,y:826,t:1527030462947};\\\", \\\"{x:1311,y:830,t:1527030462964};\\\", \\\"{x:1311,y:833,t:1527030462980};\\\", \\\"{x:1311,y:837,t:1527030462997};\\\", \\\"{x:1310,y:841,t:1527030463014};\\\", \\\"{x:1310,y:846,t:1527030463029};\\\", \\\"{x:1310,y:853,t:1527030463046};\\\", \\\"{x:1309,y:862,t:1527030463063};\\\", \\\"{x:1308,y:867,t:1527030463080};\\\", \\\"{x:1308,y:871,t:1527030463096};\\\", \\\"{x:1308,y:876,t:1527030463113};\\\", \\\"{x:1308,y:883,t:1527030463131};\\\", \\\"{x:1308,y:886,t:1527030463146};\\\", \\\"{x:1308,y:889,t:1527030463163};\\\", \\\"{x:1308,y:890,t:1527030463180};\\\", \\\"{x:1308,y:891,t:1527030463197};\\\", \\\"{x:1308,y:892,t:1527030463214};\\\", \\\"{x:1308,y:893,t:1527030463230};\\\", \\\"{x:1308,y:894,t:1527030463278};\\\", \\\"{x:1308,y:895,t:1527030463294};\\\", \\\"{x:1308,y:896,t:1527030463326};\\\", \\\"{x:1308,y:897,t:1527030463334};\\\", \\\"{x:1308,y:898,t:1527030463350};\\\", \\\"{x:1308,y:899,t:1527030463366};\\\", \\\"{x:1308,y:901,t:1527030463381};\\\", \\\"{x:1308,y:903,t:1527030463397};\\\", \\\"{x:1308,y:906,t:1527030463415};\\\", \\\"{x:1308,y:908,t:1527030463430};\\\", \\\"{x:1308,y:910,t:1527030463448};\\\", \\\"{x:1308,y:911,t:1527030463464};\\\", \\\"{x:1308,y:913,t:1527030463481};\\\", \\\"{x:1310,y:914,t:1527030463497};\\\", \\\"{x:1310,y:915,t:1527030463518};\\\", \\\"{x:1310,y:917,t:1527030463531};\\\", \\\"{x:1310,y:925,t:1527030463548};\\\", \\\"{x:1311,y:935,t:1527030463564};\\\", \\\"{x:1311,y:941,t:1527030463580};\\\", \\\"{x:1311,y:943,t:1527030463598};\\\", \\\"{x:1311,y:946,t:1527030463614};\\\", \\\"{x:1312,y:947,t:1527030463662};\\\", \\\"{x:1314,y:947,t:1527030463894};\\\", \\\"{x:1316,y:947,t:1527030463902};\\\", \\\"{x:1320,y:947,t:1527030463914};\\\", \\\"{x:1332,y:947,t:1527030463932};\\\", \\\"{x:1348,y:947,t:1527030463948};\\\", \\\"{x:1365,y:947,t:1527030463964};\\\", \\\"{x:1382,y:952,t:1527030463981};\\\", \\\"{x:1395,y:956,t:1527030463997};\\\", \\\"{x:1412,y:960,t:1527030464015};\\\", \\\"{x:1423,y:961,t:1527030464032};\\\", \\\"{x:1437,y:961,t:1527030464047};\\\", \\\"{x:1450,y:961,t:1527030464064};\\\", \\\"{x:1468,y:961,t:1527030464081};\\\", \\\"{x:1495,y:964,t:1527030464097};\\\", \\\"{x:1519,y:968,t:1527030464115};\\\", \\\"{x:1541,y:972,t:1527030464132};\\\", \\\"{x:1555,y:974,t:1527030464148};\\\", \\\"{x:1562,y:974,t:1527030464165};\\\", \\\"{x:1563,y:974,t:1527030465642};\\\", \\\"{x:1565,y:974,t:1527030465653};\\\", \\\"{x:1568,y:972,t:1527030465669};\\\", \\\"{x:1571,y:969,t:1527030465686};\\\", \\\"{x:1578,y:969,t:1527030465703};\\\", \\\"{x:1588,y:968,t:1527030465720};\\\", \\\"{x:1600,y:967,t:1527030465737};\\\", \\\"{x:1613,y:967,t:1527030465753};\\\", \\\"{x:1628,y:967,t:1527030465770};\\\", \\\"{x:1630,y:967,t:1527030465787};\\\", \\\"{x:1631,y:967,t:1527030465803};\\\", \\\"{x:1630,y:967,t:1527030466010};\\\", \\\"{x:1629,y:967,t:1527030466025};\\\", \\\"{x:1627,y:967,t:1527030466042};\\\", \\\"{x:1626,y:967,t:1527030466074};\\\", \\\"{x:1625,y:968,t:1527030466114};\\\", \\\"{x:1624,y:968,t:1527030466122};\\\", \\\"{x:1623,y:968,t:1527030466137};\\\", \\\"{x:1619,y:969,t:1527030466154};\\\", \\\"{x:1617,y:969,t:1527030466169};\\\", \\\"{x:1616,y:969,t:1527030466258};\\\", \\\"{x:1614,y:970,t:1527030466269};\\\", \\\"{x:1613,y:970,t:1527030466305};\\\", \\\"{x:1611,y:970,t:1527030466338};\\\", \\\"{x:1604,y:970,t:1527030466353};\\\", \\\"{x:1595,y:970,t:1527030466371};\\\", \\\"{x:1589,y:970,t:1527030466388};\\\", \\\"{x:1583,y:970,t:1527030466404};\\\", \\\"{x:1579,y:970,t:1527030466420};\\\", \\\"{x:1576,y:968,t:1527030466437};\\\", \\\"{x:1575,y:968,t:1527030466490};\\\", \\\"{x:1573,y:968,t:1527030466506};\\\", \\\"{x:1568,y:968,t:1527030466521};\\\", \\\"{x:1561,y:967,t:1527030466537};\\\", \\\"{x:1555,y:966,t:1527030466553};\\\", \\\"{x:1552,y:966,t:1527030466571};\\\", \\\"{x:1548,y:964,t:1527030466587};\\\", \\\"{x:1545,y:964,t:1527030466605};\\\", \\\"{x:1543,y:964,t:1527030466621};\\\", \\\"{x:1542,y:964,t:1527030466674};\\\", \\\"{x:1540,y:964,t:1527030466686};\\\", \\\"{x:1535,y:963,t:1527030466704};\\\", \\\"{x:1528,y:961,t:1527030466721};\\\", \\\"{x:1520,y:957,t:1527030466737};\\\", \\\"{x:1513,y:954,t:1527030466754};\\\", \\\"{x:1508,y:952,t:1527030466771};\\\", \\\"{x:1505,y:951,t:1527030466788};\\\", \\\"{x:1503,y:950,t:1527030466804};\\\", \\\"{x:1501,y:950,t:1527030467234};\\\", \\\"{x:1500,y:951,t:1527030467250};\\\", \\\"{x:1499,y:951,t:1527030467257};\\\", \\\"{x:1497,y:951,t:1527030467270};\\\", \\\"{x:1488,y:951,t:1527030467288};\\\", \\\"{x:1479,y:951,t:1527030467305};\\\", \\\"{x:1472,y:951,t:1527030467321};\\\", \\\"{x:1467,y:951,t:1527030467337};\\\", \\\"{x:1463,y:951,t:1527030467354};\\\", \\\"{x:1461,y:951,t:1527030467372};\\\", \\\"{x:1459,y:951,t:1527030467387};\\\", \\\"{x:1456,y:951,t:1527030467405};\\\", \\\"{x:1453,y:951,t:1527030467422};\\\", \\\"{x:1451,y:951,t:1527030467438};\\\", \\\"{x:1450,y:951,t:1527030467457};\\\", \\\"{x:1449,y:951,t:1527030467473};\\\", \\\"{x:1448,y:951,t:1527030467498};\\\", \\\"{x:1446,y:951,t:1527030467505};\\\", \\\"{x:1445,y:951,t:1527030467522};\\\", \\\"{x:1443,y:951,t:1527030467538};\\\", \\\"{x:1440,y:951,t:1527030467555};\\\", \\\"{x:1434,y:951,t:1527030467572};\\\", \\\"{x:1424,y:952,t:1527030467588};\\\", \\\"{x:1411,y:952,t:1527030467605};\\\", \\\"{x:1398,y:952,t:1527030467622};\\\", \\\"{x:1391,y:952,t:1527030467639};\\\", \\\"{x:1387,y:952,t:1527030467655};\\\", \\\"{x:1386,y:952,t:1527030467672};\\\", \\\"{x:1381,y:953,t:1527030467689};\\\", \\\"{x:1376,y:954,t:1527030467705};\\\", \\\"{x:1371,y:955,t:1527030467722};\\\", \\\"{x:1370,y:955,t:1527030467745};\\\", \\\"{x:1369,y:955,t:1527030468121};\\\", \\\"{x:1369,y:952,t:1527030468139};\\\", \\\"{x:1369,y:949,t:1527030468156};\\\", \\\"{x:1369,y:946,t:1527030468172};\\\", \\\"{x:1370,y:944,t:1527030468189};\\\", \\\"{x:1370,y:942,t:1527030468206};\\\", \\\"{x:1370,y:940,t:1527030468221};\\\", \\\"{x:1370,y:939,t:1527030468240};\\\", \\\"{x:1370,y:937,t:1527030468255};\\\", \\\"{x:1371,y:930,t:1527030468272};\\\", \\\"{x:1372,y:928,t:1527030468289};\\\", \\\"{x:1372,y:923,t:1527030468305};\\\", \\\"{x:1373,y:919,t:1527030468322};\\\", \\\"{x:1373,y:916,t:1527030468338};\\\", \\\"{x:1373,y:914,t:1527030468356};\\\", \\\"{x:1374,y:913,t:1527030468401};\\\", \\\"{x:1374,y:915,t:1527030468554};\\\", \\\"{x:1374,y:917,t:1527030468562};\\\", \\\"{x:1374,y:919,t:1527030468573};\\\", \\\"{x:1375,y:921,t:1527030468590};\\\", \\\"{x:1376,y:922,t:1527030468606};\\\", \\\"{x:1376,y:923,t:1527030468623};\\\", \\\"{x:1376,y:925,t:1527030468666};\\\", \\\"{x:1376,y:926,t:1527030468681};\\\", \\\"{x:1376,y:927,t:1527030468690};\\\", \\\"{x:1376,y:931,t:1527030468706};\\\", \\\"{x:1376,y:933,t:1527030468723};\\\", \\\"{x:1376,y:935,t:1527030468740};\\\", \\\"{x:1376,y:939,t:1527030468756};\\\", \\\"{x:1376,y:941,t:1527030468773};\\\", \\\"{x:1376,y:943,t:1527030468790};\\\", \\\"{x:1377,y:945,t:1527030468806};\\\", \\\"{x:1377,y:947,t:1527030468823};\\\", \\\"{x:1379,y:951,t:1527030468840};\\\", \\\"{x:1381,y:961,t:1527030468856};\\\", \\\"{x:1386,y:972,t:1527030468873};\\\", \\\"{x:1388,y:975,t:1527030468890};\\\", \\\"{x:1389,y:979,t:1527030468906};\\\", \\\"{x:1389,y:980,t:1527030468985};\\\", \\\"{x:1389,y:981,t:1527030469009};\\\", \\\"{x:1388,y:981,t:1527030469026};\\\", \\\"{x:1385,y:981,t:1527030469041};\\\", \\\"{x:1384,y:981,t:1527030469057};\\\", \\\"{x:1381,y:981,t:1527030469073};\\\", \\\"{x:1376,y:981,t:1527030469089};\\\", \\\"{x:1375,y:981,t:1527030469107};\\\", \\\"{x:1372,y:981,t:1527030469123};\\\", \\\"{x:1369,y:981,t:1527030469140};\\\", \\\"{x:1363,y:979,t:1527030469157};\\\", \\\"{x:1357,y:976,t:1527030469172};\\\", \\\"{x:1354,y:974,t:1527030469190};\\\", \\\"{x:1353,y:973,t:1527030469207};\\\", \\\"{x:1352,y:972,t:1527030469225};\\\", \\\"{x:1352,y:971,t:1527030469249};\\\", \\\"{x:1352,y:969,t:1527030469296};\\\", \\\"{x:1352,y:968,t:1527030469490};\\\", \\\"{x:1352,y:967,t:1527030469506};\\\", \\\"{x:1352,y:966,t:1527030469524};\\\", \\\"{x:1352,y:965,t:1527030469539};\\\", \\\"{x:1352,y:963,t:1527030469557};\\\", \\\"{x:1352,y:960,t:1527030469574};\\\", \\\"{x:1352,y:956,t:1527030469591};\\\", \\\"{x:1352,y:953,t:1527030469607};\\\", \\\"{x:1352,y:951,t:1527030469623};\\\", \\\"{x:1352,y:949,t:1527030469641};\\\", \\\"{x:1352,y:948,t:1527030469665};\\\", \\\"{x:1352,y:947,t:1527030469690};\\\", \\\"{x:1352,y:946,t:1527030469697};\\\", \\\"{x:1352,y:945,t:1527030469721};\\\", \\\"{x:1352,y:944,t:1527030469729};\\\", \\\"{x:1352,y:943,t:1527030469741};\\\", \\\"{x:1352,y:942,t:1527030469762};\\\", \\\"{x:1353,y:941,t:1527030469774};\\\", \\\"{x:1353,y:938,t:1527030469791};\\\", \\\"{x:1353,y:933,t:1527030469807};\\\", \\\"{x:1353,y:929,t:1527030469824};\\\", \\\"{x:1353,y:921,t:1527030469841};\\\", \\\"{x:1353,y:918,t:1527030469858};\\\", \\\"{x:1353,y:915,t:1527030469874};\\\", \\\"{x:1353,y:914,t:1527030469905};\\\", \\\"{x:1353,y:913,t:1527030469978};\\\", \\\"{x:1354,y:912,t:1527030469991};\\\", \\\"{x:1355,y:912,t:1527030470089};\\\", \\\"{x:1356,y:912,t:1527030470108};\\\", \\\"{x:1364,y:912,t:1527030470124};\\\", \\\"{x:1378,y:913,t:1527030470141};\\\", \\\"{x:1396,y:918,t:1527030470158};\\\", \\\"{x:1410,y:923,t:1527030470175};\\\", \\\"{x:1420,y:928,t:1527030470191};\\\", \\\"{x:1426,y:932,t:1527030470208};\\\", \\\"{x:1429,y:938,t:1527030470225};\\\", \\\"{x:1430,y:941,t:1527030470241};\\\", \\\"{x:1431,y:944,t:1527030470258};\\\", \\\"{x:1434,y:947,t:1527030470275};\\\", \\\"{x:1435,y:948,t:1527030470291};\\\", \\\"{x:1436,y:949,t:1527030470314};\\\", \\\"{x:1438,y:951,t:1527030470330};\\\", \\\"{x:1439,y:953,t:1527030470341};\\\", \\\"{x:1443,y:960,t:1527030470358};\\\", \\\"{x:1445,y:962,t:1527030470375};\\\", \\\"{x:1446,y:963,t:1527030470391};\\\", \\\"{x:1447,y:964,t:1527030470418};\\\", \\\"{x:1447,y:965,t:1527030470467};\\\", \\\"{x:1446,y:965,t:1527030470489};\\\", \\\"{x:1445,y:965,t:1527030470521};\\\", \\\"{x:1444,y:965,t:1527030470570};\\\", \\\"{x:1443,y:965,t:1527030470610};\\\", \\\"{x:1443,y:966,t:1527030470681};\\\", \\\"{x:1442,y:966,t:1527030470692};\\\", \\\"{x:1442,y:967,t:1527030470708};\\\", \\\"{x:1441,y:969,t:1527030470737};\\\", \\\"{x:1440,y:970,t:1527030470762};\\\", \\\"{x:1440,y:971,t:1527030470778};\\\", \\\"{x:1439,y:972,t:1527030470794};\\\", \\\"{x:1439,y:973,t:1527030470809};\\\", \\\"{x:1437,y:973,t:1527030470826};\\\", \\\"{x:1435,y:974,t:1527030470842};\\\", \\\"{x:1433,y:974,t:1527030470859};\\\", \\\"{x:1432,y:974,t:1527030470881};\\\", \\\"{x:1431,y:974,t:1527030470892};\\\", \\\"{x:1430,y:974,t:1527030470914};\\\", \\\"{x:1429,y:974,t:1527030470925};\\\", \\\"{x:1428,y:973,t:1527030470942};\\\", \\\"{x:1426,y:972,t:1527030470959};\\\", \\\"{x:1425,y:972,t:1527030470975};\\\", \\\"{x:1425,y:971,t:1527030471001};\\\", \\\"{x:1424,y:970,t:1527030471009};\\\", \\\"{x:1423,y:970,t:1527030471090};\\\", \\\"{x:1422,y:970,t:1527030471105};\\\", \\\"{x:1421,y:970,t:1527030471113};\\\", \\\"{x:1420,y:969,t:1527030471126};\\\", \\\"{x:1419,y:969,t:1527030471537};\\\", \\\"{x:1419,y:967,t:1527030471544};\\\", \\\"{x:1419,y:966,t:1527030471584};\\\", \\\"{x:1419,y:965,t:1527030471600};\\\", \\\"{x:1419,y:964,t:1527030471897};\\\", \\\"{x:1419,y:961,t:1527030471910};\\\", \\\"{x:1419,y:957,t:1527030471926};\\\", \\\"{x:1420,y:952,t:1527030471943};\\\", \\\"{x:1420,y:943,t:1527030471960};\\\", \\\"{x:1420,y:936,t:1527030471976};\\\", \\\"{x:1420,y:929,t:1527030471993};\\\", \\\"{x:1420,y:926,t:1527030472010};\\\", \\\"{x:1420,y:925,t:1527030472026};\\\", \\\"{x:1420,y:923,t:1527030472043};\\\", \\\"{x:1420,y:921,t:1527030472060};\\\", \\\"{x:1420,y:919,t:1527030472077};\\\", \\\"{x:1420,y:917,t:1527030472093};\\\", \\\"{x:1420,y:915,t:1527030472110};\\\", \\\"{x:1420,y:913,t:1527030472126};\\\", \\\"{x:1420,y:910,t:1527030472142};\\\", \\\"{x:1420,y:904,t:1527030472159};\\\", \\\"{x:1420,y:898,t:1527030472176};\\\", \\\"{x:1420,y:891,t:1527030472192};\\\", \\\"{x:1420,y:887,t:1527030472209};\\\", \\\"{x:1420,y:883,t:1527030472226};\\\", \\\"{x:1420,y:879,t:1527030472242};\\\", \\\"{x:1420,y:876,t:1527030472259};\\\", \\\"{x:1420,y:874,t:1527030472276};\\\", \\\"{x:1420,y:873,t:1527030472297};\\\", \\\"{x:1420,y:872,t:1527030472309};\\\", \\\"{x:1420,y:873,t:1527030472657};\\\", \\\"{x:1420,y:875,t:1527030472698};\\\", \\\"{x:1420,y:876,t:1527030472711};\\\", \\\"{x:1420,y:877,t:1527030472727};\\\", \\\"{x:1419,y:880,t:1527030472744};\\\", \\\"{x:1419,y:888,t:1527030472761};\\\", \\\"{x:1418,y:892,t:1527030472777};\\\", \\\"{x:1417,y:896,t:1527030472794};\\\", \\\"{x:1417,y:900,t:1527030472812};\\\", \\\"{x:1416,y:904,t:1527030472826};\\\", \\\"{x:1416,y:907,t:1527030472843};\\\", \\\"{x:1415,y:911,t:1527030472861};\\\", \\\"{x:1415,y:913,t:1527030472876};\\\", \\\"{x:1414,y:916,t:1527030472893};\\\", \\\"{x:1414,y:919,t:1527030472911};\\\", \\\"{x:1414,y:921,t:1527030472926};\\\", \\\"{x:1414,y:922,t:1527030472943};\\\", \\\"{x:1414,y:923,t:1527030473033};\\\", \\\"{x:1414,y:924,t:1527030473044};\\\", \\\"{x:1414,y:925,t:1527030473061};\\\", \\\"{x:1414,y:926,t:1527030473081};\\\", \\\"{x:1414,y:927,t:1527030473094};\\\", \\\"{x:1414,y:928,t:1527030473111};\\\", \\\"{x:1413,y:929,t:1527030473802};\\\", \\\"{x:1411,y:929,t:1527030473812};\\\", \\\"{x:1406,y:929,t:1527030473828};\\\", \\\"{x:1400,y:929,t:1527030473845};\\\", \\\"{x:1384,y:927,t:1527030473862};\\\", \\\"{x:1360,y:920,t:1527030473878};\\\", \\\"{x:1345,y:916,t:1527030473895};\\\", \\\"{x:1336,y:912,t:1527030473912};\\\", \\\"{x:1329,y:908,t:1527030473928};\\\", \\\"{x:1326,y:908,t:1527030473946};\\\", \\\"{x:1326,y:907,t:1527030473962};\\\", \\\"{x:1326,y:905,t:1527030474025};\\\", \\\"{x:1321,y:903,t:1527030474033};\\\", \\\"{x:1319,y:900,t:1527030474045};\\\", \\\"{x:1315,y:896,t:1527030474062};\\\", \\\"{x:1312,y:894,t:1527030474080};\\\", \\\"{x:1310,y:891,t:1527030474095};\\\", \\\"{x:1308,y:885,t:1527030474112};\\\", \\\"{x:1306,y:878,t:1527030474129};\\\", \\\"{x:1304,y:874,t:1527030474145};\\\", \\\"{x:1301,y:869,t:1527030474162};\\\", \\\"{x:1299,y:868,t:1527030474180};\\\", \\\"{x:1299,y:867,t:1527030474195};\\\", \\\"{x:1298,y:865,t:1527030474212};\\\", \\\"{x:1296,y:862,t:1527030474229};\\\", \\\"{x:1293,y:860,t:1527030474245};\\\", \\\"{x:1292,y:858,t:1527030474263};\\\", \\\"{x:1291,y:854,t:1527030474279};\\\", \\\"{x:1288,y:849,t:1527030474296};\\\", \\\"{x:1287,y:846,t:1527030474312};\\\", \\\"{x:1284,y:841,t:1527030474329};\\\", \\\"{x:1283,y:840,t:1527030474345};\\\", \\\"{x:1283,y:839,t:1527030474489};\\\", \\\"{x:1282,y:839,t:1527030474504};\\\", \\\"{x:1281,y:839,t:1527030474512};\\\", \\\"{x:1280,y:841,t:1527030474529};\\\", \\\"{x:1280,y:843,t:1527030474546};\\\", \\\"{x:1280,y:844,t:1527030474569};\\\", \\\"{x:1279,y:846,t:1527030474585};\\\", \\\"{x:1279,y:847,t:1527030474609};\\\", \\\"{x:1279,y:848,t:1527030474618};\\\", \\\"{x:1279,y:849,t:1527030474633};\\\", \\\"{x:1278,y:850,t:1527030474657};\\\", \\\"{x:1278,y:852,t:1527030474665};\\\", \\\"{x:1278,y:853,t:1527030474679};\\\", \\\"{x:1278,y:854,t:1527030474696};\\\", \\\"{x:1278,y:855,t:1527030474713};\\\", \\\"{x:1278,y:856,t:1527030475154};\\\", \\\"{x:1278,y:858,t:1527030475354};\\\", \\\"{x:1278,y:860,t:1527030475363};\\\", \\\"{x:1278,y:866,t:1527030475380};\\\", \\\"{x:1278,y:876,t:1527030475397};\\\", \\\"{x:1280,y:881,t:1527030475413};\\\", \\\"{x:1281,y:884,t:1527030475430};\\\", \\\"{x:1281,y:886,t:1527030475447};\\\", \\\"{x:1282,y:889,t:1527030475463};\\\", \\\"{x:1282,y:893,t:1527030475481};\\\", \\\"{x:1283,y:898,t:1527030475498};\\\", \\\"{x:1284,y:902,t:1527030475513};\\\", \\\"{x:1284,y:905,t:1527030475530};\\\", \\\"{x:1284,y:909,t:1527030475547};\\\", \\\"{x:1284,y:916,t:1527030475564};\\\", \\\"{x:1284,y:930,t:1527030475580};\\\", \\\"{x:1284,y:942,t:1527030475597};\\\", \\\"{x:1284,y:948,t:1527030475614};\\\", \\\"{x:1284,y:953,t:1527030475630};\\\", \\\"{x:1284,y:954,t:1527030475646};\\\", \\\"{x:1284,y:955,t:1527030475664};\\\", \\\"{x:1286,y:955,t:1527030475832};\\\", \\\"{x:1286,y:954,t:1527030475847};\\\", \\\"{x:1287,y:948,t:1527030475864};\\\", \\\"{x:1289,y:934,t:1527030475880};\\\", \\\"{x:1291,y:905,t:1527030475897};\\\", \\\"{x:1291,y:876,t:1527030475914};\\\", \\\"{x:1291,y:848,t:1527030475931};\\\", \\\"{x:1291,y:830,t:1527030475947};\\\", \\\"{x:1291,y:821,t:1527030475964};\\\", \\\"{x:1291,y:817,t:1527030475981};\\\", \\\"{x:1291,y:814,t:1527030475997};\\\", \\\"{x:1291,y:813,t:1527030476014};\\\", \\\"{x:1291,y:810,t:1527030476122};\\\", \\\"{x:1291,y:807,t:1527030476132};\\\", \\\"{x:1290,y:801,t:1527030476147};\\\", \\\"{x:1285,y:788,t:1527030476165};\\\", \\\"{x:1281,y:777,t:1527030476182};\\\", \\\"{x:1276,y:768,t:1527030476198};\\\", \\\"{x:1271,y:755,t:1527030476214};\\\", \\\"{x:1266,y:740,t:1527030476231};\\\", \\\"{x:1263,y:725,t:1527030476247};\\\", \\\"{x:1261,y:711,t:1527030476265};\\\", \\\"{x:1260,y:692,t:1527030476281};\\\", \\\"{x:1260,y:686,t:1527030476297};\\\", \\\"{x:1260,y:682,t:1527030476314};\\\", \\\"{x:1260,y:677,t:1527030476331};\\\", \\\"{x:1263,y:665,t:1527030476348};\\\", \\\"{x:1268,y:652,t:1527030476364};\\\", \\\"{x:1272,y:632,t:1527030476381};\\\", \\\"{x:1274,y:616,t:1527030476398};\\\", \\\"{x:1277,y:604,t:1527030476414};\\\", \\\"{x:1278,y:591,t:1527030476431};\\\", \\\"{x:1279,y:583,t:1527030476448};\\\", \\\"{x:1283,y:571,t:1527030476464};\\\", \\\"{x:1290,y:548,t:1527030476480};\\\", \\\"{x:1295,y:536,t:1527030476497};\\\", \\\"{x:1299,y:528,t:1527030476515};\\\", \\\"{x:1300,y:524,t:1527030476531};\\\", \\\"{x:1301,y:523,t:1527030476548};\\\", \\\"{x:1302,y:520,t:1527030476565};\\\", \\\"{x:1303,y:516,t:1527030476581};\\\", \\\"{x:1305,y:512,t:1527030476598};\\\", \\\"{x:1306,y:507,t:1527030476615};\\\", \\\"{x:1307,y:503,t:1527030476631};\\\", \\\"{x:1307,y:501,t:1527030476648};\\\", \\\"{x:1308,y:500,t:1527030476833};\\\", \\\"{x:1309,y:499,t:1527030476850};\\\", \\\"{x:1312,y:496,t:1527030476865};\\\", \\\"{x:1313,y:495,t:1527030476889};\\\", \\\"{x:1315,y:495,t:1527030477089};\\\", \\\"{x:1315,y:496,t:1527030477098};\\\", \\\"{x:1315,y:497,t:1527030477121};\\\", \\\"{x:1315,y:498,t:1527030477137};\\\", \\\"{x:1315,y:499,t:1527030477148};\\\", \\\"{x:1315,y:501,t:1527030477165};\\\", \\\"{x:1315,y:502,t:1527030477182};\\\", \\\"{x:1315,y:503,t:1527030477200};\\\", \\\"{x:1315,y:506,t:1527030477282};\\\", \\\"{x:1316,y:511,t:1527030477300};\\\", \\\"{x:1317,y:517,t:1527030477315};\\\", \\\"{x:1319,y:525,t:1527030477333};\\\", \\\"{x:1320,y:531,t:1527030477349};\\\", \\\"{x:1320,y:539,t:1527030477365};\\\", \\\"{x:1320,y:546,t:1527030477383};\\\", \\\"{x:1320,y:553,t:1527030477400};\\\", \\\"{x:1320,y:558,t:1527030477415};\\\", \\\"{x:1320,y:561,t:1527030477432};\\\", \\\"{x:1320,y:562,t:1527030477449};\\\", \\\"{x:1320,y:564,t:1527030477466};\\\", \\\"{x:1320,y:567,t:1527030477483};\\\", \\\"{x:1320,y:572,t:1527030477499};\\\", \\\"{x:1320,y:578,t:1527030477517};\\\", \\\"{x:1319,y:584,t:1527030477532};\\\", \\\"{x:1319,y:587,t:1527030477550};\\\", \\\"{x:1318,y:593,t:1527030477567};\\\", \\\"{x:1318,y:597,t:1527030477583};\\\", \\\"{x:1318,y:602,t:1527030477599};\\\", \\\"{x:1318,y:612,t:1527030477617};\\\", \\\"{x:1318,y:624,t:1527030477632};\\\", \\\"{x:1317,y:644,t:1527030477649};\\\", \\\"{x:1314,y:655,t:1527030477667};\\\", \\\"{x:1310,y:668,t:1527030477682};\\\", \\\"{x:1308,y:682,t:1527030477699};\\\", \\\"{x:1305,y:693,t:1527030477717};\\\", \\\"{x:1304,y:700,t:1527030477733};\\\", \\\"{x:1304,y:705,t:1527030477749};\\\", \\\"{x:1304,y:708,t:1527030477766};\\\", \\\"{x:1304,y:711,t:1527030477783};\\\", \\\"{x:1304,y:715,t:1527030477799};\\\", \\\"{x:1304,y:719,t:1527030477817};\\\", \\\"{x:1304,y:728,t:1527030477834};\\\", \\\"{x:1304,y:733,t:1527030477850};\\\", \\\"{x:1304,y:737,t:1527030477867};\\\", \\\"{x:1304,y:741,t:1527030477883};\\\", \\\"{x:1306,y:745,t:1527030477899};\\\", \\\"{x:1306,y:748,t:1527030477916};\\\", \\\"{x:1308,y:752,t:1527030477933};\\\", \\\"{x:1309,y:757,t:1527030477949};\\\", \\\"{x:1313,y:770,t:1527030477967};\\\", \\\"{x:1316,y:782,t:1527030477984};\\\", \\\"{x:1319,y:793,t:1527030478000};\\\", \\\"{x:1320,y:799,t:1527030478016};\\\", \\\"{x:1322,y:803,t:1527030478034};\\\", \\\"{x:1322,y:806,t:1527030478050};\\\", \\\"{x:1323,y:812,t:1527030478066};\\\", \\\"{x:1323,y:819,t:1527030478083};\\\", \\\"{x:1323,y:826,t:1527030478100};\\\", \\\"{x:1323,y:832,t:1527030478116};\\\", \\\"{x:1324,y:835,t:1527030478134};\\\", \\\"{x:1324,y:839,t:1527030478150};\\\", \\\"{x:1324,y:841,t:1527030478166};\\\", \\\"{x:1324,y:843,t:1527030478183};\\\", \\\"{x:1324,y:847,t:1527030478201};\\\", \\\"{x:1324,y:856,t:1527030478217};\\\", \\\"{x:1324,y:862,t:1527030478234};\\\", \\\"{x:1324,y:869,t:1527030478251};\\\", \\\"{x:1324,y:876,t:1527030478267};\\\", \\\"{x:1324,y:880,t:1527030478284};\\\", \\\"{x:1324,y:883,t:1527030478301};\\\", \\\"{x:1324,y:884,t:1527030478316};\\\", \\\"{x:1324,y:886,t:1527030478338};\\\", \\\"{x:1325,y:888,t:1527030478350};\\\", \\\"{x:1325,y:894,t:1527030478367};\\\", \\\"{x:1325,y:902,t:1527030478384};\\\", \\\"{x:1325,y:907,t:1527030478400};\\\", \\\"{x:1325,y:911,t:1527030478418};\\\", \\\"{x:1325,y:914,t:1527030478433};\\\", \\\"{x:1325,y:918,t:1527030478450};\\\", \\\"{x:1325,y:921,t:1527030478468};\\\", \\\"{x:1324,y:926,t:1527030478483};\\\", \\\"{x:1322,y:932,t:1527030478501};\\\", \\\"{x:1318,y:941,t:1527030478518};\\\", \\\"{x:1317,y:946,t:1527030478533};\\\", \\\"{x:1315,y:952,t:1527030478550};\\\", \\\"{x:1312,y:957,t:1527030478567};\\\", \\\"{x:1310,y:960,t:1527030478583};\\\", \\\"{x:1308,y:963,t:1527030478601};\\\", \\\"{x:1307,y:965,t:1527030478618};\\\", \\\"{x:1306,y:966,t:1527030478633};\\\", \\\"{x:1306,y:967,t:1527030478651};\\\", \\\"{x:1306,y:969,t:1527030478778};\\\", \\\"{x:1307,y:968,t:1527030478945};\\\", \\\"{x:1308,y:968,t:1527030478954};\\\", \\\"{x:1308,y:967,t:1527030478967};\\\", \\\"{x:1310,y:965,t:1527030478985};\\\", \\\"{x:1311,y:964,t:1527030479001};\\\", \\\"{x:1311,y:963,t:1527030479018};\\\", \\\"{x:1312,y:963,t:1527030479034};\\\", \\\"{x:1312,y:962,t:1527030479730};\\\", \\\"{x:1312,y:961,t:1527030479769};\\\", \\\"{x:1312,y:960,t:1527030479801};\\\", \\\"{x:1312,y:959,t:1527030479819};\\\", \\\"{x:1313,y:957,t:1527030479835};\\\", \\\"{x:1313,y:955,t:1527030479851};\\\", \\\"{x:1313,y:952,t:1527030479868};\\\", \\\"{x:1313,y:951,t:1527030479885};\\\", \\\"{x:1314,y:950,t:1527030479902};\\\", \\\"{x:1314,y:949,t:1527030480018};\\\", \\\"{x:1314,y:948,t:1527030480042};\\\", \\\"{x:1314,y:947,t:1527030480052};\\\", \\\"{x:1314,y:945,t:1527030480068};\\\", \\\"{x:1314,y:939,t:1527030480085};\\\", \\\"{x:1314,y:935,t:1527030480102};\\\", \\\"{x:1314,y:932,t:1527030480119};\\\", \\\"{x:1314,y:928,t:1527030480135};\\\", \\\"{x:1315,y:927,t:1527030480153};\\\", \\\"{x:1315,y:926,t:1527030480177};\\\", \\\"{x:1315,y:925,t:1527030480185};\\\", \\\"{x:1315,y:923,t:1527030480203};\\\", \\\"{x:1315,y:920,t:1527030480219};\\\", \\\"{x:1315,y:914,t:1527030480235};\\\", \\\"{x:1315,y:910,t:1527030480252};\\\", \\\"{x:1315,y:907,t:1527030480269};\\\", \\\"{x:1315,y:906,t:1527030480490};\\\", \\\"{x:1317,y:902,t:1527030480503};\\\", \\\"{x:1322,y:893,t:1527030480520};\\\", \\\"{x:1326,y:885,t:1527030480536};\\\", \\\"{x:1331,y:874,t:1527030480552};\\\", \\\"{x:1339,y:861,t:1527030480569};\\\", \\\"{x:1344,y:852,t:1527030480587};\\\", \\\"{x:1346,y:846,t:1527030480602};\\\", \\\"{x:1350,y:837,t:1527030480619};\\\", \\\"{x:1354,y:830,t:1527030480637};\\\", \\\"{x:1357,y:824,t:1527030480653};\\\", \\\"{x:1359,y:819,t:1527030480670};\\\", \\\"{x:1362,y:814,t:1527030480687};\\\", \\\"{x:1365,y:811,t:1527030480702};\\\", \\\"{x:1368,y:808,t:1527030480720};\\\", \\\"{x:1370,y:806,t:1527030480737};\\\", \\\"{x:1372,y:802,t:1527030480753};\\\", \\\"{x:1376,y:798,t:1527030480769};\\\", \\\"{x:1380,y:795,t:1527030480786};\\\", \\\"{x:1386,y:791,t:1527030480802};\\\", \\\"{x:1389,y:790,t:1527030480819};\\\", \\\"{x:1391,y:788,t:1527030480837};\\\", \\\"{x:1393,y:786,t:1527030480853};\\\", \\\"{x:1394,y:784,t:1527030480870};\\\", \\\"{x:1395,y:784,t:1527030480886};\\\", \\\"{x:1395,y:783,t:1527030480902};\\\", \\\"{x:1396,y:783,t:1527030481210};\\\", \\\"{x:1399,y:783,t:1527030481220};\\\", \\\"{x:1412,y:783,t:1527030481237};\\\", \\\"{x:1427,y:785,t:1527030481254};\\\", \\\"{x:1443,y:791,t:1527030481269};\\\", \\\"{x:1458,y:797,t:1527030481287};\\\", \\\"{x:1472,y:803,t:1527030481304};\\\", \\\"{x:1483,y:808,t:1527030481320};\\\", \\\"{x:1491,y:814,t:1527030481336};\\\", \\\"{x:1502,y:820,t:1527030481353};\\\", \\\"{x:1504,y:822,t:1527030481371};\\\", \\\"{x:1506,y:824,t:1527030481386};\\\", \\\"{x:1507,y:826,t:1527030481418};\\\", \\\"{x:1507,y:827,t:1527030481433};\\\", \\\"{x:1507,y:830,t:1527030481441};\\\", \\\"{x:1507,y:835,t:1527030481454};\\\", \\\"{x:1507,y:849,t:1527030481471};\\\", \\\"{x:1508,y:862,t:1527030481487};\\\", \\\"{x:1512,y:873,t:1527030481503};\\\", \\\"{x:1513,y:879,t:1527030481521};\\\", \\\"{x:1514,y:884,t:1527030481537};\\\", \\\"{x:1517,y:894,t:1527030481554};\\\", \\\"{x:1521,y:908,t:1527030481570};\\\", \\\"{x:1526,y:923,t:1527030481587};\\\", \\\"{x:1528,y:933,t:1527030481603};\\\", \\\"{x:1532,y:942,t:1527030481621};\\\", \\\"{x:1537,y:952,t:1527030481638};\\\", \\\"{x:1542,y:959,t:1527030481653};\\\", \\\"{x:1546,y:964,t:1527030481671};\\\", \\\"{x:1555,y:975,t:1527030481688};\\\", \\\"{x:1567,y:987,t:1527030481704};\\\", \\\"{x:1581,y:1001,t:1527030481721};\\\", \\\"{x:1597,y:1017,t:1527030481737};\\\", \\\"{x:1605,y:1023,t:1527030481753};\\\", \\\"{x:1613,y:1027,t:1527030481771};\\\", \\\"{x:1615,y:1028,t:1527030481787};\\\", \\\"{x:1616,y:1028,t:1527030481881};\\\", \\\"{x:1617,y:1027,t:1527030481889};\\\", \\\"{x:1617,y:1026,t:1527030481903};\\\", \\\"{x:1617,y:1023,t:1527030481920};\\\", \\\"{x:1617,y:1017,t:1527030481936};\\\", \\\"{x:1619,y:1015,t:1527030481954};\\\", \\\"{x:1620,y:1013,t:1527030481970};\\\", \\\"{x:1621,y:1013,t:1527030481987};\\\", \\\"{x:1621,y:1012,t:1527030482004};\\\", \\\"{x:1621,y:1011,t:1527030482020};\\\", \\\"{x:1621,y:1010,t:1527030482038};\\\", \\\"{x:1620,y:1009,t:1527030482054};\\\", \\\"{x:1619,y:1008,t:1527030482071};\\\", \\\"{x:1618,y:1007,t:1527030482113};\\\", \\\"{x:1614,y:1008,t:1527030482873};\\\", \\\"{x:1609,y:1012,t:1527030482889};\\\", \\\"{x:1604,y:1015,t:1527030482905};\\\", \\\"{x:1602,y:1016,t:1527030482922};\\\", \\\"{x:1601,y:1015,t:1527030483162};\\\", \\\"{x:1601,y:1012,t:1527030483172};\\\", \\\"{x:1601,y:1008,t:1527030483188};\\\", \\\"{x:1601,y:1005,t:1527030483205};\\\", \\\"{x:1601,y:1002,t:1527030483222};\\\", \\\"{x:1600,y:1002,t:1527030483239};\\\", \\\"{x:1599,y:1000,t:1527030483401};\\\", \\\"{x:1597,y:1000,t:1527030483409};\\\", \\\"{x:1593,y:998,t:1527030483422};\\\", \\\"{x:1589,y:995,t:1527030483438};\\\", \\\"{x:1588,y:994,t:1527030483456};\\\", \\\"{x:1587,y:993,t:1527030483473};\\\", \\\"{x:1587,y:991,t:1527030483489};\\\", \\\"{x:1588,y:987,t:1527030483505};\\\", \\\"{x:1588,y:986,t:1527030483523};\\\", \\\"{x:1588,y:985,t:1527030483540};\\\", \\\"{x:1588,y:983,t:1527030483555};\\\", \\\"{x:1587,y:979,t:1527030483573};\\\", \\\"{x:1587,y:967,t:1527030483589};\\\", \\\"{x:1587,y:951,t:1527030483605};\\\", \\\"{x:1594,y:925,t:1527030483622};\\\", \\\"{x:1595,y:902,t:1527030483639};\\\", \\\"{x:1594,y:885,t:1527030483655};\\\", \\\"{x:1584,y:870,t:1527030483673};\\\", \\\"{x:1580,y:866,t:1527030483689};\\\", \\\"{x:1577,y:864,t:1527030483706};\\\", \\\"{x:1574,y:864,t:1527030483825};\\\", \\\"{x:1573,y:864,t:1527030483839};\\\", \\\"{x:1568,y:864,t:1527030483857};\\\", \\\"{x:1567,y:864,t:1527030483873};\\\", \\\"{x:1566,y:864,t:1527030483938};\\\", \\\"{x:1561,y:865,t:1527030483945};\\\", \\\"{x:1560,y:867,t:1527030483956};\\\", \\\"{x:1553,y:879,t:1527030483972};\\\", \\\"{x:1548,y:896,t:1527030483990};\\\", \\\"{x:1540,y:910,t:1527030484007};\\\", \\\"{x:1532,y:918,t:1527030484023};\\\", \\\"{x:1517,y:922,t:1527030484040};\\\", \\\"{x:1502,y:923,t:1527030484056};\\\", \\\"{x:1480,y:924,t:1527030484073};\\\", \\\"{x:1469,y:924,t:1527030484090};\\\", \\\"{x:1462,y:924,t:1527030484107};\\\", \\\"{x:1457,y:924,t:1527030484124};\\\", \\\"{x:1456,y:924,t:1527030484139};\\\", \\\"{x:1455,y:924,t:1527030484161};\\\", \\\"{x:1455,y:922,t:1527030484173};\\\", \\\"{x:1452,y:915,t:1527030484190};\\\", \\\"{x:1447,y:909,t:1527030484206};\\\", \\\"{x:1435,y:902,t:1527030484223};\\\", \\\"{x:1423,y:898,t:1527030484239};\\\", \\\"{x:1415,y:895,t:1527030484257};\\\", \\\"{x:1398,y:892,t:1527030484273};\\\", \\\"{x:1384,y:890,t:1527030484290};\\\", \\\"{x:1369,y:890,t:1527030484307};\\\", \\\"{x:1355,y:890,t:1527030484324};\\\", \\\"{x:1340,y:890,t:1527030484340};\\\", \\\"{x:1327,y:893,t:1527030484357};\\\", \\\"{x:1309,y:900,t:1527030484374};\\\", \\\"{x:1290,y:906,t:1527030484390};\\\", \\\"{x:1274,y:911,t:1527030484406};\\\", \\\"{x:1265,y:913,t:1527030484424};\\\", \\\"{x:1260,y:914,t:1527030484441};\\\", \\\"{x:1257,y:914,t:1527030484456};\\\", \\\"{x:1248,y:914,t:1527030484473};\\\", \\\"{x:1244,y:914,t:1527030484490};\\\", \\\"{x:1239,y:913,t:1527030484506};\\\", \\\"{x:1230,y:907,t:1527030484523};\\\", \\\"{x:1217,y:898,t:1527030484540};\\\", \\\"{x:1212,y:894,t:1527030484556};\\\", \\\"{x:1211,y:892,t:1527030484573};\\\", \\\"{x:1211,y:891,t:1527030484625};\\\", \\\"{x:1211,y:888,t:1527030484640};\\\", \\\"{x:1212,y:880,t:1527030484656};\\\", \\\"{x:1216,y:873,t:1527030484674};\\\", \\\"{x:1217,y:872,t:1527030484691};\\\", \\\"{x:1218,y:871,t:1527030484706};\\\", \\\"{x:1219,y:871,t:1527030484723};\\\", \\\"{x:1220,y:866,t:1527030484741};\\\", \\\"{x:1220,y:862,t:1527030484757};\\\", \\\"{x:1220,y:857,t:1527030484773};\\\", \\\"{x:1220,y:848,t:1527030484791};\\\", \\\"{x:1221,y:845,t:1527030484808};\\\", \\\"{x:1223,y:844,t:1527030485002};\\\", \\\"{x:1227,y:847,t:1527030485009};\\\", \\\"{x:1232,y:854,t:1527030485024};\\\", \\\"{x:1247,y:869,t:1527030485041};\\\", \\\"{x:1267,y:884,t:1527030485057};\\\", \\\"{x:1276,y:889,t:1527030485075};\\\", \\\"{x:1280,y:891,t:1527030485090};\\\", \\\"{x:1281,y:892,t:1527030485154};\\\", \\\"{x:1284,y:894,t:1527030485162};\\\", \\\"{x:1286,y:895,t:1527030485175};\\\", \\\"{x:1290,y:897,t:1527030485191};\\\", \\\"{x:1293,y:901,t:1527030485208};\\\", \\\"{x:1294,y:904,t:1527030485225};\\\", \\\"{x:1295,y:910,t:1527030485241};\\\", \\\"{x:1295,y:914,t:1527030485258};\\\", \\\"{x:1295,y:917,t:1527030485274};\\\", \\\"{x:1295,y:921,t:1527030485291};\\\", \\\"{x:1295,y:924,t:1527030485308};\\\", \\\"{x:1295,y:926,t:1527030485577};\\\", \\\"{x:1295,y:927,t:1527030485593};\\\", \\\"{x:1295,y:928,t:1527030485832};\\\", \\\"{x:1295,y:930,t:1527030485841};\\\", \\\"{x:1295,y:933,t:1527030485858};\\\", \\\"{x:1295,y:936,t:1527030485875};\\\", \\\"{x:1295,y:938,t:1527030485891};\\\", \\\"{x:1296,y:942,t:1527030485908};\\\", \\\"{x:1296,y:945,t:1527030485925};\\\", \\\"{x:1297,y:947,t:1527030485942};\\\", \\\"{x:1298,y:948,t:1527030485958};\\\", \\\"{x:1298,y:950,t:1527030485975};\\\", \\\"{x:1300,y:951,t:1527030486018};\\\", \\\"{x:1300,y:952,t:1527030486065};\\\", \\\"{x:1301,y:953,t:1527030486170};\\\", \\\"{x:1303,y:954,t:1527030486177};\\\", \\\"{x:1304,y:955,t:1527030486192};\\\", \\\"{x:1312,y:958,t:1527030486209};\\\", \\\"{x:1323,y:961,t:1527030486225};\\\", \\\"{x:1329,y:962,t:1527030486241};\\\", \\\"{x:1337,y:963,t:1527030486259};\\\", \\\"{x:1340,y:965,t:1527030486276};\\\", \\\"{x:1342,y:966,t:1527030486296};\\\", \\\"{x:1343,y:966,t:1527030486337};\\\", \\\"{x:1344,y:966,t:1527030486969};\\\", \\\"{x:1345,y:966,t:1527030486985};\\\", \\\"{x:1346,y:966,t:1527030487018};\\\", \\\"{x:1347,y:967,t:1527030487994};\\\", \\\"{x:1348,y:967,t:1527030488058};\\\", \\\"{x:1349,y:967,t:1527030488065};\\\", \\\"{x:1350,y:968,t:1527030488810};\\\", \\\"{x:1351,y:968,t:1527030488825};\\\", \\\"{x:1352,y:968,t:1527030488833};\\\", \\\"{x:1353,y:968,t:1527030488845};\\\", \\\"{x:1354,y:968,t:1527030488873};\\\", \\\"{x:1355,y:968,t:1527030488897};\\\", \\\"{x:1356,y:967,t:1527030488913};\\\", \\\"{x:1358,y:967,t:1527030488929};\\\", \\\"{x:1359,y:966,t:1527030488945};\\\", \\\"{x:1360,y:965,t:1527030488962};\\\", \\\"{x:1360,y:964,t:1527030488979};\\\", \\\"{x:1361,y:964,t:1527030488995};\\\", \\\"{x:1362,y:963,t:1527030489011};\\\", \\\"{x:1365,y:963,t:1527030489029};\\\", \\\"{x:1377,y:962,t:1527030489045};\\\", \\\"{x:1390,y:962,t:1527030489062};\\\", \\\"{x:1405,y:962,t:1527030489079};\\\", \\\"{x:1413,y:962,t:1527030489095};\\\", \\\"{x:1418,y:962,t:1527030489112};\\\", \\\"{x:1420,y:962,t:1527030489377};\\\", \\\"{x:1422,y:962,t:1527030489393};\\\", \\\"{x:1424,y:962,t:1527030489400};\\\", \\\"{x:1428,y:962,t:1527030489412};\\\", \\\"{x:1441,y:962,t:1527030489429};\\\", \\\"{x:1456,y:962,t:1527030489446};\\\", \\\"{x:1471,y:962,t:1527030489462};\\\", \\\"{x:1486,y:962,t:1527030489478};\\\", \\\"{x:1487,y:962,t:1527030489496};\\\", \\\"{x:1489,y:962,t:1527030489513};\\\", \\\"{x:1489,y:963,t:1527030489553};\\\", \\\"{x:1489,y:964,t:1527030489594};\\\", \\\"{x:1488,y:964,t:1527030490034};\\\", \\\"{x:1487,y:964,t:1527030490050};\\\", \\\"{x:1486,y:964,t:1527030490063};\\\", \\\"{x:1485,y:963,t:1527030490080};\\\", \\\"{x:1484,y:961,t:1527030490096};\\\", \\\"{x:1482,y:954,t:1527030490113};\\\", \\\"{x:1480,y:949,t:1527030490130};\\\", \\\"{x:1478,y:941,t:1527030490146};\\\", \\\"{x:1474,y:928,t:1527030490163};\\\", \\\"{x:1471,y:918,t:1527030490180};\\\", \\\"{x:1469,y:910,t:1527030490197};\\\", \\\"{x:1466,y:901,t:1527030490213};\\\", \\\"{x:1465,y:894,t:1527030490229};\\\", \\\"{x:1465,y:892,t:1527030490247};\\\", \\\"{x:1465,y:889,t:1527030490262};\\\", \\\"{x:1465,y:885,t:1527030490280};\\\", \\\"{x:1465,y:881,t:1527030490297};\\\", \\\"{x:1465,y:877,t:1527030490313};\\\", \\\"{x:1465,y:876,t:1527030490330};\\\", \\\"{x:1465,y:873,t:1527030490346};\\\", \\\"{x:1465,y:870,t:1527030490362};\\\", \\\"{x:1465,y:866,t:1527030490380};\\\", \\\"{x:1465,y:862,t:1527030490396};\\\", \\\"{x:1465,y:860,t:1527030490413};\\\", \\\"{x:1465,y:856,t:1527030490430};\\\", \\\"{x:1465,y:854,t:1527030490447};\\\", \\\"{x:1465,y:853,t:1527030490463};\\\", \\\"{x:1465,y:852,t:1527030490479};\\\", \\\"{x:1465,y:851,t:1527030490497};\\\", \\\"{x:1465,y:849,t:1527030490521};\\\", \\\"{x:1465,y:848,t:1527030490553};\\\", \\\"{x:1465,y:847,t:1527030490564};\\\", \\\"{x:1465,y:846,t:1527030490580};\\\", \\\"{x:1465,y:845,t:1527030490597};\\\", \\\"{x:1465,y:843,t:1527030490614};\\\", \\\"{x:1465,y:842,t:1527030490633};\\\", \\\"{x:1465,y:841,t:1527030490650};\\\", \\\"{x:1465,y:840,t:1527030491410};\\\", \\\"{x:1465,y:839,t:1527030491419};\\\", \\\"{x:1465,y:838,t:1527030491431};\\\", \\\"{x:1467,y:834,t:1527030491447};\\\", \\\"{x:1468,y:831,t:1527030491465};\\\", \\\"{x:1469,y:830,t:1527030491481};\\\", \\\"{x:1470,y:828,t:1527030491499};\\\", \\\"{x:1470,y:826,t:1527030491537};\\\", \\\"{x:1472,y:824,t:1527030491577};\\\", \\\"{x:1473,y:823,t:1527030491586};\\\", \\\"{x:1473,y:820,t:1527030491598};\\\", \\\"{x:1476,y:809,t:1527030491615};\\\", \\\"{x:1477,y:801,t:1527030491631};\\\", \\\"{x:1478,y:792,t:1527030491648};\\\", \\\"{x:1479,y:779,t:1527030491665};\\\", \\\"{x:1479,y:761,t:1527030491681};\\\", \\\"{x:1479,y:738,t:1527030491698};\\\", \\\"{x:1481,y:711,t:1527030491715};\\\", \\\"{x:1482,y:682,t:1527030491732};\\\", \\\"{x:1487,y:657,t:1527030491748};\\\", \\\"{x:1489,y:638,t:1527030491765};\\\", \\\"{x:1490,y:626,t:1527030491782};\\\", \\\"{x:1492,y:617,t:1527030491798};\\\", \\\"{x:1493,y:611,t:1527030491814};\\\", \\\"{x:1493,y:604,t:1527030491831};\\\", \\\"{x:1493,y:591,t:1527030491847};\\\", \\\"{x:1492,y:578,t:1527030491864};\\\", \\\"{x:1491,y:572,t:1527030491881};\\\", \\\"{x:1488,y:567,t:1527030491898};\\\", \\\"{x:1483,y:557,t:1527030491915};\\\", \\\"{x:1477,y:541,t:1527030491931};\\\", \\\"{x:1466,y:526,t:1527030491948};\\\", \\\"{x:1458,y:514,t:1527030491964};\\\", \\\"{x:1450,y:505,t:1527030491981};\\\", \\\"{x:1440,y:494,t:1527030491997};\\\", \\\"{x:1430,y:486,t:1527030492014};\\\", \\\"{x:1422,y:478,t:1527030492031};\\\", \\\"{x:1420,y:475,t:1527030492048};\\\", \\\"{x:1420,y:473,t:1527030492065};\\\", \\\"{x:1419,y:472,t:1527030492082};\\\", \\\"{x:1419,y:469,t:1527030492099};\\\", \\\"{x:1419,y:467,t:1527030492122};\\\", \\\"{x:1418,y:467,t:1527030492162};\\\", \\\"{x:1418,y:466,t:1527030492219};\\\", \\\"{x:1418,y:464,t:1527030492232};\\\", \\\"{x:1418,y:461,t:1527030492249};\\\", \\\"{x:1419,y:459,t:1527030492265};\\\", \\\"{x:1419,y:458,t:1527030492282};\\\", \\\"{x:1419,y:456,t:1527030492299};\\\", \\\"{x:1419,y:455,t:1527030492322};\\\", \\\"{x:1419,y:454,t:1527030492337};\\\", \\\"{x:1419,y:453,t:1527030492394};\\\", \\\"{x:1416,y:453,t:1527030492569};\\\", \\\"{x:1405,y:464,t:1527030492582};\\\", \\\"{x:1350,y:525,t:1527030492599};\\\", \\\"{x:1260,y:610,t:1527030492616};\\\", \\\"{x:1159,y:692,t:1527030492632};\\\", \\\"{x:1015,y:772,t:1527030492649};\\\", \\\"{x:935,y:806,t:1527030492666};\\\", \\\"{x:861,y:836,t:1527030492683};\\\", \\\"{x:798,y:850,t:1527030492699};\\\", \\\"{x:747,y:865,t:1527030492716};\\\", \\\"{x:695,y:878,t:1527030492732};\\\", \\\"{x:642,y:886,t:1527030492748};\\\", \\\"{x:594,y:886,t:1527030492765};\\\", \\\"{x:572,y:885,t:1527030492783};\\\", \\\"{x:559,y:878,t:1527030492799};\\\", \\\"{x:544,y:865,t:1527030492816};\\\", \\\"{x:519,y:840,t:1527030492833};\\\", \\\"{x:512,y:829,t:1527030492848};\\\", \\\"{x:511,y:825,t:1527030492866};\\\", \\\"{x:511,y:820,t:1527030492883};\\\", \\\"{x:511,y:809,t:1527030492899};\\\", \\\"{x:512,y:793,t:1527030492916};\\\", \\\"{x:515,y:786,t:1527030492933};\\\", \\\"{x:516,y:782,t:1527030492949};\\\", \\\"{x:518,y:778,t:1527030492966};\\\", \\\"{x:519,y:775,t:1527030492983};\\\", \\\"{x:524,y:766,t:1527030493000};\\\", \\\"{x:525,y:761,t:1527030493016};\\\", \\\"{x:528,y:752,t:1527030493033};\\\", \\\"{x:529,y:748,t:1527030493050};\\\", \\\"{x:529,y:744,t:1527030493065};\\\", \\\"{x:529,y:741,t:1527030493083};\\\", \\\"{x:529,y:740,t:1527030493105};\\\", \\\"{x:531,y:737,t:1527030493137};\\\", \\\"{x:532,y:735,t:1527030493151};\\\", \\\"{x:534,y:731,t:1527030493165};\\\" ] }, { \\\"rt\\\": 59746, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 509800, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -12 PM-12 PM-01 PM-09 AM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:730,t:1527030497921};\\\", \\\"{x:545,y:724,t:1527030503321};\\\", \\\"{x:558,y:720,t:1527030503329};\\\", \\\"{x:575,y:715,t:1527030503346};\\\", \\\"{x:592,y:710,t:1527030503362};\\\", \\\"{x:622,y:703,t:1527030503378};\\\", \\\"{x:671,y:692,t:1527030503396};\\\", \\\"{x:723,y:681,t:1527030503413};\\\", \\\"{x:759,y:677,t:1527030503430};\\\", \\\"{x:778,y:675,t:1527030503445};\\\", \\\"{x:790,y:674,t:1527030503463};\\\", \\\"{x:799,y:674,t:1527030503480};\\\", \\\"{x:802,y:673,t:1527030503496};\\\", \\\"{x:804,y:673,t:1527030503568};\\\", \\\"{x:806,y:673,t:1527030503585};\\\", \\\"{x:807,y:671,t:1527030503641};\\\", \\\"{x:808,y:671,t:1527030503648};\\\", \\\"{x:819,y:671,t:1527030503857};\\\", \\\"{x:861,y:663,t:1527030503865};\\\", \\\"{x:1005,y:641,t:1527030503881};\\\", \\\"{x:1130,y:622,t:1527030503898};\\\", \\\"{x:1227,y:611,t:1527030503913};\\\", \\\"{x:1282,y:604,t:1527030503930};\\\", \\\"{x:1309,y:604,t:1527030503947};\\\", \\\"{x:1323,y:604,t:1527030503964};\\\", \\\"{x:1324,y:603,t:1527030503981};\\\", \\\"{x:1327,y:604,t:1527030504009};\\\", \\\"{x:1334,y:610,t:1527030504018};\\\", \\\"{x:1340,y:619,t:1527030504030};\\\", \\\"{x:1352,y:645,t:1527030504047};\\\", \\\"{x:1358,y:674,t:1527030504064};\\\", \\\"{x:1365,y:713,t:1527030504081};\\\", \\\"{x:1375,y:737,t:1527030504097};\\\", \\\"{x:1387,y:760,t:1527030504115};\\\", \\\"{x:1397,y:778,t:1527030504130};\\\", \\\"{x:1407,y:796,t:1527030504148};\\\", \\\"{x:1420,y:820,t:1527030504164};\\\", \\\"{x:1437,y:847,t:1527030504180};\\\", \\\"{x:1449,y:869,t:1527030504198};\\\", \\\"{x:1460,y:884,t:1527030504214};\\\", \\\"{x:1466,y:890,t:1527030504230};\\\", \\\"{x:1469,y:892,t:1527030504247};\\\", \\\"{x:1470,y:893,t:1527030504265};\\\", \\\"{x:1470,y:895,t:1527030504321};\\\", \\\"{x:1471,y:896,t:1527030504337};\\\", \\\"{x:1472,y:897,t:1527030504348};\\\", \\\"{x:1472,y:899,t:1527030504364};\\\", \\\"{x:1472,y:898,t:1527030505098};\\\", \\\"{x:1472,y:899,t:1527030509168};\\\", \\\"{x:1472,y:898,t:1527030509328};\\\", \\\"{x:1472,y:896,t:1527030509336};\\\", \\\"{x:1472,y:895,t:1527030509352};\\\", \\\"{x:1474,y:890,t:1527030509368};\\\", \\\"{x:1475,y:889,t:1527030509385};\\\", \\\"{x:1476,y:887,t:1527030509402};\\\", \\\"{x:1479,y:885,t:1527030509419};\\\", \\\"{x:1492,y:879,t:1527030509436};\\\", \\\"{x:1504,y:873,t:1527030509452};\\\", \\\"{x:1519,y:868,t:1527030509469};\\\", \\\"{x:1529,y:863,t:1527030509486};\\\", \\\"{x:1537,y:859,t:1527030509503};\\\", \\\"{x:1542,y:857,t:1527030509518};\\\", \\\"{x:1545,y:856,t:1527030509535};\\\", \\\"{x:1556,y:855,t:1527030509552};\\\", \\\"{x:1561,y:853,t:1527030509569};\\\", \\\"{x:1563,y:853,t:1527030509586};\\\", \\\"{x:1565,y:852,t:1527030509602};\\\", \\\"{x:1567,y:851,t:1527030509619};\\\", \\\"{x:1569,y:849,t:1527030509636};\\\", \\\"{x:1574,y:846,t:1527030509652};\\\", \\\"{x:1584,y:836,t:1527030509668};\\\", \\\"{x:1596,y:820,t:1527030509685};\\\", \\\"{x:1603,y:809,t:1527030509703};\\\", \\\"{x:1608,y:795,t:1527030509719};\\\", \\\"{x:1612,y:786,t:1527030509735};\\\", \\\"{x:1612,y:779,t:1527030509752};\\\", \\\"{x:1612,y:774,t:1527030509769};\\\", \\\"{x:1612,y:766,t:1527030509786};\\\", \\\"{x:1612,y:753,t:1527030509803};\\\", \\\"{x:1612,y:731,t:1527030509820};\\\", \\\"{x:1604,y:710,t:1527030509836};\\\", \\\"{x:1598,y:695,t:1527030509853};\\\", \\\"{x:1593,y:681,t:1527030509870};\\\", \\\"{x:1588,y:672,t:1527030509885};\\\", \\\"{x:1582,y:651,t:1527030509902};\\\", \\\"{x:1570,y:620,t:1527030509920};\\\", \\\"{x:1557,y:594,t:1527030509936};\\\", \\\"{x:1541,y:555,t:1527030509953};\\\", \\\"{x:1532,y:528,t:1527030509969};\\\", \\\"{x:1523,y:513,t:1527030509986};\\\", \\\"{x:1519,y:506,t:1527030510003};\\\", \\\"{x:1512,y:495,t:1527030510020};\\\", \\\"{x:1503,y:479,t:1527030510035};\\\", \\\"{x:1498,y:472,t:1527030510053};\\\", \\\"{x:1495,y:469,t:1527030510070};\\\", \\\"{x:1493,y:467,t:1527030510086};\\\", \\\"{x:1491,y:466,t:1527030510103};\\\", \\\"{x:1491,y:465,t:1527030510120};\\\", \\\"{x:1491,y:464,t:1527030510136};\\\", \\\"{x:1490,y:464,t:1527030510369};\\\", \\\"{x:1489,y:468,t:1527030510387};\\\", \\\"{x:1491,y:486,t:1527030510403};\\\", \\\"{x:1492,y:508,t:1527030510420};\\\", \\\"{x:1495,y:533,t:1527030510437};\\\", \\\"{x:1495,y:552,t:1527030510453};\\\", \\\"{x:1495,y:565,t:1527030510469};\\\", \\\"{x:1496,y:572,t:1527030510487};\\\", \\\"{x:1496,y:578,t:1527030510503};\\\", \\\"{x:1496,y:581,t:1527030510520};\\\", \\\"{x:1496,y:585,t:1527030510537};\\\", \\\"{x:1496,y:587,t:1527030510553};\\\", \\\"{x:1496,y:588,t:1527030510570};\\\", \\\"{x:1496,y:589,t:1527030510587};\\\", \\\"{x:1496,y:590,t:1527030510617};\\\", \\\"{x:1496,y:589,t:1527030510681};\\\", \\\"{x:1492,y:581,t:1527030510689};\\\", \\\"{x:1487,y:570,t:1527030510704};\\\", \\\"{x:1475,y:537,t:1527030510719};\\\", \\\"{x:1446,y:462,t:1527030510737};\\\", \\\"{x:1433,y:434,t:1527030510753};\\\", \\\"{x:1426,y:414,t:1527030510770};\\\", \\\"{x:1417,y:400,t:1527030510787};\\\", \\\"{x:1408,y:390,t:1527030510805};\\\", \\\"{x:1402,y:385,t:1527030510820};\\\", \\\"{x:1394,y:381,t:1527030510836};\\\", \\\"{x:1390,y:381,t:1527030510853};\\\", \\\"{x:1385,y:381,t:1527030510869};\\\", \\\"{x:1380,y:381,t:1527030510886};\\\", \\\"{x:1370,y:386,t:1527030510903};\\\", \\\"{x:1352,y:401,t:1527030510919};\\\", \\\"{x:1335,y:447,t:1527030510937};\\\", \\\"{x:1326,y:488,t:1527030510953};\\\", \\\"{x:1323,y:511,t:1527030510971};\\\", \\\"{x:1322,y:527,t:1527030510987};\\\", \\\"{x:1322,y:533,t:1527030511003};\\\", \\\"{x:1323,y:537,t:1527030511020};\\\", \\\"{x:1326,y:540,t:1527030511037};\\\", \\\"{x:1327,y:541,t:1527030511054};\\\", \\\"{x:1328,y:540,t:1527030511130};\\\", \\\"{x:1328,y:537,t:1527030511137};\\\", \\\"{x:1328,y:531,t:1527030511154};\\\", \\\"{x:1328,y:525,t:1527030511171};\\\", \\\"{x:1326,y:522,t:1527030511187};\\\", \\\"{x:1326,y:521,t:1527030511204};\\\", \\\"{x:1326,y:519,t:1527030511221};\\\", \\\"{x:1326,y:517,t:1527030511474};\\\", \\\"{x:1325,y:516,t:1527030511488};\\\", \\\"{x:1325,y:514,t:1527030511504};\\\", \\\"{x:1325,y:513,t:1527030511521};\\\", \\\"{x:1323,y:511,t:1527030511545};\\\", \\\"{x:1323,y:510,t:1527030511745};\\\", \\\"{x:1323,y:508,t:1527030511777};\\\", \\\"{x:1323,y:507,t:1527030511801};\\\", \\\"{x:1322,y:506,t:1527030511809};\\\", \\\"{x:1322,y:508,t:1527030512857};\\\", \\\"{x:1322,y:521,t:1527030512872};\\\", \\\"{x:1311,y:583,t:1527030512889};\\\", \\\"{x:1308,y:621,t:1527030512905};\\\", \\\"{x:1308,y:653,t:1527030512922};\\\", \\\"{x:1308,y:679,t:1527030512939};\\\", \\\"{x:1307,y:702,t:1527030512955};\\\", \\\"{x:1303,y:724,t:1527030512972};\\\", \\\"{x:1300,y:738,t:1527030512989};\\\", \\\"{x:1299,y:744,t:1527030513006};\\\", \\\"{x:1299,y:746,t:1527030513022};\\\", \\\"{x:1299,y:747,t:1527030513039};\\\", \\\"{x:1299,y:742,t:1527030513105};\\\", \\\"{x:1299,y:729,t:1527030513122};\\\", \\\"{x:1299,y:704,t:1527030513138};\\\", \\\"{x:1296,y:670,t:1527030513155};\\\", \\\"{x:1294,y:644,t:1527030513173};\\\", \\\"{x:1294,y:629,t:1527030513189};\\\", \\\"{x:1293,y:616,t:1527030513206};\\\", \\\"{x:1291,y:596,t:1527030513222};\\\", \\\"{x:1291,y:567,t:1527030513238};\\\", \\\"{x:1291,y:541,t:1527030513255};\\\", \\\"{x:1291,y:530,t:1527030513272};\\\", \\\"{x:1291,y:525,t:1527030513288};\\\", \\\"{x:1291,y:522,t:1527030513305};\\\", \\\"{x:1291,y:521,t:1527030513322};\\\", \\\"{x:1291,y:520,t:1527030513368};\\\", \\\"{x:1291,y:519,t:1527030513384};\\\", \\\"{x:1291,y:518,t:1527030513391};\\\", \\\"{x:1292,y:517,t:1527030513408};\\\", \\\"{x:1292,y:516,t:1527030513424};\\\", \\\"{x:1293,y:516,t:1527030513438};\\\", \\\"{x:1295,y:512,t:1527030513455};\\\", \\\"{x:1301,y:506,t:1527030513472};\\\", \\\"{x:1303,y:504,t:1527030513489};\\\", \\\"{x:1304,y:503,t:1527030513505};\\\", \\\"{x:1305,y:503,t:1527030513537};\\\", \\\"{x:1306,y:503,t:1527030513553};\\\", \\\"{x:1307,y:503,t:1527030513561};\\\", \\\"{x:1308,y:503,t:1527030513573};\\\", \\\"{x:1309,y:503,t:1527030513589};\\\", \\\"{x:1311,y:503,t:1527030513617};\\\", \\\"{x:1312,y:505,t:1527030513632};\\\", \\\"{x:1312,y:507,t:1527030513640};\\\", \\\"{x:1313,y:510,t:1527030513655};\\\", \\\"{x:1314,y:518,t:1527030513673};\\\", \\\"{x:1316,y:528,t:1527030513689};\\\", \\\"{x:1318,y:542,t:1527030513706};\\\", \\\"{x:1319,y:553,t:1527030513723};\\\", \\\"{x:1321,y:562,t:1527030513740};\\\", \\\"{x:1321,y:570,t:1527030513755};\\\", \\\"{x:1322,y:584,t:1527030513772};\\\", \\\"{x:1327,y:601,t:1527030513790};\\\", \\\"{x:1331,y:617,t:1527030513806};\\\", \\\"{x:1335,y:633,t:1527030513823};\\\", \\\"{x:1340,y:652,t:1527030513840};\\\", \\\"{x:1343,y:668,t:1527030513856};\\\", \\\"{x:1343,y:682,t:1527030513873};\\\", \\\"{x:1343,y:685,t:1527030513890};\\\", \\\"{x:1343,y:688,t:1527030513906};\\\", \\\"{x:1342,y:693,t:1527030513923};\\\", \\\"{x:1338,y:701,t:1527030513941};\\\", \\\"{x:1334,y:712,t:1527030513956};\\\", \\\"{x:1329,y:721,t:1527030513973};\\\", \\\"{x:1327,y:728,t:1527030513990};\\\", \\\"{x:1324,y:732,t:1527030514007};\\\", \\\"{x:1318,y:738,t:1527030514023};\\\", \\\"{x:1317,y:739,t:1527030514039};\\\", \\\"{x:1316,y:740,t:1527030514056};\\\", \\\"{x:1315,y:741,t:1527030514080};\\\", \\\"{x:1314,y:743,t:1527030514104};\\\", \\\"{x:1311,y:745,t:1527030514128};\\\", \\\"{x:1311,y:747,t:1527030514140};\\\", \\\"{x:1309,y:753,t:1527030514157};\\\", \\\"{x:1306,y:765,t:1527030514173};\\\", \\\"{x:1305,y:777,t:1527030514190};\\\", \\\"{x:1303,y:784,t:1527030514206};\\\", \\\"{x:1303,y:796,t:1527030514222};\\\", \\\"{x:1303,y:809,t:1527030514240};\\\", \\\"{x:1304,y:821,t:1527030514256};\\\", \\\"{x:1306,y:825,t:1527030514273};\\\", \\\"{x:1306,y:826,t:1527030514290};\\\", \\\"{x:1306,y:828,t:1527030514307};\\\", \\\"{x:1307,y:828,t:1527030514323};\\\", \\\"{x:1308,y:827,t:1527030514353};\\\", \\\"{x:1308,y:822,t:1527030514361};\\\", \\\"{x:1308,y:818,t:1527030514374};\\\", \\\"{x:1308,y:817,t:1527030514390};\\\", \\\"{x:1309,y:816,t:1527030514673};\\\", \\\"{x:1312,y:809,t:1527030514690};\\\", \\\"{x:1314,y:803,t:1527030514707};\\\", \\\"{x:1317,y:797,t:1527030514723};\\\", \\\"{x:1322,y:769,t:1527030514740};\\\", \\\"{x:1325,y:747,t:1527030514757};\\\", \\\"{x:1326,y:737,t:1527030514774};\\\", \\\"{x:1326,y:706,t:1527030514791};\\\", \\\"{x:1326,y:683,t:1527030514807};\\\", \\\"{x:1326,y:675,t:1527030514824};\\\", \\\"{x:1324,y:659,t:1527030514840};\\\", \\\"{x:1322,y:654,t:1527030514856};\\\", \\\"{x:1321,y:648,t:1527030514874};\\\", \\\"{x:1320,y:644,t:1527030514891};\\\", \\\"{x:1320,y:641,t:1527030514907};\\\", \\\"{x:1320,y:636,t:1527030514924};\\\", \\\"{x:1320,y:631,t:1527030514942};\\\", \\\"{x:1320,y:624,t:1527030514957};\\\", \\\"{x:1320,y:619,t:1527030514973};\\\", \\\"{x:1320,y:616,t:1527030514991};\\\", \\\"{x:1320,y:613,t:1527030515006};\\\", \\\"{x:1320,y:610,t:1527030515024};\\\", \\\"{x:1321,y:604,t:1527030515041};\\\", \\\"{x:1323,y:600,t:1527030515057};\\\", \\\"{x:1324,y:597,t:1527030515074};\\\", \\\"{x:1327,y:594,t:1527030515091};\\\", \\\"{x:1328,y:591,t:1527030515107};\\\", \\\"{x:1331,y:588,t:1527030515124};\\\", \\\"{x:1333,y:587,t:1527030515141};\\\", \\\"{x:1333,y:588,t:1527030515201};\\\", \\\"{x:1333,y:590,t:1527030515217};\\\", \\\"{x:1333,y:592,t:1527030515225};\\\", \\\"{x:1333,y:594,t:1527030515241};\\\", \\\"{x:1333,y:595,t:1527030515258};\\\", \\\"{x:1333,y:600,t:1527030515274};\\\", \\\"{x:1333,y:607,t:1527030515291};\\\", \\\"{x:1333,y:619,t:1527030515308};\\\", \\\"{x:1333,y:633,t:1527030515324};\\\", \\\"{x:1333,y:648,t:1527030515341};\\\", \\\"{x:1333,y:659,t:1527030515358};\\\", \\\"{x:1335,y:666,t:1527030515374};\\\", \\\"{x:1336,y:671,t:1527030515391};\\\", \\\"{x:1336,y:676,t:1527030515408};\\\", \\\"{x:1336,y:687,t:1527030515425};\\\", \\\"{x:1336,y:707,t:1527030515441};\\\", \\\"{x:1336,y:728,t:1527030515459};\\\", \\\"{x:1336,y:751,t:1527030515474};\\\", \\\"{x:1336,y:767,t:1527030515491};\\\", \\\"{x:1336,y:772,t:1527030515509};\\\", \\\"{x:1336,y:775,t:1527030515524};\\\", \\\"{x:1336,y:778,t:1527030515541};\\\", \\\"{x:1336,y:782,t:1527030515558};\\\", \\\"{x:1336,y:789,t:1527030515574};\\\", \\\"{x:1333,y:804,t:1527030515591};\\\", \\\"{x:1331,y:819,t:1527030515608};\\\", \\\"{x:1329,y:831,t:1527030515625};\\\", \\\"{x:1329,y:834,t:1527030515641};\\\", \\\"{x:1329,y:836,t:1527030515658};\\\", \\\"{x:1327,y:845,t:1527030515675};\\\", \\\"{x:1325,y:853,t:1527030515691};\\\", \\\"{x:1325,y:860,t:1527030515708};\\\", \\\"{x:1321,y:871,t:1527030515725};\\\", \\\"{x:1319,y:880,t:1527030515741};\\\", \\\"{x:1315,y:891,t:1527030515759};\\\", \\\"{x:1313,y:901,t:1527030515775};\\\", \\\"{x:1313,y:910,t:1527030515791};\\\", \\\"{x:1313,y:917,t:1527030515808};\\\", \\\"{x:1313,y:922,t:1527030515825};\\\", \\\"{x:1313,y:925,t:1527030515841};\\\", \\\"{x:1313,y:932,t:1527030515859};\\\", \\\"{x:1313,y:938,t:1527030515875};\\\", \\\"{x:1313,y:941,t:1527030515892};\\\", \\\"{x:1313,y:943,t:1527030515908};\\\", \\\"{x:1313,y:945,t:1527030515929};\\\", \\\"{x:1313,y:947,t:1527030515953};\\\", \\\"{x:1314,y:947,t:1527030515960};\\\", \\\"{x:1314,y:948,t:1527030515977};\\\", \\\"{x:1314,y:950,t:1527030515993};\\\", \\\"{x:1314,y:951,t:1527030516017};\\\", \\\"{x:1314,y:952,t:1527030516025};\\\", \\\"{x:1314,y:953,t:1527030516042};\\\", \\\"{x:1314,y:955,t:1527030516058};\\\", \\\"{x:1314,y:957,t:1527030516076};\\\", \\\"{x:1314,y:959,t:1527030516092};\\\", \\\"{x:1314,y:960,t:1527030516108};\\\", \\\"{x:1314,y:962,t:1527030516125};\\\", \\\"{x:1314,y:966,t:1527030516142};\\\", \\\"{x:1314,y:970,t:1527030516158};\\\", \\\"{x:1314,y:972,t:1527030516185};\\\", \\\"{x:1314,y:973,t:1527030516217};\\\", \\\"{x:1315,y:974,t:1527030516233};\\\", \\\"{x:1315,y:975,t:1527030516242};\\\", \\\"{x:1316,y:975,t:1527030517897};\\\", \\\"{x:1319,y:975,t:1527030517913};\\\", \\\"{x:1321,y:975,t:1527030517937};\\\", \\\"{x:1324,y:975,t:1527030518026};\\\", \\\"{x:1325,y:975,t:1527030518033};\\\", \\\"{x:1327,y:975,t:1527030518049};\\\", \\\"{x:1328,y:975,t:1527030518061};\\\", \\\"{x:1331,y:975,t:1527030518077};\\\", \\\"{x:1334,y:974,t:1527030518093};\\\", \\\"{x:1336,y:974,t:1527030518113};\\\", \\\"{x:1336,y:973,t:1527030518177};\\\", \\\"{x:1337,y:973,t:1527030518201};\\\", \\\"{x:1338,y:973,t:1527030518225};\\\", \\\"{x:1339,y:973,t:1527030518233};\\\", \\\"{x:1339,y:972,t:1527030518244};\\\", \\\"{x:1340,y:972,t:1527030518260};\\\", \\\"{x:1341,y:972,t:1527030518277};\\\", \\\"{x:1343,y:972,t:1527030518313};\\\", \\\"{x:1344,y:972,t:1527030518327};\\\", \\\"{x:1345,y:972,t:1527030518345};\\\", \\\"{x:1346,y:972,t:1527030518360};\\\", \\\"{x:1346,y:971,t:1527030518514};\\\", \\\"{x:1347,y:971,t:1527030518529};\\\", \\\"{x:1349,y:971,t:1527030518544};\\\", \\\"{x:1350,y:971,t:1527030518560};\\\", \\\"{x:1353,y:971,t:1527030518577};\\\", \\\"{x:1356,y:971,t:1527030518594};\\\", \\\"{x:1361,y:970,t:1527030518611};\\\", \\\"{x:1367,y:969,t:1527030518628};\\\", \\\"{x:1368,y:968,t:1527030518645};\\\", \\\"{x:1370,y:968,t:1527030518662};\\\", \\\"{x:1372,y:968,t:1527030518677};\\\", \\\"{x:1374,y:968,t:1527030518694};\\\", \\\"{x:1375,y:966,t:1527030518711};\\\", \\\"{x:1377,y:966,t:1527030518729};\\\", \\\"{x:1378,y:966,t:1527030518761};\\\", \\\"{x:1380,y:966,t:1527030518777};\\\", \\\"{x:1381,y:966,t:1527030518802};\\\", \\\"{x:1382,y:966,t:1527030518864};\\\", \\\"{x:1382,y:968,t:1527030519017};\\\", \\\"{x:1384,y:968,t:1527030519266};\\\", \\\"{x:1385,y:968,t:1527030519278};\\\", \\\"{x:1390,y:968,t:1527030519294};\\\", \\\"{x:1395,y:968,t:1527030519311};\\\", \\\"{x:1400,y:968,t:1527030519328};\\\", \\\"{x:1407,y:968,t:1527030519344};\\\", \\\"{x:1420,y:968,t:1527030519361};\\\", \\\"{x:1425,y:965,t:1527030519379};\\\", \\\"{x:1429,y:965,t:1527030519395};\\\", \\\"{x:1431,y:965,t:1527030519411};\\\", \\\"{x:1432,y:965,t:1527030519428};\\\", \\\"{x:1434,y:965,t:1527030519446};\\\", \\\"{x:1435,y:965,t:1527030519465};\\\", \\\"{x:1436,y:965,t:1527030519479};\\\", \\\"{x:1437,y:965,t:1527030519495};\\\", \\\"{x:1438,y:965,t:1527030519511};\\\", \\\"{x:1440,y:965,t:1527030519553};\\\", \\\"{x:1441,y:965,t:1527030519569};\\\", \\\"{x:1443,y:965,t:1527030519585};\\\", \\\"{x:1446,y:965,t:1527030519601};\\\", \\\"{x:1447,y:965,t:1527030519611};\\\", \\\"{x:1449,y:965,t:1527030519629};\\\", \\\"{x:1450,y:965,t:1527030519647};\\\", \\\"{x:1451,y:965,t:1527030519673};\\\", \\\"{x:1453,y:965,t:1527030520129};\\\", \\\"{x:1455,y:965,t:1527030520145};\\\", \\\"{x:1457,y:965,t:1527030520162};\\\", \\\"{x:1459,y:965,t:1527030520179};\\\", \\\"{x:1461,y:965,t:1527030520195};\\\", \\\"{x:1463,y:965,t:1527030520212};\\\", \\\"{x:1466,y:965,t:1527030520229};\\\", \\\"{x:1470,y:965,t:1527030520246};\\\", \\\"{x:1471,y:965,t:1527030520262};\\\", \\\"{x:1473,y:965,t:1527030520279};\\\", \\\"{x:1476,y:965,t:1527030520295};\\\", \\\"{x:1478,y:965,t:1527030520312};\\\", \\\"{x:1483,y:965,t:1527030520329};\\\", \\\"{x:1485,y:965,t:1527030520345};\\\", \\\"{x:1490,y:965,t:1527030520362};\\\", \\\"{x:1493,y:965,t:1527030520380};\\\", \\\"{x:1496,y:965,t:1527030520395};\\\", \\\"{x:1497,y:965,t:1527030520417};\\\", \\\"{x:1498,y:965,t:1527030520473};\\\", \\\"{x:1499,y:965,t:1527030520489};\\\", \\\"{x:1500,y:965,t:1527030520505};\\\", \\\"{x:1502,y:965,t:1527030520529};\\\", \\\"{x:1503,y:965,t:1527030520560};\\\", \\\"{x:1504,y:965,t:1527030520577};\\\", \\\"{x:1505,y:965,t:1527030520593};\\\", \\\"{x:1507,y:965,t:1527030520609};\\\", \\\"{x:1508,y:965,t:1527030520625};\\\", \\\"{x:1509,y:965,t:1527030520697};\\\", \\\"{x:1510,y:965,t:1527030520737};\\\", \\\"{x:1511,y:965,t:1527030520769};\\\", \\\"{x:1512,y:965,t:1527030521049};\\\", \\\"{x:1513,y:965,t:1527030521105};\\\", \\\"{x:1514,y:965,t:1527030521161};\\\", \\\"{x:1515,y:965,t:1527030521177};\\\", \\\"{x:1516,y:965,t:1527030521201};\\\", \\\"{x:1517,y:965,t:1527030521257};\\\", \\\"{x:1518,y:965,t:1527030521377};\\\", \\\"{x:1519,y:965,t:1527030521393};\\\", \\\"{x:1521,y:965,t:1527030521401};\\\", \\\"{x:1523,y:965,t:1527030521416};\\\", \\\"{x:1526,y:965,t:1527030521430};\\\", \\\"{x:1533,y:965,t:1527030521447};\\\", \\\"{x:1540,y:964,t:1527030521464};\\\", \\\"{x:1550,y:962,t:1527030521481};\\\", \\\"{x:1554,y:962,t:1527030521497};\\\", \\\"{x:1555,y:962,t:1527030521513};\\\", \\\"{x:1554,y:962,t:1527030522056};\\\", \\\"{x:1553,y:962,t:1527030522073};\\\", \\\"{x:1552,y:962,t:1527030522081};\\\", \\\"{x:1551,y:962,t:1527030522105};\\\", \\\"{x:1549,y:962,t:1527030522161};\\\", \\\"{x:1548,y:962,t:1527030522169};\\\", \\\"{x:1546,y:960,t:1527030522180};\\\", \\\"{x:1542,y:960,t:1527030522197};\\\", \\\"{x:1539,y:960,t:1527030522214};\\\", \\\"{x:1540,y:960,t:1527030522417};\\\", \\\"{x:1541,y:960,t:1527030522432};\\\", \\\"{x:1542,y:960,t:1527030522448};\\\", \\\"{x:1544,y:960,t:1527030522464};\\\", \\\"{x:1545,y:960,t:1527030522497};\\\", \\\"{x:1546,y:960,t:1527030522515};\\\", \\\"{x:1547,y:960,t:1527030522532};\\\", \\\"{x:1544,y:960,t:1527030528308};\\\", \\\"{x:1527,y:960,t:1527030528323};\\\", \\\"{x:1359,y:937,t:1527030528340};\\\", \\\"{x:1184,y:903,t:1527030528356};\\\", \\\"{x:1012,y:867,t:1527030528373};\\\", \\\"{x:871,y:826,t:1527030528390};\\\", \\\"{x:771,y:796,t:1527030528406};\\\", \\\"{x:698,y:763,t:1527030528423};\\\", \\\"{x:650,y:735,t:1527030528439};\\\", \\\"{x:619,y:716,t:1527030528456};\\\", \\\"{x:594,y:700,t:1527030528473};\\\", \\\"{x:575,y:689,t:1527030528490};\\\", \\\"{x:555,y:681,t:1527030528507};\\\", \\\"{x:540,y:672,t:1527030528523};\\\", \\\"{x:525,y:665,t:1527030528540};\\\", \\\"{x:514,y:661,t:1527030528557};\\\", \\\"{x:500,y:654,t:1527030528572};\\\", \\\"{x:482,y:650,t:1527030528589};\\\", \\\"{x:462,y:646,t:1527030528603};\\\", \\\"{x:447,y:646,t:1527030528619};\\\", \\\"{x:434,y:646,t:1527030528636};\\\", \\\"{x:421,y:646,t:1527030528653};\\\", \\\"{x:409,y:646,t:1527030528670};\\\", \\\"{x:404,y:645,t:1527030528687};\\\", \\\"{x:403,y:642,t:1527030528739};\\\", \\\"{x:403,y:639,t:1527030528753};\\\", \\\"{x:406,y:631,t:1527030528770};\\\", \\\"{x:420,y:618,t:1527030528787};\\\", \\\"{x:453,y:597,t:1527030528803};\\\", \\\"{x:473,y:588,t:1527030528821};\\\", \\\"{x:494,y:580,t:1527030528836};\\\", \\\"{x:503,y:577,t:1527030528854};\\\", \\\"{x:506,y:577,t:1527030528871};\\\", \\\"{x:507,y:577,t:1527030528886};\\\", \\\"{x:507,y:576,t:1527030528907};\\\", \\\"{x:509,y:576,t:1527030528921};\\\", \\\"{x:514,y:575,t:1527030528937};\\\", \\\"{x:525,y:574,t:1527030528954};\\\", \\\"{x:534,y:574,t:1527030528971};\\\", \\\"{x:540,y:572,t:1527030528987};\\\", \\\"{x:550,y:570,t:1527030529003};\\\", \\\"{x:551,y:570,t:1527030529021};\\\", \\\"{x:553,y:570,t:1527030529038};\\\", \\\"{x:554,y:570,t:1527030529053};\\\", \\\"{x:565,y:576,t:1527030529070};\\\", \\\"{x:577,y:584,t:1527030529087};\\\", \\\"{x:592,y:595,t:1527030529105};\\\", \\\"{x:604,y:601,t:1527030529120};\\\", \\\"{x:609,y:603,t:1527030529136};\\\", \\\"{x:612,y:604,t:1527030529153};\\\", \\\"{x:613,y:604,t:1527030529170};\\\", \\\"{x:615,y:604,t:1527030529186};\\\", \\\"{x:618,y:606,t:1527030529203};\\\", \\\"{x:619,y:606,t:1527030529235};\\\", \\\"{x:618,y:606,t:1527030529410};\\\", \\\"{x:618,y:606,t:1527030529415};\\\", \\\"{x:616,y:607,t:1527030529436};\\\", \\\"{x:615,y:608,t:1527030529453};\\\", \\\"{x:614,y:608,t:1527030529470};\\\", \\\"{x:613,y:610,t:1527030529488};\\\", \\\"{x:613,y:611,t:1527030529507};\\\", \\\"{x:613,y:613,t:1527030529521};\\\", \\\"{x:614,y:622,t:1527030529537};\\\", \\\"{x:644,y:642,t:1527030529554};\\\", \\\"{x:727,y:679,t:1527030529571};\\\", \\\"{x:954,y:770,t:1527030529588};\\\", \\\"{x:1113,y:835,t:1527030529604};\\\", \\\"{x:1226,y:888,t:1527030529620};\\\", \\\"{x:1306,y:936,t:1527030529638};\\\", \\\"{x:1346,y:963,t:1527030529653};\\\", \\\"{x:1352,y:972,t:1527030529671};\\\", \\\"{x:1352,y:974,t:1527030529700};\\\", \\\"{x:1351,y:975,t:1527030529708};\\\", \\\"{x:1350,y:976,t:1527030529723};\\\", \\\"{x:1350,y:977,t:1527030529764};\\\", \\\"{x:1350,y:979,t:1527030529772};\\\", \\\"{x:1350,y:983,t:1527030529788};\\\", \\\"{x:1353,y:991,t:1527030529805};\\\", \\\"{x:1356,y:993,t:1527030529821};\\\", \\\"{x:1362,y:993,t:1527030529838};\\\", \\\"{x:1373,y:993,t:1527030529854};\\\", \\\"{x:1386,y:990,t:1527030529871};\\\", \\\"{x:1391,y:982,t:1527030529888};\\\", \\\"{x:1399,y:970,t:1527030529904};\\\", \\\"{x:1414,y:961,t:1527030529921};\\\", \\\"{x:1429,y:956,t:1527030529938};\\\", \\\"{x:1441,y:955,t:1527030529954};\\\", \\\"{x:1445,y:955,t:1527030529971};\\\", \\\"{x:1447,y:955,t:1527030529987};\\\", \\\"{x:1448,y:955,t:1527030530005};\\\", \\\"{x:1450,y:955,t:1527030530020};\\\", \\\"{x:1454,y:954,t:1527030530038};\\\", \\\"{x:1459,y:953,t:1527030530055};\\\", \\\"{x:1466,y:952,t:1527030530071};\\\", \\\"{x:1470,y:952,t:1527030530088};\\\", \\\"{x:1474,y:951,t:1527030530105};\\\", \\\"{x:1478,y:950,t:1527030530122};\\\", \\\"{x:1479,y:950,t:1527030530164};\\\", \\\"{x:1480,y:950,t:1527030530172};\\\", \\\"{x:1482,y:950,t:1527030530188};\\\", \\\"{x:1484,y:950,t:1527030530205};\\\", \\\"{x:1486,y:950,t:1527030530222};\\\", \\\"{x:1487,y:950,t:1527030530239};\\\", \\\"{x:1488,y:950,t:1527030530255};\\\", \\\"{x:1489,y:950,t:1527030530273};\\\", \\\"{x:1493,y:950,t:1527030530288};\\\", \\\"{x:1498,y:950,t:1527030530305};\\\", \\\"{x:1503,y:952,t:1527030530322};\\\", \\\"{x:1514,y:953,t:1527030530337};\\\", \\\"{x:1529,y:954,t:1527030530354};\\\", \\\"{x:1538,y:954,t:1527030530372};\\\", \\\"{x:1539,y:954,t:1527030530652};\\\", \\\"{x:1541,y:954,t:1527030530660};\\\", \\\"{x:1542,y:955,t:1527030530675};\\\", \\\"{x:1543,y:956,t:1527030530688};\\\", \\\"{x:1545,y:956,t:1527030530716};\\\", \\\"{x:1545,y:957,t:1527030530763};\\\", \\\"{x:1547,y:957,t:1527030530780};\\\", \\\"{x:1548,y:958,t:1527030530803};\\\", \\\"{x:1549,y:959,t:1527030530844};\\\", \\\"{x:1550,y:959,t:1527030530867};\\\", \\\"{x:1551,y:959,t:1527030530884};\\\", \\\"{x:1551,y:960,t:1527030530892};\\\", \\\"{x:1552,y:960,t:1527030530905};\\\", \\\"{x:1554,y:960,t:1527030530922};\\\", \\\"{x:1555,y:960,t:1527030530940};\\\", \\\"{x:1556,y:960,t:1527030530956};\\\", \\\"{x:1557,y:960,t:1527030530980};\\\", \\\"{x:1558,y:960,t:1527030530996};\\\", \\\"{x:1559,y:961,t:1527030531012};\\\", \\\"{x:1560,y:962,t:1527030531036};\\\", \\\"{x:1560,y:963,t:1527030531109};\\\", \\\"{x:1561,y:964,t:1527030531124};\\\", \\\"{x:1561,y:965,t:1527030531140};\\\", \\\"{x:1562,y:965,t:1527030531188};\\\", \\\"{x:1561,y:965,t:1527030531292};\\\", \\\"{x:1560,y:965,t:1527030531307};\\\", \\\"{x:1558,y:965,t:1527030531322};\\\", \\\"{x:1556,y:964,t:1527030531339};\\\", \\\"{x:1553,y:963,t:1527030531356};\\\", \\\"{x:1552,y:963,t:1527030531380};\\\", \\\"{x:1551,y:963,t:1527030531396};\\\", \\\"{x:1550,y:963,t:1527030531406};\\\", \\\"{x:1549,y:963,t:1527030531436};\\\", \\\"{x:1548,y:963,t:1527030531444};\\\", \\\"{x:1547,y:963,t:1527030531460};\\\", \\\"{x:1546,y:963,t:1527030531473};\\\", \\\"{x:1544,y:963,t:1527030531489};\\\", \\\"{x:1543,y:963,t:1527030531506};\\\", \\\"{x:1542,y:963,t:1527030531523};\\\", \\\"{x:1541,y:963,t:1527030531539};\\\", \\\"{x:1539,y:964,t:1527030531556};\\\", \\\"{x:1540,y:964,t:1527030538371};\\\", \\\"{x:1541,y:964,t:1527030538387};\\\", \\\"{x:1543,y:964,t:1527030538404};\\\", \\\"{x:1544,y:964,t:1527030538420};\\\", \\\"{x:1546,y:964,t:1527030538644};\\\", \\\"{x:1528,y:952,t:1527030548693};\\\", \\\"{x:1439,y:927,t:1527030548703};\\\", \\\"{x:1267,y:893,t:1527030548720};\\\", \\\"{x:1114,y:865,t:1527030548737};\\\", \\\"{x:951,y:820,t:1527030548753};\\\", \\\"{x:804,y:797,t:1527030548770};\\\", \\\"{x:675,y:782,t:1527030548787};\\\", \\\"{x:623,y:782,t:1527030548803};\\\", \\\"{x:611,y:786,t:1527030548820};\\\", \\\"{x:607,y:791,t:1527030548836};\\\", \\\"{x:607,y:795,t:1527030548853};\\\", \\\"{x:607,y:798,t:1527030548870};\\\", \\\"{x:607,y:799,t:1527030548887};\\\", \\\"{x:607,y:800,t:1527030548903};\\\", \\\"{x:607,y:801,t:1527030548940};\\\", \\\"{x:606,y:801,t:1527030548956};\\\", \\\"{x:605,y:799,t:1527030548970};\\\", \\\"{x:601,y:782,t:1527030548987};\\\", \\\"{x:590,y:754,t:1527030549003};\\\", \\\"{x:570,y:721,t:1527030549020};\\\", \\\"{x:563,y:714,t:1527030549037};\\\", \\\"{x:557,y:708,t:1527030549053};\\\", \\\"{x:554,y:705,t:1527030549070};\\\", \\\"{x:551,y:704,t:1527030549087};\\\", \\\"{x:550,y:704,t:1527030549103};\\\", \\\"{x:546,y:703,t:1527030549119};\\\", \\\"{x:543,y:702,t:1527030549137};\\\", \\\"{x:542,y:702,t:1527030549154};\\\", \\\"{x:541,y:702,t:1527030549196};\\\", \\\"{x:540,y:702,t:1527030549203};\\\", \\\"{x:536,y:703,t:1527030549219};\\\", \\\"{x:532,y:707,t:1527030549236};\\\", \\\"{x:527,y:711,t:1527030549254};\\\", \\\"{x:526,y:714,t:1527030549270};\\\", \\\"{x:526,y:716,t:1527030549326};\\\", \\\"{x:526,y:717,t:1527030549346};\\\", \\\"{x:526,y:719,t:1527030549411};\\\", \\\"{x:526,y:720,t:1527030549427};\\\", \\\"{x:526,y:722,t:1527030549443};\\\", \\\"{x:527,y:724,t:1527030549458};\\\", \\\"{x:527,y:725,t:1527030549475};\\\", \\\"{x:527,y:726,t:1527030549485};\\\", \\\"{x:527,y:727,t:1527030549502};\\\", \\\"{x:527,y:729,t:1527030549520};\\\", \\\"{x:527,y:730,t:1527030549535};\\\", \\\"{x:527,y:731,t:1527030549552};\\\", \\\"{x:527,y:732,t:1527030549570};\\\", \\\"{x:528,y:732,t:1527030549586};\\\", \\\"{x:529,y:733,t:1527030549708};\\\", \\\"{x:530,y:733,t:1527030549718};\\\", \\\"{x:532,y:733,t:1527030549735};\\\", \\\"{x:539,y:733,t:1527030549753};\\\", \\\"{x:548,y:731,t:1527030549769};\\\", \\\"{x:562,y:726,t:1527030549786};\\\", \\\"{x:581,y:722,t:1527030549804};\\\", \\\"{x:600,y:721,t:1527030549819};\\\", \\\"{x:621,y:721,t:1527030549836};\\\", \\\"{x:630,y:721,t:1527030549852};\\\", \\\"{x:638,y:721,t:1527030549870};\\\", \\\"{x:647,y:721,t:1527030549887};\\\", \\\"{x:659,y:722,t:1527030549902};\\\", \\\"{x:670,y:723,t:1527030549919};\\\", \\\"{x:685,y:723,t:1527030549937};\\\", \\\"{x:704,y:723,t:1527030549953};\\\", \\\"{x:727,y:726,t:1527030549970};\\\", \\\"{x:752,y:729,t:1527030549987};\\\", \\\"{x:785,y:737,t:1527030550002};\\\", \\\"{x:824,y:746,t:1527030550020};\\\", \\\"{x:844,y:753,t:1527030550037};\\\", \\\"{x:862,y:761,t:1527030550052};\\\", \\\"{x:876,y:769,t:1527030550069};\\\", \\\"{x:886,y:775,t:1527030550086};\\\", \\\"{x:893,y:781,t:1527030550103};\\\", \\\"{x:899,y:786,t:1527030550120};\\\", \\\"{x:911,y:795,t:1527030550136};\\\", \\\"{x:918,y:801,t:1527030550152};\\\", \\\"{x:922,y:811,t:1527030550170};\\\", \\\"{x:928,y:820,t:1527030550185};\\\", \\\"{x:936,y:833,t:1527030550203};\\\", \\\"{x:956,y:859,t:1527030550220};\\\", \\\"{x:968,y:877,t:1527030550236};\\\", \\\"{x:990,y:902,t:1527030550253};\\\", \\\"{x:1018,y:941,t:1527030550270};\\\", \\\"{x:1035,y:968,t:1527030550286};\\\", \\\"{x:1046,y:991,t:1527030550302};\\\", \\\"{x:1052,y:1006,t:1527030550320};\\\", \\\"{x:1057,y:1018,t:1527030550336};\\\", \\\"{x:1059,y:1024,t:1527030550353};\\\", \\\"{x:1061,y:1028,t:1527030550370};\\\", \\\"{x:1062,y:1029,t:1527030550386};\\\", \\\"{x:1065,y:1029,t:1527030550403};\\\", \\\"{x:1072,y:1029,t:1527030550420};\\\", \\\"{x:1082,y:1027,t:1527030550436};\\\", \\\"{x:1093,y:1020,t:1527030550453};\\\", \\\"{x:1103,y:1014,t:1527030550470};\\\", \\\"{x:1108,y:1010,t:1527030550486};\\\", \\\"{x:1113,y:1006,t:1527030550503};\\\", \\\"{x:1116,y:1003,t:1527030550519};\\\", \\\"{x:1120,y:998,t:1527030550536};\\\", \\\"{x:1124,y:993,t:1527030550553};\\\", \\\"{x:1132,y:985,t:1527030550569};\\\", \\\"{x:1137,y:977,t:1527030550586};\\\", \\\"{x:1145,y:968,t:1527030550603};\\\", \\\"{x:1151,y:963,t:1527030550619};\\\", \\\"{x:1157,y:958,t:1527030550636};\\\", \\\"{x:1161,y:956,t:1527030550653};\\\", \\\"{x:1163,y:952,t:1527030550669};\\\", \\\"{x:1167,y:948,t:1527030550686};\\\", \\\"{x:1173,y:942,t:1527030550703};\\\", \\\"{x:1180,y:935,t:1527030550719};\\\", \\\"{x:1189,y:929,t:1527030550736};\\\", \\\"{x:1204,y:924,t:1527030550753};\\\", \\\"{x:1222,y:916,t:1527030550769};\\\", \\\"{x:1241,y:911,t:1527030550786};\\\", \\\"{x:1256,y:908,t:1527030550803};\\\", \\\"{x:1267,y:903,t:1527030550819};\\\", \\\"{x:1275,y:899,t:1527030550836};\\\", \\\"{x:1277,y:898,t:1527030550852};\\\", \\\"{x:1279,y:897,t:1527030550869};\\\", \\\"{x:1281,y:896,t:1527030550886};\\\", \\\"{x:1282,y:896,t:1527030550916};\\\", \\\"{x:1284,y:896,t:1527030550924};\\\", \\\"{x:1284,y:895,t:1527030550937};\\\", \\\"{x:1288,y:893,t:1527030550952};\\\", \\\"{x:1291,y:891,t:1527030550969};\\\", \\\"{x:1294,y:889,t:1527030550986};\\\", \\\"{x:1298,y:887,t:1527030551002};\\\", \\\"{x:1299,y:886,t:1527030551019};\\\", \\\"{x:1301,y:886,t:1527030551484};\\\", \\\"{x:1316,y:886,t:1527030551502};\\\", \\\"{x:1338,y:886,t:1527030551519};\\\", \\\"{x:1366,y:886,t:1527030551535};\\\", \\\"{x:1387,y:881,t:1527030551552};\\\", \\\"{x:1393,y:880,t:1527030551568};\\\", \\\"{x:1395,y:879,t:1527030551585};\\\", \\\"{x:1396,y:879,t:1527030551602};\\\", \\\"{x:1396,y:878,t:1527030551636};\\\", \\\"{x:1397,y:877,t:1527030551652};\\\", \\\"{x:1398,y:877,t:1527030551668};\\\", \\\"{x:1398,y:876,t:1527030551692};\\\", \\\"{x:1399,y:876,t:1527030551703};\\\", \\\"{x:1400,y:875,t:1527030551719};\\\", \\\"{x:1401,y:874,t:1527030551735};\\\", \\\"{x:1402,y:874,t:1527030551752};\\\", \\\"{x:1410,y:872,t:1527030551768};\\\", \\\"{x:1414,y:872,t:1527030551785};\\\", \\\"{x:1421,y:872,t:1527030551801};\\\", \\\"{x:1429,y:874,t:1527030551818};\\\", \\\"{x:1441,y:881,t:1527030551835};\\\", \\\"{x:1468,y:895,t:1527030551850};\\\", \\\"{x:1484,y:903,t:1527030551867};\\\", \\\"{x:1493,y:907,t:1527030551884};\\\", \\\"{x:1496,y:910,t:1527030551900};\\\", \\\"{x:1497,y:912,t:1527030551918};\\\", \\\"{x:1498,y:915,t:1527030551935};\\\", \\\"{x:1498,y:917,t:1527030551951};\\\", \\\"{x:1499,y:923,t:1527030551967};\\\", \\\"{x:1501,y:930,t:1527030551985};\\\", \\\"{x:1507,y:940,t:1527030552001};\\\", \\\"{x:1510,y:943,t:1527030552018};\\\", \\\"{x:1510,y:946,t:1527030552035};\\\", \\\"{x:1512,y:947,t:1527030552051};\\\", \\\"{x:1513,y:947,t:1527030552123};\\\", \\\"{x:1516,y:947,t:1527030552135};\\\", \\\"{x:1523,y:948,t:1527030552151};\\\", \\\"{x:1532,y:948,t:1527030552167};\\\", \\\"{x:1540,y:948,t:1527030552185};\\\", \\\"{x:1545,y:948,t:1527030552201};\\\", \\\"{x:1551,y:947,t:1527030552218};\\\", \\\"{x:1552,y:947,t:1527030552234};\\\", \\\"{x:1553,y:947,t:1527030552251};\\\", \\\"{x:1554,y:947,t:1527030552300};\\\", \\\"{x:1556,y:948,t:1527030552340};\\\", \\\"{x:1556,y:949,t:1527030552356};\\\", \\\"{x:1556,y:951,t:1527030552380};\\\", \\\"{x:1556,y:952,t:1527030552395};\\\", \\\"{x:1556,y:953,t:1527030552420};\\\", \\\"{x:1556,y:954,t:1527030552452};\\\", \\\"{x:1555,y:956,t:1527030552868};\\\", \\\"{x:1555,y:957,t:1527030552884};\\\", \\\"{x:1554,y:958,t:1527030552900};\\\", \\\"{x:1554,y:959,t:1527030552932};\\\", \\\"{x:1554,y:960,t:1527030553485};\\\", \\\"{x:1554,y:961,t:1527030553524};\\\", \\\"{x:1554,y:962,t:1527030553628};\\\", \\\"{x:1554,y:964,t:1527030553644};\\\", \\\"{x:1553,y:966,t:1527030553652};\\\", \\\"{x:1551,y:967,t:1527030553666};\\\", \\\"{x:1542,y:969,t:1527030553682};\\\", \\\"{x:1489,y:969,t:1527030553699};\\\", \\\"{x:1395,y:956,t:1527030553716};\\\", \\\"{x:1279,y:923,t:1527030553732};\\\", \\\"{x:1147,y:874,t:1527030553749};\\\", \\\"{x:1009,y:832,t:1527030553766};\\\", \\\"{x:879,y:801,t:1527030553783};\\\", \\\"{x:776,y:785,t:1527030553799};\\\", \\\"{x:706,y:772,t:1527030553816};\\\", \\\"{x:669,y:768,t:1527030553833};\\\", \\\"{x:648,y:764,t:1527030553850};\\\", \\\"{x:633,y:763,t:1527030553866};\\\", \\\"{x:613,y:760,t:1527030553883};\\\", \\\"{x:554,y:754,t:1527030553899};\\\", \\\"{x:492,y:744,t:1527030553916};\\\", \\\"{x:434,y:736,t:1527030553933};\\\", \\\"{x:404,y:733,t:1527030553949};\\\", \\\"{x:395,y:731,t:1527030553974};\\\", \\\"{x:395,y:730,t:1527030553990};\\\", \\\"{x:396,y:730,t:1527030554115};\\\", \\\"{x:405,y:732,t:1527030554123};\\\", \\\"{x:423,y:733,t:1527030554139};\\\", \\\"{x:441,y:733,t:1527030554157};\\\", \\\"{x:457,y:736,t:1527030554174};\\\", \\\"{x:462,y:736,t:1527030554190};\\\" ] }, { \\\"rt\\\": 8471, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 519784, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:464,y:736,t:1527030558012};\\\", \\\"{x:465,y:735,t:1527030558027};\\\", \\\"{x:473,y:728,t:1527030558044};\\\", \\\"{x:482,y:720,t:1527030558061};\\\", \\\"{x:492,y:706,t:1527030558079};\\\", \\\"{x:503,y:697,t:1527030558094};\\\", \\\"{x:509,y:691,t:1527030558111};\\\", \\\"{x:519,y:683,t:1527030558126};\\\", \\\"{x:526,y:678,t:1527030558142};\\\", \\\"{x:537,y:668,t:1527030558159};\\\", \\\"{x:553,y:658,t:1527030558175};\\\", \\\"{x:572,y:646,t:1527030558192};\\\", \\\"{x:592,y:635,t:1527030558209};\\\", \\\"{x:618,y:615,t:1527030558226};\\\", \\\"{x:677,y:574,t:1527030558243};\\\", \\\"{x:707,y:561,t:1527030558262};\\\", \\\"{x:727,y:554,t:1527030558277};\\\", \\\"{x:747,y:545,t:1527030558294};\\\", \\\"{x:762,y:537,t:1527030558311};\\\", \\\"{x:776,y:532,t:1527030558326};\\\", \\\"{x:788,y:527,t:1527030558344};\\\", \\\"{x:797,y:523,t:1527030558362};\\\", \\\"{x:809,y:519,t:1527030558377};\\\", \\\"{x:818,y:517,t:1527030558395};\\\", \\\"{x:833,y:513,t:1527030558411};\\\", \\\"{x:843,y:509,t:1527030558427};\\\", \\\"{x:852,y:506,t:1527030558444};\\\", \\\"{x:857,y:506,t:1527030558461};\\\", \\\"{x:859,y:505,t:1527030558478};\\\", \\\"{x:862,y:504,t:1527030558494};\\\", \\\"{x:868,y:503,t:1527030558512};\\\", \\\"{x:881,y:501,t:1527030558528};\\\", \\\"{x:908,y:501,t:1527030558544};\\\", \\\"{x:937,y:501,t:1527030558561};\\\", \\\"{x:971,y:505,t:1527030558579};\\\", \\\"{x:1037,y:521,t:1527030558595};\\\", \\\"{x:1077,y:534,t:1527030558611};\\\", \\\"{x:1098,y:545,t:1527030558627};\\\", \\\"{x:1101,y:547,t:1527030558644};\\\", \\\"{x:1102,y:547,t:1527030558779};\\\", \\\"{x:1103,y:548,t:1527030558794};\\\", \\\"{x:1104,y:548,t:1527030558811};\\\", \\\"{x:1105,y:550,t:1527030558844};\\\", \\\"{x:1107,y:554,t:1527030558861};\\\", \\\"{x:1107,y:558,t:1527030558878};\\\", \\\"{x:1111,y:562,t:1527030558895};\\\", \\\"{x:1111,y:563,t:1527030558912};\\\", \\\"{x:1114,y:564,t:1527030558929};\\\", \\\"{x:1119,y:564,t:1527030558945};\\\", \\\"{x:1125,y:564,t:1527030558961};\\\", \\\"{x:1131,y:564,t:1527030558979};\\\", \\\"{x:1139,y:564,t:1527030558996};\\\", \\\"{x:1149,y:562,t:1527030559012};\\\", \\\"{x:1161,y:562,t:1527030559028};\\\", \\\"{x:1174,y:562,t:1527030559044};\\\", \\\"{x:1186,y:562,t:1527030559061};\\\", \\\"{x:1197,y:562,t:1527030559077};\\\", \\\"{x:1206,y:562,t:1527030559095};\\\", \\\"{x:1214,y:562,t:1527030559111};\\\", \\\"{x:1228,y:562,t:1527030559128};\\\", \\\"{x:1243,y:563,t:1527030559145};\\\", \\\"{x:1257,y:564,t:1527030559161};\\\", \\\"{x:1269,y:567,t:1527030559177};\\\", \\\"{x:1279,y:567,t:1527030559195};\\\", \\\"{x:1283,y:567,t:1527030559210};\\\", \\\"{x:1284,y:567,t:1527030559283};\\\", \\\"{x:1285,y:567,t:1527030559294};\\\", \\\"{x:1286,y:567,t:1527030559311};\\\", \\\"{x:1287,y:567,t:1527030559331};\\\", \\\"{x:1288,y:567,t:1527030559347};\\\", \\\"{x:1289,y:567,t:1527030559395};\\\", \\\"{x:1291,y:567,t:1527030559418};\\\", \\\"{x:1292,y:567,t:1527030559434};\\\", \\\"{x:1294,y:567,t:1527030559451};\\\", \\\"{x:1295,y:567,t:1527030559491};\\\", \\\"{x:1297,y:566,t:1527030559915};\\\", \\\"{x:1302,y:566,t:1527030559927};\\\", \\\"{x:1314,y:563,t:1527030559945};\\\", \\\"{x:1324,y:562,t:1527030559962};\\\", \\\"{x:1340,y:557,t:1527030559979};\\\", \\\"{x:1349,y:554,t:1527030559995};\\\", \\\"{x:1356,y:553,t:1527030560011};\\\", \\\"{x:1361,y:553,t:1527030560029};\\\", \\\"{x:1365,y:552,t:1527030560044};\\\", \\\"{x:1369,y:552,t:1527030560062};\\\", \\\"{x:1372,y:552,t:1527030560079};\\\", \\\"{x:1373,y:552,t:1527030560095};\\\", \\\"{x:1374,y:552,t:1527030560173};\\\", \\\"{x:1373,y:554,t:1527030560179};\\\", \\\"{x:1365,y:559,t:1527030560196};\\\", \\\"{x:1349,y:568,t:1527030560212};\\\", \\\"{x:1326,y:574,t:1527030560230};\\\", \\\"{x:1292,y:582,t:1527030560246};\\\", \\\"{x:1247,y:596,t:1527030560262};\\\", \\\"{x:1178,y:612,t:1527030560279};\\\", \\\"{x:1090,y:633,t:1527030560296};\\\", \\\"{x:982,y:649,t:1527030560313};\\\", \\\"{x:889,y:654,t:1527030560330};\\\", \\\"{x:822,y:654,t:1527030560345};\\\", \\\"{x:777,y:654,t:1527030560362};\\\", \\\"{x:732,y:639,t:1527030560379};\\\", \\\"{x:714,y:633,t:1527030560395};\\\", \\\"{x:698,y:628,t:1527030560412};\\\", \\\"{x:688,y:626,t:1527030560428};\\\", \\\"{x:681,y:624,t:1527030560445};\\\", \\\"{x:680,y:624,t:1527030560467};\\\", \\\"{x:679,y:624,t:1527030560479};\\\", \\\"{x:673,y:624,t:1527030560495};\\\", \\\"{x:661,y:624,t:1527030560512};\\\", \\\"{x:647,y:624,t:1527030560529};\\\", \\\"{x:638,y:624,t:1527030560546};\\\", \\\"{x:635,y:624,t:1527030560562};\\\", \\\"{x:633,y:624,t:1527030560579};\\\", \\\"{x:631,y:623,t:1527030560619};\\\", \\\"{x:631,y:621,t:1527030560683};\\\", \\\"{x:631,y:618,t:1527030560696};\\\", \\\"{x:631,y:611,t:1527030560713};\\\", \\\"{x:632,y:605,t:1527030560729};\\\", \\\"{x:633,y:600,t:1527030560747};\\\", \\\"{x:634,y:587,t:1527030560763};\\\", \\\"{x:634,y:576,t:1527030560779};\\\", \\\"{x:634,y:563,t:1527030560796};\\\", \\\"{x:633,y:552,t:1527030560813};\\\", \\\"{x:633,y:551,t:1527030560829};\\\", \\\"{x:633,y:550,t:1527030560846};\\\", \\\"{x:633,y:548,t:1527030560915};\\\", \\\"{x:633,y:546,t:1527030560931};\\\", \\\"{x:633,y:545,t:1527030560945};\\\", \\\"{x:632,y:543,t:1527030560963};\\\", \\\"{x:632,y:542,t:1527030560980};\\\", \\\"{x:632,y:540,t:1527030560995};\\\", \\\"{x:632,y:538,t:1527030561012};\\\", \\\"{x:632,y:534,t:1527030561030};\\\", \\\"{x:631,y:531,t:1527030561047};\\\", \\\"{x:631,y:527,t:1527030561063};\\\", \\\"{x:629,y:524,t:1527030561081};\\\", \\\"{x:628,y:522,t:1527030561096};\\\", \\\"{x:628,y:520,t:1527030561113};\\\", \\\"{x:627,y:519,t:1527030561129};\\\", \\\"{x:627,y:516,t:1527030561147};\\\", \\\"{x:625,y:513,t:1527030561163};\\\", \\\"{x:625,y:510,t:1527030561180};\\\", \\\"{x:624,y:507,t:1527030561195};\\\", \\\"{x:623,y:504,t:1527030561213};\\\", \\\"{x:622,y:503,t:1527030561229};\\\", \\\"{x:622,y:502,t:1527030561246};\\\", \\\"{x:621,y:501,t:1527030561339};\\\", \\\"{x:621,y:501,t:1527030561412};\\\", \\\"{x:625,y:501,t:1527030561530};\\\", \\\"{x:635,y:501,t:1527030561546};\\\", \\\"{x:668,y:503,t:1527030561563};\\\", \\\"{x:698,y:506,t:1527030561580};\\\", \\\"{x:721,y:510,t:1527030561597};\\\", \\\"{x:738,y:514,t:1527030561613};\\\", \\\"{x:752,y:518,t:1527030561630};\\\", \\\"{x:763,y:521,t:1527030561647};\\\", \\\"{x:766,y:522,t:1527030561662};\\\", \\\"{x:769,y:523,t:1527030561680};\\\", \\\"{x:772,y:524,t:1527030561697};\\\", \\\"{x:775,y:525,t:1527030561713};\\\", \\\"{x:776,y:525,t:1527030561730};\\\", \\\"{x:777,y:525,t:1527030561747};\\\", \\\"{x:779,y:526,t:1527030561763};\\\", \\\"{x:783,y:527,t:1527030561780};\\\", \\\"{x:788,y:529,t:1527030561797};\\\", \\\"{x:794,y:533,t:1527030561814};\\\", \\\"{x:798,y:534,t:1527030561830};\\\", \\\"{x:799,y:535,t:1527030561847};\\\", \\\"{x:802,y:537,t:1527030561864};\\\", \\\"{x:804,y:538,t:1527030561880};\\\", \\\"{x:806,y:539,t:1527030561897};\\\", \\\"{x:807,y:539,t:1527030561915};\\\", \\\"{x:807,y:540,t:1527030561930};\\\", \\\"{x:808,y:540,t:1527030561955};\\\", \\\"{x:809,y:540,t:1527030561971};\\\", \\\"{x:810,y:540,t:1527030561981};\\\", \\\"{x:811,y:540,t:1527030561996};\\\", \\\"{x:811,y:540,t:1527030562246};\\\", \\\"{x:812,y:540,t:1527030562666};\\\", \\\"{x:814,y:540,t:1527030562679};\\\", \\\"{x:815,y:539,t:1527030562699};\\\", \\\"{x:816,y:539,t:1527030562771};\\\", \\\"{x:817,y:539,t:1527030562779};\\\", \\\"{x:818,y:539,t:1527030562883};\\\", \\\"{x:819,y:539,t:1527030562939};\\\", \\\"{x:819,y:539,t:1527030562939};\\\", \\\"{x:820,y:539,t:1527030562970};\\\", \\\"{x:821,y:539,t:1527030563043};\\\", \\\"{x:822,y:540,t:1527030563139};\\\", \\\"{x:823,y:540,t:1527030563218};\\\", \\\"{x:824,y:540,t:1527030563243};\\\", \\\"{x:824,y:541,t:1527030563275};\\\", \\\"{x:824,y:542,t:1527030563659};\\\", \\\"{x:824,y:543,t:1527030563666};\\\", \\\"{x:824,y:547,t:1527030563681};\\\", \\\"{x:820,y:557,t:1527030563698};\\\", \\\"{x:809,y:574,t:1527030563715};\\\", \\\"{x:790,y:616,t:1527030563731};\\\", \\\"{x:770,y:653,t:1527030563749};\\\", \\\"{x:746,y:692,t:1527030563765};\\\", \\\"{x:720,y:727,t:1527030563781};\\\", \\\"{x:700,y:751,t:1527030563798};\\\", \\\"{x:677,y:769,t:1527030563814};\\\", \\\"{x:661,y:780,t:1527030563831};\\\", \\\"{x:640,y:784,t:1527030563848};\\\", \\\"{x:625,y:786,t:1527030563865};\\\", \\\"{x:608,y:786,t:1527030563882};\\\", \\\"{x:594,y:786,t:1527030563898};\\\", \\\"{x:584,y:786,t:1527030563914};\\\", \\\"{x:583,y:786,t:1527030563987};\\\", \\\"{x:582,y:786,t:1527030563997};\\\", \\\"{x:580,y:784,t:1527030564014};\\\", \\\"{x:576,y:779,t:1527030564032};\\\", \\\"{x:564,y:770,t:1527030564048};\\\", \\\"{x:545,y:761,t:1527030564064};\\\", \\\"{x:526,y:753,t:1527030564082};\\\", \\\"{x:512,y:748,t:1527030564098};\\\", \\\"{x:500,y:744,t:1527030564115};\\\", \\\"{x:495,y:741,t:1527030564132};\\\", \\\"{x:493,y:740,t:1527030564149};\\\" ] }, { \\\"rt\\\": 31559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 552586, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:739,t:1527030566090};\\\", \\\"{x:494,y:739,t:1527030566107};\\\", \\\"{x:496,y:739,t:1527030566117};\\\", \\\"{x:497,y:739,t:1527030566133};\\\", \\\"{x:498,y:739,t:1527030566150};\\\", \\\"{x:499,y:738,t:1527030566170};\\\", \\\"{x:500,y:738,t:1527030566195};\\\", \\\"{x:502,y:738,t:1527030566219};\\\", \\\"{x:502,y:737,t:1527030566235};\\\", \\\"{x:505,y:738,t:1527030570875};\\\", \\\"{x:507,y:740,t:1527030570887};\\\", \\\"{x:509,y:743,t:1527030570904};\\\", \\\"{x:513,y:747,t:1527030570921};\\\", \\\"{x:516,y:749,t:1527030570937};\\\", \\\"{x:518,y:751,t:1527030570954};\\\", \\\"{x:521,y:749,t:1527030577123};\\\", \\\"{x:523,y:740,t:1527030577130};\\\", \\\"{x:528,y:730,t:1527030577143};\\\", \\\"{x:536,y:708,t:1527030577160};\\\", \\\"{x:542,y:690,t:1527030577176};\\\", \\\"{x:549,y:664,t:1527030577192};\\\", \\\"{x:551,y:643,t:1527030577209};\\\", \\\"{x:553,y:630,t:1527030577226};\\\", \\\"{x:554,y:624,t:1527030577242};\\\", \\\"{x:555,y:620,t:1527030577258};\\\", \\\"{x:557,y:615,t:1527030577275};\\\", \\\"{x:561,y:609,t:1527030577292};\\\", \\\"{x:563,y:603,t:1527030577309};\\\", \\\"{x:567,y:599,t:1527030577326};\\\", \\\"{x:569,y:597,t:1527030577343};\\\", \\\"{x:570,y:595,t:1527030577359};\\\", \\\"{x:570,y:591,t:1527030577451};\\\", \\\"{x:570,y:580,t:1527030577460};\\\", \\\"{x:570,y:559,t:1527030577475};\\\", \\\"{x:568,y:551,t:1527030577493};\\\", \\\"{x:568,y:549,t:1527030577546};\\\", \\\"{x:569,y:545,t:1527030577560};\\\", \\\"{x:570,y:530,t:1527030577575};\\\", \\\"{x:572,y:516,t:1527030577593};\\\", \\\"{x:574,y:505,t:1527030577610};\\\", \\\"{x:576,y:500,t:1527030577625};\\\", \\\"{x:577,y:499,t:1527030577642};\\\", \\\"{x:577,y:498,t:1527030577659};\\\", \\\"{x:577,y:496,t:1527030577675};\\\", \\\"{x:577,y:492,t:1527030577692};\\\", \\\"{x:576,y:490,t:1527030577709};\\\", \\\"{x:575,y:487,t:1527030577726};\\\", \\\"{x:573,y:481,t:1527030577743};\\\", \\\"{x:573,y:475,t:1527030577759};\\\", \\\"{x:577,y:463,t:1527030577776};\\\", \\\"{x:584,y:454,t:1527030577792};\\\", \\\"{x:591,y:450,t:1527030577809};\\\", \\\"{x:599,y:448,t:1527030577826};\\\", \\\"{x:603,y:446,t:1527030577842};\\\", \\\"{x:604,y:445,t:1527030577859};\\\", \\\"{x:605,y:445,t:1527030577876};\\\", \\\"{x:620,y:445,t:1527030577892};\\\", \\\"{x:648,y:449,t:1527030577909};\\\", \\\"{x:682,y:465,t:1527030577926};\\\", \\\"{x:699,y:468,t:1527030577942};\\\", \\\"{x:722,y:468,t:1527030577960};\\\", \\\"{x:749,y:468,t:1527030577976};\\\", \\\"{x:772,y:468,t:1527030577993};\\\", \\\"{x:795,y:468,t:1527030578009};\\\", \\\"{x:862,y:468,t:1527030578026};\\\", \\\"{x:929,y:468,t:1527030578043};\\\", \\\"{x:996,y:468,t:1527030578059};\\\", \\\"{x:1057,y:468,t:1527030578077};\\\", \\\"{x:1105,y:468,t:1527030578094};\\\", \\\"{x:1130,y:468,t:1527030578110};\\\", \\\"{x:1150,y:471,t:1527030578127};\\\", \\\"{x:1168,y:473,t:1527030578143};\\\", \\\"{x:1186,y:476,t:1527030578160};\\\", \\\"{x:1205,y:477,t:1527030578176};\\\", \\\"{x:1220,y:479,t:1527030578194};\\\", \\\"{x:1231,y:481,t:1527030578209};\\\", \\\"{x:1237,y:482,t:1527030578226};\\\", \\\"{x:1238,y:483,t:1527030578251};\\\", \\\"{x:1239,y:485,t:1527030578259};\\\", \\\"{x:1242,y:491,t:1527030578276};\\\", \\\"{x:1248,y:501,t:1527030578293};\\\", \\\"{x:1253,y:510,t:1527030578310};\\\", \\\"{x:1254,y:516,t:1527030578326};\\\", \\\"{x:1257,y:525,t:1527030578343};\\\", \\\"{x:1257,y:539,t:1527030578361};\\\", \\\"{x:1257,y:560,t:1527030578376};\\\", \\\"{x:1257,y:588,t:1527030578394};\\\", \\\"{x:1251,y:623,t:1527030578410};\\\", \\\"{x:1251,y:638,t:1527030578426};\\\", \\\"{x:1251,y:655,t:1527030578443};\\\", \\\"{x:1250,y:674,t:1527030578460};\\\", \\\"{x:1248,y:696,t:1527030578476};\\\", \\\"{x:1246,y:713,t:1527030578494};\\\", \\\"{x:1246,y:737,t:1527030578515};\\\", \\\"{x:1246,y:761,t:1527030578546};\\\", \\\"{x:1246,y:773,t:1527030578560};\\\", \\\"{x:1246,y:778,t:1527030578576};\\\", \\\"{x:1246,y:779,t:1527030578593};\\\", \\\"{x:1245,y:779,t:1527030578642};\\\", \\\"{x:1244,y:778,t:1527030578650};\\\", \\\"{x:1244,y:776,t:1527030578660};\\\", \\\"{x:1242,y:769,t:1527030578677};\\\", \\\"{x:1240,y:761,t:1527030578693};\\\", \\\"{x:1240,y:760,t:1527030578711};\\\", \\\"{x:1240,y:758,t:1527030578728};\\\", \\\"{x:1236,y:752,t:1527030578744};\\\", \\\"{x:1231,y:742,t:1527030578760};\\\", \\\"{x:1221,y:732,t:1527030578777};\\\", \\\"{x:1213,y:727,t:1527030578793};\\\", \\\"{x:1213,y:723,t:1527030578939};\\\", \\\"{x:1218,y:723,t:1527030578946};\\\", \\\"{x:1222,y:721,t:1527030578961};\\\", \\\"{x:1228,y:719,t:1527030578978};\\\", \\\"{x:1230,y:719,t:1527030578993};\\\", \\\"{x:1240,y:713,t:1527030579011};\\\", \\\"{x:1247,y:708,t:1527030579027};\\\", \\\"{x:1252,y:705,t:1527030579044};\\\", \\\"{x:1255,y:703,t:1527030579060};\\\", \\\"{x:1258,y:702,t:1527030579078};\\\", \\\"{x:1262,y:699,t:1527030579094};\\\", \\\"{x:1268,y:695,t:1527030579110};\\\", \\\"{x:1275,y:693,t:1527030579127};\\\", \\\"{x:1284,y:691,t:1527030579145};\\\", \\\"{x:1303,y:690,t:1527030579173};\\\", \\\"{x:1307,y:690,t:1527030579178};\\\", \\\"{x:1310,y:690,t:1527030579194};\\\", \\\"{x:1312,y:690,t:1527030579210};\\\", \\\"{x:1313,y:690,t:1527030579227};\\\", \\\"{x:1318,y:690,t:1527030579244};\\\", \\\"{x:1321,y:690,t:1527030579261};\\\", \\\"{x:1326,y:692,t:1527030579277};\\\", \\\"{x:1329,y:692,t:1527030579295};\\\", \\\"{x:1332,y:692,t:1527030579310};\\\", \\\"{x:1333,y:692,t:1527030579363};\\\", \\\"{x:1334,y:693,t:1527030579378};\\\", \\\"{x:1335,y:693,t:1527030579395};\\\", \\\"{x:1336,y:693,t:1527030579427};\\\", \\\"{x:1337,y:694,t:1527030579443};\\\", \\\"{x:1338,y:695,t:1527030579450};\\\", \\\"{x:1339,y:696,t:1527030579461};\\\", \\\"{x:1342,y:700,t:1527030579477};\\\", \\\"{x:1343,y:701,t:1527030579494};\\\", \\\"{x:1344,y:701,t:1527030579513};\\\", \\\"{x:1346,y:703,t:1527030579529};\\\", \\\"{x:1346,y:704,t:1527030579545};\\\", \\\"{x:1347,y:706,t:1527030579562};\\\", \\\"{x:1348,y:707,t:1527030579577};\\\", \\\"{x:1349,y:712,t:1527030579594};\\\", \\\"{x:1349,y:714,t:1527030579612};\\\", \\\"{x:1349,y:718,t:1527030579627};\\\", \\\"{x:1349,y:723,t:1527030579645};\\\", \\\"{x:1350,y:727,t:1527030579661};\\\", \\\"{x:1350,y:732,t:1527030579677};\\\", \\\"{x:1350,y:737,t:1527030579694};\\\", \\\"{x:1350,y:741,t:1527030579711};\\\", \\\"{x:1350,y:744,t:1527030579728};\\\", \\\"{x:1350,y:747,t:1527030579745};\\\", \\\"{x:1350,y:748,t:1527030579761};\\\", \\\"{x:1350,y:749,t:1527030579777};\\\", \\\"{x:1350,y:756,t:1527030584706};\\\", \\\"{x:1345,y:765,t:1527030584716};\\\", \\\"{x:1334,y:786,t:1527030584733};\\\", \\\"{x:1304,y:830,t:1527030584749};\\\", \\\"{x:1246,y:881,t:1527030584766};\\\", \\\"{x:1157,y:941,t:1527030584782};\\\", \\\"{x:1061,y:982,t:1527030584800};\\\", \\\"{x:965,y:1007,t:1527030584817};\\\", \\\"{x:880,y:1013,t:1527030584833};\\\", \\\"{x:796,y:1013,t:1527030584853};\\\", \\\"{x:715,y:984,t:1527030584869};\\\", \\\"{x:683,y:957,t:1527030584886};\\\", \\\"{x:644,y:925,t:1527030584903};\\\", \\\"{x:602,y:878,t:1527030584921};\\\", \\\"{x:570,y:844,t:1527030584936};\\\", \\\"{x:549,y:822,t:1527030584953};\\\", \\\"{x:532,y:803,t:1527030584971};\\\", \\\"{x:513,y:785,t:1527030584986};\\\", \\\"{x:495,y:771,t:1527030585004};\\\", \\\"{x:480,y:758,t:1527030585020};\\\", \\\"{x:473,y:749,t:1527030585036};\\\", \\\"{x:464,y:739,t:1527030585054};\\\", \\\"{x:449,y:728,t:1527030585069};\\\", \\\"{x:431,y:714,t:1527030585085};\\\", \\\"{x:409,y:699,t:1527030585101};\\\", \\\"{x:383,y:681,t:1527030585120};\\\", \\\"{x:364,y:671,t:1527030585136};\\\", \\\"{x:342,y:662,t:1527030585153};\\\", \\\"{x:318,y:654,t:1527030585169};\\\", \\\"{x:294,y:644,t:1527030585185};\\\", \\\"{x:277,y:640,t:1527030585202};\\\", \\\"{x:268,y:639,t:1527030585220};\\\", \\\"{x:263,y:639,t:1527030585235};\\\", \\\"{x:260,y:639,t:1527030585253};\\\", \\\"{x:258,y:639,t:1527030585270};\\\", \\\"{x:252,y:639,t:1527030585286};\\\", \\\"{x:227,y:647,t:1527030585302};\\\", \\\"{x:204,y:651,t:1527030585319};\\\", \\\"{x:186,y:654,t:1527030585336};\\\", \\\"{x:181,y:654,t:1527030585352};\\\", \\\"{x:179,y:654,t:1527030585369};\\\", \\\"{x:179,y:653,t:1527030585422};\\\", \\\"{x:179,y:649,t:1527030585436};\\\", \\\"{x:178,y:639,t:1527030585452};\\\", \\\"{x:175,y:631,t:1527030585470};\\\", \\\"{x:174,y:626,t:1527030585485};\\\", \\\"{x:171,y:619,t:1527030585503};\\\", \\\"{x:168,y:614,t:1527030585519};\\\", \\\"{x:168,y:613,t:1527030585535};\\\", \\\"{x:168,y:612,t:1527030585552};\\\", \\\"{x:168,y:611,t:1527030585570};\\\", \\\"{x:168,y:608,t:1527030585598};\\\", \\\"{x:167,y:605,t:1527030585605};\\\", \\\"{x:164,y:601,t:1527030585620};\\\", \\\"{x:158,y:592,t:1527030585637};\\\", \\\"{x:155,y:591,t:1527030585653};\\\", \\\"{x:151,y:589,t:1527030585670};\\\", \\\"{x:137,y:579,t:1527030585686};\\\", \\\"{x:136,y:579,t:1527030585871};\\\", \\\"{x:137,y:578,t:1527030585885};\\\", \\\"{x:138,y:577,t:1527030585902};\\\", \\\"{x:138,y:576,t:1527030585919};\\\", \\\"{x:140,y:575,t:1527030585937};\\\", \\\"{x:140,y:574,t:1527030585952};\\\", \\\"{x:141,y:573,t:1527030585970};\\\", \\\"{x:143,y:571,t:1527030585987};\\\", \\\"{x:144,y:569,t:1527030586004};\\\", \\\"{x:147,y:565,t:1527030586020};\\\", \\\"{x:148,y:564,t:1527030586036};\\\", \\\"{x:149,y:562,t:1527030586054};\\\", \\\"{x:150,y:561,t:1527030586070};\\\", \\\"{x:151,y:559,t:1527030586086};\\\", \\\"{x:151,y:558,t:1527030586150};\\\", \\\"{x:152,y:557,t:1527030586157};\\\", \\\"{x:153,y:555,t:1527030586175};\\\", \\\"{x:154,y:555,t:1527030586190};\\\", \\\"{x:154,y:553,t:1527030586203};\\\", \\\"{x:157,y:549,t:1527030586220};\\\", \\\"{x:157,y:548,t:1527030586236};\\\", \\\"{x:163,y:548,t:1527030586870};\\\", \\\"{x:189,y:544,t:1527030586888};\\\", \\\"{x:242,y:544,t:1527030586904};\\\", \\\"{x:312,y:544,t:1527030586921};\\\", \\\"{x:376,y:544,t:1527030586938};\\\", \\\"{x:434,y:544,t:1527030586954};\\\", \\\"{x:460,y:544,t:1527030586971};\\\", \\\"{x:475,y:544,t:1527030586987};\\\", \\\"{x:480,y:544,t:1527030587003};\\\", \\\"{x:481,y:544,t:1527030587021};\\\", \\\"{x:482,y:544,t:1527030587038};\\\", \\\"{x:484,y:544,t:1527030587110};\\\", \\\"{x:486,y:544,t:1527030587121};\\\", \\\"{x:491,y:544,t:1527030587138};\\\", \\\"{x:497,y:544,t:1527030587154};\\\", \\\"{x:503,y:544,t:1527030587171};\\\", \\\"{x:508,y:544,t:1527030587188};\\\", \\\"{x:514,y:544,t:1527030587203};\\\", \\\"{x:523,y:543,t:1527030587220};\\\", \\\"{x:540,y:542,t:1527030587238};\\\", \\\"{x:576,y:542,t:1527030587254};\\\", \\\"{x:599,y:542,t:1527030587270};\\\", \\\"{x:617,y:542,t:1527030587287};\\\", \\\"{x:625,y:542,t:1527030587305};\\\", \\\"{x:627,y:542,t:1527030587320};\\\", \\\"{x:628,y:541,t:1527030587390};\\\", \\\"{x:628,y:540,t:1527030587406};\\\", \\\"{x:629,y:540,t:1527030587519};\\\", \\\"{x:632,y:544,t:1527030587534};\\\", \\\"{x:633,y:546,t:1527030587541};\\\", \\\"{x:635,y:550,t:1527030587555};\\\", \\\"{x:642,y:561,t:1527030587571};\\\", \\\"{x:653,y:578,t:1527030587588};\\\", \\\"{x:667,y:596,t:1527030587604};\\\", \\\"{x:676,y:605,t:1527030587621};\\\", \\\"{x:686,y:612,t:1527030587638};\\\", \\\"{x:697,y:615,t:1527030587654};\\\", \\\"{x:704,y:615,t:1527030587671};\\\", \\\"{x:709,y:614,t:1527030587688};\\\", \\\"{x:712,y:611,t:1527030587704};\\\", \\\"{x:718,y:604,t:1527030587722};\\\", \\\"{x:731,y:596,t:1527030587738};\\\", \\\"{x:747,y:591,t:1527030587755};\\\", \\\"{x:771,y:584,t:1527030587770};\\\", \\\"{x:790,y:575,t:1527030587787};\\\", \\\"{x:803,y:570,t:1527030587804};\\\", \\\"{x:811,y:567,t:1527030587821};\\\", \\\"{x:813,y:566,t:1527030587838};\\\", \\\"{x:813,y:565,t:1527030587855};\\\", \\\"{x:814,y:564,t:1527030587926};\\\", \\\"{x:814,y:563,t:1527030587942};\\\", \\\"{x:815,y:563,t:1527030587955};\\\", \\\"{x:816,y:560,t:1527030587972};\\\", \\\"{x:817,y:559,t:1527030587988};\\\", \\\"{x:817,y:558,t:1527030588004};\\\", \\\"{x:818,y:556,t:1527030588022};\\\", \\\"{x:821,y:548,t:1527030588039};\\\", \\\"{x:822,y:545,t:1527030588054};\\\", \\\"{x:824,y:541,t:1527030588071};\\\", \\\"{x:825,y:536,t:1527030588088};\\\", \\\"{x:826,y:529,t:1527030588105};\\\", \\\"{x:827,y:528,t:1527030588126};\\\", \\\"{x:828,y:527,t:1527030588158};\\\", \\\"{x:828,y:526,t:1527030588173};\\\", \\\"{x:828,y:525,t:1527030588188};\\\", \\\"{x:830,y:521,t:1527030588204};\\\", \\\"{x:831,y:519,t:1527030588222};\\\", \\\"{x:832,y:516,t:1527030588238};\\\", \\\"{x:832,y:515,t:1527030590262};\\\", \\\"{x:833,y:513,t:1527030590273};\\\", \\\"{x:834,y:512,t:1527030590290};\\\", \\\"{x:834,y:510,t:1527030590307};\\\", \\\"{x:835,y:509,t:1527030590322};\\\", \\\"{x:823,y:509,t:1527030596598};\\\", \\\"{x:811,y:504,t:1527030596612};\\\", \\\"{x:807,y:503,t:1527030596628};\\\", \\\"{x:822,y:524,t:1527030596646};\\\", \\\"{x:837,y:608,t:1527030596662};\\\", \\\"{x:806,y:660,t:1527030596679};\\\", \\\"{x:763,y:701,t:1527030596695};\\\", \\\"{x:723,y:732,t:1527030596712};\\\", \\\"{x:706,y:742,t:1527030596728};\\\", \\\"{x:694,y:747,t:1527030596745};\\\", \\\"{x:676,y:750,t:1527030596762};\\\", \\\"{x:636,y:751,t:1527030596778};\\\", \\\"{x:582,y:753,t:1527030596795};\\\", \\\"{x:562,y:754,t:1527030596813};\\\", \\\"{x:559,y:754,t:1527030596828};\\\", \\\"{x:558,y:755,t:1527030596861};\\\", \\\"{x:556,y:755,t:1527030596878};\\\", \\\"{x:553,y:755,t:1527030596894};\\\", \\\"{x:551,y:755,t:1527030596912};\\\", \\\"{x:543,y:754,t:1527030596929};\\\", \\\"{x:529,y:754,t:1527030596945};\\\", \\\"{x:525,y:754,t:1527030596962};\\\", \\\"{x:523,y:754,t:1527030596979};\\\", \\\"{x:522,y:750,t:1527030597582};\\\", \\\"{x:525,y:730,t:1527030597596};\\\", \\\"{x:528,y:709,t:1527030597612};\\\", \\\"{x:528,y:706,t:1527030597629};\\\", \\\"{x:528,y:704,t:1527030597646};\\\", \\\"{x:529,y:702,t:1527030597926};\\\", \\\"{x:532,y:700,t:1527030597934};\\\", \\\"{x:533,y:699,t:1527030597946};\\\", \\\"{x:535,y:698,t:1527030597963};\\\", \\\"{x:536,y:698,t:1527030597979};\\\" ] }, { \\\"rt\\\": 40596, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 594404, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -M -X -X -X -B -E -11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-05 PM-X -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:696,t:1527030599734};\\\", \\\"{x:535,y:686,t:1527030599747};\\\", \\\"{x:528,y:659,t:1527030599764};\\\", \\\"{x:521,y:640,t:1527030599782};\\\", \\\"{x:516,y:626,t:1527030599798};\\\", \\\"{x:513,y:612,t:1527030599814};\\\", \\\"{x:512,y:599,t:1527030599831};\\\", \\\"{x:509,y:593,t:1527030599848};\\\", \\\"{x:508,y:590,t:1527030599864};\\\", \\\"{x:505,y:586,t:1527030599881};\\\", \\\"{x:502,y:579,t:1527030599897};\\\", \\\"{x:501,y:575,t:1527030599914};\\\", \\\"{x:501,y:572,t:1527030599931};\\\", \\\"{x:501,y:567,t:1527030599948};\\\", \\\"{x:500,y:558,t:1527030599965};\\\", \\\"{x:500,y:546,t:1527030599981};\\\", \\\"{x:498,y:530,t:1527030599998};\\\", \\\"{x:498,y:524,t:1527030600015};\\\", \\\"{x:498,y:520,t:1527030600031};\\\", \\\"{x:497,y:518,t:1527030600048};\\\", \\\"{x:497,y:517,t:1527030600064};\\\", \\\"{x:497,y:516,t:1527030600093};\\\", \\\"{x:497,y:515,t:1527030600102};\\\", \\\"{x:497,y:514,t:1527030600115};\\\", \\\"{x:497,y:510,t:1527030600131};\\\", \\\"{x:497,y:509,t:1527030600148};\\\", \\\"{x:497,y:506,t:1527030600164};\\\", \\\"{x:496,y:502,t:1527030600181};\\\", \\\"{x:494,y:499,t:1527030600199};\\\", \\\"{x:493,y:496,t:1527030600215};\\\", \\\"{x:492,y:493,t:1527030600231};\\\", \\\"{x:489,y:490,t:1527030600248};\\\", \\\"{x:488,y:488,t:1527030600264};\\\", \\\"{x:487,y:487,t:1527030600282};\\\", \\\"{x:486,y:486,t:1527030600299};\\\", \\\"{x:484,y:484,t:1527030600314};\\\", \\\"{x:483,y:484,t:1527030600349};\\\", \\\"{x:482,y:484,t:1527030600366};\\\", \\\"{x:482,y:483,t:1527030600662};\\\", \\\"{x:483,y:481,t:1527030601670};\\\", \\\"{x:485,y:479,t:1527030601682};\\\", \\\"{x:488,y:476,t:1527030601699};\\\", \\\"{x:490,y:474,t:1527030601716};\\\", \\\"{x:491,y:474,t:1527030601732};\\\", \\\"{x:494,y:472,t:1527030607174};\\\", \\\"{x:499,y:470,t:1527030607187};\\\", \\\"{x:507,y:469,t:1527030607204};\\\", \\\"{x:514,y:466,t:1527030607221};\\\", \\\"{x:516,y:465,t:1527030607236};\\\", \\\"{x:519,y:465,t:1527030607318};\\\", \\\"{x:522,y:463,t:1527030607326};\\\", \\\"{x:524,y:462,t:1527030607337};\\\", \\\"{x:527,y:462,t:1527030607353};\\\", \\\"{x:528,y:462,t:1527030607374};\\\", \\\"{x:529,y:461,t:1527030607386};\\\", \\\"{x:534,y:459,t:1527030607404};\\\", \\\"{x:535,y:459,t:1527030607421};\\\", \\\"{x:537,y:459,t:1527030607437};\\\", \\\"{x:539,y:459,t:1527030608309};\\\", \\\"{x:540,y:459,t:1527030608334};\\\", \\\"{x:545,y:459,t:1527030608582};\\\", \\\"{x:553,y:460,t:1527030608590};\\\", \\\"{x:567,y:461,t:1527030608605};\\\", \\\"{x:662,y:474,t:1527030608622};\\\", \\\"{x:763,y:482,t:1527030608638};\\\", \\\"{x:885,y:484,t:1527030608655};\\\", \\\"{x:1016,y:484,t:1527030608671};\\\", \\\"{x:1135,y:484,t:1527030608687};\\\", \\\"{x:1218,y:484,t:1527030608705};\\\", \\\"{x:1279,y:491,t:1527030608721};\\\", \\\"{x:1315,y:502,t:1527030608738};\\\", \\\"{x:1339,y:520,t:1527030608755};\\\", \\\"{x:1357,y:540,t:1527030608772};\\\", \\\"{x:1363,y:557,t:1527030608788};\\\", \\\"{x:1369,y:582,t:1527030608804};\\\", \\\"{x:1374,y:623,t:1527030608821};\\\", \\\"{x:1379,y:657,t:1527030608838};\\\", \\\"{x:1387,y:687,t:1527030608854};\\\", \\\"{x:1394,y:714,t:1527030608872};\\\", \\\"{x:1398,y:733,t:1527030608889};\\\", \\\"{x:1399,y:738,t:1527030608905};\\\", \\\"{x:1399,y:739,t:1527030608921};\\\", \\\"{x:1399,y:740,t:1527030608942};\\\", \\\"{x:1399,y:743,t:1527030608955};\\\", \\\"{x:1390,y:754,t:1527030608972};\\\", \\\"{x:1379,y:768,t:1527030608989};\\\", \\\"{x:1370,y:778,t:1527030609005};\\\", \\\"{x:1363,y:785,t:1527030609021};\\\", \\\"{x:1361,y:787,t:1527030609039};\\\", \\\"{x:1359,y:790,t:1527030609055};\\\", \\\"{x:1356,y:805,t:1527030609071};\\\", \\\"{x:1356,y:828,t:1527030609088};\\\", \\\"{x:1359,y:853,t:1527030609105};\\\", \\\"{x:1366,y:873,t:1527030609122};\\\", \\\"{x:1371,y:882,t:1527030609139};\\\", \\\"{x:1374,y:886,t:1527030609154};\\\", \\\"{x:1376,y:888,t:1527030609172};\\\", \\\"{x:1376,y:889,t:1527030609222};\\\", \\\"{x:1376,y:890,t:1527030609238};\\\", \\\"{x:1376,y:891,t:1527030609255};\\\", \\\"{x:1376,y:892,t:1527030609286};\\\", \\\"{x:1376,y:893,t:1527030609317};\\\", \\\"{x:1377,y:894,t:1527030609439};\\\", \\\"{x:1378,y:892,t:1527030609456};\\\", \\\"{x:1378,y:885,t:1527030609472};\\\", \\\"{x:1378,y:872,t:1527030609489};\\\", \\\"{x:1378,y:865,t:1527030609506};\\\", \\\"{x:1378,y:859,t:1527030609521};\\\", \\\"{x:1378,y:848,t:1527030609539};\\\", \\\"{x:1378,y:836,t:1527030609556};\\\", \\\"{x:1378,y:822,t:1527030609572};\\\", \\\"{x:1378,y:808,t:1527030609589};\\\", \\\"{x:1376,y:799,t:1527030609606};\\\", \\\"{x:1376,y:797,t:1527030609637};\\\", \\\"{x:1376,y:796,t:1527030609686};\\\", \\\"{x:1376,y:793,t:1527030609702};\\\", \\\"{x:1376,y:792,t:1527030609710};\\\", \\\"{x:1376,y:790,t:1527030609722};\\\", \\\"{x:1379,y:787,t:1527030609739};\\\", \\\"{x:1379,y:785,t:1527030609755};\\\", \\\"{x:1381,y:783,t:1527030609772};\\\", \\\"{x:1381,y:781,t:1527030609788};\\\", \\\"{x:1381,y:777,t:1527030609806};\\\", \\\"{x:1381,y:776,t:1527030609823};\\\", \\\"{x:1381,y:775,t:1527030609838};\\\", \\\"{x:1381,y:766,t:1527030609856};\\\", \\\"{x:1381,y:760,t:1527030609873};\\\", \\\"{x:1380,y:756,t:1527030609889};\\\", \\\"{x:1377,y:751,t:1527030609906};\\\", \\\"{x:1375,y:749,t:1527030609923};\\\", \\\"{x:1370,y:745,t:1527030609939};\\\", \\\"{x:1361,y:733,t:1527030609956};\\\", \\\"{x:1353,y:724,t:1527030609973};\\\", \\\"{x:1349,y:714,t:1527030609989};\\\", \\\"{x:1348,y:711,t:1527030610006};\\\", \\\"{x:1349,y:710,t:1527030610054};\\\", \\\"{x:1362,y:718,t:1527030610061};\\\", \\\"{x:1380,y:733,t:1527030610073};\\\", \\\"{x:1405,y:759,t:1527030610089};\\\", \\\"{x:1418,y:774,t:1527030610106};\\\", \\\"{x:1429,y:787,t:1527030610123};\\\", \\\"{x:1434,y:791,t:1527030610139};\\\", \\\"{x:1436,y:791,t:1527030610156};\\\", \\\"{x:1438,y:791,t:1527030610173};\\\", \\\"{x:1441,y:790,t:1527030610190};\\\", \\\"{x:1447,y:789,t:1527030610206};\\\", \\\"{x:1451,y:789,t:1527030610223};\\\", \\\"{x:1455,y:789,t:1527030610240};\\\", \\\"{x:1457,y:789,t:1527030610256};\\\", \\\"{x:1458,y:789,t:1527030610310};\\\", \\\"{x:1459,y:789,t:1527030610342};\\\", \\\"{x:1460,y:790,t:1527030610382};\\\", \\\"{x:1461,y:791,t:1527030610390};\\\", \\\"{x:1463,y:795,t:1527030610405};\\\", \\\"{x:1467,y:803,t:1527030610423};\\\", \\\"{x:1472,y:813,t:1527030610440};\\\", \\\"{x:1477,y:820,t:1527030610455};\\\", \\\"{x:1480,y:825,t:1527030610473};\\\", \\\"{x:1483,y:830,t:1527030610489};\\\", \\\"{x:1484,y:832,t:1527030610505};\\\", \\\"{x:1484,y:833,t:1527030610542};\\\", \\\"{x:1484,y:834,t:1527030610574};\\\", \\\"{x:1484,y:833,t:1527030610686};\\\", \\\"{x:1484,y:832,t:1527030610693};\\\", \\\"{x:1484,y:830,t:1527030610707};\\\", \\\"{x:1484,y:829,t:1527030610723};\\\", \\\"{x:1484,y:827,t:1527030610739};\\\", \\\"{x:1483,y:825,t:1527030610758};\\\", \\\"{x:1482,y:825,t:1527030610772};\\\", \\\"{x:1476,y:819,t:1527030610790};\\\", \\\"{x:1459,y:812,t:1527030610807};\\\", \\\"{x:1437,y:807,t:1527030610823};\\\", \\\"{x:1411,y:800,t:1527030610839};\\\", \\\"{x:1397,y:797,t:1527030610856};\\\", \\\"{x:1387,y:796,t:1527030610873};\\\", \\\"{x:1381,y:795,t:1527030610890};\\\", \\\"{x:1380,y:795,t:1527030610926};\\\", \\\"{x:1378,y:795,t:1527030610939};\\\", \\\"{x:1372,y:796,t:1527030610957};\\\", \\\"{x:1361,y:797,t:1527030610973};\\\", \\\"{x:1352,y:797,t:1527030610989};\\\", \\\"{x:1352,y:795,t:1527030611029};\\\", \\\"{x:1352,y:794,t:1527030611039};\\\", \\\"{x:1352,y:791,t:1527030611057};\\\", \\\"{x:1352,y:787,t:1527030611074};\\\", \\\"{x:1352,y:782,t:1527030611089};\\\", \\\"{x:1352,y:779,t:1527030611107};\\\", \\\"{x:1352,y:777,t:1527030611124};\\\", \\\"{x:1351,y:773,t:1527030611140};\\\", \\\"{x:1349,y:770,t:1527030611157};\\\", \\\"{x:1349,y:768,t:1527030611174};\\\", \\\"{x:1348,y:768,t:1527030611254};\\\", \\\"{x:1347,y:768,t:1527030611285};\\\", \\\"{x:1346,y:768,t:1527030611293};\\\", \\\"{x:1345,y:768,t:1527030611306};\\\", \\\"{x:1342,y:768,t:1527030611324};\\\", \\\"{x:1339,y:768,t:1527030611340};\\\", \\\"{x:1338,y:769,t:1527030611357};\\\", \\\"{x:1336,y:769,t:1527030611374};\\\", \\\"{x:1335,y:769,t:1527030611598};\\\", \\\"{x:1335,y:768,t:1527030611622};\\\", \\\"{x:1335,y:767,t:1527030611629};\\\", \\\"{x:1335,y:766,t:1527030611640};\\\", \\\"{x:1334,y:765,t:1527030611657};\\\", \\\"{x:1333,y:764,t:1527030611685};\\\", \\\"{x:1332,y:763,t:1527030611702};\\\", \\\"{x:1332,y:762,t:1527030611718};\\\", \\\"{x:1331,y:760,t:1527030611726};\\\", \\\"{x:1329,y:758,t:1527030611741};\\\", \\\"{x:1327,y:752,t:1527030611756};\\\", \\\"{x:1313,y:723,t:1527030611774};\\\", \\\"{x:1298,y:701,t:1527030611791};\\\", \\\"{x:1283,y:683,t:1527030611807};\\\", \\\"{x:1268,y:666,t:1527030611824};\\\", \\\"{x:1252,y:648,t:1527030611841};\\\", \\\"{x:1246,y:640,t:1527030611857};\\\", \\\"{x:1246,y:637,t:1527030611873};\\\", \\\"{x:1248,y:633,t:1527030611891};\\\", \\\"{x:1255,y:627,t:1527030611907};\\\", \\\"{x:1259,y:625,t:1527030611924};\\\", \\\"{x:1260,y:625,t:1527030611940};\\\", \\\"{x:1261,y:624,t:1527030611958};\\\", \\\"{x:1262,y:623,t:1527030611973};\\\", \\\"{x:1262,y:622,t:1527030611991};\\\", \\\"{x:1263,y:619,t:1527030612008};\\\", \\\"{x:1263,y:616,t:1527030612024};\\\", \\\"{x:1265,y:612,t:1527030612041};\\\", \\\"{x:1266,y:609,t:1527030612057};\\\", \\\"{x:1267,y:606,t:1527030612074};\\\", \\\"{x:1268,y:603,t:1527030612090};\\\", \\\"{x:1270,y:601,t:1527030612107};\\\", \\\"{x:1270,y:600,t:1527030612124};\\\", \\\"{x:1270,y:598,t:1527030612141};\\\", \\\"{x:1270,y:597,t:1527030612157};\\\", \\\"{x:1271,y:595,t:1527030612238};\\\", \\\"{x:1272,y:594,t:1527030612245};\\\", \\\"{x:1272,y:593,t:1527030612358};\\\", \\\"{x:1273,y:592,t:1527030612470};\\\", \\\"{x:1273,y:591,t:1527030612477};\\\", \\\"{x:1275,y:589,t:1527030612490};\\\", \\\"{x:1276,y:584,t:1527030612507};\\\", \\\"{x:1279,y:578,t:1527030612525};\\\", \\\"{x:1279,y:573,t:1527030612541};\\\", \\\"{x:1279,y:571,t:1527030612558};\\\", \\\"{x:1279,y:570,t:1527030612581};\\\", \\\"{x:1279,y:569,t:1527030612597};\\\", \\\"{x:1279,y:568,t:1527030612608};\\\", \\\"{x:1279,y:567,t:1527030618446};\\\", \\\"{x:1233,y:586,t:1527030618463};\\\", \\\"{x:1146,y:605,t:1527030618479};\\\", \\\"{x:1049,y:619,t:1527030618497};\\\", \\\"{x:921,y:623,t:1527030618512};\\\", \\\"{x:782,y:623,t:1527030618529};\\\", \\\"{x:650,y:623,t:1527030618547};\\\", \\\"{x:541,y:622,t:1527030618563};\\\", \\\"{x:451,y:618,t:1527030618580};\\\", \\\"{x:393,y:610,t:1527030618596};\\\", \\\"{x:354,y:605,t:1527030618614};\\\", \\\"{x:333,y:601,t:1527030618630};\\\", \\\"{x:320,y:597,t:1527030618646};\\\", \\\"{x:320,y:596,t:1527030618664};\\\", \\\"{x:320,y:593,t:1527030618680};\\\", \\\"{x:320,y:586,t:1527030618696};\\\", \\\"{x:320,y:572,t:1527030618714};\\\", \\\"{x:320,y:558,t:1527030618731};\\\", \\\"{x:320,y:549,t:1527030618747};\\\", \\\"{x:326,y:538,t:1527030618763};\\\", \\\"{x:333,y:530,t:1527030618779};\\\", \\\"{x:341,y:520,t:1527030618796};\\\", \\\"{x:349,y:511,t:1527030618814};\\\", \\\"{x:372,y:497,t:1527030618830};\\\", \\\"{x:396,y:488,t:1527030618846};\\\", \\\"{x:416,y:481,t:1527030618863};\\\", \\\"{x:431,y:479,t:1527030618881};\\\", \\\"{x:456,y:479,t:1527030618896};\\\", \\\"{x:505,y:482,t:1527030618913};\\\", \\\"{x:552,y:494,t:1527030618931};\\\", \\\"{x:582,y:499,t:1527030618946};\\\", \\\"{x:598,y:502,t:1527030618963};\\\", \\\"{x:604,y:502,t:1527030618980};\\\", \\\"{x:605,y:502,t:1527030618997};\\\", \\\"{x:605,y:503,t:1527030619190};\\\", \\\"{x:606,y:505,t:1527030619213};\\\", \\\"{x:610,y:508,t:1527030619230};\\\", \\\"{x:610,y:508,t:1527030619290};\\\", \\\"{x:612,y:508,t:1527030619374};\\\", \\\"{x:616,y:509,t:1527030619381};\\\", \\\"{x:619,y:509,t:1527030619397};\\\", \\\"{x:627,y:510,t:1527030619413};\\\", \\\"{x:640,y:510,t:1527030619429};\\\", \\\"{x:668,y:510,t:1527030619448};\\\", \\\"{x:722,y:512,t:1527030619463};\\\", \\\"{x:789,y:512,t:1527030619480};\\\", \\\"{x:850,y:512,t:1527030619497};\\\", \\\"{x:928,y:512,t:1527030619513};\\\", \\\"{x:1014,y:512,t:1527030619531};\\\", \\\"{x:1091,y:519,t:1527030619548};\\\", \\\"{x:1117,y:526,t:1527030619563};\\\", \\\"{x:1121,y:528,t:1527030619580};\\\", \\\"{x:1124,y:531,t:1527030619598};\\\", \\\"{x:1128,y:537,t:1527030619613};\\\", \\\"{x:1131,y:550,t:1527030619630};\\\", \\\"{x:1132,y:554,t:1527030619647};\\\", \\\"{x:1133,y:559,t:1527030619664};\\\", \\\"{x:1133,y:562,t:1527030619680};\\\", \\\"{x:1136,y:567,t:1527030619697};\\\", \\\"{x:1140,y:573,t:1527030619714};\\\", \\\"{x:1143,y:575,t:1527030619730};\\\", \\\"{x:1144,y:577,t:1527030619747};\\\", \\\"{x:1146,y:577,t:1527030619764};\\\", \\\"{x:1147,y:577,t:1527030619781};\\\", \\\"{x:1150,y:577,t:1527030619798};\\\", \\\"{x:1153,y:576,t:1527030619814};\\\", \\\"{x:1157,y:574,t:1527030619830};\\\", \\\"{x:1163,y:573,t:1527030619848};\\\", \\\"{x:1166,y:572,t:1527030619864};\\\", \\\"{x:1168,y:572,t:1527030619881};\\\", \\\"{x:1174,y:570,t:1527030619898};\\\", \\\"{x:1180,y:569,t:1527030619914};\\\", \\\"{x:1191,y:568,t:1527030619930};\\\", \\\"{x:1203,y:565,t:1527030619948};\\\", \\\"{x:1217,y:564,t:1527030619965};\\\", \\\"{x:1221,y:564,t:1527030619981};\\\", \\\"{x:1223,y:564,t:1527030619998};\\\", \\\"{x:1229,y:566,t:1527030620014};\\\", \\\"{x:1238,y:576,t:1527030620031};\\\", \\\"{x:1248,y:589,t:1527030620047};\\\", \\\"{x:1261,y:601,t:1527030620064};\\\", \\\"{x:1271,y:610,t:1527030620081};\\\", \\\"{x:1276,y:613,t:1527030620098};\\\", \\\"{x:1277,y:613,t:1527030620278};\\\", \\\"{x:1278,y:612,t:1527030620294};\\\", \\\"{x:1279,y:609,t:1527030620302};\\\", \\\"{x:1281,y:603,t:1527030620314};\\\", \\\"{x:1285,y:596,t:1527030620332};\\\", \\\"{x:1287,y:585,t:1527030620347};\\\", \\\"{x:1290,y:578,t:1527030620364};\\\", \\\"{x:1290,y:575,t:1527030620381};\\\", \\\"{x:1290,y:576,t:1527030620526};\\\", \\\"{x:1290,y:580,t:1527030620533};\\\", \\\"{x:1289,y:584,t:1527030620547};\\\", \\\"{x:1288,y:598,t:1527030620565};\\\", \\\"{x:1287,y:619,t:1527030620582};\\\", \\\"{x:1287,y:646,t:1527030620597};\\\", \\\"{x:1287,y:711,t:1527030620615};\\\", \\\"{x:1287,y:749,t:1527030620631};\\\", \\\"{x:1285,y:772,t:1527030620648};\\\", \\\"{x:1282,y:789,t:1527030620665};\\\", \\\"{x:1279,y:802,t:1527030620682};\\\", \\\"{x:1274,y:811,t:1527030620699};\\\", \\\"{x:1269,y:822,t:1527030620715};\\\", \\\"{x:1265,y:838,t:1527030620732};\\\", \\\"{x:1263,y:858,t:1527030620749};\\\", \\\"{x:1263,y:876,t:1527030620764};\\\", \\\"{x:1263,y:890,t:1527030620782};\\\", \\\"{x:1263,y:899,t:1527030620798};\\\", \\\"{x:1263,y:900,t:1527030620815};\\\", \\\"{x:1263,y:903,t:1527030620831};\\\", \\\"{x:1264,y:914,t:1527030620848};\\\", \\\"{x:1269,y:932,t:1527030620864};\\\", \\\"{x:1274,y:951,t:1527030620881};\\\", \\\"{x:1277,y:962,t:1527030620899};\\\", \\\"{x:1280,y:967,t:1527030620914};\\\", \\\"{x:1280,y:969,t:1527030620931};\\\", \\\"{x:1281,y:970,t:1527030620950};\\\", \\\"{x:1282,y:970,t:1527030620982};\\\", \\\"{x:1283,y:972,t:1527030620998};\\\", \\\"{x:1284,y:973,t:1527030621014};\\\", \\\"{x:1285,y:974,t:1527030621031};\\\", \\\"{x:1286,y:976,t:1527030621048};\\\", \\\"{x:1286,y:975,t:1527030621406};\\\", \\\"{x:1290,y:975,t:1527030622767};\\\", \\\"{x:1342,y:973,t:1527030622783};\\\", \\\"{x:1417,y:973,t:1527030622800};\\\", \\\"{x:1486,y:973,t:1527030622816};\\\", \\\"{x:1542,y:973,t:1527030622833};\\\", \\\"{x:1592,y:977,t:1527030622849};\\\", \\\"{x:1612,y:979,t:1527030622867};\\\", \\\"{x:1616,y:980,t:1527030622882};\\\", \\\"{x:1617,y:980,t:1527030622942};\\\", \\\"{x:1619,y:980,t:1527030622950};\\\", \\\"{x:1623,y:980,t:1527030622966};\\\", \\\"{x:1624,y:980,t:1527030622983};\\\", \\\"{x:1627,y:980,t:1527030623000};\\\", \\\"{x:1644,y:977,t:1527030623017};\\\", \\\"{x:1698,y:970,t:1527030623034};\\\", \\\"{x:1751,y:962,t:1527030623050};\\\", \\\"{x:1775,y:956,t:1527030623067};\\\", \\\"{x:1781,y:955,t:1527030623083};\\\", \\\"{x:1780,y:955,t:1527030623190};\\\", \\\"{x:1777,y:955,t:1527030623200};\\\", \\\"{x:1771,y:956,t:1527030623217};\\\", \\\"{x:1767,y:957,t:1527030623233};\\\", \\\"{x:1763,y:957,t:1527030623249};\\\", \\\"{x:1760,y:959,t:1527030623266};\\\", \\\"{x:1758,y:960,t:1527030623303};\\\", \\\"{x:1753,y:960,t:1527030623317};\\\", \\\"{x:1738,y:961,t:1527030623334};\\\", \\\"{x:1722,y:961,t:1527030623349};\\\", \\\"{x:1704,y:961,t:1527030623366};\\\", \\\"{x:1700,y:961,t:1527030623383};\\\", \\\"{x:1699,y:961,t:1527030623400};\\\", \\\"{x:1697,y:961,t:1527030623694};\\\", \\\"{x:1696,y:961,t:1527030623702};\\\", \\\"{x:1694,y:961,t:1527030623716};\\\", \\\"{x:1692,y:961,t:1527030623734};\\\", \\\"{x:1691,y:961,t:1527030623758};\\\", \\\"{x:1690,y:961,t:1527030624015};\\\", \\\"{x:1688,y:961,t:1527030624038};\\\", \\\"{x:1687,y:961,t:1527030624051};\\\", \\\"{x:1684,y:961,t:1527030624068};\\\", \\\"{x:1680,y:961,t:1527030624083};\\\", \\\"{x:1675,y:961,t:1527030624100};\\\", \\\"{x:1672,y:961,t:1527030624118};\\\", \\\"{x:1670,y:961,t:1527030624165};\\\", \\\"{x:1669,y:961,t:1527030624174};\\\", \\\"{x:1665,y:960,t:1527030624183};\\\", \\\"{x:1654,y:947,t:1527030624200};\\\", \\\"{x:1648,y:939,t:1527030624218};\\\", \\\"{x:1640,y:931,t:1527030624233};\\\", \\\"{x:1637,y:929,t:1527030624251};\\\", \\\"{x:1633,y:925,t:1527030624267};\\\", \\\"{x:1625,y:920,t:1527030624284};\\\", \\\"{x:1614,y:914,t:1527030624301};\\\", \\\"{x:1610,y:912,t:1527030624318};\\\", \\\"{x:1607,y:910,t:1527030624333};\\\", \\\"{x:1606,y:910,t:1527030624429};\\\", \\\"{x:1605,y:910,t:1527030624437};\\\", \\\"{x:1603,y:909,t:1527030624451};\\\", \\\"{x:1588,y:907,t:1527030624468};\\\", \\\"{x:1560,y:902,t:1527030624485};\\\", \\\"{x:1534,y:899,t:1527030624501};\\\", \\\"{x:1516,y:896,t:1527030624517};\\\", \\\"{x:1504,y:892,t:1527030624534};\\\", \\\"{x:1503,y:892,t:1527030624558};\\\", \\\"{x:1503,y:891,t:1527030624606};\\\", \\\"{x:1503,y:890,t:1527030624618};\\\", \\\"{x:1497,y:884,t:1527030624634};\\\", \\\"{x:1486,y:877,t:1527030624650};\\\", \\\"{x:1471,y:866,t:1527030624668};\\\", \\\"{x:1461,y:858,t:1527030624684};\\\", \\\"{x:1459,y:857,t:1527030624701};\\\", \\\"{x:1459,y:856,t:1527030624750};\\\", \\\"{x:1459,y:854,t:1527030624757};\\\", \\\"{x:1459,y:851,t:1527030624773};\\\", \\\"{x:1459,y:848,t:1527030624785};\\\", \\\"{x:1461,y:846,t:1527030624800};\\\", \\\"{x:1465,y:842,t:1527030624818};\\\", \\\"{x:1470,y:841,t:1527030624834};\\\", \\\"{x:1475,y:838,t:1527030624851};\\\", \\\"{x:1479,y:837,t:1527030624867};\\\", \\\"{x:1481,y:835,t:1527030624885};\\\", \\\"{x:1482,y:835,t:1527030624926};\\\", \\\"{x:1483,y:834,t:1527030627278};\\\", \\\"{x:1484,y:834,t:1527030627285};\\\", \\\"{x:1489,y:834,t:1527030627303};\\\", \\\"{x:1498,y:832,t:1527030627320};\\\", \\\"{x:1512,y:832,t:1527030627337};\\\", \\\"{x:1528,y:832,t:1527030627352};\\\", \\\"{x:1538,y:832,t:1527030627369};\\\", \\\"{x:1541,y:832,t:1527030627386};\\\", \\\"{x:1543,y:833,t:1527030627406};\\\", \\\"{x:1548,y:836,t:1527030627420};\\\", \\\"{x:1559,y:846,t:1527030627437};\\\", \\\"{x:1577,y:857,t:1527030627452};\\\", \\\"{x:1594,y:866,t:1527030627470};\\\", \\\"{x:1597,y:868,t:1527030627486};\\\", \\\"{x:1599,y:868,t:1527030627503};\\\", \\\"{x:1600,y:869,t:1527030627519};\\\", \\\"{x:1600,y:870,t:1527030627565};\\\", \\\"{x:1600,y:871,t:1527030627582};\\\", \\\"{x:1600,y:872,t:1527030627590};\\\", \\\"{x:1601,y:873,t:1527030627602};\\\", \\\"{x:1601,y:874,t:1527030627619};\\\", \\\"{x:1602,y:874,t:1527030627653};\\\", \\\"{x:1602,y:876,t:1527030627670};\\\", \\\"{x:1603,y:876,t:1527030627686};\\\", \\\"{x:1604,y:877,t:1527030627702};\\\", \\\"{x:1605,y:878,t:1527030627720};\\\", \\\"{x:1605,y:879,t:1527030627736};\\\", \\\"{x:1606,y:879,t:1527030627822};\\\", \\\"{x:1608,y:880,t:1527030627836};\\\", \\\"{x:1612,y:882,t:1527030627853};\\\", \\\"{x:1615,y:883,t:1527030627870};\\\", \\\"{x:1617,y:885,t:1527030627887};\\\", \\\"{x:1619,y:887,t:1527030627904};\\\", \\\"{x:1621,y:889,t:1527030627920};\\\", \\\"{x:1622,y:895,t:1527030627937};\\\", \\\"{x:1622,y:896,t:1527030627954};\\\", \\\"{x:1622,y:897,t:1527030627969};\\\", \\\"{x:1622,y:898,t:1527030627987};\\\", \\\"{x:1621,y:899,t:1527030633366};\\\", \\\"{x:1617,y:899,t:1527030633374};\\\", \\\"{x:1614,y:899,t:1527030633391};\\\", \\\"{x:1609,y:898,t:1527030633406};\\\", \\\"{x:1606,y:898,t:1527030633424};\\\", \\\"{x:1603,y:898,t:1527030633440};\\\", \\\"{x:1600,y:898,t:1527030633456};\\\", \\\"{x:1597,y:898,t:1527030633474};\\\", \\\"{x:1590,y:898,t:1527030633491};\\\", \\\"{x:1580,y:898,t:1527030633507};\\\", \\\"{x:1569,y:898,t:1527030633524};\\\", \\\"{x:1558,y:898,t:1527030633541};\\\", \\\"{x:1542,y:898,t:1527030633558};\\\", \\\"{x:1538,y:899,t:1527030633574};\\\", \\\"{x:1530,y:901,t:1527030633591};\\\", \\\"{x:1521,y:904,t:1527030633608};\\\", \\\"{x:1511,y:907,t:1527030633624};\\\", \\\"{x:1501,y:908,t:1527030633641};\\\", \\\"{x:1488,y:908,t:1527030633658};\\\", \\\"{x:1476,y:908,t:1527030633674};\\\", \\\"{x:1465,y:908,t:1527030633691};\\\", \\\"{x:1455,y:908,t:1527030633708};\\\", \\\"{x:1448,y:908,t:1527030633724};\\\", \\\"{x:1442,y:908,t:1527030633741};\\\", \\\"{x:1436,y:908,t:1527030633758};\\\", \\\"{x:1433,y:908,t:1527030633774};\\\", \\\"{x:1431,y:908,t:1527030633791};\\\", \\\"{x:1426,y:908,t:1527030633808};\\\", \\\"{x:1422,y:907,t:1527030633824};\\\", \\\"{x:1418,y:905,t:1527030633841};\\\", \\\"{x:1415,y:904,t:1527030633858};\\\", \\\"{x:1412,y:904,t:1527030633873};\\\", \\\"{x:1412,y:903,t:1527030633894};\\\", \\\"{x:1411,y:902,t:1527030633910};\\\", \\\"{x:1410,y:900,t:1527030633926};\\\", \\\"{x:1408,y:899,t:1527030633941};\\\", \\\"{x:1407,y:897,t:1527030633957};\\\", \\\"{x:1406,y:894,t:1527030633974};\\\", \\\"{x:1405,y:892,t:1527030633991};\\\", \\\"{x:1404,y:887,t:1527030634008};\\\", \\\"{x:1399,y:879,t:1527030634024};\\\", \\\"{x:1395,y:870,t:1527030634040};\\\", \\\"{x:1392,y:864,t:1527030634058};\\\", \\\"{x:1390,y:858,t:1527030634075};\\\", \\\"{x:1388,y:853,t:1527030634091};\\\", \\\"{x:1386,y:842,t:1527030634108};\\\", \\\"{x:1378,y:826,t:1527030634125};\\\", \\\"{x:1371,y:811,t:1527030634141};\\\", \\\"{x:1366,y:803,t:1527030634158};\\\", \\\"{x:1364,y:801,t:1527030634175};\\\", \\\"{x:1364,y:800,t:1527030634191};\\\", \\\"{x:1364,y:799,t:1527030634213};\\\", \\\"{x:1364,y:797,t:1527030634225};\\\", \\\"{x:1364,y:794,t:1527030634240};\\\", \\\"{x:1364,y:790,t:1527030634258};\\\", \\\"{x:1363,y:787,t:1527030634275};\\\", \\\"{x:1363,y:786,t:1527030634291};\\\", \\\"{x:1362,y:784,t:1527030634308};\\\", \\\"{x:1362,y:779,t:1527030634325};\\\", \\\"{x:1360,y:775,t:1527030634341};\\\", \\\"{x:1356,y:765,t:1527030634357};\\\", \\\"{x:1355,y:761,t:1527030634375};\\\", \\\"{x:1352,y:756,t:1527030634391};\\\", \\\"{x:1351,y:752,t:1527030634408};\\\", \\\"{x:1349,y:749,t:1527030634426};\\\", \\\"{x:1347,y:745,t:1527030634441};\\\", \\\"{x:1346,y:743,t:1527030634459};\\\", \\\"{x:1345,y:741,t:1527030634475};\\\", \\\"{x:1344,y:735,t:1527030634491};\\\", \\\"{x:1344,y:731,t:1527030634508};\\\", \\\"{x:1344,y:730,t:1527030634525};\\\", \\\"{x:1344,y:728,t:1527030634543};\\\", \\\"{x:1344,y:727,t:1527030634558};\\\", \\\"{x:1344,y:725,t:1527030634575};\\\", \\\"{x:1344,y:718,t:1527030634592};\\\", \\\"{x:1344,y:717,t:1527030634608};\\\", \\\"{x:1344,y:716,t:1527030634625};\\\", \\\"{x:1344,y:715,t:1527030634642};\\\", \\\"{x:1343,y:713,t:1527030634662};\\\", \\\"{x:1342,y:713,t:1527030634675};\\\", \\\"{x:1342,y:711,t:1527030634692};\\\", \\\"{x:1342,y:710,t:1527030634708};\\\", \\\"{x:1341,y:709,t:1527030634725};\\\", \\\"{x:1341,y:708,t:1527030634742};\\\", \\\"{x:1340,y:707,t:1527030634758};\\\", \\\"{x:1340,y:706,t:1527030634798};\\\", \\\"{x:1339,y:706,t:1527030634814};\\\", \\\"{x:1339,y:705,t:1527030634825};\\\", \\\"{x:1339,y:704,t:1527030634843};\\\", \\\"{x:1339,y:703,t:1527030634858};\\\", \\\"{x:1339,y:701,t:1527030634875};\\\", \\\"{x:1339,y:700,t:1527030634892};\\\", \\\"{x:1338,y:697,t:1527030634909};\\\", \\\"{x:1337,y:695,t:1527030634924};\\\", \\\"{x:1334,y:681,t:1527030634942};\\\", \\\"{x:1330,y:667,t:1527030634959};\\\", \\\"{x:1328,y:665,t:1527030634975};\\\", \\\"{x:1325,y:660,t:1527030634992};\\\", \\\"{x:1316,y:645,t:1527030635008};\\\", \\\"{x:1307,y:636,t:1527030635025};\\\", \\\"{x:1302,y:630,t:1527030635042};\\\", \\\"{x:1300,y:627,t:1527030635058};\\\", \\\"{x:1299,y:625,t:1527030635075};\\\", \\\"{x:1299,y:623,t:1527030635092};\\\", \\\"{x:1297,y:618,t:1527030635109};\\\", \\\"{x:1296,y:613,t:1527030635125};\\\", \\\"{x:1296,y:608,t:1527030635141};\\\", \\\"{x:1296,y:606,t:1527030635159};\\\", \\\"{x:1296,y:602,t:1527030635175};\\\", \\\"{x:1296,y:594,t:1527030635192};\\\", \\\"{x:1296,y:591,t:1527030635210};\\\", \\\"{x:1296,y:587,t:1527030635225};\\\", \\\"{x:1296,y:583,t:1527030635242};\\\", \\\"{x:1295,y:581,t:1527030635259};\\\", \\\"{x:1295,y:580,t:1527030635275};\\\", \\\"{x:1295,y:579,t:1527030635292};\\\", \\\"{x:1295,y:578,t:1527030635309};\\\", \\\"{x:1295,y:573,t:1527030635325};\\\", \\\"{x:1294,y:571,t:1527030635342};\\\", \\\"{x:1294,y:570,t:1527030635359};\\\", \\\"{x:1292,y:570,t:1527030635486};\\\", \\\"{x:1291,y:570,t:1527030635494};\\\", \\\"{x:1290,y:571,t:1527030635509};\\\", \\\"{x:1286,y:579,t:1527030635525};\\\", \\\"{x:1277,y:600,t:1527030635542};\\\", \\\"{x:1271,y:621,t:1527030635559};\\\", \\\"{x:1265,y:642,t:1527030635576};\\\", \\\"{x:1258,y:665,t:1527030635592};\\\", \\\"{x:1255,y:681,t:1527030635609};\\\", \\\"{x:1254,y:702,t:1527030635626};\\\", \\\"{x:1252,y:716,t:1527030635642};\\\", \\\"{x:1250,y:728,t:1527030635659};\\\", \\\"{x:1249,y:738,t:1527030635676};\\\", \\\"{x:1246,y:750,t:1527030635692};\\\", \\\"{x:1244,y:765,t:1527030635709};\\\", \\\"{x:1241,y:779,t:1527030635726};\\\", \\\"{x:1240,y:784,t:1527030635742};\\\", \\\"{x:1240,y:788,t:1527030635759};\\\", \\\"{x:1238,y:792,t:1527030635776};\\\", \\\"{x:1237,y:795,t:1527030635792};\\\", \\\"{x:1236,y:802,t:1527030635809};\\\", \\\"{x:1235,y:810,t:1527030635826};\\\", \\\"{x:1232,y:816,t:1527030635842};\\\", \\\"{x:1232,y:820,t:1527030635859};\\\", \\\"{x:1232,y:822,t:1527030635876};\\\", \\\"{x:1231,y:822,t:1527030635892};\\\", \\\"{x:1230,y:823,t:1527030635909};\\\", \\\"{x:1230,y:824,t:1527030635950};\\\", \\\"{x:1230,y:825,t:1527030635959};\\\", \\\"{x:1231,y:824,t:1527030636702};\\\", \\\"{x:1234,y:822,t:1527030636709};\\\", \\\"{x:1237,y:820,t:1527030636726};\\\", \\\"{x:1240,y:816,t:1527030636743};\\\", \\\"{x:1247,y:812,t:1527030636760};\\\", \\\"{x:1253,y:809,t:1527030636776};\\\", \\\"{x:1267,y:800,t:1527030636793};\\\", \\\"{x:1286,y:786,t:1527030636810};\\\", \\\"{x:1305,y:775,t:1527030636827};\\\", \\\"{x:1320,y:764,t:1527030636843};\\\", \\\"{x:1329,y:759,t:1527030636861};\\\", \\\"{x:1333,y:754,t:1527030636876};\\\", \\\"{x:1335,y:751,t:1527030636893};\\\", \\\"{x:1339,y:742,t:1527030636909};\\\", \\\"{x:1342,y:738,t:1527030636926};\\\", \\\"{x:1346,y:732,t:1527030636943};\\\", \\\"{x:1348,y:728,t:1527030636960};\\\", \\\"{x:1350,y:726,t:1527030636977};\\\", \\\"{x:1351,y:724,t:1527030636993};\\\", \\\"{x:1346,y:727,t:1527030638229};\\\", \\\"{x:1337,y:733,t:1527030638244};\\\", \\\"{x:1306,y:746,t:1527030638261};\\\", \\\"{x:1250,y:763,t:1527030638277};\\\", \\\"{x:1100,y:792,t:1527030638295};\\\", \\\"{x:990,y:798,t:1527030638312};\\\", \\\"{x:880,y:798,t:1527030638327};\\\", \\\"{x:773,y:793,t:1527030638344};\\\", \\\"{x:673,y:763,t:1527030638361};\\\", \\\"{x:592,y:723,t:1527030638377};\\\", \\\"{x:543,y:680,t:1527030638394};\\\", \\\"{x:507,y:651,t:1527030638411};\\\", \\\"{x:482,y:630,t:1527030638429};\\\", \\\"{x:478,y:625,t:1527030638444};\\\", \\\"{x:477,y:624,t:1527030638461};\\\", \\\"{x:474,y:626,t:1527030638526};\\\", \\\"{x:471,y:629,t:1527030638539};\\\", \\\"{x:466,y:641,t:1527030638556};\\\", \\\"{x:466,y:655,t:1527030638573};\\\", \\\"{x:467,y:672,t:1527030638597};\\\", \\\"{x:471,y:682,t:1527030638612};\\\", \\\"{x:481,y:695,t:1527030638629};\\\", \\\"{x:489,y:709,t:1527030638646};\\\", \\\"{x:494,y:719,t:1527030638662};\\\", \\\"{x:498,y:728,t:1527030638679};\\\", \\\"{x:502,y:733,t:1527030638696};\\\", \\\"{x:503,y:734,t:1527030638766};\\\", \\\"{x:504,y:735,t:1527030638779};\\\", \\\"{x:506,y:736,t:1527030638798};\\\", \\\"{x:507,y:736,t:1527030638822};\\\" ] }, { \\\"rt\\\": 35087, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 630679, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -J -10 AM-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:736,t:1527030646017};\\\", \\\"{x:535,y:730,t:1527030646025};\\\", \\\"{x:571,y:715,t:1527030646043};\\\", \\\"{x:599,y:704,t:1527030646060};\\\", \\\"{x:606,y:700,t:1527030646076};\\\", \\\"{x:608,y:699,t:1527030646087};\\\", \\\"{x:617,y:694,t:1527030646104};\\\", \\\"{x:618,y:692,t:1527030646121};\\\", \\\"{x:618,y:689,t:1527030646138};\\\", \\\"{x:618,y:686,t:1527030646154};\\\", \\\"{x:618,y:680,t:1527030646172};\\\", \\\"{x:623,y:669,t:1527030646188};\\\", \\\"{x:632,y:661,t:1527030646204};\\\", \\\"{x:640,y:660,t:1527030646221};\\\", \\\"{x:643,y:660,t:1527030646238};\\\", \\\"{x:648,y:661,t:1527030646254};\\\", \\\"{x:661,y:669,t:1527030646272};\\\", \\\"{x:676,y:678,t:1527030646289};\\\", \\\"{x:687,y:683,t:1527030646304};\\\", \\\"{x:701,y:686,t:1527030646321};\\\", \\\"{x:718,y:691,t:1527030646339};\\\", \\\"{x:734,y:695,t:1527030646354};\\\", \\\"{x:749,y:699,t:1527030646371};\\\", \\\"{x:759,y:699,t:1527030646389};\\\", \\\"{x:766,y:699,t:1527030646404};\\\", \\\"{x:774,y:699,t:1527030646422};\\\", \\\"{x:781,y:697,t:1527030646439};\\\", \\\"{x:787,y:695,t:1527030646454};\\\", \\\"{x:791,y:695,t:1527030646761};\\\", \\\"{x:825,y:688,t:1527030646771};\\\", \\\"{x:911,y:675,t:1527030646789};\\\", \\\"{x:928,y:674,t:1527030646805};\\\", \\\"{x:930,y:674,t:1527030646821};\\\", \\\"{x:931,y:674,t:1527030646848};\\\", \\\"{x:933,y:674,t:1527030646857};\\\", \\\"{x:941,y:674,t:1527030646871};\\\", \\\"{x:1018,y:673,t:1527030646889};\\\", \\\"{x:1104,y:673,t:1527030646906};\\\", \\\"{x:1176,y:673,t:1527030646921};\\\", \\\"{x:1218,y:673,t:1527030646939};\\\", \\\"{x:1234,y:673,t:1527030646955};\\\", \\\"{x:1237,y:673,t:1527030646971};\\\", \\\"{x:1238,y:674,t:1527030647009};\\\", \\\"{x:1238,y:675,t:1527030647021};\\\", \\\"{x:1238,y:679,t:1527030647039};\\\", \\\"{x:1238,y:680,t:1527030647055};\\\", \\\"{x:1239,y:681,t:1527030647136};\\\", \\\"{x:1241,y:681,t:1527030647144};\\\", \\\"{x:1244,y:681,t:1527030647155};\\\", \\\"{x:1246,y:681,t:1527030647172};\\\", \\\"{x:1248,y:681,t:1527030647188};\\\", \\\"{x:1247,y:681,t:1527030647265};\\\", \\\"{x:1245,y:681,t:1527030647273};\\\", \\\"{x:1240,y:681,t:1527030647288};\\\", \\\"{x:1233,y:686,t:1527030647305};\\\", \\\"{x:1231,y:692,t:1527030647323};\\\", \\\"{x:1231,y:695,t:1527030647339};\\\", \\\"{x:1229,y:696,t:1527030647356};\\\", \\\"{x:1231,y:700,t:1527030647409};\\\", \\\"{x:1233,y:704,t:1527030647423};\\\", \\\"{x:1238,y:713,t:1527030647438};\\\", \\\"{x:1245,y:722,t:1527030647455};\\\", \\\"{x:1261,y:734,t:1527030647472};\\\", \\\"{x:1277,y:744,t:1527030647488};\\\", \\\"{x:1296,y:753,t:1527030647505};\\\", \\\"{x:1311,y:756,t:1527030647523};\\\", \\\"{x:1326,y:759,t:1527030647538};\\\", \\\"{x:1335,y:760,t:1527030647555};\\\", \\\"{x:1336,y:760,t:1527030647572};\\\", \\\"{x:1337,y:760,t:1527030647590};\\\", \\\"{x:1338,y:760,t:1527030647713};\\\", \\\"{x:1338,y:759,t:1527030647736};\\\", \\\"{x:1339,y:758,t:1527030647744};\\\", \\\"{x:1339,y:757,t:1527030647760};\\\", \\\"{x:1339,y:755,t:1527030647817};\\\", \\\"{x:1339,y:753,t:1527030647824};\\\", \\\"{x:1339,y:752,t:1527030647840};\\\", \\\"{x:1340,y:746,t:1527030647855};\\\", \\\"{x:1344,y:740,t:1527030647872};\\\", \\\"{x:1346,y:736,t:1527030647889};\\\", \\\"{x:1347,y:731,t:1527030647906};\\\", \\\"{x:1348,y:730,t:1527030647922};\\\", \\\"{x:1349,y:728,t:1527030647939};\\\", \\\"{x:1350,y:727,t:1527030647960};\\\", \\\"{x:1350,y:726,t:1527030647984};\\\", \\\"{x:1350,y:725,t:1527030647992};\\\", \\\"{x:1351,y:723,t:1527030648041};\\\", \\\"{x:1351,y:722,t:1527030648072};\\\", \\\"{x:1351,y:721,t:1527030648090};\\\", \\\"{x:1352,y:720,t:1527030648105};\\\", \\\"{x:1350,y:721,t:1527030648977};\\\", \\\"{x:1349,y:722,t:1527030648990};\\\", \\\"{x:1349,y:728,t:1527030649006};\\\", \\\"{x:1348,y:735,t:1527030649024};\\\", \\\"{x:1343,y:748,t:1527030649040};\\\", \\\"{x:1340,y:752,t:1527030649056};\\\", \\\"{x:1337,y:755,t:1527030649129};\\\", \\\"{x:1324,y:760,t:1527030649140};\\\", \\\"{x:1282,y:769,t:1527030649156};\\\", \\\"{x:1229,y:777,t:1527030649174};\\\", \\\"{x:1176,y:785,t:1527030649191};\\\", \\\"{x:1136,y:785,t:1527030649207};\\\", \\\"{x:1117,y:787,t:1527030649223};\\\", \\\"{x:1112,y:787,t:1527030649240};\\\", \\\"{x:1112,y:786,t:1527030649392};\\\", \\\"{x:1114,y:783,t:1527030649407};\\\", \\\"{x:1116,y:780,t:1527030649424};\\\", \\\"{x:1117,y:779,t:1527030649440};\\\", \\\"{x:1117,y:778,t:1527030649465};\\\", \\\"{x:1119,y:777,t:1527030649496};\\\", \\\"{x:1119,y:776,t:1527030649506};\\\", \\\"{x:1120,y:776,t:1527030649523};\\\", \\\"{x:1122,y:774,t:1527030649540};\\\", \\\"{x:1123,y:774,t:1527030649593};\\\", \\\"{x:1125,y:774,t:1527030649607};\\\", \\\"{x:1127,y:774,t:1527030649623};\\\", \\\"{x:1131,y:773,t:1527030649640};\\\", \\\"{x:1132,y:772,t:1527030649673};\\\", \\\"{x:1135,y:772,t:1527030649688};\\\", \\\"{x:1136,y:771,t:1527030649696};\\\", \\\"{x:1137,y:770,t:1527030649833};\\\", \\\"{x:1138,y:770,t:1527030649849};\\\", \\\"{x:1139,y:770,t:1527030650016};\\\", \\\"{x:1140,y:770,t:1527030650289};\\\", \\\"{x:1142,y:770,t:1527030650304};\\\", \\\"{x:1143,y:770,t:1527030650312};\\\", \\\"{x:1144,y:770,t:1527030650325};\\\", \\\"{x:1148,y:769,t:1527030650341};\\\", \\\"{x:1150,y:768,t:1527030650358};\\\", \\\"{x:1151,y:768,t:1527030650375};\\\", \\\"{x:1153,y:768,t:1527030650409};\\\", \\\"{x:1156,y:768,t:1527030650424};\\\", \\\"{x:1161,y:768,t:1527030650441};\\\", \\\"{x:1164,y:768,t:1527030650458};\\\", \\\"{x:1166,y:768,t:1527030650475};\\\", \\\"{x:1167,y:768,t:1527030650491};\\\", \\\"{x:1168,y:768,t:1527030650513};\\\", \\\"{x:1170,y:768,t:1527030650524};\\\", \\\"{x:1171,y:768,t:1527030650540};\\\", \\\"{x:1172,y:768,t:1527030650557};\\\", \\\"{x:1174,y:768,t:1527030650574};\\\", \\\"{x:1175,y:768,t:1527030656016};\\\", \\\"{x:1177,y:769,t:1527030656033};\\\", \\\"{x:1178,y:770,t:1527030656044};\\\", \\\"{x:1181,y:775,t:1527030656062};\\\", \\\"{x:1183,y:779,t:1527030656079};\\\", \\\"{x:1186,y:786,t:1527030656094};\\\", \\\"{x:1190,y:795,t:1527030656112};\\\", \\\"{x:1197,y:812,t:1527030656128};\\\", \\\"{x:1202,y:825,t:1527030656145};\\\", \\\"{x:1207,y:836,t:1527030656162};\\\", \\\"{x:1211,y:844,t:1527030656179};\\\", \\\"{x:1214,y:848,t:1527030656195};\\\", \\\"{x:1214,y:849,t:1527030656212};\\\", \\\"{x:1215,y:851,t:1527030656229};\\\", \\\"{x:1216,y:851,t:1527030656256};\\\", \\\"{x:1216,y:848,t:1527030656345};\\\", \\\"{x:1216,y:846,t:1527030656361};\\\", \\\"{x:1216,y:844,t:1527030656368};\\\", \\\"{x:1216,y:842,t:1527030656384};\\\", \\\"{x:1216,y:841,t:1527030656396};\\\", \\\"{x:1216,y:840,t:1527030656416};\\\", \\\"{x:1216,y:839,t:1527030656457};\\\", \\\"{x:1216,y:838,t:1527030656504};\\\", \\\"{x:1216,y:836,t:1527030656577};\\\", \\\"{x:1216,y:835,t:1527030656601};\\\", \\\"{x:1216,y:834,t:1527030656629};\\\", \\\"{x:1216,y:833,t:1527030656646};\\\", \\\"{x:1216,y:832,t:1527030656662};\\\", \\\"{x:1216,y:830,t:1527030656679};\\\", \\\"{x:1215,y:829,t:1527030656696};\\\", \\\"{x:1214,y:827,t:1527030656712};\\\", \\\"{x:1213,y:827,t:1527030656729};\\\", \\\"{x:1213,y:826,t:1527030656746};\\\", \\\"{x:1213,y:824,t:1527030656763};\\\", \\\"{x:1213,y:823,t:1527030656792};\\\", \\\"{x:1213,y:822,t:1527030656800};\\\", \\\"{x:1213,y:821,t:1527030656813};\\\", \\\"{x:1212,y:819,t:1527030656829};\\\", \\\"{x:1212,y:818,t:1527030656845};\\\", \\\"{x:1212,y:817,t:1527030656863};\\\", \\\"{x:1211,y:815,t:1527030656879};\\\", \\\"{x:1211,y:814,t:1527030656896};\\\", \\\"{x:1210,y:813,t:1527030656913};\\\", \\\"{x:1209,y:811,t:1527030656929};\\\", \\\"{x:1209,y:810,t:1527030656946};\\\", \\\"{x:1208,y:809,t:1527030656968};\\\", \\\"{x:1207,y:809,t:1527030656984};\\\", \\\"{x:1206,y:807,t:1527030657001};\\\", \\\"{x:1205,y:806,t:1527030657032};\\\", \\\"{x:1204,y:805,t:1527030657049};\\\", \\\"{x:1203,y:804,t:1527030657072};\\\", \\\"{x:1202,y:804,t:1527030657097};\\\", \\\"{x:1202,y:802,t:1527030657120};\\\", \\\"{x:1201,y:801,t:1527030657129};\\\", \\\"{x:1201,y:798,t:1527030657146};\\\", \\\"{x:1200,y:796,t:1527030657163};\\\", \\\"{x:1200,y:794,t:1527030657179};\\\", \\\"{x:1199,y:793,t:1527030657195};\\\", \\\"{x:1199,y:792,t:1527030657213};\\\", \\\"{x:1199,y:791,t:1527030657230};\\\", \\\"{x:1198,y:790,t:1527030657247};\\\", \\\"{x:1198,y:789,t:1527030657263};\\\", \\\"{x:1197,y:788,t:1527030657279};\\\", \\\"{x:1197,y:787,t:1527030657296};\\\", \\\"{x:1197,y:785,t:1527030657313};\\\", \\\"{x:1195,y:783,t:1527030657409};\\\", \\\"{x:1195,y:782,t:1527030657417};\\\", \\\"{x:1194,y:782,t:1527030657430};\\\", \\\"{x:1194,y:781,t:1527030657446};\\\", \\\"{x:1194,y:780,t:1527030657463};\\\", \\\"{x:1193,y:779,t:1527030657480};\\\", \\\"{x:1193,y:777,t:1527030657897};\\\", \\\"{x:1193,y:776,t:1527030657913};\\\", \\\"{x:1195,y:775,t:1527030657930};\\\", \\\"{x:1199,y:772,t:1527030657947};\\\", \\\"{x:1200,y:771,t:1527030657963};\\\", \\\"{x:1201,y:771,t:1527030657980};\\\", \\\"{x:1202,y:771,t:1527030657997};\\\", \\\"{x:1203,y:770,t:1527030658689};\\\", \\\"{x:1204,y:770,t:1527030658697};\\\", \\\"{x:1207,y:770,t:1527030658714};\\\", \\\"{x:1209,y:769,t:1527030658731};\\\", \\\"{x:1210,y:769,t:1527030658747};\\\", \\\"{x:1209,y:769,t:1527030659024};\\\", \\\"{x:1208,y:769,t:1527030659032};\\\", \\\"{x:1207,y:769,t:1527030659049};\\\", \\\"{x:1205,y:768,t:1527030659065};\\\", \\\"{x:1204,y:768,t:1527030659080};\\\", \\\"{x:1203,y:768,t:1527030659098};\\\", \\\"{x:1202,y:768,t:1527030659114};\\\", \\\"{x:1201,y:768,t:1527030659169};\\\", \\\"{x:1200,y:767,t:1527030659184};\\\", \\\"{x:1199,y:767,t:1527030659198};\\\", \\\"{x:1198,y:767,t:1527030659353};\\\", \\\"{x:1197,y:767,t:1527030659364};\\\", \\\"{x:1196,y:767,t:1527030659381};\\\", \\\"{x:1194,y:766,t:1527030659398};\\\", \\\"{x:1193,y:766,t:1527030659414};\\\", \\\"{x:1191,y:766,t:1527030659431};\\\", \\\"{x:1190,y:766,t:1527030659448};\\\", \\\"{x:1189,y:766,t:1527030659465};\\\", \\\"{x:1188,y:766,t:1527030659505};\\\", \\\"{x:1187,y:766,t:1527030659529};\\\", \\\"{x:1187,y:767,t:1527030659912};\\\", \\\"{x:1188,y:768,t:1527030660800};\\\", \\\"{x:1189,y:768,t:1527030660815};\\\", \\\"{x:1190,y:768,t:1527030660832};\\\", \\\"{x:1192,y:768,t:1527030660849};\\\", \\\"{x:1193,y:768,t:1527030660872};\\\", \\\"{x:1195,y:768,t:1527030660882};\\\", \\\"{x:1200,y:768,t:1527030660899};\\\", \\\"{x:1207,y:768,t:1527030660915};\\\", \\\"{x:1217,y:768,t:1527030660932};\\\", \\\"{x:1232,y:768,t:1527030660949};\\\", \\\"{x:1242,y:768,t:1527030660965};\\\", \\\"{x:1248,y:768,t:1527030660982};\\\", \\\"{x:1250,y:768,t:1527030660999};\\\", \\\"{x:1250,y:769,t:1527030661089};\\\", \\\"{x:1250,y:770,t:1527030661137};\\\", \\\"{x:1250,y:771,t:1527030661152};\\\", \\\"{x:1249,y:773,t:1527030661166};\\\", \\\"{x:1248,y:774,t:1527030661182};\\\", \\\"{x:1246,y:776,t:1527030661199};\\\", \\\"{x:1245,y:778,t:1527030661216};\\\", \\\"{x:1245,y:783,t:1527030661232};\\\", \\\"{x:1245,y:791,t:1527030661249};\\\", \\\"{x:1245,y:801,t:1527030661266};\\\", \\\"{x:1245,y:813,t:1527030661282};\\\", \\\"{x:1247,y:830,t:1527030661299};\\\", \\\"{x:1252,y:854,t:1527030661316};\\\", \\\"{x:1257,y:880,t:1527030661332};\\\", \\\"{x:1259,y:895,t:1527030661350};\\\", \\\"{x:1262,y:907,t:1527030661366};\\\", \\\"{x:1263,y:910,t:1527030661382};\\\", \\\"{x:1263,y:918,t:1527030661399};\\\", \\\"{x:1264,y:925,t:1527030661416};\\\", \\\"{x:1264,y:934,t:1527030661432};\\\", \\\"{x:1264,y:941,t:1527030661449};\\\", \\\"{x:1261,y:952,t:1527030661466};\\\", \\\"{x:1260,y:955,t:1527030661482};\\\", \\\"{x:1258,y:958,t:1527030661500};\\\", \\\"{x:1257,y:960,t:1527030661516};\\\", \\\"{x:1250,y:966,t:1527030661533};\\\", \\\"{x:1245,y:966,t:1527030661549};\\\", \\\"{x:1239,y:966,t:1527030661567};\\\", \\\"{x:1236,y:966,t:1527030661582};\\\", \\\"{x:1229,y:959,t:1527030661599};\\\", \\\"{x:1218,y:944,t:1527030661616};\\\", \\\"{x:1201,y:914,t:1527030661632};\\\", \\\"{x:1191,y:895,t:1527030661649};\\\", \\\"{x:1181,y:868,t:1527030661667};\\\", \\\"{x:1174,y:848,t:1527030661683};\\\", \\\"{x:1173,y:830,t:1527030661700};\\\", \\\"{x:1173,y:820,t:1527030661716};\\\", \\\"{x:1173,y:807,t:1527030661734};\\\", \\\"{x:1173,y:802,t:1527030661749};\\\", \\\"{x:1173,y:801,t:1527030661766};\\\", \\\"{x:1173,y:800,t:1527030661783};\\\", \\\"{x:1173,y:801,t:1527030661896};\\\", \\\"{x:1173,y:806,t:1527030661905};\\\", \\\"{x:1173,y:813,t:1527030661917};\\\", \\\"{x:1177,y:836,t:1527030661933};\\\", \\\"{x:1182,y:866,t:1527030661949};\\\", \\\"{x:1185,y:902,t:1527030661966};\\\", \\\"{x:1188,y:926,t:1527030661984};\\\", \\\"{x:1190,y:940,t:1527030661999};\\\", \\\"{x:1193,y:948,t:1527030662016};\\\", \\\"{x:1193,y:949,t:1527030662064};\\\", \\\"{x:1193,y:950,t:1527030662072};\\\", \\\"{x:1193,y:951,t:1527030662083};\\\", \\\"{x:1193,y:953,t:1527030662100};\\\", \\\"{x:1192,y:955,t:1527030662116};\\\", \\\"{x:1191,y:955,t:1527030662133};\\\", \\\"{x:1190,y:956,t:1527030662345};\\\", \\\"{x:1189,y:956,t:1527030662352};\\\", \\\"{x:1189,y:958,t:1527030662367};\\\", \\\"{x:1188,y:962,t:1527030662384};\\\", \\\"{x:1186,y:965,t:1527030662400};\\\", \\\"{x:1185,y:966,t:1527030662416};\\\", \\\"{x:1185,y:967,t:1527030662433};\\\", \\\"{x:1185,y:968,t:1527030662450};\\\", \\\"{x:1185,y:969,t:1527030662576};\\\", \\\"{x:1187,y:969,t:1527030662657};\\\", \\\"{x:1189,y:969,t:1527030662667};\\\", \\\"{x:1194,y:969,t:1527030662683};\\\", \\\"{x:1198,y:969,t:1527030662700};\\\", \\\"{x:1202,y:967,t:1527030662717};\\\", \\\"{x:1204,y:967,t:1527030662733};\\\", \\\"{x:1205,y:967,t:1527030662750};\\\", \\\"{x:1207,y:967,t:1527030662767};\\\", \\\"{x:1209,y:967,t:1527030662783};\\\", \\\"{x:1220,y:967,t:1527030662800};\\\", \\\"{x:1226,y:967,t:1527030662817};\\\", \\\"{x:1229,y:967,t:1527030662833};\\\", \\\"{x:1230,y:967,t:1527030662850};\\\", \\\"{x:1232,y:967,t:1527030662896};\\\", \\\"{x:1233,y:967,t:1527030662920};\\\", \\\"{x:1235,y:967,t:1527030662944};\\\", \\\"{x:1236,y:967,t:1527030662952};\\\", \\\"{x:1239,y:967,t:1527030662967};\\\", \\\"{x:1245,y:967,t:1527030662983};\\\", \\\"{x:1248,y:968,t:1527030663001};\\\", \\\"{x:1249,y:968,t:1527030663018};\\\", \\\"{x:1250,y:968,t:1527030663035};\\\", \\\"{x:1251,y:968,t:1527030663050};\\\", \\\"{x:1253,y:969,t:1527030663067};\\\", \\\"{x:1254,y:969,t:1527030663088};\\\", \\\"{x:1254,y:970,t:1527030663129};\\\", \\\"{x:1253,y:970,t:1527030663232};\\\", \\\"{x:1254,y:970,t:1527030663344};\\\", \\\"{x:1256,y:970,t:1527030663352};\\\", \\\"{x:1258,y:970,t:1527030663367};\\\", \\\"{x:1263,y:969,t:1527030663385};\\\", \\\"{x:1265,y:968,t:1527030663401};\\\", \\\"{x:1266,y:968,t:1527030663417};\\\", \\\"{x:1270,y:968,t:1527030663434};\\\", \\\"{x:1278,y:968,t:1527030663450};\\\", \\\"{x:1287,y:968,t:1527030663467};\\\", \\\"{x:1297,y:968,t:1527030663484};\\\", \\\"{x:1305,y:968,t:1527030663501};\\\", \\\"{x:1306,y:968,t:1527030663517};\\\", \\\"{x:1307,y:968,t:1527030663534};\\\", \\\"{x:1308,y:968,t:1527030663551};\\\", \\\"{x:1309,y:968,t:1527030663567};\\\", \\\"{x:1312,y:969,t:1527030663584};\\\", \\\"{x:1313,y:969,t:1527030663616};\\\", \\\"{x:1314,y:969,t:1527030663624};\\\", \\\"{x:1315,y:969,t:1527030663634};\\\", \\\"{x:1316,y:969,t:1527030663651};\\\", \\\"{x:1318,y:969,t:1527030663667};\\\", \\\"{x:1318,y:970,t:1527030663684};\\\", \\\"{x:1319,y:971,t:1527030663704};\\\", \\\"{x:1320,y:971,t:1527030663720};\\\", \\\"{x:1321,y:971,t:1527030663736};\\\", \\\"{x:1322,y:971,t:1527030663753};\\\", \\\"{x:1324,y:972,t:1527030663769};\\\", \\\"{x:1328,y:972,t:1527030664057};\\\", \\\"{x:1332,y:972,t:1527030664068};\\\", \\\"{x:1340,y:972,t:1527030664085};\\\", \\\"{x:1356,y:972,t:1527030664101};\\\", \\\"{x:1371,y:972,t:1527030664118};\\\", \\\"{x:1380,y:972,t:1527030664134};\\\", \\\"{x:1383,y:973,t:1527030664151};\\\", \\\"{x:1385,y:974,t:1527030664168};\\\", \\\"{x:1387,y:974,t:1527030664184};\\\", \\\"{x:1391,y:974,t:1527030664202};\\\", \\\"{x:1393,y:974,t:1527030664218};\\\", \\\"{x:1394,y:974,t:1527030664241};\\\", \\\"{x:1393,y:974,t:1527030664441};\\\", \\\"{x:1390,y:974,t:1527030664451};\\\", \\\"{x:1382,y:973,t:1527030664468};\\\", \\\"{x:1348,y:959,t:1527030664486};\\\", \\\"{x:1274,y:929,t:1527030664501};\\\", \\\"{x:1148,y:878,t:1527030664518};\\\", \\\"{x:1004,y:816,t:1527030664535};\\\", \\\"{x:840,y:753,t:1527030664551};\\\", \\\"{x:567,y:645,t:1527030664568};\\\", \\\"{x:407,y:578,t:1527030664586};\\\", \\\"{x:273,y:530,t:1527030664601};\\\", \\\"{x:167,y:491,t:1527030664620};\\\", \\\"{x:101,y:467,t:1527030664637};\\\", \\\"{x:90,y:464,t:1527030664653};\\\", \\\"{x:89,y:464,t:1527030664669};\\\", \\\"{x:88,y:464,t:1527030664736};\\\", \\\"{x:87,y:464,t:1527030664753};\\\", \\\"{x:86,y:464,t:1527030664777};\\\", \\\"{x:86,y:465,t:1527030664792};\\\", \\\"{x:88,y:467,t:1527030664803};\\\", \\\"{x:108,y:472,t:1527030664821};\\\", \\\"{x:150,y:479,t:1527030664836};\\\", \\\"{x:236,y:492,t:1527030664854};\\\", \\\"{x:350,y:508,t:1527030664871};\\\", \\\"{x:472,y:525,t:1527030664887};\\\", \\\"{x:593,y:539,t:1527030664904};\\\", \\\"{x:731,y:558,t:1527030664921};\\\", \\\"{x:769,y:563,t:1527030664936};\\\", \\\"{x:786,y:564,t:1527030664953};\\\", \\\"{x:792,y:564,t:1527030664970};\\\", \\\"{x:795,y:564,t:1527030664986};\\\", \\\"{x:799,y:562,t:1527030665004};\\\", \\\"{x:801,y:560,t:1527030665020};\\\", \\\"{x:802,y:559,t:1527030665040};\\\", \\\"{x:803,y:559,t:1527030665057};\\\", \\\"{x:810,y:561,t:1527030665070};\\\", \\\"{x:848,y:582,t:1527030665087};\\\", \\\"{x:933,y:629,t:1527030665105};\\\", \\\"{x:1076,y:704,t:1527030665121};\\\", \\\"{x:1156,y:736,t:1527030665137};\\\", \\\"{x:1225,y:756,t:1527030665153};\\\", \\\"{x:1276,y:772,t:1527030665170};\\\", \\\"{x:1298,y:778,t:1527030665187};\\\", \\\"{x:1300,y:779,t:1527030665203};\\\", \\\"{x:1301,y:780,t:1527030665220};\\\", \\\"{x:1301,y:781,t:1527030665240};\\\", \\\"{x:1300,y:783,t:1527030665256};\\\", \\\"{x:1299,y:784,t:1527030665272};\\\", \\\"{x:1299,y:785,t:1527030665417};\\\", \\\"{x:1298,y:785,t:1527030665424};\\\", \\\"{x:1296,y:785,t:1527030665437};\\\", \\\"{x:1290,y:781,t:1527030665453};\\\", \\\"{x:1286,y:780,t:1527030665470};\\\", \\\"{x:1281,y:778,t:1527030665487};\\\", \\\"{x:1275,y:778,t:1527030665503};\\\", \\\"{x:1258,y:776,t:1527030665520};\\\", \\\"{x:1248,y:774,t:1527030665537};\\\", \\\"{x:1237,y:774,t:1527030665554};\\\", \\\"{x:1227,y:774,t:1527030665570};\\\", \\\"{x:1216,y:776,t:1527030665587};\\\", \\\"{x:1206,y:780,t:1527030665604};\\\", \\\"{x:1200,y:784,t:1527030665620};\\\", \\\"{x:1195,y:786,t:1527030665637};\\\", \\\"{x:1192,y:788,t:1527030665654};\\\", \\\"{x:1190,y:788,t:1527030665671};\\\", \\\"{x:1189,y:789,t:1527030665687};\\\", \\\"{x:1188,y:789,t:1527030665769};\\\", \\\"{x:1188,y:788,t:1527030665784};\\\", \\\"{x:1189,y:785,t:1527030665792};\\\", \\\"{x:1191,y:784,t:1527030665804};\\\", \\\"{x:1194,y:780,t:1527030665820};\\\", \\\"{x:1196,y:779,t:1527030665837};\\\", \\\"{x:1200,y:776,t:1527030665854};\\\", \\\"{x:1204,y:774,t:1527030665870};\\\", \\\"{x:1207,y:772,t:1527030665887};\\\", \\\"{x:1209,y:772,t:1527030665904};\\\", \\\"{x:1210,y:772,t:1527030666033};\\\", \\\"{x:1213,y:772,t:1527030666049};\\\", \\\"{x:1216,y:772,t:1527030666056};\\\", \\\"{x:1223,y:772,t:1527030666070};\\\", \\\"{x:1246,y:772,t:1527030666088};\\\", \\\"{x:1292,y:772,t:1527030666104};\\\", \\\"{x:1321,y:772,t:1527030666120};\\\", \\\"{x:1340,y:768,t:1527030666137};\\\", \\\"{x:1343,y:768,t:1527030666154};\\\", \\\"{x:1344,y:768,t:1527030666170};\\\", \\\"{x:1343,y:768,t:1527030666281};\\\", \\\"{x:1341,y:768,t:1527030666288};\\\", \\\"{x:1337,y:770,t:1527030666304};\\\", \\\"{x:1329,y:774,t:1527030666321};\\\", \\\"{x:1314,y:780,t:1527030666338};\\\", \\\"{x:1295,y:785,t:1527030666354};\\\", \\\"{x:1272,y:788,t:1527030666370};\\\", \\\"{x:1248,y:789,t:1527030666388};\\\", \\\"{x:1225,y:790,t:1527030666404};\\\", \\\"{x:1207,y:790,t:1527030666421};\\\", \\\"{x:1189,y:790,t:1527030666437};\\\", \\\"{x:1170,y:788,t:1527030666454};\\\", \\\"{x:1154,y:786,t:1527030666471};\\\", \\\"{x:1133,y:781,t:1527030666487};\\\", \\\"{x:1098,y:769,t:1527030666504};\\\", \\\"{x:1072,y:760,t:1527030666520};\\\", \\\"{x:1036,y:751,t:1527030666538};\\\", \\\"{x:983,y:736,t:1527030666554};\\\", \\\"{x:907,y:708,t:1527030666571};\\\", \\\"{x:819,y:673,t:1527030666587};\\\", \\\"{x:718,y:637,t:1527030666604};\\\", \\\"{x:619,y:596,t:1527030666622};\\\", \\\"{x:538,y:568,t:1527030666638};\\\", \\\"{x:477,y:542,t:1527030666655};\\\", \\\"{x:438,y:524,t:1527030666672};\\\", \\\"{x:413,y:518,t:1527030666687};\\\", \\\"{x:388,y:513,t:1527030666705};\\\", \\\"{x:369,y:512,t:1527030666722};\\\", \\\"{x:343,y:512,t:1527030666738};\\\", \\\"{x:316,y:512,t:1527030666755};\\\", \\\"{x:289,y:512,t:1527030666771};\\\", \\\"{x:268,y:512,t:1527030666789};\\\", \\\"{x:252,y:512,t:1527030666805};\\\", \\\"{x:249,y:512,t:1527030666821};\\\", \\\"{x:248,y:512,t:1527030666838};\\\", \\\"{x:248,y:513,t:1527030666854};\\\", \\\"{x:248,y:516,t:1527030666872};\\\", \\\"{x:253,y:525,t:1527030666889};\\\", \\\"{x:256,y:528,t:1527030666905};\\\", \\\"{x:256,y:529,t:1527030666921};\\\", \\\"{x:257,y:529,t:1527030666944};\\\", \\\"{x:258,y:530,t:1527030666955};\\\", \\\"{x:257,y:532,t:1527030666984};\\\", \\\"{x:256,y:533,t:1527030667000};\\\", \\\"{x:255,y:534,t:1527030667008};\\\", \\\"{x:254,y:534,t:1527030667021};\\\", \\\"{x:252,y:536,t:1527030667038};\\\", \\\"{x:246,y:538,t:1527030667056};\\\", \\\"{x:240,y:538,t:1527030667072};\\\", \\\"{x:231,y:538,t:1527030667088};\\\", \\\"{x:224,y:538,t:1527030667105};\\\", \\\"{x:219,y:538,t:1527030667121};\\\", \\\"{x:213,y:536,t:1527030667138};\\\", \\\"{x:208,y:532,t:1527030667156};\\\", \\\"{x:204,y:529,t:1527030667172};\\\", \\\"{x:201,y:527,t:1527030667188};\\\", \\\"{x:198,y:525,t:1527030667205};\\\", \\\"{x:194,y:522,t:1527030667222};\\\", \\\"{x:192,y:520,t:1527030667238};\\\", \\\"{x:189,y:517,t:1527030667256};\\\", \\\"{x:185,y:512,t:1527030667272};\\\", \\\"{x:182,y:509,t:1527030667288};\\\", \\\"{x:179,y:506,t:1527030667305};\\\", \\\"{x:177,y:505,t:1527030667322};\\\", \\\"{x:176,y:504,t:1527030667384};\\\", \\\"{x:175,y:504,t:1527030667416};\\\", \\\"{x:177,y:506,t:1527030667737};\\\", \\\"{x:188,y:512,t:1527030667744};\\\", \\\"{x:201,y:519,t:1527030667756};\\\", \\\"{x:246,y:554,t:1527030667773};\\\", \\\"{x:312,y:596,t:1527030667789};\\\", \\\"{x:389,y:642,t:1527030667806};\\\", \\\"{x:455,y:684,t:1527030667822};\\\", \\\"{x:504,y:721,t:1527030667840};\\\", \\\"{x:539,y:749,t:1527030667855};\\\", \\\"{x:554,y:762,t:1527030667872};\\\", \\\"{x:555,y:763,t:1527030667890};\\\", \\\"{x:555,y:764,t:1527030667906};\\\", \\\"{x:555,y:765,t:1527030667923};\\\", \\\"{x:554,y:765,t:1527030668073};\\\", \\\"{x:553,y:765,t:1527030668089};\\\", \\\"{x:552,y:764,t:1527030668105};\\\", \\\"{x:551,y:761,t:1527030668122};\\\", \\\"{x:550,y:757,t:1527030668140};\\\", \\\"{x:549,y:755,t:1527030668156};\\\", \\\"{x:549,y:753,t:1527030668172};\\\", \\\"{x:548,y:751,t:1527030668190};\\\", \\\"{x:548,y:750,t:1527030668216};\\\", \\\"{x:548,y:749,t:1527030668672};\\\", \\\"{x:548,y:748,t:1527030668689};\\\", \\\"{x:548,y:747,t:1527030668706};\\\", \\\"{x:548,y:745,t:1527030668723};\\\", \\\"{x:548,y:744,t:1527030668739};\\\", \\\"{x:548,y:743,t:1527030668768};\\\", \\\"{x:548,y:742,t:1527030668784};\\\", \\\"{x:548,y:741,t:1527030668800};\\\", \\\"{x:548,y:740,t:1527030668848};\\\", \\\"{x:548,y:739,t:1527030669272};\\\", \\\"{x:546,y:739,t:1527030670944};\\\", \\\"{x:545,y:739,t:1527030670960};\\\", \\\"{x:544,y:739,t:1527030670976};\\\" ] }, { \\\"rt\\\": 58456, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 690339, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -12 PM-E -E -11 AM-12 PM-12 PM-03 PM-02 PM-03 PM-04 PM-04 PM-B -F -12 PM-03 PM-03 PM-02 PM-M -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:738,t:1527030677336};\\\", \\\"{x:544,y:735,t:1527030677361};\\\", \\\"{x:545,y:733,t:1527030677368};\\\", \\\"{x:546,y:733,t:1527030677380};\\\", \\\"{x:547,y:732,t:1527030677396};\\\", \\\"{x:548,y:730,t:1527030677413};\\\", \\\"{x:549,y:730,t:1527030677430};\\\", \\\"{x:550,y:729,t:1527030677447};\\\", \\\"{x:553,y:728,t:1527030677462};\\\", \\\"{x:554,y:728,t:1527030677480};\\\", \\\"{x:555,y:728,t:1527030677497};\\\", \\\"{x:556,y:728,t:1527030677528};\\\", \\\"{x:557,y:728,t:1527030677545};\\\", \\\"{x:558,y:728,t:1527030677576};\\\", \\\"{x:559,y:728,t:1527030677592};\\\", \\\"{x:560,y:728,t:1527030677608};\\\", \\\"{x:562,y:727,t:1527030677616};\\\", \\\"{x:563,y:726,t:1527030677648};\\\", \\\"{x:564,y:726,t:1527030677665};\\\", \\\"{x:565,y:725,t:1527030677681};\\\", \\\"{x:568,y:724,t:1527030677696};\\\", \\\"{x:570,y:724,t:1527030677736};\\\", \\\"{x:570,y:725,t:1527030677865};\\\", \\\"{x:570,y:727,t:1527030677880};\\\", \\\"{x:567,y:735,t:1527030677897};\\\", \\\"{x:567,y:736,t:1527030677914};\\\", \\\"{x:568,y:736,t:1527030678480};\\\", \\\"{x:610,y:744,t:1527030678497};\\\", \\\"{x:671,y:744,t:1527030678514};\\\", \\\"{x:710,y:744,t:1527030678531};\\\", \\\"{x:740,y:744,t:1527030678547};\\\", \\\"{x:771,y:744,t:1527030678564};\\\", \\\"{x:798,y:740,t:1527030678581};\\\", \\\"{x:821,y:732,t:1527030678597};\\\", \\\"{x:850,y:722,t:1527030678614};\\\", \\\"{x:879,y:715,t:1527030678631};\\\", \\\"{x:918,y:706,t:1527030678647};\\\", \\\"{x:951,y:702,t:1527030678664};\\\", \\\"{x:998,y:693,t:1527030678681};\\\", \\\"{x:1027,y:691,t:1527030678697};\\\", \\\"{x:1064,y:686,t:1527030678714};\\\", \\\"{x:1088,y:683,t:1527030678731};\\\", \\\"{x:1106,y:681,t:1527030678748};\\\", \\\"{x:1120,y:679,t:1527030678764};\\\", \\\"{x:1134,y:674,t:1527030678781};\\\", \\\"{x:1151,y:666,t:1527030678798};\\\", \\\"{x:1166,y:657,t:1527030678814};\\\", \\\"{x:1175,y:648,t:1527030678831};\\\", \\\"{x:1183,y:642,t:1527030678848};\\\", \\\"{x:1200,y:639,t:1527030678864};\\\", \\\"{x:1217,y:635,t:1527030678881};\\\", \\\"{x:1239,y:630,t:1527030678898};\\\", \\\"{x:1254,y:624,t:1527030678914};\\\", \\\"{x:1263,y:619,t:1527030678931};\\\", \\\"{x:1269,y:617,t:1527030678948};\\\", \\\"{x:1271,y:616,t:1527030678964};\\\", \\\"{x:1275,y:614,t:1527030678981};\\\", \\\"{x:1276,y:614,t:1527030678998};\\\", \\\"{x:1279,y:612,t:1527030679014};\\\", \\\"{x:1282,y:612,t:1527030679031};\\\", \\\"{x:1287,y:612,t:1527030679048};\\\", \\\"{x:1319,y:618,t:1527030679064};\\\", \\\"{x:1358,y:634,t:1527030679081};\\\", \\\"{x:1385,y:644,t:1527030679099};\\\", \\\"{x:1407,y:650,t:1527030679114};\\\", \\\"{x:1431,y:651,t:1527030679131};\\\", \\\"{x:1456,y:651,t:1527030679148};\\\", \\\"{x:1478,y:648,t:1527030679164};\\\", \\\"{x:1497,y:643,t:1527030679181};\\\", \\\"{x:1518,y:639,t:1527030679198};\\\", \\\"{x:1541,y:639,t:1527030679214};\\\", \\\"{x:1561,y:639,t:1527030679231};\\\", \\\"{x:1571,y:639,t:1527030679248};\\\", \\\"{x:1577,y:639,t:1527030679264};\\\", \\\"{x:1584,y:646,t:1527030679281};\\\", \\\"{x:1595,y:674,t:1527030679298};\\\", \\\"{x:1607,y:709,t:1527030679315};\\\", \\\"{x:1613,y:731,t:1527030679331};\\\", \\\"{x:1619,y:750,t:1527030679348};\\\", \\\"{x:1631,y:774,t:1527030679365};\\\", \\\"{x:1642,y:798,t:1527030679382};\\\", \\\"{x:1652,y:813,t:1527030679398};\\\", \\\"{x:1660,y:825,t:1527030679415};\\\", \\\"{x:1664,y:832,t:1527030679431};\\\", \\\"{x:1666,y:834,t:1527030679448};\\\", \\\"{x:1667,y:834,t:1527030679464};\\\", \\\"{x:1667,y:833,t:1527030679912};\\\", \\\"{x:1667,y:832,t:1527030679921};\\\", \\\"{x:1667,y:831,t:1527030679944};\\\", \\\"{x:1666,y:830,t:1527030679961};\\\", \\\"{x:1665,y:830,t:1527030680041};\\\", \\\"{x:1663,y:830,t:1527030680049};\\\", \\\"{x:1658,y:830,t:1527030680065};\\\", \\\"{x:1654,y:830,t:1527030680082};\\\", \\\"{x:1652,y:830,t:1527030680098};\\\", \\\"{x:1651,y:830,t:1527030680115};\\\", \\\"{x:1649,y:832,t:1527030680133};\\\", \\\"{x:1645,y:837,t:1527030680148};\\\", \\\"{x:1640,y:842,t:1527030680165};\\\", \\\"{x:1638,y:844,t:1527030680182};\\\", \\\"{x:1636,y:846,t:1527030680198};\\\", \\\"{x:1635,y:847,t:1527030680215};\\\", \\\"{x:1634,y:847,t:1527030680232};\\\", \\\"{x:1631,y:847,t:1527030680249};\\\", \\\"{x:1626,y:847,t:1527030680265};\\\", \\\"{x:1614,y:843,t:1527030680282};\\\", \\\"{x:1603,y:838,t:1527030680298};\\\", \\\"{x:1591,y:833,t:1527030680315};\\\", \\\"{x:1576,y:830,t:1527030680332};\\\", \\\"{x:1555,y:825,t:1527030680348};\\\", \\\"{x:1538,y:820,t:1527030680365};\\\", \\\"{x:1526,y:819,t:1527030680382};\\\", \\\"{x:1515,y:819,t:1527030680398};\\\", \\\"{x:1509,y:821,t:1527030680415};\\\", \\\"{x:1508,y:821,t:1527030680432};\\\", \\\"{x:1507,y:822,t:1527030680449};\\\", \\\"{x:1506,y:823,t:1527030680465};\\\", \\\"{x:1505,y:824,t:1527030680482};\\\", \\\"{x:1502,y:826,t:1527030680499};\\\", \\\"{x:1500,y:828,t:1527030680515};\\\", \\\"{x:1497,y:829,t:1527030680532};\\\", \\\"{x:1494,y:831,t:1527030680549};\\\", \\\"{x:1493,y:832,t:1527030680576};\\\", \\\"{x:1491,y:832,t:1527030680672};\\\", \\\"{x:1488,y:834,t:1527030680682};\\\", \\\"{x:1480,y:836,t:1527030680699};\\\", \\\"{x:1473,y:839,t:1527030680715};\\\", \\\"{x:1466,y:841,t:1527030680732};\\\", \\\"{x:1461,y:844,t:1527030680749};\\\", \\\"{x:1458,y:848,t:1527030680765};\\\", \\\"{x:1454,y:852,t:1527030680782};\\\", \\\"{x:1452,y:855,t:1527030680799};\\\", \\\"{x:1451,y:857,t:1527030680814};\\\", \\\"{x:1450,y:858,t:1527030680856};\\\", \\\"{x:1449,y:858,t:1527030680880};\\\", \\\"{x:1448,y:858,t:1527030680888};\\\", \\\"{x:1447,y:858,t:1527030680899};\\\", \\\"{x:1446,y:858,t:1527030680920};\\\", \\\"{x:1445,y:859,t:1527030680936};\\\", \\\"{x:1445,y:858,t:1527030681129};\\\", \\\"{x:1446,y:854,t:1527030681136};\\\", \\\"{x:1444,y:847,t:1527030681149};\\\", \\\"{x:1438,y:827,t:1527030681166};\\\", \\\"{x:1427,y:800,t:1527030681182};\\\", \\\"{x:1418,y:774,t:1527030681199};\\\", \\\"{x:1407,y:746,t:1527030681216};\\\", \\\"{x:1402,y:736,t:1527030681232};\\\", \\\"{x:1396,y:727,t:1527030681249};\\\", \\\"{x:1390,y:721,t:1527030681266};\\\", \\\"{x:1384,y:719,t:1527030681282};\\\", \\\"{x:1381,y:718,t:1527030681300};\\\", \\\"{x:1379,y:718,t:1527030681316};\\\", \\\"{x:1376,y:718,t:1527030681332};\\\", \\\"{x:1373,y:716,t:1527030681512};\\\", \\\"{x:1371,y:712,t:1527030681520};\\\", \\\"{x:1368,y:707,t:1527030681533};\\\", \\\"{x:1367,y:705,t:1527030681549};\\\", \\\"{x:1366,y:704,t:1527030681567};\\\", \\\"{x:1366,y:702,t:1527030681680};\\\", \\\"{x:1365,y:702,t:1527030681736};\\\", \\\"{x:1363,y:700,t:1527030681760};\\\", \\\"{x:1362,y:700,t:1527030681776};\\\", \\\"{x:1361,y:699,t:1527030681792};\\\", \\\"{x:1360,y:699,t:1527030681800};\\\", \\\"{x:1359,y:699,t:1527030681816};\\\", \\\"{x:1358,y:699,t:1527030681833};\\\", \\\"{x:1357,y:697,t:1527030681849};\\\", \\\"{x:1356,y:697,t:1527030681866};\\\", \\\"{x:1355,y:697,t:1527030681905};\\\", \\\"{x:1353,y:696,t:1527030682209};\\\", \\\"{x:1351,y:696,t:1527030686633};\\\", \\\"{x:1351,y:697,t:1527030686648};\\\", \\\"{x:1350,y:699,t:1527030686672};\\\", \\\"{x:1350,y:700,t:1527030686686};\\\", \\\"{x:1348,y:702,t:1527030686703};\\\", \\\"{x:1348,y:703,t:1527030686720};\\\", \\\"{x:1345,y:707,t:1527030686736};\\\", \\\"{x:1345,y:712,t:1527030686752};\\\", \\\"{x:1344,y:717,t:1527030686769};\\\", \\\"{x:1342,y:722,t:1527030686785};\\\", \\\"{x:1341,y:731,t:1527030686802};\\\", \\\"{x:1341,y:738,t:1527030686819};\\\", \\\"{x:1341,y:745,t:1527030686836};\\\", \\\"{x:1341,y:748,t:1527030686852};\\\", \\\"{x:1341,y:749,t:1527030686869};\\\", \\\"{x:1341,y:751,t:1527030686886};\\\", \\\"{x:1341,y:754,t:1527030686902};\\\", \\\"{x:1343,y:764,t:1527030686920};\\\", \\\"{x:1347,y:778,t:1527030686937};\\\", \\\"{x:1349,y:784,t:1527030686952};\\\", \\\"{x:1349,y:787,t:1527030686970};\\\", \\\"{x:1351,y:797,t:1527030686986};\\\", \\\"{x:1351,y:809,t:1527030687002};\\\", \\\"{x:1351,y:825,t:1527030687019};\\\", \\\"{x:1351,y:838,t:1527030687037};\\\", \\\"{x:1347,y:852,t:1527030687053};\\\", \\\"{x:1344,y:865,t:1527030687070};\\\", \\\"{x:1340,y:880,t:1527030687087};\\\", \\\"{x:1339,y:886,t:1527030687102};\\\", \\\"{x:1339,y:891,t:1527030687119};\\\", \\\"{x:1337,y:899,t:1527030687136};\\\", \\\"{x:1337,y:904,t:1527030687152};\\\", \\\"{x:1337,y:912,t:1527030687170};\\\", \\\"{x:1337,y:921,t:1527030687186};\\\", \\\"{x:1338,y:929,t:1527030687203};\\\", \\\"{x:1338,y:936,t:1527030687219};\\\", \\\"{x:1338,y:939,t:1527030687236};\\\", \\\"{x:1338,y:943,t:1527030687252};\\\", \\\"{x:1338,y:946,t:1527030687270};\\\", \\\"{x:1339,y:949,t:1527030687286};\\\", \\\"{x:1339,y:950,t:1527030687302};\\\", \\\"{x:1340,y:953,t:1527030687320};\\\", \\\"{x:1341,y:962,t:1527030687336};\\\", \\\"{x:1341,y:968,t:1527030687352};\\\", \\\"{x:1342,y:973,t:1527030687369};\\\", \\\"{x:1343,y:974,t:1527030687386};\\\", \\\"{x:1343,y:975,t:1527030687404};\\\", \\\"{x:1343,y:974,t:1527030687632};\\\", \\\"{x:1343,y:973,t:1527030687640};\\\", \\\"{x:1343,y:972,t:1527030687653};\\\", \\\"{x:1343,y:969,t:1527030687669};\\\", \\\"{x:1343,y:960,t:1527030687686};\\\", \\\"{x:1343,y:945,t:1527030687703};\\\", \\\"{x:1343,y:914,t:1527030687719};\\\", \\\"{x:1325,y:827,t:1527030687736};\\\", \\\"{x:1306,y:768,t:1527030687753};\\\", \\\"{x:1303,y:743,t:1527030687769};\\\", \\\"{x:1299,y:720,t:1527030687787};\\\", \\\"{x:1298,y:689,t:1527030687803};\\\", \\\"{x:1298,y:659,t:1527030687819};\\\", \\\"{x:1297,y:627,t:1527030687837};\\\", \\\"{x:1295,y:608,t:1527030687854};\\\", \\\"{x:1293,y:602,t:1527030687869};\\\", \\\"{x:1293,y:599,t:1527030687887};\\\", \\\"{x:1293,y:598,t:1527030687945};\\\", \\\"{x:1293,y:596,t:1527030687960};\\\", \\\"{x:1293,y:595,t:1527030688024};\\\", \\\"{x:1292,y:594,t:1527030688040};\\\", \\\"{x:1292,y:593,t:1527030688054};\\\", \\\"{x:1291,y:591,t:1527030688070};\\\", \\\"{x:1290,y:588,t:1527030688087};\\\", \\\"{x:1289,y:584,t:1527030688103};\\\", \\\"{x:1289,y:581,t:1527030688120};\\\", \\\"{x:1288,y:580,t:1527030688136};\\\", \\\"{x:1287,y:579,t:1527030688153};\\\", \\\"{x:1286,y:579,t:1527030688801};\\\", \\\"{x:1286,y:580,t:1527030688815};\\\", \\\"{x:1285,y:580,t:1527030688872};\\\", \\\"{x:1285,y:579,t:1527030689856};\\\", \\\"{x:1285,y:578,t:1527030690216};\\\", \\\"{x:1285,y:577,t:1527030690232};\\\", \\\"{x:1285,y:576,t:1527030690257};\\\", \\\"{x:1285,y:575,t:1527030690296};\\\", \\\"{x:1285,y:574,t:1527030690305};\\\", \\\"{x:1285,y:572,t:1527030690322};\\\", \\\"{x:1285,y:569,t:1527030690338};\\\", \\\"{x:1285,y:566,t:1527030690355};\\\", \\\"{x:1284,y:564,t:1527030690372};\\\", \\\"{x:1284,y:563,t:1527030690387};\\\", \\\"{x:1284,y:562,t:1527030690408};\\\", \\\"{x:1284,y:561,t:1527030690431};\\\", \\\"{x:1283,y:560,t:1527030690448};\\\", \\\"{x:1283,y:559,t:1527030690625};\\\", \\\"{x:1282,y:559,t:1527030690656};\\\", \\\"{x:1281,y:559,t:1527030690736};\\\", \\\"{x:1281,y:563,t:1527030693624};\\\", \\\"{x:1281,y:569,t:1527030693640};\\\", \\\"{x:1281,y:580,t:1527030693657};\\\", \\\"{x:1282,y:585,t:1527030693674};\\\", \\\"{x:1282,y:592,t:1527030693690};\\\", \\\"{x:1282,y:597,t:1527030693706};\\\", \\\"{x:1282,y:600,t:1527030693723};\\\", \\\"{x:1282,y:604,t:1527030693739};\\\", \\\"{x:1282,y:606,t:1527030693756};\\\", \\\"{x:1282,y:609,t:1527030693774};\\\", \\\"{x:1282,y:610,t:1527030693790};\\\", \\\"{x:1282,y:613,t:1527030693807};\\\", \\\"{x:1282,y:616,t:1527030693824};\\\", \\\"{x:1282,y:625,t:1527030693840};\\\", \\\"{x:1282,y:635,t:1527030693857};\\\", \\\"{x:1283,y:648,t:1527030693874};\\\", \\\"{x:1283,y:656,t:1527030693890};\\\", \\\"{x:1283,y:663,t:1527030693906};\\\", \\\"{x:1283,y:668,t:1527030693924};\\\", \\\"{x:1283,y:671,t:1527030693941};\\\", \\\"{x:1283,y:675,t:1527030693956};\\\", \\\"{x:1283,y:677,t:1527030693974};\\\", \\\"{x:1283,y:678,t:1527030693990};\\\", \\\"{x:1283,y:679,t:1527030694006};\\\", \\\"{x:1283,y:680,t:1527030694024};\\\", \\\"{x:1283,y:681,t:1527030694041};\\\", \\\"{x:1284,y:683,t:1527030694056};\\\", \\\"{x:1284,y:684,t:1527030694074};\\\", \\\"{x:1284,y:687,t:1527030694091};\\\", \\\"{x:1284,y:688,t:1527030694106};\\\", \\\"{x:1284,y:691,t:1527030694124};\\\", \\\"{x:1283,y:695,t:1527030694140};\\\", \\\"{x:1283,y:698,t:1527030694157};\\\", \\\"{x:1283,y:692,t:1527030694225};\\\", \\\"{x:1283,y:656,t:1527030694240};\\\", \\\"{x:1295,y:604,t:1527030694256};\\\", \\\"{x:1304,y:575,t:1527030694273};\\\", \\\"{x:1309,y:565,t:1527030694290};\\\", \\\"{x:1311,y:562,t:1527030694307};\\\", \\\"{x:1311,y:560,t:1527030694324};\\\", \\\"{x:1311,y:559,t:1527030694340};\\\", \\\"{x:1311,y:557,t:1527030694417};\\\", \\\"{x:1310,y:555,t:1527030694431};\\\", \\\"{x:1310,y:554,t:1527030694440};\\\", \\\"{x:1309,y:553,t:1527030694488};\\\", \\\"{x:1308,y:553,t:1527030694496};\\\", \\\"{x:1307,y:553,t:1527030694508};\\\", \\\"{x:1302,y:555,t:1527030694524};\\\", \\\"{x:1295,y:560,t:1527030694541};\\\", \\\"{x:1289,y:564,t:1527030694558};\\\", \\\"{x:1285,y:567,t:1527030694574};\\\", \\\"{x:1284,y:568,t:1527030694590};\\\", \\\"{x:1283,y:569,t:1527030694608};\\\", \\\"{x:1282,y:572,t:1527030694792};\\\", \\\"{x:1280,y:577,t:1527030694808};\\\", \\\"{x:1277,y:592,t:1527030694824};\\\", \\\"{x:1270,y:628,t:1527030694841};\\\", \\\"{x:1264,y:658,t:1527030694857};\\\", \\\"{x:1261,y:684,t:1527030694874};\\\", \\\"{x:1258,y:707,t:1527030694891};\\\", \\\"{x:1258,y:726,t:1527030694908};\\\", \\\"{x:1258,y:745,t:1527030694923};\\\", \\\"{x:1258,y:760,t:1527030694941};\\\", \\\"{x:1258,y:770,t:1527030694958};\\\", \\\"{x:1258,y:779,t:1527030694975};\\\", \\\"{x:1258,y:794,t:1527030694991};\\\", \\\"{x:1258,y:808,t:1527030695008};\\\", \\\"{x:1258,y:825,t:1527030695024};\\\", \\\"{x:1258,y:830,t:1527030695040};\\\", \\\"{x:1258,y:834,t:1527030695058};\\\", \\\"{x:1259,y:838,t:1527030695075};\\\", \\\"{x:1263,y:845,t:1527030695091};\\\", \\\"{x:1266,y:851,t:1527030695108};\\\", \\\"{x:1272,y:861,t:1527030695124};\\\", \\\"{x:1276,y:869,t:1527030695141};\\\", \\\"{x:1279,y:875,t:1527030695158};\\\", \\\"{x:1280,y:881,t:1527030695175};\\\", \\\"{x:1283,y:891,t:1527030695191};\\\", \\\"{x:1284,y:900,t:1527030695208};\\\", \\\"{x:1286,y:922,t:1527030695224};\\\", \\\"{x:1289,y:929,t:1527030695241};\\\", \\\"{x:1290,y:941,t:1527030695258};\\\", \\\"{x:1293,y:954,t:1527030695275};\\\", \\\"{x:1293,y:959,t:1527030695291};\\\", \\\"{x:1293,y:962,t:1527030695308};\\\", \\\"{x:1293,y:963,t:1527030695325};\\\", \\\"{x:1293,y:964,t:1527030695341};\\\", \\\"{x:1293,y:965,t:1527030695357};\\\", \\\"{x:1293,y:966,t:1527030695375};\\\", \\\"{x:1293,y:967,t:1527030695391};\\\", \\\"{x:1293,y:968,t:1527030695408};\\\", \\\"{x:1293,y:969,t:1527030695688};\\\", \\\"{x:1292,y:966,t:1527030695729};\\\", \\\"{x:1290,y:961,t:1527030695741};\\\", \\\"{x:1285,y:952,t:1527030695758};\\\", \\\"{x:1278,y:936,t:1527030695775};\\\", \\\"{x:1269,y:916,t:1527030695792};\\\", \\\"{x:1260,y:891,t:1527030695808};\\\", \\\"{x:1254,y:846,t:1527030695825};\\\", \\\"{x:1251,y:800,t:1527030695841};\\\", \\\"{x:1251,y:741,t:1527030695857};\\\", \\\"{x:1253,y:698,t:1527030695875};\\\", \\\"{x:1264,y:656,t:1527030695892};\\\", \\\"{x:1269,y:641,t:1527030695907};\\\", \\\"{x:1269,y:639,t:1527030695925};\\\", \\\"{x:1270,y:637,t:1527030695942};\\\", \\\"{x:1270,y:636,t:1527030695958};\\\", \\\"{x:1270,y:635,t:1527030695975};\\\", \\\"{x:1270,y:634,t:1527030696016};\\\", \\\"{x:1270,y:633,t:1527030696025};\\\", \\\"{x:1272,y:624,t:1527030696042};\\\", \\\"{x:1274,y:612,t:1527030696058};\\\", \\\"{x:1275,y:602,t:1527030696075};\\\", \\\"{x:1276,y:594,t:1527030696092};\\\", \\\"{x:1276,y:590,t:1527030696108};\\\", \\\"{x:1278,y:587,t:1527030696124};\\\", \\\"{x:1278,y:586,t:1527030696142};\\\", \\\"{x:1278,y:584,t:1527030696160};\\\", \\\"{x:1279,y:583,t:1527030696174};\\\", \\\"{x:1279,y:580,t:1527030696192};\\\", \\\"{x:1280,y:579,t:1527030696297};\\\", \\\"{x:1280,y:581,t:1527030696312};\\\", \\\"{x:1281,y:586,t:1527030696325};\\\", \\\"{x:1286,y:602,t:1527030696341};\\\", \\\"{x:1289,y:625,t:1527030696359};\\\", \\\"{x:1293,y:648,t:1527030696374};\\\", \\\"{x:1295,y:667,t:1527030696392};\\\", \\\"{x:1296,y:687,t:1527030696408};\\\", \\\"{x:1296,y:695,t:1527030696425};\\\", \\\"{x:1296,y:700,t:1527030696442};\\\", \\\"{x:1296,y:706,t:1527030696459};\\\", \\\"{x:1296,y:714,t:1527030696475};\\\", \\\"{x:1296,y:724,t:1527030696492};\\\", \\\"{x:1296,y:730,t:1527030696509};\\\", \\\"{x:1294,y:737,t:1527030696525};\\\", \\\"{x:1293,y:744,t:1527030696542};\\\", \\\"{x:1292,y:748,t:1527030696559};\\\", \\\"{x:1292,y:751,t:1527030696575};\\\", \\\"{x:1290,y:759,t:1527030696592};\\\", \\\"{x:1289,y:768,t:1527030696609};\\\", \\\"{x:1288,y:770,t:1527030696625};\\\", \\\"{x:1286,y:773,t:1527030696641};\\\", \\\"{x:1286,y:774,t:1527030696658};\\\", \\\"{x:1285,y:775,t:1527030696680};\\\", \\\"{x:1284,y:777,t:1527030696692};\\\", \\\"{x:1282,y:779,t:1527030696708};\\\", \\\"{x:1279,y:783,t:1527030696724};\\\", \\\"{x:1274,y:791,t:1527030696742};\\\", \\\"{x:1270,y:798,t:1527030696758};\\\", \\\"{x:1268,y:802,t:1527030696776};\\\", \\\"{x:1267,y:806,t:1527030696792};\\\", \\\"{x:1267,y:808,t:1527030696809};\\\", \\\"{x:1267,y:812,t:1527030696826};\\\", \\\"{x:1267,y:819,t:1527030696842};\\\", \\\"{x:1265,y:829,t:1527030696859};\\\", \\\"{x:1264,y:839,t:1527030696876};\\\", \\\"{x:1264,y:852,t:1527030696892};\\\", \\\"{x:1264,y:861,t:1527030696909};\\\", \\\"{x:1264,y:870,t:1527030696926};\\\", \\\"{x:1264,y:878,t:1527030696942};\\\", \\\"{x:1264,y:888,t:1527030696959};\\\", \\\"{x:1264,y:894,t:1527030696976};\\\", \\\"{x:1264,y:896,t:1527030696993};\\\", \\\"{x:1264,y:900,t:1527030697009};\\\", \\\"{x:1264,y:905,t:1527030697026};\\\", \\\"{x:1264,y:911,t:1527030697042};\\\", \\\"{x:1264,y:917,t:1527030697059};\\\", \\\"{x:1264,y:924,t:1527030697075};\\\", \\\"{x:1264,y:927,t:1527030697092};\\\", \\\"{x:1264,y:929,t:1527030697109};\\\", \\\"{x:1265,y:931,t:1527030697126};\\\", \\\"{x:1266,y:933,t:1527030697142};\\\", \\\"{x:1266,y:935,t:1527030697158};\\\", \\\"{x:1267,y:938,t:1527030697176};\\\", \\\"{x:1267,y:940,t:1527030697192};\\\", \\\"{x:1267,y:941,t:1527030697216};\\\", \\\"{x:1268,y:941,t:1527030697226};\\\", \\\"{x:1268,y:942,t:1527030697242};\\\", \\\"{x:1269,y:943,t:1527030697259};\\\", \\\"{x:1270,y:944,t:1527030697276};\\\", \\\"{x:1272,y:949,t:1527030697292};\\\", \\\"{x:1273,y:954,t:1527030697309};\\\", \\\"{x:1274,y:957,t:1527030697326};\\\", \\\"{x:1275,y:959,t:1527030697344};\\\", \\\"{x:1276,y:961,t:1527030697359};\\\", \\\"{x:1276,y:962,t:1527030697376};\\\", \\\"{x:1276,y:964,t:1527030697392};\\\", \\\"{x:1278,y:964,t:1527030697641};\\\", \\\"{x:1279,y:964,t:1527030697664};\\\", \\\"{x:1281,y:964,t:1527030697904};\\\", \\\"{x:1282,y:964,t:1527030697928};\\\", \\\"{x:1283,y:964,t:1527030697943};\\\", \\\"{x:1284,y:964,t:1527030697959};\\\", \\\"{x:1287,y:963,t:1527030697976};\\\", \\\"{x:1289,y:963,t:1527030697993};\\\", \\\"{x:1292,y:963,t:1527030698010};\\\", \\\"{x:1295,y:961,t:1527030698026};\\\", \\\"{x:1297,y:961,t:1527030698042};\\\", \\\"{x:1299,y:961,t:1527030698060};\\\", \\\"{x:1302,y:961,t:1527030698075};\\\", \\\"{x:1303,y:961,t:1527030698093};\\\", \\\"{x:1304,y:962,t:1527030698232};\\\", \\\"{x:1304,y:963,t:1527030698256};\\\", \\\"{x:1305,y:964,t:1527030698288};\\\", \\\"{x:1306,y:964,t:1527030698320};\\\", \\\"{x:1307,y:964,t:1527030698329};\\\", \\\"{x:1308,y:964,t:1527030698344};\\\", \\\"{x:1309,y:964,t:1527030698360};\\\", \\\"{x:1311,y:964,t:1527030698376};\\\", \\\"{x:1316,y:966,t:1527030698393};\\\", \\\"{x:1321,y:968,t:1527030698410};\\\", \\\"{x:1327,y:971,t:1527030698425};\\\", \\\"{x:1330,y:972,t:1527030698443};\\\", \\\"{x:1333,y:973,t:1527030698460};\\\", \\\"{x:1333,y:974,t:1527030698477};\\\", \\\"{x:1335,y:974,t:1527030698493};\\\", \\\"{x:1337,y:974,t:1527030698510};\\\", \\\"{x:1340,y:974,t:1527030698527};\\\", \\\"{x:1341,y:974,t:1527030698543};\\\", \\\"{x:1342,y:974,t:1527030698592};\\\", \\\"{x:1343,y:974,t:1527030698600};\\\", \\\"{x:1346,y:974,t:1527030698610};\\\", \\\"{x:1352,y:974,t:1527030698627};\\\", \\\"{x:1359,y:974,t:1527030698643};\\\", \\\"{x:1360,y:974,t:1527030698660};\\\", \\\"{x:1361,y:974,t:1527030698677};\\\", \\\"{x:1361,y:975,t:1527030698704};\\\", \\\"{x:1361,y:976,t:1527030698800};\\\", \\\"{x:1360,y:976,t:1527030698968};\\\", \\\"{x:1358,y:976,t:1527030698984};\\\", \\\"{x:1353,y:974,t:1527030699000};\\\", \\\"{x:1350,y:973,t:1527030699010};\\\", \\\"{x:1338,y:970,t:1527030699027};\\\", \\\"{x:1327,y:967,t:1527030699045};\\\", \\\"{x:1318,y:966,t:1527030699059};\\\", \\\"{x:1315,y:965,t:1527030699077};\\\", \\\"{x:1312,y:964,t:1527030699095};\\\", \\\"{x:1311,y:964,t:1527030699110};\\\", \\\"{x:1312,y:964,t:1527030699281};\\\", \\\"{x:1315,y:963,t:1527030699294};\\\", \\\"{x:1320,y:962,t:1527030699310};\\\", \\\"{x:1327,y:961,t:1527030699327};\\\", \\\"{x:1335,y:961,t:1527030699344};\\\", \\\"{x:1345,y:961,t:1527030699360};\\\", \\\"{x:1360,y:964,t:1527030699377};\\\", \\\"{x:1370,y:968,t:1527030699394};\\\", \\\"{x:1379,y:969,t:1527030699410};\\\", \\\"{x:1380,y:970,t:1527030699427};\\\", \\\"{x:1381,y:971,t:1527030699448};\\\", \\\"{x:1381,y:973,t:1527030699480};\\\", \\\"{x:1381,y:974,t:1527030699496};\\\", \\\"{x:1379,y:974,t:1527030699511};\\\", \\\"{x:1376,y:974,t:1527030699527};\\\", \\\"{x:1371,y:974,t:1527030699544};\\\", \\\"{x:1367,y:974,t:1527030699560};\\\", \\\"{x:1364,y:974,t:1527030699577};\\\", \\\"{x:1362,y:974,t:1527030699594};\\\", \\\"{x:1359,y:974,t:1527030699610};\\\", \\\"{x:1355,y:974,t:1527030699627};\\\", \\\"{x:1354,y:974,t:1527030699705};\\\", \\\"{x:1353,y:974,t:1527030699728};\\\", \\\"{x:1353,y:973,t:1527030699873};\\\", \\\"{x:1354,y:972,t:1527030699896};\\\", \\\"{x:1355,y:971,t:1527030699910};\\\", \\\"{x:1358,y:970,t:1527030699927};\\\", \\\"{x:1363,y:967,t:1527030699944};\\\", \\\"{x:1365,y:966,t:1527030699961};\\\", \\\"{x:1369,y:965,t:1527030699977};\\\", \\\"{x:1372,y:964,t:1527030699994};\\\", \\\"{x:1375,y:963,t:1527030700011};\\\", \\\"{x:1376,y:963,t:1527030700032};\\\", \\\"{x:1378,y:963,t:1527030700044};\\\", \\\"{x:1379,y:963,t:1527030700062};\\\", \\\"{x:1380,y:963,t:1527030700077};\\\", \\\"{x:1382,y:962,t:1527030700094};\\\", \\\"{x:1384,y:962,t:1527030700128};\\\", \\\"{x:1385,y:962,t:1527030700152};\\\", \\\"{x:1389,y:962,t:1527030700161};\\\", \\\"{x:1397,y:962,t:1527030700177};\\\", \\\"{x:1406,y:962,t:1527030700194};\\\", \\\"{x:1414,y:962,t:1527030700211};\\\", \\\"{x:1417,y:962,t:1527030700227};\\\", \\\"{x:1418,y:962,t:1527030700244};\\\", \\\"{x:1419,y:961,t:1527030700552};\\\", \\\"{x:1419,y:960,t:1527030700561};\\\", \\\"{x:1424,y:959,t:1527030700578};\\\", \\\"{x:1428,y:956,t:1527030700594};\\\", \\\"{x:1436,y:955,t:1527030700611};\\\", \\\"{x:1439,y:955,t:1527030700628};\\\", \\\"{x:1443,y:955,t:1527030700644};\\\", \\\"{x:1445,y:955,t:1527030700661};\\\", \\\"{x:1446,y:955,t:1527030700678};\\\", \\\"{x:1454,y:957,t:1527030700694};\\\", \\\"{x:1471,y:962,t:1527030700711};\\\", \\\"{x:1499,y:968,t:1527030700728};\\\", \\\"{x:1517,y:970,t:1527030700744};\\\", \\\"{x:1526,y:972,t:1527030700760};\\\", \\\"{x:1527,y:972,t:1527030700778};\\\", \\\"{x:1528,y:972,t:1527030700799};\\\", \\\"{x:1528,y:973,t:1527030700816};\\\", \\\"{x:1528,y:974,t:1527030700840};\\\", \\\"{x:1528,y:975,t:1527030700872};\\\", \\\"{x:1528,y:976,t:1527030700888};\\\", \\\"{x:1527,y:976,t:1527030700896};\\\", \\\"{x:1524,y:978,t:1527030700912};\\\", \\\"{x:1520,y:978,t:1527030700928};\\\", \\\"{x:1515,y:978,t:1527030700945};\\\", \\\"{x:1512,y:978,t:1527030700962};\\\", \\\"{x:1510,y:978,t:1527030700979};\\\", \\\"{x:1509,y:978,t:1527030701000};\\\", \\\"{x:1507,y:978,t:1527030701024};\\\", \\\"{x:1506,y:978,t:1527030701032};\\\", \\\"{x:1504,y:978,t:1527030701048};\\\", \\\"{x:1503,y:978,t:1527030701061};\\\", \\\"{x:1500,y:978,t:1527030701078};\\\", \\\"{x:1499,y:977,t:1527030701096};\\\", \\\"{x:1498,y:977,t:1527030701120};\\\", \\\"{x:1497,y:975,t:1527030701128};\\\", \\\"{x:1495,y:973,t:1527030701145};\\\", \\\"{x:1491,y:970,t:1527030701161};\\\", \\\"{x:1484,y:968,t:1527030701179};\\\", \\\"{x:1469,y:963,t:1527030701196};\\\", \\\"{x:1460,y:961,t:1527030701211};\\\", \\\"{x:1454,y:958,t:1527030701228};\\\", \\\"{x:1453,y:958,t:1527030701248};\\\", \\\"{x:1452,y:958,t:1527030701272};\\\", \\\"{x:1452,y:957,t:1527030701337};\\\", \\\"{x:1452,y:956,t:1527030701345};\\\", \\\"{x:1455,y:954,t:1527030701361};\\\", \\\"{x:1461,y:953,t:1527030701379};\\\", \\\"{x:1470,y:951,t:1527030701395};\\\", \\\"{x:1480,y:949,t:1527030701411};\\\", \\\"{x:1489,y:943,t:1527030701428};\\\", \\\"{x:1497,y:936,t:1527030701446};\\\", \\\"{x:1501,y:932,t:1527030701462};\\\", \\\"{x:1504,y:932,t:1527030701478};\\\", \\\"{x:1508,y:932,t:1527030701495};\\\", \\\"{x:1509,y:932,t:1527030701536};\\\", \\\"{x:1510,y:932,t:1527030701560};\\\", \\\"{x:1511,y:932,t:1527030701568};\\\", \\\"{x:1512,y:932,t:1527030701578};\\\", \\\"{x:1519,y:940,t:1527030701595};\\\", \\\"{x:1528,y:950,t:1527030701612};\\\", \\\"{x:1543,y:962,t:1527030701628};\\\", \\\"{x:1551,y:968,t:1527030701645};\\\", \\\"{x:1557,y:970,t:1527030701662};\\\", \\\"{x:1562,y:972,t:1527030701678};\\\", \\\"{x:1563,y:972,t:1527030701695};\\\", \\\"{x:1563,y:973,t:1527030701792};\\\", \\\"{x:1564,y:971,t:1527030701920};\\\", \\\"{x:1565,y:970,t:1527030701928};\\\", \\\"{x:1567,y:968,t:1527030701945};\\\", \\\"{x:1572,y:966,t:1527030701962};\\\", \\\"{x:1578,y:964,t:1527030701979};\\\", \\\"{x:1586,y:964,t:1527030701995};\\\", \\\"{x:1593,y:964,t:1527030702013};\\\", \\\"{x:1601,y:964,t:1527030702029};\\\", \\\"{x:1609,y:964,t:1527030702045};\\\", \\\"{x:1623,y:966,t:1527030702062};\\\", \\\"{x:1634,y:969,t:1527030702079};\\\", \\\"{x:1638,y:969,t:1527030702095};\\\", \\\"{x:1639,y:970,t:1527030702112};\\\", \\\"{x:1640,y:970,t:1527030702168};\\\", \\\"{x:1638,y:970,t:1527030702280};\\\", \\\"{x:1635,y:970,t:1527030702295};\\\", \\\"{x:1626,y:970,t:1527030702312};\\\", \\\"{x:1623,y:970,t:1527030702329};\\\", \\\"{x:1620,y:970,t:1527030702344};\\\", \\\"{x:1619,y:970,t:1527030702362};\\\", \\\"{x:1618,y:970,t:1527030703352};\\\", \\\"{x:1618,y:969,t:1527030703376};\\\", \\\"{x:1620,y:968,t:1527030703384};\\\", \\\"{x:1620,y:967,t:1527030703396};\\\", \\\"{x:1621,y:966,t:1527030703413};\\\", \\\"{x:1622,y:966,t:1527030703429};\\\", \\\"{x:1623,y:966,t:1527030703445};\\\", \\\"{x:1626,y:966,t:1527030703463};\\\", \\\"{x:1629,y:966,t:1527030703479};\\\", \\\"{x:1636,y:966,t:1527030703495};\\\", \\\"{x:1640,y:966,t:1527030703512};\\\", \\\"{x:1643,y:966,t:1527030703529};\\\", \\\"{x:1644,y:966,t:1527030703546};\\\", \\\"{x:1647,y:966,t:1527030703616};\\\", \\\"{x:1647,y:967,t:1527030703664};\\\", \\\"{x:1648,y:967,t:1527030703679};\\\", \\\"{x:1644,y:967,t:1527030703769};\\\", \\\"{x:1638,y:966,t:1527030703780};\\\", \\\"{x:1618,y:957,t:1527030703796};\\\", \\\"{x:1579,y:947,t:1527030703813};\\\", \\\"{x:1535,y:935,t:1527030703830};\\\", \\\"{x:1506,y:930,t:1527030703846};\\\", \\\"{x:1484,y:926,t:1527030703863};\\\", \\\"{x:1472,y:922,t:1527030703880};\\\", \\\"{x:1448,y:915,t:1527030703896};\\\", \\\"{x:1425,y:908,t:1527030703913};\\\", \\\"{x:1416,y:904,t:1527030703930};\\\", \\\"{x:1416,y:902,t:1527030704088};\\\", \\\"{x:1417,y:898,t:1527030704096};\\\", \\\"{x:1417,y:893,t:1527030704113};\\\", \\\"{x:1417,y:885,t:1527030704130};\\\", \\\"{x:1417,y:870,t:1527030704146};\\\", \\\"{x:1413,y:855,t:1527030704163};\\\", \\\"{x:1408,y:846,t:1527030704180};\\\", \\\"{x:1404,y:838,t:1527030704196};\\\", \\\"{x:1401,y:830,t:1527030704213};\\\", \\\"{x:1400,y:824,t:1527030704230};\\\", \\\"{x:1400,y:814,t:1527030704246};\\\", \\\"{x:1400,y:802,t:1527030704263};\\\", \\\"{x:1400,y:792,t:1527030704280};\\\", \\\"{x:1400,y:788,t:1527030704296};\\\", \\\"{x:1399,y:786,t:1527030704313};\\\", \\\"{x:1397,y:784,t:1527030704330};\\\", \\\"{x:1393,y:779,t:1527030704347};\\\", \\\"{x:1388,y:775,t:1527030704364};\\\", \\\"{x:1386,y:774,t:1527030704380};\\\", \\\"{x:1383,y:772,t:1527030704397};\\\", \\\"{x:1382,y:771,t:1527030704414};\\\", \\\"{x:1383,y:771,t:1527030704768};\\\", \\\"{x:1385,y:772,t:1527030704784};\\\", \\\"{x:1386,y:772,t:1527030704798};\\\", \\\"{x:1386,y:773,t:1527030704832};\\\", \\\"{x:1385,y:773,t:1527030704960};\\\", \\\"{x:1384,y:773,t:1527030704968};\\\", \\\"{x:1383,y:773,t:1527030704980};\\\", \\\"{x:1382,y:773,t:1527030705000};\\\", \\\"{x:1380,y:773,t:1527030705018};\\\", \\\"{x:1368,y:766,t:1527030705034};\\\", \\\"{x:1350,y:755,t:1527030705051};\\\", \\\"{x:1308,y:735,t:1527030705067};\\\", \\\"{x:1278,y:723,t:1527030705083};\\\", \\\"{x:1250,y:719,t:1527030705101};\\\", \\\"{x:1232,y:718,t:1527030705118};\\\", \\\"{x:1218,y:720,t:1527030705133};\\\", \\\"{x:1213,y:725,t:1527030705150};\\\", \\\"{x:1211,y:729,t:1527030705167};\\\", \\\"{x:1211,y:734,t:1527030705184};\\\", \\\"{x:1214,y:739,t:1527030705200};\\\", \\\"{x:1219,y:744,t:1527030705217};\\\", \\\"{x:1222,y:747,t:1527030705233};\\\", \\\"{x:1228,y:751,t:1527030705251};\\\", \\\"{x:1245,y:761,t:1527030705268};\\\", \\\"{x:1263,y:772,t:1527030705283};\\\", \\\"{x:1274,y:779,t:1527030705301};\\\", \\\"{x:1278,y:781,t:1527030705317};\\\", \\\"{x:1279,y:782,t:1527030705334};\\\", \\\"{x:1279,y:784,t:1527030705351};\\\", \\\"{x:1279,y:788,t:1527030705368};\\\", \\\"{x:1279,y:798,t:1527030705384};\\\", \\\"{x:1283,y:811,t:1527030705400};\\\", \\\"{x:1283,y:816,t:1527030705418};\\\", \\\"{x:1283,y:818,t:1527030705434};\\\", \\\"{x:1284,y:820,t:1527030705460};\\\", \\\"{x:1285,y:820,t:1527030705467};\\\", \\\"{x:1288,y:824,t:1527030705484};\\\", \\\"{x:1291,y:830,t:1527030705501};\\\", \\\"{x:1295,y:838,t:1527030705518};\\\", \\\"{x:1302,y:848,t:1527030705534};\\\", \\\"{x:1310,y:855,t:1527030705550};\\\", \\\"{x:1317,y:860,t:1527030705567};\\\", \\\"{x:1330,y:864,t:1527030705584};\\\", \\\"{x:1337,y:867,t:1527030705600};\\\", \\\"{x:1337,y:865,t:1527030705651};\\\", \\\"{x:1337,y:859,t:1527030705667};\\\", \\\"{x:1337,y:849,t:1527030705684};\\\", \\\"{x:1340,y:834,t:1527030705700};\\\", \\\"{x:1342,y:821,t:1527030705718};\\\", \\\"{x:1344,y:818,t:1527030705735};\\\", \\\"{x:1344,y:817,t:1527030705751};\\\", \\\"{x:1345,y:815,t:1527030705768};\\\", \\\"{x:1346,y:814,t:1527030705836};\\\", \\\"{x:1346,y:812,t:1527030705850};\\\", \\\"{x:1346,y:807,t:1527030705867};\\\", \\\"{x:1349,y:802,t:1527030705885};\\\", \\\"{x:1349,y:800,t:1527030705901};\\\", \\\"{x:1349,y:794,t:1527030705917};\\\", \\\"{x:1349,y:784,t:1527030705935};\\\", \\\"{x:1344,y:772,t:1527030705951};\\\", \\\"{x:1333,y:754,t:1527030705968};\\\", \\\"{x:1326,y:742,t:1527030705984};\\\", \\\"{x:1322,y:731,t:1527030706000};\\\", \\\"{x:1321,y:718,t:1527030706017};\\\", \\\"{x:1322,y:714,t:1527030706034};\\\", \\\"{x:1323,y:713,t:1527030706051};\\\", \\\"{x:1323,y:712,t:1527030706068};\\\", \\\"{x:1323,y:711,t:1527030706084};\\\", \\\"{x:1324,y:710,t:1527030706123};\\\", \\\"{x:1325,y:710,t:1527030706139};\\\", \\\"{x:1326,y:710,t:1527030706152};\\\", \\\"{x:1328,y:709,t:1527030706168};\\\", \\\"{x:1333,y:707,t:1527030706185};\\\", \\\"{x:1335,y:706,t:1527030706201};\\\", \\\"{x:1338,y:706,t:1527030706217};\\\", \\\"{x:1339,y:705,t:1527030706236};\\\", \\\"{x:1339,y:704,t:1527030706268};\\\", \\\"{x:1341,y:702,t:1527030706285};\\\", \\\"{x:1342,y:701,t:1527030706436};\\\", \\\"{x:1343,y:701,t:1527030706707};\\\", \\\"{x:1344,y:701,t:1527030706723};\\\", \\\"{x:1345,y:701,t:1527030706735};\\\", \\\"{x:1346,y:702,t:1527030706752};\\\", \\\"{x:1347,y:704,t:1527030706768};\\\", \\\"{x:1348,y:707,t:1527030706785};\\\", \\\"{x:1348,y:711,t:1527030706802};\\\", \\\"{x:1349,y:714,t:1527030706819};\\\", \\\"{x:1351,y:717,t:1527030706835};\\\", \\\"{x:1352,y:720,t:1527030706852};\\\", \\\"{x:1352,y:721,t:1527030706883};\\\", \\\"{x:1352,y:722,t:1527030706891};\\\", \\\"{x:1352,y:723,t:1527030706902};\\\", \\\"{x:1352,y:725,t:1527030706919};\\\", \\\"{x:1354,y:731,t:1527030706935};\\\", \\\"{x:1354,y:734,t:1527030706952};\\\", \\\"{x:1354,y:738,t:1527030706969};\\\", \\\"{x:1354,y:739,t:1527030706987};\\\", \\\"{x:1354,y:737,t:1527030707187};\\\", \\\"{x:1354,y:735,t:1527030707201};\\\", \\\"{x:1354,y:734,t:1527030707219};\\\", \\\"{x:1354,y:733,t:1527030707235};\\\", \\\"{x:1354,y:731,t:1527030707252};\\\", \\\"{x:1354,y:728,t:1527030707269};\\\", \\\"{x:1354,y:726,t:1527030707285};\\\", \\\"{x:1354,y:724,t:1527030707302};\\\", \\\"{x:1353,y:719,t:1527030707319};\\\", \\\"{x:1350,y:715,t:1527030707335};\\\", \\\"{x:1349,y:714,t:1527030707352};\\\", \\\"{x:1349,y:712,t:1527030707369};\\\", \\\"{x:1348,y:713,t:1527030707452};\\\", \\\"{x:1346,y:726,t:1527030707469};\\\", \\\"{x:1339,y:753,t:1527030707485};\\\", \\\"{x:1336,y:784,t:1527030707502};\\\", \\\"{x:1336,y:812,t:1527030707518};\\\", \\\"{x:1337,y:837,t:1527030707535};\\\", \\\"{x:1342,y:850,t:1527030707552};\\\", \\\"{x:1343,y:856,t:1527030707568};\\\", \\\"{x:1343,y:858,t:1527030707586};\\\", \\\"{x:1343,y:863,t:1527030707601};\\\", \\\"{x:1345,y:869,t:1527030707619};\\\", \\\"{x:1345,y:881,t:1527030707635};\\\", \\\"{x:1345,y:895,t:1527030707651};\\\", \\\"{x:1343,y:913,t:1527030707668};\\\", \\\"{x:1340,y:930,t:1527030707685};\\\", \\\"{x:1340,y:936,t:1527030707701};\\\", \\\"{x:1340,y:943,t:1527030707718};\\\", \\\"{x:1340,y:944,t:1527030707735};\\\", \\\"{x:1340,y:946,t:1527030707752};\\\", \\\"{x:1340,y:947,t:1527030707771};\\\", \\\"{x:1342,y:950,t:1527030707786};\\\", \\\"{x:1342,y:952,t:1527030707802};\\\", \\\"{x:1344,y:958,t:1527030707819};\\\", \\\"{x:1346,y:972,t:1527030707835};\\\", \\\"{x:1347,y:973,t:1527030707908};\\\", \\\"{x:1348,y:973,t:1527030707955};\\\", \\\"{x:1350,y:973,t:1527030707996};\\\", \\\"{x:1352,y:972,t:1527030708003};\\\", \\\"{x:1353,y:972,t:1527030708018};\\\", \\\"{x:1363,y:966,t:1527030708035};\\\", \\\"{x:1384,y:960,t:1527030708053};\\\", \\\"{x:1408,y:953,t:1527030708069};\\\", \\\"{x:1434,y:940,t:1527030708086};\\\", \\\"{x:1477,y:924,t:1527030708102};\\\", \\\"{x:1515,y:910,t:1527030708119};\\\", \\\"{x:1527,y:903,t:1527030708136};\\\", \\\"{x:1532,y:900,t:1527030708152};\\\", \\\"{x:1533,y:900,t:1527030708195};\\\", \\\"{x:1533,y:903,t:1527030708203};\\\", \\\"{x:1533,y:905,t:1527030708218};\\\", \\\"{x:1533,y:922,t:1527030708236};\\\", \\\"{x:1533,y:925,t:1527030708253};\\\", \\\"{x:1533,y:928,t:1527030708269};\\\", \\\"{x:1532,y:928,t:1527030708307};\\\", \\\"{x:1532,y:929,t:1527030708323};\\\", \\\"{x:1531,y:930,t:1527030708336};\\\", \\\"{x:1530,y:932,t:1527030708353};\\\", \\\"{x:1530,y:934,t:1527030708369};\\\", \\\"{x:1527,y:936,t:1527030708385};\\\", \\\"{x:1525,y:939,t:1527030708403};\\\", \\\"{x:1519,y:946,t:1527030708419};\\\", \\\"{x:1515,y:950,t:1527030708436};\\\", \\\"{x:1511,y:954,t:1527030708452};\\\", \\\"{x:1508,y:957,t:1527030708470};\\\", \\\"{x:1506,y:959,t:1527030708486};\\\", \\\"{x:1505,y:961,t:1527030708503};\\\", \\\"{x:1505,y:962,t:1527030708532};\\\", \\\"{x:1505,y:964,t:1527030708596};\\\", \\\"{x:1505,y:965,t:1527030708788};\\\", \\\"{x:1503,y:965,t:1527030708803};\\\", \\\"{x:1498,y:963,t:1527030708820};\\\", \\\"{x:1493,y:959,t:1527030708836};\\\", \\\"{x:1483,y:951,t:1527030708853};\\\", \\\"{x:1471,y:941,t:1527030708870};\\\", \\\"{x:1460,y:929,t:1527030708886};\\\", \\\"{x:1453,y:918,t:1527030708903};\\\", \\\"{x:1448,y:906,t:1527030708920};\\\", \\\"{x:1446,y:900,t:1527030708937};\\\", \\\"{x:1446,y:894,t:1527030708952};\\\", \\\"{x:1446,y:884,t:1527030708969};\\\", \\\"{x:1446,y:878,t:1527030708985};\\\", \\\"{x:1446,y:874,t:1527030709003};\\\", \\\"{x:1446,y:871,t:1527030709019};\\\", \\\"{x:1446,y:867,t:1527030709037};\\\", \\\"{x:1446,y:863,t:1527030709053};\\\", \\\"{x:1449,y:854,t:1527030709070};\\\", \\\"{x:1450,y:848,t:1527030709086};\\\", \\\"{x:1450,y:847,t:1527030709102};\\\", \\\"{x:1451,y:844,t:1527030709120};\\\", \\\"{x:1452,y:844,t:1527030709163};\\\", \\\"{x:1453,y:843,t:1527030709180};\\\", \\\"{x:1454,y:843,t:1527030709228};\\\", \\\"{x:1455,y:843,t:1527030709236};\\\", \\\"{x:1456,y:842,t:1527030709253};\\\", \\\"{x:1457,y:842,t:1527030709270};\\\", \\\"{x:1458,y:841,t:1527030709291};\\\", \\\"{x:1459,y:841,t:1527030709331};\\\", \\\"{x:1461,y:841,t:1527030709355};\\\", \\\"{x:1462,y:841,t:1527030709371};\\\", \\\"{x:1464,y:841,t:1527030709387};\\\", \\\"{x:1465,y:841,t:1527030709402};\\\", \\\"{x:1469,y:841,t:1527030709419};\\\", \\\"{x:1471,y:841,t:1527030709437};\\\", \\\"{x:1474,y:841,t:1527030709452};\\\", \\\"{x:1476,y:841,t:1527030709470};\\\", \\\"{x:1478,y:840,t:1527030709487};\\\", \\\"{x:1478,y:839,t:1527030709508};\\\", \\\"{x:1478,y:838,t:1527030709539};\\\", \\\"{x:1478,y:837,t:1527030709553};\\\", \\\"{x:1477,y:837,t:1527030709569};\\\", \\\"{x:1470,y:834,t:1527030709586};\\\", \\\"{x:1441,y:829,t:1527030709603};\\\", \\\"{x:1394,y:822,t:1527030709619};\\\", \\\"{x:1327,y:813,t:1527030709636};\\\", \\\"{x:1236,y:802,t:1527030709654};\\\", \\\"{x:1135,y:784,t:1527030709670};\\\", \\\"{x:1042,y:760,t:1527030709686};\\\", \\\"{x:961,y:736,t:1527030709704};\\\", \\\"{x:899,y:706,t:1527030709719};\\\", \\\"{x:854,y:674,t:1527030709736};\\\", \\\"{x:822,y:640,t:1527030709754};\\\", \\\"{x:799,y:611,t:1527030709770};\\\", \\\"{x:788,y:592,t:1527030709788};\\\", \\\"{x:781,y:569,t:1527030709810};\\\", \\\"{x:778,y:560,t:1527030709827};\\\", \\\"{x:778,y:558,t:1527030709842};\\\", \\\"{x:778,y:557,t:1527030709860};\\\", \\\"{x:777,y:555,t:1527030709965};\\\", \\\"{x:774,y:553,t:1527030709977};\\\", \\\"{x:754,y:545,t:1527030709993};\\\", \\\"{x:719,y:530,t:1527030710010};\\\", \\\"{x:674,y:522,t:1527030710027};\\\", \\\"{x:624,y:518,t:1527030710043};\\\", \\\"{x:593,y:515,t:1527030710060};\\\", \\\"{x:590,y:515,t:1527030710077};\\\", \\\"{x:587,y:515,t:1527030710094};\\\", \\\"{x:586,y:515,t:1527030710109};\\\", \\\"{x:583,y:515,t:1527030710131};\\\", \\\"{x:582,y:515,t:1527030710147};\\\", \\\"{x:582,y:517,t:1527030710160};\\\", \\\"{x:582,y:520,t:1527030710177};\\\", \\\"{x:580,y:525,t:1527030710195};\\\", \\\"{x:580,y:530,t:1527030710209};\\\", \\\"{x:580,y:536,t:1527030710227};\\\", \\\"{x:585,y:547,t:1527030710244};\\\", \\\"{x:588,y:550,t:1527030710260};\\\", \\\"{x:588,y:551,t:1527030710277};\\\", \\\"{x:589,y:552,t:1527030710294};\\\", \\\"{x:591,y:554,t:1527030710310};\\\", \\\"{x:595,y:559,t:1527030710327};\\\", \\\"{x:599,y:564,t:1527030710344};\\\", \\\"{x:601,y:569,t:1527030710360};\\\", \\\"{x:603,y:572,t:1527030710377};\\\", \\\"{x:602,y:572,t:1527030710467};\\\", \\\"{x:601,y:572,t:1527030710483};\\\", \\\"{x:600,y:572,t:1527030710494};\\\", \\\"{x:597,y:572,t:1527030710511};\\\", \\\"{x:587,y:572,t:1527030710527};\\\", \\\"{x:565,y:571,t:1527030710544};\\\", \\\"{x:538,y:567,t:1527030710560};\\\", \\\"{x:509,y:567,t:1527030710577};\\\", \\\"{x:485,y:567,t:1527030710593};\\\", \\\"{x:472,y:567,t:1527030710610};\\\", \\\"{x:469,y:567,t:1527030710627};\\\", \\\"{x:468,y:568,t:1527030710644};\\\", \\\"{x:465,y:570,t:1527030710661};\\\", \\\"{x:462,y:572,t:1527030710677};\\\", \\\"{x:457,y:574,t:1527030710694};\\\", \\\"{x:453,y:575,t:1527030710711};\\\", \\\"{x:443,y:576,t:1527030710726};\\\", \\\"{x:439,y:577,t:1527030710744};\\\", \\\"{x:437,y:578,t:1527030710761};\\\", \\\"{x:435,y:579,t:1527030710777};\\\", \\\"{x:433,y:580,t:1527030710794};\\\", \\\"{x:428,y:586,t:1527030710811};\\\", \\\"{x:420,y:594,t:1527030710827};\\\", \\\"{x:404,y:611,t:1527030710844};\\\", \\\"{x:398,y:616,t:1527030710860};\\\", \\\"{x:393,y:619,t:1527030710877};\\\", \\\"{x:392,y:620,t:1527030710894};\\\", \\\"{x:390,y:621,t:1527030710911};\\\", \\\"{x:390,y:623,t:1527030710928};\\\", \\\"{x:389,y:628,t:1527030710944};\\\", \\\"{x:388,y:634,t:1527030710961};\\\", \\\"{x:386,y:638,t:1527030710978};\\\", \\\"{x:384,y:643,t:1527030710994};\\\", \\\"{x:383,y:646,t:1527030711011};\\\", \\\"{x:382,y:646,t:1527030711043};\\\", \\\"{x:381,y:646,t:1527030711051};\\\", \\\"{x:380,y:646,t:1527030711060};\\\", \\\"{x:373,y:646,t:1527030711078};\\\", \\\"{x:359,y:644,t:1527030711094};\\\", \\\"{x:334,y:642,t:1527030711111};\\\", \\\"{x:303,y:636,t:1527030711128};\\\", \\\"{x:261,y:631,t:1527030711144};\\\", \\\"{x:240,y:629,t:1527030711160};\\\", \\\"{x:230,y:627,t:1527030711178};\\\", \\\"{x:227,y:627,t:1527030711193};\\\", \\\"{x:226,y:627,t:1527030711211};\\\", \\\"{x:221,y:627,t:1527030711227};\\\", \\\"{x:213,y:632,t:1527030711244};\\\", \\\"{x:209,y:633,t:1527030711261};\\\", \\\"{x:205,y:634,t:1527030711277};\\\", \\\"{x:212,y:633,t:1527030711347};\\\", \\\"{x:226,y:627,t:1527030711361};\\\", \\\"{x:293,y:608,t:1527030711379};\\\", \\\"{x:403,y:579,t:1527030711395};\\\", \\\"{x:529,y:556,t:1527030711411};\\\", \\\"{x:704,y:538,t:1527030711428};\\\", \\\"{x:793,y:538,t:1527030711445};\\\", \\\"{x:839,y:541,t:1527030711461};\\\", \\\"{x:866,y:551,t:1527030711478};\\\", \\\"{x:868,y:553,t:1527030711495};\\\", \\\"{x:868,y:556,t:1527030711511};\\\", \\\"{x:867,y:560,t:1527030711528};\\\", \\\"{x:864,y:564,t:1527030711545};\\\", \\\"{x:864,y:567,t:1527030711561};\\\", \\\"{x:863,y:572,t:1527030711577};\\\", \\\"{x:863,y:578,t:1527030711595};\\\", \\\"{x:863,y:582,t:1527030711611};\\\", \\\"{x:863,y:589,t:1527030711627};\\\", \\\"{x:862,y:593,t:1527030711645};\\\", \\\"{x:860,y:595,t:1527030711661};\\\", \\\"{x:859,y:596,t:1527030711678};\\\", \\\"{x:859,y:597,t:1527030711723};\\\", \\\"{x:858,y:597,t:1527030711731};\\\", \\\"{x:858,y:593,t:1527030711745};\\\", \\\"{x:852,y:577,t:1527030711762};\\\", \\\"{x:845,y:563,t:1527030711778};\\\", \\\"{x:834,y:546,t:1527030711796};\\\", \\\"{x:806,y:522,t:1527030711812};\\\", \\\"{x:767,y:511,t:1527030711829};\\\", \\\"{x:702,y:491,t:1527030711845};\\\", \\\"{x:633,y:482,t:1527030711863};\\\", \\\"{x:573,y:479,t:1527030711878};\\\", \\\"{x:531,y:479,t:1527030711895};\\\", \\\"{x:504,y:480,t:1527030711912};\\\", \\\"{x:485,y:486,t:1527030711928};\\\", \\\"{x:468,y:493,t:1527030711946};\\\", \\\"{x:457,y:499,t:1527030711961};\\\", \\\"{x:449,y:506,t:1527030711978};\\\", \\\"{x:443,y:515,t:1527030711994};\\\", \\\"{x:430,y:532,t:1527030712012};\\\", \\\"{x:424,y:545,t:1527030712027};\\\", \\\"{x:423,y:553,t:1527030712045};\\\", \\\"{x:421,y:559,t:1527030712062};\\\", \\\"{x:421,y:562,t:1527030712077};\\\", \\\"{x:421,y:563,t:1527030712095};\\\", \\\"{x:420,y:563,t:1527030712112};\\\", \\\"{x:417,y:562,t:1527030712196};\\\", \\\"{x:404,y:559,t:1527030712212};\\\", \\\"{x:391,y:555,t:1527030712228};\\\", \\\"{x:382,y:552,t:1527030712245};\\\", \\\"{x:375,y:552,t:1527030712262};\\\", \\\"{x:374,y:552,t:1527030712307};\\\", \\\"{x:373,y:552,t:1527030712315};\\\", \\\"{x:371,y:552,t:1527030712328};\\\", \\\"{x:370,y:558,t:1527030712345};\\\", \\\"{x:367,y:565,t:1527030712363};\\\", \\\"{x:363,y:578,t:1527030712379};\\\", \\\"{x:356,y:604,t:1527030712395};\\\", \\\"{x:355,y:615,t:1527030712412};\\\", \\\"{x:355,y:619,t:1527030712429};\\\", \\\"{x:360,y:623,t:1527030712445};\\\", \\\"{x:361,y:624,t:1527030712461};\\\", \\\"{x:361,y:625,t:1527030712478};\\\", \\\"{x:361,y:626,t:1527030712496};\\\", \\\"{x:361,y:627,t:1527030712512};\\\", \\\"{x:360,y:630,t:1527030712529};\\\", \\\"{x:360,y:632,t:1527030712546};\\\", \\\"{x:358,y:633,t:1527030712562};\\\", \\\"{x:360,y:633,t:1527030712643};\\\", \\\"{x:366,y:632,t:1527030712651};\\\", \\\"{x:374,y:632,t:1527030712662};\\\", \\\"{x:407,y:629,t:1527030712679};\\\", \\\"{x:449,y:629,t:1527030712695};\\\", \\\"{x:499,y:629,t:1527030712712};\\\", \\\"{x:549,y:629,t:1527030712728};\\\", \\\"{x:583,y:633,t:1527030712747};\\\", \\\"{x:609,y:637,t:1527030712762};\\\", \\\"{x:621,y:638,t:1527030712779};\\\", \\\"{x:629,y:637,t:1527030712795};\\\", \\\"{x:631,y:636,t:1527030712811};\\\", \\\"{x:631,y:634,t:1527030712829};\\\", \\\"{x:632,y:632,t:1527030712846};\\\", \\\"{x:632,y:631,t:1527030712862};\\\", \\\"{x:632,y:630,t:1527030712923};\\\", \\\"{x:632,y:629,t:1527030712939};\\\", \\\"{x:632,y:628,t:1527030712947};\\\", \\\"{x:631,y:625,t:1527030712962};\\\", \\\"{x:626,y:610,t:1527030712979};\\\", \\\"{x:621,y:593,t:1527030712996};\\\", \\\"{x:619,y:585,t:1527030713012};\\\", \\\"{x:617,y:577,t:1527030713029};\\\", \\\"{x:615,y:572,t:1527030713046};\\\", \\\"{x:615,y:567,t:1527030713062};\\\", \\\"{x:614,y:565,t:1527030713079};\\\", \\\"{x:614,y:563,t:1527030713096};\\\", \\\"{x:613,y:563,t:1527030713204};\\\", \\\"{x:613,y:564,t:1527030713227};\\\", \\\"{x:613,y:565,t:1527030713236};\\\", \\\"{x:613,y:566,t:1527030713246};\\\", \\\"{x:613,y:571,t:1527030713263};\\\", \\\"{x:613,y:576,t:1527030713279};\\\", \\\"{x:614,y:580,t:1527030713296};\\\", \\\"{x:615,y:584,t:1527030713313};\\\", \\\"{x:616,y:585,t:1527030713329};\\\", \\\"{x:616,y:586,t:1527030713346};\\\", \\\"{x:617,y:587,t:1527030713780};\\\", \\\"{x:618,y:587,t:1527030714044};\\\", \\\"{x:621,y:587,t:1527030714053};\\\", \\\"{x:628,y:587,t:1527030714063};\\\", \\\"{x:647,y:587,t:1527030714081};\\\", \\\"{x:687,y:587,t:1527030714096};\\\", \\\"{x:767,y:597,t:1527030714113};\\\", \\\"{x:852,y:612,t:1527030714130};\\\", \\\"{x:927,y:635,t:1527030714147};\\\", \\\"{x:975,y:649,t:1527030714163};\\\", \\\"{x:1018,y:667,t:1527030714180};\\\", \\\"{x:1026,y:674,t:1527030714198};\\\", \\\"{x:1029,y:677,t:1527030714213};\\\", \\\"{x:1029,y:681,t:1527030714230};\\\", \\\"{x:1029,y:685,t:1527030714247};\\\", \\\"{x:1029,y:686,t:1527030714263};\\\", \\\"{x:1030,y:689,t:1527030714281};\\\", \\\"{x:1038,y:693,t:1527030714297};\\\", \\\"{x:1047,y:701,t:1527030714313};\\\", \\\"{x:1058,y:712,t:1527030714330};\\\", \\\"{x:1068,y:722,t:1527030714347};\\\", \\\"{x:1086,y:736,t:1527030714364};\\\", \\\"{x:1120,y:764,t:1527030714380};\\\", \\\"{x:1140,y:780,t:1527030714398};\\\", \\\"{x:1155,y:791,t:1527030714413};\\\", \\\"{x:1171,y:801,t:1527030714430};\\\", \\\"{x:1187,y:807,t:1527030714448};\\\", \\\"{x:1208,y:813,t:1527030714464};\\\", \\\"{x:1229,y:818,t:1527030714481};\\\", \\\"{x:1243,y:823,t:1527030714498};\\\", \\\"{x:1253,y:824,t:1527030714514};\\\", \\\"{x:1262,y:824,t:1527030714530};\\\", \\\"{x:1276,y:826,t:1527030714547};\\\", \\\"{x:1280,y:827,t:1527030714563};\\\", \\\"{x:1283,y:828,t:1527030714580};\\\", \\\"{x:1283,y:829,t:1527030714604};\\\", \\\"{x:1285,y:830,t:1527030714619};\\\", \\\"{x:1286,y:830,t:1527030714630};\\\", \\\"{x:1289,y:830,t:1527030714989};\\\", \\\"{x:1298,y:829,t:1527030714998};\\\", \\\"{x:1308,y:825,t:1527030715015};\\\", \\\"{x:1312,y:823,t:1527030715032};\\\", \\\"{x:1313,y:822,t:1527030715067};\\\", \\\"{x:1314,y:820,t:1527030715083};\\\", \\\"{x:1316,y:819,t:1527030715097};\\\", \\\"{x:1320,y:815,t:1527030715114};\\\", \\\"{x:1327,y:810,t:1527030715131};\\\", \\\"{x:1341,y:805,t:1527030715147};\\\", \\\"{x:1357,y:803,t:1527030715164};\\\", \\\"{x:1358,y:803,t:1527030715181};\\\", \\\"{x:1365,y:803,t:1527030715301};\\\", \\\"{x:1387,y:810,t:1527030715315};\\\", \\\"{x:1441,y:820,t:1527030715332};\\\", \\\"{x:1459,y:827,t:1527030715349};\\\", \\\"{x:1466,y:831,t:1527030715365};\\\", \\\"{x:1479,y:840,t:1527030715382};\\\", \\\"{x:1493,y:857,t:1527030715398};\\\", \\\"{x:1506,y:877,t:1527030715415};\\\", \\\"{x:1527,y:903,t:1527030715432};\\\", \\\"{x:1540,y:921,t:1527030715448};\\\", \\\"{x:1552,y:935,t:1527030715465};\\\", \\\"{x:1563,y:946,t:1527030715482};\\\", \\\"{x:1571,y:957,t:1527030715499};\\\", \\\"{x:1575,y:962,t:1527030715515};\\\", \\\"{x:1576,y:964,t:1527030715532};\\\", \\\"{x:1578,y:968,t:1527030715548};\\\", \\\"{x:1583,y:973,t:1527030715565};\\\", \\\"{x:1586,y:976,t:1527030715582};\\\", \\\"{x:1588,y:977,t:1527030715598};\\\", \\\"{x:1589,y:977,t:1527030715692};\\\", \\\"{x:1590,y:976,t:1527030715700};\\\", \\\"{x:1590,y:974,t:1527030715716};\\\", \\\"{x:1590,y:972,t:1527030715732};\\\", \\\"{x:1591,y:971,t:1527030715748};\\\", \\\"{x:1592,y:968,t:1527030715819};\\\", \\\"{x:1593,y:968,t:1527030715831};\\\", \\\"{x:1596,y:964,t:1527030715848};\\\", \\\"{x:1598,y:961,t:1527030715865};\\\", \\\"{x:1602,y:957,t:1527030715881};\\\", \\\"{x:1604,y:956,t:1527030715898};\\\", \\\"{x:1605,y:955,t:1527030715915};\\\", \\\"{x:1603,y:955,t:1527030716053};\\\", \\\"{x:1601,y:955,t:1527030716066};\\\", \\\"{x:1600,y:955,t:1527030716149};\\\", \\\"{x:1598,y:956,t:1527030716166};\\\", \\\"{x:1596,y:956,t:1527030716182};\\\", \\\"{x:1594,y:957,t:1527030716198};\\\", \\\"{x:1593,y:957,t:1527030716268};\\\", \\\"{x:1592,y:957,t:1527030716283};\\\", \\\"{x:1590,y:957,t:1527030716298};\\\", \\\"{x:1588,y:957,t:1527030716316};\\\", \\\"{x:1581,y:958,t:1527030716333};\\\", \\\"{x:1577,y:958,t:1527030716349};\\\", \\\"{x:1572,y:958,t:1527030716366};\\\", \\\"{x:1566,y:958,t:1527030716382};\\\", \\\"{x:1561,y:958,t:1527030716399};\\\", \\\"{x:1548,y:958,t:1527030716416};\\\", \\\"{x:1533,y:958,t:1527030716433};\\\", \\\"{x:1517,y:958,t:1527030716449};\\\", \\\"{x:1510,y:958,t:1527030716466};\\\", \\\"{x:1507,y:958,t:1527030716483};\\\", \\\"{x:1506,y:958,t:1527030716499};\\\", \\\"{x:1506,y:959,t:1527030716524};\\\", \\\"{x:1509,y:959,t:1527030716621};\\\", \\\"{x:1512,y:959,t:1527030716633};\\\", \\\"{x:1517,y:959,t:1527030716650};\\\", \\\"{x:1520,y:959,t:1527030716666};\\\", \\\"{x:1524,y:959,t:1527030716683};\\\", \\\"{x:1527,y:959,t:1527030716700};\\\", \\\"{x:1531,y:959,t:1527030716716};\\\", \\\"{x:1533,y:959,t:1527030716733};\\\", \\\"{x:1534,y:959,t:1527030716750};\\\", \\\"{x:1535,y:959,t:1527030716766};\\\", \\\"{x:1536,y:959,t:1527030716783};\\\", \\\"{x:1537,y:959,t:1527030716860};\\\", \\\"{x:1538,y:959,t:1527030716869};\\\", \\\"{x:1541,y:959,t:1527030716882};\\\", \\\"{x:1550,y:963,t:1527030716901};\\\", \\\"{x:1553,y:965,t:1527030716916};\\\", \\\"{x:1564,y:967,t:1527030716933};\\\", \\\"{x:1567,y:968,t:1527030716950};\\\", \\\"{x:1568,y:969,t:1527030716967};\\\", \\\"{x:1569,y:969,t:1527030717005};\\\", \\\"{x:1571,y:969,t:1527030717016};\\\", \\\"{x:1574,y:969,t:1527030717032};\\\", \\\"{x:1577,y:969,t:1527030717050};\\\", \\\"{x:1578,y:969,t:1527030717067};\\\", \\\"{x:1579,y:969,t:1527030717083};\\\", \\\"{x:1579,y:970,t:1527030717301};\\\", \\\"{x:1575,y:971,t:1527030717316};\\\", \\\"{x:1572,y:972,t:1527030717334};\\\", \\\"{x:1568,y:974,t:1527030717350};\\\", \\\"{x:1557,y:975,t:1527030717367};\\\", \\\"{x:1535,y:975,t:1527030717384};\\\", \\\"{x:1520,y:975,t:1527030717400};\\\", \\\"{x:1513,y:975,t:1527030717417};\\\", \\\"{x:1508,y:975,t:1527030717434};\\\", \\\"{x:1506,y:975,t:1527030717450};\\\", \\\"{x:1505,y:975,t:1527030717541};\\\", \\\"{x:1504,y:975,t:1527030717556};\\\", \\\"{x:1502,y:975,t:1527030717580};\\\", \\\"{x:1499,y:973,t:1527030717645};\\\", \\\"{x:1497,y:972,t:1527030717653};\\\", \\\"{x:1495,y:971,t:1527030717667};\\\", \\\"{x:1487,y:968,t:1527030717684};\\\", \\\"{x:1482,y:966,t:1527030717700};\\\", \\\"{x:1470,y:962,t:1527030717718};\\\", \\\"{x:1464,y:960,t:1527030717734};\\\", \\\"{x:1462,y:959,t:1527030717751};\\\", \\\"{x:1462,y:958,t:1527030717796};\\\", \\\"{x:1460,y:957,t:1527030717845};\\\", \\\"{x:1460,y:956,t:1527030717853};\\\", \\\"{x:1459,y:956,t:1527030717867};\\\", \\\"{x:1459,y:950,t:1527030717884};\\\", \\\"{x:1459,y:948,t:1527030717901};\\\", \\\"{x:1459,y:944,t:1527030717917};\\\", \\\"{x:1459,y:942,t:1527030717934};\\\", \\\"{x:1459,y:941,t:1527030717951};\\\", \\\"{x:1459,y:940,t:1527030717967};\\\", \\\"{x:1459,y:936,t:1527030717984};\\\", \\\"{x:1459,y:933,t:1527030718001};\\\", \\\"{x:1462,y:929,t:1527030718017};\\\", \\\"{x:1462,y:925,t:1527030718034};\\\", \\\"{x:1463,y:923,t:1527030718051};\\\", \\\"{x:1463,y:922,t:1527030718067};\\\", \\\"{x:1463,y:921,t:1527030718084};\\\", \\\"{x:1464,y:920,t:1527030718116};\\\", \\\"{x:1464,y:919,t:1527030718133};\\\", \\\"{x:1464,y:918,t:1527030718156};\\\", \\\"{x:1464,y:916,t:1527030718172};\\\", \\\"{x:1464,y:915,t:1527030718197};\\\", \\\"{x:1464,y:914,t:1527030718212};\\\", \\\"{x:1464,y:913,t:1527030718221};\\\", \\\"{x:1465,y:912,t:1527030718236};\\\", \\\"{x:1466,y:911,t:1527030718251};\\\", \\\"{x:1467,y:907,t:1527030718268};\\\", \\\"{x:1469,y:902,t:1527030718285};\\\", \\\"{x:1474,y:889,t:1527030718301};\\\", \\\"{x:1478,y:879,t:1527030718318};\\\", \\\"{x:1483,y:871,t:1527030718334};\\\", \\\"{x:1483,y:870,t:1527030718351};\\\", \\\"{x:1484,y:869,t:1527030718368};\\\", \\\"{x:1484,y:867,t:1527030718565};\\\", \\\"{x:1485,y:867,t:1527030718572};\\\", \\\"{x:1485,y:866,t:1527030718605};\\\", \\\"{x:1485,y:864,t:1527030718621};\\\", \\\"{x:1485,y:863,t:1527030718636};\\\", \\\"{x:1485,y:861,t:1527030718660};\\\", \\\"{x:1485,y:860,t:1527030718685};\\\", \\\"{x:1486,y:860,t:1527030718700};\\\", \\\"{x:1486,y:854,t:1527030718718};\\\", \\\"{x:1486,y:853,t:1527030718734};\\\", \\\"{x:1487,y:851,t:1527030718750};\\\", \\\"{x:1487,y:850,t:1527030718767};\\\", \\\"{x:1487,y:846,t:1527030718784};\\\", \\\"{x:1487,y:842,t:1527030718800};\\\", \\\"{x:1487,y:841,t:1527030718817};\\\", \\\"{x:1486,y:841,t:1527030719644};\\\", \\\"{x:1484,y:841,t:1527030719667};\\\", \\\"{x:1483,y:841,t:1527030719732};\\\", \\\"{x:1481,y:841,t:1527030720141};\\\", \\\"{x:1479,y:841,t:1527030720152};\\\", \\\"{x:1473,y:841,t:1527030720169};\\\", \\\"{x:1465,y:841,t:1527030720186};\\\", \\\"{x:1459,y:842,t:1527030720203};\\\", \\\"{x:1452,y:844,t:1527030720219};\\\", \\\"{x:1447,y:846,t:1527030720236};\\\", \\\"{x:1444,y:848,t:1527030720253};\\\", \\\"{x:1443,y:848,t:1527030720269};\\\", \\\"{x:1440,y:850,t:1527030720286};\\\", \\\"{x:1437,y:852,t:1527030720303};\\\", \\\"{x:1436,y:853,t:1527030720319};\\\", \\\"{x:1434,y:856,t:1527030720336};\\\", \\\"{x:1432,y:857,t:1527030720353};\\\", \\\"{x:1430,y:859,t:1527030720369};\\\", \\\"{x:1426,y:863,t:1527030720386};\\\", \\\"{x:1423,y:869,t:1527030720403};\\\", \\\"{x:1419,y:875,t:1527030720419};\\\", \\\"{x:1414,y:881,t:1527030720436};\\\", \\\"{x:1412,y:883,t:1527030720453};\\\", \\\"{x:1408,y:886,t:1527030720469};\\\", \\\"{x:1407,y:888,t:1527030720487};\\\", \\\"{x:1406,y:889,t:1527030720503};\\\", \\\"{x:1405,y:889,t:1527030720519};\\\", \\\"{x:1404,y:890,t:1527030720540};\\\", \\\"{x:1402,y:892,t:1527030720553};\\\", \\\"{x:1395,y:895,t:1527030720570};\\\", \\\"{x:1383,y:895,t:1527030720586};\\\", \\\"{x:1368,y:895,t:1527030720604};\\\", \\\"{x:1359,y:895,t:1527030720619};\\\", \\\"{x:1356,y:895,t:1527030720636};\\\", \\\"{x:1355,y:895,t:1527030720709};\\\", \\\"{x:1355,y:893,t:1527030720720};\\\", \\\"{x:1354,y:890,t:1527030720736};\\\", \\\"{x:1354,y:889,t:1527030720753};\\\", \\\"{x:1353,y:884,t:1527030720770};\\\", \\\"{x:1352,y:883,t:1527030720786};\\\", \\\"{x:1352,y:881,t:1527030720803};\\\", \\\"{x:1351,y:875,t:1527030720821};\\\", \\\"{x:1350,y:867,t:1527030720836};\\\", \\\"{x:1349,y:862,t:1527030720853};\\\", \\\"{x:1349,y:859,t:1527030720870};\\\", \\\"{x:1349,y:858,t:1527030720886};\\\", \\\"{x:1349,y:856,t:1527030720903};\\\", \\\"{x:1349,y:855,t:1527030720920};\\\", \\\"{x:1349,y:854,t:1527030720936};\\\", \\\"{x:1349,y:852,t:1527030720953};\\\", \\\"{x:1350,y:850,t:1527030720970};\\\", \\\"{x:1351,y:849,t:1527030720986};\\\", \\\"{x:1352,y:846,t:1527030721003};\\\", \\\"{x:1353,y:844,t:1527030721020};\\\", \\\"{x:1354,y:843,t:1527030721037};\\\", \\\"{x:1354,y:841,t:1527030721157};\\\", \\\"{x:1355,y:839,t:1527030721170};\\\", \\\"{x:1355,y:836,t:1527030721187};\\\", \\\"{x:1355,y:833,t:1527030721203};\\\", \\\"{x:1359,y:813,t:1527030721221};\\\", \\\"{x:1359,y:805,t:1527030721237};\\\", \\\"{x:1359,y:804,t:1527030721253};\\\", \\\"{x:1359,y:802,t:1527030721270};\\\", \\\"{x:1359,y:800,t:1527030721287};\\\", \\\"{x:1359,y:799,t:1527030721303};\\\", \\\"{x:1359,y:797,t:1527030721549};\\\", \\\"{x:1359,y:796,t:1527030721564};\\\", \\\"{x:1359,y:795,t:1527030721572};\\\", \\\"{x:1359,y:794,t:1527030721588};\\\", \\\"{x:1359,y:793,t:1527030721604};\\\", \\\"{x:1358,y:792,t:1527030721620};\\\", \\\"{x:1355,y:789,t:1527030721637};\\\", \\\"{x:1353,y:785,t:1527030721654};\\\", \\\"{x:1352,y:784,t:1527030721670};\\\", \\\"{x:1351,y:783,t:1527030721687};\\\", \\\"{x:1351,y:782,t:1527030721704};\\\", \\\"{x:1350,y:781,t:1527030721720};\\\", \\\"{x:1349,y:781,t:1527030721737};\\\", \\\"{x:1348,y:780,t:1527030722540};\\\", \\\"{x:1347,y:778,t:1527030724060};\\\", \\\"{x:1346,y:775,t:1527030724072};\\\", \\\"{x:1344,y:771,t:1527030724089};\\\", \\\"{x:1342,y:767,t:1527030724106};\\\", \\\"{x:1342,y:764,t:1527030724123};\\\", \\\"{x:1342,y:763,t:1527030724156};\\\", \\\"{x:1342,y:762,t:1527030724189};\\\", \\\"{x:1342,y:763,t:1527030724332};\\\", \\\"{x:1342,y:765,t:1527030724341};\\\", \\\"{x:1342,y:770,t:1527030724356};\\\", \\\"{x:1343,y:775,t:1527030724373};\\\", \\\"{x:1344,y:777,t:1527030724390};\\\", \\\"{x:1344,y:779,t:1527030724406};\\\", \\\"{x:1346,y:781,t:1527030725837};\\\", \\\"{x:1351,y:785,t:1527030725845};\\\", \\\"{x:1358,y:790,t:1527030725857};\\\", \\\"{x:1371,y:797,t:1527030725875};\\\", \\\"{x:1393,y:808,t:1527030725890};\\\", \\\"{x:1413,y:817,t:1527030725907};\\\", \\\"{x:1439,y:828,t:1527030725925};\\\", \\\"{x:1454,y:835,t:1527030725940};\\\", \\\"{x:1465,y:842,t:1527030725957};\\\", \\\"{x:1469,y:846,t:1527030725974};\\\", \\\"{x:1471,y:848,t:1527030725991};\\\", \\\"{x:1476,y:856,t:1527030726007};\\\", \\\"{x:1483,y:864,t:1527030726024};\\\", \\\"{x:1500,y:880,t:1527030726041};\\\", \\\"{x:1521,y:896,t:1527030726058};\\\", \\\"{x:1541,y:911,t:1527030726075};\\\", \\\"{x:1561,y:922,t:1527030726091};\\\", \\\"{x:1581,y:931,t:1527030726107};\\\", \\\"{x:1594,y:937,t:1527030726124};\\\", \\\"{x:1596,y:938,t:1527030726141};\\\", \\\"{x:1598,y:940,t:1527030726157};\\\", \\\"{x:1599,y:943,t:1527030726174};\\\", \\\"{x:1600,y:944,t:1527030726191};\\\", \\\"{x:1602,y:945,t:1527030726208};\\\", \\\"{x:1603,y:947,t:1527030726224};\\\", \\\"{x:1604,y:948,t:1527030726244};\\\", \\\"{x:1605,y:948,t:1527030726267};\\\", \\\"{x:1606,y:949,t:1527030726300};\\\", \\\"{x:1607,y:949,t:1527030726324};\\\", \\\"{x:1608,y:950,t:1527030726341};\\\", \\\"{x:1609,y:950,t:1527030726358};\\\", \\\"{x:1610,y:951,t:1527030726373};\\\", \\\"{x:1612,y:952,t:1527030726391};\\\", \\\"{x:1613,y:953,t:1527030726408};\\\", \\\"{x:1614,y:953,t:1527030726424};\\\", \\\"{x:1614,y:954,t:1527030726441};\\\", \\\"{x:1615,y:954,t:1527030726477};\\\", \\\"{x:1616,y:954,t:1527030726492};\\\", \\\"{x:1617,y:955,t:1527030726509};\\\", \\\"{x:1618,y:956,t:1527030726525};\\\", \\\"{x:1618,y:958,t:1527030726541};\\\", \\\"{x:1618,y:959,t:1527030726558};\\\", \\\"{x:1618,y:957,t:1527030728117};\\\", \\\"{x:1618,y:955,t:1527030728127};\\\", \\\"{x:1618,y:952,t:1527030728143};\\\", \\\"{x:1618,y:948,t:1527030728159};\\\", \\\"{x:1617,y:941,t:1527030728176};\\\", \\\"{x:1616,y:935,t:1527030728192};\\\", \\\"{x:1615,y:930,t:1527030728209};\\\", \\\"{x:1615,y:924,t:1527030728226};\\\", \\\"{x:1612,y:912,t:1527030728242};\\\", \\\"{x:1612,y:907,t:1527030728259};\\\", \\\"{x:1611,y:901,t:1527030728277};\\\", \\\"{x:1610,y:900,t:1527030728292};\\\", \\\"{x:1609,y:899,t:1527030728324};\\\", \\\"{x:1609,y:898,t:1527030728340};\\\", \\\"{x:1608,y:896,t:1527030728348};\\\", \\\"{x:1608,y:894,t:1527030728360};\\\", \\\"{x:1607,y:890,t:1527030728376};\\\", \\\"{x:1604,y:885,t:1527030728393};\\\", \\\"{x:1600,y:878,t:1527030728410};\\\", \\\"{x:1596,y:872,t:1527030728427};\\\", \\\"{x:1595,y:870,t:1527030728443};\\\", \\\"{x:1593,y:868,t:1527030728459};\\\", \\\"{x:1593,y:867,t:1527030728517};\\\", \\\"{x:1592,y:865,t:1527030728532};\\\", \\\"{x:1592,y:863,t:1527030728543};\\\", \\\"{x:1590,y:858,t:1527030728559};\\\", \\\"{x:1588,y:854,t:1527030728576};\\\", \\\"{x:1585,y:850,t:1527030728594};\\\", \\\"{x:1581,y:841,t:1527030728609};\\\", \\\"{x:1575,y:830,t:1527030728627};\\\", \\\"{x:1570,y:824,t:1527030728644};\\\", \\\"{x:1563,y:818,t:1527030728660};\\\", \\\"{x:1557,y:810,t:1527030728676};\\\", \\\"{x:1550,y:800,t:1527030728694};\\\", \\\"{x:1546,y:797,t:1527030728710};\\\", \\\"{x:1544,y:796,t:1527030728726};\\\", \\\"{x:1541,y:793,t:1527030728744};\\\", \\\"{x:1538,y:790,t:1527030728760};\\\", \\\"{x:1537,y:789,t:1527030728777};\\\", \\\"{x:1536,y:789,t:1527030728793};\\\", \\\"{x:1535,y:788,t:1527030728810};\\\", \\\"{x:1534,y:787,t:1527030728828};\\\", \\\"{x:1534,y:786,t:1527030728852};\\\", \\\"{x:1534,y:785,t:1527030728860};\\\", \\\"{x:1533,y:784,t:1527030728884};\\\", \\\"{x:1533,y:783,t:1527030728893};\\\", \\\"{x:1532,y:783,t:1527030728910};\\\", \\\"{x:1532,y:782,t:1527030728939};\\\", \\\"{x:1531,y:782,t:1527030729020};\\\", \\\"{x:1530,y:782,t:1527030734093};\\\", \\\"{x:1523,y:783,t:1527030734100};\\\", \\\"{x:1511,y:787,t:1527030734115};\\\", \\\"{x:1472,y:792,t:1527030734131};\\\", \\\"{x:1417,y:797,t:1527030734147};\\\", \\\"{x:1314,y:797,t:1527030734164};\\\", \\\"{x:1228,y:797,t:1527030734181};\\\", \\\"{x:1131,y:797,t:1527030734198};\\\", \\\"{x:1031,y:797,t:1527030734215};\\\", \\\"{x:926,y:797,t:1527030734232};\\\", \\\"{x:834,y:797,t:1527030734247};\\\", \\\"{x:748,y:797,t:1527030734265};\\\", \\\"{x:682,y:797,t:1527030734281};\\\", \\\"{x:620,y:797,t:1527030734298};\\\", \\\"{x:551,y:797,t:1527030734315};\\\", \\\"{x:500,y:797,t:1527030734332};\\\", \\\"{x:470,y:800,t:1527030734348};\\\", \\\"{x:468,y:801,t:1527030734364};\\\", \\\"{x:467,y:801,t:1527030734388};\\\", \\\"{x:466,y:802,t:1527030734412};\\\", \\\"{x:466,y:800,t:1527030734452};\\\", \\\"{x:465,y:797,t:1527030734464};\\\", \\\"{x:464,y:783,t:1527030734482};\\\", \\\"{x:461,y:771,t:1527030734498};\\\", \\\"{x:461,y:768,t:1527030734515};\\\", \\\"{x:461,y:766,t:1527030734531};\\\", \\\"{x:464,y:762,t:1527030734547};\\\", \\\"{x:467,y:760,t:1527030734564};\\\", \\\"{x:475,y:758,t:1527030734581};\\\", \\\"{x:480,y:756,t:1527030734598};\\\", \\\"{x:485,y:755,t:1527030734614};\\\", \\\"{x:486,y:753,t:1527030734631};\\\", \\\"{x:487,y:753,t:1527030734648};\\\", \\\"{x:488,y:752,t:1527030734664};\\\", \\\"{x:490,y:752,t:1527030734680};\\\", \\\"{x:492,y:750,t:1527030734697};\\\", \\\"{x:498,y:745,t:1527030734713};\\\", \\\"{x:500,y:743,t:1527030734730};\\\", \\\"{x:501,y:741,t:1527030734747};\\\", \\\"{x:502,y:741,t:1527030735986};\\\" ] }, { \\\"rt\\\": 8680, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 700273, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-01 PM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:740,t:1527030736363};\\\", \\\"{x:502,y:737,t:1527030736371};\\\", \\\"{x:502,y:736,t:1527030736688};\\\", \\\"{x:501,y:736,t:1527030736699};\\\", \\\"{x:497,y:736,t:1527030736729};\\\", \\\"{x:496,y:736,t:1527030736731};\\\", \\\"{x:493,y:737,t:1527030736748};\\\", \\\"{x:491,y:737,t:1527030736764};\\\", \\\"{x:485,y:740,t:1527030736781};\\\", \\\"{x:482,y:741,t:1527030736798};\\\", \\\"{x:481,y:741,t:1527030736819};\\\", \\\"{x:485,y:741,t:1527030737036};\\\", \\\"{x:494,y:737,t:1527030737049};\\\", \\\"{x:506,y:732,t:1527030737064};\\\", \\\"{x:509,y:731,t:1527030737082};\\\", \\\"{x:509,y:730,t:1527030737124};\\\", \\\"{x:510,y:729,t:1527030737132};\\\", \\\"{x:512,y:729,t:1527030737148};\\\", \\\"{x:513,y:727,t:1527030737164};\\\", \\\"{x:515,y:727,t:1527030737637};\\\", \\\"{x:516,y:726,t:1527030737649};\\\", \\\"{x:520,y:724,t:1527030737665};\\\", \\\"{x:523,y:722,t:1527030737681};\\\", \\\"{x:524,y:721,t:1527030737698};\\\", \\\"{x:527,y:719,t:1527030737716};\\\", \\\"{x:532,y:717,t:1527030737732};\\\", \\\"{x:544,y:713,t:1527030737748};\\\", \\\"{x:554,y:710,t:1527030737765};\\\", \\\"{x:563,y:707,t:1527030737782};\\\", \\\"{x:572,y:705,t:1527030737800};\\\", \\\"{x:577,y:703,t:1527030737815};\\\", \\\"{x:579,y:702,t:1527030737832};\\\", \\\"{x:582,y:701,t:1527030737850};\\\", \\\"{x:586,y:699,t:1527030737865};\\\", \\\"{x:590,y:698,t:1527030737882};\\\", \\\"{x:598,y:695,t:1527030737900};\\\", \\\"{x:603,y:694,t:1527030737916};\\\", \\\"{x:604,y:694,t:1527030737932};\\\", \\\"{x:604,y:693,t:1527030737950};\\\", \\\"{x:605,y:693,t:1527030737972};\\\", \\\"{x:605,y:692,t:1527030738100};\\\", \\\"{x:606,y:691,t:1527030738124};\\\", \\\"{x:607,y:691,t:1527030738140};\\\", \\\"{x:608,y:691,t:1527030738150};\\\", \\\"{x:611,y:689,t:1527030738167};\\\", \\\"{x:615,y:688,t:1527030738182};\\\", \\\"{x:621,y:688,t:1527030738200};\\\", \\\"{x:626,y:687,t:1527030738217};\\\", \\\"{x:637,y:684,t:1527030738233};\\\", \\\"{x:656,y:683,t:1527030738250};\\\", \\\"{x:683,y:682,t:1527030738267};\\\", \\\"{x:711,y:682,t:1527030738282};\\\", \\\"{x:769,y:682,t:1527030738300};\\\", \\\"{x:841,y:682,t:1527030738316};\\\", \\\"{x:910,y:682,t:1527030738333};\\\", \\\"{x:969,y:682,t:1527030738350};\\\", \\\"{x:1006,y:682,t:1527030738367};\\\", \\\"{x:1028,y:682,t:1527030738383};\\\", \\\"{x:1043,y:682,t:1527030738400};\\\", \\\"{x:1061,y:682,t:1527030738417};\\\", \\\"{x:1067,y:682,t:1527030738433};\\\", \\\"{x:1069,y:682,t:1527030738450};\\\", \\\"{x:1071,y:679,t:1527030738484};\\\", \\\"{x:1072,y:679,t:1527030738500};\\\", \\\"{x:1077,y:676,t:1527030738517};\\\", \\\"{x:1094,y:675,t:1527030738533};\\\", \\\"{x:1121,y:675,t:1527030738550};\\\", \\\"{x:1153,y:676,t:1527030738567};\\\", \\\"{x:1193,y:687,t:1527030738583};\\\", \\\"{x:1239,y:705,t:1527030738600};\\\", \\\"{x:1302,y:730,t:1527030738617};\\\", \\\"{x:1370,y:755,t:1527030738633};\\\", \\\"{x:1422,y:776,t:1527030738650};\\\", \\\"{x:1463,y:791,t:1527030738667};\\\", \\\"{x:1495,y:804,t:1527030738683};\\\", \\\"{x:1532,y:820,t:1527030738700};\\\", \\\"{x:1552,y:830,t:1527030738717};\\\", \\\"{x:1571,y:842,t:1527030738733};\\\", \\\"{x:1584,y:852,t:1527030738750};\\\", \\\"{x:1587,y:856,t:1527030738767};\\\", \\\"{x:1587,y:860,t:1527030738783};\\\", \\\"{x:1587,y:863,t:1527030738800};\\\", \\\"{x:1589,y:872,t:1527030738817};\\\", \\\"{x:1589,y:882,t:1527030738834};\\\", \\\"{x:1589,y:894,t:1527030738850};\\\", \\\"{x:1589,y:909,t:1527030738867};\\\", \\\"{x:1586,y:931,t:1527030738884};\\\", \\\"{x:1582,y:940,t:1527030738900};\\\", \\\"{x:1579,y:945,t:1527030738917};\\\", \\\"{x:1578,y:948,t:1527030738934};\\\", \\\"{x:1576,y:952,t:1527030738950};\\\", \\\"{x:1574,y:955,t:1527030738967};\\\", \\\"{x:1574,y:956,t:1527030738996};\\\", \\\"{x:1573,y:956,t:1527030739004};\\\", \\\"{x:1571,y:957,t:1527030739017};\\\", \\\"{x:1567,y:960,t:1527030739034};\\\", \\\"{x:1563,y:962,t:1527030739050};\\\", \\\"{x:1562,y:963,t:1527030739068};\\\", \\\"{x:1557,y:966,t:1527030739084};\\\", \\\"{x:1555,y:966,t:1527030739100};\\\", \\\"{x:1552,y:967,t:1527030739117};\\\", \\\"{x:1547,y:969,t:1527030739134};\\\", \\\"{x:1537,y:970,t:1527030739150};\\\", \\\"{x:1525,y:972,t:1527030739168};\\\", \\\"{x:1516,y:974,t:1527030739184};\\\", \\\"{x:1510,y:974,t:1527030739199};\\\", \\\"{x:1503,y:975,t:1527030739217};\\\", \\\"{x:1500,y:975,t:1527030739234};\\\", \\\"{x:1499,y:975,t:1527030739250};\\\", \\\"{x:1497,y:975,t:1527030739266};\\\", \\\"{x:1489,y:975,t:1527030739284};\\\", \\\"{x:1473,y:975,t:1527030739300};\\\", \\\"{x:1451,y:974,t:1527030739318};\\\", \\\"{x:1429,y:972,t:1527030739335};\\\", \\\"{x:1410,y:968,t:1527030739351};\\\", \\\"{x:1400,y:967,t:1527030739367};\\\", \\\"{x:1397,y:966,t:1527030739384};\\\", \\\"{x:1396,y:965,t:1527030739469};\\\", \\\"{x:1394,y:965,t:1527030739484};\\\", \\\"{x:1391,y:965,t:1527030739501};\\\", \\\"{x:1389,y:965,t:1527030739517};\\\", \\\"{x:1387,y:965,t:1527030739612};\\\", \\\"{x:1386,y:965,t:1527030739620};\\\", \\\"{x:1383,y:965,t:1527030739634};\\\", \\\"{x:1382,y:965,t:1527030739651};\\\", \\\"{x:1381,y:965,t:1527030739667};\\\", \\\"{x:1380,y:965,t:1527030739701};\\\", \\\"{x:1379,y:965,t:1527030739781};\\\", \\\"{x:1378,y:965,t:1527030739789};\\\", \\\"{x:1376,y:965,t:1527030739860};\\\", \\\"{x:1373,y:965,t:1527030739868};\\\", \\\"{x:1370,y:966,t:1527030739883};\\\", \\\"{x:1365,y:968,t:1527030739901};\\\", \\\"{x:1364,y:968,t:1527030739932};\\\", \\\"{x:1363,y:968,t:1527030739964};\\\", \\\"{x:1363,y:969,t:1527030740076};\\\", \\\"{x:1362,y:969,t:1527030740083};\\\", \\\"{x:1361,y:971,t:1527030740101};\\\", \\\"{x:1357,y:971,t:1527030740118};\\\", \\\"{x:1355,y:971,t:1527030740134};\\\", \\\"{x:1350,y:971,t:1527030740151};\\\", \\\"{x:1347,y:971,t:1527030740168};\\\", \\\"{x:1344,y:971,t:1527030740184};\\\", \\\"{x:1344,y:970,t:1527030740405};\\\", \\\"{x:1344,y:969,t:1527030740444};\\\", \\\"{x:1344,y:968,t:1527030740469};\\\", \\\"{x:1344,y:966,t:1527030740484};\\\", \\\"{x:1344,y:965,t:1527030740501};\\\", \\\"{x:1344,y:963,t:1527030740518};\\\", \\\"{x:1344,y:961,t:1527030740535};\\\", \\\"{x:1344,y:959,t:1527030740551};\\\", \\\"{x:1344,y:957,t:1527030740568};\\\", \\\"{x:1344,y:955,t:1527030740584};\\\", \\\"{x:1344,y:951,t:1527030740602};\\\", \\\"{x:1344,y:945,t:1527030740618};\\\", \\\"{x:1344,y:938,t:1527030740634};\\\", \\\"{x:1344,y:932,t:1527030740651};\\\", \\\"{x:1344,y:920,t:1527030740668};\\\", \\\"{x:1344,y:912,t:1527030740684};\\\", \\\"{x:1344,y:903,t:1527030740702};\\\", \\\"{x:1344,y:891,t:1527030740719};\\\", \\\"{x:1344,y:866,t:1527030740734};\\\", \\\"{x:1346,y:839,t:1527030740751};\\\", \\\"{x:1347,y:812,t:1527030740768};\\\", \\\"{x:1349,y:794,t:1527030740785};\\\", \\\"{x:1349,y:780,t:1527030740801};\\\", \\\"{x:1349,y:773,t:1527030740818};\\\", \\\"{x:1349,y:767,t:1527030740838};\\\", \\\"{x:1351,y:761,t:1527030740851};\\\", \\\"{x:1352,y:755,t:1527030740868};\\\", \\\"{x:1353,y:752,t:1527030740884};\\\", \\\"{x:1353,y:751,t:1527030740901};\\\", \\\"{x:1353,y:749,t:1527030740918};\\\", \\\"{x:1353,y:748,t:1527030740939};\\\", \\\"{x:1353,y:747,t:1527030740972};\\\", \\\"{x:1353,y:746,t:1527030740985};\\\", \\\"{x:1353,y:742,t:1527030741000};\\\", \\\"{x:1353,y:737,t:1527030741017};\\\", \\\"{x:1353,y:729,t:1527030741035};\\\", \\\"{x:1353,y:725,t:1527030741050};\\\", \\\"{x:1353,y:721,t:1527030741068};\\\", \\\"{x:1353,y:720,t:1527030741084};\\\", \\\"{x:1353,y:717,t:1527030741101};\\\", \\\"{x:1353,y:716,t:1527030741118};\\\", \\\"{x:1355,y:713,t:1527030741135};\\\", \\\"{x:1355,y:712,t:1527030741151};\\\", \\\"{x:1355,y:711,t:1527030741204};\\\", \\\"{x:1355,y:710,t:1527030741237};\\\", \\\"{x:1355,y:709,t:1527030741260};\\\", \\\"{x:1354,y:708,t:1527030741389};\\\", \\\"{x:1349,y:708,t:1527030741401};\\\", \\\"{x:1327,y:714,t:1527030741417};\\\", \\\"{x:1268,y:724,t:1527030741435};\\\", \\\"{x:1131,y:741,t:1527030741452};\\\", \\\"{x:1034,y:755,t:1527030741468};\\\", \\\"{x:950,y:768,t:1527030741485};\\\", \\\"{x:869,y:781,t:1527030741501};\\\", \\\"{x:786,y:792,t:1527030741518};\\\", \\\"{x:709,y:801,t:1527030741535};\\\", \\\"{x:619,y:807,t:1527030741551};\\\", \\\"{x:538,y:807,t:1527030741568};\\\", \\\"{x:479,y:807,t:1527030741585};\\\", \\\"{x:443,y:804,t:1527030741602};\\\", \\\"{x:420,y:800,t:1527030741618};\\\", \\\"{x:397,y:798,t:1527030741635};\\\", \\\"{x:352,y:789,t:1527030741652};\\\", \\\"{x:318,y:780,t:1527030741667};\\\", \\\"{x:283,y:766,t:1527030741685};\\\", \\\"{x:262,y:756,t:1527030741701};\\\", \\\"{x:242,y:745,t:1527030741718};\\\", \\\"{x:223,y:734,t:1527030741735};\\\", \\\"{x:209,y:722,t:1527030741752};\\\", \\\"{x:192,y:705,t:1527030741768};\\\", \\\"{x:178,y:687,t:1527030741785};\\\", \\\"{x:160,y:674,t:1527030741802};\\\", \\\"{x:149,y:667,t:1527030741820};\\\", \\\"{x:144,y:663,t:1527030741834};\\\", \\\"{x:143,y:660,t:1527030741851};\\\", \\\"{x:142,y:656,t:1527030741869};\\\", \\\"{x:142,y:652,t:1527030741886};\\\", \\\"{x:141,y:649,t:1527030741902};\\\", \\\"{x:140,y:647,t:1527030741919};\\\", \\\"{x:140,y:644,t:1527030741935};\\\", \\\"{x:139,y:641,t:1527030741952};\\\", \\\"{x:139,y:636,t:1527030741970};\\\", \\\"{x:139,y:631,t:1527030741987};\\\", \\\"{x:139,y:623,t:1527030742002};\\\", \\\"{x:141,y:608,t:1527030742019};\\\", \\\"{x:142,y:601,t:1527030742036};\\\", \\\"{x:143,y:592,t:1527030742053};\\\", \\\"{x:143,y:587,t:1527030742069};\\\", \\\"{x:143,y:582,t:1527030742086};\\\", \\\"{x:143,y:581,t:1527030742103};\\\", \\\"{x:143,y:580,t:1527030742120};\\\", \\\"{x:143,y:579,t:1527030742137};\\\", \\\"{x:143,y:578,t:1527030742153};\\\", \\\"{x:143,y:576,t:1527030742170};\\\", \\\"{x:144,y:569,t:1527030742188};\\\", \\\"{x:144,y:567,t:1527030742203};\\\", \\\"{x:144,y:564,t:1527030742219};\\\", \\\"{x:144,y:562,t:1527030742237};\\\", \\\"{x:144,y:561,t:1527030742252};\\\", \\\"{x:144,y:558,t:1527030742269};\\\", \\\"{x:144,y:556,t:1527030742286};\\\", \\\"{x:144,y:554,t:1527030742303};\\\", \\\"{x:145,y:552,t:1527030742387};\\\", \\\"{x:146,y:552,t:1527030742403};\\\", \\\"{x:148,y:549,t:1527030742419};\\\", \\\"{x:149,y:548,t:1527030742437};\\\", \\\"{x:150,y:547,t:1527030742454};\\\", \\\"{x:151,y:547,t:1527030742469};\\\", \\\"{x:156,y:546,t:1527030742892};\\\", \\\"{x:186,y:539,t:1527030742905};\\\", \\\"{x:299,y:512,t:1527030742922};\\\", \\\"{x:413,y:496,t:1527030742937};\\\", \\\"{x:518,y:482,t:1527030742954};\\\", \\\"{x:618,y:468,t:1527030742971};\\\", \\\"{x:718,y:460,t:1527030742986};\\\", \\\"{x:740,y:458,t:1527030743003};\\\", \\\"{x:750,y:457,t:1527030743020};\\\", \\\"{x:753,y:456,t:1527030743036};\\\", \\\"{x:760,y:453,t:1527030743053};\\\", \\\"{x:772,y:449,t:1527030743070};\\\", \\\"{x:797,y:444,t:1527030743087};\\\", \\\"{x:835,y:432,t:1527030743104};\\\", \\\"{x:868,y:424,t:1527030743120};\\\", \\\"{x:889,y:422,t:1527030743137};\\\", \\\"{x:895,y:422,t:1527030743153};\\\", \\\"{x:896,y:422,t:1527030743171};\\\", \\\"{x:900,y:423,t:1527030743188};\\\", \\\"{x:900,y:425,t:1527030743204};\\\", \\\"{x:903,y:425,t:1527030743221};\\\", \\\"{x:909,y:429,t:1527030743237};\\\", \\\"{x:916,y:432,t:1527030743254};\\\", \\\"{x:921,y:437,t:1527030743271};\\\", \\\"{x:925,y:443,t:1527030743287};\\\", \\\"{x:928,y:448,t:1527030743304};\\\", \\\"{x:930,y:453,t:1527030743321};\\\", \\\"{x:930,y:459,t:1527030743338};\\\", \\\"{x:930,y:468,t:1527030743354};\\\", \\\"{x:922,y:481,t:1527030743371};\\\", \\\"{x:907,y:495,t:1527030743390};\\\", \\\"{x:896,y:500,t:1527030743403};\\\", \\\"{x:885,y:501,t:1527030743420};\\\", \\\"{x:878,y:501,t:1527030743437};\\\", \\\"{x:875,y:501,t:1527030743455};\\\", \\\"{x:874,y:502,t:1527030743470};\\\", \\\"{x:872,y:502,t:1527030743563};\\\", \\\"{x:870,y:502,t:1527030743572};\\\", \\\"{x:861,y:502,t:1527030743588};\\\", \\\"{x:844,y:501,t:1527030743605};\\\", \\\"{x:822,y:498,t:1527030743622};\\\", \\\"{x:807,y:497,t:1527030743638};\\\", \\\"{x:800,y:496,t:1527030743654};\\\", \\\"{x:798,y:495,t:1527030743671};\\\", \\\"{x:799,y:495,t:1527030743804};\\\", \\\"{x:803,y:495,t:1527030743821};\\\", \\\"{x:807,y:497,t:1527030743838};\\\", \\\"{x:808,y:497,t:1527030743855};\\\", \\\"{x:811,y:497,t:1527030743871};\\\", \\\"{x:814,y:497,t:1527030743888};\\\", \\\"{x:817,y:498,t:1527030743905};\\\", \\\"{x:820,y:498,t:1527030743921};\\\", \\\"{x:821,y:498,t:1527030743938};\\\", \\\"{x:824,y:498,t:1527030743955};\\\", \\\"{x:827,y:498,t:1527030743972};\\\", \\\"{x:828,y:498,t:1527030744003};\\\", \\\"{x:829,y:498,t:1527030744043};\\\", \\\"{x:830,y:498,t:1527030744171};\\\", \\\"{x:830,y:499,t:1527030744203};\\\", \\\"{x:830,y:500,t:1527030744211};\\\", \\\"{x:828,y:501,t:1527030744236};\\\", \\\"{x:826,y:503,t:1527030744251};\\\", \\\"{x:825,y:505,t:1527030744268};\\\", \\\"{x:823,y:506,t:1527030744275};\\\", \\\"{x:821,y:509,t:1527030744287};\\\", \\\"{x:815,y:516,t:1527030744304};\\\", \\\"{x:803,y:537,t:1527030744322};\\\", \\\"{x:783,y:561,t:1527030744338};\\\", \\\"{x:747,y:612,t:1527030744355};\\\", \\\"{x:678,y:691,t:1527030744371};\\\", \\\"{x:647,y:715,t:1527030744388};\\\", \\\"{x:630,y:727,t:1527030744405};\\\", \\\"{x:619,y:735,t:1527030744422};\\\", \\\"{x:612,y:739,t:1527030744438};\\\", \\\"{x:609,y:740,t:1527030744455};\\\", \\\"{x:604,y:743,t:1527030744471};\\\", \\\"{x:602,y:743,t:1527030744487};\\\", \\\"{x:601,y:744,t:1527030744505};\\\", \\\"{x:598,y:744,t:1527030744548};\\\", \\\"{x:594,y:744,t:1527030744556};\\\", \\\"{x:577,y:744,t:1527030744571};\\\", \\\"{x:562,y:744,t:1527030744588};\\\", \\\"{x:551,y:744,t:1527030744604};\\\", \\\"{x:547,y:744,t:1527030744621};\\\", \\\"{x:544,y:744,t:1527030744639};\\\", \\\"{x:543,y:744,t:1527030744655};\\\", \\\"{x:542,y:744,t:1527030744671};\\\", \\\"{x:540,y:742,t:1527030744688};\\\" ] }, { \\\"rt\\\": 6096, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 707586, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:742,t:1527030747221};\\\", \\\"{x:545,y:742,t:1527030747235};\\\", \\\"{x:546,y:742,t:1527030747243};\\\", \\\"{x:549,y:742,t:1527030747257};\\\", \\\"{x:552,y:742,t:1527030747273};\\\", \\\"{x:553,y:742,t:1527030747290};\\\", \\\"{x:556,y:742,t:1527030747307};\\\", \\\"{x:560,y:742,t:1527030747323};\\\", \\\"{x:563,y:742,t:1527030747340};\\\", \\\"{x:567,y:742,t:1527030747357};\\\", \\\"{x:570,y:742,t:1527030747373};\\\", \\\"{x:572,y:742,t:1527030747391};\\\", \\\"{x:574,y:742,t:1527030747406};\\\", \\\"{x:575,y:742,t:1527030747423};\\\", \\\"{x:576,y:742,t:1527030747441};\\\", \\\"{x:577,y:742,t:1527030747457};\\\", \\\"{x:578,y:742,t:1527030747474};\\\", \\\"{x:579,y:742,t:1527030747492};\\\", \\\"{x:580,y:742,t:1527030747507};\\\", \\\"{x:583,y:742,t:1527030747523};\\\", \\\"{x:586,y:741,t:1527030748004};\\\", \\\"{x:586,y:740,t:1527030748012};\\\", \\\"{x:586,y:737,t:1527030748024};\\\", \\\"{x:586,y:729,t:1527030748041};\\\", \\\"{x:583,y:719,t:1527030748058};\\\", \\\"{x:573,y:700,t:1527030748074};\\\", \\\"{x:554,y:672,t:1527030748092};\\\", \\\"{x:517,y:637,t:1527030748108};\\\", \\\"{x:489,y:623,t:1527030748125};\\\", \\\"{x:462,y:612,t:1527030748141};\\\", \\\"{x:417,y:579,t:1527030748158};\\\", \\\"{x:382,y:560,t:1527030748174};\\\", \\\"{x:366,y:555,t:1527030748191};\\\", \\\"{x:361,y:554,t:1527030748207};\\\", \\\"{x:358,y:554,t:1527030748224};\\\", \\\"{x:354,y:554,t:1527030748241};\\\", \\\"{x:343,y:554,t:1527030748258};\\\", \\\"{x:328,y:554,t:1527030748275};\\\", \\\"{x:310,y:554,t:1527030748291};\\\", \\\"{x:284,y:554,t:1527030748307};\\\", \\\"{x:265,y:554,t:1527030748326};\\\", \\\"{x:249,y:554,t:1527030748341};\\\", \\\"{x:232,y:554,t:1527030748358};\\\", \\\"{x:218,y:554,t:1527030748374};\\\", \\\"{x:212,y:555,t:1527030748391};\\\", \\\"{x:211,y:555,t:1527030748500};\\\", \\\"{x:209,y:554,t:1527030748508};\\\", \\\"{x:204,y:550,t:1527030748524};\\\", \\\"{x:193,y:545,t:1527030748541};\\\", \\\"{x:182,y:538,t:1527030748559};\\\", \\\"{x:175,y:533,t:1527030748574};\\\", \\\"{x:172,y:533,t:1527030748591};\\\", \\\"{x:170,y:532,t:1527030748608};\\\", \\\"{x:177,y:533,t:1527030749117};\\\", \\\"{x:190,y:537,t:1527030749125};\\\", \\\"{x:231,y:550,t:1527030749143};\\\", \\\"{x:294,y:572,t:1527030749160};\\\", \\\"{x:371,y:592,t:1527030749175};\\\", \\\"{x:442,y:620,t:1527030749193};\\\", \\\"{x:503,y:646,t:1527030749210};\\\", \\\"{x:534,y:661,t:1527030749225};\\\", \\\"{x:550,y:671,t:1527030749242};\\\", \\\"{x:556,y:676,t:1527030749259};\\\", \\\"{x:557,y:678,t:1527030749275};\\\", \\\"{x:558,y:678,t:1527030749291};\\\", \\\"{x:558,y:680,t:1527030749331};\\\", \\\"{x:557,y:682,t:1527030749347};\\\", \\\"{x:556,y:683,t:1527030749358};\\\", \\\"{x:554,y:687,t:1527030749375};\\\", \\\"{x:553,y:688,t:1527030749393};\\\", \\\"{x:553,y:690,t:1527030749428};\\\", \\\"{x:553,y:691,t:1527030749444};\\\", \\\"{x:553,y:692,t:1527030749460};\\\", \\\"{x:553,y:694,t:1527030749475};\\\", \\\"{x:554,y:695,t:1527030749492};\\\", \\\"{x:554,y:698,t:1527030749508};\\\", \\\"{x:554,y:700,t:1527030749525};\\\", \\\"{x:555,y:701,t:1527030749540};\\\", \\\"{x:555,y:704,t:1527030749558};\\\", \\\"{x:556,y:707,t:1527030749574};\\\", \\\"{x:556,y:708,t:1527030749595};\\\", \\\"{x:556,y:709,t:1527030749611};\\\", \\\"{x:556,y:710,t:1527030749625};\\\", \\\"{x:556,y:711,t:1527030749643};\\\", \\\"{x:556,y:712,t:1527030749659};\\\", \\\"{x:556,y:713,t:1527030749675};\\\", \\\"{x:556,y:714,t:1527030749691};\\\", \\\"{x:556,y:715,t:1527030749708};\\\", \\\"{x:556,y:716,t:1527030750093};\\\", \\\"{x:556,y:717,t:1527030750124};\\\", \\\"{x:556,y:718,t:1527030750164};\\\", \\\"{x:556,y:719,t:1527030750380};\\\", \\\"{x:556,y:720,t:1527030750405};\\\", \\\"{x:556,y:721,t:1527030750428};\\\", \\\"{x:557,y:722,t:1527030750484};\\\", \\\"{x:557,y:723,t:1527030750523};\\\", \\\"{x:558,y:723,t:1527030750532};\\\", \\\"{x:558,y:725,t:1527030750556};\\\", \\\"{x:559,y:726,t:1527030750716};\\\", \\\"{x:559,y:727,t:1527030750740};\\\", \\\"{x:559,y:728,t:1527030750764};\\\", \\\"{x:559,y:729,t:1527030750788};\\\", \\\"{x:559,y:730,t:1527030750836};\\\", \\\"{x:559,y:731,t:1527030750851};\\\", \\\"{x:559,y:732,t:1527030750892};\\\", \\\"{x:559,y:733,t:1527030750908};\\\", \\\"{x:559,y:734,t:1527030750916};\\\", \\\"{x:559,y:735,t:1527030750948};\\\", \\\"{x:559,y:736,t:1527030750972};\\\", \\\"{x:558,y:736,t:1527030750988};\\\", \\\"{x:558,y:737,t:1527030751004};\\\", \\\"{x:558,y:738,t:1527030751035};\\\", \\\"{x:558,y:739,t:1527030751068};\\\", \\\"{x:558,y:740,t:1527030751092};\\\", \\\"{x:558,y:741,t:1527030751132};\\\", \\\"{x:557,y:742,t:1527030751148};\\\", \\\"{x:557,y:743,t:1527030751212};\\\", \\\"{x:557,y:744,t:1527030751340};\\\", \\\"{x:557,y:745,t:1527030751437};\\\", \\\"{x:557,y:746,t:1527030751451};\\\", \\\"{x:557,y:747,t:1527030751475};\\\", \\\"{x:556,y:749,t:1527030751484};\\\", \\\"{x:556,y:750,t:1527030751500};\\\", \\\"{x:555,y:750,t:1527030751511};\\\", \\\"{x:555,y:751,t:1527030751529};\\\", \\\"{x:554,y:752,t:1527030751545};\\\", \\\"{x:554,y:753,t:1527030751563};\\\", \\\"{x:554,y:752,t:1527030751892};\\\", \\\"{x:554,y:751,t:1527030751916};\\\", \\\"{x:554,y:750,t:1527030751932};\\\", \\\"{x:554,y:749,t:1527030751946};\\\", \\\"{x:554,y:748,t:1527030751979};\\\", \\\"{x:554,y:747,t:1527030752003};\\\" ] }, { \\\"rt\\\": 29276, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 738085, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-F -F -M -M -12 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:556,y:746,t:1527030757708};\\\", \\\"{x:558,y:745,t:1527030757715};\\\", \\\"{x:565,y:739,t:1527030768160};\\\", \\\"{x:591,y:699,t:1527030768174};\\\", \\\"{x:613,y:674,t:1527030768191};\\\", \\\"{x:625,y:656,t:1527030768209};\\\", \\\"{x:633,y:645,t:1527030768226};\\\", \\\"{x:635,y:643,t:1527030768243};\\\", \\\"{x:635,y:642,t:1527030768310};\\\", \\\"{x:649,y:633,t:1527030768327};\\\", \\\"{x:669,y:622,t:1527030768344};\\\", \\\"{x:716,y:589,t:1527030768361};\\\", \\\"{x:793,y:543,t:1527030768377};\\\", \\\"{x:882,y:512,t:1527030768394};\\\", \\\"{x:973,y:492,t:1527030768410};\\\", \\\"{x:1048,y:491,t:1527030768426};\\\", \\\"{x:1137,y:491,t:1527030768443};\\\", \\\"{x:1220,y:499,t:1527030768460};\\\", \\\"{x:1291,y:522,t:1527030768477};\\\", \\\"{x:1315,y:535,t:1527030768493};\\\", \\\"{x:1364,y:576,t:1527030768510};\\\", \\\"{x:1378,y:597,t:1527030768528};\\\", \\\"{x:1392,y:608,t:1527030768544};\\\", \\\"{x:1413,y:623,t:1527030768561};\\\", \\\"{x:1441,y:645,t:1527030768578};\\\", \\\"{x:1474,y:674,t:1527030768594};\\\", \\\"{x:1504,y:703,t:1527030768611};\\\", \\\"{x:1528,y:744,t:1527030768628};\\\", \\\"{x:1541,y:771,t:1527030768643};\\\", \\\"{x:1556,y:794,t:1527030768661};\\\", \\\"{x:1571,y:805,t:1527030768678};\\\", \\\"{x:1591,y:809,t:1527030768694};\\\", \\\"{x:1600,y:804,t:1527030768711};\\\", \\\"{x:1613,y:790,t:1527030768728};\\\", \\\"{x:1626,y:776,t:1527030768745};\\\", \\\"{x:1637,y:762,t:1527030768761};\\\", \\\"{x:1641,y:755,t:1527030768778};\\\", \\\"{x:1645,y:748,t:1527030768795};\\\", \\\"{x:1645,y:744,t:1527030768810};\\\", \\\"{x:1645,y:743,t:1527030768828};\\\", \\\"{x:1645,y:742,t:1527030768845};\\\", \\\"{x:1644,y:739,t:1527030768861};\\\", \\\"{x:1643,y:738,t:1527030768879};\\\", \\\"{x:1642,y:737,t:1527030768927};\\\", \\\"{x:1640,y:735,t:1527030768946};\\\", \\\"{x:1636,y:730,t:1527030768962};\\\", \\\"{x:1634,y:724,t:1527030768978};\\\", \\\"{x:1632,y:717,t:1527030768995};\\\", \\\"{x:1632,y:707,t:1527030769012};\\\", \\\"{x:1632,y:703,t:1527030769028};\\\", \\\"{x:1632,y:698,t:1527030769045};\\\", \\\"{x:1631,y:696,t:1527030769063};\\\", \\\"{x:1630,y:694,t:1527030769103};\\\", \\\"{x:1629,y:694,t:1527030769127};\\\", \\\"{x:1628,y:694,t:1527030769134};\\\", \\\"{x:1628,y:695,t:1527030769145};\\\", \\\"{x:1627,y:697,t:1527030769162};\\\", \\\"{x:1626,y:699,t:1527030769179};\\\", \\\"{x:1625,y:699,t:1527030769195};\\\", \\\"{x:1625,y:701,t:1527030769212};\\\", \\\"{x:1623,y:704,t:1527030769229};\\\", \\\"{x:1623,y:706,t:1527030769245};\\\", \\\"{x:1623,y:710,t:1527030769262};\\\", \\\"{x:1624,y:711,t:1527030769317};\\\", \\\"{x:1625,y:712,t:1527030769358};\\\", \\\"{x:1626,y:713,t:1527030769390};\\\", \\\"{x:1627,y:716,t:1527030769398};\\\", \\\"{x:1627,y:720,t:1527030769412};\\\", \\\"{x:1629,y:730,t:1527030769429};\\\", \\\"{x:1630,y:743,t:1527030769446};\\\", \\\"{x:1630,y:755,t:1527030769462};\\\", \\\"{x:1630,y:778,t:1527030769478};\\\", \\\"{x:1630,y:796,t:1527030769496};\\\", \\\"{x:1630,y:819,t:1527030769512};\\\", \\\"{x:1629,y:844,t:1527030769529};\\\", \\\"{x:1627,y:872,t:1527030769546};\\\", \\\"{x:1627,y:897,t:1527030769563};\\\", \\\"{x:1625,y:919,t:1527030769579};\\\", \\\"{x:1625,y:935,t:1527030769597};\\\", \\\"{x:1624,y:939,t:1527030769612};\\\", \\\"{x:1623,y:941,t:1527030769628};\\\", \\\"{x:1623,y:945,t:1527030769646};\\\", \\\"{x:1622,y:949,t:1527030769662};\\\", \\\"{x:1621,y:950,t:1527030769679};\\\", \\\"{x:1621,y:952,t:1527030769696};\\\", \\\"{x:1621,y:953,t:1527030769735};\\\", \\\"{x:1621,y:955,t:1527030769750};\\\", \\\"{x:1620,y:955,t:1527030769763};\\\", \\\"{x:1620,y:958,t:1527030769779};\\\", \\\"{x:1618,y:963,t:1527030769799};\\\", \\\"{x:1617,y:966,t:1527030769813};\\\", \\\"{x:1617,y:967,t:1527030769830};\\\", \\\"{x:1617,y:968,t:1527030769846};\\\", \\\"{x:1617,y:970,t:1527030769864};\\\", \\\"{x:1616,y:971,t:1527030770599};\\\", \\\"{x:1615,y:971,t:1527030770614};\\\", \\\"{x:1614,y:971,t:1527030770631};\\\", \\\"{x:1613,y:969,t:1527030771759};\\\", \\\"{x:1613,y:958,t:1527030771767};\\\", \\\"{x:1615,y:939,t:1527030771783};\\\", \\\"{x:1617,y:927,t:1527030771800};\\\", \\\"{x:1622,y:904,t:1527030771816};\\\", \\\"{x:1629,y:864,t:1527030771833};\\\", \\\"{x:1630,y:837,t:1527030771848};\\\", \\\"{x:1630,y:822,t:1527030771866};\\\", \\\"{x:1630,y:816,t:1527030771882};\\\", \\\"{x:1630,y:813,t:1527030771899};\\\", \\\"{x:1629,y:810,t:1527030771916};\\\", \\\"{x:1625,y:802,t:1527030771932};\\\", \\\"{x:1617,y:798,t:1527030771949};\\\", \\\"{x:1605,y:794,t:1527030771965};\\\", \\\"{x:1590,y:792,t:1527030771983};\\\", \\\"{x:1580,y:789,t:1527030771999};\\\", \\\"{x:1574,y:785,t:1527030772016};\\\", \\\"{x:1570,y:780,t:1527030772033};\\\", \\\"{x:1564,y:770,t:1527030772049};\\\", \\\"{x:1561,y:763,t:1527030772066};\\\", \\\"{x:1558,y:760,t:1527030772083};\\\", \\\"{x:1554,y:756,t:1527030772100};\\\", \\\"{x:1544,y:752,t:1527030772116};\\\", \\\"{x:1532,y:750,t:1527030772133};\\\", \\\"{x:1506,y:747,t:1527030772151};\\\", \\\"{x:1481,y:742,t:1527030772167};\\\", \\\"{x:1455,y:739,t:1527030772183};\\\", \\\"{x:1432,y:736,t:1527030772201};\\\", \\\"{x:1414,y:735,t:1527030772217};\\\", \\\"{x:1403,y:735,t:1527030772233};\\\", \\\"{x:1391,y:735,t:1527030772250};\\\", \\\"{x:1386,y:734,t:1527030772268};\\\", \\\"{x:1383,y:733,t:1527030772284};\\\", \\\"{x:1373,y:731,t:1527030772300};\\\", \\\"{x:1359,y:728,t:1527030772317};\\\", \\\"{x:1333,y:724,t:1527030772334};\\\", \\\"{x:1318,y:721,t:1527030772351};\\\", \\\"{x:1311,y:719,t:1527030772367};\\\", \\\"{x:1307,y:717,t:1527030772385};\\\", \\\"{x:1306,y:717,t:1527030772400};\\\", \\\"{x:1303,y:716,t:1527030772417};\\\", \\\"{x:1301,y:715,t:1527030772434};\\\", \\\"{x:1301,y:714,t:1527030772450};\\\", \\\"{x:1299,y:714,t:1527030772527};\\\", \\\"{x:1300,y:713,t:1527030772949};\\\", \\\"{x:1307,y:709,t:1527030772957};\\\", \\\"{x:1313,y:705,t:1527030772968};\\\", \\\"{x:1327,y:699,t:1527030772984};\\\", \\\"{x:1339,y:693,t:1527030773001};\\\", \\\"{x:1347,y:689,t:1527030773017};\\\", \\\"{x:1348,y:689,t:1527030773034};\\\", \\\"{x:1349,y:689,t:1527030773051};\\\", \\\"{x:1351,y:689,t:1527030773078};\\\", \\\"{x:1351,y:690,t:1527030773086};\\\", \\\"{x:1351,y:691,t:1527030773102};\\\", \\\"{x:1351,y:693,t:1527030773119};\\\", \\\"{x:1351,y:694,t:1527030773166};\\\", \\\"{x:1351,y:695,t:1527030773222};\\\", \\\"{x:1351,y:696,t:1527030773238};\\\", \\\"{x:1351,y:697,t:1527030773251};\\\", \\\"{x:1351,y:702,t:1527030773268};\\\", \\\"{x:1351,y:709,t:1527030773285};\\\", \\\"{x:1351,y:718,t:1527030773302};\\\", \\\"{x:1351,y:728,t:1527030773318};\\\", \\\"{x:1360,y:751,t:1527030773335};\\\", \\\"{x:1371,y:791,t:1527030773352};\\\", \\\"{x:1377,y:822,t:1527030773368};\\\", \\\"{x:1381,y:844,t:1527030773384};\\\", \\\"{x:1382,y:861,t:1527030773402};\\\", \\\"{x:1382,y:876,t:1527030773419};\\\", \\\"{x:1382,y:890,t:1527030773435};\\\", \\\"{x:1382,y:900,t:1527030773452};\\\", \\\"{x:1382,y:909,t:1527030773470};\\\", \\\"{x:1382,y:912,t:1527030773485};\\\", \\\"{x:1382,y:920,t:1527030773502};\\\", \\\"{x:1380,y:926,t:1527030773519};\\\", \\\"{x:1380,y:929,t:1527030773535};\\\", \\\"{x:1379,y:930,t:1527030773552};\\\", \\\"{x:1378,y:933,t:1527030773569};\\\", \\\"{x:1377,y:934,t:1527030773586};\\\", \\\"{x:1376,y:937,t:1527030773601};\\\", \\\"{x:1372,y:942,t:1527030773619};\\\", \\\"{x:1370,y:945,t:1527030773635};\\\", \\\"{x:1368,y:946,t:1527030773652};\\\", \\\"{x:1367,y:948,t:1527030773669};\\\", \\\"{x:1366,y:950,t:1527030773686};\\\", \\\"{x:1363,y:953,t:1527030773702};\\\", \\\"{x:1363,y:957,t:1527030773719};\\\", \\\"{x:1362,y:958,t:1527030773737};\\\", \\\"{x:1361,y:959,t:1527030773752};\\\", \\\"{x:1360,y:960,t:1527030774303};\\\", \\\"{x:1358,y:961,t:1527030774321};\\\", \\\"{x:1355,y:962,t:1527030774337};\\\", \\\"{x:1348,y:962,t:1527030774354};\\\", \\\"{x:1337,y:962,t:1527030774370};\\\", \\\"{x:1324,y:954,t:1527030774387};\\\", \\\"{x:1313,y:947,t:1527030774404};\\\", \\\"{x:1296,y:937,t:1527030774420};\\\", \\\"{x:1277,y:927,t:1527030774437};\\\", \\\"{x:1236,y:909,t:1527030774455};\\\", \\\"{x:1193,y:886,t:1527030774470};\\\", \\\"{x:1136,y:853,t:1527030774487};\\\", \\\"{x:1069,y:808,t:1527030774505};\\\", \\\"{x:1007,y:776,t:1527030774520};\\\", \\\"{x:950,y:753,t:1527030774538};\\\", \\\"{x:877,y:733,t:1527030774554};\\\", \\\"{x:802,y:711,t:1527030774570};\\\", \\\"{x:719,y:689,t:1527030774588};\\\", \\\"{x:628,y:663,t:1527030774603};\\\", \\\"{x:543,y:642,t:1527030774620};\\\", \\\"{x:455,y:619,t:1527030774637};\\\", \\\"{x:319,y:580,t:1527030774654};\\\", \\\"{x:277,y:567,t:1527030774665};\\\", \\\"{x:195,y:539,t:1527030774682};\\\", \\\"{x:137,y:513,t:1527030774698};\\\", \\\"{x:103,y:497,t:1527030774715};\\\", \\\"{x:80,y:481,t:1527030774732};\\\", \\\"{x:63,y:467,t:1527030774749};\\\", \\\"{x:49,y:453,t:1527030774765};\\\", \\\"{x:42,y:440,t:1527030774781};\\\", \\\"{x:41,y:439,t:1527030774798};\\\", \\\"{x:41,y:437,t:1527030774815};\\\", \\\"{x:61,y:436,t:1527030774832};\\\", \\\"{x:102,y:436,t:1527030774848};\\\", \\\"{x:166,y:447,t:1527030774866};\\\", \\\"{x:205,y:458,t:1527030774882};\\\", \\\"{x:223,y:463,t:1527030774899};\\\", \\\"{x:228,y:465,t:1527030774916};\\\", \\\"{x:231,y:467,t:1527030774932};\\\", \\\"{x:232,y:468,t:1527030774949};\\\", \\\"{x:232,y:470,t:1527030774974};\\\", \\\"{x:230,y:472,t:1527030774982};\\\", \\\"{x:215,y:477,t:1527030774998};\\\", \\\"{x:203,y:485,t:1527030775016};\\\", \\\"{x:191,y:491,t:1527030775033};\\\", \\\"{x:181,y:497,t:1527030775049};\\\", \\\"{x:176,y:501,t:1527030775066};\\\", \\\"{x:168,y:506,t:1527030775082};\\\", \\\"{x:164,y:517,t:1527030775100};\\\", \\\"{x:160,y:532,t:1527030775117};\\\", \\\"{x:160,y:549,t:1527030775132};\\\", \\\"{x:161,y:569,t:1527030775151};\\\", \\\"{x:172,y:595,t:1527030775166};\\\", \\\"{x:175,y:599,t:1527030775182};\\\", \\\"{x:175,y:600,t:1527030775285};\\\", \\\"{x:175,y:601,t:1527030775496};\\\", \\\"{x:175,y:603,t:1527030775516};\\\", \\\"{x:175,y:614,t:1527030775533};\\\", \\\"{x:175,y:644,t:1527030775550};\\\", \\\"{x:175,y:655,t:1527030775566};\\\", \\\"{x:177,y:659,t:1527030775582};\\\", \\\"{x:177,y:660,t:1527030775622};\\\", \\\"{x:178,y:660,t:1527030775632};\\\", \\\"{x:181,y:660,t:1527030775649};\\\", \\\"{x:186,y:659,t:1527030775666};\\\", \\\"{x:196,y:652,t:1527030775683};\\\", \\\"{x:209,y:637,t:1527030775699};\\\", \\\"{x:223,y:612,t:1527030775718};\\\", \\\"{x:236,y:593,t:1527030775733};\\\", \\\"{x:252,y:573,t:1527030775750};\\\", \\\"{x:261,y:563,t:1527030775765};\\\", \\\"{x:265,y:557,t:1527030775784};\\\", \\\"{x:267,y:553,t:1527030775800};\\\", \\\"{x:267,y:550,t:1527030775816};\\\", \\\"{x:267,y:547,t:1527030775832};\\\", \\\"{x:268,y:545,t:1527030775919};\\\", \\\"{x:271,y:543,t:1527030775933};\\\", \\\"{x:276,y:541,t:1527030775951};\\\", \\\"{x:293,y:534,t:1527030775966};\\\", \\\"{x:313,y:531,t:1527030775983};\\\", \\\"{x:334,y:528,t:1527030776000};\\\", \\\"{x:346,y:526,t:1527030776017};\\\", \\\"{x:358,y:525,t:1527030776033};\\\", \\\"{x:366,y:525,t:1527030776050};\\\", \\\"{x:374,y:523,t:1527030776067};\\\", \\\"{x:378,y:523,t:1527030776083};\\\", \\\"{x:383,y:520,t:1527030776100};\\\", \\\"{x:384,y:519,t:1527030776117};\\\", \\\"{x:390,y:515,t:1527030776135};\\\", \\\"{x:401,y:510,t:1527030776149};\\\", \\\"{x:419,y:505,t:1527030776167};\\\", \\\"{x:441,y:503,t:1527030776182};\\\", \\\"{x:459,y:500,t:1527030776200};\\\", \\\"{x:474,y:500,t:1527030776216};\\\", \\\"{x:489,y:500,t:1527030776233};\\\", \\\"{x:499,y:500,t:1527030776250};\\\", \\\"{x:508,y:499,t:1527030776267};\\\", \\\"{x:520,y:495,t:1527030776282};\\\", \\\"{x:538,y:493,t:1527030776299};\\\", \\\"{x:553,y:489,t:1527030776317};\\\", \\\"{x:566,y:485,t:1527030776333};\\\", \\\"{x:572,y:485,t:1527030776350};\\\", \\\"{x:575,y:484,t:1527030776367};\\\", \\\"{x:582,y:484,t:1527030776383};\\\", \\\"{x:590,y:484,t:1527030776400};\\\", \\\"{x:596,y:484,t:1527030776417};\\\", \\\"{x:602,y:484,t:1527030776433};\\\", \\\"{x:606,y:484,t:1527030776450};\\\", \\\"{x:607,y:484,t:1527030776470};\\\", \\\"{x:608,y:484,t:1527030776483};\\\", \\\"{x:612,y:484,t:1527030776500};\\\", \\\"{x:618,y:486,t:1527030776517};\\\", \\\"{x:623,y:491,t:1527030776535};\\\", \\\"{x:624,y:493,t:1527030776549};\\\", \\\"{x:625,y:494,t:1527030776567};\\\", \\\"{x:626,y:496,t:1527030776622};\\\", \\\"{x:627,y:498,t:1527030776634};\\\", \\\"{x:630,y:501,t:1527030776650};\\\", \\\"{x:634,y:504,t:1527030776667};\\\", \\\"{x:636,y:504,t:1527030776684};\\\", \\\"{x:643,y:504,t:1527030776704};\\\", \\\"{x:651,y:504,t:1527030776717};\\\", \\\"{x:676,y:503,t:1527030776733};\\\", \\\"{x:702,y:503,t:1527030776750};\\\", \\\"{x:730,y:503,t:1527030776767};\\\", \\\"{x:759,y:503,t:1527030776783};\\\", \\\"{x:778,y:503,t:1527030776800};\\\", \\\"{x:789,y:503,t:1527030776817};\\\", \\\"{x:792,y:503,t:1527030776834};\\\", \\\"{x:794,y:502,t:1527030776861};\\\", \\\"{x:795,y:502,t:1527030776893};\\\", \\\"{x:797,y:501,t:1527030776902};\\\", \\\"{x:801,y:499,t:1527030776917};\\\", \\\"{x:811,y:495,t:1527030776934};\\\", \\\"{x:814,y:494,t:1527030776950};\\\", \\\"{x:815,y:494,t:1527030776974};\\\", \\\"{x:816,y:494,t:1527030776990};\\\", \\\"{x:817,y:494,t:1527030777000};\\\", \\\"{x:819,y:494,t:1527030777017};\\\", \\\"{x:820,y:494,t:1527030777034};\\\", \\\"{x:822,y:494,t:1527030777050};\\\", \\\"{x:824,y:494,t:1527030777067};\\\", \\\"{x:825,y:495,t:1527030777084};\\\", \\\"{x:826,y:496,t:1527030777101};\\\", \\\"{x:827,y:497,t:1527030777116};\\\", \\\"{x:827,y:499,t:1527030777134};\\\", \\\"{x:827,y:500,t:1527030777150};\\\", \\\"{x:829,y:502,t:1527030777455};\\\", \\\"{x:833,y:506,t:1527030777469};\\\", \\\"{x:851,y:518,t:1527030777485};\\\", \\\"{x:876,y:532,t:1527030777501};\\\", \\\"{x:926,y:554,t:1527030777518};\\\", \\\"{x:992,y:582,t:1527030777534};\\\", \\\"{x:1053,y:608,t:1527030777551};\\\", \\\"{x:1121,y:643,t:1527030777568};\\\", \\\"{x:1178,y:676,t:1527030777584};\\\", \\\"{x:1222,y:724,t:1527030777601};\\\", \\\"{x:1255,y:778,t:1527030777618};\\\", \\\"{x:1280,y:824,t:1527030777634};\\\", \\\"{x:1303,y:867,t:1527030777650};\\\", \\\"{x:1332,y:926,t:1527030777667};\\\", \\\"{x:1353,y:976,t:1527030777684};\\\", \\\"{x:1364,y:997,t:1527030777702};\\\", \\\"{x:1367,y:1001,t:1527030777717};\\\", \\\"{x:1367,y:1002,t:1527030777758};\\\", \\\"{x:1369,y:1002,t:1527030777775};\\\", \\\"{x:1371,y:1002,t:1527030777784};\\\", \\\"{x:1377,y:1003,t:1527030777801};\\\", \\\"{x:1381,y:1003,t:1527030777817};\\\", \\\"{x:1386,y:1003,t:1527030777835};\\\", \\\"{x:1394,y:1001,t:1527030777851};\\\", \\\"{x:1403,y:997,t:1527030777868};\\\", \\\"{x:1413,y:992,t:1527030777885};\\\", \\\"{x:1426,y:990,t:1527030777901};\\\", \\\"{x:1436,y:990,t:1527030777918};\\\", \\\"{x:1449,y:990,t:1527030777935};\\\", \\\"{x:1453,y:988,t:1527030777951};\\\", \\\"{x:1454,y:988,t:1527030777999};\\\", \\\"{x:1455,y:988,t:1527030778023};\\\", \\\"{x:1456,y:988,t:1527030778034};\\\", \\\"{x:1458,y:987,t:1527030778050};\\\", \\\"{x:1459,y:987,t:1527030778067};\\\", \\\"{x:1460,y:986,t:1527030778084};\\\", \\\"{x:1462,y:986,t:1527030778101};\\\", \\\"{x:1466,y:984,t:1527030778117};\\\", \\\"{x:1471,y:981,t:1527030778134};\\\", \\\"{x:1472,y:980,t:1527030778150};\\\", \\\"{x:1473,y:979,t:1527030778215};\\\", \\\"{x:1473,y:978,t:1527030778239};\\\", \\\"{x:1473,y:977,t:1527030778367};\\\", \\\"{x:1474,y:977,t:1527030778439};\\\", \\\"{x:1474,y:976,t:1527030778471};\\\", \\\"{x:1474,y:975,t:1527030778486};\\\", \\\"{x:1474,y:974,t:1527030778500};\\\", \\\"{x:1474,y:972,t:1527030778517};\\\", \\\"{x:1474,y:968,t:1527030778534};\\\", \\\"{x:1476,y:958,t:1527030778551};\\\", \\\"{x:1477,y:956,t:1527030778568};\\\", \\\"{x:1477,y:951,t:1527030778584};\\\", \\\"{x:1477,y:943,t:1527030778600};\\\", \\\"{x:1477,y:938,t:1527030778618};\\\", \\\"{x:1477,y:935,t:1527030778633};\\\", \\\"{x:1477,y:932,t:1527030778650};\\\", \\\"{x:1476,y:929,t:1527030778667};\\\", \\\"{x:1476,y:926,t:1527030778683};\\\", \\\"{x:1476,y:917,t:1527030778701};\\\", \\\"{x:1476,y:909,t:1527030778718};\\\", \\\"{x:1476,y:904,t:1527030778733};\\\", \\\"{x:1476,y:897,t:1527030778750};\\\", \\\"{x:1476,y:894,t:1527030778767};\\\", \\\"{x:1476,y:890,t:1527030778783};\\\", \\\"{x:1476,y:888,t:1527030778800};\\\", \\\"{x:1476,y:884,t:1527030778818};\\\", \\\"{x:1477,y:883,t:1527030778833};\\\", \\\"{x:1477,y:879,t:1527030778851};\\\", \\\"{x:1477,y:877,t:1527030778867};\\\", \\\"{x:1477,y:869,t:1527030778884};\\\", \\\"{x:1477,y:861,t:1527030778901};\\\", \\\"{x:1475,y:857,t:1527030778918};\\\", \\\"{x:1470,y:856,t:1527030778933};\\\", \\\"{x:1446,y:850,t:1527030778951};\\\", \\\"{x:1414,y:844,t:1527030778967};\\\", \\\"{x:1347,y:834,t:1527030778984};\\\", \\\"{x:1255,y:819,t:1527030779000};\\\", \\\"{x:1158,y:805,t:1527030779016};\\\", \\\"{x:1084,y:791,t:1527030779033};\\\", \\\"{x:1052,y:785,t:1527030779050};\\\", \\\"{x:1034,y:778,t:1527030779066};\\\", \\\"{x:1025,y:770,t:1527030779083};\\\", \\\"{x:1021,y:762,t:1527030779100};\\\", \\\"{x:1018,y:753,t:1527030779116};\\\", \\\"{x:1013,y:746,t:1527030779133};\\\", \\\"{x:1007,y:735,t:1527030779151};\\\", \\\"{x:1003,y:729,t:1527030779167};\\\", \\\"{x:992,y:720,t:1527030779184};\\\", \\\"{x:969,y:701,t:1527030779201};\\\", \\\"{x:943,y:680,t:1527030779216};\\\", \\\"{x:926,y:671,t:1527030779233};\\\", \\\"{x:916,y:662,t:1527030779250};\\\", \\\"{x:904,y:650,t:1527030779266};\\\", \\\"{x:893,y:641,t:1527030779282};\\\", \\\"{x:886,y:640,t:1527030779299};\\\", \\\"{x:877,y:636,t:1527030779315};\\\", \\\"{x:865,y:631,t:1527030779334};\\\", \\\"{x:831,y:609,t:1527030779350};\\\", \\\"{x:800,y:599,t:1527030779369};\\\", \\\"{x:758,y:586,t:1527030779386};\\\", \\\"{x:717,y:574,t:1527030779403};\\\", \\\"{x:698,y:571,t:1527030779419};\\\", \\\"{x:686,y:569,t:1527030779436};\\\", \\\"{x:681,y:569,t:1527030779453};\\\", \\\"{x:676,y:568,t:1527030779469};\\\", \\\"{x:673,y:568,t:1527030779486};\\\", \\\"{x:672,y:568,t:1527030779509};\\\", \\\"{x:670,y:568,t:1527030779549};\\\", \\\"{x:668,y:568,t:1527030779590};\\\", \\\"{x:663,y:568,t:1527030779602};\\\", \\\"{x:647,y:570,t:1527030779620};\\\", \\\"{x:630,y:573,t:1527030779637};\\\", \\\"{x:614,y:575,t:1527030779653};\\\", \\\"{x:599,y:578,t:1527030779669};\\\", \\\"{x:566,y:585,t:1527030779686};\\\", \\\"{x:543,y:591,t:1527030779702};\\\", \\\"{x:521,y:597,t:1527030779720};\\\", \\\"{x:499,y:604,t:1527030779736};\\\", \\\"{x:483,y:612,t:1527030779754};\\\", \\\"{x:472,y:617,t:1527030779769};\\\", \\\"{x:467,y:620,t:1527030779786};\\\", \\\"{x:465,y:621,t:1527030779802};\\\", \\\"{x:463,y:621,t:1527030779818};\\\", \\\"{x:459,y:622,t:1527030779836};\\\", \\\"{x:455,y:622,t:1527030779853};\\\", \\\"{x:448,y:622,t:1527030779869};\\\", \\\"{x:431,y:622,t:1527030779886};\\\", \\\"{x:413,y:619,t:1527030779904};\\\", \\\"{x:387,y:613,t:1527030779920};\\\", \\\"{x:362,y:603,t:1527030779937};\\\", \\\"{x:354,y:601,t:1527030779953};\\\", \\\"{x:349,y:597,t:1527030779970};\\\", \\\"{x:348,y:592,t:1527030779987};\\\", \\\"{x:346,y:587,t:1527030780003};\\\", \\\"{x:346,y:585,t:1527030780020};\\\", \\\"{x:346,y:579,t:1527030780036};\\\", \\\"{x:350,y:573,t:1527030780053};\\\", \\\"{x:351,y:569,t:1527030780069};\\\", \\\"{x:354,y:559,t:1527030780088};\\\", \\\"{x:357,y:555,t:1527030780104};\\\", \\\"{x:358,y:552,t:1527030780120};\\\", \\\"{x:360,y:548,t:1527030780136};\\\", \\\"{x:361,y:547,t:1527030780153};\\\", \\\"{x:364,y:545,t:1527030780170};\\\", \\\"{x:368,y:544,t:1527030780186};\\\", \\\"{x:374,y:541,t:1527030780203};\\\", \\\"{x:378,y:540,t:1527030780220};\\\", \\\"{x:384,y:538,t:1527030780236};\\\", \\\"{x:388,y:536,t:1527030780253};\\\", \\\"{x:401,y:533,t:1527030780270};\\\", \\\"{x:416,y:533,t:1527030780287};\\\", \\\"{x:428,y:533,t:1527030780303};\\\", \\\"{x:430,y:533,t:1527030780319};\\\", \\\"{x:430,y:537,t:1527030780336};\\\", \\\"{x:430,y:552,t:1527030780353};\\\", \\\"{x:420,y:567,t:1527030780371};\\\", \\\"{x:409,y:581,t:1527030780387};\\\", \\\"{x:398,y:595,t:1527030780404};\\\", \\\"{x:378,y:611,t:1527030780420};\\\", \\\"{x:346,y:628,t:1527030780436};\\\", \\\"{x:319,y:644,t:1527030780454};\\\", \\\"{x:289,y:651,t:1527030780470};\\\", \\\"{x:278,y:653,t:1527030780486};\\\", \\\"{x:275,y:654,t:1527030780503};\\\", \\\"{x:281,y:653,t:1527030780567};\\\", \\\"{x:291,y:647,t:1527030780574};\\\", \\\"{x:304,y:643,t:1527030780587};\\\", \\\"{x:341,y:632,t:1527030780604};\\\", \\\"{x:392,y:618,t:1527030780622};\\\", \\\"{x:469,y:607,t:1527030780637};\\\", \\\"{x:534,y:595,t:1527030780654};\\\", \\\"{x:600,y:592,t:1527030780670};\\\", \\\"{x:617,y:592,t:1527030780687};\\\", \\\"{x:619,y:592,t:1527030780703};\\\", \\\"{x:620,y:592,t:1527030780734};\\\", \\\"{x:620,y:593,t:1527030780830};\\\", \\\"{x:619,y:594,t:1527030780846};\\\", \\\"{x:620,y:593,t:1527030780928};\\\", \\\"{x:621,y:592,t:1527030780941};\\\", \\\"{x:622,y:590,t:1527030780954};\\\", \\\"{x:622,y:589,t:1527030781095};\\\", \\\"{x:622,y:588,t:1527030781111};\\\", \\\"{x:622,y:587,t:1527030781121};\\\", \\\"{x:622,y:589,t:1527030781478};\\\", \\\"{x:620,y:592,t:1527030781486};\\\", \\\"{x:617,y:605,t:1527030781505};\\\", \\\"{x:604,y:624,t:1527030781520};\\\", \\\"{x:588,y:660,t:1527030781538};\\\", \\\"{x:574,y:693,t:1527030781554};\\\", \\\"{x:559,y:729,t:1527030781572};\\\", \\\"{x:550,y:743,t:1527030781587};\\\", \\\"{x:545,y:748,t:1527030781604};\\\", \\\"{x:544,y:748,t:1527030781621};\\\", \\\"{x:542,y:747,t:1527030781695};\\\", \\\"{x:540,y:741,t:1527030781704};\\\", \\\"{x:538,y:733,t:1527030781722};\\\", \\\"{x:532,y:726,t:1527030781738};\\\", \\\"{x:527,y:720,t:1527030781754};\\\", \\\"{x:524,y:718,t:1527030781772};\\\", \\\"{x:525,y:720,t:1527030782336};\\\", \\\"{x:527,y:721,t:1527030782354};\\\", \\\"{x:530,y:722,t:1527030782371};\\\", \\\"{x:531,y:722,t:1527030782388};\\\" ] }, { \\\"rt\\\": 11067, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 750392, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:722,t:1527030786662};\\\", \\\"{x:535,y:722,t:1527030786670};\\\", \\\"{x:541,y:722,t:1527030786682};\\\", \\\"{x:582,y:722,t:1527030786700};\\\", \\\"{x:685,y:722,t:1527030786715};\\\", \\\"{x:793,y:722,t:1527030786731};\\\", \\\"{x:835,y:722,t:1527030786740};\\\", \\\"{x:867,y:724,t:1527030786757};\\\", \\\"{x:876,y:727,t:1527030786774};\\\", \\\"{x:895,y:727,t:1527030786790};\\\", \\\"{x:917,y:727,t:1527030786807};\\\", \\\"{x:932,y:727,t:1527030786823};\\\", \\\"{x:954,y:727,t:1527030786841};\\\", \\\"{x:1011,y:726,t:1527030786858};\\\", \\\"{x:1084,y:726,t:1527030786874};\\\", \\\"{x:1156,y:726,t:1527030786890};\\\", \\\"{x:1222,y:730,t:1527030786908};\\\", \\\"{x:1290,y:757,t:1527030786923};\\\", \\\"{x:1373,y:793,t:1527030786940};\\\", \\\"{x:1521,y:884,t:1527030786958};\\\", \\\"{x:1626,y:949,t:1527030786974};\\\", \\\"{x:1708,y:998,t:1527030786990};\\\", \\\"{x:1755,y:1018,t:1527030787008};\\\", \\\"{x:1773,y:1021,t:1527030787024};\\\", \\\"{x:1776,y:1021,t:1527030787041};\\\", \\\"{x:1777,y:1021,t:1527030787058};\\\", \\\"{x:1774,y:1023,t:1527030787086};\\\", \\\"{x:1772,y:1024,t:1527030787094};\\\", \\\"{x:1769,y:1028,t:1527030787108};\\\", \\\"{x:1761,y:1038,t:1527030787124};\\\", \\\"{x:1747,y:1049,t:1527030787140};\\\", \\\"{x:1730,y:1056,t:1527030787158};\\\", \\\"{x:1715,y:1059,t:1527030787174};\\\", \\\"{x:1704,y:1059,t:1527030787191};\\\", \\\"{x:1696,y:1057,t:1527030787208};\\\", \\\"{x:1686,y:1053,t:1527030787223};\\\", \\\"{x:1675,y:1047,t:1527030787241};\\\", \\\"{x:1666,y:1039,t:1527030787258};\\\", \\\"{x:1660,y:1033,t:1527030787274};\\\", \\\"{x:1650,y:1023,t:1527030787291};\\\", \\\"{x:1632,y:1009,t:1527030787308};\\\", \\\"{x:1623,y:1003,t:1527030787324};\\\", \\\"{x:1621,y:1002,t:1527030787340};\\\", \\\"{x:1621,y:1001,t:1527030787358};\\\", \\\"{x:1621,y:1000,t:1527030787374};\\\", \\\"{x:1616,y:1000,t:1527030787427};\\\", \\\"{x:1604,y:1000,t:1527030787440};\\\", \\\"{x:1583,y:1000,t:1527030787458};\\\", \\\"{x:1555,y:1000,t:1527030787474};\\\", \\\"{x:1514,y:999,t:1527030787490};\\\", \\\"{x:1489,y:995,t:1527030787507};\\\", \\\"{x:1469,y:992,t:1527030787524};\\\", \\\"{x:1459,y:991,t:1527030787541};\\\", \\\"{x:1450,y:991,t:1527030787558};\\\", \\\"{x:1448,y:991,t:1527030787574};\\\", \\\"{x:1447,y:991,t:1527030787590};\\\", \\\"{x:1446,y:990,t:1527030787655};\\\", \\\"{x:1445,y:987,t:1527030787662};\\\", \\\"{x:1445,y:983,t:1527030787675};\\\", \\\"{x:1445,y:976,t:1527030787691};\\\", \\\"{x:1444,y:969,t:1527030787707};\\\", \\\"{x:1440,y:961,t:1527030787725};\\\", \\\"{x:1437,y:959,t:1527030787740};\\\", \\\"{x:1431,y:957,t:1527030787758};\\\", \\\"{x:1422,y:956,t:1527030787774};\\\", \\\"{x:1412,y:954,t:1527030787790};\\\", \\\"{x:1408,y:954,t:1527030787807};\\\", \\\"{x:1405,y:954,t:1527030787825};\\\", \\\"{x:1402,y:954,t:1527030787841};\\\", \\\"{x:1402,y:953,t:1527030787999};\\\", \\\"{x:1402,y:952,t:1527030788014};\\\", \\\"{x:1402,y:951,t:1527030788030};\\\", \\\"{x:1402,y:950,t:1527030788041};\\\", \\\"{x:1405,y:947,t:1527030788057};\\\", \\\"{x:1407,y:942,t:1527030788074};\\\", \\\"{x:1410,y:938,t:1527030788090};\\\", \\\"{x:1411,y:936,t:1527030788108};\\\", \\\"{x:1411,y:935,t:1527030788279};\\\", \\\"{x:1414,y:933,t:1527030788291};\\\", \\\"{x:1422,y:931,t:1527030788308};\\\", \\\"{x:1433,y:928,t:1527030788324};\\\", \\\"{x:1447,y:922,t:1527030788340};\\\", \\\"{x:1465,y:913,t:1527030788358};\\\", \\\"{x:1473,y:908,t:1527030788374};\\\", \\\"{x:1480,y:901,t:1527030788390};\\\", \\\"{x:1485,y:896,t:1527030788407};\\\", \\\"{x:1490,y:888,t:1527030788424};\\\", \\\"{x:1493,y:882,t:1527030788441};\\\", \\\"{x:1496,y:877,t:1527030788458};\\\", \\\"{x:1497,y:875,t:1527030788475};\\\", \\\"{x:1500,y:866,t:1527030788491};\\\", \\\"{x:1500,y:863,t:1527030788507};\\\", \\\"{x:1501,y:858,t:1527030788525};\\\", \\\"{x:1501,y:855,t:1527030788541};\\\", \\\"{x:1501,y:852,t:1527030788558};\\\", \\\"{x:1501,y:850,t:1527030788574};\\\", \\\"{x:1503,y:847,t:1527030788592};\\\", \\\"{x:1503,y:841,t:1527030788608};\\\", \\\"{x:1503,y:839,t:1527030788625};\\\", \\\"{x:1503,y:838,t:1527030788642};\\\", \\\"{x:1503,y:836,t:1527030788658};\\\", \\\"{x:1503,y:839,t:1527030788831};\\\", \\\"{x:1503,y:845,t:1527030788842};\\\", \\\"{x:1502,y:856,t:1527030788858};\\\", \\\"{x:1500,y:862,t:1527030788875};\\\", \\\"{x:1498,y:869,t:1527030788892};\\\", \\\"{x:1497,y:870,t:1527030788908};\\\", \\\"{x:1497,y:871,t:1527030788925};\\\", \\\"{x:1495,y:871,t:1527030788966};\\\", \\\"{x:1491,y:871,t:1527030788975};\\\", \\\"{x:1483,y:871,t:1527030788993};\\\", \\\"{x:1473,y:871,t:1527030789008};\\\", \\\"{x:1467,y:871,t:1527030789025};\\\", \\\"{x:1454,y:867,t:1527030789042};\\\", \\\"{x:1437,y:862,t:1527030789058};\\\", \\\"{x:1420,y:856,t:1527030789075};\\\", \\\"{x:1400,y:851,t:1527030789092};\\\", \\\"{x:1382,y:845,t:1527030789109};\\\", \\\"{x:1362,y:840,t:1527030789125};\\\", \\\"{x:1325,y:831,t:1527030789143};\\\", \\\"{x:1302,y:830,t:1527030789159};\\\", \\\"{x:1277,y:830,t:1527030789175};\\\", \\\"{x:1257,y:830,t:1527030789192};\\\", \\\"{x:1245,y:831,t:1527030789208};\\\", \\\"{x:1239,y:831,t:1527030789225};\\\", \\\"{x:1234,y:831,t:1527030789242};\\\", \\\"{x:1232,y:833,t:1527030789258};\\\", \\\"{x:1230,y:834,t:1527030789275};\\\", \\\"{x:1227,y:835,t:1527030789292};\\\", \\\"{x:1225,y:837,t:1527030789308};\\\", \\\"{x:1222,y:839,t:1527030789325};\\\", \\\"{x:1215,y:841,t:1527030789342};\\\", \\\"{x:1213,y:841,t:1527030789358};\\\", \\\"{x:1212,y:841,t:1527030789439};\\\", \\\"{x:1212,y:840,t:1527030789470};\\\", \\\"{x:1213,y:839,t:1527030789478};\\\", \\\"{x:1214,y:838,t:1527030789492};\\\", \\\"{x:1215,y:837,t:1527030789508};\\\", \\\"{x:1217,y:837,t:1527030789525};\\\", \\\"{x:1217,y:835,t:1527030789545};\\\", \\\"{x:1218,y:834,t:1527030789575};\\\", \\\"{x:1218,y:833,t:1527030789613};\\\", \\\"{x:1220,y:832,t:1527030789625};\\\", \\\"{x:1222,y:830,t:1527030789641};\\\", \\\"{x:1228,y:828,t:1527030789657};\\\", \\\"{x:1234,y:824,t:1527030789674};\\\", \\\"{x:1248,y:818,t:1527030789691};\\\", \\\"{x:1263,y:812,t:1527030789708};\\\", \\\"{x:1277,y:807,t:1527030789724};\\\", \\\"{x:1293,y:802,t:1527030789742};\\\", \\\"{x:1299,y:798,t:1527030789757};\\\", \\\"{x:1303,y:795,t:1527030789774};\\\", \\\"{x:1309,y:789,t:1527030789792};\\\", \\\"{x:1313,y:786,t:1527030789808};\\\", \\\"{x:1315,y:784,t:1527030789825};\\\", \\\"{x:1316,y:783,t:1527030789843};\\\", \\\"{x:1319,y:780,t:1527030789858};\\\", \\\"{x:1319,y:779,t:1527030789878};\\\", \\\"{x:1321,y:778,t:1527030789895};\\\", \\\"{x:1322,y:778,t:1527030789909};\\\", \\\"{x:1323,y:776,t:1527030789926};\\\", \\\"{x:1328,y:773,t:1527030789942};\\\", \\\"{x:1330,y:772,t:1527030789959};\\\", \\\"{x:1331,y:771,t:1527030789998};\\\", \\\"{x:1331,y:770,t:1527030790071};\\\", \\\"{x:1333,y:770,t:1527030790471};\\\", \\\"{x:1334,y:770,t:1527030790494};\\\", \\\"{x:1336,y:770,t:1527030790518};\\\", \\\"{x:1337,y:770,t:1527030790543};\\\", \\\"{x:1339,y:770,t:1527030790558};\\\", \\\"{x:1340,y:770,t:1527030790606};\\\", \\\"{x:1342,y:770,t:1527030790630};\\\", \\\"{x:1343,y:770,t:1527030790655};\\\", \\\"{x:1344,y:770,t:1527030790743};\\\", \\\"{x:1345,y:770,t:1527030790758};\\\", \\\"{x:1346,y:770,t:1527030790791};\\\", \\\"{x:1347,y:770,t:1527030790854};\\\", \\\"{x:1348,y:770,t:1527030790870};\\\", \\\"{x:1349,y:770,t:1527030790894};\\\", \\\"{x:1350,y:769,t:1527030790983};\\\", \\\"{x:1351,y:769,t:1527030791007};\\\", \\\"{x:1348,y:769,t:1527030791679};\\\", \\\"{x:1342,y:776,t:1527030791692};\\\", \\\"{x:1324,y:791,t:1527030791709};\\\", \\\"{x:1257,y:823,t:1527030791726};\\\", \\\"{x:1195,y:837,t:1527030791742};\\\", \\\"{x:1129,y:841,t:1527030791759};\\\", \\\"{x:1068,y:841,t:1527030791776};\\\", \\\"{x:1019,y:837,t:1527030791792};\\\", \\\"{x:970,y:828,t:1527030791809};\\\", \\\"{x:906,y:818,t:1527030791826};\\\", \\\"{x:838,y:806,t:1527030791841};\\\", \\\"{x:771,y:786,t:1527030791858};\\\", \\\"{x:717,y:767,t:1527030791876};\\\", \\\"{x:676,y:749,t:1527030791891};\\\", \\\"{x:639,y:730,t:1527030791908};\\\", \\\"{x:595,y:707,t:1527030791925};\\\", \\\"{x:564,y:695,t:1527030791942};\\\", \\\"{x:541,y:689,t:1527030791958};\\\", \\\"{x:513,y:679,t:1527030791975};\\\", \\\"{x:480,y:662,t:1527030791992};\\\", \\\"{x:445,y:658,t:1527030792008};\\\", \\\"{x:417,y:651,t:1527030792026};\\\", \\\"{x:381,y:642,t:1527030792045};\\\", \\\"{x:367,y:637,t:1527030792063};\\\", \\\"{x:367,y:636,t:1527030792093};\\\", \\\"{x:368,y:635,t:1527030792101};\\\", \\\"{x:368,y:633,t:1527030792113};\\\", \\\"{x:368,y:627,t:1527030792130};\\\", \\\"{x:368,y:622,t:1527030792146};\\\", \\\"{x:367,y:612,t:1527030792162};\\\", \\\"{x:365,y:607,t:1527030792179};\\\", \\\"{x:365,y:597,t:1527030792196};\\\", \\\"{x:365,y:587,t:1527030792214};\\\", \\\"{x:383,y:567,t:1527030792229};\\\", \\\"{x:398,y:559,t:1527030792246};\\\", \\\"{x:413,y:550,t:1527030792263};\\\", \\\"{x:424,y:546,t:1527030792280};\\\", \\\"{x:428,y:545,t:1527030792297};\\\", \\\"{x:431,y:545,t:1527030792313};\\\", \\\"{x:436,y:543,t:1527030792330};\\\", \\\"{x:446,y:542,t:1527030792347};\\\", \\\"{x:455,y:542,t:1527030792363};\\\", \\\"{x:457,y:542,t:1527030792380};\\\", \\\"{x:459,y:543,t:1527030792397};\\\", \\\"{x:460,y:543,t:1527030792510};\\\", \\\"{x:464,y:542,t:1527030792518};\\\", \\\"{x:470,y:540,t:1527030792530};\\\", \\\"{x:490,y:531,t:1527030792547};\\\", \\\"{x:529,y:517,t:1527030792565};\\\", \\\"{x:562,y:509,t:1527030792579};\\\", \\\"{x:576,y:508,t:1527030792597};\\\", \\\"{x:597,y:505,t:1527030792614};\\\", \\\"{x:631,y:499,t:1527030792668};\\\", \\\"{x:635,y:499,t:1527030792680};\\\", \\\"{x:636,y:499,t:1527030792697};\\\", \\\"{x:636,y:500,t:1527030792790};\\\", \\\"{x:634,y:502,t:1527030792797};\\\", \\\"{x:629,y:507,t:1527030792814};\\\", \\\"{x:624,y:512,t:1527030792830};\\\", \\\"{x:621,y:514,t:1527030792847};\\\", \\\"{x:620,y:516,t:1527030792864};\\\", \\\"{x:618,y:519,t:1527030792880};\\\", \\\"{x:615,y:525,t:1527030792897};\\\", \\\"{x:606,y:535,t:1527030792914};\\\", \\\"{x:595,y:546,t:1527030792930};\\\", \\\"{x:581,y:559,t:1527030792947};\\\", \\\"{x:574,y:563,t:1527030792964};\\\", \\\"{x:573,y:564,t:1527030792979};\\\", \\\"{x:571,y:564,t:1527030793005};\\\", \\\"{x:569,y:565,t:1527030793014};\\\", \\\"{x:555,y:567,t:1527030793029};\\\", \\\"{x:533,y:567,t:1527030793047};\\\", \\\"{x:507,y:567,t:1527030793064};\\\", \\\"{x:483,y:567,t:1527030793081};\\\", \\\"{x:454,y:566,t:1527030793096};\\\", \\\"{x:408,y:559,t:1527030793114};\\\", \\\"{x:346,y:549,t:1527030793130};\\\", \\\"{x:289,y:537,t:1527030793147};\\\", \\\"{x:245,y:532,t:1527030793166};\\\", \\\"{x:215,y:527,t:1527030793180};\\\", \\\"{x:196,y:524,t:1527030793197};\\\", \\\"{x:185,y:522,t:1527030793214};\\\", \\\"{x:184,y:523,t:1527030793263};\\\", \\\"{x:170,y:531,t:1527030793316};\\\", \\\"{x:167,y:532,t:1527030793330};\\\", \\\"{x:166,y:534,t:1527030793357};\\\", \\\"{x:165,y:534,t:1527030793373};\\\", \\\"{x:164,y:535,t:1527030793397};\\\", \\\"{x:164,y:536,t:1527030793430};\\\", \\\"{x:164,y:537,t:1527030793437};\\\", \\\"{x:162,y:537,t:1527030793447};\\\", \\\"{x:160,y:540,t:1527030793463};\\\", \\\"{x:159,y:541,t:1527030793481};\\\", \\\"{x:159,y:542,t:1527030793814};\\\", \\\"{x:162,y:545,t:1527030793830};\\\", \\\"{x:177,y:553,t:1527030793847};\\\", \\\"{x:202,y:565,t:1527030793865};\\\", \\\"{x:230,y:578,t:1527030793881};\\\", \\\"{x:286,y:606,t:1527030793899};\\\", \\\"{x:368,y:652,t:1527030793914};\\\", \\\"{x:464,y:710,t:1527030793930};\\\", \\\"{x:536,y:745,t:1527030793948};\\\", \\\"{x:595,y:773,t:1527030793964};\\\", \\\"{x:620,y:782,t:1527030793980};\\\", \\\"{x:627,y:785,t:1527030793997};\\\", \\\"{x:628,y:787,t:1527030794062};\\\", \\\"{x:627,y:787,t:1527030794086};\\\", \\\"{x:626,y:787,t:1527030794099};\\\", \\\"{x:625,y:787,t:1527030794118};\\\", \\\"{x:624,y:787,t:1527030794132};\\\", \\\"{x:623,y:787,t:1527030794148};\\\", \\\"{x:618,y:784,t:1527030794165};\\\", \\\"{x:604,y:775,t:1527030794182};\\\", \\\"{x:593,y:769,t:1527030794198};\\\", \\\"{x:582,y:763,t:1527030794215};\\\", \\\"{x:574,y:759,t:1527030794232};\\\", \\\"{x:565,y:755,t:1527030794249};\\\", \\\"{x:555,y:752,t:1527030794268};\\\", \\\"{x:540,y:749,t:1527030794282};\\\", \\\"{x:523,y:740,t:1527030794298};\\\", \\\"{x:506,y:734,t:1527030794314};\\\", \\\"{x:494,y:728,t:1527030794331};\\\", \\\"{x:492,y:726,t:1527030794347};\\\", \\\"{x:492,y:727,t:1527030794655};\\\" ] }, { \\\"rt\\\": 38609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 790254, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -11 AM-01 PM-02 PM-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:727,t:1527030797038};\\\", \\\"{x:496,y:727,t:1527030797054};\\\", \\\"{x:498,y:727,t:1527030797078};\\\", \\\"{x:499,y:727,t:1527030797238};\\\", \\\"{x:500,y:726,t:1527030797254};\\\", \\\"{x:501,y:726,t:1527030797267};\\\", \\\"{x:502,y:725,t:1527030797286};\\\", \\\"{x:505,y:725,t:1527030797300};\\\", \\\"{x:509,y:721,t:1527030797318};\\\", \\\"{x:519,y:714,t:1527030797334};\\\", \\\"{x:523,y:711,t:1527030797350};\\\", \\\"{x:527,y:707,t:1527030797368};\\\", \\\"{x:529,y:704,t:1527030797384};\\\", \\\"{x:529,y:703,t:1527030797400};\\\", \\\"{x:529,y:702,t:1527030808695};\\\", \\\"{x:560,y:692,t:1527030808710};\\\", \\\"{x:611,y:684,t:1527030808726};\\\", \\\"{x:635,y:683,t:1527030808743};\\\", \\\"{x:645,y:680,t:1527030808760};\\\", \\\"{x:645,y:679,t:1527030808822};\\\", \\\"{x:637,y:678,t:1527030808830};\\\", \\\"{x:627,y:670,t:1527030808843};\\\", \\\"{x:619,y:656,t:1527030808860};\\\", \\\"{x:615,y:643,t:1527030808878};\\\", \\\"{x:614,y:631,t:1527030808892};\\\", \\\"{x:614,y:604,t:1527030808909};\\\", \\\"{x:614,y:577,t:1527030808926};\\\", \\\"{x:612,y:554,t:1527030808944};\\\", \\\"{x:610,y:532,t:1527030808960};\\\", \\\"{x:607,y:511,t:1527030808976};\\\", \\\"{x:605,y:495,t:1527030808994};\\\", \\\"{x:599,y:476,t:1527030809010};\\\", \\\"{x:597,y:460,t:1527030809026};\\\", \\\"{x:597,y:448,t:1527030809044};\\\", \\\"{x:597,y:444,t:1527030809059};\\\", \\\"{x:598,y:443,t:1527030809093};\\\", \\\"{x:611,y:437,t:1527030809110};\\\", \\\"{x:636,y:427,t:1527030809126};\\\", \\\"{x:659,y:422,t:1527030809143};\\\", \\\"{x:674,y:420,t:1527030809159};\\\", \\\"{x:686,y:419,t:1527030809177};\\\", \\\"{x:701,y:416,t:1527030809192};\\\", \\\"{x:722,y:410,t:1527030809209};\\\", \\\"{x:742,y:402,t:1527030809227};\\\", \\\"{x:758,y:397,t:1527030809243};\\\", \\\"{x:765,y:395,t:1527030809260};\\\", \\\"{x:768,y:394,t:1527030809276};\\\", \\\"{x:770,y:394,t:1527030809366};\\\", \\\"{x:771,y:393,t:1527030809382};\\\", \\\"{x:771,y:392,t:1527030809398};\\\", \\\"{x:772,y:391,t:1527030809410};\\\", \\\"{x:773,y:390,t:1527030809426};\\\", \\\"{x:774,y:397,t:1527030809470};\\\", \\\"{x:774,y:416,t:1527030809478};\\\", \\\"{x:775,y:431,t:1527030809492};\\\", \\\"{x:814,y:488,t:1527030809509};\\\", \\\"{x:857,y:519,t:1527030809528};\\\", \\\"{x:920,y:546,t:1527030809543};\\\", \\\"{x:978,y:562,t:1527030809561};\\\", \\\"{x:1029,y:578,t:1527030809576};\\\", \\\"{x:1068,y:589,t:1527030809594};\\\", \\\"{x:1083,y:595,t:1527030809610};\\\", \\\"{x:1089,y:600,t:1527030809626};\\\", \\\"{x:1089,y:603,t:1527030809644};\\\", \\\"{x:1088,y:611,t:1527030809661};\\\", \\\"{x:1082,y:623,t:1527030809676};\\\", \\\"{x:1069,y:655,t:1527030809694};\\\", \\\"{x:1065,y:683,t:1527030809711};\\\", \\\"{x:1065,y:701,t:1527030809726};\\\", \\\"{x:1066,y:710,t:1527030809743};\\\", \\\"{x:1075,y:717,t:1527030809760};\\\", \\\"{x:1096,y:724,t:1527030809778};\\\", \\\"{x:1131,y:732,t:1527030809794};\\\", \\\"{x:1163,y:738,t:1527030809810};\\\", \\\"{x:1186,y:744,t:1527030809827};\\\", \\\"{x:1211,y:751,t:1527030809844};\\\", \\\"{x:1245,y:762,t:1527030809860};\\\", \\\"{x:1308,y:786,t:1527030809878};\\\", \\\"{x:1339,y:797,t:1527030809894};\\\", \\\"{x:1354,y:804,t:1527030809911};\\\", \\\"{x:1359,y:807,t:1527030809928};\\\", \\\"{x:1360,y:807,t:1527030810119};\\\", \\\"{x:1361,y:806,t:1527030810128};\\\", \\\"{x:1361,y:804,t:1527030810144};\\\", \\\"{x:1360,y:798,t:1527030810162};\\\", \\\"{x:1349,y:787,t:1527030810178};\\\", \\\"{x:1335,y:776,t:1527030810195};\\\", \\\"{x:1320,y:762,t:1527030810211};\\\", \\\"{x:1312,y:753,t:1527030810228};\\\", \\\"{x:1311,y:752,t:1527030810244};\\\", \\\"{x:1311,y:751,t:1527030810261};\\\", \\\"{x:1311,y:750,t:1527030810277};\\\", \\\"{x:1312,y:749,t:1527030810495};\\\", \\\"{x:1313,y:748,t:1527030810512};\\\", \\\"{x:1315,y:746,t:1527030810528};\\\", \\\"{x:1317,y:745,t:1527030810545};\\\", \\\"{x:1322,y:739,t:1527030810561};\\\", \\\"{x:1326,y:733,t:1527030810578};\\\", \\\"{x:1328,y:731,t:1527030810595};\\\", \\\"{x:1328,y:730,t:1527030810611};\\\", \\\"{x:1329,y:728,t:1527030810630};\\\", \\\"{x:1330,y:727,t:1527030810645};\\\", \\\"{x:1331,y:726,t:1527030810799};\\\", \\\"{x:1332,y:725,t:1527030810814};\\\", \\\"{x:1334,y:724,t:1527030810828};\\\", \\\"{x:1335,y:723,t:1527030810846};\\\", \\\"{x:1337,y:722,t:1527030810871};\\\", \\\"{x:1339,y:721,t:1527030810879};\\\", \\\"{x:1342,y:717,t:1527030810895};\\\", \\\"{x:1344,y:715,t:1527030810911};\\\", \\\"{x:1345,y:714,t:1527030810933};\\\", \\\"{x:1345,y:713,t:1527030810997};\\\", \\\"{x:1345,y:711,t:1527030811142};\\\", \\\"{x:1345,y:710,t:1527030811222};\\\", \\\"{x:1346,y:708,t:1527030811238};\\\", \\\"{x:1346,y:707,t:1527030811279};\\\", \\\"{x:1346,y:706,t:1527030811350};\\\", \\\"{x:1345,y:706,t:1527030811365};\\\", \\\"{x:1342,y:706,t:1527030811378};\\\", \\\"{x:1327,y:706,t:1527030811395};\\\", \\\"{x:1301,y:706,t:1527030811413};\\\", \\\"{x:1270,y:706,t:1527030811429};\\\", \\\"{x:1222,y:706,t:1527030811446};\\\", \\\"{x:1123,y:701,t:1527030811462};\\\", \\\"{x:1031,y:682,t:1527030811478};\\\", \\\"{x:917,y:651,t:1527030811496};\\\", \\\"{x:805,y:624,t:1527030811514};\\\", \\\"{x:729,y:612,t:1527030811529};\\\", \\\"{x:703,y:605,t:1527030811546};\\\", \\\"{x:692,y:601,t:1527030811562};\\\", \\\"{x:689,y:599,t:1527030811578};\\\", \\\"{x:688,y:599,t:1527030811654};\\\", \\\"{x:686,y:599,t:1527030811661};\\\", \\\"{x:678,y:599,t:1527030811678};\\\", \\\"{x:663,y:598,t:1527030811695};\\\", \\\"{x:637,y:595,t:1527030811712};\\\", \\\"{x:597,y:593,t:1527030811729};\\\", \\\"{x:542,y:589,t:1527030811746};\\\", \\\"{x:491,y:589,t:1527030811763};\\\", \\\"{x:449,y:587,t:1527030811778};\\\", \\\"{x:403,y:586,t:1527030811796};\\\", \\\"{x:367,y:584,t:1527030811812};\\\", \\\"{x:346,y:584,t:1527030811829};\\\", \\\"{x:343,y:584,t:1527030811845};\\\", \\\"{x:344,y:584,t:1527030812022};\\\", \\\"{x:347,y:583,t:1527030812030};\\\", \\\"{x:349,y:582,t:1527030812045};\\\", \\\"{x:349,y:583,t:1527030812159};\\\", \\\"{x:349,y:585,t:1527030812166};\\\", \\\"{x:349,y:586,t:1527030812178};\\\", \\\"{x:348,y:587,t:1527030812195};\\\", \\\"{x:347,y:587,t:1527030812213};\\\", \\\"{x:349,y:587,t:1527030812294};\\\", \\\"{x:353,y:587,t:1527030812302};\\\", \\\"{x:356,y:584,t:1527030812313};\\\", \\\"{x:365,y:580,t:1527030812330};\\\", \\\"{x:378,y:575,t:1527030812347};\\\", \\\"{x:390,y:573,t:1527030812362};\\\", \\\"{x:402,y:569,t:1527030812380};\\\", \\\"{x:412,y:565,t:1527030812397};\\\", \\\"{x:419,y:562,t:1527030812412};\\\", \\\"{x:421,y:561,t:1527030812429};\\\", \\\"{x:421,y:560,t:1527030812494};\\\", \\\"{x:424,y:560,t:1527030812750};\\\", \\\"{x:429,y:560,t:1527030812763};\\\", \\\"{x:442,y:560,t:1527030812779};\\\", \\\"{x:461,y:564,t:1527030812796};\\\", \\\"{x:475,y:570,t:1527030812814};\\\", \\\"{x:498,y:576,t:1527030812829};\\\", \\\"{x:500,y:577,t:1527030812847};\\\", \\\"{x:501,y:578,t:1527030812863};\\\", \\\"{x:504,y:578,t:1527030813030};\\\", \\\"{x:514,y:571,t:1527030813048};\\\", \\\"{x:527,y:565,t:1527030813063};\\\", \\\"{x:539,y:560,t:1527030813080};\\\", \\\"{x:548,y:556,t:1527030813096};\\\", \\\"{x:563,y:551,t:1527030813113};\\\", \\\"{x:571,y:549,t:1527030813129};\\\", \\\"{x:575,y:548,t:1527030813147};\\\", \\\"{x:575,y:547,t:1527030813163};\\\", \\\"{x:576,y:547,t:1527030813180};\\\", \\\"{x:577,y:547,t:1527030813197};\\\", \\\"{x:578,y:547,t:1527030813270};\\\", \\\"{x:578,y:548,t:1527030813286};\\\", \\\"{x:578,y:549,t:1527030813297};\\\", \\\"{x:578,y:551,t:1527030813314};\\\", \\\"{x:580,y:552,t:1527030813862};\\\", \\\"{x:581,y:552,t:1527030813870};\\\", \\\"{x:582,y:552,t:1527030813882};\\\", \\\"{x:584,y:552,t:1527030813899};\\\", \\\"{x:589,y:552,t:1527030813915};\\\", \\\"{x:597,y:547,t:1527030813932};\\\", \\\"{x:600,y:544,t:1527030813949};\\\", \\\"{x:605,y:541,t:1527030813966};\\\", \\\"{x:606,y:540,t:1527030813981};\\\", \\\"{x:608,y:539,t:1527030813997};\\\", \\\"{x:612,y:535,t:1527030814014};\\\", \\\"{x:614,y:535,t:1527030814031};\\\", \\\"{x:614,y:534,t:1527030814047};\\\", \\\"{x:615,y:534,t:1527030814063};\\\", \\\"{x:617,y:532,t:1527030814080};\\\", \\\"{x:618,y:531,t:1527030814098};\\\", \\\"{x:620,y:530,t:1527030814117};\\\", \\\"{x:622,y:529,t:1527030814134};\\\", \\\"{x:623,y:529,t:1527030814181};\\\", \\\"{x:625,y:529,t:1527030814197};\\\", \\\"{x:631,y:529,t:1527030814213};\\\", \\\"{x:641,y:529,t:1527030814231};\\\", \\\"{x:657,y:530,t:1527030814247};\\\", \\\"{x:677,y:530,t:1527030814264};\\\", \\\"{x:703,y:530,t:1527030814281};\\\", \\\"{x:730,y:530,t:1527030814298};\\\", \\\"{x:757,y:528,t:1527030814313};\\\", \\\"{x:780,y:523,t:1527030814331};\\\", \\\"{x:791,y:520,t:1527030814347};\\\", \\\"{x:795,y:518,t:1527030814364};\\\", \\\"{x:795,y:517,t:1527030814422};\\\", \\\"{x:796,y:517,t:1527030814431};\\\", \\\"{x:797,y:516,t:1527030814448};\\\", \\\"{x:798,y:515,t:1527030814464};\\\", \\\"{x:800,y:514,t:1527030814481};\\\", \\\"{x:801,y:514,t:1527030814498};\\\", \\\"{x:802,y:513,t:1527030814514};\\\", \\\"{x:803,y:513,t:1527030814542};\\\", \\\"{x:804,y:513,t:1527030814557};\\\", \\\"{x:806,y:513,t:1527030814566};\\\", \\\"{x:809,y:513,t:1527030814581};\\\", \\\"{x:815,y:513,t:1527030814597};\\\", \\\"{x:817,y:512,t:1527030814614};\\\", \\\"{x:820,y:511,t:1527030814630};\\\", \\\"{x:822,y:511,t:1527030814678};\\\", \\\"{x:823,y:511,t:1527030814718};\\\", \\\"{x:825,y:511,t:1527030814766};\\\", \\\"{x:825,y:511,t:1527030814854};\\\", \\\"{x:826,y:511,t:1527030815231};\\\", \\\"{x:837,y:511,t:1527030815247};\\\", \\\"{x:849,y:511,t:1527030815264};\\\", \\\"{x:864,y:511,t:1527030815281};\\\", \\\"{x:889,y:511,t:1527030815297};\\\", \\\"{x:933,y:516,t:1527030815314};\\\", \\\"{x:1000,y:526,t:1527030815332};\\\", \\\"{x:1067,y:537,t:1527030815348};\\\", \\\"{x:1150,y:559,t:1527030815364};\\\", \\\"{x:1283,y:608,t:1527030815381};\\\", \\\"{x:1359,y:638,t:1527030815397};\\\", \\\"{x:1421,y:668,t:1527030815415};\\\", \\\"{x:1454,y:690,t:1527030815432};\\\", \\\"{x:1477,y:704,t:1527030815448};\\\", \\\"{x:1489,y:716,t:1527030815465};\\\", \\\"{x:1493,y:727,t:1527030815482};\\\", \\\"{x:1494,y:736,t:1527030815499};\\\", \\\"{x:1493,y:743,t:1527030815515};\\\", \\\"{x:1489,y:747,t:1527030815532};\\\", \\\"{x:1484,y:752,t:1527030815549};\\\", \\\"{x:1478,y:757,t:1527030815565};\\\", \\\"{x:1473,y:761,t:1527030815582};\\\", \\\"{x:1472,y:763,t:1527030815599};\\\", \\\"{x:1470,y:764,t:1527030815615};\\\", \\\"{x:1469,y:765,t:1527030815671};\\\", \\\"{x:1468,y:766,t:1527030815682};\\\", \\\"{x:1463,y:766,t:1527030815700};\\\", \\\"{x:1456,y:768,t:1527030815715};\\\", \\\"{x:1451,y:769,t:1527030815732};\\\", \\\"{x:1444,y:770,t:1527030815750};\\\", \\\"{x:1439,y:770,t:1527030815766};\\\", \\\"{x:1431,y:770,t:1527030815782};\\\", \\\"{x:1423,y:769,t:1527030815800};\\\", \\\"{x:1409,y:761,t:1527030815815};\\\", \\\"{x:1390,y:747,t:1527030815832};\\\", \\\"{x:1359,y:725,t:1527030815849};\\\", \\\"{x:1323,y:694,t:1527030815866};\\\", \\\"{x:1306,y:675,t:1527030815882};\\\", \\\"{x:1301,y:664,t:1527030815899};\\\", \\\"{x:1299,y:659,t:1527030815915};\\\", \\\"{x:1298,y:653,t:1527030815932};\\\", \\\"{x:1298,y:648,t:1527030815949};\\\", \\\"{x:1298,y:645,t:1527030815966};\\\", \\\"{x:1297,y:645,t:1527030815982};\\\", \\\"{x:1296,y:642,t:1527030816000};\\\", \\\"{x:1296,y:639,t:1527030816016};\\\", \\\"{x:1294,y:635,t:1527030816032};\\\", \\\"{x:1293,y:633,t:1527030816049};\\\", \\\"{x:1292,y:630,t:1527030816067};\\\", \\\"{x:1290,y:624,t:1527030816083};\\\", \\\"{x:1288,y:621,t:1527030816100};\\\", \\\"{x:1288,y:620,t:1527030816117};\\\", \\\"{x:1287,y:617,t:1527030816133};\\\", \\\"{x:1286,y:615,t:1527030816149};\\\", \\\"{x:1286,y:613,t:1527030816173};\\\", \\\"{x:1286,y:612,t:1527030816182};\\\", \\\"{x:1284,y:608,t:1527030816198};\\\", \\\"{x:1283,y:606,t:1527030816216};\\\", \\\"{x:1281,y:604,t:1527030816232};\\\", \\\"{x:1280,y:601,t:1527030816249};\\\", \\\"{x:1280,y:598,t:1527030816266};\\\", \\\"{x:1277,y:594,t:1527030816283};\\\", \\\"{x:1277,y:592,t:1527030816299};\\\", \\\"{x:1274,y:585,t:1527030816316};\\\", \\\"{x:1273,y:584,t:1527030816333};\\\", \\\"{x:1271,y:579,t:1527030816349};\\\", \\\"{x:1269,y:577,t:1527030816366};\\\", \\\"{x:1268,y:575,t:1527030816383};\\\", \\\"{x:1268,y:573,t:1527030816519};\\\", \\\"{x:1268,y:572,t:1527030816623};\\\", \\\"{x:1268,y:570,t:1527030816758};\\\", \\\"{x:1269,y:570,t:1527030816766};\\\", \\\"{x:1269,y:569,t:1527030816790};\\\", \\\"{x:1270,y:569,t:1527030817454};\\\", \\\"{x:1271,y:568,t:1527030817486};\\\", \\\"{x:1272,y:567,t:1527030817502};\\\", \\\"{x:1273,y:567,t:1527030817526};\\\", \\\"{x:1274,y:566,t:1527030817654};\\\", \\\"{x:1274,y:565,t:1527030817823};\\\", \\\"{x:1275,y:565,t:1527030817839};\\\", \\\"{x:1276,y:565,t:1527030818056};\\\", \\\"{x:1277,y:565,t:1527030818083};\\\", \\\"{x:1277,y:566,t:1527030818430};\\\", \\\"{x:1277,y:567,t:1527030818479};\\\", \\\"{x:1277,y:568,t:1527030818496};\\\", \\\"{x:1277,y:569,t:1527030818501};\\\", \\\"{x:1277,y:570,t:1527030818525};\\\", \\\"{x:1277,y:571,t:1527030818541};\\\", \\\"{x:1277,y:572,t:1527030818557};\\\", \\\"{x:1277,y:573,t:1527030818590};\\\", \\\"{x:1277,y:575,t:1527030818605};\\\", \\\"{x:1277,y:576,t:1527030818694};\\\", \\\"{x:1277,y:577,t:1527030818701};\\\", \\\"{x:1277,y:578,t:1527030818718};\\\", \\\"{x:1277,y:579,t:1527030818758};\\\", \\\"{x:1277,y:580,t:1527030818782};\\\", \\\"{x:1277,y:581,t:1527030818790};\\\", \\\"{x:1277,y:582,t:1527030818902};\\\", \\\"{x:1277,y:583,t:1527030818918};\\\", \\\"{x:1277,y:584,t:1527030818934};\\\", \\\"{x:1277,y:585,t:1527030818951};\\\", \\\"{x:1277,y:587,t:1527030818968};\\\", \\\"{x:1277,y:589,t:1527030818986};\\\", \\\"{x:1277,y:590,t:1527030819002};\\\", \\\"{x:1277,y:592,t:1527030819018};\\\", \\\"{x:1277,y:593,t:1527030819035};\\\", \\\"{x:1277,y:595,t:1527030819051};\\\", \\\"{x:1277,y:596,t:1527030819068};\\\", \\\"{x:1277,y:599,t:1527030819085};\\\", \\\"{x:1277,y:600,t:1527030819102};\\\", \\\"{x:1277,y:602,t:1527030819118};\\\", \\\"{x:1277,y:603,t:1527030819135};\\\", \\\"{x:1277,y:605,t:1527030819152};\\\", \\\"{x:1279,y:610,t:1527030819168};\\\", \\\"{x:1281,y:616,t:1527030819185};\\\", \\\"{x:1283,y:622,t:1527030819201};\\\", \\\"{x:1284,y:628,t:1527030819218};\\\", \\\"{x:1287,y:634,t:1527030819236};\\\", \\\"{x:1287,y:641,t:1527030819251};\\\", \\\"{x:1288,y:646,t:1527030819269};\\\", \\\"{x:1291,y:653,t:1527030819286};\\\", \\\"{x:1292,y:661,t:1527030819302};\\\", \\\"{x:1292,y:670,t:1527030819318};\\\", \\\"{x:1293,y:676,t:1527030819335};\\\", \\\"{x:1293,y:680,t:1527030819351};\\\", \\\"{x:1295,y:683,t:1527030819368};\\\", \\\"{x:1295,y:685,t:1527030819385};\\\", \\\"{x:1295,y:686,t:1527030819402};\\\", \\\"{x:1295,y:688,t:1527030819418};\\\", \\\"{x:1295,y:689,t:1527030819439};\\\", \\\"{x:1295,y:690,t:1527030819462};\\\", \\\"{x:1295,y:691,t:1527030819478};\\\", \\\"{x:1295,y:692,t:1527030819495};\\\", \\\"{x:1295,y:693,t:1527030819534};\\\", \\\"{x:1295,y:695,t:1527030819552};\\\", \\\"{x:1295,y:696,t:1527030819569};\\\", \\\"{x:1294,y:698,t:1527030819586};\\\", \\\"{x:1294,y:699,t:1527030819602};\\\", \\\"{x:1294,y:700,t:1527030819618};\\\", \\\"{x:1293,y:702,t:1527030819635};\\\", \\\"{x:1292,y:703,t:1527030819662};\\\", \\\"{x:1291,y:704,t:1527030819830};\\\", \\\"{x:1291,y:703,t:1527030819854};\\\", \\\"{x:1291,y:701,t:1527030819869};\\\", \\\"{x:1291,y:696,t:1527030819886};\\\", \\\"{x:1291,y:691,t:1527030819902};\\\", \\\"{x:1291,y:689,t:1527030819920};\\\", \\\"{x:1290,y:687,t:1527030819935};\\\", \\\"{x:1290,y:686,t:1527030819966};\\\", \\\"{x:1290,y:685,t:1527030820022};\\\", \\\"{x:1289,y:684,t:1527030820095};\\\", \\\"{x:1288,y:684,t:1527030820110};\\\", \\\"{x:1287,y:684,t:1527030820120};\\\", \\\"{x:1285,y:684,t:1527030820142};\\\", \\\"{x:1285,y:685,t:1527030820153};\\\", \\\"{x:1283,y:687,t:1527030820170};\\\", \\\"{x:1281,y:689,t:1527030820185};\\\", \\\"{x:1279,y:692,t:1527030820202};\\\", \\\"{x:1279,y:695,t:1527030820219};\\\", \\\"{x:1279,y:696,t:1527030820236};\\\", \\\"{x:1279,y:699,t:1527030820253};\\\", \\\"{x:1279,y:701,t:1527030820269};\\\", \\\"{x:1278,y:705,t:1527030820286};\\\", \\\"{x:1278,y:708,t:1527030820303};\\\", \\\"{x:1278,y:709,t:1527030820320};\\\", \\\"{x:1278,y:711,t:1527030820336};\\\", \\\"{x:1278,y:712,t:1527030820358};\\\", \\\"{x:1278,y:715,t:1527030820374};\\\", \\\"{x:1278,y:718,t:1527030820387};\\\", \\\"{x:1280,y:727,t:1527030820403};\\\", \\\"{x:1280,y:735,t:1527030820420};\\\", \\\"{x:1280,y:740,t:1527030820436};\\\", \\\"{x:1280,y:746,t:1527030820453};\\\", \\\"{x:1280,y:750,t:1527030820469};\\\", \\\"{x:1280,y:759,t:1527030820486};\\\", \\\"{x:1282,y:773,t:1527030820502};\\\", \\\"{x:1285,y:786,t:1527030820520};\\\", \\\"{x:1289,y:799,t:1527030820537};\\\", \\\"{x:1291,y:808,t:1527030820553};\\\", \\\"{x:1291,y:811,t:1527030820570};\\\", \\\"{x:1291,y:814,t:1527030820586};\\\", \\\"{x:1291,y:816,t:1527030820603};\\\", \\\"{x:1291,y:819,t:1527030820620};\\\", \\\"{x:1291,y:822,t:1527030820636};\\\", \\\"{x:1291,y:829,t:1527030820652};\\\", \\\"{x:1289,y:836,t:1527030820669};\\\", \\\"{x:1280,y:850,t:1527030820686};\\\", \\\"{x:1277,y:855,t:1527030820704};\\\", \\\"{x:1274,y:858,t:1527030820720};\\\", \\\"{x:1272,y:862,t:1527030820736};\\\", \\\"{x:1271,y:865,t:1527030820753};\\\", \\\"{x:1268,y:868,t:1527030820769};\\\", \\\"{x:1268,y:871,t:1527030820786};\\\", \\\"{x:1267,y:875,t:1527030820804};\\\", \\\"{x:1266,y:878,t:1527030820820};\\\", \\\"{x:1265,y:880,t:1527030820836};\\\", \\\"{x:1264,y:883,t:1527030820854};\\\", \\\"{x:1264,y:884,t:1527030820878};\\\", \\\"{x:1264,y:885,t:1527030820887};\\\", \\\"{x:1264,y:886,t:1527030820903};\\\", \\\"{x:1264,y:888,t:1527030820920};\\\", \\\"{x:1266,y:892,t:1527030820936};\\\", \\\"{x:1267,y:894,t:1527030820953};\\\", \\\"{x:1269,y:897,t:1527030820969};\\\", \\\"{x:1270,y:899,t:1527030820987};\\\", \\\"{x:1272,y:903,t:1527030821003};\\\", \\\"{x:1273,y:907,t:1527030821019};\\\", \\\"{x:1274,y:912,t:1527030821036};\\\", \\\"{x:1274,y:918,t:1527030821053};\\\", \\\"{x:1274,y:922,t:1527030821069};\\\", \\\"{x:1274,y:927,t:1527030821086};\\\", \\\"{x:1274,y:933,t:1527030821103};\\\", \\\"{x:1276,y:941,t:1527030821119};\\\", \\\"{x:1276,y:944,t:1527030821137};\\\", \\\"{x:1276,y:947,t:1527030821154};\\\", \\\"{x:1276,y:950,t:1527030821170};\\\", \\\"{x:1276,y:951,t:1527030821187};\\\", \\\"{x:1276,y:953,t:1527030821207};\\\", \\\"{x:1276,y:954,t:1527030821229};\\\", \\\"{x:1276,y:956,t:1527030821310};\\\", \\\"{x:1276,y:957,t:1527030821389};\\\", \\\"{x:1276,y:958,t:1527030821479};\\\", \\\"{x:1276,y:959,t:1527030821502};\\\", \\\"{x:1276,y:960,t:1527030821774};\\\", \\\"{x:1279,y:967,t:1527030821788};\\\", \\\"{x:1287,y:978,t:1527030821804};\\\", \\\"{x:1287,y:979,t:1527030821820};\\\", \\\"{x:1287,y:980,t:1527030821934};\\\", \\\"{x:1288,y:980,t:1527030821998};\\\", \\\"{x:1288,y:978,t:1527030822014};\\\", \\\"{x:1289,y:977,t:1527030822030};\\\", \\\"{x:1290,y:975,t:1527030822054};\\\", \\\"{x:1290,y:973,t:1527030822086};\\\", \\\"{x:1290,y:971,t:1527030822094};\\\", \\\"{x:1290,y:970,t:1527030822105};\\\", \\\"{x:1294,y:965,t:1527030822121};\\\", \\\"{x:1304,y:958,t:1527030822137};\\\", \\\"{x:1314,y:953,t:1527030822154};\\\", \\\"{x:1322,y:948,t:1527030822170};\\\", \\\"{x:1326,y:946,t:1527030822187};\\\", \\\"{x:1329,y:946,t:1527030822204};\\\", \\\"{x:1331,y:946,t:1527030822220};\\\", \\\"{x:1336,y:946,t:1527030822238};\\\", \\\"{x:1338,y:946,t:1527030822254};\\\", \\\"{x:1339,y:947,t:1527030822294};\\\", \\\"{x:1340,y:947,t:1527030822311};\\\", \\\"{x:1340,y:948,t:1527030822321};\\\", \\\"{x:1342,y:951,t:1527030822337};\\\", \\\"{x:1342,y:953,t:1527030822355};\\\", \\\"{x:1343,y:955,t:1527030822370};\\\", \\\"{x:1343,y:958,t:1527030822388};\\\", \\\"{x:1344,y:960,t:1527030822404};\\\", \\\"{x:1345,y:960,t:1527030822454};\\\", \\\"{x:1346,y:961,t:1527030822472};\\\", \\\"{x:1348,y:962,t:1527030822488};\\\", \\\"{x:1348,y:963,t:1527030822505};\\\", \\\"{x:1350,y:964,t:1527030822522};\\\", \\\"{x:1350,y:963,t:1527030822655};\\\", \\\"{x:1352,y:961,t:1527030822672};\\\", \\\"{x:1358,y:958,t:1527030822687};\\\", \\\"{x:1368,y:957,t:1527030822704};\\\", \\\"{x:1382,y:957,t:1527030822721};\\\", \\\"{x:1393,y:957,t:1527030822738};\\\", \\\"{x:1407,y:957,t:1527030822755};\\\", \\\"{x:1416,y:957,t:1527030822771};\\\", \\\"{x:1426,y:958,t:1527030822788};\\\", \\\"{x:1428,y:958,t:1527030822805};\\\", \\\"{x:1429,y:958,t:1527030822821};\\\", \\\"{x:1429,y:959,t:1527030822862};\\\", \\\"{x:1429,y:961,t:1527030822886};\\\", \\\"{x:1431,y:961,t:1527030822910};\\\", \\\"{x:1432,y:961,t:1527030822943};\\\", \\\"{x:1432,y:962,t:1527030823094};\\\", \\\"{x:1432,y:963,t:1527030823110};\\\", \\\"{x:1432,y:964,t:1527030823134};\\\", \\\"{x:1432,y:965,t:1527030823158};\\\", \\\"{x:1431,y:966,t:1527030823171};\\\", \\\"{x:1428,y:966,t:1527030823189};\\\", \\\"{x:1426,y:967,t:1527030823205};\\\", \\\"{x:1425,y:968,t:1527030823222};\\\", \\\"{x:1424,y:968,t:1527030823239};\\\", \\\"{x:1423,y:969,t:1527030823341};\\\", \\\"{x:1424,y:967,t:1527030823511};\\\", \\\"{x:1426,y:966,t:1527030823521};\\\", \\\"{x:1429,y:966,t:1527030823538};\\\", \\\"{x:1436,y:966,t:1527030823556};\\\", \\\"{x:1448,y:966,t:1527030823572};\\\", \\\"{x:1461,y:966,t:1527030823589};\\\", \\\"{x:1473,y:966,t:1527030823606};\\\", \\\"{x:1477,y:966,t:1527030823622};\\\", \\\"{x:1477,y:967,t:1527030823639};\\\", \\\"{x:1477,y:969,t:1527030823655};\\\", \\\"{x:1477,y:970,t:1527030823672};\\\", \\\"{x:1477,y:971,t:1527030823689};\\\", \\\"{x:1477,y:972,t:1527030823706};\\\", \\\"{x:1477,y:973,t:1527030823721};\\\", \\\"{x:1478,y:973,t:1527030823750};\\\", \\\"{x:1479,y:973,t:1527030823814};\\\", \\\"{x:1480,y:973,t:1527030823878};\\\", \\\"{x:1481,y:973,t:1527030823902};\\\", \\\"{x:1482,y:973,t:1527030823910};\\\", \\\"{x:1483,y:973,t:1527030823922};\\\", \\\"{x:1484,y:973,t:1527030823958};\\\", \\\"{x:1483,y:973,t:1527030824807};\\\", \\\"{x:1477,y:973,t:1527030824823};\\\", \\\"{x:1465,y:972,t:1527030824839};\\\", \\\"{x:1456,y:967,t:1527030824857};\\\", \\\"{x:1442,y:954,t:1527030824873};\\\", \\\"{x:1426,y:923,t:1527030824889};\\\", \\\"{x:1413,y:875,t:1527030824907};\\\", \\\"{x:1403,y:845,t:1527030824923};\\\", \\\"{x:1398,y:825,t:1527030824940};\\\", \\\"{x:1395,y:810,t:1527030824957};\\\", \\\"{x:1394,y:799,t:1527030824973};\\\", \\\"{x:1388,y:785,t:1527030824990};\\\", \\\"{x:1378,y:766,t:1527030825006};\\\", \\\"{x:1372,y:747,t:1527030825023};\\\", \\\"{x:1367,y:725,t:1527030825039};\\\", \\\"{x:1366,y:710,t:1527030825056};\\\", \\\"{x:1364,y:701,t:1527030825073};\\\", \\\"{x:1358,y:684,t:1527030825089};\\\", \\\"{x:1348,y:667,t:1527030825107};\\\", \\\"{x:1343,y:659,t:1527030825123};\\\", \\\"{x:1341,y:658,t:1527030825139};\\\", \\\"{x:1334,y:650,t:1527030825157};\\\", \\\"{x:1315,y:633,t:1527030825173};\\\", \\\"{x:1285,y:616,t:1527030825190};\\\", \\\"{x:1268,y:612,t:1527030825209};\\\", \\\"{x:1246,y:608,t:1527030825227};\\\", \\\"{x:1201,y:607,t:1527030825243};\\\", \\\"{x:1140,y:598,t:1527030825260};\\\", \\\"{x:1055,y:591,t:1527030825277};\\\", \\\"{x:952,y:577,t:1527030825293};\\\", \\\"{x:847,y:577,t:1527030825311};\\\", \\\"{x:728,y:577,t:1527030825326};\\\", \\\"{x:590,y:577,t:1527030825342};\\\", \\\"{x:457,y:577,t:1527030825360};\\\", \\\"{x:309,y:575,t:1527030825376};\\\", \\\"{x:248,y:567,t:1527030825393};\\\", \\\"{x:207,y:563,t:1527030825409};\\\", \\\"{x:180,y:563,t:1527030825426};\\\", \\\"{x:163,y:561,t:1527030825442};\\\", \\\"{x:157,y:559,t:1527030825459};\\\", \\\"{x:157,y:557,t:1527030825488};\\\", \\\"{x:155,y:554,t:1527030825496};\\\", \\\"{x:155,y:553,t:1527030825509};\\\", \\\"{x:155,y:551,t:1527030825527};\\\", \\\"{x:154,y:549,t:1527030825543};\\\", \\\"{x:156,y:548,t:1527030825585};\\\", \\\"{x:160,y:547,t:1527030825593};\\\", \\\"{x:174,y:543,t:1527030825610};\\\", \\\"{x:191,y:538,t:1527030825628};\\\", \\\"{x:219,y:532,t:1527030825643};\\\", \\\"{x:250,y:527,t:1527030825660};\\\", \\\"{x:281,y:521,t:1527030825676};\\\", \\\"{x:317,y:518,t:1527030825694};\\\", \\\"{x:338,y:515,t:1527030825709};\\\", \\\"{x:344,y:515,t:1527030825726};\\\", \\\"{x:345,y:515,t:1527030825743};\\\", \\\"{x:345,y:516,t:1527030825833};\\\", \\\"{x:345,y:518,t:1527030825849};\\\", \\\"{x:352,y:522,t:1527030825865};\\\", \\\"{x:364,y:528,t:1527030825877};\\\", \\\"{x:433,y:548,t:1527030825895};\\\", \\\"{x:497,y:556,t:1527030825910};\\\", \\\"{x:561,y:565,t:1527030825927};\\\", \\\"{x:638,y:574,t:1527030825943};\\\", \\\"{x:691,y:574,t:1527030825959};\\\", \\\"{x:723,y:574,t:1527030825976};\\\", \\\"{x:724,y:574,t:1527030825993};\\\", \\\"{x:721,y:574,t:1527030826040};\\\", \\\"{x:715,y:572,t:1527030826048};\\\", \\\"{x:705,y:568,t:1527030826060};\\\", \\\"{x:685,y:561,t:1527030826076};\\\", \\\"{x:674,y:558,t:1527030826093};\\\", \\\"{x:669,y:556,t:1527030826110};\\\", \\\"{x:666,y:555,t:1527030826126};\\\", \\\"{x:665,y:554,t:1527030826143};\\\", \\\"{x:664,y:554,t:1527030826209};\\\", \\\"{x:663,y:553,t:1527030826224};\\\", \\\"{x:662,y:552,t:1527030826232};\\\", \\\"{x:660,y:552,t:1527030826244};\\\", \\\"{x:655,y:550,t:1527030826260};\\\", \\\"{x:649,y:547,t:1527030826277};\\\", \\\"{x:641,y:544,t:1527030826294};\\\", \\\"{x:632,y:540,t:1527030826310};\\\", \\\"{x:624,y:536,t:1527030826328};\\\", \\\"{x:617,y:535,t:1527030826343};\\\", \\\"{x:610,y:531,t:1527030826362};\\\", \\\"{x:608,y:531,t:1527030826376};\\\", \\\"{x:608,y:530,t:1527030826497};\\\", \\\"{x:608,y:529,t:1527030826513};\\\", \\\"{x:608,y:528,t:1527030826528};\\\", \\\"{x:608,y:526,t:1527030826544};\\\", \\\"{x:608,y:525,t:1527030826560};\\\", \\\"{x:609,y:525,t:1527030826577};\\\", \\\"{x:609,y:523,t:1527030826632};\\\", \\\"{x:609,y:522,t:1527030826648};\\\", \\\"{x:609,y:521,t:1527030826664};\\\", \\\"{x:612,y:521,t:1527030827730};\\\", \\\"{x:650,y:527,t:1527030827746};\\\", \\\"{x:730,y:538,t:1527030827763};\\\", \\\"{x:833,y:552,t:1527030827779};\\\", \\\"{x:938,y:564,t:1527030827795};\\\", \\\"{x:1048,y:578,t:1527030827811};\\\", \\\"{x:1124,y:590,t:1527030827828};\\\", \\\"{x:1167,y:599,t:1527030827844};\\\", \\\"{x:1182,y:604,t:1527030827862};\\\", \\\"{x:1189,y:610,t:1527030827879};\\\", \\\"{x:1193,y:617,t:1527030827894};\\\", \\\"{x:1194,y:624,t:1527030827912};\\\", \\\"{x:1194,y:631,t:1527030827928};\\\", \\\"{x:1193,y:636,t:1527030827945};\\\", \\\"{x:1193,y:638,t:1527030827961};\\\", \\\"{x:1193,y:643,t:1527030827978};\\\", \\\"{x:1193,y:648,t:1527030827996};\\\", \\\"{x:1193,y:655,t:1527030828012};\\\", \\\"{x:1193,y:658,t:1527030828029};\\\", \\\"{x:1193,y:659,t:1527030828097};\\\", \\\"{x:1194,y:660,t:1527030828112};\\\", \\\"{x:1203,y:665,t:1527030828129};\\\", \\\"{x:1211,y:670,t:1527030828146};\\\", \\\"{x:1222,y:677,t:1527030828163};\\\", \\\"{x:1242,y:689,t:1527030828179};\\\", \\\"{x:1259,y:697,t:1527030828196};\\\", \\\"{x:1267,y:699,t:1527030828213};\\\", \\\"{x:1275,y:703,t:1527030828229};\\\", \\\"{x:1280,y:705,t:1527030828246};\\\", \\\"{x:1284,y:707,t:1527030828263};\\\", \\\"{x:1286,y:707,t:1527030828330};\\\", \\\"{x:1287,y:707,t:1527030828353};\\\", \\\"{x:1289,y:706,t:1527030828369};\\\", \\\"{x:1292,y:706,t:1527030828379};\\\", \\\"{x:1298,y:706,t:1527030828396};\\\", \\\"{x:1304,y:705,t:1527030828413};\\\", \\\"{x:1309,y:704,t:1527030828430};\\\", \\\"{x:1314,y:703,t:1527030828447};\\\", \\\"{x:1318,y:701,t:1527030828463};\\\", \\\"{x:1320,y:701,t:1527030828480};\\\", \\\"{x:1321,y:701,t:1527030828496};\\\", \\\"{x:1323,y:701,t:1527030828513};\\\", \\\"{x:1327,y:701,t:1527030828530};\\\", \\\"{x:1332,y:699,t:1527030828546};\\\", \\\"{x:1333,y:699,t:1527030828563};\\\", \\\"{x:1334,y:698,t:1527030828580};\\\", \\\"{x:1336,y:698,t:1527030828597};\\\", \\\"{x:1337,y:698,t:1527030828641};\\\", \\\"{x:1338,y:698,t:1527030828673};\\\", \\\"{x:1338,y:699,t:1527030828681};\\\", \\\"{x:1339,y:699,t:1527030828705};\\\", \\\"{x:1340,y:699,t:1527030828761};\\\", \\\"{x:1340,y:700,t:1527030828793};\\\", \\\"{x:1340,y:701,t:1527030828809};\\\", \\\"{x:1340,y:702,t:1527030828825};\\\", \\\"{x:1340,y:703,t:1527030828850};\\\", \\\"{x:1340,y:705,t:1527030828890};\\\", \\\"{x:1341,y:705,t:1527030828897};\\\", \\\"{x:1341,y:706,t:1527030828913};\\\", \\\"{x:1341,y:707,t:1527030828930};\\\", \\\"{x:1341,y:708,t:1527030828970};\\\", \\\"{x:1343,y:712,t:1527030828985};\\\", \\\"{x:1344,y:714,t:1527030828997};\\\", \\\"{x:1344,y:715,t:1527030829014};\\\", \\\"{x:1344,y:717,t:1527030829030};\\\", \\\"{x:1344,y:718,t:1527030829047};\\\", \\\"{x:1344,y:719,t:1527030829073};\\\", \\\"{x:1344,y:721,t:1527030829089};\\\", \\\"{x:1344,y:722,t:1527030829113};\\\", \\\"{x:1344,y:724,t:1527030829131};\\\", \\\"{x:1344,y:725,t:1527030829153};\\\", \\\"{x:1344,y:726,t:1527030829169};\\\", \\\"{x:1342,y:727,t:1527030829201};\\\", \\\"{x:1340,y:728,t:1527030829214};\\\", \\\"{x:1333,y:729,t:1527030829230};\\\", \\\"{x:1320,y:734,t:1527030829248};\\\", \\\"{x:1303,y:736,t:1527030829263};\\\", \\\"{x:1281,y:742,t:1527030829281};\\\", \\\"{x:1263,y:746,t:1527030829298};\\\", \\\"{x:1244,y:747,t:1527030829314};\\\", \\\"{x:1226,y:748,t:1527030829331};\\\", \\\"{x:1206,y:748,t:1527030829348};\\\", \\\"{x:1189,y:748,t:1527030829364};\\\", \\\"{x:1177,y:748,t:1527030829381};\\\", \\\"{x:1171,y:748,t:1527030829398};\\\", \\\"{x:1170,y:748,t:1527030829413};\\\", \\\"{x:1169,y:748,t:1527030829430};\\\", \\\"{x:1167,y:748,t:1527030829447};\\\", \\\"{x:1158,y:748,t:1527030829464};\\\", \\\"{x:1134,y:747,t:1527030829480};\\\", \\\"{x:1114,y:745,t:1527030829498};\\\", \\\"{x:1092,y:741,t:1527030829515};\\\", \\\"{x:1071,y:738,t:1527030829531};\\\", \\\"{x:1049,y:734,t:1527030829548};\\\", \\\"{x:1025,y:728,t:1527030829565};\\\", \\\"{x:1004,y:724,t:1527030829581};\\\", \\\"{x:989,y:723,t:1527030829598};\\\", \\\"{x:981,y:722,t:1527030829615};\\\", \\\"{x:979,y:721,t:1527030829631};\\\", \\\"{x:985,y:721,t:1527030829770};\\\", \\\"{x:995,y:725,t:1527030829782};\\\", \\\"{x:1018,y:728,t:1527030829798};\\\", \\\"{x:1046,y:733,t:1527030829815};\\\", \\\"{x:1064,y:736,t:1527030829832};\\\", \\\"{x:1079,y:739,t:1527030829849};\\\", \\\"{x:1085,y:741,t:1527030829865};\\\", \\\"{x:1089,y:741,t:1527030830265};\\\", \\\"{x:1100,y:740,t:1527030830282};\\\", \\\"{x:1116,y:737,t:1527030830299};\\\", \\\"{x:1137,y:734,t:1527030830316};\\\", \\\"{x:1156,y:730,t:1527030830332};\\\", \\\"{x:1165,y:727,t:1527030830349};\\\", \\\"{x:1169,y:726,t:1527030830366};\\\", \\\"{x:1170,y:725,t:1527030830383};\\\", \\\"{x:1171,y:723,t:1527030830399};\\\", \\\"{x:1173,y:721,t:1527030830416};\\\", \\\"{x:1176,y:715,t:1527030830433};\\\", \\\"{x:1178,y:713,t:1527030830449};\\\", \\\"{x:1183,y:709,t:1527030830466};\\\", \\\"{x:1187,y:706,t:1527030830483};\\\", \\\"{x:1193,y:703,t:1527030830499};\\\", \\\"{x:1201,y:699,t:1527030830516};\\\", \\\"{x:1210,y:697,t:1527030830534};\\\", \\\"{x:1215,y:694,t:1527030830551};\\\", \\\"{x:1221,y:693,t:1527030830566};\\\", \\\"{x:1226,y:691,t:1527030830582};\\\", \\\"{x:1235,y:690,t:1527030830600};\\\", \\\"{x:1241,y:690,t:1527030830616};\\\", \\\"{x:1248,y:690,t:1527030830632};\\\", \\\"{x:1249,y:690,t:1527030830649};\\\", \\\"{x:1250,y:690,t:1527030830737};\\\", \\\"{x:1251,y:690,t:1527030830750};\\\", \\\"{x:1252,y:690,t:1527030830766};\\\", \\\"{x:1254,y:690,t:1527030830818};\\\", \\\"{x:1256,y:690,t:1527030830833};\\\", \\\"{x:1259,y:690,t:1527030830850};\\\", \\\"{x:1268,y:691,t:1527030830867};\\\", \\\"{x:1290,y:698,t:1527030830884};\\\", \\\"{x:1309,y:703,t:1527030830900};\\\", \\\"{x:1325,y:705,t:1527030830917};\\\", \\\"{x:1334,y:706,t:1527030830933};\\\", \\\"{x:1338,y:707,t:1527030830950};\\\", \\\"{x:1339,y:707,t:1527030830967};\\\", \\\"{x:1340,y:707,t:1527030830983};\\\", \\\"{x:1340,y:708,t:1527030831017};\\\", \\\"{x:1340,y:710,t:1527030831769};\\\", \\\"{x:1339,y:710,t:1527030831793};\\\", \\\"{x:1338,y:711,t:1527030831801};\\\", \\\"{x:1338,y:712,t:1527030831818};\\\", \\\"{x:1337,y:712,t:1527030831835};\\\", \\\"{x:1336,y:712,t:1527030831864};\\\", \\\"{x:1333,y:712,t:1527030831873};\\\", \\\"{x:1332,y:712,t:1527030831889};\\\", \\\"{x:1328,y:711,t:1527030831901};\\\", \\\"{x:1325,y:710,t:1527030831918};\\\", \\\"{x:1322,y:710,t:1527030831935};\\\", \\\"{x:1321,y:709,t:1527030831951};\\\", \\\"{x:1320,y:709,t:1527030831968};\\\", \\\"{x:1316,y:709,t:1527030831985};\\\", \\\"{x:1307,y:709,t:1527030832002};\\\", \\\"{x:1296,y:709,t:1527030832017};\\\", \\\"{x:1277,y:709,t:1527030832034};\\\", \\\"{x:1250,y:706,t:1527030832052};\\\", \\\"{x:1221,y:703,t:1527030832068};\\\", \\\"{x:1194,y:699,t:1527030832086};\\\", \\\"{x:1158,y:688,t:1527030832103};\\\", \\\"{x:1107,y:672,t:1527030832118};\\\", \\\"{x:1035,y:651,t:1527030832135};\\\", \\\"{x:965,y:627,t:1527030832152};\\\", \\\"{x:899,y:614,t:1527030832168};\\\", \\\"{x:869,y:610,t:1527030832185};\\\", \\\"{x:841,y:605,t:1527030832203};\\\", \\\"{x:820,y:603,t:1527030832219};\\\", \\\"{x:813,y:601,t:1527030832232};\\\", \\\"{x:790,y:601,t:1527030832248};\\\", \\\"{x:773,y:601,t:1527030832266};\\\", \\\"{x:763,y:601,t:1527030832282};\\\", \\\"{x:757,y:601,t:1527030832298};\\\", \\\"{x:749,y:602,t:1527030832316};\\\", \\\"{x:732,y:604,t:1527030832332};\\\", \\\"{x:707,y:606,t:1527030832351};\\\", \\\"{x:678,y:608,t:1527030832365};\\\", \\\"{x:651,y:608,t:1527030832381};\\\", \\\"{x:615,y:608,t:1527030832398};\\\", \\\"{x:563,y:604,t:1527030832415};\\\", \\\"{x:513,y:596,t:1527030832432};\\\", \\\"{x:476,y:590,t:1527030832448};\\\", \\\"{x:466,y:590,t:1527030832464};\\\", \\\"{x:458,y:588,t:1527030832481};\\\", \\\"{x:454,y:586,t:1527030832499};\\\", \\\"{x:450,y:586,t:1527030832514};\\\", \\\"{x:447,y:586,t:1527030832532};\\\", \\\"{x:445,y:586,t:1527030832549};\\\", \\\"{x:440,y:586,t:1527030832565};\\\", \\\"{x:431,y:586,t:1527030832582};\\\", \\\"{x:416,y:586,t:1527030832600};\\\", \\\"{x:398,y:585,t:1527030832615};\\\", \\\"{x:372,y:581,t:1527030832632};\\\", \\\"{x:324,y:575,t:1527030832649};\\\", \\\"{x:301,y:571,t:1527030832666};\\\", \\\"{x:287,y:569,t:1527030832682};\\\", \\\"{x:280,y:568,t:1527030832698};\\\", \\\"{x:276,y:568,t:1527030832716};\\\", \\\"{x:273,y:568,t:1527030832732};\\\", \\\"{x:272,y:568,t:1527030832750};\\\", \\\"{x:269,y:569,t:1527030832765};\\\", \\\"{x:265,y:572,t:1527030832782};\\\", \\\"{x:262,y:574,t:1527030832798};\\\", \\\"{x:257,y:577,t:1527030832816};\\\", \\\"{x:249,y:581,t:1527030832832};\\\", \\\"{x:246,y:582,t:1527030832848};\\\", \\\"{x:245,y:583,t:1527030832865};\\\", \\\"{x:245,y:584,t:1527030832881};\\\", \\\"{x:246,y:586,t:1527030832899};\\\", \\\"{x:252,y:586,t:1527030832916};\\\", \\\"{x:263,y:584,t:1527030832932};\\\", \\\"{x:283,y:581,t:1527030832949};\\\", \\\"{x:306,y:580,t:1527030832966};\\\", \\\"{x:335,y:580,t:1527030832983};\\\", \\\"{x:358,y:580,t:1527030832998};\\\", \\\"{x:375,y:580,t:1527030833016};\\\", \\\"{x:385,y:578,t:1527030833032};\\\", \\\"{x:389,y:576,t:1527030833049};\\\", \\\"{x:392,y:575,t:1527030833065};\\\", \\\"{x:394,y:574,t:1527030833082};\\\", \\\"{x:396,y:572,t:1527030833099};\\\", \\\"{x:396,y:570,t:1527030833115};\\\", \\\"{x:399,y:567,t:1527030833133};\\\", \\\"{x:404,y:565,t:1527030833149};\\\", \\\"{x:411,y:562,t:1527030833166};\\\", \\\"{x:418,y:558,t:1527030833182};\\\", \\\"{x:429,y:554,t:1527030833199};\\\", \\\"{x:435,y:551,t:1527030833216};\\\", \\\"{x:441,y:549,t:1527030833233};\\\", \\\"{x:443,y:548,t:1527030833250};\\\", \\\"{x:450,y:546,t:1527030833265};\\\", \\\"{x:458,y:545,t:1527030833282};\\\", \\\"{x:467,y:544,t:1527030833299};\\\", \\\"{x:476,y:540,t:1527030833316};\\\", \\\"{x:490,y:535,t:1527030833333};\\\", \\\"{x:512,y:532,t:1527030833350};\\\", \\\"{x:537,y:530,t:1527030833366};\\\", \\\"{x:562,y:528,t:1527030833382};\\\", \\\"{x:584,y:526,t:1527030833398};\\\", \\\"{x:604,y:526,t:1527030833415};\\\", \\\"{x:635,y:526,t:1527030833432};\\\", \\\"{x:660,y:526,t:1527030833450};\\\", \\\"{x:678,y:527,t:1527030833465};\\\", \\\"{x:689,y:527,t:1527030833483};\\\", \\\"{x:699,y:527,t:1527030833499};\\\", \\\"{x:714,y:527,t:1527030833515};\\\", \\\"{x:735,y:527,t:1527030833533};\\\", \\\"{x:757,y:526,t:1527030833549};\\\", \\\"{x:779,y:523,t:1527030833565};\\\", \\\"{x:800,y:519,t:1527030833582};\\\", \\\"{x:815,y:518,t:1527030833600};\\\", \\\"{x:830,y:517,t:1527030833617};\\\", \\\"{x:838,y:517,t:1527030833632};\\\", \\\"{x:845,y:517,t:1527030833649};\\\", \\\"{x:847,y:517,t:1527030833666};\\\", \\\"{x:848,y:516,t:1527030833682};\\\", \\\"{x:849,y:516,t:1527030833729};\\\", \\\"{x:850,y:516,t:1527030833737};\\\", \\\"{x:850,y:518,t:1527030833793};\\\", \\\"{x:850,y:519,t:1527030833809};\\\", \\\"{x:849,y:519,t:1527030834265};\\\", \\\"{x:843,y:523,t:1527030834273};\\\", \\\"{x:835,y:527,t:1527030834283};\\\", \\\"{x:816,y:539,t:1527030834302};\\\", \\\"{x:795,y:552,t:1527030834316};\\\", \\\"{x:748,y:579,t:1527030834334};\\\", \\\"{x:686,y:612,t:1527030834350};\\\", \\\"{x:634,y:642,t:1527030834367};\\\", \\\"{x:609,y:664,t:1527030834384};\\\", \\\"{x:593,y:679,t:1527030834400};\\\", \\\"{x:569,y:695,t:1527030834416};\\\", \\\"{x:562,y:697,t:1527030834433};\\\", \\\"{x:560,y:698,t:1527030834450};\\\", \\\"{x:559,y:698,t:1527030834467};\\\", \\\"{x:554,y:700,t:1527030834484};\\\", \\\"{x:552,y:701,t:1527030834499};\\\", \\\"{x:549,y:704,t:1527030834517};\\\", \\\"{x:546,y:707,t:1527030834534};\\\", \\\"{x:544,y:710,t:1527030834550};\\\", \\\"{x:541,y:714,t:1527030834567};\\\", \\\"{x:538,y:718,t:1527030834584};\\\", \\\"{x:533,y:724,t:1527030834601};\\\", \\\"{x:528,y:735,t:1527030834618};\\\", \\\"{x:527,y:743,t:1527030834634};\\\", \\\"{x:525,y:750,t:1527030834650};\\\", \\\"{x:525,y:751,t:1527030834665};\\\", \\\"{x:525,y:752,t:1527030834683};\\\", \\\"{x:525,y:753,t:1527030834721};\\\", \\\"{x:526,y:753,t:1527030834768};\\\", \\\"{x:526,y:753,t:1527030834856};\\\" ] }, { \\\"rt\\\": 43585, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 835052, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"If you see the dot vertically above the 12 pm, then that is the shift that starts at 12 pm\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9062, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"South Korea\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 845120, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14187, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 860322, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 37211, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 898832, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"BEGT5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"BEGT5\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 150, dom: 634, initialDom: 741",
  "javascriptErrors": []
}