var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052117323f12f5914b63320bc5427f704a71337a"] = {
  "startTime": "2018-05-21T19:21:16.7792881Z",
  "websitePageUrl": "/16",
  "visitTime": 106757,
  "engagementTime": 104910,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "70e6ba9b3e85fec9208b454e7aa3f166",
    "created": "2018-05-21T19:21:16.7792881+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=F3GZE",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c473ba718abd0b238b285f1e3560b631",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/70e6ba9b3e85fec9208b454e7aa3f166/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 2,
      "x": 923,
      "y": 607
    },
    {
      "t": 100,
      "e": 100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 1108,
      "y": 593
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 37881,
      "y": 32407,
      "ta": "html > body"
    },
    {
      "t": 685,
      "e": 685,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 1104,
      "y": 596
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 21987,
      "y": 33089,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 1095,
      "y": 608
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 1092,
      "y": 630
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 1124,
      "y": 725
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 23819,
      "y": 42042,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1161,
      "y": 833
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1170,
      "y": 861
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 27131,
      "y": 52857,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 1171,
      "y": 889
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1167,
      "y": 924
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1166,
      "y": 935
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 26778,
      "y": 57083,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1164,
      "y": 936
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1159,
      "y": 942
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 25580,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1145,
      "y": 955
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1144,
      "y": 957
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 25228,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1144,
      "y": 961
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1145,
      "y": 978
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 27650,
      "y": 53503,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1158,
      "y": 985
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1159,
      "y": 985
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1163,
      "y": 984
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 48710,
      "y": 61695,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1167,
      "y": 979
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1170,
      "y": 973
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 63290,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1172,
      "y": 973
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1167,
      "y": 973
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1162,
      "y": 973
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 47090,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1161,
      "y": 973
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1160,
      "y": 970
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 26778,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1173,
      "y": 958
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1183,
      "y": 945
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1191,
      "y": 926
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 28540,
      "y": 56438,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 1194,
      "y": 908
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1194,
      "y": 892
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 28751,
      "y": 54003,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1194,
      "y": 891
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 28751,
      "y": 53932,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 1243,
      "y": 801
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1282,
      "y": 640
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 36010,
      "y": 33018,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1301,
      "y": 575
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1316,
      "y": 552
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1347,
      "y": 530
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 41,
      "x": 39533,
      "y": 28076,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 1397,
      "y": 514
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 43056,
      "y": 26930,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 1399,
      "y": 511
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1399,
      "y": 509
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 43197,
      "y": 26572,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 1399,
      "y": 506
    },
    {
      "t": 7700,
      "e": 7700,
      "ty": 2,
      "x": 1399,
      "y": 503
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 43127,
      "y": 26070,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1398,
      "y": 502
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 1396,
      "y": 500
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 42986,
      "y": 25927,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8100,
      "e": 8100,
      "ty": 2,
      "x": 1383,
      "y": 504
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 707,
      "y": 601
    },
    {
      "t": 8204,
      "e": 8204,
      "ty": 6,
      "x": 570,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8220,
      "e": 8220,
      "ty": 7,
      "x": 458,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 41,
      "x": 31127,
      "y": 62883,
      "ta": "#.strategy"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 330,
      "y": 615
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 334,
      "y": 612
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 26630,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 8518,
      "e": 8518,
      "ty": 6,
      "x": 353,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 2,
      "x": 364,
      "y": 580
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 30002,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8785,
      "e": 8785,
      "ty": 3,
      "x": 364,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8787,
      "e": 8787,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8895,
      "e": 8895,
      "ty": 4,
      "x": 30002,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8895,
      "e": 8895,
      "ty": 5,
      "x": 364,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 2,
      "x": 365,
      "y": 580
    },
    {
      "t": 9516,
      "e": 9516,
      "ty": 2,
      "x": 444,
      "y": 577
    },
    {
      "t": 9516,
      "e": 9516,
      "ty": 41,
      "x": 38995,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9516,
      "e": 9516,
      "ty": 7,
      "x": 685,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9600,
      "e": 9600,
      "ty": 2,
      "x": 794,
      "y": 614
    },
    {
      "t": 9700,
      "e": 9700,
      "ty": 2,
      "x": 800,
      "y": 613
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 987,
      "y": 34020,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 2,
      "x": 801,
      "y": 611
    },
    {
      "t": 10250,
      "e": 10250,
      "ty": 41,
      "x": 1058,
      "y": 33877,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 804,
      "y": 611
    },
    {
      "t": 10700,
      "e": 10700,
      "ty": 2,
      "x": 904,
      "y": 637
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 9866,
      "y": 36169,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 2,
      "x": 928,
      "y": 643
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 41,
      "x": 10007,
      "y": 36169,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 10077,
      "y": 36241,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11300,
      "e": 11300,
      "ty": 2,
      "x": 929,
      "y": 644
    },
    {
      "t": 11601,
      "e": 11601,
      "ty": 2,
      "x": 929,
      "y": 645
    },
    {
      "t": 11700,
      "e": 11700,
      "ty": 2,
      "x": 934,
      "y": 647
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 13319,
      "y": 37172,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11801,
      "e": 11801,
      "ty": 2,
      "x": 1030,
      "y": 666
    },
    {
      "t": 11900,
      "e": 11900,
      "ty": 2,
      "x": 1114,
      "y": 669
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 2,
      "x": 1318,
      "y": 672
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 41,
      "x": 37489,
      "y": 38246,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12100,
      "e": 12100,
      "ty": 2,
      "x": 1483,
      "y": 676
    },
    {
      "t": 12200,
      "e": 12200,
      "ty": 2,
      "x": 1717,
      "y": 689
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 61064,
      "y": 39122,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 12300,
      "e": 12300,
      "ty": 2,
      "x": 1744,
      "y": 689
    },
    {
      "t": 14124,
      "e": 14124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14285,
      "e": 14285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14285,
      "e": 14285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14364,
      "e": 14364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "s"
    },
    {
      "t": 14371,
      "e": 14371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "s"
    },
    {
      "t": 14613,
      "e": 14613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14613,
      "e": 14613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14652,
      "e": 14652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sT"
    },
    {
      "t": 14652,
      "e": 14652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14652,
      "e": 14652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14772,
      "e": 14772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sTA"
    },
    {
      "t": 14820,
      "e": 14820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14820,
      "e": 14820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14924,
      "e": 14924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sTAR"
    },
    {
      "t": 14989,
      "e": 14989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14990,
      "e": 14990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15052,
      "e": 15052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 15285,
      "e": 15285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15285,
      "e": 15285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15356,
      "e": 15356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16300,
      "e": 16300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16341,
      "e": 16341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sTART"
    },
    {
      "t": 16501,
      "e": 16501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16548,
      "e": 16548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sTAR"
    },
    {
      "t": 16627,
      "e": 16627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16692,
      "e": 16692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sTA"
    },
    {
      "t": 16772,
      "e": 16772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16819,
      "e": 16819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "sT"
    },
    {
      "t": 16868,
      "e": 16868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16899,
      "e": 16899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "s"
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "s"
    },
    {
      "t": 17004,
      "e": 17004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17036,
      "e": 17036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 17132,
      "e": 17132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17196,
      "e": 17196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 18404,
      "e": 18404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18405,
      "e": 18405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18492,
      "e": 18492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 18539,
      "e": 18539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 18644,
      "e": 18644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 18748,
      "e": 18748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18749,
      "e": 18749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18836,
      "e": 18836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "St"
    },
    {
      "t": 18860,
      "e": 18860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18860,
      "e": 18860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18947,
      "e": 18947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sta"
    },
    {
      "t": 18956,
      "e": 18956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18957,
      "e": 18957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19027,
      "e": 19027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Star"
    },
    {
      "t": 19092,
      "e": 19092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19093,
      "e": 19093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19203,
      "e": 19203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start"
    },
    {
      "t": 19228,
      "e": 19228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19389,
      "e": 19389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19389,
      "e": 19389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19501,
      "e": 19501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19860,
      "e": 19860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19939,
      "e": 19939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20468,
      "e": 20468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20468,
      "e": 20468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20580,
      "e": 20580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21035,
      "e": 21035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21035,
      "e": 21035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21140,
      "e": 21140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 21196,
      "e": 21196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21196,
      "e": 21196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21284,
      "e": 21284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21364,
      "e": 21364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21364,
      "e": 21364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21460,
      "e": 21460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21516,
      "e": 21516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 21517,
      "e": 21517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21612,
      "e": 21612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 21708,
      "e": 21708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 21708,
      "e": 21708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21795,
      "e": 21795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 21867,
      "e": 21867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21869,
      "e": 21869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21940,
      "e": 21940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22085,
      "e": 22085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 22085,
      "e": 22085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22164,
      "e": 22164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 22252,
      "e": 22252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22252,
      "e": 22252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22340,
      "e": 22340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22404,
      "e": 22404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22404,
      "e": 22404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22492,
      "e": 22492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22603,
      "e": 22603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 fro"
    },
    {
      "t": 23588,
      "e": 23588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23588,
      "e": 23588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23667,
      "e": 23667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 23756,
      "e": 23756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23756,
      "e": 23756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23844,
      "e": 23844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23948,
      "e": 23948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23949,
      "e": 23949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23980,
      "e": 23980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24020,
      "e": 24020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24020,
      "e": 24020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24124,
      "e": 24124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 24179,
      "e": 24179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24181,
      "e": 24181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24276,
      "e": 24276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24277,
      "e": 24277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24283,
      "e": 24283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 24356,
      "e": 24356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24588,
      "e": 24588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 24589,
      "e": 24589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24659,
      "e": 24659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 24780,
      "e": 24780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24780,
      "e": 24780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24852,
      "e": 24852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24924,
      "e": 24924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24924,
      "e": 24924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24980,
      "e": 24980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25028,
      "e": 25028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25029,
      "e": 25029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25091,
      "e": 25091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25179,
      "e": 25179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25179,
      "e": 25179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25284,
      "e": 25284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25323,
      "e": 25323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25324,
      "e": 25324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25403,
      "e": 25403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25491,
      "e": 25491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25492,
      "e": 25492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25603,
      "e": 25603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom "
    },
    {
      "t": 25603,
      "e": 25603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25660,
      "e": 25660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25661,
      "e": 25661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25771,
      "e": 25771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26052,
      "e": 26052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26053,
      "e": 26053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26155,
      "e": 26155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 26219,
      "e": 26219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26220,
      "e": 26220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26316,
      "e": 26316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26340,
      "e": 26340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26341,
      "e": 26341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26404,
      "e": 26404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26459,
      "e": 26459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26459,
      "e": 26459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26539,
      "e": 26539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26604,
      "e": 26604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26605,
      "e": 26605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26700,
      "e": 26700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26748,
      "e": 26748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26749,
      "e": 26749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26827,
      "e": 26827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27100,
      "e": 27100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 27101,
      "e": 27101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27163,
      "e": 27163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 27333,
      "e": 27333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27333,
      "e": 27333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27420,
      "e": 27420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 27444,
      "e": 27444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27444,
      "e": 27444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27540,
      "e": 27540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27692,
      "e": 27692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 27693,
      "e": 27693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27772,
      "e": 27772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28084,
      "e": 28084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28085,
      "e": 28085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28171,
      "e": 28171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28243,
      "e": 28243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28244,
      "e": 28244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28316,
      "e": 28316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28492,
      "e": 28492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 28724,
      "e": 28724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 28725,
      "e": 28725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28795,
      "e": 28795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 28900,
      "e": 28900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 28901,
      "e": 28901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28915,
      "e": 28915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 29493,
      "e": 29493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29628,
      "e": 29628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 29723,
      "e": 29723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30540,
      "e": 30540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 30540,
      "e": 30540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30612,
      "e": 30612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x)"
    },
    {
      "t": 30940,
      "e": 30940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 30940,
      "e": 30940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31019,
      "e": 31019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-)"
    },
    {
      "t": 31075,
      "e": 31075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31075,
      "e": 31075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31196,
      "e": 31196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-a)"
    },
    {
      "t": 31588,
      "e": 31588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 31589,
      "e": 31589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31667,
      "e": 31667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-ax)"
    },
    {
      "t": 31764,
      "e": 31764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31765,
      "e": 31765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31852,
      "e": 31852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axi)"
    },
    {
      "t": 31860,
      "e": 31860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31861,
      "e": 31861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31971,
      "e": 31971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis)"
    },
    {
      "t": 32228,
      "e": 32228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 32372,
      "e": 32372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32635,
      "e": 32635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32636,
      "e": 32636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32739,
      "e": 32739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32804,
      "e": 32804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32804,
      "e": 32804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32939,
      "e": 32939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 32995,
      "e": 32995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32996,
      "e": 32996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33075,
      "e": 33075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33131,
      "e": 33131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33132,
      "e": 33132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33235,
      "e": 33235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33292,
      "e": 33292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33293,
      "e": 33293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33379,
      "e": 33379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33508,
      "e": 33508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33508,
      "e": 33508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33595,
      "e": 33595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 33684,
      "e": 33684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33684,
      "e": 33684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33747,
      "e": 33747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 33876,
      "e": 33876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33876,
      "e": 33876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33931,
      "e": 33931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34019,
      "e": 34019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34020,
      "e": 34020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34092,
      "e": 34092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34189,
      "e": 34189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34190,
      "e": 34190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34251,
      "e": 34251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34251,
      "e": 34251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 34252,
      "e": 34252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34371,
      "e": 34371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 34396,
      "e": 34396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34396,
      "e": 34396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34508,
      "e": 34508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34612,
      "e": 34612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34613,
      "e": 34613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34699,
      "e": 34699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34802,
      "e": 34802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow t"
    },
    {
      "t": 34868,
      "e": 34868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34869,
      "e": 34869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34916,
      "e": 34916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35515,
      "e": 35515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35620,
      "e": 35620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow t"
    },
    {
      "t": 36404,
      "e": 36404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36405,
      "e": 36405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36515,
      "e": 36515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36516,
      "e": 36516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36523,
      "e": 36523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 36579,
      "e": 36579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36596,
      "e": 36596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36596,
      "e": 36596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36693,
      "e": 36693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36916,
      "e": 36916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36917,
      "e": 36917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37027,
      "e": 37027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 37180,
      "e": 37180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37181,
      "e": 37181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37308,
      "e": 37308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37308,
      "e": 37308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37316,
      "e": 37316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 37405,
      "e": 37318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37428,
      "e": 37341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37428,
      "e": 37341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37508,
      "e": 37421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37532,
      "e": 37445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37532,
      "e": 37445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37603,
      "e": 37516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37812,
      "e": 37725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37813,
      "e": 37726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37899,
      "e": 37812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38002,
      "e": 37915,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow the line t"
    },
    {
      "t": 38012,
      "e": 37925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38012,
      "e": 37925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38107,
      "e": 38020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38107,
      "e": 38020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38123,
      "e": 38036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 38219,
      "e": 38132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38220,
      "e": 38133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38220,
      "e": 38133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38291,
      "e": 38204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38379,
      "e": 38292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38379,
      "e": 38292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38483,
      "e": 38396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38588,
      "e": 38501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 38588,
      "e": 38501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38684,
      "e": 38597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 38868,
      "e": 38781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38868,
      "e": 38781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38967,
      "e": 38880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39000,
      "e": 38913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39000,
      "e": 38913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39136,
      "e": 39049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39216,
      "e": 39129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39217,
      "e": 39130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39319,
      "e": 39232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39327,
      "e": 39240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39328,
      "e": 39241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39375,
      "e": 39288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39536,
      "e": 39449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39536,
      "e": 39449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39615,
      "e": 39528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 39775,
      "e": 39688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 39776,
      "e": 39689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39864,
      "e": 39777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 40000,
      "e": 39913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40000,
      "e": 39913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40063,
      "e": 39976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40111,
      "e": 40024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40111,
      "e": 40024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40207,
      "e": 40120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40248,
      "e": 40161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40249,
      "e": 40162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40320,
      "e": 40233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40375,
      "e": 40288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40375,
      "e": 40288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40471,
      "e": 40384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 40511,
      "e": 40424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40512,
      "e": 40425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40592,
      "e": 40505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40815,
      "e": 40728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40816,
      "e": 40729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40879,
      "e": 40792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41007,
      "e": 40920,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow the line that goes up and t"
    },
    {
      "t": 41080,
      "e": 40993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41080,
      "e": 40993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41175,
      "e": 41088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 41304,
      "e": 41217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 41304,
      "e": 41217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41399,
      "e": 41312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 41527,
      "e": 41440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41528,
      "e": 41441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41615,
      "e": 41528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41695,
      "e": 41608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41695,
      "e": 41608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41743,
      "e": 41656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 41743,
      "e": 41656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41792,
      "e": 41705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rd"
    },
    {
      "t": 41839,
      "e": 41752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41895,
      "e": 41808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41896,
      "e": 41809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41918,
      "e": 41831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41990,
      "e": 41903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41991,
      "e": 41904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42062,
      "e": 41975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42160,
      "e": 42073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42161,
      "e": 42074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42238,
      "e": 42151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42496,
      "e": 42409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42497,
      "e": 42410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42567,
      "e": 42480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43000,
      "e": 42913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43111,
      "e": 43024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow the line that goes up and towards t"
    },
    {
      "t": 44360,
      "e": 44273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44360,
      "e": 44273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44454,
      "e": 44367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 44463,
      "e": 44376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44463,
      "e": 44376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44568,
      "e": 44377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44591,
      "e": 44400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44591,
      "e": 44400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44678,
      "e": 44487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44767,
      "e": 44576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44767,
      "e": 44576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44823,
      "e": 44632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 44880,
      "e": 44689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44880,
      "e": 44689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44975,
      "e": 44784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45031,
      "e": 44840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 45031,
      "e": 44840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45111,
      "e": 44920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 45151,
      "e": 44960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 45151,
      "e": 44960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45231,
      "e": 45040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45231,
      "e": 45040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45239,
      "e": 45048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 45302,
      "e": 45111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45409,
      "e": 45218,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow the line that goes up and towards the right"
    },
    {
      "t": 45999,
      "e": 45808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 46000,
      "e": 45809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46071,
      "e": 45880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 47104,
      "e": 46913,
      "ty": 2,
      "x": 1754,
      "y": 701
    },
    {
      "t": 47205,
      "e": 47014,
      "ty": 2,
      "x": 1837,
      "y": 866
    },
    {
      "t": 47254,
      "e": 47063,
      "ty": 41,
      "x": 63021,
      "y": 47641,
      "ta": "> div.stimulus"
    },
    {
      "t": 47305,
      "e": 47114,
      "ty": 2,
      "x": 1839,
      "y": 869
    },
    {
      "t": 47405,
      "e": 47214,
      "ty": 2,
      "x": 1775,
      "y": 955
    },
    {
      "t": 47505,
      "e": 47314,
      "ty": 2,
      "x": 1740,
      "y": 980
    },
    {
      "t": 47505,
      "e": 47314,
      "ty": 41,
      "x": 60834,
      "y": 59783,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 47605,
      "e": 47414,
      "ty": 2,
      "x": 1693,
      "y": 994
    },
    {
      "t": 47705,
      "e": 47514,
      "ty": 2,
      "x": 952,
      "y": 878
    },
    {
      "t": 47755,
      "e": 47564,
      "ty": 41,
      "x": 2960,
      "y": 48918,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47804,
      "e": 47613,
      "ty": 2,
      "x": 826,
      "y": 818
    },
    {
      "t": 47904,
      "e": 47713,
      "ty": 2,
      "x": 832,
      "y": 801
    },
    {
      "t": 48005,
      "e": 47814,
      "ty": 2,
      "x": 839,
      "y": 799
    },
    {
      "t": 48005,
      "e": 47814,
      "ty": 41,
      "x": 3735,
      "y": 47342,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48104,
      "e": 47913,
      "ty": 2,
      "x": 843,
      "y": 797
    },
    {
      "t": 48204,
      "e": 48013,
      "ty": 2,
      "x": 1001,
      "y": 711
    },
    {
      "t": 48254,
      "e": 48063,
      "ty": 41,
      "x": 21137,
      "y": 44481,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line"
    },
    {
      "t": 48304,
      "e": 48113,
      "ty": 2,
      "x": 1015,
      "y": 706
    },
    {
      "t": 48404,
      "e": 48213,
      "ty": 2,
      "x": 1017,
      "y": 706
    },
    {
      "t": 48504,
      "e": 48313,
      "ty": 2,
      "x": 1173,
      "y": 648
    },
    {
      "t": 48505,
      "e": 48314,
      "ty": 41,
      "x": 27272,
      "y": 36527,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48605,
      "e": 48414,
      "ty": 2,
      "x": 1198,
      "y": 636
    },
    {
      "t": 48704,
      "e": 48513,
      "ty": 2,
      "x": 1157,
      "y": 629
    },
    {
      "t": 48755,
      "e": 48564,
      "ty": 41,
      "x": 18322,
      "y": 34880,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48805,
      "e": 48614,
      "ty": 2,
      "x": 1013,
      "y": 601
    },
    {
      "t": 48905,
      "e": 48714,
      "ty": 2,
      "x": 879,
      "y": 597
    },
    {
      "t": 48940,
      "e": 48749,
      "ty": 6,
      "x": 668,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49004,
      "e": 48813,
      "ty": 2,
      "x": 548,
      "y": 601
    },
    {
      "t": 49005,
      "e": 48814,
      "ty": 41,
      "x": 50686,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49040,
      "e": 48849,
      "ty": 7,
      "x": 521,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49104,
      "e": 48913,
      "ty": 2,
      "x": 515,
      "y": 608
    },
    {
      "t": 49204,
      "e": 49013,
      "ty": 2,
      "x": 510,
      "y": 622
    },
    {
      "t": 49255,
      "e": 49064,
      "ty": 41,
      "x": 47763,
      "y": 34401,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 49304,
      "e": 49113,
      "ty": 2,
      "x": 525,
      "y": 630
    },
    {
      "t": 49404,
      "e": 49213,
      "ty": 2,
      "x": 523,
      "y": 638
    },
    {
      "t": 49504,
      "e": 49313,
      "ty": 2,
      "x": 506,
      "y": 652
    },
    {
      "t": 49506,
      "e": 49315,
      "ty": 41,
      "x": 45965,
      "y": 35675,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 49805,
      "e": 49614,
      "ty": 2,
      "x": 507,
      "y": 652
    },
    {
      "t": 49905,
      "e": 49714,
      "ty": 2,
      "x": 511,
      "y": 653
    },
    {
      "t": 50005,
      "e": 49814,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50007,
      "e": 49816,
      "ty": 41,
      "x": 46527,
      "y": 35731,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 50105,
      "e": 49914,
      "ty": 2,
      "x": 513,
      "y": 654
    },
    {
      "t": 50205,
      "e": 50014,
      "ty": 2,
      "x": 513,
      "y": 655
    },
    {
      "t": 50255,
      "e": 50064,
      "ty": 41,
      "x": 46752,
      "y": 35842,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 51304,
      "e": 51113,
      "ty": 2,
      "x": 513,
      "y": 656
    },
    {
      "t": 51404,
      "e": 51213,
      "ty": 2,
      "x": 506,
      "y": 660
    },
    {
      "t": 51505,
      "e": 51314,
      "ty": 2,
      "x": 490,
      "y": 663
    },
    {
      "t": 51505,
      "e": 51314,
      "ty": 41,
      "x": 44166,
      "y": 36285,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 51604,
      "e": 51413,
      "ty": 2,
      "x": 465,
      "y": 668
    },
    {
      "t": 51755,
      "e": 51564,
      "ty": 41,
      "x": 41356,
      "y": 36562,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 55755,
      "e": 55564,
      "ty": 41,
      "x": 41243,
      "y": 36783,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 55805,
      "e": 55614,
      "ty": 2,
      "x": 464,
      "y": 675
    },
    {
      "t": 55905,
      "e": 55714,
      "ty": 2,
      "x": 465,
      "y": 677
    },
    {
      "t": 56005,
      "e": 55814,
      "ty": 41,
      "x": 41356,
      "y": 37060,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 56864,
      "e": 56673,
      "ty": 6,
      "x": 440,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 56905,
      "e": 56714,
      "ty": 2,
      "x": 406,
      "y": 671
    },
    {
      "t": 57005,
      "e": 56814,
      "ty": 2,
      "x": 388,
      "y": 667
    },
    {
      "t": 57005,
      "e": 56814,
      "ty": 41,
      "x": 26981,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 58204,
      "e": 58013,
      "ty": 2,
      "x": 388,
      "y": 665
    },
    {
      "t": 58255,
      "e": 58064,
      "ty": 41,
      "x": 26981,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 59525,
      "e": 59334,
      "ty": 3,
      "x": 388,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 59526,
      "e": 59335,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 from the bottom of the graph (x-axis) and follow the line that goes up and towards the right."
    },
    {
      "t": 59527,
      "e": 59336,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59529,
      "e": 59338,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 59699,
      "e": 59508,
      "ty": 4,
      "x": 26981,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 59714,
      "e": 59523,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 59716,
      "e": 59525,
      "ty": 5,
      "x": 388,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 59725,
      "e": 59534,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 60004,
      "e": 59813,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60722,
      "e": 60531,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 61404,
      "e": 61213,
      "ty": 2,
      "x": 510,
      "y": 652
    },
    {
      "t": 61504,
      "e": 61313,
      "ty": 2,
      "x": 750,
      "y": 661
    },
    {
      "t": 61504,
      "e": 61313,
      "ty": 41,
      "x": 25552,
      "y": 36174,
      "ta": "html > body"
    },
    {
      "t": 61604,
      "e": 61413,
      "ty": 2,
      "x": 835,
      "y": 627
    },
    {
      "t": 61704,
      "e": 61513,
      "ty": 2,
      "x": 900,
      "y": 593
    },
    {
      "t": 61754,
      "e": 61563,
      "ty": 41,
      "x": 21196,
      "y": 2114,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 61804,
      "e": 61613,
      "ty": 2,
      "x": 909,
      "y": 581
    },
    {
      "t": 61868,
      "e": 61677,
      "ty": 6,
      "x": 912,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61903,
      "e": 61712,
      "ty": 2,
      "x": 914,
      "y": 570
    },
    {
      "t": 62004,
      "e": 61813,
      "ty": 2,
      "x": 915,
      "y": 569
    },
    {
      "t": 62004,
      "e": 61813,
      "ty": 41,
      "x": 23142,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62059,
      "e": 61868,
      "ty": 3,
      "x": 915,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62060,
      "e": 61869,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62154,
      "e": 61963,
      "ty": 4,
      "x": 23142,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62154,
      "e": 61963,
      "ty": 5,
      "x": 915,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62404,
      "e": 62213,
      "ty": 2,
      "x": 914,
      "y": 569
    },
    {
      "t": 62504,
      "e": 62313,
      "ty": 41,
      "x": 22926,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63591,
      "e": 63400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 63592,
      "e": 63401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63743,
      "e": 63552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 64136,
      "e": 63945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 64136,
      "e": 63945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64182,
      "e": 63991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 65237,
      "e": 65046,
      "ty": 7,
      "x": 918,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65254,
      "e": 65063,
      "ty": 41,
      "x": 25089,
      "y": 9865,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65304,
      "e": 65113,
      "ty": 2,
      "x": 928,
      "y": 606
    },
    {
      "t": 65404,
      "e": 65213,
      "ty": 2,
      "x": 923,
      "y": 613
    },
    {
      "t": 65504,
      "e": 65313,
      "ty": 2,
      "x": 903,
      "y": 629
    },
    {
      "t": 65504,
      "e": 65313,
      "ty": 41,
      "x": 20547,
      "y": 32415,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65604,
      "e": 65413,
      "ty": 2,
      "x": 898,
      "y": 635
    },
    {
      "t": 65704,
      "e": 65513,
      "ty": 2,
      "x": 891,
      "y": 640
    },
    {
      "t": 65755,
      "e": 65564,
      "ty": 41,
      "x": 17086,
      "y": 42985,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65804,
      "e": 65613,
      "ty": 2,
      "x": 886,
      "y": 645
    },
    {
      "t": 65868,
      "e": 65677,
      "ty": 6,
      "x": 883,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65903,
      "e": 65712,
      "ty": 2,
      "x": 881,
      "y": 648
    },
    {
      "t": 66004,
      "e": 65813,
      "ty": 2,
      "x": 875,
      "y": 653
    },
    {
      "t": 66004,
      "e": 65813,
      "ty": 41,
      "x": 14491,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66100,
      "e": 65909,
      "ty": 3,
      "x": 874,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66101,
      "e": 65910,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 66102,
      "e": 65911,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66102,
      "e": 65911,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66104,
      "e": 65913,
      "ty": 2,
      "x": 874,
      "y": 653
    },
    {
      "t": 66227,
      "e": 66036,
      "ty": 4,
      "x": 14274,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66227,
      "e": 66036,
      "ty": 5,
      "x": 874,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66254,
      "e": 66063,
      "ty": 41,
      "x": 14274,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67191,
      "e": 67000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 67312,
      "e": 67121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 67447,
      "e": 67256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 67448,
      "e": 67257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67526,
      "e": 67335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 67903,
      "e": 67712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 67904,
      "e": 67713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67967,
      "e": 67776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 68087,
      "e": 67896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 68087,
      "e": 67896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68150,
      "e": 67959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 68573,
      "e": 68382,
      "ty": 7,
      "x": 775,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68604,
      "e": 68413,
      "ty": 2,
      "x": 772,
      "y": 677
    },
    {
      "t": 68704,
      "e": 68513,
      "ty": 2,
      "x": 785,
      "y": 667
    },
    {
      "t": 68706,
      "e": 68515,
      "ty": 6,
      "x": 841,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68723,
      "e": 68532,
      "ty": 7,
      "x": 1006,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68723,
      "e": 68532,
      "ty": 6,
      "x": 1006,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68740,
      "e": 68549,
      "ty": 7,
      "x": 1072,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68754,
      "e": 68563,
      "ty": 41,
      "x": 36641,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 68804,
      "e": 68613,
      "ty": 2,
      "x": 1074,
      "y": 719
    },
    {
      "t": 68904,
      "e": 68713,
      "ty": 2,
      "x": 1074,
      "y": 720
    },
    {
      "t": 69004,
      "e": 68813,
      "ty": 2,
      "x": 1068,
      "y": 723
    },
    {
      "t": 69005,
      "e": 68814,
      "ty": 41,
      "x": 36503,
      "y": 39609,
      "ta": "html > body"
    },
    {
      "t": 69104,
      "e": 68913,
      "ty": 2,
      "x": 1036,
      "y": 704
    },
    {
      "t": 69140,
      "e": 68949,
      "ty": 6,
      "x": 1023,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69204,
      "e": 69013,
      "ty": 2,
      "x": 1019,
      "y": 695
    },
    {
      "t": 69254,
      "e": 69063,
      "ty": 41,
      "x": 61371,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69305,
      "e": 69114,
      "ty": 2,
      "x": 1011,
      "y": 695
    },
    {
      "t": 69380,
      "e": 69189,
      "ty": 3,
      "x": 1009,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69381,
      "e": 69190,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 69382,
      "e": 69191,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69382,
      "e": 69191,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69404,
      "e": 69213,
      "ty": 2,
      "x": 1009,
      "y": 695
    },
    {
      "t": 69474,
      "e": 69283,
      "ty": 4,
      "x": 58279,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69475,
      "e": 69284,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69476,
      "e": 69285,
      "ty": 5,
      "x": 1009,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69476,
      "e": 69285,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 69504,
      "e": 69313,
      "ty": 41,
      "x": 34472,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 70004,
      "e": 69813,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70104,
      "e": 69913,
      "ty": 2,
      "x": 1007,
      "y": 695
    },
    {
      "t": 70204,
      "e": 70013,
      "ty": 2,
      "x": 995,
      "y": 695
    },
    {
      "t": 70255,
      "e": 70064,
      "ty": 41,
      "x": 33990,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 70404,
      "e": 70213,
      "ty": 2,
      "x": 966,
      "y": 695
    },
    {
      "t": 70492,
      "e": 70301,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 70504,
      "e": 70313,
      "ty": 2,
      "x": 949,
      "y": 693
    },
    {
      "t": 70504,
      "e": 70313,
      "ty": 41,
      "x": 32147,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 70604,
      "e": 70413,
      "ty": 2,
      "x": 942,
      "y": 692
    },
    {
      "t": 70704,
      "e": 70513,
      "ty": 2,
      "x": 938,
      "y": 691
    },
    {
      "t": 70755,
      "e": 70564,
      "ty": 41,
      "x": 27666,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 70805,
      "e": 70614,
      "ty": 2,
      "x": 935,
      "y": 691
    },
    {
      "t": 70904,
      "e": 70713,
      "ty": 2,
      "x": 933,
      "y": 690
    },
    {
      "t": 71008,
      "e": 70817,
      "ty": 41,
      "x": 26480,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 71104,
      "e": 70913,
      "ty": 2,
      "x": 929,
      "y": 686
    },
    {
      "t": 71204,
      "e": 71013,
      "ty": 2,
      "x": 880,
      "y": 677
    },
    {
      "t": 71254,
      "e": 71063,
      "ty": 41,
      "x": 14117,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 71304,
      "e": 71113,
      "ty": 2,
      "x": 863,
      "y": 677
    },
    {
      "t": 71405,
      "e": 71214,
      "ty": 2,
      "x": 820,
      "y": 632
    },
    {
      "t": 71505,
      "e": 71314,
      "ty": 2,
      "x": 754,
      "y": 540
    },
    {
      "t": 71505,
      "e": 71314,
      "ty": 41,
      "x": 25690,
      "y": 29471,
      "ta": "html > body"
    },
    {
      "t": 71605,
      "e": 71414,
      "ty": 2,
      "x": 748,
      "y": 430
    },
    {
      "t": 71704,
      "e": 71513,
      "ty": 2,
      "x": 778,
      "y": 328
    },
    {
      "t": 71754,
      "e": 71563,
      "ty": 41,
      "x": 26517,
      "y": 16951,
      "ta": "html > body"
    },
    {
      "t": 71804,
      "e": 71613,
      "ty": 2,
      "x": 778,
      "y": 310
    },
    {
      "t": 71904,
      "e": 71713,
      "ty": 2,
      "x": 792,
      "y": 277
    },
    {
      "t": 72005,
      "e": 71814,
      "ty": 2,
      "x": 805,
      "y": 264
    },
    {
      "t": 72005,
      "e": 71814,
      "ty": 41,
      "x": 27446,
      "y": 14181,
      "ta": "html > body"
    },
    {
      "t": 72104,
      "e": 71913,
      "ty": 2,
      "x": 809,
      "y": 262
    },
    {
      "t": 72204,
      "e": 72013,
      "ty": 2,
      "x": 861,
      "y": 232
    },
    {
      "t": 72254,
      "e": 72063,
      "ty": 41,
      "x": 35684,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 72304,
      "e": 72113,
      "ty": 2,
      "x": 866,
      "y": 230
    },
    {
      "t": 72404,
      "e": 72213,
      "ty": 2,
      "x": 862,
      "y": 227
    },
    {
      "t": 72505,
      "e": 72314,
      "ty": 2,
      "x": 847,
      "y": 229
    },
    {
      "t": 72505,
      "e": 72314,
      "ty": 41,
      "x": 20945,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 72526,
      "e": 72335,
      "ty": 6,
      "x": 830,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72542,
      "e": 72351,
      "ty": 7,
      "x": 823,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72604,
      "e": 72413,
      "ty": 2,
      "x": 817,
      "y": 239
    },
    {
      "t": 72754,
      "e": 72563,
      "ty": 41,
      "x": 27860,
      "y": 12796,
      "ta": "html > body"
    },
    {
      "t": 72805,
      "e": 72614,
      "ty": 2,
      "x": 818,
      "y": 239
    },
    {
      "t": 72905,
      "e": 72714,
      "ty": 2,
      "x": 819,
      "y": 240
    },
    {
      "t": 73005,
      "e": 72814,
      "ty": 2,
      "x": 821,
      "y": 242
    },
    {
      "t": 73005,
      "e": 72814,
      "ty": 41,
      "x": 0,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 73204,
      "e": 73013,
      "ty": 2,
      "x": 825,
      "y": 241
    },
    {
      "t": 73219,
      "e": 73028,
      "ty": 6,
      "x": 826,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73254,
      "e": 73063,
      "ty": 41,
      "x": 7955,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73304,
      "e": 73113,
      "ty": 2,
      "x": 828,
      "y": 241
    },
    {
      "t": 73405,
      "e": 73214,
      "ty": 2,
      "x": 834,
      "y": 238
    },
    {
      "t": 73504,
      "e": 73313,
      "ty": 2,
      "x": 838,
      "y": 236
    },
    {
      "t": 73504,
      "e": 73313,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73603,
      "e": 73412,
      "ty": 3,
      "x": 838,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73603,
      "e": 73412,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73715,
      "e": 73524,
      "ty": 4,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73716,
      "e": 73525,
      "ty": 5,
      "x": 838,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73716,
      "e": 73525,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 74044,
      "e": 73853,
      "ty": 7,
      "x": 838,
      "y": 253,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74105,
      "e": 73914,
      "ty": 2,
      "x": 866,
      "y": 303
    },
    {
      "t": 74204,
      "e": 74013,
      "ty": 2,
      "x": 883,
      "y": 332
    },
    {
      "t": 74254,
      "e": 74063,
      "ty": 41,
      "x": 14614,
      "y": 13525,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74304,
      "e": 74113,
      "ty": 2,
      "x": 868,
      "y": 361
    },
    {
      "t": 74405,
      "e": 74214,
      "ty": 2,
      "x": 819,
      "y": 378
    },
    {
      "t": 74505,
      "e": 74314,
      "ty": 2,
      "x": 816,
      "y": 389
    },
    {
      "t": 74505,
      "e": 74314,
      "ty": 41,
      "x": 27825,
      "y": 21106,
      "ta": "html > body"
    },
    {
      "t": 74604,
      "e": 74413,
      "ty": 2,
      "x": 825,
      "y": 414
    },
    {
      "t": 74619,
      "e": 74428,
      "ty": 6,
      "x": 826,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 74704,
      "e": 74513,
      "ty": 2,
      "x": 826,
      "y": 416
    },
    {
      "t": 74754,
      "e": 74563,
      "ty": 41,
      "x": 0,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75005,
      "e": 74814,
      "ty": 2,
      "x": 830,
      "y": 416
    },
    {
      "t": 75005,
      "e": 74814,
      "ty": 41,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75105,
      "e": 74914,
      "ty": 2,
      "x": 832,
      "y": 416
    },
    {
      "t": 75164,
      "e": 74973,
      "ty": 3,
      "x": 833,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75165,
      "e": 74974,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75166,
      "e": 74975,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75205,
      "e": 75014,
      "ty": 2,
      "x": 833,
      "y": 416
    },
    {
      "t": 75255,
      "e": 75064,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75282,
      "e": 75091,
      "ty": 4,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75283,
      "e": 75092,
      "ty": 5,
      "x": 833,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75283,
      "e": 75092,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 75604,
      "e": 75413,
      "ty": 2,
      "x": 838,
      "y": 416
    },
    {
      "t": 75612,
      "e": 75421,
      "ty": 7,
      "x": 842,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 75704,
      "e": 75513,
      "ty": 2,
      "x": 891,
      "y": 452
    },
    {
      "t": 75756,
      "e": 75514,
      "ty": 41,
      "x": 17224,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 75805,
      "e": 75563,
      "ty": 2,
      "x": 895,
      "y": 459
    },
    {
      "t": 75904,
      "e": 75662,
      "ty": 2,
      "x": 878,
      "y": 452
    },
    {
      "t": 76005,
      "e": 75763,
      "ty": 2,
      "x": 817,
      "y": 426
    },
    {
      "t": 76005,
      "e": 75763,
      "ty": 41,
      "x": 27860,
      "y": 23156,
      "ta": "html > body"
    },
    {
      "t": 76104,
      "e": 75862,
      "ty": 2,
      "x": 820,
      "y": 437
    },
    {
      "t": 76205,
      "e": 75963,
      "ty": 2,
      "x": 939,
      "y": 603
    },
    {
      "t": 76255,
      "e": 76013,
      "ty": 41,
      "x": 28141,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 76304,
      "e": 76062,
      "ty": 2,
      "x": 928,
      "y": 650
    },
    {
      "t": 76404,
      "e": 76162,
      "ty": 2,
      "x": 874,
      "y": 714
    },
    {
      "t": 76505,
      "e": 76263,
      "ty": 2,
      "x": 861,
      "y": 731
    },
    {
      "t": 76505,
      "e": 76263,
      "ty": 41,
      "x": 9933,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76605,
      "e": 76363,
      "ty": 2,
      "x": 853,
      "y": 735
    },
    {
      "t": 76705,
      "e": 76463,
      "ty": 2,
      "x": 842,
      "y": 739
    },
    {
      "t": 76754,
      "e": 76512,
      "ty": 41,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 76804,
      "e": 76562,
      "ty": 2,
      "x": 839,
      "y": 742
    },
    {
      "t": 76863,
      "e": 76621,
      "ty": 6,
      "x": 838,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 76896,
      "e": 76654,
      "ty": 7,
      "x": 840,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 76904,
      "e": 76662,
      "ty": 2,
      "x": 840,
      "y": 735
    },
    {
      "t": 77005,
      "e": 76763,
      "ty": 2,
      "x": 842,
      "y": 725
    },
    {
      "t": 77005,
      "e": 76763,
      "ty": 41,
      "x": 5164,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 77105,
      "e": 76863,
      "ty": 2,
      "x": 845,
      "y": 713
    },
    {
      "t": 77204,
      "e": 76962,
      "ty": 2,
      "x": 846,
      "y": 712
    },
    {
      "t": 77255,
      "e": 77013,
      "ty": 41,
      "x": 6193,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77805,
      "e": 77563,
      "ty": 2,
      "x": 845,
      "y": 712
    },
    {
      "t": 77904,
      "e": 77662,
      "ty": 2,
      "x": 843,
      "y": 712
    },
    {
      "t": 78004,
      "e": 77762,
      "ty": 2,
      "x": 839,
      "y": 715
    },
    {
      "t": 78005,
      "e": 77763,
      "ty": 41,
      "x": 4171,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 78105,
      "e": 77863,
      "ty": 2,
      "x": 834,
      "y": 722
    },
    {
      "t": 78204,
      "e": 77962,
      "ty": 2,
      "x": 833,
      "y": 722
    },
    {
      "t": 78255,
      "e": 78013,
      "ty": 41,
      "x": 2905,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 79004,
      "e": 78762,
      "ty": 2,
      "x": 832,
      "y": 722
    },
    {
      "t": 79004,
      "e": 78762,
      "ty": 41,
      "x": 2654,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 79204,
      "e": 78962,
      "ty": 2,
      "x": 830,
      "y": 718
    },
    {
      "t": 79255,
      "e": 79013,
      "ty": 41,
      "x": 2035,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 79304,
      "e": 79062,
      "ty": 2,
      "x": 830,
      "y": 713
    },
    {
      "t": 79404,
      "e": 79162,
      "ty": 2,
      "x": 831,
      "y": 710
    },
    {
      "t": 79505,
      "e": 79263,
      "ty": 41,
      "x": 2413,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79884,
      "e": 79642,
      "ty": 6,
      "x": 831,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 79904,
      "e": 79662,
      "ty": 2,
      "x": 831,
      "y": 707
    },
    {
      "t": 80005,
      "e": 79763,
      "ty": 2,
      "x": 831,
      "y": 704
    },
    {
      "t": 80005,
      "e": 79763,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80139,
      "e": 79897,
      "ty": 3,
      "x": 831,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80141,
      "e": 79899,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80141,
      "e": 79899,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80251,
      "e": 80009,
      "ty": 4,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80251,
      "e": 80009,
      "ty": 5,
      "x": 831,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80252,
      "e": 80010,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 84605,
      "e": 84363,
      "ty": 2,
      "x": 830,
      "y": 706
    },
    {
      "t": 84619,
      "e": 84377,
      "ty": 7,
      "x": 830,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 84702,
      "e": 84460,
      "ty": 6,
      "x": 834,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 84705,
      "e": 84463,
      "ty": 2,
      "x": 834,
      "y": 725
    },
    {
      "t": 84735,
      "e": 84493,
      "ty": 7,
      "x": 836,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 84754,
      "e": 84512,
      "ty": 41,
      "x": 3934,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 84769,
      "e": 84527,
      "ty": 6,
      "x": 839,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 84785,
      "e": 84543,
      "ty": 7,
      "x": 841,
      "y": 768,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 84804,
      "e": 84562,
      "ty": 2,
      "x": 843,
      "y": 782
    },
    {
      "t": 84904,
      "e": 84662,
      "ty": 2,
      "x": 860,
      "y": 853
    },
    {
      "t": 85005,
      "e": 84763,
      "ty": 2,
      "x": 863,
      "y": 886
    },
    {
      "t": 85005,
      "e": 84763,
      "ty": 41,
      "x": 9867,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 85105,
      "e": 84863,
      "ty": 2,
      "x": 861,
      "y": 901
    },
    {
      "t": 85204,
      "e": 84962,
      "ty": 2,
      "x": 844,
      "y": 940
    },
    {
      "t": 85255,
      "e": 85013,
      "ty": 41,
      "x": 5121,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 85305,
      "e": 85063,
      "ty": 2,
      "x": 843,
      "y": 945
    },
    {
      "t": 85404,
      "e": 85162,
      "ty": 2,
      "x": 843,
      "y": 943
    },
    {
      "t": 85505,
      "e": 85162,
      "ty": 2,
      "x": 848,
      "y": 933
    },
    {
      "t": 85506,
      "e": 85163,
      "ty": 41,
      "x": 29029,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85755,
      "e": 85412,
      "ty": 41,
      "x": 29029,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85805,
      "e": 85462,
      "ty": 2,
      "x": 848,
      "y": 931
    },
    {
      "t": 85904,
      "e": 85561,
      "ty": 2,
      "x": 848,
      "y": 930
    },
    {
      "t": 86005,
      "e": 85662,
      "ty": 2,
      "x": 841,
      "y": 927
    },
    {
      "t": 86006,
      "e": 85663,
      "ty": 41,
      "x": 21384,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 86105,
      "e": 85762,
      "ty": 2,
      "x": 838,
      "y": 926
    },
    {
      "t": 86204,
      "e": 85861,
      "ty": 2,
      "x": 836,
      "y": 926
    },
    {
      "t": 86255,
      "e": 85912,
      "ty": 41,
      "x": 15922,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 86324,
      "e": 85981,
      "ty": 3,
      "x": 836,
      "y": 926,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 86324,
      "e": 85981,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86433,
      "e": 86090,
      "ty": 4,
      "x": 15922,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 86434,
      "e": 86091,
      "ty": 5,
      "x": 836,
      "y": 926,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 86434,
      "e": 86091,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86434,
      "e": 86091,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 86739,
      "e": 86396,
      "ty": 6,
      "x": 836,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86754,
      "e": 86411,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86804,
      "e": 86461,
      "ty": 7,
      "x": 843,
      "y": 943,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86805,
      "e": 86462,
      "ty": 2,
      "x": 843,
      "y": 943
    },
    {
      "t": 86887,
      "e": 86544,
      "ty": 6,
      "x": 905,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86905,
      "e": 86562,
      "ty": 2,
      "x": 906,
      "y": 1008
    },
    {
      "t": 87005,
      "e": 86662,
      "ty": 2,
      "x": 907,
      "y": 1014
    },
    {
      "t": 87005,
      "e": 86662,
      "ty": 41,
      "x": 39982,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87105,
      "e": 86762,
      "ty": 2,
      "x": 907,
      "y": 1020
    },
    {
      "t": 87163,
      "e": 86820,
      "ty": 3,
      "x": 907,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87165,
      "e": 86822,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 87165,
      "e": 86822,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87255,
      "e": 86912,
      "ty": 41,
      "x": 39982,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87257,
      "e": 86914,
      "ty": 4,
      "x": 39982,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87258,
      "e": 86915,
      "ty": 5,
      "x": 907,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87260,
      "e": 86917,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87261,
      "e": 86918,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 87262,
      "e": 86919,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 87405,
      "e": 87062,
      "ty": 2,
      "x": 906,
      "y": 1021
    },
    {
      "t": 87505,
      "e": 87162,
      "ty": 41,
      "x": 30925,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 87705,
      "e": 87362,
      "ty": 2,
      "x": 905,
      "y": 1022
    },
    {
      "t": 87755,
      "e": 87412,
      "ty": 41,
      "x": 30890,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 87904,
      "e": 87561,
      "ty": 2,
      "x": 905,
      "y": 1018
    },
    {
      "t": 88005,
      "e": 87662,
      "ty": 2,
      "x": 906,
      "y": 1018
    },
    {
      "t": 88006,
      "e": 87663,
      "ty": 41,
      "x": 30925,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 88255,
      "e": 87912,
      "ty": 41,
      "x": 30890,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 88305,
      "e": 87962,
      "ty": 2,
      "x": 903,
      "y": 1019
    },
    {
      "t": 88405,
      "e": 88062,
      "ty": 2,
      "x": 901,
      "y": 1023
    },
    {
      "t": 88505,
      "e": 88162,
      "ty": 2,
      "x": 898,
      "y": 1028
    },
    {
      "t": 88505,
      "e": 88162,
      "ty": 41,
      "x": 30649,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 88591,
      "e": 88248,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88605,
      "e": 88262,
      "ty": 2,
      "x": 898,
      "y": 1030
    },
    {
      "t": 88755,
      "e": 88412,
      "ty": 41,
      "x": 29741,
      "y": 62579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89104,
      "e": 88761,
      "ty": 2,
      "x": 898,
      "y": 1028
    },
    {
      "t": 89204,
      "e": 88861,
      "ty": 2,
      "x": 896,
      "y": 1028
    },
    {
      "t": 89255,
      "e": 88912,
      "ty": 41,
      "x": 29643,
      "y": 62440,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89803,
      "e": 89460,
      "ty": 2,
      "x": 894,
      "y": 1029
    },
    {
      "t": 90005,
      "e": 89662,
      "ty": 41,
      "x": 29545,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90604,
      "e": 90261,
      "ty": 2,
      "x": 893,
      "y": 1029
    },
    {
      "t": 90754,
      "e": 90411,
      "ty": 41,
      "x": 29495,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91804,
      "e": 91461,
      "ty": 2,
      "x": 893,
      "y": 1027
    },
    {
      "t": 92004,
      "e": 91661,
      "ty": 2,
      "x": 893,
      "y": 1024
    },
    {
      "t": 92004,
      "e": 91661,
      "ty": 41,
      "x": 29495,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92104,
      "e": 91761,
      "ty": 2,
      "x": 893,
      "y": 1021
    },
    {
      "t": 92254,
      "e": 91911,
      "ty": 41,
      "x": 29495,
      "y": 61955,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92404,
      "e": 92061,
      "ty": 2,
      "x": 903,
      "y": 1021
    },
    {
      "t": 92504,
      "e": 92161,
      "ty": 2,
      "x": 904,
      "y": 1022
    },
    {
      "t": 92505,
      "e": 92162,
      "ty": 41,
      "x": 30037,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92604,
      "e": 92261,
      "ty": 2,
      "x": 904,
      "y": 1024
    },
    {
      "t": 92754,
      "e": 92411,
      "ty": 41,
      "x": 30037,
      "y": 62232,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92804,
      "e": 92461,
      "ty": 2,
      "x": 904,
      "y": 1025
    },
    {
      "t": 93904,
      "e": 93561,
      "ty": 2,
      "x": 904,
      "y": 1026
    },
    {
      "t": 94004,
      "e": 93661,
      "ty": 2,
      "x": 904,
      "y": 1027
    },
    {
      "t": 94004,
      "e": 93661,
      "ty": 41,
      "x": 30037,
      "y": 62371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94204,
      "e": 93861,
      "ty": 2,
      "x": 904,
      "y": 1028
    },
    {
      "t": 94254,
      "e": 93911,
      "ty": 41,
      "x": 30037,
      "y": 62440,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94404,
      "e": 94061,
      "ty": 2,
      "x": 904,
      "y": 1029
    },
    {
      "t": 94504,
      "e": 94161,
      "ty": 41,
      "x": 30037,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100009,
      "e": 99161,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 101008,
      "e": 99161,
      "ty": 2,
      "x": 902,
      "y": 1031
    },
    {
      "t": 101009,
      "e": 99162,
      "ty": 41,
      "x": 29938,
      "y": 62648,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 101109,
      "e": 99262,
      "ty": 2,
      "x": 901,
      "y": 1031
    },
    {
      "t": 101259,
      "e": 99412,
      "ty": 41,
      "x": 29889,
      "y": 62648,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 102608,
      "e": 100761,
      "ty": 2,
      "x": 901,
      "y": 1032
    },
    {
      "t": 102759,
      "e": 100912,
      "ty": 41,
      "x": 29889,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 103009,
      "e": 101162,
      "ty": 2,
      "x": 902,
      "y": 1032
    },
    {
      "t": 103009,
      "e": 101162,
      "ty": 41,
      "x": 29938,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 103108,
      "e": 101261,
      "ty": 2,
      "x": 905,
      "y": 1032
    },
    {
      "t": 103209,
      "e": 101362,
      "ty": 2,
      "x": 906,
      "y": 1062
    },
    {
      "t": 103259,
      "e": 101412,
      "ty": 41,
      "x": 9596,
      "y": 727,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 103309,
      "e": 101462,
      "ty": 2,
      "x": 910,
      "y": 1074
    },
    {
      "t": 103376,
      "e": 101529,
      "ty": 6,
      "x": 911,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 103408,
      "e": 101561,
      "ty": 2,
      "x": 914,
      "y": 1077
    },
    {
      "t": 103509,
      "e": 101662,
      "ty": 2,
      "x": 930,
      "y": 1085
    },
    {
      "t": 103509,
      "e": 101662,
      "ty": 41,
      "x": 11195,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 103609,
      "e": 101762,
      "ty": 2,
      "x": 941,
      "y": 1085
    },
    {
      "t": 103647,
      "e": 101800,
      "ty": 3,
      "x": 941,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 103648,
      "e": 101801,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 103743,
      "e": 101896,
      "ty": 4,
      "x": 17202,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 103744,
      "e": 101897,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 103746,
      "e": 101899,
      "ty": 5,
      "x": 941,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 103748,
      "e": 101901,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 103758,
      "e": 101911,
      "ty": 41,
      "x": 32130,
      "y": 59662,
      "ta": "html > body"
    },
    {
      "t": 104798,
      "e": 102951,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 106757,
      "e": 104910,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 72202, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 72204, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 56515, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 130059, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 12216, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 143283, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 13828, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 158434, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 12185, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 171622, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 42094, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 215063, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -10 AM-06 PM-03 PM-12 PM-11 AM-A -A -A -Z -11 AM-U -11 AM-F -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1112,y:829,t:1526929852414};\\\", \\\"{x:1112,y:824,t:1526929852421};\\\", \\\"{x:1112,y:820,t:1526929852433};\\\", \\\"{x:1107,y:805,t:1526929852450};\\\", \\\"{x:1107,y:780,t:1526929852466};\\\", \\\"{x:1115,y:757,t:1526929852483};\\\", \\\"{x:1138,y:728,t:1526929852500};\\\", \\\"{x:1155,y:706,t:1526929852515};\\\", \\\"{x:1214,y:661,t:1526929852533};\\\", \\\"{x:1237,y:642,t:1526929852549};\\\", \\\"{x:1255,y:625,t:1526929852566};\\\", \\\"{x:1261,y:616,t:1526929852582};\\\", \\\"{x:1268,y:602,t:1526929852600};\\\", \\\"{x:1269,y:597,t:1526929852616};\\\", \\\"{x:1269,y:594,t:1526929852632};\\\", \\\"{x:1271,y:593,t:1526929852661};\\\", \\\"{x:1271,y:592,t:1526929852669};\\\", \\\"{x:1272,y:591,t:1526929852683};\\\", \\\"{x:1280,y:585,t:1526929852699};\\\", \\\"{x:1304,y:577,t:1526929852717};\\\", \\\"{x:1322,y:569,t:1526929852733};\\\", \\\"{x:1339,y:564,t:1526929852749};\\\", \\\"{x:1342,y:564,t:1526929852765};\\\", \\\"{x:1364,y:567,t:1526929852783};\\\", \\\"{x:1393,y:588,t:1526929852799};\\\", \\\"{x:1412,y:596,t:1526929852816};\\\", \\\"{x:1440,y:621,t:1526929852832};\\\", \\\"{x:1454,y:643,t:1526929852850};\\\", \\\"{x:1469,y:667,t:1526929852866};\\\", \\\"{x:1481,y:691,t:1526929852883};\\\", \\\"{x:1485,y:712,t:1526929852899};\\\", \\\"{x:1495,y:741,t:1526929852917};\\\", \\\"{x:1499,y:757,t:1526929852933};\\\", \\\"{x:1501,y:767,t:1526929852950};\\\", \\\"{x:1501,y:780,t:1526929852967};\\\", \\\"{x:1497,y:789,t:1526929852982};\\\", \\\"{x:1494,y:799,t:1526929853000};\\\", \\\"{x:1490,y:808,t:1526929853016};\\\", \\\"{x:1488,y:816,t:1526929853033};\\\", \\\"{x:1486,y:824,t:1526929853050};\\\", \\\"{x:1486,y:828,t:1526929853069};\\\", \\\"{x:1485,y:832,t:1526929853082};\\\", \\\"{x:1484,y:833,t:1526929853099};\\\", \\\"{x:1481,y:838,t:1526929853116};\\\", \\\"{x:1479,y:841,t:1526929853132};\\\", \\\"{x:1476,y:845,t:1526929853149};\\\", \\\"{x:1474,y:848,t:1526929853166};\\\", \\\"{x:1472,y:850,t:1526929853182};\\\", \\\"{x:1470,y:852,t:1526929853199};\\\", \\\"{x:1463,y:855,t:1526929853216};\\\", \\\"{x:1458,y:858,t:1526929853233};\\\", \\\"{x:1451,y:863,t:1526929853249};\\\", \\\"{x:1448,y:865,t:1526929853266};\\\", \\\"{x:1434,y:873,t:1526929853283};\\\", \\\"{x:1417,y:883,t:1526929853299};\\\", \\\"{x:1400,y:894,t:1526929853317};\\\", \\\"{x:1394,y:900,t:1526929853333};\\\", \\\"{x:1380,y:908,t:1526929853349};\\\", \\\"{x:1365,y:916,t:1526929853366};\\\", \\\"{x:1354,y:922,t:1526929853385};\\\", \\\"{x:1332,y:930,t:1526929853399};\\\", \\\"{x:1301,y:940,t:1526929853417};\\\", \\\"{x:1279,y:952,t:1526929853433};\\\", \\\"{x:1262,y:963,t:1526929853449};\\\", \\\"{x:1237,y:972,t:1526929853467};\\\", \\\"{x:1223,y:978,t:1526929853484};\\\", \\\"{x:1217,y:980,t:1526929853500};\\\", \\\"{x:1213,y:982,t:1526929853517};\\\", \\\"{x:1214,y:982,t:1526929853749};\\\", \\\"{x:1216,y:982,t:1526929853837};\\\", \\\"{x:1217,y:982,t:1526929853901};\\\", \\\"{x:1218,y:982,t:1526929853917};\\\", \\\"{x:1219,y:982,t:1526929853957};\\\", \\\"{x:1220,y:982,t:1526929853980};\\\", \\\"{x:1220,y:981,t:1526929853989};\\\", \\\"{x:1222,y:980,t:1526929854000};\\\", \\\"{x:1223,y:978,t:1526929854016};\\\", \\\"{x:1224,y:976,t:1526929854032};\\\", \\\"{x:1228,y:973,t:1526929854050};\\\", \\\"{x:1230,y:971,t:1526929854066};\\\", \\\"{x:1233,y:969,t:1526929854083};\\\", \\\"{x:1238,y:963,t:1526929854100};\\\", \\\"{x:1242,y:959,t:1526929854117};\\\", \\\"{x:1244,y:957,t:1526929854133};\\\", \\\"{x:1245,y:957,t:1526929854150};\\\", \\\"{x:1246,y:956,t:1526929854167};\\\", \\\"{x:1246,y:954,t:1526929854184};\\\", \\\"{x:1248,y:952,t:1526929854200};\\\", \\\"{x:1250,y:950,t:1526929854218};\\\", \\\"{x:1253,y:947,t:1526929854234};\\\", \\\"{x:1255,y:945,t:1526929854251};\\\", \\\"{x:1258,y:940,t:1526929854267};\\\", \\\"{x:1260,y:936,t:1526929854284};\\\", \\\"{x:1262,y:934,t:1526929854300};\\\", \\\"{x:1264,y:924,t:1526929854317};\\\", \\\"{x:1268,y:914,t:1526929854333};\\\", \\\"{x:1274,y:898,t:1526929854351};\\\", \\\"{x:1275,y:880,t:1526929854367};\\\", \\\"{x:1275,y:862,t:1526929854385};\\\", \\\"{x:1275,y:860,t:1526929854400};\\\", \\\"{x:1275,y:856,t:1526929854417};\\\", \\\"{x:1273,y:854,t:1526929854433};\\\", \\\"{x:1272,y:852,t:1526929854451};\\\", \\\"{x:1272,y:849,t:1526929854468};\\\", \\\"{x:1269,y:844,t:1526929854484};\\\", \\\"{x:1264,y:832,t:1526929854501};\\\", \\\"{x:1261,y:824,t:1526929854518};\\\", \\\"{x:1258,y:818,t:1526929854534};\\\", \\\"{x:1255,y:808,t:1526929854550};\\\", \\\"{x:1245,y:786,t:1526929854567};\\\", \\\"{x:1228,y:744,t:1526929854585};\\\", \\\"{x:1196,y:683,t:1526929854601};\\\", \\\"{x:1155,y:614,t:1526929854617};\\\", \\\"{x:1106,y:527,t:1526929854635};\\\", \\\"{x:1030,y:426,t:1526929854650};\\\", \\\"{x:961,y:336,t:1526929854667};\\\", \\\"{x:862,y:210,t:1526929854684};\\\", \\\"{x:809,y:142,t:1526929854701};\\\", \\\"{x:761,y:96,t:1526929854717};\\\", \\\"{x:746,y:70,t:1526929854734};\\\", \\\"{x:730,y:55,t:1526929854751};\\\", \\\"{x:717,y:46,t:1526929854768};\\\", \\\"{x:709,y:35,t:1526929854785};\\\", \\\"{x:703,y:29,t:1526929854801};\\\", \\\"{x:694,y:23,t:1526929854817};\\\", \\\"{x:688,y:19,t:1526929854835};\\\", \\\"{x:684,y:16,t:1526929854851};\\\", \\\"{x:679,y:16,t:1526929854868};\\\", \\\"{x:671,y:16,t:1526929854884};\\\", \\\"{x:666,y:16,t:1526929854901};\\\", \\\"{x:662,y:16,t:1526929854918};\\\", \\\"{x:661,y:16,t:1526929854934};\\\", \\\"{x:658,y:16,t:1526929854950};\\\", \\\"{x:656,y:16,t:1526929854967};\\\", \\\"{x:655,y:16,t:1526929854984};\\\", \\\"{x:651,y:16,t:1526929855001};\\\", \\\"{x:645,y:16,t:1526929855017};\\\", \\\"{x:640,y:16,t:1526929855034};\\\", \\\"{x:634,y:16,t:1526929855050};\\\", \\\"{x:629,y:16,t:1526929855067};\\\", \\\"{x:623,y:16,t:1526929855084};\\\", \\\"{x:621,y:16,t:1526929855101};\\\", \\\"{x:617,y:16,t:1526929855117};\\\", \\\"{x:614,y:16,t:1526929855134};\\\", \\\"{x:610,y:16,t:1526929855152};\\\", \\\"{x:606,y:16,t:1526929855167};\\\", \\\"{x:598,y:16,t:1526929855185};\\\", \\\"{x:594,y:16,t:1526929855201};\\\", \\\"{x:589,y:16,t:1526929855217};\\\", \\\"{x:588,y:16,t:1526929856217};\\\", \\\"{x:585,y:17,t:1526929856224};\\\", \\\"{x:585,y:18,t:1526929856239};\\\", \\\"{x:584,y:18,t:1526929856272};\\\", \\\"{x:577,y:18,t:1526929856289};\\\", \\\"{x:559,y:17,t:1526929856305};\\\", \\\"{x:548,y:16,t:1526929856322};\\\", \\\"{x:543,y:16,t:1526929856339};\\\", \\\"{x:538,y:16,t:1526929856355};\\\", \\\"{x:533,y:16,t:1526929856372};\\\", \\\"{x:528,y:16,t:1526929856389};\\\", \\\"{x:525,y:16,t:1526929856405};\\\", \\\"{x:523,y:16,t:1526929856422};\\\", \\\"{x:525,y:16,t:1526929856519};\\\", \\\"{x:528,y:16,t:1526929856528};\\\", \\\"{x:534,y:16,t:1526929856538};\\\", \\\"{x:549,y:16,t:1526929856556};\\\", \\\"{x:572,y:16,t:1526929856572};\\\", \\\"{x:592,y:16,t:1526929856588};\\\", \\\"{x:601,y:20,t:1526929856605};\\\", \\\"{x:651,y:35,t:1526929856622};\\\", \\\"{x:742,y:61,t:1526929856639};\\\", \\\"{x:880,y:108,t:1526929856655};\\\", \\\"{x:968,y:138,t:1526929856671};\\\", \\\"{x:1023,y:160,t:1526929856688};\\\", \\\"{x:1034,y:165,t:1526929856705};\\\", \\\"{x:1036,y:167,t:1526929856722};\\\", \\\"{x:1036,y:168,t:1526929856768};\\\", \\\"{x:1037,y:169,t:1526929856784};\\\", \\\"{x:1038,y:170,t:1526929856792};\\\", \\\"{x:1038,y:172,t:1526929856806};\\\", \\\"{x:1038,y:173,t:1526929856822};\\\", \\\"{x:1038,y:175,t:1526929856839};\\\", \\\"{x:1032,y:180,t:1526929856856};\\\", \\\"{x:1027,y:187,t:1526929856872};\\\", \\\"{x:1021,y:202,t:1526929856889};\\\", \\\"{x:1013,y:211,t:1526929856906};\\\", \\\"{x:1006,y:225,t:1526929856922};\\\", \\\"{x:991,y:244,t:1526929856939};\\\", \\\"{x:972,y:281,t:1526929856956};\\\", \\\"{x:948,y:319,t:1526929856972};\\\", \\\"{x:915,y:369,t:1526929856989};\\\", \\\"{x:884,y:407,t:1526929857006};\\\", \\\"{x:864,y:430,t:1526929857023};\\\", \\\"{x:847,y:444,t:1526929857039};\\\", \\\"{x:816,y:458,t:1526929857056};\\\", \\\"{x:807,y:464,t:1526929857073};\\\", \\\"{x:802,y:464,t:1526929857089};\\\", \\\"{x:800,y:464,t:1526929857106};\\\", \\\"{x:794,y:460,t:1526929857123};\\\", \\\"{x:789,y:456,t:1526929857139};\\\", \\\"{x:793,y:456,t:1526929857545};\\\", \\\"{x:797,y:456,t:1526929857556};\\\", \\\"{x:821,y:466,t:1526929857573};\\\", \\\"{x:1008,y:514,t:1526929857591};\\\", \\\"{x:1259,y:588,t:1526929857606};\\\", \\\"{x:1580,y:689,t:1526929857622};\\\", \\\"{x:1919,y:808,t:1526929857640};\\\", \\\"{x:1919,y:864,t:1526929857656};\\\", \\\"{x:1919,y:888,t:1526929857672};\\\", \\\"{x:1919,y:894,t:1526929857690};\\\", \\\"{x:1919,y:902,t:1526929857707};\\\", \\\"{x:1919,y:912,t:1526929857724};\\\", \\\"{x:1919,y:917,t:1526929857740};\\\", \\\"{x:1919,y:920,t:1526929857756};\\\", \\\"{x:1919,y:921,t:1526929857774};\\\", \\\"{x:1919,y:924,t:1526929857790};\\\", \\\"{x:1919,y:934,t:1526929857807};\\\", \\\"{x:1919,y:941,t:1526929857823};\\\", \\\"{x:1917,y:946,t:1526929857840};\\\", \\\"{x:1913,y:949,t:1526929857857};\\\", \\\"{x:1904,y:951,t:1526929857876};\\\", \\\"{x:1895,y:954,t:1526929857890};\\\", \\\"{x:1891,y:957,t:1526929857907};\\\", \\\"{x:1884,y:958,t:1526929857924};\\\", \\\"{x:1879,y:958,t:1526929857940};\\\", \\\"{x:1872,y:958,t:1526929857957};\\\", \\\"{x:1861,y:958,t:1526929857973};\\\", \\\"{x:1846,y:958,t:1526929857990};\\\", \\\"{x:1838,y:956,t:1526929858006};\\\", \\\"{x:1827,y:956,t:1526929858023};\\\", \\\"{x:1818,y:958,t:1526929858040};\\\", \\\"{x:1812,y:960,t:1526929858056};\\\", \\\"{x:1810,y:961,t:1526929858073};\\\", \\\"{x:1802,y:965,t:1526929858091};\\\", \\\"{x:1788,y:969,t:1526929858107};\\\", \\\"{x:1768,y:976,t:1526929858124};\\\", \\\"{x:1743,y:981,t:1526929858141};\\\", \\\"{x:1721,y:988,t:1526929858157};\\\", \\\"{x:1701,y:998,t:1526929858173};\\\", \\\"{x:1685,y:1004,t:1526929858191};\\\", \\\"{x:1669,y:1011,t:1526929858207};\\\", \\\"{x:1656,y:1017,t:1526929858224};\\\", \\\"{x:1649,y:1020,t:1526929858241};\\\", \\\"{x:1645,y:1021,t:1526929858257};\\\", \\\"{x:1641,y:1021,t:1526929858274};\\\", \\\"{x:1635,y:1020,t:1526929858291};\\\", \\\"{x:1630,y:1017,t:1526929858307};\\\", \\\"{x:1609,y:1006,t:1526929858324};\\\", \\\"{x:1585,y:994,t:1526929858341};\\\", \\\"{x:1565,y:985,t:1526929858357};\\\", \\\"{x:1561,y:985,t:1526929858373};\\\", \\\"{x:1552,y:982,t:1526929858392};\\\", \\\"{x:1553,y:983,t:1526929858559};\\\", \\\"{x:1556,y:986,t:1526929858574};\\\", \\\"{x:1572,y:999,t:1526929858591};\\\", \\\"{x:1572,y:1000,t:1526929858873};\\\", \\\"{x:1570,y:1000,t:1526929858905};\\\", \\\"{x:1568,y:1002,t:1526929858953};\\\", \\\"{x:1565,y:1002,t:1526929858960};\\\", \\\"{x:1564,y:1002,t:1526929858973};\\\", \\\"{x:1563,y:1002,t:1526929858991};\\\", \\\"{x:1562,y:1002,t:1526929859105};\\\", \\\"{x:1559,y:1002,t:1526929859223};\\\", \\\"{x:1558,y:1002,t:1526929859231};\\\", \\\"{x:1555,y:1002,t:1526929859247};\\\", \\\"{x:1551,y:1002,t:1526929859258};\\\", \\\"{x:1546,y:1002,t:1526929859275};\\\", \\\"{x:1545,y:1003,t:1526929859296};\\\", \\\"{x:1539,y:1004,t:1526929859307};\\\", \\\"{x:1533,y:1006,t:1526929859325};\\\", \\\"{x:1532,y:1006,t:1526929859340};\\\", \\\"{x:1529,y:1007,t:1526929859399};\\\", \\\"{x:1528,y:1007,t:1526929859407};\\\", \\\"{x:1527,y:1007,t:1526929859440};\\\", \\\"{x:1526,y:1007,t:1526929859448};\\\", \\\"{x:1522,y:1007,t:1526929859458};\\\", \\\"{x:1518,y:1007,t:1526929859475};\\\", \\\"{x:1510,y:1008,t:1526929859491};\\\", \\\"{x:1509,y:1008,t:1526929859508};\\\", \\\"{x:1505,y:1008,t:1526929859526};\\\", \\\"{x:1495,y:1009,t:1526929859542};\\\", \\\"{x:1482,y:1009,t:1526929859559};\\\", \\\"{x:1466,y:1009,t:1526929859575};\\\", \\\"{x:1453,y:1009,t:1526929859592};\\\", \\\"{x:1451,y:1009,t:1526929859608};\\\", \\\"{x:1448,y:1009,t:1526929859625};\\\", \\\"{x:1445,y:1009,t:1526929859663};\\\", \\\"{x:1443,y:1009,t:1526929859674};\\\", \\\"{x:1435,y:1009,t:1526929859691};\\\", \\\"{x:1428,y:1009,t:1526929859707};\\\", \\\"{x:1423,y:1009,t:1526929859724};\\\", \\\"{x:1416,y:1009,t:1526929859742};\\\", \\\"{x:1415,y:1009,t:1526929859757};\\\", \\\"{x:1414,y:1009,t:1526929859856};\\\", \\\"{x:1410,y:1009,t:1526929859864};\\\", \\\"{x:1408,y:1009,t:1526929859880};\\\", \\\"{x:1407,y:1009,t:1526929859892};\\\", \\\"{x:1401,y:1009,t:1526929859908};\\\", \\\"{x:1391,y:1009,t:1526929859925};\\\", \\\"{x:1381,y:1010,t:1526929859942};\\\", \\\"{x:1378,y:1010,t:1526929859960};\\\", \\\"{x:1377,y:1010,t:1526929860521};\\\", \\\"{x:1377,y:1006,t:1526929860544};\\\", \\\"{x:1377,y:1003,t:1526929860559};\\\", \\\"{x:1377,y:998,t:1526929860577};\\\", \\\"{x:1375,y:995,t:1526929860593};\\\", \\\"{x:1375,y:991,t:1526929860609};\\\", \\\"{x:1374,y:989,t:1526929860627};\\\", \\\"{x:1374,y:986,t:1526929860642};\\\", \\\"{x:1374,y:985,t:1526929860659};\\\", \\\"{x:1372,y:983,t:1526929860676};\\\", \\\"{x:1371,y:982,t:1526929860692};\\\", \\\"{x:1371,y:980,t:1526929860709};\\\", \\\"{x:1370,y:979,t:1526929860728};\\\", \\\"{x:1370,y:978,t:1526929860768};\\\", \\\"{x:1369,y:977,t:1526929860776};\\\", \\\"{x:1369,y:976,t:1526929860800};\\\", \\\"{x:1368,y:976,t:1526929860809};\\\", \\\"{x:1367,y:973,t:1526929860827};\\\", \\\"{x:1367,y:971,t:1526929860843};\\\", \\\"{x:1366,y:971,t:1526929860859};\\\", \\\"{x:1365,y:969,t:1526929860876};\\\", \\\"{x:1365,y:967,t:1526929860893};\\\", \\\"{x:1364,y:963,t:1526929860909};\\\", \\\"{x:1364,y:960,t:1526929860927};\\\", \\\"{x:1362,y:958,t:1526929860944};\\\", \\\"{x:1357,y:939,t:1526929860960};\\\", \\\"{x:1356,y:937,t:1526929860976};\\\", \\\"{x:1356,y:935,t:1526929860993};\\\", \\\"{x:1356,y:933,t:1526929861009};\\\", \\\"{x:1356,y:932,t:1526929861145};\\\", \\\"{x:1356,y:931,t:1526929861169};\\\", \\\"{x:1356,y:930,t:1526929861200};\\\", \\\"{x:1356,y:929,t:1526929861249};\\\", \\\"{x:1356,y:928,t:1526929861288};\\\", \\\"{x:1356,y:927,t:1526929861408};\\\", \\\"{x:1356,y:926,t:1526929861529};\\\", \\\"{x:1356,y:925,t:1526929861648};\\\", \\\"{x:1356,y:924,t:1526929861697};\\\", \\\"{x:1356,y:923,t:1526929861833};\\\", \\\"{x:1356,y:922,t:1526929861856};\\\", \\\"{x:1355,y:922,t:1526929862128};\\\", \\\"{x:1353,y:922,t:1526929862143};\\\", \\\"{x:1346,y:922,t:1526929862161};\\\", \\\"{x:1342,y:924,t:1526929862177};\\\", \\\"{x:1335,y:927,t:1526929862194};\\\", \\\"{x:1329,y:930,t:1526929862210};\\\", \\\"{x:1321,y:932,t:1526929862227};\\\", \\\"{x:1317,y:934,t:1526929862243};\\\", \\\"{x:1313,y:935,t:1526929862259};\\\", \\\"{x:1309,y:936,t:1526929862277};\\\", \\\"{x:1304,y:938,t:1526929862293};\\\", \\\"{x:1298,y:940,t:1526929862310};\\\", \\\"{x:1291,y:943,t:1526929862326};\\\", \\\"{x:1284,y:947,t:1526929862343};\\\", \\\"{x:1283,y:947,t:1526929862359};\\\", \\\"{x:1282,y:947,t:1526929862416};\\\", \\\"{x:1282,y:948,t:1526929862440};\\\", \\\"{x:1282,y:949,t:1526929862455};\\\", \\\"{x:1282,y:950,t:1526929862561};\\\", \\\"{x:1282,y:951,t:1526929862584};\\\", \\\"{x:1282,y:952,t:1526929862595};\\\", \\\"{x:1281,y:953,t:1526929862611};\\\", \\\"{x:1280,y:955,t:1526929862627};\\\", \\\"{x:1279,y:957,t:1526929862657};\\\", \\\"{x:1279,y:959,t:1526929862705};\\\", \\\"{x:1279,y:961,t:1526929862720};\\\", \\\"{x:1278,y:963,t:1526929862729};\\\", \\\"{x:1278,y:964,t:1526929862744};\\\", \\\"{x:1276,y:965,t:1526929862761};\\\", \\\"{x:1276,y:966,t:1526929862778};\\\", \\\"{x:1276,y:967,t:1526929862795};\\\", \\\"{x:1276,y:968,t:1526929862832};\\\", \\\"{x:1276,y:969,t:1526929862856};\\\", \\\"{x:1276,y:970,t:1526929862864};\\\", \\\"{x:1276,y:972,t:1526929862880};\\\", \\\"{x:1277,y:974,t:1526929862912};\\\", \\\"{x:1279,y:975,t:1526929862927};\\\", \\\"{x:1280,y:976,t:1526929862944};\\\", \\\"{x:1282,y:976,t:1526929862961};\\\", \\\"{x:1284,y:977,t:1526929862977};\\\", \\\"{x:1285,y:977,t:1526929863008};\\\", \\\"{x:1286,y:977,t:1526929863088};\\\", \\\"{x:1288,y:977,t:1526929863161};\\\", \\\"{x:1288,y:976,t:1526929863184};\\\", \\\"{x:1288,y:975,t:1526929863208};\\\", \\\"{x:1288,y:974,t:1526929863224};\\\", \\\"{x:1288,y:972,t:1526929863240};\\\", \\\"{x:1288,y:971,t:1526929863256};\\\", \\\"{x:1288,y:969,t:1526929863264};\\\", \\\"{x:1288,y:968,t:1526929863278};\\\", \\\"{x:1288,y:964,t:1526929863295};\\\", \\\"{x:1287,y:964,t:1526929863312};\\\", \\\"{x:1286,y:964,t:1526929863336};\\\", \\\"{x:1285,y:964,t:1526929863512};\\\", \\\"{x:1285,y:959,t:1526929863552};\\\", \\\"{x:1285,y:952,t:1526929863562};\\\", \\\"{x:1282,y:944,t:1526929863579};\\\", \\\"{x:1282,y:939,t:1526929863594};\\\", \\\"{x:1282,y:932,t:1526929863611};\\\", \\\"{x:1282,y:928,t:1526929863628};\\\", \\\"{x:1282,y:926,t:1526929863645};\\\", \\\"{x:1282,y:924,t:1526929863662};\\\", \\\"{x:1283,y:919,t:1526929863679};\\\", \\\"{x:1285,y:914,t:1526929863694};\\\", \\\"{x:1287,y:907,t:1526929863712};\\\", \\\"{x:1287,y:888,t:1526929863728};\\\", \\\"{x:1284,y:860,t:1526929863745};\\\", \\\"{x:1280,y:838,t:1526929863762};\\\", \\\"{x:1279,y:825,t:1526929863779};\\\", \\\"{x:1278,y:811,t:1526929863795};\\\", \\\"{x:1277,y:798,t:1526929863811};\\\", \\\"{x:1275,y:791,t:1526929863828};\\\", \\\"{x:1275,y:784,t:1526929863844};\\\", \\\"{x:1274,y:779,t:1526929863861};\\\", \\\"{x:1274,y:774,t:1526929863877};\\\", \\\"{x:1274,y:773,t:1526929863894};\\\", \\\"{x:1274,y:772,t:1526929864008};\\\", \\\"{x:1273,y:776,t:1526929864032};\\\", \\\"{x:1274,y:778,t:1526929864045};\\\", \\\"{x:1278,y:782,t:1526929864061};\\\", \\\"{x:1280,y:786,t:1526929864078};\\\", \\\"{x:1280,y:788,t:1526929864095};\\\", \\\"{x:1282,y:790,t:1526929864111};\\\", \\\"{x:1283,y:791,t:1526929864161};\\\", \\\"{x:1283,y:792,t:1526929864217};\\\", \\\"{x:1283,y:794,t:1526929864248};\\\", \\\"{x:1284,y:794,t:1526929864261};\\\", \\\"{x:1285,y:796,t:1526929864279};\\\", \\\"{x:1286,y:802,t:1526929864295};\\\", \\\"{x:1289,y:812,t:1526929864312};\\\", \\\"{x:1290,y:817,t:1526929864328};\\\", \\\"{x:1290,y:819,t:1526929864346};\\\", \\\"{x:1290,y:821,t:1526929864362};\\\", \\\"{x:1290,y:824,t:1526929864378};\\\", \\\"{x:1290,y:825,t:1526929864416};\\\", \\\"{x:1290,y:826,t:1526929864429};\\\", \\\"{x:1290,y:827,t:1526929864448};\\\", \\\"{x:1291,y:828,t:1526929864463};\\\", \\\"{x:1291,y:829,t:1526929864479};\\\", \\\"{x:1292,y:831,t:1526929864495};\\\", \\\"{x:1293,y:832,t:1526929864640};\\\", \\\"{x:1293,y:831,t:1526929865031};\\\", \\\"{x:1292,y:831,t:1526929865104};\\\", \\\"{x:1290,y:831,t:1526929865160};\\\", \\\"{x:1290,y:832,t:1526929865168};\\\", \\\"{x:1288,y:832,t:1526929865192};\\\", \\\"{x:1287,y:832,t:1526929865200};\\\", \\\"{x:1285,y:832,t:1526929865224};\\\", \\\"{x:1283,y:832,t:1526929865246};\\\", \\\"{x:1282,y:832,t:1526929867049};\\\", \\\"{x:1282,y:831,t:1526929867120};\\\", \\\"{x:1281,y:831,t:1526929867168};\\\", \\\"{x:1280,y:831,t:1526929867945};\\\", \\\"{x:1280,y:832,t:1526929867951};\\\", \\\"{x:1280,y:833,t:1526929867965};\\\", \\\"{x:1280,y:835,t:1526929867982};\\\", \\\"{x:1279,y:835,t:1526929867999};\\\", \\\"{x:1279,y:836,t:1526929868015};\\\", \\\"{x:1279,y:837,t:1526929868048};\\\", \\\"{x:1279,y:838,t:1526929868080};\\\", \\\"{x:1279,y:839,t:1526929868088};\\\", \\\"{x:1278,y:841,t:1526929868104};\\\", \\\"{x:1277,y:841,t:1526929868120};\\\", \\\"{x:1277,y:842,t:1526929868131};\\\", \\\"{x:1277,y:843,t:1526929868149};\\\", \\\"{x:1277,y:844,t:1526929868165};\\\", \\\"{x:1277,y:846,t:1526929868181};\\\", \\\"{x:1278,y:848,t:1526929868198};\\\", \\\"{x:1278,y:849,t:1526929868216};\\\", \\\"{x:1279,y:850,t:1526929868232};\\\", \\\"{x:1280,y:851,t:1526929869335};\\\", \\\"{x:1282,y:852,t:1526929869349};\\\", \\\"{x:1287,y:854,t:1526929869365};\\\", \\\"{x:1288,y:855,t:1526929869381};\\\", \\\"{x:1290,y:857,t:1526929869399};\\\", \\\"{x:1292,y:860,t:1526929869415};\\\", \\\"{x:1293,y:861,t:1526929869432};\\\", \\\"{x:1294,y:863,t:1526929869455};\\\", \\\"{x:1295,y:863,t:1526929869471};\\\", \\\"{x:1295,y:864,t:1526929869487};\\\", \\\"{x:1296,y:866,t:1526929869512};\\\", \\\"{x:1296,y:867,t:1526929869528};\\\", \\\"{x:1296,y:868,t:1526929869536};\\\", \\\"{x:1296,y:869,t:1526929869549};\\\", \\\"{x:1298,y:870,t:1526929869565};\\\", \\\"{x:1299,y:871,t:1526929869583};\\\", \\\"{x:1299,y:872,t:1526929869608};\\\", \\\"{x:1300,y:873,t:1526929869624};\\\", \\\"{x:1301,y:876,t:1526929869633};\\\", \\\"{x:1302,y:877,t:1526929869650};\\\", \\\"{x:1303,y:881,t:1526929869666};\\\", \\\"{x:1306,y:886,t:1526929869682};\\\", \\\"{x:1306,y:887,t:1526929869699};\\\", \\\"{x:1306,y:890,t:1526929869720};\\\", \\\"{x:1306,y:892,t:1526929869744};\\\", \\\"{x:1306,y:893,t:1526929869752};\\\", \\\"{x:1305,y:893,t:1526929869765};\\\", \\\"{x:1303,y:896,t:1526929869782};\\\", \\\"{x:1303,y:897,t:1526929869824};\\\", \\\"{x:1303,y:896,t:1526929869904};\\\", \\\"{x:1303,y:895,t:1526929870337};\\\", \\\"{x:1304,y:893,t:1526929870424};\\\", \\\"{x:1305,y:891,t:1526929870434};\\\", \\\"{x:1307,y:887,t:1526929870450};\\\", \\\"{x:1307,y:883,t:1526929870467};\\\", \\\"{x:1307,y:880,t:1526929870484};\\\", \\\"{x:1308,y:874,t:1526929870500};\\\", \\\"{x:1309,y:869,t:1526929870517};\\\", \\\"{x:1311,y:864,t:1526929870533};\\\", \\\"{x:1313,y:858,t:1526929870549};\\\", \\\"{x:1318,y:849,t:1526929870567};\\\", \\\"{x:1325,y:839,t:1526929870584};\\\", \\\"{x:1331,y:832,t:1526929870600};\\\", \\\"{x:1333,y:828,t:1526929870616};\\\", \\\"{x:1335,y:826,t:1526929870633};\\\", \\\"{x:1339,y:819,t:1526929870650};\\\", \\\"{x:1345,y:812,t:1526929870667};\\\", \\\"{x:1353,y:804,t:1526929870684};\\\", \\\"{x:1363,y:796,t:1526929870700};\\\", \\\"{x:1367,y:792,t:1526929870716};\\\", \\\"{x:1370,y:788,t:1526929870734};\\\", \\\"{x:1373,y:783,t:1526929870750};\\\", \\\"{x:1375,y:781,t:1526929870767};\\\", \\\"{x:1384,y:773,t:1526929870784};\\\", \\\"{x:1395,y:760,t:1526929870800};\\\", \\\"{x:1407,y:750,t:1526929870817};\\\", \\\"{x:1419,y:741,t:1526929870833};\\\", \\\"{x:1422,y:738,t:1526929870850};\\\", \\\"{x:1429,y:732,t:1526929870866};\\\", \\\"{x:1433,y:727,t:1526929870884};\\\", \\\"{x:1436,y:723,t:1526929870901};\\\", \\\"{x:1438,y:721,t:1526929870916};\\\", \\\"{x:1442,y:714,t:1526929870934};\\\", \\\"{x:1450,y:705,t:1526929870951};\\\", \\\"{x:1457,y:701,t:1526929870967};\\\", \\\"{x:1464,y:694,t:1526929870984};\\\", \\\"{x:1467,y:690,t:1526929871000};\\\", \\\"{x:1470,y:688,t:1526929871017};\\\", \\\"{x:1471,y:686,t:1526929871034};\\\", \\\"{x:1472,y:685,t:1526929871056};\\\", \\\"{x:1473,y:684,t:1526929871072};\\\", \\\"{x:1473,y:683,t:1526929871084};\\\", \\\"{x:1475,y:681,t:1526929871104};\\\", \\\"{x:1476,y:680,t:1526929871143};\\\", \\\"{x:1477,y:679,t:1526929872760};\\\", \\\"{x:1478,y:678,t:1526929873064};\\\", \\\"{x:1477,y:678,t:1526929874751};\\\", \\\"{x:1476,y:681,t:1526929874759};\\\", \\\"{x:1476,y:684,t:1526929874769};\\\", \\\"{x:1476,y:687,t:1526929874786};\\\", \\\"{x:1476,y:689,t:1526929874802};\\\", \\\"{x:1473,y:692,t:1526929874819};\\\", \\\"{x:1472,y:693,t:1526929874836};\\\", \\\"{x:1471,y:693,t:1526929875919};\\\", \\\"{x:1470,y:693,t:1526929875926};\\\", \\\"{x:1469,y:695,t:1526929875936};\\\", \\\"{x:1467,y:697,t:1526929875953};\\\", \\\"{x:1466,y:699,t:1526929875970};\\\", \\\"{x:1463,y:706,t:1526929875987};\\\", \\\"{x:1454,y:722,t:1526929876003};\\\", \\\"{x:1437,y:743,t:1526929876020};\\\", \\\"{x:1430,y:762,t:1526929876037};\\\", \\\"{x:1424,y:781,t:1526929876053};\\\", \\\"{x:1420,y:797,t:1526929876070};\\\", \\\"{x:1405,y:823,t:1526929876087};\\\", \\\"{x:1393,y:839,t:1526929876103};\\\", \\\"{x:1382,y:855,t:1526929876120};\\\", \\\"{x:1373,y:865,t:1526929876137};\\\", \\\"{x:1368,y:872,t:1526929876153};\\\", \\\"{x:1365,y:876,t:1526929876170};\\\", \\\"{x:1364,y:880,t:1526929876187};\\\", \\\"{x:1361,y:885,t:1526929876203};\\\", \\\"{x:1356,y:894,t:1526929876219};\\\", \\\"{x:1351,y:896,t:1526929876237};\\\", \\\"{x:1342,y:900,t:1526929876253};\\\", \\\"{x:1336,y:902,t:1526929876269};\\\", \\\"{x:1331,y:903,t:1526929876287};\\\", \\\"{x:1329,y:905,t:1526929876303};\\\", \\\"{x:1329,y:904,t:1526929876383};\\\", \\\"{x:1329,y:903,t:1526929876390};\\\", \\\"{x:1329,y:902,t:1526929876403};\\\", \\\"{x:1329,y:898,t:1526929876420};\\\", \\\"{x:1329,y:890,t:1526929876437};\\\", \\\"{x:1335,y:879,t:1526929876454};\\\", \\\"{x:1349,y:859,t:1526929876470};\\\", \\\"{x:1369,y:835,t:1526929876487};\\\", \\\"{x:1379,y:813,t:1526929876504};\\\", \\\"{x:1388,y:796,t:1526929876520};\\\", \\\"{x:1395,y:781,t:1526929876537};\\\", \\\"{x:1398,y:771,t:1526929876555};\\\", \\\"{x:1399,y:768,t:1526929876570};\\\", \\\"{x:1400,y:761,t:1526929876587};\\\", \\\"{x:1402,y:757,t:1526929876604};\\\", \\\"{x:1402,y:753,t:1526929876620};\\\", \\\"{x:1401,y:751,t:1526929876679};\\\", \\\"{x:1398,y:750,t:1526929876686};\\\", \\\"{x:1384,y:749,t:1526929876704};\\\", \\\"{x:1364,y:747,t:1526929876720};\\\", \\\"{x:1338,y:745,t:1526929876737};\\\", \\\"{x:1299,y:742,t:1526929876754};\\\", \\\"{x:1238,y:741,t:1526929876770};\\\", \\\"{x:1209,y:739,t:1526929876787};\\\", \\\"{x:1161,y:740,t:1526929876804};\\\", \\\"{x:1119,y:736,t:1526929876820};\\\", \\\"{x:1104,y:735,t:1526929876837};\\\", \\\"{x:1076,y:735,t:1526929876854};\\\", \\\"{x:1017,y:735,t:1526929876870};\\\", \\\"{x:1000,y:737,t:1526929876887};\\\", \\\"{x:980,y:737,t:1526929876904};\\\", \\\"{x:963,y:737,t:1526929876921};\\\", \\\"{x:940,y:737,t:1526929876936};\\\", \\\"{x:925,y:737,t:1526929876954};\\\", \\\"{x:899,y:732,t:1526929876971};\\\", \\\"{x:877,y:730,t:1526929876987};\\\", \\\"{x:867,y:722,t:1526929877004};\\\", \\\"{x:836,y:722,t:1526929877020};\\\", \\\"{x:827,y:722,t:1526929877038};\\\", \\\"{x:819,y:722,t:1526929877054};\\\", \\\"{x:808,y:717,t:1526929877071};\\\", \\\"{x:803,y:717,t:1526929877087};\\\", \\\"{x:796,y:716,t:1526929877104};\\\", \\\"{x:786,y:712,t:1526929877121};\\\", \\\"{x:774,y:708,t:1526929877137};\\\", \\\"{x:749,y:698,t:1526929877154};\\\", \\\"{x:723,y:685,t:1526929877170};\\\", \\\"{x:677,y:669,t:1526929877187};\\\", \\\"{x:620,y:656,t:1526929877204};\\\", \\\"{x:597,y:650,t:1526929877221};\\\", \\\"{x:570,y:643,t:1526929877237};\\\", \\\"{x:549,y:639,t:1526929877254};\\\", \\\"{x:514,y:631,t:1526929877272};\\\", \\\"{x:497,y:628,t:1526929877289};\\\", \\\"{x:487,y:625,t:1526929877306};\\\", \\\"{x:485,y:621,t:1526929877322};\\\", \\\"{x:485,y:619,t:1526929877340};\\\", \\\"{x:484,y:619,t:1526929877583};\\\", \\\"{x:482,y:619,t:1526929877631};\\\", \\\"{x:479,y:619,t:1526929877639};\\\", \\\"{x:470,y:619,t:1526929877656};\\\", \\\"{x:454,y:618,t:1526929877672};\\\", \\\"{x:435,y:613,t:1526929877689};\\\", \\\"{x:415,y:604,t:1526929877706};\\\", \\\"{x:396,y:601,t:1526929877721};\\\", \\\"{x:373,y:592,t:1526929877739};\\\", \\\"{x:350,y:579,t:1526929877756};\\\", \\\"{x:337,y:573,t:1526929877774};\\\", \\\"{x:335,y:571,t:1526929877789};\\\", \\\"{x:333,y:570,t:1526929877806};\\\", \\\"{x:333,y:569,t:1526929877863};\\\", \\\"{x:333,y:567,t:1526929877879};\\\", \\\"{x:334,y:566,t:1526929877889};\\\", \\\"{x:337,y:564,t:1526929877906};\\\", \\\"{x:341,y:561,t:1526929877922};\\\", \\\"{x:350,y:559,t:1526929877939};\\\", \\\"{x:356,y:557,t:1526929877956};\\\", \\\"{x:369,y:556,t:1526929877972};\\\", \\\"{x:379,y:554,t:1526929877989};\\\", \\\"{x:389,y:552,t:1526929878007};\\\", \\\"{x:402,y:550,t:1526929878023};\\\", \\\"{x:406,y:550,t:1526929878039};\\\", \\\"{x:409,y:550,t:1526929878056};\\\", \\\"{x:410,y:550,t:1526929878094};\\\", \\\"{x:409,y:550,t:1526929878295};\\\", \\\"{x:408,y:550,t:1526929878306};\\\", \\\"{x:407,y:550,t:1526929878323};\\\", \\\"{x:403,y:551,t:1526929878339};\\\", \\\"{x:397,y:553,t:1526929878356};\\\", \\\"{x:389,y:554,t:1526929878373};\\\", \\\"{x:388,y:555,t:1526929878399};\\\", \\\"{x:386,y:555,t:1526929878422};\\\", \\\"{x:386,y:556,t:1526929878935};\\\", \\\"{x:398,y:560,t:1526929878943};\\\", \\\"{x:410,y:565,t:1526929878957};\\\", \\\"{x:520,y:595,t:1526929878974};\\\", \\\"{x:647,y:633,t:1526929878991};\\\", \\\"{x:849,y:689,t:1526929879006};\\\", \\\"{x:986,y:745,t:1526929879023};\\\", \\\"{x:1069,y:781,t:1526929879040};\\\", \\\"{x:1105,y:798,t:1526929879057};\\\", \\\"{x:1112,y:803,t:1526929879073};\\\", \\\"{x:1114,y:806,t:1526929879090};\\\", \\\"{x:1115,y:808,t:1526929879107};\\\", \\\"{x:1115,y:812,t:1526929879123};\\\", \\\"{x:1117,y:814,t:1526929879140};\\\", \\\"{x:1118,y:823,t:1526929879157};\\\", \\\"{x:1122,y:832,t:1526929879174};\\\", \\\"{x:1125,y:836,t:1526929879190};\\\", \\\"{x:1128,y:839,t:1526929879207};\\\", \\\"{x:1129,y:841,t:1526929879225};\\\", \\\"{x:1130,y:843,t:1526929879263};\\\", \\\"{x:1132,y:846,t:1526929879274};\\\", \\\"{x:1138,y:852,t:1526929879290};\\\", \\\"{x:1140,y:854,t:1526929879307};\\\", \\\"{x:1142,y:856,t:1526929879324};\\\", \\\"{x:1145,y:860,t:1526929879340};\\\", \\\"{x:1150,y:866,t:1526929879357};\\\", \\\"{x:1158,y:873,t:1526929879374};\\\", \\\"{x:1166,y:881,t:1526929879390};\\\", \\\"{x:1176,y:891,t:1526929879407};\\\", \\\"{x:1183,y:904,t:1526929879424};\\\", \\\"{x:1189,y:911,t:1526929879440};\\\", \\\"{x:1192,y:921,t:1526929879457};\\\", \\\"{x:1197,y:929,t:1526929879474};\\\", \\\"{x:1198,y:935,t:1526929879491};\\\", \\\"{x:1199,y:937,t:1526929879507};\\\", \\\"{x:1200,y:940,t:1526929879524};\\\", \\\"{x:1201,y:940,t:1526929879541};\\\", \\\"{x:1202,y:942,t:1526929879566};\\\", \\\"{x:1203,y:943,t:1526929879574};\\\", \\\"{x:1203,y:945,t:1526929879598};\\\", \\\"{x:1204,y:946,t:1526929879607};\\\", \\\"{x:1205,y:947,t:1526929879624};\\\", \\\"{x:1206,y:947,t:1526929879641};\\\", \\\"{x:1206,y:948,t:1526929879657};\\\", \\\"{x:1208,y:950,t:1526929879674};\\\", \\\"{x:1210,y:953,t:1526929879691};\\\", \\\"{x:1212,y:954,t:1526929879707};\\\", \\\"{x:1215,y:958,t:1526929879724};\\\", \\\"{x:1216,y:958,t:1526929879741};\\\", \\\"{x:1219,y:960,t:1526929879757};\\\", \\\"{x:1224,y:961,t:1526929879774};\\\", \\\"{x:1236,y:965,t:1526929879791};\\\", \\\"{x:1243,y:967,t:1526929879807};\\\", \\\"{x:1250,y:969,t:1526929879824};\\\", \\\"{x:1257,y:970,t:1526929879841};\\\", \\\"{x:1264,y:971,t:1526929879857};\\\", \\\"{x:1270,y:972,t:1526929879874};\\\", \\\"{x:1274,y:972,t:1526929879891};\\\", \\\"{x:1276,y:972,t:1526929879907};\\\", \\\"{x:1277,y:972,t:1526929879951};\\\", \\\"{x:1278,y:972,t:1526929879959};\\\", \\\"{x:1279,y:972,t:1526929879975};\\\", \\\"{x:1281,y:972,t:1526929880014};\\\", \\\"{x:1282,y:972,t:1526929880024};\\\", \\\"{x:1283,y:971,t:1526929880041};\\\", \\\"{x:1284,y:971,t:1526929880223};\\\", \\\"{x:1287,y:968,t:1526929880239};\\\", \\\"{x:1289,y:967,t:1526929880263};\\\", \\\"{x:1290,y:966,t:1526929880278};\\\", \\\"{x:1291,y:966,t:1526929880291};\\\", \\\"{x:1293,y:965,t:1526929880308};\\\", \\\"{x:1295,y:964,t:1526929880325};\\\", \\\"{x:1296,y:963,t:1526929880341};\\\", \\\"{x:1297,y:962,t:1526929880359};\\\", \\\"{x:1298,y:961,t:1526929880374};\\\", \\\"{x:1299,y:961,t:1526929880399};\\\", \\\"{x:1299,y:960,t:1526929880408};\\\", \\\"{x:1299,y:959,t:1526929880431};\\\", \\\"{x:1299,y:958,t:1526929880446};\\\", \\\"{x:1299,y:957,t:1526929880462};\\\", \\\"{x:1298,y:957,t:1526929880567};\\\", \\\"{x:1296,y:957,t:1526929880583};\\\", \\\"{x:1295,y:957,t:1526929880927};\\\", \\\"{x:1293,y:957,t:1526929880943};\\\", \\\"{x:1292,y:957,t:1526929880958};\\\", \\\"{x:1290,y:957,t:1526929880975};\\\", \\\"{x:1287,y:957,t:1526929881071};\\\", \\\"{x:1286,y:957,t:1526929881079};\\\", \\\"{x:1283,y:956,t:1526929881092};\\\", \\\"{x:1277,y:956,t:1526929881109};\\\", \\\"{x:1275,y:956,t:1526929881125};\\\", \\\"{x:1273,y:956,t:1526929881142};\\\", \\\"{x:1271,y:956,t:1526929881159};\\\", \\\"{x:1263,y:956,t:1526929881175};\\\", \\\"{x:1252,y:956,t:1526929881192};\\\", \\\"{x:1242,y:955,t:1526929881209};\\\", \\\"{x:1238,y:954,t:1526929881225};\\\", \\\"{x:1238,y:953,t:1526929881263};\\\", \\\"{x:1238,y:952,t:1526929881275};\\\", \\\"{x:1238,y:951,t:1526929881415};\\\", \\\"{x:1238,y:950,t:1526929881425};\\\", \\\"{x:1238,y:947,t:1526929881442};\\\", \\\"{x:1238,y:945,t:1526929881459};\\\", \\\"{x:1236,y:940,t:1526929881477};\\\", \\\"{x:1235,y:935,t:1526929881492};\\\", \\\"{x:1232,y:924,t:1526929881509};\\\", \\\"{x:1227,y:916,t:1526929881526};\\\", \\\"{x:1223,y:910,t:1526929881542};\\\", \\\"{x:1217,y:902,t:1526929881559};\\\", \\\"{x:1215,y:897,t:1526929881576};\\\", \\\"{x:1211,y:892,t:1526929881592};\\\", \\\"{x:1206,y:887,t:1526929881609};\\\", \\\"{x:1201,y:879,t:1526929881626};\\\", \\\"{x:1197,y:874,t:1526929881642};\\\", \\\"{x:1195,y:871,t:1526929881659};\\\", \\\"{x:1195,y:870,t:1526929881687};\\\", \\\"{x:1194,y:868,t:1526929881695};\\\", \\\"{x:1192,y:866,t:1526929881710};\\\", \\\"{x:1192,y:865,t:1526929881726};\\\", \\\"{x:1191,y:863,t:1526929881742};\\\", \\\"{x:1190,y:857,t:1526929881759};\\\", \\\"{x:1190,y:853,t:1526929881777};\\\", \\\"{x:1187,y:849,t:1526929881793};\\\", \\\"{x:1186,y:846,t:1526929881810};\\\", \\\"{x:1183,y:841,t:1526929881826};\\\", \\\"{x:1182,y:834,t:1526929881842};\\\", \\\"{x:1180,y:827,t:1526929881859};\\\", \\\"{x:1179,y:822,t:1526929881876};\\\", \\\"{x:1174,y:813,t:1526929881893};\\\", \\\"{x:1172,y:805,t:1526929881909};\\\", \\\"{x:1170,y:801,t:1526929881926};\\\", \\\"{x:1168,y:797,t:1526929881942};\\\", \\\"{x:1168,y:795,t:1526929881959};\\\", \\\"{x:1167,y:794,t:1526929881976};\\\", \\\"{x:1167,y:792,t:1526929881993};\\\", \\\"{x:1165,y:790,t:1526929882009};\\\", \\\"{x:1165,y:789,t:1526929882026};\\\", \\\"{x:1165,y:788,t:1526929882043};\\\", \\\"{x:1164,y:786,t:1526929882059};\\\", \\\"{x:1164,y:785,t:1526929882076};\\\", \\\"{x:1164,y:784,t:1526929882119};\\\", \\\"{x:1163,y:784,t:1526929882174};\\\", \\\"{x:1163,y:783,t:1526929882181};\\\", \\\"{x:1163,y:782,t:1526929882205};\\\", \\\"{x:1163,y:781,t:1526929882214};\\\", \\\"{x:1162,y:780,t:1526929882230};\\\", \\\"{x:1162,y:779,t:1526929882262};\\\", \\\"{x:1161,y:779,t:1526929882287};\\\", \\\"{x:1161,y:778,t:1526929882294};\\\", \\\"{x:1160,y:778,t:1526929882391};\\\", \\\"{x:1160,y:777,t:1526929882399};\\\", \\\"{x:1160,y:776,t:1526929882478};\\\", \\\"{x:1159,y:775,t:1526929882615};\\\", \\\"{x:1159,y:774,t:1526929882638};\\\", \\\"{x:1159,y:773,t:1526929882670};\\\", \\\"{x:1159,y:772,t:1526929882678};\\\", \\\"{x:1159,y:771,t:1526929882758};\\\", \\\"{x:1159,y:770,t:1526929882831};\\\", \\\"{x:1158,y:770,t:1526929883311};\\\", \\\"{x:1155,y:770,t:1526929883327};\\\", \\\"{x:1143,y:776,t:1526929883344};\\\", \\\"{x:1125,y:782,t:1526929883360};\\\", \\\"{x:1067,y:783,t:1526929883377};\\\", \\\"{x:1046,y:783,t:1526929883394};\\\", \\\"{x:961,y:779,t:1526929883410};\\\", \\\"{x:888,y:777,t:1526929883427};\\\", \\\"{x:808,y:777,t:1526929883444};\\\", \\\"{x:788,y:776,t:1526929883460};\\\", \\\"{x:750,y:773,t:1526929883477};\\\", \\\"{x:704,y:771,t:1526929883494};\\\", \\\"{x:685,y:766,t:1526929883510};\\\", \\\"{x:668,y:760,t:1526929883527};\\\", \\\"{x:643,y:755,t:1526929883544};\\\", \\\"{x:607,y:749,t:1526929883561};\\\", \\\"{x:571,y:743,t:1526929883578};\\\", \\\"{x:561,y:739,t:1526929883594};\\\", \\\"{x:552,y:732,t:1526929883611};\\\", \\\"{x:543,y:730,t:1526929883627};\\\", \\\"{x:541,y:728,t:1526929883644};\\\", \\\"{x:531,y:726,t:1526929883658};\\\", \\\"{x:512,y:719,t:1526929883675};\\\", \\\"{x:496,y:715,t:1526929883692};\\\", \\\"{x:483,y:709,t:1526929883708};\\\", \\\"{x:471,y:703,t:1526929883725};\\\", \\\"{x:452,y:696,t:1526929883742};\\\", \\\"{x:442,y:692,t:1526929883758};\\\", \\\"{x:437,y:687,t:1526929883777};\\\", \\\"{x:434,y:685,t:1526929883793};\\\", \\\"{x:431,y:681,t:1526929883810};\\\", \\\"{x:431,y:679,t:1526929883827};\\\", \\\"{x:431,y:678,t:1526929883844};\\\", \\\"{x:431,y:677,t:1526929883860};\\\", \\\"{x:431,y:676,t:1526929883877};\\\", \\\"{x:423,y:676,t:1526929884271};\\\", \\\"{x:403,y:676,t:1526929884278};\\\", \\\"{x:397,y:674,t:1526929884292};\\\", \\\"{x:375,y:672,t:1526929884309};\\\", \\\"{x:365,y:672,t:1526929884325};\\\", \\\"{x:321,y:675,t:1526929884342};\\\", \\\"{x:296,y:675,t:1526929884358};\\\", \\\"{x:275,y:675,t:1526929884375};\\\", \\\"{x:254,y:675,t:1526929884393};\\\", \\\"{x:242,y:676,t:1526929884408};\\\", \\\"{x:234,y:676,t:1526929884425};\\\", \\\"{x:233,y:676,t:1526929884442};\\\", \\\"{x:230,y:675,t:1526929884487};\\\", \\\"{x:227,y:671,t:1526929884494};\\\", \\\"{x:219,y:666,t:1526929884510};\\\", \\\"{x:213,y:659,t:1526929884525};\\\", \\\"{x:207,y:647,t:1526929884542};\\\", \\\"{x:199,y:629,t:1526929884558};\\\", \\\"{x:194,y:621,t:1526929884577};\\\", \\\"{x:190,y:615,t:1526929884595};\\\", \\\"{x:188,y:611,t:1526929884612};\\\", \\\"{x:181,y:600,t:1526929884628};\\\", \\\"{x:175,y:593,t:1526929884644};\\\", \\\"{x:168,y:585,t:1526929884661};\\\", \\\"{x:167,y:583,t:1526929884678};\\\", \\\"{x:166,y:580,t:1526929884695};\\\", \\\"{x:165,y:580,t:1526929884711};\\\", \\\"{x:162,y:577,t:1526929884728};\\\", \\\"{x:160,y:576,t:1526929884745};\\\", \\\"{x:160,y:571,t:1526929884761};\\\", \\\"{x:160,y:568,t:1526929884779};\\\", \\\"{x:160,y:563,t:1526929884795};\\\", \\\"{x:160,y:559,t:1526929884811};\\\", \\\"{x:160,y:555,t:1526929884828};\\\", \\\"{x:160,y:552,t:1526929884845};\\\", \\\"{x:160,y:549,t:1526929884861};\\\", \\\"{x:162,y:543,t:1526929884878};\\\", \\\"{x:163,y:540,t:1526929884895};\\\", \\\"{x:165,y:538,t:1526929884911};\\\", \\\"{x:166,y:536,t:1526929884935};\\\", \\\"{x:167,y:534,t:1526929885030};\\\", \\\"{x:168,y:533,t:1526929885047};\\\", \\\"{x:168,y:532,t:1526929885061};\\\", \\\"{x:169,y:531,t:1526929885079};\\\", \\\"{x:170,y:530,t:1526929885143};\\\", \\\"{x:170,y:529,t:1526929885222};\\\", \\\"{x:170,y:528,t:1526929885238};\\\", \\\"{x:170,y:527,t:1526929885270};\\\", \\\"{x:170,y:526,t:1526929885278};\\\", \\\"{x:170,y:525,t:1526929885310};\\\", \\\"{x:178,y:527,t:1526929885734};\\\", \\\"{x:197,y:528,t:1526929885746};\\\", \\\"{x:281,y:543,t:1526929885762};\\\", \\\"{x:414,y:564,t:1526929885780};\\\", \\\"{x:588,y:589,t:1526929885795};\\\", \\\"{x:741,y:613,t:1526929885813};\\\", \\\"{x:932,y:649,t:1526929885829};\\\", \\\"{x:1098,y:675,t:1526929885845};\\\", \\\"{x:1303,y:712,t:1526929885862};\\\", \\\"{x:1402,y:733,t:1526929885879};\\\", \\\"{x:1452,y:747,t:1526929885895};\\\", \\\"{x:1469,y:753,t:1526929885912};\\\", \\\"{x:1476,y:757,t:1526929885929};\\\", \\\"{x:1480,y:764,t:1526929885945};\\\", \\\"{x:1484,y:773,t:1526929885962};\\\", \\\"{x:1485,y:785,t:1526929885979};\\\", \\\"{x:1488,y:793,t:1526929885995};\\\", \\\"{x:1491,y:802,t:1526929886012};\\\", \\\"{x:1496,y:811,t:1526929886029};\\\", \\\"{x:1496,y:812,t:1526929886079};\\\", \\\"{x:1497,y:812,t:1526929886167};\\\", \\\"{x:1496,y:815,t:1526929886254};\\\", \\\"{x:1491,y:821,t:1526929886262};\\\", \\\"{x:1478,y:829,t:1526929886280};\\\", \\\"{x:1462,y:837,t:1526929886295};\\\", \\\"{x:1454,y:842,t:1526929886312};\\\", \\\"{x:1439,y:852,t:1526929886329};\\\", \\\"{x:1423,y:859,t:1526929886345};\\\", \\\"{x:1388,y:868,t:1526929886362};\\\", \\\"{x:1369,y:868,t:1526929886380};\\\", \\\"{x:1354,y:871,t:1526929886395};\\\", \\\"{x:1332,y:876,t:1526929886412};\\\", \\\"{x:1317,y:880,t:1526929886429};\\\", \\\"{x:1311,y:884,t:1526929886445};\\\", \\\"{x:1307,y:893,t:1526929886462};\\\", \\\"{x:1309,y:908,t:1526929886479};\\\", \\\"{x:1318,y:919,t:1526929886496};\\\", \\\"{x:1319,y:926,t:1526929886513};\\\", \\\"{x:1319,y:940,t:1526929886529};\\\", \\\"{x:1321,y:958,t:1526929886545};\\\", \\\"{x:1324,y:973,t:1526929886562};\\\", \\\"{x:1325,y:981,t:1526929886579};\\\", \\\"{x:1325,y:987,t:1526929886595};\\\", \\\"{x:1325,y:989,t:1526929886612};\\\", \\\"{x:1325,y:990,t:1526929886629};\\\", \\\"{x:1325,y:991,t:1526929886645};\\\", \\\"{x:1324,y:992,t:1526929886662};\\\", \\\"{x:1321,y:992,t:1526929886694};\\\", \\\"{x:1319,y:992,t:1526929886702};\\\", \\\"{x:1314,y:990,t:1526929886712};\\\", \\\"{x:1303,y:986,t:1526929886730};\\\", \\\"{x:1294,y:980,t:1526929886745};\\\", \\\"{x:1283,y:976,t:1526929886762};\\\", \\\"{x:1277,y:972,t:1526929886780};\\\", \\\"{x:1277,y:970,t:1526929886854};\\\", \\\"{x:1276,y:968,t:1526929886862};\\\", \\\"{x:1272,y:967,t:1526929886879};\\\", \\\"{x:1271,y:967,t:1526929886895};\\\", \\\"{x:1269,y:967,t:1526929886925};\\\", \\\"{x:1267,y:966,t:1526929886958};\\\", \\\"{x:1267,y:965,t:1526929886991};\\\", \\\"{x:1267,y:962,t:1526929886998};\\\", \\\"{x:1267,y:957,t:1526929887014};\\\", \\\"{x:1267,y:955,t:1526929887029};\\\", \\\"{x:1263,y:946,t:1526929887045};\\\", \\\"{x:1253,y:914,t:1526929887062};\\\", \\\"{x:1245,y:894,t:1526929887079};\\\", \\\"{x:1237,y:880,t:1526929887095};\\\", \\\"{x:1229,y:868,t:1526929887112};\\\", \\\"{x:1220,y:854,t:1526929887129};\\\", \\\"{x:1201,y:827,t:1526929887145};\\\", \\\"{x:1187,y:806,t:1526929887162};\\\", \\\"{x:1171,y:786,t:1526929887179};\\\", \\\"{x:1163,y:768,t:1526929887195};\\\", \\\"{x:1157,y:757,t:1526929887212};\\\", \\\"{x:1153,y:751,t:1526929887229};\\\", \\\"{x:1153,y:750,t:1526929887246};\\\", \\\"{x:1153,y:753,t:1526929887295};\\\", \\\"{x:1153,y:755,t:1526929887302};\\\", \\\"{x:1153,y:758,t:1526929887312};\\\", \\\"{x:1154,y:764,t:1526929887328};\\\", \\\"{x:1159,y:773,t:1526929887346};\\\", \\\"{x:1169,y:786,t:1526929887362};\\\", \\\"{x:1179,y:801,t:1526929887378};\\\", \\\"{x:1195,y:815,t:1526929887396};\\\", \\\"{x:1205,y:824,t:1526929887412};\\\", \\\"{x:1213,y:840,t:1526929887429};\\\", \\\"{x:1222,y:850,t:1526929887446};\\\", \\\"{x:1228,y:861,t:1526929887462};\\\", \\\"{x:1230,y:865,t:1526929887478};\\\", \\\"{x:1234,y:867,t:1526929887496};\\\", \\\"{x:1236,y:870,t:1526929887514};\\\", \\\"{x:1239,y:876,t:1526929887529};\\\", \\\"{x:1246,y:883,t:1526929887545};\\\", \\\"{x:1248,y:888,t:1526929887562};\\\", \\\"{x:1251,y:891,t:1526929887578};\\\", \\\"{x:1252,y:892,t:1526929887678};\\\", \\\"{x:1256,y:898,t:1526929887695};\\\", \\\"{x:1256,y:901,t:1526929887712};\\\", \\\"{x:1258,y:901,t:1526929887728};\\\", \\\"{x:1260,y:901,t:1526929887745};\\\", \\\"{x:1261,y:901,t:1526929887762};\\\", \\\"{x:1262,y:901,t:1526929887779};\\\", \\\"{x:1270,y:901,t:1526929887796};\\\", \\\"{x:1281,y:901,t:1526929887812};\\\", \\\"{x:1287,y:901,t:1526929887828};\\\", \\\"{x:1303,y:899,t:1526929887845};\\\", \\\"{x:1319,y:883,t:1526929887862};\\\", \\\"{x:1329,y:864,t:1526929887878};\\\", \\\"{x:1334,y:846,t:1526929887895};\\\", \\\"{x:1342,y:831,t:1526929887912};\\\", \\\"{x:1343,y:821,t:1526929887928};\\\", \\\"{x:1346,y:808,t:1526929887945};\\\", \\\"{x:1348,y:800,t:1526929887962};\\\", \\\"{x:1348,y:796,t:1526929887978};\\\", \\\"{x:1348,y:794,t:1526929887995};\\\", \\\"{x:1348,y:792,t:1526929888012};\\\", \\\"{x:1349,y:791,t:1526929888029};\\\", \\\"{x:1349,y:789,t:1526929888046};\\\", \\\"{x:1352,y:786,t:1526929888062};\\\", \\\"{x:1353,y:785,t:1526929888079};\\\", \\\"{x:1355,y:781,t:1526929888095};\\\", \\\"{x:1356,y:779,t:1526929888112};\\\", \\\"{x:1359,y:776,t:1526929888128};\\\", \\\"{x:1361,y:774,t:1526929888145};\\\", \\\"{x:1362,y:772,t:1526929888163};\\\", \\\"{x:1362,y:771,t:1526929888179};\\\", \\\"{x:1364,y:768,t:1526929888195};\\\", \\\"{x:1368,y:764,t:1526929888212};\\\", \\\"{x:1374,y:756,t:1526929888228};\\\", \\\"{x:1383,y:748,t:1526929888245};\\\", \\\"{x:1392,y:736,t:1526929888262};\\\", \\\"{x:1399,y:727,t:1526929888278};\\\", \\\"{x:1408,y:713,t:1526929888295};\\\", \\\"{x:1413,y:705,t:1526929888312};\\\", \\\"{x:1419,y:694,t:1526929888328};\\\", \\\"{x:1423,y:684,t:1526929888346};\\\", \\\"{x:1434,y:672,t:1526929888362};\\\", \\\"{x:1444,y:662,t:1526929888378};\\\", \\\"{x:1450,y:654,t:1526929888395};\\\", \\\"{x:1456,y:646,t:1526929888412};\\\", \\\"{x:1459,y:638,t:1526929888428};\\\", \\\"{x:1463,y:634,t:1526929888446};\\\", \\\"{x:1464,y:629,t:1526929888462};\\\", \\\"{x:1467,y:622,t:1526929888478};\\\", \\\"{x:1468,y:620,t:1526929888495};\\\", \\\"{x:1472,y:614,t:1526929888512};\\\", \\\"{x:1477,y:606,t:1526929888528};\\\", \\\"{x:1480,y:603,t:1526929888546};\\\", \\\"{x:1484,y:596,t:1526929888562};\\\", \\\"{x:1491,y:586,t:1526929888578};\\\", \\\"{x:1497,y:577,t:1526929888595};\\\", \\\"{x:1503,y:567,t:1526929888612};\\\", \\\"{x:1509,y:553,t:1526929888629};\\\", \\\"{x:1514,y:534,t:1526929888645};\\\", \\\"{x:1523,y:513,t:1526929888662};\\\", \\\"{x:1531,y:495,t:1526929888678};\\\", \\\"{x:1546,y:475,t:1526929888695};\\\", \\\"{x:1562,y:459,t:1526929888712};\\\", \\\"{x:1573,y:449,t:1526929888728};\\\", \\\"{x:1584,y:439,t:1526929888745};\\\", \\\"{x:1587,y:434,t:1526929888762};\\\", \\\"{x:1592,y:430,t:1526929888778};\\\", \\\"{x:1595,y:427,t:1526929888795};\\\", \\\"{x:1595,y:426,t:1526929888862};\\\", \\\"{x:1595,y:425,t:1526929888894};\\\", \\\"{x:1595,y:424,t:1526929889135};\\\", \\\"{x:1593,y:424,t:1526929889145};\\\", \\\"{x:1586,y:427,t:1526929889162};\\\", \\\"{x:1573,y:441,t:1526929889178};\\\", \\\"{x:1561,y:471,t:1526929889195};\\\", \\\"{x:1546,y:529,t:1526929889213};\\\", \\\"{x:1520,y:582,t:1526929889228};\\\", \\\"{x:1482,y:645,t:1526929889245};\\\", \\\"{x:1461,y:691,t:1526929889262};\\\", \\\"{x:1455,y:714,t:1526929889278};\\\", \\\"{x:1447,y:733,t:1526929889295};\\\", \\\"{x:1433,y:757,t:1526929889312};\\\", \\\"{x:1414,y:806,t:1526929889329};\\\", \\\"{x:1376,y:846,t:1526929889346};\\\", \\\"{x:1365,y:857,t:1526929889363};\\\", \\\"{x:1364,y:860,t:1526929889378};\\\", \\\"{x:1359,y:862,t:1526929889396};\\\", \\\"{x:1359,y:863,t:1526929889412};\\\", \\\"{x:1359,y:870,t:1526929889429};\\\", \\\"{x:1359,y:871,t:1526929889446};\\\", \\\"{x:1359,y:873,t:1526929889462};\\\", \\\"{x:1359,y:875,t:1526929889526};\\\", \\\"{x:1359,y:876,t:1526929889534};\\\", \\\"{x:1359,y:877,t:1526929889545};\\\", \\\"{x:1359,y:878,t:1526929889562};\\\", \\\"{x:1359,y:879,t:1526929889578};\\\", \\\"{x:1359,y:880,t:1526929889614};\\\", \\\"{x:1359,y:881,t:1526929889671};\\\", \\\"{x:1359,y:882,t:1526929889678};\\\", \\\"{x:1358,y:882,t:1526929889790};\\\", \\\"{x:1358,y:883,t:1526929890103};\\\", \\\"{x:1355,y:883,t:1526929890118};\\\", \\\"{x:1351,y:883,t:1526929890129};\\\", \\\"{x:1347,y:881,t:1526929890145};\\\", \\\"{x:1325,y:862,t:1526929890162};\\\", \\\"{x:1300,y:829,t:1526929890179};\\\", \\\"{x:1285,y:806,t:1526929890195};\\\", \\\"{x:1269,y:782,t:1526929890211};\\\", \\\"{x:1259,y:758,t:1526929890228};\\\", \\\"{x:1257,y:747,t:1526929890246};\\\", \\\"{x:1257,y:745,t:1526929890471};\\\", \\\"{x:1257,y:739,t:1526929890479};\\\", \\\"{x:1244,y:730,t:1526929890496};\\\", \\\"{x:1224,y:728,t:1526929890512};\\\", \\\"{x:1175,y:723,t:1526929890529};\\\", \\\"{x:1077,y:724,t:1526929890546};\\\", \\\"{x:990,y:719,t:1526929890562};\\\", \\\"{x:832,y:720,t:1526929890578};\\\", \\\"{x:666,y:701,t:1526929890595};\\\", \\\"{x:543,y:689,t:1526929890612};\\\", \\\"{x:437,y:690,t:1526929890629};\\\", \\\"{x:366,y:702,t:1526929890646};\\\", \\\"{x:321,y:725,t:1526929890661};\\\", \\\"{x:300,y:747,t:1526929890678};\\\", \\\"{x:298,y:754,t:1526929890696};\\\", \\\"{x:298,y:755,t:1526929890711};\\\", \\\"{x:296,y:756,t:1526929890775};\\\", \\\"{x:295,y:756,t:1526929890782};\\\", \\\"{x:295,y:755,t:1526929890846};\\\", \\\"{x:297,y:755,t:1526929890861};\\\", \\\"{x:318,y:745,t:1526929890878};\\\", \\\"{x:333,y:743,t:1526929890895};\\\", \\\"{x:398,y:743,t:1526929890912};\\\", \\\"{x:480,y:749,t:1526929890928};\\\", \\\"{x:514,y:755,t:1526929890946};\\\", \\\"{x:533,y:756,t:1526929890961};\\\", \\\"{x:534,y:756,t:1526929890978};\\\", \\\"{x:535,y:756,t:1526929890996};\\\", \\\"{x:536,y:756,t:1526929891126};\\\", \\\"{x:536,y:754,t:1526929891141};\\\", \\\"{x:537,y:752,t:1526929891150};\\\", \\\"{x:537,y:751,t:1526929891183};\\\", \\\"{x:537,y:750,t:1526929891195};\\\", \\\"{x:537,y:748,t:1526929891211};\\\", \\\"{x:538,y:745,t:1526929891228};\\\", \\\"{x:538,y:743,t:1526929891245};\\\", \\\"{x:538,y:740,t:1526929891261};\\\", \\\"{x:539,y:735,t:1526929891279};\\\", \\\"{x:540,y:734,t:1526929891295};\\\", \\\"{x:540,y:732,t:1526929891311};\\\", \\\"{x:540,y:730,t:1526929891334};\\\", \\\"{x:540,y:729,t:1526929891350};\\\", \\\"{x:541,y:726,t:1526929891367};\\\", \\\"{x:543,y:723,t:1526929891384};\\\", \\\"{x:544,y:720,t:1526929891400};\\\", \\\"{x:544,y:719,t:1526929891926};\\\" ] }, { \\\"rt\\\": 28831, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 245305, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -K -A -12 PM-01 PM-U -D -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:718,t:1526929893013};\\\", \\\"{x:549,y:716,t:1526929893022};\\\", \\\"{x:551,y:715,t:1526929893039};\\\", \\\"{x:553,y:714,t:1526929893052};\\\", \\\"{x:556,y:714,t:1526929893068};\\\", \\\"{x:559,y:713,t:1526929893084};\\\", \\\"{x:561,y:712,t:1526929893107};\\\", \\\"{x:562,y:711,t:1526929893118};\\\", \\\"{x:564,y:710,t:1526929893142};\\\", \\\"{x:565,y:709,t:1526929893159};\\\", \\\"{x:565,y:708,t:1526929893183};\\\", \\\"{x:567,y:706,t:1526929893190};\\\", \\\"{x:571,y:705,t:1526929893201};\\\", \\\"{x:572,y:703,t:1526929893218};\\\", \\\"{x:582,y:700,t:1526929893234};\\\", \\\"{x:593,y:698,t:1526929893251};\\\", \\\"{x:651,y:688,t:1526929893371};\\\", \\\"{x:658,y:687,t:1526929893386};\\\", \\\"{x:667,y:687,t:1526929893401};\\\", \\\"{x:671,y:686,t:1526929893418};\\\", \\\"{x:675,y:684,t:1526929893435};\\\", \\\"{x:677,y:684,t:1526929893451};\\\", \\\"{x:678,y:684,t:1526929893468};\\\", \\\"{x:680,y:683,t:1526929893485};\\\", \\\"{x:685,y:682,t:1526929893501};\\\", \\\"{x:698,y:679,t:1526929893518};\\\", \\\"{x:707,y:676,t:1526929893535};\\\", \\\"{x:712,y:673,t:1526929893552};\\\", \\\"{x:714,y:673,t:1526929893569};\\\", \\\"{x:719,y:668,t:1526929893585};\\\", \\\"{x:725,y:667,t:1526929893602};\\\", \\\"{x:734,y:664,t:1526929893618};\\\", \\\"{x:739,y:662,t:1526929893635};\\\", \\\"{x:743,y:660,t:1526929893651};\\\", \\\"{x:747,y:657,t:1526929893669};\\\", \\\"{x:754,y:654,t:1526929893686};\\\", \\\"{x:759,y:652,t:1526929893702};\\\", \\\"{x:770,y:648,t:1526929893719};\\\", \\\"{x:779,y:645,t:1526929893736};\\\", \\\"{x:783,y:643,t:1526929893751};\\\", \\\"{x:785,y:641,t:1526929893768};\\\", \\\"{x:791,y:638,t:1526929893785};\\\", \\\"{x:795,y:636,t:1526929893802};\\\", \\\"{x:800,y:633,t:1526929893819};\\\", \\\"{x:804,y:631,t:1526929893836};\\\", \\\"{x:806,y:630,t:1526929893852};\\\", \\\"{x:803,y:629,t:1526929893886};\\\", \\\"{x:799,y:630,t:1526929893902};\\\", \\\"{x:798,y:630,t:1526929893919};\\\", \\\"{x:797,y:630,t:1526929893935};\\\", \\\"{x:796,y:631,t:1526929893953};\\\", \\\"{x:793,y:631,t:1526929893969};\\\", \\\"{x:792,y:632,t:1526929893986};\\\", \\\"{x:791,y:633,t:1526929894002};\\\", \\\"{x:789,y:634,t:1526929894018};\\\", \\\"{x:786,y:634,t:1526929894054};\\\", \\\"{x:785,y:634,t:1526929894086};\\\", \\\"{x:784,y:634,t:1526929894102};\\\", \\\"{x:784,y:635,t:1526929897342};\\\", \\\"{x:805,y:644,t:1526929897354};\\\", \\\"{x:955,y:675,t:1526929897372};\\\", \\\"{x:1116,y:701,t:1526929897388};\\\", \\\"{x:1191,y:710,t:1526929897404};\\\", \\\"{x:1269,y:723,t:1526929897421};\\\", \\\"{x:1366,y:728,t:1526929897438};\\\", \\\"{x:1414,y:729,t:1526929897454};\\\", \\\"{x:1466,y:722,t:1526929897472};\\\", \\\"{x:1505,y:721,t:1526929897489};\\\", \\\"{x:1532,y:721,t:1526929897504};\\\", \\\"{x:1545,y:719,t:1526929897522};\\\", \\\"{x:1546,y:719,t:1526929897539};\\\", \\\"{x:1549,y:719,t:1526929897555};\\\", \\\"{x:1549,y:718,t:1526929897992};\\\", \\\"{x:1549,y:717,t:1526929898766};\\\", \\\"{x:1549,y:716,t:1526929898782};\\\", \\\"{x:1548,y:716,t:1526929899646};\\\", \\\"{x:1547,y:716,t:1526929899663};\\\", \\\"{x:1546,y:716,t:1526929899686};\\\", \\\"{x:1545,y:716,t:1526929899702};\\\", \\\"{x:1543,y:716,t:1526929899790};\\\", \\\"{x:1542,y:716,t:1526929899838};\\\", \\\"{x:1541,y:716,t:1526929899854};\\\", \\\"{x:1539,y:716,t:1526929899894};\\\", \\\"{x:1538,y:716,t:1526929900049};\\\", \\\"{x:1538,y:715,t:1526929900063};\\\", \\\"{x:1538,y:713,t:1526929900095};\\\", \\\"{x:1537,y:712,t:1526929900238};\\\", \\\"{x:1536,y:712,t:1526929900502};\\\", \\\"{x:1536,y:711,t:1526929900510};\\\", \\\"{x:1536,y:710,t:1526929900524};\\\", \\\"{x:1536,y:709,t:1526929900541};\\\", \\\"{x:1536,y:708,t:1526929900557};\\\", \\\"{x:1536,y:706,t:1526929900573};\\\", \\\"{x:1536,y:704,t:1526929900590};\\\", \\\"{x:1537,y:703,t:1526929900607};\\\", \\\"{x:1538,y:701,t:1526929900670};\\\", \\\"{x:1538,y:700,t:1526929900966};\\\", \\\"{x:1538,y:699,t:1526929901062};\\\", \\\"{x:1537,y:698,t:1526929901479};\\\", \\\"{x:1531,y:698,t:1526929901492};\\\", \\\"{x:1528,y:698,t:1526929901509};\\\", \\\"{x:1527,y:696,t:1526929901526};\\\", \\\"{x:1528,y:691,t:1526929901543};\\\", \\\"{x:1536,y:667,t:1526929901559};\\\", \\\"{x:1546,y:648,t:1526929901575};\\\", \\\"{x:1561,y:627,t:1526929901592};\\\", \\\"{x:1576,y:604,t:1526929901608};\\\", \\\"{x:1589,y:580,t:1526929901625};\\\", \\\"{x:1597,y:562,t:1526929901642};\\\", \\\"{x:1608,y:544,t:1526929901658};\\\", \\\"{x:1617,y:533,t:1526929901676};\\\", \\\"{x:1624,y:523,t:1526929901692};\\\", \\\"{x:1627,y:517,t:1526929901710};\\\", \\\"{x:1628,y:510,t:1526929901726};\\\", \\\"{x:1630,y:496,t:1526929901743};\\\", \\\"{x:1630,y:494,t:1526929901759};\\\", \\\"{x:1631,y:491,t:1526929901775};\\\", \\\"{x:1631,y:490,t:1526929901792};\\\", \\\"{x:1631,y:489,t:1526929901809};\\\", \\\"{x:1632,y:487,t:1526929901826};\\\", \\\"{x:1633,y:481,t:1526929901842};\\\", \\\"{x:1634,y:478,t:1526929901860};\\\", \\\"{x:1634,y:472,t:1526929901875};\\\", \\\"{x:1634,y:464,t:1526929901892};\\\", \\\"{x:1630,y:457,t:1526929901909};\\\", \\\"{x:1629,y:450,t:1526929901925};\\\", \\\"{x:1629,y:439,t:1526929901942};\\\", \\\"{x:1630,y:432,t:1526929901959};\\\", \\\"{x:1630,y:426,t:1526929901975};\\\", \\\"{x:1630,y:421,t:1526929901991};\\\", \\\"{x:1628,y:416,t:1526929902009};\\\", \\\"{x:1626,y:414,t:1526929902078};\\\", \\\"{x:1625,y:414,t:1526929902206};\\\", \\\"{x:1623,y:414,t:1526929902214};\\\", \\\"{x:1622,y:414,t:1526929902230};\\\", \\\"{x:1619,y:415,t:1526929902246};\\\", \\\"{x:1617,y:417,t:1526929902259};\\\", \\\"{x:1615,y:419,t:1526929902277};\\\", \\\"{x:1610,y:424,t:1526929902292};\\\", \\\"{x:1607,y:429,t:1526929902309};\\\", \\\"{x:1604,y:433,t:1526929902326};\\\", \\\"{x:1601,y:439,t:1526929902341};\\\", \\\"{x:1597,y:453,t:1526929902359};\\\", \\\"{x:1592,y:462,t:1526929902376};\\\", \\\"{x:1591,y:467,t:1526929902392};\\\", \\\"{x:1589,y:473,t:1526929902409};\\\", \\\"{x:1586,y:477,t:1526929902426};\\\", \\\"{x:1586,y:478,t:1526929902575};\\\", \\\"{x:1584,y:480,t:1526929902594};\\\", \\\"{x:1582,y:484,t:1526929902609};\\\", \\\"{x:1578,y:493,t:1526929902626};\\\", \\\"{x:1574,y:508,t:1526929902644};\\\", \\\"{x:1566,y:529,t:1526929902660};\\\", \\\"{x:1558,y:549,t:1526929902680};\\\", \\\"{x:1556,y:553,t:1526929902693};\\\", \\\"{x:1555,y:557,t:1526929902709};\\\", \\\"{x:1553,y:560,t:1526929902725};\\\", \\\"{x:1551,y:561,t:1526929902952};\\\", \\\"{x:1550,y:563,t:1526929902960};\\\", \\\"{x:1549,y:564,t:1526929902976};\\\", \\\"{x:1549,y:566,t:1526929902994};\\\", \\\"{x:1547,y:570,t:1526929903011};\\\", \\\"{x:1543,y:573,t:1526929903026};\\\", \\\"{x:1541,y:578,t:1526929903044};\\\", \\\"{x:1538,y:582,t:1526929903060};\\\", \\\"{x:1534,y:588,t:1526929903077};\\\", \\\"{x:1532,y:592,t:1526929903094};\\\", \\\"{x:1525,y:603,t:1526929903110};\\\", \\\"{x:1521,y:615,t:1526929903127};\\\", \\\"{x:1518,y:622,t:1526929903143};\\\", \\\"{x:1516,y:626,t:1526929903163};\\\", \\\"{x:1514,y:627,t:1526929903177};\\\", \\\"{x:1514,y:628,t:1526929903193};\\\", \\\"{x:1514,y:629,t:1526929903222};\\\", \\\"{x:1513,y:630,t:1526929903254};\\\", \\\"{x:1513,y:632,t:1526929903374};\\\", \\\"{x:1512,y:633,t:1526929903382};\\\", \\\"{x:1509,y:635,t:1526929903393};\\\", \\\"{x:1507,y:637,t:1526929903409};\\\", \\\"{x:1506,y:639,t:1526929903427};\\\", \\\"{x:1501,y:643,t:1526929903443};\\\", \\\"{x:1496,y:653,t:1526929903460};\\\", \\\"{x:1490,y:671,t:1526929903477};\\\", \\\"{x:1484,y:678,t:1526929903492};\\\", \\\"{x:1480,y:684,t:1526929903510};\\\", \\\"{x:1479,y:685,t:1526929903527};\\\", \\\"{x:1479,y:686,t:1526929903599};\\\", \\\"{x:1479,y:688,t:1526929903630};\\\", \\\"{x:1478,y:689,t:1526929903646};\\\", \\\"{x:1477,y:690,t:1526929903678};\\\", \\\"{x:1477,y:691,t:1526929903695};\\\", \\\"{x:1476,y:692,t:1526929903710};\\\", \\\"{x:1474,y:696,t:1526929903727};\\\", \\\"{x:1473,y:700,t:1526929903743};\\\", \\\"{x:1472,y:702,t:1526929903760};\\\", \\\"{x:1470,y:703,t:1526929903839};\\\", \\\"{x:1470,y:705,t:1526929903847};\\\", \\\"{x:1470,y:706,t:1526929903860};\\\", \\\"{x:1470,y:710,t:1526929903877};\\\", \\\"{x:1470,y:714,t:1526929903895};\\\", \\\"{x:1470,y:716,t:1526929903911};\\\", \\\"{x:1469,y:719,t:1526929903927};\\\", \\\"{x:1469,y:721,t:1526929903945};\\\", \\\"{x:1468,y:723,t:1526929903960};\\\", \\\"{x:1467,y:723,t:1526929903978};\\\", \\\"{x:1466,y:725,t:1526929903995};\\\", \\\"{x:1466,y:726,t:1526929904015};\\\", \\\"{x:1466,y:727,t:1526929904027};\\\", \\\"{x:1466,y:730,t:1526929904045};\\\", \\\"{x:1465,y:733,t:1526929904060};\\\", \\\"{x:1462,y:736,t:1526929904078};\\\", \\\"{x:1461,y:739,t:1526929904094};\\\", \\\"{x:1460,y:741,t:1526929904111};\\\", \\\"{x:1459,y:742,t:1526929904127};\\\", \\\"{x:1459,y:744,t:1526929904144};\\\", \\\"{x:1458,y:746,t:1526929904161};\\\", \\\"{x:1456,y:749,t:1526929904207};\\\", \\\"{x:1456,y:751,t:1526929904215};\\\", \\\"{x:1454,y:754,t:1526929904227};\\\", \\\"{x:1454,y:756,t:1526929904245};\\\", \\\"{x:1453,y:758,t:1526929904262};\\\", \\\"{x:1452,y:761,t:1526929904278};\\\", \\\"{x:1451,y:762,t:1526929904295};\\\", \\\"{x:1451,y:764,t:1526929904310};\\\", \\\"{x:1450,y:766,t:1526929904343};\\\", \\\"{x:1449,y:766,t:1526929904375};\\\", \\\"{x:1449,y:767,t:1526929904383};\\\", \\\"{x:1448,y:767,t:1526929904415};\\\", \\\"{x:1448,y:768,t:1526929904427};\\\", \\\"{x:1446,y:769,t:1526929904445};\\\", \\\"{x:1446,y:770,t:1526929904462};\\\", \\\"{x:1445,y:773,t:1526929904527};\\\", \\\"{x:1445,y:774,t:1526929904544};\\\", \\\"{x:1445,y:775,t:1526929904567};\\\", \\\"{x:1445,y:776,t:1526929904591};\\\", \\\"{x:1445,y:777,t:1526929904607};\\\", \\\"{x:1444,y:778,t:1526929904623};\\\", \\\"{x:1444,y:779,t:1526929904638};\\\", \\\"{x:1444,y:780,t:1526929904663};\\\", \\\"{x:1443,y:781,t:1526929904695};\\\", \\\"{x:1442,y:782,t:1526929904735};\\\", \\\"{x:1442,y:783,t:1526929904759};\\\", \\\"{x:1441,y:784,t:1526929904934};\\\", \\\"{x:1441,y:785,t:1526929904950};\\\", \\\"{x:1441,y:786,t:1526929904998};\\\", \\\"{x:1440,y:786,t:1526929905011};\\\", \\\"{x:1440,y:788,t:1526929905038};\\\", \\\"{x:1440,y:789,t:1526929905094};\\\", \\\"{x:1439,y:789,t:1526929905152};\\\", \\\"{x:1438,y:790,t:1526929905208};\\\", \\\"{x:1438,y:791,t:1526929905280};\\\", \\\"{x:1438,y:792,t:1526929905319};\\\", \\\"{x:1437,y:792,t:1526929905329};\\\", \\\"{x:1436,y:793,t:1526929905351};\\\", \\\"{x:1435,y:794,t:1526929905375};\\\", \\\"{x:1435,y:795,t:1526929905464};\\\", \\\"{x:1434,y:796,t:1526929905487};\\\", \\\"{x:1434,y:797,t:1526929905543};\\\", \\\"{x:1434,y:798,t:1526929905559};\\\", \\\"{x:1433,y:798,t:1526929905591};\\\", \\\"{x:1433,y:799,t:1526929905647};\\\", \\\"{x:1432,y:801,t:1526929905751};\\\", \\\"{x:1431,y:802,t:1526929905863};\\\", \\\"{x:1431,y:803,t:1526929905919};\\\", \\\"{x:1431,y:804,t:1526929906095};\\\", \\\"{x:1430,y:805,t:1526929906760};\\\", \\\"{x:1430,y:806,t:1526929906775};\\\", \\\"{x:1429,y:807,t:1526929906863};\\\", \\\"{x:1428,y:807,t:1526929906880};\\\", \\\"{x:1426,y:808,t:1526929907855};\\\", \\\"{x:1425,y:809,t:1526929907864};\\\", \\\"{x:1424,y:810,t:1526929907880};\\\", \\\"{x:1423,y:814,t:1526929907898};\\\", \\\"{x:1422,y:815,t:1526929907914};\\\", \\\"{x:1421,y:816,t:1526929907931};\\\", \\\"{x:1421,y:817,t:1526929907947};\\\", \\\"{x:1420,y:818,t:1526929907964};\\\", \\\"{x:1419,y:820,t:1526929907981};\\\", \\\"{x:1418,y:822,t:1526929907998};\\\", \\\"{x:1416,y:824,t:1526929908015};\\\", \\\"{x:1415,y:826,t:1526929908031};\\\", \\\"{x:1415,y:827,t:1526929908048};\\\", \\\"{x:1414,y:829,t:1526929908064};\\\", \\\"{x:1413,y:829,t:1526929908081};\\\", \\\"{x:1412,y:831,t:1526929908097};\\\", \\\"{x:1412,y:833,t:1526929908114};\\\", \\\"{x:1411,y:838,t:1526929908131};\\\", \\\"{x:1409,y:841,t:1526929908147};\\\", \\\"{x:1408,y:842,t:1526929908164};\\\", \\\"{x:1407,y:843,t:1526929908181};\\\", \\\"{x:1406,y:844,t:1526929908198};\\\", \\\"{x:1404,y:846,t:1526929908215};\\\", \\\"{x:1404,y:848,t:1526929908231};\\\", \\\"{x:1404,y:849,t:1526929908247};\\\", \\\"{x:1404,y:850,t:1526929908264};\\\", \\\"{x:1402,y:853,t:1526929908281};\\\", \\\"{x:1402,y:855,t:1526929908311};\\\", \\\"{x:1401,y:855,t:1526929908319};\\\", \\\"{x:1401,y:856,t:1526929908331};\\\", \\\"{x:1399,y:859,t:1526929908348};\\\", \\\"{x:1398,y:860,t:1526929908375};\\\", \\\"{x:1398,y:861,t:1526929908398};\\\", \\\"{x:1396,y:863,t:1526929908414};\\\", \\\"{x:1394,y:866,t:1526929908431};\\\", \\\"{x:1393,y:867,t:1526929908447};\\\", \\\"{x:1391,y:870,t:1526929908465};\\\", \\\"{x:1389,y:872,t:1526929908481};\\\", \\\"{x:1388,y:874,t:1526929908498};\\\", \\\"{x:1387,y:875,t:1526929908515};\\\", \\\"{x:1386,y:877,t:1526929908531};\\\", \\\"{x:1385,y:879,t:1526929908548};\\\", \\\"{x:1384,y:883,t:1526929908565};\\\", \\\"{x:1383,y:884,t:1526929908582};\\\", \\\"{x:1382,y:885,t:1526929908599};\\\", \\\"{x:1382,y:886,t:1526929908615};\\\", \\\"{x:1381,y:887,t:1526929908630};\\\", \\\"{x:1381,y:888,t:1526929908648};\\\", \\\"{x:1380,y:889,t:1526929908665};\\\", \\\"{x:1379,y:891,t:1526929908682};\\\", \\\"{x:1378,y:893,t:1526929908698};\\\", \\\"{x:1376,y:897,t:1526929908715};\\\", \\\"{x:1375,y:899,t:1526929908732};\\\", \\\"{x:1373,y:904,t:1526929908747};\\\", \\\"{x:1371,y:908,t:1526929908765};\\\", \\\"{x:1370,y:913,t:1526929908782};\\\", \\\"{x:1368,y:916,t:1526929908798};\\\", \\\"{x:1367,y:921,t:1526929908815};\\\", \\\"{x:1366,y:926,t:1526929908832};\\\", \\\"{x:1365,y:929,t:1526929908847};\\\", \\\"{x:1363,y:933,t:1526929908864};\\\", \\\"{x:1359,y:941,t:1526929908882};\\\", \\\"{x:1358,y:944,t:1526929908898};\\\", \\\"{x:1357,y:946,t:1526929908914};\\\", \\\"{x:1356,y:948,t:1526929908931};\\\", \\\"{x:1353,y:949,t:1526929908948};\\\", \\\"{x:1351,y:952,t:1526929908965};\\\", \\\"{x:1349,y:954,t:1526929908981};\\\", \\\"{x:1349,y:956,t:1526929908998};\\\", \\\"{x:1348,y:957,t:1526929909014};\\\", \\\"{x:1346,y:958,t:1526929909032};\\\", \\\"{x:1346,y:959,t:1526929909279};\\\", \\\"{x:1345,y:959,t:1526929909520};\\\", \\\"{x:1342,y:956,t:1526929911855};\\\", \\\"{x:1335,y:948,t:1526929911867};\\\", \\\"{x:1319,y:929,t:1526929911883};\\\", \\\"{x:1304,y:915,t:1526929911901};\\\", \\\"{x:1290,y:894,t:1526929911917};\\\", \\\"{x:1280,y:874,t:1526929911934};\\\", \\\"{x:1275,y:855,t:1526929911951};\\\", \\\"{x:1275,y:851,t:1526929911967};\\\", \\\"{x:1275,y:846,t:1526929911984};\\\", \\\"{x:1274,y:840,t:1526929912001};\\\", \\\"{x:1273,y:835,t:1526929912018};\\\", \\\"{x:1272,y:832,t:1526929912033};\\\", \\\"{x:1269,y:823,t:1526929912051};\\\", \\\"{x:1265,y:818,t:1526929912067};\\\", \\\"{x:1262,y:811,t:1526929912084};\\\", \\\"{x:1261,y:810,t:1526929912101};\\\", \\\"{x:1261,y:809,t:1526929912168};\\\", \\\"{x:1260,y:809,t:1526929912184};\\\", \\\"{x:1259,y:809,t:1526929912271};\\\", \\\"{x:1259,y:810,t:1526929912295};\\\", \\\"{x:1259,y:811,t:1526929912367};\\\", \\\"{x:1259,y:812,t:1526929912407};\\\", \\\"{x:1254,y:812,t:1526929912766};\\\", \\\"{x:1242,y:809,t:1526929912774};\\\", \\\"{x:1225,y:799,t:1526929912784};\\\", \\\"{x:1189,y:783,t:1526929912800};\\\", \\\"{x:1098,y:752,t:1526929912817};\\\", \\\"{x:956,y:702,t:1526929912834};\\\", \\\"{x:832,y:668,t:1526929912850};\\\", \\\"{x:735,y:638,t:1526929912867};\\\", \\\"{x:702,y:625,t:1526929912885};\\\", \\\"{x:682,y:619,t:1526929912902};\\\", \\\"{x:666,y:613,t:1526929912917};\\\", \\\"{x:651,y:604,t:1526929912934};\\\", \\\"{x:632,y:595,t:1526929912950};\\\", \\\"{x:617,y:586,t:1526929912967};\\\", \\\"{x:600,y:572,t:1526929912985};\\\", \\\"{x:589,y:566,t:1526929913001};\\\", \\\"{x:571,y:557,t:1526929913017};\\\", \\\"{x:549,y:547,t:1526929913034};\\\", \\\"{x:519,y:539,t:1526929913051};\\\", \\\"{x:498,y:529,t:1526929913067};\\\", \\\"{x:483,y:522,t:1526929913084};\\\", \\\"{x:475,y:517,t:1526929913101};\\\", \\\"{x:468,y:516,t:1526929913117};\\\", \\\"{x:467,y:516,t:1526929913134};\\\", \\\"{x:460,y:518,t:1526929913152};\\\", \\\"{x:458,y:518,t:1526929913167};\\\", \\\"{x:456,y:519,t:1526929913184};\\\", \\\"{x:453,y:522,t:1526929913201};\\\", \\\"{x:445,y:526,t:1526929913218};\\\", \\\"{x:439,y:531,t:1526929913235};\\\", \\\"{x:430,y:536,t:1526929913251};\\\", \\\"{x:421,y:541,t:1526929913269};\\\", \\\"{x:416,y:545,t:1526929913286};\\\", \\\"{x:406,y:552,t:1526929913301};\\\", \\\"{x:389,y:561,t:1526929913318};\\\", \\\"{x:383,y:565,t:1526929913334};\\\", \\\"{x:378,y:569,t:1526929913352};\\\", \\\"{x:377,y:571,t:1526929913383};\\\", \\\"{x:377,y:572,t:1526929913401};\\\", \\\"{x:376,y:574,t:1526929913418};\\\", \\\"{x:374,y:576,t:1526929913435};\\\", \\\"{x:372,y:578,t:1526929913471};\\\", \\\"{x:369,y:580,t:1526929913485};\\\", \\\"{x:368,y:583,t:1526929913504};\\\", \\\"{x:367,y:584,t:1526929913518};\\\", \\\"{x:366,y:584,t:1526929913581};\\\", \\\"{x:366,y:585,t:1526929913589};\\\", \\\"{x:366,y:586,t:1526929913601};\\\", \\\"{x:367,y:590,t:1526929913618};\\\", \\\"{x:370,y:594,t:1526929913634};\\\", \\\"{x:371,y:594,t:1526929913651};\\\", \\\"{x:373,y:594,t:1526929913727};\\\", \\\"{x:374,y:594,t:1526929913735};\\\", \\\"{x:377,y:594,t:1526929913752};\\\", \\\"{x:371,y:595,t:1526929914238};\\\", \\\"{x:362,y:595,t:1526929914252};\\\", \\\"{x:346,y:595,t:1526929914268};\\\", \\\"{x:345,y:594,t:1526929914285};\\\", \\\"{x:343,y:594,t:1526929914302};\\\", \\\"{x:342,y:594,t:1526929914335};\\\", \\\"{x:339,y:594,t:1526929914342};\\\", \\\"{x:333,y:594,t:1526929914353};\\\", \\\"{x:329,y:596,t:1526929914368};\\\", \\\"{x:334,y:596,t:1526929914486};\\\", \\\"{x:363,y:596,t:1526929914502};\\\", \\\"{x:448,y:602,t:1526929914519};\\\", \\\"{x:529,y:617,t:1526929914536};\\\", \\\"{x:569,y:628,t:1526929914554};\\\", \\\"{x:592,y:629,t:1526929914569};\\\", \\\"{x:616,y:624,t:1526929914585};\\\", \\\"{x:624,y:621,t:1526929914602};\\\", \\\"{x:634,y:615,t:1526929914620};\\\", \\\"{x:640,y:610,t:1526929914635};\\\", \\\"{x:648,y:608,t:1526929914652};\\\", \\\"{x:654,y:604,t:1526929914669};\\\", \\\"{x:659,y:600,t:1526929914685};\\\", \\\"{x:665,y:594,t:1526929914702};\\\", \\\"{x:670,y:592,t:1526929914719};\\\", \\\"{x:675,y:588,t:1526929914736};\\\", \\\"{x:676,y:586,t:1526929914752};\\\", \\\"{x:678,y:585,t:1526929914769};\\\", \\\"{x:679,y:584,t:1526929914786};\\\", \\\"{x:679,y:583,t:1526929914802};\\\", \\\"{x:679,y:580,t:1526929914821};\\\", \\\"{x:675,y:577,t:1526929914837};\\\", \\\"{x:645,y:563,t:1526929914852};\\\", \\\"{x:565,y:543,t:1526929914869};\\\", \\\"{x:437,y:515,t:1526929914886};\\\", \\\"{x:279,y:489,t:1526929914902};\\\", \\\"{x:247,y:480,t:1526929914920};\\\", \\\"{x:220,y:475,t:1526929914936};\\\", \\\"{x:211,y:474,t:1526929914952};\\\", \\\"{x:210,y:473,t:1526929915030};\\\", \\\"{x:210,y:471,t:1526929915046};\\\", \\\"{x:213,y:471,t:1526929915062};\\\", \\\"{x:219,y:474,t:1526929915070};\\\", \\\"{x:239,y:493,t:1526929915086};\\\", \\\"{x:262,y:505,t:1526929915102};\\\", \\\"{x:340,y:539,t:1526929915119};\\\", \\\"{x:428,y:574,t:1526929915137};\\\", \\\"{x:499,y:603,t:1526929915153};\\\", \\\"{x:505,y:607,t:1526929915169};\\\", \\\"{x:502,y:607,t:1526929915295};\\\", \\\"{x:496,y:606,t:1526929915304};\\\", \\\"{x:490,y:602,t:1526929915317};\\\", \\\"{x:479,y:595,t:1526929915336};\\\", \\\"{x:460,y:580,t:1526929915353};\\\", \\\"{x:453,y:574,t:1526929915370};\\\", \\\"{x:447,y:572,t:1526929915387};\\\", \\\"{x:446,y:570,t:1526929915402};\\\", \\\"{x:445,y:568,t:1526929915419};\\\", \\\"{x:444,y:563,t:1526929915436};\\\", \\\"{x:437,y:557,t:1526929915453};\\\", \\\"{x:436,y:557,t:1526929915502};\\\", \\\"{x:434,y:556,t:1526929915510};\\\", \\\"{x:431,y:553,t:1526929915520};\\\", \\\"{x:429,y:552,t:1526929915537};\\\", \\\"{x:420,y:548,t:1526929915553};\\\", \\\"{x:416,y:543,t:1526929915571};\\\", \\\"{x:410,y:539,t:1526929915587};\\\", \\\"{x:407,y:536,t:1526929915604};\\\", \\\"{x:406,y:536,t:1526929915619};\\\", \\\"{x:405,y:536,t:1526929915637};\\\", \\\"{x:403,y:535,t:1526929915654};\\\", \\\"{x:401,y:533,t:1526929915669};\\\", \\\"{x:401,y:531,t:1526929915717};\\\", \\\"{x:399,y:530,t:1526929915726};\\\", \\\"{x:398,y:529,t:1526929915742};\\\", \\\"{x:396,y:528,t:1526929915774};\\\", \\\"{x:395,y:528,t:1526929915827};\\\", \\\"{x:401,y:529,t:1526929916187};\\\", \\\"{x:403,y:530,t:1526929916195};\\\", \\\"{x:436,y:540,t:1526929916208};\\\", \\\"{x:568,y:572,t:1526929916225};\\\", \\\"{x:722,y:616,t:1526929916243};\\\", \\\"{x:868,y:649,t:1526929916258};\\\", \\\"{x:998,y:687,t:1526929916275};\\\", \\\"{x:1048,y:701,t:1526929916291};\\\", \\\"{x:1112,y:719,t:1526929916308};\\\", \\\"{x:1171,y:727,t:1526929916325};\\\", \\\"{x:1198,y:737,t:1526929916342};\\\", \\\"{x:1212,y:744,t:1526929916358};\\\", \\\"{x:1233,y:753,t:1526929916375};\\\", \\\"{x:1247,y:765,t:1526929916392};\\\", \\\"{x:1255,y:775,t:1526929916408};\\\", \\\"{x:1259,y:779,t:1526929916425};\\\", \\\"{x:1264,y:788,t:1526929916442};\\\", \\\"{x:1268,y:794,t:1526929916458};\\\", \\\"{x:1273,y:800,t:1526929916474};\\\", \\\"{x:1273,y:803,t:1526929916492};\\\", \\\"{x:1274,y:807,t:1526929916508};\\\", \\\"{x:1274,y:810,t:1526929916525};\\\", \\\"{x:1274,y:812,t:1526929916542};\\\", \\\"{x:1274,y:816,t:1526929916559};\\\", \\\"{x:1284,y:827,t:1526929916575};\\\", \\\"{x:1297,y:844,t:1526929916592};\\\", \\\"{x:1309,y:854,t:1526929916608};\\\", \\\"{x:1323,y:870,t:1526929916624};\\\", \\\"{x:1336,y:882,t:1526929916642};\\\", \\\"{x:1356,y:903,t:1526929916659};\\\", \\\"{x:1357,y:904,t:1526929916675};\\\", \\\"{x:1358,y:904,t:1526929916947};\\\", \\\"{x:1359,y:904,t:1526929916971};\\\", \\\"{x:1361,y:904,t:1526929916979};\\\", \\\"{x:1362,y:904,t:1526929916995};\\\", \\\"{x:1363,y:904,t:1526929917116};\\\", \\\"{x:1364,y:906,t:1526929917131};\\\", \\\"{x:1366,y:907,t:1526929917147};\\\", \\\"{x:1368,y:907,t:1526929917159};\\\", \\\"{x:1376,y:910,t:1526929917175};\\\", \\\"{x:1382,y:912,t:1526929917192};\\\", \\\"{x:1389,y:913,t:1526929917209};\\\", \\\"{x:1389,y:914,t:1526929917226};\\\", \\\"{x:1389,y:915,t:1526929917267};\\\", \\\"{x:1388,y:915,t:1526929917275};\\\", \\\"{x:1380,y:918,t:1526929917292};\\\", \\\"{x:1371,y:920,t:1526929917309};\\\", \\\"{x:1367,y:921,t:1526929917325};\\\", \\\"{x:1364,y:923,t:1526929917342};\\\", \\\"{x:1361,y:925,t:1526929917359};\\\", \\\"{x:1359,y:925,t:1526929917376};\\\", \\\"{x:1357,y:928,t:1526929917392};\\\", \\\"{x:1356,y:930,t:1526929917410};\\\", \\\"{x:1354,y:933,t:1526929917425};\\\", \\\"{x:1348,y:936,t:1526929917442};\\\", \\\"{x:1340,y:941,t:1526929917459};\\\", \\\"{x:1336,y:943,t:1526929917475};\\\", \\\"{x:1334,y:944,t:1526929917493};\\\", \\\"{x:1331,y:946,t:1526929917509};\\\", \\\"{x:1329,y:948,t:1526929917525};\\\", \\\"{x:1328,y:948,t:1526929917563};\\\", \\\"{x:1328,y:950,t:1526929917580};\\\", \\\"{x:1328,y:952,t:1526929917603};\\\", \\\"{x:1326,y:954,t:1526929917611};\\\", \\\"{x:1326,y:956,t:1526929917626};\\\", \\\"{x:1326,y:957,t:1526929917643};\\\", \\\"{x:1326,y:958,t:1526929917659};\\\", \\\"{x:1326,y:961,t:1526929917676};\\\", \\\"{x:1334,y:965,t:1526929917692};\\\", \\\"{x:1351,y:971,t:1526929917710};\\\", \\\"{x:1366,y:976,t:1526929917726};\\\", \\\"{x:1384,y:983,t:1526929917743};\\\", \\\"{x:1389,y:985,t:1526929917759};\\\", \\\"{x:1390,y:985,t:1526929917776};\\\", \\\"{x:1391,y:982,t:1526929917843};\\\", \\\"{x:1396,y:977,t:1526929917860};\\\", \\\"{x:1399,y:974,t:1526929917876};\\\", \\\"{x:1401,y:972,t:1526929917892};\\\", \\\"{x:1402,y:971,t:1526929917909};\\\", \\\"{x:1405,y:965,t:1526929917926};\\\", \\\"{x:1407,y:958,t:1526929917942};\\\", \\\"{x:1411,y:948,t:1526929917959};\\\", \\\"{x:1417,y:935,t:1526929917976};\\\", \\\"{x:1425,y:921,t:1526929917992};\\\", \\\"{x:1430,y:909,t:1526929918009};\\\", \\\"{x:1439,y:896,t:1526929918026};\\\", \\\"{x:1451,y:876,t:1526929918043};\\\", \\\"{x:1461,y:865,t:1526929918058};\\\", \\\"{x:1468,y:847,t:1526929918076};\\\", \\\"{x:1474,y:829,t:1526929918092};\\\", \\\"{x:1479,y:812,t:1526929918109};\\\", \\\"{x:1484,y:799,t:1526929918127};\\\", \\\"{x:1489,y:784,t:1526929918142};\\\", \\\"{x:1491,y:770,t:1526929918159};\\\", \\\"{x:1491,y:758,t:1526929918177};\\\", \\\"{x:1491,y:750,t:1526929918192};\\\", \\\"{x:1491,y:744,t:1526929918209};\\\", \\\"{x:1494,y:730,t:1526929918226};\\\", \\\"{x:1494,y:708,t:1526929918242};\\\", \\\"{x:1495,y:673,t:1526929918260};\\\", \\\"{x:1495,y:650,t:1526929918276};\\\", \\\"{x:1500,y:623,t:1526929918292};\\\", \\\"{x:1501,y:602,t:1526929918310};\\\", \\\"{x:1504,y:587,t:1526929918327};\\\", \\\"{x:1504,y:566,t:1526929918342};\\\", \\\"{x:1508,y:547,t:1526929918359};\\\", \\\"{x:1512,y:526,t:1526929918377};\\\", \\\"{x:1519,y:506,t:1526929918394};\\\", \\\"{x:1519,y:490,t:1526929918410};\\\", \\\"{x:1529,y:472,t:1526929918427};\\\", \\\"{x:1545,y:448,t:1526929918443};\\\", \\\"{x:1550,y:437,t:1526929918459};\\\", \\\"{x:1556,y:427,t:1526929918476};\\\", \\\"{x:1567,y:422,t:1526929918493};\\\", \\\"{x:1572,y:418,t:1526929918509};\\\", \\\"{x:1575,y:416,t:1526929918526};\\\", \\\"{x:1576,y:415,t:1526929918543};\\\", \\\"{x:1579,y:415,t:1526929918571};\\\", \\\"{x:1581,y:415,t:1526929918587};\\\", \\\"{x:1582,y:415,t:1526929918595};\\\", \\\"{x:1583,y:415,t:1526929918609};\\\", \\\"{x:1585,y:415,t:1526929918626};\\\", \\\"{x:1597,y:414,t:1526929918643};\\\", \\\"{x:1617,y:414,t:1526929918660};\\\", \\\"{x:1637,y:414,t:1526929918677};\\\", \\\"{x:1657,y:413,t:1526929918693};\\\", \\\"{x:1664,y:412,t:1526929918709};\\\", \\\"{x:1666,y:412,t:1526929918727};\\\", \\\"{x:1669,y:411,t:1526929918743};\\\", \\\"{x:1669,y:410,t:1526929918760};\\\", \\\"{x:1667,y:414,t:1526929918828};\\\", \\\"{x:1659,y:429,t:1526929918843};\\\", \\\"{x:1646,y:449,t:1526929918860};\\\", \\\"{x:1633,y:478,t:1526929918877};\\\", \\\"{x:1615,y:517,t:1526929918893};\\\", \\\"{x:1602,y:549,t:1526929918909};\\\", \\\"{x:1594,y:574,t:1526929918925};\\\", \\\"{x:1588,y:585,t:1526929918943};\\\", \\\"{x:1579,y:603,t:1526929918959};\\\", \\\"{x:1569,y:622,t:1526929918976};\\\", \\\"{x:1559,y:640,t:1526929918993};\\\", \\\"{x:1550,y:658,t:1526929919009};\\\", \\\"{x:1544,y:672,t:1526929919025};\\\", \\\"{x:1527,y:706,t:1526929919043};\\\", \\\"{x:1513,y:728,t:1526929919059};\\\", \\\"{x:1503,y:744,t:1526929919076};\\\", \\\"{x:1488,y:758,t:1526929919093};\\\", \\\"{x:1474,y:774,t:1526929919110};\\\", \\\"{x:1463,y:790,t:1526929919126};\\\", \\\"{x:1445,y:807,t:1526929919144};\\\", \\\"{x:1435,y:818,t:1526929919161};\\\", \\\"{x:1421,y:828,t:1526929919176};\\\", \\\"{x:1416,y:836,t:1526929919193};\\\", \\\"{x:1413,y:839,t:1526929919211};\\\", \\\"{x:1412,y:841,t:1526929919226};\\\", \\\"{x:1409,y:846,t:1526929919243};\\\", \\\"{x:1404,y:856,t:1526929919260};\\\", \\\"{x:1398,y:866,t:1526929919276};\\\", \\\"{x:1392,y:877,t:1526929919294};\\\", \\\"{x:1385,y:887,t:1526929919310};\\\", \\\"{x:1381,y:893,t:1526929919326};\\\", \\\"{x:1377,y:897,t:1526929919343};\\\", \\\"{x:1372,y:903,t:1526929919360};\\\", \\\"{x:1369,y:908,t:1526929919377};\\\", \\\"{x:1366,y:914,t:1526929919393};\\\", \\\"{x:1362,y:921,t:1526929919411};\\\", \\\"{x:1356,y:929,t:1526929919427};\\\", \\\"{x:1354,y:932,t:1526929919442};\\\", \\\"{x:1351,y:936,t:1526929919460};\\\", \\\"{x:1348,y:940,t:1526929919476};\\\", \\\"{x:1348,y:946,t:1526929919494};\\\", \\\"{x:1348,y:949,t:1526929919510};\\\", \\\"{x:1348,y:951,t:1526929919527};\\\", \\\"{x:1348,y:953,t:1526929919543};\\\", \\\"{x:1348,y:954,t:1526929919579};\\\", \\\"{x:1348,y:955,t:1526929919595};\\\", \\\"{x:1348,y:956,t:1526929919611};\\\", \\\"{x:1347,y:958,t:1526929919659};\\\", \\\"{x:1347,y:960,t:1526929919676};\\\", \\\"{x:1344,y:963,t:1526929919694};\\\", \\\"{x:1344,y:964,t:1526929919755};\\\", \\\"{x:1344,y:967,t:1526929919763};\\\", \\\"{x:1341,y:972,t:1526929919777};\\\", \\\"{x:1338,y:976,t:1526929919794};\\\", \\\"{x:1338,y:978,t:1526929919811};\\\", \\\"{x:1338,y:979,t:1526929919827};\\\", \\\"{x:1338,y:980,t:1526929919843};\\\", \\\"{x:1339,y:980,t:1526929919987};\\\", \\\"{x:1340,y:980,t:1526929920003};\\\", \\\"{x:1340,y:979,t:1526929920019};\\\", \\\"{x:1340,y:976,t:1526929920026};\\\", \\\"{x:1343,y:968,t:1526929920044};\\\", \\\"{x:1345,y:963,t:1526929920061};\\\", \\\"{x:1345,y:959,t:1526929920078};\\\", \\\"{x:1345,y:953,t:1526929920093};\\\", \\\"{x:1345,y:949,t:1526929920111};\\\", \\\"{x:1345,y:945,t:1526929920127};\\\", \\\"{x:1340,y:937,t:1526929920143};\\\", \\\"{x:1332,y:928,t:1526929920161};\\\", \\\"{x:1329,y:923,t:1526929920177};\\\", \\\"{x:1328,y:918,t:1526929920194};\\\", \\\"{x:1328,y:917,t:1526929920211};\\\", \\\"{x:1327,y:914,t:1526929920228};\\\", \\\"{x:1324,y:908,t:1526929920243};\\\", \\\"{x:1319,y:901,t:1526929920261};\\\", \\\"{x:1315,y:893,t:1526929920277};\\\", \\\"{x:1312,y:890,t:1526929920293};\\\", \\\"{x:1298,y:882,t:1526929920311};\\\", \\\"{x:1280,y:868,t:1526929920327};\\\", \\\"{x:1268,y:857,t:1526929920344};\\\", \\\"{x:1255,y:845,t:1526929920360};\\\", \\\"{x:1249,y:838,t:1526929920377};\\\", \\\"{x:1246,y:832,t:1526929920393};\\\", \\\"{x:1245,y:830,t:1526929920410};\\\", \\\"{x:1245,y:829,t:1526929920427};\\\", \\\"{x:1243,y:826,t:1526929920444};\\\", \\\"{x:1241,y:819,t:1526929920460};\\\", \\\"{x:1239,y:818,t:1526929920477};\\\", \\\"{x:1238,y:816,t:1526929920493};\\\", \\\"{x:1236,y:813,t:1526929920511};\\\", \\\"{x:1234,y:810,t:1526929920528};\\\", \\\"{x:1230,y:806,t:1526929920544};\\\", \\\"{x:1221,y:799,t:1526929920560};\\\", \\\"{x:1210,y:793,t:1526929920577};\\\", \\\"{x:1193,y:783,t:1526929920595};\\\", \\\"{x:1186,y:775,t:1526929920610};\\\", \\\"{x:1154,y:759,t:1526929920627};\\\", \\\"{x:1114,y:746,t:1526929920644};\\\", \\\"{x:1048,y:728,t:1526929920661};\\\", \\\"{x:1018,y:713,t:1526929920677};\\\", \\\"{x:958,y:691,t:1526929920695};\\\", \\\"{x:904,y:681,t:1526929920710};\\\", \\\"{x:873,y:675,t:1526929920727};\\\", \\\"{x:857,y:672,t:1526929920744};\\\", \\\"{x:853,y:670,t:1526929920760};\\\", \\\"{x:851,y:669,t:1526929920777};\\\", \\\"{x:847,y:669,t:1526929920915};\\\", \\\"{x:844,y:673,t:1526929920930};\\\", \\\"{x:840,y:677,t:1526929920945};\\\", \\\"{x:832,y:681,t:1526929920960};\\\", \\\"{x:817,y:681,t:1526929920977};\\\", \\\"{x:807,y:685,t:1526929920994};\\\", \\\"{x:792,y:689,t:1526929921010};\\\", \\\"{x:755,y:689,t:1526929921027};\\\", \\\"{x:740,y:689,t:1526929921044};\\\", \\\"{x:740,y:691,t:1526929921147};\\\", \\\"{x:740,y:692,t:1526929921170};\\\", \\\"{x:739,y:692,t:1526929921181};\\\", \\\"{x:729,y:687,t:1526929921194};\\\", \\\"{x:727,y:687,t:1526929921211};\\\", \\\"{x:723,y:687,t:1526929921227};\\\", \\\"{x:709,y:685,t:1526929921244};\\\", \\\"{x:681,y:684,t:1526929921261};\\\", \\\"{x:650,y:681,t:1526929921278};\\\", \\\"{x:634,y:681,t:1526929921294};\\\", \\\"{x:611,y:679,t:1526929921311};\\\", \\\"{x:593,y:678,t:1526929921327};\\\", \\\"{x:584,y:678,t:1526929921344};\\\", \\\"{x:583,y:678,t:1526929921395};\\\", \\\"{x:577,y:678,t:1526929921410};\\\", \\\"{x:567,y:678,t:1526929921427};\\\", \\\"{x:545,y:678,t:1526929921445};\\\", \\\"{x:538,y:680,t:1526929921461};\\\", \\\"{x:532,y:684,t:1526929921477};\\\", \\\"{x:527,y:688,t:1526929921494};\\\", \\\"{x:518,y:691,t:1526929921511};\\\", \\\"{x:505,y:698,t:1526929921527};\\\", \\\"{x:503,y:699,t:1526929921545};\\\", \\\"{x:503,y:700,t:1526929921563};\\\", \\\"{x:503,y:701,t:1526929921661};\\\", \\\"{x:503,y:702,t:1526929921722};\\\", \\\"{x:503,y:703,t:1526929921922};\\\", \\\"{x:504,y:704,t:1526929921938};\\\", \\\"{x:505,y:704,t:1526929922243};\\\", \\\"{x:508,y:705,t:1526929922266};\\\", \\\"{x:511,y:705,t:1526929922280};\\\", \\\"{x:512,y:705,t:1526929922296};\\\", \\\"{x:519,y:705,t:1526929922313};\\\", \\\"{x:533,y:709,t:1526929922331};\\\", \\\"{x:533,y:708,t:1526929922371};\\\", \\\"{x:533,y:707,t:1526929922380};\\\", \\\"{x:533,y:706,t:1526929922397};\\\", \\\"{x:533,y:704,t:1526929922413};\\\", \\\"{x:533,y:700,t:1526929922430};\\\", \\\"{x:534,y:700,t:1526929922474};\\\", \\\"{x:534,y:702,t:1526929922515};\\\", \\\"{x:532,y:704,t:1526929922530};\\\", \\\"{x:529,y:705,t:1526929922546};\\\", \\\"{x:528,y:706,t:1526929922563};\\\" ] }, { \\\"rt\\\": 27742, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 274251, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"U\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-11 AM-12 PM-01 PM-E -02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:705,t:1526929923054};\\\", \\\"{x:532,y:704,t:1526929923080};\\\", \\\"{x:532,y:703,t:1526929923371};\\\", \\\"{x:533,y:701,t:1526929923380};\\\", \\\"{x:544,y:694,t:1526929923398};\\\", \\\"{x:571,y:681,t:1526929923414};\\\", \\\"{x:589,y:672,t:1526929923430};\\\", \\\"{x:593,y:670,t:1526929923447};\\\", \\\"{x:601,y:662,t:1526929923540};\\\", \\\"{x:602,y:662,t:1526929923578};\\\", \\\"{x:602,y:661,t:1526929923891};\\\", \\\"{x:603,y:661,t:1526929923898};\\\", \\\"{x:604,y:660,t:1526929923921};\\\", \\\"{x:606,y:659,t:1526929923931};\\\", \\\"{x:607,y:658,t:1526929923948};\\\", \\\"{x:610,y:650,t:1526929923966};\\\", \\\"{x:631,y:643,t:1526929923982};\\\", \\\"{x:641,y:633,t:1526929923998};\\\", \\\"{x:644,y:633,t:1526929924014};\\\", \\\"{x:645,y:631,t:1526929924031};\\\", \\\"{x:651,y:628,t:1526929924050};\\\", \\\"{x:656,y:624,t:1526929924064};\\\", \\\"{x:670,y:618,t:1526929924081};\\\", \\\"{x:697,y:611,t:1526929924099};\\\", \\\"{x:701,y:610,t:1526929924114};\\\", \\\"{x:700,y:610,t:1526929924154};\\\", \\\"{x:691,y:610,t:1526929924164};\\\", \\\"{x:679,y:609,t:1526929924181};\\\", \\\"{x:667,y:609,t:1526929924198};\\\", \\\"{x:655,y:609,t:1526929924214};\\\", \\\"{x:644,y:609,t:1526929924231};\\\", \\\"{x:633,y:609,t:1526929924248};\\\", \\\"{x:627,y:609,t:1526929924264};\\\", \\\"{x:626,y:609,t:1526929924281};\\\", \\\"{x:626,y:608,t:1526929924395};\\\", \\\"{x:626,y:607,t:1526929924403};\\\", \\\"{x:628,y:603,t:1526929924415};\\\", \\\"{x:639,y:597,t:1526929924431};\\\", \\\"{x:647,y:592,t:1526929924448};\\\", \\\"{x:652,y:592,t:1526929924464};\\\", \\\"{x:658,y:588,t:1526929924480};\\\", \\\"{x:675,y:579,t:1526929924498};\\\", \\\"{x:691,y:572,t:1526929924515};\\\", \\\"{x:708,y:567,t:1526929924531};\\\", \\\"{x:716,y:565,t:1526929924548};\\\", \\\"{x:718,y:563,t:1526929924565};\\\", \\\"{x:719,y:563,t:1526929924581};\\\", \\\"{x:721,y:562,t:1526929924602};\\\", \\\"{x:723,y:562,t:1526929924614};\\\", \\\"{x:733,y:558,t:1526929924632};\\\", \\\"{x:747,y:554,t:1526929924648};\\\", \\\"{x:754,y:552,t:1526929924665};\\\", \\\"{x:759,y:548,t:1526929924681};\\\", \\\"{x:774,y:544,t:1526929924698};\\\", \\\"{x:783,y:537,t:1526929924715};\\\", \\\"{x:809,y:529,t:1526929924732};\\\", \\\"{x:865,y:521,t:1526929924748};\\\", \\\"{x:972,y:509,t:1526929924765};\\\", \\\"{x:1109,y:500,t:1526929924781};\\\", \\\"{x:1248,y:494,t:1526929924798};\\\", \\\"{x:1295,y:499,t:1526929924815};\\\", \\\"{x:1382,y:483,t:1526929924831};\\\", \\\"{x:1446,y:475,t:1526929924848};\\\", \\\"{x:1483,y:467,t:1526929924865};\\\", \\\"{x:1499,y:464,t:1526929924882};\\\", \\\"{x:1502,y:463,t:1526929924898};\\\", \\\"{x:1503,y:463,t:1526929924915};\\\", \\\"{x:1505,y:463,t:1526929924932};\\\", \\\"{x:1508,y:462,t:1526929924948};\\\", \\\"{x:1512,y:462,t:1526929924965};\\\", \\\"{x:1516,y:462,t:1526929924982};\\\", \\\"{x:1518,y:462,t:1526929924998};\\\", \\\"{x:1520,y:462,t:1526929925016};\\\", \\\"{x:1522,y:462,t:1526929925059};\\\", \\\"{x:1522,y:464,t:1526929925067};\\\", \\\"{x:1525,y:471,t:1526929925083};\\\", \\\"{x:1525,y:472,t:1526929925099};\\\", \\\"{x:1524,y:475,t:1526929925116};\\\", \\\"{x:1524,y:476,t:1526929925133};\\\", \\\"{x:1524,y:479,t:1526929925149};\\\", \\\"{x:1524,y:482,t:1526929925165};\\\", \\\"{x:1524,y:488,t:1526929925183};\\\", \\\"{x:1522,y:494,t:1526929925199};\\\", \\\"{x:1521,y:501,t:1526929925215};\\\", \\\"{x:1517,y:507,t:1526929925232};\\\", \\\"{x:1516,y:516,t:1526929925248};\\\", \\\"{x:1510,y:525,t:1526929925266};\\\", \\\"{x:1503,y:539,t:1526929925283};\\\", \\\"{x:1497,y:550,t:1526929925299};\\\", \\\"{x:1493,y:559,t:1526929925316};\\\", \\\"{x:1488,y:568,t:1526929925332};\\\", \\\"{x:1483,y:577,t:1526929925349};\\\", \\\"{x:1481,y:584,t:1526929925365};\\\", \\\"{x:1478,y:590,t:1526929925382};\\\", \\\"{x:1476,y:595,t:1526929925400};\\\", \\\"{x:1471,y:602,t:1526929925415};\\\", \\\"{x:1466,y:611,t:1526929925433};\\\", \\\"{x:1463,y:613,t:1526929925449};\\\", \\\"{x:1459,y:620,t:1526929925466};\\\", \\\"{x:1452,y:638,t:1526929925483};\\\", \\\"{x:1449,y:646,t:1526929925499};\\\", \\\"{x:1447,y:652,t:1526929925516};\\\", \\\"{x:1446,y:658,t:1526929925533};\\\", \\\"{x:1445,y:662,t:1526929925550};\\\", \\\"{x:1445,y:666,t:1526929925566};\\\", \\\"{x:1445,y:672,t:1526929925582};\\\", \\\"{x:1443,y:680,t:1526929925600};\\\", \\\"{x:1441,y:695,t:1526929925615};\\\", \\\"{x:1439,y:715,t:1526929925632};\\\", \\\"{x:1436,y:724,t:1526929925650};\\\", \\\"{x:1433,y:732,t:1526929925666};\\\", \\\"{x:1431,y:737,t:1526929925683};\\\", \\\"{x:1430,y:739,t:1526929925699};\\\", \\\"{x:1426,y:743,t:1526929925716};\\\", \\\"{x:1423,y:749,t:1526929925733};\\\", \\\"{x:1417,y:754,t:1526929925750};\\\", \\\"{x:1413,y:760,t:1526929925765};\\\", \\\"{x:1406,y:763,t:1526929925783};\\\", \\\"{x:1395,y:769,t:1526929925800};\\\", \\\"{x:1387,y:778,t:1526929925816};\\\", \\\"{x:1373,y:780,t:1526929925833};\\\", \\\"{x:1366,y:784,t:1526929925850};\\\", \\\"{x:1363,y:788,t:1526929925866};\\\", \\\"{x:1360,y:793,t:1526929925883};\\\", \\\"{x:1357,y:794,t:1526929925898};\\\", \\\"{x:1351,y:799,t:1526929925916};\\\", \\\"{x:1345,y:802,t:1526929925932};\\\", \\\"{x:1342,y:807,t:1526929925949};\\\", \\\"{x:1336,y:813,t:1526929925965};\\\", \\\"{x:1331,y:816,t:1526929925982};\\\", \\\"{x:1331,y:818,t:1526929925998};\\\", \\\"{x:1331,y:819,t:1526929926016};\\\", \\\"{x:1323,y:823,t:1526929926033};\\\", \\\"{x:1301,y:823,t:1526929926049};\\\", \\\"{x:1274,y:825,t:1526929926066};\\\", \\\"{x:1267,y:826,t:1526929926083};\\\", \\\"{x:1267,y:827,t:1526929926099};\\\", \\\"{x:1266,y:827,t:1526929927163};\\\", \\\"{x:1261,y:827,t:1526929927171};\\\", \\\"{x:1253,y:827,t:1526929927183};\\\", \\\"{x:1228,y:830,t:1526929927201};\\\", \\\"{x:1185,y:832,t:1526929927218};\\\", \\\"{x:1153,y:832,t:1526929927234};\\\", \\\"{x:1136,y:833,t:1526929927251};\\\", \\\"{x:1135,y:833,t:1526929927379};\\\", \\\"{x:1135,y:834,t:1526929927459};\\\", \\\"{x:1135,y:835,t:1526929927467};\\\", \\\"{x:1135,y:839,t:1526929927483};\\\", \\\"{x:1142,y:844,t:1526929927501};\\\", \\\"{x:1181,y:851,t:1526929927518};\\\", \\\"{x:1248,y:861,t:1526929927535};\\\", \\\"{x:1285,y:868,t:1526929927551};\\\", \\\"{x:1289,y:869,t:1526929927567};\\\", \\\"{x:1291,y:870,t:1526929927585};\\\", \\\"{x:1290,y:870,t:1526929927755};\\\", \\\"{x:1287,y:870,t:1526929927767};\\\", \\\"{x:1276,y:868,t:1526929927785};\\\", \\\"{x:1254,y:857,t:1526929927801};\\\", \\\"{x:1207,y:842,t:1526929927818};\\\", \\\"{x:1165,y:827,t:1526929927835};\\\", \\\"{x:1155,y:820,t:1526929927850};\\\", \\\"{x:1153,y:819,t:1526929927868};\\\", \\\"{x:1152,y:818,t:1526929927885};\\\", \\\"{x:1152,y:817,t:1526929928002};\\\", \\\"{x:1151,y:817,t:1526929928034};\\\", \\\"{x:1151,y:821,t:1526929928051};\\\", \\\"{x:1164,y:833,t:1526929928068};\\\", \\\"{x:1176,y:837,t:1526929928084};\\\", \\\"{x:1191,y:846,t:1526929928102};\\\", \\\"{x:1198,y:853,t:1526929928117};\\\", \\\"{x:1205,y:864,t:1526929928135};\\\", \\\"{x:1208,y:869,t:1526929928152};\\\", \\\"{x:1209,y:872,t:1526929928168};\\\", \\\"{x:1211,y:876,t:1526929928184};\\\", \\\"{x:1213,y:882,t:1526929928201};\\\", \\\"{x:1215,y:889,t:1526929928218};\\\", \\\"{x:1217,y:893,t:1526929928234};\\\", \\\"{x:1218,y:900,t:1526929928251};\\\", \\\"{x:1218,y:902,t:1526929928268};\\\", \\\"{x:1220,y:905,t:1526929928285};\\\", \\\"{x:1220,y:906,t:1526929928302};\\\", \\\"{x:1221,y:908,t:1526929928319};\\\", \\\"{x:1224,y:915,t:1526929928334};\\\", \\\"{x:1227,y:924,t:1526929928351};\\\", \\\"{x:1234,y:938,t:1526929928369};\\\", \\\"{x:1240,y:951,t:1526929928384};\\\", \\\"{x:1245,y:960,t:1526929928402};\\\", \\\"{x:1249,y:965,t:1526929928419};\\\", \\\"{x:1249,y:966,t:1526929928435};\\\", \\\"{x:1252,y:967,t:1526929928452};\\\", \\\"{x:1256,y:973,t:1526929928469};\\\", \\\"{x:1259,y:977,t:1526929928485};\\\", \\\"{x:1263,y:980,t:1526929928502};\\\", \\\"{x:1271,y:983,t:1526929928518};\\\", \\\"{x:1274,y:984,t:1526929928535};\\\", \\\"{x:1275,y:985,t:1526929928552};\\\", \\\"{x:1279,y:985,t:1526929928569};\\\", \\\"{x:1283,y:985,t:1526929928585};\\\", \\\"{x:1286,y:983,t:1526929928602};\\\", \\\"{x:1292,y:979,t:1526929928619};\\\", \\\"{x:1293,y:978,t:1526929928634};\\\", \\\"{x:1297,y:974,t:1526929928652};\\\", \\\"{x:1302,y:971,t:1526929928669};\\\", \\\"{x:1302,y:970,t:1526929928707};\\\", \\\"{x:1303,y:969,t:1526929928795};\\\", \\\"{x:1303,y:968,t:1526929928811};\\\", \\\"{x:1303,y:967,t:1526929928884};\\\", \\\"{x:1302,y:967,t:1526929928914};\\\", \\\"{x:1301,y:967,t:1526929928931};\\\", \\\"{x:1298,y:967,t:1526929928939};\\\", \\\"{x:1296,y:967,t:1526929928952};\\\", \\\"{x:1290,y:969,t:1526929928969};\\\", \\\"{x:1290,y:970,t:1526929928986};\\\", \\\"{x:1289,y:970,t:1526929929002};\\\", \\\"{x:1287,y:970,t:1526929929395};\\\", \\\"{x:1285,y:970,t:1526929929451};\\\", \\\"{x:1285,y:969,t:1526929929555};\\\", \\\"{x:1285,y:967,t:1526929929636};\\\", \\\"{x:1284,y:966,t:1526929929836};\\\", \\\"{x:1284,y:964,t:1526929929853};\\\", \\\"{x:1284,y:963,t:1526929929891};\\\", \\\"{x:1284,y:962,t:1526929929903};\\\", \\\"{x:1284,y:961,t:1526929929954};\\\", \\\"{x:1283,y:961,t:1526929929970};\\\", \\\"{x:1282,y:960,t:1526929930010};\\\", \\\"{x:1281,y:959,t:1526929930020};\\\", \\\"{x:1279,y:953,t:1526929930036};\\\", \\\"{x:1273,y:943,t:1526929930053};\\\", \\\"{x:1267,y:933,t:1526929930070};\\\", \\\"{x:1258,y:919,t:1526929930086};\\\", \\\"{x:1254,y:903,t:1526929930102};\\\", \\\"{x:1251,y:899,t:1526929930119};\\\", \\\"{x:1245,y:883,t:1526929930136};\\\", \\\"{x:1238,y:863,t:1526929930152};\\\", \\\"{x:1230,y:850,t:1526929930169};\\\", \\\"{x:1226,y:841,t:1526929930186};\\\", \\\"{x:1225,y:839,t:1526929930202};\\\", \\\"{x:1223,y:838,t:1526929930220};\\\", \\\"{x:1221,y:838,t:1526929930236};\\\", \\\"{x:1218,y:838,t:1526929930252};\\\", \\\"{x:1217,y:837,t:1526929930269};\\\", \\\"{x:1215,y:837,t:1526929932842};\\\", \\\"{x:1213,y:839,t:1526929932855};\\\", \\\"{x:1212,y:852,t:1526929932872};\\\", \\\"{x:1212,y:855,t:1526929932888};\\\", \\\"{x:1212,y:860,t:1526929932904};\\\", \\\"{x:1212,y:867,t:1526929932921};\\\", \\\"{x:1211,y:869,t:1526929932938};\\\", \\\"{x:1210,y:871,t:1526929932954};\\\", \\\"{x:1210,y:880,t:1526929932972};\\\", \\\"{x:1212,y:888,t:1526929932988};\\\", \\\"{x:1218,y:895,t:1526929933004};\\\", \\\"{x:1224,y:903,t:1526929933021};\\\", \\\"{x:1231,y:913,t:1526929933038};\\\", \\\"{x:1242,y:923,t:1526929933054};\\\", \\\"{x:1248,y:929,t:1526929933071};\\\", \\\"{x:1249,y:932,t:1526929933088};\\\", \\\"{x:1251,y:938,t:1526929933104};\\\", \\\"{x:1261,y:944,t:1526929933121};\\\", \\\"{x:1273,y:949,t:1526929933138};\\\", \\\"{x:1280,y:954,t:1526929933156};\\\", \\\"{x:1289,y:959,t:1526929933172};\\\", \\\"{x:1291,y:961,t:1526929933188};\\\", \\\"{x:1292,y:962,t:1526929933205};\\\", \\\"{x:1293,y:963,t:1526929933251};\\\", \\\"{x:1300,y:964,t:1526929933259};\\\", \\\"{x:1306,y:964,t:1526929933272};\\\", \\\"{x:1322,y:969,t:1526929933289};\\\", \\\"{x:1335,y:972,t:1526929933306};\\\", \\\"{x:1354,y:975,t:1526929933322};\\\", \\\"{x:1359,y:975,t:1526929933338};\\\", \\\"{x:1362,y:975,t:1526929933356};\\\", \\\"{x:1363,y:976,t:1526929933381};\\\", \\\"{x:1364,y:976,t:1526929933417};\\\", \\\"{x:1365,y:976,t:1526929933426};\\\", \\\"{x:1366,y:976,t:1526929933506};\\\", \\\"{x:1366,y:977,t:1526929933834};\\\", \\\"{x:1366,y:978,t:1526929933850};\\\", \\\"{x:1366,y:979,t:1526929933874};\\\", \\\"{x:1365,y:979,t:1526929933890};\\\", \\\"{x:1362,y:979,t:1526929933906};\\\", \\\"{x:1361,y:979,t:1526929933923};\\\", \\\"{x:1360,y:979,t:1526929933939};\\\", \\\"{x:1359,y:979,t:1526929933956};\\\", \\\"{x:1357,y:981,t:1526929933972};\\\", \\\"{x:1352,y:981,t:1526929933989};\\\", \\\"{x:1349,y:981,t:1526929934005};\\\", \\\"{x:1348,y:981,t:1526929934023};\\\", \\\"{x:1347,y:981,t:1526929934250};\\\", \\\"{x:1347,y:980,t:1526929934331};\\\", \\\"{x:1347,y:978,t:1526929934363};\\\", \\\"{x:1349,y:978,t:1526929934394};\\\", \\\"{x:1354,y:978,t:1526929934406};\\\", \\\"{x:1367,y:978,t:1526929934422};\\\", \\\"{x:1371,y:978,t:1526929934440};\\\", \\\"{x:1379,y:978,t:1526929934457};\\\", \\\"{x:1384,y:978,t:1526929934473};\\\", \\\"{x:1386,y:978,t:1526929934490};\\\", \\\"{x:1388,y:978,t:1526929934555};\\\", \\\"{x:1391,y:978,t:1526929934578};\\\", \\\"{x:1392,y:978,t:1526929934589};\\\", \\\"{x:1396,y:978,t:1526929934607};\\\", \\\"{x:1398,y:977,t:1526929934623};\\\", \\\"{x:1399,y:977,t:1526929934640};\\\", \\\"{x:1400,y:975,t:1526929934657};\\\", \\\"{x:1400,y:974,t:1526929934682};\\\", \\\"{x:1401,y:973,t:1526929934690};\\\", \\\"{x:1404,y:969,t:1526929934707};\\\", \\\"{x:1411,y:964,t:1526929934723};\\\", \\\"{x:1414,y:963,t:1526929934740};\\\", \\\"{x:1419,y:961,t:1526929934757};\\\", \\\"{x:1420,y:959,t:1526929934779};\\\", \\\"{x:1421,y:958,t:1526929934819};\\\", \\\"{x:1422,y:957,t:1526929934851};\\\", \\\"{x:1422,y:956,t:1526929934858};\\\", \\\"{x:1422,y:957,t:1526929935195};\\\", \\\"{x:1423,y:958,t:1526929935206};\\\", \\\"{x:1423,y:960,t:1526929935223};\\\", \\\"{x:1423,y:961,t:1526929935241};\\\", \\\"{x:1423,y:962,t:1526929935256};\\\", \\\"{x:1423,y:963,t:1526929935275};\\\", \\\"{x:1423,y:965,t:1526929935483};\\\", \\\"{x:1422,y:965,t:1526929935491};\\\", \\\"{x:1420,y:966,t:1526929935506};\\\", \\\"{x:1419,y:966,t:1526929936435};\\\", \\\"{x:1417,y:966,t:1526929936627};\\\", \\\"{x:1414,y:964,t:1526929936643};\\\", \\\"{x:1411,y:961,t:1526929936658};\\\", \\\"{x:1403,y:956,t:1526929936675};\\\", \\\"{x:1401,y:954,t:1526929936692};\\\", \\\"{x:1397,y:953,t:1526929936708};\\\", \\\"{x:1396,y:951,t:1526929936725};\\\", \\\"{x:1395,y:950,t:1526929936742};\\\", \\\"{x:1393,y:950,t:1526929936758};\\\", \\\"{x:1393,y:949,t:1526929936778};\\\", \\\"{x:1392,y:948,t:1526929936859};\\\", \\\"{x:1387,y:945,t:1526929936874};\\\", \\\"{x:1384,y:944,t:1526929936892};\\\", \\\"{x:1382,y:942,t:1526929936908};\\\", \\\"{x:1378,y:933,t:1526929936925};\\\", \\\"{x:1376,y:926,t:1526929936942};\\\", \\\"{x:1375,y:917,t:1526929936959};\\\", \\\"{x:1371,y:907,t:1526929936975};\\\", \\\"{x:1370,y:901,t:1526929936992};\\\", \\\"{x:1369,y:897,t:1526929937008};\\\", \\\"{x:1368,y:890,t:1526929937024};\\\", \\\"{x:1367,y:888,t:1526929937041};\\\", \\\"{x:1367,y:886,t:1526929937058};\\\", \\\"{x:1367,y:885,t:1526929937089};\\\", \\\"{x:1366,y:884,t:1526929937097};\\\", \\\"{x:1366,y:883,t:1526929937109};\\\", \\\"{x:1366,y:880,t:1526929937125};\\\", \\\"{x:1366,y:878,t:1526929937142};\\\", \\\"{x:1365,y:874,t:1526929937158};\\\", \\\"{x:1363,y:871,t:1526929937174};\\\", \\\"{x:1360,y:865,t:1526929937192};\\\", \\\"{x:1359,y:862,t:1526929937208};\\\", \\\"{x:1358,y:857,t:1526929937225};\\\", \\\"{x:1356,y:851,t:1526929937242};\\\", \\\"{x:1355,y:849,t:1526929937258};\\\", \\\"{x:1354,y:849,t:1526929937378};\\\", \\\"{x:1354,y:851,t:1526929937391};\\\", \\\"{x:1354,y:858,t:1526929937408};\\\", \\\"{x:1354,y:868,t:1526929937424};\\\", \\\"{x:1361,y:883,t:1526929937443};\\\", \\\"{x:1371,y:896,t:1526929937459};\\\", \\\"{x:1377,y:904,t:1526929937476};\\\", \\\"{x:1383,y:914,t:1526929937492};\\\", \\\"{x:1387,y:919,t:1526929937509};\\\", \\\"{x:1391,y:927,t:1526929937526};\\\", \\\"{x:1395,y:935,t:1526929937542};\\\", \\\"{x:1400,y:940,t:1526929937559};\\\", \\\"{x:1402,y:944,t:1526929937576};\\\", \\\"{x:1404,y:948,t:1526929937592};\\\", \\\"{x:1406,y:949,t:1526929937609};\\\", \\\"{x:1406,y:952,t:1526929937626};\\\", \\\"{x:1407,y:953,t:1526929937642};\\\", \\\"{x:1407,y:956,t:1526929937667};\\\", \\\"{x:1407,y:957,t:1526929937682};\\\", \\\"{x:1407,y:958,t:1526929937691};\\\", \\\"{x:1409,y:959,t:1526929937709};\\\", \\\"{x:1410,y:961,t:1526929937898};\\\", \\\"{x:1410,y:962,t:1526929938002};\\\", \\\"{x:1411,y:963,t:1526929938137};\\\", \\\"{x:1412,y:963,t:1526929938242};\\\", \\\"{x:1413,y:963,t:1526929938259};\\\", \\\"{x:1414,y:963,t:1526929938298};\\\", \\\"{x:1415,y:963,t:1526929938314};\\\", \\\"{x:1416,y:963,t:1526929938330};\\\", \\\"{x:1417,y:962,t:1526929938343};\\\", \\\"{x:1420,y:961,t:1526929938360};\\\", \\\"{x:1424,y:959,t:1526929938376};\\\", \\\"{x:1428,y:957,t:1526929938393};\\\", \\\"{x:1430,y:954,t:1526929938410};\\\", \\\"{x:1435,y:949,t:1526929938426};\\\", \\\"{x:1441,y:943,t:1526929938442};\\\", \\\"{x:1444,y:939,t:1526929938459};\\\", \\\"{x:1450,y:932,t:1526929938476};\\\", \\\"{x:1454,y:927,t:1526929938492};\\\", \\\"{x:1460,y:916,t:1526929938510};\\\", \\\"{x:1466,y:907,t:1526929938526};\\\", \\\"{x:1471,y:897,t:1526929938543};\\\", \\\"{x:1474,y:892,t:1526929938560};\\\", \\\"{x:1477,y:887,t:1526929938576};\\\", \\\"{x:1478,y:884,t:1526929938593};\\\", \\\"{x:1478,y:880,t:1526929938610};\\\", \\\"{x:1478,y:879,t:1526929938626};\\\", \\\"{x:1478,y:877,t:1526929938643};\\\", \\\"{x:1478,y:876,t:1526929938683};\\\", \\\"{x:1478,y:874,t:1526929938699};\\\", \\\"{x:1479,y:873,t:1526929938723};\\\", \\\"{x:1479,y:870,t:1526929938738};\\\", \\\"{x:1481,y:869,t:1526929938746};\\\", \\\"{x:1481,y:868,t:1526929938770};\\\", \\\"{x:1481,y:867,t:1526929938787};\\\", \\\"{x:1481,y:866,t:1526929938794};\\\", \\\"{x:1484,y:862,t:1526929938810};\\\", \\\"{x:1486,y:860,t:1526929938827};\\\", \\\"{x:1487,y:853,t:1526929938843};\\\", \\\"{x:1487,y:852,t:1526929938866};\\\", \\\"{x:1487,y:847,t:1526929938877};\\\", \\\"{x:1489,y:843,t:1526929938893};\\\", \\\"{x:1489,y:837,t:1526929938910};\\\", \\\"{x:1491,y:835,t:1526929938926};\\\", \\\"{x:1491,y:830,t:1526929938943};\\\", \\\"{x:1492,y:827,t:1526929938959};\\\", \\\"{x:1494,y:823,t:1526929938977};\\\", \\\"{x:1494,y:822,t:1526929938993};\\\", \\\"{x:1495,y:819,t:1526929939010};\\\", \\\"{x:1496,y:817,t:1526929939026};\\\", \\\"{x:1497,y:816,t:1526929939058};\\\", \\\"{x:1498,y:815,t:1526929939123};\\\", \\\"{x:1499,y:814,t:1526929939171};\\\", \\\"{x:1500,y:813,t:1526929939211};\\\", \\\"{x:1500,y:811,t:1526929939243};\\\", \\\"{x:1501,y:811,t:1526929939251};\\\", \\\"{x:1501,y:810,t:1526929939260};\\\", \\\"{x:1503,y:808,t:1526929939277};\\\", \\\"{x:1505,y:805,t:1526929939294};\\\", \\\"{x:1510,y:798,t:1526929939310};\\\", \\\"{x:1513,y:786,t:1526929939327};\\\", \\\"{x:1523,y:769,t:1526929939344};\\\", \\\"{x:1529,y:758,t:1526929939360};\\\", \\\"{x:1536,y:746,t:1526929939377};\\\", \\\"{x:1552,y:713,t:1526929939394};\\\", \\\"{x:1555,y:708,t:1526929939410};\\\", \\\"{x:1566,y:685,t:1526929939427};\\\", \\\"{x:1571,y:675,t:1526929939444};\\\", \\\"{x:1576,y:669,t:1526929939460};\\\", \\\"{x:1580,y:660,t:1526929939477};\\\", \\\"{x:1586,y:648,t:1526929939494};\\\", \\\"{x:1593,y:638,t:1526929939510};\\\", \\\"{x:1597,y:631,t:1526929939527};\\\", \\\"{x:1599,y:627,t:1526929939544};\\\", \\\"{x:1601,y:624,t:1526929939560};\\\", \\\"{x:1604,y:617,t:1526929939577};\\\", \\\"{x:1608,y:606,t:1526929939595};\\\", \\\"{x:1610,y:600,t:1526929939610};\\\", \\\"{x:1611,y:593,t:1526929939627};\\\", \\\"{x:1616,y:585,t:1526929939644};\\\", \\\"{x:1619,y:578,t:1526929939662};\\\", \\\"{x:1621,y:575,t:1526929939677};\\\", \\\"{x:1621,y:574,t:1526929939694};\\\", \\\"{x:1622,y:573,t:1526929939711};\\\", \\\"{x:1623,y:572,t:1526929939727};\\\", \\\"{x:1623,y:571,t:1526929939755};\\\", \\\"{x:1624,y:571,t:1526929940042};\\\", \\\"{x:1624,y:570,t:1526929940074};\\\", \\\"{x:1624,y:569,t:1526929940098};\\\", \\\"{x:1623,y:568,t:1526929940111};\\\", \\\"{x:1621,y:567,t:1526929940128};\\\", \\\"{x:1619,y:566,t:1526929940172};\\\", \\\"{x:1619,y:565,t:1526929940202};\\\", \\\"{x:1617,y:564,t:1526929940227};\\\", \\\"{x:1617,y:563,t:1526929940242};\\\", \\\"{x:1616,y:562,t:1526929940250};\\\", \\\"{x:1614,y:561,t:1526929940261};\\\", \\\"{x:1611,y:561,t:1526929940278};\\\", \\\"{x:1609,y:560,t:1526929940295};\\\", \\\"{x:1606,y:558,t:1526929940311};\\\", \\\"{x:1605,y:558,t:1526929940328};\\\", \\\"{x:1603,y:556,t:1526929940345};\\\", \\\"{x:1601,y:555,t:1526929940362};\\\", \\\"{x:1599,y:555,t:1526929940394};\\\", \\\"{x:1597,y:555,t:1526929940411};\\\", \\\"{x:1595,y:555,t:1526929940428};\\\", \\\"{x:1595,y:556,t:1526929940450};\\\", \\\"{x:1595,y:557,t:1526929940461};\\\", \\\"{x:1595,y:560,t:1526929940478};\\\", \\\"{x:1597,y:563,t:1526929940495};\\\", \\\"{x:1598,y:565,t:1526929940511};\\\", \\\"{x:1599,y:567,t:1526929940527};\\\", \\\"{x:1600,y:569,t:1526929940546};\\\", \\\"{x:1601,y:570,t:1526929940570};\\\", \\\"{x:1602,y:572,t:1526929940594};\\\", \\\"{x:1605,y:572,t:1526929940611};\\\", \\\"{x:1606,y:572,t:1526929940628};\\\", \\\"{x:1608,y:572,t:1526929940645};\\\", \\\"{x:1611,y:572,t:1526929940661};\\\", \\\"{x:1614,y:572,t:1526929940678};\\\", \\\"{x:1617,y:572,t:1526929940695};\\\", \\\"{x:1620,y:572,t:1526929940711};\\\", \\\"{x:1622,y:571,t:1526929940728};\\\", \\\"{x:1624,y:570,t:1526929940745};\\\", \\\"{x:1626,y:569,t:1526929940761};\\\", \\\"{x:1629,y:567,t:1526929940778};\\\", \\\"{x:1630,y:566,t:1526929940795};\\\", \\\"{x:1629,y:567,t:1526929941650};\\\", \\\"{x:1628,y:567,t:1526929941699};\\\", \\\"{x:1626,y:569,t:1526929941898};\\\", \\\"{x:1625,y:569,t:1526929941911};\\\", \\\"{x:1617,y:571,t:1526929941929};\\\", \\\"{x:1598,y:571,t:1526929941945};\\\", \\\"{x:1582,y:573,t:1526929941962};\\\", \\\"{x:1568,y:576,t:1526929941979};\\\", \\\"{x:1556,y:577,t:1526929941996};\\\", \\\"{x:1522,y:582,t:1526929942012};\\\", \\\"{x:1471,y:585,t:1526929942029};\\\", \\\"{x:1423,y:591,t:1526929942045};\\\", \\\"{x:1356,y:591,t:1526929942062};\\\", \\\"{x:1317,y:590,t:1526929942079};\\\", \\\"{x:1261,y:590,t:1526929942096};\\\", \\\"{x:1167,y:590,t:1526929942111};\\\", \\\"{x:1070,y:590,t:1526929942129};\\\", \\\"{x:970,y:590,t:1526929942146};\\\", \\\"{x:938,y:589,t:1526929942163};\\\", \\\"{x:923,y:589,t:1526929942178};\\\", \\\"{x:895,y:588,t:1526929942196};\\\", \\\"{x:885,y:588,t:1526929942208};\\\", \\\"{x:834,y:582,t:1526929942225};\\\", \\\"{x:771,y:575,t:1526929942243};\\\", \\\"{x:698,y:564,t:1526929942259};\\\", \\\"{x:649,y:560,t:1526929942278};\\\", \\\"{x:596,y:560,t:1526929942295};\\\", \\\"{x:573,y:560,t:1526929942312};\\\", \\\"{x:564,y:560,t:1526929942328};\\\", \\\"{x:562,y:560,t:1526929942346};\\\", \\\"{x:561,y:561,t:1526929942466};\\\", \\\"{x:561,y:562,t:1526929942478};\\\", \\\"{x:563,y:568,t:1526929942496};\\\", \\\"{x:568,y:573,t:1526929942513};\\\", \\\"{x:584,y:580,t:1526929942530};\\\", \\\"{x:608,y:592,t:1526929942546};\\\", \\\"{x:613,y:595,t:1526929942562};\\\", \\\"{x:620,y:597,t:1526929942580};\\\", \\\"{x:621,y:599,t:1526929942596};\\\", \\\"{x:622,y:600,t:1526929942613};\\\", \\\"{x:624,y:602,t:1526929942629};\\\", \\\"{x:625,y:602,t:1526929942682};\\\", \\\"{x:626,y:601,t:1526929942835};\\\", \\\"{x:626,y:600,t:1526929942851};\\\", \\\"{x:626,y:598,t:1526929942874};\\\", \\\"{x:625,y:598,t:1526929942994};\\\", \\\"{x:625,y:597,t:1526929943001};\\\", \\\"{x:624,y:597,t:1526929943012};\\\", \\\"{x:623,y:597,t:1526929943049};\\\", \\\"{x:622,y:597,t:1526929943073};\\\", \\\"{x:620,y:596,t:1526929943090};\\\", \\\"{x:619,y:596,t:1526929943163};\\\", \\\"{x:619,y:595,t:1526929944219};\\\", \\\"{x:619,y:594,t:1526929944234};\\\", \\\"{x:618,y:591,t:1526929944346};\\\", \\\"{x:604,y:589,t:1526929944354};\\\", \\\"{x:591,y:586,t:1526929944365};\\\", \\\"{x:555,y:575,t:1526929944381};\\\", \\\"{x:517,y:565,t:1526929944398};\\\", \\\"{x:496,y:563,t:1526929944414};\\\", \\\"{x:493,y:562,t:1526929944431};\\\", \\\"{x:492,y:562,t:1526929944447};\\\", \\\"{x:490,y:561,t:1526929944463};\\\", \\\"{x:485,y:561,t:1526929944480};\\\", \\\"{x:473,y:561,t:1526929944497};\\\", \\\"{x:470,y:561,t:1526929944513};\\\", \\\"{x:464,y:561,t:1526929944531};\\\", \\\"{x:460,y:560,t:1526929944547};\\\", \\\"{x:459,y:560,t:1526929944563};\\\", \\\"{x:457,y:560,t:1526929944610};\\\", \\\"{x:454,y:561,t:1526929944617};\\\", \\\"{x:451,y:563,t:1526929944631};\\\", \\\"{x:448,y:565,t:1526929944650};\\\", \\\"{x:445,y:566,t:1526929944664};\\\", \\\"{x:441,y:569,t:1526929944681};\\\", \\\"{x:430,y:572,t:1526929944698};\\\", \\\"{x:420,y:579,t:1526929944715};\\\", \\\"{x:405,y:587,t:1526929944731};\\\", \\\"{x:390,y:595,t:1526929944747};\\\", \\\"{x:366,y:597,t:1526929944765};\\\", \\\"{x:349,y:599,t:1526929944781};\\\", \\\"{x:336,y:600,t:1526929944797};\\\", \\\"{x:321,y:601,t:1526929944814};\\\", \\\"{x:307,y:601,t:1526929944831};\\\", \\\"{x:293,y:597,t:1526929944847};\\\", \\\"{x:283,y:597,t:1526929944864};\\\", \\\"{x:278,y:597,t:1526929944881};\\\", \\\"{x:269,y:597,t:1526929944899};\\\", \\\"{x:262,y:598,t:1526929944915};\\\", \\\"{x:258,y:598,t:1526929944930};\\\", \\\"{x:251,y:598,t:1526929944947};\\\", \\\"{x:244,y:602,t:1526929944964};\\\", \\\"{x:230,y:603,t:1526929944982};\\\", \\\"{x:216,y:603,t:1526929944998};\\\", \\\"{x:200,y:603,t:1526929945014};\\\", \\\"{x:197,y:606,t:1526929945032};\\\", \\\"{x:193,y:606,t:1526929945048};\\\", \\\"{x:189,y:609,t:1526929945082};\\\", \\\"{x:186,y:615,t:1526929945100};\\\", \\\"{x:182,y:616,t:1526929945114};\\\", \\\"{x:181,y:618,t:1526929945132};\\\", \\\"{x:180,y:618,t:1526929945193};\\\", \\\"{x:179,y:618,t:1526929945201};\\\", \\\"{x:178,y:620,t:1526929945215};\\\", \\\"{x:174,y:624,t:1526929945232};\\\", \\\"{x:172,y:626,t:1526929945248};\\\", \\\"{x:170,y:628,t:1526929945274};\\\", \\\"{x:169,y:628,t:1526929945282};\\\", \\\"{x:166,y:628,t:1526929945298};\\\", \\\"{x:164,y:629,t:1526929945315};\\\", \\\"{x:163,y:629,t:1526929945332};\\\", \\\"{x:162,y:630,t:1526929945348};\\\", \\\"{x:160,y:631,t:1526929945365};\\\", \\\"{x:159,y:631,t:1526929945381};\\\", \\\"{x:158,y:632,t:1526929945397};\\\", \\\"{x:157,y:633,t:1526929945617};\\\", \\\"{x:157,y:635,t:1526929945632};\\\", \\\"{x:171,y:643,t:1526929945648};\\\", \\\"{x:200,y:653,t:1526929945665};\\\", \\\"{x:243,y:674,t:1526929945681};\\\", \\\"{x:274,y:686,t:1526929945698};\\\", \\\"{x:305,y:696,t:1526929945714};\\\", \\\"{x:337,y:702,t:1526929945731};\\\", \\\"{x:363,y:708,t:1526929945749};\\\", \\\"{x:385,y:712,t:1526929945765};\\\", \\\"{x:403,y:714,t:1526929945782};\\\", \\\"{x:409,y:716,t:1526929945798};\\\", \\\"{x:411,y:716,t:1526929945841};\\\", \\\"{x:412,y:716,t:1526929945858};\\\", \\\"{x:415,y:716,t:1526929945866};\\\", \\\"{x:421,y:716,t:1526929945882};\\\", \\\"{x:441,y:717,t:1526929945899};\\\", \\\"{x:452,y:718,t:1526929945916};\\\", \\\"{x:465,y:722,t:1526929945931};\\\", \\\"{x:477,y:731,t:1526929945949};\\\", \\\"{x:487,y:731,t:1526929945965};\\\", \\\"{x:496,y:734,t:1526929945982};\\\", \\\"{x:502,y:735,t:1526929945999};\\\", \\\"{x:509,y:735,t:1526929946015};\\\", \\\"{x:511,y:735,t:1526929946032};\\\", \\\"{x:511,y:734,t:1526929946123};\\\", \\\"{x:512,y:732,t:1526929946154};\\\", \\\"{x:513,y:731,t:1526929946166};\\\", \\\"{x:515,y:729,t:1526929946182};\\\", \\\"{x:516,y:726,t:1526929946199};\\\", \\\"{x:516,y:724,t:1526929946216};\\\", \\\"{x:516,y:722,t:1526929946232};\\\", \\\"{x:522,y:722,t:1526929947922};\\\", \\\"{x:549,y:726,t:1526929947933};\\\", \\\"{x:681,y:753,t:1526929947951};\\\", \\\"{x:865,y:799,t:1526929947965};\\\", \\\"{x:1047,y:849,t:1526929947983};\\\", \\\"{x:1249,y:907,t:1526929948000};\\\", \\\"{x:1407,y:953,t:1526929948016};\\\", \\\"{x:1506,y:982,t:1526929948033};\\\", \\\"{x:1509,y:984,t:1526929948050};\\\", \\\"{x:1502,y:981,t:1526929948283};\\\", \\\"{x:1487,y:977,t:1526929948291};\\\", \\\"{x:1472,y:974,t:1526929948301};\\\", \\\"{x:1453,y:968,t:1526929948317};\\\", \\\"{x:1432,y:957,t:1526929948334};\\\", \\\"{x:1418,y:954,t:1526929948351};\\\", \\\"{x:1411,y:951,t:1526929948368};\\\", \\\"{x:1416,y:947,t:1526929948563};\\\", \\\"{x:1422,y:941,t:1526929948571};\\\", \\\"{x:1427,y:935,t:1526929948584};\\\", \\\"{x:1441,y:923,t:1526929948601};\\\", \\\"{x:1458,y:904,t:1526929948618};\\\", \\\"{x:1472,y:887,t:1526929948634};\\\", \\\"{x:1477,y:871,t:1526929948651};\\\", \\\"{x:1484,y:855,t:1526929948668};\\\", \\\"{x:1487,y:836,t:1526929948684};\\\", \\\"{x:1490,y:819,t:1526929948701};\\\", \\\"{x:1492,y:810,t:1526929948718};\\\", \\\"{x:1494,y:800,t:1526929948734};\\\", \\\"{x:1498,y:792,t:1526929948751};\\\", \\\"{x:1500,y:788,t:1526929948769};\\\", \\\"{x:1502,y:783,t:1526929948784};\\\", \\\"{x:1503,y:777,t:1526929948801};\\\", \\\"{x:1504,y:773,t:1526929948818};\\\", \\\"{x:1504,y:770,t:1526929948834};\\\", \\\"{x:1507,y:766,t:1526929948851};\\\", \\\"{x:1507,y:764,t:1526929948868};\\\", \\\"{x:1507,y:759,t:1526929948885};\\\", \\\"{x:1508,y:754,t:1526929948902};\\\", \\\"{x:1511,y:747,t:1526929948919};\\\", \\\"{x:1514,y:738,t:1526929948935};\\\", \\\"{x:1520,y:730,t:1526929948951};\\\", \\\"{x:1525,y:723,t:1526929948969};\\\", \\\"{x:1527,y:717,t:1526929948985};\\\", \\\"{x:1534,y:707,t:1526929949001};\\\", \\\"{x:1543,y:694,t:1526929949018};\\\", \\\"{x:1554,y:683,t:1526929949036};\\\", \\\"{x:1564,y:669,t:1526929949051};\\\", \\\"{x:1573,y:659,t:1526929949068};\\\", \\\"{x:1577,y:655,t:1526929949085};\\\", \\\"{x:1580,y:650,t:1526929949102};\\\", \\\"{x:1587,y:642,t:1526929949119};\\\", \\\"{x:1594,y:630,t:1526929949135};\\\", \\\"{x:1600,y:623,t:1526929949153};\\\", \\\"{x:1612,y:610,t:1526929949168};\\\", \\\"{x:1624,y:599,t:1526929949186};\\\", \\\"{x:1641,y:583,t:1526929949202};\\\", \\\"{x:1653,y:577,t:1526929949218};\\\", \\\"{x:1657,y:574,t:1526929949235};\\\", \\\"{x:1662,y:569,t:1526929949252};\\\", \\\"{x:1663,y:569,t:1526929949268};\\\", \\\"{x:1663,y:568,t:1526929949285};\\\", \\\"{x:1663,y:566,t:1526929949306};\\\", \\\"{x:1663,y:565,t:1526929949318};\\\", \\\"{x:1665,y:561,t:1526929949335};\\\", \\\"{x:1667,y:559,t:1526929949353};\\\", \\\"{x:1667,y:557,t:1526929949368};\\\", \\\"{x:1667,y:556,t:1526929949386};\\\", \\\"{x:1671,y:553,t:1526929949401};\\\", \\\"{x:1672,y:553,t:1526929949419};\\\", \\\"{x:1672,y:551,t:1526929949435};\\\", \\\"{x:1670,y:551,t:1526929949490};\\\", \\\"{x:1662,y:557,t:1526929949502};\\\", \\\"{x:1640,y:589,t:1526929949518};\\\", \\\"{x:1591,y:652,t:1526929949535};\\\", \\\"{x:1485,y:725,t:1526929949552};\\\", \\\"{x:1370,y:774,t:1526929949569};\\\", \\\"{x:1256,y:809,t:1526929949585};\\\", \\\"{x:1102,y:845,t:1526929949602};\\\", \\\"{x:1028,y:863,t:1526929949620};\\\", \\\"{x:970,y:878,t:1526929949635};\\\", \\\"{x:901,y:883,t:1526929949652};\\\", \\\"{x:842,y:887,t:1526929949669};\\\", \\\"{x:830,y:887,t:1526929949685};\\\", \\\"{x:803,y:887,t:1526929949702};\\\", \\\"{x:784,y:882,t:1526929949719};\\\", \\\"{x:763,y:873,t:1526929949735};\\\", \\\"{x:733,y:867,t:1526929949752};\\\", \\\"{x:710,y:860,t:1526929949769};\\\", \\\"{x:667,y:853,t:1526929949786};\\\", \\\"{x:611,y:830,t:1526929949802};\\\", \\\"{x:603,y:827,t:1526929949819};\\\", \\\"{x:601,y:821,t:1526929949836};\\\", \\\"{x:601,y:813,t:1526929949853};\\\", \\\"{x:603,y:807,t:1526929949869};\\\", \\\"{x:606,y:804,t:1526929949885};\\\", \\\"{x:610,y:799,t:1526929949902};\\\", \\\"{x:613,y:793,t:1526929949919};\\\", \\\"{x:620,y:786,t:1526929949936};\\\", \\\"{x:633,y:771,t:1526929949952};\\\", \\\"{x:649,y:758,t:1526929949969};\\\", \\\"{x:655,y:750,t:1526929949986};\\\", \\\"{x:656,y:750,t:1526929950002};\\\", \\\"{x:656,y:749,t:1526929950019};\\\", \\\"{x:656,y:748,t:1526929950037};\\\", \\\"{x:656,y:746,t:1526929950052};\\\", \\\"{x:654,y:743,t:1526929950069};\\\", \\\"{x:650,y:742,t:1526929950086};\\\", \\\"{x:636,y:739,t:1526929950102};\\\", \\\"{x:602,y:734,t:1526929950119};\\\", \\\"{x:583,y:727,t:1526929950136};\\\", \\\"{x:582,y:727,t:1526929950152};\\\", \\\"{x:582,y:728,t:1526929950178};\\\", \\\"{x:582,y:729,t:1526929950186};\\\", \\\"{x:580,y:731,t:1526929950202};\\\", \\\"{x:579,y:731,t:1526929950242};\\\", \\\"{x:577,y:731,t:1526929950434};\\\", \\\"{x:570,y:731,t:1526929950442};\\\", \\\"{x:563,y:731,t:1526929950454};\\\", \\\"{x:558,y:731,t:1526929950468};\\\", \\\"{x:547,y:726,t:1526929950485};\\\", \\\"{x:529,y:722,t:1526929950502};\\\", \\\"{x:523,y:722,t:1526929950519};\\\", \\\"{x:520,y:720,t:1526929950535};\\\", \\\"{x:518,y:720,t:1526929950594};\\\", \\\"{x:517,y:720,t:1526929950609};\\\", \\\"{x:516,y:719,t:1526929950625};\\\", \\\"{x:517,y:719,t:1526929951210};\\\", \\\"{x:526,y:719,t:1526929951219};\\\", \\\"{x:541,y:715,t:1526929951236};\\\", \\\"{x:549,y:714,t:1526929951253};\\\", \\\"{x:564,y:710,t:1526929951269};\\\", \\\"{x:611,y:705,t:1526929951286};\\\", \\\"{x:744,y:705,t:1526929951303};\\\", \\\"{x:908,y:706,t:1526929951319};\\\", \\\"{x:1075,y:717,t:1526929951336};\\\", \\\"{x:1214,y:741,t:1526929951353};\\\", \\\"{x:1256,y:742,t:1526929951370};\\\", \\\"{x:1270,y:742,t:1526929951385};\\\", \\\"{x:1272,y:742,t:1526929951473};\\\", \\\"{x:1275,y:740,t:1526929951486};\\\", \\\"{x:1280,y:739,t:1526929951503};\\\", \\\"{x:1292,y:736,t:1526929951520};\\\", \\\"{x:1299,y:735,t:1526929951535};\\\", \\\"{x:1312,y:731,t:1526929951552};\\\", \\\"{x:1329,y:726,t:1526929951569};\\\", \\\"{x:1379,y:711,t:1526929951586};\\\", \\\"{x:1484,y:685,t:1526929951602};\\\", \\\"{x:1624,y:653,t:1526929951620};\\\", \\\"{x:1791,y:617,t:1526929951636};\\\", \\\"{x:1919,y:588,t:1526929951653};\\\", \\\"{x:1919,y:573,t:1526929951670};\\\", \\\"{x:1919,y:549,t:1526929951687};\\\", \\\"{x:1919,y:537,t:1526929951702};\\\", \\\"{x:1919,y:531,t:1526929951720};\\\", \\\"{x:1919,y:530,t:1526929951737};\\\" ] }, { \\\"rt\\\": 102206, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 377671, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-01 PM-Z -Z -Z -12 PM-01 PM-01 PM-12 PM-Z -Z -O -K -F -U -U -U -H -H -A -10 AM-12 PM-05 PM-04 PM-11 AM-11 AM-C -C -09 AM-09 AM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1919,y:526,t:1526929953731};\\\", \\\"{x:1919,y:518,t:1526929953748};\\\", \\\"{x:1919,y:517,t:1526929953757};\\\", \\\"{x:1913,y:517,t:1526929953802};\\\", \\\"{x:1907,y:525,t:1526929953809};\\\", \\\"{x:1891,y:531,t:1526929953824};\\\", \\\"{x:1874,y:544,t:1526929953839};\\\", \\\"{x:1853,y:557,t:1526929953855};\\\", \\\"{x:1832,y:572,t:1526929953872};\\\", \\\"{x:1814,y:590,t:1526929953888};\\\", \\\"{x:1799,y:604,t:1526929953905};\\\", \\\"{x:1764,y:630,t:1526929953921};\\\", \\\"{x:1753,y:636,t:1526929953939};\\\", \\\"{x:1746,y:641,t:1526929953954};\\\", \\\"{x:1741,y:646,t:1526929953972};\\\", \\\"{x:1731,y:654,t:1526929953989};\\\", \\\"{x:1710,y:665,t:1526929954005};\\\", \\\"{x:1684,y:685,t:1526929954022};\\\", \\\"{x:1642,y:713,t:1526929954040};\\\", \\\"{x:1564,y:751,t:1526929954055};\\\", \\\"{x:1506,y:771,t:1526929954072};\\\", \\\"{x:1442,y:787,t:1526929954089};\\\", \\\"{x:1380,y:819,t:1526929954105};\\\", \\\"{x:1301,y:861,t:1526929954122};\\\", \\\"{x:1248,y:894,t:1526929954139};\\\", \\\"{x:1215,y:922,t:1526929954155};\\\", \\\"{x:1188,y:964,t:1526929954173};\\\", \\\"{x:1162,y:995,t:1526929954190};\\\", \\\"{x:1151,y:1011,t:1526929954206};\\\", \\\"{x:1141,y:1035,t:1526929954222};\\\", \\\"{x:1135,y:1046,t:1526929954239};\\\", \\\"{x:1131,y:1055,t:1526929954257};\\\", \\\"{x:1131,y:1070,t:1526929954272};\\\", \\\"{x:1133,y:1080,t:1526929954289};\\\", \\\"{x:1142,y:1096,t:1526929954305};\\\", \\\"{x:1157,y:1108,t:1526929954322};\\\", \\\"{x:1176,y:1120,t:1526929954339};\\\", \\\"{x:1217,y:1136,t:1526929954356};\\\", \\\"{x:1269,y:1149,t:1526929954372};\\\", \\\"{x:1297,y:1156,t:1526929954389};\\\", \\\"{x:1323,y:1156,t:1526929954406};\\\", \\\"{x:1351,y:1154,t:1526929954422};\\\", \\\"{x:1403,y:1145,t:1526929954439};\\\", \\\"{x:1483,y:1145,t:1526929954456};\\\", \\\"{x:1521,y:1139,t:1526929954472};\\\", \\\"{x:1538,y:1132,t:1526929954489};\\\", \\\"{x:1542,y:1128,t:1526929954506};\\\", \\\"{x:1543,y:1128,t:1526929954523};\\\", \\\"{x:1540,y:1127,t:1526929954540};\\\", \\\"{x:1535,y:1128,t:1526929954557};\\\", \\\"{x:1519,y:1134,t:1526929954573};\\\", \\\"{x:1485,y:1151,t:1526929954589};\\\", \\\"{x:1446,y:1168,t:1526929954606};\\\", \\\"{x:1436,y:1169,t:1526929954624};\\\", \\\"{x:1435,y:1169,t:1526929954639};\\\", \\\"{x:1437,y:1169,t:1526929954738};\\\", \\\"{x:1443,y:1165,t:1526929954756};\\\", \\\"{x:1445,y:1164,t:1526929954773};\\\", \\\"{x:1450,y:1162,t:1526929954791};\\\", \\\"{x:1462,y:1154,t:1526929954806};\\\", \\\"{x:1468,y:1150,t:1526929954823};\\\", \\\"{x:1475,y:1146,t:1526929954840};\\\", \\\"{x:1486,y:1140,t:1526929954856};\\\", \\\"{x:1504,y:1129,t:1526929954873};\\\", \\\"{x:1521,y:1114,t:1526929954889};\\\", \\\"{x:1528,y:1108,t:1526929954906};\\\", \\\"{x:1540,y:1099,t:1526929954924};\\\", \\\"{x:1552,y:1093,t:1526929954939};\\\", \\\"{x:1566,y:1084,t:1526929954956};\\\", \\\"{x:1580,y:1072,t:1526929954973};\\\", \\\"{x:1589,y:1067,t:1526929954990};\\\", \\\"{x:1595,y:1051,t:1526929955006};\\\", \\\"{x:1598,y:1049,t:1526929955023};\\\", \\\"{x:1599,y:1049,t:1526929955040};\\\", \\\"{x:1593,y:1052,t:1526929955090};\\\", \\\"{x:1575,y:1055,t:1526929955107};\\\", \\\"{x:1562,y:1057,t:1526929955123};\\\", \\\"{x:1546,y:1058,t:1526929955140};\\\", \\\"{x:1532,y:1061,t:1526929955157};\\\", \\\"{x:1529,y:1063,t:1526929955173};\\\", \\\"{x:1528,y:1064,t:1526929955190};\\\", \\\"{x:1527,y:1064,t:1526929955207};\\\", \\\"{x:1529,y:1064,t:1526929955282};\\\", \\\"{x:1532,y:1064,t:1526929955291};\\\", \\\"{x:1545,y:1055,t:1526929955308};\\\", \\\"{x:1554,y:1048,t:1526929955324};\\\", \\\"{x:1567,y:1040,t:1526929955341};\\\", \\\"{x:1585,y:1030,t:1526929955357};\\\", \\\"{x:1595,y:1026,t:1526929955374};\\\", \\\"{x:1608,y:1020,t:1526929955390};\\\", \\\"{x:1617,y:1016,t:1526929955408};\\\", \\\"{x:1618,y:1015,t:1526929955424};\\\", \\\"{x:1620,y:1013,t:1526929955441};\\\", \\\"{x:1621,y:1012,t:1526929955457};\\\", \\\"{x:1622,y:1011,t:1526929955474};\\\", \\\"{x:1623,y:1010,t:1526929955506};\\\", \\\"{x:1624,y:1010,t:1526929955514};\\\", \\\"{x:1625,y:1009,t:1526929955530};\\\", \\\"{x:1627,y:1009,t:1526929955546};\\\", \\\"{x:1628,y:1008,t:1526929955558};\\\", \\\"{x:1628,y:1007,t:1526929955574};\\\", \\\"{x:1630,y:1007,t:1526929955591};\\\", \\\"{x:1630,y:1006,t:1526929955608};\\\", \\\"{x:1631,y:1006,t:1526929955624};\\\", \\\"{x:1633,y:1005,t:1526929955642};\\\", \\\"{x:1634,y:1004,t:1526929955658};\\\", \\\"{x:1635,y:1003,t:1526929955675};\\\", \\\"{x:1633,y:1005,t:1526929955819};\\\", \\\"{x:1629,y:1006,t:1526929955826};\\\", \\\"{x:1615,y:1014,t:1526929955842};\\\", \\\"{x:1604,y:1017,t:1526929955857};\\\", \\\"{x:1600,y:1019,t:1526929955874};\\\", \\\"{x:1596,y:1021,t:1526929955891};\\\", \\\"{x:1592,y:1024,t:1526929955908};\\\", \\\"{x:1589,y:1024,t:1526929955924};\\\", \\\"{x:1586,y:1025,t:1526929955941};\\\", \\\"{x:1585,y:1026,t:1526929956442};\\\", \\\"{x:1574,y:1022,t:1526929956459};\\\", \\\"{x:1562,y:1019,t:1526929956476};\\\", \\\"{x:1547,y:1013,t:1526929956493};\\\", \\\"{x:1538,y:1008,t:1526929956509};\\\", \\\"{x:1533,y:1005,t:1526929956525};\\\", \\\"{x:1530,y:1005,t:1526929956543};\\\", \\\"{x:1529,y:1005,t:1526929956558};\\\", \\\"{x:1527,y:1005,t:1526929956667};\\\", \\\"{x:1525,y:1005,t:1526929956690};\\\", \\\"{x:1523,y:1005,t:1526929956698};\\\", \\\"{x:1519,y:1003,t:1526929956710};\\\", \\\"{x:1518,y:1002,t:1526929956725};\\\", \\\"{x:1515,y:1002,t:1526929956743};\\\", \\\"{x:1513,y:1002,t:1526929956762};\\\", \\\"{x:1512,y:1002,t:1526929956811};\\\", \\\"{x:1509,y:1000,t:1526929956851};\\\", \\\"{x:1508,y:1000,t:1526929956859};\\\", \\\"{x:1502,y:998,t:1526929956875};\\\", \\\"{x:1497,y:997,t:1526929956893};\\\", \\\"{x:1495,y:997,t:1526929956910};\\\", \\\"{x:1492,y:997,t:1526929956926};\\\", \\\"{x:1489,y:997,t:1526929956943};\\\", \\\"{x:1487,y:996,t:1526929956959};\\\", \\\"{x:1484,y:995,t:1526929956977};\\\", \\\"{x:1482,y:995,t:1526929956994};\\\", \\\"{x:1481,y:995,t:1526929957026};\\\", \\\"{x:1479,y:995,t:1526929957801};\\\", \\\"{x:1478,y:995,t:1526929957841};\\\", \\\"{x:1477,y:994,t:1526929957849};\\\", \\\"{x:1474,y:993,t:1526929957860};\\\", \\\"{x:1472,y:993,t:1526929957877};\\\", \\\"{x:1468,y:992,t:1526929957893};\\\", \\\"{x:1466,y:992,t:1526929957910};\\\", \\\"{x:1465,y:992,t:1526929957946};\\\", \\\"{x:1467,y:992,t:1526929958137};\\\", \\\"{x:1468,y:992,t:1526929958161};\\\", \\\"{x:1469,y:991,t:1526929958185};\\\", \\\"{x:1470,y:991,t:1526929958194};\\\", \\\"{x:1473,y:989,t:1526929958210};\\\", \\\"{x:1478,y:988,t:1526929958227};\\\", \\\"{x:1479,y:987,t:1526929958244};\\\", \\\"{x:1480,y:986,t:1526929958261};\\\", \\\"{x:1482,y:985,t:1526929958277};\\\", \\\"{x:1484,y:982,t:1526929958294};\\\", \\\"{x:1485,y:979,t:1526929958311};\\\", \\\"{x:1487,y:977,t:1526929958330};\\\", \\\"{x:1489,y:975,t:1526929958345};\\\", \\\"{x:1491,y:970,t:1526929958361};\\\", \\\"{x:1491,y:968,t:1526929958378};\\\", \\\"{x:1491,y:965,t:1526929958395};\\\", \\\"{x:1492,y:962,t:1526929958411};\\\", \\\"{x:1493,y:960,t:1526929958428};\\\", \\\"{x:1493,y:958,t:1526929958444};\\\", \\\"{x:1497,y:954,t:1526929958462};\\\", \\\"{x:1500,y:948,t:1526929958478};\\\", \\\"{x:1501,y:944,t:1526929958494};\\\", \\\"{x:1501,y:941,t:1526929958511};\\\", \\\"{x:1503,y:936,t:1526929958527};\\\", \\\"{x:1503,y:932,t:1526929958544};\\\", \\\"{x:1505,y:930,t:1526929958562};\\\", \\\"{x:1506,y:926,t:1526929958578};\\\", \\\"{x:1507,y:922,t:1526929958594};\\\", \\\"{x:1510,y:920,t:1526929958611};\\\", \\\"{x:1511,y:918,t:1526929958629};\\\", \\\"{x:1513,y:917,t:1526929958650};\\\", \\\"{x:1514,y:915,t:1526929958674};\\\", \\\"{x:1513,y:918,t:1526929958810};\\\", \\\"{x:1510,y:921,t:1526929958828};\\\", \\\"{x:1510,y:923,t:1526929958845};\\\", \\\"{x:1507,y:928,t:1526929958862};\\\", \\\"{x:1505,y:931,t:1526929958879};\\\", \\\"{x:1503,y:934,t:1526929958896};\\\", \\\"{x:1500,y:938,t:1526929958911};\\\", \\\"{x:1495,y:944,t:1526929958928};\\\", \\\"{x:1492,y:948,t:1526929958946};\\\", \\\"{x:1490,y:951,t:1526929958962};\\\", \\\"{x:1490,y:952,t:1526929958978};\\\", \\\"{x:1489,y:954,t:1526929958995};\\\", \\\"{x:1488,y:955,t:1526929959012};\\\", \\\"{x:1487,y:958,t:1526929959029};\\\", \\\"{x:1486,y:961,t:1526929959045};\\\", \\\"{x:1484,y:962,t:1526929959062};\\\", \\\"{x:1484,y:964,t:1526929959079};\\\", \\\"{x:1483,y:965,t:1526929959096};\\\", \\\"{x:1483,y:966,t:1526929959113};\\\", \\\"{x:1482,y:966,t:1526929959129};\\\", \\\"{x:1481,y:967,t:1526929959170};\\\", \\\"{x:1480,y:969,t:1526929959258};\\\", \\\"{x:1479,y:969,t:1526929959314};\\\", \\\"{x:1478,y:970,t:1526929959378};\\\", \\\"{x:1478,y:969,t:1526929959883};\\\", \\\"{x:1478,y:968,t:1526929959906};\\\", \\\"{x:1478,y:967,t:1526929959922};\\\", \\\"{x:1479,y:965,t:1526929959930};\\\", \\\"{x:1480,y:964,t:1526929959946};\\\", \\\"{x:1481,y:962,t:1526929959963};\\\", \\\"{x:1482,y:961,t:1526929959979};\\\", \\\"{x:1482,y:959,t:1526929960001};\\\", \\\"{x:1482,y:958,t:1526929960017};\\\", \\\"{x:1484,y:957,t:1526929960033};\\\", \\\"{x:1485,y:956,t:1526929960046};\\\", \\\"{x:1486,y:955,t:1526929960063};\\\", \\\"{x:1486,y:954,t:1526929960082};\\\", \\\"{x:1486,y:952,t:1526929960096};\\\", \\\"{x:1486,y:949,t:1526929960113};\\\", \\\"{x:1486,y:948,t:1526929960137};\\\", \\\"{x:1486,y:947,t:1526929960147};\\\", \\\"{x:1486,y:945,t:1526929960163};\\\", \\\"{x:1486,y:943,t:1526929960180};\\\", \\\"{x:1486,y:942,t:1526929960196};\\\", \\\"{x:1485,y:942,t:1526929960259};\\\", \\\"{x:1479,y:942,t:1526929960266};\\\", \\\"{x:1476,y:942,t:1526929960281};\\\", \\\"{x:1469,y:949,t:1526929960297};\\\", \\\"{x:1460,y:953,t:1526929960313};\\\", \\\"{x:1458,y:954,t:1526929960331};\\\", \\\"{x:1455,y:955,t:1526929960347};\\\", \\\"{x:1455,y:956,t:1526929960364};\\\", \\\"{x:1452,y:957,t:1526929960381};\\\", \\\"{x:1447,y:961,t:1526929960397};\\\", \\\"{x:1445,y:962,t:1526929960413};\\\", \\\"{x:1440,y:966,t:1526929960431};\\\", \\\"{x:1439,y:967,t:1526929960450};\\\", \\\"{x:1438,y:967,t:1526929960531};\\\", \\\"{x:1436,y:969,t:1526929960547};\\\", \\\"{x:1435,y:969,t:1526929960564};\\\", \\\"{x:1434,y:970,t:1526929960586};\\\", \\\"{x:1434,y:968,t:1526929960667};\\\", \\\"{x:1434,y:966,t:1526929960680};\\\", \\\"{x:1433,y:959,t:1526929960698};\\\", \\\"{x:1433,y:951,t:1526929960714};\\\", \\\"{x:1433,y:948,t:1526929960731};\\\", \\\"{x:1437,y:939,t:1526929960748};\\\", \\\"{x:1439,y:936,t:1526929960765};\\\", \\\"{x:1440,y:934,t:1526929960780};\\\", \\\"{x:1444,y:928,t:1526929960798};\\\", \\\"{x:1447,y:922,t:1526929960815};\\\", \\\"{x:1450,y:914,t:1526929960831};\\\", \\\"{x:1453,y:909,t:1526929960847};\\\", \\\"{x:1457,y:900,t:1526929960864};\\\", \\\"{x:1460,y:893,t:1526929960880};\\\", \\\"{x:1462,y:884,t:1526929960898};\\\", \\\"{x:1463,y:882,t:1526929960915};\\\", \\\"{x:1464,y:878,t:1526929960931};\\\", \\\"{x:1465,y:876,t:1526929960948};\\\", \\\"{x:1468,y:872,t:1526929960965};\\\", \\\"{x:1471,y:867,t:1526929960982};\\\", \\\"{x:1474,y:861,t:1526929960998};\\\", \\\"{x:1476,y:858,t:1526929961015};\\\", \\\"{x:1479,y:853,t:1526929961032};\\\", \\\"{x:1481,y:851,t:1526929961047};\\\", \\\"{x:1483,y:849,t:1526929961065};\\\", \\\"{x:1483,y:848,t:1526929961082};\\\", \\\"{x:1484,y:847,t:1526929961097};\\\", \\\"{x:1484,y:846,t:1526929961115};\\\", \\\"{x:1484,y:845,t:1526929961132};\\\", \\\"{x:1486,y:843,t:1526929961148};\\\", \\\"{x:1487,y:840,t:1526929961164};\\\", \\\"{x:1488,y:839,t:1526929961182};\\\", \\\"{x:1488,y:838,t:1526929961218};\\\", \\\"{x:1488,y:837,t:1526929961250};\\\", \\\"{x:1489,y:837,t:1526929961265};\\\", \\\"{x:1490,y:836,t:1526929961282};\\\", \\\"{x:1490,y:834,t:1526929961298};\\\", \\\"{x:1490,y:833,t:1526929961314};\\\", \\\"{x:1490,y:831,t:1526929961331};\\\", \\\"{x:1490,y:830,t:1526929961361};\\\", \\\"{x:1490,y:832,t:1526929964067};\\\", \\\"{x:1490,y:834,t:1526929964074};\\\", \\\"{x:1490,y:838,t:1526929964085};\\\", \\\"{x:1490,y:844,t:1526929964102};\\\", \\\"{x:1490,y:851,t:1526929964119};\\\", \\\"{x:1488,y:853,t:1526929965674};\\\", \\\"{x:1480,y:855,t:1526929965687};\\\", \\\"{x:1446,y:868,t:1526929965704};\\\", \\\"{x:1422,y:877,t:1526929965721};\\\", \\\"{x:1421,y:878,t:1526929965737};\\\", \\\"{x:1421,y:880,t:1526929965754};\\\", \\\"{x:1416,y:883,t:1526929965771};\\\", \\\"{x:1410,y:888,t:1526929965788};\\\", \\\"{x:1409,y:888,t:1526929965804};\\\", \\\"{x:1408,y:888,t:1526929965821};\\\", \\\"{x:1407,y:888,t:1526929965849};\\\", \\\"{x:1406,y:888,t:1526929966306};\\\", \\\"{x:1401,y:888,t:1526929966321};\\\", \\\"{x:1379,y:882,t:1526929966338};\\\", \\\"{x:1360,y:875,t:1526929966354};\\\", \\\"{x:1346,y:871,t:1526929966372};\\\", \\\"{x:1344,y:871,t:1526929966387};\\\", \\\"{x:1334,y:871,t:1526929966405};\\\", \\\"{x:1315,y:871,t:1526929966422};\\\", \\\"{x:1298,y:872,t:1526929966438};\\\", \\\"{x:1293,y:873,t:1526929966454};\\\", \\\"{x:1289,y:874,t:1526929966471};\\\", \\\"{x:1288,y:874,t:1526929966546};\\\", \\\"{x:1288,y:875,t:1526929966555};\\\", \\\"{x:1288,y:879,t:1526929966572};\\\", \\\"{x:1288,y:880,t:1526929966589};\\\", \\\"{x:1288,y:885,t:1526929966604};\\\", \\\"{x:1288,y:891,t:1526929966622};\\\", \\\"{x:1288,y:900,t:1526929966639};\\\", \\\"{x:1288,y:909,t:1526929966655};\\\", \\\"{x:1292,y:918,t:1526929966672};\\\", \\\"{x:1299,y:926,t:1526929966690};\\\", \\\"{x:1309,y:936,t:1526929966705};\\\", \\\"{x:1325,y:942,t:1526929966722};\\\", \\\"{x:1334,y:942,t:1526929966739};\\\", \\\"{x:1340,y:942,t:1526929966755};\\\", \\\"{x:1341,y:942,t:1526929966772};\\\", \\\"{x:1342,y:942,t:1526929966789};\\\", \\\"{x:1344,y:942,t:1526929966805};\\\", \\\"{x:1346,y:941,t:1526929966822};\\\", \\\"{x:1348,y:936,t:1526929966839};\\\", \\\"{x:1352,y:930,t:1526929966856};\\\", \\\"{x:1355,y:927,t:1526929966871};\\\", \\\"{x:1360,y:918,t:1526929966889};\\\", \\\"{x:1367,y:902,t:1526929966906};\\\", \\\"{x:1369,y:895,t:1526929966922};\\\", \\\"{x:1369,y:891,t:1526929966939};\\\", \\\"{x:1369,y:887,t:1526929966956};\\\", \\\"{x:1369,y:886,t:1526929966972};\\\", \\\"{x:1369,y:880,t:1526929966989};\\\", \\\"{x:1369,y:878,t:1526929967006};\\\", \\\"{x:1369,y:877,t:1526929967022};\\\", \\\"{x:1369,y:876,t:1526929967058};\\\", \\\"{x:1364,y:876,t:1526929967114};\\\", \\\"{x:1361,y:878,t:1526929967130};\\\", \\\"{x:1360,y:879,t:1526929967139};\\\", \\\"{x:1357,y:882,t:1526929967156};\\\", \\\"{x:1354,y:884,t:1526929967173};\\\", \\\"{x:1352,y:886,t:1526929967189};\\\", \\\"{x:1352,y:888,t:1526929967274};\\\", \\\"{x:1350,y:890,t:1526929967289};\\\", \\\"{x:1347,y:892,t:1526929967308};\\\", \\\"{x:1346,y:892,t:1526929967754};\\\", \\\"{x:1345,y:892,t:1526929967761};\\\", \\\"{x:1343,y:893,t:1526929967786};\\\", \\\"{x:1343,y:894,t:1526929967817};\\\", \\\"{x:1342,y:895,t:1526929967824};\\\", \\\"{x:1341,y:895,t:1526929967850};\\\", \\\"{x:1340,y:896,t:1526929967857};\\\", \\\"{x:1339,y:897,t:1526929967873};\\\", \\\"{x:1337,y:898,t:1526929967889};\\\", \\\"{x:1337,y:899,t:1526929967906};\\\", \\\"{x:1337,y:900,t:1526929968106};\\\", \\\"{x:1339,y:899,t:1526929968194};\\\", \\\"{x:1340,y:898,t:1526929968207};\\\", \\\"{x:1342,y:896,t:1526929968225};\\\", \\\"{x:1343,y:895,t:1526929968242};\\\", \\\"{x:1343,y:894,t:1526929968265};\\\", \\\"{x:1343,y:892,t:1526929968339};\\\", \\\"{x:1343,y:891,t:1526929968442};\\\", \\\"{x:1343,y:890,t:1526929968698};\\\", \\\"{x:1345,y:890,t:1526929968836};\\\", \\\"{x:1346,y:890,t:1526929968841};\\\", \\\"{x:1350,y:890,t:1526929968858};\\\", \\\"{x:1360,y:891,t:1526929968875};\\\", \\\"{x:1364,y:891,t:1526929968891};\\\", \\\"{x:1371,y:891,t:1526929968907};\\\", \\\"{x:1372,y:891,t:1526929968925};\\\", \\\"{x:1373,y:891,t:1526929968945};\\\", \\\"{x:1372,y:892,t:1526929969266};\\\", \\\"{x:1372,y:894,t:1526929969275};\\\", \\\"{x:1370,y:900,t:1526929969292};\\\", \\\"{x:1368,y:904,t:1526929969309};\\\", \\\"{x:1368,y:909,t:1526929969325};\\\", \\\"{x:1367,y:912,t:1526929969342};\\\", \\\"{x:1367,y:916,t:1526929969359};\\\", \\\"{x:1366,y:918,t:1526929969375};\\\", \\\"{x:1366,y:920,t:1526929969392};\\\", \\\"{x:1365,y:924,t:1526929969409};\\\", \\\"{x:1362,y:927,t:1526929969425};\\\", \\\"{x:1359,y:931,t:1526929969442};\\\", \\\"{x:1356,y:936,t:1526929969459};\\\", \\\"{x:1355,y:941,t:1526929969475};\\\", \\\"{x:1351,y:948,t:1526929969492};\\\", \\\"{x:1351,y:949,t:1526929969509};\\\", \\\"{x:1350,y:953,t:1526929969526};\\\", \\\"{x:1348,y:956,t:1526929969542};\\\", \\\"{x:1348,y:958,t:1526929969559};\\\", \\\"{x:1348,y:961,t:1526929969576};\\\", \\\"{x:1348,y:963,t:1526929969593};\\\", \\\"{x:1349,y:966,t:1526929969609};\\\", \\\"{x:1349,y:967,t:1526929969626};\\\", \\\"{x:1349,y:969,t:1526929969642};\\\", \\\"{x:1349,y:970,t:1526929969666};\\\", \\\"{x:1351,y:971,t:1526929969689};\\\", \\\"{x:1352,y:973,t:1526929969705};\\\", \\\"{x:1353,y:973,t:1526929969729};\\\", \\\"{x:1353,y:974,t:1526929969841};\\\", \\\"{x:1355,y:974,t:1526929969922};\\\", \\\"{x:1355,y:973,t:1526929970122};\\\", \\\"{x:1355,y:971,t:1526929970194};\\\", \\\"{x:1355,y:970,t:1526929970217};\\\", \\\"{x:1355,y:968,t:1526929970250};\\\", \\\"{x:1356,y:966,t:1526929970265};\\\", \\\"{x:1356,y:964,t:1526929970277};\\\", \\\"{x:1356,y:963,t:1526929970292};\\\", \\\"{x:1356,y:962,t:1526929970311};\\\", \\\"{x:1356,y:960,t:1526929970327};\\\", \\\"{x:1356,y:959,t:1526929970343};\\\", \\\"{x:1356,y:958,t:1526929970360};\\\", \\\"{x:1356,y:953,t:1526929970377};\\\", \\\"{x:1356,y:951,t:1526929970393};\\\", \\\"{x:1356,y:946,t:1526929970411};\\\", \\\"{x:1357,y:945,t:1526929970427};\\\", \\\"{x:1357,y:944,t:1526929970443};\\\", \\\"{x:1354,y:944,t:1526929970650};\\\", \\\"{x:1353,y:945,t:1526929970660};\\\", \\\"{x:1350,y:947,t:1526929970677};\\\", \\\"{x:1347,y:948,t:1526929970706};\\\", \\\"{x:1347,y:949,t:1526929970721};\\\", \\\"{x:1346,y:949,t:1526929970729};\\\", \\\"{x:1345,y:950,t:1526929970744};\\\", \\\"{x:1344,y:950,t:1526929970760};\\\", \\\"{x:1344,y:951,t:1526929970777};\\\", \\\"{x:1341,y:952,t:1526929970794};\\\", \\\"{x:1340,y:953,t:1526929970810};\\\", \\\"{x:1338,y:954,t:1526929970827};\\\", \\\"{x:1337,y:954,t:1526929970844};\\\", \\\"{x:1334,y:955,t:1526929970861};\\\", \\\"{x:1333,y:956,t:1526929970877};\\\", \\\"{x:1328,y:958,t:1526929970894};\\\", \\\"{x:1324,y:959,t:1526929970911};\\\", \\\"{x:1322,y:961,t:1526929970927};\\\", \\\"{x:1320,y:962,t:1526929970944};\\\", \\\"{x:1320,y:963,t:1526929970961};\\\", \\\"{x:1317,y:964,t:1526929970978};\\\", \\\"{x:1314,y:966,t:1526929970994};\\\", \\\"{x:1313,y:967,t:1526929971011};\\\", \\\"{x:1311,y:968,t:1526929971027};\\\", \\\"{x:1310,y:968,t:1526929971082};\\\", \\\"{x:1309,y:968,t:1526929971098};\\\", \\\"{x:1308,y:968,t:1526929971138};\\\", \\\"{x:1307,y:968,t:1526929971258};\\\", \\\"{x:1312,y:968,t:1526929971265};\\\", \\\"{x:1322,y:968,t:1526929971278};\\\", \\\"{x:1346,y:968,t:1526929971294};\\\", \\\"{x:1389,y:980,t:1526929971311};\\\", \\\"{x:1414,y:982,t:1526929971328};\\\", \\\"{x:1428,y:985,t:1526929971344};\\\", \\\"{x:1429,y:985,t:1526929971361};\\\", \\\"{x:1428,y:984,t:1526929971394};\\\", \\\"{x:1422,y:980,t:1526929971411};\\\", \\\"{x:1415,y:977,t:1526929971428};\\\", \\\"{x:1410,y:975,t:1526929971444};\\\", \\\"{x:1409,y:973,t:1526929971461};\\\", \\\"{x:1408,y:973,t:1526929971478};\\\", \\\"{x:1403,y:971,t:1526929971495};\\\", \\\"{x:1398,y:969,t:1526929971511};\\\", \\\"{x:1393,y:969,t:1526929971528};\\\", \\\"{x:1386,y:966,t:1526929971545};\\\", \\\"{x:1382,y:964,t:1526929971561};\\\", \\\"{x:1376,y:964,t:1526929971578};\\\", \\\"{x:1372,y:964,t:1526929971595};\\\", \\\"{x:1367,y:964,t:1526929971611};\\\", \\\"{x:1359,y:964,t:1526929971628};\\\", \\\"{x:1357,y:964,t:1526929971645};\\\", \\\"{x:1355,y:962,t:1526929971770};\\\", \\\"{x:1353,y:961,t:1526929971937};\\\", \\\"{x:1352,y:959,t:1526929971945};\\\", \\\"{x:1350,y:959,t:1526929971961};\\\", \\\"{x:1350,y:958,t:1526929971985};\\\", \\\"{x:1349,y:958,t:1526929972049};\\\", \\\"{x:1349,y:956,t:1526929972065};\\\", \\\"{x:1349,y:955,t:1526929972306};\\\", \\\"{x:1349,y:954,t:1526929972314};\\\", \\\"{x:1349,y:953,t:1526929972338};\\\", \\\"{x:1350,y:952,t:1526929972370};\\\", \\\"{x:1351,y:952,t:1526929972394};\\\", \\\"{x:1351,y:951,t:1526929972402};\\\", \\\"{x:1351,y:950,t:1526929972611};\\\", \\\"{x:1352,y:950,t:1526929972706};\\\", \\\"{x:1353,y:950,t:1526929972714};\\\", \\\"{x:1359,y:954,t:1526929972729};\\\", \\\"{x:1360,y:955,t:1526929972746};\\\", \\\"{x:1361,y:955,t:1526929972763};\\\", \\\"{x:1362,y:955,t:1526929972780};\\\", \\\"{x:1362,y:957,t:1526929972796};\\\", \\\"{x:1362,y:958,t:1526929972818};\\\", \\\"{x:1362,y:959,t:1526929972834};\\\", \\\"{x:1362,y:960,t:1526929972846};\\\", \\\"{x:1362,y:961,t:1526929972866};\\\", \\\"{x:1362,y:962,t:1526929972889};\\\", \\\"{x:1362,y:963,t:1526929972898};\\\", \\\"{x:1362,y:964,t:1526929972954};\\\", \\\"{x:1360,y:965,t:1526929972978};\\\", \\\"{x:1360,y:966,t:1526929972986};\\\", \\\"{x:1359,y:967,t:1526929973009};\\\", \\\"{x:1359,y:968,t:1526929973017};\\\", \\\"{x:1358,y:968,t:1526929973049};\\\", \\\"{x:1357,y:968,t:1526929973062};\\\", \\\"{x:1357,y:969,t:1526929973097};\\\", \\\"{x:1355,y:969,t:1526929973137};\\\", \\\"{x:1353,y:969,t:1526929973266};\\\", \\\"{x:1351,y:969,t:1526929973282};\\\", \\\"{x:1350,y:969,t:1526929973298};\\\", \\\"{x:1348,y:969,t:1526929973314};\\\", \\\"{x:1347,y:969,t:1526929973466};\\\", \\\"{x:1347,y:968,t:1526929973498};\\\", \\\"{x:1345,y:965,t:1526929973513};\\\", \\\"{x:1345,y:963,t:1526929973530};\\\", \\\"{x:1343,y:960,t:1526929973547};\\\", \\\"{x:1343,y:959,t:1526929973564};\\\", \\\"{x:1339,y:955,t:1526929973581};\\\", \\\"{x:1326,y:939,t:1526929973597};\\\", \\\"{x:1318,y:928,t:1526929973614};\\\", \\\"{x:1314,y:922,t:1526929973631};\\\", \\\"{x:1312,y:917,t:1526929973647};\\\", \\\"{x:1309,y:911,t:1526929973665};\\\", \\\"{x:1306,y:903,t:1526929973681};\\\", \\\"{x:1304,y:900,t:1526929973698};\\\", \\\"{x:1302,y:896,t:1526929973714};\\\", \\\"{x:1299,y:892,t:1526929973732};\\\", \\\"{x:1297,y:887,t:1526929973747};\\\", \\\"{x:1297,y:884,t:1526929973764};\\\", \\\"{x:1294,y:880,t:1526929973781};\\\", \\\"{x:1294,y:877,t:1526929973798};\\\", \\\"{x:1292,y:873,t:1526929973814};\\\", \\\"{x:1291,y:871,t:1526929973831};\\\", \\\"{x:1290,y:867,t:1526929973848};\\\", \\\"{x:1289,y:863,t:1526929973864};\\\", \\\"{x:1287,y:859,t:1526929973881};\\\", \\\"{x:1286,y:856,t:1526929973897};\\\", \\\"{x:1285,y:852,t:1526929973914};\\\", \\\"{x:1283,y:849,t:1526929973931};\\\", \\\"{x:1283,y:848,t:1526929973948};\\\", \\\"{x:1281,y:846,t:1526929973965};\\\", \\\"{x:1281,y:847,t:1526929974130};\\\", \\\"{x:1281,y:852,t:1526929974148};\\\", \\\"{x:1283,y:859,t:1526929974165};\\\", \\\"{x:1287,y:868,t:1526929974181};\\\", \\\"{x:1290,y:878,t:1526929974198};\\\", \\\"{x:1291,y:881,t:1526929974215};\\\", \\\"{x:1293,y:889,t:1526929974231};\\\", \\\"{x:1299,y:900,t:1526929974249};\\\", \\\"{x:1307,y:912,t:1526929974266};\\\", \\\"{x:1312,y:919,t:1526929974282};\\\", \\\"{x:1316,y:924,t:1526929974298};\\\", \\\"{x:1319,y:929,t:1526929974315};\\\", \\\"{x:1324,y:933,t:1526929974332};\\\", \\\"{x:1326,y:936,t:1526929974348};\\\", \\\"{x:1326,y:937,t:1526929974365};\\\", \\\"{x:1326,y:938,t:1526929974410};\\\", \\\"{x:1326,y:939,t:1526929974418};\\\", \\\"{x:1326,y:940,t:1526929974434};\\\", \\\"{x:1326,y:941,t:1526929974449};\\\", \\\"{x:1326,y:942,t:1526929974465};\\\", \\\"{x:1326,y:944,t:1526929974546};\\\", \\\"{x:1326,y:945,t:1526929974554};\\\", \\\"{x:1326,y:946,t:1526929974565};\\\", \\\"{x:1326,y:949,t:1526929974593};\\\", \\\"{x:1326,y:950,t:1526929974601};\\\", \\\"{x:1326,y:951,t:1526929974615};\\\", \\\"{x:1326,y:954,t:1526929974632};\\\", \\\"{x:1328,y:957,t:1526929974650};\\\", \\\"{x:1329,y:959,t:1526929974665};\\\", \\\"{x:1331,y:960,t:1526929974682};\\\", \\\"{x:1338,y:962,t:1526929974699};\\\", \\\"{x:1343,y:963,t:1526929974715};\\\", \\\"{x:1350,y:965,t:1526929974732};\\\", \\\"{x:1352,y:966,t:1526929974749};\\\", \\\"{x:1355,y:967,t:1526929974766};\\\", \\\"{x:1356,y:967,t:1526929974826};\\\", \\\"{x:1357,y:967,t:1526929974835};\\\", \\\"{x:1358,y:967,t:1526929974888};\\\", \\\"{x:1359,y:967,t:1526929974899};\\\", \\\"{x:1362,y:964,t:1526929974915};\\\", \\\"{x:1364,y:960,t:1526929974931};\\\", \\\"{x:1368,y:956,t:1526929974948};\\\", \\\"{x:1370,y:950,t:1526929974966};\\\", \\\"{x:1373,y:943,t:1526929974982};\\\", \\\"{x:1374,y:936,t:1526929974999};\\\", \\\"{x:1379,y:929,t:1526929975016};\\\", \\\"{x:1382,y:922,t:1526929975031};\\\", \\\"{x:1391,y:918,t:1526929975048};\\\", \\\"{x:1393,y:916,t:1526929975066};\\\", \\\"{x:1393,y:914,t:1526929975082};\\\", \\\"{x:1393,y:910,t:1526929975099};\\\", \\\"{x:1395,y:908,t:1526929975116};\\\", \\\"{x:1397,y:904,t:1526929975133};\\\", \\\"{x:1399,y:900,t:1526929975148};\\\", \\\"{x:1401,y:896,t:1526929975166};\\\", \\\"{x:1403,y:892,t:1526929975183};\\\", \\\"{x:1404,y:890,t:1526929975199};\\\", \\\"{x:1405,y:889,t:1526929975218};\\\", \\\"{x:1405,y:887,t:1526929975282};\\\", \\\"{x:1406,y:882,t:1526929975322};\\\", \\\"{x:1407,y:882,t:1526929975334};\\\", \\\"{x:1407,y:881,t:1526929975350};\\\", \\\"{x:1407,y:880,t:1526929975366};\\\", \\\"{x:1407,y:879,t:1526929975416};\\\", \\\"{x:1408,y:878,t:1526929975489};\\\", \\\"{x:1409,y:878,t:1526929975512};\\\", \\\"{x:1409,y:879,t:1526929975810};\\\", \\\"{x:1407,y:881,t:1526929975817};\\\", \\\"{x:1402,y:888,t:1526929975839};\\\", \\\"{x:1393,y:897,t:1526929975854};\\\", \\\"{x:1381,y:905,t:1526929975871};\\\", \\\"{x:1371,y:917,t:1526929975888};\\\", \\\"{x:1362,y:924,t:1526929975904};\\\", \\\"{x:1355,y:928,t:1526929975922};\\\", \\\"{x:1348,y:933,t:1526929975938};\\\", \\\"{x:1345,y:937,t:1526929975955};\\\", \\\"{x:1342,y:940,t:1526929975972};\\\", \\\"{x:1339,y:942,t:1526929975989};\\\", \\\"{x:1338,y:943,t:1526929976005};\\\", \\\"{x:1337,y:944,t:1526929976022};\\\", \\\"{x:1336,y:945,t:1526929976038};\\\", \\\"{x:1335,y:945,t:1526929976070};\\\", \\\"{x:1333,y:947,t:1526929976143};\\\", \\\"{x:1333,y:949,t:1526929976190};\\\", \\\"{x:1331,y:950,t:1526929976206};\\\", \\\"{x:1328,y:952,t:1526929976221};\\\", \\\"{x:1327,y:953,t:1526929976239};\\\", \\\"{x:1326,y:954,t:1526929976255};\\\", \\\"{x:1325,y:957,t:1526929976271};\\\", \\\"{x:1325,y:958,t:1526929976288};\\\", \\\"{x:1324,y:959,t:1526929976305};\\\", \\\"{x:1324,y:960,t:1526929976358};\\\", \\\"{x:1323,y:960,t:1526929976390};\\\", \\\"{x:1322,y:961,t:1526929976421};\\\", \\\"{x:1321,y:962,t:1526929976470};\\\", \\\"{x:1319,y:963,t:1526929976486};\\\", \\\"{x:1318,y:964,t:1526929976502};\\\", \\\"{x:1317,y:964,t:1526929976526};\\\", \\\"{x:1316,y:964,t:1526929976655};\\\", \\\"{x:1316,y:963,t:1526929976673};\\\", \\\"{x:1316,y:962,t:1526929976689};\\\", \\\"{x:1316,y:961,t:1526929977158};\\\", \\\"{x:1315,y:960,t:1526929977742};\\\", \\\"{x:1315,y:959,t:1526929977840};\\\", \\\"{x:1315,y:956,t:1526929977858};\\\", \\\"{x:1317,y:951,t:1526929977874};\\\", \\\"{x:1320,y:945,t:1526929977891};\\\", \\\"{x:1324,y:941,t:1526929977908};\\\", \\\"{x:1325,y:938,t:1526929977924};\\\", \\\"{x:1326,y:936,t:1526929977941};\\\", \\\"{x:1328,y:934,t:1526929977957};\\\", \\\"{x:1331,y:932,t:1526929977974};\\\", \\\"{x:1333,y:929,t:1526929977991};\\\", \\\"{x:1334,y:925,t:1526929978008};\\\", \\\"{x:1336,y:922,t:1526929978024};\\\", \\\"{x:1338,y:921,t:1526929978041};\\\", \\\"{x:1338,y:919,t:1526929978058};\\\", \\\"{x:1340,y:915,t:1526929978074};\\\", \\\"{x:1341,y:913,t:1526929978090};\\\", \\\"{x:1343,y:911,t:1526929978108};\\\", \\\"{x:1345,y:909,t:1526929978125};\\\", \\\"{x:1346,y:906,t:1526929978141};\\\", \\\"{x:1349,y:901,t:1526929978158};\\\", \\\"{x:1351,y:897,t:1526929978174};\\\", \\\"{x:1352,y:895,t:1526929978191};\\\", \\\"{x:1352,y:891,t:1526929978208};\\\", \\\"{x:1354,y:887,t:1526929978224};\\\", \\\"{x:1355,y:884,t:1526929978240};\\\", \\\"{x:1356,y:883,t:1526929978257};\\\", \\\"{x:1356,y:882,t:1526929978275};\\\", \\\"{x:1355,y:882,t:1526929978477};\\\", \\\"{x:1354,y:882,t:1526929978491};\\\", \\\"{x:1353,y:884,t:1526929978507};\\\", \\\"{x:1353,y:885,t:1526929978524};\\\", \\\"{x:1352,y:888,t:1526929978541};\\\", \\\"{x:1351,y:890,t:1526929978935};\\\", \\\"{x:1351,y:891,t:1526929978949};\\\", \\\"{x:1351,y:892,t:1526929978959};\\\", \\\"{x:1351,y:893,t:1526929978975};\\\", \\\"{x:1351,y:894,t:1526929978991};\\\", \\\"{x:1352,y:894,t:1526929985758};\\\", \\\"{x:1353,y:893,t:1526929985767};\\\", \\\"{x:1354,y:890,t:1526929985784};\\\", \\\"{x:1356,y:885,t:1526929985801};\\\", \\\"{x:1360,y:874,t:1526929985817};\\\", \\\"{x:1360,y:865,t:1526929985834};\\\", \\\"{x:1361,y:860,t:1526929985851};\\\", \\\"{x:1367,y:848,t:1526929985868};\\\", \\\"{x:1372,y:838,t:1526929985884};\\\", \\\"{x:1375,y:829,t:1526929985901};\\\", \\\"{x:1386,y:802,t:1526929985917};\\\", \\\"{x:1391,y:789,t:1526929985933};\\\", \\\"{x:1396,y:767,t:1526929985950};\\\", \\\"{x:1398,y:750,t:1526929985967};\\\", \\\"{x:1398,y:745,t:1526929985984};\\\", \\\"{x:1398,y:737,t:1526929986001};\\\", \\\"{x:1396,y:731,t:1526929986018};\\\", \\\"{x:1388,y:725,t:1526929986034};\\\", \\\"{x:1372,y:718,t:1526929986050};\\\", \\\"{x:1369,y:712,t:1526929986067};\\\", \\\"{x:1355,y:702,t:1526929986084};\\\", \\\"{x:1341,y:696,t:1526929986101};\\\", \\\"{x:1321,y:688,t:1526929986117};\\\", \\\"{x:1316,y:686,t:1526929986134};\\\", \\\"{x:1315,y:685,t:1526929986151};\\\", \\\"{x:1313,y:685,t:1526929986181};\\\", \\\"{x:1312,y:683,t:1526929986197};\\\", \\\"{x:1311,y:682,t:1526929986229};\\\", \\\"{x:1310,y:680,t:1526929986237};\\\", \\\"{x:1310,y:679,t:1526929986250};\\\", \\\"{x:1306,y:672,t:1526929986267};\\\", \\\"{x:1305,y:665,t:1526929986284};\\\", \\\"{x:1301,y:656,t:1526929986301};\\\", \\\"{x:1301,y:652,t:1526929986318};\\\", \\\"{x:1300,y:645,t:1526929986334};\\\", \\\"{x:1300,y:635,t:1526929986350};\\\", \\\"{x:1300,y:622,t:1526929986368};\\\", \\\"{x:1300,y:617,t:1526929986385};\\\", \\\"{x:1300,y:616,t:1526929986402};\\\", \\\"{x:1300,y:615,t:1526929986417};\\\", \\\"{x:1301,y:615,t:1526929986470};\\\", \\\"{x:1303,y:615,t:1526929986485};\\\", \\\"{x:1304,y:616,t:1526929986501};\\\", \\\"{x:1305,y:617,t:1526929986517};\\\", \\\"{x:1305,y:619,t:1526929986535};\\\", \\\"{x:1305,y:620,t:1526929986552};\\\", \\\"{x:1305,y:622,t:1526929986567};\\\", \\\"{x:1305,y:623,t:1526929986585};\\\", \\\"{x:1305,y:624,t:1526929986601};\\\", \\\"{x:1306,y:624,t:1526929986618};\\\", \\\"{x:1307,y:624,t:1526929986646};\\\", \\\"{x:1308,y:624,t:1526929986653};\\\", \\\"{x:1310,y:626,t:1526929986669};\\\", \\\"{x:1314,y:627,t:1526929986685};\\\", \\\"{x:1314,y:628,t:1526929986701};\\\", \\\"{x:1316,y:628,t:1526929986718};\\\", \\\"{x:1317,y:628,t:1526929986829};\\\", \\\"{x:1318,y:628,t:1526929991046};\\\", \\\"{x:1320,y:628,t:1526929991061};\\\", \\\"{x:1321,y:628,t:1526929991078};\\\", \\\"{x:1323,y:629,t:1526929991094};\\\", \\\"{x:1325,y:629,t:1526929991107};\\\", \\\"{x:1330,y:629,t:1526929991125};\\\", \\\"{x:1334,y:629,t:1526929991141};\\\", \\\"{x:1343,y:630,t:1526929991158};\\\", \\\"{x:1353,y:634,t:1526929991175};\\\", \\\"{x:1371,y:637,t:1526929991191};\\\", \\\"{x:1389,y:642,t:1526929991207};\\\", \\\"{x:1409,y:646,t:1526929991224};\\\", \\\"{x:1427,y:647,t:1526929991240};\\\", \\\"{x:1438,y:647,t:1526929991258};\\\", \\\"{x:1449,y:647,t:1526929991274};\\\", \\\"{x:1451,y:647,t:1526929991290};\\\", \\\"{x:1452,y:647,t:1526929991307};\\\", \\\"{x:1453,y:647,t:1526929991324};\\\", \\\"{x:1458,y:646,t:1526929991340};\\\", \\\"{x:1463,y:646,t:1526929991357};\\\", \\\"{x:1468,y:646,t:1526929991374};\\\", \\\"{x:1469,y:646,t:1526929991390};\\\", \\\"{x:1472,y:645,t:1526929991408};\\\", \\\"{x:1476,y:645,t:1526929991424};\\\", \\\"{x:1477,y:645,t:1526929991441};\\\", \\\"{x:1479,y:645,t:1526929991457};\\\", \\\"{x:1480,y:645,t:1526929991474};\\\", \\\"{x:1481,y:645,t:1526929991490};\\\", \\\"{x:1484,y:644,t:1526929991507};\\\", \\\"{x:1489,y:641,t:1526929991524};\\\", \\\"{x:1493,y:639,t:1526929991541};\\\", \\\"{x:1497,y:637,t:1526929991557};\\\", \\\"{x:1499,y:635,t:1526929991575};\\\", \\\"{x:1500,y:634,t:1526929991590};\\\", \\\"{x:1502,y:634,t:1526929991607};\\\", \\\"{x:1503,y:632,t:1526929991625};\\\", \\\"{x:1505,y:631,t:1526929991717};\\\", \\\"{x:1506,y:631,t:1526929991725};\\\", \\\"{x:1507,y:630,t:1526929991741};\\\", \\\"{x:1508,y:630,t:1526929991757};\\\", \\\"{x:1509,y:630,t:1526929991853};\\\", \\\"{x:1511,y:630,t:1526929991901};\\\", \\\"{x:1512,y:630,t:1526929991917};\\\", \\\"{x:1513,y:630,t:1526929992878};\\\", \\\"{x:1514,y:631,t:1526929992893};\\\", \\\"{x:1514,y:632,t:1526929992918};\\\", \\\"{x:1515,y:633,t:1526929992942};\\\", \\\"{x:1515,y:634,t:1526929992982};\\\", \\\"{x:1515,y:635,t:1526929993054};\\\", \\\"{x:1515,y:636,t:1526929993079};\\\", \\\"{x:1515,y:637,t:1526929993101};\\\", \\\"{x:1515,y:638,t:1526929993110};\\\", \\\"{x:1514,y:641,t:1526929993126};\\\", \\\"{x:1511,y:644,t:1526929993190};\\\", \\\"{x:1510,y:645,t:1526929993198};\\\", \\\"{x:1509,y:646,t:1526929993210};\\\", \\\"{x:1505,y:652,t:1526929993227};\\\", \\\"{x:1502,y:656,t:1526929993243};\\\", \\\"{x:1497,y:663,t:1526929993260};\\\", \\\"{x:1493,y:674,t:1526929993278};\\\", \\\"{x:1492,y:681,t:1526929993294};\\\", \\\"{x:1489,y:690,t:1526929993310};\\\", \\\"{x:1487,y:696,t:1526929993328};\\\", \\\"{x:1485,y:704,t:1526929993344};\\\", \\\"{x:1481,y:709,t:1526929993361};\\\", \\\"{x:1479,y:721,t:1526929993377};\\\", \\\"{x:1475,y:733,t:1526929993394};\\\", \\\"{x:1472,y:748,t:1526929993411};\\\", \\\"{x:1467,y:763,t:1526929993427};\\\", \\\"{x:1467,y:773,t:1526929993444};\\\", \\\"{x:1467,y:781,t:1526929993461};\\\", \\\"{x:1467,y:784,t:1526929993478};\\\", \\\"{x:1466,y:788,t:1526929993494};\\\", \\\"{x:1463,y:794,t:1526929993511};\\\", \\\"{x:1460,y:799,t:1526929993528};\\\", \\\"{x:1456,y:807,t:1526929993544};\\\", \\\"{x:1451,y:814,t:1526929993560};\\\", \\\"{x:1447,y:822,t:1526929993576};\\\", \\\"{x:1439,y:832,t:1526929993594};\\\", \\\"{x:1430,y:843,t:1526929993611};\\\", \\\"{x:1425,y:853,t:1526929993627};\\\", \\\"{x:1421,y:860,t:1526929993644};\\\", \\\"{x:1414,y:868,t:1526929993661};\\\", \\\"{x:1408,y:877,t:1526929993677};\\\", \\\"{x:1403,y:883,t:1526929993694};\\\", \\\"{x:1401,y:887,t:1526929993712};\\\", \\\"{x:1394,y:896,t:1526929993728};\\\", \\\"{x:1390,y:900,t:1526929993745};\\\", \\\"{x:1386,y:905,t:1526929993761};\\\", \\\"{x:1382,y:910,t:1526929993777};\\\", \\\"{x:1381,y:912,t:1526929993794};\\\", \\\"{x:1381,y:915,t:1526929993811};\\\", \\\"{x:1378,y:921,t:1526929993827};\\\", \\\"{x:1374,y:927,t:1526929993844};\\\", \\\"{x:1369,y:933,t:1526929993862};\\\", \\\"{x:1366,y:936,t:1526929993878};\\\", \\\"{x:1363,y:940,t:1526929993894};\\\", \\\"{x:1363,y:941,t:1526929993911};\\\", \\\"{x:1361,y:944,t:1526929993928};\\\", \\\"{x:1359,y:946,t:1526929993944};\\\", \\\"{x:1358,y:948,t:1526929993961};\\\", \\\"{x:1354,y:950,t:1526929993978};\\\", \\\"{x:1347,y:953,t:1526929993994};\\\", \\\"{x:1343,y:955,t:1526929994011};\\\", \\\"{x:1341,y:956,t:1526929994028};\\\", \\\"{x:1340,y:956,t:1526929994044};\\\", \\\"{x:1340,y:957,t:1526929994069};\\\", \\\"{x:1339,y:958,t:1526929994093};\\\", \\\"{x:1338,y:959,t:1526929994111};\\\", \\\"{x:1337,y:959,t:1526929994128};\\\", \\\"{x:1337,y:960,t:1526929994145};\\\", \\\"{x:1338,y:960,t:1526929994622};\\\", \\\"{x:1339,y:960,t:1526929994629};\\\", \\\"{x:1340,y:960,t:1526929994654};\\\", \\\"{x:1342,y:958,t:1526929994686};\\\", \\\"{x:1345,y:957,t:1526929994695};\\\", \\\"{x:1355,y:947,t:1526929994712};\\\", \\\"{x:1370,y:934,t:1526929994729};\\\", \\\"{x:1385,y:921,t:1526929994745};\\\", \\\"{x:1400,y:906,t:1526929994762};\\\", \\\"{x:1414,y:892,t:1526929994779};\\\", \\\"{x:1423,y:878,t:1526929994795};\\\", \\\"{x:1429,y:864,t:1526929994812};\\\", \\\"{x:1438,y:847,t:1526929994829};\\\", \\\"{x:1451,y:833,t:1526929994845};\\\", \\\"{x:1459,y:820,t:1526929994862};\\\", \\\"{x:1468,y:806,t:1526929994880};\\\", \\\"{x:1478,y:795,t:1526929994896};\\\", \\\"{x:1488,y:780,t:1526929994913};\\\", \\\"{x:1494,y:770,t:1526929994929};\\\", \\\"{x:1498,y:757,t:1526929994946};\\\", \\\"{x:1499,y:744,t:1526929994962};\\\", \\\"{x:1499,y:733,t:1526929994978};\\\", \\\"{x:1500,y:724,t:1526929994996};\\\", \\\"{x:1503,y:715,t:1526929995011};\\\", \\\"{x:1507,y:699,t:1526929995028};\\\", \\\"{x:1511,y:689,t:1526929995046};\\\", \\\"{x:1514,y:682,t:1526929995062};\\\", \\\"{x:1515,y:675,t:1526929995079};\\\", \\\"{x:1516,y:669,t:1526929995096};\\\", \\\"{x:1517,y:664,t:1526929995112};\\\", \\\"{x:1520,y:659,t:1526929995128};\\\", \\\"{x:1521,y:653,t:1526929995146};\\\", \\\"{x:1524,y:644,t:1526929995161};\\\", \\\"{x:1525,y:642,t:1526929995179};\\\", \\\"{x:1525,y:639,t:1526929995196};\\\", \\\"{x:1527,y:636,t:1526929995213};\\\", \\\"{x:1527,y:635,t:1526929995229};\\\", \\\"{x:1529,y:634,t:1526929995246};\\\", \\\"{x:1529,y:633,t:1526929995263};\\\", \\\"{x:1530,y:632,t:1526929995279};\\\", \\\"{x:1530,y:631,t:1526929995296};\\\", \\\"{x:1528,y:637,t:1526929995852};\\\", \\\"{x:1523,y:641,t:1526929995862};\\\", \\\"{x:1517,y:657,t:1526929995880};\\\", \\\"{x:1511,y:669,t:1526929995896};\\\", \\\"{x:1503,y:681,t:1526929995912};\\\", \\\"{x:1492,y:696,t:1526929995929};\\\", \\\"{x:1480,y:710,t:1526929995947};\\\", \\\"{x:1472,y:720,t:1526929995962};\\\", \\\"{x:1462,y:735,t:1526929995979};\\\", \\\"{x:1451,y:748,t:1526929995997};\\\", \\\"{x:1446,y:752,t:1526929996013};\\\", \\\"{x:1442,y:755,t:1526929996029};\\\", \\\"{x:1439,y:757,t:1526929996046};\\\", \\\"{x:1438,y:757,t:1526929996077};\\\", \\\"{x:1437,y:758,t:1526929996118};\\\", \\\"{x:1437,y:759,t:1526929996130};\\\", \\\"{x:1431,y:760,t:1526929996146};\\\", \\\"{x:1427,y:762,t:1526929996164};\\\", \\\"{x:1419,y:766,t:1526929996179};\\\", \\\"{x:1416,y:766,t:1526929996197};\\\", \\\"{x:1415,y:766,t:1526929996214};\\\", \\\"{x:1414,y:766,t:1526929996230};\\\", \\\"{x:1411,y:768,t:1526929996247};\\\", \\\"{x:1404,y:768,t:1526929996264};\\\", \\\"{x:1401,y:769,t:1526929996281};\\\", \\\"{x:1393,y:769,t:1526929996297};\\\", \\\"{x:1390,y:770,t:1526929996314};\\\", \\\"{x:1388,y:770,t:1526929996790};\\\", \\\"{x:1388,y:771,t:1526929996910};\\\", \\\"{x:1388,y:772,t:1526929997286};\\\", \\\"{x:1386,y:772,t:1526929997310};\\\", \\\"{x:1384,y:772,t:1526929997318};\\\", \\\"{x:1382,y:772,t:1526929997332};\\\", \\\"{x:1378,y:771,t:1526929997350};\\\", \\\"{x:1373,y:768,t:1526929997365};\\\", \\\"{x:1370,y:767,t:1526929997382};\\\", \\\"{x:1369,y:766,t:1526929997399};\\\", \\\"{x:1368,y:766,t:1526929997438};\\\", \\\"{x:1368,y:765,t:1526929997950};\\\", \\\"{x:1368,y:764,t:1526929998646};\\\", \\\"{x:1368,y:763,t:1526929998669};\\\", \\\"{x:1368,y:762,t:1526929998685};\\\", \\\"{x:1368,y:761,t:1526929998718};\\\", \\\"{x:1369,y:761,t:1526929998750};\\\", \\\"{x:1369,y:760,t:1526929998767};\\\", \\\"{x:1369,y:759,t:1526929998784};\\\", \\\"{x:1370,y:758,t:1526929998801};\\\", \\\"{x:1371,y:758,t:1526929998818};\\\", \\\"{x:1371,y:756,t:1526929998834};\\\", \\\"{x:1372,y:755,t:1526929998854};\\\", \\\"{x:1373,y:755,t:1526929999342};\\\", \\\"{x:1375,y:755,t:1526929999351};\\\", \\\"{x:1382,y:755,t:1526929999369};\\\", \\\"{x:1392,y:758,t:1526929999385};\\\", \\\"{x:1404,y:764,t:1526929999401};\\\", \\\"{x:1423,y:772,t:1526929999418};\\\", \\\"{x:1434,y:782,t:1526929999434};\\\", \\\"{x:1446,y:793,t:1526929999451};\\\", \\\"{x:1465,y:803,t:1526929999468};\\\", \\\"{x:1480,y:809,t:1526929999486};\\\", \\\"{x:1480,y:810,t:1526929999509};\\\", \\\"{x:1481,y:811,t:1526929999550};\\\", \\\"{x:1482,y:811,t:1526929999558};\\\", \\\"{x:1482,y:812,t:1526929999568};\\\", \\\"{x:1483,y:814,t:1526929999586};\\\", \\\"{x:1483,y:818,t:1526929999602};\\\", \\\"{x:1483,y:823,t:1526929999618};\\\", \\\"{x:1482,y:831,t:1526929999636};\\\", \\\"{x:1481,y:838,t:1526929999652};\\\", \\\"{x:1477,y:847,t:1526929999669};\\\", \\\"{x:1469,y:858,t:1526929999685};\\\", \\\"{x:1468,y:862,t:1526929999701};\\\", \\\"{x:1466,y:865,t:1526929999718};\\\", \\\"{x:1465,y:867,t:1526929999735};\\\", \\\"{x:1464,y:869,t:1526929999752};\\\", \\\"{x:1462,y:871,t:1526929999769};\\\", \\\"{x:1462,y:876,t:1526929999786};\\\", \\\"{x:1461,y:881,t:1526929999803};\\\", \\\"{x:1457,y:887,t:1526929999819};\\\", \\\"{x:1457,y:889,t:1526929999835};\\\", \\\"{x:1454,y:894,t:1526929999852};\\\", \\\"{x:1453,y:896,t:1526929999869};\\\", \\\"{x:1451,y:900,t:1526929999885};\\\", \\\"{x:1451,y:901,t:1526929999901};\\\", \\\"{x:1450,y:903,t:1526929999919};\\\", \\\"{x:1450,y:904,t:1526929999935};\\\", \\\"{x:1448,y:907,t:1526929999952};\\\", \\\"{x:1446,y:908,t:1526929999969};\\\", \\\"{x:1442,y:912,t:1526929999985};\\\", \\\"{x:1440,y:916,t:1526930000002};\\\", \\\"{x:1439,y:918,t:1526930000019};\\\", \\\"{x:1439,y:919,t:1526930000035};\\\", \\\"{x:1437,y:922,t:1526930000052};\\\", \\\"{x:1436,y:924,t:1526930000068};\\\", \\\"{x:1435,y:926,t:1526930000085};\\\", \\\"{x:1432,y:928,t:1526930000102};\\\", \\\"{x:1431,y:930,t:1526930000119};\\\", \\\"{x:1429,y:932,t:1526930000135};\\\", \\\"{x:1427,y:936,t:1526930000152};\\\", \\\"{x:1426,y:938,t:1526930000169};\\\", \\\"{x:1425,y:941,t:1526930000186};\\\", \\\"{x:1422,y:944,t:1526930000203};\\\", \\\"{x:1418,y:949,t:1526930000219};\\\", \\\"{x:1418,y:950,t:1526930000236};\\\", \\\"{x:1418,y:952,t:1526930000252};\\\", \\\"{x:1417,y:953,t:1526930000269};\\\", \\\"{x:1417,y:954,t:1526930000287};\\\", \\\"{x:1415,y:955,t:1526930000303};\\\", \\\"{x:1416,y:955,t:1526930000430};\\\", \\\"{x:1418,y:953,t:1526930000437};\\\", \\\"{x:1418,y:952,t:1526930000452};\\\", \\\"{x:1428,y:939,t:1526930000469};\\\", \\\"{x:1438,y:926,t:1526930000486};\\\", \\\"{x:1449,y:916,t:1526930000502};\\\", \\\"{x:1467,y:901,t:1526930000520};\\\", \\\"{x:1474,y:892,t:1526930000536};\\\", \\\"{x:1485,y:882,t:1526930000553};\\\", \\\"{x:1494,y:876,t:1526930000569};\\\", \\\"{x:1497,y:873,t:1526930000586};\\\", \\\"{x:1506,y:864,t:1526930000603};\\\", \\\"{x:1511,y:856,t:1526930000619};\\\", \\\"{x:1515,y:850,t:1526930000636};\\\", \\\"{x:1523,y:839,t:1526930000652};\\\", \\\"{x:1524,y:835,t:1526930000669};\\\", \\\"{x:1526,y:831,t:1526930000686};\\\", \\\"{x:1529,y:828,t:1526930000703};\\\", \\\"{x:1530,y:826,t:1526930000719};\\\", \\\"{x:1530,y:825,t:1526930000789};\\\", \\\"{x:1529,y:825,t:1526930000803};\\\", \\\"{x:1524,y:825,t:1526930000820};\\\", \\\"{x:1517,y:826,t:1526930000837};\\\", \\\"{x:1503,y:827,t:1526930000853};\\\", \\\"{x:1495,y:827,t:1526930000870};\\\", \\\"{x:1492,y:827,t:1526930000886};\\\", \\\"{x:1491,y:827,t:1526930000974};\\\", \\\"{x:1490,y:829,t:1526930001038};\\\", \\\"{x:1489,y:830,t:1526930001069};\\\", \\\"{x:1486,y:832,t:1526930001088};\\\", \\\"{x:1485,y:832,t:1526930001103};\\\", \\\"{x:1482,y:833,t:1526930001121};\\\", \\\"{x:1481,y:833,t:1526930001137};\\\", \\\"{x:1480,y:833,t:1526930001165};\\\", \\\"{x:1480,y:834,t:1526930001189};\\\", \\\"{x:1479,y:834,t:1526930001203};\\\", \\\"{x:1480,y:834,t:1526930001510};\\\", \\\"{x:1481,y:834,t:1526930001566};\\\", \\\"{x:1481,y:833,t:1526930005709};\\\", \\\"{x:1483,y:833,t:1526930008014};\\\", \\\"{x:1494,y:833,t:1526930008030};\\\", \\\"{x:1586,y:864,t:1526930008045};\\\", \\\"{x:1616,y:881,t:1526930008063};\\\", \\\"{x:1636,y:895,t:1526930008080};\\\", \\\"{x:1647,y:904,t:1526930008096};\\\", \\\"{x:1652,y:907,t:1526930008112};\\\", \\\"{x:1652,y:908,t:1526930008130};\\\", \\\"{x:1652,y:909,t:1526930008182};\\\", \\\"{x:1652,y:910,t:1526930008230};\\\", \\\"{x:1652,y:911,t:1526930008246};\\\", \\\"{x:1652,y:913,t:1526930008262};\\\", \\\"{x:1652,y:916,t:1526930008280};\\\", \\\"{x:1648,y:919,t:1526930008297};\\\", \\\"{x:1646,y:924,t:1526930008313};\\\", \\\"{x:1636,y:928,t:1526930008329};\\\", \\\"{x:1631,y:931,t:1526930008347};\\\", \\\"{x:1630,y:931,t:1526930008362};\\\", \\\"{x:1629,y:932,t:1526930008380};\\\", \\\"{x:1627,y:933,t:1526930008397};\\\", \\\"{x:1626,y:935,t:1526930008413};\\\", \\\"{x:1624,y:936,t:1526930008429};\\\", \\\"{x:1622,y:937,t:1526930008446};\\\", \\\"{x:1620,y:938,t:1526930008463};\\\", \\\"{x:1617,y:940,t:1526930008480};\\\", \\\"{x:1616,y:941,t:1526930008497};\\\", \\\"{x:1614,y:942,t:1526930008513};\\\", \\\"{x:1613,y:943,t:1526930008573};\\\", \\\"{x:1612,y:945,t:1526930008589};\\\", \\\"{x:1611,y:945,t:1526930008597};\\\", \\\"{x:1610,y:946,t:1526930008613};\\\", \\\"{x:1609,y:948,t:1526930008630};\\\", \\\"{x:1608,y:949,t:1526930008647};\\\", \\\"{x:1608,y:950,t:1526930008733};\\\", \\\"{x:1607,y:947,t:1526930009006};\\\", \\\"{x:1606,y:945,t:1526930009014};\\\", \\\"{x:1604,y:938,t:1526930009031};\\\", \\\"{x:1600,y:928,t:1526930009046};\\\", \\\"{x:1597,y:919,t:1526930009064};\\\", \\\"{x:1595,y:915,t:1526930009081};\\\", \\\"{x:1591,y:907,t:1526930009097};\\\", \\\"{x:1588,y:902,t:1526930009113};\\\", \\\"{x:1583,y:897,t:1526930009130};\\\", \\\"{x:1578,y:888,t:1526930009147};\\\", \\\"{x:1571,y:878,t:1526930009164};\\\", \\\"{x:1567,y:875,t:1526930009180};\\\", \\\"{x:1560,y:862,t:1526930009197};\\\", \\\"{x:1555,y:856,t:1526930009213};\\\", \\\"{x:1551,y:851,t:1526930009230};\\\", \\\"{x:1546,y:844,t:1526930009248};\\\", \\\"{x:1541,y:837,t:1526930009264};\\\", \\\"{x:1534,y:827,t:1526930009280};\\\", \\\"{x:1528,y:818,t:1526930009298};\\\", \\\"{x:1526,y:816,t:1526930009313};\\\", \\\"{x:1519,y:809,t:1526930009330};\\\", \\\"{x:1516,y:805,t:1526930009348};\\\", \\\"{x:1514,y:800,t:1526930009364};\\\", \\\"{x:1507,y:788,t:1526930009381};\\\", \\\"{x:1503,y:780,t:1526930009397};\\\", \\\"{x:1501,y:773,t:1526930009414};\\\", \\\"{x:1496,y:762,t:1526930009431};\\\", \\\"{x:1494,y:757,t:1526930009447};\\\", \\\"{x:1492,y:752,t:1526930009464};\\\", \\\"{x:1492,y:749,t:1526930009480};\\\", \\\"{x:1489,y:741,t:1526930009497};\\\", \\\"{x:1484,y:734,t:1526930009515};\\\", \\\"{x:1481,y:728,t:1526930009531};\\\", \\\"{x:1477,y:720,t:1526930009548};\\\", \\\"{x:1472,y:709,t:1526930009565};\\\", \\\"{x:1468,y:700,t:1526930009581};\\\", \\\"{x:1464,y:689,t:1526930009597};\\\", \\\"{x:1461,y:680,t:1526930009615};\\\", \\\"{x:1453,y:669,t:1526930009630};\\\", \\\"{x:1447,y:659,t:1526930009647};\\\", \\\"{x:1443,y:654,t:1526930009665};\\\", \\\"{x:1438,y:647,t:1526930009682};\\\", \\\"{x:1433,y:640,t:1526930009697};\\\", \\\"{x:1425,y:630,t:1526930009714};\\\", \\\"{x:1421,y:623,t:1526930009732};\\\", \\\"{x:1416,y:614,t:1526930009747};\\\", \\\"{x:1412,y:604,t:1526930009765};\\\", \\\"{x:1410,y:600,t:1526930009781};\\\", \\\"{x:1406,y:594,t:1526930009798};\\\", \\\"{x:1404,y:591,t:1526930009814};\\\", \\\"{x:1403,y:588,t:1526930009832};\\\", \\\"{x:1403,y:586,t:1526930009848};\\\", \\\"{x:1402,y:583,t:1526930009865};\\\", \\\"{x:1402,y:580,t:1526930009882};\\\", \\\"{x:1401,y:576,t:1526930009898};\\\", \\\"{x:1401,y:574,t:1526930009914};\\\", \\\"{x:1400,y:571,t:1526930009931};\\\", \\\"{x:1400,y:569,t:1526930009949};\\\", \\\"{x:1399,y:566,t:1526930009965};\\\", \\\"{x:1399,y:564,t:1526930010030};\\\", \\\"{x:1399,y:563,t:1526930010045};\\\", \\\"{x:1399,y:562,t:1526930010053};\\\", \\\"{x:1399,y:561,t:1526930010094};\\\", \\\"{x:1400,y:561,t:1526930010254};\\\", \\\"{x:1401,y:561,t:1526930010269};\\\", \\\"{x:1402,y:561,t:1526930010282};\\\", \\\"{x:1403,y:561,t:1526930010299};\\\", \\\"{x:1404,y:561,t:1526930010317};\\\", \\\"{x:1405,y:561,t:1526930010332};\\\", \\\"{x:1411,y:564,t:1526930010349};\\\", \\\"{x:1417,y:567,t:1526930010365};\\\", \\\"{x:1419,y:568,t:1526930010382};\\\", \\\"{x:1421,y:569,t:1526930010399};\\\", \\\"{x:1425,y:571,t:1526930010416};\\\", \\\"{x:1426,y:572,t:1526930010432};\\\", \\\"{x:1428,y:572,t:1526930010485};\\\", \\\"{x:1428,y:571,t:1526930010717};\\\", \\\"{x:1427,y:571,t:1526930010749};\\\", \\\"{x:1425,y:571,t:1526930010766};\\\", \\\"{x:1424,y:570,t:1526930010782};\\\", \\\"{x:1422,y:570,t:1526930010800};\\\", \\\"{x:1420,y:570,t:1526930010816};\\\", \\\"{x:1419,y:569,t:1526930010833};\\\", \\\"{x:1418,y:568,t:1526930010849};\\\", \\\"{x:1417,y:568,t:1526930010865};\\\", \\\"{x:1416,y:567,t:1526930011101};\\\", \\\"{x:1416,y:566,t:1526930011229};\\\", \\\"{x:1416,y:565,t:1526930013454};\\\", \\\"{x:1415,y:565,t:1526930015253};\\\", \\\"{x:1413,y:565,t:1526930015261};\\\", \\\"{x:1413,y:567,t:1526930015272};\\\", \\\"{x:1412,y:569,t:1526930015290};\\\", \\\"{x:1409,y:573,t:1526930015305};\\\", \\\"{x:1407,y:580,t:1526930015322};\\\", \\\"{x:1405,y:586,t:1526930015339};\\\", \\\"{x:1405,y:592,t:1526930015355};\\\", \\\"{x:1403,y:600,t:1526930015372};\\\", \\\"{x:1399,y:615,t:1526930015389};\\\", \\\"{x:1396,y:621,t:1526930015405};\\\", \\\"{x:1393,y:625,t:1526930015422};\\\", \\\"{x:1391,y:631,t:1526930015440};\\\", \\\"{x:1388,y:639,t:1526930015455};\\\", \\\"{x:1383,y:648,t:1526930015472};\\\", \\\"{x:1377,y:660,t:1526930015489};\\\", \\\"{x:1377,y:667,t:1526930015505};\\\", \\\"{x:1373,y:675,t:1526930015522};\\\", \\\"{x:1372,y:679,t:1526930015539};\\\", \\\"{x:1372,y:681,t:1526930015556};\\\", \\\"{x:1370,y:684,t:1526930015572};\\\", \\\"{x:1366,y:688,t:1526930015589};\\\", \\\"{x:1362,y:694,t:1526930015605};\\\", \\\"{x:1360,y:699,t:1526930015622};\\\", \\\"{x:1357,y:704,t:1526930015640};\\\", \\\"{x:1354,y:708,t:1526930015656};\\\", \\\"{x:1353,y:709,t:1526930015672};\\\", \\\"{x:1352,y:709,t:1526930015693};\\\", \\\"{x:1352,y:710,t:1526930015710};\\\", \\\"{x:1351,y:711,t:1526930015722};\\\", \\\"{x:1349,y:714,t:1526930015739};\\\", \\\"{x:1348,y:716,t:1526930015756};\\\", \\\"{x:1342,y:723,t:1526930015772};\\\", \\\"{x:1340,y:729,t:1526930015789};\\\", \\\"{x:1338,y:730,t:1526930015806};\\\", \\\"{x:1336,y:734,t:1526930015823};\\\", \\\"{x:1335,y:736,t:1526930015840};\\\", \\\"{x:1332,y:739,t:1526930015856};\\\", \\\"{x:1329,y:743,t:1526930015872};\\\", \\\"{x:1327,y:747,t:1526930015888};\\\", \\\"{x:1320,y:756,t:1526930015906};\\\", \\\"{x:1314,y:764,t:1526930015923};\\\", \\\"{x:1311,y:768,t:1526930015939};\\\", \\\"{x:1306,y:774,t:1526930015956};\\\", \\\"{x:1301,y:785,t:1526930015973};\\\", \\\"{x:1296,y:791,t:1526930015989};\\\", \\\"{x:1292,y:794,t:1526930016005};\\\", \\\"{x:1290,y:796,t:1526930016023};\\\", \\\"{x:1287,y:800,t:1526930016040};\\\", \\\"{x:1286,y:804,t:1526930016056};\\\", \\\"{x:1284,y:809,t:1526930016073};\\\", \\\"{x:1282,y:813,t:1526930016089};\\\", \\\"{x:1280,y:818,t:1526930016105};\\\", \\\"{x:1279,y:819,t:1526930016122};\\\", \\\"{x:1278,y:822,t:1526930016139};\\\", \\\"{x:1277,y:824,t:1526930016155};\\\", \\\"{x:1272,y:830,t:1526930016172};\\\", \\\"{x:1271,y:833,t:1526930016189};\\\", \\\"{x:1269,y:836,t:1526930016206};\\\", \\\"{x:1267,y:838,t:1526930016223};\\\", \\\"{x:1265,y:840,t:1526930016241};\\\", \\\"{x:1265,y:843,t:1526930016255};\\\", \\\"{x:1264,y:844,t:1526930016272};\\\", \\\"{x:1261,y:845,t:1526930016289};\\\", \\\"{x:1259,y:848,t:1526930016305};\\\", \\\"{x:1257,y:852,t:1526930016322};\\\", \\\"{x:1254,y:855,t:1526930016339};\\\", \\\"{x:1249,y:858,t:1526930016356};\\\", \\\"{x:1249,y:862,t:1526930016372};\\\", \\\"{x:1247,y:864,t:1526930016389};\\\", \\\"{x:1247,y:866,t:1526930016406};\\\", \\\"{x:1244,y:869,t:1526930016422};\\\", \\\"{x:1244,y:873,t:1526930016439};\\\", \\\"{x:1243,y:874,t:1526930016457};\\\", \\\"{x:1242,y:876,t:1526930016473};\\\", \\\"{x:1242,y:877,t:1526930016490};\\\", \\\"{x:1240,y:882,t:1526930016507};\\\", \\\"{x:1238,y:888,t:1526930016523};\\\", \\\"{x:1237,y:892,t:1526930016539};\\\", \\\"{x:1237,y:897,t:1526930016556};\\\", \\\"{x:1235,y:906,t:1526930016573};\\\", \\\"{x:1235,y:912,t:1526930016590};\\\", \\\"{x:1233,y:916,t:1526930016606};\\\", \\\"{x:1231,y:923,t:1526930016624};\\\", \\\"{x:1228,y:929,t:1526930016640};\\\", \\\"{x:1224,y:936,t:1526930016657};\\\", \\\"{x:1222,y:939,t:1526930016673};\\\", \\\"{x:1220,y:944,t:1526930016690};\\\", \\\"{x:1217,y:948,t:1526930016707};\\\", \\\"{x:1215,y:951,t:1526930016724};\\\", \\\"{x:1212,y:956,t:1526930016740};\\\", \\\"{x:1209,y:960,t:1526930016757};\\\", \\\"{x:1207,y:962,t:1526930016774};\\\", \\\"{x:1206,y:964,t:1526930016789};\\\", \\\"{x:1206,y:965,t:1526930016829};\\\", \\\"{x:1206,y:966,t:1526930016840};\\\", \\\"{x:1205,y:967,t:1526930016857};\\\", \\\"{x:1205,y:968,t:1526930016874};\\\", \\\"{x:1205,y:969,t:1526930017950};\\\", \\\"{x:1206,y:969,t:1526930019221};\\\", \\\"{x:1207,y:969,t:1526930019253};\\\", \\\"{x:1208,y:969,t:1526930020510};\\\", \\\"{x:1208,y:968,t:1526930020846};\\\", \\\"{x:1208,y:967,t:1526930022909};\\\", \\\"{x:1208,y:966,t:1526930023165};\\\", \\\"{x:1208,y:965,t:1526930023182};\\\", \\\"{x:1219,y:960,t:1526930023198};\\\", \\\"{x:1240,y:960,t:1526930023215};\\\", \\\"{x:1347,y:975,t:1526930023232};\\\", \\\"{x:1529,y:1002,t:1526930023249};\\\", \\\"{x:1748,y:1032,t:1526930023265};\\\", \\\"{x:1919,y:1057,t:1526930023282};\\\", \\\"{x:1919,y:1073,t:1526930023299};\\\", \\\"{x:1919,y:1077,t:1526930023315};\\\", \\\"{x:1919,y:1075,t:1526930023388};\\\", \\\"{x:1919,y:1071,t:1526930023403};\\\", \\\"{x:1918,y:1069,t:1526930023415};\\\", \\\"{x:1915,y:1065,t:1526930023430};\\\", \\\"{x:1910,y:1061,t:1526930023448};\\\", \\\"{x:1900,y:1058,t:1526930023465};\\\", \\\"{x:1886,y:1055,t:1526930023481};\\\", \\\"{x:1819,y:1044,t:1526930023499};\\\", \\\"{x:1734,y:1035,t:1526930023516};\\\", \\\"{x:1652,y:1016,t:1526930023532};\\\", \\\"{x:1596,y:997,t:1526930023549};\\\", \\\"{x:1582,y:993,t:1526930023565};\\\", \\\"{x:1580,y:991,t:1526930023581};\\\", \\\"{x:1580,y:990,t:1526930023598};\\\", \\\"{x:1580,y:989,t:1526930023627};\\\", \\\"{x:1580,y:987,t:1526930023732};\\\", \\\"{x:1578,y:986,t:1526930023748};\\\", \\\"{x:1578,y:983,t:1526930023766};\\\", \\\"{x:1578,y:980,t:1526930023783};\\\", \\\"{x:1579,y:980,t:1526930023798};\\\", \\\"{x:1579,y:978,t:1526930023815};\\\", \\\"{x:1579,y:977,t:1526930023833};\\\", \\\"{x:1582,y:973,t:1526930023848};\\\", \\\"{x:1583,y:971,t:1526930023866};\\\", \\\"{x:1584,y:968,t:1526930023883};\\\", \\\"{x:1585,y:967,t:1526930023900};\\\", \\\"{x:1586,y:964,t:1526930023917};\\\", \\\"{x:1589,y:963,t:1526930023933};\\\", \\\"{x:1592,y:960,t:1526930023950};\\\", \\\"{x:1593,y:957,t:1526930023966};\\\", \\\"{x:1595,y:956,t:1526930023983};\\\", \\\"{x:1596,y:954,t:1526930023999};\\\", \\\"{x:1598,y:952,t:1526930024016};\\\", \\\"{x:1599,y:950,t:1526930024033};\\\", \\\"{x:1601,y:948,t:1526930024050};\\\", \\\"{x:1601,y:946,t:1526930024066};\\\", \\\"{x:1603,y:942,t:1526930024083};\\\", \\\"{x:1603,y:939,t:1526930024100};\\\", \\\"{x:1603,y:934,t:1526930024116};\\\", \\\"{x:1603,y:924,t:1526930024133};\\\", \\\"{x:1603,y:917,t:1526930024149};\\\", \\\"{x:1603,y:911,t:1526930024166};\\\", \\\"{x:1600,y:902,t:1526930024183};\\\", \\\"{x:1593,y:888,t:1526930024200};\\\", \\\"{x:1586,y:874,t:1526930024216};\\\", \\\"{x:1575,y:860,t:1526930024233};\\\", \\\"{x:1563,y:845,t:1526930024250};\\\", \\\"{x:1548,y:831,t:1526930024266};\\\", \\\"{x:1546,y:827,t:1526930024283};\\\", \\\"{x:1537,y:816,t:1526930024300};\\\", \\\"{x:1533,y:813,t:1526930024316};\\\", \\\"{x:1527,y:806,t:1526930024333};\\\", \\\"{x:1523,y:801,t:1526930024350};\\\", \\\"{x:1518,y:798,t:1526930024366};\\\", \\\"{x:1516,y:796,t:1526930024383};\\\", \\\"{x:1514,y:795,t:1526930024400};\\\", \\\"{x:1512,y:795,t:1526930024416};\\\", \\\"{x:1511,y:794,t:1526930024444};\\\", \\\"{x:1511,y:793,t:1526930024469};\\\", \\\"{x:1509,y:791,t:1526930024483};\\\", \\\"{x:1508,y:790,t:1526930024500};\\\", \\\"{x:1507,y:787,t:1526930024517};\\\", \\\"{x:1503,y:781,t:1526930024533};\\\", \\\"{x:1500,y:778,t:1526930024550};\\\", \\\"{x:1497,y:773,t:1526930024566};\\\", \\\"{x:1495,y:768,t:1526930024583};\\\", \\\"{x:1493,y:764,t:1526930024600};\\\", \\\"{x:1492,y:758,t:1526930024617};\\\", \\\"{x:1490,y:754,t:1526930024634};\\\", \\\"{x:1487,y:747,t:1526930024650};\\\", \\\"{x:1485,y:740,t:1526930024667};\\\", \\\"{x:1485,y:733,t:1526930024683};\\\", \\\"{x:1483,y:721,t:1526930024700};\\\", \\\"{x:1475,y:710,t:1526930024717};\\\", \\\"{x:1472,y:702,t:1526930024733};\\\", \\\"{x:1470,y:694,t:1526930024750};\\\", \\\"{x:1467,y:688,t:1526930024767};\\\", \\\"{x:1462,y:681,t:1526930024783};\\\", \\\"{x:1461,y:676,t:1526930024800};\\\", \\\"{x:1458,y:673,t:1526930024817};\\\", \\\"{x:1457,y:668,t:1526930024834};\\\", \\\"{x:1454,y:663,t:1526930024850};\\\", \\\"{x:1451,y:658,t:1526930024867};\\\", \\\"{x:1451,y:655,t:1526930024883};\\\", \\\"{x:1448,y:652,t:1526930024900};\\\", \\\"{x:1446,y:646,t:1526930024917};\\\", \\\"{x:1443,y:642,t:1526930024933};\\\", \\\"{x:1439,y:637,t:1526930024950};\\\", \\\"{x:1436,y:631,t:1526930024967};\\\", \\\"{x:1431,y:624,t:1526930024983};\\\", \\\"{x:1427,y:619,t:1526930025000};\\\", \\\"{x:1423,y:613,t:1526930025017};\\\", \\\"{x:1421,y:611,t:1526930025033};\\\", \\\"{x:1420,y:610,t:1526930025050};\\\", \\\"{x:1419,y:610,t:1526930025067};\\\", \\\"{x:1416,y:606,t:1526930025084};\\\", \\\"{x:1415,y:602,t:1526930025100};\\\", \\\"{x:1413,y:597,t:1526930025117};\\\", \\\"{x:1412,y:593,t:1526930025134};\\\", \\\"{x:1411,y:590,t:1526930025150};\\\", \\\"{x:1411,y:585,t:1526930025167};\\\", \\\"{x:1411,y:583,t:1526930025184};\\\", \\\"{x:1411,y:582,t:1526930025201};\\\", \\\"{x:1411,y:579,t:1526930025217};\\\", \\\"{x:1411,y:576,t:1526930025234};\\\", \\\"{x:1411,y:574,t:1526930025250};\\\", \\\"{x:1411,y:573,t:1526930025269};\\\", \\\"{x:1411,y:572,t:1526930025293};\\\", \\\"{x:1411,y:571,t:1526930025333};\\\", \\\"{x:1411,y:570,t:1526930025412};\\\", \\\"{x:1411,y:573,t:1526930025420};\\\", \\\"{x:1414,y:579,t:1526930025434};\\\", \\\"{x:1426,y:600,t:1526930025449};\\\", \\\"{x:1442,y:625,t:1526930025467};\\\", \\\"{x:1463,y:646,t:1526930025484};\\\", \\\"{x:1584,y:729,t:1526930025500};\\\", \\\"{x:1701,y:788,t:1526930025516};\\\", \\\"{x:1766,y:818,t:1526930025534};\\\", \\\"{x:1793,y:835,t:1526930025550};\\\", \\\"{x:1812,y:849,t:1526930025567};\\\", \\\"{x:1816,y:853,t:1526930025584};\\\", \\\"{x:1816,y:854,t:1526930025604};\\\", \\\"{x:1816,y:856,t:1526930025617};\\\", \\\"{x:1814,y:860,t:1526930025634};\\\", \\\"{x:1809,y:863,t:1526930025651};\\\", \\\"{x:1804,y:869,t:1526930025667};\\\", \\\"{x:1788,y:883,t:1526930025684};\\\", \\\"{x:1774,y:894,t:1526930025700};\\\", \\\"{x:1760,y:903,t:1526930025717};\\\", \\\"{x:1745,y:916,t:1526930025734};\\\", \\\"{x:1730,y:924,t:1526930025750};\\\", \\\"{x:1717,y:933,t:1526930025766};\\\", \\\"{x:1706,y:938,t:1526930025783};\\\", \\\"{x:1696,y:944,t:1526930025801};\\\", \\\"{x:1692,y:948,t:1526930025817};\\\", \\\"{x:1688,y:954,t:1526930025833};\\\", \\\"{x:1683,y:962,t:1526930025851};\\\", \\\"{x:1675,y:972,t:1526930025867};\\\", \\\"{x:1662,y:983,t:1526930025884};\\\", \\\"{x:1656,y:988,t:1526930025900};\\\", \\\"{x:1647,y:991,t:1526930025916};\\\", \\\"{x:1642,y:993,t:1526930025933};\\\", \\\"{x:1640,y:994,t:1526930025951};\\\", \\\"{x:1639,y:994,t:1526930026069};\\\", \\\"{x:1633,y:983,t:1526930026085};\\\", \\\"{x:1630,y:974,t:1526930026101};\\\", \\\"{x:1627,y:963,t:1526930026118};\\\", \\\"{x:1619,y:952,t:1526930026134};\\\", \\\"{x:1612,y:941,t:1526930026151};\\\", \\\"{x:1608,y:934,t:1526930026168};\\\", \\\"{x:1605,y:933,t:1526930026184};\\\", \\\"{x:1602,y:923,t:1526930026200};\\\", \\\"{x:1599,y:919,t:1526930026218};\\\", \\\"{x:1598,y:919,t:1526930026251};\\\", \\\"{x:1596,y:919,t:1526930026284};\\\", \\\"{x:1593,y:919,t:1526930026300};\\\", \\\"{x:1592,y:919,t:1526930026324};\\\", \\\"{x:1592,y:920,t:1526930026493};\\\", \\\"{x:1592,y:922,t:1526930026501};\\\", \\\"{x:1595,y:926,t:1526930026518};\\\", \\\"{x:1596,y:928,t:1526930026535};\\\", \\\"{x:1599,y:930,t:1526930026551};\\\", \\\"{x:1602,y:933,t:1526930026568};\\\", \\\"{x:1605,y:935,t:1526930026584};\\\", \\\"{x:1610,y:937,t:1526930026601};\\\", \\\"{x:1614,y:939,t:1526930026618};\\\", \\\"{x:1621,y:941,t:1526930026635};\\\", \\\"{x:1627,y:943,t:1526930026651};\\\", \\\"{x:1628,y:944,t:1526930026668};\\\", \\\"{x:1633,y:945,t:1526930026684};\\\", \\\"{x:1635,y:945,t:1526930026701};\\\", \\\"{x:1639,y:945,t:1526930026717};\\\", \\\"{x:1641,y:945,t:1526930026734};\\\", \\\"{x:1643,y:944,t:1526930026750};\\\", \\\"{x:1644,y:943,t:1526930026768};\\\", \\\"{x:1644,y:942,t:1526930026785};\\\", \\\"{x:1644,y:941,t:1526930026801};\\\", \\\"{x:1644,y:940,t:1526930026821};\\\", \\\"{x:1644,y:939,t:1526930026835};\\\", \\\"{x:1644,y:938,t:1526930026851};\\\", \\\"{x:1644,y:937,t:1526930026884};\\\", \\\"{x:1644,y:934,t:1526930026901};\\\", \\\"{x:1644,y:933,t:1526930026918};\\\", \\\"{x:1645,y:927,t:1526930026935};\\\", \\\"{x:1646,y:921,t:1526930026952};\\\", \\\"{x:1649,y:915,t:1526930026968};\\\", \\\"{x:1650,y:908,t:1526930026985};\\\", \\\"{x:1651,y:908,t:1526930027003};\\\", \\\"{x:1655,y:899,t:1526930027019};\\\", \\\"{x:1657,y:892,t:1526930027035};\\\", \\\"{x:1660,y:868,t:1526930027052};\\\", \\\"{x:1661,y:860,t:1526930027068};\\\", \\\"{x:1664,y:837,t:1526930027085};\\\", \\\"{x:1664,y:831,t:1526930027102};\\\", \\\"{x:1665,y:827,t:1526930027118};\\\", \\\"{x:1666,y:822,t:1526930027135};\\\", \\\"{x:1666,y:820,t:1526930027157};\\\", \\\"{x:1666,y:819,t:1526930027169};\\\", \\\"{x:1667,y:818,t:1526930027185};\\\", \\\"{x:1669,y:816,t:1526930027202};\\\", \\\"{x:1670,y:813,t:1526930027219};\\\", \\\"{x:1672,y:810,t:1526930027235};\\\", \\\"{x:1673,y:805,t:1526930027252};\\\", \\\"{x:1675,y:803,t:1526930027269};\\\", \\\"{x:1676,y:802,t:1526930027285};\\\", \\\"{x:1678,y:800,t:1526930027302};\\\", \\\"{x:1679,y:798,t:1526930027318};\\\", \\\"{x:1681,y:797,t:1526930027336};\\\", \\\"{x:1683,y:796,t:1526930027352};\\\", \\\"{x:1684,y:795,t:1526930027369};\\\", \\\"{x:1687,y:793,t:1526930027385};\\\", \\\"{x:1689,y:792,t:1526930027402};\\\", \\\"{x:1692,y:788,t:1526930027419};\\\", \\\"{x:1695,y:787,t:1526930027435};\\\", \\\"{x:1702,y:784,t:1526930027453};\\\", \\\"{x:1706,y:781,t:1526930027469};\\\", \\\"{x:1707,y:780,t:1526930027485};\\\", \\\"{x:1709,y:778,t:1526930027502};\\\", \\\"{x:1710,y:778,t:1526930027519};\\\", \\\"{x:1712,y:775,t:1526930027535};\\\", \\\"{x:1713,y:774,t:1526930027552};\\\", \\\"{x:1714,y:773,t:1526930027569};\\\", \\\"{x:1714,y:771,t:1526930027585};\\\", \\\"{x:1717,y:769,t:1526930027602};\\\", \\\"{x:1717,y:768,t:1526930027619};\\\", \\\"{x:1719,y:765,t:1526930027635};\\\", \\\"{x:1721,y:761,t:1526930027652};\\\", \\\"{x:1721,y:759,t:1526930027669};\\\", \\\"{x:1723,y:757,t:1526930027686};\\\", \\\"{x:1723,y:755,t:1526930027702};\\\", \\\"{x:1725,y:752,t:1526930027719};\\\", \\\"{x:1726,y:749,t:1526930027736};\\\", \\\"{x:1727,y:745,t:1526930027752};\\\", \\\"{x:1728,y:742,t:1526930027769};\\\", \\\"{x:1728,y:741,t:1526930027785};\\\", \\\"{x:1729,y:740,t:1526930027802};\\\", \\\"{x:1729,y:739,t:1526930027819};\\\", \\\"{x:1728,y:740,t:1526930028533};\\\", \\\"{x:1726,y:743,t:1526930028549};\\\", \\\"{x:1725,y:743,t:1526930028572};\\\", \\\"{x:1725,y:744,t:1526930028586};\\\", \\\"{x:1724,y:745,t:1526930028605};\\\", \\\"{x:1724,y:746,t:1526930028621};\\\", \\\"{x:1724,y:747,t:1526930028644};\\\", \\\"{x:1722,y:748,t:1526930028653};\\\", \\\"{x:1721,y:750,t:1526930028669};\\\", \\\"{x:1720,y:752,t:1526930028686};\\\", \\\"{x:1718,y:755,t:1526930028704};\\\", \\\"{x:1716,y:757,t:1526930028720};\\\", \\\"{x:1716,y:758,t:1526930028737};\\\", \\\"{x:1714,y:762,t:1526930028753};\\\", \\\"{x:1711,y:765,t:1526930028770};\\\", \\\"{x:1709,y:767,t:1526930028786};\\\", \\\"{x:1705,y:772,t:1526930028803};\\\", \\\"{x:1700,y:777,t:1526930028821};\\\", \\\"{x:1693,y:782,t:1526930028837};\\\", \\\"{x:1687,y:787,t:1526930028853};\\\", \\\"{x:1685,y:790,t:1526930028871};\\\", \\\"{x:1681,y:793,t:1526930028886};\\\", \\\"{x:1677,y:796,t:1526930028903};\\\", \\\"{x:1674,y:797,t:1526930028920};\\\", \\\"{x:1671,y:800,t:1526930028937};\\\", \\\"{x:1667,y:803,t:1526930028954};\\\", \\\"{x:1664,y:805,t:1526930028971};\\\", \\\"{x:1661,y:809,t:1526930028986};\\\", \\\"{x:1658,y:811,t:1526930029003};\\\", \\\"{x:1640,y:827,t:1526930029021};\\\", \\\"{x:1626,y:838,t:1526930029037};\\\", \\\"{x:1607,y:851,t:1526930029053};\\\", \\\"{x:1589,y:862,t:1526930029071};\\\", \\\"{x:1577,y:872,t:1526930029086};\\\", \\\"{x:1555,y:884,t:1526930029104};\\\", \\\"{x:1531,y:898,t:1526930029120};\\\", \\\"{x:1509,y:909,t:1526930029136};\\\", \\\"{x:1483,y:922,t:1526930029154};\\\", \\\"{x:1466,y:927,t:1526930029171};\\\", \\\"{x:1453,y:929,t:1526930029186};\\\", \\\"{x:1449,y:931,t:1526930029203};\\\", \\\"{x:1439,y:931,t:1526930029221};\\\", \\\"{x:1433,y:931,t:1526930029236};\\\", \\\"{x:1430,y:931,t:1526930029254};\\\", \\\"{x:1429,y:931,t:1526930029270};\\\", \\\"{x:1428,y:931,t:1526930029287};\\\", \\\"{x:1425,y:931,t:1526930029303};\\\", \\\"{x:1417,y:934,t:1526930029320};\\\", \\\"{x:1411,y:935,t:1526930029341};\\\", \\\"{x:1403,y:938,t:1526930029354};\\\", \\\"{x:1399,y:941,t:1526930029370};\\\", \\\"{x:1386,y:945,t:1526930029387};\\\", \\\"{x:1370,y:950,t:1526930029404};\\\", \\\"{x:1349,y:957,t:1526930029420};\\\", \\\"{x:1310,y:968,t:1526930029437};\\\", \\\"{x:1288,y:973,t:1526930029454};\\\", \\\"{x:1277,y:975,t:1526930029470};\\\", \\\"{x:1274,y:976,t:1526930029487};\\\", \\\"{x:1272,y:976,t:1526930029629};\\\", \\\"{x:1271,y:976,t:1526930029637};\\\", \\\"{x:1269,y:976,t:1526930029653};\\\", \\\"{x:1268,y:976,t:1526930029781};\\\", \\\"{x:1267,y:976,t:1526930029845};\\\", \\\"{x:1267,y:974,t:1526930029854};\\\", \\\"{x:1267,y:968,t:1526930029871};\\\", \\\"{x:1269,y:962,t:1526930029887};\\\", \\\"{x:1270,y:955,t:1526930029904};\\\", \\\"{x:1270,y:949,t:1526930029921};\\\", \\\"{x:1269,y:946,t:1526930029937};\\\", \\\"{x:1264,y:940,t:1526930029954};\\\", \\\"{x:1253,y:927,t:1526930029969};\\\", \\\"{x:1243,y:919,t:1526930029987};\\\", \\\"{x:1236,y:913,t:1526930030004};\\\", \\\"{x:1233,y:910,t:1526930030020};\\\", \\\"{x:1232,y:906,t:1526930030037};\\\", \\\"{x:1230,y:902,t:1526930030054};\\\", \\\"{x:1228,y:899,t:1526930030070};\\\", \\\"{x:1228,y:898,t:1526930030087};\\\", \\\"{x:1227,y:897,t:1526930030104};\\\", \\\"{x:1226,y:896,t:1526930030120};\\\", \\\"{x:1225,y:895,t:1526930030137};\\\", \\\"{x:1225,y:894,t:1526930030154};\\\", \\\"{x:1225,y:893,t:1526930030172};\\\", \\\"{x:1225,y:892,t:1526930030188};\\\", \\\"{x:1225,y:890,t:1526930030204};\\\", \\\"{x:1225,y:888,t:1526930030220};\\\", \\\"{x:1225,y:885,t:1526930030237};\\\", \\\"{x:1225,y:883,t:1526930030254};\\\", \\\"{x:1225,y:882,t:1526930030276};\\\", \\\"{x:1226,y:881,t:1526930030287};\\\", \\\"{x:1227,y:881,t:1526930030332};\\\", \\\"{x:1231,y:892,t:1526930030341};\\\", \\\"{x:1235,y:905,t:1526930030355};\\\", \\\"{x:1238,y:932,t:1526930030372};\\\", \\\"{x:1242,y:949,t:1526930030387};\\\", \\\"{x:1247,y:962,t:1526930030405};\\\", \\\"{x:1248,y:971,t:1526930030421};\\\", \\\"{x:1248,y:979,t:1526930030438};\\\", \\\"{x:1248,y:987,t:1526930030455};\\\", \\\"{x:1248,y:991,t:1526930030471};\\\", \\\"{x:1249,y:993,t:1526930030487};\\\", \\\"{x:1250,y:996,t:1526930030504};\\\", \\\"{x:1251,y:996,t:1526930030521};\\\", \\\"{x:1252,y:996,t:1526930030565};\\\", \\\"{x:1253,y:996,t:1526930030572};\\\", \\\"{x:1255,y:996,t:1526930030597};\\\", \\\"{x:1257,y:995,t:1526930030612};\\\", \\\"{x:1260,y:993,t:1526930030621};\\\", \\\"{x:1265,y:989,t:1526930030637};\\\", \\\"{x:1275,y:981,t:1526930030655};\\\", \\\"{x:1292,y:966,t:1526930030672};\\\", \\\"{x:1298,y:958,t:1526930030688};\\\", \\\"{x:1304,y:952,t:1526930030705};\\\", \\\"{x:1306,y:951,t:1526930030721};\\\", \\\"{x:1307,y:950,t:1526930030741};\\\", \\\"{x:1304,y:950,t:1526930030901};\\\", \\\"{x:1301,y:950,t:1526930030909};\\\", \\\"{x:1299,y:950,t:1526930030921};\\\", \\\"{x:1291,y:950,t:1526930030938};\\\", \\\"{x:1280,y:947,t:1526930030954};\\\", \\\"{x:1274,y:943,t:1526930030972};\\\", \\\"{x:1267,y:937,t:1526930030989};\\\", \\\"{x:1265,y:931,t:1526930031005};\\\", \\\"{x:1261,y:918,t:1526930031021};\\\", \\\"{x:1257,y:907,t:1526930031040};\\\", \\\"{x:1253,y:896,t:1526930031054};\\\", \\\"{x:1248,y:884,t:1526930031072};\\\", \\\"{x:1237,y:867,t:1526930031089};\\\", \\\"{x:1230,y:853,t:1526930031105};\\\", \\\"{x:1222,y:842,t:1526930031121};\\\", \\\"{x:1217,y:834,t:1526930031138};\\\", \\\"{x:1214,y:827,t:1526930031155};\\\", \\\"{x:1212,y:823,t:1526930031172};\\\", \\\"{x:1208,y:817,t:1526930031189};\\\", \\\"{x:1206,y:815,t:1526930031205};\\\", \\\"{x:1206,y:814,t:1526930031222};\\\", \\\"{x:1205,y:813,t:1526930031240};\\\", \\\"{x:1204,y:812,t:1526930031285};\\\", \\\"{x:1201,y:815,t:1526930032829};\\\", \\\"{x:1195,y:819,t:1526930032841};\\\", \\\"{x:1191,y:838,t:1526930032856};\\\", \\\"{x:1185,y:853,t:1526930032871};\\\", \\\"{x:1180,y:867,t:1526930032888};\\\", \\\"{x:1172,y:878,t:1526930032906};\\\", \\\"{x:1169,y:887,t:1526930032922};\\\", \\\"{x:1166,y:891,t:1526930032938};\\\", \\\"{x:1163,y:896,t:1526930032956};\\\", \\\"{x:1160,y:899,t:1526930032972};\\\", \\\"{x:1159,y:900,t:1526930032989};\\\", \\\"{x:1159,y:906,t:1526930033006};\\\", \\\"{x:1157,y:912,t:1526930033022};\\\", \\\"{x:1157,y:921,t:1526930033039};\\\", \\\"{x:1156,y:923,t:1526930033056};\\\", \\\"{x:1156,y:926,t:1526930033073};\\\", \\\"{x:1156,y:929,t:1526930033089};\\\", \\\"{x:1156,y:930,t:1526930033106};\\\", \\\"{x:1156,y:933,t:1526930033123};\\\", \\\"{x:1156,y:936,t:1526930033139};\\\", \\\"{x:1156,y:941,t:1526930033156};\\\", \\\"{x:1156,y:944,t:1526930033173};\\\", \\\"{x:1156,y:945,t:1526930033189};\\\", \\\"{x:1155,y:947,t:1526930033206};\\\", \\\"{x:1155,y:949,t:1526930033223};\\\", \\\"{x:1154,y:950,t:1526930033239};\\\", \\\"{x:1153,y:950,t:1526930033257};\\\", \\\"{x:1153,y:952,t:1526930033273};\\\", \\\"{x:1153,y:953,t:1526930033289};\\\", \\\"{x:1153,y:954,t:1526930033307};\\\", \\\"{x:1152,y:955,t:1526930033323};\\\", \\\"{x:1151,y:957,t:1526930033340};\\\", \\\"{x:1151,y:958,t:1526930033373};\\\", \\\"{x:1150,y:960,t:1526930033453};\\\", \\\"{x:1149,y:960,t:1526930033469};\\\", \\\"{x:1148,y:960,t:1526930033493};\\\", \\\"{x:1147,y:962,t:1526930033506};\\\", \\\"{x:1146,y:963,t:1526930033524};\\\", \\\"{x:1146,y:964,t:1526930033540};\\\", \\\"{x:1146,y:966,t:1526930033557};\\\", \\\"{x:1144,y:966,t:1526930033573};\\\", \\\"{x:1141,y:969,t:1526930033591};\\\", \\\"{x:1139,y:971,t:1526930033606};\\\", \\\"{x:1139,y:972,t:1526930033624};\\\", \\\"{x:1137,y:975,t:1526930033640};\\\", \\\"{x:1136,y:976,t:1526930033656};\\\", \\\"{x:1135,y:977,t:1526930033673};\\\", \\\"{x:1134,y:978,t:1526930033693};\\\", \\\"{x:1133,y:979,t:1526930033706};\\\", \\\"{x:1133,y:980,t:1526930033723};\\\", \\\"{x:1132,y:982,t:1526930033740};\\\", \\\"{x:1130,y:984,t:1526930033789};\\\", \\\"{x:1130,y:985,t:1526930033830};\\\", \\\"{x:1129,y:986,t:1526930034220};\\\", \\\"{x:1128,y:986,t:1526930034227};\\\", \\\"{x:1128,y:987,t:1526930034292};\\\", \\\"{x:1129,y:987,t:1526930034307};\\\", \\\"{x:1132,y:985,t:1526930034323};\\\", \\\"{x:1137,y:977,t:1526930034340};\\\", \\\"{x:1143,y:969,t:1526930034357};\\\", \\\"{x:1146,y:964,t:1526930034373};\\\", \\\"{x:1149,y:959,t:1526930034390};\\\", \\\"{x:1150,y:956,t:1526930034408};\\\", \\\"{x:1153,y:952,t:1526930034424};\\\", \\\"{x:1157,y:947,t:1526930034441};\\\", \\\"{x:1161,y:938,t:1526930034457};\\\", \\\"{x:1164,y:931,t:1526930034474};\\\", \\\"{x:1165,y:929,t:1526930034490};\\\", \\\"{x:1168,y:924,t:1526930034508};\\\", \\\"{x:1172,y:917,t:1526930034524};\\\", \\\"{x:1176,y:911,t:1526930034540};\\\", \\\"{x:1177,y:907,t:1526930034558};\\\", \\\"{x:1180,y:899,t:1526930034574};\\\", \\\"{x:1181,y:892,t:1526930034591};\\\", \\\"{x:1182,y:890,t:1526930034607};\\\", \\\"{x:1184,y:884,t:1526930034624};\\\", \\\"{x:1186,y:878,t:1526930034640};\\\", \\\"{x:1187,y:875,t:1526930034657};\\\", \\\"{x:1188,y:872,t:1526930034673};\\\", \\\"{x:1189,y:869,t:1526930034690};\\\", \\\"{x:1192,y:866,t:1526930034707};\\\", \\\"{x:1195,y:863,t:1526930034724};\\\", \\\"{x:1195,y:862,t:1526930034740};\\\", \\\"{x:1195,y:861,t:1526930034757};\\\", \\\"{x:1197,y:858,t:1526930034774};\\\", \\\"{x:1199,y:856,t:1526930034790};\\\", \\\"{x:1199,y:853,t:1526930034807};\\\", \\\"{x:1201,y:851,t:1526930034824};\\\", \\\"{x:1204,y:849,t:1526930034840};\\\", \\\"{x:1206,y:847,t:1526930034857};\\\", \\\"{x:1207,y:846,t:1526930034874};\\\", \\\"{x:1209,y:845,t:1526930034890};\\\", \\\"{x:1209,y:844,t:1526930034924};\\\", \\\"{x:1212,y:843,t:1526930034940};\\\", \\\"{x:1213,y:842,t:1526930034964};\\\", \\\"{x:1214,y:841,t:1526930034974};\\\", \\\"{x:1216,y:840,t:1526930034991};\\\", \\\"{x:1218,y:838,t:1526930035011};\\\", \\\"{x:1219,y:837,t:1526930035035};\\\", \\\"{x:1220,y:837,t:1526930035060};\\\", \\\"{x:1220,y:836,t:1526930035084};\\\", \\\"{x:1220,y:841,t:1526930035389};\\\", \\\"{x:1222,y:849,t:1526930035397};\\\", \\\"{x:1222,y:854,t:1526930035408};\\\", \\\"{x:1224,y:869,t:1526930035424};\\\", \\\"{x:1224,y:876,t:1526930035441};\\\", \\\"{x:1227,y:891,t:1526930035458};\\\", \\\"{x:1229,y:897,t:1526930035474};\\\", \\\"{x:1232,y:904,t:1526930035491};\\\", \\\"{x:1240,y:914,t:1526930035509};\\\", \\\"{x:1248,y:920,t:1526930035525};\\\", \\\"{x:1262,y:928,t:1526930035541};\\\", \\\"{x:1285,y:946,t:1526930035559};\\\", \\\"{x:1297,y:955,t:1526930035575};\\\", \\\"{x:1301,y:960,t:1526930035591};\\\", \\\"{x:1304,y:965,t:1526930035608};\\\", \\\"{x:1303,y:965,t:1526930035749};\\\", \\\"{x:1301,y:965,t:1526930035764};\\\", \\\"{x:1300,y:965,t:1526930035781};\\\", \\\"{x:1300,y:961,t:1526930035812};\\\", \\\"{x:1300,y:960,t:1526930035825};\\\", \\\"{x:1297,y:953,t:1526930035844};\\\", \\\"{x:1294,y:944,t:1526930035862};\\\", \\\"{x:1286,y:933,t:1526930035879};\\\", \\\"{x:1283,y:924,t:1526930035895};\\\", \\\"{x:1272,y:912,t:1526930035912};\\\", \\\"{x:1267,y:904,t:1526930035928};\\\", \\\"{x:1265,y:902,t:1526930035945};\\\", \\\"{x:1261,y:898,t:1526930035962};\\\", \\\"{x:1257,y:895,t:1526930035979};\\\", \\\"{x:1255,y:892,t:1526930035995};\\\", \\\"{x:1252,y:887,t:1526930036012};\\\", \\\"{x:1250,y:885,t:1526930036029};\\\", \\\"{x:1249,y:883,t:1526930036045};\\\", \\\"{x:1248,y:879,t:1526930036062};\\\", \\\"{x:1245,y:874,t:1526930036079};\\\", \\\"{x:1241,y:870,t:1526930036095};\\\", \\\"{x:1239,y:864,t:1526930036112};\\\", \\\"{x:1237,y:860,t:1526930036128};\\\", \\\"{x:1234,y:857,t:1526930036145};\\\", \\\"{x:1232,y:853,t:1526930036162};\\\", \\\"{x:1230,y:850,t:1526930036179};\\\", \\\"{x:1230,y:847,t:1526930036195};\\\", \\\"{x:1228,y:843,t:1526930036212};\\\", \\\"{x:1228,y:842,t:1526930036229};\\\", \\\"{x:1228,y:841,t:1526930036296};\\\", \\\"{x:1228,y:840,t:1526930036369};\\\", \\\"{x:1249,y:842,t:1526930038144};\\\", \\\"{x:1286,y:848,t:1526930038151};\\\", \\\"{x:1335,y:853,t:1526930038163};\\\", \\\"{x:1426,y:877,t:1526930038180};\\\", \\\"{x:1460,y:892,t:1526930038197};\\\", \\\"{x:1480,y:896,t:1526930038213};\\\", \\\"{x:1481,y:896,t:1526930038230};\\\", \\\"{x:1484,y:896,t:1526930038312};\\\", \\\"{x:1485,y:896,t:1526930038320};\\\", \\\"{x:1487,y:896,t:1526930038339};\\\", \\\"{x:1488,y:896,t:1526930038431};\\\", \\\"{x:1488,y:897,t:1526930038446};\\\", \\\"{x:1493,y:903,t:1526930038463};\\\", \\\"{x:1500,y:908,t:1526930038479};\\\", \\\"{x:1511,y:913,t:1526930038496};\\\", \\\"{x:1527,y:918,t:1526930038513};\\\", \\\"{x:1546,y:924,t:1526930038529};\\\", \\\"{x:1565,y:929,t:1526930038547};\\\", \\\"{x:1583,y:932,t:1526930038563};\\\", \\\"{x:1596,y:936,t:1526930038580};\\\", \\\"{x:1613,y:940,t:1526930038597};\\\", \\\"{x:1619,y:940,t:1526930038614};\\\", \\\"{x:1620,y:940,t:1526930038630};\\\", \\\"{x:1621,y:940,t:1526930038792};\\\", \\\"{x:1618,y:941,t:1526930038816};\\\", \\\"{x:1611,y:943,t:1526930038831};\\\", \\\"{x:1600,y:951,t:1526930038847};\\\", \\\"{x:1594,y:955,t:1526930038864};\\\", \\\"{x:1591,y:958,t:1526930038881};\\\", \\\"{x:1591,y:960,t:1526930038897};\\\", \\\"{x:1590,y:961,t:1526930038914};\\\", \\\"{x:1590,y:962,t:1526930038931};\\\", \\\"{x:1592,y:962,t:1526930040127};\\\", \\\"{x:1595,y:962,t:1526930040135};\\\", \\\"{x:1598,y:963,t:1526930040147};\\\", \\\"{x:1603,y:963,t:1526930040164};\\\", \\\"{x:1604,y:963,t:1526930040181};\\\", \\\"{x:1606,y:964,t:1526930040198};\\\", \\\"{x:1607,y:964,t:1526930040311};\\\", \\\"{x:1608,y:964,t:1526930040422};\\\", \\\"{x:1609,y:964,t:1526930048552};\\\", \\\"{x:1608,y:962,t:1526930048560};\\\", \\\"{x:1605,y:960,t:1526930048572};\\\", \\\"{x:1594,y:947,t:1526930048587};\\\", \\\"{x:1573,y:932,t:1526930048604};\\\", \\\"{x:1554,y:914,t:1526930048621};\\\", \\\"{x:1539,y:899,t:1526930048638};\\\", \\\"{x:1527,y:880,t:1526930048654};\\\", \\\"{x:1519,y:869,t:1526930048672};\\\", \\\"{x:1516,y:864,t:1526930048687};\\\", \\\"{x:1513,y:856,t:1526930048704};\\\", \\\"{x:1508,y:851,t:1526930048721};\\\", \\\"{x:1499,y:838,t:1526930048739};\\\", \\\"{x:1488,y:817,t:1526930048755};\\\", \\\"{x:1480,y:798,t:1526930048771};\\\", \\\"{x:1472,y:784,t:1526930048788};\\\", \\\"{x:1466,y:771,t:1526930048805};\\\", \\\"{x:1457,y:755,t:1526930048822};\\\", \\\"{x:1452,y:739,t:1526930048838};\\\", \\\"{x:1444,y:719,t:1526930048854};\\\", \\\"{x:1429,y:683,t:1526930048872};\\\", \\\"{x:1418,y:661,t:1526930048888};\\\", \\\"{x:1405,y:636,t:1526930048904};\\\", \\\"{x:1394,y:617,t:1526930048922};\\\", \\\"{x:1390,y:604,t:1526930048938};\\\", \\\"{x:1389,y:591,t:1526930048954};\\\", \\\"{x:1382,y:574,t:1526930048971};\\\", \\\"{x:1379,y:566,t:1526930048989};\\\", \\\"{x:1379,y:561,t:1526930049005};\\\", \\\"{x:1380,y:556,t:1526930049021};\\\", \\\"{x:1381,y:554,t:1526930049038};\\\", \\\"{x:1383,y:552,t:1526930049054};\\\", \\\"{x:1383,y:551,t:1526930049071};\\\", \\\"{x:1383,y:550,t:1526930049136};\\\", \\\"{x:1386,y:550,t:1526930049168};\\\", \\\"{x:1388,y:551,t:1526930049176};\\\", \\\"{x:1389,y:552,t:1526930049188};\\\", \\\"{x:1391,y:553,t:1526930049205};\\\", \\\"{x:1393,y:557,t:1526930049221};\\\", \\\"{x:1395,y:559,t:1526930049239};\\\", \\\"{x:1397,y:560,t:1526930049256};\\\", \\\"{x:1399,y:560,t:1526930049280};\\\", \\\"{x:1400,y:561,t:1526930049296};\\\", \\\"{x:1403,y:561,t:1526930049312};\\\", \\\"{x:1404,y:562,t:1526930049322};\\\", \\\"{x:1406,y:563,t:1526930049339};\\\", \\\"{x:1407,y:563,t:1526930049355};\\\", \\\"{x:1409,y:563,t:1526930049372};\\\", \\\"{x:1410,y:563,t:1526930049405};\\\", \\\"{x:1411,y:563,t:1526930049421};\\\", \\\"{x:1412,y:563,t:1526930049438};\\\", \\\"{x:1414,y:564,t:1526930049456};\\\", \\\"{x:1415,y:564,t:1526930049472};\\\", \\\"{x:1416,y:564,t:1526930049488};\\\", \\\"{x:1417,y:565,t:1526930049505};\\\", \\\"{x:1419,y:566,t:1526930049522};\\\", \\\"{x:1419,y:568,t:1526930050073};\\\", \\\"{x:1419,y:569,t:1526930050103};\\\", \\\"{x:1419,y:570,t:1526930050120};\\\", \\\"{x:1419,y:571,t:1526930050136};\\\", \\\"{x:1418,y:572,t:1526930050144};\\\", \\\"{x:1417,y:572,t:1526930050156};\\\", \\\"{x:1416,y:573,t:1526930050172};\\\", \\\"{x:1414,y:574,t:1526930050189};\\\", \\\"{x:1413,y:575,t:1526930050206};\\\", \\\"{x:1412,y:576,t:1526930050222};\\\", \\\"{x:1411,y:578,t:1526930050239};\\\", \\\"{x:1408,y:580,t:1526930050256};\\\", \\\"{x:1406,y:583,t:1526930050273};\\\", \\\"{x:1400,y:589,t:1526930050289};\\\", \\\"{x:1398,y:590,t:1526930050305};\\\", \\\"{x:1393,y:596,t:1526930050343};\\\", \\\"{x:1388,y:602,t:1526930050355};\\\", \\\"{x:1379,y:613,t:1526930050372};\\\", \\\"{x:1366,y:631,t:1526930050390};\\\", \\\"{x:1348,y:652,t:1526930050406};\\\", \\\"{x:1329,y:678,t:1526930050422};\\\", \\\"{x:1315,y:701,t:1526930050439};\\\", \\\"{x:1303,y:730,t:1526930050455};\\\", \\\"{x:1280,y:774,t:1526930050472};\\\", \\\"{x:1266,y:814,t:1526930050490};\\\", \\\"{x:1253,y:866,t:1526930050506};\\\", \\\"{x:1245,y:896,t:1526930050523};\\\", \\\"{x:1240,y:919,t:1526930050540};\\\", \\\"{x:1235,y:931,t:1526930050556};\\\", \\\"{x:1232,y:936,t:1526930050573};\\\", \\\"{x:1232,y:937,t:1526930050589};\\\", \\\"{x:1232,y:939,t:1526930050623};\\\", \\\"{x:1231,y:940,t:1526930050679};\\\", \\\"{x:1231,y:941,t:1526930050688};\\\", \\\"{x:1230,y:941,t:1526930050879};\\\", \\\"{x:1228,y:944,t:1526930050888};\\\", \\\"{x:1225,y:945,t:1526930050905};\\\", \\\"{x:1224,y:946,t:1526930050921};\\\", \\\"{x:1223,y:947,t:1526930050938};\\\", \\\"{x:1224,y:947,t:1526930051047};\\\", \\\"{x:1224,y:948,t:1526930051063};\\\", \\\"{x:1225,y:948,t:1526930051087};\\\", \\\"{x:1226,y:948,t:1526930051111};\\\", \\\"{x:1226,y:949,t:1526930051135};\\\", \\\"{x:1227,y:950,t:1526930051143};\\\", \\\"{x:1228,y:950,t:1526930051296};\\\", \\\"{x:1231,y:950,t:1526930051306};\\\", \\\"{x:1238,y:944,t:1526930051323};\\\", \\\"{x:1246,y:935,t:1526930051339};\\\", \\\"{x:1258,y:919,t:1526930051356};\\\", \\\"{x:1275,y:895,t:1526930051374};\\\", \\\"{x:1294,y:866,t:1526930051390};\\\", \\\"{x:1306,y:842,t:1526930051407};\\\", \\\"{x:1349,y:768,t:1526930051423};\\\", \\\"{x:1361,y:726,t:1526930051439};\\\", \\\"{x:1373,y:702,t:1526930051457};\\\", \\\"{x:1378,y:668,t:1526930051473};\\\", \\\"{x:1383,y:640,t:1526930051489};\\\", \\\"{x:1386,y:624,t:1526930051507};\\\", \\\"{x:1388,y:614,t:1526930051523};\\\", \\\"{x:1389,y:606,t:1526930051540};\\\", \\\"{x:1389,y:599,t:1526930051556};\\\", \\\"{x:1390,y:590,t:1526930051573};\\\", \\\"{x:1393,y:583,t:1526930051589};\\\", \\\"{x:1394,y:577,t:1526930051606};\\\", \\\"{x:1396,y:572,t:1526930051623};\\\", \\\"{x:1396,y:571,t:1526930051639};\\\", \\\"{x:1397,y:571,t:1526930051656};\\\", \\\"{x:1398,y:569,t:1526930051673};\\\", \\\"{x:1399,y:568,t:1526930051690};\\\", \\\"{x:1400,y:567,t:1526930051705};\\\", \\\"{x:1400,y:566,t:1526930051723};\\\", \\\"{x:1400,y:565,t:1526930051798};\\\", \\\"{x:1401,y:565,t:1526930051815};\\\", \\\"{x:1400,y:565,t:1526930052007};\\\", \\\"{x:1372,y:566,t:1526930052023};\\\", \\\"{x:1273,y:573,t:1526930052040};\\\", \\\"{x:1160,y:573,t:1526930052058};\\\", \\\"{x:1021,y:575,t:1526930052074};\\\", \\\"{x:918,y:574,t:1526930052092};\\\", \\\"{x:875,y:574,t:1526930052106};\\\", \\\"{x:858,y:579,t:1526930052123};\\\", \\\"{x:854,y:579,t:1526930052134};\\\", \\\"{x:841,y:584,t:1526930052151};\\\", \\\"{x:837,y:585,t:1526930052168};\\\", \\\"{x:822,y:591,t:1526930052192};\\\", \\\"{x:813,y:596,t:1526930052209};\\\", \\\"{x:802,y:599,t:1526930052224};\\\", \\\"{x:788,y:602,t:1526930052242};\\\", \\\"{x:782,y:602,t:1526930052258};\\\", \\\"{x:777,y:602,t:1526930052276};\\\", \\\"{x:769,y:602,t:1526930052292};\\\", \\\"{x:752,y:600,t:1526930052309};\\\", \\\"{x:732,y:594,t:1526930052325};\\\", \\\"{x:705,y:580,t:1526930052343};\\\", \\\"{x:682,y:571,t:1526930052359};\\\", \\\"{x:671,y:563,t:1526930052374};\\\", \\\"{x:668,y:561,t:1526930052392};\\\", \\\"{x:663,y:558,t:1526930052447};\\\", \\\"{x:656,y:554,t:1526930052458};\\\", \\\"{x:648,y:551,t:1526930052475};\\\", \\\"{x:643,y:549,t:1526930052493};\\\", \\\"{x:640,y:547,t:1526930052509};\\\", \\\"{x:639,y:547,t:1526930052527};\\\", \\\"{x:638,y:547,t:1526930052543};\\\", \\\"{x:636,y:548,t:1526930052559};\\\", \\\"{x:632,y:550,t:1526930052576};\\\", \\\"{x:628,y:551,t:1526930052592};\\\", \\\"{x:627,y:552,t:1526930052609};\\\", \\\"{x:627,y:553,t:1526930052625};\\\", \\\"{x:626,y:553,t:1526930052664};\\\", \\\"{x:624,y:553,t:1526930052676};\\\", \\\"{x:623,y:554,t:1526930052693};\\\", \\\"{x:619,y:555,t:1526930052711};\\\", \\\"{x:618,y:557,t:1526930052726};\\\", \\\"{x:615,y:558,t:1526930052743};\\\", \\\"{x:612,y:560,t:1526930052760};\\\", \\\"{x:611,y:561,t:1526930052776};\\\", \\\"{x:610,y:561,t:1526930052832};\\\", \\\"{x:609,y:561,t:1526930052888};\\\", \\\"{x:609,y:562,t:1526930052895};\\\", \\\"{x:607,y:564,t:1526930053383};\\\", \\\"{x:602,y:573,t:1526930053393};\\\", \\\"{x:586,y:593,t:1526930053410};\\\", \\\"{x:563,y:618,t:1526930053426};\\\", \\\"{x:548,y:643,t:1526930053443};\\\", \\\"{x:529,y:660,t:1526930053460};\\\", \\\"{x:528,y:662,t:1526930053476};\\\", \\\"{x:527,y:662,t:1526930053493};\\\", \\\"{x:528,y:662,t:1526930053672};\\\", \\\"{x:528,y:664,t:1526930053679};\\\", \\\"{x:528,y:667,t:1526930053695};\\\", \\\"{x:528,y:669,t:1526930053711};\\\", \\\"{x:528,y:670,t:1526930053728};\\\", \\\"{x:529,y:671,t:1526930053744};\\\", \\\"{x:528,y:673,t:1526930053775};\\\", \\\"{x:528,y:675,t:1526930053783};\\\", \\\"{x:528,y:676,t:1526930053794};\\\", \\\"{x:524,y:681,t:1526930053810};\\\", \\\"{x:522,y:689,t:1526930053827};\\\", \\\"{x:517,y:696,t:1526930053844};\\\", \\\"{x:515,y:699,t:1526930053860};\\\", \\\"{x:514,y:701,t:1526930053877};\\\", \\\"{x:513,y:701,t:1526930053893};\\\", \\\"{x:513,y:702,t:1526930053927};\\\", \\\"{x:512,y:707,t:1526930053943};\\\", \\\"{x:510,y:710,t:1526930053960};\\\", \\\"{x:507,y:714,t:1526930053976};\\\", \\\"{x:506,y:715,t:1526930053993};\\\", \\\"{x:505,y:716,t:1526930054010};\\\", \\\"{x:505,y:717,t:1526930054294};\\\", \\\"{x:505,y:718,t:1526930054350};\\\", \\\"{x:506,y:720,t:1526930054744};\\\", \\\"{x:507,y:720,t:1526930054761};\\\" ] }, { \\\"rt\\\": 101333, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 480543, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-08 AM-I -Z -C -A -F -Z -09 AM-O -A -A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:720,t:1526930056632};\\\", \\\"{x:514,y:719,t:1526930056642};\\\", \\\"{x:548,y:703,t:1526930056660};\\\", \\\"{x:580,y:676,t:1526930056675};\\\", \\\"{x:605,y:647,t:1526930056697};\\\", \\\"{x:632,y:610,t:1526930056712};\\\", \\\"{x:666,y:560,t:1526930056729};\\\", \\\"{x:692,y:502,t:1526930056746};\\\", \\\"{x:708,y:465,t:1526930056762};\\\", \\\"{x:716,y:439,t:1526930056779};\\\", \\\"{x:718,y:425,t:1526930056795};\\\", \\\"{x:719,y:419,t:1526930056812};\\\", \\\"{x:719,y:416,t:1526930056829};\\\", \\\"{x:717,y:414,t:1526930056887};\\\", \\\"{x:713,y:414,t:1526930056896};\\\", \\\"{x:709,y:414,t:1526930056912};\\\", \\\"{x:706,y:414,t:1526930056929};\\\", \\\"{x:700,y:416,t:1526930056945};\\\", \\\"{x:690,y:419,t:1526930056962};\\\", \\\"{x:672,y:424,t:1526930056978};\\\", \\\"{x:649,y:434,t:1526930056995};\\\", \\\"{x:625,y:439,t:1526930057012};\\\", \\\"{x:612,y:443,t:1526930057028};\\\", \\\"{x:602,y:444,t:1526930057045};\\\", \\\"{x:594,y:444,t:1526930057062};\\\", \\\"{x:588,y:444,t:1526930057079};\\\", \\\"{x:577,y:445,t:1526930057095};\\\", \\\"{x:564,y:449,t:1526930057112};\\\", \\\"{x:545,y:455,t:1526930057128};\\\", \\\"{x:528,y:460,t:1526930057145};\\\", \\\"{x:509,y:463,t:1526930057162};\\\", \\\"{x:496,y:466,t:1526930057178};\\\", \\\"{x:485,y:468,t:1526930057195};\\\", \\\"{x:484,y:469,t:1526930057211};\\\", \\\"{x:486,y:469,t:1526930057431};\\\", \\\"{x:493,y:467,t:1526930057445};\\\", \\\"{x:499,y:464,t:1526930057461};\\\", \\\"{x:518,y:462,t:1526930057478};\\\", \\\"{x:546,y:462,t:1526930057495};\\\", \\\"{x:548,y:462,t:1526930057511};\\\", \\\"{x:548,y:463,t:1526930057528};\\\", \\\"{x:548,y:464,t:1526930057544};\\\", \\\"{x:552,y:468,t:1526930057561};\\\", \\\"{x:555,y:469,t:1526930057579};\\\", \\\"{x:558,y:471,t:1526930057594};\\\", \\\"{x:561,y:472,t:1526930057611};\\\", \\\"{x:567,y:473,t:1526930057628};\\\", \\\"{x:572,y:476,t:1526930057645};\\\", \\\"{x:576,y:477,t:1526930057662};\\\", \\\"{x:579,y:479,t:1526930057678};\\\", \\\"{x:581,y:479,t:1526930057695};\\\", \\\"{x:581,y:480,t:1526930057712};\\\", \\\"{x:582,y:480,t:1526930058016};\\\", \\\"{x:584,y:480,t:1526930058031};\\\", \\\"{x:586,y:480,t:1526930058047};\\\", \\\"{x:587,y:480,t:1526930058061};\\\", \\\"{x:588,y:480,t:1526930058078};\\\", \\\"{x:589,y:480,t:1526930058174};\\\", \\\"{x:590,y:480,t:1526930058214};\\\", \\\"{x:592,y:480,t:1526930058247};\\\", \\\"{x:593,y:479,t:1526930058271};\\\", \\\"{x:594,y:478,t:1526930058320};\\\", \\\"{x:595,y:477,t:1526930058335};\\\", \\\"{x:597,y:476,t:1526930058344};\\\", \\\"{x:602,y:473,t:1526930058360};\\\", \\\"{x:606,y:473,t:1526930058378};\\\", \\\"{x:608,y:473,t:1526930058393};\\\", \\\"{x:608,y:472,t:1526930058410};\\\", \\\"{x:609,y:472,t:1526930058471};\\\", \\\"{x:610,y:471,t:1526930058527};\\\", \\\"{x:611,y:471,t:1526930058615};\\\", \\\"{x:612,y:471,t:1526930058696};\\\", \\\"{x:613,y:471,t:1526930058711};\\\", \\\"{x:614,y:470,t:1526930058727};\\\", \\\"{x:615,y:470,t:1526930058791};\\\", \\\"{x:615,y:469,t:1526930058872};\\\", \\\"{x:616,y:469,t:1526930058903};\\\", \\\"{x:617,y:469,t:1526930058911};\\\", \\\"{x:618,y:469,t:1526930058927};\\\", \\\"{x:620,y:468,t:1526930058943};\\\", \\\"{x:622,y:467,t:1526930058960};\\\", \\\"{x:634,y:467,t:1526930058977};\\\", \\\"{x:644,y:467,t:1526930058993};\\\", \\\"{x:668,y:470,t:1526930059010};\\\", \\\"{x:682,y:471,t:1526930059027};\\\", \\\"{x:691,y:473,t:1526930059043};\\\", \\\"{x:693,y:474,t:1526930059060};\\\", \\\"{x:693,y:475,t:1526930059112};\\\", \\\"{x:693,y:476,t:1526930059126};\\\", \\\"{x:691,y:479,t:1526930059143};\\\", \\\"{x:691,y:480,t:1526930059175};\\\", \\\"{x:690,y:481,t:1526930059191};\\\", \\\"{x:688,y:481,t:1526930059199};\\\", \\\"{x:688,y:482,t:1526930059210};\\\", \\\"{x:682,y:485,t:1526930059227};\\\", \\\"{x:676,y:488,t:1526930059243};\\\", \\\"{x:673,y:489,t:1526930059260};\\\", \\\"{x:672,y:490,t:1526930059277};\\\", \\\"{x:671,y:490,t:1526930059295};\\\", \\\"{x:665,y:492,t:1526930059309};\\\", \\\"{x:649,y:501,t:1526930059326};\\\", \\\"{x:624,y:508,t:1526930059343};\\\", \\\"{x:574,y:519,t:1526930059359};\\\", \\\"{x:559,y:524,t:1526930059377};\\\", \\\"{x:541,y:531,t:1526930059392};\\\", \\\"{x:530,y:534,t:1526930059414};\\\", \\\"{x:528,y:534,t:1526930059430};\\\", \\\"{x:528,y:532,t:1526930059608};\\\", \\\"{x:528,y:530,t:1526930059615};\\\", \\\"{x:528,y:526,t:1526930059631};\\\", \\\"{x:523,y:517,t:1526930059650};\\\", \\\"{x:515,y:508,t:1526930059665};\\\", \\\"{x:505,y:501,t:1526930059681};\\\", \\\"{x:496,y:494,t:1526930059698};\\\", \\\"{x:487,y:491,t:1526930059714};\\\", \\\"{x:483,y:489,t:1526930059731};\\\", \\\"{x:480,y:488,t:1526930059748};\\\", \\\"{x:477,y:488,t:1526930059764};\\\", \\\"{x:472,y:488,t:1526930059781};\\\", \\\"{x:469,y:488,t:1526930059798};\\\", \\\"{x:467,y:488,t:1526930059814};\\\", \\\"{x:466,y:488,t:1526930059863};\\\", \\\"{x:467,y:488,t:1526930059984};\\\", \\\"{x:468,y:488,t:1526930059998};\\\", \\\"{x:469,y:488,t:1526930060015};\\\", \\\"{x:470,y:489,t:1526930060039};\\\", \\\"{x:470,y:491,t:1526930060055};\\\", \\\"{x:470,y:493,t:1526930060071};\\\", \\\"{x:470,y:495,t:1526930060103};\\\", \\\"{x:470,y:496,t:1526930060135};\\\", \\\"{x:470,y:497,t:1526930060148};\\\", \\\"{x:468,y:499,t:1526930060165};\\\", \\\"{x:467,y:500,t:1526930060183};\\\", \\\"{x:466,y:501,t:1526930060216};\\\", \\\"{x:466,y:503,t:1526930060256};\\\", \\\"{x:465,y:504,t:1526930060266};\\\", \\\"{x:461,y:507,t:1526930060282};\\\", \\\"{x:457,y:514,t:1526930060298};\\\", \\\"{x:451,y:520,t:1526930060317};\\\", \\\"{x:449,y:523,t:1526930060332};\\\", \\\"{x:446,y:525,t:1526930060348};\\\", \\\"{x:441,y:529,t:1526930060365};\\\", \\\"{x:434,y:535,t:1526930060382};\\\", \\\"{x:430,y:539,t:1526930060398};\\\", \\\"{x:426,y:542,t:1526930060415};\\\", \\\"{x:426,y:543,t:1526930060432};\\\", \\\"{x:425,y:544,t:1526930060454};\\\", \\\"{x:424,y:545,t:1526930060470};\\\", \\\"{x:424,y:546,t:1526930060494};\\\", \\\"{x:424,y:547,t:1526930060510};\\\", \\\"{x:423,y:548,t:1526930060519};\\\", \\\"{x:423,y:549,t:1526930060534};\\\", \\\"{x:423,y:550,t:1526930060550};\\\", \\\"{x:423,y:552,t:1526930060566};\\\", \\\"{x:422,y:553,t:1526930060582};\\\", \\\"{x:422,y:556,t:1526930060615};\\\", \\\"{x:422,y:562,t:1526930060633};\\\", \\\"{x:422,y:569,t:1526930060649};\\\", \\\"{x:424,y:578,t:1526930060665};\\\", \\\"{x:426,y:588,t:1526930060682};\\\", \\\"{x:430,y:596,t:1526930060700};\\\", \\\"{x:434,y:607,t:1526930060715};\\\", \\\"{x:436,y:614,t:1526930060731};\\\", \\\"{x:438,y:622,t:1526930060749};\\\", \\\"{x:439,y:627,t:1526930060765};\\\", \\\"{x:439,y:634,t:1526930060782};\\\", \\\"{x:441,y:641,t:1526930060798};\\\", \\\"{x:441,y:644,t:1526930060815};\\\", \\\"{x:442,y:645,t:1526930060832};\\\", \\\"{x:443,y:646,t:1526930060849};\\\", \\\"{x:443,y:647,t:1526930060865};\\\", \\\"{x:444,y:650,t:1526930060882};\\\", \\\"{x:445,y:651,t:1526930060899};\\\", \\\"{x:445,y:652,t:1526930060927};\\\", \\\"{x:445,y:653,t:1526930060952};\\\", \\\"{x:445,y:654,t:1526930060967};\\\", \\\"{x:445,y:655,t:1526930060991};\\\", \\\"{x:445,y:656,t:1526930061000};\\\", \\\"{x:445,y:657,t:1526930061016};\\\", \\\"{x:445,y:658,t:1526930061032};\\\", \\\"{x:445,y:660,t:1526930061049};\\\", \\\"{x:445,y:663,t:1526930061066};\\\", \\\"{x:445,y:667,t:1526930061083};\\\", \\\"{x:447,y:673,t:1526930061099};\\\", \\\"{x:447,y:678,t:1526930061116};\\\", \\\"{x:448,y:683,t:1526930061133};\\\", \\\"{x:448,y:686,t:1526930061149};\\\", \\\"{x:449,y:689,t:1526930061166};\\\", \\\"{x:450,y:690,t:1526930061183};\\\", \\\"{x:450,y:691,t:1526930061199};\\\", \\\"{x:450,y:693,t:1526930061216};\\\", \\\"{x:453,y:696,t:1526930061238};\\\", \\\"{x:459,y:702,t:1526930061249};\\\", \\\"{x:469,y:711,t:1526930061266};\\\", \\\"{x:489,y:721,t:1526930061284};\\\", \\\"{x:501,y:727,t:1526930061300};\\\", \\\"{x:520,y:741,t:1526930061316};\\\", \\\"{x:534,y:749,t:1526930061332};\\\", \\\"{x:541,y:754,t:1526930061349};\\\", \\\"{x:553,y:768,t:1526930061367};\\\", \\\"{x:561,y:779,t:1526930061382};\\\", \\\"{x:568,y:797,t:1526930061399};\\\", \\\"{x:572,y:813,t:1526930061416};\\\", \\\"{x:577,y:826,t:1526930061432};\\\", \\\"{x:577,y:836,t:1526930061449};\\\", \\\"{x:580,y:846,t:1526930061466};\\\", \\\"{x:584,y:857,t:1526930061483};\\\", \\\"{x:592,y:870,t:1526930061499};\\\", \\\"{x:594,y:876,t:1526930061517};\\\", \\\"{x:597,y:879,t:1526930061533};\\\", \\\"{x:599,y:881,t:1526930061550};\\\", \\\"{x:612,y:884,t:1526930061567};\\\", \\\"{x:631,y:891,t:1526930061583};\\\", \\\"{x:690,y:913,t:1526930061600};\\\", \\\"{x:767,y:942,t:1526930061617};\\\", \\\"{x:823,y:959,t:1526930061633};\\\", \\\"{x:854,y:971,t:1526930061650};\\\", \\\"{x:882,y:979,t:1526930061667};\\\", \\\"{x:899,y:986,t:1526930061684};\\\", \\\"{x:937,y:992,t:1526930061699};\\\", \\\"{x:971,y:994,t:1526930061716};\\\", \\\"{x:1019,y:994,t:1526930061734};\\\", \\\"{x:1059,y:996,t:1526930061750};\\\", \\\"{x:1079,y:1002,t:1526930061767};\\\", \\\"{x:1118,y:1004,t:1526930061783};\\\", \\\"{x:1148,y:1005,t:1526930061800};\\\", \\\"{x:1165,y:1006,t:1526930061817};\\\", \\\"{x:1179,y:1002,t:1526930061834};\\\", \\\"{x:1185,y:999,t:1526930061850};\\\", \\\"{x:1197,y:995,t:1526930061867};\\\", \\\"{x:1202,y:995,t:1526930061883};\\\", \\\"{x:1208,y:993,t:1526930061900};\\\", \\\"{x:1210,y:992,t:1526930061917};\\\", \\\"{x:1211,y:992,t:1526930061952};\\\", \\\"{x:1213,y:991,t:1526930061967};\\\", \\\"{x:1214,y:990,t:1526930061984};\\\", \\\"{x:1216,y:988,t:1526930062000};\\\", \\\"{x:1218,y:988,t:1526930062017};\\\", \\\"{x:1220,y:987,t:1526930062034};\\\", \\\"{x:1222,y:986,t:1526930062050};\\\", \\\"{x:1226,y:985,t:1526930062066};\\\", \\\"{x:1230,y:985,t:1526930062083};\\\", \\\"{x:1235,y:984,t:1526930062101};\\\", \\\"{x:1242,y:984,t:1526930062118};\\\", \\\"{x:1245,y:984,t:1526930062133};\\\", \\\"{x:1249,y:984,t:1526930062151};\\\", \\\"{x:1256,y:984,t:1526930062168};\\\", \\\"{x:1260,y:984,t:1526930062183};\\\", \\\"{x:1270,y:984,t:1526930062201};\\\", \\\"{x:1283,y:984,t:1526930062217};\\\", \\\"{x:1295,y:987,t:1526930062235};\\\", \\\"{x:1307,y:991,t:1526930062251};\\\", \\\"{x:1317,y:997,t:1526930062267};\\\", \\\"{x:1330,y:1003,t:1526930062284};\\\", \\\"{x:1335,y:1004,t:1526930062301};\\\", \\\"{x:1340,y:1007,t:1526930062317};\\\", \\\"{x:1343,y:1008,t:1526930062334};\\\", \\\"{x:1345,y:1008,t:1526930062351};\\\", \\\"{x:1348,y:1008,t:1526930062439};\\\", \\\"{x:1351,y:1008,t:1526930062463};\\\", \\\"{x:1353,y:1006,t:1526930062471};\\\", \\\"{x:1359,y:1003,t:1526930062483};\\\", \\\"{x:1365,y:997,t:1526930062500};\\\", \\\"{x:1372,y:992,t:1526930062517};\\\", \\\"{x:1384,y:975,t:1526930062535};\\\", \\\"{x:1390,y:962,t:1526930062550};\\\", \\\"{x:1393,y:957,t:1526930062567};\\\", \\\"{x:1394,y:948,t:1526930062584};\\\", \\\"{x:1398,y:932,t:1526930062600};\\\", \\\"{x:1390,y:898,t:1526930062617};\\\", \\\"{x:1365,y:845,t:1526930062635};\\\", \\\"{x:1343,y:765,t:1526930062650};\\\", \\\"{x:1330,y:707,t:1526930062667};\\\", \\\"{x:1316,y:657,t:1526930062684};\\\", \\\"{x:1310,y:640,t:1526930062700};\\\", \\\"{x:1308,y:630,t:1526930062717};\\\", \\\"{x:1305,y:614,t:1526930062734};\\\", \\\"{x:1301,y:602,t:1526930062750};\\\", \\\"{x:1300,y:596,t:1526930062767};\\\", \\\"{x:1297,y:590,t:1526930062785};\\\", \\\"{x:1294,y:582,t:1526930062800};\\\", \\\"{x:1292,y:576,t:1526930062818};\\\", \\\"{x:1291,y:572,t:1526930062835};\\\", \\\"{x:1291,y:570,t:1526930062871};\\\", \\\"{x:1290,y:569,t:1526930062885};\\\", \\\"{x:1290,y:566,t:1526930062901};\\\", \\\"{x:1290,y:562,t:1526930062918};\\\", \\\"{x:1290,y:558,t:1526930062935};\\\", \\\"{x:1289,y:558,t:1526930062952};\\\", \\\"{x:1287,y:559,t:1526930062967};\\\", \\\"{x:1284,y:568,t:1526930062984};\\\", \\\"{x:1268,y:591,t:1526930063003};\\\", \\\"{x:1262,y:602,t:1526930063017};\\\", \\\"{x:1251,y:628,t:1526930063034};\\\", \\\"{x:1240,y:663,t:1526930063052};\\\", \\\"{x:1209,y:725,t:1526930063068};\\\", \\\"{x:1184,y:775,t:1526930063085};\\\", \\\"{x:1169,y:811,t:1526930063102};\\\", \\\"{x:1162,y:836,t:1526930063118};\\\", \\\"{x:1156,y:856,t:1526930063136};\\\", \\\"{x:1155,y:867,t:1526930063151};\\\", \\\"{x:1151,y:880,t:1526930063168};\\\", \\\"{x:1149,y:886,t:1526930063185};\\\", \\\"{x:1148,y:887,t:1526930063202};\\\", \\\"{x:1147,y:888,t:1526930063217};\\\", \\\"{x:1146,y:889,t:1526930063235};\\\", \\\"{x:1145,y:890,t:1526930063253};\\\", \\\"{x:1145,y:892,t:1526930063268};\\\", \\\"{x:1144,y:892,t:1526930063287};\\\", \\\"{x:1143,y:892,t:1526930063302};\\\", \\\"{x:1139,y:893,t:1526930063319};\\\", \\\"{x:1132,y:897,t:1526930063335};\\\", \\\"{x:1126,y:904,t:1526930063351};\\\", \\\"{x:1111,y:911,t:1526930063369};\\\", \\\"{x:1091,y:919,t:1526930063385};\\\", \\\"{x:1080,y:925,t:1526930063402};\\\", \\\"{x:1071,y:926,t:1526930063419};\\\", \\\"{x:1067,y:929,t:1526930063435};\\\", \\\"{x:1063,y:929,t:1526930063452};\\\", \\\"{x:1057,y:933,t:1526930063468};\\\", \\\"{x:1052,y:937,t:1526930063484};\\\", \\\"{x:1049,y:941,t:1526930063502};\\\", \\\"{x:1048,y:943,t:1526930063519};\\\", \\\"{x:1047,y:944,t:1526930063535};\\\", \\\"{x:1047,y:945,t:1526930063551};\\\", \\\"{x:1047,y:947,t:1526930063569};\\\", \\\"{x:1045,y:951,t:1526930063584};\\\", \\\"{x:1045,y:955,t:1526930063601};\\\", \\\"{x:1045,y:962,t:1526930063619};\\\", \\\"{x:1045,y:970,t:1526930063635};\\\", \\\"{x:1051,y:980,t:1526930063651};\\\", \\\"{x:1056,y:986,t:1526930063668};\\\", \\\"{x:1059,y:989,t:1526930063685};\\\", \\\"{x:1060,y:989,t:1526930063701};\\\", \\\"{x:1069,y:989,t:1526930063718};\\\", \\\"{x:1074,y:986,t:1526930063735};\\\", \\\"{x:1099,y:970,t:1526930063751};\\\", \\\"{x:1111,y:958,t:1526930063769};\\\", \\\"{x:1131,y:934,t:1526930063785};\\\", \\\"{x:1164,y:905,t:1526930063801};\\\", \\\"{x:1200,y:866,t:1526930063818};\\\", \\\"{x:1218,y:835,t:1526930063835};\\\", \\\"{x:1236,y:786,t:1526930063852};\\\", \\\"{x:1247,y:695,t:1526930063869};\\\", \\\"{x:1247,y:618,t:1526930063886};\\\", \\\"{x:1238,y:570,t:1526930063902};\\\", \\\"{x:1230,y:543,t:1526930063919};\\\", \\\"{x:1227,y:534,t:1526930063935};\\\", \\\"{x:1227,y:526,t:1526930063951};\\\", \\\"{x:1227,y:517,t:1526930063969};\\\", \\\"{x:1227,y:505,t:1526930063986};\\\", \\\"{x:1227,y:496,t:1526930064002};\\\", \\\"{x:1227,y:493,t:1526930064019};\\\", \\\"{x:1228,y:489,t:1526930064035};\\\", \\\"{x:1230,y:487,t:1526930064054};\\\", \\\"{x:1231,y:485,t:1526930064069};\\\", \\\"{x:1232,y:485,t:1526930064104};\\\", \\\"{x:1237,y:485,t:1526930064119};\\\", \\\"{x:1242,y:485,t:1526930064135};\\\", \\\"{x:1245,y:487,t:1526930064153};\\\", \\\"{x:1252,y:488,t:1526930064169};\\\", \\\"{x:1259,y:493,t:1526930064186};\\\", \\\"{x:1267,y:501,t:1526930064203};\\\", \\\"{x:1285,y:511,t:1526930064218};\\\", \\\"{x:1300,y:518,t:1526930064235};\\\", \\\"{x:1306,y:521,t:1526930064252};\\\", \\\"{x:1308,y:521,t:1526930064268};\\\", \\\"{x:1309,y:521,t:1526930064294};\\\", \\\"{x:1311,y:521,t:1526930064302};\\\", \\\"{x:1313,y:521,t:1526930064318};\\\", \\\"{x:1314,y:521,t:1526930064335};\\\", \\\"{x:1316,y:521,t:1526930064478};\\\", \\\"{x:1318,y:520,t:1526930064494};\\\", \\\"{x:1319,y:520,t:1526930064502};\\\", \\\"{x:1323,y:517,t:1526930064518};\\\", \\\"{x:1325,y:516,t:1526930064535};\\\", \\\"{x:1329,y:513,t:1526930064552};\\\", \\\"{x:1331,y:511,t:1526930064569};\\\", \\\"{x:1331,y:510,t:1526930064586};\\\", \\\"{x:1331,y:509,t:1526930064603};\\\", \\\"{x:1331,y:508,t:1526930064620};\\\", \\\"{x:1331,y:507,t:1526930064664};\\\", \\\"{x:1331,y:506,t:1526930064687};\\\", \\\"{x:1329,y:506,t:1526930064711};\\\", \\\"{x:1328,y:506,t:1526930064719};\\\", \\\"{x:1324,y:506,t:1526930064736};\\\", \\\"{x:1323,y:506,t:1526930064753};\\\", \\\"{x:1322,y:506,t:1526930064770};\\\", \\\"{x:1321,y:506,t:1526930064785};\\\", \\\"{x:1319,y:506,t:1526930064872};\\\", \\\"{x:1318,y:504,t:1526930064895};\\\", \\\"{x:1318,y:502,t:1526930064928};\\\", \\\"{x:1318,y:501,t:1526930064939};\\\", \\\"{x:1317,y:498,t:1526930064952};\\\", \\\"{x:1317,y:496,t:1526930064969};\\\", \\\"{x:1315,y:493,t:1526930064987};\\\", \\\"{x:1315,y:492,t:1526930065071};\\\", \\\"{x:1315,y:491,t:1526930074080};\\\", \\\"{x:1314,y:491,t:1526930078583};\\\", \\\"{x:1311,y:493,t:1526930078598};\\\", \\\"{x:1308,y:501,t:1526930078616};\\\", \\\"{x:1306,y:508,t:1526930078632};\\\", \\\"{x:1303,y:519,t:1526930078650};\\\", \\\"{x:1302,y:536,t:1526930078665};\\\", \\\"{x:1302,y:562,t:1526930078682};\\\", \\\"{x:1302,y:601,t:1526930078699};\\\", \\\"{x:1302,y:662,t:1526930078715};\\\", \\\"{x:1312,y:695,t:1526930078732};\\\", \\\"{x:1322,y:730,t:1526930078749};\\\", \\\"{x:1336,y:763,t:1526930078765};\\\", \\\"{x:1346,y:807,t:1526930078782};\\\", \\\"{x:1353,y:826,t:1526930078798};\\\", \\\"{x:1355,y:837,t:1526930078816};\\\", \\\"{x:1355,y:856,t:1526930078832};\\\", \\\"{x:1355,y:877,t:1526930078849};\\\", \\\"{x:1352,y:904,t:1526930078866};\\\", \\\"{x:1347,y:923,t:1526930078882};\\\", \\\"{x:1340,y:939,t:1526930078899};\\\", \\\"{x:1337,y:946,t:1526930078916};\\\", \\\"{x:1332,y:949,t:1526930078933};\\\", \\\"{x:1331,y:950,t:1526930078949};\\\", \\\"{x:1329,y:951,t:1526930078967};\\\", \\\"{x:1327,y:952,t:1526930078991};\\\", \\\"{x:1326,y:952,t:1526930078999};\\\", \\\"{x:1323,y:953,t:1526930079016};\\\", \\\"{x:1318,y:957,t:1526930079033};\\\", \\\"{x:1314,y:960,t:1526930079049};\\\", \\\"{x:1312,y:960,t:1526930079066};\\\", \\\"{x:1312,y:961,t:1526930079327};\\\", \\\"{x:1312,y:962,t:1526930079375};\\\", \\\"{x:1313,y:962,t:1526930079447};\\\", \\\"{x:1314,y:962,t:1526930079503};\\\", \\\"{x:1315,y:962,t:1526930079535};\\\", \\\"{x:1317,y:962,t:1526930079559};\\\", \\\"{x:1318,y:962,t:1526930079575};\\\", \\\"{x:1320,y:962,t:1526930079591};\\\", \\\"{x:1321,y:962,t:1526930079600};\\\", \\\"{x:1322,y:962,t:1526930079616};\\\", \\\"{x:1324,y:961,t:1526930079634};\\\", \\\"{x:1327,y:960,t:1526930079650};\\\", \\\"{x:1329,y:958,t:1526930079667};\\\", \\\"{x:1331,y:956,t:1526930079683};\\\", \\\"{x:1333,y:954,t:1526930079701};\\\", \\\"{x:1334,y:953,t:1526930079716};\\\", \\\"{x:1335,y:951,t:1526930079733};\\\", \\\"{x:1338,y:948,t:1526930079750};\\\", \\\"{x:1340,y:944,t:1526930079767};\\\", \\\"{x:1343,y:941,t:1526930079784};\\\", \\\"{x:1344,y:939,t:1526930079801};\\\", \\\"{x:1347,y:935,t:1526930079817};\\\", \\\"{x:1351,y:932,t:1526930079833};\\\", \\\"{x:1351,y:931,t:1526930079850};\\\", \\\"{x:1352,y:929,t:1526930079867};\\\", \\\"{x:1354,y:927,t:1526930079883};\\\", \\\"{x:1357,y:922,t:1526930079901};\\\", \\\"{x:1357,y:919,t:1526930079917};\\\", \\\"{x:1357,y:917,t:1526930079933};\\\", \\\"{x:1357,y:916,t:1526930079951};\\\", \\\"{x:1357,y:914,t:1526930079967};\\\", \\\"{x:1357,y:913,t:1526930080039};\\\", \\\"{x:1357,y:911,t:1526930080050};\\\", \\\"{x:1358,y:910,t:1526930080071};\\\", \\\"{x:1358,y:909,t:1526930080083};\\\", \\\"{x:1358,y:908,t:1526930080100};\\\", \\\"{x:1358,y:907,t:1526930080118};\\\", \\\"{x:1358,y:906,t:1526930080135};\\\", \\\"{x:1357,y:905,t:1526930080151};\\\", \\\"{x:1356,y:903,t:1526930080167};\\\", \\\"{x:1354,y:901,t:1526930080183};\\\", \\\"{x:1354,y:900,t:1526930080200};\\\", \\\"{x:1353,y:899,t:1526930080218};\\\", \\\"{x:1352,y:898,t:1526930080250};\\\", \\\"{x:1351,y:897,t:1526930080267};\\\", \\\"{x:1350,y:896,t:1526930080284};\\\", \\\"{x:1350,y:895,t:1526930080300};\\\", \\\"{x:1349,y:893,t:1526930080317};\\\", \\\"{x:1348,y:893,t:1526930080334};\\\", \\\"{x:1346,y:892,t:1526930080350};\\\", \\\"{x:1341,y:892,t:1526930085454};\\\", \\\"{x:1314,y:904,t:1526930085471};\\\", \\\"{x:1295,y:913,t:1526930085488};\\\", \\\"{x:1282,y:913,t:1526930085505};\\\", \\\"{x:1278,y:913,t:1526930085522};\\\", \\\"{x:1275,y:914,t:1526930085538};\\\", \\\"{x:1274,y:914,t:1526930085615};\\\", \\\"{x:1273,y:914,t:1526930085631};\\\", \\\"{x:1271,y:914,t:1526930085639};\\\", \\\"{x:1270,y:912,t:1526930085655};\\\", \\\"{x:1266,y:906,t:1526930085672};\\\", \\\"{x:1263,y:901,t:1526930085688};\\\", \\\"{x:1256,y:894,t:1526930085705};\\\", \\\"{x:1250,y:888,t:1526930085723};\\\", \\\"{x:1248,y:885,t:1526930085739};\\\", \\\"{x:1246,y:884,t:1526930085758};\\\", \\\"{x:1243,y:884,t:1526930085772};\\\", \\\"{x:1238,y:884,t:1526930085788};\\\", \\\"{x:1220,y:884,t:1526930085805};\\\", \\\"{x:1188,y:882,t:1526930085823};\\\", \\\"{x:1171,y:878,t:1526930085839};\\\", \\\"{x:1164,y:875,t:1526930085856};\\\", \\\"{x:1161,y:874,t:1526930085872};\\\", \\\"{x:1161,y:872,t:1526930085927};\\\", \\\"{x:1161,y:871,t:1526930085951};\\\", \\\"{x:1161,y:870,t:1526930085959};\\\", \\\"{x:1163,y:869,t:1526930085975};\\\", \\\"{x:1163,y:868,t:1526930085989};\\\", \\\"{x:1166,y:865,t:1526930086005};\\\", \\\"{x:1171,y:861,t:1526930086022};\\\", \\\"{x:1174,y:858,t:1526930086039};\\\", \\\"{x:1181,y:854,t:1526930086056};\\\", \\\"{x:1185,y:853,t:1526930086073};\\\", \\\"{x:1188,y:850,t:1526930086090};\\\", \\\"{x:1189,y:850,t:1526930086110};\\\", \\\"{x:1190,y:851,t:1526930086167};\\\", \\\"{x:1189,y:861,t:1526930086174};\\\", \\\"{x:1187,y:872,t:1526930086190};\\\", \\\"{x:1181,y:887,t:1526930086206};\\\", \\\"{x:1173,y:906,t:1526930086222};\\\", \\\"{x:1173,y:917,t:1526930086239};\\\", \\\"{x:1171,y:928,t:1526930086255};\\\", \\\"{x:1170,y:932,t:1526930086272};\\\", \\\"{x:1169,y:935,t:1526930086289};\\\", \\\"{x:1169,y:936,t:1526930086306};\\\", \\\"{x:1169,y:937,t:1526930086322};\\\", \\\"{x:1168,y:937,t:1526930086343};\\\", \\\"{x:1168,y:938,t:1526930086357};\\\", \\\"{x:1166,y:939,t:1526930086373};\\\", \\\"{x:1166,y:940,t:1526930086390};\\\", \\\"{x:1165,y:945,t:1526930086407};\\\", \\\"{x:1163,y:946,t:1526930086423};\\\", \\\"{x:1159,y:947,t:1526930086440};\\\", \\\"{x:1154,y:949,t:1526930086456};\\\", \\\"{x:1151,y:950,t:1526930086472};\\\", \\\"{x:1147,y:952,t:1526930086490};\\\", \\\"{x:1147,y:953,t:1526930086507};\\\", \\\"{x:1144,y:955,t:1526930086523};\\\", \\\"{x:1142,y:956,t:1526930086540};\\\", \\\"{x:1141,y:957,t:1526930086556};\\\", \\\"{x:1140,y:959,t:1526930086572};\\\", \\\"{x:1139,y:960,t:1526930086589};\\\", \\\"{x:1138,y:961,t:1526930086622};\\\", \\\"{x:1137,y:962,t:1526930086639};\\\", \\\"{x:1138,y:962,t:1526930086735};\\\", \\\"{x:1144,y:960,t:1526930086742};\\\", \\\"{x:1150,y:954,t:1526930086757};\\\", \\\"{x:1158,y:942,t:1526930086774};\\\", \\\"{x:1178,y:926,t:1526930086790};\\\", \\\"{x:1204,y:904,t:1526930086806};\\\", \\\"{x:1217,y:892,t:1526930086823};\\\", \\\"{x:1225,y:882,t:1526930086839};\\\", \\\"{x:1226,y:880,t:1526930086856};\\\", \\\"{x:1229,y:874,t:1526930086874};\\\", \\\"{x:1232,y:869,t:1526930086890};\\\", \\\"{x:1234,y:862,t:1526930086906};\\\", \\\"{x:1238,y:856,t:1526930086924};\\\", \\\"{x:1242,y:849,t:1526930086940};\\\", \\\"{x:1243,y:845,t:1526930086957};\\\", \\\"{x:1243,y:843,t:1526930086974};\\\", \\\"{x:1243,y:842,t:1526930086989};\\\", \\\"{x:1243,y:839,t:1526930087007};\\\", \\\"{x:1244,y:839,t:1526930087031};\\\", \\\"{x:1244,y:838,t:1526930087047};\\\", \\\"{x:1244,y:837,t:1526930087063};\\\", \\\"{x:1244,y:836,t:1526930087087};\\\", \\\"{x:1244,y:834,t:1526930087119};\\\", \\\"{x:1242,y:834,t:1526930087143};\\\", \\\"{x:1241,y:834,t:1526930087157};\\\", \\\"{x:1240,y:833,t:1526930087173};\\\", \\\"{x:1240,y:832,t:1526930087191};\\\", \\\"{x:1239,y:832,t:1526930087222};\\\", \\\"{x:1236,y:831,t:1526930087240};\\\", \\\"{x:1231,y:830,t:1526930087257};\\\", \\\"{x:1230,y:830,t:1526930087287};\\\", \\\"{x:1228,y:829,t:1526930087295};\\\", \\\"{x:1227,y:828,t:1526930087311};\\\", \\\"{x:1226,y:828,t:1526930087327};\\\", \\\"{x:1226,y:827,t:1526930087343};\\\", \\\"{x:1225,y:827,t:1526930087358};\\\", \\\"{x:1224,y:826,t:1526930087374};\\\", \\\"{x:1223,y:826,t:1526930087399};\\\", \\\"{x:1222,y:826,t:1526930087415};\\\", \\\"{x:1221,y:826,t:1526930087424};\\\", \\\"{x:1220,y:826,t:1526930087527};\\\", \\\"{x:1218,y:826,t:1526930087543};\\\", \\\"{x:1216,y:826,t:1526930087574};\\\", \\\"{x:1215,y:826,t:1526930087613};\\\", \\\"{x:1214,y:826,t:1526930090198};\\\", \\\"{x:1214,y:828,t:1526930090209};\\\", \\\"{x:1215,y:833,t:1526930090226};\\\", \\\"{x:1216,y:839,t:1526930090243};\\\", \\\"{x:1218,y:844,t:1526930090259};\\\", \\\"{x:1224,y:854,t:1526930090276};\\\", \\\"{x:1229,y:862,t:1526930090292};\\\", \\\"{x:1233,y:869,t:1526930090310};\\\", \\\"{x:1237,y:881,t:1526930090326};\\\", \\\"{x:1239,y:890,t:1526930090344};\\\", \\\"{x:1239,y:900,t:1526930090359};\\\", \\\"{x:1240,y:906,t:1526930090376};\\\", \\\"{x:1240,y:910,t:1526930090392};\\\", \\\"{x:1240,y:917,t:1526930090409};\\\", \\\"{x:1240,y:923,t:1526930090426};\\\", \\\"{x:1239,y:925,t:1526930090443};\\\", \\\"{x:1235,y:931,t:1526930090459};\\\", \\\"{x:1233,y:934,t:1526930090476};\\\", \\\"{x:1231,y:938,t:1526930090493};\\\", \\\"{x:1229,y:940,t:1526930090510};\\\", \\\"{x:1228,y:942,t:1526930090526};\\\", \\\"{x:1227,y:943,t:1526930090544};\\\", \\\"{x:1226,y:943,t:1526930090560};\\\", \\\"{x:1224,y:944,t:1526930090576};\\\", \\\"{x:1224,y:945,t:1526930090594};\\\", \\\"{x:1222,y:946,t:1526930090610};\\\", \\\"{x:1222,y:948,t:1526930090627};\\\", \\\"{x:1221,y:950,t:1526930090644};\\\", \\\"{x:1220,y:951,t:1526930090687};\\\", \\\"{x:1217,y:953,t:1526930090695};\\\", \\\"{x:1213,y:954,t:1526930090710};\\\", \\\"{x:1213,y:955,t:1526930090727};\\\", \\\"{x:1213,y:956,t:1526930090744};\\\", \\\"{x:1213,y:957,t:1526930090760};\\\", \\\"{x:1212,y:958,t:1526930090777};\\\", \\\"{x:1212,y:959,t:1526930090793};\\\", \\\"{x:1212,y:958,t:1526930090902};\\\", \\\"{x:1215,y:954,t:1526930090911};\\\", \\\"{x:1221,y:949,t:1526930090927};\\\", \\\"{x:1227,y:940,t:1526930090944};\\\", \\\"{x:1240,y:928,t:1526930090961};\\\", \\\"{x:1250,y:918,t:1526930090976};\\\", \\\"{x:1260,y:909,t:1526930090993};\\\", \\\"{x:1270,y:901,t:1526930091011};\\\", \\\"{x:1275,y:895,t:1526930091027};\\\", \\\"{x:1278,y:892,t:1526930091044};\\\", \\\"{x:1279,y:891,t:1526930091119};\\\", \\\"{x:1280,y:890,t:1526930091167};\\\", \\\"{x:1280,y:889,t:1526930091178};\\\", \\\"{x:1282,y:885,t:1526930091193};\\\", \\\"{x:1285,y:878,t:1526930091210};\\\", \\\"{x:1289,y:870,t:1526930091228};\\\", \\\"{x:1292,y:864,t:1526930091243};\\\", \\\"{x:1295,y:857,t:1526930091261};\\\", \\\"{x:1296,y:851,t:1526930091278};\\\", \\\"{x:1296,y:848,t:1526930091294};\\\", \\\"{x:1296,y:845,t:1526930091311};\\\", \\\"{x:1296,y:844,t:1526930091327};\\\", \\\"{x:1296,y:842,t:1526930091344};\\\", \\\"{x:1296,y:838,t:1526930091361};\\\", \\\"{x:1296,y:835,t:1526930091378};\\\", \\\"{x:1295,y:832,t:1526930091394};\\\", \\\"{x:1295,y:831,t:1526930091411};\\\", \\\"{x:1294,y:830,t:1526930091428};\\\", \\\"{x:1293,y:829,t:1526930091471};\\\", \\\"{x:1293,y:828,t:1526930091495};\\\", \\\"{x:1292,y:827,t:1526930091518};\\\", \\\"{x:1291,y:826,t:1526930091543};\\\", \\\"{x:1290,y:826,t:1526930091623};\\\", \\\"{x:1290,y:825,t:1526930091655};\\\", \\\"{x:1288,y:825,t:1526930091719};\\\", \\\"{x:1287,y:825,t:1526930091751};\\\", \\\"{x:1284,y:825,t:1526930091799};\\\", \\\"{x:1284,y:826,t:1526930091811};\\\", \\\"{x:1283,y:826,t:1526930091847};\\\", \\\"{x:1281,y:826,t:1526930091862};\\\", \\\"{x:1279,y:827,t:1526930091878};\\\", \\\"{x:1277,y:828,t:1526930091894};\\\", \\\"{x:1276,y:829,t:1526930094815};\\\", \\\"{x:1275,y:832,t:1526930094832};\\\", \\\"{x:1275,y:834,t:1526930094847};\\\", \\\"{x:1275,y:838,t:1526930094864};\\\", \\\"{x:1275,y:844,t:1526930094881};\\\", \\\"{x:1289,y:863,t:1526930094897};\\\", \\\"{x:1302,y:882,t:1526930094914};\\\", \\\"{x:1309,y:893,t:1526930094931};\\\", \\\"{x:1316,y:906,t:1526930094947};\\\", \\\"{x:1322,y:915,t:1526930094964};\\\", \\\"{x:1326,y:922,t:1526930094981};\\\", \\\"{x:1326,y:927,t:1526930094998};\\\", \\\"{x:1326,y:933,t:1526930095014};\\\", \\\"{x:1326,y:938,t:1526930095030};\\\", \\\"{x:1324,y:941,t:1526930095048};\\\", \\\"{x:1321,y:944,t:1526930095064};\\\", \\\"{x:1318,y:947,t:1526930095081};\\\", \\\"{x:1316,y:947,t:1526930095183};\\\", \\\"{x:1316,y:948,t:1526930095198};\\\", \\\"{x:1311,y:950,t:1526930095214};\\\", \\\"{x:1305,y:951,t:1526930095231};\\\", \\\"{x:1303,y:951,t:1526930095248};\\\", \\\"{x:1299,y:954,t:1526930095265};\\\", \\\"{x:1297,y:954,t:1526930095280};\\\", \\\"{x:1294,y:956,t:1526930095298};\\\", \\\"{x:1290,y:958,t:1526930095314};\\\", \\\"{x:1288,y:960,t:1526930095331};\\\", \\\"{x:1285,y:961,t:1526930095347};\\\", \\\"{x:1283,y:961,t:1526930095364};\\\", \\\"{x:1284,y:961,t:1526930095478};\\\", \\\"{x:1289,y:959,t:1526930095486};\\\", \\\"{x:1293,y:955,t:1526930095497};\\\", \\\"{x:1304,y:944,t:1526930095514};\\\", \\\"{x:1319,y:928,t:1526930095530};\\\", \\\"{x:1331,y:918,t:1526930095547};\\\", \\\"{x:1345,y:910,t:1526930095564};\\\", \\\"{x:1358,y:896,t:1526930095580};\\\", \\\"{x:1368,y:888,t:1526930095598};\\\", \\\"{x:1378,y:871,t:1526930095614};\\\", \\\"{x:1382,y:861,t:1526930095631};\\\", \\\"{x:1386,y:846,t:1526930095648};\\\", \\\"{x:1391,y:836,t:1526930095665};\\\", \\\"{x:1392,y:829,t:1526930095682};\\\", \\\"{x:1396,y:820,t:1526930095698};\\\", \\\"{x:1397,y:813,t:1526930095715};\\\", \\\"{x:1399,y:809,t:1526930095731};\\\", \\\"{x:1400,y:807,t:1526930095748};\\\", \\\"{x:1401,y:802,t:1526930095765};\\\", \\\"{x:1402,y:798,t:1526930095782};\\\", \\\"{x:1402,y:796,t:1526930095798};\\\", \\\"{x:1402,y:790,t:1526930095814};\\\", \\\"{x:1402,y:787,t:1526930095832};\\\", \\\"{x:1402,y:784,t:1526930095852};\\\", \\\"{x:1402,y:783,t:1526930095869};\\\", \\\"{x:1402,y:781,t:1526930095886};\\\", \\\"{x:1402,y:779,t:1526930095902};\\\", \\\"{x:1402,y:777,t:1526930095919};\\\", \\\"{x:1401,y:774,t:1526930095936};\\\", \\\"{x:1400,y:773,t:1526930095952};\\\", \\\"{x:1399,y:772,t:1526930095969};\\\", \\\"{x:1398,y:771,t:1526930095986};\\\", \\\"{x:1394,y:767,t:1526930096002};\\\", \\\"{x:1390,y:767,t:1526930096020};\\\", \\\"{x:1388,y:767,t:1526930096037};\\\", \\\"{x:1384,y:766,t:1526930096053};\\\", \\\"{x:1383,y:766,t:1526930096086};\\\", \\\"{x:1383,y:765,t:1526930096103};\\\", \\\"{x:1383,y:764,t:1526930096119};\\\", \\\"{x:1383,y:763,t:1526930096137};\\\", \\\"{x:1383,y:765,t:1526930105772};\\\", \\\"{x:1385,y:770,t:1526930105780};\\\", \\\"{x:1385,y:784,t:1526930105796};\\\", \\\"{x:1383,y:804,t:1526930105812};\\\", \\\"{x:1373,y:818,t:1526930105828};\\\", \\\"{x:1367,y:833,t:1526930105845};\\\", \\\"{x:1359,y:853,t:1526930105861};\\\", \\\"{x:1354,y:873,t:1526930105879};\\\", \\\"{x:1354,y:895,t:1526930105895};\\\", \\\"{x:1359,y:913,t:1526930105911};\\\", \\\"{x:1365,y:921,t:1526930105928};\\\", \\\"{x:1365,y:923,t:1526930105946};\\\", \\\"{x:1365,y:926,t:1526930106028};\\\", \\\"{x:1365,y:930,t:1526930106035};\\\", \\\"{x:1365,y:933,t:1526930106046};\\\", \\\"{x:1366,y:938,t:1526930106061};\\\", \\\"{x:1365,y:941,t:1526930106078};\\\", \\\"{x:1365,y:942,t:1526930106095};\\\", \\\"{x:1365,y:943,t:1526930106112};\\\", \\\"{x:1365,y:944,t:1526930106131};\\\", \\\"{x:1365,y:945,t:1526930106180};\\\", \\\"{x:1365,y:948,t:1526930106196};\\\", \\\"{x:1365,y:949,t:1526930106213};\\\", \\\"{x:1364,y:949,t:1526930106229};\\\", \\\"{x:1361,y:951,t:1526930106246};\\\", \\\"{x:1358,y:951,t:1526930106283};\\\", \\\"{x:1354,y:952,t:1526930106295};\\\", \\\"{x:1348,y:956,t:1526930106313};\\\", \\\"{x:1343,y:959,t:1526930106329};\\\", \\\"{x:1340,y:959,t:1526930106346};\\\", \\\"{x:1332,y:963,t:1526930106363};\\\", \\\"{x:1323,y:967,t:1526930106379};\\\", \\\"{x:1316,y:968,t:1526930106396};\\\", \\\"{x:1314,y:969,t:1526930106414};\\\", \\\"{x:1313,y:970,t:1526930106429};\\\", \\\"{x:1312,y:970,t:1526930106467};\\\", \\\"{x:1311,y:970,t:1526930106478};\\\", \\\"{x:1309,y:970,t:1526930106495};\\\", \\\"{x:1306,y:972,t:1526930106512};\\\", \\\"{x:1304,y:972,t:1526930106528};\\\", \\\"{x:1304,y:973,t:1526930106545};\\\", \\\"{x:1305,y:973,t:1526930106796};\\\", \\\"{x:1306,y:971,t:1526930106812};\\\", \\\"{x:1308,y:970,t:1526930106830};\\\", \\\"{x:1309,y:969,t:1526930106846};\\\", \\\"{x:1310,y:968,t:1526930106863};\\\", \\\"{x:1310,y:966,t:1526930106899};\\\", \\\"{x:1311,y:964,t:1526930106915};\\\", \\\"{x:1313,y:964,t:1526930106947};\\\", \\\"{x:1315,y:958,t:1526930106963};\\\", \\\"{x:1317,y:953,t:1526930106980};\\\", \\\"{x:1320,y:948,t:1526930106997};\\\", \\\"{x:1322,y:945,t:1526930107013};\\\", \\\"{x:1325,y:940,t:1526930107030};\\\", \\\"{x:1327,y:937,t:1526930107047};\\\", \\\"{x:1327,y:936,t:1526930107063};\\\", \\\"{x:1327,y:935,t:1526930107080};\\\", \\\"{x:1327,y:934,t:1526930107098};\\\", \\\"{x:1327,y:932,t:1526930107123};\\\", \\\"{x:1327,y:931,t:1526930107131};\\\", \\\"{x:1329,y:928,t:1526930107147};\\\", \\\"{x:1332,y:925,t:1526930107162};\\\", \\\"{x:1338,y:919,t:1526930107180};\\\", \\\"{x:1341,y:913,t:1526930107197};\\\", \\\"{x:1345,y:909,t:1526930107213};\\\", \\\"{x:1351,y:905,t:1526930107230};\\\", \\\"{x:1355,y:902,t:1526930107247};\\\", \\\"{x:1356,y:899,t:1526930107264};\\\", \\\"{x:1359,y:897,t:1526930107280};\\\", \\\"{x:1360,y:896,t:1526930107307};\\\", \\\"{x:1360,y:895,t:1526930107331};\\\", \\\"{x:1362,y:894,t:1526930107347};\\\", \\\"{x:1362,y:893,t:1526930107682};\\\", \\\"{x:1360,y:893,t:1526930107770};\\\", \\\"{x:1359,y:893,t:1526930107851};\\\", \\\"{x:1358,y:894,t:1526930107864};\\\", \\\"{x:1358,y:895,t:1526930107882};\\\", \\\"{x:1357,y:895,t:1526930107906};\\\", \\\"{x:1356,y:895,t:1526930107922};\\\", \\\"{x:1355,y:895,t:1526930107930};\\\", \\\"{x:1354,y:896,t:1526930107947};\\\", \\\"{x:1354,y:897,t:1526930107963};\\\", \\\"{x:1352,y:897,t:1526930107981};\\\", \\\"{x:1351,y:897,t:1526930109643};\\\", \\\"{x:1351,y:896,t:1526930109715};\\\", \\\"{x:1351,y:895,t:1526930109787};\\\", \\\"{x:1351,y:894,t:1526930109803};\\\", \\\"{x:1352,y:894,t:1526930109827};\\\", \\\"{x:1353,y:894,t:1526930109931};\\\", \\\"{x:1354,y:894,t:1526930109939};\\\", \\\"{x:1355,y:894,t:1526930109955};\\\", \\\"{x:1356,y:894,t:1526930109987};\\\", \\\"{x:1357,y:894,t:1526930110131};\\\", \\\"{x:1360,y:894,t:1526930110154};\\\", \\\"{x:1362,y:894,t:1526930110166};\\\", \\\"{x:1365,y:894,t:1526930110183};\\\", \\\"{x:1371,y:894,t:1526930110199};\\\", \\\"{x:1374,y:894,t:1526930110216};\\\", \\\"{x:1375,y:894,t:1526930110233};\\\", \\\"{x:1377,y:894,t:1526930110249};\\\", \\\"{x:1379,y:894,t:1526930110316};\\\", \\\"{x:1379,y:893,t:1526930110339};\\\", \\\"{x:1380,y:893,t:1526930110350};\\\", \\\"{x:1382,y:893,t:1526930110491};\\\", \\\"{x:1383,y:892,t:1526930118027};\\\", \\\"{x:1383,y:891,t:1526930118041};\\\", \\\"{x:1383,y:881,t:1526930118056};\\\", \\\"{x:1379,y:852,t:1526930118074};\\\", \\\"{x:1356,y:774,t:1526930118090};\\\", \\\"{x:1331,y:693,t:1526930118106};\\\", \\\"{x:1300,y:601,t:1526930118123};\\\", \\\"{x:1284,y:527,t:1526930118141};\\\", \\\"{x:1280,y:494,t:1526930118156};\\\", \\\"{x:1276,y:477,t:1526930118174};\\\", \\\"{x:1276,y:458,t:1526930118190};\\\", \\\"{x:1276,y:450,t:1526930118206};\\\", \\\"{x:1276,y:447,t:1526930118223};\\\", \\\"{x:1276,y:446,t:1526930118240};\\\", \\\"{x:1276,y:445,t:1526930118259};\\\", \\\"{x:1276,y:443,t:1526930118273};\\\", \\\"{x:1276,y:442,t:1526930118290};\\\", \\\"{x:1276,y:443,t:1526930118346};\\\", \\\"{x:1276,y:451,t:1526930118357};\\\", \\\"{x:1276,y:469,t:1526930118373};\\\", \\\"{x:1276,y:481,t:1526930118390};\\\", \\\"{x:1284,y:504,t:1526930118408};\\\", \\\"{x:1296,y:532,t:1526930118424};\\\", \\\"{x:1312,y:557,t:1526930118441};\\\", \\\"{x:1329,y:579,t:1526930118458};\\\", \\\"{x:1331,y:584,t:1526930118474};\\\", \\\"{x:1340,y:593,t:1526930118490};\\\", \\\"{x:1342,y:594,t:1526930118507};\\\", \\\"{x:1343,y:594,t:1526930118563};\\\", \\\"{x:1344,y:594,t:1526930118611};\\\", \\\"{x:1346,y:594,t:1526930118624};\\\", \\\"{x:1347,y:594,t:1526930118640};\\\", \\\"{x:1349,y:590,t:1526930118658};\\\", \\\"{x:1349,y:589,t:1526930118683};\\\", \\\"{x:1349,y:587,t:1526930118690};\\\", \\\"{x:1349,y:583,t:1526930118707};\\\", \\\"{x:1350,y:579,t:1526930118725};\\\", \\\"{x:1350,y:577,t:1526930118740};\\\", \\\"{x:1350,y:575,t:1526930118758};\\\", \\\"{x:1350,y:572,t:1526930118774};\\\", \\\"{x:1350,y:569,t:1526930118790};\\\", \\\"{x:1350,y:568,t:1526930118807};\\\", \\\"{x:1350,y:569,t:1526930118875};\\\", \\\"{x:1350,y:572,t:1526930118891};\\\", \\\"{x:1356,y:583,t:1526930118908};\\\", \\\"{x:1368,y:600,t:1526930118924};\\\", \\\"{x:1381,y:618,t:1526930118940};\\\", \\\"{x:1396,y:637,t:1526930118958};\\\", \\\"{x:1411,y:655,t:1526930118975};\\\", \\\"{x:1417,y:663,t:1526930118991};\\\", \\\"{x:1426,y:676,t:1526930119007};\\\", \\\"{x:1426,y:678,t:1526930119025};\\\", \\\"{x:1433,y:691,t:1526930119042};\\\", \\\"{x:1443,y:707,t:1526930119060};\\\", \\\"{x:1448,y:716,t:1526930119074};\\\", \\\"{x:1461,y:728,t:1526930119091};\\\", \\\"{x:1466,y:733,t:1526930119107};\\\", \\\"{x:1468,y:739,t:1526930119124};\\\", \\\"{x:1471,y:746,t:1526930119141};\\\", \\\"{x:1472,y:755,t:1526930119157};\\\", \\\"{x:1473,y:770,t:1526930119175};\\\", \\\"{x:1476,y:786,t:1526930119192};\\\", \\\"{x:1481,y:803,t:1526930119207};\\\", \\\"{x:1487,y:814,t:1526930119224};\\\", \\\"{x:1491,y:821,t:1526930119241};\\\", \\\"{x:1493,y:831,t:1526930119259};\\\", \\\"{x:1496,y:840,t:1526930119275};\\\", \\\"{x:1497,y:846,t:1526930119291};\\\", \\\"{x:1500,y:859,t:1526930119307};\\\", \\\"{x:1511,y:873,t:1526930119325};\\\", \\\"{x:1515,y:881,t:1526930119341};\\\", \\\"{x:1519,y:888,t:1526930119358};\\\", \\\"{x:1526,y:896,t:1526930119375};\\\", \\\"{x:1533,y:906,t:1526930119392};\\\", \\\"{x:1539,y:914,t:1526930119408};\\\", \\\"{x:1543,y:918,t:1526930119423};\\\", \\\"{x:1548,y:924,t:1526930119440};\\\", \\\"{x:1557,y:934,t:1526930119457};\\\", \\\"{x:1563,y:940,t:1526930119473};\\\", \\\"{x:1567,y:946,t:1526930119491};\\\", \\\"{x:1570,y:950,t:1526930119508};\\\", \\\"{x:1572,y:953,t:1526930119524};\\\", \\\"{x:1574,y:959,t:1526930119541};\\\", \\\"{x:1577,y:961,t:1526930119558};\\\", \\\"{x:1577,y:962,t:1526930119594};\\\", \\\"{x:1577,y:963,t:1526930119610};\\\", \\\"{x:1577,y:964,t:1526930119658};\\\", \\\"{x:1572,y:965,t:1526930119674};\\\", \\\"{x:1563,y:965,t:1526930119691};\\\", \\\"{x:1554,y:965,t:1526930119707};\\\", \\\"{x:1549,y:965,t:1526930119724};\\\", \\\"{x:1548,y:965,t:1526930119741};\\\", \\\"{x:1547,y:965,t:1526930119779};\\\", \\\"{x:1547,y:964,t:1526930120226};\\\", \\\"{x:1522,y:955,t:1526930134484};\\\", \\\"{x:1464,y:934,t:1526930134490};\\\", \\\"{x:1413,y:914,t:1526930134505};\\\", \\\"{x:1317,y:881,t:1526930134522};\\\", \\\"{x:1284,y:862,t:1526930134538};\\\", \\\"{x:1253,y:846,t:1526930134554};\\\", \\\"{x:1229,y:832,t:1526930134572};\\\", \\\"{x:1222,y:828,t:1526930134589};\\\", \\\"{x:1221,y:827,t:1526930134604};\\\", \\\"{x:1220,y:825,t:1526930134622};\\\", \\\"{x:1220,y:824,t:1526930134642};\\\", \\\"{x:1220,y:822,t:1526930134654};\\\", \\\"{x:1218,y:808,t:1526930134671};\\\", \\\"{x:1216,y:798,t:1526930134689};\\\", \\\"{x:1216,y:792,t:1526930134704};\\\", \\\"{x:1215,y:788,t:1526930134721};\\\", \\\"{x:1215,y:787,t:1526930134754};\\\", \\\"{x:1211,y:793,t:1526930134762};\\\", \\\"{x:1207,y:803,t:1526930134772};\\\", \\\"{x:1197,y:830,t:1526930134788};\\\", \\\"{x:1189,y:854,t:1526930134806};\\\", \\\"{x:1182,y:882,t:1526930134821};\\\", \\\"{x:1174,y:911,t:1526930134838};\\\", \\\"{x:1169,y:935,t:1526930134855};\\\", \\\"{x:1168,y:956,t:1526930134871};\\\", \\\"{x:1168,y:967,t:1526930134888};\\\", \\\"{x:1168,y:970,t:1526930134906};\\\", \\\"{x:1166,y:969,t:1526930135081};\\\", \\\"{x:1166,y:968,t:1526930135089};\\\", \\\"{x:1165,y:967,t:1526930135105};\\\", \\\"{x:1164,y:967,t:1526930135137};\\\", \\\"{x:1163,y:967,t:1526930135145};\\\", \\\"{x:1162,y:967,t:1526930135170};\\\", \\\"{x:1162,y:966,t:1526930135201};\\\", \\\"{x:1162,y:963,t:1526930135210};\\\", \\\"{x:1162,y:950,t:1526930135223};\\\", \\\"{x:1165,y:924,t:1526930135238};\\\", \\\"{x:1169,y:908,t:1526930135255};\\\", \\\"{x:1178,y:891,t:1526930135272};\\\", \\\"{x:1186,y:871,t:1526930135288};\\\", \\\"{x:1196,y:849,t:1526930135306};\\\", \\\"{x:1198,y:839,t:1526930135322};\\\", \\\"{x:1198,y:835,t:1526930135339};\\\", \\\"{x:1197,y:834,t:1526930135395};\\\", \\\"{x:1190,y:838,t:1526930135406};\\\", \\\"{x:1170,y:850,t:1526930135423};\\\", \\\"{x:1143,y:872,t:1526930135439};\\\", \\\"{x:1133,y:878,t:1526930135455};\\\", \\\"{x:1115,y:897,t:1526930135472};\\\", \\\"{x:1108,y:908,t:1526930135488};\\\", \\\"{x:1108,y:910,t:1526930135513};\\\", \\\"{x:1108,y:912,t:1526930135529};\\\", \\\"{x:1108,y:913,t:1526930135539};\\\", \\\"{x:1108,y:916,t:1526930135610};\\\", \\\"{x:1109,y:917,t:1526930135622};\\\", \\\"{x:1110,y:918,t:1526930135639};\\\", \\\"{x:1114,y:921,t:1526930135656};\\\", \\\"{x:1120,y:926,t:1526930135672};\\\", \\\"{x:1133,y:936,t:1526930135689};\\\", \\\"{x:1140,y:939,t:1526930135706};\\\", \\\"{x:1142,y:940,t:1526930135722};\\\", \\\"{x:1142,y:941,t:1526930135818};\\\", \\\"{x:1142,y:942,t:1526930135835};\\\", \\\"{x:1141,y:946,t:1526930135850};\\\", \\\"{x:1140,y:947,t:1526930135907};\\\", \\\"{x:1139,y:948,t:1526930135963};\\\", \\\"{x:1138,y:949,t:1526930135978};\\\", \\\"{x:1137,y:949,t:1526930135990};\\\", \\\"{x:1136,y:949,t:1526930136007};\\\", \\\"{x:1136,y:951,t:1526930136023};\\\", \\\"{x:1136,y:953,t:1526930136040};\\\", \\\"{x:1136,y:955,t:1526930136057};\\\", \\\"{x:1136,y:956,t:1526930136073};\\\", \\\"{x:1136,y:959,t:1526930136090};\\\", \\\"{x:1136,y:961,t:1526930136211};\\\", \\\"{x:1136,y:962,t:1526930136242};\\\", \\\"{x:1136,y:964,t:1526930136323};\\\", \\\"{x:1137,y:964,t:1526930136340};\\\", \\\"{x:1140,y:964,t:1526930136357};\\\", \\\"{x:1142,y:964,t:1526930136374};\\\", \\\"{x:1145,y:964,t:1526930136389};\\\", \\\"{x:1149,y:962,t:1526930136407};\\\", \\\"{x:1150,y:961,t:1526930136424};\\\", \\\"{x:1152,y:960,t:1526930136440};\\\", \\\"{x:1154,y:959,t:1526930136459};\\\", \\\"{x:1154,y:958,t:1526930136474};\\\", \\\"{x:1155,y:957,t:1526930136498};\\\", \\\"{x:1158,y:957,t:1526930136507};\\\", \\\"{x:1161,y:955,t:1526930136524};\\\", \\\"{x:1162,y:954,t:1526930136540};\\\", \\\"{x:1163,y:954,t:1526930136557};\\\", \\\"{x:1162,y:954,t:1526930136939};\\\", \\\"{x:1161,y:954,t:1526930136963};\\\", \\\"{x:1160,y:955,t:1526930136995};\\\", \\\"{x:1159,y:955,t:1526930137011};\\\", \\\"{x:1158,y:955,t:1526930137023};\\\", \\\"{x:1158,y:954,t:1526930137931};\\\", \\\"{x:1158,y:951,t:1526930137942};\\\", \\\"{x:1165,y:941,t:1526930137958};\\\", \\\"{x:1174,y:931,t:1526930137974};\\\", \\\"{x:1184,y:926,t:1526930137992};\\\", \\\"{x:1198,y:908,t:1526930138008};\\\", \\\"{x:1210,y:889,t:1526930138025};\\\", \\\"{x:1227,y:857,t:1526930138042};\\\", \\\"{x:1232,y:840,t:1526930138059};\\\", \\\"{x:1239,y:818,t:1526930138075};\\\", \\\"{x:1243,y:802,t:1526930138092};\\\", \\\"{x:1248,y:785,t:1526930138108};\\\", \\\"{x:1250,y:776,t:1526930138125};\\\", \\\"{x:1254,y:767,t:1526930138142};\\\", \\\"{x:1257,y:761,t:1526930138158};\\\", \\\"{x:1260,y:755,t:1526930138175};\\\", \\\"{x:1261,y:748,t:1526930138192};\\\", \\\"{x:1262,y:739,t:1526930138209};\\\", \\\"{x:1265,y:733,t:1526930138225};\\\", \\\"{x:1270,y:725,t:1526930138242};\\\", \\\"{x:1270,y:719,t:1526930138258};\\\", \\\"{x:1271,y:717,t:1526930138275};\\\", \\\"{x:1273,y:714,t:1526930138292};\\\", \\\"{x:1280,y:710,t:1526930138309};\\\", \\\"{x:1286,y:705,t:1526930138325};\\\", \\\"{x:1297,y:695,t:1526930138342};\\\", \\\"{x:1308,y:683,t:1526930138359};\\\", \\\"{x:1317,y:676,t:1526930138375};\\\", \\\"{x:1330,y:667,t:1526930138392};\\\", \\\"{x:1339,y:650,t:1526930138409};\\\", \\\"{x:1347,y:640,t:1526930138425};\\\", \\\"{x:1354,y:631,t:1526930138443};\\\", \\\"{x:1355,y:627,t:1526930138458};\\\", \\\"{x:1356,y:625,t:1526930138475};\\\", \\\"{x:1356,y:624,t:1526930138674};\\\", \\\"{x:1354,y:625,t:1526930138692};\\\", \\\"{x:1350,y:629,t:1526930138709};\\\", \\\"{x:1345,y:634,t:1526930138726};\\\", \\\"{x:1343,y:636,t:1526930138742};\\\", \\\"{x:1343,y:637,t:1526930138759};\\\", \\\"{x:1341,y:638,t:1526930138776};\\\", \\\"{x:1340,y:638,t:1526930138792};\\\", \\\"{x:1339,y:639,t:1526930138809};\\\", \\\"{x:1338,y:640,t:1526930138891};\\\", \\\"{x:1337,y:640,t:1526930138995};\\\", \\\"{x:1334,y:640,t:1526930139058};\\\", \\\"{x:1329,y:638,t:1526930139076};\\\", \\\"{x:1328,y:637,t:1526930139093};\\\", \\\"{x:1327,y:636,t:1526930139114};\\\", \\\"{x:1326,y:635,t:1526930139138};\\\", \\\"{x:1323,y:634,t:1526930139170};\\\", \\\"{x:1323,y:633,t:1526930139186};\\\", \\\"{x:1321,y:633,t:1526930139235};\\\", \\\"{x:1320,y:633,t:1526930139307};\\\", \\\"{x:1319,y:633,t:1526930139314};\\\", \\\"{x:1318,y:633,t:1526930139402};\\\", \\\"{x:1316,y:632,t:1526930139410};\\\", \\\"{x:1315,y:632,t:1526930139834};\\\", \\\"{x:1313,y:632,t:1526930146202};\\\", \\\"{x:1311,y:632,t:1526930146217};\\\", \\\"{x:1309,y:632,t:1526930146232};\\\", \\\"{x:1305,y:632,t:1526930146250};\\\", \\\"{x:1300,y:632,t:1526930146266};\\\", \\\"{x:1299,y:634,t:1526930146378};\\\", \\\"{x:1298,y:636,t:1526930146386};\\\", \\\"{x:1298,y:638,t:1526930146399};\\\", \\\"{x:1297,y:641,t:1526930146416};\\\", \\\"{x:1296,y:642,t:1526930146450};\\\", \\\"{x:1293,y:643,t:1526930146466};\\\", \\\"{x:1289,y:645,t:1526930146483};\\\", \\\"{x:1287,y:648,t:1526930146499};\\\", \\\"{x:1285,y:649,t:1526930146515};\\\", \\\"{x:1285,y:650,t:1526930146533};\\\", \\\"{x:1284,y:651,t:1526930146548};\\\", \\\"{x:1280,y:654,t:1526930146565};\\\", \\\"{x:1280,y:655,t:1526930146583};\\\", \\\"{x:1278,y:656,t:1526930146598};\\\", \\\"{x:1276,y:657,t:1526930146617};\\\", \\\"{x:1274,y:651,t:1526930146738};\\\", \\\"{x:1270,y:642,t:1526930146748};\\\", \\\"{x:1265,y:630,t:1526930146766};\\\", \\\"{x:1264,y:624,t:1526930146783};\\\", \\\"{x:1264,y:621,t:1526930146799};\\\", \\\"{x:1264,y:620,t:1526930146816};\\\", \\\"{x:1261,y:619,t:1526930146842};\\\", \\\"{x:1247,y:623,t:1526930146850};\\\", \\\"{x:1143,y:642,t:1526930146866};\\\", \\\"{x:1003,y:657,t:1526930146883};\\\", \\\"{x:861,y:664,t:1526930146901};\\\", \\\"{x:710,y:656,t:1526930146917};\\\", \\\"{x:563,y:630,t:1526930146933};\\\", \\\"{x:433,y:618,t:1526930146950};\\\", \\\"{x:293,y:608,t:1526930146972};\\\", \\\"{x:257,y:605,t:1526930146990};\\\", \\\"{x:251,y:604,t:1526930147007};\\\", \\\"{x:249,y:603,t:1526930147022};\\\", \\\"{x:249,y:601,t:1526930147081};\\\", \\\"{x:247,y:595,t:1526930147090};\\\", \\\"{x:246,y:590,t:1526930147107};\\\", \\\"{x:246,y:582,t:1526930147123};\\\", \\\"{x:246,y:578,t:1526930147140};\\\", \\\"{x:251,y:574,t:1526930147157};\\\", \\\"{x:278,y:567,t:1526930147174};\\\", \\\"{x:315,y:562,t:1526930147189};\\\", \\\"{x:394,y:560,t:1526930147207};\\\", \\\"{x:466,y:560,t:1526930147222};\\\", \\\"{x:522,y:559,t:1526930147241};\\\", \\\"{x:582,y:558,t:1526930147258};\\\", \\\"{x:599,y:553,t:1526930147274};\\\", \\\"{x:622,y:548,t:1526930147290};\\\", \\\"{x:647,y:545,t:1526930147307};\\\", \\\"{x:679,y:545,t:1526930147323};\\\", \\\"{x:727,y:543,t:1526930147341};\\\", \\\"{x:761,y:541,t:1526930147356};\\\", \\\"{x:780,y:538,t:1526930147373};\\\", \\\"{x:789,y:536,t:1526930147389};\\\", \\\"{x:794,y:534,t:1526930147407};\\\", \\\"{x:794,y:533,t:1526930147423};\\\", \\\"{x:795,y:532,t:1526930147498};\\\", \\\"{x:796,y:531,t:1526930147562};\\\", \\\"{x:797,y:531,t:1526930147601};\\\", \\\"{x:798,y:531,t:1526930147610};\\\", \\\"{x:799,y:531,t:1526930147623};\\\", \\\"{x:802,y:532,t:1526930147640};\\\", \\\"{x:805,y:532,t:1526930147657};\\\", \\\"{x:807,y:533,t:1526930147673};\\\", \\\"{x:808,y:533,t:1526930147690};\\\", \\\"{x:809,y:533,t:1526930147754};\\\", \\\"{x:810,y:533,t:1526930147914};\\\", \\\"{x:811,y:533,t:1526930147922};\\\", \\\"{x:812,y:533,t:1526930147986};\\\", \\\"{x:812,y:534,t:1526930148026};\\\", \\\"{x:813,y:534,t:1526930148049};\\\", \\\"{x:814,y:534,t:1526930148058};\\\", \\\"{x:814,y:535,t:1526930148073};\\\", \\\"{x:814,y:536,t:1526930148090};\\\", \\\"{x:814,y:537,t:1526930148105};\\\", \\\"{x:814,y:538,t:1526930148122};\\\", \\\"{x:814,y:539,t:1526930148259};\\\", \\\"{x:815,y:539,t:1526930148371};\\\", \\\"{x:816,y:539,t:1526930148386};\\\", \\\"{x:818,y:539,t:1526930148394};\\\", \\\"{x:819,y:539,t:1526930148405};\\\", \\\"{x:821,y:538,t:1526930148421};\\\", \\\"{x:822,y:538,t:1526930148438};\\\", \\\"{x:823,y:537,t:1526930148455};\\\", \\\"{x:824,y:537,t:1526930148605};\\\", \\\"{x:824,y:537,t:1526930148714};\\\", \\\"{x:826,y:537,t:1526930149034};\\\", \\\"{x:836,y:533,t:1526930149042};\\\", \\\"{x:864,y:531,t:1526930149060};\\\", \\\"{x:949,y:538,t:1526930149076};\\\", \\\"{x:1011,y:539,t:1526930149092};\\\", \\\"{x:1061,y:544,t:1526930149108};\\\", \\\"{x:1081,y:546,t:1526930149125};\\\", \\\"{x:1101,y:546,t:1526930149142};\\\", \\\"{x:1105,y:546,t:1526930149157};\\\", \\\"{x:1106,y:546,t:1526930149175};\\\", \\\"{x:1105,y:546,t:1526930149217};\\\", \\\"{x:1103,y:547,t:1526930149233};\\\", \\\"{x:1101,y:549,t:1526930149241};\\\", \\\"{x:1088,y:550,t:1526930149258};\\\", \\\"{x:1034,y:550,t:1526930149275};\\\", \\\"{x:958,y:547,t:1526930149292};\\\", \\\"{x:888,y:536,t:1526930149309};\\\", \\\"{x:835,y:528,t:1526930149325};\\\", \\\"{x:816,y:523,t:1526930149342};\\\", \\\"{x:807,y:522,t:1526930149358};\\\", \\\"{x:805,y:522,t:1526930149375};\\\", \\\"{x:808,y:522,t:1526930149506};\\\", \\\"{x:810,y:522,t:1526930149513};\\\", \\\"{x:812,y:522,t:1526930149526};\\\", \\\"{x:816,y:523,t:1526930149542};\\\", \\\"{x:820,y:525,t:1526930149558};\\\", \\\"{x:828,y:531,t:1526930149576};\\\", \\\"{x:836,y:536,t:1526930149592};\\\", \\\"{x:839,y:537,t:1526930149609};\\\", \\\"{x:839,y:538,t:1526930149625};\\\", \\\"{x:840,y:539,t:1526930149977};\\\", \\\"{x:841,y:538,t:1526930150001};\\\", \\\"{x:842,y:538,t:1526930150066};\\\", \\\"{x:843,y:538,t:1526930150075};\\\", \\\"{x:846,y:536,t:1526930150092};\\\", \\\"{x:849,y:535,t:1526930150109};\\\", \\\"{x:858,y:534,t:1526930150126};\\\", \\\"{x:882,y:538,t:1526930150143};\\\", \\\"{x:911,y:542,t:1526930150159};\\\", \\\"{x:935,y:550,t:1526930150176};\\\", \\\"{x:973,y:564,t:1526930150193};\\\", \\\"{x:1037,y:575,t:1526930150209};\\\", \\\"{x:1053,y:580,t:1526930150225};\\\", \\\"{x:1066,y:585,t:1526930150242};\\\", \\\"{x:1087,y:585,t:1526930150259};\\\", \\\"{x:1113,y:586,t:1526930150276};\\\", \\\"{x:1116,y:586,t:1526930150292};\\\", \\\"{x:1133,y:586,t:1526930150308};\\\", \\\"{x:1151,y:586,t:1526930150326};\\\", \\\"{x:1161,y:586,t:1526930150342};\\\", \\\"{x:1172,y:586,t:1526930150359};\\\", \\\"{x:1184,y:586,t:1526930150376};\\\", \\\"{x:1189,y:585,t:1526930150392};\\\", \\\"{x:1205,y:584,t:1526930150409};\\\", \\\"{x:1216,y:581,t:1526930150426};\\\", \\\"{x:1222,y:578,t:1526930150443};\\\", \\\"{x:1226,y:577,t:1526930150459};\\\", \\\"{x:1230,y:577,t:1526930150476};\\\", \\\"{x:1232,y:576,t:1526930150493};\\\", \\\"{x:1245,y:575,t:1526930150509};\\\", \\\"{x:1258,y:572,t:1526930150526};\\\", \\\"{x:1267,y:572,t:1526930150543};\\\", \\\"{x:1276,y:571,t:1526930150559};\\\", \\\"{x:1278,y:571,t:1526930150576};\\\", \\\"{x:1281,y:570,t:1526930150593};\\\", \\\"{x:1285,y:568,t:1526930150609};\\\", \\\"{x:1294,y:568,t:1526930150627};\\\", \\\"{x:1308,y:568,t:1526930150643};\\\", \\\"{x:1323,y:571,t:1526930150660};\\\", \\\"{x:1333,y:577,t:1526930150676};\\\", \\\"{x:1340,y:585,t:1526930150693};\\\", \\\"{x:1343,y:591,t:1526930150709};\\\", \\\"{x:1347,y:599,t:1526930150726};\\\", \\\"{x:1351,y:606,t:1526930150743};\\\", \\\"{x:1355,y:612,t:1526930150759};\\\", \\\"{x:1361,y:618,t:1526930150776};\\\", \\\"{x:1361,y:621,t:1526930150793};\\\", \\\"{x:1361,y:624,t:1526930150809};\\\", \\\"{x:1361,y:625,t:1526930150826};\\\", \\\"{x:1360,y:626,t:1526930150844};\\\", \\\"{x:1359,y:627,t:1526930150861};\\\", \\\"{x:1358,y:628,t:1526930150876};\\\", \\\"{x:1356,y:628,t:1526930150914};\\\", \\\"{x:1355,y:628,t:1526930150938};\\\", \\\"{x:1354,y:629,t:1526930150946};\\\", \\\"{x:1351,y:629,t:1526930150962};\\\", \\\"{x:1350,y:629,t:1526930150976};\\\", \\\"{x:1346,y:629,t:1526930150994};\\\", \\\"{x:1344,y:629,t:1526930151010};\\\", \\\"{x:1343,y:629,t:1526930151091};\\\", \\\"{x:1342,y:629,t:1526930151290};\\\", \\\"{x:1343,y:629,t:1526930152073};\\\", \\\"{x:1345,y:627,t:1526930152082};\\\", \\\"{x:1347,y:626,t:1526930152097};\\\", \\\"{x:1348,y:625,t:1526930152110};\\\", \\\"{x:1351,y:622,t:1526930152127};\\\", \\\"{x:1351,y:621,t:1526930152144};\\\", \\\"{x:1353,y:620,t:1526930152160};\\\", \\\"{x:1358,y:619,t:1526930152177};\\\", \\\"{x:1365,y:614,t:1526930152194};\\\", \\\"{x:1369,y:612,t:1526930152210};\\\", \\\"{x:1371,y:611,t:1526930152228};\\\", \\\"{x:1373,y:609,t:1526930152244};\\\", \\\"{x:1374,y:609,t:1526930152260};\\\", \\\"{x:1375,y:609,t:1526930152379};\\\", \\\"{x:1378,y:615,t:1526930152395};\\\", \\\"{x:1379,y:617,t:1526930152412};\\\", \\\"{x:1380,y:618,t:1526930152428};\\\", \\\"{x:1381,y:623,t:1526930152444};\\\", \\\"{x:1381,y:635,t:1526930152461};\\\", \\\"{x:1381,y:645,t:1526930152478};\\\", \\\"{x:1382,y:661,t:1526930152494};\\\", \\\"{x:1381,y:681,t:1526930152511};\\\", \\\"{x:1380,y:698,t:1526930152528};\\\", \\\"{x:1380,y:710,t:1526930152545};\\\", \\\"{x:1374,y:727,t:1526930152562};\\\", \\\"{x:1372,y:733,t:1526930152577};\\\", \\\"{x:1368,y:738,t:1526930152595};\\\", \\\"{x:1363,y:745,t:1526930152612};\\\", \\\"{x:1358,y:752,t:1526930152627};\\\", \\\"{x:1352,y:758,t:1526930152645};\\\", \\\"{x:1346,y:765,t:1526930152661};\\\", \\\"{x:1341,y:769,t:1526930152678};\\\", \\\"{x:1334,y:775,t:1526930152694};\\\", \\\"{x:1329,y:775,t:1526930152711};\\\", \\\"{x:1321,y:780,t:1526930152728};\\\", \\\"{x:1315,y:780,t:1526930152744};\\\", \\\"{x:1308,y:785,t:1526930152761};\\\", \\\"{x:1305,y:787,t:1526930152777};\\\", \\\"{x:1303,y:787,t:1526930152794};\\\", \\\"{x:1297,y:794,t:1526930152811};\\\", \\\"{x:1297,y:795,t:1526930152827};\\\", \\\"{x:1295,y:797,t:1526930152844};\\\", \\\"{x:1294,y:799,t:1526930152865};\\\", \\\"{x:1293,y:800,t:1526930152877};\\\", \\\"{x:1291,y:802,t:1526930152894};\\\", \\\"{x:1290,y:803,t:1526930152911};\\\", \\\"{x:1289,y:804,t:1526930152928};\\\", \\\"{x:1288,y:804,t:1526930152954};\\\", \\\"{x:1287,y:805,t:1526930152961};\\\", \\\"{x:1286,y:806,t:1526930152978};\\\", \\\"{x:1284,y:808,t:1526930152994};\\\", \\\"{x:1283,y:808,t:1526930153011};\\\", \\\"{x:1282,y:810,t:1526930153028};\\\", \\\"{x:1282,y:811,t:1526930153050};\\\", \\\"{x:1281,y:811,t:1526930153066};\\\", \\\"{x:1278,y:813,t:1526930153098};\\\", \\\"{x:1278,y:816,t:1526930153114};\\\", \\\"{x:1276,y:817,t:1526930153128};\\\", \\\"{x:1274,y:819,t:1526930153145};\\\", \\\"{x:1272,y:822,t:1526930153162};\\\", \\\"{x:1268,y:826,t:1526930153178};\\\", \\\"{x:1267,y:829,t:1526930153196};\\\", \\\"{x:1265,y:832,t:1526930153212};\\\", \\\"{x:1263,y:834,t:1526930153228};\\\", \\\"{x:1258,y:840,t:1526930153245};\\\", \\\"{x:1252,y:845,t:1526930153261};\\\", \\\"{x:1251,y:848,t:1526930153279};\\\", \\\"{x:1247,y:851,t:1526930153295};\\\", \\\"{x:1244,y:855,t:1526930153312};\\\", \\\"{x:1240,y:863,t:1526930153329};\\\", \\\"{x:1235,y:875,t:1526930153345};\\\", \\\"{x:1233,y:879,t:1526930153362};\\\", \\\"{x:1232,y:881,t:1526930153378};\\\", \\\"{x:1232,y:882,t:1526930153396};\\\", \\\"{x:1230,y:883,t:1526930153412};\\\", \\\"{x:1229,y:885,t:1526930153650};\\\", \\\"{x:1229,y:886,t:1526930153665};\\\", \\\"{x:1229,y:887,t:1526930153679};\\\", \\\"{x:1229,y:888,t:1526930153696};\\\", \\\"{x:1232,y:885,t:1526930153778};\\\", \\\"{x:1241,y:882,t:1526930153796};\\\", \\\"{x:1243,y:880,t:1526930153813};\\\", \\\"{x:1248,y:877,t:1526930153828};\\\", \\\"{x:1252,y:873,t:1526930153846};\\\", \\\"{x:1260,y:867,t:1526930153863};\\\", \\\"{x:1265,y:863,t:1526930153878};\\\", \\\"{x:1267,y:860,t:1526930153895};\\\", \\\"{x:1271,y:857,t:1526930153913};\\\", \\\"{x:1272,y:853,t:1526930153929};\\\", \\\"{x:1274,y:850,t:1526930153945};\\\", \\\"{x:1274,y:847,t:1526930153962};\\\", \\\"{x:1274,y:843,t:1526930153978};\\\", \\\"{x:1275,y:841,t:1526930153995};\\\", \\\"{x:1275,y:840,t:1526930154012};\\\", \\\"{x:1276,y:839,t:1526930154029};\\\", \\\"{x:1277,y:839,t:1526930154050};\\\", \\\"{x:1278,y:837,t:1526930154073};\\\", \\\"{x:1278,y:836,t:1526930154114};\\\", \\\"{x:1278,y:835,t:1526930154138};\\\", \\\"{x:1278,y:834,t:1526930154163};\\\", \\\"{x:1279,y:833,t:1526930154218};\\\", \\\"{x:1279,y:832,t:1526930155998};\\\", \\\"{x:1279,y:830,t:1526930156005};\\\", \\\"{x:1279,y:829,t:1526930156017};\\\", \\\"{x:1278,y:827,t:1526930156062};\\\", \\\"{x:1277,y:827,t:1526930156069};\\\", \\\"{x:1273,y:827,t:1526930156084};\\\", \\\"{x:1255,y:827,t:1526930156101};\\\", \\\"{x:1238,y:827,t:1526930156117};\\\", \\\"{x:1216,y:827,t:1526930156135};\\\", \\\"{x:1152,y:824,t:1526930156152};\\\", \\\"{x:1078,y:818,t:1526930156167};\\\", \\\"{x:994,y:805,t:1526930156184};\\\", \\\"{x:890,y:778,t:1526930156201};\\\", \\\"{x:803,y:763,t:1526930156216};\\\", \\\"{x:758,y:756,t:1526930156234};\\\", \\\"{x:743,y:749,t:1526930156251};\\\", \\\"{x:711,y:747,t:1526930156266};\\\", \\\"{x:692,y:742,t:1526930156283};\\\", \\\"{x:670,y:740,t:1526930156301};\\\", \\\"{x:649,y:737,t:1526930156317};\\\", \\\"{x:626,y:732,t:1526930156334};\\\", \\\"{x:621,y:731,t:1526930156351};\\\", \\\"{x:601,y:722,t:1526930156367};\\\", \\\"{x:580,y:716,t:1526930156384};\\\", \\\"{x:563,y:710,t:1526930156401};\\\", \\\"{x:554,y:709,t:1526930156417};\\\", \\\"{x:545,y:708,t:1526930156434};\\\", \\\"{x:539,y:708,t:1526930156451};\\\", \\\"{x:532,y:707,t:1526930156466};\\\", \\\"{x:525,y:707,t:1526930156485};\\\", \\\"{x:513,y:706,t:1526930156501};\\\", \\\"{x:511,y:705,t:1526930156517};\\\", \\\"{x:510,y:705,t:1526930156534};\\\", \\\"{x:509,y:705,t:1526930156551};\\\", \\\"{x:508,y:706,t:1526930156573};\\\", \\\"{x:507,y:706,t:1526930156588};\\\", \\\"{x:505,y:707,t:1526930156605};\\\", \\\"{x:503,y:708,t:1526930156618};\\\", \\\"{x:502,y:709,t:1526930156634};\\\", \\\"{x:502,y:710,t:1526930156677};\\\", \\\"{x:501,y:710,t:1526930156693};\\\", \\\"{x:501,y:711,t:1526930156757};\\\", \\\"{x:500,y:713,t:1526930156773};\\\", \\\"{x:498,y:716,t:1526930156785};\\\", \\\"{x:496,y:717,t:1526930156801};\\\", \\\"{x:494,y:719,t:1526930156817};\\\", \\\"{x:493,y:720,t:1526930156834};\\\", \\\"{x:491,y:721,t:1526930156851};\\\", \\\"{x:489,y:723,t:1526930156867};\\\", \\\"{x:484,y:727,t:1526930156884};\\\", \\\"{x:484,y:726,t:1526930157622};\\\", \\\"{x:484,y:725,t:1526930157870};\\\", \\\"{x:485,y:723,t:1526930157901};\\\", \\\"{x:486,y:723,t:1526930157973};\\\" ] }, { \\\"rt\\\": 11232, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 493316, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:722,t:1526930162822};\\\", \\\"{x:487,y:722,t:1526930162829};\\\", \\\"{x:487,y:720,t:1526930162839};\\\", \\\"{x:496,y:709,t:1526930162858};\\\", \\\"{x:503,y:688,t:1526930162872};\\\", \\\"{x:519,y:662,t:1526930162888};\\\", \\\"{x:528,y:632,t:1526930162905};\\\", \\\"{x:534,y:611,t:1526930162922};\\\", \\\"{x:537,y:594,t:1526930162939};\\\", \\\"{x:537,y:580,t:1526930162956};\\\", \\\"{x:541,y:551,t:1526930162973};\\\", \\\"{x:542,y:529,t:1526930162989};\\\", \\\"{x:543,y:514,t:1526930163006};\\\", \\\"{x:546,y:503,t:1526930163023};\\\", \\\"{x:549,y:493,t:1526930163039};\\\", \\\"{x:553,y:485,t:1526930163057};\\\", \\\"{x:556,y:481,t:1526930163073};\\\", \\\"{x:556,y:478,t:1526930163090};\\\", \\\"{x:559,y:477,t:1526930163105};\\\", \\\"{x:566,y:473,t:1526930163122};\\\", \\\"{x:583,y:467,t:1526930163140};\\\", \\\"{x:598,y:462,t:1526930163155};\\\", \\\"{x:615,y:459,t:1526930163172};\\\", \\\"{x:630,y:458,t:1526930163190};\\\", \\\"{x:655,y:456,t:1526930163206};\\\", \\\"{x:674,y:456,t:1526930163223};\\\", \\\"{x:694,y:456,t:1526930163240};\\\", \\\"{x:704,y:458,t:1526930163257};\\\", \\\"{x:709,y:458,t:1526930163273};\\\", \\\"{x:712,y:458,t:1526930163290};\\\", \\\"{x:713,y:458,t:1526930163365};\\\", \\\"{x:714,y:458,t:1526930163429};\\\", \\\"{x:715,y:459,t:1526930163440};\\\", \\\"{x:717,y:460,t:1526930163458};\\\", \\\"{x:730,y:468,t:1526930163474};\\\", \\\"{x:753,y:481,t:1526930163490};\\\", \\\"{x:786,y:499,t:1526930163508};\\\", \\\"{x:852,y:528,t:1526930163524};\\\", \\\"{x:926,y:555,t:1526930163541};\\\", \\\"{x:971,y:582,t:1526930163557};\\\", \\\"{x:989,y:592,t:1526930163572};\\\", \\\"{x:1003,y:602,t:1526930163589};\\\", \\\"{x:1013,y:609,t:1526930163607};\\\", \\\"{x:1014,y:610,t:1526930163623};\\\", \\\"{x:1016,y:613,t:1526930163639};\\\", \\\"{x:1016,y:614,t:1526930163655};\\\", \\\"{x:1017,y:616,t:1526930163673};\\\", \\\"{x:1017,y:617,t:1526930163690};\\\", \\\"{x:1017,y:619,t:1526930163706};\\\", \\\"{x:1017,y:620,t:1526930163722};\\\", \\\"{x:1019,y:623,t:1526930163740};\\\", \\\"{x:1019,y:624,t:1526930163756};\\\", \\\"{x:1020,y:627,t:1526930163772};\\\", \\\"{x:1021,y:631,t:1526930163789};\\\", \\\"{x:1023,y:632,t:1526930163806};\\\", \\\"{x:1024,y:635,t:1526930163823};\\\", \\\"{x:1024,y:637,t:1526930163839};\\\", \\\"{x:1024,y:640,t:1526930163856};\\\", \\\"{x:1024,y:643,t:1526930163872};\\\", \\\"{x:1026,y:647,t:1526930163889};\\\", \\\"{x:1027,y:648,t:1526930163906};\\\", \\\"{x:1028,y:649,t:1526930163965};\\\", \\\"{x:1030,y:651,t:1526930163973};\\\", \\\"{x:1033,y:651,t:1526930163989};\\\", \\\"{x:1034,y:651,t:1526930164221};\\\", \\\"{x:1035,y:651,t:1526930164245};\\\", \\\"{x:1036,y:651,t:1526930164261};\\\", \\\"{x:1037,y:651,t:1526930164272};\\\", \\\"{x:1039,y:651,t:1526930164288};\\\", \\\"{x:1043,y:649,t:1526930164305};\\\", \\\"{x:1046,y:647,t:1526930164322};\\\", \\\"{x:1048,y:647,t:1526930164338};\\\", \\\"{x:1050,y:645,t:1526930164355};\\\", \\\"{x:1052,y:645,t:1526930164371};\\\", \\\"{x:1053,y:644,t:1526930164389};\\\", \\\"{x:1055,y:643,t:1526930164404};\\\", \\\"{x:1056,y:642,t:1526930164421};\\\", \\\"{x:1058,y:641,t:1526930164438};\\\", \\\"{x:1059,y:640,t:1526930164456};\\\", \\\"{x:1062,y:640,t:1526930164472};\\\", \\\"{x:1063,y:638,t:1526930164488};\\\", \\\"{x:1064,y:638,t:1526930164517};\\\", \\\"{x:1065,y:638,t:1526930164533};\\\", \\\"{x:1066,y:637,t:1526930164694};\\\", \\\"{x:1067,y:637,t:1526930164704};\\\", \\\"{x:1069,y:636,t:1526930164721};\\\", \\\"{x:1078,y:625,t:1526930164737};\\\", \\\"{x:1088,y:611,t:1526930164753};\\\", \\\"{x:1102,y:596,t:1526930164771};\\\", \\\"{x:1109,y:580,t:1526930164787};\\\", \\\"{x:1112,y:568,t:1526930164804};\\\", \\\"{x:1114,y:564,t:1526930164819};\\\", \\\"{x:1115,y:556,t:1526930164837};\\\", \\\"{x:1115,y:553,t:1526930164853};\\\", \\\"{x:1115,y:550,t:1526930164870};\\\", \\\"{x:1113,y:547,t:1526930164887};\\\", \\\"{x:1113,y:546,t:1526930164904};\\\", \\\"{x:1113,y:545,t:1526930164965};\\\", \\\"{x:1112,y:545,t:1526930164980};\\\", \\\"{x:1110,y:545,t:1526930164989};\\\", \\\"{x:1107,y:545,t:1526930165004};\\\", \\\"{x:1101,y:546,t:1526930165019};\\\", \\\"{x:1100,y:547,t:1526930165037};\\\", \\\"{x:1104,y:547,t:1526930165100};\\\", \\\"{x:1108,y:547,t:1526930165108};\\\", \\\"{x:1117,y:547,t:1526930165119};\\\", \\\"{x:1138,y:550,t:1526930165136};\\\", \\\"{x:1176,y:556,t:1526930165153};\\\", \\\"{x:1205,y:560,t:1526930165169};\\\", \\\"{x:1214,y:562,t:1526930165186};\\\", \\\"{x:1222,y:562,t:1526930165203};\\\", \\\"{x:1224,y:562,t:1526930165220};\\\", \\\"{x:1230,y:563,t:1526930165374};\\\", \\\"{x:1235,y:563,t:1526930165387};\\\", \\\"{x:1250,y:566,t:1526930165403};\\\", \\\"{x:1264,y:568,t:1526930165419};\\\", \\\"{x:1283,y:568,t:1526930165437};\\\", \\\"{x:1286,y:568,t:1526930165453};\\\", \\\"{x:1291,y:567,t:1526930165469};\\\", \\\"{x:1295,y:566,t:1526930165484};\\\", \\\"{x:1300,y:566,t:1526930165502};\\\", \\\"{x:1305,y:566,t:1526930165518};\\\", \\\"{x:1313,y:564,t:1526930165534};\\\", \\\"{x:1328,y:563,t:1526930165552};\\\", \\\"{x:1346,y:561,t:1526930165569};\\\", \\\"{x:1357,y:561,t:1526930165585};\\\", \\\"{x:1378,y:563,t:1526930165602};\\\", \\\"{x:1394,y:567,t:1526930165619};\\\", \\\"{x:1405,y:569,t:1526930165635};\\\", \\\"{x:1412,y:569,t:1526930165652};\\\", \\\"{x:1415,y:569,t:1526930165668};\\\", \\\"{x:1416,y:569,t:1526930165701};\\\", \\\"{x:1417,y:569,t:1526930165725};\\\", \\\"{x:1416,y:569,t:1526930165933};\\\", \\\"{x:1411,y:571,t:1526930165952};\\\", \\\"{x:1408,y:572,t:1526930165968};\\\", \\\"{x:1401,y:574,t:1526930165985};\\\", \\\"{x:1387,y:575,t:1526930166001};\\\", \\\"{x:1360,y:577,t:1526930166018};\\\", \\\"{x:1266,y:577,t:1526930166034};\\\", \\\"{x:1137,y:570,t:1526930166052};\\\", \\\"{x:950,y:545,t:1526930166068};\\\", \\\"{x:746,y:522,t:1526930166084};\\\", \\\"{x:501,y:484,t:1526930166104};\\\", \\\"{x:394,y:478,t:1526930166122};\\\", \\\"{x:299,y:476,t:1526930166138};\\\", \\\"{x:235,y:476,t:1526930166155};\\\", \\\"{x:212,y:476,t:1526930166171};\\\", \\\"{x:199,y:476,t:1526930166188};\\\", \\\"{x:198,y:477,t:1526930166212};\\\", \\\"{x:197,y:477,t:1526930166222};\\\", \\\"{x:196,y:477,t:1526930166268};\\\", \\\"{x:196,y:478,t:1526930166284};\\\", \\\"{x:195,y:479,t:1526930166301};\\\", \\\"{x:194,y:481,t:1526930166309};\\\", \\\"{x:194,y:482,t:1526930166322};\\\", \\\"{x:194,y:484,t:1526930166339};\\\", \\\"{x:201,y:489,t:1526930166356};\\\", \\\"{x:226,y:496,t:1526930166371};\\\", \\\"{x:373,y:525,t:1526930166388};\\\", \\\"{x:488,y:545,t:1526930166408};\\\", \\\"{x:574,y:559,t:1526930166426};\\\", \\\"{x:606,y:567,t:1526930166443};\\\", \\\"{x:618,y:567,t:1526930166458};\\\", \\\"{x:620,y:566,t:1526930166476};\\\", \\\"{x:624,y:564,t:1526930166492};\\\", \\\"{x:627,y:561,t:1526930166509};\\\", \\\"{x:630,y:559,t:1526930166526};\\\", \\\"{x:633,y:559,t:1526930166541};\\\", \\\"{x:636,y:557,t:1526930166559};\\\", \\\"{x:636,y:556,t:1526930166580};\\\", \\\"{x:636,y:555,t:1526930166592};\\\", \\\"{x:636,y:553,t:1526930166608};\\\", \\\"{x:636,y:552,t:1526930166644};\\\", \\\"{x:636,y:550,t:1526930166659};\\\", \\\"{x:627,y:540,t:1526930166676};\\\", \\\"{x:621,y:537,t:1526930166691};\\\", \\\"{x:618,y:535,t:1526930166709};\\\", \\\"{x:617,y:533,t:1526930166726};\\\", \\\"{x:617,y:531,t:1526930166748};\\\", \\\"{x:615,y:527,t:1526930166759};\\\", \\\"{x:615,y:525,t:1526930166775};\\\", \\\"{x:615,y:523,t:1526930166792};\\\", \\\"{x:615,y:519,t:1526930166809};\\\", \\\"{x:615,y:518,t:1526930166826};\\\", \\\"{x:615,y:516,t:1526930166843};\\\", \\\"{x:615,y:515,t:1526930166860};\\\", \\\"{x:615,y:514,t:1526930166934};\\\", \\\"{x:615,y:513,t:1526930166996};\\\", \\\"{x:615,y:512,t:1526930167020};\\\", \\\"{x:615,y:511,t:1526930167141};\\\", \\\"{x:617,y:510,t:1526930167411};\\\", \\\"{x:623,y:510,t:1526930167426};\\\", \\\"{x:633,y:510,t:1526930167443};\\\", \\\"{x:658,y:516,t:1526930167460};\\\", \\\"{x:671,y:518,t:1526930167476};\\\", \\\"{x:691,y:522,t:1526930167492};\\\", \\\"{x:704,y:522,t:1526930167509};\\\", \\\"{x:715,y:523,t:1526930167525};\\\", \\\"{x:719,y:525,t:1526930167543};\\\", \\\"{x:722,y:525,t:1526930167563};\\\", \\\"{x:723,y:525,t:1526930167604};\\\", \\\"{x:724,y:525,t:1526930167612};\\\", \\\"{x:725,y:525,t:1526930167626};\\\", \\\"{x:727,y:525,t:1526930167642};\\\", \\\"{x:729,y:525,t:1526930167667};\\\", \\\"{x:730,y:525,t:1526930167724};\\\", \\\"{x:731,y:525,t:1526930167732};\\\", \\\"{x:735,y:528,t:1526930167743};\\\", \\\"{x:740,y:530,t:1526930167759};\\\", \\\"{x:745,y:531,t:1526930167776};\\\", \\\"{x:748,y:531,t:1526930167793};\\\", \\\"{x:760,y:535,t:1526930167809};\\\", \\\"{x:773,y:535,t:1526930167826};\\\", \\\"{x:778,y:535,t:1526930167843};\\\", \\\"{x:784,y:534,t:1526930167859};\\\", \\\"{x:786,y:533,t:1526930167924};\\\", \\\"{x:787,y:533,t:1526930167940};\\\", \\\"{x:788,y:532,t:1526930167948};\\\", \\\"{x:789,y:532,t:1526930167959};\\\", \\\"{x:790,y:531,t:1526930167977};\\\", \\\"{x:791,y:531,t:1526930167993};\\\", \\\"{x:792,y:531,t:1526930168010};\\\", \\\"{x:797,y:531,t:1526930168027};\\\", \\\"{x:801,y:531,t:1526930168044};\\\", \\\"{x:805,y:532,t:1526930168059};\\\", \\\"{x:806,y:532,t:1526930168084};\\\", \\\"{x:807,y:533,t:1526930168094};\\\", \\\"{x:807,y:534,t:1526930168116};\\\", \\\"{x:808,y:535,t:1526930168127};\\\", \\\"{x:809,y:536,t:1526930168164};\\\", \\\"{x:809,y:537,t:1526930168357};\\\", \\\"{x:811,y:538,t:1526930168389};\\\", \\\"{x:813,y:539,t:1526930168404};\\\", \\\"{x:814,y:540,t:1526930168412};\\\", \\\"{x:815,y:541,t:1526930168427};\\\", \\\"{x:816,y:542,t:1526930168444};\\\", \\\"{x:821,y:542,t:1526930168460};\\\", \\\"{x:827,y:544,t:1526930168478};\\\", \\\"{x:828,y:544,t:1526930168508};\\\", \\\"{x:829,y:545,t:1526930168860};\\\", \\\"{x:829,y:546,t:1526930168973};\\\", \\\"{x:828,y:548,t:1526930168980};\\\", \\\"{x:825,y:549,t:1526930168994};\\\", \\\"{x:818,y:552,t:1526930169012};\\\", \\\"{x:812,y:554,t:1526930169028};\\\", \\\"{x:808,y:558,t:1526930169078};\\\", \\\"{x:801,y:566,t:1526930169095};\\\", \\\"{x:796,y:572,t:1526930169111};\\\", \\\"{x:791,y:579,t:1526930169129};\\\", \\\"{x:783,y:588,t:1526930169144};\\\", \\\"{x:773,y:601,t:1526930169161};\\\", \\\"{x:760,y:616,t:1526930169178};\\\", \\\"{x:752,y:627,t:1526930169193};\\\", \\\"{x:744,y:640,t:1526930169211};\\\", \\\"{x:732,y:658,t:1526930169227};\\\", \\\"{x:722,y:673,t:1526930169244};\\\", \\\"{x:707,y:683,t:1526930169261};\\\", \\\"{x:703,y:688,t:1526930169278};\\\", \\\"{x:700,y:690,t:1526930169295};\\\", \\\"{x:682,y:693,t:1526930169311};\\\", \\\"{x:658,y:701,t:1526930169329};\\\", \\\"{x:649,y:701,t:1526930169345};\\\", \\\"{x:631,y:704,t:1526930169361};\\\", \\\"{x:617,y:704,t:1526930169378};\\\", \\\"{x:607,y:706,t:1526930169395};\\\", \\\"{x:600,y:706,t:1526930169411};\\\", \\\"{x:591,y:706,t:1526930169428};\\\", \\\"{x:590,y:706,t:1526930169445};\\\", \\\"{x:586,y:707,t:1526930169463};\\\", \\\"{x:579,y:708,t:1526930169478};\\\", \\\"{x:574,y:710,t:1526930169495};\\\", \\\"{x:569,y:712,t:1526930169512};\\\", \\\"{x:568,y:712,t:1526930169529};\\\", \\\"{x:557,y:715,t:1526930169546};\\\", \\\"{x:547,y:719,t:1526930169563};\\\", \\\"{x:543,y:724,t:1526930169579};\\\", \\\"{x:541,y:727,t:1526930169595};\\\", \\\"{x:537,y:729,t:1526930169611};\\\", \\\"{x:537,y:731,t:1526930169636};\\\", \\\"{x:536,y:732,t:1526930169645};\\\", \\\"{x:535,y:733,t:1526930169661};\\\", \\\"{x:534,y:734,t:1526930169678};\\\", \\\"{x:535,y:734,t:1526930170588};\\\" ] }, { \\\"rt\\\": 30583, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 525158, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -M -M -M -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:734,t:1526930171245};\\\", \\\"{x:536,y:733,t:1526930171300};\\\", \\\"{x:536,y:732,t:1526930171372};\\\", \\\"{x:536,y:731,t:1526930171388};\\\", \\\"{x:536,y:730,t:1526930171420};\\\", \\\"{x:536,y:729,t:1526930171429};\\\", \\\"{x:536,y:725,t:1526930171446};\\\", \\\"{x:536,y:722,t:1526930171461};\\\", \\\"{x:536,y:720,t:1526930171479};\\\", \\\"{x:555,y:637,t:1526930171589};\\\", \\\"{x:556,y:630,t:1526930171597};\\\", \\\"{x:556,y:622,t:1526930171613};\\\", \\\"{x:556,y:610,t:1526930171630};\\\", \\\"{x:556,y:603,t:1526930171645};\\\", \\\"{x:557,y:598,t:1526930171663};\\\", \\\"{x:557,y:590,t:1526930171681};\\\", \\\"{x:557,y:577,t:1526930171696};\\\", \\\"{x:557,y:563,t:1526930171713};\\\", \\\"{x:554,y:547,t:1526930171730};\\\", \\\"{x:549,y:527,t:1526930171747};\\\", \\\"{x:544,y:514,t:1526930171763};\\\", \\\"{x:542,y:506,t:1526930171779};\\\", \\\"{x:538,y:493,t:1526930171796};\\\", \\\"{x:529,y:477,t:1526930171813};\\\", \\\"{x:521,y:469,t:1526930171830};\\\", \\\"{x:515,y:460,t:1526930171846};\\\", \\\"{x:510,y:454,t:1526930171862};\\\", \\\"{x:506,y:448,t:1526930171879};\\\", \\\"{x:502,y:445,t:1526930171896};\\\", \\\"{x:499,y:444,t:1526930171913};\\\", \\\"{x:494,y:444,t:1526930171930};\\\", \\\"{x:492,y:444,t:1526930171946};\\\", \\\"{x:487,y:445,t:1526930171963};\\\", \\\"{x:484,y:447,t:1526930171980};\\\", \\\"{x:480,y:449,t:1526930171996};\\\", \\\"{x:477,y:450,t:1526930172013};\\\", \\\"{x:472,y:452,t:1526930172030};\\\", \\\"{x:470,y:454,t:1526930172046};\\\", \\\"{x:468,y:455,t:1526930172062};\\\", \\\"{x:467,y:455,t:1526930172080};\\\", \\\"{x:466,y:457,t:1526930172095};\\\", \\\"{x:464,y:459,t:1526930172115};\\\", \\\"{x:465,y:459,t:1526930172381};\\\", \\\"{x:465,y:458,t:1526930172957};\\\", \\\"{x:464,y:458,t:1526930172965};\\\", \\\"{x:462,y:458,t:1526930172979};\\\", \\\"{x:458,y:458,t:1526930172997};\\\", \\\"{x:454,y:458,t:1526930173013};\\\", \\\"{x:449,y:458,t:1526930173029};\\\", \\\"{x:445,y:458,t:1526930173047};\\\", \\\"{x:440,y:459,t:1526930173063};\\\", \\\"{x:427,y:459,t:1526930173079};\\\", \\\"{x:407,y:459,t:1526930173096};\\\", \\\"{x:398,y:459,t:1526930173112};\\\", \\\"{x:383,y:458,t:1526930173129};\\\", \\\"{x:372,y:458,t:1526930173146};\\\", \\\"{x:369,y:458,t:1526930173162};\\\", \\\"{x:368,y:458,t:1526930173179};\\\", \\\"{x:367,y:458,t:1526930173196};\\\", \\\"{x:366,y:458,t:1526930173212};\\\", \\\"{x:365,y:459,t:1526930173230};\\\", \\\"{x:364,y:459,t:1526930173246};\\\", \\\"{x:363,y:459,t:1526930173262};\\\", \\\"{x:362,y:459,t:1526930173389};\\\", \\\"{x:361,y:459,t:1526930173421};\\\", \\\"{x:362,y:459,t:1526930173597};\\\", \\\"{x:366,y:459,t:1526930173612};\\\", \\\"{x:373,y:460,t:1526930173629};\\\", \\\"{x:378,y:463,t:1526930173646};\\\", \\\"{x:386,y:466,t:1526930173663};\\\", \\\"{x:399,y:468,t:1526930173679};\\\", \\\"{x:414,y:471,t:1526930173696};\\\", \\\"{x:427,y:473,t:1526930173712};\\\", \\\"{x:434,y:473,t:1526930173729};\\\", \\\"{x:449,y:476,t:1526930173745};\\\", \\\"{x:460,y:477,t:1526930173763};\\\", \\\"{x:467,y:477,t:1526930173779};\\\", \\\"{x:475,y:477,t:1526930173795};\\\", \\\"{x:483,y:476,t:1526930173812};\\\", \\\"{x:486,y:475,t:1526930173829};\\\", \\\"{x:490,y:473,t:1526930173845};\\\", \\\"{x:490,y:472,t:1526930173957};\\\", \\\"{x:491,y:471,t:1526930173965};\\\", \\\"{x:491,y:470,t:1526930174013};\\\", \\\"{x:493,y:470,t:1526930174028};\\\", \\\"{x:497,y:468,t:1526930174046};\\\", \\\"{x:499,y:468,t:1526930174063};\\\", \\\"{x:501,y:465,t:1526930174079};\\\", \\\"{x:508,y:463,t:1526930174095};\\\", \\\"{x:513,y:462,t:1526930174113};\\\", \\\"{x:518,y:461,t:1526930174128};\\\", \\\"{x:523,y:459,t:1526930174145};\\\", \\\"{x:529,y:455,t:1526930174162};\\\", \\\"{x:534,y:455,t:1526930174179};\\\", \\\"{x:538,y:454,t:1526930174195};\\\", \\\"{x:541,y:454,t:1526930174213};\\\", \\\"{x:542,y:454,t:1526930174245};\\\", \\\"{x:543,y:454,t:1526930174277};\\\", \\\"{x:544,y:454,t:1526930174284};\\\", \\\"{x:546,y:453,t:1526930174301};\\\", \\\"{x:548,y:452,t:1526930174324};\\\", \\\"{x:549,y:452,t:1526930174333};\\\", \\\"{x:550,y:452,t:1526930174357};\\\", \\\"{x:552,y:452,t:1526930174373};\\\", \\\"{x:554,y:452,t:1526930174380};\\\", \\\"{x:558,y:452,t:1526930174396};\\\", \\\"{x:567,y:453,t:1526930174413};\\\", \\\"{x:568,y:453,t:1526930174429};\\\", \\\"{x:572,y:455,t:1526930174446};\\\", \\\"{x:573,y:455,t:1526930174462};\\\", \\\"{x:578,y:457,t:1526930174478};\\\", \\\"{x:586,y:459,t:1526930174495};\\\", \\\"{x:590,y:459,t:1526930174512};\\\", \\\"{x:593,y:460,t:1526930174528};\\\", \\\"{x:594,y:461,t:1526930174749};\\\", \\\"{x:596,y:462,t:1526930174797};\\\", \\\"{x:597,y:462,t:1526930174811};\\\", \\\"{x:608,y:466,t:1526930174829};\\\", \\\"{x:613,y:468,t:1526930174853};\\\", \\\"{x:618,y:469,t:1526930174861};\\\", \\\"{x:627,y:472,t:1526930174879};\\\", \\\"{x:630,y:473,t:1526930174896};\\\", \\\"{x:628,y:473,t:1526930176574};\\\", \\\"{x:626,y:473,t:1526930176613};\\\", \\\"{x:625,y:473,t:1526930176717};\\\", \\\"{x:624,y:473,t:1526930176727};\\\", \\\"{x:623,y:473,t:1526930176764};\\\", \\\"{x:621,y:473,t:1526930177333};\\\", \\\"{x:619,y:473,t:1526930177344};\\\", \\\"{x:617,y:473,t:1526930177360};\\\", \\\"{x:622,y:479,t:1526930177469};\\\", \\\"{x:627,y:481,t:1526930177477};\\\", \\\"{x:672,y:495,t:1526930177494};\\\", \\\"{x:730,y:509,t:1526930177511};\\\", \\\"{x:831,y:542,t:1526930177528};\\\", \\\"{x:1065,y:604,t:1526930177548};\\\", \\\"{x:1223,y:650,t:1526930177565};\\\", \\\"{x:1380,y:695,t:1526930177584};\\\", \\\"{x:1513,y:735,t:1526930177601};\\\", \\\"{x:1591,y:758,t:1526930177618};\\\", \\\"{x:1622,y:772,t:1526930177634};\\\", \\\"{x:1636,y:777,t:1526930177651};\\\", \\\"{x:1638,y:778,t:1526930177668};\\\", \\\"{x:1637,y:780,t:1526930177684};\\\", \\\"{x:1633,y:781,t:1526930177701};\\\", \\\"{x:1623,y:784,t:1526930177718};\\\", \\\"{x:1617,y:785,t:1526930177734};\\\", \\\"{x:1616,y:787,t:1526930177765};\\\", \\\"{x:1614,y:788,t:1526930177788};\\\", \\\"{x:1613,y:789,t:1526930177801};\\\", \\\"{x:1611,y:791,t:1526930177819};\\\", \\\"{x:1598,y:794,t:1526930177835};\\\", \\\"{x:1591,y:794,t:1526930177851};\\\", \\\"{x:1571,y:794,t:1526930177869};\\\", \\\"{x:1553,y:792,t:1526930177885};\\\", \\\"{x:1540,y:788,t:1526930177901};\\\", \\\"{x:1526,y:786,t:1526930177918};\\\", \\\"{x:1510,y:778,t:1526930177934};\\\", \\\"{x:1493,y:772,t:1526930177951};\\\", \\\"{x:1472,y:766,t:1526930177968};\\\", \\\"{x:1457,y:760,t:1526930177984};\\\", \\\"{x:1444,y:755,t:1526930178002};\\\", \\\"{x:1435,y:752,t:1526930178019};\\\", \\\"{x:1431,y:750,t:1526930178035};\\\", \\\"{x:1428,y:750,t:1526930178052};\\\", \\\"{x:1427,y:750,t:1526930178085};\\\", \\\"{x:1425,y:749,t:1526930178101};\\\", \\\"{x:1422,y:748,t:1526930178118};\\\", \\\"{x:1414,y:746,t:1526930178136};\\\", \\\"{x:1410,y:744,t:1526930178152};\\\", \\\"{x:1404,y:743,t:1526930178169};\\\", \\\"{x:1396,y:741,t:1526930178186};\\\", \\\"{x:1387,y:739,t:1526930178202};\\\", \\\"{x:1380,y:735,t:1526930178219};\\\", \\\"{x:1367,y:733,t:1526930178236};\\\", \\\"{x:1357,y:730,t:1526930178252};\\\", \\\"{x:1343,y:725,t:1526930178269};\\\", \\\"{x:1334,y:718,t:1526930178285};\\\", \\\"{x:1327,y:715,t:1526930178302};\\\", \\\"{x:1324,y:713,t:1526930178319};\\\", \\\"{x:1324,y:712,t:1526930178356};\\\", \\\"{x:1324,y:711,t:1526930178372};\\\", \\\"{x:1324,y:710,t:1526930178385};\\\", \\\"{x:1324,y:708,t:1526930178402};\\\", \\\"{x:1327,y:706,t:1526930178418};\\\", \\\"{x:1330,y:702,t:1526930178436};\\\", \\\"{x:1333,y:700,t:1526930178452};\\\", \\\"{x:1341,y:694,t:1526930178469};\\\", \\\"{x:1345,y:690,t:1526930178486};\\\", \\\"{x:1350,y:686,t:1526930178504};\\\", \\\"{x:1353,y:685,t:1526930178519};\\\", \\\"{x:1355,y:681,t:1526930178536};\\\", \\\"{x:1358,y:678,t:1526930178553};\\\", \\\"{x:1360,y:677,t:1526930178569};\\\", \\\"{x:1363,y:671,t:1526930178586};\\\", \\\"{x:1366,y:667,t:1526930178603};\\\", \\\"{x:1369,y:664,t:1526930178618};\\\", \\\"{x:1378,y:659,t:1526930178636};\\\", \\\"{x:1390,y:651,t:1526930178653};\\\", \\\"{x:1396,y:650,t:1526930178668};\\\", \\\"{x:1398,y:647,t:1526930178685};\\\", \\\"{x:1400,y:647,t:1526930178703};\\\", \\\"{x:1403,y:646,t:1526930178719};\\\", \\\"{x:1404,y:646,t:1526930178735};\\\", \\\"{x:1407,y:644,t:1526930178752};\\\", \\\"{x:1414,y:644,t:1526930178768};\\\", \\\"{x:1426,y:643,t:1526930178785};\\\", \\\"{x:1443,y:642,t:1526930178802};\\\", \\\"{x:1457,y:640,t:1526930178819};\\\", \\\"{x:1477,y:640,t:1526930178835};\\\", \\\"{x:1507,y:640,t:1526930178852};\\\", \\\"{x:1520,y:640,t:1526930178870};\\\", \\\"{x:1529,y:640,t:1526930178886};\\\", \\\"{x:1535,y:640,t:1526930178902};\\\", \\\"{x:1538,y:640,t:1526930178919};\\\", \\\"{x:1540,y:640,t:1526930178935};\\\", \\\"{x:1541,y:640,t:1526930178957};\\\", \\\"{x:1543,y:640,t:1526930178970};\\\", \\\"{x:1544,y:640,t:1526930178986};\\\", \\\"{x:1545,y:640,t:1526930188333};\\\", \\\"{x:1543,y:643,t:1526930188343};\\\", \\\"{x:1537,y:648,t:1526930188360};\\\", \\\"{x:1525,y:657,t:1526930188378};\\\", \\\"{x:1514,y:665,t:1526930188394};\\\", \\\"{x:1509,y:671,t:1526930188410};\\\", \\\"{x:1504,y:677,t:1526930188427};\\\", \\\"{x:1500,y:682,t:1526930188444};\\\", \\\"{x:1497,y:686,t:1526930188461};\\\", \\\"{x:1492,y:692,t:1526930188477};\\\", \\\"{x:1484,y:702,t:1526930188494};\\\", \\\"{x:1478,y:710,t:1526930188510};\\\", \\\"{x:1472,y:715,t:1526930188528};\\\", \\\"{x:1468,y:720,t:1526930188544};\\\", \\\"{x:1465,y:722,t:1526930188560};\\\", \\\"{x:1461,y:726,t:1526930188577};\\\", \\\"{x:1458,y:731,t:1526930188594};\\\", \\\"{x:1456,y:731,t:1526930188611};\\\", \\\"{x:1454,y:733,t:1526930188636};\\\", \\\"{x:1453,y:734,t:1526930188661};\\\", \\\"{x:1452,y:736,t:1526930188699};\\\", \\\"{x:1451,y:736,t:1526930188709};\\\", \\\"{x:1450,y:738,t:1526930188726};\\\", \\\"{x:1448,y:738,t:1526930188743};\\\", \\\"{x:1447,y:738,t:1526930188759};\\\", \\\"{x:1446,y:740,t:1526930188777};\\\", \\\"{x:1444,y:740,t:1526930188796};\\\", \\\"{x:1444,y:741,t:1526930188812};\\\", \\\"{x:1444,y:742,t:1526930188826};\\\", \\\"{x:1443,y:743,t:1526930188844};\\\", \\\"{x:1441,y:743,t:1526930188884};\\\", \\\"{x:1440,y:743,t:1526930188925};\\\", \\\"{x:1439,y:743,t:1526930188997};\\\", \\\"{x:1437,y:743,t:1526930189732};\\\", \\\"{x:1434,y:743,t:1526930189745};\\\", \\\"{x:1423,y:743,t:1526930189761};\\\", \\\"{x:1413,y:744,t:1526930189778};\\\", \\\"{x:1407,y:744,t:1526930189795};\\\", \\\"{x:1398,y:745,t:1526930189811};\\\", \\\"{x:1379,y:749,t:1526930189829};\\\", \\\"{x:1372,y:750,t:1526930189845};\\\", \\\"{x:1366,y:752,t:1526930189861};\\\", \\\"{x:1363,y:753,t:1526930189878};\\\", \\\"{x:1361,y:754,t:1526930189895};\\\", \\\"{x:1357,y:755,t:1526930189911};\\\", \\\"{x:1356,y:756,t:1526930189929};\\\", \\\"{x:1353,y:757,t:1526930189945};\\\", \\\"{x:1352,y:757,t:1526930189962};\\\", \\\"{x:1350,y:758,t:1526930189981};\\\", \\\"{x:1348,y:760,t:1526930189995};\\\", \\\"{x:1345,y:762,t:1526930190010};\\\", \\\"{x:1335,y:767,t:1526930190028};\\\", \\\"{x:1329,y:771,t:1526930190044};\\\", \\\"{x:1326,y:772,t:1526930190062};\\\", \\\"{x:1322,y:773,t:1526930190077};\\\", \\\"{x:1320,y:775,t:1526930190094};\\\", \\\"{x:1319,y:778,t:1526930190131};\\\", \\\"{x:1318,y:778,t:1526930190145};\\\", \\\"{x:1315,y:781,t:1526930190162};\\\", \\\"{x:1305,y:787,t:1526930190177};\\\", \\\"{x:1299,y:792,t:1526930190194};\\\", \\\"{x:1294,y:796,t:1526930190211};\\\", \\\"{x:1293,y:796,t:1526930190235};\\\", \\\"{x:1292,y:796,t:1526930190341};\\\", \\\"{x:1292,y:797,t:1526930190461};\\\", \\\"{x:1292,y:798,t:1526930190621};\\\", \\\"{x:1292,y:799,t:1526930190628};\\\", \\\"{x:1292,y:800,t:1526930190645};\\\", \\\"{x:1292,y:803,t:1526930190724};\\\", \\\"{x:1293,y:805,t:1526930190732};\\\", \\\"{x:1298,y:805,t:1526930190746};\\\", \\\"{x:1303,y:810,t:1526930190762};\\\", \\\"{x:1310,y:813,t:1526930190779};\\\", \\\"{x:1314,y:815,t:1526930190795};\\\", \\\"{x:1318,y:817,t:1526930190813};\\\", \\\"{x:1321,y:818,t:1526930190828};\\\", \\\"{x:1323,y:818,t:1526930190845};\\\", \\\"{x:1324,y:818,t:1526930190862};\\\", \\\"{x:1325,y:818,t:1526930190879};\\\", \\\"{x:1331,y:820,t:1526930190895};\\\", \\\"{x:1335,y:821,t:1526930190912};\\\", \\\"{x:1337,y:821,t:1526930190929};\\\", \\\"{x:1341,y:822,t:1526930190945};\\\", \\\"{x:1346,y:826,t:1526930190962};\\\", \\\"{x:1349,y:828,t:1526930190980};\\\", \\\"{x:1351,y:830,t:1526930190995};\\\", \\\"{x:1356,y:831,t:1526930191012};\\\", \\\"{x:1359,y:832,t:1526930191029};\\\", \\\"{x:1362,y:832,t:1526930191046};\\\", \\\"{x:1363,y:832,t:1526930191067};\\\", \\\"{x:1364,y:833,t:1526930191079};\\\", \\\"{x:1365,y:833,t:1526930191095};\\\", \\\"{x:1367,y:835,t:1526930191111};\\\", \\\"{x:1369,y:838,t:1526930191128};\\\", \\\"{x:1372,y:840,t:1526930191145};\\\", \\\"{x:1380,y:846,t:1526930191162};\\\", \\\"{x:1384,y:848,t:1526930191179};\\\", \\\"{x:1385,y:851,t:1526930191195};\\\", \\\"{x:1389,y:855,t:1526930191212};\\\", \\\"{x:1390,y:858,t:1526930191229};\\\", \\\"{x:1391,y:861,t:1526930191246};\\\", \\\"{x:1391,y:865,t:1526930191262};\\\", \\\"{x:1391,y:870,t:1526930191279};\\\", \\\"{x:1391,y:876,t:1526930191296};\\\", \\\"{x:1391,y:879,t:1526930191312};\\\", \\\"{x:1391,y:881,t:1526930191328};\\\", \\\"{x:1391,y:882,t:1526930191345};\\\", \\\"{x:1391,y:883,t:1526930191364};\\\", \\\"{x:1391,y:884,t:1526930191379};\\\", \\\"{x:1390,y:884,t:1526930191396};\\\", \\\"{x:1389,y:885,t:1526930191412};\\\", \\\"{x:1388,y:887,t:1526930191429};\\\", \\\"{x:1387,y:889,t:1526930191446};\\\", \\\"{x:1386,y:891,t:1526930191463};\\\", \\\"{x:1385,y:893,t:1526930191480};\\\", \\\"{x:1382,y:898,t:1526930191496};\\\", \\\"{x:1382,y:900,t:1526930191513};\\\", \\\"{x:1381,y:904,t:1526930191531};\\\", \\\"{x:1378,y:910,t:1526930191545};\\\", \\\"{x:1375,y:916,t:1526930191562};\\\", \\\"{x:1373,y:921,t:1526930191578};\\\", \\\"{x:1370,y:930,t:1526930191596};\\\", \\\"{x:1369,y:935,t:1526930191613};\\\", \\\"{x:1367,y:941,t:1526930191629};\\\", \\\"{x:1367,y:944,t:1526930191645};\\\", \\\"{x:1367,y:945,t:1526930191662};\\\", \\\"{x:1367,y:946,t:1526930191678};\\\", \\\"{x:1367,y:947,t:1526930191707};\\\", \\\"{x:1367,y:946,t:1526930192156};\\\", \\\"{x:1367,y:945,t:1526930192173};\\\", \\\"{x:1367,y:942,t:1526930192188};\\\", \\\"{x:1366,y:940,t:1526930192276};\\\", \\\"{x:1366,y:939,t:1526930192299};\\\", \\\"{x:1366,y:938,t:1526930192517};\\\", \\\"{x:1366,y:937,t:1526930192530};\\\", \\\"{x:1366,y:936,t:1526930192547};\\\", \\\"{x:1366,y:935,t:1526930192572};\\\", \\\"{x:1366,y:934,t:1526930192581};\\\", \\\"{x:1366,y:932,t:1526930192604};\\\", \\\"{x:1366,y:931,t:1526930192629};\\\", \\\"{x:1366,y:929,t:1526930192652};\\\", \\\"{x:1366,y:927,t:1526930192701};\\\", \\\"{x:1366,y:926,t:1526930192725};\\\", \\\"{x:1366,y:924,t:1526930192732};\\\", \\\"{x:1366,y:923,t:1526930192804};\\\", \\\"{x:1366,y:921,t:1526930192814};\\\", \\\"{x:1366,y:916,t:1526930192830};\\\", \\\"{x:1367,y:911,t:1526930192848};\\\", \\\"{x:1371,y:906,t:1526930192864};\\\", \\\"{x:1373,y:900,t:1526930192880};\\\", \\\"{x:1379,y:891,t:1526930192897};\\\", \\\"{x:1381,y:888,t:1526930192914};\\\", \\\"{x:1383,y:885,t:1526930192931};\\\", \\\"{x:1385,y:880,t:1526930192947};\\\", \\\"{x:1386,y:878,t:1526930192964};\\\", \\\"{x:1387,y:877,t:1526930192980};\\\", \\\"{x:1389,y:874,t:1526930192996};\\\", \\\"{x:1390,y:873,t:1526930193013};\\\", \\\"{x:1391,y:872,t:1526930193052};\\\", \\\"{x:1392,y:871,t:1526930193076};\\\", \\\"{x:1392,y:872,t:1526930193165};\\\", \\\"{x:1392,y:873,t:1526930193180};\\\", \\\"{x:1393,y:876,t:1526930193211};\\\", \\\"{x:1393,y:878,t:1526930193235};\\\", \\\"{x:1393,y:879,t:1526930193246};\\\", \\\"{x:1393,y:883,t:1526930193263};\\\", \\\"{x:1390,y:886,t:1526930193281};\\\", \\\"{x:1389,y:889,t:1526930193296};\\\", \\\"{x:1388,y:890,t:1526930193313};\\\", \\\"{x:1388,y:891,t:1526930193355};\\\", \\\"{x:1386,y:893,t:1526930193363};\\\", \\\"{x:1386,y:894,t:1526930193381};\\\", \\\"{x:1386,y:895,t:1526930193397};\\\", \\\"{x:1385,y:895,t:1526930193414};\\\", \\\"{x:1385,y:896,t:1526930193430};\\\", \\\"{x:1384,y:897,t:1526930193447};\\\", \\\"{x:1384,y:896,t:1526930193667};\\\", \\\"{x:1385,y:894,t:1526930193680};\\\", \\\"{x:1386,y:893,t:1526930193698};\\\", \\\"{x:1387,y:892,t:1526930193714};\\\", \\\"{x:1389,y:888,t:1526930193730};\\\", \\\"{x:1400,y:870,t:1526930193747};\\\", \\\"{x:1405,y:857,t:1526930193764};\\\", \\\"{x:1411,y:846,t:1526930193780};\\\", \\\"{x:1416,y:837,t:1526930193798};\\\", \\\"{x:1419,y:830,t:1526930193814};\\\", \\\"{x:1420,y:827,t:1526930193830};\\\", \\\"{x:1421,y:818,t:1526930193847};\\\", \\\"{x:1424,y:810,t:1526930193864};\\\", \\\"{x:1426,y:801,t:1526930193881};\\\", \\\"{x:1429,y:797,t:1526930193897};\\\", \\\"{x:1431,y:788,t:1526930193914};\\\", \\\"{x:1432,y:783,t:1526930193930};\\\", \\\"{x:1438,y:774,t:1526930193947};\\\", \\\"{x:1441,y:767,t:1526930193964};\\\", \\\"{x:1447,y:759,t:1526930193980};\\\", \\\"{x:1451,y:754,t:1526930193998};\\\", \\\"{x:1454,y:748,t:1526930194014};\\\", \\\"{x:1457,y:743,t:1526930194030};\\\", \\\"{x:1461,y:737,t:1526930194047};\\\", \\\"{x:1466,y:729,t:1526930194065};\\\", \\\"{x:1470,y:724,t:1526930194080};\\\", \\\"{x:1474,y:719,t:1526930194098};\\\", \\\"{x:1478,y:713,t:1526930194115};\\\", \\\"{x:1481,y:710,t:1526930194131};\\\", \\\"{x:1482,y:708,t:1526930194147};\\\", \\\"{x:1484,y:705,t:1526930194164};\\\", \\\"{x:1488,y:700,t:1526930194181};\\\", \\\"{x:1492,y:696,t:1526930194198};\\\", \\\"{x:1493,y:695,t:1526930194215};\\\", \\\"{x:1493,y:694,t:1526930194230};\\\", \\\"{x:1494,y:695,t:1526930194292};\\\", \\\"{x:1495,y:697,t:1526930194299};\\\", \\\"{x:1495,y:702,t:1526930194314};\\\", \\\"{x:1493,y:712,t:1526930194331};\\\", \\\"{x:1486,y:733,t:1526930194347};\\\", \\\"{x:1480,y:754,t:1526930194364};\\\", \\\"{x:1475,y:775,t:1526930194381};\\\", \\\"{x:1474,y:785,t:1526930194398};\\\", \\\"{x:1472,y:801,t:1526930194415};\\\", \\\"{x:1472,y:815,t:1526930194431};\\\", \\\"{x:1470,y:829,t:1526930194448};\\\", \\\"{x:1471,y:835,t:1526930194465};\\\", \\\"{x:1473,y:840,t:1526930194482};\\\", \\\"{x:1474,y:843,t:1526930194498};\\\", \\\"{x:1474,y:844,t:1526930194540};\\\", \\\"{x:1475,y:845,t:1526930194549};\\\", \\\"{x:1476,y:845,t:1526930194621};\\\", \\\"{x:1477,y:845,t:1526930194632};\\\", \\\"{x:1478,y:844,t:1526930194661};\\\", \\\"{x:1479,y:842,t:1526930194684};\\\", \\\"{x:1480,y:842,t:1526930194698};\\\", \\\"{x:1481,y:840,t:1526930194715};\\\", \\\"{x:1482,y:838,t:1526930194732};\\\", \\\"{x:1483,y:836,t:1526930194749};\\\", \\\"{x:1484,y:836,t:1526930194805};\\\", \\\"{x:1485,y:835,t:1526930194861};\\\", \\\"{x:1486,y:834,t:1526930194892};\\\", \\\"{x:1486,y:833,t:1526930194900};\\\", \\\"{x:1487,y:832,t:1526930194915};\\\", \\\"{x:1490,y:827,t:1526930194932};\\\", \\\"{x:1491,y:825,t:1526930194948};\\\", \\\"{x:1493,y:823,t:1526930194965};\\\", \\\"{x:1494,y:821,t:1526930194996};\\\", \\\"{x:1495,y:820,t:1526930195021};\\\", \\\"{x:1495,y:819,t:1526930195032};\\\", \\\"{x:1496,y:817,t:1526930195049};\\\", \\\"{x:1497,y:817,t:1526930195066};\\\", \\\"{x:1497,y:816,t:1526930195082};\\\", \\\"{x:1497,y:815,t:1526930195197};\\\", \\\"{x:1496,y:815,t:1526930195204};\\\", \\\"{x:1494,y:817,t:1526930195215};\\\", \\\"{x:1492,y:820,t:1526930195232};\\\", \\\"{x:1491,y:822,t:1526930195249};\\\", \\\"{x:1490,y:824,t:1526930195266};\\\", \\\"{x:1489,y:825,t:1526930195282};\\\", \\\"{x:1488,y:826,t:1526930195300};\\\", \\\"{x:1487,y:827,t:1526930195316};\\\", \\\"{x:1487,y:828,t:1526930195332};\\\", \\\"{x:1488,y:827,t:1526930195685};\\\", \\\"{x:1491,y:826,t:1526930195699};\\\", \\\"{x:1492,y:821,t:1526930195716};\\\", \\\"{x:1494,y:818,t:1526930195733};\\\", \\\"{x:1496,y:815,t:1526930195748};\\\", \\\"{x:1497,y:813,t:1526930195766};\\\", \\\"{x:1501,y:809,t:1526930195783};\\\", \\\"{x:1503,y:807,t:1526930195799};\\\", \\\"{x:1505,y:805,t:1526930195815};\\\", \\\"{x:1506,y:801,t:1526930195833};\\\", \\\"{x:1507,y:797,t:1526930195848};\\\", \\\"{x:1508,y:794,t:1526930195866};\\\", \\\"{x:1508,y:790,t:1526930195883};\\\", \\\"{x:1510,y:786,t:1526930195899};\\\", \\\"{x:1512,y:780,t:1526930195916};\\\", \\\"{x:1513,y:776,t:1526930195933};\\\", \\\"{x:1514,y:772,t:1526930195949};\\\", \\\"{x:1514,y:768,t:1526930195967};\\\", \\\"{x:1515,y:766,t:1526930195983};\\\", \\\"{x:1515,y:765,t:1526930195999};\\\", \\\"{x:1515,y:764,t:1526930196016};\\\", \\\"{x:1515,y:763,t:1526930196036};\\\", \\\"{x:1515,y:762,t:1526930196060};\\\", \\\"{x:1515,y:761,t:1526930196115};\\\", \\\"{x:1516,y:761,t:1526930196147};\\\", \\\"{x:1516,y:760,t:1526930196155};\\\", \\\"{x:1517,y:759,t:1526930196268};\\\", \\\"{x:1515,y:759,t:1526930197605};\\\", \\\"{x:1514,y:759,t:1526930197620};\\\", \\\"{x:1513,y:759,t:1526930197634};\\\", \\\"{x:1512,y:759,t:1526930197651};\\\", \\\"{x:1509,y:760,t:1526930197668};\\\", \\\"{x:1497,y:761,t:1526930197684};\\\", \\\"{x:1482,y:761,t:1526930197702};\\\", \\\"{x:1460,y:759,t:1526930197718};\\\", \\\"{x:1435,y:752,t:1526930197734};\\\", \\\"{x:1383,y:743,t:1526930197751};\\\", \\\"{x:1340,y:734,t:1526930197767};\\\", \\\"{x:1300,y:727,t:1526930197784};\\\", \\\"{x:1267,y:716,t:1526930197801};\\\", \\\"{x:1249,y:710,t:1526930197817};\\\", \\\"{x:1228,y:707,t:1526930197833};\\\", \\\"{x:1199,y:695,t:1526930197851};\\\", \\\"{x:1181,y:689,t:1526930197867};\\\", \\\"{x:1150,y:678,t:1526930197884};\\\", \\\"{x:1127,y:671,t:1526930197901};\\\", \\\"{x:1111,y:665,t:1526930197917};\\\", \\\"{x:1091,y:656,t:1526930197934};\\\", \\\"{x:1071,y:649,t:1526930197951};\\\", \\\"{x:1061,y:645,t:1526930197968};\\\", \\\"{x:1047,y:637,t:1526930197984};\\\", \\\"{x:1027,y:634,t:1526930198001};\\\", \\\"{x:1010,y:632,t:1526930198019};\\\", \\\"{x:994,y:628,t:1526930198035};\\\", \\\"{x:981,y:623,t:1526930198051};\\\", \\\"{x:970,y:619,t:1526930198068};\\\", \\\"{x:968,y:619,t:1526930198084};\\\", \\\"{x:966,y:619,t:1526930198101};\\\", \\\"{x:964,y:618,t:1526930198118};\\\", \\\"{x:963,y:617,t:1526930198140};\\\", \\\"{x:961,y:616,t:1526930198164};\\\", \\\"{x:960,y:616,t:1526930198172};\\\", \\\"{x:957,y:615,t:1526930198184};\\\", \\\"{x:947,y:612,t:1526930198203};\\\", \\\"{x:926,y:610,t:1526930198218};\\\", \\\"{x:903,y:607,t:1526930198233};\\\", \\\"{x:872,y:603,t:1526930198250};\\\", \\\"{x:835,y:598,t:1526930198268};\\\", \\\"{x:804,y:594,t:1526930198284};\\\", \\\"{x:767,y:589,t:1526930198301};\\\", \\\"{x:710,y:579,t:1526930198318};\\\", \\\"{x:683,y:573,t:1526930198335};\\\", \\\"{x:666,y:567,t:1526930198350};\\\", \\\"{x:659,y:567,t:1526930198367};\\\", \\\"{x:651,y:567,t:1526930198385};\\\", \\\"{x:643,y:567,t:1526930198401};\\\", \\\"{x:642,y:567,t:1526930198418};\\\", \\\"{x:642,y:566,t:1526930198435};\\\", \\\"{x:641,y:566,t:1526930198451};\\\", \\\"{x:640,y:566,t:1526930198468};\\\", \\\"{x:637,y:566,t:1526930198492};\\\", \\\"{x:635,y:567,t:1526930198502};\\\", \\\"{x:632,y:569,t:1526930198518};\\\", \\\"{x:627,y:572,t:1526930198535};\\\", \\\"{x:627,y:573,t:1526930198552};\\\", \\\"{x:625,y:575,t:1526930198568};\\\", \\\"{x:624,y:576,t:1526930198585};\\\", \\\"{x:622,y:577,t:1526930198604};\\\", \\\"{x:620,y:578,t:1526930198621};\\\", \\\"{x:619,y:579,t:1526930198636};\\\", \\\"{x:617,y:580,t:1526930198652};\\\", \\\"{x:615,y:580,t:1526930198669};\\\", \\\"{x:613,y:580,t:1526930198860};\\\", \\\"{x:618,y:580,t:1526930199003};\\\", \\\"{x:622,y:580,t:1526930199019};\\\", \\\"{x:651,y:580,t:1526930199035};\\\", \\\"{x:738,y:579,t:1526930199051};\\\", \\\"{x:789,y:582,t:1526930199068};\\\", \\\"{x:840,y:582,t:1526930199085};\\\", \\\"{x:863,y:584,t:1526930199102};\\\", \\\"{x:869,y:580,t:1526930199118};\\\", \\\"{x:871,y:579,t:1526930199135};\\\", \\\"{x:869,y:580,t:1526930199276};\\\", \\\"{x:867,y:580,t:1526930199284};\\\", \\\"{x:860,y:581,t:1526930199301};\\\", \\\"{x:856,y:584,t:1526930199319};\\\", \\\"{x:853,y:584,t:1526930199335};\\\", \\\"{x:848,y:585,t:1526930199351};\\\", \\\"{x:847,y:585,t:1526930199379};\\\", \\\"{x:846,y:585,t:1526930199476};\\\", \\\"{x:845,y:585,t:1526930199531};\\\", \\\"{x:843,y:585,t:1526930199539};\\\", \\\"{x:842,y:585,t:1526930199552};\\\", \\\"{x:838,y:584,t:1526930199569};\\\", \\\"{x:836,y:583,t:1526930199586};\\\", \\\"{x:836,y:582,t:1526930199611};\\\", \\\"{x:835,y:582,t:1526930200156};\\\", \\\"{x:834,y:582,t:1526930200169};\\\", \\\"{x:833,y:582,t:1526930200185};\\\", \\\"{x:832,y:583,t:1526930200251};\\\", \\\"{x:831,y:584,t:1526930200275};\\\", \\\"{x:830,y:585,t:1526930200307};\\\", \\\"{x:829,y:585,t:1526930200319};\\\", \\\"{x:825,y:589,t:1526930200336};\\\", \\\"{x:821,y:591,t:1526930200353};\\\", \\\"{x:818,y:593,t:1526930200370};\\\", \\\"{x:810,y:596,t:1526930200386};\\\", \\\"{x:800,y:600,t:1526930200403};\\\", \\\"{x:783,y:604,t:1526930200420};\\\", \\\"{x:748,y:616,t:1526930200436};\\\", \\\"{x:726,y:625,t:1526930200453};\\\", \\\"{x:704,y:634,t:1526930200471};\\\", \\\"{x:680,y:645,t:1526930200486};\\\", \\\"{x:633,y:670,t:1526930200503};\\\", \\\"{x:604,y:691,t:1526930200520};\\\", \\\"{x:575,y:712,t:1526930200535};\\\", \\\"{x:548,y:727,t:1526930200553};\\\", \\\"{x:532,y:739,t:1526930200570};\\\", \\\"{x:519,y:747,t:1526930200586};\\\", \\\"{x:511,y:755,t:1526930200603};\\\", \\\"{x:499,y:764,t:1526930200619};\\\", \\\"{x:489,y:778,t:1526930200636};\\\", \\\"{x:470,y:793,t:1526930200652};\\\", \\\"{x:457,y:804,t:1526930200670};\\\", \\\"{x:447,y:816,t:1526930200686};\\\", \\\"{x:436,y:823,t:1526930200702};\\\", \\\"{x:428,y:829,t:1526930200720};\\\", \\\"{x:418,y:834,t:1526930200736};\\\", \\\"{x:409,y:841,t:1526930200753};\\\", \\\"{x:400,y:846,t:1526930200770};\\\", \\\"{x:397,y:849,t:1526930200786};\\\", \\\"{x:396,y:849,t:1526930200803};\\\", \\\"{x:397,y:848,t:1526930200956};\\\", \\\"{x:402,y:845,t:1526930200970};\\\", \\\"{x:412,y:838,t:1526930200988};\\\", \\\"{x:431,y:827,t:1526930201004};\\\", \\\"{x:438,y:823,t:1526930201020};\\\", \\\"{x:443,y:819,t:1526930201037};\\\", \\\"{x:450,y:814,t:1526930201053};\\\", \\\"{x:455,y:807,t:1526930201071};\\\", \\\"{x:460,y:804,t:1526930201087};\\\", \\\"{x:462,y:800,t:1526930201103};\\\", \\\"{x:464,y:798,t:1526930201121};\\\", \\\"{x:465,y:798,t:1526930201137};\\\", \\\"{x:466,y:797,t:1526930201154};\\\", \\\"{x:468,y:796,t:1526930201170};\\\", \\\"{x:476,y:791,t:1526930201187};\\\", \\\"{x:487,y:783,t:1526930201204};\\\", \\\"{x:498,y:777,t:1526930201220};\\\", \\\"{x:503,y:775,t:1526930201238};\\\", \\\"{x:504,y:775,t:1526930201254};\\\", \\\"{x:505,y:774,t:1526930201284};\\\", \\\"{x:507,y:771,t:1526930201300};\\\", \\\"{x:509,y:770,t:1526930201308};\\\", \\\"{x:514,y:768,t:1526930201320};\\\", \\\"{x:521,y:762,t:1526930201337};\\\", \\\"{x:527,y:757,t:1526930201354};\\\", \\\"{x:533,y:749,t:1526930201372};\\\", \\\"{x:536,y:745,t:1526930201387};\\\", \\\"{x:537,y:743,t:1526930201404};\\\" ] }, { \\\"rt\\\": 34165, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 560618, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -E -G -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:743,t:1526930203925};\\\", \\\"{x:541,y:738,t:1526930203941};\\\", \\\"{x:542,y:735,t:1526930203958};\\\", \\\"{x:552,y:725,t:1526930203975};\\\", \\\"{x:565,y:700,t:1526930203993};\\\", \\\"{x:586,y:672,t:1526930204007};\\\", \\\"{x:606,y:648,t:1526930204022};\\\", \\\"{x:629,y:617,t:1526930204039};\\\", \\\"{x:643,y:587,t:1526930204055};\\\", \\\"{x:654,y:559,t:1526930204072};\\\", \\\"{x:656,y:540,t:1526930204089};\\\", \\\"{x:656,y:531,t:1526930204106};\\\", \\\"{x:656,y:525,t:1526930204122};\\\", \\\"{x:653,y:510,t:1526930204139};\\\", \\\"{x:653,y:506,t:1526930204156};\\\", \\\"{x:645,y:498,t:1526930204172};\\\", \\\"{x:639,y:493,t:1526930204189};\\\", \\\"{x:631,y:490,t:1526930204206};\\\", \\\"{x:625,y:487,t:1526930204222};\\\", \\\"{x:618,y:486,t:1526930204239};\\\", \\\"{x:612,y:484,t:1526930204256};\\\", \\\"{x:609,y:483,t:1526930204272};\\\", \\\"{x:604,y:483,t:1526930204289};\\\", \\\"{x:600,y:483,t:1526930204306};\\\", \\\"{x:599,y:483,t:1526930204322};\\\", \\\"{x:597,y:483,t:1526930204339};\\\", \\\"{x:595,y:483,t:1526930204363};\\\", \\\"{x:594,y:483,t:1526930204379};\\\", \\\"{x:591,y:483,t:1526930204396};\\\", \\\"{x:588,y:483,t:1526930204406};\\\", \\\"{x:585,y:483,t:1526930204423};\\\", \\\"{x:583,y:483,t:1526930204439};\\\", \\\"{x:581,y:483,t:1526930204456};\\\", \\\"{x:580,y:482,t:1526930204473};\\\", \\\"{x:577,y:482,t:1526930204490};\\\", \\\"{x:576,y:482,t:1526930204524};\\\", \\\"{x:575,y:482,t:1526930204539};\\\", \\\"{x:571,y:482,t:1526930204556};\\\", \\\"{x:570,y:482,t:1526930205885};\\\", \\\"{x:568,y:482,t:1526930209813};\\\", \\\"{x:570,y:482,t:1526930209823};\\\", \\\"{x:574,y:484,t:1526930209839};\\\", \\\"{x:576,y:486,t:1526930209856};\\\", \\\"{x:578,y:487,t:1526930209949};\\\", \\\"{x:582,y:488,t:1526930209972};\\\", \\\"{x:593,y:488,t:1526930209989};\\\", \\\"{x:595,y:488,t:1526930210010};\\\", \\\"{x:597,y:489,t:1526930210027};\\\", \\\"{x:598,y:490,t:1526930210075};\\\", \\\"{x:600,y:490,t:1526930210083};\\\", \\\"{x:605,y:491,t:1526930210093};\\\", \\\"{x:613,y:496,t:1526930210110};\\\", \\\"{x:615,y:499,t:1526930210127};\\\", \\\"{x:628,y:507,t:1526930210143};\\\", \\\"{x:672,y:519,t:1526930210161};\\\", \\\"{x:739,y:540,t:1526930210178};\\\", \\\"{x:801,y:559,t:1526930210194};\\\", \\\"{x:937,y:602,t:1526930210211};\\\", \\\"{x:1029,y:631,t:1526930210227};\\\", \\\"{x:1114,y:664,t:1526930210244};\\\", \\\"{x:1164,y:687,t:1526930210260};\\\", \\\"{x:1269,y:735,t:1526930210277};\\\", \\\"{x:1322,y:765,t:1526930210294};\\\", \\\"{x:1345,y:779,t:1526930210310};\\\", \\\"{x:1362,y:791,t:1526930210327};\\\", \\\"{x:1367,y:794,t:1526930210344};\\\", \\\"{x:1367,y:792,t:1526930210588};\\\", \\\"{x:1367,y:790,t:1526930210595};\\\", \\\"{x:1367,y:787,t:1526930210611};\\\", \\\"{x:1367,y:782,t:1526930210627};\\\", \\\"{x:1366,y:775,t:1526930210644};\\\", \\\"{x:1365,y:774,t:1526930210661};\\\", \\\"{x:1365,y:773,t:1526930210684};\\\", \\\"{x:1364,y:773,t:1526930210724};\\\", \\\"{x:1364,y:772,t:1526930210788};\\\", \\\"{x:1363,y:772,t:1526930210804};\\\", \\\"{x:1361,y:772,t:1526930210852};\\\", \\\"{x:1360,y:772,t:1526930210860};\\\", \\\"{x:1357,y:771,t:1526930210884};\\\", \\\"{x:1355,y:771,t:1526930210908};\\\", \\\"{x:1354,y:771,t:1526930211093};\\\", \\\"{x:1353,y:771,t:1526930211110};\\\", \\\"{x:1352,y:771,t:1526930211133};\\\", \\\"{x:1351,y:771,t:1526930211156};\\\", \\\"{x:1349,y:771,t:1526930211180};\\\", \\\"{x:1348,y:771,t:1526930211196};\\\", \\\"{x:1345,y:771,t:1526930211212};\\\", \\\"{x:1342,y:770,t:1526930211226};\\\", \\\"{x:1337,y:770,t:1526930211243};\\\", \\\"{x:1329,y:768,t:1526930211260};\\\", \\\"{x:1329,y:767,t:1526930211452};\\\", \\\"{x:1329,y:766,t:1526930211484};\\\", \\\"{x:1329,y:765,t:1526930211492};\\\", \\\"{x:1329,y:764,t:1526930211524};\\\", \\\"{x:1330,y:764,t:1526930211556};\\\", \\\"{x:1331,y:764,t:1526930211734};\\\", \\\"{x:1332,y:762,t:1526930211741};\\\", \\\"{x:1334,y:761,t:1526930211771};\\\", \\\"{x:1335,y:761,t:1526930211779};\\\", \\\"{x:1336,y:761,t:1526930211791};\\\", \\\"{x:1340,y:759,t:1526930211808};\\\", \\\"{x:1342,y:758,t:1526930211825};\\\", \\\"{x:1344,y:755,t:1526930211842};\\\", \\\"{x:1346,y:754,t:1526930211858};\\\", \\\"{x:1348,y:749,t:1526930211874};\\\", \\\"{x:1350,y:747,t:1526930211891};\\\", \\\"{x:1350,y:744,t:1526930211909};\\\", \\\"{x:1350,y:743,t:1526930211925};\\\", \\\"{x:1351,y:742,t:1526930211942};\\\", \\\"{x:1350,y:742,t:1526930212284};\\\", \\\"{x:1349,y:742,t:1526930212300};\\\", \\\"{x:1347,y:742,t:1526930212307};\\\", \\\"{x:1345,y:742,t:1526930212325};\\\", \\\"{x:1343,y:743,t:1526930212420};\\\", \\\"{x:1342,y:744,t:1526930212428};\\\", \\\"{x:1341,y:744,t:1526930212468};\\\", \\\"{x:1339,y:745,t:1526930212484};\\\", \\\"{x:1339,y:746,t:1526930212491};\\\", \\\"{x:1337,y:746,t:1526930212524};\\\", \\\"{x:1336,y:747,t:1526930212541};\\\", \\\"{x:1336,y:749,t:1526930212564};\\\", \\\"{x:1336,y:754,t:1526930212574};\\\", \\\"{x:1336,y:759,t:1526930212591};\\\", \\\"{x:1337,y:766,t:1526930212607};\\\", \\\"{x:1342,y:769,t:1526930212623};\\\", \\\"{x:1342,y:768,t:1526930212787};\\\", \\\"{x:1343,y:766,t:1526930212837};\\\", \\\"{x:1344,y:765,t:1526930212856};\\\", \\\"{x:1344,y:764,t:1526930212875};\\\", \\\"{x:1344,y:763,t:1526930212899};\\\", \\\"{x:1344,y:762,t:1526930212923};\\\", \\\"{x:1344,y:761,t:1526930213028};\\\", \\\"{x:1345,y:760,t:1526930213108};\\\", \\\"{x:1344,y:760,t:1526930214476};\\\", \\\"{x:1343,y:760,t:1526930215596};\\\", \\\"{x:1342,y:760,t:1526930215694};\\\", \\\"{x:1341,y:761,t:1526930216401};\\\", \\\"{x:1338,y:763,t:1526930216416};\\\", \\\"{x:1337,y:765,t:1526930216424};\\\", \\\"{x:1336,y:765,t:1526930216439};\\\", \\\"{x:1334,y:765,t:1526930216455};\\\", \\\"{x:1335,y:763,t:1526930216608};\\\", \\\"{x:1339,y:758,t:1526930216622};\\\", \\\"{x:1349,y:744,t:1526930216638};\\\", \\\"{x:1355,y:731,t:1526930216656};\\\", \\\"{x:1361,y:714,t:1526930216672};\\\", \\\"{x:1365,y:701,t:1526930216688};\\\", \\\"{x:1369,y:688,t:1526930216705};\\\", \\\"{x:1373,y:668,t:1526930216721};\\\", \\\"{x:1375,y:654,t:1526930216738};\\\", \\\"{x:1380,y:640,t:1526930216755};\\\", \\\"{x:1382,y:623,t:1526930216771};\\\", \\\"{x:1386,y:603,t:1526930216788};\\\", \\\"{x:1386,y:583,t:1526930216805};\\\", \\\"{x:1386,y:574,t:1526930216821};\\\", \\\"{x:1386,y:568,t:1526930216838};\\\", \\\"{x:1386,y:554,t:1526930216855};\\\", \\\"{x:1386,y:542,t:1526930216871};\\\", \\\"{x:1386,y:526,t:1526930216888};\\\", \\\"{x:1386,y:515,t:1526930216905};\\\", \\\"{x:1389,y:498,t:1526930216921};\\\", \\\"{x:1389,y:491,t:1526930216939};\\\", \\\"{x:1390,y:485,t:1526930216954};\\\", \\\"{x:1390,y:483,t:1526930216971};\\\", \\\"{x:1390,y:485,t:1526930217096};\\\", \\\"{x:1390,y:488,t:1526930217104};\\\", \\\"{x:1388,y:496,t:1526930217121};\\\", \\\"{x:1386,y:505,t:1526930217138};\\\", \\\"{x:1381,y:512,t:1526930217154};\\\", \\\"{x:1381,y:520,t:1526930217171};\\\", \\\"{x:1381,y:528,t:1526930217187};\\\", \\\"{x:1379,y:539,t:1526930217204};\\\", \\\"{x:1374,y:556,t:1526930217222};\\\", \\\"{x:1369,y:577,t:1526930217237};\\\", \\\"{x:1362,y:596,t:1526930217254};\\\", \\\"{x:1360,y:606,t:1526930217271};\\\", \\\"{x:1359,y:613,t:1526930217287};\\\", \\\"{x:1356,y:620,t:1526930217304};\\\", \\\"{x:1354,y:623,t:1526930217321};\\\", \\\"{x:1354,y:624,t:1526930218416};\\\", \\\"{x:1353,y:623,t:1526930218473};\\\", \\\"{x:1351,y:621,t:1526930218486};\\\", \\\"{x:1348,y:614,t:1526930218502};\\\", \\\"{x:1345,y:609,t:1526930218519};\\\", \\\"{x:1337,y:606,t:1526930218535};\\\", \\\"{x:1323,y:598,t:1526930218552};\\\", \\\"{x:1313,y:596,t:1526930218569};\\\", \\\"{x:1307,y:595,t:1526930218585};\\\", \\\"{x:1303,y:593,t:1526930218602};\\\", \\\"{x:1297,y:590,t:1526930218618};\\\", \\\"{x:1290,y:587,t:1526930218635};\\\", \\\"{x:1285,y:585,t:1526930218652};\\\", \\\"{x:1281,y:583,t:1526930218668};\\\", \\\"{x:1279,y:582,t:1526930218685};\\\", \\\"{x:1279,y:581,t:1526930218745};\\\", \\\"{x:1279,y:580,t:1526930218760};\\\", \\\"{x:1279,y:578,t:1526930218792};\\\", \\\"{x:1279,y:576,t:1526930218801};\\\", \\\"{x:1279,y:574,t:1526930218818};\\\", \\\"{x:1279,y:573,t:1526930218835};\\\", \\\"{x:1279,y:570,t:1526930218856};\\\", \\\"{x:1279,y:568,t:1526930218872};\\\", \\\"{x:1281,y:566,t:1526930218901};\\\", \\\"{x:1281,y:565,t:1526930218918};\\\", \\\"{x:1282,y:563,t:1526930218935};\\\", \\\"{x:1283,y:562,t:1526930219048};\\\", \\\"{x:1284,y:562,t:1526930219055};\\\", \\\"{x:1284,y:561,t:1526930220047};\\\", \\\"{x:1287,y:558,t:1526930220055};\\\", \\\"{x:1291,y:557,t:1526930220071};\\\", \\\"{x:1293,y:555,t:1526930220083};\\\", \\\"{x:1307,y:550,t:1526930220099};\\\", \\\"{x:1328,y:546,t:1526930220116};\\\", \\\"{x:1342,y:543,t:1526930220133};\\\", \\\"{x:1354,y:543,t:1526930220149};\\\", \\\"{x:1358,y:543,t:1526930220166};\\\", \\\"{x:1359,y:542,t:1526930220183};\\\", \\\"{x:1360,y:542,t:1526930220240};\\\", \\\"{x:1362,y:542,t:1526930220272};\\\", \\\"{x:1365,y:542,t:1526930220282};\\\", \\\"{x:1367,y:542,t:1526930220300};\\\", \\\"{x:1375,y:542,t:1526930220316};\\\", \\\"{x:1378,y:544,t:1526930220332};\\\", \\\"{x:1383,y:546,t:1526930220349};\\\", \\\"{x:1384,y:546,t:1526930220367};\\\", \\\"{x:1385,y:547,t:1526930220537};\\\", \\\"{x:1386,y:547,t:1526930220559};\\\", \\\"{x:1386,y:549,t:1526930220583};\\\", \\\"{x:1387,y:549,t:1526930220598};\\\", \\\"{x:1388,y:549,t:1526930220623};\\\", \\\"{x:1389,y:550,t:1526930220639};\\\", \\\"{x:1391,y:550,t:1526930220648};\\\", \\\"{x:1396,y:554,t:1526930220665};\\\", \\\"{x:1400,y:557,t:1526930220681};\\\", \\\"{x:1405,y:558,t:1526930220698};\\\", \\\"{x:1406,y:559,t:1526930220714};\\\", \\\"{x:1407,y:559,t:1526930220912};\\\", \\\"{x:1409,y:559,t:1526930220938};\\\", \\\"{x:1410,y:559,t:1526930220948};\\\", \\\"{x:1412,y:559,t:1526930220965};\\\", \\\"{x:1414,y:558,t:1526930220981};\\\", \\\"{x:1411,y:558,t:1526930223994};\\\", \\\"{x:1407,y:564,t:1526930224009};\\\", \\\"{x:1403,y:571,t:1526930224025};\\\", \\\"{x:1400,y:577,t:1526930224043};\\\", \\\"{x:1397,y:583,t:1526930224059};\\\", \\\"{x:1393,y:590,t:1526930224075};\\\", \\\"{x:1388,y:597,t:1526930224093};\\\", \\\"{x:1384,y:606,t:1526930224108};\\\", \\\"{x:1378,y:613,t:1526930224126};\\\", \\\"{x:1374,y:620,t:1526930224142};\\\", \\\"{x:1373,y:626,t:1526930224159};\\\", \\\"{x:1369,y:634,t:1526930224176};\\\", \\\"{x:1367,y:642,t:1526930224193};\\\", \\\"{x:1366,y:648,t:1526930224209};\\\", \\\"{x:1362,y:655,t:1526930224225};\\\", \\\"{x:1362,y:659,t:1526930224243};\\\", \\\"{x:1362,y:662,t:1526930224259};\\\", \\\"{x:1362,y:665,t:1526930224276};\\\", \\\"{x:1362,y:669,t:1526930224292};\\\", \\\"{x:1362,y:671,t:1526930224309};\\\", \\\"{x:1356,y:680,t:1526930224327};\\\", \\\"{x:1356,y:683,t:1526930224343};\\\", \\\"{x:1354,y:684,t:1526930224359};\\\", \\\"{x:1353,y:686,t:1526930224376};\\\", \\\"{x:1353,y:687,t:1526930224433};\\\", \\\"{x:1352,y:687,t:1526930224448};\\\", \\\"{x:1351,y:688,t:1526930224560};\\\", \\\"{x:1351,y:689,t:1526930224592};\\\", \\\"{x:1350,y:689,t:1526930224609};\\\", \\\"{x:1348,y:690,t:1526930224626};\\\", \\\"{x:1346,y:692,t:1526930224642};\\\", \\\"{x:1345,y:692,t:1526930224659};\\\", \\\"{x:1345,y:693,t:1526930234248};\\\", \\\"{x:1343,y:693,t:1526930234260};\\\", \\\"{x:1337,y:690,t:1526930234277};\\\", \\\"{x:1321,y:683,t:1526930234294};\\\", \\\"{x:1266,y:662,t:1526930234310};\\\", \\\"{x:1123,y:627,t:1526930234327};\\\", \\\"{x:920,y:571,t:1526930234345};\\\", \\\"{x:803,y:535,t:1526930234360};\\\", \\\"{x:716,y:506,t:1526930234376};\\\", \\\"{x:691,y:500,t:1526930234401};\\\", \\\"{x:690,y:500,t:1526930234417};\\\", \\\"{x:689,y:500,t:1526930234434};\\\", \\\"{x:688,y:500,t:1526930234551};\\\", \\\"{x:685,y:501,t:1526930234567};\\\", \\\"{x:682,y:502,t:1526930234584};\\\", \\\"{x:677,y:505,t:1526930234601};\\\", \\\"{x:675,y:507,t:1526930234618};\\\", \\\"{x:671,y:511,t:1526930234634};\\\", \\\"{x:668,y:515,t:1526930234651};\\\", \\\"{x:667,y:517,t:1526930234667};\\\", \\\"{x:664,y:520,t:1526930234685};\\\", \\\"{x:663,y:520,t:1526930234700};\\\", \\\"{x:662,y:520,t:1526930234718};\\\", \\\"{x:661,y:520,t:1526930234767};\\\", \\\"{x:660,y:520,t:1526930234775};\\\", \\\"{x:655,y:520,t:1526930234785};\\\", \\\"{x:647,y:522,t:1526930234802};\\\", \\\"{x:633,y:523,t:1526930234818};\\\", \\\"{x:622,y:523,t:1526930234835};\\\", \\\"{x:615,y:523,t:1526930234852};\\\", \\\"{x:608,y:525,t:1526930234870};\\\", \\\"{x:607,y:526,t:1526930234885};\\\", \\\"{x:607,y:527,t:1526930234911};\\\", \\\"{x:609,y:528,t:1526930234935};\\\", \\\"{x:632,y:533,t:1526930234951};\\\", \\\"{x:662,y:538,t:1526930234968};\\\", \\\"{x:744,y:559,t:1526930234986};\\\", \\\"{x:817,y:571,t:1526930235001};\\\", \\\"{x:881,y:580,t:1526930235018};\\\", \\\"{x:910,y:583,t:1526930235034};\\\", \\\"{x:918,y:582,t:1526930235050};\\\", \\\"{x:919,y:581,t:1526930235087};\\\", \\\"{x:919,y:580,t:1526930235127};\\\", \\\"{x:919,y:579,t:1526930235151};\\\", \\\"{x:919,y:578,t:1526930235168};\\\", \\\"{x:919,y:577,t:1526930235185};\\\", \\\"{x:914,y:573,t:1526930235201};\\\", \\\"{x:894,y:568,t:1526930235218};\\\", \\\"{x:883,y:565,t:1526930235235};\\\", \\\"{x:869,y:559,t:1526930235252};\\\", \\\"{x:860,y:557,t:1526930235268};\\\", \\\"{x:858,y:555,t:1526930235285};\\\", \\\"{x:858,y:554,t:1526930235326};\\\", \\\"{x:858,y:552,t:1526930235350};\\\", \\\"{x:857,y:550,t:1526930235374};\\\", \\\"{x:857,y:549,t:1526930235390};\\\", \\\"{x:856,y:548,t:1526930235402};\\\", \\\"{x:856,y:547,t:1526930235418};\\\", \\\"{x:855,y:546,t:1526930235435};\\\", \\\"{x:854,y:546,t:1526930235452};\\\", \\\"{x:852,y:545,t:1526930235478};\\\", \\\"{x:850,y:545,t:1526930235511};\\\", \\\"{x:850,y:544,t:1526930235519};\\\", \\\"{x:847,y:544,t:1526930235551};\\\", \\\"{x:846,y:543,t:1526930235559};\\\", \\\"{x:844,y:542,t:1526930235656};\\\", \\\"{x:843,y:541,t:1526930235752};\\\", \\\"{x:841,y:541,t:1526930236208};\\\", \\\"{x:839,y:542,t:1526930236219};\\\", \\\"{x:831,y:547,t:1526930236236};\\\", \\\"{x:826,y:555,t:1526930236253};\\\", \\\"{x:815,y:565,t:1526930236270};\\\", \\\"{x:805,y:573,t:1526930236286};\\\", \\\"{x:791,y:584,t:1526930236302};\\\", \\\"{x:777,y:595,t:1526930236320};\\\", \\\"{x:765,y:604,t:1526930236336};\\\", \\\"{x:760,y:608,t:1526930236352};\\\", \\\"{x:750,y:617,t:1526930236369};\\\", \\\"{x:740,y:630,t:1526930236386};\\\", \\\"{x:736,y:639,t:1526930236403};\\\", \\\"{x:731,y:646,t:1526930236419};\\\", \\\"{x:727,y:655,t:1526930236436};\\\", \\\"{x:718,y:662,t:1526930236452};\\\", \\\"{x:707,y:669,t:1526930236469};\\\", \\\"{x:696,y:675,t:1526930236486};\\\", \\\"{x:686,y:683,t:1526930236503};\\\", \\\"{x:668,y:686,t:1526930236519};\\\", \\\"{x:653,y:688,t:1526930236537};\\\", \\\"{x:631,y:689,t:1526930236552};\\\", \\\"{x:612,y:689,t:1526930236569};\\\", \\\"{x:586,y:689,t:1526930236586};\\\", \\\"{x:563,y:682,t:1526930236603};\\\", \\\"{x:537,y:678,t:1526930236619};\\\", \\\"{x:507,y:677,t:1526930236636};\\\", \\\"{x:489,y:671,t:1526930236652};\\\", \\\"{x:476,y:671,t:1526930236669};\\\", \\\"{x:467,y:672,t:1526930236686};\\\", \\\"{x:462,y:685,t:1526930236702};\\\", \\\"{x:462,y:689,t:1526930236720};\\\", \\\"{x:462,y:690,t:1526930236738};\\\", \\\"{x:465,y:693,t:1526930236759};\\\", \\\"{x:466,y:696,t:1526930236770};\\\", \\\"{x:469,y:705,t:1526930236786};\\\", \\\"{x:476,y:717,t:1526930236804};\\\", \\\"{x:479,y:722,t:1526930236821};\\\", \\\"{x:479,y:724,t:1526930236838};\\\", \\\"{x:479,y:725,t:1526930236853};\\\", \\\"{x:479,y:723,t:1526930237455};\\\", \\\"{x:479,y:722,t:1526930237504};\\\", \\\"{x:479,y:720,t:1526930237521};\\\", \\\"{x:479,y:719,t:1526930237537};\\\", \\\"{x:479,y:716,t:1526930237554};\\\", \\\"{x:480,y:713,t:1526930237570};\\\", \\\"{x:482,y:711,t:1526930237588};\\\", \\\"{x:484,y:708,t:1526930237602};\\\", \\\"{x:485,y:705,t:1526930237620};\\\", \\\"{x:487,y:701,t:1526930237637};\\\", \\\"{x:489,y:697,t:1526930237653};\\\", \\\"{x:490,y:694,t:1526930237670};\\\", \\\"{x:494,y:687,t:1526930237687};\\\", \\\"{x:498,y:681,t:1526930237704};\\\", \\\"{x:501,y:676,t:1526930237721};\\\", \\\"{x:503,y:672,t:1526930237737};\\\", \\\"{x:505,y:666,t:1526930237754};\\\", \\\"{x:507,y:664,t:1526930237770};\\\", \\\"{x:510,y:659,t:1526930237787};\\\", \\\"{x:512,y:656,t:1526930237803};\\\", \\\"{x:515,y:652,t:1526930237821};\\\", \\\"{x:521,y:647,t:1526930237837};\\\", \\\"{x:527,y:642,t:1526930237854};\\\", \\\"{x:531,y:637,t:1526930237871};\\\", \\\"{x:535,y:629,t:1526930237887};\\\", \\\"{x:539,y:624,t:1526930237904};\\\", \\\"{x:543,y:619,t:1526930237920};\\\", \\\"{x:550,y:614,t:1526930237937};\\\", \\\"{x:558,y:609,t:1526930237954};\\\", \\\"{x:563,y:605,t:1526930237970};\\\", \\\"{x:570,y:600,t:1526930237987};\\\", \\\"{x:584,y:596,t:1526930238004};\\\", \\\"{x:589,y:592,t:1526930238021};\\\", \\\"{x:597,y:589,t:1526930238037};\\\", \\\"{x:602,y:586,t:1526930238054};\\\", \\\"{x:609,y:584,t:1526930238070};\\\", \\\"{x:613,y:580,t:1526930238088};\\\", \\\"{x:617,y:577,t:1526930238104};\\\", \\\"{x:620,y:576,t:1526930238120};\\\", \\\"{x:628,y:571,t:1526930238138};\\\", \\\"{x:632,y:569,t:1526930238154};\\\", \\\"{x:635,y:567,t:1526930238170};\\\", \\\"{x:643,y:564,t:1526930238194};\\\", \\\"{x:646,y:563,t:1526930238204};\\\", \\\"{x:656,y:560,t:1526930238220};\\\", \\\"{x:667,y:554,t:1526930238237};\\\", \\\"{x:684,y:546,t:1526930238254};\\\", \\\"{x:709,y:533,t:1526930238270};\\\" ] }, { \\\"rt\\\": 62113, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 623996, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -B -B -B -B -B -02 PM-E -E -I -I -B -10 AM-E -E -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1360,y:505,t:1526930238426};\\\", \\\"{x:1365,y:505,t:1526930238437};\\\", \\\"{x:1366,y:505,t:1526930238454};\\\", \\\"{x:1365,y:505,t:1526930239648};\\\", \\\"{x:1364,y:505,t:1526930239750};\\\", \\\"{x:1363,y:505,t:1526930239895};\\\", \\\"{x:1363,y:506,t:1526930239968};\\\", \\\"{x:1361,y:506,t:1526930240120};\\\", \\\"{x:1360,y:506,t:1526930240168};\\\", \\\"{x:1358,y:507,t:1526930240544};\\\", \\\"{x:1357,y:507,t:1526930240560};\\\", \\\"{x:1356,y:507,t:1526930240768};\\\", \\\"{x:1355,y:507,t:1526930240783};\\\", \\\"{x:1354,y:507,t:1526930240840};\\\", \\\"{x:1354,y:508,t:1526930240863};\\\", \\\"{x:1353,y:508,t:1526930241112};\\\", \\\"{x:1351,y:509,t:1526930241124};\\\", \\\"{x:1351,y:510,t:1526930242096};\\\", \\\"{x:1350,y:510,t:1526930244792};\\\", \\\"{x:1347,y:511,t:1526930244863};\\\", \\\"{x:1347,y:512,t:1526930244879};\\\", \\\"{x:1346,y:512,t:1526930244904};\\\", \\\"{x:1346,y:513,t:1526930244911};\\\", \\\"{x:1343,y:515,t:1526930244926};\\\", \\\"{x:1330,y:528,t:1526930244943};\\\", \\\"{x:1321,y:541,t:1526930244960};\\\", \\\"{x:1315,y:550,t:1526930244976};\\\", \\\"{x:1311,y:556,t:1526930244993};\\\", \\\"{x:1307,y:565,t:1526930245010};\\\", \\\"{x:1304,y:571,t:1526930245026};\\\", \\\"{x:1301,y:584,t:1526930245043};\\\", \\\"{x:1299,y:606,t:1526930245060};\\\", \\\"{x:1299,y:629,t:1526930245076};\\\", \\\"{x:1297,y:658,t:1526930245093};\\\", \\\"{x:1297,y:686,t:1526930245111};\\\", \\\"{x:1304,y:715,t:1526930245127};\\\", \\\"{x:1312,y:742,t:1526930245144};\\\", \\\"{x:1312,y:749,t:1526930245160};\\\", \\\"{x:1314,y:752,t:1526930245176};\\\", \\\"{x:1314,y:754,t:1526930245193};\\\", \\\"{x:1312,y:756,t:1526930245210};\\\", \\\"{x:1309,y:759,t:1526930245226};\\\", \\\"{x:1304,y:761,t:1526930245242};\\\", \\\"{x:1297,y:764,t:1526930245259};\\\", \\\"{x:1295,y:766,t:1526930245275};\\\", \\\"{x:1292,y:768,t:1526930245293};\\\", \\\"{x:1287,y:770,t:1526930245309};\\\", \\\"{x:1281,y:772,t:1526930245327};\\\", \\\"{x:1279,y:773,t:1526930245343};\\\", \\\"{x:1274,y:775,t:1526930245359};\\\", \\\"{x:1271,y:777,t:1526930245377};\\\", \\\"{x:1264,y:781,t:1526930245393};\\\", \\\"{x:1256,y:787,t:1526930245409};\\\", \\\"{x:1240,y:795,t:1526930245426};\\\", \\\"{x:1234,y:801,t:1526930245443};\\\", \\\"{x:1224,y:810,t:1526930245460};\\\", \\\"{x:1211,y:820,t:1526930245476};\\\", \\\"{x:1204,y:825,t:1526930245493};\\\", \\\"{x:1196,y:830,t:1526930245509};\\\", \\\"{x:1187,y:837,t:1526930245527};\\\", \\\"{x:1186,y:838,t:1526930245551};\\\", \\\"{x:1185,y:838,t:1526930245583};\\\", \\\"{x:1185,y:839,t:1526930245593};\\\", \\\"{x:1184,y:839,t:1526930245623};\\\", \\\"{x:1185,y:841,t:1526930246095};\\\", \\\"{x:1187,y:841,t:1526930246119};\\\", \\\"{x:1188,y:841,t:1526930246135};\\\", \\\"{x:1191,y:841,t:1526930246152};\\\", \\\"{x:1191,y:842,t:1526930246160};\\\", \\\"{x:1192,y:842,t:1526930246183};\\\", \\\"{x:1193,y:842,t:1526930246223};\\\", \\\"{x:1194,y:842,t:1526930246231};\\\", \\\"{x:1197,y:842,t:1526930246247};\\\", \\\"{x:1199,y:842,t:1526930246260};\\\", \\\"{x:1201,y:842,t:1526930246277};\\\", \\\"{x:1208,y:842,t:1526930246294};\\\", \\\"{x:1218,y:842,t:1526930246311};\\\", \\\"{x:1224,y:841,t:1526930246327};\\\", \\\"{x:1228,y:839,t:1526930246344};\\\", \\\"{x:1233,y:837,t:1526930246361};\\\", \\\"{x:1236,y:835,t:1526930246377};\\\", \\\"{x:1243,y:834,t:1526930246394};\\\", \\\"{x:1245,y:832,t:1526930246411};\\\", \\\"{x:1245,y:831,t:1526930246427};\\\", \\\"{x:1244,y:831,t:1526930246568};\\\", \\\"{x:1243,y:832,t:1526930246577};\\\", \\\"{x:1241,y:833,t:1526930246594};\\\", \\\"{x:1240,y:833,t:1526930246611};\\\", \\\"{x:1239,y:833,t:1526930246627};\\\", \\\"{x:1238,y:833,t:1526930246644};\\\", \\\"{x:1237,y:834,t:1526930246752};\\\", \\\"{x:1235,y:834,t:1526930246767};\\\", \\\"{x:1234,y:835,t:1526930246778};\\\", \\\"{x:1233,y:836,t:1526930246795};\\\", \\\"{x:1230,y:836,t:1526930246811};\\\", \\\"{x:1229,y:836,t:1526930246831};\\\", \\\"{x:1228,y:836,t:1526930246896};\\\", \\\"{x:1227,y:836,t:1526930246911};\\\", \\\"{x:1225,y:838,t:1526930246927};\\\", \\\"{x:1224,y:838,t:1526930246944};\\\", \\\"{x:1222,y:838,t:1526930246961};\\\", \\\"{x:1222,y:839,t:1526930246978};\\\", \\\"{x:1219,y:839,t:1526930246994};\\\", \\\"{x:1217,y:841,t:1526930247012};\\\", \\\"{x:1214,y:842,t:1526930247028};\\\", \\\"{x:1213,y:842,t:1526930247143};\\\", \\\"{x:1213,y:843,t:1526930247161};\\\", \\\"{x:1214,y:843,t:1526930247312};\\\", \\\"{x:1214,y:842,t:1526930247351};\\\", \\\"{x:1215,y:841,t:1526930247383};\\\", \\\"{x:1216,y:840,t:1526930247431};\\\", \\\"{x:1216,y:839,t:1526930247519};\\\", \\\"{x:1217,y:838,t:1526930247575};\\\", \\\"{x:1217,y:836,t:1526930248222};\\\", \\\"{x:1218,y:836,t:1526930248310};\\\", \\\"{x:1218,y:835,t:1526930250872};\\\", \\\"{x:1218,y:833,t:1526930253114};\\\", \\\"{x:1218,y:832,t:1526930253200};\\\", \\\"{x:1218,y:831,t:1526930253215};\\\", \\\"{x:1218,y:830,t:1526930253232};\\\", \\\"{x:1218,y:829,t:1526930253248};\\\", \\\"{x:1218,y:827,t:1526930253265};\\\", \\\"{x:1218,y:826,t:1526930253359};\\\", \\\"{x:1218,y:824,t:1526930253489};\\\", \\\"{x:1218,y:823,t:1526930253503};\\\", \\\"{x:1218,y:821,t:1526930253535};\\\", \\\"{x:1218,y:820,t:1526930253549};\\\", \\\"{x:1218,y:818,t:1526930253583};\\\", \\\"{x:1218,y:817,t:1526930253615};\\\", \\\"{x:1218,y:815,t:1526930253663};\\\", \\\"{x:1218,y:814,t:1526930253687};\\\", \\\"{x:1218,y:813,t:1526930253700};\\\", \\\"{x:1218,y:811,t:1526930253717};\\\", \\\"{x:1218,y:809,t:1526930253732};\\\", \\\"{x:1220,y:807,t:1526930253750};\\\", \\\"{x:1221,y:807,t:1526930253808};\\\", \\\"{x:1220,y:807,t:1526930254047};\\\", \\\"{x:1220,y:806,t:1526930254087};\\\", \\\"{x:1220,y:805,t:1526930254287};\\\", \\\"{x:1221,y:804,t:1526930254299};\\\", \\\"{x:1223,y:801,t:1526930254317};\\\", \\\"{x:1227,y:798,t:1526930254334};\\\", \\\"{x:1228,y:797,t:1526930254350};\\\", \\\"{x:1229,y:796,t:1526930254367};\\\", \\\"{x:1230,y:794,t:1526930254383};\\\", \\\"{x:1232,y:794,t:1526930254401};\\\", \\\"{x:1232,y:793,t:1526930254423};\\\", \\\"{x:1232,y:791,t:1526930254439};\\\", \\\"{x:1233,y:791,t:1526930254450};\\\", \\\"{x:1234,y:791,t:1526930254479};\\\", \\\"{x:1235,y:791,t:1526930254504};\\\", \\\"{x:1237,y:791,t:1526930254519};\\\", \\\"{x:1238,y:791,t:1526930254543};\\\", \\\"{x:1240,y:791,t:1526930254600};\\\", \\\"{x:1246,y:795,t:1526930254616};\\\", \\\"{x:1269,y:795,t:1526930254633};\\\", \\\"{x:1280,y:796,t:1526930254651};\\\", \\\"{x:1295,y:797,t:1526930254666};\\\", \\\"{x:1313,y:797,t:1526930254683};\\\", \\\"{x:1319,y:797,t:1526930254700};\\\", \\\"{x:1322,y:797,t:1526930254716};\\\", \\\"{x:1325,y:795,t:1526930254791};\\\", \\\"{x:1327,y:795,t:1526930254807};\\\", \\\"{x:1327,y:794,t:1526930254817};\\\", \\\"{x:1329,y:791,t:1526930254834};\\\", \\\"{x:1330,y:791,t:1526930254850};\\\", \\\"{x:1330,y:789,t:1526930254867};\\\", \\\"{x:1331,y:788,t:1526930254883};\\\", \\\"{x:1333,y:785,t:1526930254901};\\\", \\\"{x:1336,y:779,t:1526930254917};\\\", \\\"{x:1342,y:773,t:1526930254933};\\\", \\\"{x:1348,y:768,t:1526930254951};\\\", \\\"{x:1353,y:765,t:1526930254967};\\\", \\\"{x:1354,y:765,t:1526930255136};\\\", \\\"{x:1355,y:765,t:1526930255366};\\\", \\\"{x:1354,y:765,t:1526930256079};\\\", \\\"{x:1353,y:765,t:1526930256152};\\\", \\\"{x:1351,y:765,t:1526930256199};\\\", \\\"{x:1350,y:765,t:1526930256270};\\\", \\\"{x:1349,y:765,t:1526930257047};\\\", \\\"{x:1348,y:765,t:1526930257055};\\\", \\\"{x:1346,y:765,t:1526930257071};\\\", \\\"{x:1344,y:765,t:1526930257085};\\\", \\\"{x:1343,y:765,t:1526930257102};\\\", \\\"{x:1341,y:766,t:1526930257144};\\\", \\\"{x:1340,y:766,t:1526930257400};\\\", \\\"{x:1338,y:768,t:1526930257447};\\\", \\\"{x:1336,y:769,t:1526930257496};\\\", \\\"{x:1334,y:769,t:1526930257607};\\\", \\\"{x:1333,y:769,t:1526930258607};\\\", \\\"{x:1331,y:770,t:1526930259312};\\\", \\\"{x:1330,y:771,t:1526930259320};\\\", \\\"{x:1329,y:771,t:1526930259337};\\\", \\\"{x:1330,y:771,t:1526930259951};\\\", \\\"{x:1333,y:771,t:1526930259959};\\\", \\\"{x:1335,y:770,t:1526930259975};\\\", \\\"{x:1338,y:768,t:1526930259990};\\\", \\\"{x:1339,y:768,t:1526930260004};\\\", \\\"{x:1341,y:767,t:1526930260020};\\\", \\\"{x:1343,y:767,t:1526930260062};\\\", \\\"{x:1344,y:766,t:1526930260078};\\\", \\\"{x:1346,y:764,t:1526930260086};\\\", \\\"{x:1348,y:762,t:1526930260104};\\\", \\\"{x:1350,y:758,t:1526930260119};\\\", \\\"{x:1351,y:757,t:1526930260137};\\\", \\\"{x:1353,y:756,t:1526930260174};\\\", \\\"{x:1354,y:756,t:1526930260190};\\\", \\\"{x:1354,y:755,t:1526930260204};\\\", \\\"{x:1355,y:754,t:1526930260220};\\\", \\\"{x:1356,y:752,t:1526930260237};\\\", \\\"{x:1357,y:751,t:1526930260254};\\\", \\\"{x:1357,y:749,t:1526930260271};\\\", \\\"{x:1358,y:748,t:1526930260287};\\\", \\\"{x:1359,y:748,t:1526930260304};\\\", \\\"{x:1358,y:748,t:1526930260727};\\\", \\\"{x:1357,y:748,t:1526930260775};\\\", \\\"{x:1356,y:748,t:1526930260823};\\\", \\\"{x:1355,y:748,t:1526930260847};\\\", \\\"{x:1353,y:748,t:1526930260871};\\\", \\\"{x:1353,y:749,t:1526930260895};\\\", \\\"{x:1353,y:750,t:1526930260904};\\\", \\\"{x:1352,y:751,t:1526930260921};\\\", \\\"{x:1351,y:751,t:1526930260939};\\\", \\\"{x:1351,y:753,t:1526930260955};\\\", \\\"{x:1351,y:754,t:1526930260975};\\\", \\\"{x:1351,y:755,t:1526930260988};\\\", \\\"{x:1350,y:757,t:1526930261005};\\\", \\\"{x:1347,y:762,t:1526930261022};\\\", \\\"{x:1347,y:764,t:1526930261039};\\\", \\\"{x:1347,y:765,t:1526930261071};\\\", \\\"{x:1347,y:766,t:1526930261103};\\\", \\\"{x:1347,y:767,t:1526930261111};\\\", \\\"{x:1347,y:766,t:1526930261342};\\\", \\\"{x:1348,y:765,t:1526930261383};\\\", \\\"{x:1348,y:767,t:1526930261999};\\\", \\\"{x:1348,y:768,t:1526930262022};\\\", \\\"{x:1348,y:770,t:1526930262046};\\\", \\\"{x:1348,y:771,t:1526930262054};\\\", \\\"{x:1350,y:774,t:1526930262072};\\\", \\\"{x:1351,y:775,t:1526930262088};\\\", \\\"{x:1352,y:776,t:1526930262110};\\\", \\\"{x:1353,y:778,t:1526930262122};\\\", \\\"{x:1353,y:780,t:1526930262191};\\\", \\\"{x:1354,y:781,t:1526930262383};\\\", \\\"{x:1355,y:782,t:1526930262391};\\\", \\\"{x:1356,y:784,t:1526930262406};\\\", \\\"{x:1362,y:789,t:1526930262423};\\\", \\\"{x:1366,y:792,t:1526930262439};\\\", \\\"{x:1366,y:793,t:1526930262455};\\\", \\\"{x:1367,y:795,t:1526930262473};\\\", \\\"{x:1368,y:795,t:1526930262543};\\\", \\\"{x:1368,y:796,t:1526930262664};\\\", \\\"{x:1368,y:797,t:1526930262673};\\\", \\\"{x:1368,y:798,t:1526930262690};\\\", \\\"{x:1368,y:800,t:1526930262706};\\\", \\\"{x:1369,y:802,t:1526930262723};\\\", \\\"{x:1372,y:805,t:1526930262740};\\\", \\\"{x:1377,y:810,t:1526930262755};\\\", \\\"{x:1378,y:814,t:1526930262772};\\\", \\\"{x:1384,y:822,t:1526930262790};\\\", \\\"{x:1394,y:835,t:1526930262806};\\\", \\\"{x:1397,y:841,t:1526930262822};\\\", \\\"{x:1398,y:844,t:1526930262839};\\\", \\\"{x:1400,y:847,t:1526930262856};\\\", \\\"{x:1400,y:849,t:1526930262872};\\\", \\\"{x:1401,y:851,t:1526930262889};\\\", \\\"{x:1402,y:854,t:1526930262906};\\\", \\\"{x:1405,y:857,t:1526930262922};\\\", \\\"{x:1406,y:860,t:1526930262939};\\\", \\\"{x:1408,y:862,t:1526930262957};\\\", \\\"{x:1409,y:863,t:1526930262973};\\\", \\\"{x:1409,y:864,t:1526930262989};\\\", \\\"{x:1410,y:865,t:1526930263006};\\\", \\\"{x:1410,y:866,t:1526930263022};\\\", \\\"{x:1411,y:868,t:1526930263039};\\\", \\\"{x:1412,y:869,t:1526930263056};\\\", \\\"{x:1412,y:870,t:1526930263073};\\\", \\\"{x:1413,y:871,t:1526930263090};\\\", \\\"{x:1413,y:872,t:1526930263135};\\\", \\\"{x:1413,y:873,t:1526930263167};\\\", \\\"{x:1413,y:874,t:1526930263191};\\\", \\\"{x:1415,y:876,t:1526930263206};\\\", \\\"{x:1415,y:877,t:1526930263223};\\\", \\\"{x:1417,y:880,t:1526930263240};\\\", \\\"{x:1418,y:882,t:1526930263256};\\\", \\\"{x:1418,y:883,t:1526930263273};\\\", \\\"{x:1419,y:885,t:1526930263289};\\\", \\\"{x:1420,y:888,t:1526930263306};\\\", \\\"{x:1422,y:893,t:1526930263323};\\\", \\\"{x:1424,y:898,t:1526930263339};\\\", \\\"{x:1426,y:900,t:1526930263356};\\\", \\\"{x:1426,y:902,t:1526930263373};\\\", \\\"{x:1427,y:903,t:1526930263389};\\\", \\\"{x:1429,y:908,t:1526930263406};\\\", \\\"{x:1429,y:911,t:1526930263423};\\\", \\\"{x:1431,y:917,t:1526930263440};\\\", \\\"{x:1432,y:921,t:1526930263456};\\\", \\\"{x:1434,y:925,t:1526930263473};\\\", \\\"{x:1435,y:929,t:1526930263490};\\\", \\\"{x:1439,y:933,t:1526930263506};\\\", \\\"{x:1442,y:936,t:1526930263523};\\\", \\\"{x:1444,y:942,t:1526930263539};\\\", \\\"{x:1445,y:943,t:1526930263557};\\\", \\\"{x:1445,y:944,t:1526930263573};\\\", \\\"{x:1448,y:949,t:1526930263590};\\\", \\\"{x:1454,y:961,t:1526930263607};\\\", \\\"{x:1457,y:968,t:1526930263623};\\\", \\\"{x:1459,y:972,t:1526930263639};\\\", \\\"{x:1461,y:975,t:1526930263656};\\\", \\\"{x:1462,y:975,t:1526930263720};\\\", \\\"{x:1461,y:975,t:1526930264063};\\\", \\\"{x:1460,y:975,t:1526930264073};\\\", \\\"{x:1457,y:973,t:1526930264091};\\\", \\\"{x:1454,y:971,t:1526930264107};\\\", \\\"{x:1452,y:970,t:1526930264123};\\\", \\\"{x:1450,y:969,t:1526930264140};\\\", \\\"{x:1450,y:968,t:1526930264167};\\\", \\\"{x:1448,y:967,t:1526930264175};\\\", \\\"{x:1448,y:966,t:1526930264190};\\\", \\\"{x:1447,y:966,t:1526930264215};\\\", \\\"{x:1446,y:966,t:1526930264295};\\\", \\\"{x:1444,y:966,t:1526930266528};\\\", \\\"{x:1443,y:967,t:1526930266550};\\\", \\\"{x:1440,y:967,t:1526930268224};\\\", \\\"{x:1438,y:967,t:1526930268238};\\\", \\\"{x:1437,y:967,t:1526930268255};\\\", \\\"{x:1436,y:967,t:1526930268271};\\\", \\\"{x:1434,y:967,t:1526930268278};\\\", \\\"{x:1432,y:966,t:1526930268293};\\\", \\\"{x:1430,y:966,t:1526930268309};\\\", \\\"{x:1428,y:964,t:1526930268326};\\\", \\\"{x:1425,y:964,t:1526930268358};\\\", \\\"{x:1424,y:963,t:1526930268382};\\\", \\\"{x:1422,y:962,t:1526930268414};\\\", \\\"{x:1421,y:961,t:1526930268462};\\\", \\\"{x:1418,y:959,t:1526930268476};\\\", \\\"{x:1412,y:957,t:1526930268494};\\\", \\\"{x:1402,y:951,t:1526930268510};\\\", \\\"{x:1396,y:946,t:1526930268527};\\\", \\\"{x:1389,y:937,t:1526930268544};\\\", \\\"{x:1377,y:928,t:1526930268561};\\\", \\\"{x:1370,y:924,t:1526930268576};\\\", \\\"{x:1366,y:920,t:1526930268594};\\\", \\\"{x:1362,y:917,t:1526930268610};\\\", \\\"{x:1360,y:916,t:1526930268627};\\\", \\\"{x:1359,y:915,t:1526930268644};\\\", \\\"{x:1358,y:915,t:1526930268661};\\\", \\\"{x:1358,y:914,t:1526930268703};\\\", \\\"{x:1357,y:913,t:1526930268719};\\\", \\\"{x:1356,y:912,t:1526930268727};\\\", \\\"{x:1354,y:912,t:1526930268744};\\\", \\\"{x:1349,y:908,t:1526930268761};\\\", \\\"{x:1335,y:904,t:1526930268777};\\\", \\\"{x:1316,y:897,t:1526930268793};\\\", \\\"{x:1309,y:892,t:1526930268810};\\\", \\\"{x:1296,y:885,t:1526930268826};\\\", \\\"{x:1286,y:877,t:1526930268844};\\\", \\\"{x:1278,y:870,t:1526930268860};\\\", \\\"{x:1274,y:867,t:1526930268877};\\\", \\\"{x:1273,y:865,t:1526930268894};\\\", \\\"{x:1271,y:863,t:1526930268967};\\\", \\\"{x:1269,y:863,t:1526930268977};\\\", \\\"{x:1267,y:861,t:1526930268994};\\\", \\\"{x:1263,y:858,t:1526930269011};\\\", \\\"{x:1259,y:854,t:1526930269027};\\\", \\\"{x:1256,y:851,t:1526930269044};\\\", \\\"{x:1252,y:848,t:1526930269061};\\\", \\\"{x:1250,y:848,t:1526930269077};\\\", \\\"{x:1248,y:847,t:1526930269093};\\\", \\\"{x:1241,y:846,t:1526930269110};\\\", \\\"{x:1237,y:843,t:1526930269128};\\\", \\\"{x:1233,y:841,t:1526930269143};\\\", \\\"{x:1229,y:838,t:1526930269161};\\\", \\\"{x:1228,y:836,t:1526930269177};\\\", \\\"{x:1227,y:836,t:1526930269303};\\\", \\\"{x:1226,y:836,t:1526930271847};\\\", \\\"{x:1226,y:837,t:1526930271959};\\\", \\\"{x:1226,y:838,t:1526930271967};\\\", \\\"{x:1224,y:839,t:1526930271982};\\\", \\\"{x:1223,y:839,t:1526930271998};\\\", \\\"{x:1223,y:840,t:1526930272013};\\\", \\\"{x:1222,y:840,t:1526930272927};\\\", \\\"{x:1219,y:842,t:1526930272934};\\\", \\\"{x:1218,y:843,t:1526930272950};\\\", \\\"{x:1216,y:844,t:1526930273079};\\\", \\\"{x:1213,y:844,t:1526930273094};\\\", \\\"{x:1209,y:844,t:1526930273103};\\\", \\\"{x:1207,y:844,t:1526930273118};\\\", \\\"{x:1205,y:844,t:1526930273130};\\\", \\\"{x:1203,y:844,t:1526930273166};\\\", \\\"{x:1202,y:844,t:1526930273183};\\\", \\\"{x:1198,y:844,t:1526930273197};\\\", \\\"{x:1198,y:843,t:1526930273213};\\\", \\\"{x:1195,y:843,t:1526930273231};\\\", \\\"{x:1189,y:838,t:1526930273247};\\\", \\\"{x:1186,y:835,t:1526930273264};\\\", \\\"{x:1186,y:832,t:1526930273281};\\\", \\\"{x:1185,y:830,t:1526930273297};\\\", \\\"{x:1183,y:827,t:1526930273314};\\\", \\\"{x:1183,y:824,t:1526930273331};\\\", \\\"{x:1183,y:819,t:1526930273347};\\\", \\\"{x:1181,y:814,t:1526930273364};\\\", \\\"{x:1180,y:811,t:1526930273381};\\\", \\\"{x:1180,y:810,t:1526930273398};\\\", \\\"{x:1180,y:807,t:1526930273414};\\\", \\\"{x:1180,y:803,t:1526930273430};\\\", \\\"{x:1182,y:801,t:1526930273447};\\\", \\\"{x:1184,y:800,t:1526930273464};\\\", \\\"{x:1184,y:798,t:1526930273480};\\\", \\\"{x:1184,y:797,t:1526930273503};\\\", \\\"{x:1184,y:796,t:1526930273519};\\\", \\\"{x:1184,y:795,t:1526930273531};\\\", \\\"{x:1184,y:793,t:1526930273547};\\\", \\\"{x:1185,y:791,t:1526930273563};\\\", \\\"{x:1186,y:788,t:1526930273580};\\\", \\\"{x:1186,y:786,t:1526930273598};\\\", \\\"{x:1187,y:784,t:1526930273614};\\\", \\\"{x:1188,y:782,t:1526930273631};\\\", \\\"{x:1188,y:781,t:1526930273648};\\\", \\\"{x:1188,y:780,t:1526930273664};\\\", \\\"{x:1188,y:778,t:1526930273682};\\\", \\\"{x:1188,y:776,t:1526930273697};\\\", \\\"{x:1188,y:774,t:1526930273714};\\\", \\\"{x:1188,y:772,t:1526930273731};\\\", \\\"{x:1188,y:770,t:1526930273748};\\\", \\\"{x:1188,y:769,t:1526930273764};\\\", \\\"{x:1188,y:768,t:1526930273910};\\\", \\\"{x:1188,y:766,t:1526930275406};\\\", \\\"{x:1188,y:764,t:1526930275414};\\\", \\\"{x:1194,y:754,t:1526930275431};\\\", \\\"{x:1203,y:747,t:1526930275449};\\\", \\\"{x:1213,y:740,t:1526930275465};\\\", \\\"{x:1223,y:726,t:1526930275482};\\\", \\\"{x:1234,y:709,t:1526930275498};\\\", \\\"{x:1251,y:689,t:1526930275516};\\\", \\\"{x:1266,y:675,t:1526930275531};\\\", \\\"{x:1276,y:655,t:1526930275549};\\\", \\\"{x:1290,y:630,t:1526930275566};\\\", \\\"{x:1299,y:615,t:1526930275581};\\\", \\\"{x:1305,y:598,t:1526930275598};\\\", \\\"{x:1309,y:588,t:1526930275615};\\\", \\\"{x:1310,y:583,t:1526930275631};\\\", \\\"{x:1310,y:582,t:1526930275648};\\\", \\\"{x:1310,y:581,t:1526930275670};\\\", \\\"{x:1307,y:579,t:1526930275823};\\\", \\\"{x:1305,y:578,t:1526930275832};\\\", \\\"{x:1296,y:575,t:1526930275850};\\\", \\\"{x:1292,y:572,t:1526930275866};\\\", \\\"{x:1289,y:570,t:1526930275882};\\\", \\\"{x:1288,y:569,t:1526930275899};\\\", \\\"{x:1287,y:567,t:1526930275918};\\\", \\\"{x:1285,y:565,t:1526930275932};\\\", \\\"{x:1285,y:564,t:1526930275953};\\\", \\\"{x:1285,y:563,t:1526930275970};\\\", \\\"{x:1285,y:561,t:1526930275986};\\\", \\\"{x:1285,y:560,t:1526930276187};\\\", \\\"{x:1285,y:558,t:1526930276324};\\\", \\\"{x:1284,y:558,t:1526930276500};\\\", \\\"{x:1284,y:560,t:1526930276520};\\\", \\\"{x:1284,y:564,t:1526930276537};\\\", \\\"{x:1284,y:570,t:1526930276555};\\\", \\\"{x:1284,y:574,t:1526930276570};\\\", \\\"{x:1284,y:578,t:1526930276587};\\\", \\\"{x:1285,y:585,t:1526930276604};\\\", \\\"{x:1285,y:595,t:1526930276620};\\\", \\\"{x:1287,y:603,t:1526930276637};\\\", \\\"{x:1291,y:610,t:1526930276654};\\\", \\\"{x:1292,y:615,t:1526930276670};\\\", \\\"{x:1294,y:619,t:1526930276686};\\\", \\\"{x:1294,y:623,t:1526930276703};\\\", \\\"{x:1294,y:624,t:1526930276719};\\\", \\\"{x:1295,y:626,t:1526930276778};\\\", \\\"{x:1296,y:627,t:1526930276834};\\\", \\\"{x:1297,y:628,t:1526930276842};\\\", \\\"{x:1298,y:629,t:1526930276858};\\\", \\\"{x:1299,y:630,t:1526930276870};\\\", \\\"{x:1300,y:630,t:1526930276887};\\\", \\\"{x:1301,y:631,t:1526930276904};\\\", \\\"{x:1308,y:636,t:1526930276920};\\\", \\\"{x:1312,y:639,t:1526930276937};\\\", \\\"{x:1323,y:647,t:1526930276954};\\\", \\\"{x:1333,y:656,t:1526930276971};\\\", \\\"{x:1342,y:663,t:1526930276987};\\\", \\\"{x:1354,y:667,t:1526930277004};\\\", \\\"{x:1357,y:670,t:1526930277021};\\\", \\\"{x:1359,y:671,t:1526930277038};\\\", \\\"{x:1360,y:672,t:1526930277059};\\\", \\\"{x:1362,y:674,t:1526930277072};\\\", \\\"{x:1365,y:677,t:1526930277090};\\\", \\\"{x:1366,y:678,t:1526930277104};\\\", \\\"{x:1367,y:681,t:1526930277121};\\\", \\\"{x:1371,y:686,t:1526930277137};\\\", \\\"{x:1373,y:688,t:1526930277154};\\\", \\\"{x:1374,y:691,t:1526930277171};\\\", \\\"{x:1374,y:694,t:1526930277187};\\\", \\\"{x:1374,y:696,t:1526930277205};\\\", \\\"{x:1376,y:700,t:1526930277220};\\\", \\\"{x:1377,y:703,t:1526930277236};\\\", \\\"{x:1377,y:706,t:1526930277254};\\\", \\\"{x:1377,y:710,t:1526930277271};\\\", \\\"{x:1377,y:715,t:1526930277286};\\\", \\\"{x:1377,y:719,t:1526930277304};\\\", \\\"{x:1377,y:722,t:1526930277321};\\\", \\\"{x:1377,y:726,t:1526930277337};\\\", \\\"{x:1377,y:730,t:1526930277353};\\\", \\\"{x:1376,y:732,t:1526930277371};\\\", \\\"{x:1375,y:735,t:1526930277387};\\\", \\\"{x:1375,y:736,t:1526930277403};\\\", \\\"{x:1375,y:739,t:1526930277421};\\\", \\\"{x:1375,y:740,t:1526930277438};\\\", \\\"{x:1375,y:741,t:1526930277458};\\\", \\\"{x:1374,y:743,t:1526930277470};\\\", \\\"{x:1373,y:745,t:1526930277488};\\\", \\\"{x:1373,y:749,t:1526930277504};\\\", \\\"{x:1373,y:750,t:1526930277521};\\\", \\\"{x:1373,y:755,t:1526930277539};\\\", \\\"{x:1373,y:756,t:1526930277555};\\\", \\\"{x:1373,y:759,t:1526930277571};\\\", \\\"{x:1373,y:760,t:1526930277588};\\\", \\\"{x:1374,y:763,t:1526930277604};\\\", \\\"{x:1374,y:766,t:1526930277621};\\\", \\\"{x:1374,y:767,t:1526930277638};\\\", \\\"{x:1374,y:769,t:1526930277654};\\\", \\\"{x:1376,y:771,t:1526930277671};\\\", \\\"{x:1376,y:773,t:1526930277689};\\\", \\\"{x:1377,y:776,t:1526930277705};\\\", \\\"{x:1378,y:777,t:1526930277722};\\\", \\\"{x:1378,y:779,t:1526930277738};\\\", \\\"{x:1380,y:782,t:1526930277754};\\\", \\\"{x:1381,y:785,t:1526930277771};\\\", \\\"{x:1381,y:786,t:1526930277788};\\\", \\\"{x:1381,y:787,t:1526930277819};\\\", \\\"{x:1381,y:788,t:1526930277843};\\\", \\\"{x:1382,y:789,t:1526930277859};\\\", \\\"{x:1383,y:789,t:1526930277883};\\\", \\\"{x:1383,y:790,t:1526930277890};\\\", \\\"{x:1383,y:791,t:1526930277915};\\\", \\\"{x:1383,y:792,t:1526930277923};\\\", \\\"{x:1384,y:794,t:1526930277971};\\\", \\\"{x:1385,y:797,t:1526930277995};\\\", \\\"{x:1387,y:797,t:1526930278011};\\\", \\\"{x:1387,y:798,t:1526930278026};\\\", \\\"{x:1388,y:799,t:1526930278043};\\\", \\\"{x:1388,y:800,t:1526930278056};\\\", \\\"{x:1389,y:801,t:1526930278071};\\\", \\\"{x:1389,y:802,t:1526930278088};\\\", \\\"{x:1390,y:803,t:1526930278107};\\\", \\\"{x:1390,y:804,t:1526930278121};\\\", \\\"{x:1392,y:805,t:1526930278138};\\\", \\\"{x:1393,y:806,t:1526930278156};\\\", \\\"{x:1394,y:807,t:1526930278258};\\\", \\\"{x:1396,y:810,t:1526930278289};\\\", \\\"{x:1398,y:812,t:1526930278305};\\\", \\\"{x:1404,y:814,t:1526930278320};\\\", \\\"{x:1407,y:816,t:1526930278338};\\\", \\\"{x:1408,y:817,t:1526930278355};\\\", \\\"{x:1409,y:818,t:1526930278370};\\\", \\\"{x:1410,y:818,t:1526930278459};\\\", \\\"{x:1411,y:818,t:1526930278491};\\\", \\\"{x:1411,y:819,t:1526930278547};\\\", \\\"{x:1412,y:819,t:1526930278555};\\\", \\\"{x:1412,y:820,t:1526930278586};\\\", \\\"{x:1413,y:821,t:1526930278611};\\\", \\\"{x:1414,y:822,t:1526930278627};\\\", \\\"{x:1414,y:823,t:1526930278642};\\\", \\\"{x:1417,y:825,t:1526930278656};\\\", \\\"{x:1417,y:826,t:1526930278672};\\\", \\\"{x:1418,y:827,t:1526930278688};\\\", \\\"{x:1418,y:828,t:1526930278723};\\\", \\\"{x:1418,y:829,t:1526930278738};\\\", \\\"{x:1418,y:828,t:1526930278851};\\\", \\\"{x:1418,y:827,t:1526930278858};\\\", \\\"{x:1417,y:824,t:1526930278873};\\\", \\\"{x:1417,y:823,t:1526930278890};\\\", \\\"{x:1416,y:822,t:1526930278905};\\\", \\\"{x:1416,y:821,t:1526930278922};\\\", \\\"{x:1415,y:819,t:1526930278939};\\\", \\\"{x:1415,y:817,t:1526930278955};\\\", \\\"{x:1413,y:815,t:1526930278972};\\\", \\\"{x:1410,y:811,t:1526930278989};\\\", \\\"{x:1408,y:809,t:1526930279006};\\\", \\\"{x:1403,y:806,t:1526930279022};\\\", \\\"{x:1399,y:802,t:1526930279039};\\\", \\\"{x:1397,y:800,t:1526930279055};\\\", \\\"{x:1391,y:794,t:1526930279072};\\\", \\\"{x:1380,y:785,t:1526930279089};\\\", \\\"{x:1371,y:780,t:1526930279106};\\\", \\\"{x:1361,y:775,t:1526930279123};\\\", \\\"{x:1360,y:774,t:1526930279140};\\\", \\\"{x:1359,y:773,t:1526930279219};\\\", \\\"{x:1358,y:773,t:1526930279323};\\\", \\\"{x:1357,y:773,t:1526930279891};\\\", \\\"{x:1358,y:774,t:1526930279906};\\\", \\\"{x:1358,y:775,t:1526930279923};\\\", \\\"{x:1360,y:780,t:1526930279940};\\\", \\\"{x:1364,y:784,t:1526930279956};\\\", \\\"{x:1366,y:788,t:1526930279973};\\\", \\\"{x:1369,y:792,t:1526930279989};\\\", \\\"{x:1371,y:798,t:1526930280006};\\\", \\\"{x:1372,y:800,t:1526930280023};\\\", \\\"{x:1374,y:804,t:1526930280039};\\\", \\\"{x:1375,y:807,t:1526930280056};\\\", \\\"{x:1376,y:808,t:1526930280073};\\\", \\\"{x:1377,y:810,t:1526930280090};\\\", \\\"{x:1380,y:815,t:1526930280107};\\\", \\\"{x:1381,y:818,t:1526930280123};\\\", \\\"{x:1387,y:829,t:1526930280139};\\\", \\\"{x:1390,y:833,t:1526930280156};\\\", \\\"{x:1390,y:834,t:1526930280187};\\\", \\\"{x:1390,y:835,t:1526930280210};\\\", \\\"{x:1390,y:836,t:1526930280223};\\\", \\\"{x:1392,y:837,t:1526930280240};\\\", \\\"{x:1392,y:839,t:1526930280257};\\\", \\\"{x:1392,y:840,t:1526930280274};\\\", \\\"{x:1392,y:842,t:1526930280314};\\\", \\\"{x:1392,y:843,t:1526930281628};\\\", \\\"{x:1390,y:843,t:1526930281651};\\\", \\\"{x:1389,y:844,t:1526930281658};\\\", \\\"{x:1388,y:844,t:1526930281675};\\\", \\\"{x:1385,y:844,t:1526930281690};\\\", \\\"{x:1377,y:844,t:1526930281707};\\\", \\\"{x:1370,y:844,t:1526930281725};\\\", \\\"{x:1360,y:840,t:1526930281741};\\\", \\\"{x:1355,y:835,t:1526930281757};\\\", \\\"{x:1341,y:831,t:1526930281774};\\\", \\\"{x:1330,y:829,t:1526930281791};\\\", \\\"{x:1322,y:827,t:1526930281807};\\\", \\\"{x:1315,y:824,t:1526930281825};\\\", \\\"{x:1310,y:822,t:1526930281841};\\\", \\\"{x:1305,y:819,t:1526930281857};\\\", \\\"{x:1294,y:816,t:1526930281874};\\\", \\\"{x:1292,y:815,t:1526930281891};\\\", \\\"{x:1287,y:815,t:1526930281908};\\\", \\\"{x:1286,y:815,t:1526930281979};\\\", \\\"{x:1285,y:815,t:1526930282019};\\\", \\\"{x:1283,y:815,t:1526930282034};\\\", \\\"{x:1282,y:815,t:1526930282051};\\\", \\\"{x:1280,y:815,t:1526930282059};\\\", \\\"{x:1276,y:815,t:1526930282074};\\\", \\\"{x:1268,y:815,t:1526930282091};\\\", \\\"{x:1256,y:814,t:1526930282108};\\\", \\\"{x:1248,y:814,t:1526930282124};\\\", \\\"{x:1247,y:812,t:1526930282141};\\\", \\\"{x:1246,y:812,t:1526930282158};\\\", \\\"{x:1243,y:812,t:1526930282387};\\\", \\\"{x:1243,y:811,t:1526930282499};\\\", \\\"{x:1243,y:809,t:1526930282508};\\\", \\\"{x:1245,y:804,t:1526930282525};\\\", \\\"{x:1255,y:794,t:1526930282542};\\\", \\\"{x:1264,y:784,t:1526930282558};\\\", \\\"{x:1276,y:771,t:1526930282574};\\\", \\\"{x:1287,y:752,t:1526930282591};\\\", \\\"{x:1297,y:732,t:1526930282608};\\\", \\\"{x:1308,y:713,t:1526930282626};\\\", \\\"{x:1318,y:694,t:1526930282642};\\\", \\\"{x:1338,y:661,t:1526930282659};\\\", \\\"{x:1348,y:645,t:1526930282675};\\\", \\\"{x:1357,y:631,t:1526930282691};\\\", \\\"{x:1365,y:614,t:1526930282708};\\\", \\\"{x:1374,y:594,t:1526930282726};\\\", \\\"{x:1380,y:574,t:1526930282742};\\\", \\\"{x:1385,y:564,t:1526930282759};\\\", \\\"{x:1387,y:547,t:1526930282775};\\\", \\\"{x:1395,y:532,t:1526930282791};\\\", \\\"{x:1396,y:528,t:1526930282808};\\\", \\\"{x:1400,y:522,t:1526930282826};\\\", \\\"{x:1404,y:511,t:1526930282842};\\\", \\\"{x:1411,y:486,t:1526930282859};\\\", \\\"{x:1415,y:471,t:1526930282875};\\\", \\\"{x:1416,y:460,t:1526930282891};\\\", \\\"{x:1419,y:450,t:1526930282908};\\\", \\\"{x:1420,y:442,t:1526930282925};\\\", \\\"{x:1422,y:434,t:1526930282941};\\\", \\\"{x:1424,y:429,t:1526930282958};\\\", \\\"{x:1429,y:422,t:1526930282975};\\\", \\\"{x:1432,y:416,t:1526930282991};\\\", \\\"{x:1436,y:407,t:1526930283009};\\\", \\\"{x:1444,y:395,t:1526930283026};\\\", \\\"{x:1446,y:390,t:1526930283042};\\\", \\\"{x:1450,y:380,t:1526930283059};\\\", \\\"{x:1451,y:377,t:1526930283075};\\\", \\\"{x:1454,y:373,t:1526930283092};\\\", \\\"{x:1457,y:369,t:1526930283108};\\\", \\\"{x:1459,y:366,t:1526930283126};\\\", \\\"{x:1461,y:363,t:1526930283143};\\\", \\\"{x:1464,y:359,t:1526930283159};\\\", \\\"{x:1466,y:356,t:1526930283176};\\\", \\\"{x:1467,y:353,t:1526930283193};\\\", \\\"{x:1470,y:349,t:1526930283209};\\\", \\\"{x:1471,y:348,t:1526930283225};\\\", \\\"{x:1475,y:344,t:1526930283242};\\\", \\\"{x:1476,y:344,t:1526930283259};\\\", \\\"{x:1479,y:340,t:1526930283276};\\\", \\\"{x:1483,y:337,t:1526930283292};\\\", \\\"{x:1486,y:333,t:1526930283308};\\\", \\\"{x:1490,y:326,t:1526930283326};\\\", \\\"{x:1496,y:321,t:1526930283343};\\\", \\\"{x:1500,y:314,t:1526930283358};\\\", \\\"{x:1507,y:304,t:1526930283375};\\\", \\\"{x:1514,y:300,t:1526930283393};\\\", \\\"{x:1520,y:294,t:1526930283409};\\\", \\\"{x:1524,y:288,t:1526930283425};\\\", \\\"{x:1531,y:278,t:1526930283442};\\\", \\\"{x:1534,y:273,t:1526930283459};\\\", \\\"{x:1538,y:266,t:1526930283476};\\\", \\\"{x:1539,y:264,t:1526930283492};\\\", \\\"{x:1539,y:263,t:1526930283509};\\\", \\\"{x:1540,y:262,t:1526930283539};\\\", \\\"{x:1539,y:262,t:1526930287547};\\\", \\\"{x:1538,y:262,t:1526930287970};\\\", \\\"{x:1537,y:262,t:1526930288058};\\\", \\\"{x:1536,y:262,t:1526930288083};\\\", \\\"{x:1535,y:262,t:1526930288171};\\\", \\\"{x:1534,y:262,t:1526930288178};\\\", \\\"{x:1532,y:263,t:1526930288234};\\\", \\\"{x:1531,y:264,t:1526930288306};\\\", \\\"{x:1530,y:264,t:1526930288314};\\\", \\\"{x:1529,y:264,t:1526930288329};\\\", \\\"{x:1525,y:268,t:1526930288345};\\\", \\\"{x:1514,y:275,t:1526930288362};\\\", \\\"{x:1508,y:281,t:1526930288379};\\\", \\\"{x:1496,y:292,t:1526930288395};\\\", \\\"{x:1478,y:306,t:1526930288412};\\\", \\\"{x:1462,y:320,t:1526930288429};\\\", \\\"{x:1446,y:341,t:1526930288445};\\\", \\\"{x:1409,y:394,t:1526930288462};\\\", \\\"{x:1354,y:474,t:1526930288479};\\\", \\\"{x:1303,y:577,t:1526930288495};\\\", \\\"{x:1232,y:675,t:1526930288512};\\\", \\\"{x:1171,y:792,t:1526930288529};\\\", \\\"{x:1151,y:850,t:1526930288545};\\\", \\\"{x:1132,y:891,t:1526930288562};\\\", \\\"{x:1132,y:893,t:1526930288579};\\\", \\\"{x:1132,y:895,t:1526930288595};\\\", \\\"{x:1132,y:901,t:1526930288612};\\\", \\\"{x:1132,y:905,t:1526930288629};\\\", \\\"{x:1132,y:908,t:1526930288645};\\\", \\\"{x:1132,y:909,t:1526930288697};\\\", \\\"{x:1133,y:909,t:1526930288712};\\\", \\\"{x:1140,y:903,t:1526930288729};\\\", \\\"{x:1152,y:881,t:1526930288746};\\\", \\\"{x:1164,y:863,t:1526930288762};\\\", \\\"{x:1173,y:838,t:1526930288779};\\\", \\\"{x:1177,y:819,t:1526930288796};\\\", \\\"{x:1180,y:805,t:1526930288812};\\\", \\\"{x:1182,y:793,t:1526930288829};\\\", \\\"{x:1182,y:785,t:1526930288846};\\\", \\\"{x:1184,y:779,t:1526930288862};\\\", \\\"{x:1184,y:767,t:1526930288879};\\\", \\\"{x:1185,y:765,t:1526930288896};\\\", \\\"{x:1185,y:763,t:1526930288913};\\\", \\\"{x:1185,y:762,t:1526930288978};\\\", \\\"{x:1182,y:767,t:1526930288997};\\\", \\\"{x:1175,y:779,t:1526930289014};\\\", \\\"{x:1172,y:785,t:1526930289029};\\\", \\\"{x:1172,y:786,t:1526930289047};\\\", \\\"{x:1172,y:785,t:1526930289162};\\\", \\\"{x:1176,y:779,t:1526930289179};\\\", \\\"{x:1178,y:777,t:1526930289197};\\\", \\\"{x:1180,y:774,t:1526930289213};\\\", \\\"{x:1181,y:773,t:1526930289230};\\\", \\\"{x:1181,y:772,t:1526930289247};\\\", \\\"{x:1182,y:771,t:1526930289263};\\\", \\\"{x:1184,y:768,t:1526930289291};\\\", \\\"{x:1185,y:768,t:1526930289332};\\\", \\\"{x:1187,y:768,t:1526930289346};\\\", \\\"{x:1188,y:768,t:1526930290891};\\\", \\\"{x:1191,y:771,t:1526930290907};\\\", \\\"{x:1194,y:773,t:1526930290915};\\\", \\\"{x:1206,y:784,t:1526930290931};\\\", \\\"{x:1218,y:791,t:1526930290948};\\\", \\\"{x:1237,y:796,t:1526930290965};\\\", \\\"{x:1252,y:800,t:1526930290981};\\\", \\\"{x:1264,y:803,t:1526930290997};\\\", \\\"{x:1283,y:803,t:1526930291015};\\\", \\\"{x:1292,y:803,t:1526930291030};\\\", \\\"{x:1306,y:802,t:1526930291048};\\\", \\\"{x:1318,y:800,t:1526930291065};\\\", \\\"{x:1326,y:797,t:1526930291081};\\\", \\\"{x:1328,y:796,t:1526930291097};\\\", \\\"{x:1328,y:794,t:1526930291114};\\\", \\\"{x:1328,y:791,t:1526930291132};\\\", \\\"{x:1328,y:789,t:1526930291148};\\\", \\\"{x:1328,y:783,t:1526930291164};\\\", \\\"{x:1328,y:779,t:1526930291182};\\\", \\\"{x:1328,y:775,t:1526930291198};\\\", \\\"{x:1328,y:774,t:1526930291219};\\\", \\\"{x:1328,y:773,t:1526930291243};\\\", \\\"{x:1328,y:772,t:1526930291339};\\\", \\\"{x:1328,y:770,t:1526930291370};\\\", \\\"{x:1329,y:769,t:1526930291387};\\\", \\\"{x:1330,y:769,t:1526930291410};\\\", \\\"{x:1331,y:768,t:1526930291418};\\\", \\\"{x:1332,y:768,t:1526930291547};\\\", \\\"{x:1334,y:768,t:1526930291579};\\\", \\\"{x:1336,y:767,t:1526930291595};\\\", \\\"{x:1338,y:766,t:1526930291602};\\\", \\\"{x:1342,y:766,t:1526930291619};\\\", \\\"{x:1343,y:766,t:1526930291651};\\\", \\\"{x:1345,y:766,t:1526930291665};\\\", \\\"{x:1346,y:766,t:1526930291683};\\\", \\\"{x:1347,y:767,t:1526930291706};\\\", \\\"{x:1348,y:769,t:1526930291723};\\\", \\\"{x:1350,y:772,t:1526930291732};\\\", \\\"{x:1350,y:774,t:1526930291749};\\\", \\\"{x:1350,y:780,t:1526930291764};\\\", \\\"{x:1346,y:792,t:1526930291782};\\\", \\\"{x:1342,y:799,t:1526930291800};\\\", \\\"{x:1334,y:808,t:1526930291815};\\\", \\\"{x:1330,y:814,t:1526930291832};\\\", \\\"{x:1325,y:822,t:1526930291849};\\\", \\\"{x:1322,y:828,t:1526930291865};\\\", \\\"{x:1316,y:837,t:1526930291882};\\\", \\\"{x:1306,y:857,t:1526930291899};\\\", \\\"{x:1305,y:859,t:1526930291922};\\\", \\\"{x:1302,y:862,t:1526930291932};\\\", \\\"{x:1301,y:868,t:1526930291948};\\\", \\\"{x:1299,y:872,t:1526930291965};\\\", \\\"{x:1296,y:875,t:1526930291982};\\\", \\\"{x:1291,y:884,t:1526930292000};\\\", \\\"{x:1285,y:894,t:1526930292015};\\\", \\\"{x:1281,y:902,t:1526930292032};\\\", \\\"{x:1279,y:907,t:1526930292049};\\\", \\\"{x:1275,y:915,t:1526930292065};\\\", \\\"{x:1272,y:921,t:1526930292082};\\\", \\\"{x:1267,y:927,t:1526930292099};\\\", \\\"{x:1263,y:929,t:1526930292115};\\\", \\\"{x:1261,y:932,t:1526930292131};\\\", \\\"{x:1260,y:935,t:1526930292148};\\\", \\\"{x:1257,y:939,t:1526930292165};\\\", \\\"{x:1255,y:944,t:1526930292181};\\\", \\\"{x:1252,y:948,t:1526930292198};\\\", \\\"{x:1248,y:953,t:1526930292215};\\\", \\\"{x:1244,y:958,t:1526930292232};\\\", \\\"{x:1241,y:961,t:1526930292248};\\\", \\\"{x:1239,y:965,t:1526930292265};\\\", \\\"{x:1237,y:968,t:1526930292281};\\\", \\\"{x:1236,y:970,t:1526930292298};\\\", \\\"{x:1235,y:972,t:1526930292315};\\\", \\\"{x:1235,y:973,t:1526930292331};\\\", \\\"{x:1234,y:975,t:1526930292348};\\\", \\\"{x:1233,y:976,t:1526930292365};\\\", \\\"{x:1233,y:977,t:1526930292381};\\\", \\\"{x:1233,y:978,t:1526930292402};\\\", \\\"{x:1235,y:978,t:1526930292555};\\\", \\\"{x:1238,y:977,t:1526930292567};\\\", \\\"{x:1243,y:974,t:1526930292583};\\\", \\\"{x:1248,y:972,t:1526930292600};\\\", \\\"{x:1252,y:966,t:1526930292616};\\\", \\\"{x:1256,y:962,t:1526930292632};\\\", \\\"{x:1257,y:960,t:1526930292648};\\\", \\\"{x:1257,y:958,t:1526930292665};\\\", \\\"{x:1259,y:958,t:1526930292689};\\\", \\\"{x:1259,y:957,t:1526930292698};\\\", \\\"{x:1259,y:955,t:1526930292715};\\\", \\\"{x:1260,y:952,t:1526930292732};\\\", \\\"{x:1262,y:948,t:1526930292748};\\\", \\\"{x:1263,y:947,t:1526930292766};\\\", \\\"{x:1263,y:946,t:1526930292782};\\\", \\\"{x:1263,y:945,t:1526930292914};\\\", \\\"{x:1262,y:930,t:1526930292933};\\\", \\\"{x:1255,y:907,t:1526930292950};\\\", \\\"{x:1235,y:848,t:1526930292965};\\\", \\\"{x:1205,y:759,t:1526930292983};\\\", \\\"{x:1167,y:660,t:1526930293000};\\\", \\\"{x:1151,y:632,t:1526930293016};\\\", \\\"{x:1143,y:620,t:1526930293033};\\\", \\\"{x:1139,y:617,t:1526930293050};\\\", \\\"{x:1137,y:615,t:1526930293066};\\\", \\\"{x:1136,y:615,t:1526930293090};\\\", \\\"{x:1133,y:615,t:1526930293106};\\\", \\\"{x:1131,y:616,t:1526930293122};\\\", \\\"{x:1129,y:617,t:1526930293132};\\\", \\\"{x:1129,y:619,t:1526930293149};\\\", \\\"{x:1128,y:622,t:1526930293165};\\\", \\\"{x:1127,y:624,t:1526930293182};\\\", \\\"{x:1127,y:630,t:1526930293199};\\\", \\\"{x:1131,y:644,t:1526930293216};\\\", \\\"{x:1154,y:673,t:1526930293232};\\\", \\\"{x:1215,y:725,t:1526930293250};\\\", \\\"{x:1243,y:742,t:1526930293266};\\\", \\\"{x:1282,y:768,t:1526930293282};\\\", \\\"{x:1294,y:790,t:1526930293300};\\\", \\\"{x:1299,y:802,t:1526930293315};\\\", \\\"{x:1299,y:807,t:1526930293332};\\\", \\\"{x:1299,y:808,t:1526930293350};\\\", \\\"{x:1298,y:808,t:1526930293411};\\\", \\\"{x:1298,y:805,t:1526930293418};\\\", \\\"{x:1298,y:801,t:1526930293433};\\\", \\\"{x:1297,y:786,t:1526930293450};\\\", \\\"{x:1296,y:772,t:1526930293467};\\\", \\\"{x:1294,y:750,t:1526930293483};\\\", \\\"{x:1291,y:729,t:1526930293500};\\\", \\\"{x:1284,y:695,t:1526930293517};\\\", \\\"{x:1265,y:641,t:1526930293533};\\\", \\\"{x:1245,y:594,t:1526930293550};\\\", \\\"{x:1234,y:563,t:1526930293567};\\\", \\\"{x:1227,y:541,t:1526930293583};\\\", \\\"{x:1219,y:522,t:1526930293600};\\\", \\\"{x:1218,y:508,t:1526930293617};\\\", \\\"{x:1218,y:501,t:1526930293633};\\\", \\\"{x:1219,y:495,t:1526930293650};\\\", \\\"{x:1221,y:493,t:1526930293667};\\\", \\\"{x:1223,y:493,t:1526930293763};\\\", \\\"{x:1227,y:494,t:1526930293771};\\\", \\\"{x:1232,y:498,t:1526930293782};\\\", \\\"{x:1240,y:507,t:1526930293800};\\\", \\\"{x:1246,y:514,t:1526930293816};\\\", \\\"{x:1262,y:528,t:1526930293833};\\\", \\\"{x:1278,y:545,t:1526930293851};\\\", \\\"{x:1286,y:554,t:1526930293866};\\\", \\\"{x:1294,y:563,t:1526930293883};\\\", \\\"{x:1294,y:564,t:1526930293900};\\\", \\\"{x:1295,y:564,t:1526930294010};\\\", \\\"{x:1295,y:563,t:1526930294026};\\\", \\\"{x:1294,y:560,t:1526930294042};\\\", \\\"{x:1292,y:559,t:1526930294114};\\\", \\\"{x:1290,y:559,t:1526930294154};\\\", \\\"{x:1287,y:560,t:1526930294167};\\\", \\\"{x:1284,y:561,t:1526930294184};\\\", \\\"{x:1281,y:562,t:1526930294200};\\\", \\\"{x:1280,y:562,t:1526930294218};\\\", \\\"{x:1279,y:562,t:1526930294234};\\\", \\\"{x:1278,y:562,t:1526930294267};\\\", \\\"{x:1277,y:562,t:1526930294290};\\\", \\\"{x:1276,y:562,t:1526930294300};\\\", \\\"{x:1276,y:564,t:1526930294426};\\\", \\\"{x:1276,y:567,t:1526930294435};\\\", \\\"{x:1279,y:571,t:1526930294450};\\\", \\\"{x:1283,y:582,t:1526930294466};\\\", \\\"{x:1290,y:591,t:1526930294484};\\\", \\\"{x:1296,y:602,t:1526930294501};\\\", \\\"{x:1304,y:616,t:1526930294517};\\\", \\\"{x:1316,y:628,t:1526930294533};\\\", \\\"{x:1325,y:638,t:1526930294551};\\\", \\\"{x:1331,y:646,t:1526930294567};\\\", \\\"{x:1337,y:655,t:1526930294584};\\\", \\\"{x:1343,y:663,t:1526930294602};\\\", \\\"{x:1346,y:672,t:1526930294617};\\\", \\\"{x:1349,y:681,t:1526930294634};\\\", \\\"{x:1349,y:685,t:1526930294651};\\\", \\\"{x:1351,y:689,t:1526930294668};\\\", \\\"{x:1351,y:695,t:1526930294684};\\\", \\\"{x:1352,y:699,t:1526930294701};\\\", \\\"{x:1354,y:706,t:1526930294718};\\\", \\\"{x:1356,y:708,t:1526930294734};\\\", \\\"{x:1356,y:709,t:1526930294754};\\\", \\\"{x:1357,y:711,t:1526930294767};\\\", \\\"{x:1359,y:716,t:1526930294784};\\\", \\\"{x:1361,y:721,t:1526930294801};\\\", \\\"{x:1363,y:724,t:1526930294817};\\\", \\\"{x:1364,y:726,t:1526930294834};\\\", \\\"{x:1364,y:728,t:1526930294858};\\\", \\\"{x:1366,y:729,t:1526930294868};\\\", \\\"{x:1367,y:730,t:1526930294884};\\\", \\\"{x:1367,y:733,t:1526930294901};\\\", \\\"{x:1368,y:735,t:1526930294918};\\\", \\\"{x:1369,y:736,t:1526930294933};\\\", \\\"{x:1370,y:738,t:1526930294950};\\\", \\\"{x:1370,y:740,t:1526930294968};\\\", \\\"{x:1372,y:742,t:1526930294985};\\\", \\\"{x:1374,y:748,t:1526930295001};\\\", \\\"{x:1375,y:757,t:1526930295017};\\\", \\\"{x:1378,y:761,t:1526930295034};\\\", \\\"{x:1380,y:764,t:1526930295050};\\\", \\\"{x:1380,y:766,t:1526930295067};\\\", \\\"{x:1384,y:771,t:1526930295083};\\\", \\\"{x:1385,y:772,t:1526930295100};\\\", \\\"{x:1385,y:773,t:1526930295118};\\\", \\\"{x:1387,y:774,t:1526930295133};\\\", \\\"{x:1389,y:777,t:1526930295151};\\\", \\\"{x:1391,y:780,t:1526930295167};\\\", \\\"{x:1391,y:781,t:1526930295184};\\\", \\\"{x:1392,y:782,t:1526930295200};\\\", \\\"{x:1394,y:787,t:1526930295218};\\\", \\\"{x:1395,y:790,t:1526930295234};\\\", \\\"{x:1397,y:790,t:1526930295251};\\\", \\\"{x:1398,y:792,t:1526930295268};\\\", \\\"{x:1400,y:794,t:1526930295284};\\\", \\\"{x:1401,y:796,t:1526930295301};\\\", \\\"{x:1403,y:800,t:1526930295317};\\\", \\\"{x:1405,y:802,t:1526930295334};\\\", \\\"{x:1407,y:806,t:1526930295351};\\\", \\\"{x:1408,y:808,t:1526930295368};\\\", \\\"{x:1408,y:811,t:1526930295385};\\\", \\\"{x:1409,y:812,t:1526930295401};\\\", \\\"{x:1409,y:818,t:1526930295418};\\\", \\\"{x:1409,y:819,t:1526930295435};\\\", \\\"{x:1410,y:821,t:1526930295451};\\\", \\\"{x:1410,y:823,t:1526930295469};\\\", \\\"{x:1410,y:825,t:1526930295484};\\\", \\\"{x:1410,y:829,t:1526930295501};\\\", \\\"{x:1412,y:833,t:1526930295518};\\\", \\\"{x:1415,y:836,t:1526930295535};\\\", \\\"{x:1415,y:837,t:1526930295551};\\\", \\\"{x:1417,y:839,t:1526930295568};\\\", \\\"{x:1418,y:840,t:1526930295585};\\\", \\\"{x:1418,y:841,t:1526930295601};\\\", \\\"{x:1419,y:842,t:1526930295619};\\\", \\\"{x:1421,y:847,t:1526930295642};\\\", \\\"{x:1422,y:849,t:1526930295659};\\\", \\\"{x:1423,y:850,t:1526930295668};\\\", \\\"{x:1424,y:851,t:1526930295685};\\\", \\\"{x:1425,y:853,t:1526930295701};\\\", \\\"{x:1426,y:854,t:1526930295723};\\\", \\\"{x:1427,y:855,t:1526930295734};\\\", \\\"{x:1428,y:856,t:1526930295751};\\\", \\\"{x:1428,y:857,t:1526930295818};\\\", \\\"{x:1430,y:857,t:1526930295923};\\\", \\\"{x:1432,y:861,t:1526930295935};\\\", \\\"{x:1445,y:872,t:1526930295952};\\\", \\\"{x:1461,y:884,t:1526930295968};\\\", \\\"{x:1474,y:895,t:1526930295985};\\\", \\\"{x:1479,y:898,t:1526930296002};\\\", \\\"{x:1479,y:899,t:1526930296123};\\\", \\\"{x:1477,y:900,t:1526930296234};\\\", \\\"{x:1474,y:900,t:1526930296252};\\\", \\\"{x:1457,y:891,t:1526930296268};\\\", \\\"{x:1440,y:877,t:1526930296285};\\\", \\\"{x:1425,y:860,t:1526930296302};\\\", \\\"{x:1397,y:841,t:1526930296319};\\\", \\\"{x:1365,y:824,t:1526930296335};\\\", \\\"{x:1351,y:816,t:1526930296352};\\\", \\\"{x:1338,y:806,t:1526930296368};\\\", \\\"{x:1333,y:803,t:1526930296385};\\\", \\\"{x:1332,y:802,t:1526930296402};\\\", \\\"{x:1331,y:802,t:1526930296426};\\\", \\\"{x:1330,y:802,t:1526930296435};\\\", \\\"{x:1330,y:801,t:1526930296459};\\\", \\\"{x:1329,y:801,t:1526930296468};\\\", \\\"{x:1325,y:801,t:1526930296484};\\\", \\\"{x:1314,y:800,t:1526930296502};\\\", \\\"{x:1303,y:796,t:1526930296519};\\\", \\\"{x:1282,y:789,t:1526930296535};\\\", \\\"{x:1254,y:781,t:1526930296552};\\\", \\\"{x:1224,y:774,t:1526930296569};\\\", \\\"{x:1207,y:769,t:1526930296585};\\\", \\\"{x:1173,y:761,t:1526930296602};\\\", \\\"{x:1147,y:759,t:1526930296618};\\\", \\\"{x:1136,y:759,t:1526930296634};\\\", \\\"{x:1125,y:755,t:1526930296651};\\\", \\\"{x:1122,y:753,t:1526930296668};\\\", \\\"{x:1104,y:751,t:1526930296685};\\\", \\\"{x:1094,y:750,t:1526930296701};\\\", \\\"{x:1066,y:748,t:1526930296718};\\\", \\\"{x:1004,y:744,t:1526930296735};\\\", \\\"{x:957,y:734,t:1526930296751};\\\", \\\"{x:928,y:724,t:1526930296768};\\\", \\\"{x:895,y:703,t:1526930296786};\\\", \\\"{x:880,y:692,t:1526930296802};\\\", \\\"{x:871,y:682,t:1526930296818};\\\", \\\"{x:868,y:676,t:1526930296835};\\\", \\\"{x:867,y:671,t:1526930296852};\\\", \\\"{x:865,y:664,t:1526930296868};\\\", \\\"{x:862,y:658,t:1526930296886};\\\", \\\"{x:852,y:652,t:1526930296902};\\\", \\\"{x:831,y:644,t:1526930296919};\\\", \\\"{x:810,y:636,t:1526930296936};\\\", \\\"{x:786,y:628,t:1526930296954};\\\", \\\"{x:768,y:620,t:1526930296969};\\\", \\\"{x:721,y:609,t:1526930296986};\\\", \\\"{x:704,y:604,t:1526930297006};\\\", \\\"{x:699,y:599,t:1526930297023};\\\", \\\"{x:693,y:595,t:1526930297040};\\\", \\\"{x:689,y:592,t:1526930297056};\\\", \\\"{x:686,y:591,t:1526930297073};\\\", \\\"{x:684,y:587,t:1526930297090};\\\", \\\"{x:676,y:586,t:1526930297105};\\\", \\\"{x:661,y:586,t:1526930297122};\\\", \\\"{x:642,y:586,t:1526930297140};\\\", \\\"{x:625,y:586,t:1526930297155};\\\", \\\"{x:609,y:588,t:1526930297172};\\\", \\\"{x:567,y:588,t:1526930297189};\\\", \\\"{x:552,y:587,t:1526930297205};\\\", \\\"{x:531,y:588,t:1526930297222};\\\", \\\"{x:513,y:589,t:1526930297240};\\\", \\\"{x:504,y:589,t:1526930297256};\\\", \\\"{x:502,y:589,t:1526930297272};\\\", \\\"{x:500,y:588,t:1526930297346};\\\", \\\"{x:500,y:587,t:1526930297356};\\\", \\\"{x:499,y:587,t:1526930297372};\\\", \\\"{x:490,y:583,t:1526930297392};\\\", \\\"{x:477,y:579,t:1526930297407};\\\", \\\"{x:459,y:575,t:1526930297422};\\\", \\\"{x:442,y:575,t:1526930297439};\\\", \\\"{x:419,y:575,t:1526930297456};\\\", \\\"{x:392,y:575,t:1526930297473};\\\", \\\"{x:379,y:576,t:1526930297489};\\\", \\\"{x:377,y:576,t:1526930297506};\\\", \\\"{x:373,y:577,t:1526930297523};\\\", \\\"{x:369,y:579,t:1526930297539};\\\", \\\"{x:359,y:585,t:1526930297556};\\\", \\\"{x:352,y:589,t:1526930297572};\\\", \\\"{x:349,y:591,t:1526930297589};\\\", \\\"{x:328,y:593,t:1526930297606};\\\", \\\"{x:309,y:593,t:1526930297622};\\\", \\\"{x:289,y:594,t:1526930297639};\\\", \\\"{x:272,y:594,t:1526930297656};\\\", \\\"{x:252,y:594,t:1526930297673};\\\", \\\"{x:227,y:593,t:1526930297690};\\\", \\\"{x:215,y:593,t:1526930297707};\\\", \\\"{x:202,y:593,t:1526930297722};\\\", \\\"{x:194,y:593,t:1526930297739};\\\", \\\"{x:192,y:593,t:1526930297756};\\\", \\\"{x:175,y:598,t:1526930297774};\\\", \\\"{x:157,y:607,t:1526930297790};\\\", \\\"{x:153,y:609,t:1526930297806};\\\", \\\"{x:152,y:609,t:1526930297822};\\\", \\\"{x:152,y:604,t:1526930297913};\\\", \\\"{x:152,y:593,t:1526930297924};\\\", \\\"{x:158,y:554,t:1526930297940};\\\", \\\"{x:164,y:522,t:1526930297957};\\\", \\\"{x:165,y:503,t:1526930297973};\\\", \\\"{x:165,y:497,t:1526930297989};\\\", \\\"{x:165,y:495,t:1526930298007};\\\", \\\"{x:165,y:494,t:1526930298023};\\\", \\\"{x:165,y:493,t:1526930298147};\\\", \\\"{x:164,y:493,t:1526930298156};\\\", \\\"{x:162,y:495,t:1526930298173};\\\", \\\"{x:161,y:497,t:1526930298189};\\\", \\\"{x:165,y:501,t:1526930298418};\\\", \\\"{x:175,y:508,t:1526930298425};\\\", \\\"{x:184,y:520,t:1526930298441};\\\", \\\"{x:256,y:551,t:1526930298457};\\\", \\\"{x:414,y:632,t:1526930298474};\\\", \\\"{x:503,y:679,t:1526930298490};\\\", \\\"{x:589,y:718,t:1526930298506};\\\", \\\"{x:611,y:735,t:1526930298523};\\\", \\\"{x:626,y:744,t:1526930298540};\\\", \\\"{x:626,y:745,t:1526930298557};\\\", \\\"{x:626,y:746,t:1526930298618};\\\", \\\"{x:626,y:748,t:1526930298626};\\\", \\\"{x:627,y:751,t:1526930298641};\\\", \\\"{x:627,y:758,t:1526930298657};\\\", \\\"{x:627,y:769,t:1526930298674};\\\", \\\"{x:624,y:776,t:1526930298690};\\\", \\\"{x:623,y:778,t:1526930298707};\\\", \\\"{x:622,y:780,t:1526930298723};\\\", \\\"{x:615,y:784,t:1526930298741};\\\", \\\"{x:611,y:785,t:1526930298756};\\\", \\\"{x:606,y:785,t:1526930298774};\\\", \\\"{x:599,y:785,t:1526930298790};\\\", \\\"{x:596,y:785,t:1526930298806};\\\", \\\"{x:587,y:785,t:1526930298823};\\\", \\\"{x:573,y:784,t:1526930298840};\\\", \\\"{x:557,y:779,t:1526930298857};\\\", \\\"{x:554,y:776,t:1526930298873};\\\", \\\"{x:554,y:775,t:1526930298906};\\\", \\\"{x:555,y:773,t:1526930298962};\\\", \\\"{x:555,y:771,t:1526930298974};\\\", \\\"{x:555,y:766,t:1526930298991};\\\", \\\"{x:555,y:763,t:1526930299007};\\\", \\\"{x:555,y:761,t:1526930299023};\\\", \\\"{x:555,y:759,t:1526930299040};\\\", \\\"{x:555,y:757,t:1526930299057};\\\", \\\"{x:555,y:751,t:1526930299073};\\\", \\\"{x:555,y:749,t:1526930299090};\\\", \\\"{x:555,y:750,t:1526930299241};\\\", \\\"{x:556,y:751,t:1526930299258};\\\", \\\"{x:557,y:752,t:1526930299274};\\\", \\\"{x:557,y:753,t:1526930299346};\\\", \\\"{x:558,y:753,t:1526930299426};\\\", \\\"{x:558,y:752,t:1526930299483};\\\", \\\"{x:558,y:751,t:1526930299507};\\\", \\\"{x:558,y:748,t:1526930299524};\\\", \\\"{x:558,y:745,t:1526930299542};\\\", \\\"{x:558,y:739,t:1526930299557};\\\", \\\"{x:555,y:731,t:1526930299575};\\\", \\\"{x:550,y:724,t:1526930299591};\\\", \\\"{x:548,y:721,t:1526930299607};\\\", \\\"{x:548,y:719,t:1526930299625};\\\", \\\"{x:547,y:719,t:1526930299641};\\\", \\\"{x:546,y:719,t:1526930300170};\\\", \\\"{x:546,y:720,t:1526930300179};\\\", \\\"{x:544,y:722,t:1526930300191};\\\", \\\"{x:544,y:723,t:1526930300209};\\\", \\\"{x:544,y:724,t:1526930300225};\\\", \\\"{x:544,y:726,t:1526930300338};\\\", \\\"{x:544,y:727,t:1526930300345};\\\", \\\"{x:544,y:728,t:1526930300358};\\\", \\\"{x:544,y:729,t:1526930300375};\\\" ] }, { \\\"rt\\\": 22499, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 648040, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F -F -02 PM-02 PM-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:730,t:1526930305867};\\\", \\\"{x:541,y:730,t:1526930305873};\\\", \\\"{x:537,y:730,t:1526930305885};\\\", \\\"{x:528,y:729,t:1526930305902};\\\", \\\"{x:514,y:725,t:1526930305918};\\\", \\\"{x:512,y:723,t:1526930305935};\\\", \\\"{x:512,y:722,t:1526930306138};\\\", \\\"{x:512,y:721,t:1526930306152};\\\", \\\"{x:512,y:719,t:1526930306170};\\\", \\\"{x:516,y:717,t:1526930306185};\\\", \\\"{x:527,y:712,t:1526930306203};\\\", \\\"{x:553,y:712,t:1526930306218};\\\", \\\"{x:580,y:712,t:1526930306229};\\\", \\\"{x:669,y:712,t:1526930306244};\\\", \\\"{x:790,y:726,t:1526930306261};\\\", \\\"{x:905,y:736,t:1526930306279};\\\", \\\"{x:1052,y:756,t:1526930306295};\\\", \\\"{x:1154,y:767,t:1526930306311};\\\", \\\"{x:1239,y:775,t:1526930306329};\\\", \\\"{x:1283,y:776,t:1526930306345};\\\", \\\"{x:1309,y:771,t:1526930306361};\\\", \\\"{x:1326,y:769,t:1526930306379};\\\", \\\"{x:1333,y:766,t:1526930306394};\\\", \\\"{x:1334,y:765,t:1526930306412};\\\", \\\"{x:1335,y:765,t:1526930306434};\\\", \\\"{x:1336,y:763,t:1526930306449};\\\", \\\"{x:1337,y:763,t:1526930306462};\\\", \\\"{x:1340,y:761,t:1526930306479};\\\", \\\"{x:1343,y:759,t:1526930306494};\\\", \\\"{x:1349,y:758,t:1526930306513};\\\", \\\"{x:1353,y:755,t:1526930306530};\\\", \\\"{x:1354,y:755,t:1526930306570};\\\", \\\"{x:1354,y:754,t:1526930306579};\\\", \\\"{x:1357,y:750,t:1526930306595};\\\", \\\"{x:1364,y:742,t:1526930306612};\\\", \\\"{x:1371,y:733,t:1526930306629};\\\", \\\"{x:1376,y:728,t:1526930306645};\\\", \\\"{x:1377,y:725,t:1526930306662};\\\", \\\"{x:1378,y:725,t:1526930306679};\\\", \\\"{x:1378,y:724,t:1526930306695};\\\", \\\"{x:1378,y:722,t:1526930306722};\\\", \\\"{x:1378,y:720,t:1526930306730};\\\", \\\"{x:1378,y:718,t:1526930306754};\\\", \\\"{x:1377,y:716,t:1526930306762};\\\", \\\"{x:1375,y:715,t:1526930306780};\\\", \\\"{x:1373,y:714,t:1526930306795};\\\", \\\"{x:1369,y:713,t:1526930306812};\\\", \\\"{x:1362,y:713,t:1526930306829};\\\", \\\"{x:1357,y:712,t:1526930306846};\\\", \\\"{x:1354,y:711,t:1526930306862};\\\", \\\"{x:1352,y:711,t:1526930306879};\\\", \\\"{x:1346,y:708,t:1526930306896};\\\", \\\"{x:1343,y:707,t:1526930306912};\\\", \\\"{x:1342,y:707,t:1526930306929};\\\", \\\"{x:1341,y:706,t:1526930306946};\\\", \\\"{x:1341,y:705,t:1526930306962};\\\", \\\"{x:1341,y:703,t:1526930307273};\\\", \\\"{x:1341,y:702,t:1526930307313};\\\", \\\"{x:1340,y:702,t:1526930307618};\\\", \\\"{x:1339,y:702,t:1526930307658};\\\", \\\"{x:1338,y:703,t:1526930307994};\\\", \\\"{x:1337,y:704,t:1526930310075};\\\", \\\"{x:1338,y:704,t:1526930310890};\\\", \\\"{x:1339,y:704,t:1526930310898};\\\", \\\"{x:1342,y:704,t:1526930310913};\\\", \\\"{x:1343,y:702,t:1526930310932};\\\", \\\"{x:1344,y:701,t:1526930310948};\\\", \\\"{x:1345,y:698,t:1526930310965};\\\", \\\"{x:1346,y:698,t:1526930310981};\\\", \\\"{x:1346,y:695,t:1526930311004};\\\", \\\"{x:1349,y:693,t:1526930311037};\\\", \\\"{x:1349,y:692,t:1526930311049};\\\", \\\"{x:1349,y:691,t:1526930311065};\\\", \\\"{x:1352,y:693,t:1526930311114};\\\", \\\"{x:1357,y:714,t:1526930311131};\\\", \\\"{x:1360,y:739,t:1526930311147};\\\", \\\"{x:1373,y:780,t:1526930311164};\\\", \\\"{x:1394,y:829,t:1526930311181};\\\", \\\"{x:1424,y:874,t:1526930311197};\\\", \\\"{x:1487,y:937,t:1526930311214};\\\", \\\"{x:1552,y:985,t:1526930311231};\\\", \\\"{x:1600,y:1018,t:1526930311247};\\\", \\\"{x:1620,y:1028,t:1526930311264};\\\", \\\"{x:1624,y:1029,t:1526930311281};\\\", \\\"{x:1623,y:1029,t:1526930311411};\\\", \\\"{x:1621,y:1027,t:1526930311418};\\\", \\\"{x:1616,y:1023,t:1526930311434};\\\", \\\"{x:1612,y:1022,t:1526930311448};\\\", \\\"{x:1595,y:1012,t:1526930311465};\\\", \\\"{x:1560,y:1001,t:1526930311482};\\\", \\\"{x:1548,y:996,t:1526930311497};\\\", \\\"{x:1531,y:986,t:1526930311514};\\\", \\\"{x:1520,y:980,t:1526930311531};\\\", \\\"{x:1513,y:979,t:1526930311547};\\\", \\\"{x:1512,y:979,t:1526930311564};\\\", \\\"{x:1512,y:978,t:1526930312082};\\\", \\\"{x:1512,y:977,t:1526930312097};\\\", \\\"{x:1512,y:975,t:1526930312122};\\\", \\\"{x:1512,y:974,t:1526930312132};\\\", \\\"{x:1512,y:972,t:1526930312149};\\\", \\\"{x:1510,y:970,t:1526930312170};\\\", \\\"{x:1510,y:968,t:1526930312181};\\\", \\\"{x:1509,y:968,t:1526930312224};\\\", \\\"{x:1508,y:966,t:1526930312241};\\\", \\\"{x:1507,y:965,t:1526930312257};\\\", \\\"{x:1505,y:963,t:1526930312265};\\\", \\\"{x:1504,y:963,t:1526930312297};\\\", \\\"{x:1502,y:963,t:1526930312361};\\\", \\\"{x:1502,y:962,t:1526930312369};\\\", \\\"{x:1501,y:962,t:1526930312381};\\\", \\\"{x:1499,y:960,t:1526930312397};\\\", \\\"{x:1498,y:960,t:1526930312414};\\\", \\\"{x:1497,y:960,t:1526930312431};\\\", \\\"{x:1496,y:960,t:1526930312458};\\\", \\\"{x:1495,y:960,t:1526930312474};\\\", \\\"{x:1494,y:960,t:1526930312490};\\\", \\\"{x:1492,y:960,t:1526930312498};\\\", \\\"{x:1488,y:960,t:1526930312515};\\\", \\\"{x:1485,y:960,t:1526930312531};\\\", \\\"{x:1482,y:960,t:1526930312549};\\\", \\\"{x:1481,y:960,t:1526930312755};\\\", \\\"{x:1480,y:960,t:1526930312778};\\\", \\\"{x:1479,y:960,t:1526930312786};\\\", \\\"{x:1478,y:960,t:1526930312930};\\\", \\\"{x:1477,y:960,t:1526930312937};\\\", \\\"{x:1476,y:960,t:1526930313010};\\\", \\\"{x:1473,y:960,t:1526930313042};\\\", \\\"{x:1473,y:959,t:1526930313163};\\\", \\\"{x:1473,y:958,t:1526930313170};\\\", \\\"{x:1473,y:957,t:1526930313182};\\\", \\\"{x:1473,y:954,t:1526930313199};\\\", \\\"{x:1475,y:951,t:1526930313216};\\\", \\\"{x:1479,y:947,t:1526930313232};\\\", \\\"{x:1483,y:943,t:1526930313248};\\\", \\\"{x:1488,y:938,t:1526930313266};\\\", \\\"{x:1491,y:934,t:1526930313282};\\\", \\\"{x:1495,y:928,t:1526930313299};\\\", \\\"{x:1499,y:925,t:1526930313315};\\\", \\\"{x:1504,y:924,t:1526930313331};\\\", \\\"{x:1506,y:922,t:1526930313349};\\\", \\\"{x:1507,y:920,t:1526930313365};\\\", \\\"{x:1508,y:917,t:1526930313383};\\\", \\\"{x:1508,y:916,t:1526930313398};\\\", \\\"{x:1511,y:912,t:1526930313415};\\\", \\\"{x:1514,y:906,t:1526930313433};\\\", \\\"{x:1519,y:903,t:1526930313448};\\\", \\\"{x:1523,y:895,t:1526930313466};\\\", \\\"{x:1524,y:891,t:1526930313482};\\\", \\\"{x:1526,y:887,t:1526930313498};\\\", \\\"{x:1529,y:879,t:1526930313516};\\\", \\\"{x:1534,y:871,t:1526930313533};\\\", \\\"{x:1535,y:865,t:1526930313549};\\\", \\\"{x:1536,y:853,t:1526930313565};\\\", \\\"{x:1536,y:840,t:1526930313583};\\\", \\\"{x:1536,y:831,t:1526930313599};\\\", \\\"{x:1540,y:821,t:1526930313616};\\\", \\\"{x:1543,y:814,t:1526930313632};\\\", \\\"{x:1544,y:809,t:1526930313648};\\\", \\\"{x:1549,y:799,t:1526930313666};\\\", \\\"{x:1553,y:790,t:1526930313682};\\\", \\\"{x:1558,y:780,t:1526930313698};\\\", \\\"{x:1563,y:772,t:1526930313716};\\\", \\\"{x:1566,y:767,t:1526930313732};\\\", \\\"{x:1569,y:762,t:1526930313748};\\\", \\\"{x:1572,y:759,t:1526930313765};\\\", \\\"{x:1576,y:756,t:1526930313783};\\\", \\\"{x:1581,y:749,t:1526930313798};\\\", \\\"{x:1584,y:745,t:1526930313816};\\\", \\\"{x:1587,y:741,t:1526930313833};\\\", \\\"{x:1593,y:734,t:1526930313848};\\\", \\\"{x:1598,y:725,t:1526930313866};\\\", \\\"{x:1603,y:721,t:1526930313882};\\\", \\\"{x:1607,y:717,t:1526930313899};\\\", \\\"{x:1609,y:715,t:1526930313915};\\\", \\\"{x:1612,y:713,t:1526930313933};\\\", \\\"{x:1616,y:712,t:1526930313948};\\\", \\\"{x:1620,y:710,t:1526930313966};\\\", \\\"{x:1621,y:708,t:1526930313983};\\\", \\\"{x:1622,y:708,t:1526930313998};\\\", \\\"{x:1623,y:707,t:1526930314016};\\\", \\\"{x:1624,y:706,t:1526930314049};\\\", \\\"{x:1622,y:706,t:1526930316610};\\\", \\\"{x:1620,y:712,t:1526930316617};\\\", \\\"{x:1611,y:724,t:1526930316634};\\\", \\\"{x:1601,y:740,t:1526930316649};\\\", \\\"{x:1589,y:757,t:1526930316667};\\\", \\\"{x:1578,y:778,t:1526930316684};\\\", \\\"{x:1564,y:799,t:1526930316700};\\\", \\\"{x:1552,y:817,t:1526930316717};\\\", \\\"{x:1542,y:835,t:1526930316733};\\\", \\\"{x:1536,y:847,t:1526930316751};\\\", \\\"{x:1535,y:849,t:1526930316767};\\\", \\\"{x:1533,y:855,t:1526930316784};\\\", \\\"{x:1532,y:860,t:1526930316801};\\\", \\\"{x:1531,y:866,t:1526930316817};\\\", \\\"{x:1529,y:869,t:1526930316834};\\\", \\\"{x:1527,y:873,t:1526930316850};\\\", \\\"{x:1526,y:878,t:1526930316867};\\\", \\\"{x:1523,y:883,t:1526930316883};\\\", \\\"{x:1519,y:889,t:1526930316901};\\\", \\\"{x:1517,y:897,t:1526930316917};\\\", \\\"{x:1513,y:904,t:1526930316933};\\\", \\\"{x:1506,y:917,t:1526930316950};\\\", \\\"{x:1500,y:926,t:1526930316967};\\\", \\\"{x:1497,y:936,t:1526930316984};\\\", \\\"{x:1491,y:948,t:1526930317001};\\\", \\\"{x:1486,y:961,t:1526930317017};\\\", \\\"{x:1485,y:977,t:1526930317033};\\\", \\\"{x:1482,y:985,t:1526930317050};\\\", \\\"{x:1481,y:988,t:1526930317067};\\\", \\\"{x:1481,y:989,t:1526930317083};\\\", \\\"{x:1481,y:990,t:1526930317101};\\\", \\\"{x:1481,y:992,t:1526930317130};\\\", \\\"{x:1480,y:992,t:1526930317138};\\\", \\\"{x:1480,y:991,t:1526930317330};\\\", \\\"{x:1481,y:987,t:1526930317346};\\\", \\\"{x:1482,y:986,t:1526930317354};\\\", \\\"{x:1483,y:985,t:1526930317366};\\\", \\\"{x:1485,y:981,t:1526930317384};\\\", \\\"{x:1485,y:980,t:1526930317401};\\\", \\\"{x:1486,y:978,t:1526930317416};\\\", \\\"{x:1486,y:977,t:1526930317434};\\\", \\\"{x:1486,y:976,t:1526930317458};\\\", \\\"{x:1486,y:975,t:1526930317467};\\\", \\\"{x:1486,y:974,t:1526930317522};\\\", \\\"{x:1486,y:972,t:1526930317890};\\\", \\\"{x:1486,y:969,t:1526930317914};\\\", \\\"{x:1486,y:968,t:1526930317922};\\\", \\\"{x:1486,y:965,t:1526930317933};\\\", \\\"{x:1479,y:954,t:1526930317950};\\\", \\\"{x:1473,y:939,t:1526930317967};\\\", \\\"{x:1469,y:930,t:1526930317984};\\\", \\\"{x:1464,y:922,t:1526930318000};\\\", \\\"{x:1457,y:906,t:1526930318017};\\\", \\\"{x:1449,y:894,t:1526930318034};\\\", \\\"{x:1438,y:877,t:1526930318051};\\\", \\\"{x:1419,y:848,t:1526930318068};\\\", \\\"{x:1399,y:824,t:1526930318083};\\\", \\\"{x:1384,y:803,t:1526930318100};\\\", \\\"{x:1378,y:789,t:1526930318118};\\\", \\\"{x:1371,y:776,t:1526930318134};\\\", \\\"{x:1364,y:767,t:1526930318151};\\\", \\\"{x:1357,y:757,t:1526930318168};\\\", \\\"{x:1351,y:745,t:1526930318184};\\\", \\\"{x:1345,y:734,t:1526930318200};\\\", \\\"{x:1341,y:720,t:1526930318218};\\\", \\\"{x:1338,y:709,t:1526930318234};\\\", \\\"{x:1335,y:703,t:1526930318251};\\\", \\\"{x:1334,y:696,t:1526930318268};\\\", \\\"{x:1332,y:690,t:1526930318284};\\\", \\\"{x:1330,y:687,t:1526930318300};\\\", \\\"{x:1329,y:685,t:1526930318318};\\\", \\\"{x:1329,y:680,t:1526930318334};\\\", \\\"{x:1327,y:677,t:1526930318351};\\\", \\\"{x:1326,y:674,t:1526930318368};\\\", \\\"{x:1322,y:667,t:1526930318385};\\\", \\\"{x:1320,y:660,t:1526930318401};\\\", \\\"{x:1316,y:657,t:1526930318418};\\\", \\\"{x:1315,y:655,t:1526930318434};\\\", \\\"{x:1312,y:650,t:1526930318451};\\\", \\\"{x:1308,y:643,t:1526930318468};\\\", \\\"{x:1305,y:639,t:1526930318485};\\\", \\\"{x:1302,y:633,t:1526930318501};\\\", \\\"{x:1300,y:630,t:1526930318518};\\\", \\\"{x:1299,y:629,t:1526930318535};\\\", \\\"{x:1299,y:627,t:1526930318551};\\\", \\\"{x:1296,y:622,t:1526930318568};\\\", \\\"{x:1295,y:617,t:1526930318585};\\\", \\\"{x:1291,y:611,t:1526930318601};\\\", \\\"{x:1289,y:605,t:1526930318618};\\\", \\\"{x:1287,y:602,t:1526930318634};\\\", \\\"{x:1285,y:599,t:1526930318651};\\\", \\\"{x:1282,y:593,t:1526930318667};\\\", \\\"{x:1278,y:586,t:1526930318684};\\\", \\\"{x:1276,y:582,t:1526930318700};\\\", \\\"{x:1270,y:577,t:1526930318718};\\\", \\\"{x:1268,y:574,t:1526930318735};\\\", \\\"{x:1267,y:572,t:1526930318751};\\\", \\\"{x:1265,y:569,t:1526930318768};\\\", \\\"{x:1264,y:567,t:1526930318786};\\\", \\\"{x:1264,y:566,t:1526930318818};\\\", \\\"{x:1264,y:565,t:1526930318850};\\\", \\\"{x:1264,y:564,t:1526930318868};\\\", \\\"{x:1264,y:563,t:1526930318914};\\\", \\\"{x:1265,y:561,t:1526930318946};\\\", \\\"{x:1267,y:559,t:1526930318977};\\\", \\\"{x:1268,y:559,t:1526930319018};\\\", \\\"{x:1268,y:558,t:1526930319042};\\\", \\\"{x:1270,y:558,t:1526930319114};\\\", \\\"{x:1272,y:558,t:1526930319154};\\\", \\\"{x:1273,y:558,t:1526930319193};\\\", \\\"{x:1274,y:559,t:1526930319617};\\\", \\\"{x:1274,y:561,t:1526930319762};\\\", \\\"{x:1275,y:562,t:1526930319858};\\\", \\\"{x:1275,y:563,t:1526930319874};\\\", \\\"{x:1275,y:564,t:1526930319906};\\\", \\\"{x:1275,y:565,t:1526930320850};\\\", \\\"{x:1275,y:566,t:1526930320858};\\\", \\\"{x:1271,y:568,t:1526930320868};\\\", \\\"{x:1248,y:575,t:1526930320885};\\\", \\\"{x:1230,y:579,t:1526930320902};\\\", \\\"{x:1208,y:586,t:1526930320918};\\\", \\\"{x:1154,y:586,t:1526930320936};\\\", \\\"{x:1104,y:586,t:1526930320952};\\\", \\\"{x:1058,y:586,t:1526930320969};\\\", \\\"{x:923,y:587,t:1526930320987};\\\", \\\"{x:837,y:587,t:1526930321001};\\\", \\\"{x:770,y:587,t:1526930321018};\\\", \\\"{x:749,y:588,t:1526930321040};\\\", \\\"{x:742,y:588,t:1526930321058};\\\", \\\"{x:741,y:588,t:1526930321104};\\\", \\\"{x:740,y:588,t:1526930321145};\\\", \\\"{x:738,y:588,t:1526930321158};\\\", \\\"{x:737,y:588,t:1526930321175};\\\", \\\"{x:735,y:588,t:1526930321192};\\\", \\\"{x:734,y:589,t:1526930321208};\\\", \\\"{x:733,y:589,t:1526930321225};\\\", \\\"{x:728,y:590,t:1526930321242};\\\", \\\"{x:724,y:590,t:1526930321258};\\\", \\\"{x:714,y:590,t:1526930321275};\\\", \\\"{x:705,y:588,t:1526930321292};\\\", \\\"{x:694,y:581,t:1526930321308};\\\", \\\"{x:680,y:577,t:1526930321325};\\\", \\\"{x:671,y:572,t:1526930321342};\\\", \\\"{x:663,y:566,t:1526930321358};\\\", \\\"{x:655,y:562,t:1526930321376};\\\", \\\"{x:650,y:560,t:1526930321392};\\\", \\\"{x:644,y:557,t:1526930321408};\\\", \\\"{x:636,y:551,t:1526930321425};\\\", \\\"{x:630,y:545,t:1526930321443};\\\", \\\"{x:625,y:542,t:1526930321459};\\\", \\\"{x:619,y:536,t:1526930321475};\\\", \\\"{x:617,y:536,t:1526930321492};\\\", \\\"{x:617,y:535,t:1526930321521};\\\", \\\"{x:617,y:533,t:1526930321536};\\\", \\\"{x:617,y:531,t:1526930321560};\\\", \\\"{x:617,y:530,t:1526930321585};\\\", \\\"{x:617,y:528,t:1526930321600};\\\", \\\"{x:617,y:527,t:1526930321617};\\\", \\\"{x:617,y:525,t:1526930321640};\\\", \\\"{x:617,y:524,t:1526930321665};\\\", \\\"{x:617,y:523,t:1526930321676};\\\", \\\"{x:618,y:521,t:1526930321692};\\\", \\\"{x:620,y:517,t:1526930321709};\\\", \\\"{x:621,y:515,t:1526930321725};\\\", \\\"{x:622,y:514,t:1526930321742};\\\", \\\"{x:622,y:512,t:1526930321759};\\\", \\\"{x:623,y:510,t:1526930321775};\\\", \\\"{x:624,y:509,t:1526930321792};\\\", \\\"{x:624,y:507,t:1526930321808};\\\", \\\"{x:624,y:506,t:1526930321848};\\\", \\\"{x:624,y:505,t:1526930321961};\\\", \\\"{x:623,y:505,t:1526930322009};\\\", \\\"{x:622,y:505,t:1526930322025};\\\", \\\"{x:621,y:505,t:1526930322041};\\\", \\\"{x:619,y:505,t:1526930322161};\\\", \\\"{x:618,y:505,t:1526930322192};\\\", \\\"{x:618,y:504,t:1526930322209};\\\", \\\"{x:616,y:505,t:1526930323314};\\\", \\\"{x:616,y:510,t:1526930323327};\\\", \\\"{x:613,y:518,t:1526930323345};\\\", \\\"{x:612,y:526,t:1526930323362};\\\", \\\"{x:609,y:530,t:1526930323377};\\\", \\\"{x:608,y:534,t:1526930323393};\\\", \\\"{x:608,y:540,t:1526930323410};\\\", \\\"{x:608,y:550,t:1526930323427};\\\", \\\"{x:608,y:566,t:1526930323444};\\\", \\\"{x:608,y:585,t:1526930323460};\\\", \\\"{x:608,y:602,t:1526930323478};\\\", \\\"{x:608,y:608,t:1526930323493};\\\", \\\"{x:604,y:619,t:1526930323510};\\\", \\\"{x:599,y:627,t:1526930323527};\\\", \\\"{x:594,y:642,t:1526930323544};\\\", \\\"{x:586,y:660,t:1526930323560};\\\", \\\"{x:573,y:686,t:1526930323577};\\\", \\\"{x:567,y:706,t:1526930323593};\\\", \\\"{x:561,y:718,t:1526930323611};\\\", \\\"{x:553,y:730,t:1526930323627};\\\", \\\"{x:549,y:737,t:1526930323643};\\\", \\\"{x:546,y:743,t:1526930323660};\\\", \\\"{x:544,y:746,t:1526930323678};\\\", \\\"{x:541,y:748,t:1526930323693};\\\", \\\"{x:541,y:749,t:1526930323713};\\\", \\\"{x:540,y:750,t:1526930323729};\\\", \\\"{x:539,y:750,t:1526930323743};\\\", \\\"{x:536,y:753,t:1526930323760};\\\", \\\"{x:526,y:761,t:1526930323778};\\\", \\\"{x:525,y:762,t:1526930323793};\\\", \\\"{x:523,y:762,t:1526930323873};\\\", \\\"{x:523,y:761,t:1526930323905};\\\", \\\"{x:523,y:759,t:1526930323913};\\\", \\\"{x:523,y:757,t:1526930323927};\\\", \\\"{x:526,y:753,t:1526930323946};\\\", \\\"{x:527,y:752,t:1526930323961};\\\", \\\"{x:527,y:751,t:1526930323993};\\\", \\\"{x:528,y:749,t:1526930324026};\\\", \\\"{x:529,y:749,t:1526930324033};\\\", \\\"{x:529,y:748,t:1526930324044};\\\", \\\"{x:529,y:747,t:1526930324061};\\\", \\\"{x:529,y:746,t:1526930324078};\\\", \\\"{x:530,y:744,t:1526930324105};\\\", \\\"{x:531,y:744,t:1526930324113};\\\", \\\"{x:531,y:743,t:1526930324138};\\\", \\\"{x:532,y:743,t:1526930324640};\\\", \\\"{x:533,y:742,t:1526930324657};\\\", \\\"{x:534,y:741,t:1526930324664};\\\", \\\"{x:534,y:739,t:1526930324681};\\\", \\\"{x:535,y:739,t:1526930324793};\\\" ] }, { \\\"rt\\\": 12090, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 661439, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:739,t:1526930329410};\\\", \\\"{x:553,y:745,t:1526930329454};\\\", \\\"{x:565,y:749,t:1526930329470};\\\", \\\"{x:576,y:756,t:1526930329487};\\\", \\\"{x:589,y:766,t:1526930329505};\\\", \\\"{x:594,y:774,t:1526930329515};\\\", \\\"{x:617,y:791,t:1526930329532};\\\", \\\"{x:667,y:812,t:1526930329549};\\\", \\\"{x:731,y:838,t:1526930329566};\\\", \\\"{x:831,y:870,t:1526930329581};\\\", \\\"{x:940,y:890,t:1526930329598};\\\", \\\"{x:1020,y:897,t:1526930329616};\\\", \\\"{x:1118,y:915,t:1526930329632};\\\", \\\"{x:1226,y:930,t:1526930329649};\\\", \\\"{x:1276,y:932,t:1526930329665};\\\", \\\"{x:1330,y:941,t:1526930329681};\\\", \\\"{x:1371,y:945,t:1526930329699};\\\", \\\"{x:1388,y:948,t:1526930329715};\\\", \\\"{x:1400,y:952,t:1526930329731};\\\", \\\"{x:1410,y:953,t:1526930329748};\\\", \\\"{x:1426,y:953,t:1526930329766};\\\", \\\"{x:1447,y:953,t:1526930329782};\\\", \\\"{x:1461,y:953,t:1526930329798};\\\", \\\"{x:1478,y:953,t:1526930329816};\\\", \\\"{x:1485,y:951,t:1526930329832};\\\", \\\"{x:1486,y:950,t:1526930329848};\\\", \\\"{x:1488,y:950,t:1526930329866};\\\", \\\"{x:1484,y:951,t:1526930329978};\\\", \\\"{x:1480,y:953,t:1526930329985};\\\", \\\"{x:1472,y:956,t:1526930329999};\\\", \\\"{x:1455,y:962,t:1526930330017};\\\", \\\"{x:1371,y:968,t:1526930330034};\\\", \\\"{x:1332,y:968,t:1526930330049};\\\", \\\"{x:1262,y:968,t:1526930330066};\\\", \\\"{x:1251,y:968,t:1526930330083};\\\", \\\"{x:1247,y:968,t:1526930330099};\\\", \\\"{x:1246,y:968,t:1526930330116};\\\", \\\"{x:1247,y:968,t:1526930330281};\\\", \\\"{x:1253,y:968,t:1526930330289};\\\", \\\"{x:1268,y:969,t:1526930330300};\\\", \\\"{x:1296,y:971,t:1526930330315};\\\", \\\"{x:1328,y:977,t:1526930330334};\\\", \\\"{x:1347,y:979,t:1526930330349};\\\", \\\"{x:1352,y:979,t:1526930330366};\\\", \\\"{x:1352,y:977,t:1526930330425};\\\", \\\"{x:1352,y:974,t:1526930330433};\\\", \\\"{x:1352,y:972,t:1526930330449};\\\", \\\"{x:1352,y:969,t:1526930330466};\\\", \\\"{x:1352,y:963,t:1526930330483};\\\", \\\"{x:1351,y:960,t:1526930330500};\\\", \\\"{x:1349,y:954,t:1526930330516};\\\", \\\"{x:1349,y:952,t:1526930330533};\\\", \\\"{x:1349,y:951,t:1526930330550};\\\", \\\"{x:1350,y:948,t:1526930330566};\\\", \\\"{x:1352,y:945,t:1526930330583};\\\", \\\"{x:1355,y:939,t:1526930330600};\\\", \\\"{x:1358,y:930,t:1526930330616};\\\", \\\"{x:1364,y:914,t:1526930330633};\\\", \\\"{x:1368,y:895,t:1526930330650};\\\", \\\"{x:1371,y:885,t:1526930330666};\\\", \\\"{x:1371,y:876,t:1526930330684};\\\", \\\"{x:1371,y:869,t:1526930330701};\\\", \\\"{x:1371,y:865,t:1526930330717};\\\", \\\"{x:1371,y:862,t:1526930330733};\\\", \\\"{x:1371,y:861,t:1526930330754};\\\", \\\"{x:1370,y:861,t:1526930330810};\\\", \\\"{x:1368,y:861,t:1526930330833};\\\", \\\"{x:1365,y:862,t:1526930330849};\\\", \\\"{x:1360,y:863,t:1526930330866};\\\", \\\"{x:1355,y:866,t:1526930330883};\\\", \\\"{x:1353,y:871,t:1526930330900};\\\", \\\"{x:1353,y:874,t:1526930330917};\\\", \\\"{x:1354,y:877,t:1526930330933};\\\", \\\"{x:1356,y:879,t:1526930330950};\\\", \\\"{x:1359,y:882,t:1526930330967};\\\", \\\"{x:1360,y:884,t:1526930330983};\\\", \\\"{x:1363,y:886,t:1526930331000};\\\", \\\"{x:1365,y:887,t:1526930331017};\\\", \\\"{x:1367,y:889,t:1526930331034};\\\", \\\"{x:1367,y:890,t:1526930331057};\\\", \\\"{x:1367,y:891,t:1526930331097};\\\", \\\"{x:1367,y:892,t:1526930331114};\\\", \\\"{x:1367,y:893,t:1526930331122};\\\", \\\"{x:1368,y:893,t:1526930331257};\\\", \\\"{x:1370,y:893,t:1526930331267};\\\", \\\"{x:1379,y:890,t:1526930331283};\\\", \\\"{x:1387,y:881,t:1526930331300};\\\", \\\"{x:1393,y:872,t:1526930331317};\\\", \\\"{x:1400,y:863,t:1526930331334};\\\", \\\"{x:1407,y:853,t:1526930331350};\\\", \\\"{x:1411,y:844,t:1526930331367};\\\", \\\"{x:1414,y:825,t:1526930331384};\\\", \\\"{x:1418,y:814,t:1526930331400};\\\", \\\"{x:1422,y:803,t:1526930331417};\\\", \\\"{x:1423,y:795,t:1526930331434};\\\", \\\"{x:1423,y:789,t:1526930331450};\\\", \\\"{x:1423,y:787,t:1526930331467};\\\", \\\"{x:1423,y:785,t:1526930331484};\\\", \\\"{x:1424,y:785,t:1526930331500};\\\", \\\"{x:1420,y:785,t:1526930331562};\\\", \\\"{x:1416,y:785,t:1526930331569};\\\", \\\"{x:1414,y:785,t:1526930331584};\\\", \\\"{x:1410,y:785,t:1526930331600};\\\", \\\"{x:1406,y:793,t:1526930331618};\\\", \\\"{x:1403,y:804,t:1526930331634};\\\", \\\"{x:1400,y:809,t:1526930331650};\\\", \\\"{x:1398,y:818,t:1526930331666};\\\", \\\"{x:1396,y:826,t:1526930331683};\\\", \\\"{x:1391,y:836,t:1526930331700};\\\", \\\"{x:1386,y:852,t:1526930331716};\\\", \\\"{x:1381,y:860,t:1526930331733};\\\", \\\"{x:1379,y:865,t:1526930331749};\\\", \\\"{x:1378,y:871,t:1526930331767};\\\", \\\"{x:1375,y:878,t:1526930331783};\\\", \\\"{x:1373,y:886,t:1526930331800};\\\", \\\"{x:1371,y:889,t:1526930331817};\\\", \\\"{x:1371,y:892,t:1526930331833};\\\", \\\"{x:1371,y:893,t:1526930331857};\\\", \\\"{x:1371,y:895,t:1526930331898};\\\", \\\"{x:1371,y:896,t:1526930331946};\\\", \\\"{x:1371,y:898,t:1526930331962};\\\", \\\"{x:1372,y:898,t:1526930332146};\\\", \\\"{x:1373,y:898,t:1526930332153};\\\", \\\"{x:1374,y:898,t:1526930332168};\\\", \\\"{x:1376,y:898,t:1526930332187};\\\", \\\"{x:1387,y:891,t:1526930332200};\\\", \\\"{x:1393,y:882,t:1526930332217};\\\", \\\"{x:1400,y:876,t:1526930332233};\\\", \\\"{x:1409,y:870,t:1526930332250};\\\", \\\"{x:1412,y:865,t:1526930332267};\\\", \\\"{x:1415,y:862,t:1526930332284};\\\", \\\"{x:1418,y:860,t:1526930332300};\\\", \\\"{x:1418,y:858,t:1526930332317};\\\", \\\"{x:1420,y:856,t:1526930332334};\\\", \\\"{x:1422,y:853,t:1526930332351};\\\", \\\"{x:1422,y:849,t:1526930332368};\\\", \\\"{x:1424,y:845,t:1526930332384};\\\", \\\"{x:1426,y:837,t:1526930332400};\\\", \\\"{x:1428,y:834,t:1526930332418};\\\", \\\"{x:1429,y:832,t:1526930332433};\\\", \\\"{x:1430,y:829,t:1526930332450};\\\", \\\"{x:1432,y:825,t:1526930332468};\\\", \\\"{x:1434,y:819,t:1526930332484};\\\", \\\"{x:1437,y:814,t:1526930332501};\\\", \\\"{x:1440,y:808,t:1526930332518};\\\", \\\"{x:1443,y:800,t:1526930332533};\\\", \\\"{x:1445,y:787,t:1526930332550};\\\", \\\"{x:1448,y:775,t:1526930332568};\\\", \\\"{x:1450,y:761,t:1526930332584};\\\", \\\"{x:1455,y:752,t:1526930332601};\\\", \\\"{x:1456,y:747,t:1526930332618};\\\", \\\"{x:1458,y:744,t:1526930332634};\\\", \\\"{x:1460,y:738,t:1526930332651};\\\", \\\"{x:1461,y:737,t:1526930332667};\\\", \\\"{x:1464,y:732,t:1526930332683};\\\", \\\"{x:1466,y:729,t:1526930332701};\\\", \\\"{x:1469,y:726,t:1526930332718};\\\", \\\"{x:1469,y:723,t:1526930332734};\\\", \\\"{x:1471,y:720,t:1526930332750};\\\", \\\"{x:1472,y:719,t:1526930332768};\\\", \\\"{x:1473,y:717,t:1526930332784};\\\", \\\"{x:1476,y:714,t:1526930332800};\\\", \\\"{x:1479,y:710,t:1526930332818};\\\", \\\"{x:1480,y:705,t:1526930332835};\\\", \\\"{x:1484,y:698,t:1526930332851};\\\", \\\"{x:1491,y:690,t:1526930332868};\\\", \\\"{x:1494,y:682,t:1526930332885};\\\", \\\"{x:1502,y:667,t:1526930332901};\\\", \\\"{x:1508,y:656,t:1526930332918};\\\", \\\"{x:1518,y:641,t:1526930332934};\\\", \\\"{x:1527,y:625,t:1526930332951};\\\", \\\"{x:1535,y:613,t:1526930332968};\\\", \\\"{x:1549,y:583,t:1526930332985};\\\", \\\"{x:1556,y:571,t:1526930333001};\\\", \\\"{x:1566,y:559,t:1526930333018};\\\", \\\"{x:1576,y:550,t:1526930333035};\\\", \\\"{x:1580,y:543,t:1526930333051};\\\", \\\"{x:1583,y:539,t:1526930333069};\\\", \\\"{x:1584,y:536,t:1526930333085};\\\", \\\"{x:1584,y:535,t:1526930333101};\\\", \\\"{x:1585,y:535,t:1526930333118};\\\", \\\"{x:1586,y:533,t:1526930333135};\\\", \\\"{x:1587,y:532,t:1526930333151};\\\", \\\"{x:1588,y:530,t:1526930333168};\\\", \\\"{x:1592,y:525,t:1526930333185};\\\", \\\"{x:1594,y:523,t:1526930333201};\\\", \\\"{x:1595,y:520,t:1526930333218};\\\", \\\"{x:1597,y:517,t:1526930333235};\\\", \\\"{x:1597,y:515,t:1526930333252};\\\", \\\"{x:1598,y:512,t:1526930333268};\\\", \\\"{x:1600,y:508,t:1526930333285};\\\", \\\"{x:1601,y:503,t:1526930333302};\\\", \\\"{x:1602,y:497,t:1526930333319};\\\", \\\"{x:1605,y:491,t:1526930333335};\\\", \\\"{x:1605,y:488,t:1526930333352};\\\", \\\"{x:1607,y:484,t:1526930333368};\\\", \\\"{x:1607,y:480,t:1526930333385};\\\", \\\"{x:1607,y:479,t:1526930333402};\\\", \\\"{x:1607,y:478,t:1526930333418};\\\", \\\"{x:1607,y:479,t:1526930333546};\\\", \\\"{x:1605,y:481,t:1526930333554};\\\", \\\"{x:1602,y:484,t:1526930333568};\\\", \\\"{x:1592,y:493,t:1526930333585};\\\", \\\"{x:1584,y:503,t:1526930333603};\\\", \\\"{x:1577,y:510,t:1526930333618};\\\", \\\"{x:1573,y:515,t:1526930333635};\\\", \\\"{x:1570,y:519,t:1526930333653};\\\", \\\"{x:1569,y:520,t:1526930333669};\\\", \\\"{x:1568,y:521,t:1526930333686};\\\", \\\"{x:1567,y:522,t:1526930333713};\\\", \\\"{x:1566,y:523,t:1526930333721};\\\", \\\"{x:1565,y:523,t:1526930333735};\\\", \\\"{x:1562,y:526,t:1526930333752};\\\", \\\"{x:1555,y:534,t:1526930333769};\\\", \\\"{x:1548,y:541,t:1526930333786};\\\", \\\"{x:1533,y:557,t:1526930333802};\\\", \\\"{x:1526,y:574,t:1526930333820};\\\", \\\"{x:1511,y:596,t:1526930333835};\\\", \\\"{x:1498,y:615,t:1526930333852};\\\", \\\"{x:1485,y:626,t:1526930333870};\\\", \\\"{x:1465,y:656,t:1526930333885};\\\", \\\"{x:1439,y:691,t:1526930333902};\\\", \\\"{x:1417,y:718,t:1526930333919};\\\", \\\"{x:1404,y:736,t:1526930333935};\\\", \\\"{x:1389,y:756,t:1526930333953};\\\", \\\"{x:1367,y:783,t:1526930333969};\\\", \\\"{x:1348,y:796,t:1526930333986};\\\", \\\"{x:1331,y:808,t:1526930334002};\\\", \\\"{x:1320,y:810,t:1526930334019};\\\", \\\"{x:1308,y:810,t:1526930334035};\\\", \\\"{x:1288,y:810,t:1526930334052};\\\", \\\"{x:1270,y:810,t:1526930334069};\\\", \\\"{x:1253,y:812,t:1526930334085};\\\", \\\"{x:1225,y:805,t:1526930334102};\\\", \\\"{x:1177,y:783,t:1526930334119};\\\", \\\"{x:1128,y:764,t:1526930334135};\\\", \\\"{x:1043,y:712,t:1526930334153};\\\", \\\"{x:1013,y:694,t:1526930334169};\\\", \\\"{x:997,y:683,t:1526930334186};\\\", \\\"{x:975,y:674,t:1526930334203};\\\", \\\"{x:950,y:657,t:1526930334219};\\\", \\\"{x:922,y:645,t:1526930334235};\\\", \\\"{x:903,y:636,t:1526930334252};\\\", \\\"{x:886,y:627,t:1526930334271};\\\", \\\"{x:873,y:622,t:1526930334286};\\\", \\\"{x:856,y:621,t:1526930334302};\\\", \\\"{x:847,y:616,t:1526930334318};\\\", \\\"{x:844,y:616,t:1526930334335};\\\", \\\"{x:842,y:614,t:1526930334352};\\\", \\\"{x:842,y:613,t:1526930334376};\\\", \\\"{x:842,y:611,t:1526930334385};\\\", \\\"{x:839,y:608,t:1526930334403};\\\", \\\"{x:838,y:604,t:1526930334419};\\\", \\\"{x:833,y:598,t:1526930334436};\\\", \\\"{x:831,y:594,t:1526930334453};\\\", \\\"{x:824,y:590,t:1526930334469};\\\", \\\"{x:821,y:586,t:1526930334486};\\\", \\\"{x:818,y:583,t:1526930334502};\\\", \\\"{x:810,y:579,t:1526930334520};\\\", \\\"{x:786,y:567,t:1526930334536};\\\", \\\"{x:762,y:561,t:1526930334553};\\\", \\\"{x:741,y:559,t:1526930334570};\\\", \\\"{x:722,y:554,t:1526930334586};\\\", \\\"{x:708,y:554,t:1526930334602};\\\", \\\"{x:704,y:554,t:1526930334620};\\\", \\\"{x:696,y:554,t:1526930334635};\\\", \\\"{x:690,y:554,t:1526930334652};\\\", \\\"{x:686,y:554,t:1526930334669};\\\", \\\"{x:678,y:555,t:1526930334685};\\\", \\\"{x:667,y:557,t:1526930334703};\\\", \\\"{x:650,y:558,t:1526930334720};\\\", \\\"{x:635,y:561,t:1526930334735};\\\", \\\"{x:618,y:561,t:1526930334752};\\\", \\\"{x:613,y:563,t:1526930334771};\\\", \\\"{x:605,y:565,t:1526930334785};\\\", \\\"{x:603,y:567,t:1526930334803};\\\", \\\"{x:601,y:567,t:1526930334820};\\\", \\\"{x:577,y:572,t:1526930334836};\\\", \\\"{x:558,y:576,t:1526930334853};\\\", \\\"{x:543,y:576,t:1526930334869};\\\", \\\"{x:540,y:576,t:1526930334885};\\\", \\\"{x:539,y:579,t:1526930334920};\\\", \\\"{x:536,y:579,t:1526930334936};\\\", \\\"{x:531,y:585,t:1526930334952};\\\", \\\"{x:530,y:587,t:1526930334970};\\\", \\\"{x:529,y:589,t:1526930334986};\\\", \\\"{x:529,y:592,t:1526930335003};\\\", \\\"{x:529,y:596,t:1526930335021};\\\", \\\"{x:529,y:601,t:1526930335036};\\\", \\\"{x:529,y:606,t:1526930335053};\\\", \\\"{x:529,y:607,t:1526930335069};\\\", \\\"{x:531,y:610,t:1526930335086};\\\", \\\"{x:534,y:615,t:1526930335104};\\\", \\\"{x:539,y:621,t:1526930335119};\\\", \\\"{x:541,y:626,t:1526930335137};\\\", \\\"{x:540,y:630,t:1526930335153};\\\", \\\"{x:529,y:635,t:1526930335170};\\\", \\\"{x:525,y:637,t:1526930335186};\\\", \\\"{x:521,y:639,t:1526930335203};\\\", \\\"{x:512,y:640,t:1526930335219};\\\", \\\"{x:493,y:640,t:1526930335239};\\\", \\\"{x:441,y:640,t:1526930335254};\\\", \\\"{x:361,y:634,t:1526930335270};\\\", \\\"{x:305,y:624,t:1526930335287};\\\", \\\"{x:265,y:618,t:1526930335303};\\\", \\\"{x:256,y:618,t:1526930335319};\\\", \\\"{x:251,y:618,t:1526930335337};\\\", \\\"{x:250,y:618,t:1526930335353};\\\", \\\"{x:248,y:616,t:1526930335400};\\\", \\\"{x:247,y:615,t:1526930335408};\\\", \\\"{x:247,y:612,t:1526930335419};\\\", \\\"{x:247,y:611,t:1526930335436};\\\", \\\"{x:247,y:610,t:1526930335456};\\\", \\\"{x:247,y:609,t:1526930335481};\\\", \\\"{x:247,y:608,t:1526930335512};\\\", \\\"{x:247,y:607,t:1526930335521};\\\", \\\"{x:247,y:605,t:1526930335537};\\\", \\\"{x:247,y:604,t:1526930335594};\\\", \\\"{x:249,y:603,t:1526930335617};\\\", \\\"{x:258,y:603,t:1526930335625};\\\", \\\"{x:264,y:603,t:1526930335637};\\\", \\\"{x:282,y:604,t:1526930335656};\\\", \\\"{x:310,y:604,t:1526930335670};\\\", \\\"{x:323,y:604,t:1526930335687};\\\", \\\"{x:334,y:602,t:1526930335703};\\\", \\\"{x:343,y:598,t:1526930335720};\\\", \\\"{x:345,y:595,t:1526930335738};\\\", \\\"{x:347,y:593,t:1526930335754};\\\", \\\"{x:348,y:591,t:1526930335771};\\\", \\\"{x:352,y:583,t:1526930335787};\\\", \\\"{x:354,y:577,t:1526930335803};\\\", \\\"{x:355,y:573,t:1526930335820};\\\", \\\"{x:355,y:570,t:1526930335837};\\\", \\\"{x:356,y:568,t:1526930335853};\\\", \\\"{x:358,y:564,t:1526930335870};\\\", \\\"{x:360,y:559,t:1526930335887};\\\", \\\"{x:361,y:554,t:1526930335904};\\\", \\\"{x:361,y:550,t:1526930335920};\\\", \\\"{x:361,y:548,t:1526930335937};\\\", \\\"{x:361,y:547,t:1526930335958};\\\", \\\"{x:361,y:545,t:1526930335975};\\\", \\\"{x:362,y:543,t:1526930335991};\\\", \\\"{x:364,y:541,t:1526930336008};\\\", \\\"{x:365,y:541,t:1526930336029};\\\", \\\"{x:366,y:540,t:1526930336062};\\\", \\\"{x:368,y:540,t:1526930336076};\\\", \\\"{x:370,y:537,t:1526930336091};\\\", \\\"{x:372,y:537,t:1526930336108};\\\", \\\"{x:373,y:536,t:1526930336127};\\\", \\\"{x:377,y:537,t:1526930336452};\\\", \\\"{x:378,y:540,t:1526930336461};\\\", \\\"{x:382,y:545,t:1526930336475};\\\", \\\"{x:397,y:557,t:1526930336492};\\\", \\\"{x:410,y:571,t:1526930336509};\\\", \\\"{x:425,y:584,t:1526930336525};\\\", \\\"{x:430,y:590,t:1526930336542};\\\", \\\"{x:432,y:596,t:1526930336558};\\\", \\\"{x:433,y:597,t:1526930336575};\\\", \\\"{x:433,y:600,t:1526930336592};\\\", \\\"{x:433,y:603,t:1526930336609};\\\", \\\"{x:432,y:605,t:1526930336625};\\\", \\\"{x:432,y:606,t:1526930336642};\\\", \\\"{x:431,y:607,t:1526930336659};\\\", \\\"{x:427,y:608,t:1526930336675};\\\", \\\"{x:425,y:609,t:1526930336692};\\\", \\\"{x:421,y:610,t:1526930336708};\\\", \\\"{x:417,y:610,t:1526930336725};\\\", \\\"{x:411,y:611,t:1526930336743};\\\", \\\"{x:402,y:615,t:1526930336759};\\\", \\\"{x:399,y:615,t:1526930336775};\\\", \\\"{x:396,y:617,t:1526930336792};\\\", \\\"{x:395,y:618,t:1526930336809};\\\", \\\"{x:394,y:618,t:1526930336909};\\\", \\\"{x:392,y:618,t:1526930336925};\\\", \\\"{x:396,y:622,t:1526930337141};\\\", \\\"{x:405,y:627,t:1526930337149};\\\", \\\"{x:416,y:637,t:1526930337159};\\\", \\\"{x:446,y:661,t:1526930337176};\\\", \\\"{x:489,y:693,t:1526930337192};\\\", \\\"{x:502,y:710,t:1526930337209};\\\", \\\"{x:520,y:727,t:1526930337227};\\\", \\\"{x:530,y:736,t:1526930337242};\\\", \\\"{x:533,y:740,t:1526930337258};\\\", \\\"{x:534,y:742,t:1526930337276};\\\", \\\"{x:534,y:744,t:1526930337292};\\\", \\\"{x:534,y:745,t:1526930337309};\\\", \\\"{x:534,y:746,t:1526930337382};\\\", \\\"{x:535,y:746,t:1526930337742};\\\", \\\"{x:535,y:745,t:1526930337765};\\\", \\\"{x:537,y:745,t:1526930337781};\\\", \\\"{x:538,y:743,t:1526930337793};\\\", \\\"{x:539,y:743,t:1526930337809};\\\", \\\"{x:539,y:742,t:1526930337829};\\\", \\\"{x:540,y:742,t:1526930338637};\\\", \\\"{x:541,y:742,t:1526930338645};\\\", \\\"{x:542,y:742,t:1526930338677};\\\", \\\"{x:543,y:742,t:1526930338725};\\\", \\\"{x:544,y:742,t:1526930338742};\\\" ] }, { \\\"rt\\\": 14133, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 676802, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -10 AM-B -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:742,t:1526930340246};\\\", \\\"{x:546,y:742,t:1526930340282};\\\", \\\"{x:549,y:742,t:1526930340300};\\\", \\\"{x:550,y:742,t:1526930340316};\\\", \\\"{x:552,y:742,t:1526930340324};\\\", \\\"{x:557,y:740,t:1526930340340};\\\", \\\"{x:563,y:735,t:1526930340358};\\\", \\\"{x:570,y:730,t:1526930340376};\\\", \\\"{x:574,y:726,t:1526930340391};\\\", \\\"{x:576,y:724,t:1526930340411};\\\", \\\"{x:577,y:722,t:1526930340428};\\\", \\\"{x:588,y:717,t:1526930340445};\\\", \\\"{x:598,y:713,t:1526930340462};\\\", \\\"{x:602,y:712,t:1526930340478};\\\", \\\"{x:617,y:709,t:1526930340495};\\\", \\\"{x:632,y:709,t:1526930340512};\\\", \\\"{x:644,y:710,t:1526930340528};\\\", \\\"{x:646,y:710,t:1526930340545};\\\", \\\"{x:650,y:710,t:1526930340562};\\\", \\\"{x:653,y:710,t:1526930340578};\\\", \\\"{x:657,y:711,t:1526930340595};\\\", \\\"{x:658,y:711,t:1526930340612};\\\", \\\"{x:663,y:711,t:1526930340628};\\\", \\\"{x:667,y:711,t:1526930340645};\\\", \\\"{x:672,y:710,t:1526930340662};\\\", \\\"{x:676,y:709,t:1526930340679};\\\", \\\"{x:682,y:709,t:1526930340695};\\\", \\\"{x:685,y:708,t:1526930340712};\\\", \\\"{x:689,y:708,t:1526930340729};\\\", \\\"{x:690,y:707,t:1526930340745};\\\", \\\"{x:701,y:707,t:1526930341773};\\\", \\\"{x:728,y:707,t:1526930341782};\\\", \\\"{x:753,y:708,t:1526930341796};\\\", \\\"{x:893,y:737,t:1526930341813};\\\", \\\"{x:999,y:776,t:1526930341831};\\\", \\\"{x:1082,y:800,t:1526930341847};\\\", \\\"{x:1129,y:819,t:1526930341864};\\\", \\\"{x:1176,y:839,t:1526930341881};\\\", \\\"{x:1218,y:860,t:1526930341897};\\\", \\\"{x:1250,y:878,t:1526930341914};\\\", \\\"{x:1268,y:889,t:1526930341931};\\\", \\\"{x:1280,y:896,t:1526930341948};\\\", \\\"{x:1295,y:905,t:1526930341964};\\\", \\\"{x:1306,y:911,t:1526930341981};\\\", \\\"{x:1328,y:917,t:1526930341997};\\\", \\\"{x:1342,y:925,t:1526930342013};\\\", \\\"{x:1351,y:930,t:1526930342031};\\\", \\\"{x:1359,y:934,t:1526930342048};\\\", \\\"{x:1360,y:935,t:1526930342063};\\\", \\\"{x:1360,y:936,t:1526930342245};\\\", \\\"{x:1360,y:937,t:1526930342253};\\\", \\\"{x:1358,y:938,t:1526930342277};\\\", \\\"{x:1357,y:938,t:1526930342293};\\\", \\\"{x:1357,y:939,t:1526930342309};\\\", \\\"{x:1356,y:940,t:1526930342317};\\\", \\\"{x:1354,y:941,t:1526930342330};\\\", \\\"{x:1352,y:942,t:1526930342348};\\\", \\\"{x:1348,y:945,t:1526930342364};\\\", \\\"{x:1346,y:945,t:1526930342380};\\\", \\\"{x:1341,y:948,t:1526930342397};\\\", \\\"{x:1340,y:949,t:1526930342414};\\\", \\\"{x:1339,y:949,t:1526930342430};\\\", \\\"{x:1338,y:949,t:1526930342447};\\\", \\\"{x:1337,y:949,t:1526930342465};\\\", \\\"{x:1336,y:949,t:1526930342493};\\\", \\\"{x:1335,y:949,t:1526930342517};\\\", \\\"{x:1333,y:949,t:1526930342532};\\\", \\\"{x:1334,y:949,t:1526930342742};\\\", \\\"{x:1335,y:949,t:1526930342766};\\\", \\\"{x:1337,y:949,t:1526930342781};\\\", \\\"{x:1338,y:948,t:1526930342799};\\\", \\\"{x:1340,y:947,t:1526930342815};\\\", \\\"{x:1343,y:945,t:1526930342832};\\\", \\\"{x:1346,y:943,t:1526930342849};\\\", \\\"{x:1348,y:942,t:1526930342865};\\\", \\\"{x:1349,y:942,t:1526930342882};\\\", \\\"{x:1349,y:941,t:1526930342901};\\\", \\\"{x:1351,y:940,t:1526930342915};\\\", \\\"{x:1355,y:937,t:1526930342932};\\\", \\\"{x:1357,y:936,t:1526930342949};\\\", \\\"{x:1359,y:935,t:1526930342965};\\\", \\\"{x:1360,y:935,t:1526930342989};\\\", \\\"{x:1360,y:934,t:1526930343005};\\\", \\\"{x:1361,y:934,t:1526930343037};\\\", \\\"{x:1362,y:933,t:1526930343054};\\\", \\\"{x:1363,y:932,t:1526930343093};\\\", \\\"{x:1365,y:932,t:1526930343134};\\\", \\\"{x:1365,y:931,t:1526930343150};\\\", \\\"{x:1366,y:931,t:1526930343165};\\\", \\\"{x:1368,y:931,t:1526930343182};\\\", \\\"{x:1370,y:930,t:1526930343199};\\\", \\\"{x:1372,y:928,t:1526930343215};\\\", \\\"{x:1373,y:926,t:1526930343254};\\\", \\\"{x:1372,y:926,t:1526930343470};\\\", \\\"{x:1371,y:926,t:1526930343483};\\\", \\\"{x:1369,y:926,t:1526930343499};\\\", \\\"{x:1368,y:926,t:1526930343517};\\\", \\\"{x:1366,y:926,t:1526930343533};\\\", \\\"{x:1362,y:927,t:1526930343550};\\\", \\\"{x:1355,y:927,t:1526930343565};\\\", \\\"{x:1351,y:928,t:1526930343583};\\\", \\\"{x:1348,y:929,t:1526930343599};\\\", \\\"{x:1344,y:929,t:1526930343615};\\\", \\\"{x:1341,y:929,t:1526930343633};\\\", \\\"{x:1335,y:929,t:1526930343649};\\\", \\\"{x:1320,y:929,t:1526930343666};\\\", \\\"{x:1318,y:929,t:1526930343683};\\\", \\\"{x:1314,y:929,t:1526930343700};\\\", \\\"{x:1312,y:929,t:1526930343715};\\\", \\\"{x:1310,y:928,t:1526930343733};\\\", \\\"{x:1307,y:927,t:1526930343749};\\\", \\\"{x:1303,y:922,t:1526930343766};\\\", \\\"{x:1299,y:913,t:1526930343783};\\\", \\\"{x:1289,y:904,t:1526930343800};\\\", \\\"{x:1285,y:897,t:1526930343816};\\\", \\\"{x:1275,y:884,t:1526930343833};\\\", \\\"{x:1265,y:869,t:1526930343849};\\\", \\\"{x:1253,y:854,t:1526930343865};\\\", \\\"{x:1239,y:840,t:1526930343882};\\\", \\\"{x:1228,y:829,t:1526930343899};\\\", \\\"{x:1226,y:828,t:1526930343915};\\\", \\\"{x:1226,y:827,t:1526930343933};\\\", \\\"{x:1226,y:824,t:1526930343949};\\\", \\\"{x:1230,y:817,t:1526930343966};\\\", \\\"{x:1238,y:806,t:1526930343982};\\\", \\\"{x:1252,y:794,t:1526930344000};\\\", \\\"{x:1264,y:785,t:1526930344016};\\\", \\\"{x:1279,y:775,t:1526930344032};\\\", \\\"{x:1292,y:769,t:1526930344049};\\\", \\\"{x:1307,y:762,t:1526930344067};\\\", \\\"{x:1315,y:757,t:1526930344082};\\\", \\\"{x:1319,y:755,t:1526930344100};\\\", \\\"{x:1322,y:753,t:1526930344116};\\\", \\\"{x:1325,y:751,t:1526930344133};\\\", \\\"{x:1328,y:745,t:1526930344149};\\\", \\\"{x:1328,y:744,t:1526930344167};\\\", \\\"{x:1330,y:742,t:1526930344183};\\\", \\\"{x:1330,y:739,t:1526930344200};\\\", \\\"{x:1331,y:739,t:1526930344217};\\\", \\\"{x:1332,y:738,t:1526930344318};\\\", \\\"{x:1333,y:735,t:1526930344334};\\\", \\\"{x:1334,y:732,t:1526930344350};\\\", \\\"{x:1335,y:730,t:1526930344367};\\\", \\\"{x:1337,y:728,t:1526930344383};\\\", \\\"{x:1337,y:727,t:1526930344399};\\\", \\\"{x:1337,y:726,t:1526930344429};\\\", \\\"{x:1338,y:723,t:1526930344437};\\\", \\\"{x:1341,y:721,t:1526930344461};\\\", \\\"{x:1342,y:719,t:1526930344470};\\\", \\\"{x:1344,y:716,t:1526930344484};\\\", \\\"{x:1347,y:710,t:1526930344500};\\\", \\\"{x:1351,y:702,t:1526930344518};\\\", \\\"{x:1352,y:699,t:1526930344537};\\\", \\\"{x:1352,y:697,t:1526930344550};\\\", \\\"{x:1352,y:695,t:1526930344566};\\\", \\\"{x:1351,y:695,t:1526930344661};\\\", \\\"{x:1348,y:695,t:1526930344669};\\\", \\\"{x:1346,y:697,t:1526930344683};\\\", \\\"{x:1342,y:703,t:1526930344701};\\\", \\\"{x:1339,y:708,t:1526930344716};\\\", \\\"{x:1333,y:720,t:1526930344733};\\\", \\\"{x:1331,y:724,t:1526930344751};\\\", \\\"{x:1326,y:729,t:1526930344766};\\\", \\\"{x:1321,y:741,t:1526930344784};\\\", \\\"{x:1314,y:752,t:1526930344801};\\\", \\\"{x:1313,y:765,t:1526930344817};\\\", \\\"{x:1308,y:775,t:1526930344833};\\\", \\\"{x:1308,y:779,t:1526930344851};\\\", \\\"{x:1305,y:785,t:1526930344867};\\\", \\\"{x:1303,y:790,t:1526930344884};\\\", \\\"{x:1301,y:793,t:1526930344901};\\\", \\\"{x:1296,y:802,t:1526930344917};\\\", \\\"{x:1292,y:810,t:1526930344933};\\\", \\\"{x:1289,y:821,t:1526930344951};\\\", \\\"{x:1283,y:836,t:1526930344967};\\\", \\\"{x:1278,y:846,t:1526930344984};\\\", \\\"{x:1277,y:855,t:1526930345001};\\\", \\\"{x:1273,y:860,t:1526930345017};\\\", \\\"{x:1272,y:866,t:1526930345034};\\\", \\\"{x:1267,y:873,t:1526930345051};\\\", \\\"{x:1263,y:883,t:1526930345068};\\\", \\\"{x:1259,y:893,t:1526930345084};\\\", \\\"{x:1255,y:899,t:1526930345100};\\\", \\\"{x:1250,y:904,t:1526930345117};\\\", \\\"{x:1248,y:907,t:1526930345135};\\\", \\\"{x:1248,y:908,t:1526930345151};\\\", \\\"{x:1247,y:909,t:1526930345168};\\\", \\\"{x:1246,y:914,t:1526930345185};\\\", \\\"{x:1246,y:915,t:1526930345201};\\\", \\\"{x:1245,y:917,t:1526930345218};\\\", \\\"{x:1244,y:920,t:1526930345235};\\\", \\\"{x:1238,y:925,t:1526930345251};\\\", \\\"{x:1232,y:929,t:1526930345268};\\\", \\\"{x:1226,y:935,t:1526930345285};\\\", \\\"{x:1223,y:936,t:1526930345301};\\\", \\\"{x:1220,y:938,t:1526930345318};\\\", \\\"{x:1216,y:941,t:1526930345334};\\\", \\\"{x:1211,y:944,t:1526930345350};\\\", \\\"{x:1209,y:946,t:1526930345368};\\\", \\\"{x:1204,y:949,t:1526930345384};\\\", \\\"{x:1204,y:951,t:1526930345421};\\\", \\\"{x:1204,y:952,t:1526930345461};\\\", \\\"{x:1204,y:953,t:1526930345468};\\\", \\\"{x:1204,y:954,t:1526930345492};\\\", \\\"{x:1204,y:955,t:1526930345524};\\\", \\\"{x:1204,y:956,t:1526930345541};\\\", \\\"{x:1203,y:958,t:1526930345565};\\\", \\\"{x:1202,y:960,t:1526930345573};\\\", \\\"{x:1202,y:961,t:1526930345590};\\\", \\\"{x:1202,y:962,t:1526930345602};\\\", \\\"{x:1202,y:964,t:1526930345618};\\\", \\\"{x:1202,y:965,t:1526930345635};\\\", \\\"{x:1202,y:967,t:1526930345661};\\\", \\\"{x:1202,y:968,t:1526930345677};\\\", \\\"{x:1202,y:969,t:1526930345694};\\\", \\\"{x:1203,y:969,t:1526930345710};\\\", \\\"{x:1203,y:970,t:1526930345733};\\\", \\\"{x:1204,y:970,t:1526930345758};\\\", \\\"{x:1205,y:970,t:1526930345797};\\\", \\\"{x:1206,y:970,t:1526930345806};\\\", \\\"{x:1208,y:970,t:1526930345819};\\\", \\\"{x:1213,y:969,t:1526930345834};\\\", \\\"{x:1220,y:965,t:1526930345852};\\\", \\\"{x:1226,y:959,t:1526930345869};\\\", \\\"{x:1240,y:945,t:1526930345886};\\\", \\\"{x:1242,y:940,t:1526930345901};\\\", \\\"{x:1244,y:937,t:1526930345919};\\\", \\\"{x:1248,y:932,t:1526930345935};\\\", \\\"{x:1252,y:924,t:1526930345952};\\\", \\\"{x:1255,y:913,t:1526930345968};\\\", \\\"{x:1257,y:906,t:1526930345985};\\\", \\\"{x:1260,y:899,t:1526930346002};\\\", \\\"{x:1264,y:894,t:1526930346019};\\\", \\\"{x:1267,y:890,t:1526930346036};\\\", \\\"{x:1270,y:883,t:1526930346051};\\\", \\\"{x:1276,y:867,t:1526930346068};\\\", \\\"{x:1283,y:855,t:1526930346084};\\\", \\\"{x:1290,y:839,t:1526930346101};\\\", \\\"{x:1297,y:825,t:1526930346118};\\\", \\\"{x:1305,y:811,t:1526930346135};\\\", \\\"{x:1312,y:798,t:1526930346151};\\\", \\\"{x:1317,y:792,t:1526930346168};\\\", \\\"{x:1325,y:780,t:1526930346185};\\\", \\\"{x:1335,y:765,t:1526930346201};\\\", \\\"{x:1345,y:748,t:1526930346218};\\\", \\\"{x:1356,y:732,t:1526930346236};\\\", \\\"{x:1364,y:716,t:1526930346252};\\\", \\\"{x:1376,y:695,t:1526930346268};\\\", \\\"{x:1383,y:685,t:1526930346286};\\\", \\\"{x:1386,y:679,t:1526930346302};\\\", \\\"{x:1387,y:673,t:1526930346319};\\\", \\\"{x:1392,y:663,t:1526930346336};\\\", \\\"{x:1397,y:648,t:1526930346353};\\\", \\\"{x:1401,y:638,t:1526930346369};\\\", \\\"{x:1404,y:626,t:1526930346385};\\\", \\\"{x:1407,y:618,t:1526930346403};\\\", \\\"{x:1410,y:606,t:1526930346419};\\\", \\\"{x:1413,y:600,t:1526930346435};\\\", \\\"{x:1417,y:593,t:1526930346453};\\\", \\\"{x:1418,y:588,t:1526930346468};\\\", \\\"{x:1418,y:582,t:1526930346486};\\\", \\\"{x:1420,y:578,t:1526930346502};\\\", \\\"{x:1421,y:572,t:1526930346519};\\\", \\\"{x:1423,y:562,t:1526930346535};\\\", \\\"{x:1423,y:556,t:1526930346553};\\\", \\\"{x:1423,y:551,t:1526930346569};\\\", \\\"{x:1423,y:550,t:1526930346586};\\\", \\\"{x:1423,y:548,t:1526930346603};\\\", \\\"{x:1423,y:547,t:1526930346622};\\\", \\\"{x:1423,y:546,t:1526930346654};\\\", \\\"{x:1423,y:545,t:1526930346670};\\\", \\\"{x:1423,y:544,t:1526930346687};\\\", \\\"{x:1421,y:544,t:1526930346750};\\\", \\\"{x:1419,y:544,t:1526930346757};\\\", \\\"{x:1416,y:548,t:1526930346770};\\\", \\\"{x:1413,y:554,t:1526930346786};\\\", \\\"{x:1407,y:565,t:1526930346804};\\\", \\\"{x:1405,y:572,t:1526930346820};\\\", \\\"{x:1405,y:576,t:1526930346835};\\\", \\\"{x:1404,y:576,t:1526930346852};\\\", \\\"{x:1404,y:577,t:1526930346869};\\\", \\\"{x:1405,y:576,t:1526930347118};\\\", \\\"{x:1406,y:575,t:1526930347125};\\\", \\\"{x:1406,y:574,t:1526930347141};\\\", \\\"{x:1407,y:574,t:1526930347153};\\\", \\\"{x:1407,y:573,t:1526930347181};\\\", \\\"{x:1407,y:572,t:1526930347429};\\\", \\\"{x:1408,y:571,t:1526930347445};\\\", \\\"{x:1409,y:570,t:1526930347453};\\\", \\\"{x:1409,y:569,t:1526930347470};\\\", \\\"{x:1410,y:569,t:1526930347487};\\\", \\\"{x:1410,y:568,t:1526930347504};\\\", \\\"{x:1411,y:568,t:1526930347533};\\\", \\\"{x:1411,y:567,t:1526930347590};\\\", \\\"{x:1412,y:566,t:1526930347604};\\\", \\\"{x:1412,y:565,t:1526930347662};\\\", \\\"{x:1412,y:566,t:1526930349172};\\\", \\\"{x:1403,y:577,t:1526930349189};\\\", \\\"{x:1397,y:587,t:1526930349206};\\\", \\\"{x:1389,y:599,t:1526930349222};\\\", \\\"{x:1381,y:609,t:1526930349239};\\\", \\\"{x:1376,y:616,t:1526930349255};\\\", \\\"{x:1373,y:620,t:1526930349272};\\\", \\\"{x:1370,y:623,t:1526930349288};\\\", \\\"{x:1368,y:625,t:1526930349306};\\\", \\\"{x:1367,y:631,t:1526930349323};\\\", \\\"{x:1363,y:637,t:1526930349338};\\\", \\\"{x:1357,y:646,t:1526930349356};\\\", \\\"{x:1353,y:653,t:1526930349373};\\\", \\\"{x:1350,y:659,t:1526930349388};\\\", \\\"{x:1345,y:663,t:1526930349405};\\\", \\\"{x:1338,y:669,t:1526930349423};\\\", \\\"{x:1331,y:676,t:1526930349438};\\\", \\\"{x:1328,y:680,t:1526930349455};\\\", \\\"{x:1323,y:683,t:1526930349472};\\\", \\\"{x:1319,y:685,t:1526930349488};\\\", \\\"{x:1311,y:690,t:1526930349506};\\\", \\\"{x:1304,y:694,t:1526930349522};\\\", \\\"{x:1297,y:697,t:1526930349539};\\\", \\\"{x:1289,y:697,t:1526930349555};\\\", \\\"{x:1272,y:697,t:1526930349573};\\\", \\\"{x:1253,y:690,t:1526930349589};\\\", \\\"{x:1205,y:674,t:1526930349605};\\\", \\\"{x:1108,y:646,t:1526930349623};\\\", \\\"{x:1048,y:625,t:1526930349639};\\\", \\\"{x:922,y:593,t:1526930349656};\\\", \\\"{x:805,y:560,t:1526930349673};\\\", \\\"{x:730,y:536,t:1526930349690};\\\", \\\"{x:695,y:529,t:1526930349703};\\\", \\\"{x:677,y:527,t:1526930349719};\\\", \\\"{x:671,y:526,t:1526930349736};\\\", \\\"{x:670,y:526,t:1526930349752};\\\", \\\"{x:669,y:526,t:1526930349812};\\\", \\\"{x:668,y:526,t:1526930349837};\\\", \\\"{x:666,y:526,t:1526930349853};\\\", \\\"{x:665,y:526,t:1526930349869};\\\", \\\"{x:664,y:526,t:1526930349909};\\\", \\\"{x:662,y:526,t:1526930349919};\\\", \\\"{x:659,y:526,t:1526930349936};\\\", \\\"{x:656,y:526,t:1526930349952};\\\", \\\"{x:654,y:526,t:1526930349970};\\\", \\\"{x:652,y:526,t:1526930349986};\\\", \\\"{x:644,y:526,t:1526930350003};\\\", \\\"{x:637,y:526,t:1526930350019};\\\", \\\"{x:632,y:526,t:1526930350036};\\\", \\\"{x:620,y:528,t:1526930350053};\\\", \\\"{x:606,y:530,t:1526930350069};\\\", \\\"{x:594,y:530,t:1526930350086};\\\", \\\"{x:589,y:532,t:1526930350102};\\\", \\\"{x:588,y:532,t:1526930350119};\\\", \\\"{x:586,y:532,t:1526930350136};\\\", \\\"{x:585,y:532,t:1526930350153};\\\", \\\"{x:584,y:533,t:1526930350169};\\\", \\\"{x:582,y:534,t:1526930350186};\\\", \\\"{x:581,y:534,t:1526930350202};\\\", \\\"{x:578,y:534,t:1526930350220};\\\", \\\"{x:577,y:536,t:1526930350236};\\\", \\\"{x:574,y:537,t:1526930350253};\\\", \\\"{x:561,y:540,t:1526930350269};\\\", \\\"{x:543,y:542,t:1526930350286};\\\", \\\"{x:516,y:542,t:1526930350303};\\\", \\\"{x:499,y:543,t:1526930350320};\\\", \\\"{x:483,y:541,t:1526930350338};\\\", \\\"{x:457,y:540,t:1526930350353};\\\", \\\"{x:445,y:539,t:1526930350370};\\\", \\\"{x:429,y:540,t:1526930350386};\\\", \\\"{x:424,y:540,t:1526930350403};\\\", \\\"{x:416,y:541,t:1526930350420};\\\", \\\"{x:408,y:542,t:1526930350436};\\\", \\\"{x:405,y:542,t:1526930350453};\\\", \\\"{x:404,y:542,t:1526930350469};\\\", \\\"{x:401,y:542,t:1526930350493};\\\", \\\"{x:400,y:542,t:1526930350508};\\\", \\\"{x:397,y:546,t:1526930350519};\\\", \\\"{x:392,y:546,t:1526930350537};\\\", \\\"{x:381,y:549,t:1526930350554};\\\", \\\"{x:375,y:549,t:1526930350570};\\\", \\\"{x:369,y:550,t:1526930350587};\\\", \\\"{x:365,y:553,t:1526930350603};\\\", \\\"{x:342,y:553,t:1526930350620};\\\", \\\"{x:299,y:553,t:1526930350636};\\\", \\\"{x:270,y:553,t:1526930350654};\\\", \\\"{x:254,y:552,t:1526930350669};\\\", \\\"{x:238,y:552,t:1526930350686};\\\", \\\"{x:228,y:552,t:1526930350703};\\\", \\\"{x:218,y:554,t:1526930350719};\\\", \\\"{x:212,y:554,t:1526930350736};\\\", \\\"{x:210,y:555,t:1526930350753};\\\", \\\"{x:211,y:555,t:1526930350869};\\\", \\\"{x:215,y:555,t:1526930350877};\\\", \\\"{x:217,y:555,t:1526930350887};\\\", \\\"{x:219,y:555,t:1526930350904};\\\", \\\"{x:224,y:555,t:1526930350920};\\\", \\\"{x:244,y:560,t:1526930350937};\\\", \\\"{x:259,y:562,t:1526930350953};\\\", \\\"{x:292,y:569,t:1526930350971};\\\", \\\"{x:375,y:577,t:1526930350988};\\\", \\\"{x:467,y:579,t:1526930351004};\\\", \\\"{x:603,y:579,t:1526930351022};\\\", \\\"{x:656,y:579,t:1526930351036};\\\", \\\"{x:681,y:576,t:1526930351053};\\\", \\\"{x:696,y:570,t:1526930351071};\\\", \\\"{x:709,y:562,t:1526930351087};\\\", \\\"{x:721,y:555,t:1526930351104};\\\", \\\"{x:732,y:547,t:1526930351121};\\\", \\\"{x:747,y:538,t:1526930351136};\\\", \\\"{x:764,y:531,t:1526930351153};\\\", \\\"{x:780,y:527,t:1526930351170};\\\", \\\"{x:792,y:524,t:1526930351188};\\\", \\\"{x:798,y:522,t:1526930351203};\\\", \\\"{x:804,y:521,t:1526930351220};\\\", \\\"{x:804,y:520,t:1526930351236};\\\", \\\"{x:805,y:520,t:1526930351286};\\\", \\\"{x:805,y:519,t:1526930351293};\\\", \\\"{x:807,y:519,t:1526930351304};\\\", \\\"{x:808,y:517,t:1526930351322};\\\", \\\"{x:810,y:517,t:1526930351337};\\\", \\\"{x:811,y:517,t:1526930351353};\\\", \\\"{x:813,y:515,t:1526930351380};\\\", \\\"{x:814,y:515,t:1526930351396};\\\", \\\"{x:815,y:515,t:1526930351412};\\\", \\\"{x:816,y:515,t:1526930351429};\\\", \\\"{x:818,y:513,t:1526930351445};\\\", \\\"{x:820,y:513,t:1526930351454};\\\", \\\"{x:825,y:511,t:1526930351471};\\\", \\\"{x:833,y:510,t:1526930351488};\\\", \\\"{x:836,y:510,t:1526930351504};\\\", \\\"{x:837,y:510,t:1526930351521};\\\", \\\"{x:839,y:510,t:1526930351541};\\\", \\\"{x:840,y:511,t:1526930351573};\\\", \\\"{x:840,y:514,t:1526930351588};\\\", \\\"{x:840,y:517,t:1526930351603};\\\", \\\"{x:840,y:521,t:1526930351622};\\\", \\\"{x:840,y:525,t:1526930351639};\\\", \\\"{x:840,y:529,t:1526930351654};\\\", \\\"{x:839,y:530,t:1526930351693};\\\", \\\"{x:838,y:530,t:1526930351704};\\\", \\\"{x:837,y:531,t:1526930351721};\\\", \\\"{x:837,y:532,t:1526930351737};\\\", \\\"{x:836,y:533,t:1526930351754};\\\", \\\"{x:835,y:534,t:1526930351770};\\\", \\\"{x:831,y:537,t:1526930352299};\\\", \\\"{x:828,y:539,t:1526930352308};\\\", \\\"{x:819,y:544,t:1526930352321};\\\", \\\"{x:803,y:554,t:1526930352337};\\\", \\\"{x:789,y:563,t:1526930352355};\\\", \\\"{x:773,y:571,t:1526930352372};\\\", \\\"{x:758,y:580,t:1526930352388};\\\", \\\"{x:733,y:590,t:1526930352404};\\\", \\\"{x:715,y:598,t:1526930352422};\\\", \\\"{x:710,y:601,t:1526930352439};\\\", \\\"{x:702,y:606,t:1526930352454};\\\", \\\"{x:691,y:613,t:1526930352471};\\\", \\\"{x:684,y:618,t:1526930352488};\\\", \\\"{x:678,y:621,t:1526930352505};\\\", \\\"{x:672,y:624,t:1526930352521};\\\", \\\"{x:670,y:625,t:1526930352537};\\\", \\\"{x:657,y:632,t:1526930352555};\\\", \\\"{x:627,y:640,t:1526930352572};\\\", \\\"{x:598,y:648,t:1526930352588};\\\", \\\"{x:585,y:655,t:1526930352604};\\\", \\\"{x:573,y:660,t:1526930352622};\\\", \\\"{x:544,y:666,t:1526930352638};\\\", \\\"{x:500,y:682,t:1526930352654};\\\", \\\"{x:428,y:702,t:1526930352672};\\\", \\\"{x:397,y:710,t:1526930352689};\\\", \\\"{x:377,y:718,t:1526930352705};\\\", \\\"{x:372,y:719,t:1526930352722};\\\", \\\"{x:372,y:720,t:1526930352790};\\\", \\\"{x:373,y:721,t:1526930352813};\\\", \\\"{x:374,y:721,t:1526930352829};\\\", \\\"{x:375,y:721,t:1526930352839};\\\", \\\"{x:380,y:721,t:1526930352855};\\\", \\\"{x:387,y:721,t:1526930352872};\\\", \\\"{x:404,y:721,t:1526930352889};\\\", \\\"{x:426,y:721,t:1526930352906};\\\", \\\"{x:452,y:721,t:1526930352923};\\\", \\\"{x:478,y:723,t:1526930352939};\\\", \\\"{x:502,y:728,t:1526930352954};\\\", \\\"{x:509,y:730,t:1526930352971};\\\", \\\"{x:512,y:731,t:1526930352988};\\\", \\\"{x:512,y:732,t:1526930353077};\\\", \\\"{x:513,y:732,t:1526930354021};\\\", \\\"{x:513,y:731,t:1526930354126};\\\", \\\"{x:513,y:730,t:1526930354149};\\\", \\\"{x:513,y:729,t:1526930354165};\\\", \\\"{x:513,y:728,t:1526930354197};\\\", \\\"{x:513,y:727,t:1526930354253};\\\", \\\"{x:513,y:726,t:1526930354293};\\\", \\\"{x:513,y:725,t:1526930354309};\\\", \\\"{x:513,y:724,t:1526930354341};\\\", \\\"{x:513,y:723,t:1526930354356};\\\", \\\"{x:513,y:722,t:1526930354376};\\\", \\\"{x:513,y:721,t:1526930354396};\\\", \\\"{x:513,y:720,t:1526930354406};\\\", \\\"{x:513,y:719,t:1526930354428};\\\", \\\"{x:514,y:718,t:1526930354440};\\\" ] }, { \\\"rt\\\": 20408, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 698437, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -M -Z -Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:718,t:1526930354574};\\\", \\\"{x:516,y:718,t:1526930354637};\\\", \\\"{x:516,y:717,t:1526930354645};\\\", \\\"{x:517,y:716,t:1526930354656};\\\", \\\"{x:517,y:714,t:1526930354684};\\\", \\\"{x:518,y:713,t:1526930354708};\\\", \\\"{x:518,y:712,t:1526930354749};\\\", \\\"{x:518,y:711,t:1526930354783};\\\", \\\"{x:519,y:711,t:1526930354806};\\\", \\\"{x:519,y:710,t:1526930354916};\\\", \\\"{x:519,y:708,t:1526930355031};\\\", \\\"{x:519,y:707,t:1526930355132};\\\", \\\"{x:519,y:706,t:1526930355148};\\\", \\\"{x:518,y:706,t:1526930355220};\\\", \\\"{x:523,y:706,t:1526930357870};\\\", \\\"{x:535,y:706,t:1526930357877};\\\", \\\"{x:563,y:711,t:1526930357893};\\\", \\\"{x:716,y:724,t:1526930357909};\\\", \\\"{x:835,y:741,t:1526930357926};\\\", \\\"{x:926,y:754,t:1526930357942};\\\", \\\"{x:984,y:766,t:1526930357960};\\\", \\\"{x:1063,y:776,t:1526930357978};\\\", \\\"{x:1152,y:786,t:1526930357993};\\\", \\\"{x:1234,y:795,t:1526930358009};\\\", \\\"{x:1299,y:795,t:1526930358026};\\\", \\\"{x:1379,y:795,t:1526930358044};\\\", \\\"{x:1458,y:795,t:1526930358059};\\\", \\\"{x:1515,y:797,t:1526930358076};\\\", \\\"{x:1659,y:797,t:1526930358094};\\\", \\\"{x:1741,y:803,t:1526930358109};\\\", \\\"{x:1822,y:803,t:1526930358126};\\\", \\\"{x:1867,y:803,t:1526930358143};\\\", \\\"{x:1885,y:802,t:1526930358159};\\\", \\\"{x:1886,y:801,t:1526930358178};\\\", \\\"{x:1889,y:799,t:1526930358194};\\\", \\\"{x:1891,y:797,t:1526930358209};\\\", \\\"{x:1895,y:791,t:1526930358227};\\\", \\\"{x:1902,y:775,t:1526930358244};\\\", \\\"{x:1918,y:738,t:1526930358259};\\\", \\\"{x:1919,y:713,t:1526930358276};\\\", \\\"{x:1919,y:677,t:1526930358292};\\\", \\\"{x:1919,y:645,t:1526930358310};\\\", \\\"{x:1919,y:597,t:1526930358325};\\\", \\\"{x:1919,y:530,t:1526930358342};\\\", \\\"{x:1918,y:490,t:1526930358360};\\\", \\\"{x:1913,y:470,t:1526930358376};\\\", \\\"{x:1913,y:455,t:1526930358393};\\\", \\\"{x:1915,y:440,t:1526930358410};\\\", \\\"{x:1916,y:430,t:1526930358425};\\\", \\\"{x:1918,y:423,t:1526930358443};\\\", \\\"{x:1919,y:417,t:1526930358460};\\\", \\\"{x:1919,y:415,t:1526930358476};\\\", \\\"{x:1919,y:410,t:1526930358493};\\\", \\\"{x:1919,y:409,t:1526930358510};\\\", \\\"{x:1919,y:407,t:1526930358566};\\\", \\\"{x:1911,y:403,t:1526930358577};\\\", \\\"{x:1900,y:393,t:1526930358593};\\\", \\\"{x:1876,y:377,t:1526930358609};\\\", \\\"{x:1857,y:360,t:1526930358626};\\\", \\\"{x:1823,y:344,t:1526930358643};\\\", \\\"{x:1803,y:333,t:1526930358660};\\\", \\\"{x:1768,y:318,t:1526930358676};\\\", \\\"{x:1743,y:308,t:1526930358693};\\\", \\\"{x:1729,y:303,t:1526930358710};\\\", \\\"{x:1707,y:301,t:1526930358727};\\\", \\\"{x:1697,y:301,t:1526930358743};\\\", \\\"{x:1686,y:299,t:1526930358760};\\\", \\\"{x:1676,y:293,t:1526930358777};\\\", \\\"{x:1665,y:285,t:1526930358793};\\\", \\\"{x:1658,y:281,t:1526930358810};\\\", \\\"{x:1656,y:281,t:1526930358827};\\\", \\\"{x:1654,y:281,t:1526930358843};\\\", \\\"{x:1652,y:281,t:1526930358860};\\\", \\\"{x:1642,y:281,t:1526930358877};\\\", \\\"{x:1629,y:284,t:1526930358893};\\\", \\\"{x:1608,y:290,t:1526930358910};\\\", \\\"{x:1582,y:295,t:1526930358927};\\\", \\\"{x:1557,y:304,t:1526930358944};\\\", \\\"{x:1537,y:309,t:1526930358960};\\\", \\\"{x:1524,y:318,t:1526930358977};\\\", \\\"{x:1514,y:324,t:1526930358993};\\\", \\\"{x:1507,y:328,t:1526930359010};\\\", \\\"{x:1501,y:334,t:1526930359027};\\\", \\\"{x:1496,y:344,t:1526930359043};\\\", \\\"{x:1492,y:360,t:1526930359060};\\\", \\\"{x:1487,y:387,t:1526930359077};\\\", \\\"{x:1482,y:415,t:1526930359094};\\\", \\\"{x:1477,y:442,t:1526930359111};\\\", \\\"{x:1474,y:464,t:1526930359127};\\\", \\\"{x:1468,y:487,t:1526930359144};\\\", \\\"{x:1458,y:524,t:1526930359160};\\\", \\\"{x:1444,y:545,t:1526930359177};\\\", \\\"{x:1426,y:574,t:1526930359195};\\\", \\\"{x:1407,y:603,t:1526930359210};\\\", \\\"{x:1388,y:641,t:1526930359227};\\\", \\\"{x:1366,y:673,t:1526930359245};\\\", \\\"{x:1358,y:685,t:1526930359261};\\\", \\\"{x:1354,y:691,t:1526930359277};\\\", \\\"{x:1353,y:692,t:1526930359294};\\\", \\\"{x:1351,y:693,t:1526930359313};\\\", \\\"{x:1347,y:695,t:1526930359327};\\\", \\\"{x:1338,y:697,t:1526930359344};\\\", \\\"{x:1325,y:705,t:1526930359360};\\\", \\\"{x:1310,y:712,t:1526930359377};\\\", \\\"{x:1298,y:718,t:1526930359394};\\\", \\\"{x:1290,y:722,t:1526930359410};\\\", \\\"{x:1281,y:724,t:1526930359426};\\\", \\\"{x:1274,y:727,t:1526930359444};\\\", \\\"{x:1258,y:733,t:1526930359460};\\\", \\\"{x:1236,y:742,t:1526930359476};\\\", \\\"{x:1218,y:747,t:1526930359494};\\\", \\\"{x:1198,y:756,t:1526930359510};\\\", \\\"{x:1184,y:761,t:1526930359527};\\\", \\\"{x:1178,y:762,t:1526930359544};\\\", \\\"{x:1174,y:764,t:1526930359561};\\\", \\\"{x:1171,y:764,t:1526930359577};\\\", \\\"{x:1170,y:770,t:1526930359594};\\\", \\\"{x:1169,y:783,t:1526930359610};\\\", \\\"{x:1169,y:785,t:1526930359627};\\\", \\\"{x:1170,y:793,t:1526930359644};\\\", \\\"{x:1179,y:806,t:1526930359661};\\\", \\\"{x:1186,y:811,t:1526930359677};\\\", \\\"{x:1192,y:816,t:1526930359694};\\\", \\\"{x:1205,y:826,t:1526930359711};\\\", \\\"{x:1221,y:831,t:1526930359727};\\\", \\\"{x:1238,y:842,t:1526930359744};\\\", \\\"{x:1249,y:850,t:1526930359761};\\\", \\\"{x:1257,y:853,t:1526930359778};\\\", \\\"{x:1263,y:857,t:1526930359794};\\\", \\\"{x:1270,y:860,t:1526930359812};\\\", \\\"{x:1274,y:861,t:1526930359827};\\\", \\\"{x:1277,y:865,t:1526930359844};\\\", \\\"{x:1283,y:868,t:1526930359861};\\\", \\\"{x:1285,y:868,t:1526930359877};\\\", \\\"{x:1290,y:871,t:1526930359895};\\\", \\\"{x:1296,y:872,t:1526930359911};\\\", \\\"{x:1304,y:876,t:1526930359928};\\\", \\\"{x:1312,y:879,t:1526930359944};\\\", \\\"{x:1323,y:883,t:1526930359961};\\\", \\\"{x:1330,y:886,t:1526930359978};\\\", \\\"{x:1334,y:886,t:1526930359994};\\\", \\\"{x:1344,y:888,t:1526930360011};\\\", \\\"{x:1359,y:888,t:1526930360028};\\\", \\\"{x:1367,y:888,t:1526930360044};\\\", \\\"{x:1379,y:888,t:1526930360061};\\\", \\\"{x:1382,y:888,t:1526930360078};\\\", \\\"{x:1383,y:887,t:1526930360094};\\\", \\\"{x:1384,y:887,t:1526930360117};\\\", \\\"{x:1386,y:887,t:1526930360129};\\\", \\\"{x:1390,y:884,t:1526930360144};\\\", \\\"{x:1394,y:879,t:1526930360162};\\\", \\\"{x:1399,y:874,t:1526930360179};\\\", \\\"{x:1405,y:868,t:1526930360195};\\\", \\\"{x:1408,y:860,t:1526930360211};\\\", \\\"{x:1415,y:847,t:1526930360228};\\\", \\\"{x:1416,y:841,t:1526930360244};\\\", \\\"{x:1416,y:840,t:1526930360341};\\\", \\\"{x:1417,y:838,t:1526930360349};\\\", \\\"{x:1418,y:837,t:1526930360361};\\\", \\\"{x:1419,y:837,t:1526930360398};\\\", \\\"{x:1422,y:834,t:1526930360411};\\\", \\\"{x:1427,y:829,t:1526930360428};\\\", \\\"{x:1431,y:823,t:1526930360445};\\\", \\\"{x:1440,y:815,t:1526930360461};\\\", \\\"{x:1448,y:808,t:1526930360479};\\\", \\\"{x:1462,y:802,t:1526930360495};\\\", \\\"{x:1476,y:794,t:1526930360511};\\\", \\\"{x:1486,y:788,t:1526930360529};\\\", \\\"{x:1491,y:785,t:1526930360545};\\\", \\\"{x:1493,y:783,t:1526930360561};\\\", \\\"{x:1496,y:782,t:1526930360579};\\\", \\\"{x:1498,y:780,t:1526930360595};\\\", \\\"{x:1500,y:778,t:1526930360612};\\\", \\\"{x:1502,y:776,t:1526930360628};\\\", \\\"{x:1504,y:773,t:1526930360645};\\\", \\\"{x:1505,y:776,t:1526930360710};\\\", \\\"{x:1505,y:782,t:1526930360718};\\\", \\\"{x:1507,y:785,t:1526930360729};\\\", \\\"{x:1510,y:792,t:1526930360746};\\\", \\\"{x:1510,y:797,t:1526930360761};\\\", \\\"{x:1510,y:803,t:1526930360778};\\\", \\\"{x:1510,y:808,t:1526930360795};\\\", \\\"{x:1510,y:815,t:1526930360811};\\\", \\\"{x:1502,y:831,t:1526930360828};\\\", \\\"{x:1497,y:836,t:1526930360844};\\\", \\\"{x:1495,y:839,t:1526930360861};\\\", \\\"{x:1493,y:840,t:1526930360878};\\\", \\\"{x:1492,y:842,t:1526930360895};\\\", \\\"{x:1491,y:843,t:1526930360916};\\\", \\\"{x:1490,y:844,t:1526930360928};\\\", \\\"{x:1489,y:844,t:1526930360945};\\\", \\\"{x:1487,y:845,t:1526930360961};\\\", \\\"{x:1486,y:845,t:1526930360989};\\\", \\\"{x:1489,y:846,t:1526930361117};\\\", \\\"{x:1493,y:846,t:1526930361129};\\\", \\\"{x:1516,y:846,t:1526930361145};\\\", \\\"{x:1553,y:847,t:1526930361162};\\\", \\\"{x:1603,y:847,t:1526930361179};\\\", \\\"{x:1637,y:847,t:1526930361195};\\\", \\\"{x:1657,y:847,t:1526930361212};\\\", \\\"{x:1674,y:847,t:1526930361229};\\\", \\\"{x:1681,y:847,t:1526930361245};\\\", \\\"{x:1682,y:846,t:1526930361262};\\\", \\\"{x:1683,y:846,t:1526930361301};\\\", \\\"{x:1684,y:846,t:1526930361312};\\\", \\\"{x:1686,y:846,t:1526930361329};\\\", \\\"{x:1687,y:845,t:1526930361345};\\\", \\\"{x:1691,y:843,t:1526930361363};\\\", \\\"{x:1693,y:843,t:1526930361382};\\\", \\\"{x:1695,y:842,t:1526930361395};\\\", \\\"{x:1701,y:842,t:1526930361412};\\\", \\\"{x:1711,y:840,t:1526930361429};\\\", \\\"{x:1719,y:839,t:1526930361445};\\\", \\\"{x:1723,y:838,t:1526930361462};\\\", \\\"{x:1730,y:837,t:1526930361479};\\\", \\\"{x:1732,y:836,t:1526930361496};\\\", \\\"{x:1734,y:836,t:1526930361512};\\\", \\\"{x:1735,y:836,t:1526930361573};\\\", \\\"{x:1736,y:836,t:1526930361590};\\\", \\\"{x:1737,y:836,t:1526930361597};\\\", \\\"{x:1737,y:835,t:1526930361813};\\\", \\\"{x:1737,y:832,t:1526930361829};\\\", \\\"{x:1737,y:831,t:1526930361846};\\\", \\\"{x:1737,y:828,t:1526930361863};\\\", \\\"{x:1736,y:825,t:1526930361879};\\\", \\\"{x:1734,y:820,t:1526930361896};\\\", \\\"{x:1731,y:817,t:1526930361913};\\\", \\\"{x:1729,y:813,t:1526930361930};\\\", \\\"{x:1725,y:809,t:1526930361946};\\\", \\\"{x:1721,y:805,t:1526930361963};\\\", \\\"{x:1718,y:801,t:1526930361979};\\\", \\\"{x:1715,y:797,t:1526930361997};\\\", \\\"{x:1710,y:790,t:1526930362012};\\\", \\\"{x:1701,y:781,t:1526930362029};\\\", \\\"{x:1695,y:773,t:1526930362047};\\\", \\\"{x:1689,y:767,t:1526930362063};\\\", \\\"{x:1684,y:761,t:1526930362079};\\\", \\\"{x:1678,y:754,t:1526930362096};\\\", \\\"{x:1671,y:747,t:1526930362112};\\\", \\\"{x:1665,y:741,t:1526930362129};\\\", \\\"{x:1656,y:736,t:1526930362147};\\\", \\\"{x:1649,y:730,t:1526930362163};\\\", \\\"{x:1642,y:726,t:1526930362180};\\\", \\\"{x:1638,y:723,t:1526930362197};\\\", \\\"{x:1629,y:723,t:1526930362213};\\\", \\\"{x:1627,y:723,t:1526930362229};\\\", \\\"{x:1624,y:722,t:1526930362252};\\\", \\\"{x:1623,y:721,t:1526930362284};\\\", \\\"{x:1621,y:720,t:1526930362296};\\\", \\\"{x:1619,y:719,t:1526930362312};\\\", \\\"{x:1618,y:717,t:1526930362329};\\\", \\\"{x:1616,y:716,t:1526930362346};\\\", \\\"{x:1616,y:715,t:1526930362362};\\\", \\\"{x:1615,y:714,t:1526930362379};\\\", \\\"{x:1614,y:711,t:1526930362397};\\\", \\\"{x:1613,y:709,t:1526930362413};\\\", \\\"{x:1613,y:707,t:1526930362430};\\\", \\\"{x:1613,y:704,t:1526930362446};\\\", \\\"{x:1613,y:701,t:1526930362465};\\\", \\\"{x:1613,y:700,t:1526930362480};\\\", \\\"{x:1613,y:699,t:1526930362496};\\\", \\\"{x:1612,y:697,t:1526930362513};\\\", \\\"{x:1612,y:696,t:1526930362645};\\\", \\\"{x:1610,y:696,t:1526930365854};\\\", \\\"{x:1610,y:697,t:1526930365869};\\\", \\\"{x:1609,y:698,t:1526930365883};\\\", \\\"{x:1609,y:699,t:1526930365898};\\\", \\\"{x:1607,y:700,t:1526930365934};\\\", \\\"{x:1607,y:702,t:1526930365949};\\\", \\\"{x:1606,y:704,t:1526930365965};\\\", \\\"{x:1604,y:706,t:1526930365983};\\\", \\\"{x:1603,y:709,t:1526930365999};\\\", \\\"{x:1603,y:710,t:1526930366015};\\\", \\\"{x:1603,y:712,t:1526930366032};\\\", \\\"{x:1602,y:713,t:1526930366049};\\\", \\\"{x:1601,y:714,t:1526930366066};\\\", \\\"{x:1599,y:716,t:1526930366082};\\\", \\\"{x:1599,y:717,t:1526930366099};\\\", \\\"{x:1598,y:717,t:1526930366116};\\\", \\\"{x:1598,y:718,t:1526930366157};\\\", \\\"{x:1599,y:715,t:1526930366397};\\\", \\\"{x:1600,y:715,t:1526930366405};\\\", \\\"{x:1601,y:714,t:1526930366416};\\\", \\\"{x:1601,y:713,t:1526930366432};\\\", \\\"{x:1603,y:709,t:1526930366450};\\\", \\\"{x:1607,y:705,t:1526930366466};\\\", \\\"{x:1607,y:704,t:1526930366483};\\\", \\\"{x:1609,y:703,t:1526930366499};\\\", \\\"{x:1610,y:701,t:1526930366516};\\\", \\\"{x:1611,y:700,t:1526930366533};\\\", \\\"{x:1611,y:699,t:1526930366550};\\\", \\\"{x:1612,y:698,t:1526930366565};\\\", \\\"{x:1612,y:696,t:1526930366582};\\\", \\\"{x:1613,y:695,t:1526930366621};\\\", \\\"{x:1614,y:694,t:1526930366653};\\\", \\\"{x:1614,y:693,t:1526930366668};\\\", \\\"{x:1615,y:692,t:1526930366684};\\\", \\\"{x:1615,y:693,t:1526930367381};\\\", \\\"{x:1615,y:694,t:1526930367397};\\\", \\\"{x:1615,y:695,t:1526930367412};\\\", \\\"{x:1615,y:696,t:1526930367453};\\\", \\\"{x:1615,y:697,t:1526930367467};\\\", \\\"{x:1615,y:698,t:1526930367483};\\\", \\\"{x:1615,y:699,t:1526930367500};\\\", \\\"{x:1613,y:703,t:1526930367518};\\\", \\\"{x:1613,y:705,t:1526930367533};\\\", \\\"{x:1611,y:708,t:1526930367549};\\\", \\\"{x:1609,y:711,t:1526930367567};\\\", \\\"{x:1607,y:714,t:1526930367584};\\\", \\\"{x:1606,y:719,t:1526930367600};\\\", \\\"{x:1604,y:722,t:1526930367617};\\\", \\\"{x:1603,y:722,t:1526930367634};\\\", \\\"{x:1599,y:726,t:1526930367651};\\\", \\\"{x:1597,y:730,t:1526930367667};\\\", \\\"{x:1593,y:738,t:1526930367683};\\\", \\\"{x:1588,y:745,t:1526930367701};\\\", \\\"{x:1587,y:748,t:1526930367717};\\\", \\\"{x:1584,y:752,t:1526930367733};\\\", \\\"{x:1581,y:757,t:1526930367750};\\\", \\\"{x:1576,y:763,t:1526930367767};\\\", \\\"{x:1571,y:769,t:1526930367785};\\\", \\\"{x:1568,y:777,t:1526930367801};\\\", \\\"{x:1564,y:787,t:1526930367816};\\\", \\\"{x:1560,y:799,t:1526930367833};\\\", \\\"{x:1553,y:813,t:1526930367850};\\\", \\\"{x:1545,y:827,t:1526930367866};\\\", \\\"{x:1540,y:838,t:1526930367884};\\\", \\\"{x:1530,y:857,t:1526930367900};\\\", \\\"{x:1524,y:871,t:1526930367916};\\\", \\\"{x:1517,y:881,t:1526930367933};\\\", \\\"{x:1513,y:892,t:1526930367950};\\\", \\\"{x:1509,y:902,t:1526930367966};\\\", \\\"{x:1506,y:912,t:1526930367983};\\\", \\\"{x:1501,y:921,t:1526930368001};\\\", \\\"{x:1496,y:930,t:1526930368017};\\\", \\\"{x:1494,y:939,t:1526930368033};\\\", \\\"{x:1492,y:948,t:1526930368050};\\\", \\\"{x:1489,y:954,t:1526930368067};\\\", \\\"{x:1488,y:958,t:1526930368083};\\\", \\\"{x:1486,y:961,t:1526930368101};\\\", \\\"{x:1485,y:964,t:1526930368118};\\\", \\\"{x:1484,y:965,t:1526930368134};\\\", \\\"{x:1481,y:967,t:1526930368151};\\\", \\\"{x:1481,y:968,t:1526930368173};\\\", \\\"{x:1479,y:967,t:1526930368653};\\\", \\\"{x:1479,y:965,t:1526930368669};\\\", \\\"{x:1478,y:962,t:1526930368685};\\\", \\\"{x:1476,y:955,t:1526930368701};\\\", \\\"{x:1475,y:950,t:1526930368718};\\\", \\\"{x:1471,y:942,t:1526930368735};\\\", \\\"{x:1464,y:933,t:1526930368751};\\\", \\\"{x:1455,y:919,t:1526930368768};\\\", \\\"{x:1444,y:899,t:1526930368785};\\\", \\\"{x:1430,y:880,t:1526930368801};\\\", \\\"{x:1417,y:862,t:1526930368818};\\\", \\\"{x:1403,y:842,t:1526930368835};\\\", \\\"{x:1398,y:830,t:1526930368851};\\\", \\\"{x:1392,y:815,t:1526930368868};\\\", \\\"{x:1382,y:793,t:1526930368885};\\\", \\\"{x:1376,y:774,t:1526930368901};\\\", \\\"{x:1371,y:757,t:1526930368918};\\\", \\\"{x:1367,y:743,t:1526930368934};\\\", \\\"{x:1363,y:736,t:1526930368951};\\\", \\\"{x:1363,y:734,t:1526930368968};\\\", \\\"{x:1363,y:732,t:1526930368984};\\\", \\\"{x:1361,y:729,t:1526930369001};\\\", \\\"{x:1360,y:727,t:1526930369018};\\\", \\\"{x:1359,y:726,t:1526930369035};\\\", \\\"{x:1357,y:724,t:1526930369051};\\\", \\\"{x:1356,y:722,t:1526930369068};\\\", \\\"{x:1355,y:720,t:1526930369085};\\\", \\\"{x:1354,y:719,t:1526930369101};\\\", \\\"{x:1354,y:718,t:1526930369118};\\\", \\\"{x:1352,y:716,t:1526930369135};\\\", \\\"{x:1350,y:712,t:1526930369152};\\\", \\\"{x:1346,y:707,t:1526930369168};\\\", \\\"{x:1343,y:703,t:1526930369185};\\\", \\\"{x:1342,y:698,t:1526930369202};\\\", \\\"{x:1339,y:695,t:1526930369219};\\\", \\\"{x:1338,y:693,t:1526930369235};\\\", \\\"{x:1338,y:691,t:1526930369252};\\\", \\\"{x:1337,y:689,t:1526930369268};\\\", \\\"{x:1336,y:686,t:1526930369285};\\\", \\\"{x:1336,y:685,t:1526930369309};\\\", \\\"{x:1336,y:684,t:1526930369318};\\\", \\\"{x:1335,y:682,t:1526930369422};\\\", \\\"{x:1334,y:679,t:1526930369501};\\\", \\\"{x:1334,y:678,t:1526930369758};\\\", \\\"{x:1334,y:677,t:1526930369773};\\\", \\\"{x:1334,y:676,t:1526930369797};\\\", \\\"{x:1334,y:675,t:1526930369829};\\\", \\\"{x:1334,y:674,t:1526930369965};\\\", \\\"{x:1333,y:674,t:1526930370013};\\\", \\\"{x:1333,y:673,t:1526930370028};\\\", \\\"{x:1333,y:671,t:1526930370053};\\\", \\\"{x:1332,y:667,t:1526930370069};\\\", \\\"{x:1328,y:662,t:1526930370084};\\\", \\\"{x:1326,y:655,t:1526930370102};\\\", \\\"{x:1321,y:646,t:1526930370119};\\\", \\\"{x:1317,y:639,t:1526930370136};\\\", \\\"{x:1312,y:630,t:1526930370153};\\\", \\\"{x:1308,y:622,t:1526930370169};\\\", \\\"{x:1306,y:616,t:1526930370186};\\\", \\\"{x:1300,y:607,t:1526930370201};\\\", \\\"{x:1297,y:602,t:1526930370219};\\\", \\\"{x:1293,y:598,t:1526930370236};\\\", \\\"{x:1291,y:594,t:1526930370252};\\\", \\\"{x:1289,y:593,t:1526930370269};\\\", \\\"{x:1288,y:592,t:1526930370420};\\\", \\\"{x:1277,y:591,t:1526930371077};\\\", \\\"{x:1262,y:585,t:1526930371085};\\\", \\\"{x:1198,y:566,t:1526930371103};\\\", \\\"{x:1158,y:558,t:1526930371120};\\\", \\\"{x:1122,y:549,t:1526930371136};\\\", \\\"{x:1075,y:538,t:1526930371153};\\\", \\\"{x:1000,y:527,t:1526930371169};\\\", \\\"{x:861,y:499,t:1526930371187};\\\", \\\"{x:697,y:468,t:1526930371202};\\\", \\\"{x:521,y:435,t:1526930371220};\\\", \\\"{x:315,y:381,t:1526930371236};\\\", \\\"{x:206,y:365,t:1526930371253};\\\", \\\"{x:162,y:359,t:1526930371270};\\\", \\\"{x:149,y:356,t:1526930371286};\\\", \\\"{x:148,y:358,t:1526930371332};\\\", \\\"{x:148,y:360,t:1526930371340};\\\", \\\"{x:148,y:362,t:1526930371353};\\\", \\\"{x:153,y:367,t:1526930371370};\\\", \\\"{x:158,y:373,t:1526930371386};\\\", \\\"{x:166,y:381,t:1526930371404};\\\", \\\"{x:203,y:405,t:1526930371420};\\\", \\\"{x:229,y:419,t:1526930371437};\\\", \\\"{x:262,y:436,t:1526930371453};\\\", \\\"{x:301,y:451,t:1526930371470};\\\", \\\"{x:344,y:464,t:1526930371487};\\\", \\\"{x:375,y:468,t:1526930371503};\\\", \\\"{x:391,y:468,t:1526930371521};\\\", \\\"{x:399,y:468,t:1526930371536};\\\", \\\"{x:401,y:467,t:1526930371557};\\\", \\\"{x:403,y:466,t:1526930371570};\\\", \\\"{x:406,y:466,t:1526930371587};\\\", \\\"{x:421,y:465,t:1526930371603};\\\", \\\"{x:457,y:470,t:1526930371621};\\\", \\\"{x:487,y:475,t:1526930371637};\\\", \\\"{x:496,y:476,t:1526930371653};\\\", \\\"{x:497,y:476,t:1526930371670};\\\", \\\"{x:498,y:476,t:1526930371693};\\\", \\\"{x:499,y:476,t:1526930371709};\\\", \\\"{x:500,y:476,t:1526930371721};\\\", \\\"{x:502,y:476,t:1526930371737};\\\", \\\"{x:506,y:476,t:1526930371753};\\\", \\\"{x:511,y:476,t:1526930371770};\\\", \\\"{x:514,y:476,t:1526930371787};\\\", \\\"{x:519,y:477,t:1526930371804};\\\", \\\"{x:520,y:478,t:1526930371829};\\\", \\\"{x:520,y:480,t:1526930371845};\\\", \\\"{x:521,y:482,t:1526930371854};\\\", \\\"{x:524,y:484,t:1526930371870};\\\", \\\"{x:534,y:489,t:1526930371889};\\\", \\\"{x:550,y:496,t:1526930371904};\\\", \\\"{x:568,y:504,t:1526930371919};\\\", \\\"{x:582,y:509,t:1526930371937};\\\", \\\"{x:587,y:511,t:1526930371953};\\\", \\\"{x:590,y:512,t:1526930371969};\\\", \\\"{x:592,y:513,t:1526930372021};\\\", \\\"{x:593,y:513,t:1526930372037};\\\", \\\"{x:594,y:514,t:1526930372053};\\\", \\\"{x:596,y:514,t:1526930372149};\\\", \\\"{x:597,y:513,t:1526930372156};\\\", \\\"{x:599,y:513,t:1526930372169};\\\", \\\"{x:601,y:511,t:1526930372188};\\\", \\\"{x:604,y:510,t:1526930372202};\\\", \\\"{x:604,y:509,t:1526930372220};\\\", \\\"{x:607,y:508,t:1526930372419};\\\", \\\"{x:617,y:508,t:1526930372428};\\\", \\\"{x:635,y:508,t:1526930372437};\\\", \\\"{x:665,y:508,t:1526930372454};\\\", \\\"{x:690,y:508,t:1526930372471};\\\", \\\"{x:704,y:508,t:1526930372487};\\\", \\\"{x:716,y:506,t:1526930372504};\\\", \\\"{x:719,y:506,t:1526930372521};\\\", \\\"{x:722,y:503,t:1526930372537};\\\", \\\"{x:731,y:501,t:1526930372555};\\\", \\\"{x:743,y:498,t:1526930372571};\\\", \\\"{x:763,y:498,t:1526930372587};\\\", \\\"{x:784,y:498,t:1526930372604};\\\", \\\"{x:785,y:498,t:1526930372621};\\\", \\\"{x:787,y:499,t:1526930372733};\\\", \\\"{x:790,y:501,t:1526930372741};\\\", \\\"{x:797,y:504,t:1526930372755};\\\", \\\"{x:818,y:512,t:1526930372772};\\\", \\\"{x:839,y:523,t:1526930372789};\\\", \\\"{x:880,y:532,t:1526930372805};\\\", \\\"{x:895,y:535,t:1526930372821};\\\", \\\"{x:897,y:535,t:1526930372838};\\\", \\\"{x:897,y:532,t:1526930372854};\\\", \\\"{x:888,y:525,t:1526930372871};\\\", \\\"{x:884,y:522,t:1526930372889};\\\", \\\"{x:882,y:522,t:1526930372905};\\\", \\\"{x:880,y:520,t:1526930372932};\\\", \\\"{x:877,y:520,t:1526930372940};\\\", \\\"{x:874,y:519,t:1526930372954};\\\", \\\"{x:849,y:514,t:1526930372971};\\\", \\\"{x:831,y:510,t:1526930372987};\\\", \\\"{x:810,y:507,t:1526930373005};\\\", \\\"{x:803,y:507,t:1526930373021};\\\", \\\"{x:801,y:507,t:1526930373038};\\\", \\\"{x:801,y:506,t:1526930373245};\\\", \\\"{x:806,y:505,t:1526930373317};\\\", \\\"{x:808,y:504,t:1526930373324};\\\", \\\"{x:813,y:504,t:1526930373339};\\\", \\\"{x:818,y:504,t:1526930373354};\\\", \\\"{x:835,y:504,t:1526930373373};\\\", \\\"{x:848,y:504,t:1526930373389};\\\", \\\"{x:850,y:504,t:1526930373404};\\\", \\\"{x:852,y:503,t:1526930373476};\\\", \\\"{x:851,y:503,t:1526930374020};\\\", \\\"{x:850,y:503,t:1526930374028};\\\", \\\"{x:848,y:503,t:1526930374038};\\\", \\\"{x:846,y:504,t:1526930374100};\\\", \\\"{x:846,y:505,t:1526930374116};\\\", \\\"{x:843,y:507,t:1526930374124};\\\", \\\"{x:840,y:511,t:1526930374139};\\\", \\\"{x:827,y:519,t:1526930374156};\\\", \\\"{x:816,y:530,t:1526930374173};\\\", \\\"{x:806,y:537,t:1526930374188};\\\", \\\"{x:794,y:546,t:1526930374206};\\\", \\\"{x:785,y:555,t:1526930374222};\\\", \\\"{x:773,y:565,t:1526930374240};\\\", \\\"{x:757,y:577,t:1526930374255};\\\", \\\"{x:745,y:594,t:1526930374272};\\\", \\\"{x:730,y:611,t:1526930374290};\\\", \\\"{x:718,y:623,t:1526930374306};\\\", \\\"{x:713,y:628,t:1526930374322};\\\", \\\"{x:707,y:634,t:1526930374340};\\\", \\\"{x:703,y:642,t:1526930374355};\\\", \\\"{x:695,y:652,t:1526930374372};\\\", \\\"{x:687,y:663,t:1526930374389};\\\", \\\"{x:675,y:675,t:1526930374405};\\\", \\\"{x:658,y:686,t:1526930374423};\\\", \\\"{x:645,y:694,t:1526930374439};\\\", \\\"{x:636,y:700,t:1526930374455};\\\", \\\"{x:628,y:704,t:1526930374472};\\\", \\\"{x:622,y:707,t:1526930374489};\\\", \\\"{x:610,y:710,t:1526930374505};\\\", \\\"{x:600,y:714,t:1526930374522};\\\", \\\"{x:592,y:718,t:1526930374540};\\\", \\\"{x:580,y:719,t:1526930374556};\\\", \\\"{x:567,y:719,t:1526930374572};\\\", \\\"{x:558,y:719,t:1526930374589};\\\", \\\"{x:557,y:719,t:1526930374607};\\\", \\\"{x:555,y:719,t:1526930374622};\\\", \\\"{x:554,y:719,t:1526930374660};\\\", \\\"{x:551,y:719,t:1526930374676};\\\", \\\"{x:549,y:719,t:1526930374689};\\\", \\\"{x:543,y:722,t:1526930374707};\\\", \\\"{x:533,y:724,t:1526930374722};\\\", \\\"{x:529,y:724,t:1526930374739};\\\", \\\"{x:526,y:724,t:1526930374755};\\\", \\\"{x:524,y:724,t:1526930374821};\\\", \\\"{x:523,y:724,t:1526930374837};\\\", \\\"{x:523,y:725,t:1526930374852};\\\", \\\"{x:522,y:726,t:1526930374869};\\\", \\\"{x:522,y:727,t:1526930375164};\\\", \\\"{x:521,y:727,t:1526930375173};\\\", \\\"{x:521,y:728,t:1526930375317};\\\", \\\"{x:522,y:728,t:1526930375581};\\\", \\\"{x:523,y:727,t:1526930375605};\\\", \\\"{x:523,y:726,t:1526930375620};\\\", \\\"{x:524,y:725,t:1526930375653};\\\", \\\"{x:525,y:724,t:1526930375676};\\\", \\\"{x:525,y:723,t:1526930375692};\\\", \\\"{x:526,y:722,t:1526930375716};\\\", \\\"{x:526,y:721,t:1526930375732};\\\", \\\"{x:527,y:720,t:1526930375765};\\\", \\\"{x:527,y:719,t:1526930375796};\\\", \\\"{x:528,y:719,t:1526930375807};\\\", \\\"{x:528,y:718,t:1526930375829};\\\", \\\"{x:529,y:717,t:1526930375852};\\\", \\\"{x:529,y:716,t:1526930375884};\\\", \\\"{x:530,y:716,t:1526930375900};\\\", \\\"{x:530,y:715,t:1526930375933};\\\", \\\"{x:531,y:714,t:1526930375989};\\\", \\\"{x:532,y:713,t:1526930376007};\\\" ] }, { \\\"rt\\\": 8823, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 708468, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:712,t:1526930376208};\\\", \\\"{x:534,y:711,t:1526930378461};\\\", \\\"{x:535,y:710,t:1526930378476};\\\", \\\"{x:536,y:710,t:1526930378493};\\\", \\\"{x:539,y:708,t:1526930378509};\\\", \\\"{x:543,y:707,t:1526930378526};\\\", \\\"{x:574,y:716,t:1526930378544};\\\", \\\"{x:677,y:738,t:1526930378559};\\\", \\\"{x:829,y:782,t:1526930378576};\\\", \\\"{x:929,y:812,t:1526930378593};\\\", \\\"{x:1054,y:852,t:1526930378610};\\\", \\\"{x:1095,y:867,t:1526930378626};\\\", \\\"{x:1110,y:874,t:1526930378643};\\\", \\\"{x:1112,y:874,t:1526930378660};\\\", \\\"{x:1114,y:874,t:1526930378677};\\\", \\\"{x:1119,y:873,t:1526930378693};\\\", \\\"{x:1123,y:871,t:1526930378710};\\\", \\\"{x:1129,y:870,t:1526930378726};\\\", \\\"{x:1135,y:868,t:1526930378743};\\\", \\\"{x:1142,y:868,t:1526930378760};\\\", \\\"{x:1157,y:868,t:1526930378776};\\\", \\\"{x:1169,y:868,t:1526930378793};\\\", \\\"{x:1185,y:867,t:1526930378810};\\\", \\\"{x:1196,y:866,t:1526930378826};\\\", \\\"{x:1205,y:866,t:1526930378844};\\\", \\\"{x:1209,y:865,t:1526930378860};\\\", \\\"{x:1222,y:865,t:1526930378877};\\\", \\\"{x:1235,y:869,t:1526930378893};\\\", \\\"{x:1247,y:874,t:1526930378910};\\\", \\\"{x:1265,y:881,t:1526930378927};\\\", \\\"{x:1285,y:888,t:1526930378943};\\\", \\\"{x:1301,y:891,t:1526930378960};\\\", \\\"{x:1311,y:898,t:1526930378977};\\\", \\\"{x:1321,y:900,t:1526930378993};\\\", \\\"{x:1327,y:903,t:1526930379010};\\\", \\\"{x:1328,y:903,t:1526930379027};\\\", \\\"{x:1329,y:904,t:1526930379042};\\\", \\\"{x:1327,y:904,t:1526930379116};\\\", \\\"{x:1321,y:904,t:1526930379126};\\\", \\\"{x:1311,y:904,t:1526930379142};\\\", \\\"{x:1308,y:903,t:1526930379159};\\\", \\\"{x:1299,y:902,t:1526930379176};\\\", \\\"{x:1294,y:902,t:1526930379192};\\\", \\\"{x:1292,y:902,t:1526930379210};\\\", \\\"{x:1296,y:902,t:1526930379285};\\\", \\\"{x:1300,y:902,t:1526930379293};\\\", \\\"{x:1317,y:902,t:1526930379310};\\\", \\\"{x:1344,y:907,t:1526930379327};\\\", \\\"{x:1376,y:920,t:1526930379344};\\\", \\\"{x:1402,y:938,t:1526930379360};\\\", \\\"{x:1425,y:949,t:1526930379377};\\\", \\\"{x:1442,y:955,t:1526930379394};\\\", \\\"{x:1450,y:959,t:1526930379410};\\\", \\\"{x:1451,y:959,t:1526930379427};\\\", \\\"{x:1452,y:959,t:1526930379469};\\\", \\\"{x:1453,y:959,t:1526930379485};\\\", \\\"{x:1454,y:959,t:1526930379500};\\\", \\\"{x:1455,y:959,t:1526930379510};\\\", \\\"{x:1457,y:959,t:1526930379540};\\\", \\\"{x:1459,y:959,t:1526930379549};\\\", \\\"{x:1462,y:959,t:1526930379560};\\\", \\\"{x:1466,y:959,t:1526930379577};\\\", \\\"{x:1470,y:959,t:1526930379594};\\\", \\\"{x:1473,y:959,t:1526930379610};\\\", \\\"{x:1487,y:959,t:1526930379626};\\\", \\\"{x:1503,y:959,t:1526930379644};\\\", \\\"{x:1513,y:959,t:1526930379660};\\\", \\\"{x:1521,y:959,t:1526930379676};\\\", \\\"{x:1528,y:959,t:1526930379694};\\\", \\\"{x:1530,y:958,t:1526930379709};\\\", \\\"{x:1531,y:958,t:1526930379773};\\\", \\\"{x:1532,y:958,t:1526930379837};\\\", \\\"{x:1533,y:958,t:1526930379885};\\\", \\\"{x:1534,y:958,t:1526930379957};\\\", \\\"{x:1534,y:959,t:1526930379965};\\\", \\\"{x:1535,y:961,t:1526930379977};\\\", \\\"{x:1535,y:962,t:1526930379994};\\\", \\\"{x:1536,y:963,t:1526930380046};\\\", \\\"{x:1537,y:963,t:1526930380077};\\\", \\\"{x:1538,y:963,t:1526930380100};\\\", \\\"{x:1539,y:963,t:1526930380117};\\\", \\\"{x:1540,y:963,t:1526930380166};\\\", \\\"{x:1540,y:961,t:1526930380229};\\\", \\\"{x:1540,y:953,t:1526930380244};\\\", \\\"{x:1534,y:943,t:1526930380260};\\\", \\\"{x:1526,y:931,t:1526930380278};\\\", \\\"{x:1520,y:923,t:1526930380294};\\\", \\\"{x:1508,y:910,t:1526930380311};\\\", \\\"{x:1501,y:903,t:1526930380329};\\\", \\\"{x:1499,y:900,t:1526930380344};\\\", \\\"{x:1497,y:897,t:1526930380360};\\\", \\\"{x:1496,y:893,t:1526930380378};\\\", \\\"{x:1494,y:890,t:1526930380393};\\\", \\\"{x:1493,y:888,t:1526930380411};\\\", \\\"{x:1492,y:888,t:1526930380428};\\\", \\\"{x:1490,y:886,t:1526930380444};\\\", \\\"{x:1490,y:885,t:1526930380460};\\\", \\\"{x:1490,y:884,t:1526930380477};\\\", \\\"{x:1490,y:883,t:1526930380494};\\\", \\\"{x:1489,y:881,t:1526930380510};\\\", \\\"{x:1487,y:877,t:1526930380528};\\\", \\\"{x:1485,y:873,t:1526930380544};\\\", \\\"{x:1478,y:859,t:1526930380560};\\\", \\\"{x:1472,y:850,t:1526930380578};\\\", \\\"{x:1467,y:844,t:1526930380594};\\\", \\\"{x:1466,y:840,t:1526930380611};\\\", \\\"{x:1464,y:837,t:1526930380628};\\\", \\\"{x:1464,y:834,t:1526930380644};\\\", \\\"{x:1464,y:832,t:1526930380676};\\\", \\\"{x:1463,y:831,t:1526930380741};\\\", \\\"{x:1463,y:830,t:1526930380765};\\\", \\\"{x:1463,y:829,t:1526930380846};\\\", \\\"{x:1463,y:827,t:1526930380885};\\\", \\\"{x:1463,y:826,t:1526930380925};\\\", \\\"{x:1462,y:825,t:1526930380932};\\\", \\\"{x:1461,y:825,t:1526930381029};\\\", \\\"{x:1459,y:825,t:1526930381045};\\\", \\\"{x:1457,y:826,t:1526930381063};\\\", \\\"{x:1457,y:827,t:1526930381078};\\\", \\\"{x:1457,y:830,t:1526930381095};\\\", \\\"{x:1455,y:834,t:1526930381112};\\\", \\\"{x:1455,y:836,t:1526930381128};\\\", \\\"{x:1454,y:838,t:1526930381146};\\\", \\\"{x:1454,y:841,t:1526930381162};\\\", \\\"{x:1454,y:844,t:1526930381178};\\\", \\\"{x:1455,y:848,t:1526930381195};\\\", \\\"{x:1459,y:853,t:1526930381212};\\\", \\\"{x:1461,y:854,t:1526930381228};\\\", \\\"{x:1472,y:860,t:1526930381244};\\\", \\\"{x:1477,y:864,t:1526930381262};\\\", \\\"{x:1482,y:869,t:1526930381278};\\\", \\\"{x:1486,y:873,t:1526930381295};\\\", \\\"{x:1490,y:877,t:1526930381313};\\\", \\\"{x:1494,y:882,t:1526930381328};\\\", \\\"{x:1497,y:886,t:1526930381345};\\\", \\\"{x:1498,y:888,t:1526930381363};\\\", \\\"{x:1498,y:889,t:1526930381378};\\\", \\\"{x:1499,y:892,t:1526930381395};\\\", \\\"{x:1503,y:897,t:1526930381412};\\\", \\\"{x:1506,y:903,t:1526930381428};\\\", \\\"{x:1508,y:906,t:1526930381446};\\\", \\\"{x:1511,y:909,t:1526930381462};\\\", \\\"{x:1511,y:912,t:1526930381478};\\\", \\\"{x:1513,y:915,t:1526930381495};\\\", \\\"{x:1514,y:916,t:1526930381512};\\\", \\\"{x:1515,y:918,t:1526930381529};\\\", \\\"{x:1516,y:919,t:1526930381546};\\\", \\\"{x:1518,y:918,t:1526930382148};\\\", \\\"{x:1519,y:915,t:1526930382164};\\\", \\\"{x:1519,y:914,t:1526930382179};\\\", \\\"{x:1520,y:904,t:1526930382196};\\\", \\\"{x:1521,y:899,t:1526930382212};\\\", \\\"{x:1521,y:878,t:1526930382229};\\\", \\\"{x:1520,y:859,t:1526930382246};\\\", \\\"{x:1513,y:847,t:1526930382262};\\\", \\\"{x:1509,y:838,t:1526930382278};\\\", \\\"{x:1505,y:830,t:1526930382296};\\\", \\\"{x:1496,y:820,t:1526930382312};\\\", \\\"{x:1486,y:812,t:1526930382329};\\\", \\\"{x:1477,y:804,t:1526930382346};\\\", \\\"{x:1469,y:797,t:1526930382363};\\\", \\\"{x:1463,y:794,t:1526930382379};\\\", \\\"{x:1459,y:790,t:1526930382397};\\\", \\\"{x:1457,y:785,t:1526930382413};\\\", \\\"{x:1453,y:778,t:1526930382429};\\\", \\\"{x:1447,y:769,t:1526930382446};\\\", \\\"{x:1442,y:762,t:1526930382463};\\\", \\\"{x:1435,y:749,t:1526930382479};\\\", \\\"{x:1429,y:730,t:1526930382496};\\\", \\\"{x:1419,y:713,t:1526930382513};\\\", \\\"{x:1412,y:698,t:1526930382529};\\\", \\\"{x:1407,y:686,t:1526930382546};\\\", \\\"{x:1403,y:681,t:1526930382563};\\\", \\\"{x:1399,y:673,t:1526930382579};\\\", \\\"{x:1393,y:650,t:1526930382597};\\\", \\\"{x:1390,y:639,t:1526930382613};\\\", \\\"{x:1385,y:624,t:1526930382630};\\\", \\\"{x:1378,y:614,t:1526930382646};\\\", \\\"{x:1372,y:607,t:1526930382663};\\\", \\\"{x:1370,y:602,t:1526930382679};\\\", \\\"{x:1367,y:596,t:1526930382697};\\\", \\\"{x:1364,y:592,t:1526930382713};\\\", \\\"{x:1362,y:587,t:1526930382730};\\\", \\\"{x:1360,y:581,t:1526930382746};\\\", \\\"{x:1358,y:578,t:1526930382763};\\\", \\\"{x:1354,y:568,t:1526930382781};\\\", \\\"{x:1344,y:555,t:1526930382796};\\\", \\\"{x:1339,y:551,t:1526930382813};\\\", \\\"{x:1333,y:547,t:1526930382830};\\\", \\\"{x:1328,y:542,t:1526930382846};\\\", \\\"{x:1323,y:538,t:1526930382864};\\\", \\\"{x:1318,y:533,t:1526930382881};\\\", \\\"{x:1315,y:530,t:1526930382896};\\\", \\\"{x:1312,y:529,t:1526930382913};\\\", \\\"{x:1310,y:527,t:1526930382930};\\\", \\\"{x:1309,y:526,t:1526930382946};\\\", \\\"{x:1308,y:525,t:1526930382989};\\\", \\\"{x:1307,y:524,t:1526930383005};\\\", \\\"{x:1307,y:523,t:1526930383013};\\\", \\\"{x:1303,y:520,t:1526930383030};\\\", \\\"{x:1300,y:519,t:1526930383046};\\\", \\\"{x:1297,y:517,t:1526930383062};\\\", \\\"{x:1286,y:515,t:1526930383079};\\\", \\\"{x:1263,y:512,t:1526930383096};\\\", \\\"{x:1225,y:510,t:1526930383113};\\\", \\\"{x:1185,y:510,t:1526930383129};\\\", \\\"{x:1120,y:510,t:1526930383146};\\\", \\\"{x:1023,y:510,t:1526930383163};\\\", \\\"{x:875,y:517,t:1526930383180};\\\", \\\"{x:765,y:525,t:1526930383197};\\\", \\\"{x:684,y:527,t:1526930383213};\\\", \\\"{x:643,y:539,t:1526930383245};\\\", \\\"{x:634,y:544,t:1526930383262};\\\", \\\"{x:627,y:547,t:1526930383279};\\\", \\\"{x:611,y:552,t:1526930383297};\\\", \\\"{x:587,y:561,t:1526930383313};\\\", \\\"{x:525,y:571,t:1526930383330};\\\", \\\"{x:474,y:580,t:1526930383347};\\\", \\\"{x:461,y:585,t:1526930383362};\\\", \\\"{x:452,y:589,t:1526930383379};\\\", \\\"{x:450,y:590,t:1526930383397};\\\", \\\"{x:449,y:591,t:1526930383420};\\\", \\\"{x:449,y:592,t:1526930383451};\\\", \\\"{x:450,y:592,t:1526930383463};\\\", \\\"{x:452,y:592,t:1526930383480};\\\", \\\"{x:465,y:592,t:1526930383497};\\\", \\\"{x:486,y:592,t:1526930383512};\\\", \\\"{x:509,y:594,t:1526930383530};\\\", \\\"{x:538,y:594,t:1526930383547};\\\", \\\"{x:561,y:594,t:1526930383563};\\\", \\\"{x:575,y:596,t:1526930383579};\\\", \\\"{x:576,y:596,t:1526930383597};\\\", \\\"{x:582,y:595,t:1526930383613};\\\", \\\"{x:590,y:591,t:1526930383630};\\\", \\\"{x:593,y:591,t:1526930383647};\\\", \\\"{x:596,y:588,t:1526930383664};\\\", \\\"{x:603,y:584,t:1526930383680};\\\", \\\"{x:614,y:582,t:1526930383696};\\\", \\\"{x:631,y:582,t:1526930383714};\\\", \\\"{x:636,y:582,t:1526930383729};\\\", \\\"{x:640,y:582,t:1526930383747};\\\", \\\"{x:641,y:582,t:1526930383763};\\\", \\\"{x:643,y:581,t:1526930383781};\\\", \\\"{x:643,y:580,t:1526930383797};\\\", \\\"{x:643,y:578,t:1526930383933};\\\", \\\"{x:643,y:577,t:1526930383949};\\\", \\\"{x:638,y:576,t:1526930383965};\\\", \\\"{x:632,y:576,t:1526930383980};\\\", \\\"{x:622,y:576,t:1526930383996};\\\", \\\"{x:616,y:576,t:1526930384014};\\\", \\\"{x:615,y:576,t:1526930384030};\\\", \\\"{x:614,y:576,t:1526930384108};\\\", \\\"{x:609,y:577,t:1526930384347};\\\", \\\"{x:605,y:585,t:1526930384364};\\\", \\\"{x:602,y:586,t:1526930384380};\\\", \\\"{x:592,y:594,t:1526930384397};\\\", \\\"{x:576,y:609,t:1526930384414};\\\", \\\"{x:556,y:628,t:1526930384430};\\\", \\\"{x:533,y:644,t:1526930384447};\\\", \\\"{x:515,y:659,t:1526930384464};\\\", \\\"{x:503,y:675,t:1526930384480};\\\", \\\"{x:494,y:685,t:1526930384496};\\\", \\\"{x:490,y:690,t:1526930384514};\\\", \\\"{x:488,y:692,t:1526930384530};\\\", \\\"{x:487,y:694,t:1526930384546};\\\", \\\"{x:484,y:699,t:1526930384563};\\\", \\\"{x:483,y:702,t:1526930384580};\\\", \\\"{x:483,y:706,t:1526930384597};\\\", \\\"{x:481,y:709,t:1526930384614};\\\", \\\"{x:480,y:714,t:1526930384631};\\\", \\\"{x:479,y:718,t:1526930384646};\\\", \\\"{x:479,y:720,t:1526930384665};\\\", \\\"{x:479,y:721,t:1526930384681};\\\", \\\"{x:479,y:724,t:1526930384836};\\\", \\\"{x:480,y:725,t:1526930385316};\\\", \\\"{x:480,y:726,t:1526930385340};\\\", \\\"{x:483,y:726,t:1526930385532};\\\", \\\"{x:484,y:726,t:1526930385548};\\\", \\\"{x:487,y:724,t:1526930385565};\\\", \\\"{x:488,y:723,t:1526930385581};\\\", \\\"{x:488,y:720,t:1526930385598};\\\", \\\"{x:491,y:714,t:1526930385615};\\\", \\\"{x:494,y:708,t:1526930385631};\\\", \\\"{x:499,y:704,t:1526930385648};\\\", \\\"{x:507,y:699,t:1526930385664};\\\", \\\"{x:516,y:692,t:1526930385682};\\\", \\\"{x:526,y:682,t:1526930385698};\\\", \\\"{x:533,y:675,t:1526930385715};\\\", \\\"{x:544,y:661,t:1526930385731};\\\", \\\"{x:550,y:652,t:1526930385748};\\\", \\\"{x:557,y:644,t:1526930385765};\\\", \\\"{x:560,y:642,t:1526930385782};\\\", \\\"{x:565,y:638,t:1526930385798};\\\", \\\"{x:568,y:636,t:1526930385815};\\\", \\\"{x:571,y:633,t:1526930385832};\\\", \\\"{x:576,y:628,t:1526930385848};\\\", \\\"{x:579,y:625,t:1526930385864};\\\", \\\"{x:580,y:625,t:1526930385882};\\\", \\\"{x:580,y:624,t:1526930385899};\\\", \\\"{x:581,y:624,t:1526930385948};\\\", \\\"{x:582,y:624,t:1526930385964};\\\", \\\"{x:583,y:624,t:1526930385996};\\\", \\\"{x:585,y:624,t:1526930386020};\\\", \\\"{x:589,y:624,t:1526930386040};\\\", \\\"{x:595,y:624,t:1526930386049};\\\", \\\"{x:604,y:624,t:1526930386065};\\\", \\\"{x:611,y:624,t:1526930386082};\\\", \\\"{x:622,y:626,t:1526930386099};\\\", \\\"{x:630,y:628,t:1526930386116};\\\", \\\"{x:631,y:629,t:1526930386131};\\\" ] }, { \\\"rt\\\": 89734, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 799459, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-03 PM-02 PM-02 PM-M -B -12 PM-B -B -B -B -M -B -F -F -G -C -C -C -01 PM-M -B -B -B -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:633,y:629,t:1526930386645};\\\", \\\"{x:634,y:630,t:1526930386660};\\\", \\\"{x:635,y:630,t:1526930386668};\\\", \\\"{x:636,y:632,t:1526930386701};\\\", \\\"{x:637,y:632,t:1526930386724};\\\", \\\"{x:638,y:632,t:1526930386740};\\\", \\\"{x:639,y:633,t:1526930386862};\\\", \\\"{x:640,y:633,t:1526930386948};\\\", \\\"{x:641,y:634,t:1526930386955};\\\", \\\"{x:641,y:635,t:1526930386979};\\\", \\\"{x:642,y:636,t:1526930387019};\\\", \\\"{x:642,y:637,t:1526930387309};\\\", \\\"{x:642,y:638,t:1526930387357};\\\", \\\"{x:643,y:638,t:1526930387901};\\\", \\\"{x:645,y:637,t:1526930387909};\\\", \\\"{x:647,y:635,t:1526930387919};\\\", \\\"{x:651,y:625,t:1526930387934};\\\", \\\"{x:658,y:603,t:1526930387951};\\\", \\\"{x:662,y:516,t:1526930387967};\\\", \\\"{x:662,y:454,t:1526930387984};\\\", \\\"{x:661,y:436,t:1526930387999};\\\", \\\"{x:661,y:425,t:1526930388017};\\\", \\\"{x:661,y:419,t:1526930388033};\\\", \\\"{x:659,y:415,t:1526930388050};\\\", \\\"{x:657,y:412,t:1526930388067};\\\", \\\"{x:655,y:412,t:1526930388082};\\\", \\\"{x:653,y:412,t:1526930388099};\\\", \\\"{x:651,y:412,t:1526930388117};\\\", \\\"{x:650,y:412,t:1526930388133};\\\", \\\"{x:646,y:413,t:1526930388150};\\\", \\\"{x:642,y:415,t:1526930388166};\\\", \\\"{x:638,y:418,t:1526930388183};\\\", \\\"{x:635,y:420,t:1526930388200};\\\", \\\"{x:630,y:422,t:1526930388217};\\\", \\\"{x:625,y:425,t:1526930388233};\\\", \\\"{x:621,y:428,t:1526930388250};\\\", \\\"{x:615,y:432,t:1526930388267};\\\", \\\"{x:610,y:433,t:1526930388282};\\\", \\\"{x:605,y:435,t:1526930388300};\\\", \\\"{x:605,y:436,t:1526930388317};\\\", \\\"{x:602,y:436,t:1526930388333};\\\", \\\"{x:598,y:437,t:1526930388350};\\\", \\\"{x:593,y:440,t:1526930388367};\\\", \\\"{x:583,y:444,t:1526930388383};\\\", \\\"{x:575,y:449,t:1526930388400};\\\", \\\"{x:558,y:453,t:1526930388416};\\\", \\\"{x:552,y:454,t:1526930388434};\\\", \\\"{x:544,y:457,t:1526930388450};\\\", \\\"{x:531,y:457,t:1526930388467};\\\", \\\"{x:523,y:458,t:1526930388483};\\\", \\\"{x:494,y:460,t:1526930388500};\\\", \\\"{x:479,y:462,t:1526930388517};\\\", \\\"{x:467,y:462,t:1526930388533};\\\", \\\"{x:461,y:462,t:1526930388550};\\\", \\\"{x:457,y:462,t:1526930388567};\\\", \\\"{x:453,y:462,t:1526930388583};\\\", \\\"{x:452,y:462,t:1526930388601};\\\", \\\"{x:450,y:463,t:1526930388616};\\\", \\\"{x:449,y:463,t:1526930388633};\\\", \\\"{x:447,y:463,t:1526930388650};\\\", \\\"{x:445,y:464,t:1526930388666};\\\", \\\"{x:444,y:465,t:1526930388685};\\\", \\\"{x:443,y:466,t:1526930388701};\\\", \\\"{x:442,y:467,t:1526930388716};\\\", \\\"{x:441,y:467,t:1526930388740};\\\", \\\"{x:441,y:468,t:1526930388773};\\\", \\\"{x:440,y:470,t:1526930388783};\\\", \\\"{x:438,y:473,t:1526930388799};\\\", \\\"{x:436,y:476,t:1526930388816};\\\", \\\"{x:435,y:478,t:1526930388833};\\\", \\\"{x:434,y:480,t:1526930388849};\\\", \\\"{x:432,y:481,t:1526930388866};\\\", \\\"{x:431,y:482,t:1526930388883};\\\", \\\"{x:431,y:483,t:1526930388900};\\\", \\\"{x:432,y:483,t:1526930388973};\\\", \\\"{x:435,y:485,t:1526930388983};\\\", \\\"{x:440,y:485,t:1526930389000};\\\", \\\"{x:459,y:485,t:1526930389017};\\\", \\\"{x:490,y:485,t:1526930389033};\\\", \\\"{x:522,y:487,t:1526930389049};\\\", \\\"{x:578,y:495,t:1526930389066};\\\", \\\"{x:611,y:503,t:1526930389085};\\\", \\\"{x:629,y:507,t:1526930389099};\\\", \\\"{x:640,y:508,t:1526930389118};\\\", \\\"{x:638,y:508,t:1526930389437};\\\", \\\"{x:632,y:508,t:1526930389451};\\\", \\\"{x:605,y:502,t:1526930389469};\\\", \\\"{x:590,y:498,t:1526930389486};\\\", \\\"{x:582,y:497,t:1526930389502};\\\", \\\"{x:579,y:496,t:1526930389517};\\\", \\\"{x:578,y:495,t:1526930389535};\\\", \\\"{x:579,y:494,t:1526930389716};\\\", \\\"{x:581,y:493,t:1526930389724};\\\", \\\"{x:584,y:492,t:1526930389735};\\\", \\\"{x:587,y:492,t:1526930389752};\\\", \\\"{x:588,y:491,t:1526930389768};\\\", \\\"{x:589,y:490,t:1526930389785};\\\", \\\"{x:591,y:489,t:1526930389876};\\\", \\\"{x:593,y:489,t:1526930389893};\\\", \\\"{x:593,y:487,t:1526930389908};\\\", \\\"{x:594,y:487,t:1526930389919};\\\", \\\"{x:595,y:485,t:1526930389948};\\\", \\\"{x:596,y:485,t:1526930389956};\\\", \\\"{x:597,y:485,t:1526930389970};\\\", \\\"{x:601,y:482,t:1526930389985};\\\", \\\"{x:603,y:482,t:1526930390001};\\\", \\\"{x:605,y:480,t:1526930390019};\\\", \\\"{x:614,y:480,t:1526930390077};\\\", \\\"{x:625,y:479,t:1526930390086};\\\", \\\"{x:646,y:479,t:1526930390102};\\\", \\\"{x:661,y:479,t:1526930390119};\\\", \\\"{x:689,y:481,t:1526930390136};\\\", \\\"{x:707,y:483,t:1526930390153};\\\", \\\"{x:724,y:487,t:1526930390169};\\\", \\\"{x:732,y:488,t:1526930390187};\\\", \\\"{x:740,y:490,t:1526930390202};\\\", \\\"{x:744,y:491,t:1526930390219};\\\", \\\"{x:750,y:492,t:1526930390236};\\\", \\\"{x:751,y:492,t:1526930390252};\\\", \\\"{x:753,y:492,t:1526930390269};\\\", \\\"{x:754,y:492,t:1526930390287};\\\", \\\"{x:756,y:493,t:1526930390302};\\\", \\\"{x:757,y:493,t:1526930390319};\\\", \\\"{x:759,y:493,t:1526930390337};\\\", \\\"{x:764,y:494,t:1526930390352};\\\", \\\"{x:772,y:495,t:1526930390369};\\\", \\\"{x:781,y:495,t:1526930390386};\\\", \\\"{x:797,y:498,t:1526930390403};\\\", \\\"{x:808,y:500,t:1526930390420};\\\", \\\"{x:844,y:507,t:1526930390437};\\\", \\\"{x:860,y:509,t:1526930390453};\\\", \\\"{x:873,y:512,t:1526930390469};\\\", \\\"{x:886,y:516,t:1526930390485};\\\", \\\"{x:899,y:519,t:1526930390502};\\\", \\\"{x:911,y:520,t:1526930390519};\\\", \\\"{x:914,y:520,t:1526930390535};\\\", \\\"{x:917,y:520,t:1526930390552};\\\", \\\"{x:918,y:520,t:1526930390569};\\\", \\\"{x:919,y:521,t:1526930390585};\\\", \\\"{x:920,y:521,t:1526930390601};\\\", \\\"{x:926,y:523,t:1526930390618};\\\", \\\"{x:939,y:524,t:1526930390636};\\\", \\\"{x:955,y:530,t:1526930390652};\\\", \\\"{x:968,y:534,t:1526930390669};\\\", \\\"{x:986,y:539,t:1526930390686};\\\", \\\"{x:994,y:541,t:1526930390702};\\\", \\\"{x:1009,y:549,t:1526930390719};\\\", \\\"{x:1029,y:557,t:1526930390736};\\\", \\\"{x:1062,y:567,t:1526930390752};\\\", \\\"{x:1100,y:585,t:1526930390770};\\\", \\\"{x:1132,y:597,t:1526930390786};\\\", \\\"{x:1189,y:619,t:1526930390802};\\\", \\\"{x:1264,y:639,t:1526930390819};\\\", \\\"{x:1355,y:669,t:1526930390837};\\\", \\\"{x:1454,y:692,t:1526930390853};\\\", \\\"{x:1535,y:719,t:1526930390869};\\\", \\\"{x:1566,y:737,t:1526930390886};\\\", \\\"{x:1589,y:740,t:1526930390902};\\\", \\\"{x:1602,y:749,t:1526930390919};\\\", \\\"{x:1610,y:756,t:1526930390936};\\\", \\\"{x:1613,y:762,t:1526930390952};\\\", \\\"{x:1616,y:770,t:1526930390969};\\\", \\\"{x:1618,y:778,t:1526930390986};\\\", \\\"{x:1628,y:795,t:1526930391003};\\\", \\\"{x:1635,y:815,t:1526930391020};\\\", \\\"{x:1650,y:845,t:1526930391037};\\\", \\\"{x:1655,y:858,t:1526930391053};\\\", \\\"{x:1657,y:866,t:1526930391069};\\\", \\\"{x:1657,y:872,t:1526930391086};\\\", \\\"{x:1657,y:878,t:1526930391104};\\\", \\\"{x:1654,y:888,t:1526930391120};\\\", \\\"{x:1653,y:893,t:1526930391136};\\\", \\\"{x:1643,y:904,t:1526930391153};\\\", \\\"{x:1636,y:913,t:1526930391170};\\\", \\\"{x:1628,y:922,t:1526930391187};\\\", \\\"{x:1625,y:924,t:1526930391203};\\\", \\\"{x:1624,y:926,t:1526930391219};\\\", \\\"{x:1623,y:926,t:1526930391236};\\\", \\\"{x:1622,y:926,t:1526930391317};\\\", \\\"{x:1621,y:926,t:1526930391333};\\\", \\\"{x:1619,y:927,t:1526930391349};\\\", \\\"{x:1618,y:927,t:1526930391372};\\\", \\\"{x:1618,y:928,t:1526930391396};\\\", \\\"{x:1617,y:928,t:1526930391404};\\\", \\\"{x:1616,y:929,t:1526930391419};\\\", \\\"{x:1615,y:929,t:1526930391477};\\\", \\\"{x:1610,y:930,t:1526930391486};\\\", \\\"{x:1607,y:932,t:1526930391504};\\\", \\\"{x:1597,y:934,t:1526930391520};\\\", \\\"{x:1596,y:934,t:1526930391537};\\\", \\\"{x:1594,y:934,t:1526930391661};\\\", \\\"{x:1593,y:934,t:1526930391701};\\\", \\\"{x:1591,y:934,t:1526930391709};\\\", \\\"{x:1589,y:935,t:1526930391732};\\\", \\\"{x:1586,y:936,t:1526930391748};\\\", \\\"{x:1583,y:938,t:1526930391756};\\\", \\\"{x:1581,y:939,t:1526930391770};\\\", \\\"{x:1573,y:942,t:1526930391786};\\\", \\\"{x:1567,y:945,t:1526930391803};\\\", \\\"{x:1563,y:949,t:1526930391820};\\\", \\\"{x:1561,y:950,t:1526930391837};\\\", \\\"{x:1560,y:951,t:1526930391869};\\\", \\\"{x:1559,y:952,t:1526930391885};\\\", \\\"{x:1558,y:952,t:1526930391892};\\\", \\\"{x:1558,y:956,t:1526930391903};\\\", \\\"{x:1550,y:966,t:1526930391921};\\\", \\\"{x:1544,y:973,t:1526930391938};\\\", \\\"{x:1539,y:978,t:1526930391954};\\\", \\\"{x:1533,y:981,t:1526930391970};\\\", \\\"{x:1531,y:982,t:1526930391988};\\\", \\\"{x:1529,y:983,t:1526930392004};\\\", \\\"{x:1529,y:984,t:1526930392020};\\\", \\\"{x:1525,y:985,t:1526930392038};\\\", \\\"{x:1519,y:986,t:1526930392053};\\\", \\\"{x:1509,y:987,t:1526930392070};\\\", \\\"{x:1498,y:987,t:1526930392088};\\\", \\\"{x:1492,y:987,t:1526930392104};\\\", \\\"{x:1489,y:987,t:1526930392121};\\\", \\\"{x:1487,y:987,t:1526930392138};\\\", \\\"{x:1485,y:987,t:1526930392188};\\\", \\\"{x:1484,y:985,t:1526930392204};\\\", \\\"{x:1479,y:985,t:1526930392220};\\\", \\\"{x:1476,y:982,t:1526930392237};\\\", \\\"{x:1474,y:980,t:1526930392252};\\\", \\\"{x:1472,y:978,t:1526930392269};\\\", \\\"{x:1471,y:977,t:1526930392300};\\\", \\\"{x:1471,y:976,t:1526930392307};\\\", \\\"{x:1471,y:975,t:1526930392320};\\\", \\\"{x:1471,y:974,t:1526930392337};\\\", \\\"{x:1471,y:971,t:1526930392354};\\\", \\\"{x:1471,y:969,t:1526930392370};\\\", \\\"{x:1471,y:968,t:1526930392387};\\\", \\\"{x:1471,y:966,t:1526930392404};\\\", \\\"{x:1471,y:965,t:1526930392484};\\\", \\\"{x:1472,y:965,t:1526930392508};\\\", \\\"{x:1473,y:965,t:1526930392532};\\\", \\\"{x:1474,y:965,t:1526930392541};\\\", \\\"{x:1475,y:966,t:1526930392597};\\\", \\\"{x:1476,y:966,t:1526930392621};\\\", \\\"{x:1477,y:967,t:1526930392821};\\\", \\\"{x:1476,y:968,t:1526930392838};\\\", \\\"{x:1474,y:969,t:1526930392855};\\\", \\\"{x:1475,y:969,t:1526930392957};\\\", \\\"{x:1478,y:968,t:1526930392973};\\\", \\\"{x:1479,y:967,t:1526930393069};\\\", \\\"{x:1481,y:966,t:1526930393133};\\\", \\\"{x:1481,y:964,t:1526930393140};\\\", \\\"{x:1482,y:963,t:1526930393157};\\\", \\\"{x:1482,y:962,t:1526930393171};\\\", \\\"{x:1484,y:960,t:1526930393187};\\\", \\\"{x:1485,y:957,t:1526930393204};\\\", \\\"{x:1485,y:956,t:1526930393221};\\\", \\\"{x:1485,y:953,t:1526930393238};\\\", \\\"{x:1483,y:955,t:1526930393397};\\\", \\\"{x:1482,y:955,t:1526930393445};\\\", \\\"{x:1481,y:956,t:1526930393533};\\\", \\\"{x:1480,y:956,t:1526930393548};\\\", \\\"{x:1479,y:957,t:1526930393564};\\\", \\\"{x:1478,y:957,t:1526930393572};\\\", \\\"{x:1477,y:958,t:1526930393605};\\\", \\\"{x:1476,y:958,t:1526930393660};\\\", \\\"{x:1475,y:959,t:1526930393709};\\\", \\\"{x:1474,y:960,t:1526930393901};\\\", \\\"{x:1473,y:960,t:1526930393925};\\\", \\\"{x:1473,y:961,t:1526930393939};\\\", \\\"{x:1472,y:961,t:1526930395085};\\\", \\\"{x:1472,y:958,t:1526930395092};\\\", \\\"{x:1472,y:949,t:1526930395106};\\\", \\\"{x:1472,y:918,t:1526930395123};\\\", \\\"{x:1472,y:883,t:1526930395140};\\\", \\\"{x:1469,y:856,t:1526930395156};\\\", \\\"{x:1460,y:825,t:1526930395172};\\\", \\\"{x:1455,y:811,t:1526930395190};\\\", \\\"{x:1454,y:801,t:1526930395206};\\\", \\\"{x:1453,y:793,t:1526930395223};\\\", \\\"{x:1452,y:789,t:1526930395239};\\\", \\\"{x:1451,y:781,t:1526930395256};\\\", \\\"{x:1449,y:778,t:1526930395273};\\\", \\\"{x:1447,y:775,t:1526930395290};\\\", \\\"{x:1446,y:773,t:1526930395306};\\\", \\\"{x:1445,y:771,t:1526930395323};\\\", \\\"{x:1444,y:770,t:1526930395357};\\\", \\\"{x:1444,y:769,t:1526930395372};\\\", \\\"{x:1444,y:768,t:1526930395389};\\\", \\\"{x:1443,y:767,t:1526930395861};\\\", \\\"{x:1443,y:769,t:1526930395893};\\\", \\\"{x:1443,y:770,t:1526930395907};\\\", \\\"{x:1443,y:777,t:1526930395923};\\\", \\\"{x:1443,y:791,t:1526930395942};\\\", \\\"{x:1445,y:803,t:1526930395960};\\\", \\\"{x:1452,y:811,t:1526930395978};\\\", \\\"{x:1457,y:822,t:1526930395994};\\\", \\\"{x:1463,y:836,t:1526930396011};\\\", \\\"{x:1470,y:842,t:1526930396027};\\\", \\\"{x:1472,y:845,t:1526930396044};\\\", \\\"{x:1473,y:849,t:1526930396061};\\\", \\\"{x:1473,y:852,t:1526930396077};\\\", \\\"{x:1473,y:857,t:1526930396094};\\\", \\\"{x:1473,y:862,t:1526930396110};\\\", \\\"{x:1473,y:863,t:1526930396127};\\\", \\\"{x:1473,y:868,t:1526930396143};\\\", \\\"{x:1473,y:870,t:1526930396160};\\\", \\\"{x:1473,y:872,t:1526930396177};\\\", \\\"{x:1473,y:873,t:1526930396194};\\\", \\\"{x:1473,y:874,t:1526930396210};\\\", \\\"{x:1473,y:876,t:1526930396227};\\\", \\\"{x:1473,y:878,t:1526930396245};\\\", \\\"{x:1471,y:881,t:1526930396260};\\\", \\\"{x:1471,y:883,t:1526930396277};\\\", \\\"{x:1469,y:885,t:1526930396294};\\\", \\\"{x:1468,y:889,t:1526930396310};\\\", \\\"{x:1468,y:893,t:1526930396327};\\\", \\\"{x:1468,y:898,t:1526930396343};\\\", \\\"{x:1468,y:901,t:1526930396360};\\\", \\\"{x:1468,y:905,t:1526930396377};\\\", \\\"{x:1469,y:909,t:1526930396395};\\\", \\\"{x:1470,y:912,t:1526930396411};\\\", \\\"{x:1470,y:913,t:1526930396432};\\\", \\\"{x:1471,y:913,t:1526930396448};\\\", \\\"{x:1471,y:915,t:1526930396513};\\\", \\\"{x:1471,y:917,t:1526930397297};\\\", \\\"{x:1470,y:917,t:1526930397311};\\\", \\\"{x:1469,y:917,t:1526930397329};\\\", \\\"{x:1467,y:917,t:1526930397361};\\\", \\\"{x:1466,y:917,t:1526930397385};\\\", \\\"{x:1465,y:917,t:1526930397433};\\\", \\\"{x:1463,y:916,t:1526930397449};\\\", \\\"{x:1461,y:916,t:1526930397465};\\\", \\\"{x:1460,y:916,t:1526930397479};\\\", \\\"{x:1456,y:916,t:1526930397495};\\\", \\\"{x:1453,y:916,t:1526930397512};\\\", \\\"{x:1449,y:915,t:1526930397528};\\\", \\\"{x:1448,y:915,t:1526930397546};\\\", \\\"{x:1447,y:914,t:1526930397593};\\\", \\\"{x:1444,y:913,t:1526930397608};\\\", \\\"{x:1443,y:912,t:1526930397616};\\\", \\\"{x:1441,y:910,t:1526930397628};\\\", \\\"{x:1438,y:909,t:1526930397645};\\\", \\\"{x:1434,y:907,t:1526930397661};\\\", \\\"{x:1434,y:905,t:1526930397678};\\\", \\\"{x:1433,y:904,t:1526930397695};\\\", \\\"{x:1433,y:903,t:1526930398545};\\\", \\\"{x:1432,y:901,t:1526930398563};\\\", \\\"{x:1431,y:901,t:1526930398580};\\\", \\\"{x:1430,y:899,t:1526930398596};\\\", \\\"{x:1427,y:898,t:1526930398613};\\\", \\\"{x:1423,y:894,t:1526930398630};\\\", \\\"{x:1420,y:892,t:1526930398646};\\\", \\\"{x:1417,y:891,t:1526930398663};\\\", \\\"{x:1415,y:890,t:1526930398680};\\\", \\\"{x:1414,y:890,t:1526930398696};\\\", \\\"{x:1412,y:890,t:1526930398937};\\\", \\\"{x:1411,y:890,t:1526930398946};\\\", \\\"{x:1410,y:890,t:1526930398963};\\\", \\\"{x:1407,y:890,t:1526930398985};\\\", \\\"{x:1405,y:890,t:1526930399009};\\\", \\\"{x:1404,y:890,t:1526930399032};\\\", \\\"{x:1404,y:891,t:1526930399089};\\\", \\\"{x:1403,y:891,t:1526930399145};\\\", \\\"{x:1402,y:892,t:1526930399193};\\\", \\\"{x:1401,y:892,t:1526930399209};\\\", \\\"{x:1400,y:892,t:1526930399224};\\\", \\\"{x:1400,y:893,t:1526930399232};\\\", \\\"{x:1399,y:894,t:1526930399247};\\\", \\\"{x:1396,y:895,t:1526930399263};\\\", \\\"{x:1395,y:896,t:1526930399280};\\\", \\\"{x:1391,y:898,t:1526930399297};\\\", \\\"{x:1390,y:899,t:1526930399313};\\\", \\\"{x:1389,y:899,t:1526930399337};\\\", \\\"{x:1388,y:899,t:1526930399347};\\\", \\\"{x:1387,y:900,t:1526930399937};\\\", \\\"{x:1387,y:901,t:1526930399947};\\\", \\\"{x:1386,y:901,t:1526930399964};\\\", \\\"{x:1385,y:901,t:1526930399981};\\\", \\\"{x:1384,y:901,t:1526930400003};\\\", \\\"{x:1383,y:901,t:1526930401056};\\\", \\\"{x:1380,y:901,t:1526930402865};\\\", \\\"{x:1367,y:901,t:1526930402885};\\\", \\\"{x:1350,y:895,t:1526930402899};\\\", \\\"{x:1329,y:888,t:1526930402916};\\\", \\\"{x:1320,y:886,t:1526930402933};\\\", \\\"{x:1311,y:883,t:1526930402949};\\\", \\\"{x:1310,y:883,t:1526930402966};\\\", \\\"{x:1308,y:883,t:1526930403033};\\\", \\\"{x:1297,y:880,t:1526930403049};\\\", \\\"{x:1286,y:873,t:1526930403066};\\\", \\\"{x:1262,y:865,t:1526930403083};\\\", \\\"{x:1245,y:860,t:1526930403099};\\\", \\\"{x:1230,y:856,t:1526930403116};\\\", \\\"{x:1227,y:854,t:1526930403134};\\\", \\\"{x:1225,y:854,t:1526930403150};\\\", \\\"{x:1224,y:853,t:1526930403177};\\\", \\\"{x:1223,y:852,t:1526930403184};\\\", \\\"{x:1222,y:850,t:1526930403200};\\\", \\\"{x:1221,y:849,t:1526930403217};\\\", \\\"{x:1220,y:848,t:1526930403233};\\\", \\\"{x:1219,y:847,t:1526930403250};\\\", \\\"{x:1218,y:846,t:1526930403266};\\\", \\\"{x:1217,y:846,t:1526930403361};\\\", \\\"{x:1217,y:848,t:1526930403376};\\\", \\\"{x:1217,y:850,t:1526930403392};\\\", \\\"{x:1216,y:851,t:1526930403400};\\\", \\\"{x:1214,y:857,t:1526930403417};\\\", \\\"{x:1212,y:860,t:1526930403433};\\\", \\\"{x:1212,y:864,t:1526930403450};\\\", \\\"{x:1212,y:868,t:1526930403466};\\\", \\\"{x:1211,y:870,t:1526930403483};\\\", \\\"{x:1209,y:875,t:1526930403500};\\\", \\\"{x:1206,y:879,t:1526930403516};\\\", \\\"{x:1203,y:885,t:1526930403533};\\\", \\\"{x:1199,y:891,t:1526930403550};\\\", \\\"{x:1194,y:899,t:1526930403566};\\\", \\\"{x:1192,y:902,t:1526930403583};\\\", \\\"{x:1185,y:909,t:1526930403600};\\\", \\\"{x:1181,y:914,t:1526930403616};\\\", \\\"{x:1178,y:918,t:1526930403633};\\\", \\\"{x:1176,y:920,t:1526930403650};\\\", \\\"{x:1174,y:922,t:1526930403666};\\\", \\\"{x:1174,y:924,t:1526930403684};\\\", \\\"{x:1173,y:925,t:1526930403700};\\\", \\\"{x:1172,y:926,t:1526930403721};\\\", \\\"{x:1171,y:928,t:1526930403744};\\\", \\\"{x:1171,y:931,t:1526930403761};\\\", \\\"{x:1170,y:931,t:1526930403768};\\\", \\\"{x:1173,y:928,t:1526930404009};\\\", \\\"{x:1175,y:925,t:1526930404016};\\\", \\\"{x:1180,y:917,t:1526930404033};\\\", \\\"{x:1186,y:910,t:1526930404050};\\\", \\\"{x:1190,y:904,t:1526930404067};\\\", \\\"{x:1194,y:898,t:1526930404082};\\\", \\\"{x:1197,y:894,t:1526930404099};\\\", \\\"{x:1198,y:890,t:1526930404116};\\\", \\\"{x:1200,y:886,t:1526930404133};\\\", \\\"{x:1203,y:882,t:1526930404149};\\\", \\\"{x:1206,y:878,t:1526930404167};\\\", \\\"{x:1209,y:874,t:1526930404182};\\\", \\\"{x:1212,y:866,t:1526930404199};\\\", \\\"{x:1214,y:862,t:1526930404216};\\\", \\\"{x:1215,y:859,t:1526930404233};\\\", \\\"{x:1217,y:856,t:1526930404250};\\\", \\\"{x:1217,y:854,t:1526930404267};\\\", \\\"{x:1218,y:852,t:1526930404283};\\\", \\\"{x:1218,y:851,t:1526930404299};\\\", \\\"{x:1218,y:849,t:1526930404317};\\\", \\\"{x:1218,y:847,t:1526930404334};\\\", \\\"{x:1219,y:846,t:1526930404349};\\\", \\\"{x:1219,y:845,t:1526930404366};\\\", \\\"{x:1219,y:841,t:1526930404384};\\\", \\\"{x:1220,y:839,t:1526930404400};\\\", \\\"{x:1221,y:838,t:1526930404417};\\\", \\\"{x:1221,y:836,t:1526930404439};\\\", \\\"{x:1221,y:835,t:1526930404449};\\\", \\\"{x:1222,y:834,t:1526930404467};\\\", \\\"{x:1222,y:833,t:1526930404483};\\\", \\\"{x:1222,y:832,t:1526930404500};\\\", \\\"{x:1222,y:831,t:1526930404517};\\\", \\\"{x:1222,y:830,t:1526930404534};\\\", \\\"{x:1222,y:829,t:1526930404559};\\\", \\\"{x:1223,y:828,t:1526930405121};\\\", \\\"{x:1224,y:828,t:1526930405136};\\\", \\\"{x:1227,y:828,t:1526930405152};\\\", \\\"{x:1252,y:826,t:1526930405168};\\\", \\\"{x:1284,y:826,t:1526930405184};\\\", \\\"{x:1333,y:826,t:1526930405201};\\\", \\\"{x:1381,y:826,t:1526930405218};\\\", \\\"{x:1403,y:825,t:1526930405234};\\\", \\\"{x:1409,y:823,t:1526930405250};\\\", \\\"{x:1412,y:821,t:1526930405268};\\\", \\\"{x:1412,y:820,t:1526930405285};\\\", \\\"{x:1412,y:818,t:1526930405301};\\\", \\\"{x:1412,y:816,t:1526930405318};\\\", \\\"{x:1412,y:815,t:1526930405344};\\\", \\\"{x:1412,y:812,t:1526930405352};\\\", \\\"{x:1409,y:808,t:1526930405368};\\\", \\\"{x:1406,y:803,t:1526930405385};\\\", \\\"{x:1405,y:802,t:1526930405401};\\\", \\\"{x:1401,y:800,t:1526930405419};\\\", \\\"{x:1398,y:798,t:1526930405434};\\\", \\\"{x:1392,y:794,t:1526930405452};\\\", \\\"{x:1384,y:789,t:1526930405468};\\\", \\\"{x:1371,y:782,t:1526930405484};\\\", \\\"{x:1368,y:779,t:1526930405501};\\\", \\\"{x:1366,y:777,t:1526930405518};\\\", \\\"{x:1365,y:777,t:1526930405545};\\\", \\\"{x:1361,y:774,t:1526930405568};\\\", \\\"{x:1359,y:773,t:1526930405584};\\\", \\\"{x:1357,y:772,t:1526930405601};\\\", \\\"{x:1357,y:771,t:1526930405618};\\\", \\\"{x:1356,y:770,t:1526930405635};\\\", \\\"{x:1355,y:770,t:1526930405673};\\\", \\\"{x:1354,y:769,t:1526930405697};\\\", \\\"{x:1353,y:769,t:1526930405712};\\\", \\\"{x:1352,y:769,t:1526930405744};\\\", \\\"{x:1352,y:768,t:1526930405825};\\\", \\\"{x:1351,y:767,t:1526930405836};\\\", \\\"{x:1350,y:767,t:1526930405872};\\\", \\\"{x:1349,y:766,t:1526930406152};\\\", \\\"{x:1348,y:766,t:1526930414479};\\\", \\\"{x:1348,y:767,t:1526930414490};\\\", \\\"{x:1348,y:771,t:1526930414508};\\\", \\\"{x:1348,y:774,t:1526930414524};\\\", \\\"{x:1348,y:776,t:1526930414541};\\\", \\\"{x:1348,y:778,t:1526930414558};\\\", \\\"{x:1349,y:781,t:1526930414573};\\\", \\\"{x:1350,y:784,t:1526930414591};\\\", \\\"{x:1350,y:790,t:1526930414607};\\\", \\\"{x:1351,y:794,t:1526930414624};\\\", \\\"{x:1351,y:796,t:1526930414641};\\\", \\\"{x:1351,y:798,t:1526930414657};\\\", \\\"{x:1351,y:800,t:1526930414674};\\\", \\\"{x:1351,y:801,t:1526930414691};\\\", \\\"{x:1351,y:803,t:1526930414708};\\\", \\\"{x:1353,y:806,t:1526930414724};\\\", \\\"{x:1353,y:810,t:1526930414741};\\\", \\\"{x:1353,y:814,t:1526930414758};\\\", \\\"{x:1354,y:819,t:1526930414774};\\\", \\\"{x:1354,y:821,t:1526930414791};\\\", \\\"{x:1354,y:825,t:1526930414808};\\\", \\\"{x:1354,y:827,t:1526930414824};\\\", \\\"{x:1353,y:831,t:1526930414841};\\\", \\\"{x:1353,y:838,t:1526930414858};\\\", \\\"{x:1353,y:841,t:1526930414874};\\\", \\\"{x:1352,y:847,t:1526930414892};\\\", \\\"{x:1352,y:851,t:1526930414908};\\\", \\\"{x:1352,y:855,t:1526930414924};\\\", \\\"{x:1352,y:858,t:1526930414941};\\\", \\\"{x:1352,y:860,t:1526930414958};\\\", \\\"{x:1352,y:861,t:1526930414975};\\\", \\\"{x:1353,y:864,t:1526930414991};\\\", \\\"{x:1353,y:867,t:1526930415008};\\\", \\\"{x:1354,y:870,t:1526930415025};\\\", \\\"{x:1354,y:872,t:1526930415042};\\\", \\\"{x:1354,y:874,t:1526930415058};\\\", \\\"{x:1357,y:878,t:1526930415075};\\\", \\\"{x:1358,y:883,t:1526930415091};\\\", \\\"{x:1358,y:887,t:1526930415109};\\\", \\\"{x:1358,y:892,t:1526930415125};\\\", \\\"{x:1358,y:895,t:1526930415142};\\\", \\\"{x:1358,y:898,t:1526930415159};\\\", \\\"{x:1358,y:903,t:1526930415176};\\\", \\\"{x:1358,y:905,t:1526930415192};\\\", \\\"{x:1361,y:912,t:1526930415208};\\\", \\\"{x:1361,y:916,t:1526930415226};\\\", \\\"{x:1364,y:918,t:1526930415242};\\\", \\\"{x:1364,y:923,t:1526930415258};\\\", \\\"{x:1366,y:926,t:1526930415275};\\\", \\\"{x:1367,y:929,t:1526930415292};\\\", \\\"{x:1368,y:932,t:1526930415309};\\\", \\\"{x:1370,y:936,t:1526930415325};\\\", \\\"{x:1371,y:938,t:1526930415341};\\\", \\\"{x:1373,y:943,t:1526930415358};\\\", \\\"{x:1374,y:945,t:1526930415376};\\\", \\\"{x:1374,y:947,t:1526930415392};\\\", \\\"{x:1376,y:949,t:1526930415408};\\\", \\\"{x:1376,y:951,t:1526930415425};\\\", \\\"{x:1376,y:952,t:1526930415441};\\\", \\\"{x:1376,y:954,t:1526930415458};\\\", \\\"{x:1377,y:955,t:1526930415475};\\\", \\\"{x:1378,y:957,t:1526930415492};\\\", \\\"{x:1378,y:958,t:1526930415508};\\\", \\\"{x:1378,y:959,t:1526930415524};\\\", \\\"{x:1379,y:961,t:1526930415541};\\\", \\\"{x:1379,y:962,t:1526930415560};\\\", \\\"{x:1381,y:962,t:1526930415575};\\\", \\\"{x:1382,y:964,t:1526930415592};\\\", \\\"{x:1386,y:968,t:1526930415608};\\\", \\\"{x:1389,y:970,t:1526930415625};\\\", \\\"{x:1390,y:972,t:1526930415642};\\\", \\\"{x:1388,y:973,t:1526930415936};\\\", \\\"{x:1385,y:973,t:1526930415944};\\\", \\\"{x:1381,y:973,t:1526930415960};\\\", \\\"{x:1380,y:973,t:1526930415975};\\\", \\\"{x:1378,y:974,t:1526930415992};\\\", \\\"{x:1377,y:974,t:1526930416009};\\\", \\\"{x:1375,y:974,t:1526930416064};\\\", \\\"{x:1374,y:974,t:1526930416079};\\\", \\\"{x:1373,y:974,t:1526930416092};\\\", \\\"{x:1368,y:974,t:1526930416109};\\\", \\\"{x:1362,y:974,t:1526930416125};\\\", \\\"{x:1357,y:974,t:1526930416142};\\\", \\\"{x:1355,y:975,t:1526930416159};\\\", \\\"{x:1350,y:975,t:1526930416175};\\\", \\\"{x:1348,y:975,t:1526930416192};\\\", \\\"{x:1346,y:975,t:1526930416209};\\\", \\\"{x:1345,y:975,t:1526930416225};\\\", \\\"{x:1343,y:974,t:1526930416247};\\\", \\\"{x:1342,y:973,t:1526930416448};\\\", \\\"{x:1342,y:972,t:1526930416464};\\\", \\\"{x:1344,y:971,t:1526930416476};\\\", \\\"{x:1347,y:971,t:1526930416493};\\\", \\\"{x:1349,y:971,t:1526930416512};\\\", \\\"{x:1349,y:970,t:1526930416526};\\\", \\\"{x:1350,y:970,t:1526930416543};\\\", \\\"{x:1351,y:969,t:1526930416559};\\\", \\\"{x:1352,y:967,t:1526930416657};\\\", \\\"{x:1353,y:967,t:1526930416672};\\\", \\\"{x:1354,y:965,t:1526930416697};\\\", \\\"{x:1355,y:964,t:1526930416710};\\\", \\\"{x:1357,y:962,t:1526930416727};\\\", \\\"{x:1359,y:956,t:1526930416743};\\\", \\\"{x:1362,y:949,t:1526930416760};\\\", \\\"{x:1365,y:929,t:1526930416776};\\\", \\\"{x:1365,y:915,t:1526930416792};\\\", \\\"{x:1365,y:900,t:1526930416809};\\\", \\\"{x:1365,y:881,t:1526930416827};\\\", \\\"{x:1350,y:848,t:1526930416842};\\\", \\\"{x:1338,y:821,t:1526930416860};\\\", \\\"{x:1326,y:799,t:1526930416876};\\\", \\\"{x:1322,y:778,t:1526930416892};\\\", \\\"{x:1318,y:765,t:1526930416910};\\\", \\\"{x:1316,y:754,t:1526930416926};\\\", \\\"{x:1313,y:740,t:1526930416944};\\\", \\\"{x:1313,y:738,t:1526930416959};\\\", \\\"{x:1312,y:735,t:1526930416976};\\\", \\\"{x:1312,y:733,t:1526930416994};\\\", \\\"{x:1312,y:732,t:1526930417009};\\\", \\\"{x:1312,y:729,t:1526930417027};\\\", \\\"{x:1312,y:727,t:1526930417044};\\\", \\\"{x:1312,y:726,t:1526930417064};\\\", \\\"{x:1312,y:725,t:1526930417128};\\\", \\\"{x:1316,y:725,t:1526930417144};\\\", \\\"{x:1321,y:728,t:1526930417159};\\\", \\\"{x:1326,y:732,t:1526930417176};\\\", \\\"{x:1329,y:734,t:1526930417194};\\\", \\\"{x:1331,y:736,t:1526930417224};\\\", \\\"{x:1332,y:737,t:1526930417233};\\\", \\\"{x:1334,y:739,t:1526930417243};\\\", \\\"{x:1335,y:740,t:1526930417260};\\\", \\\"{x:1336,y:745,t:1526930417277};\\\", \\\"{x:1339,y:752,t:1526930417294};\\\", \\\"{x:1344,y:761,t:1526930417310};\\\", \\\"{x:1347,y:769,t:1526930417328};\\\", \\\"{x:1356,y:793,t:1526930417344};\\\", \\\"{x:1363,y:813,t:1526930417360};\\\", \\\"{x:1368,y:830,t:1526930417377};\\\", \\\"{x:1376,y:848,t:1526930417394};\\\", \\\"{x:1380,y:861,t:1526930417410};\\\", \\\"{x:1382,y:871,t:1526930417427};\\\", \\\"{x:1387,y:882,t:1526930417443};\\\", \\\"{x:1391,y:891,t:1526930417460};\\\", \\\"{x:1392,y:897,t:1526930417476};\\\", \\\"{x:1394,y:905,t:1526930417494};\\\", \\\"{x:1397,y:909,t:1526930417511};\\\", \\\"{x:1400,y:915,t:1526930417526};\\\", \\\"{x:1410,y:933,t:1526930417543};\\\", \\\"{x:1412,y:936,t:1526930417560};\\\", \\\"{x:1412,y:937,t:1526930417576};\\\", \\\"{x:1413,y:939,t:1526930417594};\\\", \\\"{x:1413,y:940,t:1526930417611};\\\", \\\"{x:1413,y:941,t:1526930417632};\\\", \\\"{x:1413,y:942,t:1526930417643};\\\", \\\"{x:1413,y:943,t:1526930417660};\\\", \\\"{x:1413,y:945,t:1526930417677};\\\", \\\"{x:1413,y:946,t:1526930417693};\\\", \\\"{x:1413,y:947,t:1526930418024};\\\", \\\"{x:1409,y:946,t:1526930418032};\\\", \\\"{x:1407,y:945,t:1526930418043};\\\", \\\"{x:1398,y:943,t:1526930418060};\\\", \\\"{x:1386,y:936,t:1526930418077};\\\", \\\"{x:1380,y:931,t:1526930418093};\\\", \\\"{x:1374,y:929,t:1526930418110};\\\", \\\"{x:1368,y:925,t:1526930418127};\\\", \\\"{x:1363,y:919,t:1526930418143};\\\", \\\"{x:1361,y:917,t:1526930418160};\\\", \\\"{x:1361,y:915,t:1526930418177};\\\", \\\"{x:1359,y:912,t:1526930418193};\\\", \\\"{x:1359,y:908,t:1526930418210};\\\", \\\"{x:1359,y:900,t:1526930418228};\\\", \\\"{x:1359,y:886,t:1526930418244};\\\", \\\"{x:1362,y:873,t:1526930418261};\\\", \\\"{x:1364,y:858,t:1526930418277};\\\", \\\"{x:1367,y:847,t:1526930418293};\\\", \\\"{x:1368,y:836,t:1526930418310};\\\", \\\"{x:1368,y:819,t:1526930418328};\\\", \\\"{x:1368,y:808,t:1526930418344};\\\", \\\"{x:1367,y:799,t:1526930418360};\\\", \\\"{x:1365,y:791,t:1526930418377};\\\", \\\"{x:1359,y:786,t:1526930418394};\\\", \\\"{x:1357,y:781,t:1526930418410};\\\", \\\"{x:1355,y:777,t:1526930418427};\\\", \\\"{x:1351,y:769,t:1526930418445};\\\", \\\"{x:1348,y:761,t:1526930418461};\\\", \\\"{x:1345,y:756,t:1526930418478};\\\", \\\"{x:1344,y:753,t:1526930418494};\\\", \\\"{x:1343,y:751,t:1526930418511};\\\", \\\"{x:1343,y:750,t:1526930418527};\\\", \\\"{x:1342,y:750,t:1526930418625};\\\", \\\"{x:1342,y:751,t:1526930418712};\\\", \\\"{x:1343,y:760,t:1526930418729};\\\", \\\"{x:1344,y:773,t:1526930418745};\\\", \\\"{x:1350,y:785,t:1526930418761};\\\", \\\"{x:1352,y:794,t:1526930418778};\\\", \\\"{x:1357,y:804,t:1526930418795};\\\", \\\"{x:1362,y:813,t:1526930418812};\\\", \\\"{x:1365,y:818,t:1526930418827};\\\", \\\"{x:1368,y:822,t:1526930418845};\\\", \\\"{x:1372,y:827,t:1526930418861};\\\", \\\"{x:1376,y:833,t:1526930418878};\\\", \\\"{x:1379,y:837,t:1526930418895};\\\", \\\"{x:1387,y:847,t:1526930418912};\\\", \\\"{x:1392,y:854,t:1526930418928};\\\", \\\"{x:1396,y:862,t:1526930418945};\\\", \\\"{x:1402,y:872,t:1526930418961};\\\", \\\"{x:1409,y:882,t:1526930418977};\\\", \\\"{x:1417,y:890,t:1526930418995};\\\", \\\"{x:1420,y:896,t:1526930419012};\\\", \\\"{x:1425,y:900,t:1526930419028};\\\", \\\"{x:1429,y:905,t:1526930419045};\\\", \\\"{x:1432,y:909,t:1526930419061};\\\", \\\"{x:1436,y:915,t:1526930419077};\\\", \\\"{x:1441,y:922,t:1526930419094};\\\", \\\"{x:1450,y:936,t:1526930419112};\\\", \\\"{x:1455,y:944,t:1526930419128};\\\", \\\"{x:1459,y:952,t:1526930419144};\\\", \\\"{x:1460,y:956,t:1526930419161};\\\", \\\"{x:1461,y:957,t:1526930419178};\\\", \\\"{x:1461,y:958,t:1526930419200};\\\", \\\"{x:1462,y:959,t:1526930419281};\\\", \\\"{x:1462,y:960,t:1526930419320};\\\", \\\"{x:1462,y:962,t:1526930419336};\\\", \\\"{x:1462,y:963,t:1526930419369};\\\", \\\"{x:1461,y:965,t:1526930419392};\\\", \\\"{x:1460,y:965,t:1526930419432};\\\", \\\"{x:1455,y:964,t:1526930419445};\\\", \\\"{x:1430,y:944,t:1526930419462};\\\", \\\"{x:1382,y:900,t:1526930419479};\\\", \\\"{x:1337,y:848,t:1526930419494};\\\", \\\"{x:1292,y:792,t:1526930419511};\\\", \\\"{x:1281,y:775,t:1526930419528};\\\", \\\"{x:1278,y:770,t:1526930419544};\\\", \\\"{x:1275,y:764,t:1526930419560};\\\", \\\"{x:1275,y:763,t:1526930419578};\\\", \\\"{x:1273,y:759,t:1526930419594};\\\", \\\"{x:1273,y:757,t:1526930419610};\\\", \\\"{x:1273,y:753,t:1526930419628};\\\", \\\"{x:1273,y:750,t:1526930419644};\\\", \\\"{x:1274,y:747,t:1526930419661};\\\", \\\"{x:1274,y:746,t:1526930419678};\\\", \\\"{x:1275,y:745,t:1526930419694};\\\", \\\"{x:1282,y:745,t:1526930419728};\\\", \\\"{x:1289,y:745,t:1526930419746};\\\", \\\"{x:1297,y:751,t:1526930419761};\\\", \\\"{x:1313,y:752,t:1526930419778};\\\", \\\"{x:1339,y:757,t:1526930419795};\\\", \\\"{x:1366,y:763,t:1526930419811};\\\", \\\"{x:1371,y:765,t:1526930419829};\\\", \\\"{x:1372,y:765,t:1526930419845};\\\", \\\"{x:1372,y:767,t:1526930419872};\\\", \\\"{x:1371,y:768,t:1526930419880};\\\", \\\"{x:1368,y:770,t:1526930419895};\\\", \\\"{x:1367,y:771,t:1526930419985};\\\", \\\"{x:1366,y:771,t:1526930419996};\\\", \\\"{x:1364,y:771,t:1526930420048};\\\", \\\"{x:1363,y:771,t:1526930420062};\\\", \\\"{x:1356,y:773,t:1526930420079};\\\", \\\"{x:1353,y:773,t:1526930420095};\\\", \\\"{x:1352,y:773,t:1526930420128};\\\", \\\"{x:1351,y:773,t:1526930420146};\\\", \\\"{x:1350,y:773,t:1526930420163};\\\", \\\"{x:1349,y:773,t:1526930420179};\\\", \\\"{x:1349,y:772,t:1526930420196};\\\", \\\"{x:1352,y:769,t:1526930420213};\\\", \\\"{x:1353,y:767,t:1526930420229};\\\", \\\"{x:1353,y:765,t:1526930420247};\\\", \\\"{x:1353,y:763,t:1526930420278};\\\", \\\"{x:1353,y:764,t:1526930420384};\\\", \\\"{x:1353,y:770,t:1526930420396};\\\", \\\"{x:1345,y:779,t:1526930420412};\\\", \\\"{x:1340,y:791,t:1526930420428};\\\", \\\"{x:1336,y:802,t:1526930420445};\\\", \\\"{x:1331,y:808,t:1526930420462};\\\", \\\"{x:1328,y:814,t:1526930420478};\\\", \\\"{x:1324,y:825,t:1526930420495};\\\", \\\"{x:1319,y:833,t:1526930420512};\\\", \\\"{x:1314,y:841,t:1526930420528};\\\", \\\"{x:1308,y:853,t:1526930420545};\\\", \\\"{x:1299,y:868,t:1526930420561};\\\", \\\"{x:1293,y:879,t:1526930420578};\\\", \\\"{x:1286,y:885,t:1526930420595};\\\", \\\"{x:1284,y:888,t:1526930420612};\\\", \\\"{x:1282,y:892,t:1526930420629};\\\", \\\"{x:1281,y:895,t:1526930420645};\\\", \\\"{x:1277,y:900,t:1526930420662};\\\", \\\"{x:1272,y:909,t:1526930420680};\\\", \\\"{x:1270,y:916,t:1526930420695};\\\", \\\"{x:1268,y:922,t:1526930420712};\\\", \\\"{x:1265,y:927,t:1526930420729};\\\", \\\"{x:1264,y:931,t:1526930420745};\\\", \\\"{x:1264,y:933,t:1526930420762};\\\", \\\"{x:1264,y:934,t:1526930420779};\\\", \\\"{x:1264,y:936,t:1526930420795};\\\", \\\"{x:1264,y:939,t:1526930420812};\\\", \\\"{x:1262,y:941,t:1526930420830};\\\", \\\"{x:1259,y:946,t:1526930420846};\\\", \\\"{x:1256,y:949,t:1526930420863};\\\", \\\"{x:1256,y:955,t:1526930420880};\\\", \\\"{x:1252,y:960,t:1526930420896};\\\", \\\"{x:1249,y:963,t:1526930420912};\\\", \\\"{x:1248,y:965,t:1526930420929};\\\", \\\"{x:1245,y:966,t:1526930420946};\\\", \\\"{x:1243,y:968,t:1526930420963};\\\", \\\"{x:1242,y:971,t:1526930420979};\\\", \\\"{x:1241,y:971,t:1526930420996};\\\", \\\"{x:1241,y:972,t:1526930421013};\\\", \\\"{x:1239,y:973,t:1526930421030};\\\", \\\"{x:1240,y:973,t:1526930421264};\\\", \\\"{x:1242,y:970,t:1526930421280};\\\", \\\"{x:1243,y:968,t:1526930421296};\\\", \\\"{x:1244,y:968,t:1526930421320};\\\", \\\"{x:1244,y:967,t:1526930421330};\\\", \\\"{x:1246,y:965,t:1526930421347};\\\", \\\"{x:1246,y:964,t:1526930421368};\\\", \\\"{x:1246,y:963,t:1526930421384};\\\", \\\"{x:1247,y:963,t:1526930421399};\\\", \\\"{x:1247,y:961,t:1526930421433};\\\", \\\"{x:1248,y:960,t:1526930421447};\\\", \\\"{x:1248,y:959,t:1526930421505};\\\", \\\"{x:1250,y:959,t:1526930421600};\\\", \\\"{x:1250,y:957,t:1526930421624};\\\", \\\"{x:1251,y:957,t:1526930421680};\\\", \\\"{x:1251,y:953,t:1526930427992};\\\", \\\"{x:1256,y:944,t:1526930428000};\\\", \\\"{x:1273,y:933,t:1526930428018};\\\", \\\"{x:1294,y:917,t:1526930428035};\\\", \\\"{x:1312,y:898,t:1526930428050};\\\", \\\"{x:1331,y:873,t:1526930428068};\\\", \\\"{x:1344,y:850,t:1526930428085};\\\", \\\"{x:1348,y:834,t:1526930428101};\\\", \\\"{x:1354,y:812,t:1526930428118};\\\", \\\"{x:1357,y:796,t:1526930428135};\\\", \\\"{x:1357,y:791,t:1526930428151};\\\", \\\"{x:1356,y:784,t:1526930428167};\\\", \\\"{x:1358,y:780,t:1526930428185};\\\", \\\"{x:1364,y:772,t:1526930428202};\\\", \\\"{x:1370,y:767,t:1526930428218};\\\", \\\"{x:1370,y:765,t:1526930428235};\\\", \\\"{x:1371,y:764,t:1526930428252};\\\", \\\"{x:1371,y:761,t:1526930428400};\\\", \\\"{x:1371,y:757,t:1526930428408};\\\", \\\"{x:1369,y:753,t:1526930428418};\\\", \\\"{x:1363,y:742,t:1526930428435};\\\", \\\"{x:1359,y:737,t:1526930428452};\\\", \\\"{x:1356,y:731,t:1526930428468};\\\", \\\"{x:1353,y:726,t:1526930428485};\\\", \\\"{x:1352,y:721,t:1526930428502};\\\", \\\"{x:1346,y:712,t:1526930428517};\\\", \\\"{x:1345,y:709,t:1526930428535};\\\", \\\"{x:1344,y:704,t:1526930428552};\\\", \\\"{x:1344,y:703,t:1526930428567};\\\", \\\"{x:1344,y:701,t:1526930428585};\\\", \\\"{x:1344,y:700,t:1526930428664};\\\", \\\"{x:1343,y:699,t:1526930428728};\\\", \\\"{x:1341,y:700,t:1526930428937};\\\", \\\"{x:1341,y:702,t:1526930428952};\\\", \\\"{x:1341,y:706,t:1526930428969};\\\", \\\"{x:1340,y:712,t:1526930428985};\\\", \\\"{x:1339,y:715,t:1526930429003};\\\", \\\"{x:1338,y:719,t:1526930429019};\\\", \\\"{x:1336,y:721,t:1526930429035};\\\", \\\"{x:1335,y:722,t:1526930429064};\\\", \\\"{x:1333,y:722,t:1526930429096};\\\", \\\"{x:1333,y:724,t:1526930429184};\\\", \\\"{x:1332,y:726,t:1526930429232};\\\", \\\"{x:1331,y:726,t:1526930429255};\\\", \\\"{x:1330,y:727,t:1526930429269};\\\", \\\"{x:1327,y:732,t:1526930429286};\\\", \\\"{x:1326,y:735,t:1526930429301};\\\", \\\"{x:1325,y:738,t:1526930429319};\\\", \\\"{x:1324,y:739,t:1526930429336};\\\", \\\"{x:1324,y:741,t:1526930429352};\\\", \\\"{x:1324,y:742,t:1526930429369};\\\", \\\"{x:1322,y:745,t:1526930429386};\\\", \\\"{x:1322,y:746,t:1526930429402};\\\", \\\"{x:1321,y:748,t:1526930429418};\\\", \\\"{x:1319,y:752,t:1526930429436};\\\", \\\"{x:1319,y:755,t:1526930429452};\\\", \\\"{x:1318,y:756,t:1526930429472};\\\", \\\"{x:1318,y:758,t:1526930429487};\\\", \\\"{x:1316,y:760,t:1526930429502};\\\", \\\"{x:1315,y:761,t:1526930429519};\\\", \\\"{x:1313,y:763,t:1526930429536};\\\", \\\"{x:1313,y:764,t:1526930429592};\\\", \\\"{x:1316,y:762,t:1526930430033};\\\", \\\"{x:1318,y:759,t:1526930430039};\\\", \\\"{x:1320,y:756,t:1526930430053};\\\", \\\"{x:1323,y:751,t:1526930430069};\\\", \\\"{x:1325,y:748,t:1526930430086};\\\", \\\"{x:1327,y:743,t:1526930430104};\\\", \\\"{x:1329,y:740,t:1526930430119};\\\", \\\"{x:1331,y:735,t:1526930430136};\\\", \\\"{x:1332,y:732,t:1526930430152};\\\", \\\"{x:1334,y:728,t:1526930430170};\\\", \\\"{x:1337,y:725,t:1526930430186};\\\", \\\"{x:1337,y:723,t:1526930430203};\\\", \\\"{x:1337,y:720,t:1526930430220};\\\", \\\"{x:1338,y:717,t:1526930430236};\\\", \\\"{x:1340,y:714,t:1526930430253};\\\", \\\"{x:1340,y:713,t:1526930430270};\\\", \\\"{x:1342,y:710,t:1526930430286};\\\", \\\"{x:1342,y:709,t:1526930430303};\\\", \\\"{x:1344,y:706,t:1526930430320};\\\", \\\"{x:1345,y:705,t:1526930430336};\\\", \\\"{x:1345,y:703,t:1526930430352};\\\", \\\"{x:1346,y:702,t:1526930431209};\\\", \\\"{x:1347,y:701,t:1526930431220};\\\", \\\"{x:1350,y:700,t:1526930431237};\\\", \\\"{x:1350,y:699,t:1526930431253};\\\", \\\"{x:1351,y:698,t:1526930431269};\\\", \\\"{x:1352,y:697,t:1526930431592};\\\", \\\"{x:1354,y:697,t:1526930432577};\\\", \\\"{x:1355,y:694,t:1526930432588};\\\", \\\"{x:1363,y:688,t:1526930432605};\\\", \\\"{x:1366,y:679,t:1526930432621};\\\", \\\"{x:1368,y:670,t:1526930432638};\\\", \\\"{x:1374,y:662,t:1526930432655};\\\", \\\"{x:1376,y:658,t:1526930432671};\\\", \\\"{x:1379,y:652,t:1526930432687};\\\", \\\"{x:1380,y:647,t:1526930432705};\\\", \\\"{x:1385,y:641,t:1526930432721};\\\", \\\"{x:1388,y:636,t:1526930432738};\\\", \\\"{x:1390,y:630,t:1526930432755};\\\", \\\"{x:1393,y:627,t:1526930432771};\\\", \\\"{x:1393,y:625,t:1526930432788};\\\", \\\"{x:1393,y:624,t:1526930432805};\\\", \\\"{x:1395,y:623,t:1526930432821};\\\", \\\"{x:1395,y:621,t:1526930432864};\\\", \\\"{x:1397,y:619,t:1526930432872};\\\", \\\"{x:1399,y:615,t:1526930432888};\\\", \\\"{x:1403,y:609,t:1526930432905};\\\", \\\"{x:1406,y:604,t:1526930432921};\\\", \\\"{x:1407,y:601,t:1526930432938};\\\", \\\"{x:1408,y:597,t:1526930432955};\\\", \\\"{x:1409,y:595,t:1526930432984};\\\", \\\"{x:1410,y:594,t:1526930432992};\\\", \\\"{x:1410,y:592,t:1526930433015};\\\", \\\"{x:1411,y:592,t:1526930433024};\\\", \\\"{x:1411,y:591,t:1526930433040};\\\", \\\"{x:1411,y:589,t:1526930433055};\\\", \\\"{x:1412,y:588,t:1526930433078};\\\", \\\"{x:1413,y:587,t:1526930433095};\\\", \\\"{x:1414,y:587,t:1526930433118};\\\", \\\"{x:1415,y:585,t:1526930433135};\\\", \\\"{x:1416,y:584,t:1526930433159};\\\", \\\"{x:1417,y:583,t:1526930433256};\\\", \\\"{x:1418,y:582,t:1526930433280};\\\", \\\"{x:1418,y:581,t:1526930433336};\\\", \\\"{x:1421,y:580,t:1526930433351};\\\", \\\"{x:1421,y:579,t:1526930433360};\\\", \\\"{x:1421,y:578,t:1526930433372};\\\", \\\"{x:1421,y:576,t:1526930433389};\\\", \\\"{x:1423,y:574,t:1526930433406};\\\", \\\"{x:1424,y:572,t:1526930433422};\\\", \\\"{x:1424,y:569,t:1526930433440};\\\", \\\"{x:1425,y:569,t:1526930433455};\\\", \\\"{x:1425,y:568,t:1526930433472};\\\", \\\"{x:1425,y:567,t:1526930433496};\\\", \\\"{x:1425,y:566,t:1526930433512};\\\", \\\"{x:1424,y:566,t:1526930433527};\\\", \\\"{x:1423,y:566,t:1526930433568};\\\", \\\"{x:1422,y:566,t:1526930433809};\\\", \\\"{x:1421,y:566,t:1526930433822};\\\", \\\"{x:1421,y:565,t:1526930433968};\\\", \\\"{x:1420,y:565,t:1526930434057};\\\", \\\"{x:1420,y:564,t:1526930434137};\\\", \\\"{x:1419,y:564,t:1526930434880};\\\", \\\"{x:1418,y:564,t:1526930434976};\\\", \\\"{x:1417,y:564,t:1526930437216};\\\", \\\"{x:1413,y:566,t:1526930437225};\\\", \\\"{x:1412,y:576,t:1526930437242};\\\", \\\"{x:1411,y:585,t:1526930437257};\\\", \\\"{x:1412,y:595,t:1526930437274};\\\", \\\"{x:1413,y:603,t:1526930437291};\\\", \\\"{x:1415,y:609,t:1526930437308};\\\", \\\"{x:1416,y:611,t:1526930437324};\\\", \\\"{x:1419,y:615,t:1526930437341};\\\", \\\"{x:1425,y:620,t:1526930437357};\\\", \\\"{x:1429,y:625,t:1526930437375};\\\", \\\"{x:1430,y:626,t:1526930437390};\\\", \\\"{x:1431,y:627,t:1526930437431};\\\", \\\"{x:1432,y:627,t:1526930437504};\\\", \\\"{x:1433,y:628,t:1526930437624};\\\", \\\"{x:1433,y:631,t:1526930437642};\\\", \\\"{x:1433,y:633,t:1526930437658};\\\", \\\"{x:1434,y:636,t:1526930437675};\\\", \\\"{x:1435,y:636,t:1526930437692};\\\", \\\"{x:1437,y:636,t:1526930437708};\\\", \\\"{x:1438,y:636,t:1526930437768};\\\", \\\"{x:1439,y:636,t:1526930437783};\\\", \\\"{x:1441,y:638,t:1526930437791};\\\", \\\"{x:1442,y:638,t:1526930437815};\\\", \\\"{x:1446,y:638,t:1526930437826};\\\", \\\"{x:1454,y:638,t:1526930437842};\\\", \\\"{x:1457,y:638,t:1526930437858};\\\", \\\"{x:1460,y:638,t:1526930437876};\\\", \\\"{x:1461,y:638,t:1526930437944};\\\", \\\"{x:1457,y:636,t:1526930438288};\\\", \\\"{x:1450,y:635,t:1526930438296};\\\", \\\"{x:1446,y:634,t:1526930438308};\\\", \\\"{x:1443,y:633,t:1526930438324};\\\", \\\"{x:1441,y:632,t:1526930438342};\\\", \\\"{x:1439,y:632,t:1526930438544};\\\", \\\"{x:1437,y:639,t:1526930438559};\\\", \\\"{x:1433,y:648,t:1526930438575};\\\", \\\"{x:1430,y:660,t:1526930438592};\\\", \\\"{x:1427,y:673,t:1526930438609};\\\", \\\"{x:1425,y:682,t:1526930438626};\\\", \\\"{x:1421,y:690,t:1526930438642};\\\", \\\"{x:1420,y:695,t:1526930438659};\\\", \\\"{x:1417,y:700,t:1526930438676};\\\", \\\"{x:1415,y:706,t:1526930438692};\\\", \\\"{x:1409,y:718,t:1526930438709};\\\", \\\"{x:1403,y:726,t:1526930438726};\\\", \\\"{x:1400,y:738,t:1526930438742};\\\", \\\"{x:1393,y:758,t:1526930438760};\\\", \\\"{x:1391,y:766,t:1526930438775};\\\", \\\"{x:1388,y:774,t:1526930438792};\\\", \\\"{x:1387,y:777,t:1526930438809};\\\", \\\"{x:1383,y:782,t:1526930438826};\\\", \\\"{x:1380,y:789,t:1526930438842};\\\", \\\"{x:1378,y:795,t:1526930438859};\\\", \\\"{x:1374,y:804,t:1526930438876};\\\", \\\"{x:1371,y:812,t:1526930438892};\\\", \\\"{x:1367,y:820,t:1526930438909};\\\", \\\"{x:1366,y:822,t:1526930438926};\\\", \\\"{x:1364,y:824,t:1526930438942};\\\", \\\"{x:1360,y:828,t:1526930438959};\\\", \\\"{x:1358,y:831,t:1526930438976};\\\", \\\"{x:1353,y:833,t:1526930438992};\\\", \\\"{x:1348,y:840,t:1526930439010};\\\", \\\"{x:1343,y:844,t:1526930439026};\\\", \\\"{x:1337,y:849,t:1526930439042};\\\", \\\"{x:1332,y:854,t:1526930439059};\\\", \\\"{x:1328,y:857,t:1526930439075};\\\", \\\"{x:1326,y:860,t:1526930439093};\\\", \\\"{x:1323,y:863,t:1526930439108};\\\", \\\"{x:1319,y:865,t:1526930439126};\\\", \\\"{x:1315,y:869,t:1526930439142};\\\", \\\"{x:1311,y:873,t:1526930439158};\\\", \\\"{x:1310,y:875,t:1526930439176};\\\", \\\"{x:1309,y:876,t:1526930439192};\\\", \\\"{x:1306,y:878,t:1526930439209};\\\", \\\"{x:1306,y:879,t:1526930439226};\\\", \\\"{x:1305,y:881,t:1526930439243};\\\", \\\"{x:1305,y:883,t:1526930439259};\\\", \\\"{x:1303,y:884,t:1526930439276};\\\", \\\"{x:1303,y:886,t:1526930439293};\\\", \\\"{x:1302,y:887,t:1526930439320};\\\", \\\"{x:1302,y:888,t:1526930439488};\\\", \\\"{x:1304,y:888,t:1526930439495};\\\", \\\"{x:1307,y:888,t:1526930439509};\\\", \\\"{x:1316,y:879,t:1526930439526};\\\", \\\"{x:1332,y:861,t:1526930439543};\\\", \\\"{x:1343,y:846,t:1526930439560};\\\", \\\"{x:1355,y:827,t:1526930439576};\\\", \\\"{x:1367,y:804,t:1526930439593};\\\", \\\"{x:1384,y:774,t:1526930439611};\\\", \\\"{x:1396,y:749,t:1526930439627};\\\", \\\"{x:1408,y:720,t:1526930439643};\\\", \\\"{x:1419,y:701,t:1526930439660};\\\", \\\"{x:1428,y:686,t:1526930439676};\\\", \\\"{x:1432,y:681,t:1526930439693};\\\", \\\"{x:1433,y:674,t:1526930439710};\\\", \\\"{x:1435,y:669,t:1526930439726};\\\", \\\"{x:1437,y:662,t:1526930439743};\\\", \\\"{x:1437,y:660,t:1526930439760};\\\", \\\"{x:1439,y:656,t:1526930439776};\\\", \\\"{x:1441,y:653,t:1526930439794};\\\", \\\"{x:1445,y:647,t:1526930439810};\\\", \\\"{x:1447,y:643,t:1526930439826};\\\", \\\"{x:1447,y:642,t:1526930439844};\\\", \\\"{x:1448,y:642,t:1526930439860};\\\", \\\"{x:1448,y:640,t:1526930439876};\\\", \\\"{x:1450,y:639,t:1526930439893};\\\", \\\"{x:1451,y:636,t:1526930439910};\\\", \\\"{x:1452,y:634,t:1526930439927};\\\", \\\"{x:1453,y:631,t:1526930439943};\\\", \\\"{x:1453,y:632,t:1526930444680};\\\", \\\"{x:1453,y:633,t:1526930444801};\\\", \\\"{x:1452,y:633,t:1526930444816};\\\", \\\"{x:1449,y:636,t:1526930444848};\\\", \\\"{x:1446,y:637,t:1526930444863};\\\", \\\"{x:1444,y:639,t:1526930444881};\\\", \\\"{x:1441,y:641,t:1526930444898};\\\", \\\"{x:1438,y:643,t:1526930444914};\\\", \\\"{x:1437,y:644,t:1526930444931};\\\", \\\"{x:1436,y:644,t:1526930444947};\\\", \\\"{x:1434,y:644,t:1526930444984};\\\", \\\"{x:1433,y:644,t:1526930446304};\\\", \\\"{x:1430,y:642,t:1526930446314};\\\", \\\"{x:1430,y:638,t:1526930446331};\\\", \\\"{x:1430,y:630,t:1526930446349};\\\", \\\"{x:1416,y:570,t:1526930446364};\\\", \\\"{x:1392,y:509,t:1526930446381};\\\", \\\"{x:1384,y:496,t:1526930446399};\\\", \\\"{x:1379,y:488,t:1526930446415};\\\", \\\"{x:1377,y:483,t:1526930446431};\\\", \\\"{x:1377,y:481,t:1526930446511};\\\", \\\"{x:1377,y:480,t:1526930446519};\\\", \\\"{x:1377,y:479,t:1526930446532};\\\", \\\"{x:1377,y:473,t:1526930446548};\\\", \\\"{x:1379,y:471,t:1526930446565};\\\", \\\"{x:1380,y:468,t:1526930446582};\\\", \\\"{x:1381,y:467,t:1526930446656};\\\", \\\"{x:1383,y:468,t:1526930446671};\\\", \\\"{x:1383,y:474,t:1526930446681};\\\", \\\"{x:1384,y:490,t:1526930446699};\\\", \\\"{x:1381,y:513,t:1526930446716};\\\", \\\"{x:1369,y:540,t:1526930446731};\\\", \\\"{x:1353,y:566,t:1526930446748};\\\", \\\"{x:1324,y:620,t:1526930446765};\\\", \\\"{x:1287,y:680,t:1526930446781};\\\", \\\"{x:1256,y:750,t:1526930446799};\\\", \\\"{x:1224,y:809,t:1526930446815};\\\", \\\"{x:1206,y:844,t:1526930446832};\\\", \\\"{x:1201,y:858,t:1526930446848};\\\", \\\"{x:1191,y:879,t:1526930446865};\\\", \\\"{x:1185,y:890,t:1526930446882};\\\", \\\"{x:1179,y:897,t:1526930446898};\\\", \\\"{x:1175,y:903,t:1526930446915};\\\", \\\"{x:1172,y:908,t:1526930446931};\\\", \\\"{x:1168,y:915,t:1526930446948};\\\", \\\"{x:1166,y:917,t:1526930446966};\\\", \\\"{x:1166,y:918,t:1526930446981};\\\", \\\"{x:1166,y:919,t:1526930446998};\\\", \\\"{x:1164,y:925,t:1526930447151};\\\", \\\"{x:1162,y:925,t:1526930447166};\\\", \\\"{x:1156,y:931,t:1526930447182};\\\", \\\"{x:1151,y:940,t:1526930447199};\\\", \\\"{x:1147,y:948,t:1526930447216};\\\", \\\"{x:1144,y:952,t:1526930447233};\\\", \\\"{x:1141,y:956,t:1526930447248};\\\", \\\"{x:1138,y:960,t:1526930447265};\\\", \\\"{x:1138,y:963,t:1526930447282};\\\", \\\"{x:1137,y:964,t:1526930447298};\\\", \\\"{x:1137,y:966,t:1526930447316};\\\", \\\"{x:1137,y:967,t:1526930447439};\\\", \\\"{x:1140,y:965,t:1526930447448};\\\", \\\"{x:1147,y:961,t:1526930447466};\\\", \\\"{x:1160,y:949,t:1526930447482};\\\", \\\"{x:1172,y:934,t:1526930447499};\\\", \\\"{x:1186,y:915,t:1526930447516};\\\", \\\"{x:1200,y:893,t:1526930447533};\\\", \\\"{x:1220,y:872,t:1526930447549};\\\", \\\"{x:1247,y:826,t:1526930447566};\\\", \\\"{x:1272,y:776,t:1526930447583};\\\", \\\"{x:1302,y:705,t:1526930447599};\\\", \\\"{x:1311,y:683,t:1526930447615};\\\", \\\"{x:1323,y:664,t:1526930447632};\\\", \\\"{x:1331,y:640,t:1526930447649};\\\", \\\"{x:1337,y:627,t:1526930447665};\\\", \\\"{x:1345,y:612,t:1526930447682};\\\", \\\"{x:1354,y:598,t:1526930447699};\\\", \\\"{x:1362,y:587,t:1526930447715};\\\", \\\"{x:1368,y:577,t:1526930447732};\\\", \\\"{x:1372,y:572,t:1526930447749};\\\", \\\"{x:1373,y:569,t:1526930447765};\\\", \\\"{x:1377,y:562,t:1526930447782};\\\", \\\"{x:1383,y:549,t:1526930447798};\\\", \\\"{x:1385,y:543,t:1526930447815};\\\", \\\"{x:1388,y:534,t:1526930447832};\\\", \\\"{x:1390,y:524,t:1526930447849};\\\", \\\"{x:1393,y:515,t:1526930447865};\\\", \\\"{x:1394,y:507,t:1526930447882};\\\", \\\"{x:1395,y:500,t:1526930447899};\\\", \\\"{x:1399,y:491,t:1526930447915};\\\", \\\"{x:1402,y:481,t:1526930447932};\\\", \\\"{x:1404,y:475,t:1526930447949};\\\", \\\"{x:1406,y:470,t:1526930447965};\\\", \\\"{x:1408,y:461,t:1526930447982};\\\", \\\"{x:1412,y:454,t:1526930447999};\\\", \\\"{x:1413,y:450,t:1526930448016};\\\", \\\"{x:1414,y:447,t:1526930448033};\\\", \\\"{x:1415,y:446,t:1526930448049};\\\", \\\"{x:1416,y:445,t:1526930448071};\\\", \\\"{x:1416,y:444,t:1526930448103};\\\", \\\"{x:1417,y:444,t:1526930448127};\\\", \\\"{x:1418,y:443,t:1526930448264};\\\", \\\"{x:1419,y:442,t:1526930448327};\\\", \\\"{x:1419,y:441,t:1526930448336};\\\", \\\"{x:1421,y:440,t:1526930448349};\\\", \\\"{x:1423,y:439,t:1526930448366};\\\", \\\"{x:1424,y:438,t:1526930448383};\\\", \\\"{x:1425,y:437,t:1526930448399};\\\", \\\"{x:1425,y:436,t:1526930448417};\\\", \\\"{x:1427,y:434,t:1526930448433};\\\", \\\"{x:1427,y:431,t:1526930448504};\\\", \\\"{x:1427,y:432,t:1526930455007};\\\", \\\"{x:1430,y:434,t:1526930455021};\\\", \\\"{x:1430,y:437,t:1526930455037};\\\", \\\"{x:1434,y:451,t:1526930455055};\\\", \\\"{x:1436,y:461,t:1526930455071};\\\", \\\"{x:1440,y:479,t:1526930455087};\\\", \\\"{x:1447,y:510,t:1526930455104};\\\", \\\"{x:1471,y:573,t:1526930455121};\\\", \\\"{x:1511,y:664,t:1526930455138};\\\", \\\"{x:1547,y:762,t:1526930455155};\\\", \\\"{x:1574,y:848,t:1526930455171};\\\", \\\"{x:1601,y:910,t:1526930455188};\\\", \\\"{x:1616,y:935,t:1526930455205};\\\", \\\"{x:1617,y:944,t:1526930455222};\\\", \\\"{x:1617,y:947,t:1526930455238};\\\", \\\"{x:1617,y:950,t:1526930455255};\\\", \\\"{x:1615,y:956,t:1526930455271};\\\", \\\"{x:1600,y:968,t:1526930455288};\\\", \\\"{x:1581,y:979,t:1526930455305};\\\", \\\"{x:1566,y:988,t:1526930455322};\\\", \\\"{x:1550,y:993,t:1526930455338};\\\", \\\"{x:1535,y:998,t:1526930455355};\\\", \\\"{x:1521,y:999,t:1526930455372};\\\", \\\"{x:1511,y:999,t:1526930455388};\\\", \\\"{x:1493,y:999,t:1526930455405};\\\", \\\"{x:1482,y:999,t:1526930455422};\\\", \\\"{x:1476,y:999,t:1526930455438};\\\", \\\"{x:1470,y:999,t:1526930455455};\\\", \\\"{x:1465,y:999,t:1526930455471};\\\", \\\"{x:1459,y:999,t:1526930455488};\\\", \\\"{x:1457,y:999,t:1526930455504};\\\", \\\"{x:1456,y:998,t:1526930455521};\\\", \\\"{x:1454,y:996,t:1526930455538};\\\", \\\"{x:1450,y:994,t:1526930455555};\\\", \\\"{x:1440,y:992,t:1526930455571};\\\", \\\"{x:1433,y:990,t:1526930455588};\\\", \\\"{x:1423,y:988,t:1526930455604};\\\", \\\"{x:1417,y:985,t:1526930455621};\\\", \\\"{x:1410,y:982,t:1526930455639};\\\", \\\"{x:1406,y:981,t:1526930455654};\\\", \\\"{x:1404,y:981,t:1526930455671};\\\", \\\"{x:1401,y:979,t:1526930455688};\\\", \\\"{x:1397,y:978,t:1526930455704};\\\", \\\"{x:1392,y:974,t:1526930455721};\\\", \\\"{x:1388,y:970,t:1526930455738};\\\", \\\"{x:1381,y:966,t:1526930455755};\\\", \\\"{x:1377,y:962,t:1526930455772};\\\", \\\"{x:1376,y:961,t:1526930455799};\\\", \\\"{x:1375,y:959,t:1526930455839};\\\", \\\"{x:1373,y:957,t:1526930455855};\\\", \\\"{x:1367,y:952,t:1526930455872};\\\", \\\"{x:1360,y:949,t:1526930455889};\\\", \\\"{x:1350,y:946,t:1526930455905};\\\", \\\"{x:1346,y:945,t:1526930455922};\\\", \\\"{x:1345,y:945,t:1526930455943};\\\", \\\"{x:1344,y:944,t:1526930455955};\\\", \\\"{x:1343,y:943,t:1526930455995};\\\", \\\"{x:1343,y:942,t:1526930456035};\\\", \\\"{x:1343,y:940,t:1526930456042};\\\", \\\"{x:1343,y:936,t:1526930456058};\\\", \\\"{x:1345,y:931,t:1526930456075};\\\", \\\"{x:1348,y:925,t:1526930456092};\\\", \\\"{x:1352,y:918,t:1526930456108};\\\", \\\"{x:1357,y:912,t:1526930456124};\\\", \\\"{x:1360,y:907,t:1526930456142};\\\", \\\"{x:1365,y:900,t:1526930456158};\\\", \\\"{x:1378,y:892,t:1526930456174};\\\", \\\"{x:1392,y:882,t:1526930456192};\\\", \\\"{x:1407,y:875,t:1526930456209};\\\", \\\"{x:1412,y:872,t:1526930456225};\\\", \\\"{x:1414,y:871,t:1526930456242};\\\", \\\"{x:1412,y:873,t:1526930456515};\\\", \\\"{x:1411,y:876,t:1526930456527};\\\", \\\"{x:1407,y:882,t:1526930456542};\\\", \\\"{x:1406,y:883,t:1526930456559};\\\", \\\"{x:1405,y:886,t:1526930456577};\\\", \\\"{x:1403,y:887,t:1526930456592};\\\", \\\"{x:1403,y:888,t:1526930456707};\\\", \\\"{x:1402,y:888,t:1526930456715};\\\", \\\"{x:1402,y:890,t:1526930456771};\\\", \\\"{x:1400,y:891,t:1526930456778};\\\", \\\"{x:1400,y:892,t:1526930456792};\\\", \\\"{x:1398,y:895,t:1526930456809};\\\", \\\"{x:1396,y:898,t:1526930456826};\\\", \\\"{x:1394,y:900,t:1526930456842};\\\", \\\"{x:1394,y:901,t:1526930456866};\\\", \\\"{x:1393,y:901,t:1526930456907};\\\", \\\"{x:1394,y:901,t:1526930458010};\\\", \\\"{x:1397,y:897,t:1526930458027};\\\", \\\"{x:1398,y:892,t:1526930458043};\\\", \\\"{x:1400,y:891,t:1526930458060};\\\", \\\"{x:1402,y:887,t:1526930458076};\\\", \\\"{x:1404,y:884,t:1526930458093};\\\", \\\"{x:1406,y:881,t:1526930458109};\\\", \\\"{x:1406,y:879,t:1526930458127};\\\", \\\"{x:1408,y:876,t:1526930458143};\\\", \\\"{x:1409,y:872,t:1526930458160};\\\", \\\"{x:1412,y:871,t:1526930458177};\\\", \\\"{x:1412,y:868,t:1526930458193};\\\", \\\"{x:1415,y:860,t:1526930458210};\\\", \\\"{x:1415,y:858,t:1526930458227};\\\", \\\"{x:1417,y:854,t:1526930458243};\\\", \\\"{x:1419,y:849,t:1526930458260};\\\", \\\"{x:1420,y:845,t:1526930458277};\\\", \\\"{x:1423,y:838,t:1526930458293};\\\", \\\"{x:1424,y:835,t:1526930458310};\\\", \\\"{x:1426,y:832,t:1526930458327};\\\", \\\"{x:1428,y:826,t:1526930458343};\\\", \\\"{x:1431,y:821,t:1526930458360};\\\", \\\"{x:1435,y:815,t:1526930458377};\\\", \\\"{x:1437,y:808,t:1526930458394};\\\", \\\"{x:1440,y:803,t:1526930458410};\\\", \\\"{x:1443,y:801,t:1526930458427};\\\", \\\"{x:1443,y:799,t:1526930458444};\\\", \\\"{x:1443,y:798,t:1526930458461};\\\", \\\"{x:1444,y:797,t:1526930458477};\\\", \\\"{x:1444,y:796,t:1526930458547};\\\", \\\"{x:1442,y:797,t:1526930459299};\\\", \\\"{x:1438,y:799,t:1526930459312};\\\", \\\"{x:1425,y:812,t:1526930459328};\\\", \\\"{x:1406,y:830,t:1526930459345};\\\", \\\"{x:1391,y:846,t:1526930459361};\\\", \\\"{x:1381,y:852,t:1526930459378};\\\", \\\"{x:1380,y:854,t:1526930459394};\\\", \\\"{x:1379,y:854,t:1526930459411};\\\", \\\"{x:1378,y:855,t:1526930459428};\\\", \\\"{x:1377,y:857,t:1526930459483};\\\", \\\"{x:1377,y:858,t:1526930459514};\\\", \\\"{x:1374,y:860,t:1526930459528};\\\", \\\"{x:1371,y:864,t:1526930459544};\\\", \\\"{x:1364,y:871,t:1526930459561};\\\", \\\"{x:1348,y:885,t:1526930459578};\\\", \\\"{x:1330,y:896,t:1526930459594};\\\", \\\"{x:1310,y:904,t:1526930459611};\\\", \\\"{x:1297,y:911,t:1526930459628};\\\", \\\"{x:1281,y:918,t:1526930459644};\\\", \\\"{x:1269,y:922,t:1526930459660};\\\", \\\"{x:1263,y:924,t:1526930459678};\\\", \\\"{x:1256,y:927,t:1526930459694};\\\", \\\"{x:1252,y:928,t:1526930459711};\\\", \\\"{x:1248,y:929,t:1526930459728};\\\", \\\"{x:1247,y:930,t:1526930459744};\\\", \\\"{x:1246,y:930,t:1526930459778};\\\", \\\"{x:1245,y:930,t:1526930459794};\\\", \\\"{x:1240,y:926,t:1526930459811};\\\", \\\"{x:1231,y:919,t:1526930459828};\\\", \\\"{x:1215,y:914,t:1526930459845};\\\", \\\"{x:1197,y:905,t:1526930459861};\\\", \\\"{x:1179,y:895,t:1526930459878};\\\", \\\"{x:1165,y:888,t:1526930459894};\\\", \\\"{x:1149,y:882,t:1526930459911};\\\", \\\"{x:1142,y:878,t:1526930459928};\\\", \\\"{x:1141,y:878,t:1526930459945};\\\", \\\"{x:1140,y:878,t:1526930459961};\\\", \\\"{x:1140,y:876,t:1526930460139};\\\", \\\"{x:1140,y:873,t:1526930460147};\\\", \\\"{x:1140,y:872,t:1526930460162};\\\", \\\"{x:1144,y:863,t:1526930460178};\\\", \\\"{x:1146,y:860,t:1526930460195};\\\", \\\"{x:1147,y:858,t:1526930460211};\\\", \\\"{x:1147,y:856,t:1526930460283};\\\", \\\"{x:1147,y:855,t:1526930460295};\\\", \\\"{x:1147,y:854,t:1526930460314};\\\", \\\"{x:1147,y:851,t:1526930460328};\\\", \\\"{x:1148,y:851,t:1526930460346};\\\", \\\"{x:1150,y:847,t:1526930460362};\\\", \\\"{x:1151,y:844,t:1526930460379};\\\", \\\"{x:1154,y:840,t:1526930460395};\\\", \\\"{x:1155,y:833,t:1526930460413};\\\", \\\"{x:1159,y:826,t:1526930460429};\\\", \\\"{x:1163,y:817,t:1526930460445};\\\", \\\"{x:1165,y:812,t:1526930460462};\\\", \\\"{x:1168,y:804,t:1526930460478};\\\", \\\"{x:1173,y:797,t:1526930460494};\\\", \\\"{x:1175,y:791,t:1526930460512};\\\", \\\"{x:1180,y:786,t:1526930460528};\\\", \\\"{x:1181,y:782,t:1526930460545};\\\", \\\"{x:1184,y:775,t:1526930460561};\\\", \\\"{x:1185,y:773,t:1526930460578};\\\", \\\"{x:1188,y:772,t:1526930460595};\\\", \\\"{x:1188,y:771,t:1526930460612};\\\", \\\"{x:1189,y:770,t:1526930460628};\\\", \\\"{x:1191,y:770,t:1526930461507};\\\", \\\"{x:1200,y:770,t:1526930461523};\\\", \\\"{x:1206,y:770,t:1526930461530};\\\", \\\"{x:1225,y:768,t:1526930461546};\\\", \\\"{x:1259,y:768,t:1526930461562};\\\", \\\"{x:1279,y:768,t:1526930461579};\\\", \\\"{x:1305,y:770,t:1526930461596};\\\", \\\"{x:1322,y:770,t:1526930461614};\\\", \\\"{x:1328,y:770,t:1526930461630};\\\", \\\"{x:1330,y:770,t:1526930461647};\\\", \\\"{x:1331,y:771,t:1526930461674};\\\", \\\"{x:1331,y:772,t:1526930461683};\\\", \\\"{x:1332,y:772,t:1526930461786};\\\", \\\"{x:1332,y:773,t:1526930461811};\\\", \\\"{x:1330,y:773,t:1526930461835};\\\", \\\"{x:1327,y:776,t:1526930461846};\\\", \\\"{x:1324,y:779,t:1526930461863};\\\", \\\"{x:1322,y:780,t:1526930461879};\\\", \\\"{x:1321,y:783,t:1526930461896};\\\", \\\"{x:1323,y:783,t:1526930462019};\\\", \\\"{x:1325,y:782,t:1526930462030};\\\", \\\"{x:1328,y:781,t:1526930462047};\\\", \\\"{x:1330,y:780,t:1526930462063};\\\", \\\"{x:1333,y:779,t:1526930462079};\\\", \\\"{x:1335,y:778,t:1526930462096};\\\", \\\"{x:1338,y:778,t:1526930462113};\\\", \\\"{x:1340,y:775,t:1526930462130};\\\", \\\"{x:1341,y:775,t:1526930462146};\\\", \\\"{x:1342,y:773,t:1526930462163};\\\", \\\"{x:1343,y:772,t:1526930462181};\\\", \\\"{x:1345,y:771,t:1526930462197};\\\", \\\"{x:1347,y:770,t:1526930462213};\\\", \\\"{x:1348,y:769,t:1526930462230};\\\", \\\"{x:1349,y:769,t:1526930462275};\\\", \\\"{x:1350,y:768,t:1526930462307};\\\", \\\"{x:1350,y:767,t:1526930462330};\\\", \\\"{x:1350,y:766,t:1526930462346};\\\", \\\"{x:1351,y:765,t:1526930462363};\\\", \\\"{x:1351,y:764,t:1526930462386};\\\", \\\"{x:1351,y:763,t:1526930462410};\\\", \\\"{x:1351,y:762,t:1526930462419};\\\", \\\"{x:1351,y:761,t:1526930462435};\\\", \\\"{x:1350,y:759,t:1526930462446};\\\", \\\"{x:1350,y:758,t:1526930462463};\\\", \\\"{x:1350,y:757,t:1526930462481};\\\", \\\"{x:1350,y:755,t:1526930462496};\\\", \\\"{x:1350,y:754,t:1526930462514};\\\", \\\"{x:1350,y:753,t:1526930462530};\\\", \\\"{x:1349,y:755,t:1526930462883};\\\", \\\"{x:1348,y:756,t:1526930462906};\\\", \\\"{x:1348,y:757,t:1526930462938};\\\", \\\"{x:1347,y:757,t:1526930462947};\\\", \\\"{x:1347,y:758,t:1526930462964};\\\", \\\"{x:1346,y:759,t:1526930462980};\\\", \\\"{x:1345,y:760,t:1526930463010};\\\", \\\"{x:1344,y:760,t:1526930463034};\\\", \\\"{x:1344,y:761,t:1526930463048};\\\", \\\"{x:1344,y:763,t:1526930463063};\\\", \\\"{x:1344,y:764,t:1526930463090};\\\", \\\"{x:1344,y:765,t:1526930463123};\\\", \\\"{x:1344,y:766,t:1526930463138};\\\", \\\"{x:1345,y:767,t:1526930465473};\\\", \\\"{x:1345,y:768,t:1526930465481};\\\", \\\"{x:1342,y:772,t:1526930465499};\\\", \\\"{x:1337,y:780,t:1526930465515};\\\", \\\"{x:1332,y:788,t:1526930465532};\\\", \\\"{x:1327,y:796,t:1526930465549};\\\", \\\"{x:1326,y:803,t:1526930465565};\\\", \\\"{x:1323,y:807,t:1526930465581};\\\", \\\"{x:1319,y:817,t:1526930465599};\\\", \\\"{x:1310,y:830,t:1526930465615};\\\", \\\"{x:1308,y:842,t:1526930465632};\\\", \\\"{x:1304,y:854,t:1526930465649};\\\", \\\"{x:1301,y:864,t:1526930465665};\\\", \\\"{x:1293,y:875,t:1526930465682};\\\", \\\"{x:1290,y:882,t:1526930465699};\\\", \\\"{x:1289,y:886,t:1526930465715};\\\", \\\"{x:1285,y:893,t:1526930465732};\\\", \\\"{x:1281,y:906,t:1526930465749};\\\", \\\"{x:1278,y:914,t:1526930465765};\\\", \\\"{x:1275,y:919,t:1526930465783};\\\", \\\"{x:1272,y:924,t:1526930465800};\\\", \\\"{x:1270,y:928,t:1526930465815};\\\", \\\"{x:1268,y:934,t:1526930465833};\\\", \\\"{x:1265,y:940,t:1526930465850};\\\", \\\"{x:1263,y:944,t:1526930465866};\\\", \\\"{x:1260,y:952,t:1526930465882};\\\", \\\"{x:1259,y:955,t:1526930465899};\\\", \\\"{x:1257,y:959,t:1526930465915};\\\", \\\"{x:1257,y:961,t:1526930465932};\\\", \\\"{x:1255,y:963,t:1526930465950};\\\", \\\"{x:1254,y:965,t:1526930465965};\\\", \\\"{x:1253,y:966,t:1526930465982};\\\", \\\"{x:1252,y:968,t:1526930465999};\\\", \\\"{x:1251,y:968,t:1526930466017};\\\", \\\"{x:1251,y:969,t:1526930466034};\\\", \\\"{x:1250,y:970,t:1526930466050};\\\", \\\"{x:1250,y:971,t:1526930466066};\\\", \\\"{x:1251,y:971,t:1526930466331};\\\", \\\"{x:1252,y:970,t:1526930466346};\\\", \\\"{x:1254,y:968,t:1526930466354};\\\", \\\"{x:1254,y:967,t:1526930466367};\\\", \\\"{x:1258,y:965,t:1526930466383};\\\", \\\"{x:1261,y:962,t:1526930466399};\\\", \\\"{x:1262,y:960,t:1526930466417};\\\", \\\"{x:1262,y:959,t:1526930469387};\\\", \\\"{x:1263,y:957,t:1526930469402};\\\", \\\"{x:1266,y:951,t:1526930469418};\\\", \\\"{x:1268,y:947,t:1526930469436};\\\", \\\"{x:1269,y:946,t:1526930469452};\\\", \\\"{x:1270,y:944,t:1526930469469};\\\", \\\"{x:1271,y:943,t:1526930469486};\\\", \\\"{x:1272,y:942,t:1526930469502};\\\", \\\"{x:1273,y:939,t:1526930469519};\\\", \\\"{x:1276,y:936,t:1526930469535};\\\", \\\"{x:1276,y:933,t:1526930469551};\\\", \\\"{x:1276,y:932,t:1526930469578};\\\", \\\"{x:1277,y:932,t:1526930469594};\\\", \\\"{x:1278,y:930,t:1526930469626};\\\", \\\"{x:1279,y:929,t:1526930469636};\\\", \\\"{x:1280,y:927,t:1526930469652};\\\", \\\"{x:1283,y:924,t:1526930469668};\\\", \\\"{x:1288,y:921,t:1526930469686};\\\", \\\"{x:1294,y:917,t:1526930469702};\\\", \\\"{x:1298,y:911,t:1526930469719};\\\", \\\"{x:1307,y:898,t:1526930469735};\\\", \\\"{x:1323,y:880,t:1526930469752};\\\", \\\"{x:1356,y:847,t:1526930469769};\\\", \\\"{x:1387,y:815,t:1526930469786};\\\", \\\"{x:1412,y:786,t:1526930469802};\\\", \\\"{x:1428,y:770,t:1526930469819};\\\", \\\"{x:1437,y:757,t:1526930469836};\\\", \\\"{x:1444,y:746,t:1526930469852};\\\", \\\"{x:1449,y:738,t:1526930469869};\\\", \\\"{x:1455,y:731,t:1526930469886};\\\", \\\"{x:1460,y:724,t:1526930469903};\\\", \\\"{x:1464,y:715,t:1526930469919};\\\", \\\"{x:1472,y:705,t:1526930469936};\\\", \\\"{x:1476,y:699,t:1526930469953};\\\", \\\"{x:1481,y:693,t:1526930469968};\\\", \\\"{x:1485,y:684,t:1526930469986};\\\", \\\"{x:1488,y:680,t:1526930470002};\\\", \\\"{x:1491,y:678,t:1526930470018};\\\", \\\"{x:1493,y:676,t:1526930470036};\\\", \\\"{x:1494,y:674,t:1526930470052};\\\", \\\"{x:1495,y:673,t:1526930470069};\\\", \\\"{x:1495,y:672,t:1526930470086};\\\", \\\"{x:1496,y:671,t:1526930470103};\\\", \\\"{x:1493,y:673,t:1526930470435};\\\", \\\"{x:1490,y:676,t:1526930470453};\\\", \\\"{x:1484,y:680,t:1526930470469};\\\", \\\"{x:1478,y:684,t:1526930470485};\\\", \\\"{x:1471,y:689,t:1526930470502};\\\", \\\"{x:1467,y:692,t:1526930470519};\\\", \\\"{x:1466,y:692,t:1526930470535};\\\", \\\"{x:1464,y:693,t:1526930470552};\\\", \\\"{x:1463,y:693,t:1526930470594};\\\", \\\"{x:1461,y:693,t:1526930470602};\\\", \\\"{x:1459,y:693,t:1526930470641};\\\", \\\"{x:1458,y:691,t:1526930470652};\\\", \\\"{x:1455,y:678,t:1526930470669};\\\", \\\"{x:1454,y:668,t:1526930470686};\\\", \\\"{x:1451,y:659,t:1526930470702};\\\", \\\"{x:1451,y:651,t:1526930470719};\\\", \\\"{x:1451,y:647,t:1526930470736};\\\", \\\"{x:1451,y:643,t:1526930470752};\\\", \\\"{x:1451,y:640,t:1526930470769};\\\", \\\"{x:1451,y:638,t:1526930470785};\\\", \\\"{x:1451,y:637,t:1526930470803};\\\", \\\"{x:1451,y:635,t:1526930470819};\\\", \\\"{x:1451,y:634,t:1526930471555};\\\", \\\"{x:1449,y:634,t:1526930471570};\\\", \\\"{x:1444,y:635,t:1526930471588};\\\", \\\"{x:1439,y:640,t:1526930471603};\\\", \\\"{x:1436,y:647,t:1526930471620};\\\", \\\"{x:1433,y:652,t:1526930471636};\\\", \\\"{x:1431,y:659,t:1526930471654};\\\", \\\"{x:1430,y:662,t:1526930471671};\\\", \\\"{x:1430,y:664,t:1526930471687};\\\", \\\"{x:1430,y:666,t:1526930471703};\\\", \\\"{x:1427,y:670,t:1526930471721};\\\", \\\"{x:1426,y:673,t:1526930471737};\\\", \\\"{x:1420,y:683,t:1526930471754};\\\", \\\"{x:1419,y:688,t:1526930471770};\\\", \\\"{x:1415,y:693,t:1526930471787};\\\", \\\"{x:1415,y:698,t:1526930471804};\\\", \\\"{x:1414,y:702,t:1526930471821};\\\", \\\"{x:1412,y:707,t:1526930471837};\\\", \\\"{x:1410,y:712,t:1526930471853};\\\", \\\"{x:1408,y:720,t:1526930471871};\\\", \\\"{x:1405,y:725,t:1526930471887};\\\", \\\"{x:1401,y:731,t:1526930471904};\\\", \\\"{x:1398,y:740,t:1526930471921};\\\", \\\"{x:1395,y:750,t:1526930471937};\\\", \\\"{x:1391,y:762,t:1526930471954};\\\", \\\"{x:1390,y:766,t:1526930471970};\\\", \\\"{x:1388,y:770,t:1526930471986};\\\", \\\"{x:1387,y:772,t:1526930472004};\\\", \\\"{x:1387,y:773,t:1526930472020};\\\", \\\"{x:1387,y:774,t:1526930472038};\\\", \\\"{x:1386,y:775,t:1526930472057};\\\", \\\"{x:1386,y:776,t:1526930472081};\\\", \\\"{x:1386,y:777,t:1526930472097};\\\", \\\"{x:1385,y:778,t:1526930472105};\\\", \\\"{x:1384,y:779,t:1526930472120};\\\", \\\"{x:1382,y:782,t:1526930472137};\\\", \\\"{x:1380,y:784,t:1526930472153};\\\", \\\"{x:1380,y:785,t:1526930472177};\\\", \\\"{x:1379,y:786,t:1526930472188};\\\", \\\"{x:1379,y:787,t:1526930472225};\\\", \\\"{x:1378,y:787,t:1526930472237};\\\", \\\"{x:1377,y:788,t:1526930472253};\\\", \\\"{x:1376,y:788,t:1526930472270};\\\", \\\"{x:1375,y:790,t:1526930472297};\\\", \\\"{x:1374,y:791,t:1526930472314};\\\", \\\"{x:1374,y:792,t:1526930472329};\\\", \\\"{x:1373,y:792,t:1526930472345};\\\", \\\"{x:1373,y:793,t:1526930472362};\\\", \\\"{x:1372,y:794,t:1526930472395};\\\", \\\"{x:1372,y:795,t:1526930472417};\\\", \\\"{x:1371,y:795,t:1526930472442};\\\", \\\"{x:1370,y:795,t:1526930473531};\\\", \\\"{x:1366,y:795,t:1526930473538};\\\", \\\"{x:1351,y:786,t:1526930473555};\\\", \\\"{x:1321,y:773,t:1526930473572};\\\", \\\"{x:1281,y:755,t:1526930473589};\\\", \\\"{x:1229,y:742,t:1526930473605};\\\", \\\"{x:1179,y:720,t:1526930473622};\\\", \\\"{x:1149,y:707,t:1526930473639};\\\", \\\"{x:1124,y:701,t:1526930473655};\\\", \\\"{x:1084,y:694,t:1526930473672};\\\", \\\"{x:1068,y:689,t:1526930473689};\\\", \\\"{x:1051,y:686,t:1526930473705};\\\", \\\"{x:1046,y:686,t:1526930473722};\\\", \\\"{x:1044,y:685,t:1526930473739};\\\", \\\"{x:1042,y:685,t:1526930473754};\\\", \\\"{x:1039,y:685,t:1526930473778};\\\", \\\"{x:1038,y:685,t:1526930473789};\\\", \\\"{x:1035,y:685,t:1526930473805};\\\", \\\"{x:1031,y:684,t:1526930473822};\\\", \\\"{x:1028,y:684,t:1526930473838};\\\", \\\"{x:1020,y:682,t:1526930473855};\\\", \\\"{x:1010,y:681,t:1526930473871};\\\", \\\"{x:995,y:679,t:1526930473889};\\\", \\\"{x:978,y:679,t:1526930473905};\\\", \\\"{x:954,y:674,t:1526930473922};\\\", \\\"{x:945,y:672,t:1526930473938};\\\", \\\"{x:942,y:672,t:1526930473954};\\\", \\\"{x:940,y:672,t:1526930474330};\\\", \\\"{x:938,y:672,t:1526930474339};\\\", \\\"{x:924,y:672,t:1526930474356};\\\", \\\"{x:893,y:670,t:1526930474371};\\\", \\\"{x:858,y:665,t:1526930474388};\\\", \\\"{x:812,y:656,t:1526930474406};\\\", \\\"{x:766,y:647,t:1526930474423};\\\", \\\"{x:727,y:638,t:1526930474440};\\\", \\\"{x:689,y:630,t:1526930474456};\\\", \\\"{x:669,y:623,t:1526930474472};\\\", \\\"{x:623,y:612,t:1526930474492};\\\", \\\"{x:600,y:608,t:1526930474508};\\\", \\\"{x:573,y:602,t:1526930474525};\\\", \\\"{x:550,y:599,t:1526930474541};\\\", \\\"{x:522,y:599,t:1526930474561};\\\", \\\"{x:513,y:599,t:1526930474577};\\\", \\\"{x:507,y:599,t:1526930474594};\\\", \\\"{x:505,y:600,t:1526930474681};\\\", \\\"{x:505,y:601,t:1526930474706};\\\", \\\"{x:505,y:604,t:1526930474778};\\\", \\\"{x:516,y:609,t:1526930474796};\\\", \\\"{x:525,y:611,t:1526930474811};\\\", \\\"{x:531,y:613,t:1526930474827};\\\", \\\"{x:536,y:614,t:1526930474843};\\\", \\\"{x:549,y:615,t:1526930474861};\\\", \\\"{x:563,y:618,t:1526930474877};\\\", \\\"{x:575,y:620,t:1526930474894};\\\", \\\"{x:592,y:624,t:1526930474911};\\\", \\\"{x:600,y:627,t:1526930474927};\\\", \\\"{x:601,y:628,t:1526930474944};\\\", \\\"{x:601,y:629,t:1526930475025};\\\", \\\"{x:601,y:630,t:1526930475042};\\\", \\\"{x:602,y:631,t:1526930475065};\\\", \\\"{x:603,y:631,t:1526930475114};\\\", \\\"{x:604,y:631,t:1526930475146};\\\", \\\"{x:605,y:631,t:1526930475162};\\\", \\\"{x:606,y:631,t:1526930475178};\\\", \\\"{x:599,y:631,t:1526930475417};\\\", \\\"{x:593,y:635,t:1526930475429};\\\", \\\"{x:584,y:641,t:1526930475444};\\\", \\\"{x:575,y:658,t:1526930475461};\\\", \\\"{x:564,y:679,t:1526930475478};\\\", \\\"{x:557,y:690,t:1526930475494};\\\", \\\"{x:552,y:699,t:1526930475511};\\\", \\\"{x:547,y:708,t:1526930475528};\\\", \\\"{x:543,y:714,t:1526930475545};\\\", \\\"{x:538,y:719,t:1526930475561};\\\", \\\"{x:535,y:723,t:1526930475578};\\\", \\\"{x:533,y:723,t:1526930475596};\\\", \\\"{x:531,y:725,t:1526930475611};\\\", \\\"{x:530,y:727,t:1526930475628};\\\", \\\"{x:527,y:732,t:1526930475646};\\\", \\\"{x:519,y:736,t:1526930475662};\\\", \\\"{x:518,y:741,t:1526930475679};\\\", \\\"{x:514,y:744,t:1526930475695};\\\", \\\"{x:513,y:746,t:1526930475711};\\\", \\\"{x:512,y:748,t:1526930475728};\\\", \\\"{x:507,y:750,t:1526930475745};\\\", \\\"{x:500,y:754,t:1526930475762};\\\", \\\"{x:494,y:758,t:1526930475779};\\\", \\\"{x:493,y:759,t:1526930475796};\\\", \\\"{x:492,y:760,t:1526930475812};\\\", \\\"{x:493,y:760,t:1526930476178};\\\", \\\"{x:495,y:759,t:1526930476185};\\\", \\\"{x:499,y:757,t:1526930476195};\\\", \\\"{x:503,y:753,t:1526930476212};\\\", \\\"{x:505,y:751,t:1526930476229};\\\", \\\"{x:505,y:750,t:1526930476482};\\\", \\\"{x:506,y:750,t:1526930476778};\\\", \\\"{x:506,y:749,t:1526930476785};\\\", \\\"{x:507,y:747,t:1526930476795};\\\", \\\"{x:507,y:746,t:1526930476813};\\\", \\\"{x:509,y:743,t:1526930476829};\\\", \\\"{x:509,y:740,t:1526930476847};\\\", \\\"{x:512,y:738,t:1526930476862};\\\", \\\"{x:513,y:736,t:1526930476880};\\\", \\\"{x:514,y:736,t:1526930476896};\\\", \\\"{x:515,y:735,t:1526930476912};\\\", \\\"{x:515,y:734,t:1526930476930};\\\", \\\"{x:515,y:733,t:1526930476946};\\\", \\\"{x:517,y:732,t:1526930476963};\\\", \\\"{x:520,y:729,t:1526930476980};\\\", \\\"{x:526,y:720,t:1526930476996};\\\", \\\"{x:536,y:710,t:1526930477012};\\\", \\\"{x:550,y:699,t:1526930477035};\\\", \\\"{x:566,y:684,t:1526930477058};\\\", \\\"{x:578,y:677,t:1526930477062};\\\", \\\"{x:609,y:659,t:1526930477079};\\\", \\\"{x:661,y:640,t:1526930477096};\\\", \\\"{x:754,y:623,t:1526930477112};\\\", \\\"{x:923,y:607,t:1526930477128};\\\", \\\"{x:1016,y:597,t:1526930477146};\\\", \\\"{x:1074,y:594,t:1526930477162};\\\", \\\"{x:1098,y:593,t:1526930477179};\\\", \\\"{x:1108,y:593,t:1526930477196};\\\" ] }, { \\\"rt\\\": 59183, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 860194, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Start at 12 from the bottom of the graph (x-axis) and follow the line that goes up and towards the right.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8754, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 869954, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 16770, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 887739, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 15158, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 904224, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"F3GZE\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"F3GZE\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 120, dom: 773, initialDom: 836",
  "javascriptErrors": []
}