var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6a3c61cdc03c83c6b37729fdc54d0b12",
  "created": "2018-05-29T10:15:56.1506144-07:00",
  "lastActivity": "2018-05-29T10:16:36.6466144-07:00",
  "pageViews": [
    {
      "id": "052956964b2f2cffdc854581c7e8863f8e929a8a",
      "startTime": "2018-05-29T10:15:56.1506144-07:00",
      "endTime": "2018-05-29T10:16:36.6466144-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 40496,
      "engagementTime": 32847,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 40496,
  "engagementTime": 32847,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TGOML",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6b03e0d66ab012a9a7a7dcd73c64193f",
  "gdpr": false
}