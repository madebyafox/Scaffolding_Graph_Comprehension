var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6caa9a282e87245a7434d4afe889dac1",
  "created": "2018-06-01T10:16:55.7407493-07:00",
  "lastActivity": "2018-06-01T10:18:58.3104889-07:00",
  "pageViews": [
    {
      "id": "060155751664d98bb323e9d5aeaaab428472db40",
      "startTime": "2018-06-01T10:16:55.9935052-07:00",
      "endTime": "2018-06-01T10:18:58.3104889-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 122682,
      "engagementTime": 116130,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 122682,
  "engagementTime": 116130,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=1Z2H9",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5d388ad4835ab5fc21d06c5f854b3ece",
  "gdpr": false
}