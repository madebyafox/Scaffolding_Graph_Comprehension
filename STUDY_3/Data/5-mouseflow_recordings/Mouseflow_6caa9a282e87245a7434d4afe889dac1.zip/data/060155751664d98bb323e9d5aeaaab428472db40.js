var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060155751664d98bb323e9d5aeaaab428472db40"] = {
  "startTime": "2018-06-01T17:16:55.9935052Z",
  "websitePageUrl": "/16",
  "visitTime": 122682,
  "engagementTime": 116130,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "6caa9a282e87245a7434d4afe889dac1",
    "created": "2018-06-01T17:16:55.7407493+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=1Z2H9",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5d388ad4835ab5fc21d06c5f854b3ece",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6caa9a282e87245a7434d4afe889dac1/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 250,
      "e": 250,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 250,
      "e": 250,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 519,
      "y": 735
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 47426,
      "y": 40273,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 534,
      "y": 694
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 534,
      "y": 693
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 49112,
      "y": 37947,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 535,
      "y": 693
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 564,
      "y": 687
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 639,
      "y": 671
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 60915,
      "y": 36728,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 759,
      "y": 679
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 2,
      "x": 763,
      "y": 679
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 4758,
      "y": 38412,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 808,
      "y": 698
    },
    {
      "t": 2702,
      "e": 2702,
      "ty": 2,
      "x": 1018,
      "y": 786
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 23819,
      "y": 50709,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 1206,
      "y": 895
    },
    {
      "t": 2902,
      "e": 2902,
      "ty": 2,
      "x": 1264,
      "y": 921
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 2,
      "x": 1264,
      "y": 925
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 33684,
      "y": 56367,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 2,
      "x": 1263,
      "y": 933
    },
    {
      "t": 3202,
      "e": 3202,
      "ty": 2,
      "x": 1260,
      "y": 946
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 33120,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3302,
      "e": 3302,
      "ty": 2,
      "x": 1225,
      "y": 960
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1145,
      "y": 962
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 25299,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1144,
      "y": 962
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 1145,
      "y": 959
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 1148,
      "y": 955
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 25510,
      "y": 58515,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1148,
      "y": 953
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 25651,
      "y": 58229,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1151,
      "y": 949
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1159,
      "y": 939
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1167,
      "y": 926
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 26849,
      "y": 56438,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1177,
      "y": 908
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1190,
      "y": 879
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 29456,
      "y": 51067,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1221,
      "y": 822
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1225,
      "y": 820
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 30936,
      "y": 48846,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1227,
      "y": 822
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 31147,
      "y": 49204,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1230,
      "y": 826
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 1230,
      "y": 832
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1221,
      "y": 839
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 30654,
      "y": 50207,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 1208,
      "y": 859
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1197,
      "y": 878
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 28822,
      "y": 53359,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1194,
      "y": 884
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1194,
      "y": 886
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1192,
      "y": 886
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 28611,
      "y": 53573,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 789,
      "y": 786
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 453,
      "y": 607
    },
    {
      "t": 7207,
      "e": 7207,
      "ty": 6,
      "x": 451,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 38433,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7290,
      "e": 7290,
      "ty": 7,
      "x": 391,
      "y": 514,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 391,
      "y": 514
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 375,
      "y": 492
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 384,
      "y": 512
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 41,
      "x": 32251,
      "y": 40410,
      "ta": "#.strategy > p"
    },
    {
      "t": 7524,
      "e": 7524,
      "ty": 6,
      "x": 387,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 388,
      "y": 559
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 390,
      "y": 562
    },
    {
      "t": 7750,
      "e": 7750,
      "ty": 41,
      "x": 32925,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8256,
      "e": 8256,
      "ty": 3,
      "x": 390,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8258,
      "e": 8258,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8358,
      "e": 8358,
      "ty": 4,
      "x": 32925,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8358,
      "e": 8358,
      "ty": 5,
      "x": 390,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 2,
      "x": 397,
      "y": 533
    },
    {
      "t": 8608,
      "e": 8608,
      "ty": 7,
      "x": 410,
      "y": 501,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 456,
      "y": 383
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 43379,
      "y": 17450,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 487,
      "y": 316
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 489,
      "y": 314
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 494,
      "y": 312
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 44616,
      "y": 16840,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12299,
      "e": 12299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12406,
      "e": 12406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12406,
      "e": 12406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12506,
      "e": 12506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 12514,
      "e": 12514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 12611,
      "e": 12611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12611,
      "e": 12611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12674,
      "e": 12674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 12754,
      "e": 12754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12755,
      "e": 12755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12826,
      "e": 12826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 12899,
      "e": 12899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 12900,
      "e": 12900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 13018,
      "e": 13018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 13034,
      "e": 13034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13034,
      "e": 13034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13138,
      "e": 13138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13538,
      "e": 13538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13539,
      "e": 13539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13667,
      "e": 13667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13763,
      "e": 13763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13764,
      "e": 13764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13834,
      "e": 13834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13842,
      "e": 13842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13843,
      "e": 13843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13914,
      "e": 13914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13954,
      "e": 13954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13955,
      "e": 13955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14035,
      "e": 14035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14043,
      "e": 14043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14043,
      "e": 14043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14123,
      "e": 14123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14171,
      "e": 14171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14172,
      "e": 14172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14242,
      "e": 14242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14243,
      "e": 14243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14274,
      "e": 14274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 14314,
      "e": 14314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15763,
      "e": 15763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 15764,
      "e": 15764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15898,
      "e": 15898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 15930,
      "e": 15930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 15930,
      "e": 15930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16010,
      "e": 16010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 18411,
      "e": 18411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18412,
      "e": 18412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18530,
      "e": 18530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18747,
      "e": 18747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18747,
      "e": 18747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18882,
      "e": 18882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 18882,
      "e": 18882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18883,
      "e": 18883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18971,
      "e": 18971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18972,
      "e": 18972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19018,
      "e": 19018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 19082,
      "e": 19082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21851,
      "e": 21851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21852,
      "e": 21852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21954,
      "e": 21954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22010,
      "e": 22010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22011,
      "e": 22011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22082,
      "e": 22082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22083,
      "e": 22083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22138,
      "e": 22138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 22187,
      "e": 22187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22290,
      "e": 22290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22292,
      "e": 22292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22379,
      "e": 22379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22434,
      "e": 22434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22435,
      "e": 22435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22538,
      "e": 22538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22578,
      "e": 22578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22578,
      "e": 22578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22714,
      "e": 22714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22771,
      "e": 22771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22771,
      "e": 22771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22850,
      "e": 22850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23106,
      "e": 23106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23194,
      "e": 23194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot o"
    },
    {
      "t": 23467,
      "e": 23467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23468,
      "e": 23468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23562,
      "e": 23562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23883,
      "e": 23883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23884,
      "e": 23884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23963,
      "e": 23963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24035,
      "e": 24035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24036,
      "e": 24036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24114,
      "e": 24114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24130,
      "e": 24130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24130,
      "e": 24130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24210,
      "e": 24210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 24242,
      "e": 24242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24242,
      "e": 24242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24282,
      "e": 24282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24283,
      "e": 24283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24314,
      "e": 24314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 24347,
      "e": 24347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24451,
      "e": 24451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 24452,
      "e": 24452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24531,
      "e": 24531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24531,
      "e": 24531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24546,
      "e": 24546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bo"
    },
    {
      "t": 24626,
      "e": 24626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24626,
      "e": 24626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24633,
      "e": 24633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24682,
      "e": 24682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24763,
      "e": 24763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24763,
      "e": 24763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24818,
      "e": 24818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24818,
      "e": 24818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24850,
      "e": 24850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 24897,
      "e": 24897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 24898,
      "e": 24898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24930,
      "e": 24930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25010,
      "e": 25010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25012,
      "e": 25012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25049,
      "e": 25049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25105,
      "e": 25105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26714,
      "e": 26714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26803,
      "e": 26803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom"
    },
    {
      "t": 26915,
      "e": 26915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26970,
      "e": 26970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the botto"
    },
    {
      "t": 27099,
      "e": 27099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27122,
      "e": 27122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bott"
    },
    {
      "t": 28075,
      "e": 28075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28076,
      "e": 28076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28146,
      "e": 28146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28146,
      "e": 28146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28185,
      "e": 28185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 28242,
      "e": 28242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28243,
      "e": 28243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28298,
      "e": 28298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28339,
      "e": 28339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28411,
      "e": 28411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28411,
      "e": 28411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28505,
      "e": 28505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28795,
      "e": 28795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 28796,
      "e": 28796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28874,
      "e": 28874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 28929,
      "e": 28929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28930,
      "e": 28930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29034,
      "e": 29034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29035,
      "e": 29035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29043,
      "e": 29043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 29114,
      "e": 29114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29114,
      "e": 29114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29122,
      "e": 29122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29194,
      "e": 29194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29323,
      "e": 29323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29323,
      "e": 29323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29426,
      "e": 29426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29467,
      "e": 29467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29468,
      "e": 29468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29570,
      "e": 29570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29593,
      "e": 29593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29594,
      "e": 29594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29666,
      "e": 29666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 29667,
      "e": 29667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29667,
      "e": 29667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29755,
      "e": 29755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30411,
      "e": 30411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30411,
      "e": 30411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30498,
      "e": 30498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 30513,
      "e": 30513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30514,
      "e": 30514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30594,
      "e": 30594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30731,
      "e": 30731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30731,
      "e": 30731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30930,
      "e": 30930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31337,
      "e": 31337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31338,
      "e": 31338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31442,
      "e": 31442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31515,
      "e": 31515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31515,
      "e": 31515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31577,
      "e": 31577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31602,
      "e": 31602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31602,
      "e": 31602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31666,
      "e": 31666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 31722,
      "e": 31722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31722,
      "e": 31722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31803,
      "e": 31803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31890,
      "e": 31890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31892,
      "e": 31892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31970,
      "e": 31970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32066,
      "e": 32066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32066,
      "e": 32066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32146,
      "e": 32146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 32250,
      "e": 32250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32252,
      "e": 32252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32339,
      "e": 32339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32370,
      "e": 32370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32372,
      "e": 32372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32467,
      "e": 32467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33082,
      "e": 33082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33083,
      "e": 33083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33161,
      "e": 33161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33178,
      "e": 33178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33178,
      "e": 33178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33266,
      "e": 33266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33290,
      "e": 33290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33291,
      "e": 33291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33354,
      "e": 33354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33523,
      "e": 33523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 33523,
      "e": 33523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33618,
      "e": 33618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 33625,
      "e": 33625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33626,
      "e": 33626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33722,
      "e": 33722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 33826,
      "e": 33826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33828,
      "e": 33828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33906,
      "e": 33906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33947,
      "e": 33947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33948,
      "e": 33948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34018,
      "e": 34018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34050,
      "e": 34050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34051,
      "e": 34051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34130,
      "e": 34130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34131,
      "e": 34131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34153,
      "e": 34153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 34201,
      "e": 34201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34394,
      "e": 34394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34396,
      "e": 34396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34499,
      "e": 34499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34851,
      "e": 34851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34851,
      "e": 34851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34929,
      "e": 34929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34930,
      "e": 34930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34970,
      "e": 34970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 35018,
      "e": 35018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35018,
      "e": 35018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35058,
      "e": 35058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35098,
      "e": 35098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35107,
      "e": 35107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35107,
      "e": 35107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35193,
      "e": 35193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38539,
      "e": 38539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38539,
      "e": 38539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38626,
      "e": 38626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38634,
      "e": 38634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38634,
      "e": 38634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38706,
      "e": 38706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38786,
      "e": 38786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38786,
      "e": 38786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38906,
      "e": 38906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38908,
      "e": 38908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38908,
      "e": 38908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38978,
      "e": 38978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39410,
      "e": 39410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 39412,
      "e": 39412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39497,
      "e": 39497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'"
    },
    {
      "t": 39498,
      "e": 39498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39498,
      "e": 39498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39602,
      "e": 39602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39610,
      "e": 39610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39611,
      "e": 39611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39681,
      "e": 39681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39689,
      "e": 39689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39690,
      "e": 39690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39794,
      "e": 39794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39810,
      "e": 39810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39811,
      "e": 39811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39905,
      "e": 39905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 40001,
      "e": 40001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40098,
      "e": 40098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40098,
      "e": 40098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40202,
      "e": 40202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 40202,
      "e": 40202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40234,
      "e": 40234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||op"
    },
    {
      "t": 40298,
      "e": 40298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40298,
      "e": 40298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40305,
      "e": 40305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40394,
      "e": 40394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40499,
      "e": 40499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40499,
      "e": 40499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40577,
      "e": 40577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 40578,
      "e": 40578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40578,
      "e": 40578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40650,
      "e": 40650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40738,
      "e": 40738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40739,
      "e": 40739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40793,
      "e": 40793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40793,
      "e": 40793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40826,
      "e": 40826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 40881,
      "e": 40881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40881,
      "e": 40881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40890,
      "e": 40890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40945,
      "e": 40945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40946,
      "e": 40946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40953,
      "e": 40953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41018,
      "e": 41018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41066,
      "e": 41066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41067,
      "e": 41067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41129,
      "e": 41129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 41137,
      "e": 41137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41137,
      "e": 41137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41218,
      "e": 41218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41226,
      "e": 41226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41226,
      "e": 41226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41297,
      "e": 41297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41394,
      "e": 41394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41395,
      "e": 41395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41481,
      "e": 41481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 41481,
      "e": 41481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41482,
      "e": 41482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41553,
      "e": 41553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41746,
      "e": 41746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41747,
      "e": 41747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41802,
      "e": 41802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 42130,
      "e": 42130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42234,
      "e": 42234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the ri"
    },
    {
      "t": 42322,
      "e": 42322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 42322,
      "e": 42322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42410,
      "e": 42410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 42466,
      "e": 42466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42466,
      "e": 42466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42537,
      "e": 42537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 42594,
      "e": 42594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42595,
      "e": 42595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42665,
      "e": 42665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45273,
      "e": 45273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 45273,
      "e": 45273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45345,
      "e": 45345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 45635,
      "e": 45635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45635,
      "e": 45635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45697,
      "e": 45697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45803,
      "e": 45803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. "
    },
    {
      "t": 45858,
      "e": 45858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 46027,
      "e": 46027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 46028,
      "e": 46028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46073,
      "e": 46073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 46097,
      "e": 46097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46169,
      "e": 46169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46170,
      "e": 46170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46242,
      "e": 46242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46242,
      "e": 46242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46274,
      "e": 46274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 46339,
      "e": 46339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46377,
      "e": 46377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 46377,
      "e": 46377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46434,
      "e": 46434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 46473,
      "e": 46473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46474,
      "e": 46474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46546,
      "e": 46546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 46682,
      "e": 46682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46683,
      "e": 46683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46745,
      "e": 46745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 47010,
      "e": 47010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 47011,
      "e": 47011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47105,
      "e": 47105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 47146,
      "e": 47146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47146,
      "e": 47146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47273,
      "e": 47273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47274,
      "e": 47274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47306,
      "e": 47306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 47378,
      "e": 47378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47901,
      "e": 47901,
      "ty": 2,
      "x": 515,
      "y": 315
    },
    {
      "t": 48002,
      "e": 48002,
      "ty": 2,
      "x": 618,
      "y": 409
    },
    {
      "t": 48002,
      "e": 48002,
      "ty": 41,
      "x": 58555,
      "y": 22214,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 48102,
      "e": 48102,
      "ty": 2,
      "x": 642,
      "y": 452
    },
    {
      "t": 48202,
      "e": 48202,
      "ty": 2,
      "x": 638,
      "y": 465
    },
    {
      "t": 48251,
      "e": 48251,
      "ty": 41,
      "x": 60241,
      "y": 25427,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 48301,
      "e": 48301,
      "ty": 2,
      "x": 623,
      "y": 466
    },
    {
      "t": 48401,
      "e": 48401,
      "ty": 2,
      "x": 599,
      "y": 434
    },
    {
      "t": 48501,
      "e": 48501,
      "ty": 2,
      "x": 617,
      "y": 397
    },
    {
      "t": 48501,
      "e": 48501,
      "ty": 41,
      "x": 58442,
      "y": 21549,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 48601,
      "e": 48601,
      "ty": 2,
      "x": 669,
      "y": 359
    },
    {
      "t": 48751,
      "e": 48751,
      "ty": 41,
      "x": 64287,
      "y": 19444,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 49595,
      "e": 49595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49596,
      "e": 49596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49690,
      "e": 49690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50002,
      "e": 50002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50017,
      "e": 50017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50017,
      "e": 50017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50113,
      "e": 50113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50113,
      "e": 50113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50137,
      "e": 50137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||no"
    },
    {
      "t": 50185,
      "e": 50185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 50185,
      "e": 50185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50226,
      "e": 50226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 50266,
      "e": 50266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50466,
      "e": 50466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50467,
      "e": 50467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50585,
      "e": 50585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50602,
      "e": 50602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50603,
      "e": 50603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50723,
      "e": 50723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 52851,
      "e": 52851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52851,
      "e": 52851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52953,
      "e": 52953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53154,
      "e": 53154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 53155,
      "e": 53155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53241,
      "e": 53241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 53786,
      "e": 53786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53866,
      "e": 53866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes "
    },
    {
      "t": 53873,
      "e": 53873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53874,
      "e": 53874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54007,
      "e": 54007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes a"
    },
    {
      "t": 54022,
      "e": 54022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54030,
      "e": 54030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 54030,
      "e": 54030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54110,
      "e": 54110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54110,
      "e": 54110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54142,
      "e": 54142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 54207,
      "e": 54207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54213,
      "e": 54213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54215,
      "e": 54215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54302,
      "e": 54302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54408,
      "e": 54408,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes are "
    },
    {
      "t": 54430,
      "e": 54430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 54431,
      "e": 54431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54549,
      "e": 54549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 54647,
      "e": 54647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54647,
      "e": 54647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54710,
      "e": 54710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54974,
      "e": 54974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55070,
      "e": 55070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes are o"
    },
    {
      "t": 55262,
      "e": 55262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55263,
      "e": 55263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55350,
      "e": 55350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55353,
      "e": 55353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55389,
      "e": 55389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 55430,
      "e": 55430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55431,
      "e": 55431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55437,
      "e": 55437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55517,
      "e": 55517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55542,
      "e": 55542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 55543,
      "e": 55543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55622,
      "e": 55622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 55661,
      "e": 55661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 55662,
      "e": 55662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55733,
      "e": 55733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55735,
      "e": 55735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55765,
      "e": 55765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 55790,
      "e": 55790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55790,
      "e": 55790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55822,
      "e": 55822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55862,
      "e": 55862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55894,
      "e": 55894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 55894,
      "e": 55894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55974,
      "e": 55974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 56087,
      "e": 56087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56087,
      "e": 56087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56182,
      "e": 56088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56182,
      "e": 56088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56214,
      "e": 56120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 56254,
      "e": 56160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56343,
      "e": 56249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56343,
      "e": 56249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56406,
      "e": 56312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56445,
      "e": 56351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56445,
      "e": 56351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56517,
      "e": 56423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56566,
      "e": 56472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 56567,
      "e": 56473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56694,
      "e": 56600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 56726,
      "e": 56632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56727,
      "e": 56633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56797,
      "e": 56703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56821,
      "e": 56727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56821,
      "e": 56727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56934,
      "e": 56840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 56935,
      "e": 56841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56982,
      "e": 56888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 57030,
      "e": 56936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57134,
      "e": 57040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57135,
      "e": 57041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57213,
      "e": 57119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57230,
      "e": 57136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57230,
      "e": 57136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57302,
      "e": 57208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57408,
      "e": 57314,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes are on that line start "
    },
    {
      "t": 57439,
      "e": 57345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57439,
      "e": 57345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57582,
      "e": 57488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57598,
      "e": 57504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57598,
      "e": 57504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57670,
      "e": 57576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57693,
      "e": 57599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57694,
      "e": 57600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57782,
      "e": 57688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58190,
      "e": 58096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 58191,
      "e": 58097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58286,
      "e": 58192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 58286,
      "e": 58192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58309,
      "e": 58215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 58374,
      "e": 58280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58390,
      "e": 58296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58390,
      "e": 58296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58477,
      "e": 58383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58566,
      "e": 58472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 58566,
      "e": 58472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58694,
      "e": 58600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 58702,
      "e": 58608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 58702,
      "e": 58608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58766,
      "e": 58672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 59183,
      "e": 59089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 59183,
      "e": 59089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59237,
      "e": 59143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 59705,
      "e": 59611,
      "ty": 2,
      "x": 714,
      "y": 499
    },
    {
      "t": 59723,
      "e": 59629,
      "ty": 6,
      "x": 673,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59755,
      "e": 59661,
      "ty": 41,
      "x": 59004,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59805,
      "e": 59711,
      "ty": 7,
      "x": 569,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59807,
      "e": 59713,
      "ty": 2,
      "x": 569,
      "y": 605
    },
    {
      "t": 59888,
      "e": 59794,
      "ty": 6,
      "x": 471,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59905,
      "e": 59811,
      "ty": 2,
      "x": 471,
      "y": 591
    },
    {
      "t": 60005,
      "e": 59911,
      "ty": 2,
      "x": 430,
      "y": 582
    },
    {
      "t": 60005,
      "e": 59911,
      "ty": 41,
      "x": 37421,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60205,
      "e": 60111,
      "ty": 2,
      "x": 420,
      "y": 574
    },
    {
      "t": 60255,
      "e": 60161,
      "ty": 41,
      "x": 35623,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60305,
      "e": 60211,
      "ty": 2,
      "x": 409,
      "y": 557
    },
    {
      "t": 60405,
      "e": 60311,
      "ty": 2,
      "x": 392,
      "y": 549
    },
    {
      "t": 60505,
      "e": 60411,
      "ty": 2,
      "x": 384,
      "y": 548
    },
    {
      "t": 60505,
      "e": 60411,
      "ty": 41,
      "x": 32251,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60605,
      "e": 60511,
      "ty": 2,
      "x": 368,
      "y": 552
    },
    {
      "t": 60705,
      "e": 60611,
      "ty": 2,
      "x": 367,
      "y": 552
    },
    {
      "t": 60755,
      "e": 60661,
      "ty": 41,
      "x": 30340,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60805,
      "e": 60711,
      "ty": 2,
      "x": 365,
      "y": 553
    },
    {
      "t": 60904,
      "e": 60810,
      "ty": 2,
      "x": 361,
      "y": 554
    },
    {
      "t": 61005,
      "e": 60911,
      "ty": 2,
      "x": 359,
      "y": 554
    },
    {
      "t": 61006,
      "e": 60912,
      "ty": 41,
      "x": 29440,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61010,
      "e": 60916,
      "ty": 3,
      "x": 359,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61099,
      "e": 61005,
      "ty": 4,
      "x": 29440,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61099,
      "e": 61005,
      "ty": 5,
      "x": 359,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61205,
      "e": 61111,
      "ty": 2,
      "x": 392,
      "y": 537
    },
    {
      "t": 61223,
      "e": 61129,
      "ty": 7,
      "x": 448,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61255,
      "e": 61161,
      "ty": 41,
      "x": 42930,
      "y": 2962,
      "ta": "#.strategy > p"
    },
    {
      "t": 61304,
      "e": 61210,
      "ty": 2,
      "x": 535,
      "y": 479
    },
    {
      "t": 61405,
      "e": 61311,
      "ty": 2,
      "x": 539,
      "y": 477
    },
    {
      "t": 61506,
      "e": 61412,
      "ty": 41,
      "x": 49674,
      "y": 0,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 61903,
      "e": 61809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 61997,
      "e": 61903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66005,
      "e": 65911,
      "ty": 2,
      "x": 541,
      "y": 476
    },
    {
      "t": 66005,
      "e": 65911,
      "ty": 41,
      "x": 49899,
      "y": 25925,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 66105,
      "e": 66011,
      "ty": 2,
      "x": 541,
      "y": 477
    },
    {
      "t": 66194,
      "e": 66100,
      "ty": 6,
      "x": 498,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66205,
      "e": 66111,
      "ty": 2,
      "x": 498,
      "y": 526
    },
    {
      "t": 66255,
      "e": 66161,
      "ty": 41,
      "x": 41581,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66276,
      "e": 66182,
      "ty": 7,
      "x": 452,
      "y": 619,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66305,
      "e": 66211,
      "ty": 2,
      "x": 447,
      "y": 635
    },
    {
      "t": 66377,
      "e": 66283,
      "ty": 6,
      "x": 439,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 66405,
      "e": 66311,
      "ty": 2,
      "x": 437,
      "y": 659
    },
    {
      "t": 66505,
      "e": 66411,
      "ty": 2,
      "x": 436,
      "y": 661
    },
    {
      "t": 66505,
      "e": 66411,
      "ty": 41,
      "x": 53195,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 66805,
      "e": 66711,
      "ty": 2,
      "x": 434,
      "y": 661
    },
    {
      "t": 66905,
      "e": 66811,
      "ty": 2,
      "x": 427,
      "y": 665
    },
    {
      "t": 67005,
      "e": 66911,
      "ty": 2,
      "x": 418,
      "y": 668
    },
    {
      "t": 67005,
      "e": 66911,
      "ty": 41,
      "x": 43365,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 67305,
      "e": 67211,
      "ty": 2,
      "x": 414,
      "y": 671
    },
    {
      "t": 67406,
      "e": 67312,
      "ty": 2,
      "x": 407,
      "y": 678
    },
    {
      "t": 67505,
      "e": 67411,
      "ty": 41,
      "x": 37358,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 68346,
      "e": 68252,
      "ty": 3,
      "x": 407,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 68350,
      "e": 68254,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes are on that line start at 12 pm."
    },
    {
      "t": 68352,
      "e": 68256,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68354,
      "e": 68258,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 68441,
      "e": 68345,
      "ty": 4,
      "x": 37358,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 68453,
      "e": 68357,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 68453,
      "e": 68357,
      "ty": 5,
      "x": 407,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 68463,
      "e": 68367,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 69460,
      "e": 69364,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 70007,
      "e": 69911,
      "ty": 6,
      "x": 967,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70007,
      "e": 69911,
      "ty": 2,
      "x": 967,
      "y": 648
    },
    {
      "t": 70007,
      "e": 69911,
      "ty": 41,
      "x": 34389,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70013,
      "e": 69917,
      "ty": 7,
      "x": 979,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70106,
      "e": 70010,
      "ty": 2,
      "x": 995,
      "y": 638
    },
    {
      "t": 70206,
      "e": 70110,
      "ty": 2,
      "x": 994,
      "y": 583
    },
    {
      "t": 70214,
      "e": 70118,
      "ty": 6,
      "x": 992,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70256,
      "e": 70160,
      "ty": 41,
      "x": 38931,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70305,
      "e": 70209,
      "ty": 2,
      "x": 988,
      "y": 560
    },
    {
      "t": 70451,
      "e": 70355,
      "ty": 3,
      "x": 988,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70452,
      "e": 70356,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70506,
      "e": 70410,
      "ty": 41,
      "x": 38931,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70521,
      "e": 70425,
      "ty": 4,
      "x": 38931,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70521,
      "e": 70425,
      "ty": 5,
      "x": 988,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71039,
      "e": 70943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 71039,
      "e": 70943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71102,
      "e": 71006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 71205,
      "e": 71109,
      "ty": 2,
      "x": 985,
      "y": 564
    },
    {
      "t": 71206,
      "e": 71110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 71207,
      "e": 71111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71231,
      "e": 71135,
      "ty": 7,
      "x": 983,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71255,
      "e": 71159,
      "ty": 41,
      "x": 37201,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 71277,
      "e": 71181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 71305,
      "e": 71209,
      "ty": 2,
      "x": 975,
      "y": 614
    },
    {
      "t": 71405,
      "e": 71309,
      "ty": 2,
      "x": 972,
      "y": 624
    },
    {
      "t": 71506,
      "e": 71410,
      "ty": 2,
      "x": 971,
      "y": 646
    },
    {
      "t": 71506,
      "e": 71410,
      "ty": 41,
      "x": 35254,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 71515,
      "e": 71419,
      "ty": 6,
      "x": 971,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71606,
      "e": 71510,
      "ty": 2,
      "x": 971,
      "y": 656
    },
    {
      "t": 71746,
      "e": 71650,
      "ty": 3,
      "x": 971,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71747,
      "e": 71651,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 71748,
      "e": 71652,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71750,
      "e": 71654,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71756,
      "e": 71660,
      "ty": 41,
      "x": 35254,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71826,
      "e": 71730,
      "ty": 4,
      "x": 35254,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71827,
      "e": 71731,
      "ty": 5,
      "x": 971,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72254,
      "e": 72158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 72454,
      "e": 72358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 72455,
      "e": 72359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72542,
      "e": 72446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 72543,
      "e": 72447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 72614,
      "e": 72518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 72615,
      "e": 72519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72725,
      "e": 72629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ph"
    },
    {
      "t": 72726,
      "e": 72630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 72726,
      "e": 72630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72814,
      "e": 72718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 72926,
      "e": 72830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 72926,
      "e": 72830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73029,
      "e": 72933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phil"
    },
    {
      "t": 73110,
      "e": 73014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 73110,
      "e": 73014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73198,
      "e": 73102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 73270,
      "e": 73174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 73271,
      "e": 73175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73341,
      "e": 73245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 73381,
      "e": 73285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 73381,
      "e": 73285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73526,
      "e": 73430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 73806,
      "e": 73710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 73806,
      "e": 73710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73877,
      "e": 73781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 74022,
      "e": 73926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 74022,
      "e": 73926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74085,
      "e": 73989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 74133,
      "e": 74037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 74133,
      "e": 74037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74213,
      "e": 74117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 74214,
      "e": 74118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74246,
      "e": 74150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 74326,
      "e": 74230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 74602,
      "e": 74506,
      "ty": 7,
      "x": 1021,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74605,
      "e": 74509,
      "ty": 2,
      "x": 1021,
      "y": 673
    },
    {
      "t": 74705,
      "e": 74609,
      "ty": 2,
      "x": 1029,
      "y": 680
    },
    {
      "t": 74756,
      "e": 74660,
      "ty": 41,
      "x": 35160,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 74806,
      "e": 74710,
      "ty": 2,
      "x": 1028,
      "y": 685
    },
    {
      "t": 74851,
      "e": 74755,
      "ty": 6,
      "x": 1023,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 74905,
      "e": 74809,
      "ty": 2,
      "x": 995,
      "y": 702
    },
    {
      "t": 75005,
      "e": 74909,
      "ty": 2,
      "x": 980,
      "y": 704
    },
    {
      "t": 75006,
      "e": 74910,
      "ty": 41,
      "x": 43332,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75205,
      "e": 75109,
      "ty": 2,
      "x": 977,
      "y": 702
    },
    {
      "t": 75256,
      "e": 75160,
      "ty": 41,
      "x": 39209,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75305,
      "e": 75209,
      "ty": 2,
      "x": 972,
      "y": 693
    },
    {
      "t": 76299,
      "e": 76203,
      "ty": 3,
      "x": 972,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76299,
      "e": 76203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philippines"
    },
    {
      "t": 76300,
      "e": 76204,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76301,
      "e": 76205,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76401,
      "e": 76305,
      "ty": 4,
      "x": 39209,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76401,
      "e": 76305,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76403,
      "e": 76307,
      "ty": 5,
      "x": 972,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76403,
      "e": 76307,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 77005,
      "e": 76909,
      "ty": 2,
      "x": 971,
      "y": 693
    },
    {
      "t": 77005,
      "e": 76909,
      "ty": 41,
      "x": 33163,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 77427,
      "e": 77331,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 77705,
      "e": 77609,
      "ty": 2,
      "x": 967,
      "y": 699
    },
    {
      "t": 77755,
      "e": 77610,
      "ty": 41,
      "x": 36683,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 78205,
      "e": 78060,
      "ty": 2,
      "x": 966,
      "y": 686
    },
    {
      "t": 78254,
      "e": 78109,
      "ty": 41,
      "x": 30040,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 78305,
      "e": 78160,
      "ty": 2,
      "x": 925,
      "y": 415
    },
    {
      "t": 78405,
      "e": 78260,
      "ty": 2,
      "x": 888,
      "y": 264
    },
    {
      "t": 78505,
      "e": 78360,
      "ty": 2,
      "x": 867,
      "y": 217
    },
    {
      "t": 78505,
      "e": 78360,
      "ty": 41,
      "x": 10816,
      "y": 15761,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 78604,
      "e": 78459,
      "ty": 2,
      "x": 855,
      "y": 216
    },
    {
      "t": 78655,
      "e": 78510,
      "ty": 6,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 78704,
      "e": 78559,
      "ty": 7,
      "x": 825,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 78705,
      "e": 78560,
      "ty": 2,
      "x": 825,
      "y": 246
    },
    {
      "t": 78755,
      "e": 78610,
      "ty": 41,
      "x": 849,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 78805,
      "e": 78660,
      "ty": 2,
      "x": 825,
      "y": 253
    },
    {
      "t": 78904,
      "e": 78759,
      "ty": 2,
      "x": 825,
      "y": 257
    },
    {
      "t": 79003,
      "e": 78858,
      "ty": 6,
      "x": 828,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 79004,
      "e": 78859,
      "ty": 2,
      "x": 828,
      "y": 260
    },
    {
      "t": 79005,
      "e": 78860,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 79105,
      "e": 78960,
      "ty": 7,
      "x": 833,
      "y": 273,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 79106,
      "e": 78961,
      "ty": 2,
      "x": 833,
      "y": 273
    },
    {
      "t": 79205,
      "e": 79060,
      "ty": 6,
      "x": 835,
      "y": 289,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 79207,
      "e": 79062,
      "ty": 2,
      "x": 835,
      "y": 289
    },
    {
      "t": 79255,
      "e": 79110,
      "ty": 41,
      "x": 48284,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 79272,
      "e": 79127,
      "ty": 7,
      "x": 836,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 79306,
      "e": 79161,
      "ty": 2,
      "x": 836,
      "y": 305
    },
    {
      "t": 79405,
      "e": 79260,
      "ty": 2,
      "x": 836,
      "y": 311
    },
    {
      "t": 79454,
      "e": 79309,
      "ty": 6,
      "x": 835,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79505,
      "e": 79360,
      "ty": 2,
      "x": 833,
      "y": 318
    },
    {
      "t": 79505,
      "e": 79360,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79605,
      "e": 79460,
      "ty": 2,
      "x": 832,
      "y": 319
    },
    {
      "t": 79755,
      "e": 79610,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79804,
      "e": 79659,
      "ty": 2,
      "x": 829,
      "y": 321
    },
    {
      "t": 79819,
      "e": 79674,
      "ty": 3,
      "x": 829,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79820,
      "e": 79675,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79914,
      "e": 79769,
      "ty": 4,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79915,
      "e": 79770,
      "ty": 5,
      "x": 829,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 79916,
      "e": 79771,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 80504,
      "e": 80359,
      "ty": 2,
      "x": 829,
      "y": 324
    },
    {
      "t": 80505,
      "e": 80360,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 80506,
      "e": 80361,
      "ty": 7,
      "x": 829,
      "y": 330,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 80605,
      "e": 80460,
      "ty": 2,
      "x": 829,
      "y": 368
    },
    {
      "t": 80705,
      "e": 80560,
      "ty": 2,
      "x": 829,
      "y": 403
    },
    {
      "t": 80739,
      "e": 80594,
      "ty": 6,
      "x": 828,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80755,
      "e": 80610,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80805,
      "e": 80660,
      "ty": 2,
      "x": 828,
      "y": 409
    },
    {
      "t": 80857,
      "e": 80712,
      "ty": 7,
      "x": 827,
      "y": 423,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80889,
      "e": 80744,
      "ty": 6,
      "x": 826,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80904,
      "e": 80759,
      "ty": 2,
      "x": 826,
      "y": 436
    },
    {
      "t": 80940,
      "e": 80760,
      "ty": 7,
      "x": 826,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 81005,
      "e": 80825,
      "ty": 2,
      "x": 826,
      "y": 463
    },
    {
      "t": 81005,
      "e": 80825,
      "ty": 41,
      "x": 4839,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 81006,
      "e": 80826,
      "ty": 6,
      "x": 826,
      "y": 470,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 81039,
      "e": 80859,
      "ty": 7,
      "x": 826,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 81104,
      "e": 80924,
      "ty": 2,
      "x": 826,
      "y": 486
    },
    {
      "t": 81122,
      "e": 80942,
      "ty": 6,
      "x": 826,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81204,
      "e": 81024,
      "ty": 2,
      "x": 827,
      "y": 494
    },
    {
      "t": 81255,
      "e": 81075,
      "ty": 41,
      "x": 2914,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81405,
      "e": 81225,
      "ty": 2,
      "x": 828,
      "y": 498
    },
    {
      "t": 81505,
      "e": 81325,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81715,
      "e": 81535,
      "ty": 3,
      "x": 828,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81716,
      "e": 81536,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 81717,
      "e": 81537,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81809,
      "e": 81629,
      "ty": 4,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81810,
      "e": 81630,
      "ty": 5,
      "x": 828,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 81810,
      "e": 81630,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 82140,
      "e": 81960,
      "ty": 7,
      "x": 825,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 82205,
      "e": 82025,
      "ty": 2,
      "x": 812,
      "y": 511
    },
    {
      "t": 82254,
      "e": 82074,
      "ty": 41,
      "x": 27171,
      "y": 28640,
      "ta": "html > body"
    },
    {
      "t": 82305,
      "e": 82125,
      "ty": 2,
      "x": 772,
      "y": 567
    },
    {
      "t": 82404,
      "e": 82224,
      "ty": 2,
      "x": 757,
      "y": 648
    },
    {
      "t": 82504,
      "e": 82324,
      "ty": 2,
      "x": 773,
      "y": 688
    },
    {
      "t": 82505,
      "e": 82325,
      "ty": 41,
      "x": 26344,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 82605,
      "e": 82425,
      "ty": 2,
      "x": 795,
      "y": 691
    },
    {
      "t": 82705,
      "e": 82525,
      "ty": 2,
      "x": 835,
      "y": 690
    },
    {
      "t": 82755,
      "e": 82575,
      "ty": 41,
      "x": 4171,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 82804,
      "e": 82624,
      "ty": 2,
      "x": 839,
      "y": 689
    },
    {
      "t": 82905,
      "e": 82725,
      "ty": 2,
      "x": 840,
      "y": 689
    },
    {
      "t": 83005,
      "e": 82825,
      "ty": 41,
      "x": 4409,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 83405,
      "e": 83225,
      "ty": 2,
      "x": 843,
      "y": 689
    },
    {
      "t": 83504,
      "e": 83324,
      "ty": 2,
      "x": 847,
      "y": 687
    },
    {
      "t": 83505,
      "e": 83325,
      "ty": 41,
      "x": 6070,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 83605,
      "e": 83425,
      "ty": 2,
      "x": 848,
      "y": 686
    },
    {
      "t": 83705,
      "e": 83525,
      "ty": 2,
      "x": 842,
      "y": 685
    },
    {
      "t": 83755,
      "e": 83575,
      "ty": 41,
      "x": 4182,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 83757,
      "e": 83577,
      "ty": 6,
      "x": 835,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 83805,
      "e": 83625,
      "ty": 2,
      "x": 826,
      "y": 675
    },
    {
      "t": 83807,
      "e": 83627,
      "ty": 7,
      "x": 824,
      "y": 673,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 83904,
      "e": 83724,
      "ty": 2,
      "x": 820,
      "y": 671
    },
    {
      "t": 84005,
      "e": 83825,
      "ty": 41,
      "x": 27963,
      "y": 36728,
      "ta": "html > body"
    },
    {
      "t": 84105,
      "e": 83925,
      "ty": 2,
      "x": 823,
      "y": 671
    },
    {
      "t": 84169,
      "e": 83989,
      "ty": 6,
      "x": 826,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84205,
      "e": 84025,
      "ty": 2,
      "x": 826,
      "y": 671
    },
    {
      "t": 84255,
      "e": 84075,
      "ty": 41,
      "x": 2914,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84305,
      "e": 84125,
      "ty": 2,
      "x": 827,
      "y": 671
    },
    {
      "t": 84306,
      "e": 84126,
      "ty": 3,
      "x": 827,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84307,
      "e": 84127,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 84308,
      "e": 84128,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84362,
      "e": 84182,
      "ty": 4,
      "x": 2914,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84363,
      "e": 84183,
      "ty": 5,
      "x": 827,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84364,
      "e": 84184,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 84661,
      "e": 84481,
      "ty": 7,
      "x": 825,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 84705,
      "e": 84525,
      "ty": 2,
      "x": 806,
      "y": 719
    },
    {
      "t": 84754,
      "e": 84574,
      "ty": 41,
      "x": 27102,
      "y": 44096,
      "ta": "html > body"
    },
    {
      "t": 84805,
      "e": 84625,
      "ty": 2,
      "x": 795,
      "y": 861
    },
    {
      "t": 84905,
      "e": 84725,
      "ty": 2,
      "x": 797,
      "y": 884
    },
    {
      "t": 85005,
      "e": 84825,
      "ty": 2,
      "x": 812,
      "y": 911
    },
    {
      "t": 85005,
      "e": 84825,
      "ty": 41,
      "x": 27687,
      "y": 50023,
      "ta": "html > body"
    },
    {
      "t": 85042,
      "e": 84862,
      "ty": 6,
      "x": 826,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 85105,
      "e": 84925,
      "ty": 2,
      "x": 826,
      "y": 934
    },
    {
      "t": 85205,
      "e": 85025,
      "ty": 2,
      "x": 826,
      "y": 935
    },
    {
      "t": 85255,
      "e": 85075,
      "ty": 41,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 85277,
      "e": 85075,
      "ty": 7,
      "x": 833,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 85305,
      "e": 85103,
      "ty": 2,
      "x": 834,
      "y": 943
    },
    {
      "t": 85359,
      "e": 85157,
      "ty": 6,
      "x": 835,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 85404,
      "e": 85202,
      "ty": 2,
      "x": 836,
      "y": 961
    },
    {
      "t": 85505,
      "e": 85303,
      "ty": 2,
      "x": 836,
      "y": 964
    },
    {
      "t": 85505,
      "e": 85303,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 85858,
      "e": 85656,
      "ty": 3,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 85859,
      "e": 85657,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 85860,
      "e": 85658,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 85913,
      "e": 85711,
      "ty": 4,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 85913,
      "e": 85711,
      "ty": 5,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 85913,
      "e": 85711,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 86077,
      "e": 85875,
      "ty": 7,
      "x": 838,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86105,
      "e": 85903,
      "ty": 2,
      "x": 844,
      "y": 979
    },
    {
      "t": 86144,
      "e": 85942,
      "ty": 6,
      "x": 859,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86205,
      "e": 86003,
      "ty": 2,
      "x": 869,
      "y": 1026
    },
    {
      "t": 86255,
      "e": 86053,
      "ty": 41,
      "x": 20398,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86499,
      "e": 86297,
      "ty": 3,
      "x": 869,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86500,
      "e": 86298,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 86501,
      "e": 86299,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86561,
      "e": 86359,
      "ty": 4,
      "x": 20913,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86561,
      "e": 86359,
      "ty": 5,
      "x": 870,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86564,
      "e": 86362,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86564,
      "e": 86362,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 86565,
      "e": 86363,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 86605,
      "e": 86403,
      "ty": 2,
      "x": 870,
      "y": 1026
    },
    {
      "t": 86755,
      "e": 86553,
      "ty": 41,
      "x": 29685,
      "y": 56394,
      "ta": "html > body"
    },
    {
      "t": 87005,
      "e": 86803,
      "ty": 2,
      "x": 800,
      "y": 989
    },
    {
      "t": 87005,
      "e": 86803,
      "ty": 41,
      "x": 27274,
      "y": 54344,
      "ta": "html > body"
    },
    {
      "t": 87105,
      "e": 86903,
      "ty": 2,
      "x": 433,
      "y": 789
    },
    {
      "t": 87205,
      "e": 87003,
      "ty": 2,
      "x": 433,
      "y": 788
    },
    {
      "t": 87255,
      "e": 87053,
      "ty": 41,
      "x": 14636,
      "y": 43209,
      "ta": "html > body"
    },
    {
      "t": 87905,
      "e": 87703,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 88205,
      "e": 88003,
      "ty": 2,
      "x": 433,
      "y": 787
    },
    {
      "t": 88255,
      "e": 88053,
      "ty": 41,
      "x": 6865,
      "y": 52047,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 88304,
      "e": 88102,
      "ty": 2,
      "x": 434,
      "y": 779
    },
    {
      "t": 88405,
      "e": 88203,
      "ty": 2,
      "x": 456,
      "y": 735
    },
    {
      "t": 88505,
      "e": 88303,
      "ty": 2,
      "x": 548,
      "y": 736
    },
    {
      "t": 88505,
      "e": 88303,
      "ty": 41,
      "x": 12522,
      "y": 39505,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 88605,
      "e": 88403,
      "ty": 2,
      "x": 684,
      "y": 796
    },
    {
      "t": 88705,
      "e": 88503,
      "ty": 2,
      "x": 695,
      "y": 802
    },
    {
      "t": 88755,
      "e": 88553,
      "ty": 41,
      "x": 19804,
      "y": 5284,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 88805,
      "e": 88603,
      "ty": 2,
      "x": 699,
      "y": 806
    },
    {
      "t": 88905,
      "e": 88703,
      "ty": 2,
      "x": 707,
      "y": 807
    },
    {
      "t": 89005,
      "e": 88803,
      "ty": 2,
      "x": 728,
      "y": 807
    },
    {
      "t": 89005,
      "e": 88803,
      "ty": 41,
      "x": 21378,
      "y": 9965,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 89105,
      "e": 88903,
      "ty": 2,
      "x": 898,
      "y": 742
    },
    {
      "t": 89205,
      "e": 89003,
      "ty": 2,
      "x": 1000,
      "y": 570
    },
    {
      "t": 89256,
      "e": 89054,
      "ty": 41,
      "x": 34759,
      "y": 34138,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 89805,
      "e": 89603,
      "ty": 2,
      "x": 999,
      "y": 563
    },
    {
      "t": 89905,
      "e": 89703,
      "ty": 2,
      "x": 1006,
      "y": 521
    },
    {
      "t": 90005,
      "e": 89803,
      "ty": 2,
      "x": 1023,
      "y": 466
    },
    {
      "t": 90006,
      "e": 89804,
      "ty": 41,
      "x": 35891,
      "y": 15227,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 90105,
      "e": 89903,
      "ty": 2,
      "x": 1028,
      "y": 454
    },
    {
      "t": 90205,
      "e": 90003,
      "ty": 2,
      "x": 1029,
      "y": 452
    },
    {
      "t": 90255,
      "e": 90053,
      "ty": 41,
      "x": 36186,
      "y": 55794,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 100006,
      "e": 95053,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 101605,
      "e": 95053,
      "ty": 2,
      "x": 1029,
      "y": 451
    },
    {
      "t": 101704,
      "e": 95152,
      "ty": 2,
      "x": 1023,
      "y": 453
    },
    {
      "t": 101754,
      "e": 95202,
      "ty": 41,
      "x": 35448,
      "y": 61256,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 101804,
      "e": 95252,
      "ty": 2,
      "x": 1004,
      "y": 468
    },
    {
      "t": 101905,
      "e": 95353,
      "ty": 2,
      "x": 988,
      "y": 487
    },
    {
      "t": 102005,
      "e": 95453,
      "ty": 2,
      "x": 978,
      "y": 499
    },
    {
      "t": 102005,
      "e": 95453,
      "ty": 41,
      "x": 33677,
      "y": 6442,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102105,
      "e": 95553,
      "ty": 2,
      "x": 977,
      "y": 501
    },
    {
      "t": 102255,
      "e": 95703,
      "ty": 41,
      "x": 33530,
      "y": 7612,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102304,
      "e": 95752,
      "ty": 2,
      "x": 975,
      "y": 502
    },
    {
      "t": 102505,
      "e": 95953,
      "ty": 2,
      "x": 969,
      "y": 507
    },
    {
      "t": 102506,
      "e": 95954,
      "ty": 41,
      "x": 33234,
      "y": 9563,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102605,
      "e": 96053,
      "ty": 2,
      "x": 969,
      "y": 508
    },
    {
      "t": 102755,
      "e": 96203,
      "ty": 41,
      "x": 33136,
      "y": 10343,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 102805,
      "e": 96253,
      "ty": 2,
      "x": 967,
      "y": 509
    },
    {
      "t": 107505,
      "e": 100953,
      "ty": 2,
      "x": 955,
      "y": 520
    },
    {
      "t": 107505,
      "e": 100953,
      "ty": 41,
      "x": 32546,
      "y": 14634,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107605,
      "e": 101053,
      "ty": 2,
      "x": 944,
      "y": 528
    },
    {
      "t": 107705,
      "e": 101153,
      "ty": 2,
      "x": 933,
      "y": 536
    },
    {
      "t": 107756,
      "e": 101204,
      "ty": 41,
      "x": 31316,
      "y": 21656,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107805,
      "e": 101253,
      "ty": 2,
      "x": 929,
      "y": 539
    },
    {
      "t": 108005,
      "e": 101453,
      "ty": 41,
      "x": 31266,
      "y": 22046,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 108204,
      "e": 101652,
      "ty": 2,
      "x": 928,
      "y": 539
    },
    {
      "t": 108255,
      "e": 101703,
      "ty": 41,
      "x": 31217,
      "y": 22046,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 109905,
      "e": 103353,
      "ty": 2,
      "x": 927,
      "y": 539
    },
    {
      "t": 110005,
      "e": 103453,
      "ty": 41,
      "x": 31168,
      "y": 22046,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 110006,
      "e": 103454,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 113105,
      "e": 106553,
      "ty": 2,
      "x": 927,
      "y": 540
    },
    {
      "t": 113205,
      "e": 106653,
      "ty": 2,
      "x": 920,
      "y": 546
    },
    {
      "t": 113256,
      "e": 106704,
      "ty": 41,
      "x": 30627,
      "y": 26337,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 113305,
      "e": 106753,
      "ty": 2,
      "x": 910,
      "y": 557
    },
    {
      "t": 113405,
      "e": 106853,
      "ty": 2,
      "x": 901,
      "y": 573
    },
    {
      "t": 113505,
      "e": 106953,
      "ty": 2,
      "x": 888,
      "y": 595
    },
    {
      "t": 113506,
      "e": 106954,
      "ty": 41,
      "x": 29249,
      "y": 43891,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 113605,
      "e": 107053,
      "ty": 2,
      "x": 874,
      "y": 615
    },
    {
      "t": 113705,
      "e": 107153,
      "ty": 2,
      "x": 857,
      "y": 654
    },
    {
      "t": 113755,
      "e": 107203,
      "ty": 41,
      "x": 27331,
      "y": 3227,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 113805,
      "e": 107253,
      "ty": 2,
      "x": 844,
      "y": 699
    },
    {
      "t": 113905,
      "e": 107353,
      "ty": 2,
      "x": 844,
      "y": 748
    },
    {
      "t": 114005,
      "e": 107453,
      "ty": 2,
      "x": 849,
      "y": 763
    },
    {
      "t": 114005,
      "e": 107453,
      "ty": 41,
      "x": 27331,
      "y": 55304,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114509,
      "e": 107957,
      "ty": 2,
      "x": 859,
      "y": 781
    },
    {
      "t": 114509,
      "e": 107957,
      "ty": 41,
      "x": 27823,
      "y": 51700,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 114608,
      "e": 108056,
      "ty": 2,
      "x": 882,
      "y": 846
    },
    {
      "t": 114708,
      "e": 108156,
      "ty": 2,
      "x": 896,
      "y": 889
    },
    {
      "t": 114759,
      "e": 108207,
      "ty": 41,
      "x": 29791,
      "y": 54061,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114809,
      "e": 108257,
      "ty": 2,
      "x": 902,
      "y": 917
    },
    {
      "t": 114909,
      "e": 108357,
      "ty": 2,
      "x": 910,
      "y": 946
    },
    {
      "t": 115009,
      "e": 108457,
      "ty": 2,
      "x": 923,
      "y": 972
    },
    {
      "t": 115009,
      "e": 108457,
      "ty": 41,
      "x": 30971,
      "y": 58562,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115109,
      "e": 108557,
      "ty": 2,
      "x": 934,
      "y": 993
    },
    {
      "t": 115209,
      "e": 108657,
      "ty": 2,
      "x": 943,
      "y": 1015
    },
    {
      "t": 115259,
      "e": 108707,
      "ty": 41,
      "x": 32054,
      "y": 61817,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115309,
      "e": 108757,
      "ty": 2,
      "x": 946,
      "y": 1026
    },
    {
      "t": 115409,
      "e": 108857,
      "ty": 2,
      "x": 950,
      "y": 1049
    },
    {
      "t": 115509,
      "e": 108957,
      "ty": 2,
      "x": 952,
      "y": 1061
    },
    {
      "t": 115509,
      "e": 108957,
      "ty": 41,
      "x": 32398,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115585,
      "e": 109033,
      "ty": 6,
      "x": 955,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 115608,
      "e": 109056,
      "ty": 2,
      "x": 955,
      "y": 1075
    },
    {
      "t": 115709,
      "e": 109157,
      "ty": 2,
      "x": 957,
      "y": 1080
    },
    {
      "t": 115759,
      "e": 109207,
      "ty": 41,
      "x": 25940,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 120009,
      "e": 113457,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120165,
      "e": 113613,
      "ty": 3,
      "x": 957,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 120166,
      "e": 113614,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 120244,
      "e": 113692,
      "ty": 4,
      "x": 25940,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 120245,
      "e": 113693,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 120245,
      "e": 113693,
      "ty": 5,
      "x": 957,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 120245,
      "e": 113693,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 121281,
      "e": 114729,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 122259,
      "e": 115707,
      "ty": 41,
      "x": 32665,
      "y": 32877,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 122309,
      "e": 115757,
      "ty": 2,
      "x": 957,
      "y": 1075
    },
    {
      "t": 122409,
      "e": 115857,
      "ty": 2,
      "x": 957,
      "y": 1074
    },
    {
      "t": 122509,
      "e": 115957,
      "ty": 2,
      "x": 951,
      "y": 1061
    },
    {
      "t": 122510,
      "e": 115958,
      "ty": 41,
      "x": 32420,
      "y": 32873,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 122609,
      "e": 116057,
      "ty": 2,
      "x": 830,
      "y": 875
    },
    {
      "t": 122682,
      "e": 116130,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 79138, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 79143, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13385, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 93929, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19105, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"WHISKEY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 114041, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14818, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 129962, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12864, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 143830, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 91108, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 236348, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 4.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-10 AM-11 AM-A -A -A -A -4-11 AM-A -11 AM-10 AM-09 AM-08 AM-10 AM-11 AM-11 AM-C -F -F -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1042,y:947,t:1527872955397};\\\", \\\"{x:1037,y:944,t:1527872955410};\\\", \\\"{x:1020,y:933,t:1527872955427};\\\", \\\"{x:992,y:915,t:1527872955443};\\\", \\\"{x:972,y:903,t:1527872955460};\\\", \\\"{x:928,y:877,t:1527872955476};\\\", \\\"{x:907,y:863,t:1527872955493};\\\", \\\"{x:884,y:850,t:1527872955510};\\\", \\\"{x:861,y:833,t:1527872955526};\\\", \\\"{x:834,y:817,t:1527872955542};\\\", \\\"{x:813,y:804,t:1527872955560};\\\", \\\"{x:791,y:791,t:1527872955578};\\\", \\\"{x:774,y:781,t:1527872955594};\\\", \\\"{x:757,y:771,t:1527872955610};\\\", \\\"{x:740,y:761,t:1527872955627};\\\", \\\"{x:721,y:750,t:1527872955644};\\\", \\\"{x:699,y:737,t:1527872955661};\\\", \\\"{x:668,y:720,t:1527872955677};\\\", \\\"{x:652,y:713,t:1527872955693};\\\", \\\"{x:634,y:703,t:1527872955711};\\\", \\\"{x:624,y:697,t:1527872955727};\\\", \\\"{x:614,y:692,t:1527872955743};\\\", \\\"{x:609,y:689,t:1527872955759};\\\", \\\"{x:600,y:685,t:1527872955777};\\\", \\\"{x:588,y:679,t:1527872955794};\\\", \\\"{x:579,y:675,t:1527872955810};\\\", \\\"{x:578,y:674,t:1527872955827};\\\", \\\"{x:578,y:673,t:1527872955934};\\\", \\\"{x:578,y:671,t:1527872955945};\\\", \\\"{x:578,y:666,t:1527872955960};\\\", \\\"{x:579,y:660,t:1527872955978};\\\", \\\"{x:584,y:653,t:1527872955995};\\\", \\\"{x:585,y:648,t:1527872956012};\\\", \\\"{x:585,y:640,t:1527872956027};\\\", \\\"{x:585,y:639,t:1527872956044};\\\", \\\"{x:585,y:638,t:1527872957437};\\\", \\\"{x:585,y:641,t:1527872957478};\\\", \\\"{x:602,y:650,t:1527872957495};\\\", \\\"{x:618,y:658,t:1527872957514};\\\", \\\"{x:631,y:663,t:1527872957528};\\\", \\\"{x:646,y:672,t:1527872957544};\\\", \\\"{x:656,y:676,t:1527872957562};\\\", \\\"{x:665,y:681,t:1527872957579};\\\", \\\"{x:672,y:685,t:1527872957595};\\\", \\\"{x:677,y:686,t:1527872957611};\\\", \\\"{x:691,y:696,t:1527872957629};\\\", \\\"{x:707,y:707,t:1527872957644};\\\", \\\"{x:726,y:717,t:1527872957662};\\\", \\\"{x:743,y:724,t:1527872957679};\\\", \\\"{x:769,y:735,t:1527872957695};\\\", \\\"{x:795,y:748,t:1527872957712};\\\", \\\"{x:842,y:768,t:1527872957729};\\\", \\\"{x:889,y:790,t:1527872957745};\\\", \\\"{x:929,y:813,t:1527872957763};\\\", \\\"{x:965,y:826,t:1527872957779};\\\", \\\"{x:996,y:839,t:1527872957796};\\\", \\\"{x:1022,y:851,t:1527872957812};\\\", \\\"{x:1058,y:862,t:1527872957829};\\\", \\\"{x:1080,y:869,t:1527872957845};\\\", \\\"{x:1096,y:871,t:1527872957862};\\\", \\\"{x:1110,y:873,t:1527872957879};\\\", \\\"{x:1125,y:873,t:1527872957895};\\\", \\\"{x:1139,y:873,t:1527872957913};\\\", \\\"{x:1150,y:872,t:1527872957929};\\\", \\\"{x:1158,y:868,t:1527872957946};\\\", \\\"{x:1160,y:866,t:1527872957963};\\\", \\\"{x:1160,y:865,t:1527872958837};\\\", \\\"{x:1160,y:863,t:1527872958846};\\\", \\\"{x:1160,y:862,t:1527872958863};\\\", \\\"{x:1160,y:860,t:1527872958881};\\\", \\\"{x:1160,y:859,t:1527872958901};\\\", \\\"{x:1159,y:858,t:1527872958916};\\\", \\\"{x:1159,y:857,t:1527872958933};\\\", \\\"{x:1159,y:856,t:1527872958957};\\\", \\\"{x:1159,y:854,t:1527872958972};\\\", \\\"{x:1159,y:853,t:1527872958980};\\\", \\\"{x:1159,y:852,t:1527872958996};\\\", \\\"{x:1159,y:851,t:1527872959013};\\\", \\\"{x:1159,y:848,t:1527872959030};\\\", \\\"{x:1158,y:847,t:1527872959046};\\\", \\\"{x:1158,y:846,t:1527872959063};\\\", \\\"{x:1158,y:845,t:1527872959080};\\\", \\\"{x:1158,y:844,t:1527872959096};\\\", \\\"{x:1158,y:843,t:1527872959113};\\\", \\\"{x:1158,y:842,t:1527872959130};\\\", \\\"{x:1158,y:841,t:1527872959157};\\\", \\\"{x:1158,y:840,t:1527872959165};\\\", \\\"{x:1156,y:839,t:1527872959180};\\\", \\\"{x:1156,y:837,t:1527872959197};\\\", \\\"{x:1155,y:834,t:1527872959214};\\\", \\\"{x:1155,y:832,t:1527872959231};\\\", \\\"{x:1154,y:831,t:1527872959248};\\\", \\\"{x:1154,y:829,t:1527872959263};\\\", \\\"{x:1153,y:828,t:1527872959406};\\\", \\\"{x:1152,y:828,t:1527872959414};\\\", \\\"{x:1149,y:820,t:1527872959431};\\\", \\\"{x:1147,y:812,t:1527872959447};\\\", \\\"{x:1143,y:808,t:1527872959464};\\\", \\\"{x:1140,y:805,t:1527872959480};\\\", \\\"{x:1136,y:799,t:1527872959497};\\\", \\\"{x:1133,y:795,t:1527872959513};\\\", \\\"{x:1131,y:792,t:1527872959530};\\\", \\\"{x:1127,y:788,t:1527872959547};\\\", \\\"{x:1124,y:784,t:1527872959563};\\\", \\\"{x:1121,y:779,t:1527872959580};\\\", \\\"{x:1117,y:773,t:1527872959596};\\\", \\\"{x:1116,y:770,t:1527872959614};\\\", \\\"{x:1114,y:764,t:1527872959630};\\\", \\\"{x:1113,y:753,t:1527872959647};\\\", \\\"{x:1112,y:743,t:1527872959664};\\\", \\\"{x:1112,y:735,t:1527872959680};\\\", \\\"{x:1112,y:726,t:1527872959697};\\\", \\\"{x:1112,y:714,t:1527872959714};\\\", \\\"{x:1112,y:701,t:1527872959730};\\\", \\\"{x:1112,y:684,t:1527872959747};\\\", \\\"{x:1112,y:665,t:1527872959764};\\\", \\\"{x:1112,y:646,t:1527872959781};\\\", \\\"{x:1112,y:610,t:1527872959797};\\\", \\\"{x:1112,y:583,t:1527872959814};\\\", \\\"{x:1112,y:556,t:1527872959830};\\\", \\\"{x:1112,y:532,t:1527872959847};\\\", \\\"{x:1112,y:503,t:1527872959864};\\\", \\\"{x:1106,y:478,t:1527872959880};\\\", \\\"{x:1101,y:454,t:1527872959897};\\\", \\\"{x:1096,y:432,t:1527872959914};\\\", \\\"{x:1091,y:408,t:1527872959930};\\\", \\\"{x:1087,y:382,t:1527872959948};\\\", \\\"{x:1085,y:364,t:1527872959964};\\\", \\\"{x:1083,y:344,t:1527872959980};\\\", \\\"{x:1078,y:317,t:1527872959997};\\\", \\\"{x:1076,y:307,t:1527872960015};\\\", \\\"{x:1075,y:302,t:1527872960032};\\\", \\\"{x:1075,y:297,t:1527872960048};\\\", \\\"{x:1075,y:294,t:1527872960065};\\\", \\\"{x:1072,y:288,t:1527872960082};\\\", \\\"{x:1072,y:285,t:1527872960097};\\\", \\\"{x:1072,y:282,t:1527872960114};\\\", \\\"{x:1072,y:279,t:1527872960132};\\\", \\\"{x:1072,y:278,t:1527872960148};\\\", \\\"{x:1072,y:284,t:1527872960438};\\\", \\\"{x:1072,y:289,t:1527872960449};\\\", \\\"{x:1072,y:308,t:1527872960464};\\\", \\\"{x:1072,y:327,t:1527872960482};\\\", \\\"{x:1072,y:350,t:1527872960500};\\\", \\\"{x:1072,y:375,t:1527872960514};\\\", \\\"{x:1079,y:400,t:1527872960532};\\\", \\\"{x:1086,y:428,t:1527872960549};\\\", \\\"{x:1097,y:460,t:1527872960565};\\\", \\\"{x:1115,y:522,t:1527872960582};\\\", \\\"{x:1126,y:561,t:1527872960599};\\\", \\\"{x:1130,y:587,t:1527872960614};\\\", \\\"{x:1133,y:614,t:1527872960631};\\\", \\\"{x:1134,y:638,t:1527872960649};\\\", \\\"{x:1134,y:665,t:1527872960665};\\\", \\\"{x:1134,y:694,t:1527872960682};\\\", \\\"{x:1134,y:718,t:1527872960700};\\\", \\\"{x:1129,y:744,t:1527872960714};\\\", \\\"{x:1123,y:763,t:1527872960731};\\\", \\\"{x:1115,y:783,t:1527872960749};\\\", \\\"{x:1112,y:798,t:1527872960765};\\\", \\\"{x:1109,y:821,t:1527872960782};\\\", \\\"{x:1107,y:835,t:1527872960799};\\\", \\\"{x:1104,y:850,t:1527872960816};\\\", \\\"{x:1102,y:863,t:1527872960832};\\\", \\\"{x:1101,y:875,t:1527872960848};\\\", \\\"{x:1101,y:894,t:1527872960866};\\\", \\\"{x:1101,y:916,t:1527872960882};\\\", \\\"{x:1101,y:931,t:1527872960900};\\\", \\\"{x:1103,y:945,t:1527872960915};\\\", \\\"{x:1106,y:953,t:1527872960932};\\\", \\\"{x:1110,y:959,t:1527872960949};\\\", \\\"{x:1113,y:963,t:1527872960966};\\\", \\\"{x:1116,y:966,t:1527872960982};\\\", \\\"{x:1119,y:968,t:1527872960999};\\\", \\\"{x:1124,y:971,t:1527872961015};\\\", \\\"{x:1126,y:972,t:1527872961032};\\\", \\\"{x:1128,y:972,t:1527872961048};\\\", \\\"{x:1130,y:972,t:1527872961066};\\\", \\\"{x:1134,y:972,t:1527872961082};\\\", \\\"{x:1142,y:973,t:1527872961100};\\\", \\\"{x:1148,y:974,t:1527872961115};\\\", \\\"{x:1157,y:974,t:1527872961132};\\\", \\\"{x:1169,y:974,t:1527872961152};\\\", \\\"{x:1184,y:974,t:1527872961164};\\\", \\\"{x:1196,y:974,t:1527872961180};\\\", \\\"{x:1205,y:976,t:1527872961198};\\\", \\\"{x:1214,y:976,t:1527872961215};\\\", \\\"{x:1220,y:976,t:1527872961232};\\\", \\\"{x:1225,y:976,t:1527872961248};\\\", \\\"{x:1228,y:976,t:1527872961265};\\\", \\\"{x:1230,y:976,t:1527872961282};\\\", \\\"{x:1232,y:976,t:1527872961299};\\\", \\\"{x:1234,y:976,t:1527872961315};\\\", \\\"{x:1235,y:976,t:1527872961332};\\\", \\\"{x:1237,y:976,t:1527872961348};\\\", \\\"{x:1239,y:976,t:1527872961364};\\\", \\\"{x:1240,y:976,t:1527872961383};\\\", \\\"{x:1242,y:976,t:1527872961398};\\\", \\\"{x:1246,y:976,t:1527872961415};\\\", \\\"{x:1247,y:976,t:1527872961433};\\\", \\\"{x:1249,y:976,t:1527872961449};\\\", \\\"{x:1252,y:976,t:1527872961465};\\\", \\\"{x:1253,y:976,t:1527872961482};\\\", \\\"{x:1254,y:976,t:1527872961498};\\\", \\\"{x:1255,y:976,t:1527872961515};\\\", \\\"{x:1256,y:976,t:1527872961533};\\\", \\\"{x:1258,y:976,t:1527872961549};\\\", \\\"{x:1259,y:976,t:1527872961566};\\\", \\\"{x:1262,y:976,t:1527872961583};\\\", \\\"{x:1263,y:976,t:1527872961599};\\\", \\\"{x:1265,y:976,t:1527872961615};\\\", \\\"{x:1268,y:976,t:1527872961633};\\\", \\\"{x:1269,y:976,t:1527872961649};\\\", \\\"{x:1272,y:976,t:1527872961666};\\\", \\\"{x:1273,y:976,t:1527872961682};\\\", \\\"{x:1274,y:976,t:1527872961699};\\\", \\\"{x:1275,y:976,t:1527872961715};\\\", \\\"{x:1276,y:976,t:1527872961797};\\\", \\\"{x:1277,y:976,t:1527872964342};\\\", \\\"{x:1278,y:975,t:1527872968973};\\\", \\\"{x:1279,y:968,t:1527872968990};\\\", \\\"{x:1279,y:962,t:1527872969005};\\\", \\\"{x:1281,y:956,t:1527872969022};\\\", \\\"{x:1282,y:952,t:1527872969039};\\\", \\\"{x:1282,y:949,t:1527872969056};\\\", \\\"{x:1282,y:946,t:1527872969072};\\\", \\\"{x:1282,y:944,t:1527872969089};\\\", \\\"{x:1283,y:940,t:1527872969106};\\\", \\\"{x:1283,y:937,t:1527872969122};\\\", \\\"{x:1285,y:932,t:1527872969139};\\\", \\\"{x:1285,y:928,t:1527872969156};\\\", \\\"{x:1286,y:923,t:1527872969172};\\\", \\\"{x:1287,y:914,t:1527872969189};\\\", \\\"{x:1287,y:908,t:1527872969205};\\\", \\\"{x:1289,y:901,t:1527872969223};\\\", \\\"{x:1290,y:894,t:1527872969239};\\\", \\\"{x:1290,y:888,t:1527872969256};\\\", \\\"{x:1290,y:883,t:1527872969272};\\\", \\\"{x:1291,y:877,t:1527872969289};\\\", \\\"{x:1292,y:872,t:1527872969306};\\\", \\\"{x:1293,y:868,t:1527872969321};\\\", \\\"{x:1293,y:865,t:1527872969338};\\\", \\\"{x:1293,y:861,t:1527872969356};\\\", \\\"{x:1293,y:858,t:1527872969371};\\\", \\\"{x:1293,y:854,t:1527872969388};\\\", \\\"{x:1293,y:848,t:1527872969405};\\\", \\\"{x:1293,y:845,t:1527872969422};\\\", \\\"{x:1293,y:844,t:1527872969438};\\\", \\\"{x:1293,y:841,t:1527872969456};\\\", \\\"{x:1293,y:839,t:1527872969473};\\\", \\\"{x:1292,y:835,t:1527872969489};\\\", \\\"{x:1292,y:833,t:1527872969506};\\\", \\\"{x:1290,y:831,t:1527872969523};\\\", \\\"{x:1290,y:830,t:1527872969646};\\\", \\\"{x:1289,y:829,t:1527872969657};\\\", \\\"{x:1288,y:829,t:1527872969685};\\\", \\\"{x:1287,y:829,t:1527872969709};\\\", \\\"{x:1286,y:829,t:1527872969752};\\\", \\\"{x:1285,y:829,t:1527872969773};\\\", \\\"{x:1284,y:829,t:1527872969789};\\\", \\\"{x:1283,y:829,t:1527872969829};\\\", \\\"{x:1282,y:829,t:1527872969853};\\\", \\\"{x:1281,y:829,t:1527872969997};\\\", \\\"{x:1281,y:830,t:1527872970678};\\\", \\\"{x:1280,y:831,t:1527872970690};\\\", \\\"{x:1279,y:834,t:1527872970707};\\\", \\\"{x:1279,y:838,t:1527872970726};\\\", \\\"{x:1278,y:843,t:1527872970740};\\\", \\\"{x:1278,y:849,t:1527872970758};\\\", \\\"{x:1278,y:853,t:1527872970773};\\\", \\\"{x:1278,y:856,t:1527872970790};\\\", \\\"{x:1278,y:860,t:1527872970807};\\\", \\\"{x:1279,y:865,t:1527872970824};\\\", \\\"{x:1279,y:867,t:1527872970840};\\\", \\\"{x:1279,y:868,t:1527872970857};\\\", \\\"{x:1280,y:870,t:1527872970874};\\\", \\\"{x:1280,y:872,t:1527872970901};\\\", \\\"{x:1281,y:871,t:1527872971110};\\\", \\\"{x:1281,y:870,t:1527872971125};\\\", \\\"{x:1283,y:862,t:1527872971142};\\\", \\\"{x:1283,y:858,t:1527872971157};\\\", \\\"{x:1284,y:853,t:1527872971174};\\\", \\\"{x:1285,y:850,t:1527872971191};\\\", \\\"{x:1286,y:847,t:1527872971207};\\\", \\\"{x:1286,y:841,t:1527872971224};\\\", \\\"{x:1288,y:838,t:1527872971241};\\\", \\\"{x:1288,y:834,t:1527872971257};\\\", \\\"{x:1288,y:832,t:1527872971274};\\\", \\\"{x:1288,y:830,t:1527872971291};\\\", \\\"{x:1288,y:829,t:1527872971307};\\\", \\\"{x:1288,y:827,t:1527872971323};\\\", \\\"{x:1288,y:826,t:1527872971340};\\\", \\\"{x:1288,y:825,t:1527872971356};\\\", \\\"{x:1288,y:824,t:1527872971373};\\\", \\\"{x:1288,y:822,t:1527872971390};\\\", \\\"{x:1288,y:820,t:1527872971406};\\\", \\\"{x:1288,y:818,t:1527872971423};\\\", \\\"{x:1288,y:817,t:1527872971440};\\\", \\\"{x:1288,y:816,t:1527872971533};\\\", \\\"{x:1288,y:815,t:1527872972381};\\\", \\\"{x:1287,y:815,t:1527872972392};\\\", \\\"{x:1284,y:817,t:1527872972408};\\\", \\\"{x:1283,y:818,t:1527872972425};\\\", \\\"{x:1283,y:820,t:1527872972442};\\\", \\\"{x:1282,y:821,t:1527872972457};\\\", \\\"{x:1282,y:822,t:1527872972485};\\\", \\\"{x:1282,y:823,t:1527872972501};\\\", \\\"{x:1282,y:824,t:1527872972605};\\\", \\\"{x:1282,y:826,t:1527872972614};\\\", \\\"{x:1282,y:827,t:1527872972625};\\\", \\\"{x:1282,y:828,t:1527872972653};\\\", \\\"{x:1282,y:827,t:1527872975501};\\\", \\\"{x:1282,y:826,t:1527872975511};\\\", \\\"{x:1282,y:824,t:1527872975528};\\\", \\\"{x:1281,y:820,t:1527872975544};\\\", \\\"{x:1280,y:817,t:1527872975561};\\\", \\\"{x:1280,y:815,t:1527872975577};\\\", \\\"{x:1280,y:814,t:1527872975594};\\\", \\\"{x:1280,y:812,t:1527872975611};\\\", \\\"{x:1280,y:811,t:1527872975628};\\\", \\\"{x:1280,y:809,t:1527872975645};\\\", \\\"{x:1280,y:807,t:1527872975661};\\\", \\\"{x:1279,y:804,t:1527872975678};\\\", \\\"{x:1279,y:803,t:1527872975701};\\\", \\\"{x:1279,y:802,t:1527872975711};\\\", \\\"{x:1279,y:801,t:1527872975733};\\\", \\\"{x:1279,y:800,t:1527872975822};\\\", \\\"{x:1279,y:799,t:1527872975845};\\\", \\\"{x:1279,y:798,t:1527872975861};\\\", \\\"{x:1279,y:797,t:1527872975877};\\\", \\\"{x:1279,y:796,t:1527872975894};\\\", \\\"{x:1279,y:794,t:1527872975911};\\\", \\\"{x:1279,y:793,t:1527872975928};\\\", \\\"{x:1279,y:790,t:1527872975946};\\\", \\\"{x:1279,y:787,t:1527872975962};\\\", \\\"{x:1279,y:786,t:1527872975978};\\\", \\\"{x:1278,y:784,t:1527872975995};\\\", \\\"{x:1278,y:782,t:1527872976011};\\\", \\\"{x:1278,y:780,t:1527872976028};\\\", \\\"{x:1278,y:777,t:1527872976045};\\\", \\\"{x:1278,y:776,t:1527872976061};\\\", \\\"{x:1278,y:774,t:1527872976078};\\\", \\\"{x:1278,y:773,t:1527872976095};\\\", \\\"{x:1278,y:772,t:1527872976111};\\\", \\\"{x:1278,y:771,t:1527872976128};\\\", \\\"{x:1278,y:770,t:1527872976157};\\\", \\\"{x:1278,y:769,t:1527872976173};\\\", \\\"{x:1278,y:768,t:1527872976181};\\\", \\\"{x:1278,y:767,t:1527872976205};\\\", \\\"{x:1278,y:766,t:1527872976222};\\\", \\\"{x:1278,y:765,t:1527872976229};\\\", \\\"{x:1278,y:764,t:1527872976253};\\\", \\\"{x:1278,y:763,t:1527872976270};\\\", \\\"{x:1278,y:762,t:1527872976285};\\\", \\\"{x:1278,y:761,t:1527872976342};\\\", \\\"{x:1278,y:760,t:1527872976373};\\\", \\\"{x:1278,y:759,t:1527872976398};\\\", \\\"{x:1278,y:758,t:1527872976429};\\\", \\\"{x:1278,y:757,t:1527872976445};\\\", \\\"{x:1278,y:756,t:1527872976462};\\\", \\\"{x:1278,y:754,t:1527872976478};\\\", \\\"{x:1278,y:753,t:1527872976510};\\\", \\\"{x:1278,y:752,t:1527872976525};\\\", \\\"{x:1278,y:751,t:1527872976533};\\\", \\\"{x:1278,y:750,t:1527872976565};\\\", \\\"{x:1278,y:749,t:1527872976579};\\\", \\\"{x:1279,y:747,t:1527872976597};\\\", \\\"{x:1279,y:746,t:1527872976653};\\\", \\\"{x:1279,y:745,t:1527872976669};\\\", \\\"{x:1279,y:744,t:1527872976709};\\\", \\\"{x:1279,y:743,t:1527872976717};\\\", \\\"{x:1279,y:742,t:1527872976733};\\\", \\\"{x:1279,y:741,t:1527872976750};\\\", \\\"{x:1279,y:740,t:1527872976762};\\\", \\\"{x:1279,y:739,t:1527872976778};\\\", \\\"{x:1279,y:737,t:1527872976794};\\\", \\\"{x:1280,y:736,t:1527872976811};\\\", \\\"{x:1280,y:735,t:1527872976829};\\\", \\\"{x:1280,y:733,t:1527872976844};\\\", \\\"{x:1280,y:732,t:1527872976862};\\\", \\\"{x:1280,y:730,t:1527872976879};\\\", \\\"{x:1281,y:728,t:1527872976895};\\\", \\\"{x:1281,y:726,t:1527872976912};\\\", \\\"{x:1282,y:723,t:1527872976929};\\\", \\\"{x:1282,y:721,t:1527872976945};\\\", \\\"{x:1282,y:718,t:1527872976962};\\\", \\\"{x:1282,y:716,t:1527872976979};\\\", \\\"{x:1283,y:713,t:1527872976995};\\\", \\\"{x:1283,y:710,t:1527872977013};\\\", \\\"{x:1285,y:705,t:1527872977029};\\\", \\\"{x:1285,y:704,t:1527872977045};\\\", \\\"{x:1286,y:701,t:1527872977063};\\\", \\\"{x:1287,y:699,t:1527872977079};\\\", \\\"{x:1287,y:698,t:1527872977096};\\\", \\\"{x:1288,y:696,t:1527872977112};\\\", \\\"{x:1288,y:695,t:1527872977130};\\\", \\\"{x:1289,y:693,t:1527872977146};\\\", \\\"{x:1289,y:692,t:1527872977165};\\\", \\\"{x:1289,y:691,t:1527872977179};\\\", \\\"{x:1289,y:690,t:1527872977196};\\\", \\\"{x:1289,y:689,t:1527872977212};\\\", \\\"{x:1289,y:687,t:1527872977237};\\\", \\\"{x:1289,y:686,t:1527872977261};\\\", \\\"{x:1289,y:684,t:1527872977285};\\\", \\\"{x:1289,y:683,t:1527872977296};\\\", \\\"{x:1289,y:681,t:1527872977312};\\\", \\\"{x:1289,y:678,t:1527872977329};\\\", \\\"{x:1289,y:673,t:1527872977346};\\\", \\\"{x:1289,y:670,t:1527872977362};\\\", \\\"{x:1289,y:665,t:1527872977379};\\\", \\\"{x:1289,y:659,t:1527872977396};\\\", \\\"{x:1289,y:655,t:1527872977412};\\\", \\\"{x:1289,y:647,t:1527872977429};\\\", \\\"{x:1288,y:642,t:1527872977446};\\\", \\\"{x:1287,y:638,t:1527872977462};\\\", \\\"{x:1287,y:635,t:1527872977479};\\\", \\\"{x:1287,y:633,t:1527872977497};\\\", \\\"{x:1287,y:630,t:1527872977512};\\\", \\\"{x:1287,y:627,t:1527872977530};\\\", \\\"{x:1287,y:621,t:1527872977546};\\\", \\\"{x:1287,y:610,t:1527872977562};\\\", \\\"{x:1286,y:601,t:1527872977580};\\\", \\\"{x:1284,y:592,t:1527872977597};\\\", \\\"{x:1284,y:582,t:1527872977613};\\\", \\\"{x:1283,y:574,t:1527872977629};\\\", \\\"{x:1282,y:564,t:1527872977647};\\\", \\\"{x:1279,y:551,t:1527872977664};\\\", \\\"{x:1278,y:535,t:1527872977680};\\\", \\\"{x:1277,y:521,t:1527872977697};\\\", \\\"{x:1275,y:516,t:1527872977714};\\\", \\\"{x:1274,y:513,t:1527872977730};\\\", \\\"{x:1271,y:513,t:1527872977790};\\\", \\\"{x:1266,y:514,t:1527872977797};\\\", \\\"{x:1240,y:542,t:1527872977813};\\\", \\\"{x:1194,y:588,t:1527872977829};\\\", \\\"{x:1134,y:637,t:1527872977847};\\\", \\\"{x:1058,y:693,t:1527872977863};\\\", \\\"{x:981,y:743,t:1527872977880};\\\", \\\"{x:884,y:784,t:1527872977896};\\\", \\\"{x:775,y:806,t:1527872977913};\\\", \\\"{x:675,y:822,t:1527872977929};\\\", \\\"{x:569,y:824,t:1527872977946};\\\", \\\"{x:472,y:824,t:1527872977963};\\\", \\\"{x:382,y:819,t:1527872977980};\\\", \\\"{x:315,y:809,t:1527872977996};\\\", \\\"{x:241,y:785,t:1527872978012};\\\", \\\"{x:209,y:772,t:1527872978030};\\\", \\\"{x:192,y:763,t:1527872978047};\\\", \\\"{x:182,y:752,t:1527872978063};\\\", \\\"{x:176,y:740,t:1527872978079};\\\", \\\"{x:172,y:721,t:1527872978096};\\\", \\\"{x:172,y:698,t:1527872978113};\\\", \\\"{x:171,y:670,t:1527872978130};\\\", \\\"{x:165,y:641,t:1527872978147};\\\", \\\"{x:152,y:608,t:1527872978163};\\\", \\\"{x:138,y:584,t:1527872978179};\\\", \\\"{x:129,y:569,t:1527872978195};\\\", \\\"{x:125,y:562,t:1527872978211};\\\", \\\"{x:124,y:558,t:1527872978228};\\\", \\\"{x:124,y:557,t:1527872978246};\\\", \\\"{x:125,y:556,t:1527872978261};\\\", \\\"{x:131,y:556,t:1527872978278};\\\", \\\"{x:142,y:556,t:1527872978295};\\\", \\\"{x:157,y:556,t:1527872978312};\\\", \\\"{x:182,y:556,t:1527872978329};\\\", \\\"{x:206,y:556,t:1527872978346};\\\", \\\"{x:228,y:556,t:1527872978362};\\\", \\\"{x:246,y:556,t:1527872978379};\\\", \\\"{x:266,y:556,t:1527872978396};\\\", \\\"{x:283,y:556,t:1527872978413};\\\", \\\"{x:298,y:556,t:1527872978429};\\\", \\\"{x:305,y:554,t:1527872978444};\\\", \\\"{x:308,y:552,t:1527872978462};\\\", \\\"{x:314,y:549,t:1527872978478};\\\", \\\"{x:320,y:546,t:1527872978495};\\\", \\\"{x:327,y:540,t:1527872978512};\\\", \\\"{x:332,y:536,t:1527872978529};\\\", \\\"{x:336,y:534,t:1527872978545};\\\", \\\"{x:338,y:532,t:1527872978562};\\\", \\\"{x:339,y:531,t:1527872978579};\\\", \\\"{x:339,y:530,t:1527872978596};\\\", \\\"{x:339,y:529,t:1527872978612};\\\", \\\"{x:340,y:527,t:1527872978629};\\\", \\\"{x:341,y:526,t:1527872978646};\\\", \\\"{x:342,y:525,t:1527872978663};\\\", \\\"{x:347,y:523,t:1527872978679};\\\", \\\"{x:352,y:522,t:1527872978695};\\\", \\\"{x:358,y:518,t:1527872978713};\\\", \\\"{x:360,y:518,t:1527872978729};\\\", \\\"{x:362,y:517,t:1527872978746};\\\", \\\"{x:363,y:517,t:1527872978765};\\\", \\\"{x:364,y:516,t:1527872978797};\\\", \\\"{x:365,y:515,t:1527872978829};\\\", \\\"{x:366,y:515,t:1527872978869};\\\", \\\"{x:367,y:515,t:1527872978909};\\\", \\\"{x:368,y:515,t:1527872978925};\\\", \\\"{x:368,y:514,t:1527872978957};\\\", \\\"{x:369,y:514,t:1527872978965};\\\", \\\"{x:370,y:514,t:1527872978989};\\\", \\\"{x:371,y:514,t:1527872979007};\\\", \\\"{x:372,y:514,t:1527872979020};\\\", \\\"{x:373,y:514,t:1527872979052};\\\", \\\"{x:377,y:514,t:1527872979582};\\\", \\\"{x:381,y:519,t:1527872979597};\\\", \\\"{x:386,y:526,t:1527872979613};\\\", \\\"{x:394,y:537,t:1527872979631};\\\", \\\"{x:406,y:551,t:1527872979647};\\\", \\\"{x:427,y:569,t:1527872979662};\\\", \\\"{x:465,y:599,t:1527872979678};\\\", \\\"{x:498,y:620,t:1527872979695};\\\", \\\"{x:537,y:649,t:1527872979713};\\\", \\\"{x:576,y:673,t:1527872979730};\\\", \\\"{x:609,y:695,t:1527872979747};\\\", \\\"{x:647,y:716,t:1527872979762};\\\", \\\"{x:692,y:746,t:1527872979780};\\\", \\\"{x:712,y:761,t:1527872979795};\\\", \\\"{x:721,y:768,t:1527872979813};\\\", \\\"{x:727,y:773,t:1527872979830};\\\", \\\"{x:731,y:778,t:1527872979846};\\\", \\\"{x:737,y:784,t:1527872979862};\\\", \\\"{x:743,y:791,t:1527872979880};\\\", \\\"{x:746,y:795,t:1527872979896};\\\", \\\"{x:748,y:800,t:1527872979912};\\\", \\\"{x:750,y:803,t:1527872979929};\\\", \\\"{x:752,y:807,t:1527872979947};\\\", \\\"{x:755,y:811,t:1527872979963};\\\", \\\"{x:755,y:814,t:1527872979980};\\\", \\\"{x:756,y:814,t:1527872979997};\\\", \\\"{x:751,y:811,t:1527872980085};\\\", \\\"{x:739,y:795,t:1527872980097};\\\", \\\"{x:694,y:729,t:1527872980113};\\\", \\\"{x:644,y:684,t:1527872980129};\\\", \\\"{x:594,y:649,t:1527872980147};\\\", \\\"{x:554,y:620,t:1527872980163};\\\", \\\"{x:514,y:593,t:1527872980181};\\\", \\\"{x:503,y:583,t:1527872980197};\\\", \\\"{x:499,y:576,t:1527872980214};\\\", \\\"{x:498,y:573,t:1527872980231};\\\", \\\"{x:498,y:571,t:1527872980247};\\\", \\\"{x:496,y:568,t:1527872980263};\\\", \\\"{x:494,y:565,t:1527872980281};\\\", \\\"{x:488,y:561,t:1527872980297};\\\", \\\"{x:483,y:560,t:1527872980313};\\\", \\\"{x:479,y:558,t:1527872980330};\\\", \\\"{x:473,y:556,t:1527872980346};\\\", \\\"{x:468,y:553,t:1527872980364};\\\", \\\"{x:456,y:548,t:1527872980380};\\\", \\\"{x:441,y:543,t:1527872980398};\\\", \\\"{x:427,y:538,t:1527872980413};\\\", \\\"{x:412,y:533,t:1527872980431};\\\", \\\"{x:400,y:527,t:1527872980447};\\\", \\\"{x:391,y:524,t:1527872980464};\\\", \\\"{x:379,y:520,t:1527872980480};\\\", \\\"{x:373,y:518,t:1527872980496};\\\", \\\"{x:368,y:514,t:1527872980514};\\\", \\\"{x:366,y:514,t:1527872980531};\\\", \\\"{x:365,y:513,t:1527872980547};\\\", \\\"{x:366,y:512,t:1527872980733};\\\", \\\"{x:367,y:512,t:1527872980757};\\\", \\\"{x:368,y:512,t:1527872980861};\\\", \\\"{x:369,y:513,t:1527872980869};\\\", \\\"{x:370,y:513,t:1527872980881};\\\", \\\"{x:372,y:513,t:1527872980898};\\\", \\\"{x:376,y:515,t:1527872980914};\\\", \\\"{x:379,y:518,t:1527872980931};\\\", \\\"{x:380,y:519,t:1527872980948};\\\", \\\"{x:381,y:521,t:1527872980964};\\\", \\\"{x:382,y:523,t:1527872980980};\\\", \\\"{x:383,y:525,t:1527872980998};\\\", \\\"{x:383,y:527,t:1527872981645};\\\", \\\"{x:383,y:534,t:1527872981654};\\\", \\\"{x:390,y:543,t:1527872981669};\\\", \\\"{x:406,y:566,t:1527872981682};\\\", \\\"{x:439,y:605,t:1527872981699};\\\", \\\"{x:495,y:661,t:1527872981715};\\\", \\\"{x:583,y:730,t:1527872981732};\\\", \\\"{x:718,y:839,t:1527872981748};\\\", \\\"{x:777,y:882,t:1527872981765};\\\", \\\"{x:842,y:932,t:1527872981781};\\\", \\\"{x:914,y:975,t:1527872981798};\\\", \\\"{x:971,y:1008,t:1527872981815};\\\", \\\"{x:1019,y:1034,t:1527872981832};\\\", \\\"{x:1054,y:1053,t:1527872981848};\\\", \\\"{x:1073,y:1064,t:1527872981865};\\\", \\\"{x:1082,y:1070,t:1527872981882};\\\", \\\"{x:1084,y:1071,t:1527872981898};\\\", \\\"{x:1094,y:1068,t:1527872998065};\\\", \\\"{x:1105,y:1062,t:1527872998075};\\\", \\\"{x:1120,y:1054,t:1527872998092};\\\", \\\"{x:1127,y:1051,t:1527872998109};\\\", \\\"{x:1135,y:1047,t:1527872998124};\\\", \\\"{x:1141,y:1043,t:1527872998141};\\\", \\\"{x:1144,y:1040,t:1527872998158};\\\", \\\"{x:1150,y:1036,t:1527872998176};\\\", \\\"{x:1161,y:1032,t:1527872998192};\\\", \\\"{x:1170,y:1030,t:1527872998208};\\\", \\\"{x:1195,y:1022,t:1527872998224};\\\", \\\"{x:1215,y:1020,t:1527872998242};\\\", \\\"{x:1246,y:1016,t:1527872998258};\\\", \\\"{x:1268,y:1016,t:1527872998276};\\\", \\\"{x:1287,y:1013,t:1527872998292};\\\", \\\"{x:1296,y:1011,t:1527872998308};\\\", \\\"{x:1300,y:1009,t:1527872998325};\\\", \\\"{x:1300,y:1008,t:1527872998841};\\\", \\\"{x:1300,y:1007,t:1527872998882};\\\", \\\"{x:1300,y:1006,t:1527872998897};\\\", \\\"{x:1300,y:1005,t:1527872998909};\\\", \\\"{x:1299,y:1004,t:1527872998925};\\\", \\\"{x:1298,y:1002,t:1527872998942};\\\", \\\"{x:1297,y:1000,t:1527872998969};\\\", \\\"{x:1297,y:999,t:1527872998993};\\\", \\\"{x:1297,y:998,t:1527872999008};\\\", \\\"{x:1297,y:996,t:1527872999026};\\\", \\\"{x:1297,y:995,t:1527872999042};\\\", \\\"{x:1297,y:994,t:1527872999059};\\\", \\\"{x:1295,y:991,t:1527872999075};\\\", \\\"{x:1295,y:989,t:1527872999092};\\\", \\\"{x:1294,y:988,t:1527872999110};\\\", \\\"{x:1292,y:984,t:1527872999125};\\\", \\\"{x:1290,y:982,t:1527872999142};\\\", \\\"{x:1290,y:980,t:1527872999159};\\\", \\\"{x:1288,y:978,t:1527872999175};\\\", \\\"{x:1285,y:974,t:1527872999193};\\\", \\\"{x:1284,y:972,t:1527872999209};\\\", \\\"{x:1282,y:969,t:1527872999225};\\\", \\\"{x:1281,y:968,t:1527872999242};\\\", \\\"{x:1281,y:967,t:1527872999260};\\\", \\\"{x:1280,y:966,t:1527872999276};\\\", \\\"{x:1279,y:965,t:1527872999293};\\\", \\\"{x:1279,y:964,t:1527872999309};\\\", \\\"{x:1279,y:963,t:1527872999328};\\\", \\\"{x:1278,y:963,t:1527872999342};\\\", \\\"{x:1278,y:961,t:1527873001225};\\\", \\\"{x:1278,y:959,t:1527873001233};\\\", \\\"{x:1280,y:955,t:1527873001244};\\\", \\\"{x:1281,y:949,t:1527873001261};\\\", \\\"{x:1285,y:935,t:1527873001277};\\\", \\\"{x:1289,y:914,t:1527873001295};\\\", \\\"{x:1292,y:887,t:1527873001310};\\\", \\\"{x:1292,y:862,t:1527873001328};\\\", \\\"{x:1295,y:837,t:1527873001345};\\\", \\\"{x:1295,y:822,t:1527873001361};\\\", \\\"{x:1295,y:817,t:1527873001378};\\\", \\\"{x:1295,y:813,t:1527873001394};\\\", \\\"{x:1295,y:812,t:1527873001416};\\\", \\\"{x:1295,y:811,t:1527873001609};\\\", \\\"{x:1294,y:811,t:1527873001617};\\\", \\\"{x:1292,y:812,t:1527873001627};\\\", \\\"{x:1291,y:812,t:1527873001644};\\\", \\\"{x:1289,y:814,t:1527873001661};\\\", \\\"{x:1287,y:815,t:1527873001677};\\\", \\\"{x:1285,y:817,t:1527873001694};\\\", \\\"{x:1284,y:818,t:1527873001720};\\\", \\\"{x:1282,y:818,t:1527873001744};\\\", \\\"{x:1281,y:819,t:1527873001769};\\\", \\\"{x:1280,y:820,t:1527873001785};\\\", \\\"{x:1279,y:821,t:1527873001856};\\\", \\\"{x:1277,y:821,t:1527873001953};\\\", \\\"{x:1276,y:822,t:1527873002001};\\\", \\\"{x:1276,y:823,t:1527873002208};\\\", \\\"{x:1275,y:824,t:1527873002217};\\\", \\\"{x:1275,y:825,t:1527873002449};\\\", \\\"{x:1275,y:826,t:1527873002473};\\\", \\\"{x:1275,y:827,t:1527873002505};\\\", \\\"{x:1275,y:828,t:1527873002529};\\\", \\\"{x:1275,y:829,t:1527873002577};\\\", \\\"{x:1275,y:831,t:1527873002881};\\\", \\\"{x:1275,y:832,t:1527873002895};\\\", \\\"{x:1275,y:833,t:1527873002969};\\\", \\\"{x:1275,y:834,t:1527873018042};\\\", \\\"{x:1275,y:838,t:1527873018058};\\\", \\\"{x:1275,y:844,t:1527873018075};\\\", \\\"{x:1273,y:852,t:1527873018092};\\\", \\\"{x:1273,y:857,t:1527873018108};\\\", \\\"{x:1273,y:862,t:1527873018126};\\\", \\\"{x:1273,y:866,t:1527873018143};\\\", \\\"{x:1273,y:869,t:1527873018158};\\\", \\\"{x:1273,y:873,t:1527873018176};\\\", \\\"{x:1273,y:875,t:1527873018192};\\\", \\\"{x:1273,y:878,t:1527873018208};\\\", \\\"{x:1273,y:880,t:1527873018225};\\\", \\\"{x:1274,y:885,t:1527873018242};\\\", \\\"{x:1274,y:888,t:1527873018258};\\\", \\\"{x:1275,y:894,t:1527873018276};\\\", \\\"{x:1277,y:900,t:1527873018292};\\\", \\\"{x:1278,y:904,t:1527873018309};\\\", \\\"{x:1280,y:910,t:1527873018326};\\\", \\\"{x:1282,y:916,t:1527873018342};\\\", \\\"{x:1284,y:922,t:1527873018358};\\\", \\\"{x:1285,y:925,t:1527873018375};\\\", \\\"{x:1286,y:929,t:1527873018392};\\\", \\\"{x:1288,y:936,t:1527873018408};\\\", \\\"{x:1289,y:938,t:1527873018425};\\\", \\\"{x:1290,y:943,t:1527873018442};\\\", \\\"{x:1290,y:945,t:1527873018459};\\\", \\\"{x:1290,y:947,t:1527873018475};\\\", \\\"{x:1290,y:948,t:1527873018498};\\\", \\\"{x:1290,y:949,t:1527873018514};\\\", \\\"{x:1290,y:950,t:1527873018529};\\\", \\\"{x:1290,y:951,t:1527873018562};\\\", \\\"{x:1290,y:952,t:1527873018578};\\\", \\\"{x:1290,y:953,t:1527873018618};\\\", \\\"{x:1290,y:954,t:1527873018650};\\\", \\\"{x:1290,y:955,t:1527873018665};\\\", \\\"{x:1290,y:956,t:1527873018681};\\\", \\\"{x:1289,y:957,t:1527873018697};\\\", \\\"{x:1289,y:958,t:1527873018708};\\\", \\\"{x:1289,y:959,t:1527873018724};\\\", \\\"{x:1288,y:961,t:1527873018742};\\\", \\\"{x:1287,y:962,t:1527873018760};\\\", \\\"{x:1287,y:963,t:1527873018785};\\\", \\\"{x:1286,y:964,t:1527873018792};\\\", \\\"{x:1286,y:965,t:1527873018881};\\\", \\\"{x:1284,y:968,t:1527873022074};\\\", \\\"{x:1280,y:968,t:1527873022082};\\\", \\\"{x:1273,y:969,t:1527873022097};\\\", \\\"{x:1256,y:970,t:1527873022111};\\\", \\\"{x:1235,y:973,t:1527873022128};\\\", \\\"{x:1207,y:973,t:1527873022145};\\\", \\\"{x:1186,y:973,t:1527873022162};\\\", \\\"{x:1166,y:973,t:1527873022179};\\\", \\\"{x:1149,y:974,t:1527873022196};\\\", \\\"{x:1139,y:975,t:1527873022212};\\\", \\\"{x:1133,y:975,t:1527873022228};\\\", \\\"{x:1129,y:977,t:1527873022245};\\\", \\\"{x:1126,y:977,t:1527873022362};\\\", \\\"{x:1125,y:978,t:1527873022378};\\\", \\\"{x:1119,y:979,t:1527873022395};\\\", \\\"{x:1113,y:981,t:1527873022411};\\\", \\\"{x:1107,y:982,t:1527873022428};\\\", \\\"{x:1104,y:982,t:1527873022445};\\\", \\\"{x:1102,y:982,t:1527873022462};\\\", \\\"{x:1099,y:982,t:1527873022479};\\\", \\\"{x:1097,y:982,t:1527873022496};\\\", \\\"{x:1096,y:982,t:1527873022513};\\\", \\\"{x:1093,y:982,t:1527873022529};\\\", \\\"{x:1091,y:981,t:1527873022545};\\\", \\\"{x:1090,y:981,t:1527873022602};\\\", \\\"{x:1089,y:980,t:1527873022650};\\\", \\\"{x:1089,y:979,t:1527873022761};\\\", \\\"{x:1089,y:977,t:1527873022778};\\\", \\\"{x:1092,y:975,t:1527873022794};\\\", \\\"{x:1095,y:974,t:1527873022811};\\\", \\\"{x:1100,y:973,t:1527873022827};\\\", \\\"{x:1102,y:972,t:1527873022844};\\\", \\\"{x:1103,y:972,t:1527873022954};\\\", \\\"{x:1104,y:972,t:1527873022962};\\\", \\\"{x:1105,y:972,t:1527873022979};\\\", \\\"{x:1112,y:972,t:1527873022996};\\\", \\\"{x:1126,y:971,t:1527873023012};\\\", \\\"{x:1144,y:964,t:1527873023030};\\\", \\\"{x:1166,y:954,t:1527873023045};\\\", \\\"{x:1182,y:946,t:1527873023062};\\\", \\\"{x:1195,y:941,t:1527873023079};\\\", \\\"{x:1199,y:939,t:1527873023097};\\\", \\\"{x:1199,y:940,t:1527873023146};\\\", \\\"{x:1199,y:951,t:1527873023162};\\\", \\\"{x:1195,y:963,t:1527873023179};\\\", \\\"{x:1194,y:971,t:1527873023194};\\\", \\\"{x:1193,y:979,t:1527873023211};\\\", \\\"{x:1193,y:984,t:1527873023228};\\\", \\\"{x:1193,y:986,t:1527873023244};\\\", \\\"{x:1193,y:987,t:1527873023261};\\\", \\\"{x:1196,y:985,t:1527873023297};\\\", \\\"{x:1200,y:981,t:1527873023312};\\\", \\\"{x:1222,y:961,t:1527873023329};\\\", \\\"{x:1241,y:948,t:1527873023345};\\\", \\\"{x:1254,y:937,t:1527873023362};\\\", \\\"{x:1260,y:929,t:1527873023379};\\\", \\\"{x:1263,y:926,t:1527873023396};\\\", \\\"{x:1262,y:932,t:1527873023474};\\\", \\\"{x:1261,y:937,t:1527873023481};\\\", \\\"{x:1260,y:944,t:1527873023497};\\\", \\\"{x:1256,y:959,t:1527873023512};\\\", \\\"{x:1251,y:975,t:1527873023530};\\\", \\\"{x:1250,y:981,t:1527873023546};\\\", \\\"{x:1250,y:986,t:1527873023563};\\\", \\\"{x:1250,y:990,t:1527873023580};\\\", \\\"{x:1250,y:994,t:1527873023596};\\\", \\\"{x:1250,y:995,t:1527873023612};\\\", \\\"{x:1251,y:995,t:1527873023682};\\\", \\\"{x:1258,y:991,t:1527873023702};\\\", \\\"{x:1275,y:979,t:1527873023713};\\\", \\\"{x:1293,y:963,t:1527873023729};\\\", \\\"{x:1309,y:947,t:1527873023746};\\\", \\\"{x:1316,y:938,t:1527873023763};\\\", \\\"{x:1320,y:933,t:1527873023779};\\\", \\\"{x:1320,y:934,t:1527873024450};\\\", \\\"{x:1320,y:936,t:1527873024463};\\\", \\\"{x:1317,y:939,t:1527873024480};\\\", \\\"{x:1312,y:946,t:1527873024497};\\\", \\\"{x:1301,y:955,t:1527873024513};\\\", \\\"{x:1296,y:959,t:1527873024530};\\\", \\\"{x:1291,y:962,t:1527873024546};\\\", \\\"{x:1286,y:967,t:1527873024562};\\\", \\\"{x:1281,y:971,t:1527873024580};\\\", \\\"{x:1281,y:970,t:1527873025897};\\\", \\\"{x:1281,y:968,t:1527873025915};\\\", \\\"{x:1281,y:967,t:1527873025931};\\\", \\\"{x:1281,y:965,t:1527873025948};\\\", \\\"{x:1280,y:964,t:1527873025965};\\\", \\\"{x:1279,y:963,t:1527873026098};\\\", \\\"{x:1278,y:963,t:1527873026146};\\\", \\\"{x:1278,y:964,t:1527873026274};\\\", \\\"{x:1279,y:964,t:1527873027210};\\\", \\\"{x:1280,y:964,t:1527873027306};\\\", \\\"{x:1281,y:964,t:1527873027370};\\\", \\\"{x:1282,y:964,t:1527873027794};\\\", \\\"{x:1282,y:962,t:1527873028938};\\\", \\\"{x:1282,y:961,t:1527873028970};\\\", \\\"{x:1282,y:959,t:1527873029146};\\\", \\\"{x:1281,y:957,t:1527873029642};\\\", \\\"{x:1280,y:957,t:1527873029650};\\\", \\\"{x:1278,y:954,t:1527873029668};\\\", \\\"{x:1276,y:951,t:1527873029685};\\\", \\\"{x:1274,y:950,t:1527873029700};\\\", \\\"{x:1272,y:948,t:1527873029717};\\\", \\\"{x:1271,y:947,t:1527873029735};\\\", \\\"{x:1271,y:946,t:1527873029751};\\\", \\\"{x:1270,y:944,t:1527873029768};\\\", \\\"{x:1268,y:940,t:1527873029785};\\\", \\\"{x:1267,y:938,t:1527873029800};\\\", \\\"{x:1264,y:934,t:1527873029818};\\\", \\\"{x:1263,y:930,t:1527873029834};\\\", \\\"{x:1260,y:925,t:1527873029851};\\\", \\\"{x:1257,y:918,t:1527873029868};\\\", \\\"{x:1255,y:914,t:1527873029885};\\\", \\\"{x:1252,y:910,t:1527873029901};\\\", \\\"{x:1250,y:905,t:1527873029917};\\\", \\\"{x:1246,y:900,t:1527873029934};\\\", \\\"{x:1244,y:896,t:1527873029951};\\\", \\\"{x:1241,y:890,t:1527873029968};\\\", \\\"{x:1241,y:889,t:1527873029984};\\\", \\\"{x:1239,y:885,t:1527873030001};\\\", \\\"{x:1238,y:882,t:1527873030018};\\\", \\\"{x:1237,y:879,t:1527873030035};\\\", \\\"{x:1236,y:878,t:1527873030052};\\\", \\\"{x:1235,y:874,t:1527873030067};\\\", \\\"{x:1234,y:873,t:1527873030085};\\\", \\\"{x:1234,y:871,t:1527873030101};\\\", \\\"{x:1234,y:869,t:1527873030117};\\\", \\\"{x:1234,y:867,t:1527873030134};\\\", \\\"{x:1234,y:865,t:1527873030150};\\\", \\\"{x:1233,y:863,t:1527873030167};\\\", \\\"{x:1233,y:862,t:1527873030184};\\\", \\\"{x:1231,y:857,t:1527873030200};\\\", \\\"{x:1228,y:852,t:1527873030216};\\\", \\\"{x:1227,y:851,t:1527873030234};\\\", \\\"{x:1226,y:848,t:1527873030251};\\\", \\\"{x:1224,y:845,t:1527873030267};\\\", \\\"{x:1223,y:843,t:1527873030284};\\\", \\\"{x:1222,y:840,t:1527873030301};\\\", \\\"{x:1221,y:838,t:1527873030317};\\\", \\\"{x:1220,y:836,t:1527873030335};\\\", \\\"{x:1219,y:833,t:1527873030351};\\\", \\\"{x:1218,y:832,t:1527873030367};\\\", \\\"{x:1216,y:829,t:1527873030384};\\\", \\\"{x:1215,y:827,t:1527873030401};\\\", \\\"{x:1215,y:828,t:1527873030522};\\\", \\\"{x:1216,y:829,t:1527873030534};\\\", \\\"{x:1218,y:832,t:1527873030552};\\\", \\\"{x:1220,y:835,t:1527873030570};\\\", \\\"{x:1223,y:837,t:1527873030585};\\\", \\\"{x:1227,y:841,t:1527873030602};\\\", \\\"{x:1228,y:845,t:1527873030619};\\\", \\\"{x:1231,y:849,t:1527873030634};\\\", \\\"{x:1233,y:853,t:1527873030652};\\\", \\\"{x:1238,y:862,t:1527873030668};\\\", \\\"{x:1245,y:872,t:1527873030684};\\\", \\\"{x:1251,y:882,t:1527873030702};\\\", \\\"{x:1254,y:889,t:1527873030718};\\\", \\\"{x:1256,y:894,t:1527873030734};\\\", \\\"{x:1259,y:901,t:1527873030751};\\\", \\\"{x:1261,y:907,t:1527873030769};\\\", \\\"{x:1266,y:917,t:1527873030785};\\\", \\\"{x:1268,y:923,t:1527873030802};\\\", \\\"{x:1270,y:928,t:1527873030819};\\\", \\\"{x:1272,y:933,t:1527873030835};\\\", \\\"{x:1272,y:936,t:1527873030852};\\\", \\\"{x:1272,y:940,t:1527873030869};\\\", \\\"{x:1272,y:943,t:1527873030885};\\\", \\\"{x:1274,y:947,t:1527873030902};\\\", \\\"{x:1275,y:951,t:1527873030919};\\\", \\\"{x:1275,y:955,t:1527873030935};\\\", \\\"{x:1276,y:959,t:1527873030951};\\\", \\\"{x:1277,y:961,t:1527873030969};\\\", \\\"{x:1278,y:962,t:1527873030986};\\\", \\\"{x:1279,y:963,t:1527873031058};\\\", \\\"{x:1281,y:961,t:1527873031074};\\\", \\\"{x:1283,y:957,t:1527873031086};\\\", \\\"{x:1287,y:952,t:1527873031102};\\\", \\\"{x:1296,y:944,t:1527873031119};\\\", \\\"{x:1303,y:935,t:1527873031136};\\\", \\\"{x:1307,y:930,t:1527873031151};\\\", \\\"{x:1310,y:925,t:1527873031169};\\\", \\\"{x:1314,y:919,t:1527873031185};\\\", \\\"{x:1316,y:916,t:1527873031201};\\\", \\\"{x:1316,y:912,t:1527873031218};\\\", \\\"{x:1319,y:907,t:1527873031236};\\\", \\\"{x:1320,y:902,t:1527873031251};\\\", \\\"{x:1323,y:896,t:1527873031269};\\\", \\\"{x:1324,y:891,t:1527873031286};\\\", \\\"{x:1325,y:888,t:1527873031303};\\\", \\\"{x:1328,y:882,t:1527873031319};\\\", \\\"{x:1331,y:876,t:1527873031335};\\\", \\\"{x:1336,y:864,t:1527873031353};\\\", \\\"{x:1336,y:861,t:1527873031369};\\\", \\\"{x:1340,y:850,t:1527873031385};\\\", \\\"{x:1341,y:845,t:1527873031403};\\\", \\\"{x:1345,y:839,t:1527873031419};\\\", \\\"{x:1346,y:832,t:1527873031436};\\\", \\\"{x:1350,y:827,t:1527873031453};\\\", \\\"{x:1352,y:821,t:1527873031469};\\\", \\\"{x:1355,y:815,t:1527873031486};\\\", \\\"{x:1360,y:810,t:1527873031503};\\\", \\\"{x:1363,y:803,t:1527873031519};\\\", \\\"{x:1366,y:798,t:1527873031536};\\\", \\\"{x:1368,y:795,t:1527873031552};\\\", \\\"{x:1369,y:792,t:1527873031568};\\\", \\\"{x:1370,y:790,t:1527873031585};\\\", \\\"{x:1371,y:789,t:1527873031602};\\\", \\\"{x:1371,y:787,t:1527873031618};\\\", \\\"{x:1372,y:786,t:1527873031637};\\\", \\\"{x:1372,y:784,t:1527873031653};\\\", \\\"{x:1372,y:782,t:1527873031672};\\\", \\\"{x:1373,y:782,t:1527873031685};\\\", \\\"{x:1373,y:781,t:1527873031702};\\\", \\\"{x:1374,y:778,t:1527873031718};\\\", \\\"{x:1375,y:774,t:1527873031735};\\\", \\\"{x:1376,y:772,t:1527873031752};\\\", \\\"{x:1377,y:768,t:1527873031769};\\\", \\\"{x:1378,y:764,t:1527873031785};\\\", \\\"{x:1380,y:762,t:1527873031802};\\\", \\\"{x:1380,y:759,t:1527873031819};\\\", \\\"{x:1380,y:755,t:1527873031835};\\\", \\\"{x:1382,y:753,t:1527873031852};\\\", \\\"{x:1382,y:752,t:1527873031869};\\\", \\\"{x:1383,y:750,t:1527873031885};\\\", \\\"{x:1383,y:749,t:1527873031902};\\\", \\\"{x:1379,y:749,t:1527873032306};\\\", \\\"{x:1368,y:750,t:1527873032320};\\\", \\\"{x:1336,y:756,t:1527873032337};\\\", \\\"{x:1283,y:764,t:1527873032352};\\\", \\\"{x:1160,y:769,t:1527873032370};\\\", \\\"{x:1068,y:769,t:1527873032387};\\\", \\\"{x:984,y:769,t:1527873032402};\\\", \\\"{x:892,y:751,t:1527873032419};\\\", \\\"{x:814,y:727,t:1527873032436};\\\", \\\"{x:747,y:710,t:1527873032452};\\\", \\\"{x:703,y:698,t:1527873032470};\\\", \\\"{x:676,y:688,t:1527873032487};\\\", \\\"{x:657,y:678,t:1527873032502};\\\", \\\"{x:641,y:668,t:1527873032519};\\\", \\\"{x:629,y:659,t:1527873032536};\\\", \\\"{x:603,y:649,t:1527873032554};\\\", \\\"{x:586,y:643,t:1527873032569};\\\", \\\"{x:571,y:639,t:1527873032585};\\\", \\\"{x:554,y:629,t:1527873032603};\\\", \\\"{x:544,y:624,t:1527873032612};\\\", \\\"{x:517,y:605,t:1527873032629};\\\", \\\"{x:491,y:589,t:1527873032646};\\\", \\\"{x:467,y:572,t:1527873032670};\\\", \\\"{x:460,y:566,t:1527873032686};\\\", \\\"{x:458,y:563,t:1527873032704};\\\", \\\"{x:455,y:558,t:1527873032720};\\\", \\\"{x:454,y:555,t:1527873032737};\\\", \\\"{x:454,y:553,t:1527873032754};\\\", \\\"{x:454,y:552,t:1527873032770};\\\", \\\"{x:453,y:550,t:1527873032786};\\\", \\\"{x:452,y:548,t:1527873032804};\\\", \\\"{x:451,y:546,t:1527873032820};\\\", \\\"{x:445,y:542,t:1527873032838};\\\", \\\"{x:438,y:536,t:1527873032854};\\\", \\\"{x:430,y:531,t:1527873032871};\\\", \\\"{x:422,y:523,t:1527873032888};\\\", \\\"{x:417,y:519,t:1527873032904};\\\", \\\"{x:412,y:516,t:1527873032921};\\\", \\\"{x:410,y:516,t:1527873032938};\\\", \\\"{x:409,y:516,t:1527873032953};\\\", \\\"{x:408,y:516,t:1527873032971};\\\", \\\"{x:407,y:516,t:1527873032988};\\\", \\\"{x:406,y:516,t:1527873033005};\\\", \\\"{x:404,y:516,t:1527873033021};\\\", \\\"{x:402,y:516,t:1527873033038};\\\", \\\"{x:399,y:516,t:1527873033055};\\\", \\\"{x:397,y:516,t:1527873033071};\\\", \\\"{x:395,y:516,t:1527873033088};\\\", \\\"{x:392,y:517,t:1527873033105};\\\", \\\"{x:391,y:518,t:1527873033121};\\\", \\\"{x:390,y:519,t:1527873033139};\\\", \\\"{x:389,y:519,t:1527873033161};\\\", \\\"{x:388,y:519,t:1527873033193};\\\", \\\"{x:387,y:520,t:1527873033241};\\\", \\\"{x:382,y:520,t:1527873033496};\\\", \\\"{x:381,y:520,t:1527873033504};\\\", \\\"{x:368,y:520,t:1527873033521};\\\", \\\"{x:345,y:521,t:1527873033538};\\\", \\\"{x:316,y:526,t:1527873033554};\\\", \\\"{x:285,y:531,t:1527873033571};\\\", \\\"{x:256,y:534,t:1527873033591};\\\", \\\"{x:229,y:541,t:1527873033605};\\\", \\\"{x:208,y:548,t:1527873033621};\\\", \\\"{x:191,y:553,t:1527873033637};\\\", \\\"{x:180,y:559,t:1527873033655};\\\", \\\"{x:175,y:563,t:1527873033671};\\\", \\\"{x:173,y:565,t:1527873033687};\\\", \\\"{x:171,y:565,t:1527873033704};\\\", \\\"{x:169,y:568,t:1527873033721};\\\", \\\"{x:169,y:574,t:1527873033738};\\\", \\\"{x:171,y:582,t:1527873033755};\\\", \\\"{x:179,y:590,t:1527873033772};\\\", \\\"{x:192,y:598,t:1527873033788};\\\", \\\"{x:208,y:608,t:1527873033805};\\\", \\\"{x:222,y:616,t:1527873033821};\\\", \\\"{x:235,y:622,t:1527873033839};\\\", \\\"{x:247,y:627,t:1527873033854};\\\", \\\"{x:261,y:632,t:1527873033872};\\\", \\\"{x:265,y:632,t:1527873033888};\\\", \\\"{x:285,y:637,t:1527873033905};\\\", \\\"{x:304,y:638,t:1527873033922};\\\", \\\"{x:329,y:638,t:1527873033937};\\\", \\\"{x:356,y:638,t:1527873033955};\\\", \\\"{x:386,y:638,t:1527873033971};\\\", \\\"{x:415,y:635,t:1527873033988};\\\", \\\"{x:436,y:633,t:1527873034005};\\\", \\\"{x:453,y:630,t:1527873034021};\\\", \\\"{x:459,y:629,t:1527873034037};\\\", \\\"{x:460,y:629,t:1527873034137};\\\", \\\"{x:463,y:627,t:1527873034154};\\\", \\\"{x:468,y:625,t:1527873034171};\\\", \\\"{x:476,y:617,t:1527873034187};\\\", \\\"{x:484,y:609,t:1527873034204};\\\", \\\"{x:495,y:602,t:1527873034222};\\\", \\\"{x:508,y:592,t:1527873034240};\\\", \\\"{x:528,y:581,t:1527873034255};\\\", \\\"{x:546,y:575,t:1527873034272};\\\", \\\"{x:574,y:566,t:1527873034289};\\\", \\\"{x:587,y:565,t:1527873034305};\\\", \\\"{x:595,y:564,t:1527873034322};\\\", \\\"{x:600,y:564,t:1527873034338};\\\", \\\"{x:604,y:564,t:1527873034355};\\\", \\\"{x:610,y:564,t:1527873034372};\\\", \\\"{x:615,y:564,t:1527873034388};\\\", \\\"{x:621,y:564,t:1527873034405};\\\", \\\"{x:631,y:564,t:1527873034421};\\\", \\\"{x:641,y:564,t:1527873034439};\\\", \\\"{x:657,y:565,t:1527873034455};\\\", \\\"{x:674,y:569,t:1527873034471};\\\", \\\"{x:692,y:573,t:1527873034488};\\\", \\\"{x:724,y:576,t:1527873034505};\\\", \\\"{x:747,y:577,t:1527873034521};\\\", \\\"{x:762,y:577,t:1527873034539};\\\", \\\"{x:780,y:577,t:1527873034556};\\\", \\\"{x:797,y:574,t:1527873034573};\\\", \\\"{x:808,y:570,t:1527873034589};\\\", \\\"{x:818,y:565,t:1527873034605};\\\", \\\"{x:825,y:561,t:1527873034621};\\\", \\\"{x:830,y:558,t:1527873034639};\\\", \\\"{x:832,y:555,t:1527873034655};\\\", \\\"{x:826,y:555,t:1527873034713};\\\", \\\"{x:815,y:555,t:1527873034722};\\\", \\\"{x:786,y:555,t:1527873034739};\\\", \\\"{x:732,y:556,t:1527873034755};\\\", \\\"{x:696,y:563,t:1527873034773};\\\", \\\"{x:653,y:570,t:1527873034788};\\\", \\\"{x:616,y:577,t:1527873034807};\\\", \\\"{x:587,y:587,t:1527873034822};\\\", \\\"{x:561,y:600,t:1527873034839};\\\", \\\"{x:545,y:610,t:1527873034855};\\\", \\\"{x:532,y:621,t:1527873034873};\\\", \\\"{x:526,y:628,t:1527873034889};\\\", \\\"{x:520,y:633,t:1527873034906};\\\", \\\"{x:513,y:639,t:1527873034922};\\\", \\\"{x:501,y:641,t:1527873034939};\\\", \\\"{x:487,y:643,t:1527873034956};\\\", \\\"{x:469,y:643,t:1527873034972};\\\", \\\"{x:453,y:643,t:1527873034989};\\\", \\\"{x:438,y:643,t:1527873035006};\\\", \\\"{x:430,y:644,t:1527873035022};\\\", \\\"{x:425,y:644,t:1527873035039};\\\", \\\"{x:420,y:646,t:1527873035056};\\\", \\\"{x:410,y:648,t:1527873035073};\\\", \\\"{x:404,y:649,t:1527873035089};\\\", \\\"{x:397,y:650,t:1527873035106};\\\", \\\"{x:391,y:650,t:1527873035124};\\\", \\\"{x:386,y:650,t:1527873035139};\\\", \\\"{x:381,y:650,t:1527873035156};\\\", \\\"{x:372,y:649,t:1527873035173};\\\", \\\"{x:363,y:647,t:1527873035189};\\\", \\\"{x:356,y:647,t:1527873035206};\\\", \\\"{x:348,y:646,t:1527873035223};\\\", \\\"{x:339,y:644,t:1527873035239};\\\", \\\"{x:331,y:642,t:1527873035257};\\\", \\\"{x:309,y:632,t:1527873035272};\\\", \\\"{x:293,y:626,t:1527873035290};\\\", \\\"{x:274,y:619,t:1527873035308};\\\", \\\"{x:251,y:612,t:1527873035323};\\\", \\\"{x:233,y:607,t:1527873035339};\\\", \\\"{x:213,y:602,t:1527873035356};\\\", \\\"{x:194,y:592,t:1527873035373};\\\", \\\"{x:178,y:581,t:1527873035389};\\\", \\\"{x:164,y:570,t:1527873035407};\\\", \\\"{x:158,y:564,t:1527873035423};\\\", \\\"{x:155,y:558,t:1527873035439};\\\", \\\"{x:153,y:556,t:1527873035456};\\\", \\\"{x:153,y:549,t:1527873035473};\\\", \\\"{x:153,y:544,t:1527873035489};\\\", \\\"{x:153,y:538,t:1527873035507};\\\", \\\"{x:153,y:534,t:1527873035523};\\\", \\\"{x:153,y:531,t:1527873035540};\\\", \\\"{x:153,y:529,t:1527873035556};\\\", \\\"{x:153,y:526,t:1527873035572};\\\", \\\"{x:154,y:522,t:1527873035590};\\\", \\\"{x:154,y:521,t:1527873035606};\\\", \\\"{x:155,y:520,t:1527873035623};\\\", \\\"{x:162,y:519,t:1527873035960};\\\", \\\"{x:173,y:518,t:1527873035973};\\\", \\\"{x:219,y:514,t:1527873035990};\\\", \\\"{x:288,y:514,t:1527873036008};\\\", \\\"{x:380,y:514,t:1527873036023};\\\", \\\"{x:477,y:514,t:1527873036041};\\\", \\\"{x:605,y:514,t:1527873036057};\\\", \\\"{x:666,y:519,t:1527873036074};\\\", \\\"{x:708,y:525,t:1527873036090};\\\", \\\"{x:737,y:531,t:1527873036108};\\\", \\\"{x:758,y:536,t:1527873036123};\\\", \\\"{x:766,y:541,t:1527873036141};\\\", \\\"{x:767,y:541,t:1527873036157};\\\", \\\"{x:767,y:542,t:1527873036225};\\\", \\\"{x:761,y:543,t:1527873036241};\\\", \\\"{x:738,y:550,t:1527873036257};\\\", \\\"{x:709,y:556,t:1527873036274};\\\", \\\"{x:662,y:562,t:1527873036291};\\\", \\\"{x:611,y:569,t:1527873036307};\\\", \\\"{x:550,y:578,t:1527873036323};\\\", \\\"{x:502,y:585,t:1527873036340};\\\", \\\"{x:470,y:585,t:1527873036358};\\\", \\\"{x:451,y:585,t:1527873036373};\\\", \\\"{x:445,y:585,t:1527873036389};\\\", \\\"{x:444,y:585,t:1527873036407};\\\", \\\"{x:443,y:585,t:1527873036528};\\\", \\\"{x:442,y:585,t:1527873036540};\\\", \\\"{x:438,y:585,t:1527873036557};\\\", \\\"{x:431,y:584,t:1527873036574};\\\", \\\"{x:425,y:579,t:1527873036591};\\\", \\\"{x:416,y:576,t:1527873036608};\\\", \\\"{x:410,y:574,t:1527873036624};\\\", \\\"{x:406,y:572,t:1527873036640};\\\", \\\"{x:405,y:572,t:1527873036705};\\\", \\\"{x:404,y:571,t:1527873036713};\\\", \\\"{x:403,y:571,t:1527873036729};\\\", \\\"{x:402,y:570,t:1527873036740};\\\", \\\"{x:401,y:569,t:1527873036757};\\\", \\\"{x:399,y:568,t:1527873036775};\\\", \\\"{x:397,y:568,t:1527873036793};\\\", \\\"{x:396,y:567,t:1527873036840};\\\", \\\"{x:402,y:567,t:1527873037266};\\\", \\\"{x:413,y:570,t:1527873037275};\\\", \\\"{x:454,y:583,t:1527873037292};\\\", \\\"{x:516,y:601,t:1527873037309};\\\", \\\"{x:598,y:634,t:1527873037325};\\\", \\\"{x:696,y:670,t:1527873037342};\\\", \\\"{x:800,y:711,t:1527873037358};\\\", \\\"{x:916,y:761,t:1527873037374};\\\", \\\"{x:1029,y:807,t:1527873037392};\\\", \\\"{x:1168,y:869,t:1527873037408};\\\", \\\"{x:1200,y:883,t:1527873037424};\\\", \\\"{x:1292,y:922,t:1527873037441};\\\", \\\"{x:1331,y:939,t:1527873037458};\\\", \\\"{x:1346,y:946,t:1527873037475};\\\", \\\"{x:1353,y:950,t:1527873037491};\\\", \\\"{x:1355,y:951,t:1527873037508};\\\", \\\"{x:1357,y:951,t:1527873037618};\\\", \\\"{x:1356,y:953,t:1527873037802};\\\", \\\"{x:1353,y:953,t:1527873037817};\\\", \\\"{x:1350,y:953,t:1527873037826};\\\", \\\"{x:1347,y:953,t:1527873037842};\\\", \\\"{x:1342,y:953,t:1527873037859};\\\", \\\"{x:1339,y:953,t:1527873037876};\\\", \\\"{x:1334,y:953,t:1527873037892};\\\", \\\"{x:1329,y:953,t:1527873037909};\\\", \\\"{x:1323,y:953,t:1527873037926};\\\", \\\"{x:1316,y:953,t:1527873037941};\\\", \\\"{x:1308,y:953,t:1527873037959};\\\", \\\"{x:1303,y:953,t:1527873037976};\\\", \\\"{x:1298,y:953,t:1527873037993};\\\", \\\"{x:1296,y:954,t:1527873038009};\\\", \\\"{x:1295,y:954,t:1527873038033};\\\", \\\"{x:1294,y:954,t:1527873038043};\\\", \\\"{x:1293,y:954,t:1527873038065};\\\", \\\"{x:1292,y:954,t:1527873038076};\\\", \\\"{x:1290,y:954,t:1527873038093};\\\", \\\"{x:1289,y:954,t:1527873038109};\\\", \\\"{x:1288,y:954,t:1527873038145};\\\", \\\"{x:1287,y:954,t:1527873038394};\\\", \\\"{x:1286,y:954,t:1527873038482};\\\", \\\"{x:1285,y:954,t:1527873038493};\\\", \\\"{x:1284,y:954,t:1527873038509};\\\", \\\"{x:1283,y:954,t:1527873038786};\\\", \\\"{x:1282,y:953,t:1527873038794};\\\", \\\"{x:1281,y:951,t:1527873038810};\\\", \\\"{x:1280,y:949,t:1527873038826};\\\", \\\"{x:1277,y:946,t:1527873038842};\\\", \\\"{x:1275,y:943,t:1527873038860};\\\", \\\"{x:1273,y:940,t:1527873038875};\\\", \\\"{x:1270,y:936,t:1527873038893};\\\", \\\"{x:1267,y:930,t:1527873038910};\\\", \\\"{x:1265,y:928,t:1527873038926};\\\", \\\"{x:1264,y:923,t:1527873038943};\\\", \\\"{x:1263,y:920,t:1527873038959};\\\", \\\"{x:1259,y:908,t:1527873038976};\\\", \\\"{x:1257,y:905,t:1527873038992};\\\", \\\"{x:1255,y:901,t:1527873039009};\\\", \\\"{x:1254,y:898,t:1527873039026};\\\", \\\"{x:1252,y:896,t:1527873039042};\\\", \\\"{x:1252,y:893,t:1527873039060};\\\", \\\"{x:1250,y:891,t:1527873039076};\\\", \\\"{x:1248,y:887,t:1527873039093};\\\", \\\"{x:1246,y:883,t:1527873039109};\\\", \\\"{x:1243,y:878,t:1527873039126};\\\", \\\"{x:1239,y:871,t:1527873039142};\\\", \\\"{x:1234,y:860,t:1527873039159};\\\", \\\"{x:1223,y:843,t:1527873039176};\\\", \\\"{x:1215,y:829,t:1527873039193};\\\", \\\"{x:1209,y:816,t:1527873039210};\\\", \\\"{x:1203,y:804,t:1527873039227};\\\", \\\"{x:1199,y:794,t:1527873039243};\\\", \\\"{x:1196,y:786,t:1527873039260};\\\", \\\"{x:1195,y:783,t:1527873039277};\\\", \\\"{x:1194,y:781,t:1527873039293};\\\", \\\"{x:1194,y:782,t:1527873039433};\\\", \\\"{x:1194,y:787,t:1527873039443};\\\", \\\"{x:1198,y:801,t:1527873039460};\\\", \\\"{x:1204,y:819,t:1527873039477};\\\", \\\"{x:1216,y:846,t:1527873039494};\\\", \\\"{x:1230,y:876,t:1527873039510};\\\", \\\"{x:1248,y:907,t:1527873039527};\\\", \\\"{x:1260,y:925,t:1527873039544};\\\", \\\"{x:1270,y:940,t:1527873039560};\\\", \\\"{x:1278,y:949,t:1527873039577};\\\", \\\"{x:1279,y:949,t:1527873039594};\\\", \\\"{x:1280,y:950,t:1527873039610};\\\", \\\"{x:1281,y:950,t:1527873040346};\\\", \\\"{x:1284,y:951,t:1527873040361};\\\", \\\"{x:1285,y:952,t:1527873040378};\\\", \\\"{x:1285,y:953,t:1527873040538};\\\", \\\"{x:1285,y:954,t:1527873040554};\\\", \\\"{x:1285,y:955,t:1527873040569};\\\", \\\"{x:1285,y:956,t:1527873040593};\\\", \\\"{x:1285,y:957,t:1527873040626};\\\", \\\"{x:1285,y:958,t:1527873040649};\\\", \\\"{x:1284,y:959,t:1527873040661};\\\", \\\"{x:1284,y:958,t:1527873042562};\\\", \\\"{x:1285,y:953,t:1527873042579};\\\", \\\"{x:1290,y:946,t:1527873042596};\\\", \\\"{x:1292,y:941,t:1527873042612};\\\", \\\"{x:1297,y:935,t:1527873042629};\\\", \\\"{x:1299,y:929,t:1527873042646};\\\", \\\"{x:1306,y:921,t:1527873042663};\\\", \\\"{x:1310,y:914,t:1527873042679};\\\", \\\"{x:1313,y:907,t:1527873042696};\\\", \\\"{x:1317,y:900,t:1527873042713};\\\", \\\"{x:1319,y:895,t:1527873042729};\\\", \\\"{x:1322,y:890,t:1527873042746};\\\", \\\"{x:1324,y:887,t:1527873042763};\\\", \\\"{x:1326,y:883,t:1527873042779};\\\", \\\"{x:1330,y:876,t:1527873042797};\\\", \\\"{x:1333,y:868,t:1527873042813};\\\", \\\"{x:1337,y:862,t:1527873042829};\\\", \\\"{x:1342,y:853,t:1527873042846};\\\", \\\"{x:1346,y:846,t:1527873042863};\\\", \\\"{x:1350,y:837,t:1527873042878};\\\", \\\"{x:1354,y:828,t:1527873042899};\\\", \\\"{x:1358,y:823,t:1527873042912};\\\", \\\"{x:1362,y:816,t:1527873042930};\\\", \\\"{x:1364,y:814,t:1527873042946};\\\", \\\"{x:1366,y:809,t:1527873042962};\\\", \\\"{x:1369,y:806,t:1527873042979};\\\", \\\"{x:1372,y:802,t:1527873042995};\\\", \\\"{x:1374,y:798,t:1527873043012};\\\", \\\"{x:1379,y:793,t:1527873043030};\\\", \\\"{x:1381,y:790,t:1527873043045};\\\", \\\"{x:1384,y:786,t:1527873043063};\\\", \\\"{x:1386,y:784,t:1527873043080};\\\", \\\"{x:1387,y:782,t:1527873043096};\\\", \\\"{x:1389,y:779,t:1527873043113};\\\", \\\"{x:1390,y:778,t:1527873043137};\\\", \\\"{x:1390,y:777,t:1527873043161};\\\", \\\"{x:1390,y:776,t:1527873043185};\\\", \\\"{x:1381,y:776,t:1527873045010};\\\", \\\"{x:1364,y:777,t:1527873045017};\\\", \\\"{x:1346,y:778,t:1527873045030};\\\", \\\"{x:1288,y:787,t:1527873045048};\\\", \\\"{x:1221,y:795,t:1527873045064};\\\", \\\"{x:1134,y:797,t:1527873045082};\\\", \\\"{x:1070,y:797,t:1527873045098};\\\", \\\"{x:1006,y:797,t:1527873045115};\\\", \\\"{x:959,y:797,t:1527873045131};\\\", \\\"{x:914,y:797,t:1527873045147};\\\", \\\"{x:866,y:797,t:1527873045164};\\\", \\\"{x:819,y:794,t:1527873045180};\\\", \\\"{x:787,y:793,t:1527873045198};\\\", \\\"{x:759,y:793,t:1527873045215};\\\", \\\"{x:729,y:793,t:1527873045231};\\\", \\\"{x:708,y:793,t:1527873045247};\\\", \\\"{x:690,y:793,t:1527873045265};\\\", \\\"{x:684,y:793,t:1527873045281};\\\", \\\"{x:680,y:793,t:1527873045298};\\\", \\\"{x:678,y:794,t:1527873045315};\\\", \\\"{x:676,y:794,t:1527873045330};\\\", \\\"{x:674,y:794,t:1527873045384};\\\", \\\"{x:673,y:794,t:1527873045397};\\\", \\\"{x:664,y:789,t:1527873045415};\\\", \\\"{x:658,y:785,t:1527873045430};\\\", \\\"{x:647,y:778,t:1527873045447};\\\", \\\"{x:625,y:767,t:1527873045464};\\\", \\\"{x:606,y:757,t:1527873045480};\\\", \\\"{x:587,y:751,t:1527873045498};\\\", \\\"{x:576,y:747,t:1527873045515};\\\", \\\"{x:572,y:746,t:1527873045531};\\\", \\\"{x:570,y:745,t:1527873045548};\\\", \\\"{x:570,y:744,t:1527873045569};\\\", \\\"{x:569,y:742,t:1527873045581};\\\", \\\"{x:569,y:741,t:1527873045598};\\\", \\\"{x:568,y:739,t:1527873045614};\\\", \\\"{x:567,y:737,t:1527873045632};\\\", \\\"{x:565,y:736,t:1527873045648};\\\", \\\"{x:560,y:733,t:1527873045666};\\\", \\\"{x:556,y:730,t:1527873045681};\\\", \\\"{x:554,y:729,t:1527873045698};\\\", \\\"{x:552,y:728,t:1527873045707};\\\", \\\"{x:549,y:726,t:1527873045725};\\\", \\\"{x:548,y:725,t:1527873045741};\\\", \\\"{x:547,y:724,t:1527873045758};\\\", \\\"{x:545,y:723,t:1527873045774};\\\", \\\"{x:543,y:722,t:1527873045791};\\\" ] }, { \\\"rt\\\": 46781, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 284690, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -12 PM-11 AM-F -F -10 AM-11 AM-01 PM-K -K -D -D -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:722,t:1527873049235};\\\", \\\"{x:549,y:723,t:1527873049243};\\\", \\\"{x:555,y:726,t:1527873049257};\\\", \\\"{x:569,y:731,t:1527873049274};\\\", \\\"{x:591,y:741,t:1527873049290};\\\", \\\"{x:628,y:754,t:1527873049307};\\\", \\\"{x:638,y:759,t:1527873049318};\\\", \\\"{x:660,y:772,t:1527873049336};\\\", \\\"{x:696,y:782,t:1527873049351};\\\", \\\"{x:730,y:794,t:1527873049368};\\\", \\\"{x:767,y:805,t:1527873049385};\\\", \\\"{x:806,y:824,t:1527873049402};\\\", \\\"{x:857,y:846,t:1527873049418};\\\", \\\"{x:870,y:855,t:1527873049436};\\\", \\\"{x:874,y:860,t:1527873049451};\\\", \\\"{x:876,y:860,t:1527873050355};\\\", \\\"{x:882,y:860,t:1527873050369};\\\", \\\"{x:883,y:860,t:1527873050386};\\\", \\\"{x:899,y:857,t:1527873050403};\\\", \\\"{x:904,y:855,t:1527873050419};\\\", \\\"{x:914,y:854,t:1527873050436};\\\", \\\"{x:929,y:850,t:1527873050454};\\\", \\\"{x:950,y:848,t:1527873050469};\\\", \\\"{x:967,y:845,t:1527873050486};\\\", \\\"{x:981,y:844,t:1527873050504};\\\", \\\"{x:996,y:842,t:1527873050519};\\\", \\\"{x:1013,y:837,t:1527873050536};\\\", \\\"{x:1030,y:834,t:1527873050553};\\\", \\\"{x:1044,y:831,t:1527873050570};\\\", \\\"{x:1067,y:824,t:1527873050587};\\\", \\\"{x:1086,y:818,t:1527873050603};\\\", \\\"{x:1103,y:813,t:1527873050619};\\\", \\\"{x:1131,y:810,t:1527873050636};\\\", \\\"{x:1162,y:805,t:1527873050653};\\\", \\\"{x:1199,y:800,t:1527873050670};\\\", \\\"{x:1234,y:797,t:1527873050687};\\\", \\\"{x:1278,y:792,t:1527873050703};\\\", \\\"{x:1310,y:792,t:1527873050719};\\\", \\\"{x:1340,y:791,t:1527873050737};\\\", \\\"{x:1342,y:791,t:1527873050753};\\\", \\\"{x:1342,y:792,t:1527873051627};\\\", \\\"{x:1342,y:793,t:1527873051708};\\\", \\\"{x:1342,y:794,t:1527873051755};\\\", \\\"{x:1342,y:795,t:1527873051787};\\\", \\\"{x:1341,y:796,t:1527873051802};\\\", \\\"{x:1340,y:797,t:1527873051819};\\\", \\\"{x:1339,y:799,t:1527873051836};\\\", \\\"{x:1336,y:801,t:1527873051853};\\\", \\\"{x:1334,y:802,t:1527873051869};\\\", \\\"{x:1331,y:805,t:1527873051886};\\\", \\\"{x:1330,y:806,t:1527873051903};\\\", \\\"{x:1328,y:808,t:1527873051919};\\\", \\\"{x:1327,y:808,t:1527873051937};\\\", \\\"{x:1326,y:809,t:1527873051953};\\\", \\\"{x:1326,y:810,t:1527873051969};\\\", \\\"{x:1325,y:811,t:1527873051987};\\\", \\\"{x:1324,y:812,t:1527873052051};\\\", \\\"{x:1324,y:813,t:1527873052091};\\\", \\\"{x:1323,y:813,t:1527873052115};\\\", \\\"{x:1322,y:815,t:1527873052147};\\\", \\\"{x:1321,y:817,t:1527873052187};\\\", \\\"{x:1323,y:817,t:1527873052340};\\\", \\\"{x:1324,y:817,t:1527873052353};\\\", \\\"{x:1325,y:817,t:1527873052369};\\\", \\\"{x:1326,y:816,t:1527873052386};\\\", \\\"{x:1327,y:816,t:1527873052916};\\\", \\\"{x:1328,y:816,t:1527873052923};\\\", \\\"{x:1331,y:815,t:1527873052939};\\\", \\\"{x:1332,y:814,t:1527873052955};\\\", \\\"{x:1333,y:813,t:1527873052970};\\\", \\\"{x:1334,y:812,t:1527873052986};\\\", \\\"{x:1338,y:809,t:1527873053003};\\\", \\\"{x:1342,y:806,t:1527873053020};\\\", \\\"{x:1346,y:803,t:1527873053037};\\\", \\\"{x:1351,y:802,t:1527873053054};\\\", \\\"{x:1356,y:800,t:1527873053070};\\\", \\\"{x:1363,y:797,t:1527873053087};\\\", \\\"{x:1374,y:792,t:1527873053104};\\\", \\\"{x:1384,y:787,t:1527873053120};\\\", \\\"{x:1398,y:782,t:1527873053136};\\\", \\\"{x:1409,y:777,t:1527873053153};\\\", \\\"{x:1424,y:768,t:1527873053170};\\\", \\\"{x:1440,y:761,t:1527873053186};\\\", \\\"{x:1468,y:747,t:1527873053203};\\\", \\\"{x:1485,y:740,t:1527873053221};\\\", \\\"{x:1500,y:734,t:1527873053236};\\\", \\\"{x:1516,y:729,t:1527873053254};\\\", \\\"{x:1525,y:724,t:1527873053271};\\\", \\\"{x:1531,y:721,t:1527873053287};\\\", \\\"{x:1537,y:717,t:1527873053304};\\\", \\\"{x:1544,y:714,t:1527873053320};\\\", \\\"{x:1549,y:711,t:1527873053336};\\\", \\\"{x:1559,y:704,t:1527873053353};\\\", \\\"{x:1569,y:699,t:1527873053370};\\\", \\\"{x:1581,y:693,t:1527873053386};\\\", \\\"{x:1599,y:682,t:1527873053403};\\\", \\\"{x:1609,y:675,t:1527873053420};\\\", \\\"{x:1616,y:670,t:1527873053436};\\\", \\\"{x:1624,y:661,t:1527873053454};\\\", \\\"{x:1628,y:655,t:1527873053470};\\\", \\\"{x:1630,y:651,t:1527873053487};\\\", \\\"{x:1633,y:646,t:1527873053504};\\\", \\\"{x:1635,y:641,t:1527873053521};\\\", \\\"{x:1637,y:636,t:1527873053536};\\\", \\\"{x:1639,y:630,t:1527873053554};\\\", \\\"{x:1639,y:625,t:1527873053570};\\\", \\\"{x:1641,y:619,t:1527873053587};\\\", \\\"{x:1643,y:606,t:1527873053603};\\\", \\\"{x:1643,y:594,t:1527873053620};\\\", \\\"{x:1643,y:581,t:1527873053636};\\\", \\\"{x:1643,y:566,t:1527873053653};\\\", \\\"{x:1644,y:550,t:1527873053670};\\\", \\\"{x:1648,y:532,t:1527873053687};\\\", \\\"{x:1649,y:517,t:1527873053703};\\\", \\\"{x:1650,y:499,t:1527873053721};\\\", \\\"{x:1651,y:486,t:1527873053736};\\\", \\\"{x:1654,y:473,t:1527873053753};\\\", \\\"{x:1654,y:464,t:1527873053771};\\\", \\\"{x:1654,y:456,t:1527873053787};\\\", \\\"{x:1654,y:449,t:1527873053803};\\\", \\\"{x:1654,y:445,t:1527873053821};\\\", \\\"{x:1654,y:442,t:1527873053836};\\\", \\\"{x:1654,y:438,t:1527873053854};\\\", \\\"{x:1654,y:437,t:1527873053964};\\\", \\\"{x:1652,y:437,t:1527873053979};\\\", \\\"{x:1650,y:437,t:1527873053987};\\\", \\\"{x:1648,y:437,t:1527873054004};\\\", \\\"{x:1644,y:437,t:1527873054021};\\\", \\\"{x:1642,y:435,t:1527873054043};\\\", \\\"{x:1641,y:435,t:1527873054053};\\\", \\\"{x:1640,y:435,t:1527873054070};\\\", \\\"{x:1639,y:435,t:1527873054087};\\\", \\\"{x:1637,y:435,t:1527873054104};\\\", \\\"{x:1635,y:435,t:1527873054121};\\\", \\\"{x:1634,y:435,t:1527873054136};\\\", \\\"{x:1632,y:435,t:1527873054153};\\\", \\\"{x:1631,y:435,t:1527873054170};\\\", \\\"{x:1630,y:435,t:1527873054186};\\\", \\\"{x:1629,y:435,t:1527873054204};\\\", \\\"{x:1628,y:435,t:1527873054235};\\\", \\\"{x:1627,y:436,t:1527873054243};\\\", \\\"{x:1626,y:436,t:1527873054267};\\\", \\\"{x:1625,y:436,t:1527873054315};\\\", \\\"{x:1624,y:436,t:1527873054339};\\\", \\\"{x:1623,y:436,t:1527873054353};\\\", \\\"{x:1622,y:436,t:1527873054370};\\\", \\\"{x:1621,y:436,t:1527873054386};\\\", \\\"{x:1620,y:436,t:1527873054404};\\\", \\\"{x:1619,y:436,t:1527873054491};\\\", \\\"{x:1618,y:436,t:1527873055445};\\\", \\\"{x:1616,y:436,t:1527873055454};\\\", \\\"{x:1615,y:436,t:1527873055474};\\\", \\\"{x:1615,y:437,t:1527873055486};\\\", \\\"{x:1614,y:437,t:1527873055502};\\\", \\\"{x:1613,y:437,t:1527873055586};\\\", \\\"{x:1612,y:437,t:1527873055834};\\\", \\\"{x:1612,y:436,t:1527873055865};\\\", \\\"{x:1612,y:435,t:1527873055882};\\\", \\\"{x:1611,y:435,t:1527873055903};\\\", \\\"{x:1611,y:434,t:1527873055920};\\\", \\\"{x:1610,y:434,t:1527873057138};\\\", \\\"{x:1609,y:435,t:1527873057154};\\\", \\\"{x:1609,y:438,t:1527873057169};\\\", \\\"{x:1609,y:441,t:1527873057187};\\\", \\\"{x:1609,y:445,t:1527873057204};\\\", \\\"{x:1607,y:447,t:1527873057219};\\\", \\\"{x:1606,y:449,t:1527873057236};\\\", \\\"{x:1606,y:451,t:1527873057254};\\\", \\\"{x:1605,y:453,t:1527873057270};\\\", \\\"{x:1603,y:456,t:1527873057287};\\\", \\\"{x:1603,y:460,t:1527873057304};\\\", \\\"{x:1602,y:463,t:1527873057320};\\\", \\\"{x:1600,y:467,t:1527873057337};\\\", \\\"{x:1599,y:473,t:1527873057355};\\\", \\\"{x:1599,y:477,t:1527873057370};\\\", \\\"{x:1598,y:483,t:1527873057387};\\\", \\\"{x:1596,y:487,t:1527873057404};\\\", \\\"{x:1596,y:491,t:1527873057420};\\\", \\\"{x:1595,y:494,t:1527873057438};\\\", \\\"{x:1594,y:498,t:1527873057454};\\\", \\\"{x:1592,y:503,t:1527873057471};\\\", \\\"{x:1591,y:507,t:1527873057487};\\\", \\\"{x:1589,y:511,t:1527873057504};\\\", \\\"{x:1587,y:519,t:1527873057521};\\\", \\\"{x:1584,y:524,t:1527873057537};\\\", \\\"{x:1580,y:533,t:1527873057554};\\\", \\\"{x:1576,y:541,t:1527873057571};\\\", \\\"{x:1574,y:544,t:1527873057587};\\\", \\\"{x:1572,y:550,t:1527873057604};\\\", \\\"{x:1571,y:554,t:1527873057620};\\\", \\\"{x:1567,y:559,t:1527873057637};\\\", \\\"{x:1565,y:565,t:1527873057654};\\\", \\\"{x:1562,y:570,t:1527873057671};\\\", \\\"{x:1559,y:574,t:1527873057687};\\\", \\\"{x:1555,y:581,t:1527873057704};\\\", \\\"{x:1552,y:585,t:1527873057720};\\\", \\\"{x:1551,y:590,t:1527873057737};\\\", \\\"{x:1549,y:593,t:1527873057754};\\\", \\\"{x:1548,y:595,t:1527873057771};\\\", \\\"{x:1545,y:598,t:1527873057788};\\\", \\\"{x:1544,y:601,t:1527873057804};\\\", \\\"{x:1542,y:604,t:1527873057820};\\\", \\\"{x:1541,y:608,t:1527873057838};\\\", \\\"{x:1539,y:611,t:1527873057854};\\\", \\\"{x:1538,y:615,t:1527873057871};\\\", \\\"{x:1535,y:619,t:1527873057888};\\\", \\\"{x:1535,y:622,t:1527873057904};\\\", \\\"{x:1534,y:625,t:1527873057921};\\\", \\\"{x:1532,y:628,t:1527873057938};\\\", \\\"{x:1530,y:634,t:1527873057955};\\\", \\\"{x:1528,y:640,t:1527873057970};\\\", \\\"{x:1525,y:644,t:1527873057987};\\\", \\\"{x:1521,y:651,t:1527873058004};\\\", \\\"{x:1519,y:656,t:1527873058020};\\\", \\\"{x:1517,y:662,t:1527873058037};\\\", \\\"{x:1513,y:669,t:1527873058054};\\\", \\\"{x:1507,y:676,t:1527873058071};\\\", \\\"{x:1505,y:681,t:1527873058088};\\\", \\\"{x:1501,y:686,t:1527873058104};\\\", \\\"{x:1498,y:691,t:1527873058120};\\\", \\\"{x:1495,y:696,t:1527873058138};\\\", \\\"{x:1491,y:703,t:1527873058155};\\\", \\\"{x:1490,y:705,t:1527873058170};\\\", \\\"{x:1488,y:709,t:1527873058187};\\\", \\\"{x:1486,y:712,t:1527873058204};\\\", \\\"{x:1483,y:718,t:1527873058221};\\\", \\\"{x:1480,y:723,t:1527873058238};\\\", \\\"{x:1476,y:729,t:1527873058255};\\\", \\\"{x:1473,y:734,t:1527873058271};\\\", \\\"{x:1470,y:738,t:1527873058287};\\\", \\\"{x:1467,y:741,t:1527873058305};\\\", \\\"{x:1465,y:745,t:1527873058320};\\\", \\\"{x:1464,y:747,t:1527873058338};\\\", \\\"{x:1460,y:754,t:1527873058355};\\\", \\\"{x:1455,y:760,t:1527873058371};\\\", \\\"{x:1451,y:766,t:1527873058387};\\\", \\\"{x:1445,y:773,t:1527873058405};\\\", \\\"{x:1440,y:780,t:1527873058420};\\\", \\\"{x:1436,y:786,t:1527873058437};\\\", \\\"{x:1432,y:790,t:1527873058455};\\\", \\\"{x:1427,y:797,t:1527873058471};\\\", \\\"{x:1424,y:802,t:1527873058487};\\\", \\\"{x:1423,y:804,t:1527873058505};\\\", \\\"{x:1420,y:808,t:1527873058520};\\\", \\\"{x:1417,y:812,t:1527873058538};\\\", \\\"{x:1413,y:818,t:1527873058554};\\\", \\\"{x:1412,y:822,t:1527873058570};\\\", \\\"{x:1408,y:826,t:1527873058588};\\\", \\\"{x:1405,y:834,t:1527873058605};\\\", \\\"{x:1403,y:838,t:1527873058620};\\\", \\\"{x:1401,y:840,t:1527873058638};\\\", \\\"{x:1398,y:844,t:1527873058655};\\\", \\\"{x:1394,y:849,t:1527873058672};\\\", \\\"{x:1390,y:854,t:1527873058688};\\\", \\\"{x:1389,y:857,t:1527873058704};\\\", \\\"{x:1385,y:864,t:1527873058722};\\\", \\\"{x:1382,y:868,t:1527873058737};\\\", \\\"{x:1376,y:881,t:1527873058755};\\\", \\\"{x:1372,y:888,t:1527873058771};\\\", \\\"{x:1368,y:894,t:1527873058788};\\\", \\\"{x:1365,y:899,t:1527873058805};\\\", \\\"{x:1363,y:902,t:1527873058822};\\\", \\\"{x:1360,y:910,t:1527873058838};\\\", \\\"{x:1357,y:919,t:1527873058855};\\\", \\\"{x:1356,y:930,t:1527873058871};\\\", \\\"{x:1354,y:938,t:1527873058888};\\\", \\\"{x:1352,y:946,t:1527873058904};\\\", \\\"{x:1351,y:950,t:1527873058921};\\\", \\\"{x:1350,y:954,t:1527873058938};\\\", \\\"{x:1348,y:960,t:1527873058955};\\\", \\\"{x:1348,y:961,t:1527873058972};\\\", \\\"{x:1347,y:964,t:1527873058988};\\\", \\\"{x:1347,y:965,t:1527873059005};\\\", \\\"{x:1347,y:966,t:1527873059021};\\\", \\\"{x:1345,y:968,t:1527873059038};\\\", \\\"{x:1345,y:969,t:1527873059061};\\\", \\\"{x:1344,y:970,t:1527873059071};\\\", \\\"{x:1343,y:971,t:1527873059087};\\\", \\\"{x:1343,y:970,t:1527873060907};\\\", \\\"{x:1343,y:969,t:1527873060931};\\\", \\\"{x:1343,y:967,t:1527873060939};\\\", \\\"{x:1343,y:966,t:1527873060955};\\\", \\\"{x:1343,y:964,t:1527873060972};\\\", \\\"{x:1343,y:961,t:1527873060989};\\\", \\\"{x:1343,y:958,t:1527873061004};\\\", \\\"{x:1343,y:953,t:1527873061022};\\\", \\\"{x:1344,y:945,t:1527873061039};\\\", \\\"{x:1348,y:933,t:1527873061054};\\\", \\\"{x:1351,y:919,t:1527873061071};\\\", \\\"{x:1356,y:899,t:1527873061088};\\\", \\\"{x:1361,y:879,t:1527873061105};\\\", \\\"{x:1368,y:853,t:1527873061122};\\\", \\\"{x:1378,y:826,t:1527873061138};\\\", \\\"{x:1402,y:772,t:1527873061155};\\\", \\\"{x:1412,y:747,t:1527873061172};\\\", \\\"{x:1420,y:728,t:1527873061189};\\\", \\\"{x:1424,y:712,t:1527873061205};\\\", \\\"{x:1428,y:698,t:1527873061222};\\\", \\\"{x:1430,y:687,t:1527873061238};\\\", \\\"{x:1434,y:676,t:1527873061255};\\\", \\\"{x:1438,y:664,t:1527873061272};\\\", \\\"{x:1440,y:655,t:1527873061289};\\\", \\\"{x:1443,y:650,t:1527873061305};\\\", \\\"{x:1445,y:644,t:1527873061321};\\\", \\\"{x:1449,y:640,t:1527873061339};\\\", \\\"{x:1449,y:639,t:1527873061355};\\\", \\\"{x:1451,y:637,t:1527873061372};\\\", \\\"{x:1455,y:634,t:1527873061389};\\\", \\\"{x:1459,y:632,t:1527873061405};\\\", \\\"{x:1468,y:631,t:1527873061421};\\\", \\\"{x:1477,y:630,t:1527873061439};\\\", \\\"{x:1486,y:630,t:1527873061454};\\\", \\\"{x:1490,y:630,t:1527873061471};\\\", \\\"{x:1493,y:630,t:1527873061488};\\\", \\\"{x:1495,y:630,t:1527873061505};\\\", \\\"{x:1496,y:630,t:1527873061529};\\\", \\\"{x:1497,y:630,t:1527873061625};\\\", \\\"{x:1498,y:630,t:1527873061747};\\\", \\\"{x:1499,y:630,t:1527873061770};\\\", \\\"{x:1499,y:629,t:1527873061779};\\\", \\\"{x:1500,y:629,t:1527873061811};\\\", \\\"{x:1501,y:629,t:1527873061843};\\\", \\\"{x:1502,y:629,t:1527873061875};\\\", \\\"{x:1503,y:629,t:1527873062531};\\\", \\\"{x:1504,y:629,t:1527873062555};\\\", \\\"{x:1501,y:630,t:1527873063387};\\\", \\\"{x:1491,y:632,t:1527873063395};\\\", \\\"{x:1470,y:636,t:1527873063406};\\\", \\\"{x:1379,y:646,t:1527873063422};\\\", \\\"{x:1251,y:648,t:1527873063438};\\\", \\\"{x:1105,y:648,t:1527873063456};\\\", \\\"{x:958,y:648,t:1527873063471};\\\", \\\"{x:803,y:648,t:1527873063488};\\\", \\\"{x:665,y:648,t:1527873063508};\\\", \\\"{x:544,y:656,t:1527873063522};\\\", \\\"{x:430,y:656,t:1527873063538};\\\", \\\"{x:413,y:656,t:1527873063548};\\\", \\\"{x:386,y:656,t:1527873063564};\\\", \\\"{x:370,y:656,t:1527873063581};\\\", \\\"{x:361,y:656,t:1527873063599};\\\", \\\"{x:359,y:656,t:1527873063614};\\\", \\\"{x:359,y:655,t:1527873063762};\\\", \\\"{x:359,y:651,t:1527873063770};\\\", \\\"{x:359,y:648,t:1527873063783};\\\", \\\"{x:359,y:641,t:1527873063798};\\\", \\\"{x:359,y:632,t:1527873063815};\\\", \\\"{x:359,y:623,t:1527873063831};\\\", \\\"{x:359,y:613,t:1527873063849};\\\", \\\"{x:359,y:604,t:1527873063865};\\\", \\\"{x:359,y:592,t:1527873063881};\\\", \\\"{x:352,y:575,t:1527873063898};\\\", \\\"{x:348,y:569,t:1527873063916};\\\", \\\"{x:345,y:565,t:1527873063931};\\\", \\\"{x:343,y:563,t:1527873063948};\\\", \\\"{x:341,y:561,t:1527873063965};\\\", \\\"{x:337,y:560,t:1527873063981};\\\", \\\"{x:330,y:560,t:1527873063998};\\\", \\\"{x:318,y:560,t:1527873064015};\\\", \\\"{x:302,y:560,t:1527873064031};\\\", \\\"{x:283,y:560,t:1527873064049};\\\", \\\"{x:274,y:560,t:1527873064065};\\\", \\\"{x:272,y:560,t:1527873064083};\\\", \\\"{x:272,y:561,t:1527873064163};\\\", \\\"{x:275,y:565,t:1527873064172};\\\", \\\"{x:284,y:570,t:1527873064183};\\\", \\\"{x:304,y:575,t:1527873064199};\\\", \\\"{x:328,y:577,t:1527873064216};\\\", \\\"{x:370,y:579,t:1527873064232};\\\", \\\"{x:445,y:579,t:1527873064248};\\\", \\\"{x:526,y:579,t:1527873064265};\\\", \\\"{x:615,y:579,t:1527873064282};\\\", \\\"{x:657,y:579,t:1527873064298};\\\", \\\"{x:688,y:576,t:1527873064315};\\\", \\\"{x:705,y:574,t:1527873064333};\\\", \\\"{x:712,y:572,t:1527873064348};\\\", \\\"{x:714,y:571,t:1527873064365};\\\", \\\"{x:711,y:571,t:1527873064507};\\\", \\\"{x:706,y:572,t:1527873064516};\\\", \\\"{x:688,y:577,t:1527873064534};\\\", \\\"{x:662,y:583,t:1527873064550};\\\", \\\"{x:625,y:589,t:1527873064565};\\\", \\\"{x:565,y:593,t:1527873064583};\\\", \\\"{x:493,y:593,t:1527873064600};\\\", \\\"{x:407,y:593,t:1527873064615};\\\", \\\"{x:354,y:593,t:1527873064632};\\\", \\\"{x:318,y:593,t:1527873064649};\\\", \\\"{x:296,y:593,t:1527873064665};\\\", \\\"{x:292,y:593,t:1527873064682};\\\", \\\"{x:294,y:593,t:1527873064794};\\\", \\\"{x:297,y:593,t:1527873064803};\\\", \\\"{x:298,y:592,t:1527873064815};\\\", \\\"{x:305,y:590,t:1527873064832};\\\", \\\"{x:313,y:587,t:1527873064850};\\\", \\\"{x:323,y:586,t:1527873064866};\\\", \\\"{x:327,y:586,t:1527873064883};\\\", \\\"{x:330,y:586,t:1527873064900};\\\", \\\"{x:332,y:586,t:1527873064922};\\\", \\\"{x:333,y:586,t:1527873064939};\\\", \\\"{x:334,y:588,t:1527873064949};\\\", \\\"{x:335,y:589,t:1527873064966};\\\", \\\"{x:336,y:592,t:1527873064982};\\\", \\\"{x:336,y:593,t:1527873064999};\\\", \\\"{x:336,y:594,t:1527873065016};\\\", \\\"{x:336,y:596,t:1527873065033};\\\", \\\"{x:336,y:598,t:1527873065050};\\\", \\\"{x:336,y:602,t:1527873065067};\\\", \\\"{x:337,y:604,t:1527873065082};\\\", \\\"{x:339,y:606,t:1527873065099};\\\", \\\"{x:342,y:608,t:1527873065116};\\\", \\\"{x:345,y:609,t:1527873065133};\\\", \\\"{x:348,y:609,t:1527873065150};\\\", \\\"{x:351,y:609,t:1527873065166};\\\", \\\"{x:355,y:609,t:1527873065183};\\\", \\\"{x:358,y:609,t:1527873065200};\\\", \\\"{x:360,y:609,t:1527873065217};\\\", \\\"{x:363,y:609,t:1527873065232};\\\", \\\"{x:366,y:609,t:1527873065250};\\\", \\\"{x:370,y:609,t:1527873065266};\\\", \\\"{x:373,y:609,t:1527873065282};\\\", \\\"{x:374,y:609,t:1527873065300};\\\", \\\"{x:377,y:608,t:1527873065317};\\\", \\\"{x:379,y:607,t:1527873065346};\\\", \\\"{x:380,y:607,t:1527873065379};\\\", \\\"{x:381,y:606,t:1527873065386};\\\", \\\"{x:382,y:606,t:1527873065419};\\\", \\\"{x:383,y:606,t:1527873065435};\\\", \\\"{x:384,y:605,t:1527873065466};\\\", \\\"{x:386,y:605,t:1527873066083};\\\", \\\"{x:401,y:605,t:1527873066101};\\\", \\\"{x:452,y:621,t:1527873066118};\\\", \\\"{x:543,y:648,t:1527873066135};\\\", \\\"{x:662,y:679,t:1527873066151};\\\", \\\"{x:800,y:718,t:1527873066167};\\\", \\\"{x:943,y:750,t:1527873066183};\\\", \\\"{x:1094,y:790,t:1527873066200};\\\", \\\"{x:1224,y:826,t:1527873066217};\\\", \\\"{x:1338,y:857,t:1527873066233};\\\", \\\"{x:1457,y:890,t:1527873066249};\\\", \\\"{x:1502,y:904,t:1527873066267};\\\", \\\"{x:1521,y:909,t:1527873066283};\\\", \\\"{x:1531,y:913,t:1527873066300};\\\", \\\"{x:1532,y:913,t:1527873066317};\\\", \\\"{x:1530,y:914,t:1527873066491};\\\", \\\"{x:1519,y:915,t:1527873066500};\\\", \\\"{x:1492,y:917,t:1527873066518};\\\", \\\"{x:1455,y:921,t:1527873066534};\\\", \\\"{x:1428,y:927,t:1527873066550};\\\", \\\"{x:1400,y:932,t:1527873066567};\\\", \\\"{x:1381,y:936,t:1527873066584};\\\", \\\"{x:1368,y:942,t:1527873066600};\\\", \\\"{x:1362,y:945,t:1527873066618};\\\", \\\"{x:1359,y:949,t:1527873066634};\\\", \\\"{x:1358,y:949,t:1527873067099};\\\", \\\"{x:1356,y:949,t:1527873067114};\\\", \\\"{x:1354,y:950,t:1527873067123};\\\", \\\"{x:1349,y:950,t:1527873067135};\\\", \\\"{x:1344,y:952,t:1527873067152};\\\", \\\"{x:1342,y:952,t:1527873067168};\\\", \\\"{x:1337,y:954,t:1527873067184};\\\", \\\"{x:1334,y:954,t:1527873067201};\\\", \\\"{x:1332,y:955,t:1527873067217};\\\", \\\"{x:1331,y:956,t:1527873067235};\\\", \\\"{x:1330,y:956,t:1527873067252};\\\", \\\"{x:1329,y:956,t:1527873067268};\\\", \\\"{x:1327,y:957,t:1527873067284};\\\", \\\"{x:1326,y:957,t:1527873067301};\\\", \\\"{x:1324,y:957,t:1527873067319};\\\", \\\"{x:1322,y:958,t:1527873067334};\\\", \\\"{x:1317,y:960,t:1527873067351};\\\", \\\"{x:1313,y:960,t:1527873067368};\\\", \\\"{x:1309,y:960,t:1527873067384};\\\", \\\"{x:1307,y:960,t:1527873067402};\\\", \\\"{x:1302,y:961,t:1527873067418};\\\", \\\"{x:1299,y:961,t:1527873067435};\\\", \\\"{x:1296,y:961,t:1527873067451};\\\", \\\"{x:1293,y:961,t:1527873067469};\\\", \\\"{x:1292,y:961,t:1527873067484};\\\", \\\"{x:1291,y:961,t:1527873067502};\\\", \\\"{x:1290,y:961,t:1527873067519};\\\", \\\"{x:1289,y:961,t:1527873067795};\\\", \\\"{x:1288,y:962,t:1527873068603};\\\", \\\"{x:1287,y:963,t:1527873068675};\\\", \\\"{x:1286,y:963,t:1527873068787};\\\", \\\"{x:1286,y:964,t:1527873068803};\\\", \\\"{x:1285,y:964,t:1527873069379};\\\", \\\"{x:1284,y:964,t:1527873069410};\\\", \\\"{x:1283,y:964,t:1527873069442};\\\", \\\"{x:1283,y:965,t:1527873069467};\\\", \\\"{x:1282,y:965,t:1527873069483};\\\", \\\"{x:1281,y:965,t:1527873069530};\\\", \\\"{x:1280,y:965,t:1527873069571};\\\", \\\"{x:1280,y:964,t:1527873069819};\\\", \\\"{x:1280,y:961,t:1527873069827};\\\", \\\"{x:1282,y:959,t:1527873069837};\\\", \\\"{x:1287,y:953,t:1527873069854};\\\", \\\"{x:1291,y:948,t:1527873069871};\\\", \\\"{x:1293,y:946,t:1527873069887};\\\", \\\"{x:1297,y:942,t:1527873069904};\\\", \\\"{x:1299,y:939,t:1527873069921};\\\", \\\"{x:1301,y:937,t:1527873069937};\\\", \\\"{x:1303,y:935,t:1527873069954};\\\", \\\"{x:1304,y:933,t:1527873069971};\\\", \\\"{x:1306,y:932,t:1527873069987};\\\", \\\"{x:1307,y:930,t:1527873070003};\\\", \\\"{x:1308,y:929,t:1527873070020};\\\", \\\"{x:1310,y:926,t:1527873070036};\\\", \\\"{x:1310,y:925,t:1527873070053};\\\", \\\"{x:1312,y:923,t:1527873070070};\\\", \\\"{x:1314,y:920,t:1527873070087};\\\", \\\"{x:1316,y:917,t:1527873070104};\\\", \\\"{x:1317,y:915,t:1527873070120};\\\", \\\"{x:1319,y:912,t:1527873070137};\\\", \\\"{x:1319,y:911,t:1527873070153};\\\", \\\"{x:1319,y:913,t:1527873070603};\\\", \\\"{x:1319,y:914,t:1527873070610};\\\", \\\"{x:1319,y:915,t:1527873070621};\\\", \\\"{x:1319,y:917,t:1527873070638};\\\", \\\"{x:1318,y:921,t:1527873070655};\\\", \\\"{x:1316,y:927,t:1527873070670};\\\", \\\"{x:1315,y:933,t:1527873070687};\\\", \\\"{x:1312,y:939,t:1527873070705};\\\", \\\"{x:1310,y:946,t:1527873070720};\\\", \\\"{x:1307,y:951,t:1527873070738};\\\", \\\"{x:1303,y:959,t:1527873070754};\\\", \\\"{x:1302,y:963,t:1527873070771};\\\", \\\"{x:1298,y:967,t:1527873070788};\\\", \\\"{x:1296,y:970,t:1527873070805};\\\", \\\"{x:1295,y:970,t:1527873070821};\\\", \\\"{x:1293,y:971,t:1527873070837};\\\", \\\"{x:1291,y:972,t:1527873070855};\\\", \\\"{x:1290,y:972,t:1527873070870};\\\", \\\"{x:1289,y:972,t:1527873070887};\\\", \\\"{x:1287,y:972,t:1527873070905};\\\", \\\"{x:1286,y:972,t:1527873070920};\\\", \\\"{x:1285,y:972,t:1527873070938};\\\", \\\"{x:1283,y:972,t:1527873070954};\\\", \\\"{x:1282,y:972,t:1527873070978};\\\", \\\"{x:1281,y:972,t:1527873070995};\\\", \\\"{x:1280,y:972,t:1527873071051};\\\", \\\"{x:1280,y:970,t:1527873071619};\\\", \\\"{x:1279,y:965,t:1527873071627};\\\", \\\"{x:1279,y:961,t:1527873071639};\\\", \\\"{x:1276,y:952,t:1527873071656};\\\", \\\"{x:1267,y:936,t:1527873071671};\\\", \\\"{x:1258,y:921,t:1527873071690};\\\", \\\"{x:1244,y:904,t:1527873071706};\\\", \\\"{x:1229,y:889,t:1527873071723};\\\", \\\"{x:1214,y:873,t:1527873071739};\\\", \\\"{x:1206,y:864,t:1527873071755};\\\", \\\"{x:1203,y:861,t:1527873071773};\\\", \\\"{x:1203,y:860,t:1527873071789};\\\", \\\"{x:1204,y:863,t:1527873071874};\\\", \\\"{x:1210,y:870,t:1527873071888};\\\", \\\"{x:1232,y:895,t:1527873071906};\\\", \\\"{x:1250,y:912,t:1527873071922};\\\", \\\"{x:1264,y:926,t:1527873071938};\\\", \\\"{x:1278,y:939,t:1527873071956};\\\", \\\"{x:1288,y:949,t:1527873071972};\\\", \\\"{x:1293,y:954,t:1527873071989};\\\", \\\"{x:1294,y:954,t:1527873072006};\\\", \\\"{x:1295,y:954,t:1527873072067};\\\", \\\"{x:1296,y:951,t:1527873072075};\\\", \\\"{x:1298,y:947,t:1527873072089};\\\", \\\"{x:1309,y:922,t:1527873072106};\\\", \\\"{x:1319,y:899,t:1527873072122};\\\", \\\"{x:1329,y:878,t:1527873072139};\\\", \\\"{x:1339,y:855,t:1527873072157};\\\", \\\"{x:1351,y:834,t:1527873072172};\\\", \\\"{x:1362,y:810,t:1527873072189};\\\", \\\"{x:1371,y:791,t:1527873072206};\\\", \\\"{x:1379,y:776,t:1527873072223};\\\", \\\"{x:1384,y:767,t:1527873072240};\\\", \\\"{x:1385,y:763,t:1527873072256};\\\", \\\"{x:1386,y:761,t:1527873072272};\\\", \\\"{x:1385,y:761,t:1527873073506};\\\", \\\"{x:1380,y:764,t:1527873073524};\\\", \\\"{x:1369,y:778,t:1527873073541};\\\", \\\"{x:1362,y:790,t:1527873073558};\\\", \\\"{x:1354,y:805,t:1527873073574};\\\", \\\"{x:1342,y:825,t:1527873073590};\\\", \\\"{x:1330,y:847,t:1527873073607};\\\", \\\"{x:1317,y:868,t:1527873073624};\\\", \\\"{x:1310,y:887,t:1527873073640};\\\", \\\"{x:1305,y:900,t:1527873073658};\\\", \\\"{x:1298,y:919,t:1527873073674};\\\", \\\"{x:1297,y:928,t:1527873073690};\\\", \\\"{x:1294,y:934,t:1527873073707};\\\", \\\"{x:1294,y:936,t:1527873073724};\\\", \\\"{x:1294,y:938,t:1527873073741};\\\", \\\"{x:1294,y:940,t:1527873073758};\\\", \\\"{x:1294,y:943,t:1527873073774};\\\", \\\"{x:1293,y:947,t:1527873073790};\\\", \\\"{x:1292,y:950,t:1527873073807};\\\", \\\"{x:1291,y:953,t:1527873073824};\\\", \\\"{x:1290,y:955,t:1527873073841};\\\", \\\"{x:1290,y:956,t:1527873073857};\\\", \\\"{x:1290,y:958,t:1527873073874};\\\", \\\"{x:1290,y:959,t:1527873073891};\\\", \\\"{x:1289,y:962,t:1527873073907};\\\", \\\"{x:1288,y:962,t:1527873073925};\\\", \\\"{x:1288,y:963,t:1527873074019};\\\", \\\"{x:1286,y:963,t:1527873074291};\\\", \\\"{x:1281,y:961,t:1527873074309};\\\", \\\"{x:1277,y:958,t:1527873074325};\\\", \\\"{x:1276,y:957,t:1527873074341};\\\", \\\"{x:1274,y:956,t:1527873074358};\\\", \\\"{x:1273,y:955,t:1527873074375};\\\", \\\"{x:1272,y:953,t:1527873074391};\\\", \\\"{x:1271,y:953,t:1527873074407};\\\", \\\"{x:1270,y:951,t:1527873074424};\\\", \\\"{x:1268,y:948,t:1527873074441};\\\", \\\"{x:1266,y:943,t:1527873074458};\\\", \\\"{x:1263,y:937,t:1527873074474};\\\", \\\"{x:1260,y:931,t:1527873074491};\\\", \\\"{x:1257,y:924,t:1527873074508};\\\", \\\"{x:1255,y:918,t:1527873074524};\\\", \\\"{x:1254,y:913,t:1527873074541};\\\", \\\"{x:1253,y:911,t:1527873074559};\\\", \\\"{x:1252,y:910,t:1527873074574};\\\", \\\"{x:1252,y:909,t:1527873074591};\\\", \\\"{x:1252,y:910,t:1527873075026};\\\", \\\"{x:1253,y:912,t:1527873075042};\\\", \\\"{x:1257,y:918,t:1527873075059};\\\", \\\"{x:1259,y:921,t:1527873075075};\\\", \\\"{x:1263,y:926,t:1527873075092};\\\", \\\"{x:1267,y:931,t:1527873075108};\\\", \\\"{x:1272,y:938,t:1527873075126};\\\", \\\"{x:1277,y:946,t:1527873075142};\\\", \\\"{x:1282,y:952,t:1527873075158};\\\", \\\"{x:1282,y:954,t:1527873075175};\\\", \\\"{x:1283,y:957,t:1527873075192};\\\", \\\"{x:1284,y:958,t:1527873075208};\\\", \\\"{x:1285,y:959,t:1527873075226};\\\", \\\"{x:1286,y:957,t:1527873075715};\\\", \\\"{x:1287,y:955,t:1527873075731};\\\", \\\"{x:1287,y:953,t:1527873075743};\\\", \\\"{x:1289,y:948,t:1527873075760};\\\", \\\"{x:1293,y:943,t:1527873075775};\\\", \\\"{x:1296,y:934,t:1527873075792};\\\", \\\"{x:1303,y:922,t:1527873075810};\\\", \\\"{x:1308,y:910,t:1527873075825};\\\", \\\"{x:1317,y:890,t:1527873075842};\\\", \\\"{x:1325,y:876,t:1527873075859};\\\", \\\"{x:1332,y:862,t:1527873075875};\\\", \\\"{x:1342,y:846,t:1527873075893};\\\", \\\"{x:1348,y:834,t:1527873075909};\\\", \\\"{x:1354,y:819,t:1527873075926};\\\", \\\"{x:1360,y:806,t:1527873075942};\\\", \\\"{x:1367,y:795,t:1527873075960};\\\", \\\"{x:1370,y:788,t:1527873075976};\\\", \\\"{x:1373,y:783,t:1527873075993};\\\", \\\"{x:1376,y:777,t:1527873076010};\\\", \\\"{x:1380,y:769,t:1527873076027};\\\", \\\"{x:1380,y:767,t:1527873076043};\\\", \\\"{x:1381,y:766,t:1527873076059};\\\", \\\"{x:1383,y:766,t:1527873079531};\\\", \\\"{x:1384,y:768,t:1527873079546};\\\", \\\"{x:1388,y:772,t:1527873079563};\\\", \\\"{x:1391,y:775,t:1527873079579};\\\", \\\"{x:1394,y:779,t:1527873079595};\\\", \\\"{x:1397,y:783,t:1527873079613};\\\", \\\"{x:1399,y:790,t:1527873079629};\\\", \\\"{x:1401,y:796,t:1527873079645};\\\", \\\"{x:1406,y:806,t:1527873079663};\\\", \\\"{x:1411,y:816,t:1527873079679};\\\", \\\"{x:1415,y:824,t:1527873079695};\\\", \\\"{x:1417,y:832,t:1527873079713};\\\", \\\"{x:1422,y:843,t:1527873079729};\\\", \\\"{x:1427,y:855,t:1527873079746};\\\", \\\"{x:1437,y:871,t:1527873079763};\\\", \\\"{x:1445,y:883,t:1527873079779};\\\", \\\"{x:1451,y:891,t:1527873079795};\\\", \\\"{x:1456,y:898,t:1527873079812};\\\", \\\"{x:1459,y:902,t:1527873079830};\\\", \\\"{x:1464,y:911,t:1527873079845};\\\", \\\"{x:1472,y:920,t:1527873079862};\\\", \\\"{x:1476,y:928,t:1527873079879};\\\", \\\"{x:1480,y:935,t:1527873079896};\\\", \\\"{x:1482,y:940,t:1527873079912};\\\", \\\"{x:1485,y:944,t:1527873079930};\\\", \\\"{x:1487,y:949,t:1527873079945};\\\", \\\"{x:1490,y:954,t:1527873079963};\\\", \\\"{x:1491,y:955,t:1527873079980};\\\", \\\"{x:1492,y:956,t:1527873079996};\\\", \\\"{x:1492,y:957,t:1527873080042};\\\", \\\"{x:1492,y:958,t:1527873080051};\\\", \\\"{x:1492,y:959,t:1527873080062};\\\", \\\"{x:1493,y:960,t:1527873080080};\\\", \\\"{x:1493,y:961,t:1527873080096};\\\", \\\"{x:1493,y:962,t:1527873080211};\\\", \\\"{x:1492,y:962,t:1527873082811};\\\", \\\"{x:1490,y:962,t:1527873082835};\\\", \\\"{x:1489,y:961,t:1527873082955};\\\", \\\"{x:1488,y:961,t:1527873083299};\\\", \\\"{x:1471,y:958,t:1527873083315};\\\", \\\"{x:1440,y:952,t:1527873083333};\\\", \\\"{x:1406,y:948,t:1527873083348};\\\", \\\"{x:1364,y:943,t:1527873083366};\\\", \\\"{x:1324,y:936,t:1527873083382};\\\", \\\"{x:1295,y:934,t:1527873083399};\\\", \\\"{x:1272,y:932,t:1527873083416};\\\", \\\"{x:1250,y:932,t:1527873083432};\\\", \\\"{x:1232,y:932,t:1527873083449};\\\", \\\"{x:1219,y:937,t:1527873083466};\\\", \\\"{x:1203,y:942,t:1527873083483};\\\", \\\"{x:1198,y:944,t:1527873083498};\\\", \\\"{x:1196,y:945,t:1527873083515};\\\", \\\"{x:1196,y:946,t:1527873083675};\\\", \\\"{x:1196,y:947,t:1527873083683};\\\", \\\"{x:1196,y:949,t:1527873083699};\\\", \\\"{x:1196,y:950,t:1527873083715};\\\", \\\"{x:1196,y:951,t:1527873083732};\\\", \\\"{x:1195,y:952,t:1527873083810};\\\", \\\"{x:1196,y:953,t:1527873083817};\\\", \\\"{x:1199,y:955,t:1527873083832};\\\", \\\"{x:1214,y:963,t:1527873083849};\\\", \\\"{x:1231,y:970,t:1527873083865};\\\", \\\"{x:1255,y:982,t:1527873083882};\\\", \\\"{x:1272,y:989,t:1527873083899};\\\", \\\"{x:1285,y:993,t:1527873083915};\\\", \\\"{x:1287,y:993,t:1527873083932};\\\", \\\"{x:1289,y:993,t:1527873083950};\\\", \\\"{x:1290,y:993,t:1527873083971};\\\", \\\"{x:1291,y:993,t:1527873083994};\\\", \\\"{x:1291,y:992,t:1527873084146};\\\", \\\"{x:1291,y:990,t:1527873084171};\\\", \\\"{x:1291,y:987,t:1527873084186};\\\", \\\"{x:1292,y:985,t:1527873084200};\\\", \\\"{x:1298,y:979,t:1527873084217};\\\", \\\"{x:1303,y:973,t:1527873084233};\\\", \\\"{x:1310,y:968,t:1527873084250};\\\", \\\"{x:1324,y:960,t:1527873084266};\\\", \\\"{x:1335,y:957,t:1527873084282};\\\", \\\"{x:1345,y:954,t:1527873084299};\\\", \\\"{x:1354,y:954,t:1527873084317};\\\", \\\"{x:1357,y:954,t:1527873084333};\\\", \\\"{x:1362,y:954,t:1527873084349};\\\", \\\"{x:1369,y:955,t:1527873084366};\\\", \\\"{x:1378,y:959,t:1527873084383};\\\", \\\"{x:1392,y:965,t:1527873084400};\\\", \\\"{x:1410,y:971,t:1527873084417};\\\", \\\"{x:1413,y:975,t:1527873084433};\\\", \\\"{x:1414,y:974,t:1527873084883};\\\", \\\"{x:1415,y:973,t:1527873084901};\\\", \\\"{x:1417,y:972,t:1527873084916};\\\", \\\"{x:1417,y:971,t:1527873084938};\\\", \\\"{x:1418,y:971,t:1527873084952};\\\", \\\"{x:1418,y:970,t:1527873084986};\\\", \\\"{x:1418,y:969,t:1527873085000};\\\", \\\"{x:1418,y:968,t:1527873085018};\\\", \\\"{x:1418,y:967,t:1527873085073};\\\", \\\"{x:1418,y:966,t:1527873085106};\\\", \\\"{x:1419,y:965,t:1527873085116};\\\", \\\"{x:1419,y:964,t:1527873085138};\\\", \\\"{x:1420,y:964,t:1527873085154};\\\", \\\"{x:1421,y:963,t:1527873085166};\\\", \\\"{x:1423,y:963,t:1527873085183};\\\", \\\"{x:1426,y:962,t:1527873085201};\\\", \\\"{x:1432,y:961,t:1527873085217};\\\", \\\"{x:1438,y:958,t:1527873085234};\\\", \\\"{x:1449,y:956,t:1527873085250};\\\", \\\"{x:1461,y:952,t:1527873085267};\\\", \\\"{x:1474,y:944,t:1527873085283};\\\", \\\"{x:1488,y:936,t:1527873085300};\\\", \\\"{x:1503,y:924,t:1527873085317};\\\", \\\"{x:1518,y:910,t:1527873085334};\\\", \\\"{x:1534,y:894,t:1527873085351};\\\", \\\"{x:1544,y:882,t:1527873085368};\\\", \\\"{x:1558,y:869,t:1527873085384};\\\", \\\"{x:1571,y:856,t:1527873085401};\\\", \\\"{x:1579,y:848,t:1527873085418};\\\", \\\"{x:1586,y:837,t:1527873085434};\\\", \\\"{x:1594,y:824,t:1527873085450};\\\", \\\"{x:1595,y:817,t:1527873085467};\\\", \\\"{x:1596,y:813,t:1527873085483};\\\", \\\"{x:1596,y:808,t:1527873085501};\\\", \\\"{x:1596,y:802,t:1527873085518};\\\", \\\"{x:1594,y:795,t:1527873085533};\\\", \\\"{x:1588,y:786,t:1527873085550};\\\", \\\"{x:1582,y:777,t:1527873085567};\\\", \\\"{x:1572,y:763,t:1527873085584};\\\", \\\"{x:1561,y:747,t:1527873085601};\\\", \\\"{x:1554,y:736,t:1527873085618};\\\", \\\"{x:1545,y:722,t:1527873085634};\\\", \\\"{x:1534,y:706,t:1527873085650};\\\", \\\"{x:1528,y:699,t:1527873085668};\\\", \\\"{x:1522,y:690,t:1527873085684};\\\", \\\"{x:1518,y:682,t:1527873085701};\\\", \\\"{x:1517,y:678,t:1527873085717};\\\", \\\"{x:1516,y:673,t:1527873085734};\\\", \\\"{x:1516,y:671,t:1527873085750};\\\", \\\"{x:1515,y:665,t:1527873085767};\\\", \\\"{x:1515,y:661,t:1527873085784};\\\", \\\"{x:1514,y:657,t:1527873085800};\\\", \\\"{x:1514,y:651,t:1527873085817};\\\", \\\"{x:1514,y:645,t:1527873085834};\\\", \\\"{x:1514,y:640,t:1527873085850};\\\", \\\"{x:1514,y:633,t:1527873085868};\\\", \\\"{x:1518,y:624,t:1527873085884};\\\", \\\"{x:1521,y:616,t:1527873085901};\\\", \\\"{x:1526,y:606,t:1527873085917};\\\", \\\"{x:1530,y:595,t:1527873085935};\\\", \\\"{x:1535,y:583,t:1527873085950};\\\", \\\"{x:1535,y:578,t:1527873085968};\\\", \\\"{x:1539,y:569,t:1527873085984};\\\", \\\"{x:1542,y:561,t:1527873086001};\\\", \\\"{x:1545,y:553,t:1527873086017};\\\", \\\"{x:1549,y:544,t:1527873086035};\\\", \\\"{x:1553,y:536,t:1527873086050};\\\", \\\"{x:1557,y:529,t:1527873086067};\\\", \\\"{x:1561,y:522,t:1527873086084};\\\", \\\"{x:1564,y:515,t:1527873086100};\\\", \\\"{x:1566,y:509,t:1527873086117};\\\", \\\"{x:1568,y:504,t:1527873086135};\\\", \\\"{x:1571,y:500,t:1527873086152};\\\", \\\"{x:1573,y:497,t:1527873086168};\\\", \\\"{x:1573,y:496,t:1527873086185};\\\", \\\"{x:1574,y:495,t:1527873086262};\\\", \\\"{x:1575,y:493,t:1527873086268};\\\", \\\"{x:1577,y:489,t:1527873086284};\\\", \\\"{x:1580,y:484,t:1527873086301};\\\", \\\"{x:1584,y:477,t:1527873086317};\\\", \\\"{x:1591,y:469,t:1527873086334};\\\", \\\"{x:1598,y:459,t:1527873086351};\\\", \\\"{x:1604,y:451,t:1527873086368};\\\", \\\"{x:1613,y:442,t:1527873086384};\\\", \\\"{x:1617,y:438,t:1527873086401};\\\", \\\"{x:1624,y:433,t:1527873086417};\\\", \\\"{x:1631,y:429,t:1527873086434};\\\", \\\"{x:1632,y:429,t:1527873086452};\\\", \\\"{x:1633,y:429,t:1527873086467};\\\", \\\"{x:1633,y:430,t:1527873086667};\\\", \\\"{x:1633,y:431,t:1527873086675};\\\", \\\"{x:1631,y:434,t:1527873086685};\\\", \\\"{x:1629,y:438,t:1527873086701};\\\", \\\"{x:1628,y:441,t:1527873086718};\\\", \\\"{x:1626,y:445,t:1527873086735};\\\", \\\"{x:1623,y:449,t:1527873086752};\\\", \\\"{x:1619,y:455,t:1527873086769};\\\", \\\"{x:1616,y:459,t:1527873086785};\\\", \\\"{x:1614,y:462,t:1527873086801};\\\", \\\"{x:1611,y:468,t:1527873086818};\\\", \\\"{x:1609,y:474,t:1527873086835};\\\", \\\"{x:1607,y:479,t:1527873086851};\\\", \\\"{x:1605,y:485,t:1527873086868};\\\", \\\"{x:1603,y:497,t:1527873086885};\\\", \\\"{x:1598,y:507,t:1527873086901};\\\", \\\"{x:1594,y:519,t:1527873086918};\\\", \\\"{x:1590,y:527,t:1527873086935};\\\", \\\"{x:1589,y:534,t:1527873086951};\\\", \\\"{x:1585,y:543,t:1527873086968};\\\", \\\"{x:1582,y:550,t:1527873086985};\\\", \\\"{x:1580,y:556,t:1527873087001};\\\", \\\"{x:1576,y:565,t:1527873087018};\\\", \\\"{x:1572,y:573,t:1527873087035};\\\", \\\"{x:1569,y:580,t:1527873087051};\\\", \\\"{x:1567,y:585,t:1527873087068};\\\", \\\"{x:1563,y:590,t:1527873087085};\\\", \\\"{x:1560,y:597,t:1527873087101};\\\", \\\"{x:1556,y:603,t:1527873087118};\\\", \\\"{x:1552,y:611,t:1527873087136};\\\", \\\"{x:1549,y:616,t:1527873087151};\\\", \\\"{x:1547,y:622,t:1527873087168};\\\", \\\"{x:1544,y:628,t:1527873087185};\\\", \\\"{x:1542,y:635,t:1527873087202};\\\", \\\"{x:1541,y:636,t:1527873087218};\\\", \\\"{x:1540,y:638,t:1527873087235};\\\", \\\"{x:1539,y:639,t:1527873087251};\\\", \\\"{x:1538,y:641,t:1527873087268};\\\", \\\"{x:1538,y:642,t:1527873087289};\\\", \\\"{x:1537,y:642,t:1527873087402};\\\", \\\"{x:1536,y:642,t:1527873087547};\\\", \\\"{x:1533,y:644,t:1527873087570};\\\", \\\"{x:1532,y:646,t:1527873087587};\\\", \\\"{x:1529,y:651,t:1527873087602};\\\", \\\"{x:1526,y:654,t:1527873087619};\\\", \\\"{x:1522,y:661,t:1527873087636};\\\", \\\"{x:1515,y:670,t:1527873087653};\\\", \\\"{x:1507,y:682,t:1527873087669};\\\", \\\"{x:1497,y:694,t:1527873087686};\\\", \\\"{x:1491,y:707,t:1527873087702};\\\", \\\"{x:1484,y:723,t:1527873087718};\\\", \\\"{x:1476,y:737,t:1527873087735};\\\", \\\"{x:1469,y:752,t:1527873087753};\\\", \\\"{x:1460,y:767,t:1527873087769};\\\", \\\"{x:1453,y:779,t:1527873087786};\\\", \\\"{x:1444,y:797,t:1527873087802};\\\", \\\"{x:1443,y:806,t:1527873087820};\\\", \\\"{x:1439,y:815,t:1527873087836};\\\", \\\"{x:1436,y:827,t:1527873087852};\\\", \\\"{x:1431,y:839,t:1527873087870};\\\", \\\"{x:1425,y:852,t:1527873087886};\\\", \\\"{x:1417,y:866,t:1527873087903};\\\", \\\"{x:1411,y:876,t:1527873087920};\\\", \\\"{x:1406,y:884,t:1527873087935};\\\", \\\"{x:1400,y:893,t:1527873087953};\\\", \\\"{x:1392,y:904,t:1527873087969};\\\", \\\"{x:1382,y:918,t:1527873087986};\\\", \\\"{x:1367,y:937,t:1527873088002};\\\", \\\"{x:1361,y:943,t:1527873088020};\\\", \\\"{x:1355,y:949,t:1527873088036};\\\", \\\"{x:1352,y:952,t:1527873088053};\\\", \\\"{x:1349,y:956,t:1527873088070};\\\", \\\"{x:1348,y:958,t:1527873088085};\\\", \\\"{x:1347,y:960,t:1527873088102};\\\", \\\"{x:1346,y:960,t:1527873088120};\\\", \\\"{x:1346,y:961,t:1527873088137};\\\", \\\"{x:1345,y:961,t:1527873088211};\\\", \\\"{x:1345,y:960,t:1527873089419};\\\", \\\"{x:1357,y:942,t:1527873089427};\\\", \\\"{x:1385,y:898,t:1527873089438};\\\", \\\"{x:1444,y:799,t:1527873089454};\\\", \\\"{x:1479,y:720,t:1527873089471};\\\", \\\"{x:1510,y:630,t:1527873089488};\\\", \\\"{x:1541,y:543,t:1527873089504};\\\", \\\"{x:1560,y:461,t:1527873089521};\\\", \\\"{x:1586,y:398,t:1527873089539};\\\", \\\"{x:1591,y:388,t:1527873089554};\\\", \\\"{x:1603,y:361,t:1527873089571};\\\", \\\"{x:1608,y:348,t:1527873089588};\\\", \\\"{x:1610,y:342,t:1527873089604};\\\", \\\"{x:1610,y:336,t:1527873089621};\\\", \\\"{x:1609,y:343,t:1527873089723};\\\", \\\"{x:1603,y:357,t:1527873089738};\\\", \\\"{x:1602,y:370,t:1527873089754};\\\", \\\"{x:1602,y:376,t:1527873089770};\\\", \\\"{x:1602,y:382,t:1527873089788};\\\", \\\"{x:1604,y:390,t:1527873089805};\\\", \\\"{x:1607,y:397,t:1527873089820};\\\", \\\"{x:1612,y:403,t:1527873089838};\\\", \\\"{x:1612,y:408,t:1527873089855};\\\", \\\"{x:1613,y:412,t:1527873089870};\\\", \\\"{x:1614,y:416,t:1527873089887};\\\", \\\"{x:1614,y:422,t:1527873089904};\\\", \\\"{x:1614,y:426,t:1527873089920};\\\", \\\"{x:1614,y:428,t:1527873089937};\\\", \\\"{x:1614,y:430,t:1527873089954};\\\", \\\"{x:1614,y:433,t:1527873090259};\\\", \\\"{x:1614,y:435,t:1527873090274};\\\", \\\"{x:1613,y:437,t:1527873090289};\\\", \\\"{x:1610,y:444,t:1527873090305};\\\", \\\"{x:1606,y:449,t:1527873090322};\\\", \\\"{x:1601,y:457,t:1527873090338};\\\", \\\"{x:1593,y:473,t:1527873090355};\\\", \\\"{x:1585,y:485,t:1527873090372};\\\", \\\"{x:1582,y:492,t:1527873090388};\\\", \\\"{x:1577,y:501,t:1527873090405};\\\", \\\"{x:1576,y:508,t:1527873090422};\\\", \\\"{x:1573,y:512,t:1527873090438};\\\", \\\"{x:1571,y:518,t:1527873090455};\\\", \\\"{x:1569,y:523,t:1527873090472};\\\", \\\"{x:1566,y:529,t:1527873090488};\\\", \\\"{x:1563,y:538,t:1527873090505};\\\", \\\"{x:1556,y:552,t:1527873090522};\\\", \\\"{x:1551,y:565,t:1527873090538};\\\", \\\"{x:1545,y:578,t:1527873090555};\\\", \\\"{x:1540,y:590,t:1527873090572};\\\", \\\"{x:1533,y:601,t:1527873090589};\\\", \\\"{x:1528,y:615,t:1527873090605};\\\", \\\"{x:1521,y:630,t:1527873090622};\\\", \\\"{x:1515,y:649,t:1527873090639};\\\", \\\"{x:1506,y:669,t:1527873090655};\\\", \\\"{x:1503,y:683,t:1527873090672};\\\", \\\"{x:1498,y:695,t:1527873090689};\\\", \\\"{x:1494,y:707,t:1527873090705};\\\", \\\"{x:1491,y:716,t:1527873090722};\\\", \\\"{x:1486,y:733,t:1527873090739};\\\", \\\"{x:1480,y:747,t:1527873090755};\\\", \\\"{x:1476,y:759,t:1527873090772};\\\", \\\"{x:1472,y:770,t:1527873090789};\\\", \\\"{x:1467,y:780,t:1527873090805};\\\", \\\"{x:1461,y:787,t:1527873090822};\\\", \\\"{x:1457,y:792,t:1527873090839};\\\", \\\"{x:1451,y:801,t:1527873090855};\\\", \\\"{x:1442,y:813,t:1527873090872};\\\", \\\"{x:1433,y:823,t:1527873090889};\\\", \\\"{x:1425,y:830,t:1527873090906};\\\", \\\"{x:1417,y:837,t:1527873090922};\\\", \\\"{x:1411,y:845,t:1527873090939};\\\", \\\"{x:1403,y:858,t:1527873090955};\\\", \\\"{x:1393,y:872,t:1527873090972};\\\", \\\"{x:1384,y:886,t:1527873090989};\\\", \\\"{x:1376,y:896,t:1527873091005};\\\", \\\"{x:1368,y:907,t:1527873091023};\\\", \\\"{x:1362,y:920,t:1527873091039};\\\", \\\"{x:1355,y:931,t:1527873091056};\\\", \\\"{x:1350,y:940,t:1527873091072};\\\", \\\"{x:1346,y:951,t:1527873091089};\\\", \\\"{x:1339,y:961,t:1527873091106};\\\", \\\"{x:1336,y:968,t:1527873091122};\\\", \\\"{x:1335,y:970,t:1527873091138};\\\", \\\"{x:1334,y:973,t:1527873091155};\\\", \\\"{x:1334,y:974,t:1527873091179};\\\", \\\"{x:1334,y:973,t:1527873091466};\\\", \\\"{x:1334,y:972,t:1527873091483};\\\", \\\"{x:1335,y:970,t:1527873091499};\\\", \\\"{x:1336,y:970,t:1527873091522};\\\", \\\"{x:1337,y:968,t:1527873091539};\\\", \\\"{x:1337,y:967,t:1527873091556};\\\", \\\"{x:1340,y:965,t:1527873091573};\\\", \\\"{x:1343,y:961,t:1527873091589};\\\", \\\"{x:1344,y:960,t:1527873091606};\\\", \\\"{x:1347,y:956,t:1527873091623};\\\", \\\"{x:1349,y:954,t:1527873091639};\\\", \\\"{x:1351,y:950,t:1527873091656};\\\", \\\"{x:1355,y:946,t:1527873091673};\\\", \\\"{x:1360,y:940,t:1527873091689};\\\", \\\"{x:1365,y:933,t:1527873091705};\\\", \\\"{x:1370,y:926,t:1527873091722};\\\", \\\"{x:1373,y:920,t:1527873091738};\\\", \\\"{x:1377,y:915,t:1527873091755};\\\", \\\"{x:1381,y:908,t:1527873091773};\\\", \\\"{x:1384,y:903,t:1527873091788};\\\", \\\"{x:1386,y:899,t:1527873091805};\\\", \\\"{x:1389,y:893,t:1527873091823};\\\", \\\"{x:1390,y:891,t:1527873091840};\\\", \\\"{x:1393,y:886,t:1527873091855};\\\", \\\"{x:1394,y:884,t:1527873091872};\\\", \\\"{x:1396,y:878,t:1527873091889};\\\", \\\"{x:1397,y:875,t:1527873091906};\\\", \\\"{x:1399,y:871,t:1527873091923};\\\", \\\"{x:1402,y:867,t:1527873091939};\\\", \\\"{x:1404,y:862,t:1527873091955};\\\", \\\"{x:1406,y:858,t:1527873091972};\\\", \\\"{x:1408,y:854,t:1527873091989};\\\", \\\"{x:1410,y:849,t:1527873092005};\\\", \\\"{x:1412,y:846,t:1527873092023};\\\", \\\"{x:1415,y:840,t:1527873092040};\\\", \\\"{x:1416,y:837,t:1527873092056};\\\", \\\"{x:1419,y:831,t:1527873092073};\\\", \\\"{x:1421,y:826,t:1527873092090};\\\", \\\"{x:1425,y:819,t:1527873092106};\\\", \\\"{x:1428,y:811,t:1527873092122};\\\", \\\"{x:1430,y:806,t:1527873092139};\\\", \\\"{x:1432,y:800,t:1527873092156};\\\", \\\"{x:1434,y:793,t:1527873092173};\\\", \\\"{x:1436,y:786,t:1527873092190};\\\", \\\"{x:1438,y:780,t:1527873092206};\\\", \\\"{x:1443,y:771,t:1527873092223};\\\", \\\"{x:1447,y:759,t:1527873092239};\\\", \\\"{x:1450,y:749,t:1527873092256};\\\", \\\"{x:1456,y:736,t:1527873092272};\\\", \\\"{x:1460,y:720,t:1527873092289};\\\", \\\"{x:1462,y:714,t:1527873092305};\\\", \\\"{x:1464,y:707,t:1527873092322};\\\", \\\"{x:1466,y:702,t:1527873092339};\\\", \\\"{x:1467,y:697,t:1527873092356};\\\", \\\"{x:1469,y:690,t:1527873092373};\\\", \\\"{x:1472,y:681,t:1527873092389};\\\", \\\"{x:1474,y:673,t:1527873092407};\\\", \\\"{x:1477,y:665,t:1527873092423};\\\", \\\"{x:1480,y:659,t:1527873092440};\\\", \\\"{x:1482,y:654,t:1527873092456};\\\", \\\"{x:1484,y:648,t:1527873092472};\\\", \\\"{x:1489,y:642,t:1527873092490};\\\", \\\"{x:1493,y:636,t:1527873092507};\\\", \\\"{x:1497,y:631,t:1527873092523};\\\", \\\"{x:1499,y:627,t:1527873092539};\\\", \\\"{x:1501,y:624,t:1527873092557};\\\", \\\"{x:1503,y:621,t:1527873092573};\\\", \\\"{x:1504,y:620,t:1527873092590};\\\", \\\"{x:1501,y:620,t:1527873092706};\\\", \\\"{x:1477,y:631,t:1527873092724};\\\", \\\"{x:1432,y:651,t:1527873092740};\\\", \\\"{x:1352,y:674,t:1527873092757};\\\", \\\"{x:1250,y:702,t:1527873092774};\\\", \\\"{x:1139,y:730,t:1527873092790};\\\", \\\"{x:1046,y:754,t:1527873092807};\\\", \\\"{x:960,y:778,t:1527873092825};\\\", \\\"{x:892,y:793,t:1527873092840};\\\", \\\"{x:841,y:800,t:1527873092857};\\\", \\\"{x:795,y:805,t:1527873092874};\\\", \\\"{x:791,y:805,t:1527873092890};\\\", \\\"{x:790,y:805,t:1527873092907};\\\", \\\"{x:789,y:806,t:1527873093179};\\\", \\\"{x:787,y:806,t:1527873093191};\\\", \\\"{x:778,y:808,t:1527873093207};\\\", \\\"{x:760,y:808,t:1527873093224};\\\", \\\"{x:741,y:808,t:1527873093240};\\\", \\\"{x:714,y:808,t:1527873093256};\\\", \\\"{x:669,y:808,t:1527873093274};\\\", \\\"{x:639,y:808,t:1527873093290};\\\", \\\"{x:615,y:803,t:1527873093306};\\\", \\\"{x:593,y:794,t:1527873093324};\\\", \\\"{x:575,y:785,t:1527873093341};\\\", \\\"{x:561,y:779,t:1527873093356};\\\", \\\"{x:548,y:770,t:1527873093374};\\\", \\\"{x:539,y:763,t:1527873093391};\\\", \\\"{x:524,y:752,t:1527873093407};\\\", \\\"{x:505,y:739,t:1527873093424};\\\", \\\"{x:497,y:733,t:1527873093442};\\\", \\\"{x:479,y:718,t:1527873093457};\\\", \\\"{x:471,y:712,t:1527873093473};\\\", \\\"{x:461,y:701,t:1527873093499};\\\", \\\"{x:459,y:690,t:1527873093515};\\\", \\\"{x:459,y:681,t:1527873093532};\\\", \\\"{x:459,y:665,t:1527873093556};\\\", \\\"{x:459,y:663,t:1527873093572};\\\", \\\"{x:461,y:663,t:1527873093650};\\\", \\\"{x:464,y:663,t:1527873093658};\\\", \\\"{x:467,y:663,t:1527873093672};\\\", \\\"{x:482,y:667,t:1527873093690};\\\", \\\"{x:486,y:671,t:1527873093706};\\\", \\\"{x:490,y:680,t:1527873093722};\\\", \\\"{x:492,y:688,t:1527873093739};\\\", \\\"{x:496,y:697,t:1527873093756};\\\", \\\"{x:499,y:706,t:1527873093773};\\\", \\\"{x:501,y:713,t:1527873093790};\\\", \\\"{x:502,y:717,t:1527873093806};\\\", \\\"{x:502,y:718,t:1527873093824};\\\", \\\"{x:502,y:720,t:1527873093839};\\\", \\\"{x:502,y:723,t:1527873093856};\\\", \\\"{x:503,y:725,t:1527873093873};\\\", \\\"{x:503,y:726,t:1527873093889};\\\", \\\"{x:503,y:727,t:1527873093906};\\\", \\\"{x:503,y:726,t:1527873094115};\\\", \\\"{x:503,y:725,t:1527873094124};\\\", \\\"{x:503,y:724,t:1527873094141};\\\", \\\"{x:503,y:722,t:1527873094158};\\\", \\\"{x:503,y:721,t:1527873094174};\\\" ] }, { \\\"rt\\\": 15629, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 301527, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -1-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:718,t:1527873096134};\\\", \\\"{x:506,y:717,t:1527873096145};\\\", \\\"{x:507,y:717,t:1527873096165};\\\", \\\"{x:509,y:716,t:1527873096177};\\\", \\\"{x:510,y:715,t:1527873096192};\\\", \\\"{x:511,y:715,t:1527873096209};\\\", \\\"{x:512,y:714,t:1527873096274};\\\", \\\"{x:512,y:713,t:1527873096321};\\\", \\\"{x:513,y:712,t:1527873096329};\\\", \\\"{x:514,y:711,t:1527873096343};\\\", \\\"{x:515,y:710,t:1527873096359};\\\", \\\"{x:516,y:710,t:1527873096376};\\\", \\\"{x:520,y:710,t:1527873096393};\\\", \\\"{x:531,y:710,t:1527873096409};\\\", \\\"{x:551,y:710,t:1527873096426};\\\", \\\"{x:578,y:710,t:1527873096443};\\\", \\\"{x:607,y:710,t:1527873096459};\\\", \\\"{x:642,y:715,t:1527873096476};\\\", \\\"{x:671,y:717,t:1527873096491};\\\", \\\"{x:709,y:717,t:1527873096508};\\\", \\\"{x:741,y:717,t:1527873096525};\\\", \\\"{x:773,y:717,t:1527873096542};\\\", \\\"{x:801,y:717,t:1527873096559};\\\", \\\"{x:830,y:721,t:1527873096576};\\\", \\\"{x:857,y:722,t:1527873096592};\\\", \\\"{x:878,y:723,t:1527873096608};\\\", \\\"{x:900,y:727,t:1527873096625};\\\", \\\"{x:905,y:728,t:1527873096642};\\\", \\\"{x:906,y:728,t:1527873096658};\\\", \\\"{x:907,y:728,t:1527873096707};\\\", \\\"{x:908,y:729,t:1527873096731};\\\", \\\"{x:910,y:729,t:1527873096743};\\\", \\\"{x:919,y:731,t:1527873096759};\\\", \\\"{x:929,y:732,t:1527873096776};\\\", \\\"{x:943,y:736,t:1527873096793};\\\", \\\"{x:961,y:742,t:1527873096809};\\\", \\\"{x:991,y:752,t:1527873096826};\\\", \\\"{x:1015,y:761,t:1527873096843};\\\", \\\"{x:1022,y:765,t:1527873096859};\\\", \\\"{x:1022,y:766,t:1527873096876};\\\", \\\"{x:1021,y:767,t:1527873097826};\\\", \\\"{x:1020,y:767,t:1527873097850};\\\", \\\"{x:1019,y:768,t:1527873097860};\\\", \\\"{x:1019,y:769,t:1527873097877};\\\", \\\"{x:1017,y:770,t:1527873097894};\\\", \\\"{x:1014,y:773,t:1527873097910};\\\", \\\"{x:1012,y:773,t:1527873097927};\\\", \\\"{x:1010,y:776,t:1527873097944};\\\", \\\"{x:1007,y:778,t:1527873097960};\\\", \\\"{x:1004,y:781,t:1527873097978};\\\", \\\"{x:999,y:788,t:1527873097994};\\\", \\\"{x:995,y:793,t:1527873098010};\\\", \\\"{x:990,y:797,t:1527873098027};\\\", \\\"{x:985,y:801,t:1527873098045};\\\", \\\"{x:982,y:803,t:1527873098062};\\\", \\\"{x:979,y:806,t:1527873098077};\\\", \\\"{x:977,y:808,t:1527873098094};\\\", \\\"{x:975,y:810,t:1527873098111};\\\", \\\"{x:974,y:812,t:1527873098127};\\\", \\\"{x:974,y:815,t:1527873098144};\\\", \\\"{x:972,y:816,t:1527873098161};\\\", \\\"{x:972,y:818,t:1527873098177};\\\", \\\"{x:972,y:821,t:1527873098194};\\\", \\\"{x:972,y:823,t:1527873098211};\\\", \\\"{x:972,y:828,t:1527873098227};\\\", \\\"{x:972,y:832,t:1527873098244};\\\", \\\"{x:972,y:835,t:1527873098261};\\\", \\\"{x:972,y:837,t:1527873098277};\\\", \\\"{x:973,y:841,t:1527873098294};\\\", \\\"{x:977,y:844,t:1527873098311};\\\", \\\"{x:979,y:846,t:1527873098327};\\\", \\\"{x:982,y:850,t:1527873098345};\\\", \\\"{x:988,y:853,t:1527873098361};\\\", \\\"{x:1001,y:857,t:1527873098378};\\\", \\\"{x:1010,y:861,t:1527873098395};\\\", \\\"{x:1020,y:864,t:1527873098411};\\\", \\\"{x:1029,y:866,t:1527873098429};\\\", \\\"{x:1045,y:871,t:1527873098445};\\\", \\\"{x:1063,y:874,t:1527873098461};\\\", \\\"{x:1081,y:877,t:1527873098479};\\\", \\\"{x:1097,y:880,t:1527873098494};\\\", \\\"{x:1116,y:883,t:1527873098511};\\\", \\\"{x:1135,y:887,t:1527873098529};\\\", \\\"{x:1149,y:890,t:1527873098545};\\\", \\\"{x:1164,y:892,t:1527873098561};\\\", \\\"{x:1178,y:893,t:1527873098578};\\\", \\\"{x:1185,y:893,t:1527873098594};\\\", \\\"{x:1189,y:893,t:1527873098611};\\\", \\\"{x:1191,y:893,t:1527873098629};\\\", \\\"{x:1193,y:893,t:1527873098644};\\\", \\\"{x:1194,y:893,t:1527873098662};\\\", \\\"{x:1195,y:893,t:1527873098679};\\\", \\\"{x:1196,y:893,t:1527873098694};\\\", \\\"{x:1200,y:893,t:1527873098711};\\\", \\\"{x:1211,y:893,t:1527873098728};\\\", \\\"{x:1217,y:893,t:1527873098745};\\\", \\\"{x:1226,y:895,t:1527873098761};\\\", \\\"{x:1241,y:897,t:1527873098778};\\\", \\\"{x:1250,y:898,t:1527873098794};\\\", \\\"{x:1255,y:899,t:1527873098811};\\\", \\\"{x:1256,y:900,t:1527873098829};\\\", \\\"{x:1259,y:902,t:1527873098846};\\\", \\\"{x:1259,y:903,t:1527873098866};\\\", \\\"{x:1259,y:905,t:1527873098890};\\\", \\\"{x:1259,y:906,t:1527873098907};\\\", \\\"{x:1259,y:908,t:1527873098954};\\\", \\\"{x:1259,y:910,t:1527873098986};\\\", \\\"{x:1258,y:910,t:1527873099002};\\\", \\\"{x:1257,y:911,t:1527873099011};\\\", \\\"{x:1254,y:913,t:1527873099028};\\\", \\\"{x:1253,y:913,t:1527873099045};\\\", \\\"{x:1251,y:915,t:1527873099062};\\\", \\\"{x:1250,y:916,t:1527873099078};\\\", \\\"{x:1249,y:916,t:1527873099095};\\\", \\\"{x:1248,y:917,t:1527873099111};\\\", \\\"{x:1246,y:918,t:1527873099128};\\\", \\\"{x:1245,y:919,t:1527873099145};\\\", \\\"{x:1243,y:919,t:1527873099161};\\\", \\\"{x:1241,y:921,t:1527873099177};\\\", \\\"{x:1237,y:921,t:1527873099194};\\\", \\\"{x:1234,y:922,t:1527873099212};\\\", \\\"{x:1233,y:922,t:1527873099228};\\\", \\\"{x:1232,y:923,t:1527873099245};\\\", \\\"{x:1230,y:923,t:1527873099261};\\\", \\\"{x:1229,y:925,t:1527873099278};\\\", \\\"{x:1228,y:926,t:1527873099306};\\\", \\\"{x:1226,y:927,t:1527873099314};\\\", \\\"{x:1225,y:928,t:1527873099330};\\\", \\\"{x:1224,y:929,t:1527873099344};\\\", \\\"{x:1223,y:930,t:1527873099361};\\\", \\\"{x:1222,y:930,t:1527873099378};\\\", \\\"{x:1221,y:930,t:1527873099395};\\\", \\\"{x:1220,y:930,t:1527873099459};\\\", \\\"{x:1218,y:929,t:1527873099466};\\\", \\\"{x:1216,y:927,t:1527873099479};\\\", \\\"{x:1211,y:925,t:1527873099496};\\\", \\\"{x:1208,y:922,t:1527873099512};\\\", \\\"{x:1207,y:922,t:1527873099529};\\\", \\\"{x:1206,y:922,t:1527873099545};\\\", \\\"{x:1205,y:921,t:1527873099562};\\\", \\\"{x:1204,y:919,t:1527873099594};\\\", \\\"{x:1203,y:918,t:1527873099612};\\\", \\\"{x:1201,y:917,t:1527873099629};\\\", \\\"{x:1201,y:916,t:1527873099683};\\\", \\\"{x:1201,y:914,t:1527873099695};\\\", \\\"{x:1201,y:909,t:1527873099712};\\\", \\\"{x:1201,y:901,t:1527873099729};\\\", \\\"{x:1203,y:892,t:1527873099746};\\\", \\\"{x:1205,y:885,t:1527873099762};\\\", \\\"{x:1205,y:880,t:1527873099779};\\\", \\\"{x:1205,y:867,t:1527873099796};\\\", \\\"{x:1205,y:853,t:1527873099812};\\\", \\\"{x:1205,y:843,t:1527873099830};\\\", \\\"{x:1205,y:839,t:1527873099846};\\\", \\\"{x:1205,y:838,t:1527873099863};\\\", \\\"{x:1206,y:837,t:1527873100067};\\\", \\\"{x:1207,y:837,t:1527873100079};\\\", \\\"{x:1209,y:837,t:1527873100099};\\\", \\\"{x:1210,y:837,t:1527873100114};\\\", \\\"{x:1212,y:837,t:1527873100129};\\\", \\\"{x:1214,y:837,t:1527873100372};\\\", \\\"{x:1214,y:838,t:1527873100379};\\\", \\\"{x:1214,y:839,t:1527873100410};\\\", \\\"{x:1215,y:840,t:1527873100418};\\\", \\\"{x:1216,y:842,t:1527873100474};\\\", \\\"{x:1217,y:844,t:1527873100490};\\\", \\\"{x:1217,y:845,t:1527873100506};\\\", \\\"{x:1217,y:846,t:1527873100514};\\\", \\\"{x:1219,y:848,t:1527873100538};\\\", \\\"{x:1219,y:850,t:1527873100554};\\\", \\\"{x:1220,y:852,t:1527873100572};\\\", \\\"{x:1221,y:852,t:1527873100580};\\\", \\\"{x:1223,y:857,t:1527873100596};\\\", \\\"{x:1224,y:859,t:1527873100614};\\\", \\\"{x:1226,y:861,t:1527873100631};\\\", \\\"{x:1227,y:863,t:1527873100647};\\\", \\\"{x:1227,y:864,t:1527873100664};\\\", \\\"{x:1228,y:866,t:1527873100681};\\\", \\\"{x:1228,y:867,t:1527873100696};\\\", \\\"{x:1230,y:869,t:1527873100714};\\\", \\\"{x:1233,y:874,t:1527873100730};\\\", \\\"{x:1234,y:876,t:1527873100746};\\\", \\\"{x:1237,y:880,t:1527873100763};\\\", \\\"{x:1238,y:883,t:1527873100780};\\\", \\\"{x:1240,y:885,t:1527873100797};\\\", \\\"{x:1242,y:888,t:1527873100813};\\\", \\\"{x:1245,y:892,t:1527873100831};\\\", \\\"{x:1249,y:897,t:1527873100847};\\\", \\\"{x:1252,y:902,t:1527873100863};\\\", \\\"{x:1253,y:904,t:1527873100881};\\\", \\\"{x:1255,y:907,t:1527873100897};\\\", \\\"{x:1256,y:907,t:1527873100913};\\\", \\\"{x:1257,y:909,t:1527873100930};\\\", \\\"{x:1259,y:912,t:1527873100947};\\\", \\\"{x:1260,y:916,t:1527873100964};\\\", \\\"{x:1262,y:921,t:1527873100980};\\\", \\\"{x:1264,y:926,t:1527873100997};\\\", \\\"{x:1266,y:929,t:1527873101014};\\\", \\\"{x:1268,y:933,t:1527873101030};\\\", \\\"{x:1270,y:938,t:1527873101048};\\\", \\\"{x:1270,y:942,t:1527873101064};\\\", \\\"{x:1271,y:945,t:1527873101081};\\\", \\\"{x:1272,y:950,t:1527873101098};\\\", \\\"{x:1273,y:951,t:1527873101113};\\\", \\\"{x:1275,y:958,t:1527873101131};\\\", \\\"{x:1277,y:960,t:1527873101148};\\\", \\\"{x:1277,y:961,t:1527873101164};\\\", \\\"{x:1278,y:962,t:1527873101922};\\\", \\\"{x:1279,y:962,t:1527873101953};\\\", \\\"{x:1280,y:962,t:1527873101970};\\\", \\\"{x:1281,y:962,t:1527873102859};\\\", \\\"{x:1283,y:961,t:1527873102883};\\\", \\\"{x:1283,y:960,t:1527873102906};\\\", \\\"{x:1284,y:960,t:1527873102963};\\\", \\\"{x:1284,y:958,t:1527873102987};\\\", \\\"{x:1285,y:957,t:1527873103010};\\\", \\\"{x:1286,y:956,t:1527873103026};\\\", \\\"{x:1286,y:955,t:1527873103059};\\\", \\\"{x:1287,y:954,t:1527873103075};\\\", \\\"{x:1287,y:952,t:1527873103107};\\\", \\\"{x:1289,y:950,t:1527873103115};\\\", \\\"{x:1291,y:949,t:1527873103132};\\\", \\\"{x:1291,y:946,t:1527873103149};\\\", \\\"{x:1293,y:944,t:1527873103166};\\\", \\\"{x:1296,y:939,t:1527873103182};\\\", \\\"{x:1298,y:931,t:1527873103200};\\\", \\\"{x:1303,y:920,t:1527873103216};\\\", \\\"{x:1307,y:907,t:1527873103232};\\\", \\\"{x:1313,y:889,t:1527873103249};\\\", \\\"{x:1317,y:876,t:1527873103264};\\\", \\\"{x:1320,y:867,t:1527873103282};\\\", \\\"{x:1321,y:864,t:1527873103299};\\\", \\\"{x:1322,y:863,t:1527873103315};\\\", \\\"{x:1323,y:859,t:1527873103332};\\\", \\\"{x:1325,y:855,t:1527873103349};\\\", \\\"{x:1329,y:845,t:1527873103366};\\\", \\\"{x:1333,y:839,t:1527873103382};\\\", \\\"{x:1338,y:829,t:1527873103399};\\\", \\\"{x:1339,y:825,t:1527873103416};\\\", \\\"{x:1342,y:819,t:1527873103433};\\\", \\\"{x:1344,y:813,t:1527873103449};\\\", \\\"{x:1349,y:803,t:1527873103465};\\\", \\\"{x:1353,y:796,t:1527873103482};\\\", \\\"{x:1355,y:792,t:1527873103500};\\\", \\\"{x:1358,y:789,t:1527873103517};\\\", \\\"{x:1359,y:787,t:1527873103532};\\\", \\\"{x:1361,y:784,t:1527873103549};\\\", \\\"{x:1362,y:780,t:1527873103566};\\\", \\\"{x:1365,y:777,t:1527873103582};\\\", \\\"{x:1367,y:773,t:1527873103599};\\\", \\\"{x:1368,y:771,t:1527873103616};\\\", \\\"{x:1369,y:769,t:1527873103633};\\\", \\\"{x:1371,y:767,t:1527873103650};\\\", \\\"{x:1371,y:765,t:1527873103666};\\\", \\\"{x:1373,y:763,t:1527873103684};\\\", \\\"{x:1374,y:762,t:1527873103769};\\\", \\\"{x:1375,y:761,t:1527873103786};\\\", \\\"{x:1376,y:760,t:1527873103800};\\\", \\\"{x:1376,y:758,t:1527873103816};\\\", \\\"{x:1378,y:757,t:1527873103833};\\\", \\\"{x:1378,y:756,t:1527873103849};\\\", \\\"{x:1380,y:754,t:1527873103865};\\\", \\\"{x:1381,y:753,t:1527873103883};\\\", \\\"{x:1382,y:750,t:1527873103898};\\\", \\\"{x:1384,y:747,t:1527873103916};\\\", \\\"{x:1388,y:742,t:1527873103933};\\\", \\\"{x:1389,y:740,t:1527873103949};\\\", \\\"{x:1390,y:737,t:1527873103966};\\\", \\\"{x:1391,y:736,t:1527873103983};\\\", \\\"{x:1392,y:734,t:1527873103999};\\\", \\\"{x:1393,y:732,t:1527873104017};\\\", \\\"{x:1394,y:731,t:1527873104034};\\\", \\\"{x:1395,y:729,t:1527873104050};\\\", \\\"{x:1398,y:725,t:1527873104067};\\\", \\\"{x:1400,y:722,t:1527873104083};\\\", \\\"{x:1402,y:719,t:1527873104101};\\\", \\\"{x:1404,y:715,t:1527873104117};\\\", \\\"{x:1405,y:714,t:1527873104134};\\\", \\\"{x:1405,y:713,t:1527873104151};\\\", \\\"{x:1404,y:713,t:1527873104241};\\\", \\\"{x:1398,y:716,t:1527873104249};\\\", \\\"{x:1381,y:725,t:1527873104266};\\\", \\\"{x:1354,y:735,t:1527873104283};\\\", \\\"{x:1306,y:748,t:1527873104300};\\\", \\\"{x:1220,y:757,t:1527873104316};\\\", \\\"{x:1117,y:759,t:1527873104333};\\\", \\\"{x:998,y:759,t:1527873104350};\\\", \\\"{x:849,y:741,t:1527873104366};\\\", \\\"{x:710,y:720,t:1527873104383};\\\", \\\"{x:598,y:697,t:1527873104400};\\\", \\\"{x:520,y:671,t:1527873104416};\\\", \\\"{x:480,y:659,t:1527873104433};\\\", \\\"{x:447,y:640,t:1527873104451};\\\", \\\"{x:438,y:635,t:1527873104467};\\\", \\\"{x:435,y:632,t:1527873104483};\\\", \\\"{x:433,y:627,t:1527873104512};\\\", \\\"{x:433,y:625,t:1527873104521};\\\", \\\"{x:431,y:623,t:1527873104531};\\\", \\\"{x:429,y:617,t:1527873104548};\\\", \\\"{x:428,y:615,t:1527873104565};\\\", \\\"{x:427,y:613,t:1527873104581};\\\", \\\"{x:426,y:612,t:1527873104599};\\\", \\\"{x:426,y:609,t:1527873104615};\\\", \\\"{x:426,y:603,t:1527873104632};\\\", \\\"{x:425,y:599,t:1527873104648};\\\", \\\"{x:424,y:595,t:1527873104664};\\\", \\\"{x:415,y:589,t:1527873104682};\\\", \\\"{x:408,y:588,t:1527873104699};\\\", \\\"{x:399,y:586,t:1527873104715};\\\", \\\"{x:389,y:581,t:1527873104733};\\\", \\\"{x:383,y:580,t:1527873104749};\\\", \\\"{x:378,y:578,t:1527873104765};\\\", \\\"{x:379,y:578,t:1527873104978};\\\", \\\"{x:381,y:578,t:1527873104986};\\\", \\\"{x:382,y:579,t:1527873104999};\\\", \\\"{x:385,y:582,t:1527873105018};\\\", \\\"{x:387,y:584,t:1527873105032};\\\", \\\"{x:387,y:587,t:1527873105050};\\\", \\\"{x:387,y:590,t:1527873105067};\\\", \\\"{x:387,y:591,t:1527873105083};\\\", \\\"{x:387,y:593,t:1527873105099};\\\", \\\"{x:387,y:594,t:1527873105116};\\\", \\\"{x:389,y:593,t:1527873105226};\\\", \\\"{x:389,y:587,t:1527873105234};\\\", \\\"{x:389,y:582,t:1527873105250};\\\", \\\"{x:389,y:568,t:1527873105267};\\\", \\\"{x:389,y:564,t:1527873105283};\\\", \\\"{x:389,y:562,t:1527873105299};\\\", \\\"{x:389,y:561,t:1527873105315};\\\", \\\"{x:389,y:560,t:1527873105353};\\\", \\\"{x:389,y:559,t:1527873105393};\\\", \\\"{x:390,y:559,t:1527873105930};\\\", \\\"{x:395,y:563,t:1527873105938};\\\", \\\"{x:403,y:569,t:1527873105951};\\\", \\\"{x:420,y:579,t:1527873105968};\\\", \\\"{x:438,y:589,t:1527873105983};\\\", \\\"{x:463,y:605,t:1527873106000};\\\", \\\"{x:492,y:620,t:1527873106016};\\\", \\\"{x:544,y:647,t:1527873106033};\\\", \\\"{x:580,y:670,t:1527873106050};\\\", \\\"{x:618,y:692,t:1527873106067};\\\", \\\"{x:648,y:711,t:1527873106083};\\\", \\\"{x:673,y:731,t:1527873106100};\\\", \\\"{x:699,y:749,t:1527873106116};\\\", \\\"{x:718,y:765,t:1527873106132};\\\", \\\"{x:733,y:779,t:1527873106150};\\\", \\\"{x:741,y:789,t:1527873106166};\\\", \\\"{x:748,y:798,t:1527873106182};\\\", \\\"{x:752,y:803,t:1527873106200};\\\", \\\"{x:754,y:805,t:1527873106216};\\\", \\\"{x:756,y:808,t:1527873106233};\\\", \\\"{x:758,y:811,t:1527873106442};\\\", \\\"{x:761,y:812,t:1527873106450};\\\", \\\"{x:775,y:817,t:1527873106466};\\\", \\\"{x:791,y:824,t:1527873106484};\\\", \\\"{x:811,y:833,t:1527873106500};\\\", \\\"{x:831,y:840,t:1527873106517};\\\", \\\"{x:854,y:851,t:1527873106534};\\\", \\\"{x:870,y:859,t:1527873106549};\\\", \\\"{x:896,y:868,t:1527873106567};\\\", \\\"{x:919,y:877,t:1527873106584};\\\", \\\"{x:943,y:883,t:1527873106599};\\\", \\\"{x:966,y:887,t:1527873106616};\\\", \\\"{x:988,y:890,t:1527873106633};\\\", \\\"{x:1009,y:894,t:1527873106649};\\\", \\\"{x:1037,y:898,t:1527873106666};\\\", \\\"{x:1050,y:900,t:1527873106682};\\\", \\\"{x:1059,y:901,t:1527873106699};\\\", \\\"{x:1068,y:904,t:1527873106716};\\\", \\\"{x:1071,y:905,t:1527873106733};\\\", \\\"{x:1074,y:905,t:1527873106749};\\\", \\\"{x:1082,y:907,t:1527873106766};\\\", \\\"{x:1092,y:910,t:1527873106783};\\\", \\\"{x:1102,y:913,t:1527873106799};\\\", \\\"{x:1108,y:914,t:1527873106816};\\\", \\\"{x:1114,y:917,t:1527873106833};\\\", \\\"{x:1116,y:917,t:1527873106849};\\\", \\\"{x:1118,y:918,t:1527873106866};\\\", \\\"{x:1120,y:920,t:1527873106883};\\\", \\\"{x:1121,y:921,t:1527873106899};\\\", \\\"{x:1122,y:922,t:1527873106916};\\\", \\\"{x:1122,y:925,t:1527873106932};\\\", \\\"{x:1124,y:929,t:1527873106949};\\\", \\\"{x:1125,y:933,t:1527873106967};\\\", \\\"{x:1126,y:939,t:1527873106982};\\\", \\\"{x:1128,y:943,t:1527873106999};\\\", \\\"{x:1128,y:946,t:1527873107016};\\\", \\\"{x:1128,y:950,t:1527873107032};\\\", \\\"{x:1128,y:952,t:1527873107049};\\\", \\\"{x:1129,y:956,t:1527873107066};\\\", \\\"{x:1131,y:956,t:1527873107227};\\\", \\\"{x:1134,y:956,t:1527873107235};\\\", \\\"{x:1138,y:954,t:1527873107249};\\\", \\\"{x:1154,y:940,t:1527873107266};\\\", \\\"{x:1168,y:930,t:1527873107283};\\\", \\\"{x:1179,y:920,t:1527873107300};\\\", \\\"{x:1189,y:907,t:1527873107315};\\\", \\\"{x:1199,y:891,t:1527873107332};\\\", \\\"{x:1207,y:879,t:1527873107349};\\\", \\\"{x:1211,y:872,t:1527873107365};\\\", \\\"{x:1213,y:869,t:1527873107382};\\\", \\\"{x:1214,y:869,t:1527873107398};\\\", \\\"{x:1214,y:872,t:1527873107458};\\\", \\\"{x:1216,y:877,t:1527873107465};\\\", \\\"{x:1220,y:888,t:1527873107482};\\\", \\\"{x:1226,y:902,t:1527873107499};\\\", \\\"{x:1232,y:913,t:1527873107515};\\\", \\\"{x:1240,y:927,t:1527873107532};\\\", \\\"{x:1251,y:941,t:1527873107550};\\\", \\\"{x:1266,y:955,t:1527873107566};\\\", \\\"{x:1281,y:970,t:1527873107582};\\\", \\\"{x:1293,y:980,t:1527873107600};\\\", \\\"{x:1303,y:988,t:1527873107615};\\\", \\\"{x:1309,y:992,t:1527873107632};\\\", \\\"{x:1310,y:993,t:1527873107650};\\\", \\\"{x:1310,y:992,t:1527873107930};\\\", \\\"{x:1310,y:990,t:1527873107938};\\\", \\\"{x:1310,y:988,t:1527873107948};\\\", \\\"{x:1310,y:984,t:1527873107965};\\\", \\\"{x:1308,y:978,t:1527873107982};\\\", \\\"{x:1307,y:973,t:1527873107999};\\\", \\\"{x:1307,y:967,t:1527873108016};\\\", \\\"{x:1307,y:961,t:1527873108033};\\\", \\\"{x:1307,y:954,t:1527873108049};\\\", \\\"{x:1309,y:935,t:1527873108066};\\\", \\\"{x:1316,y:919,t:1527873108082};\\\", \\\"{x:1326,y:902,t:1527873108098};\\\", \\\"{x:1340,y:883,t:1527873108116};\\\", \\\"{x:1351,y:863,t:1527873108133};\\\", \\\"{x:1364,y:844,t:1527873108148};\\\", \\\"{x:1371,y:831,t:1527873108165};\\\", \\\"{x:1381,y:819,t:1527873108182};\\\", \\\"{x:1386,y:810,t:1527873108199};\\\", \\\"{x:1391,y:804,t:1527873108215};\\\", \\\"{x:1394,y:799,t:1527873108232};\\\", \\\"{x:1394,y:797,t:1527873108249};\\\", \\\"{x:1394,y:796,t:1527873108266};\\\", \\\"{x:1395,y:795,t:1527873108315};\\\", \\\"{x:1396,y:795,t:1527873108332};\\\", \\\"{x:1396,y:794,t:1527873108627};\\\", \\\"{x:1396,y:793,t:1527873108642};\\\", \\\"{x:1395,y:791,t:1527873108658};\\\", \\\"{x:1395,y:790,t:1527873108714};\\\", \\\"{x:1395,y:789,t:1527873108739};\\\", \\\"{x:1395,y:788,t:1527873108754};\\\", \\\"{x:1394,y:787,t:1527873108786};\\\", \\\"{x:1393,y:787,t:1527873108811};\\\", \\\"{x:1393,y:786,t:1527873108826};\\\", \\\"{x:1393,y:785,t:1527873108851};\\\", \\\"{x:1391,y:785,t:1527873109358};\\\", \\\"{x:1388,y:786,t:1527873109368};\\\", \\\"{x:1377,y:788,t:1527873109385};\\\", \\\"{x:1352,y:791,t:1527873109401};\\\", \\\"{x:1309,y:793,t:1527873109419};\\\", \\\"{x:1253,y:793,t:1527873109435};\\\", \\\"{x:1191,y:793,t:1527873109452};\\\", \\\"{x:1125,y:793,t:1527873109469};\\\", \\\"{x:1042,y:789,t:1527873109486};\\\", \\\"{x:1007,y:782,t:1527873109502};\\\", \\\"{x:978,y:777,t:1527873109518};\\\", \\\"{x:952,y:771,t:1527873109536};\\\", \\\"{x:928,y:764,t:1527873109552};\\\", \\\"{x:903,y:760,t:1527873109569};\\\", \\\"{x:869,y:753,t:1527873109585};\\\", \\\"{x:836,y:747,t:1527873109602};\\\", \\\"{x:808,y:745,t:1527873109618};\\\", \\\"{x:784,y:741,t:1527873109635};\\\", \\\"{x:770,y:739,t:1527873109651};\\\", \\\"{x:767,y:738,t:1527873109668};\\\", \\\"{x:766,y:738,t:1527873109685};\\\", \\\"{x:762,y:738,t:1527873109878};\\\", \\\"{x:760,y:738,t:1527873109886};\\\", \\\"{x:755,y:738,t:1527873109902};\\\", \\\"{x:749,y:738,t:1527873109918};\\\", \\\"{x:747,y:738,t:1527873109935};\\\", \\\"{x:746,y:738,t:1527873109951};\\\", \\\"{x:744,y:738,t:1527873109968};\\\", \\\"{x:742,y:738,t:1527873109984};\\\", \\\"{x:740,y:738,t:1527873110001};\\\", \\\"{x:738,y:738,t:1527873110017};\\\", \\\"{x:731,y:738,t:1527873110035};\\\", \\\"{x:725,y:738,t:1527873110052};\\\", \\\"{x:719,y:738,t:1527873110067};\\\", \\\"{x:713,y:739,t:1527873110085};\\\", \\\"{x:704,y:742,t:1527873110102};\\\", \\\"{x:692,y:746,t:1527873110118};\\\", \\\"{x:681,y:748,t:1527873110134};\\\", \\\"{x:665,y:753,t:1527873110151};\\\", \\\"{x:651,y:757,t:1527873110167};\\\", \\\"{x:639,y:761,t:1527873110184};\\\", \\\"{x:633,y:762,t:1527873110201};\\\", \\\"{x:629,y:763,t:1527873110217};\\\", \\\"{x:625,y:765,t:1527873110234};\\\", \\\"{x:621,y:766,t:1527873110252};\\\", \\\"{x:614,y:769,t:1527873110268};\\\", \\\"{x:605,y:773,t:1527873110285};\\\", \\\"{x:594,y:776,t:1527873110302};\\\", \\\"{x:587,y:778,t:1527873110318};\\\", \\\"{x:581,y:780,t:1527873110335};\\\", \\\"{x:571,y:783,t:1527873110352};\\\", \\\"{x:564,y:783,t:1527873110367};\\\", \\\"{x:557,y:783,t:1527873110384};\\\", \\\"{x:552,y:784,t:1527873110402};\\\", \\\"{x:544,y:784,t:1527873110418};\\\", \\\"{x:534,y:784,t:1527873110434};\\\", \\\"{x:522,y:781,t:1527873110451};\\\", \\\"{x:513,y:776,t:1527873110468};\\\", \\\"{x:505,y:773,t:1527873110484};\\\", \\\"{x:500,y:771,t:1527873110501};\\\", \\\"{x:493,y:769,t:1527873110518};\\\", \\\"{x:491,y:768,t:1527873110534};\\\", \\\"{x:488,y:767,t:1527873110550};\\\", \\\"{x:487,y:766,t:1527873110567};\\\", \\\"{x:487,y:765,t:1527873110585};\\\", \\\"{x:485,y:763,t:1527873110601};\\\", \\\"{x:485,y:757,t:1527873110617};\\\", \\\"{x:485,y:750,t:1527873110635};\\\", \\\"{x:486,y:744,t:1527873110650};\\\", \\\"{x:488,y:737,t:1527873110667};\\\", \\\"{x:489,y:733,t:1527873110685};\\\", \\\"{x:490,y:730,t:1527873110700};\\\", \\\"{x:490,y:728,t:1527873110717};\\\", \\\"{x:493,y:725,t:1527873110741};\\\", \\\"{x:493,y:724,t:1527873110758};\\\", \\\"{x:493,y:723,t:1527873110877};\\\", \\\"{x:494,y:722,t:1527873110891};\\\", \\\"{x:494,y:720,t:1527873110908};\\\", \\\"{x:497,y:715,t:1527873110925};\\\", \\\"{x:497,y:713,t:1527873110942};\\\", \\\"{x:499,y:709,t:1527873110958};\\\", \\\"{x:499,y:708,t:1527873110976};\\\", \\\"{x:499,y:707,t:1527873111094};\\\" ] }, { \\\"rt\\\": 10835, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 313596, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:705,t:1527873113157};\\\", \\\"{x:503,y:704,t:1527873113169};\\\", \\\"{x:505,y:704,t:1527873113175};\\\", \\\"{x:514,y:703,t:1527873113192};\\\", \\\"{x:526,y:702,t:1527873113208};\\\", \\\"{x:544,y:702,t:1527873113225};\\\", \\\"{x:567,y:702,t:1527873113242};\\\", \\\"{x:589,y:702,t:1527873113258};\\\", \\\"{x:616,y:702,t:1527873113276};\\\", \\\"{x:658,y:710,t:1527873113293};\\\", \\\"{x:691,y:719,t:1527873113310};\\\", \\\"{x:725,y:731,t:1527873113326};\\\", \\\"{x:754,y:741,t:1527873113344};\\\", \\\"{x:781,y:748,t:1527873113360};\\\", \\\"{x:803,y:759,t:1527873113377};\\\", \\\"{x:826,y:768,t:1527873113393};\\\", \\\"{x:864,y:780,t:1527873113411};\\\", \\\"{x:907,y:795,t:1527873113426};\\\", \\\"{x:932,y:801,t:1527873113443};\\\", \\\"{x:933,y:803,t:1527873114631};\\\", \\\"{x:936,y:803,t:1527873114654};\\\", \\\"{x:939,y:804,t:1527873114662};\\\", \\\"{x:948,y:805,t:1527873114679};\\\", \\\"{x:956,y:805,t:1527873114695};\\\", \\\"{x:967,y:805,t:1527873114712};\\\", \\\"{x:980,y:807,t:1527873114728};\\\", \\\"{x:997,y:809,t:1527873114746};\\\", \\\"{x:1014,y:813,t:1527873114762};\\\", \\\"{x:1034,y:815,t:1527873114779};\\\", \\\"{x:1058,y:820,t:1527873114796};\\\", \\\"{x:1082,y:826,t:1527873114812};\\\", \\\"{x:1111,y:831,t:1527873114829};\\\", \\\"{x:1158,y:838,t:1527873114846};\\\", \\\"{x:1188,y:845,t:1527873114862};\\\", \\\"{x:1219,y:851,t:1527873114879};\\\", \\\"{x:1255,y:861,t:1527873114896};\\\", \\\"{x:1291,y:869,t:1527873114912};\\\", \\\"{x:1329,y:877,t:1527873114929};\\\", \\\"{x:1359,y:882,t:1527873114946};\\\", \\\"{x:1396,y:887,t:1527873114962};\\\", \\\"{x:1424,y:893,t:1527873114979};\\\", \\\"{x:1450,y:894,t:1527873114996};\\\", \\\"{x:1470,y:896,t:1527873115013};\\\", \\\"{x:1484,y:898,t:1527873115029};\\\", \\\"{x:1498,y:900,t:1527873115046};\\\", \\\"{x:1503,y:900,t:1527873115063};\\\", \\\"{x:1505,y:900,t:1527873115079};\\\", \\\"{x:1506,y:900,t:1527873115110};\\\", \\\"{x:1506,y:901,t:1527873115118};\\\", \\\"{x:1507,y:901,t:1527873115134};\\\", \\\"{x:1507,y:902,t:1527873115150};\\\", \\\"{x:1507,y:903,t:1527873115163};\\\", \\\"{x:1507,y:904,t:1527873115182};\\\", \\\"{x:1507,y:906,t:1527873115197};\\\", \\\"{x:1508,y:908,t:1527873115213};\\\", \\\"{x:1508,y:909,t:1527873115228};\\\", \\\"{x:1508,y:912,t:1527873115245};\\\", \\\"{x:1508,y:915,t:1527873115262};\\\", \\\"{x:1508,y:917,t:1527873115279};\\\", \\\"{x:1506,y:920,t:1527873115295};\\\", \\\"{x:1506,y:921,t:1527873115313};\\\", \\\"{x:1505,y:923,t:1527873115329};\\\", \\\"{x:1503,y:923,t:1527873115346};\\\", \\\"{x:1503,y:924,t:1527873115363};\\\", \\\"{x:1503,y:925,t:1527873115581};\\\", \\\"{x:1505,y:926,t:1527873115596};\\\", \\\"{x:1508,y:930,t:1527873115613};\\\", \\\"{x:1518,y:937,t:1527873115629};\\\", \\\"{x:1529,y:944,t:1527873115647};\\\", \\\"{x:1534,y:948,t:1527873115662};\\\", \\\"{x:1540,y:952,t:1527873115680};\\\", \\\"{x:1545,y:955,t:1527873115697};\\\", \\\"{x:1549,y:958,t:1527873115713};\\\", \\\"{x:1551,y:960,t:1527873115730};\\\", \\\"{x:1552,y:962,t:1527873115746};\\\", \\\"{x:1553,y:962,t:1527873115763};\\\", \\\"{x:1555,y:962,t:1527873116366};\\\", \\\"{x:1557,y:962,t:1527873116382};\\\", \\\"{x:1563,y:962,t:1527873116398};\\\", \\\"{x:1570,y:962,t:1527873116414};\\\", \\\"{x:1574,y:962,t:1527873116432};\\\", \\\"{x:1577,y:961,t:1527873116448};\\\", \\\"{x:1580,y:959,t:1527873116464};\\\", \\\"{x:1581,y:959,t:1527873116481};\\\", \\\"{x:1583,y:957,t:1527873116498};\\\", \\\"{x:1584,y:957,t:1527873116514};\\\", \\\"{x:1586,y:956,t:1527873116532};\\\", \\\"{x:1588,y:956,t:1527873116548};\\\", \\\"{x:1589,y:955,t:1527873116563};\\\", \\\"{x:1591,y:954,t:1527873116581};\\\", \\\"{x:1594,y:954,t:1527873116597};\\\", \\\"{x:1595,y:954,t:1527873116646};\\\", \\\"{x:1597,y:953,t:1527873116661};\\\", \\\"{x:1598,y:953,t:1527873116678};\\\", \\\"{x:1600,y:953,t:1527873116686};\\\", \\\"{x:1601,y:953,t:1527873116702};\\\", \\\"{x:1602,y:952,t:1527873116715};\\\", \\\"{x:1603,y:952,t:1527873116731};\\\", \\\"{x:1604,y:952,t:1527873116748};\\\", \\\"{x:1605,y:951,t:1527873116774};\\\", \\\"{x:1605,y:949,t:1527873116815};\\\", \\\"{x:1605,y:944,t:1527873116831};\\\", \\\"{x:1602,y:938,t:1527873116848};\\\", \\\"{x:1595,y:930,t:1527873116865};\\\", \\\"{x:1587,y:923,t:1527873116881};\\\", \\\"{x:1581,y:916,t:1527873116898};\\\", \\\"{x:1572,y:909,t:1527873116915};\\\", \\\"{x:1569,y:906,t:1527873116931};\\\", \\\"{x:1567,y:903,t:1527873116948};\\\", \\\"{x:1567,y:899,t:1527873116965};\\\", \\\"{x:1566,y:894,t:1527873116982};\\\", \\\"{x:1564,y:890,t:1527873116998};\\\", \\\"{x:1563,y:883,t:1527873117016};\\\", \\\"{x:1560,y:878,t:1527873117032};\\\", \\\"{x:1560,y:872,t:1527873117048};\\\", \\\"{x:1560,y:866,t:1527873117065};\\\", \\\"{x:1558,y:860,t:1527873117082};\\\", \\\"{x:1556,y:854,t:1527873117098};\\\", \\\"{x:1556,y:848,t:1527873117115};\\\", \\\"{x:1555,y:843,t:1527873117132};\\\", \\\"{x:1552,y:834,t:1527873117148};\\\", \\\"{x:1551,y:825,t:1527873117165};\\\", \\\"{x:1546,y:811,t:1527873117182};\\\", \\\"{x:1543,y:803,t:1527873117198};\\\", \\\"{x:1537,y:787,t:1527873117215};\\\", \\\"{x:1532,y:778,t:1527873117232};\\\", \\\"{x:1530,y:772,t:1527873117249};\\\", \\\"{x:1528,y:765,t:1527873117265};\\\", \\\"{x:1524,y:755,t:1527873117282};\\\", \\\"{x:1520,y:745,t:1527873117299};\\\", \\\"{x:1514,y:736,t:1527873117315};\\\", \\\"{x:1509,y:727,t:1527873117332};\\\", \\\"{x:1504,y:719,t:1527873117349};\\\", \\\"{x:1498,y:706,t:1527873117365};\\\", \\\"{x:1487,y:688,t:1527873117382};\\\", \\\"{x:1480,y:678,t:1527873117399};\\\", \\\"{x:1475,y:670,t:1527873117415};\\\", \\\"{x:1472,y:664,t:1527873117432};\\\", \\\"{x:1468,y:659,t:1527873117449};\\\", \\\"{x:1464,y:653,t:1527873117466};\\\", \\\"{x:1461,y:646,t:1527873117482};\\\", \\\"{x:1458,y:641,t:1527873117499};\\\", \\\"{x:1456,y:637,t:1527873117516};\\\", \\\"{x:1452,y:629,t:1527873117532};\\\", \\\"{x:1449,y:624,t:1527873117549};\\\", \\\"{x:1444,y:617,t:1527873117566};\\\", \\\"{x:1442,y:612,t:1527873117582};\\\", \\\"{x:1440,y:606,t:1527873117599};\\\", \\\"{x:1438,y:600,t:1527873117616};\\\", \\\"{x:1437,y:595,t:1527873117632};\\\", \\\"{x:1436,y:589,t:1527873117649};\\\", \\\"{x:1433,y:585,t:1527873117666};\\\", \\\"{x:1430,y:581,t:1527873117682};\\\", \\\"{x:1428,y:578,t:1527873117699};\\\", \\\"{x:1426,y:575,t:1527873117717};\\\", \\\"{x:1422,y:572,t:1527873117732};\\\", \\\"{x:1418,y:567,t:1527873117752};\\\", \\\"{x:1412,y:563,t:1527873117764};\\\", \\\"{x:1410,y:562,t:1527873117781};\\\", \\\"{x:1408,y:561,t:1527873117805};\\\", \\\"{x:1407,y:560,t:1527873117829};\\\", \\\"{x:1406,y:560,t:1527873117853};\\\", \\\"{x:1405,y:559,t:1527873118134};\\\", \\\"{x:1405,y:558,t:1527873118149};\\\", \\\"{x:1402,y:550,t:1527873118166};\\\", \\\"{x:1392,y:538,t:1527873118183};\\\", \\\"{x:1384,y:527,t:1527873118200};\\\", \\\"{x:1374,y:512,t:1527873118216};\\\", \\\"{x:1363,y:497,t:1527873118233};\\\", \\\"{x:1347,y:481,t:1527873118250};\\\", \\\"{x:1332,y:467,t:1527873118266};\\\", \\\"{x:1309,y:457,t:1527873118283};\\\", \\\"{x:1286,y:449,t:1527873118300};\\\", \\\"{x:1247,y:444,t:1527873118316};\\\", \\\"{x:1191,y:444,t:1527873118333};\\\", \\\"{x:1013,y:442,t:1527873118350};\\\", \\\"{x:854,y:454,t:1527873118367};\\\", \\\"{x:675,y:477,t:1527873118383};\\\", \\\"{x:511,y:505,t:1527873118400};\\\", \\\"{x:390,y:535,t:1527873118418};\\\", \\\"{x:307,y:567,t:1527873118433};\\\", \\\"{x:257,y:592,t:1527873118449};\\\", \\\"{x:239,y:610,t:1527873118480};\\\", \\\"{x:239,y:613,t:1527873118497};\\\", \\\"{x:242,y:617,t:1527873118514};\\\", \\\"{x:248,y:622,t:1527873118531};\\\", \\\"{x:253,y:625,t:1527873118547};\\\", \\\"{x:262,y:630,t:1527873118564};\\\", \\\"{x:271,y:630,t:1527873118581};\\\", \\\"{x:297,y:633,t:1527873118598};\\\", \\\"{x:325,y:635,t:1527873118615};\\\", \\\"{x:353,y:635,t:1527873118630};\\\", \\\"{x:381,y:636,t:1527873118648};\\\", \\\"{x:412,y:636,t:1527873118664};\\\", \\\"{x:434,y:636,t:1527873118681};\\\", \\\"{x:448,y:636,t:1527873118697};\\\", \\\"{x:451,y:636,t:1527873118714};\\\", \\\"{x:454,y:635,t:1527873118730};\\\", \\\"{x:454,y:633,t:1527873118748};\\\", \\\"{x:454,y:629,t:1527873118764};\\\", \\\"{x:455,y:624,t:1527873118781};\\\", \\\"{x:462,y:617,t:1527873118799};\\\", \\\"{x:468,y:613,t:1527873118815};\\\", \\\"{x:481,y:608,t:1527873118831};\\\", \\\"{x:505,y:600,t:1527873118848};\\\", \\\"{x:538,y:590,t:1527873118865};\\\", \\\"{x:570,y:578,t:1527873118882};\\\", \\\"{x:594,y:570,t:1527873118898};\\\", \\\"{x:612,y:566,t:1527873118914};\\\", \\\"{x:623,y:562,t:1527873118930};\\\", \\\"{x:624,y:561,t:1527873118947};\\\", \\\"{x:626,y:561,t:1527873119014};\\\", \\\"{x:625,y:561,t:1527873119302};\\\", \\\"{x:623,y:561,t:1527873119317};\\\", \\\"{x:622,y:561,t:1527873119330};\\\", \\\"{x:620,y:560,t:1527873119347};\\\", \\\"{x:619,y:559,t:1527873119364};\\\", \\\"{x:617,y:559,t:1527873119830};\\\", \\\"{x:615,y:561,t:1527873119847};\\\", \\\"{x:612,y:563,t:1527873119864};\\\", \\\"{x:608,y:568,t:1527873119881};\\\", \\\"{x:601,y:576,t:1527873119898};\\\", \\\"{x:592,y:590,t:1527873119915};\\\", \\\"{x:577,y:608,t:1527873119931};\\\", \\\"{x:562,y:622,t:1527873119953};\\\", \\\"{x:539,y:642,t:1527873119964};\\\", \\\"{x:529,y:651,t:1527873119982};\\\", \\\"{x:523,y:658,t:1527873119998};\\\", \\\"{x:515,y:669,t:1527873120015};\\\", \\\"{x:508,y:676,t:1527873120031};\\\", \\\"{x:503,y:682,t:1527873120048};\\\", \\\"{x:499,y:687,t:1527873120066};\\\", \\\"{x:497,y:690,t:1527873120081};\\\", \\\"{x:497,y:692,t:1527873120098};\\\", \\\"{x:496,y:692,t:1527873120115};\\\", \\\"{x:495,y:693,t:1527873120132};\\\", \\\"{x:494,y:696,t:1527873120149};\\\", \\\"{x:491,y:705,t:1527873120166};\\\", \\\"{x:490,y:709,t:1527873120182};\\\", \\\"{x:490,y:710,t:1527873120199};\\\", \\\"{x:490,y:712,t:1527873120269};\\\", \\\"{x:491,y:712,t:1527873120293};\\\", \\\"{x:492,y:712,t:1527873120317};\\\", \\\"{x:492,y:707,t:1527873124142};\\\", \\\"{x:492,y:697,t:1527873124152};\\\", \\\"{x:492,y:673,t:1527873124168};\\\", \\\"{x:489,y:649,t:1527873124186};\\\", \\\"{x:489,y:625,t:1527873124202};\\\", \\\"{x:489,y:610,t:1527873124219};\\\", \\\"{x:490,y:598,t:1527873124236};\\\", \\\"{x:502,y:569,t:1527873124268};\\\", \\\"{x:508,y:559,t:1527873124286};\\\", \\\"{x:510,y:555,t:1527873124302};\\\" ] }, { \\\"rt\\\": 32186, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 346987, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -I -O -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:555,t:1527873126111};\\\", \\\"{x:513,y:554,t:1527873126221};\\\", \\\"{x:513,y:552,t:1527873126252};\\\", \\\"{x:513,y:550,t:1527873126294};\\\", \\\"{x:513,y:549,t:1527873126349};\\\", \\\"{x:513,y:547,t:1527873126373};\\\", \\\"{x:515,y:546,t:1527873126386};\\\", \\\"{x:516,y:544,t:1527873126404};\\\", \\\"{x:517,y:544,t:1527873126421};\\\", \\\"{x:518,y:543,t:1527873126437};\\\", \\\"{x:519,y:542,t:1527873126454};\\\", \\\"{x:521,y:542,t:1527873126470};\\\", \\\"{x:522,y:542,t:1527873126487};\\\", \\\"{x:524,y:540,t:1527873126504};\\\", \\\"{x:525,y:538,t:1527873126521};\\\", \\\"{x:527,y:536,t:1527873126537};\\\", \\\"{x:531,y:533,t:1527873126553};\\\", \\\"{x:533,y:532,t:1527873126570};\\\", \\\"{x:534,y:531,t:1527873126588};\\\", \\\"{x:537,y:529,t:1527873126604};\\\", \\\"{x:539,y:528,t:1527873126621};\\\", \\\"{x:540,y:528,t:1527873126645};\\\", \\\"{x:542,y:527,t:1527873126654};\\\", \\\"{x:543,y:526,t:1527873126694};\\\", \\\"{x:544,y:526,t:1527873126709};\\\", \\\"{x:545,y:526,t:1527873126721};\\\", \\\"{x:547,y:525,t:1527873126741};\\\", \\\"{x:549,y:523,t:1527873126754};\\\", \\\"{x:551,y:523,t:1527873126773};\\\", \\\"{x:551,y:522,t:1527873126789};\\\", \\\"{x:553,y:522,t:1527873126805};\\\", \\\"{x:554,y:521,t:1527873126821};\\\", \\\"{x:555,y:521,t:1527873126854};\\\", \\\"{x:555,y:520,t:1527873126893};\\\", \\\"{x:557,y:519,t:1527873126925};\\\", \\\"{x:558,y:518,t:1527873126949};\\\", \\\"{x:560,y:518,t:1527873126965};\\\", \\\"{x:561,y:518,t:1527873126989};\\\", \\\"{x:563,y:517,t:1527873127003};\\\", \\\"{x:566,y:516,t:1527873127021};\\\", \\\"{x:568,y:516,t:1527873127038};\\\", \\\"{x:571,y:516,t:1527873127055};\\\", \\\"{x:573,y:516,t:1527873127071};\\\", \\\"{x:575,y:516,t:1527873127088};\\\", \\\"{x:577,y:516,t:1527873127106};\\\", \\\"{x:580,y:516,t:1527873127121};\\\", \\\"{x:584,y:515,t:1527873127139};\\\", \\\"{x:586,y:515,t:1527873127155};\\\", \\\"{x:590,y:515,t:1527873127171};\\\", \\\"{x:594,y:513,t:1527873127188};\\\", \\\"{x:598,y:513,t:1527873127206};\\\", \\\"{x:600,y:513,t:1527873127221};\\\", \\\"{x:605,y:512,t:1527873127238};\\\", \\\"{x:609,y:512,t:1527873127255};\\\", \\\"{x:612,y:512,t:1527873127271};\\\", \\\"{x:615,y:512,t:1527873127288};\\\", \\\"{x:619,y:512,t:1527873127305};\\\", \\\"{x:624,y:511,t:1527873127321};\\\", \\\"{x:625,y:511,t:1527873127338};\\\", \\\"{x:627,y:511,t:1527873127355};\\\", \\\"{x:628,y:510,t:1527873127371};\\\", \\\"{x:629,y:510,t:1527873127405};\\\", \\\"{x:630,y:509,t:1527873127422};\\\", \\\"{x:631,y:508,t:1527873127445};\\\", \\\"{x:631,y:507,t:1527873127455};\\\", \\\"{x:632,y:506,t:1527873127472};\\\", \\\"{x:633,y:506,t:1527873127501};\\\", \\\"{x:634,y:505,t:1527873127526};\\\", \\\"{x:635,y:504,t:1527873127566};\\\", \\\"{x:636,y:503,t:1527873127590};\\\", \\\"{x:637,y:502,t:1527873127613};\\\", \\\"{x:638,y:501,t:1527873127654};\\\", \\\"{x:639,y:501,t:1527873127685};\\\", \\\"{x:639,y:500,t:1527873127709};\\\", \\\"{x:640,y:499,t:1527873127723};\\\", \\\"{x:641,y:498,t:1527873127742};\\\", \\\"{x:642,y:497,t:1527873127807};\\\", \\\"{x:643,y:496,t:1527873127822};\\\", \\\"{x:643,y:495,t:1527873131228};\\\", \\\"{x:643,y:494,t:1527873131241};\\\", \\\"{x:643,y:492,t:1527873131257};\\\", \\\"{x:644,y:491,t:1527873131933};\\\", \\\"{x:646,y:492,t:1527873131942};\\\", \\\"{x:650,y:497,t:1527873131958};\\\", \\\"{x:656,y:507,t:1527873131975};\\\", \\\"{x:662,y:515,t:1527873131992};\\\", \\\"{x:670,y:525,t:1527873132009};\\\", \\\"{x:678,y:535,t:1527873132024};\\\", \\\"{x:684,y:542,t:1527873132041};\\\", \\\"{x:692,y:555,t:1527873132058};\\\", \\\"{x:701,y:565,t:1527873132075};\\\", \\\"{x:714,y:577,t:1527873132092};\\\", \\\"{x:732,y:600,t:1527873132109};\\\", \\\"{x:748,y:616,t:1527873132125};\\\", \\\"{x:765,y:630,t:1527873132143};\\\", \\\"{x:782,y:644,t:1527873132159};\\\", \\\"{x:799,y:659,t:1527873132175};\\\", \\\"{x:820,y:674,t:1527873132192};\\\", \\\"{x:836,y:686,t:1527873132209};\\\", \\\"{x:849,y:696,t:1527873132224};\\\", \\\"{x:861,y:707,t:1527873132242};\\\", \\\"{x:872,y:716,t:1527873132259};\\\", \\\"{x:876,y:719,t:1527873132276};\\\", \\\"{x:880,y:723,t:1527873132292};\\\", \\\"{x:884,y:729,t:1527873132308};\\\", \\\"{x:887,y:732,t:1527873132326};\\\", \\\"{x:887,y:734,t:1527873132342};\\\", \\\"{x:889,y:735,t:1527873132359};\\\", \\\"{x:889,y:737,t:1527873132375};\\\", \\\"{x:892,y:740,t:1527873132392};\\\", \\\"{x:894,y:745,t:1527873132409};\\\", \\\"{x:896,y:747,t:1527873132426};\\\", \\\"{x:898,y:750,t:1527873132442};\\\", \\\"{x:899,y:753,t:1527873132458};\\\", \\\"{x:901,y:757,t:1527873132476};\\\", \\\"{x:903,y:760,t:1527873132492};\\\", \\\"{x:906,y:767,t:1527873132508};\\\", \\\"{x:908,y:774,t:1527873132526};\\\", \\\"{x:910,y:779,t:1527873132543};\\\", \\\"{x:911,y:787,t:1527873132559};\\\", \\\"{x:911,y:794,t:1527873132576};\\\", \\\"{x:914,y:805,t:1527873132593};\\\", \\\"{x:915,y:819,t:1527873132609};\\\", \\\"{x:916,y:833,t:1527873132626};\\\", \\\"{x:920,y:844,t:1527873132643};\\\", \\\"{x:924,y:849,t:1527873132659};\\\", \\\"{x:927,y:852,t:1527873133228};\\\", \\\"{x:928,y:853,t:1527873133245};\\\", \\\"{x:932,y:853,t:1527873133260};\\\", \\\"{x:940,y:859,t:1527873133277};\\\", \\\"{x:947,y:860,t:1527873133294};\\\", \\\"{x:956,y:861,t:1527873133310};\\\", \\\"{x:964,y:864,t:1527873133327};\\\", \\\"{x:974,y:865,t:1527873133344};\\\", \\\"{x:988,y:868,t:1527873133360};\\\", \\\"{x:1000,y:869,t:1527873133377};\\\", \\\"{x:1018,y:871,t:1527873133395};\\\", \\\"{x:1041,y:875,t:1527873133410};\\\", \\\"{x:1071,y:880,t:1527873133427};\\\", \\\"{x:1112,y:886,t:1527873133444};\\\", \\\"{x:1161,y:889,t:1527873133460};\\\", \\\"{x:1241,y:893,t:1527873133477};\\\", \\\"{x:1294,y:893,t:1527873133494};\\\", \\\"{x:1356,y:893,t:1527873133511};\\\", \\\"{x:1409,y:893,t:1527873133527};\\\", \\\"{x:1467,y:893,t:1527873133544};\\\", \\\"{x:1519,y:883,t:1527873133561};\\\", \\\"{x:1561,y:870,t:1527873133577};\\\", \\\"{x:1593,y:854,t:1527873133594};\\\", \\\"{x:1609,y:841,t:1527873133611};\\\", \\\"{x:1619,y:828,t:1527873133627};\\\", \\\"{x:1626,y:813,t:1527873133644};\\\", \\\"{x:1629,y:789,t:1527873133661};\\\", \\\"{x:1629,y:775,t:1527873133677};\\\", \\\"{x:1629,y:764,t:1527873133694};\\\", \\\"{x:1628,y:751,t:1527873133711};\\\", \\\"{x:1628,y:743,t:1527873133728};\\\", \\\"{x:1625,y:733,t:1527873133744};\\\", \\\"{x:1624,y:723,t:1527873133761};\\\", \\\"{x:1624,y:714,t:1527873133778};\\\", \\\"{x:1624,y:707,t:1527873133796};\\\", \\\"{x:1624,y:696,t:1527873133828};\\\", \\\"{x:1624,y:693,t:1527873133845};\\\", \\\"{x:1627,y:685,t:1527873133861};\\\", \\\"{x:1628,y:680,t:1527873133878};\\\", \\\"{x:1628,y:677,t:1527873133894};\\\", \\\"{x:1628,y:673,t:1527873133911};\\\", \\\"{x:1628,y:671,t:1527873133928};\\\", \\\"{x:1628,y:668,t:1527873133944};\\\", \\\"{x:1625,y:665,t:1527873133961};\\\", \\\"{x:1623,y:663,t:1527873133978};\\\", \\\"{x:1622,y:662,t:1527873133995};\\\", \\\"{x:1621,y:662,t:1527873134011};\\\", \\\"{x:1618,y:662,t:1527873134332};\\\", \\\"{x:1613,y:659,t:1527873134345};\\\", \\\"{x:1604,y:656,t:1527873134362};\\\", \\\"{x:1595,y:654,t:1527873134378};\\\", \\\"{x:1575,y:647,t:1527873134395};\\\", \\\"{x:1552,y:640,t:1527873134412};\\\", \\\"{x:1518,y:627,t:1527873134429};\\\", \\\"{x:1471,y:605,t:1527873134445};\\\", \\\"{x:1451,y:595,t:1527873134462};\\\", \\\"{x:1436,y:586,t:1527873134479};\\\", \\\"{x:1423,y:577,t:1527873134495};\\\", \\\"{x:1415,y:573,t:1527873134512};\\\", \\\"{x:1409,y:569,t:1527873134529};\\\", \\\"{x:1404,y:567,t:1527873134545};\\\", \\\"{x:1396,y:563,t:1527873134562};\\\", \\\"{x:1391,y:559,t:1527873134579};\\\", \\\"{x:1377,y:554,t:1527873134595};\\\", \\\"{x:1364,y:549,t:1527873134612};\\\", \\\"{x:1346,y:541,t:1527873134629};\\\", \\\"{x:1339,y:539,t:1527873134646};\\\", \\\"{x:1337,y:537,t:1527873134662};\\\", \\\"{x:1335,y:536,t:1527873134679};\\\", \\\"{x:1334,y:534,t:1527873134696};\\\", \\\"{x:1333,y:532,t:1527873134712};\\\", \\\"{x:1331,y:530,t:1527873134730};\\\", \\\"{x:1330,y:528,t:1527873134746};\\\", \\\"{x:1330,y:527,t:1527873134762};\\\", \\\"{x:1330,y:525,t:1527873134779};\\\", \\\"{x:1330,y:524,t:1527873134805};\\\", \\\"{x:1330,y:522,t:1527873134829};\\\", \\\"{x:1330,y:521,t:1527873134846};\\\", \\\"{x:1328,y:518,t:1527873134862};\\\", \\\"{x:1327,y:515,t:1527873134879};\\\", \\\"{x:1324,y:513,t:1527873134896};\\\", \\\"{x:1322,y:511,t:1527873134913};\\\", \\\"{x:1320,y:509,t:1527873134929};\\\", \\\"{x:1317,y:506,t:1527873134946};\\\", \\\"{x:1316,y:505,t:1527873134963};\\\", \\\"{x:1315,y:504,t:1527873134979};\\\", \\\"{x:1314,y:503,t:1527873134997};\\\", \\\"{x:1313,y:502,t:1527873135053};\\\", \\\"{x:1312,y:505,t:1527873135381};\\\", \\\"{x:1312,y:507,t:1527873135405};\\\", \\\"{x:1312,y:508,t:1527873135413};\\\", \\\"{x:1312,y:511,t:1527873135430};\\\", \\\"{x:1312,y:514,t:1527873135447};\\\", \\\"{x:1312,y:518,t:1527873135463};\\\", \\\"{x:1312,y:522,t:1527873135480};\\\", \\\"{x:1312,y:528,t:1527873135497};\\\", \\\"{x:1310,y:536,t:1527873135513};\\\", \\\"{x:1310,y:546,t:1527873135530};\\\", \\\"{x:1309,y:555,t:1527873135547};\\\", \\\"{x:1309,y:562,t:1527873135563};\\\", \\\"{x:1309,y:567,t:1527873135580};\\\", \\\"{x:1309,y:575,t:1527873135597};\\\", \\\"{x:1309,y:579,t:1527873135614};\\\", \\\"{x:1309,y:583,t:1527873135630};\\\", \\\"{x:1309,y:586,t:1527873135647};\\\", \\\"{x:1309,y:588,t:1527873135664};\\\", \\\"{x:1309,y:591,t:1527873135680};\\\", \\\"{x:1309,y:592,t:1527873135698};\\\", \\\"{x:1309,y:595,t:1527873135714};\\\", \\\"{x:1309,y:598,t:1527873135730};\\\", \\\"{x:1309,y:600,t:1527873135747};\\\", \\\"{x:1309,y:604,t:1527873135764};\\\", \\\"{x:1309,y:607,t:1527873135780};\\\", \\\"{x:1309,y:612,t:1527873135797};\\\", \\\"{x:1309,y:618,t:1527873135814};\\\", \\\"{x:1309,y:623,t:1527873135830};\\\", \\\"{x:1309,y:630,t:1527873135847};\\\", \\\"{x:1309,y:636,t:1527873135865};\\\", \\\"{x:1309,y:642,t:1527873135881};\\\", \\\"{x:1309,y:646,t:1527873135897};\\\", \\\"{x:1309,y:651,t:1527873135914};\\\", \\\"{x:1309,y:657,t:1527873135931};\\\", \\\"{x:1309,y:660,t:1527873135947};\\\", \\\"{x:1309,y:666,t:1527873135964};\\\", \\\"{x:1309,y:676,t:1527873135981};\\\", \\\"{x:1309,y:681,t:1527873135997};\\\", \\\"{x:1309,y:688,t:1527873136014};\\\", \\\"{x:1309,y:693,t:1527873136031};\\\", \\\"{x:1309,y:702,t:1527873136047};\\\", \\\"{x:1313,y:713,t:1527873136065};\\\", \\\"{x:1315,y:717,t:1527873136082};\\\", \\\"{x:1316,y:721,t:1527873136098};\\\", \\\"{x:1317,y:725,t:1527873136114};\\\", \\\"{x:1317,y:726,t:1527873136131};\\\", \\\"{x:1317,y:729,t:1527873136149};\\\", \\\"{x:1318,y:731,t:1527873136164};\\\", \\\"{x:1318,y:734,t:1527873136181};\\\", \\\"{x:1318,y:735,t:1527873136198};\\\", \\\"{x:1319,y:737,t:1527873136214};\\\", \\\"{x:1319,y:738,t:1527873136231};\\\", \\\"{x:1319,y:739,t:1527873136277};\\\", \\\"{x:1319,y:740,t:1527873136293};\\\", \\\"{x:1319,y:741,t:1527873136301};\\\", \\\"{x:1319,y:743,t:1527873136317};\\\", \\\"{x:1319,y:744,t:1527873136331};\\\", \\\"{x:1319,y:745,t:1527873136348};\\\", \\\"{x:1319,y:748,t:1527873136365};\\\", \\\"{x:1319,y:753,t:1527873136381};\\\", \\\"{x:1319,y:758,t:1527873136398};\\\", \\\"{x:1319,y:760,t:1527873136415};\\\", \\\"{x:1319,y:761,t:1527873136431};\\\", \\\"{x:1319,y:762,t:1527873136573};\\\", \\\"{x:1317,y:765,t:1527873136582};\\\", \\\"{x:1310,y:773,t:1527873136598};\\\", \\\"{x:1301,y:786,t:1527873136615};\\\", \\\"{x:1295,y:798,t:1527873136632};\\\", \\\"{x:1291,y:803,t:1527873136649};\\\", \\\"{x:1291,y:802,t:1527873136701};\\\", \\\"{x:1291,y:798,t:1527873136715};\\\", \\\"{x:1294,y:777,t:1527873136732};\\\", \\\"{x:1304,y:748,t:1527873136749};\\\", \\\"{x:1315,y:674,t:1527873136766};\\\", \\\"{x:1322,y:628,t:1527873136782};\\\", \\\"{x:1327,y:594,t:1527873136799};\\\", \\\"{x:1332,y:568,t:1527873136815};\\\", \\\"{x:1332,y:547,t:1527873136832};\\\", \\\"{x:1333,y:531,t:1527873136849};\\\", \\\"{x:1333,y:524,t:1527873136865};\\\", \\\"{x:1333,y:519,t:1527873136882};\\\", \\\"{x:1333,y:515,t:1527873136899};\\\", \\\"{x:1332,y:513,t:1527873136915};\\\", \\\"{x:1331,y:512,t:1527873136932};\\\", \\\"{x:1331,y:511,t:1527873136948};\\\", \\\"{x:1329,y:510,t:1527873136989};\\\", \\\"{x:1329,y:509,t:1527873137020};\\\", \\\"{x:1328,y:509,t:1527873137045};\\\", \\\"{x:1327,y:508,t:1527873137053};\\\", \\\"{x:1326,y:508,t:1527873137069};\\\", \\\"{x:1324,y:506,t:1527873137085};\\\", \\\"{x:1322,y:506,t:1527873137101};\\\", \\\"{x:1322,y:505,t:1527873137116};\\\", \\\"{x:1318,y:502,t:1527873137133};\\\", \\\"{x:1315,y:499,t:1527873137149};\\\", \\\"{x:1314,y:499,t:1527873137166};\\\", \\\"{x:1313,y:498,t:1527873137182};\\\", \\\"{x:1312,y:498,t:1527873137789};\\\", \\\"{x:1312,y:499,t:1527873138309};\\\", \\\"{x:1312,y:502,t:1527873138318};\\\", \\\"{x:1312,y:506,t:1527873138335};\\\", \\\"{x:1312,y:513,t:1527873138352};\\\", \\\"{x:1312,y:522,t:1527873138367};\\\", \\\"{x:1312,y:531,t:1527873138384};\\\", \\\"{x:1312,y:540,t:1527873138401};\\\", \\\"{x:1312,y:549,t:1527873138417};\\\", \\\"{x:1311,y:556,t:1527873138435};\\\", \\\"{x:1309,y:565,t:1527873138451};\\\", \\\"{x:1308,y:572,t:1527873138468};\\\", \\\"{x:1307,y:581,t:1527873138484};\\\", \\\"{x:1305,y:592,t:1527873138501};\\\", \\\"{x:1304,y:594,t:1527873138519};\\\", \\\"{x:1304,y:598,t:1527873138534};\\\", \\\"{x:1303,y:602,t:1527873138552};\\\", \\\"{x:1303,y:606,t:1527873138568};\\\", \\\"{x:1303,y:609,t:1527873138584};\\\", \\\"{x:1303,y:612,t:1527873138601};\\\", \\\"{x:1303,y:615,t:1527873138618};\\\", \\\"{x:1303,y:617,t:1527873138634};\\\", \\\"{x:1303,y:618,t:1527873138651};\\\", \\\"{x:1303,y:620,t:1527873138668};\\\", \\\"{x:1305,y:624,t:1527873138685};\\\", \\\"{x:1306,y:627,t:1527873138701};\\\", \\\"{x:1307,y:628,t:1527873138718};\\\", \\\"{x:1309,y:632,t:1527873138735};\\\", \\\"{x:1312,y:635,t:1527873138751};\\\", \\\"{x:1312,y:636,t:1527873138781};\\\", \\\"{x:1312,y:637,t:1527873138788};\\\", \\\"{x:1312,y:638,t:1527873138802};\\\", \\\"{x:1313,y:638,t:1527873138819};\\\", \\\"{x:1313,y:640,t:1527873139061};\\\", \\\"{x:1313,y:641,t:1527873139068};\\\", \\\"{x:1313,y:644,t:1527873139085};\\\", \\\"{x:1311,y:653,t:1527873139102};\\\", \\\"{x:1310,y:662,t:1527873139118};\\\", \\\"{x:1309,y:672,t:1527873139136};\\\", \\\"{x:1306,y:685,t:1527873139152};\\\", \\\"{x:1306,y:691,t:1527873139169};\\\", \\\"{x:1305,y:702,t:1527873139186};\\\", \\\"{x:1305,y:710,t:1527873139202};\\\", \\\"{x:1305,y:715,t:1527873139219};\\\", \\\"{x:1305,y:718,t:1527873139235};\\\", \\\"{x:1305,y:726,t:1527873139252};\\\", \\\"{x:1304,y:729,t:1527873139268};\\\", \\\"{x:1304,y:733,t:1527873139286};\\\", \\\"{x:1304,y:737,t:1527873139302};\\\", \\\"{x:1304,y:741,t:1527873139320};\\\", \\\"{x:1305,y:745,t:1527873139335};\\\", \\\"{x:1307,y:749,t:1527873139353};\\\", \\\"{x:1307,y:750,t:1527873139369};\\\", \\\"{x:1307,y:751,t:1527873139386};\\\", \\\"{x:1307,y:752,t:1527873139402};\\\", \\\"{x:1308,y:753,t:1527873139420};\\\", \\\"{x:1308,y:754,t:1527873139436};\\\", \\\"{x:1309,y:756,t:1527873139452};\\\", \\\"{x:1310,y:758,t:1527873139469};\\\", \\\"{x:1310,y:760,t:1527873139486};\\\", \\\"{x:1310,y:761,t:1527873139509};\\\", \\\"{x:1312,y:762,t:1527873139519};\\\", \\\"{x:1312,y:763,t:1527873139536};\\\", \\\"{x:1312,y:764,t:1527873139553};\\\", \\\"{x:1312,y:766,t:1527873139877};\\\", \\\"{x:1312,y:767,t:1527873139886};\\\", \\\"{x:1312,y:770,t:1527873139903};\\\", \\\"{x:1312,y:776,t:1527873139921};\\\", \\\"{x:1313,y:782,t:1527873139936};\\\", \\\"{x:1313,y:793,t:1527873139954};\\\", \\\"{x:1313,y:799,t:1527873139970};\\\", \\\"{x:1313,y:808,t:1527873139987};\\\", \\\"{x:1313,y:814,t:1527873140003};\\\", \\\"{x:1313,y:821,t:1527873140021};\\\", \\\"{x:1314,y:825,t:1527873140036};\\\", \\\"{x:1314,y:834,t:1527873140053};\\\", \\\"{x:1315,y:837,t:1527873140071};\\\", \\\"{x:1316,y:839,t:1527873140086};\\\", \\\"{x:1316,y:840,t:1527873140103};\\\", \\\"{x:1316,y:841,t:1527873140157};\\\", \\\"{x:1316,y:842,t:1527873140173};\\\", \\\"{x:1316,y:843,t:1527873140188};\\\", \\\"{x:1316,y:844,t:1527873140203};\\\", \\\"{x:1317,y:846,t:1527873140221};\\\", \\\"{x:1317,y:847,t:1527873140237};\\\", \\\"{x:1317,y:848,t:1527873140253};\\\", \\\"{x:1317,y:850,t:1527873140271};\\\", \\\"{x:1317,y:853,t:1527873140287};\\\", \\\"{x:1317,y:856,t:1527873140303};\\\", \\\"{x:1317,y:859,t:1527873140320};\\\", \\\"{x:1317,y:863,t:1527873140337};\\\", \\\"{x:1317,y:866,t:1527873140355};\\\", \\\"{x:1317,y:869,t:1527873140371};\\\", \\\"{x:1317,y:870,t:1527873140388};\\\", \\\"{x:1317,y:872,t:1527873140405};\\\", \\\"{x:1317,y:875,t:1527873140421};\\\", \\\"{x:1317,y:879,t:1527873140437};\\\", \\\"{x:1317,y:882,t:1527873140454};\\\", \\\"{x:1317,y:883,t:1527873140471};\\\", \\\"{x:1317,y:885,t:1527873140487};\\\", \\\"{x:1317,y:886,t:1527873140505};\\\", \\\"{x:1317,y:888,t:1527873140520};\\\", \\\"{x:1317,y:889,t:1527873140538};\\\", \\\"{x:1317,y:891,t:1527873140621};\\\", \\\"{x:1317,y:892,t:1527873140637};\\\", \\\"{x:1316,y:892,t:1527873140661};\\\", \\\"{x:1315,y:893,t:1527873140671};\\\", \\\"{x:1315,y:894,t:1527873140701};\\\", \\\"{x:1314,y:894,t:1527873140741};\\\", \\\"{x:1314,y:895,t:1527873140772};\\\", \\\"{x:1314,y:896,t:1527873140787};\\\", \\\"{x:1313,y:897,t:1527873140804};\\\", \\\"{x:1313,y:901,t:1527873140821};\\\", \\\"{x:1313,y:903,t:1527873140838};\\\", \\\"{x:1313,y:907,t:1527873140854};\\\", \\\"{x:1312,y:911,t:1527873140871};\\\", \\\"{x:1311,y:915,t:1527873140888};\\\", \\\"{x:1311,y:917,t:1527873140905};\\\", \\\"{x:1310,y:919,t:1527873140921};\\\", \\\"{x:1310,y:922,t:1527873140938};\\\", \\\"{x:1310,y:925,t:1527873140954};\\\", \\\"{x:1310,y:929,t:1527873140971};\\\", \\\"{x:1310,y:934,t:1527873140989};\\\", \\\"{x:1313,y:939,t:1527873141005};\\\", \\\"{x:1313,y:940,t:1527873141022};\\\", \\\"{x:1313,y:943,t:1527873141038};\\\", \\\"{x:1313,y:945,t:1527873141055};\\\", \\\"{x:1313,y:947,t:1527873141072};\\\", \\\"{x:1312,y:950,t:1527873141088};\\\", \\\"{x:1311,y:953,t:1527873141105};\\\", \\\"{x:1311,y:957,t:1527873141121};\\\", \\\"{x:1311,y:961,t:1527873141138};\\\", \\\"{x:1311,y:965,t:1527873141156};\\\", \\\"{x:1311,y:967,t:1527873141171};\\\", \\\"{x:1311,y:968,t:1527873142213};\\\", \\\"{x:1312,y:968,t:1527873142261};\\\", \\\"{x:1313,y:968,t:1527873142316};\\\", \\\"{x:1314,y:968,t:1527873142405};\\\", \\\"{x:1315,y:967,t:1527873142429};\\\", \\\"{x:1316,y:967,t:1527873144429};\\\", \\\"{x:1316,y:965,t:1527873145398};\\\", \\\"{x:1316,y:964,t:1527873145413};\\\", \\\"{x:1315,y:962,t:1527873145428};\\\", \\\"{x:1315,y:959,t:1527873145445};\\\", \\\"{x:1314,y:957,t:1527873145462};\\\", \\\"{x:1314,y:954,t:1527873145478};\\\", \\\"{x:1312,y:952,t:1527873145496};\\\", \\\"{x:1312,y:949,t:1527873145512};\\\", \\\"{x:1312,y:945,t:1527873145528};\\\", \\\"{x:1312,y:944,t:1527873145545};\\\", \\\"{x:1312,y:941,t:1527873145562};\\\", \\\"{x:1312,y:938,t:1527873145580};\\\", \\\"{x:1312,y:937,t:1527873145598};\\\", \\\"{x:1312,y:936,t:1527873145613};\\\", \\\"{x:1312,y:935,t:1527873145629};\\\", \\\"{x:1312,y:934,t:1527873145686};\\\", \\\"{x:1312,y:933,t:1527873145702};\\\", \\\"{x:1312,y:932,t:1527873145725};\\\", \\\"{x:1312,y:931,t:1527873145766};\\\", \\\"{x:1312,y:930,t:1527873145779};\\\", \\\"{x:1312,y:929,t:1527873145796};\\\", \\\"{x:1312,y:928,t:1527873145812};\\\", \\\"{x:1313,y:925,t:1527873145829};\\\", \\\"{x:1313,y:924,t:1527873145853};\\\", \\\"{x:1313,y:922,t:1527873145862};\\\", \\\"{x:1313,y:921,t:1527873145879};\\\", \\\"{x:1313,y:917,t:1527873145896};\\\", \\\"{x:1313,y:915,t:1527873145912};\\\", \\\"{x:1313,y:913,t:1527873145930};\\\", \\\"{x:1315,y:912,t:1527873145946};\\\", \\\"{x:1315,y:910,t:1527873145962};\\\", \\\"{x:1315,y:909,t:1527873145980};\\\", \\\"{x:1315,y:907,t:1527873145996};\\\", \\\"{x:1315,y:905,t:1527873146014};\\\", \\\"{x:1315,y:903,t:1527873146029};\\\", \\\"{x:1316,y:902,t:1527873146047};\\\", \\\"{x:1316,y:900,t:1527873146063};\\\", \\\"{x:1316,y:898,t:1527873146079};\\\", \\\"{x:1317,y:897,t:1527873146096};\\\", \\\"{x:1317,y:894,t:1527873146113};\\\", \\\"{x:1317,y:892,t:1527873146130};\\\", \\\"{x:1317,y:890,t:1527873146146};\\\", \\\"{x:1317,y:889,t:1527873146163};\\\", \\\"{x:1317,y:887,t:1527873146179};\\\", \\\"{x:1317,y:885,t:1527873146196};\\\", \\\"{x:1318,y:880,t:1527873146213};\\\", \\\"{x:1318,y:877,t:1527873146229};\\\", \\\"{x:1318,y:874,t:1527873146246};\\\", \\\"{x:1319,y:869,t:1527873146263};\\\", \\\"{x:1320,y:864,t:1527873146281};\\\", \\\"{x:1320,y:859,t:1527873146296};\\\", \\\"{x:1320,y:852,t:1527873146313};\\\", \\\"{x:1320,y:842,t:1527873146331};\\\", \\\"{x:1320,y:834,t:1527873146346};\\\", \\\"{x:1320,y:823,t:1527873146363};\\\", \\\"{x:1321,y:813,t:1527873146380};\\\", \\\"{x:1321,y:804,t:1527873146396};\\\", \\\"{x:1322,y:792,t:1527873146413};\\\", \\\"{x:1322,y:788,t:1527873146430};\\\", \\\"{x:1323,y:783,t:1527873146447};\\\", \\\"{x:1324,y:776,t:1527873146463};\\\", \\\"{x:1325,y:769,t:1527873146480};\\\", \\\"{x:1327,y:759,t:1527873146497};\\\", \\\"{x:1327,y:749,t:1527873146513};\\\", \\\"{x:1328,y:740,t:1527873146530};\\\", \\\"{x:1328,y:733,t:1527873146546};\\\", \\\"{x:1328,y:725,t:1527873146562};\\\", \\\"{x:1328,y:715,t:1527873146580};\\\", \\\"{x:1328,y:701,t:1527873146597};\\\", \\\"{x:1328,y:690,t:1527873146612};\\\", \\\"{x:1328,y:680,t:1527873146630};\\\", \\\"{x:1328,y:674,t:1527873146646};\\\", \\\"{x:1328,y:672,t:1527873146663};\\\", \\\"{x:1329,y:668,t:1527873146681};\\\", \\\"{x:1329,y:666,t:1527873146697};\\\", \\\"{x:1329,y:663,t:1527873146714};\\\", \\\"{x:1329,y:661,t:1527873146731};\\\", \\\"{x:1329,y:660,t:1527873146747};\\\", \\\"{x:1329,y:659,t:1527873146764};\\\", \\\"{x:1329,y:656,t:1527873146781};\\\", \\\"{x:1329,y:651,t:1527873146797};\\\", \\\"{x:1328,y:647,t:1527873146814};\\\", \\\"{x:1327,y:642,t:1527873146830};\\\", \\\"{x:1327,y:641,t:1527873146847};\\\", \\\"{x:1326,y:637,t:1527873146864};\\\", \\\"{x:1326,y:634,t:1527873146881};\\\", \\\"{x:1324,y:631,t:1527873146897};\\\", \\\"{x:1322,y:629,t:1527873146914};\\\", \\\"{x:1322,y:628,t:1527873146942};\\\", \\\"{x:1321,y:628,t:1527873146958};\\\", \\\"{x:1320,y:628,t:1527873146982};\\\", \\\"{x:1319,y:627,t:1527873147014};\\\", \\\"{x:1318,y:627,t:1527873147094};\\\", \\\"{x:1317,y:627,t:1527873147158};\\\", \\\"{x:1316,y:627,t:1527873147173};\\\", \\\"{x:1315,y:627,t:1527873147205};\\\", \\\"{x:1315,y:628,t:1527873147214};\\\", \\\"{x:1312,y:628,t:1527873153958};\\\", \\\"{x:1311,y:630,t:1527873153975};\\\", \\\"{x:1311,y:631,t:1527873153991};\\\", \\\"{x:1311,y:634,t:1527873154007};\\\", \\\"{x:1311,y:637,t:1527873154026};\\\", \\\"{x:1310,y:641,t:1527873154041};\\\", \\\"{x:1309,y:644,t:1527873154057};\\\", \\\"{x:1307,y:648,t:1527873154074};\\\", \\\"{x:1307,y:651,t:1527873154091};\\\", \\\"{x:1307,y:652,t:1527873154107};\\\", \\\"{x:1307,y:654,t:1527873154124};\\\", \\\"{x:1307,y:658,t:1527873154141};\\\", \\\"{x:1304,y:663,t:1527873154157};\\\", \\\"{x:1303,y:668,t:1527873154174};\\\", \\\"{x:1300,y:673,t:1527873154191};\\\", \\\"{x:1293,y:678,t:1527873154208};\\\", \\\"{x:1282,y:684,t:1527873154224};\\\", \\\"{x:1261,y:689,t:1527873154241};\\\", \\\"{x:1229,y:690,t:1527873154258};\\\", \\\"{x:1167,y:690,t:1527873154274};\\\", \\\"{x:1079,y:690,t:1527873154291};\\\", \\\"{x:998,y:690,t:1527873154308};\\\", \\\"{x:950,y:684,t:1527873154324};\\\", \\\"{x:908,y:670,t:1527873154340};\\\", \\\"{x:893,y:662,t:1527873154358};\\\", \\\"{x:882,y:656,t:1527873154374};\\\", \\\"{x:875,y:652,t:1527873154391};\\\", \\\"{x:867,y:647,t:1527873154408};\\\", \\\"{x:854,y:643,t:1527873154424};\\\", \\\"{x:837,y:639,t:1527873154441};\\\", \\\"{x:815,y:635,t:1527873154458};\\\", \\\"{x:786,y:632,t:1527873154475};\\\", \\\"{x:752,y:632,t:1527873154491};\\\", \\\"{x:725,y:632,t:1527873154508};\\\", \\\"{x:687,y:632,t:1527873154524};\\\", \\\"{x:661,y:632,t:1527873154541};\\\", \\\"{x:642,y:632,t:1527873154558};\\\", \\\"{x:624,y:632,t:1527873154575};\\\", \\\"{x:611,y:630,t:1527873154591};\\\", \\\"{x:596,y:625,t:1527873154609};\\\", \\\"{x:581,y:619,t:1527873154625};\\\", \\\"{x:568,y:614,t:1527873154641};\\\", \\\"{x:560,y:608,t:1527873154660};\\\", \\\"{x:560,y:607,t:1527873154685};\\\", \\\"{x:560,y:606,t:1527873154693};\\\", \\\"{x:567,y:603,t:1527873154711};\\\", \\\"{x:593,y:599,t:1527873154727};\\\", \\\"{x:641,y:598,t:1527873154744};\\\", \\\"{x:718,y:592,t:1527873154761};\\\", \\\"{x:784,y:592,t:1527873154777};\\\", \\\"{x:852,y:591,t:1527873154794};\\\", \\\"{x:902,y:591,t:1527873154811};\\\", \\\"{x:929,y:589,t:1527873154827};\\\", \\\"{x:939,y:589,t:1527873154844};\\\", \\\"{x:942,y:586,t:1527873154862};\\\", \\\"{x:943,y:586,t:1527873154885};\\\", \\\"{x:943,y:584,t:1527873154909};\\\", \\\"{x:943,y:581,t:1527873154925};\\\", \\\"{x:943,y:580,t:1527873154933};\\\", \\\"{x:943,y:579,t:1527873154944};\\\", \\\"{x:943,y:573,t:1527873154961};\\\", \\\"{x:943,y:567,t:1527873154977};\\\", \\\"{x:940,y:563,t:1527873154994};\\\", \\\"{x:936,y:559,t:1527873155011};\\\", \\\"{x:928,y:555,t:1527873155029};\\\", \\\"{x:921,y:552,t:1527873155044};\\\", \\\"{x:910,y:548,t:1527873155061};\\\", \\\"{x:903,y:547,t:1527873155078};\\\", \\\"{x:897,y:544,t:1527873155094};\\\", \\\"{x:891,y:542,t:1527873155110};\\\", \\\"{x:890,y:542,t:1527873155132};\\\", \\\"{x:889,y:542,t:1527873155148};\\\", \\\"{x:887,y:542,t:1527873155164};\\\", \\\"{x:886,y:542,t:1527873155178};\\\", \\\"{x:883,y:542,t:1527873155194};\\\", \\\"{x:877,y:542,t:1527873155211};\\\", \\\"{x:867,y:542,t:1527873155229};\\\", \\\"{x:860,y:542,t:1527873155244};\\\", \\\"{x:854,y:542,t:1527873155261};\\\", \\\"{x:853,y:542,t:1527873155278};\\\", \\\"{x:852,y:542,t:1527873155294};\\\", \\\"{x:850,y:542,t:1527873155341};\\\", \\\"{x:849,y:542,t:1527873155365};\\\", \\\"{x:849,y:541,t:1527873155378};\\\", \\\"{x:848,y:540,t:1527873155394};\\\", \\\"{x:847,y:540,t:1527873155413};\\\", \\\"{x:846,y:540,t:1527873155828};\\\", \\\"{x:844,y:540,t:1527873155845};\\\", \\\"{x:839,y:540,t:1527873155862};\\\", \\\"{x:831,y:545,t:1527873155879};\\\", \\\"{x:819,y:551,t:1527873155896};\\\", \\\"{x:804,y:561,t:1527873155913};\\\", \\\"{x:788,y:568,t:1527873155929};\\\", \\\"{x:769,y:577,t:1527873155945};\\\", \\\"{x:751,y:583,t:1527873155962};\\\", \\\"{x:734,y:593,t:1527873155978};\\\", \\\"{x:714,y:606,t:1527873155995};\\\", \\\"{x:694,y:617,t:1527873156012};\\\", \\\"{x:671,y:629,t:1527873156029};\\\", \\\"{x:648,y:644,t:1527873156046};\\\", \\\"{x:631,y:654,t:1527873156062};\\\", \\\"{x:611,y:664,t:1527873156079};\\\", \\\"{x:595,y:671,t:1527873156096};\\\", \\\"{x:578,y:674,t:1527873156112};\\\", \\\"{x:568,y:676,t:1527873156128};\\\", \\\"{x:558,y:677,t:1527873156145};\\\", \\\"{x:544,y:679,t:1527873156162};\\\", \\\"{x:531,y:681,t:1527873156178};\\\", \\\"{x:522,y:682,t:1527873156195};\\\", \\\"{x:516,y:685,t:1527873156212};\\\", \\\"{x:512,y:686,t:1527873156228};\\\", \\\"{x:511,y:689,t:1527873156245};\\\", \\\"{x:510,y:692,t:1527873156262};\\\", \\\"{x:509,y:696,t:1527873156278};\\\", \\\"{x:507,y:702,t:1527873156295};\\\", \\\"{x:507,y:707,t:1527873156313};\\\", \\\"{x:507,y:710,t:1527873156330};\\\", \\\"{x:507,y:712,t:1527873156346};\\\", \\\"{x:507,y:716,t:1527873156363};\\\", \\\"{x:507,y:719,t:1527873156378};\\\", \\\"{x:507,y:721,t:1527873156395};\\\", \\\"{x:507,y:722,t:1527873156412};\\\", \\\"{x:507,y:723,t:1527873156429};\\\", \\\"{x:507,y:724,t:1527873156446};\\\", \\\"{x:507,y:725,t:1527873156462};\\\" ] }, { \\\"rt\\\": 21981, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 370206, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM-09 AM-E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:728,t:1527873159054};\\\", \\\"{x:514,y:731,t:1527873159068};\\\", \\\"{x:559,y:747,t:1527873159088};\\\", \\\"{x:604,y:769,t:1527873159101};\\\", \\\"{x:664,y:791,t:1527873159118};\\\", \\\"{x:697,y:801,t:1527873159130};\\\", \\\"{x:766,y:831,t:1527873159147};\\\", \\\"{x:832,y:859,t:1527873159163};\\\", \\\"{x:893,y:885,t:1527873159180};\\\", \\\"{x:978,y:924,t:1527873159197};\\\", \\\"{x:1030,y:947,t:1527873159213};\\\", \\\"{x:1066,y:962,t:1527873159230};\\\", \\\"{x:1093,y:974,t:1527873159248};\\\", \\\"{x:1118,y:985,t:1527873159264};\\\", \\\"{x:1140,y:994,t:1527873159280};\\\", \\\"{x:1158,y:1003,t:1527873159297};\\\", \\\"{x:1177,y:1012,t:1527873159314};\\\", \\\"{x:1193,y:1020,t:1527873159330};\\\", \\\"{x:1207,y:1025,t:1527873159347};\\\", \\\"{x:1215,y:1029,t:1527873159364};\\\", \\\"{x:1223,y:1033,t:1527873159381};\\\", \\\"{x:1227,y:1036,t:1527873159398};\\\", \\\"{x:1228,y:1037,t:1527873159413};\\\", \\\"{x:1228,y:1038,t:1527873159517};\\\", \\\"{x:1227,y:1038,t:1527873159531};\\\", \\\"{x:1222,y:1039,t:1527873159548};\\\", \\\"{x:1215,y:1039,t:1527873159564};\\\", \\\"{x:1209,y:1039,t:1527873159581};\\\", \\\"{x:1202,y:1038,t:1527873159597};\\\", \\\"{x:1196,y:1035,t:1527873159614};\\\", \\\"{x:1192,y:1034,t:1527873159631};\\\", \\\"{x:1190,y:1032,t:1527873159648};\\\", \\\"{x:1189,y:1032,t:1527873159663};\\\", \\\"{x:1187,y:1031,t:1527873159681};\\\", \\\"{x:1186,y:1031,t:1527873159699};\\\", \\\"{x:1183,y:1028,t:1527873159713};\\\", \\\"{x:1181,y:1027,t:1527873159730};\\\", \\\"{x:1178,y:1024,t:1527873159748};\\\", \\\"{x:1176,y:1022,t:1527873159764};\\\", \\\"{x:1175,y:1021,t:1527873159780};\\\", \\\"{x:1175,y:1019,t:1527873159797};\\\", \\\"{x:1173,y:1016,t:1527873159813};\\\", \\\"{x:1172,y:1015,t:1527873159831};\\\", \\\"{x:1169,y:1011,t:1527873159848};\\\", \\\"{x:1168,y:1011,t:1527873159863};\\\", \\\"{x:1167,y:1009,t:1527873159881};\\\", \\\"{x:1166,y:1008,t:1527873159898};\\\", \\\"{x:1165,y:1008,t:1527873159914};\\\", \\\"{x:1162,y:1006,t:1527873159931};\\\", \\\"{x:1160,y:1004,t:1527873159947};\\\", \\\"{x:1157,y:1004,t:1527873159963};\\\", \\\"{x:1155,y:1004,t:1527873159981};\\\", \\\"{x:1151,y:1002,t:1527873159998};\\\", \\\"{x:1150,y:1001,t:1527873160014};\\\", \\\"{x:1146,y:999,t:1527873160031};\\\", \\\"{x:1144,y:998,t:1527873160053};\\\", \\\"{x:1142,y:997,t:1527873160063};\\\", \\\"{x:1140,y:996,t:1527873160081};\\\", \\\"{x:1139,y:995,t:1527873160098};\\\", \\\"{x:1137,y:995,t:1527873160113};\\\", \\\"{x:1137,y:994,t:1527873160133};\\\", \\\"{x:1137,y:993,t:1527873160230};\\\", \\\"{x:1136,y:993,t:1527873160270};\\\", \\\"{x:1135,y:992,t:1527873160318};\\\", \\\"{x:1134,y:992,t:1527873160333};\\\", \\\"{x:1133,y:991,t:1527873160422};\\\", \\\"{x:1133,y:990,t:1527873160431};\\\", \\\"{x:1133,y:989,t:1527873160447};\\\", \\\"{x:1131,y:987,t:1527873160464};\\\", \\\"{x:1130,y:987,t:1527873160481};\\\", \\\"{x:1130,y:986,t:1527873160498};\\\", \\\"{x:1130,y:985,t:1527873161892};\\\", \\\"{x:1131,y:983,t:1527873161900};\\\", \\\"{x:1133,y:983,t:1527873161913};\\\", \\\"{x:1135,y:982,t:1527873161930};\\\", \\\"{x:1138,y:981,t:1527873161947};\\\", \\\"{x:1139,y:980,t:1527873161963};\\\", \\\"{x:1141,y:979,t:1527873161980};\\\", \\\"{x:1144,y:977,t:1527873161996};\\\", \\\"{x:1146,y:976,t:1527873162013};\\\", \\\"{x:1147,y:976,t:1527873162036};\\\", \\\"{x:1148,y:976,t:1527873162061};\\\", \\\"{x:1149,y:976,t:1527873162092};\\\", \\\"{x:1148,y:977,t:1527873162309};\\\", \\\"{x:1147,y:977,t:1527873162333};\\\", \\\"{x:1147,y:978,t:1527873162348};\\\", \\\"{x:1146,y:978,t:1527873162363};\\\", \\\"{x:1146,y:979,t:1527873162380};\\\", \\\"{x:1144,y:980,t:1527873162397};\\\", \\\"{x:1144,y:981,t:1527873163045};\\\", \\\"{x:1143,y:982,t:1527873163086};\\\", \\\"{x:1143,y:983,t:1527873163308};\\\", \\\"{x:1143,y:984,t:1527873163316};\\\", \\\"{x:1143,y:985,t:1527873163332};\\\", \\\"{x:1143,y:986,t:1527873163348};\\\", \\\"{x:1143,y:988,t:1527873163364};\\\", \\\"{x:1143,y:991,t:1527873163380};\\\", \\\"{x:1144,y:993,t:1527873163398};\\\", \\\"{x:1144,y:994,t:1527873163428};\\\", \\\"{x:1144,y:995,t:1527873163469};\\\", \\\"{x:1144,y:994,t:1527873163661};\\\", \\\"{x:1144,y:993,t:1527873163669};\\\", \\\"{x:1144,y:992,t:1527873163681};\\\", \\\"{x:1144,y:991,t:1527873163699};\\\", \\\"{x:1144,y:989,t:1527873163714};\\\", \\\"{x:1144,y:988,t:1527873163731};\\\", \\\"{x:1144,y:987,t:1527873163765};\\\", \\\"{x:1144,y:986,t:1527873163781};\\\", \\\"{x:1144,y:983,t:1527873163798};\\\", \\\"{x:1144,y:982,t:1527873163814};\\\", \\\"{x:1143,y:980,t:1527873163831};\\\", \\\"{x:1143,y:978,t:1527873163848};\\\", \\\"{x:1143,y:977,t:1527873163864};\\\", \\\"{x:1141,y:975,t:1527873163881};\\\", \\\"{x:1141,y:973,t:1527873163899};\\\", \\\"{x:1141,y:972,t:1527873163917};\\\", \\\"{x:1141,y:971,t:1527873163930};\\\", \\\"{x:1141,y:970,t:1527873163948};\\\", \\\"{x:1141,y:969,t:1527873163964};\\\", \\\"{x:1140,y:967,t:1527873163981};\\\", \\\"{x:1138,y:965,t:1527873164701};\\\", \\\"{x:1138,y:964,t:1527873164714};\\\", \\\"{x:1137,y:959,t:1527873164731};\\\", \\\"{x:1136,y:951,t:1527873164748};\\\", \\\"{x:1133,y:942,t:1527873164764};\\\", \\\"{x:1128,y:926,t:1527873164781};\\\", \\\"{x:1123,y:907,t:1527873164797};\\\", \\\"{x:1118,y:892,t:1527873164814};\\\", \\\"{x:1118,y:882,t:1527873164831};\\\", \\\"{x:1116,y:873,t:1527873164849};\\\", \\\"{x:1116,y:864,t:1527873164864};\\\", \\\"{x:1114,y:854,t:1527873164882};\\\", \\\"{x:1111,y:845,t:1527873164898};\\\", \\\"{x:1111,y:844,t:1527873165438};\\\", \\\"{x:1109,y:838,t:1527873165448};\\\", \\\"{x:1110,y:823,t:1527873165464};\\\", \\\"{x:1116,y:806,t:1527873165481};\\\", \\\"{x:1120,y:782,t:1527873165499};\\\", \\\"{x:1125,y:754,t:1527873165515};\\\", \\\"{x:1126,y:726,t:1527873165532};\\\", \\\"{x:1126,y:704,t:1527873165548};\\\", \\\"{x:1126,y:682,t:1527873165564};\\\", \\\"{x:1132,y:662,t:1527873165581};\\\", \\\"{x:1140,y:650,t:1527873165598};\\\", \\\"{x:1146,y:643,t:1527873165615};\\\", \\\"{x:1150,y:633,t:1527873165631};\\\", \\\"{x:1157,y:625,t:1527873165648};\\\", \\\"{x:1158,y:619,t:1527873165664};\\\", \\\"{x:1159,y:614,t:1527873165681};\\\", \\\"{x:1159,y:610,t:1527873165699};\\\", \\\"{x:1159,y:609,t:1527873165714};\\\", \\\"{x:1160,y:606,t:1527873165731};\\\", \\\"{x:1160,y:603,t:1527873165749};\\\", \\\"{x:1161,y:601,t:1527873165764};\\\", \\\"{x:1161,y:595,t:1527873165781};\\\", \\\"{x:1161,y:587,t:1527873165798};\\\", \\\"{x:1162,y:581,t:1527873165814};\\\", \\\"{x:1164,y:578,t:1527873165831};\\\", \\\"{x:1165,y:576,t:1527873165848};\\\", \\\"{x:1167,y:574,t:1527873165864};\\\", \\\"{x:1169,y:573,t:1527873165881};\\\", \\\"{x:1173,y:572,t:1527873165898};\\\", \\\"{x:1178,y:569,t:1527873165914};\\\", \\\"{x:1186,y:565,t:1527873165931};\\\", \\\"{x:1199,y:563,t:1527873165949};\\\", \\\"{x:1211,y:560,t:1527873165965};\\\", \\\"{x:1232,y:558,t:1527873165981};\\\", \\\"{x:1248,y:558,t:1527873165997};\\\", \\\"{x:1266,y:558,t:1527873166014};\\\", \\\"{x:1280,y:558,t:1527873166033};\\\", \\\"{x:1293,y:558,t:1527873166048};\\\", \\\"{x:1305,y:558,t:1527873166063};\\\", \\\"{x:1307,y:558,t:1527873166080};\\\", \\\"{x:1308,y:558,t:1527873166097};\\\", \\\"{x:1308,y:559,t:1527873166164};\\\", \\\"{x:1308,y:560,t:1527873166262};\\\", \\\"{x:1308,y:561,t:1527873166293};\\\", \\\"{x:1308,y:562,t:1527873166301};\\\", \\\"{x:1306,y:563,t:1527873166318};\\\", \\\"{x:1304,y:563,t:1527873166331};\\\", \\\"{x:1302,y:563,t:1527873166348};\\\", \\\"{x:1298,y:563,t:1527873166365};\\\", \\\"{x:1295,y:563,t:1527873166381};\\\", \\\"{x:1293,y:563,t:1527873166398};\\\", \\\"{x:1291,y:563,t:1527873166415};\\\", \\\"{x:1288,y:563,t:1527873166431};\\\", \\\"{x:1285,y:564,t:1527873166448};\\\", \\\"{x:1283,y:564,t:1527873166464};\\\", \\\"{x:1282,y:564,t:1527873166481};\\\", \\\"{x:1280,y:564,t:1527873166499};\\\", \\\"{x:1279,y:564,t:1527873166517};\\\", \\\"{x:1285,y:562,t:1527873173295};\\\", \\\"{x:1290,y:562,t:1527873173304};\\\", \\\"{x:1294,y:562,t:1527873173318};\\\", \\\"{x:1300,y:562,t:1527873173334};\\\", \\\"{x:1304,y:562,t:1527873173351};\\\", \\\"{x:1307,y:562,t:1527873173367};\\\", \\\"{x:1308,y:562,t:1527873173384};\\\", \\\"{x:1311,y:561,t:1527873173401};\\\", \\\"{x:1314,y:561,t:1527873173418};\\\", \\\"{x:1317,y:561,t:1527873173433};\\\", \\\"{x:1320,y:561,t:1527873173451};\\\", \\\"{x:1323,y:561,t:1527873173468};\\\", \\\"{x:1328,y:561,t:1527873173484};\\\", \\\"{x:1336,y:562,t:1527873173501};\\\", \\\"{x:1343,y:563,t:1527873173519};\\\", \\\"{x:1353,y:563,t:1527873173534};\\\", \\\"{x:1365,y:563,t:1527873173551};\\\", \\\"{x:1382,y:563,t:1527873173568};\\\", \\\"{x:1394,y:563,t:1527873173584};\\\", \\\"{x:1406,y:564,t:1527873173602};\\\", \\\"{x:1412,y:564,t:1527873173619};\\\", \\\"{x:1417,y:564,t:1527873173634};\\\", \\\"{x:1424,y:564,t:1527873173652};\\\", \\\"{x:1426,y:564,t:1527873173668};\\\", \\\"{x:1427,y:564,t:1527873173712};\\\", \\\"{x:1427,y:565,t:1527873174008};\\\", \\\"{x:1423,y:568,t:1527873174019};\\\", \\\"{x:1380,y:576,t:1527873174034};\\\", \\\"{x:1283,y:588,t:1527873174051};\\\", \\\"{x:1154,y:598,t:1527873174069};\\\", \\\"{x:982,y:605,t:1527873174084};\\\", \\\"{x:805,y:609,t:1527873174102};\\\", \\\"{x:639,y:609,t:1527873174118};\\\", \\\"{x:516,y:616,t:1527873174134};\\\", \\\"{x:425,y:625,t:1527873174147};\\\", \\\"{x:382,y:628,t:1527873174162};\\\", \\\"{x:361,y:630,t:1527873174179};\\\", \\\"{x:346,y:631,t:1527873174195};\\\", \\\"{x:335,y:631,t:1527873174212};\\\", \\\"{x:321,y:631,t:1527873174230};\\\", \\\"{x:307,y:631,t:1527873174246};\\\", \\\"{x:300,y:631,t:1527873174263};\\\", \\\"{x:290,y:627,t:1527873174279};\\\", \\\"{x:281,y:619,t:1527873174295};\\\", \\\"{x:274,y:605,t:1527873174313};\\\", \\\"{x:267,y:592,t:1527873174330};\\\", \\\"{x:263,y:583,t:1527873174347};\\\", \\\"{x:258,y:569,t:1527873174362};\\\", \\\"{x:256,y:559,t:1527873174380};\\\", \\\"{x:256,y:549,t:1527873174397};\\\", \\\"{x:257,y:544,t:1527873174414};\\\", \\\"{x:259,y:541,t:1527873174430};\\\", \\\"{x:266,y:537,t:1527873174447};\\\", \\\"{x:290,y:528,t:1527873174464};\\\", \\\"{x:303,y:523,t:1527873174481};\\\", \\\"{x:306,y:522,t:1527873174497};\\\", \\\"{x:307,y:522,t:1527873174543};\\\", \\\"{x:306,y:523,t:1527873174559};\\\", \\\"{x:304,y:524,t:1527873174567};\\\", \\\"{x:299,y:525,t:1527873174581};\\\", \\\"{x:285,y:529,t:1527873174597};\\\", \\\"{x:261,y:534,t:1527873174614};\\\", \\\"{x:225,y:540,t:1527873174630};\\\", \\\"{x:202,y:541,t:1527873174646};\\\", \\\"{x:183,y:541,t:1527873174663};\\\", \\\"{x:180,y:541,t:1527873174679};\\\", \\\"{x:179,y:541,t:1527873174696};\\\", \\\"{x:178,y:543,t:1527873174800};\\\", \\\"{x:178,y:546,t:1527873174814};\\\", \\\"{x:178,y:552,t:1527873174830};\\\", \\\"{x:184,y:559,t:1527873174848};\\\", \\\"{x:213,y:568,t:1527873174864};\\\", \\\"{x:238,y:568,t:1527873174881};\\\", \\\"{x:296,y:562,t:1527873174897};\\\", \\\"{x:375,y:555,t:1527873174914};\\\", \\\"{x:481,y:555,t:1527873174929};\\\", \\\"{x:580,y:555,t:1527873174948};\\\", \\\"{x:669,y:555,t:1527873174963};\\\", \\\"{x:741,y:546,t:1527873174982};\\\", \\\"{x:771,y:543,t:1527873174997};\\\", \\\"{x:788,y:541,t:1527873175014};\\\", \\\"{x:796,y:540,t:1527873175030};\\\", \\\"{x:797,y:539,t:1527873175047};\\\", \\\"{x:801,y:537,t:1527873175063};\\\", \\\"{x:806,y:535,t:1527873175080};\\\", \\\"{x:820,y:532,t:1527873175097};\\\", \\\"{x:842,y:530,t:1527873175114};\\\", \\\"{x:866,y:528,t:1527873175130};\\\", \\\"{x:882,y:525,t:1527873175148};\\\", \\\"{x:889,y:523,t:1527873175165};\\\", \\\"{x:885,y:521,t:1527873175199};\\\", \\\"{x:875,y:520,t:1527873175214};\\\", \\\"{x:846,y:517,t:1527873175230};\\\", \\\"{x:765,y:517,t:1527873175246};\\\", \\\"{x:707,y:517,t:1527873175264};\\\", \\\"{x:674,y:517,t:1527873175281};\\\", \\\"{x:653,y:515,t:1527873175296};\\\", \\\"{x:648,y:514,t:1527873175313};\\\", \\\"{x:645,y:514,t:1527873175331};\\\", \\\"{x:644,y:514,t:1527873175351};\\\", \\\"{x:642,y:514,t:1527873175367};\\\", \\\"{x:640,y:514,t:1527873175383};\\\", \\\"{x:638,y:514,t:1527873175396};\\\", \\\"{x:635,y:514,t:1527873175414};\\\", \\\"{x:629,y:514,t:1527873175431};\\\", \\\"{x:625,y:514,t:1527873175447};\\\", \\\"{x:624,y:514,t:1527873175527};\\\", \\\"{x:624,y:513,t:1527873175535};\\\", \\\"{x:624,y:512,t:1527873175567};\\\", \\\"{x:624,y:511,t:1527873175584};\\\", \\\"{x:623,y:510,t:1527873175599};\\\", \\\"{x:625,y:510,t:1527873175879};\\\", \\\"{x:635,y:508,t:1527873175887};\\\", \\\"{x:645,y:508,t:1527873175898};\\\", \\\"{x:666,y:508,t:1527873175915};\\\", \\\"{x:704,y:508,t:1527873175932};\\\", \\\"{x:761,y:510,t:1527873175948};\\\", \\\"{x:802,y:515,t:1527873175965};\\\", \\\"{x:820,y:518,t:1527873175981};\\\", \\\"{x:827,y:519,t:1527873175997};\\\", \\\"{x:828,y:519,t:1527873176015};\\\", \\\"{x:828,y:521,t:1527873176040};\\\", \\\"{x:828,y:523,t:1527873176056};\\\", \\\"{x:828,y:524,t:1527873176065};\\\", \\\"{x:829,y:527,t:1527873176082};\\\", \\\"{x:830,y:528,t:1527873176098};\\\", \\\"{x:830,y:529,t:1527873176114};\\\", \\\"{x:830,y:530,t:1527873176130};\\\", \\\"{x:831,y:534,t:1527873176148};\\\", \\\"{x:831,y:537,t:1527873176164};\\\", \\\"{x:831,y:540,t:1527873176180};\\\", \\\"{x:831,y:541,t:1527873176198};\\\", \\\"{x:831,y:542,t:1527873176215};\\\", \\\"{x:832,y:542,t:1527873176296};\\\", \\\"{x:834,y:544,t:1527873177455};\\\", \\\"{x:836,y:544,t:1527873177465};\\\", \\\"{x:843,y:544,t:1527873177483};\\\", \\\"{x:863,y:547,t:1527873177499};\\\", \\\"{x:884,y:550,t:1527873177516};\\\", \\\"{x:906,y:556,t:1527873177533};\\\", \\\"{x:933,y:558,t:1527873177548};\\\", \\\"{x:959,y:563,t:1527873177566};\\\", \\\"{x:1010,y:570,t:1527873177582};\\\", \\\"{x:1044,y:575,t:1527873177599};\\\", \\\"{x:1078,y:582,t:1527873177616};\\\", \\\"{x:1113,y:587,t:1527873177633};\\\", \\\"{x:1141,y:591,t:1527873177648};\\\", \\\"{x:1168,y:594,t:1527873177666};\\\", \\\"{x:1197,y:594,t:1527873177683};\\\", \\\"{x:1219,y:594,t:1527873177699};\\\", \\\"{x:1234,y:594,t:1527873177716};\\\", \\\"{x:1243,y:594,t:1527873177733};\\\", \\\"{x:1249,y:594,t:1527873177749};\\\", \\\"{x:1255,y:593,t:1527873177766};\\\", \\\"{x:1264,y:590,t:1527873177782};\\\", \\\"{x:1275,y:586,t:1527873177798};\\\", \\\"{x:1293,y:582,t:1527873177815};\\\", \\\"{x:1303,y:581,t:1527873177833};\\\", \\\"{x:1314,y:579,t:1527873177850};\\\", \\\"{x:1320,y:578,t:1527873177866};\\\", \\\"{x:1325,y:577,t:1527873177883};\\\", \\\"{x:1326,y:577,t:1527873177901};\\\", \\\"{x:1327,y:577,t:1527873178009};\\\", \\\"{x:1328,y:577,t:1527873178024};\\\", \\\"{x:1330,y:577,t:1527873178034};\\\", \\\"{x:1337,y:577,t:1527873178050};\\\", \\\"{x:1347,y:574,t:1527873178067};\\\", \\\"{x:1364,y:573,t:1527873178084};\\\", \\\"{x:1378,y:572,t:1527873178101};\\\", \\\"{x:1387,y:567,t:1527873178117};\\\", \\\"{x:1388,y:567,t:1527873178133};\\\", \\\"{x:1387,y:567,t:1527873178232};\\\", \\\"{x:1386,y:567,t:1527873178369};\\\", \\\"{x:1384,y:568,t:1527873178384};\\\", \\\"{x:1381,y:570,t:1527873178400};\\\", \\\"{x:1366,y:575,t:1527873178417};\\\", \\\"{x:1332,y:580,t:1527873178434};\\\", \\\"{x:1255,y:591,t:1527873178451};\\\", \\\"{x:1154,y:608,t:1527873178468};\\\", \\\"{x:1037,y:627,t:1527873178483};\\\", \\\"{x:915,y:645,t:1527873178503};\\\", \\\"{x:808,y:655,t:1527873178517};\\\", \\\"{x:746,y:663,t:1527873178533};\\\", \\\"{x:693,y:671,t:1527873178550};\\\", \\\"{x:668,y:678,t:1527873178568};\\\", \\\"{x:653,y:685,t:1527873178583};\\\", \\\"{x:638,y:695,t:1527873178601};\\\", \\\"{x:621,y:706,t:1527873178617};\\\", \\\"{x:601,y:715,t:1527873178633};\\\", \\\"{x:577,y:725,t:1527873178650};\\\", \\\"{x:550,y:737,t:1527873178669};\\\", \\\"{x:529,y:746,t:1527873178683};\\\", \\\"{x:514,y:757,t:1527873178700};\\\", \\\"{x:503,y:765,t:1527873178717};\\\", \\\"{x:492,y:771,t:1527873178733};\\\", \\\"{x:480,y:779,t:1527873178750};\\\", \\\"{x:462,y:794,t:1527873178767};\\\", \\\"{x:457,y:798,t:1527873178783};\\\", \\\"{x:456,y:799,t:1527873178799};\\\", \\\"{x:455,y:799,t:1527873178817};\\\", \\\"{x:454,y:800,t:1527873178833};\\\", \\\"{x:453,y:801,t:1527873178871};\\\", \\\"{x:452,y:801,t:1527873178928};\\\", \\\"{x:451,y:801,t:1527873178935};\\\", \\\"{x:450,y:800,t:1527873178951};\\\", \\\"{x:450,y:796,t:1527873178967};\\\", \\\"{x:450,y:793,t:1527873178983};\\\", \\\"{x:450,y:791,t:1527873178999};\\\", \\\"{x:450,y:787,t:1527873179017};\\\", \\\"{x:450,y:785,t:1527873179033};\\\", \\\"{x:450,y:784,t:1527873179050};\\\", \\\"{x:450,y:783,t:1527873179067};\\\", \\\"{x:450,y:782,t:1527873179084};\\\", \\\"{x:451,y:782,t:1527873179304};\\\", \\\"{x:452,y:782,t:1527873179319};\\\", \\\"{x:453,y:782,t:1527873179334};\\\", \\\"{x:454,y:782,t:1527873179350};\\\", \\\"{x:456,y:782,t:1527873179366};\\\", \\\"{x:458,y:782,t:1527873179384};\\\", \\\"{x:461,y:780,t:1527873179400};\\\", \\\"{x:471,y:771,t:1527873179417};\\\", \\\"{x:478,y:764,t:1527873179433};\\\", \\\"{x:481,y:760,t:1527873179450};\\\", \\\"{x:483,y:756,t:1527873179467};\\\", \\\"{x:484,y:755,t:1527873179484};\\\", \\\"{x:484,y:754,t:1527873179501};\\\", \\\"{x:484,y:753,t:1527873179517};\\\", \\\"{x:485,y:752,t:1527873179534};\\\", \\\"{x:488,y:748,t:1527873179551};\\\", \\\"{x:490,y:744,t:1527873179567};\\\", \\\"{x:491,y:742,t:1527873179583};\\\", \\\"{x:491,y:740,t:1527873179600};\\\", \\\"{x:492,y:739,t:1527873179623};\\\", \\\"{x:492,y:738,t:1527873179664};\\\" ] }, { \\\"rt\\\": 25225, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 396655, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-0-J -C -C -C -O -X -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:738,t:1527873181943};\\\", \\\"{x:494,y:741,t:1527873181954};\\\", \\\"{x:499,y:750,t:1527873181970};\\\", \\\"{x:509,y:762,t:1527873181989};\\\", \\\"{x:520,y:771,t:1527873182004};\\\", \\\"{x:538,y:786,t:1527873182019};\\\", \\\"{x:561,y:800,t:1527873182036};\\\", \\\"{x:592,y:812,t:1527873182053};\\\", \\\"{x:619,y:822,t:1527873182068};\\\", \\\"{x:648,y:829,t:1527873182086};\\\", \\\"{x:677,y:838,t:1527873182103};\\\", \\\"{x:693,y:843,t:1527873182119};\\\", \\\"{x:704,y:849,t:1527873182136};\\\", \\\"{x:710,y:854,t:1527873182153};\\\", \\\"{x:712,y:857,t:1527873182169};\\\", \\\"{x:712,y:856,t:1527873183008};\\\", \\\"{x:711,y:855,t:1527873183040};\\\", \\\"{x:709,y:854,t:1527873183056};\\\", \\\"{x:708,y:853,t:1527873183070};\\\", \\\"{x:705,y:852,t:1527873183087};\\\", \\\"{x:706,y:852,t:1527873183672};\\\", \\\"{x:710,y:852,t:1527873183687};\\\", \\\"{x:714,y:852,t:1527873183704};\\\", \\\"{x:722,y:854,t:1527873183721};\\\", \\\"{x:734,y:858,t:1527873183737};\\\", \\\"{x:746,y:864,t:1527873183754};\\\", \\\"{x:760,y:869,t:1527873183772};\\\", \\\"{x:780,y:875,t:1527873183788};\\\", \\\"{x:802,y:880,t:1527873183804};\\\", \\\"{x:829,y:888,t:1527873183822};\\\", \\\"{x:862,y:899,t:1527873183838};\\\", \\\"{x:893,y:907,t:1527873183855};\\\", \\\"{x:952,y:924,t:1527873183872};\\\", \\\"{x:988,y:935,t:1527873183888};\\\", \\\"{x:1015,y:941,t:1527873183904};\\\", \\\"{x:1039,y:949,t:1527873183921};\\\", \\\"{x:1056,y:954,t:1527873183938};\\\", \\\"{x:1063,y:957,t:1527873183955};\\\", \\\"{x:1065,y:959,t:1527873184946};\\\", \\\"{x:1068,y:959,t:1527873184960};\\\", \\\"{x:1069,y:959,t:1527873184973};\\\", \\\"{x:1073,y:959,t:1527873184988};\\\", \\\"{x:1079,y:959,t:1527873185006};\\\", \\\"{x:1086,y:960,t:1527873185023};\\\", \\\"{x:1089,y:960,t:1527873185039};\\\", \\\"{x:1094,y:962,t:1527873185056};\\\", \\\"{x:1096,y:962,t:1527873185073};\\\", \\\"{x:1098,y:962,t:1527873185088};\\\", \\\"{x:1102,y:962,t:1527873185105};\\\", \\\"{x:1104,y:962,t:1527873185123};\\\", \\\"{x:1108,y:962,t:1527873185138};\\\", \\\"{x:1110,y:962,t:1527873185156};\\\", \\\"{x:1115,y:962,t:1527873185172};\\\", \\\"{x:1120,y:962,t:1527873185189};\\\", \\\"{x:1126,y:962,t:1527873185206};\\\", \\\"{x:1133,y:962,t:1527873185223};\\\", \\\"{x:1142,y:961,t:1527873185238};\\\", \\\"{x:1152,y:959,t:1527873185256};\\\", \\\"{x:1160,y:958,t:1527873185273};\\\", \\\"{x:1168,y:957,t:1527873185289};\\\", \\\"{x:1176,y:956,t:1527873185306};\\\", \\\"{x:1184,y:954,t:1527873185323};\\\", \\\"{x:1190,y:954,t:1527873185339};\\\", \\\"{x:1199,y:953,t:1527873185355};\\\", \\\"{x:1207,y:953,t:1527873185373};\\\", \\\"{x:1218,y:952,t:1527873185389};\\\", \\\"{x:1228,y:951,t:1527873185406};\\\", \\\"{x:1237,y:949,t:1527873185423};\\\", \\\"{x:1249,y:949,t:1527873185440};\\\", \\\"{x:1253,y:949,t:1527873185455};\\\", \\\"{x:1257,y:949,t:1527873185472};\\\", \\\"{x:1260,y:949,t:1527873185490};\\\", \\\"{x:1261,y:949,t:1527873185505};\\\", \\\"{x:1264,y:949,t:1527873185523};\\\", \\\"{x:1266,y:950,t:1527873185540};\\\", \\\"{x:1269,y:952,t:1527873185555};\\\", \\\"{x:1271,y:952,t:1527873185573};\\\", \\\"{x:1274,y:954,t:1527873185589};\\\", \\\"{x:1275,y:954,t:1527873185608};\\\", \\\"{x:1276,y:955,t:1527873185623};\\\", \\\"{x:1275,y:955,t:1527873185873};\\\", \\\"{x:1271,y:955,t:1527873185890};\\\", \\\"{x:1266,y:954,t:1527873185907};\\\", \\\"{x:1257,y:949,t:1527873185922};\\\", \\\"{x:1243,y:942,t:1527873185939};\\\", \\\"{x:1223,y:932,t:1527873185957};\\\", \\\"{x:1192,y:916,t:1527873185973};\\\", \\\"{x:1152,y:894,t:1527873185990};\\\", \\\"{x:1118,y:878,t:1527873186007};\\\", \\\"{x:1099,y:870,t:1527873186022};\\\", \\\"{x:1091,y:864,t:1527873186039};\\\", \\\"{x:1091,y:863,t:1527873186056};\\\", \\\"{x:1091,y:861,t:1527873186073};\\\", \\\"{x:1095,y:858,t:1527873186090};\\\", \\\"{x:1098,y:857,t:1527873186107};\\\", \\\"{x:1103,y:854,t:1527873186123};\\\", \\\"{x:1108,y:851,t:1527873186140};\\\", \\\"{x:1112,y:851,t:1527873186157};\\\", \\\"{x:1114,y:849,t:1527873186174};\\\", \\\"{x:1116,y:848,t:1527873186190};\\\", \\\"{x:1117,y:847,t:1527873186206};\\\", \\\"{x:1119,y:846,t:1527873186224};\\\", \\\"{x:1122,y:844,t:1527873186239};\\\", \\\"{x:1124,y:843,t:1527873186257};\\\", \\\"{x:1125,y:843,t:1527873186274};\\\", \\\"{x:1127,y:841,t:1527873186290};\\\", \\\"{x:1129,y:841,t:1527873186359};\\\", \\\"{x:1131,y:841,t:1527873186375};\\\", \\\"{x:1132,y:841,t:1527873186389};\\\", \\\"{x:1133,y:842,t:1527873186406};\\\", \\\"{x:1138,y:848,t:1527873186423};\\\", \\\"{x:1144,y:854,t:1527873186439};\\\", \\\"{x:1152,y:862,t:1527873186456};\\\", \\\"{x:1160,y:872,t:1527873186473};\\\", \\\"{x:1168,y:881,t:1527873186489};\\\", \\\"{x:1179,y:888,t:1527873186506};\\\", \\\"{x:1184,y:892,t:1527873186523};\\\", \\\"{x:1193,y:898,t:1527873186539};\\\", \\\"{x:1199,y:901,t:1527873186556};\\\", \\\"{x:1203,y:904,t:1527873186574};\\\", \\\"{x:1208,y:907,t:1527873186589};\\\", \\\"{x:1212,y:910,t:1527873186606};\\\", \\\"{x:1215,y:912,t:1527873186623};\\\", \\\"{x:1218,y:914,t:1527873186640};\\\", \\\"{x:1219,y:915,t:1527873186656};\\\", \\\"{x:1220,y:916,t:1527873186673};\\\", \\\"{x:1220,y:917,t:1527873186691};\\\", \\\"{x:1220,y:919,t:1527873186711};\\\", \\\"{x:1220,y:920,t:1527873186735};\\\", \\\"{x:1220,y:922,t:1527873186760};\\\", \\\"{x:1220,y:923,t:1527873186792};\\\", \\\"{x:1219,y:923,t:1527873186808};\\\", \\\"{x:1219,y:924,t:1527873186824};\\\", \\\"{x:1218,y:925,t:1527873186840};\\\", \\\"{x:1217,y:925,t:1527873186857};\\\", \\\"{x:1216,y:926,t:1527873186896};\\\", \\\"{x:1217,y:926,t:1527873187168};\\\", \\\"{x:1218,y:925,t:1527873187200};\\\", \\\"{x:1218,y:924,t:1527873187216};\\\", \\\"{x:1219,y:923,t:1527873187232};\\\", \\\"{x:1220,y:921,t:1527873187248};\\\", \\\"{x:1220,y:920,t:1527873187258};\\\", \\\"{x:1220,y:917,t:1527873187274};\\\", \\\"{x:1220,y:913,t:1527873187291};\\\", \\\"{x:1221,y:909,t:1527873187307};\\\", \\\"{x:1221,y:902,t:1527873187323};\\\", \\\"{x:1221,y:896,t:1527873187340};\\\", \\\"{x:1220,y:887,t:1527873187357};\\\", \\\"{x:1216,y:875,t:1527873187374};\\\", \\\"{x:1214,y:865,t:1527873187390};\\\", \\\"{x:1213,y:854,t:1527873187407};\\\", \\\"{x:1211,y:843,t:1527873187423};\\\", \\\"{x:1210,y:829,t:1527873187441};\\\", \\\"{x:1207,y:817,t:1527873187458};\\\", \\\"{x:1206,y:803,t:1527873187473};\\\", \\\"{x:1205,y:794,t:1527873187490};\\\", \\\"{x:1203,y:784,t:1527873187507};\\\", \\\"{x:1201,y:771,t:1527873187523};\\\", \\\"{x:1198,y:757,t:1527873187540};\\\", \\\"{x:1193,y:745,t:1527873187557};\\\", \\\"{x:1189,y:736,t:1527873187574};\\\", \\\"{x:1185,y:730,t:1527873187590};\\\", \\\"{x:1173,y:719,t:1527873187607};\\\", \\\"{x:1165,y:710,t:1527873187624};\\\", \\\"{x:1157,y:703,t:1527873187641};\\\", \\\"{x:1154,y:699,t:1527873187657};\\\", \\\"{x:1152,y:695,t:1527873187674};\\\", \\\"{x:1149,y:692,t:1527873187691};\\\", \\\"{x:1148,y:689,t:1527873187708};\\\", \\\"{x:1148,y:686,t:1527873187724};\\\", \\\"{x:1148,y:681,t:1527873187740};\\\", \\\"{x:1145,y:677,t:1527873187757};\\\", \\\"{x:1145,y:672,t:1527873187774};\\\", \\\"{x:1145,y:668,t:1527873187791};\\\", \\\"{x:1145,y:662,t:1527873187807};\\\", \\\"{x:1145,y:657,t:1527873187824};\\\", \\\"{x:1145,y:652,t:1527873187841};\\\", \\\"{x:1145,y:647,t:1527873187857};\\\", \\\"{x:1145,y:640,t:1527873187875};\\\", \\\"{x:1146,y:633,t:1527873187891};\\\", \\\"{x:1146,y:629,t:1527873187907};\\\", \\\"{x:1146,y:626,t:1527873187924};\\\", \\\"{x:1147,y:624,t:1527873187941};\\\", \\\"{x:1148,y:624,t:1527873188120};\\\", \\\"{x:1148,y:625,t:1527873188128};\\\", \\\"{x:1149,y:625,t:1527873188192};\\\", \\\"{x:1150,y:625,t:1527873188281};\\\", \\\"{x:1152,y:625,t:1527873188292};\\\", \\\"{x:1161,y:626,t:1527873188308};\\\", \\\"{x:1175,y:626,t:1527873188325};\\\", \\\"{x:1191,y:626,t:1527873188343};\\\", \\\"{x:1214,y:626,t:1527873188358};\\\", \\\"{x:1240,y:627,t:1527873188375};\\\", \\\"{x:1285,y:627,t:1527873188392};\\\", \\\"{x:1317,y:627,t:1527873188409};\\\", \\\"{x:1354,y:627,t:1527873188425};\\\", \\\"{x:1391,y:627,t:1527873188442};\\\", \\\"{x:1418,y:627,t:1527873188459};\\\", \\\"{x:1445,y:627,t:1527873188476};\\\", \\\"{x:1464,y:627,t:1527873188493};\\\", \\\"{x:1475,y:627,t:1527873188508};\\\", \\\"{x:1480,y:627,t:1527873188524};\\\", \\\"{x:1478,y:627,t:1527873188864};\\\", \\\"{x:1477,y:628,t:1527873188887};\\\", \\\"{x:1476,y:628,t:1527873188896};\\\", \\\"{x:1475,y:629,t:1527873188909};\\\", \\\"{x:1474,y:629,t:1527873188926};\\\", \\\"{x:1472,y:630,t:1527873188942};\\\", \\\"{x:1471,y:630,t:1527873188958};\\\", \\\"{x:1470,y:631,t:1527873188984};\\\", \\\"{x:1469,y:632,t:1527873189000};\\\", \\\"{x:1468,y:632,t:1527873189016};\\\", \\\"{x:1467,y:632,t:1527873189296};\\\", \\\"{x:1466,y:632,t:1527873189312};\\\", \\\"{x:1465,y:632,t:1527873189328};\\\", \\\"{x:1464,y:632,t:1527873189376};\\\", \\\"{x:1463,y:632,t:1527873189393};\\\", \\\"{x:1462,y:632,t:1527873189409};\\\", \\\"{x:1462,y:633,t:1527873189426};\\\", \\\"{x:1461,y:633,t:1527873189609};\\\", \\\"{x:1460,y:633,t:1527873189626};\\\", \\\"{x:1459,y:633,t:1527873189648};\\\", \\\"{x:1458,y:633,t:1527873189672};\\\", \\\"{x:1457,y:633,t:1527873189680};\\\", \\\"{x:1456,y:633,t:1527873189693};\\\", \\\"{x:1454,y:633,t:1527873189709};\\\", \\\"{x:1453,y:634,t:1527873189726};\\\", \\\"{x:1451,y:635,t:1527873189743};\\\", \\\"{x:1447,y:635,t:1527873189760};\\\", \\\"{x:1443,y:635,t:1527873189776};\\\", \\\"{x:1439,y:634,t:1527873189793};\\\", \\\"{x:1434,y:634,t:1527873189810};\\\", \\\"{x:1431,y:633,t:1527873189826};\\\", \\\"{x:1430,y:633,t:1527873189843};\\\", \\\"{x:1429,y:633,t:1527873189860};\\\", \\\"{x:1428,y:633,t:1527873190232};\\\", \\\"{x:1428,y:632,t:1527873190243};\\\", \\\"{x:1429,y:632,t:1527873190259};\\\", \\\"{x:1429,y:631,t:1527873190277};\\\", \\\"{x:1430,y:631,t:1527873190328};\\\", \\\"{x:1431,y:631,t:1527873190407};\\\", \\\"{x:1431,y:630,t:1527873190431};\\\", \\\"{x:1432,y:630,t:1527873190455};\\\", \\\"{x:1433,y:630,t:1527873190479};\\\", \\\"{x:1434,y:630,t:1527873190493};\\\", \\\"{x:1435,y:630,t:1527873190519};\\\", \\\"{x:1436,y:630,t:1527873190535};\\\", \\\"{x:1437,y:630,t:1527873190551};\\\", \\\"{x:1438,y:630,t:1527873190575};\\\", \\\"{x:1439,y:630,t:1527873190583};\\\", \\\"{x:1440,y:630,t:1527873190593};\\\", \\\"{x:1442,y:630,t:1527873190610};\\\", \\\"{x:1443,y:630,t:1527873190735};\\\", \\\"{x:1443,y:631,t:1527873191840};\\\", \\\"{x:1443,y:632,t:1527873191847};\\\", \\\"{x:1442,y:634,t:1527873191873};\\\", \\\"{x:1441,y:635,t:1527873191880};\\\", \\\"{x:1439,y:637,t:1527873191894};\\\", \\\"{x:1436,y:640,t:1527873191910};\\\", \\\"{x:1432,y:645,t:1527873191927};\\\", \\\"{x:1430,y:650,t:1527873191945};\\\", \\\"{x:1427,y:653,t:1527873191960};\\\", \\\"{x:1422,y:659,t:1527873191978};\\\", \\\"{x:1412,y:667,t:1527873191995};\\\", \\\"{x:1405,y:672,t:1527873192010};\\\", \\\"{x:1402,y:679,t:1527873192027};\\\", \\\"{x:1398,y:682,t:1527873192044};\\\", \\\"{x:1395,y:686,t:1527873192061};\\\", \\\"{x:1393,y:689,t:1527873192078};\\\", \\\"{x:1389,y:694,t:1527873192095};\\\", \\\"{x:1387,y:697,t:1527873192110};\\\", \\\"{x:1382,y:699,t:1527873192127};\\\", \\\"{x:1381,y:700,t:1527873192144};\\\", \\\"{x:1380,y:700,t:1527873192160};\\\", \\\"{x:1378,y:701,t:1527873192178};\\\", \\\"{x:1377,y:701,t:1527873192195};\\\", \\\"{x:1375,y:702,t:1527873192211};\\\", \\\"{x:1373,y:702,t:1527873192228};\\\", \\\"{x:1371,y:702,t:1527873192245};\\\", \\\"{x:1368,y:702,t:1527873192261};\\\", \\\"{x:1365,y:702,t:1527873192278};\\\", \\\"{x:1362,y:702,t:1527873192295};\\\", \\\"{x:1361,y:702,t:1527873192311};\\\", \\\"{x:1360,y:702,t:1527873192528};\\\", \\\"{x:1359,y:702,t:1527873192545};\\\", \\\"{x:1358,y:702,t:1527873192680};\\\", \\\"{x:1361,y:702,t:1527873194416};\\\", \\\"{x:1366,y:704,t:1527873194430};\\\", \\\"{x:1380,y:713,t:1527873194446};\\\", \\\"{x:1413,y:732,t:1527873194463};\\\", \\\"{x:1467,y:763,t:1527873194480};\\\", \\\"{x:1485,y:772,t:1527873194497};\\\", \\\"{x:1495,y:776,t:1527873194514};\\\", \\\"{x:1497,y:776,t:1527873194530};\\\", \\\"{x:1499,y:776,t:1527873194546};\\\", \\\"{x:1500,y:776,t:1527873194564};\\\", \\\"{x:1502,y:777,t:1527873194580};\\\", \\\"{x:1503,y:777,t:1527873194597};\\\", \\\"{x:1506,y:777,t:1527873194613};\\\", \\\"{x:1510,y:778,t:1527873194630};\\\", \\\"{x:1512,y:778,t:1527873194647};\\\", \\\"{x:1513,y:778,t:1527873194663};\\\", \\\"{x:1514,y:778,t:1527873194680};\\\", \\\"{x:1515,y:778,t:1527873194768};\\\", \\\"{x:1515,y:777,t:1527873194784};\\\", \\\"{x:1516,y:774,t:1527873194797};\\\", \\\"{x:1516,y:772,t:1527873194813};\\\", \\\"{x:1517,y:771,t:1527873194830};\\\", \\\"{x:1517,y:769,t:1527873194856};\\\", \\\"{x:1517,y:768,t:1527873194888};\\\", \\\"{x:1517,y:766,t:1527873194913};\\\", \\\"{x:1517,y:765,t:1527873195064};\\\", \\\"{x:1516,y:765,t:1527873195344};\\\", \\\"{x:1514,y:765,t:1527873195352};\\\", \\\"{x:1512,y:767,t:1527873195364};\\\", \\\"{x:1510,y:774,t:1527873195381};\\\", \\\"{x:1505,y:783,t:1527873195397};\\\", \\\"{x:1500,y:793,t:1527873195414};\\\", \\\"{x:1496,y:805,t:1527873195432};\\\", \\\"{x:1495,y:808,t:1527873195448};\\\", \\\"{x:1492,y:815,t:1527873195463};\\\", \\\"{x:1490,y:818,t:1527873195481};\\\", \\\"{x:1487,y:824,t:1527873195497};\\\", \\\"{x:1483,y:827,t:1527873195515};\\\", \\\"{x:1482,y:828,t:1527873195531};\\\", \\\"{x:1481,y:828,t:1527873195552};\\\", \\\"{x:1478,y:829,t:1527873196696};\\\", \\\"{x:1470,y:829,t:1527873196705};\\\", \\\"{x:1459,y:829,t:1527873196715};\\\", \\\"{x:1415,y:829,t:1527873196731};\\\", \\\"{x:1324,y:822,t:1527873196748};\\\", \\\"{x:1215,y:802,t:1527873196765};\\\", \\\"{x:1118,y:788,t:1527873196783};\\\", \\\"{x:1046,y:778,t:1527873196799};\\\", \\\"{x:982,y:762,t:1527873196815};\\\", \\\"{x:908,y:742,t:1527873196832};\\\", \\\"{x:863,y:728,t:1527873196848};\\\", \\\"{x:816,y:708,t:1527873196865};\\\", \\\"{x:780,y:693,t:1527873196882};\\\", \\\"{x:753,y:682,t:1527873196899};\\\", \\\"{x:733,y:672,t:1527873196915};\\\", \\\"{x:713,y:660,t:1527873196932};\\\", \\\"{x:694,y:648,t:1527873196948};\\\", \\\"{x:670,y:633,t:1527873196965};\\\", \\\"{x:629,y:607,t:1527873196983};\\\", \\\"{x:588,y:590,t:1527873196998};\\\", \\\"{x:524,y:573,t:1527873197015};\\\", \\\"{x:480,y:561,t:1527873197032};\\\", \\\"{x:446,y:556,t:1527873197049};\\\", \\\"{x:429,y:554,t:1527873197065};\\\", \\\"{x:420,y:552,t:1527873197081};\\\", \\\"{x:414,y:550,t:1527873197099};\\\", \\\"{x:412,y:550,t:1527873197115};\\\", \\\"{x:408,y:550,t:1527873197132};\\\", \\\"{x:402,y:551,t:1527873197149};\\\", \\\"{x:395,y:553,t:1527873197166};\\\", \\\"{x:387,y:556,t:1527873197183};\\\", \\\"{x:368,y:560,t:1527873197199};\\\", \\\"{x:348,y:562,t:1527873197215};\\\", \\\"{x:323,y:565,t:1527873197232};\\\", \\\"{x:304,y:567,t:1527873197248};\\\", \\\"{x:293,y:568,t:1527873197266};\\\", \\\"{x:286,y:570,t:1527873197281};\\\", \\\"{x:281,y:572,t:1527873197298};\\\", \\\"{x:279,y:572,t:1527873197316};\\\", \\\"{x:275,y:574,t:1527873197331};\\\", \\\"{x:272,y:575,t:1527873197350};\\\", \\\"{x:269,y:577,t:1527873197365};\\\", \\\"{x:266,y:580,t:1527873197381};\\\", \\\"{x:262,y:582,t:1527873197398};\\\", \\\"{x:265,y:582,t:1527873197463};\\\", \\\"{x:273,y:582,t:1527873197471};\\\", \\\"{x:285,y:582,t:1527873197482};\\\", \\\"{x:339,y:582,t:1527873197499};\\\", \\\"{x:428,y:582,t:1527873197515};\\\", \\\"{x:536,y:582,t:1527873197533};\\\", \\\"{x:658,y:582,t:1527873197548};\\\", \\\"{x:753,y:582,t:1527873197567};\\\", \\\"{x:836,y:582,t:1527873197583};\\\", \\\"{x:857,y:582,t:1527873197599};\\\", \\\"{x:858,y:582,t:1527873197616};\\\", \\\"{x:859,y:582,t:1527873197633};\\\", \\\"{x:858,y:581,t:1527873197648};\\\", \\\"{x:851,y:576,t:1527873197666};\\\", \\\"{x:848,y:573,t:1527873197682};\\\", \\\"{x:845,y:570,t:1527873197699};\\\", \\\"{x:843,y:569,t:1527873197716};\\\", \\\"{x:843,y:567,t:1527873197733};\\\", \\\"{x:842,y:565,t:1527873197749};\\\", \\\"{x:841,y:563,t:1527873197765};\\\", \\\"{x:840,y:560,t:1527873197784};\\\", \\\"{x:840,y:558,t:1527873197798};\\\", \\\"{x:840,y:557,t:1527873197816};\\\", \\\"{x:840,y:554,t:1527873197833};\\\", \\\"{x:840,y:551,t:1527873197849};\\\", \\\"{x:840,y:550,t:1527873197895};\\\", \\\"{x:840,y:549,t:1527873197911};\\\", \\\"{x:840,y:548,t:1527873197919};\\\", \\\"{x:840,y:547,t:1527873197943};\\\", \\\"{x:840,y:548,t:1527873198040};\\\", \\\"{x:840,y:551,t:1527873198050};\\\", \\\"{x:840,y:558,t:1527873198067};\\\", \\\"{x:841,y:563,t:1527873198084};\\\", \\\"{x:842,y:567,t:1527873198100};\\\", \\\"{x:843,y:568,t:1527873198115};\\\", \\\"{x:844,y:570,t:1527873198133};\\\", \\\"{x:844,y:571,t:1527873198149};\\\", \\\"{x:844,y:572,t:1527873198166};\\\", \\\"{x:844,y:573,t:1527873198190};\\\", \\\"{x:844,y:574,t:1527873198487};\\\", \\\"{x:842,y:576,t:1527873198518};\\\", \\\"{x:840,y:577,t:1527873198535};\\\", \\\"{x:835,y:578,t:1527873198549};\\\", \\\"{x:806,y:587,t:1527873198567};\\\", \\\"{x:777,y:594,t:1527873198583};\\\", \\\"{x:760,y:599,t:1527873198600};\\\", \\\"{x:739,y:605,t:1527873198617};\\\", \\\"{x:719,y:610,t:1527873198635};\\\", \\\"{x:709,y:614,t:1527873198650};\\\", \\\"{x:699,y:615,t:1527873198666};\\\", \\\"{x:690,y:615,t:1527873198683};\\\", \\\"{x:684,y:615,t:1527873198700};\\\", \\\"{x:676,y:615,t:1527873198717};\\\", \\\"{x:670,y:615,t:1527873198733};\\\", \\\"{x:666,y:615,t:1527873198750};\\\", \\\"{x:662,y:615,t:1527873198767};\\\", \\\"{x:660,y:614,t:1527873198783};\\\", \\\"{x:656,y:613,t:1527873198800};\\\", \\\"{x:653,y:611,t:1527873198817};\\\", \\\"{x:652,y:611,t:1527873198834};\\\", \\\"{x:651,y:611,t:1527873198850};\\\", \\\"{x:649,y:610,t:1527873198888};\\\", \\\"{x:649,y:609,t:1527873198899};\\\", \\\"{x:644,y:607,t:1527873198917};\\\", \\\"{x:638,y:604,t:1527873198934};\\\", \\\"{x:632,y:602,t:1527873198951};\\\", \\\"{x:622,y:595,t:1527873198969};\\\", \\\"{x:619,y:593,t:1527873198983};\\\", \\\"{x:617,y:592,t:1527873199000};\\\", \\\"{x:615,y:591,t:1527873199016};\\\", \\\"{x:614,y:590,t:1527873199034};\\\", \\\"{x:612,y:588,t:1527873199051};\\\", \\\"{x:609,y:587,t:1527873199066};\\\", \\\"{x:608,y:585,t:1527873199084};\\\", \\\"{x:607,y:585,t:1527873199101};\\\", \\\"{x:606,y:585,t:1527873199116};\\\", \\\"{x:605,y:584,t:1527873199134};\\\", \\\"{x:613,y:584,t:1527873199822};\\\", \\\"{x:625,y:584,t:1527873199834};\\\", \\\"{x:660,y:584,t:1527873199852};\\\", \\\"{x:691,y:584,t:1527873199869};\\\", \\\"{x:747,y:591,t:1527873199885};\\\", \\\"{x:801,y:602,t:1527873199903};\\\", \\\"{x:895,y:617,t:1527873199918};\\\", \\\"{x:928,y:624,t:1527873199933};\\\", \\\"{x:1029,y:647,t:1527873199952};\\\", \\\"{x:1087,y:662,t:1527873199968};\\\", \\\"{x:1123,y:666,t:1527873199983};\\\", \\\"{x:1154,y:670,t:1527873200001};\\\", \\\"{x:1182,y:675,t:1527873200018};\\\", \\\"{x:1200,y:679,t:1527873200035};\\\", \\\"{x:1217,y:680,t:1527873200051};\\\", \\\"{x:1228,y:681,t:1527873200067};\\\", \\\"{x:1233,y:681,t:1527873200084};\\\", \\\"{x:1237,y:681,t:1527873200101};\\\", \\\"{x:1241,y:681,t:1527873200117};\\\", \\\"{x:1249,y:682,t:1527873200134};\\\", \\\"{x:1253,y:684,t:1527873200151};\\\", \\\"{x:1256,y:684,t:1527873200168};\\\", \\\"{x:1260,y:685,t:1527873200185};\\\", \\\"{x:1264,y:686,t:1527873200201};\\\", \\\"{x:1267,y:686,t:1527873200218};\\\", \\\"{x:1269,y:687,t:1527873200235};\\\", \\\"{x:1270,y:687,t:1527873200251};\\\", \\\"{x:1272,y:687,t:1527873200269};\\\", \\\"{x:1277,y:688,t:1527873200286};\\\", \\\"{x:1281,y:689,t:1527873200302};\\\", \\\"{x:1290,y:689,t:1527873200318};\\\", \\\"{x:1323,y:694,t:1527873200335};\\\", \\\"{x:1350,y:699,t:1527873200352};\\\", \\\"{x:1381,y:703,t:1527873200369};\\\", \\\"{x:1412,y:710,t:1527873200385};\\\", \\\"{x:1451,y:719,t:1527873200402};\\\", \\\"{x:1483,y:725,t:1527873200419};\\\", \\\"{x:1520,y:736,t:1527873200435};\\\", \\\"{x:1542,y:743,t:1527873200451};\\\", \\\"{x:1562,y:747,t:1527873200469};\\\", \\\"{x:1572,y:750,t:1527873200486};\\\", \\\"{x:1580,y:752,t:1527873200502};\\\", \\\"{x:1584,y:752,t:1527873200518};\\\", \\\"{x:1585,y:753,t:1527873200535};\\\", \\\"{x:1583,y:754,t:1527873200696};\\\", \\\"{x:1581,y:754,t:1527873200704};\\\", \\\"{x:1579,y:755,t:1527873200718};\\\", \\\"{x:1570,y:757,t:1527873200736};\\\", \\\"{x:1565,y:759,t:1527873200752};\\\", \\\"{x:1561,y:759,t:1527873200768};\\\", \\\"{x:1558,y:760,t:1527873200786};\\\", \\\"{x:1557,y:761,t:1527873200803};\\\", \\\"{x:1554,y:762,t:1527873200819};\\\", \\\"{x:1551,y:764,t:1527873200836};\\\", \\\"{x:1547,y:765,t:1527873200853};\\\", \\\"{x:1544,y:767,t:1527873200868};\\\", \\\"{x:1541,y:768,t:1527873200885};\\\", \\\"{x:1540,y:768,t:1527873200901};\\\", \\\"{x:1538,y:769,t:1527873200918};\\\", \\\"{x:1539,y:769,t:1527873201888};\\\", \\\"{x:1541,y:769,t:1527873201903};\\\", \\\"{x:1542,y:768,t:1527873201928};\\\", \\\"{x:1543,y:768,t:1527873201976};\\\", \\\"{x:1544,y:768,t:1527873201999};\\\", \\\"{x:1544,y:767,t:1527873202015};\\\", \\\"{x:1546,y:766,t:1527873202656};\\\", \\\"{x:1547,y:766,t:1527873202671};\\\", \\\"{x:1549,y:766,t:1527873202696};\\\", \\\"{x:1551,y:765,t:1527873202704};\\\", \\\"{x:1553,y:764,t:1527873202720};\\\", \\\"{x:1555,y:764,t:1527873202737};\\\", \\\"{x:1559,y:763,t:1527873202753};\\\", \\\"{x:1561,y:763,t:1527873202770};\\\", \\\"{x:1564,y:763,t:1527873202787};\\\", \\\"{x:1568,y:763,t:1527873202803};\\\", \\\"{x:1570,y:762,t:1527873202820};\\\", \\\"{x:1572,y:762,t:1527873202837};\\\", \\\"{x:1576,y:762,t:1527873202853};\\\", \\\"{x:1579,y:761,t:1527873202870};\\\", \\\"{x:1583,y:761,t:1527873202887};\\\", \\\"{x:1584,y:761,t:1527873202903};\\\", \\\"{x:1586,y:760,t:1527873203072};\\\", \\\"{x:1587,y:760,t:1527873203088};\\\", \\\"{x:1587,y:758,t:1527873203103};\\\", \\\"{x:1588,y:755,t:1527873203120};\\\", \\\"{x:1588,y:753,t:1527873203137};\\\", \\\"{x:1588,y:752,t:1527873203155};\\\", \\\"{x:1588,y:751,t:1527873203200};\\\", \\\"{x:1589,y:751,t:1527873203224};\\\", \\\"{x:1589,y:750,t:1527873203239};\\\", \\\"{x:1590,y:750,t:1527873203256};\\\", \\\"{x:1591,y:749,t:1527873203279};\\\", \\\"{x:1592,y:748,t:1527873203360};\\\", \\\"{x:1594,y:748,t:1527873203392};\\\", \\\"{x:1595,y:748,t:1527873203404};\\\", \\\"{x:1598,y:748,t:1527873203421};\\\", \\\"{x:1602,y:748,t:1527873203438};\\\", \\\"{x:1605,y:748,t:1527873203455};\\\", \\\"{x:1607,y:747,t:1527873203471};\\\", \\\"{x:1609,y:747,t:1527873203487};\\\", \\\"{x:1610,y:747,t:1527873203505};\\\", \\\"{x:1612,y:747,t:1527873203544};\\\", \\\"{x:1613,y:746,t:1527873203554};\\\", \\\"{x:1614,y:744,t:1527873203572};\\\", \\\"{x:1616,y:743,t:1527873203587};\\\", \\\"{x:1617,y:742,t:1527873203604};\\\", \\\"{x:1617,y:740,t:1527873203622};\\\", \\\"{x:1618,y:739,t:1527873203640};\\\", \\\"{x:1619,y:739,t:1527873203654};\\\", \\\"{x:1619,y:738,t:1527873203696};\\\", \\\"{x:1619,y:737,t:1527873203712};\\\", \\\"{x:1619,y:736,t:1527873203727};\\\", \\\"{x:1619,y:734,t:1527873203744};\\\", \\\"{x:1618,y:733,t:1527873203754};\\\", \\\"{x:1618,y:730,t:1527873203771};\\\", \\\"{x:1616,y:728,t:1527873203787};\\\", \\\"{x:1616,y:727,t:1527873203804};\\\", \\\"{x:1616,y:726,t:1527873203821};\\\", \\\"{x:1615,y:725,t:1527873203837};\\\", \\\"{x:1615,y:723,t:1527873203854};\\\", \\\"{x:1614,y:723,t:1527873203983};\\\", \\\"{x:1612,y:723,t:1527873204624};\\\", \\\"{x:1610,y:725,t:1527873204639};\\\", \\\"{x:1597,y:739,t:1527873204655};\\\", \\\"{x:1581,y:751,t:1527873204670};\\\", \\\"{x:1562,y:765,t:1527873204688};\\\", \\\"{x:1529,y:781,t:1527873204705};\\\", \\\"{x:1481,y:805,t:1527873204721};\\\", \\\"{x:1427,y:833,t:1527873204738};\\\", \\\"{x:1385,y:867,t:1527873204754};\\\", \\\"{x:1331,y:899,t:1527873204771};\\\", \\\"{x:1277,y:937,t:1527873204788};\\\", \\\"{x:1229,y:963,t:1527873204805};\\\", \\\"{x:1191,y:985,t:1527873204822};\\\", \\\"{x:1155,y:1010,t:1527873204838};\\\", \\\"{x:1121,y:1034,t:1527873204855};\\\", \\\"{x:1102,y:1044,t:1527873204872};\\\", \\\"{x:1089,y:1050,t:1527873204888};\\\", \\\"{x:1076,y:1052,t:1527873204905};\\\", \\\"{x:1063,y:1052,t:1527873204921};\\\", \\\"{x:1049,y:1052,t:1527873204938};\\\", \\\"{x:1030,y:1052,t:1527873204955};\\\", \\\"{x:1008,y:1052,t:1527873204972};\\\", \\\"{x:995,y:1052,t:1527873204988};\\\", \\\"{x:989,y:1052,t:1527873205006};\\\", \\\"{x:988,y:1052,t:1527873205031};\\\", \\\"{x:988,y:1050,t:1527873205048};\\\", \\\"{x:988,y:1048,t:1527873205055};\\\", \\\"{x:988,y:1046,t:1527873205072};\\\", \\\"{x:987,y:1042,t:1527873205089};\\\", \\\"{x:983,y:1037,t:1527873205106};\\\", \\\"{x:977,y:1031,t:1527873205123};\\\", \\\"{x:970,y:1023,t:1527873205138};\\\", \\\"{x:949,y:1000,t:1527873205155};\\\", \\\"{x:911,y:956,t:1527873205172};\\\", \\\"{x:856,y:904,t:1527873205188};\\\", \\\"{x:798,y:855,t:1527873205205};\\\", \\\"{x:740,y:806,t:1527873205222};\\\", \\\"{x:670,y:753,t:1527873205238};\\\", \\\"{x:569,y:668,t:1527873205255};\\\", \\\"{x:509,y:635,t:1527873205272};\\\", \\\"{x:476,y:620,t:1527873205290};\\\", \\\"{x:460,y:614,t:1527873205304};\\\", \\\"{x:453,y:611,t:1527873205321};\\\", \\\"{x:452,y:610,t:1527873205339};\\\", \\\"{x:451,y:610,t:1527873205354};\\\", \\\"{x:449,y:611,t:1527873205372};\\\", \\\"{x:449,y:621,t:1527873205389};\\\", \\\"{x:449,y:629,t:1527873205404};\\\", \\\"{x:449,y:635,t:1527873205423};\\\", \\\"{x:449,y:640,t:1527873205439};\\\", \\\"{x:449,y:644,t:1527873205454};\\\", \\\"{x:451,y:650,t:1527873205471};\\\", \\\"{x:455,y:660,t:1527873205488};\\\", \\\"{x:460,y:666,t:1527873205505};\\\", \\\"{x:464,y:670,t:1527873205524};\\\", \\\"{x:468,y:675,t:1527873205539};\\\", \\\"{x:473,y:681,t:1527873205555};\\\", \\\"{x:476,y:684,t:1527873205572};\\\", \\\"{x:479,y:688,t:1527873205589};\\\", \\\"{x:480,y:689,t:1527873205606};\\\", \\\"{x:483,y:696,t:1527873205623};\\\", \\\"{x:486,y:707,t:1527873205639};\\\", \\\"{x:487,y:710,t:1527873205656};\\\", \\\"{x:488,y:712,t:1527873205673};\\\", \\\"{x:488,y:713,t:1527873205689};\\\", \\\"{x:488,y:715,t:1527873205736};\\\", \\\"{x:489,y:716,t:1527873205832};\\\", \\\"{x:490,y:717,t:1527873205840};\\\", \\\"{x:490,y:718,t:1527873205856};\\\", \\\"{x:490,y:719,t:1527873205912};\\\", \\\"{x:490,y:721,t:1527873205961};\\\", \\\"{x:490,y:722,t:1527873205973};\\\", \\\"{x:490,y:723,t:1527873205989};\\\", \\\"{x:490,y:726,t:1527873206006};\\\", \\\"{x:490,y:729,t:1527873206023};\\\", \\\"{x:491,y:730,t:1527873206039};\\\" ] }, { \\\"rt\\\": 55031, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 452880, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -B -F -F -G -C -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:731,t:1527873208360};\\\", \\\"{x:496,y:737,t:1527873208375};\\\", \\\"{x:527,y:752,t:1527873208391};\\\", \\\"{x:558,y:765,t:1527873208409};\\\", \\\"{x:599,y:779,t:1527873208424};\\\", \\\"{x:644,y:794,t:1527873208441};\\\", \\\"{x:691,y:805,t:1527873208458};\\\", \\\"{x:728,y:819,t:1527873208474};\\\", \\\"{x:771,y:832,t:1527873208491};\\\", \\\"{x:805,y:842,t:1527873208508};\\\", \\\"{x:833,y:848,t:1527873208524};\\\", \\\"{x:851,y:851,t:1527873208541};\\\", \\\"{x:865,y:853,t:1527873208558};\\\", \\\"{x:877,y:854,t:1527873208574};\\\", \\\"{x:880,y:855,t:1527873208591};\\\", \\\"{x:883,y:856,t:1527873208608};\\\", \\\"{x:887,y:858,t:1527873208625};\\\", \\\"{x:889,y:858,t:1527873208641};\\\", \\\"{x:890,y:858,t:1527873208658};\\\", \\\"{x:892,y:858,t:1527873209494};\\\", \\\"{x:893,y:858,t:1527873209509};\\\", \\\"{x:894,y:858,t:1527873209525};\\\", \\\"{x:898,y:861,t:1527873209542};\\\", \\\"{x:900,y:861,t:1527873209559};\\\", \\\"{x:902,y:861,t:1527873209575};\\\", \\\"{x:904,y:861,t:1527873209592};\\\", \\\"{x:907,y:861,t:1527873209609};\\\", \\\"{x:910,y:861,t:1527873209638};\\\", \\\"{x:912,y:862,t:1527873209647};\\\", \\\"{x:913,y:862,t:1527873209658};\\\", \\\"{x:918,y:862,t:1527873209675};\\\", \\\"{x:921,y:862,t:1527873209692};\\\", \\\"{x:926,y:862,t:1527873209708};\\\", \\\"{x:932,y:862,t:1527873209725};\\\", \\\"{x:941,y:862,t:1527873209742};\\\", \\\"{x:961,y:866,t:1527873209759};\\\", \\\"{x:979,y:868,t:1527873209774};\\\", \\\"{x:1000,y:868,t:1527873209792};\\\", \\\"{x:1024,y:868,t:1527873209809};\\\", \\\"{x:1058,y:868,t:1527873209825};\\\", \\\"{x:1102,y:868,t:1527873209842};\\\", \\\"{x:1150,y:862,t:1527873209859};\\\", \\\"{x:1210,y:848,t:1527873209875};\\\", \\\"{x:1269,y:840,t:1527873209892};\\\", \\\"{x:1339,y:830,t:1527873209910};\\\", \\\"{x:1395,y:814,t:1527873209926};\\\", \\\"{x:1433,y:798,t:1527873209943};\\\", \\\"{x:1441,y:794,t:1527873209960};\\\", \\\"{x:1441,y:793,t:1527873210600};\\\", \\\"{x:1439,y:793,t:1527873210616};\\\", \\\"{x:1438,y:793,t:1527873210632};\\\", \\\"{x:1437,y:792,t:1527873210644};\\\", \\\"{x:1436,y:791,t:1527873210660};\\\", \\\"{x:1435,y:790,t:1527873210677};\\\", \\\"{x:1434,y:790,t:1527873210694};\\\", \\\"{x:1433,y:790,t:1527873210710};\\\", \\\"{x:1431,y:788,t:1527873210727};\\\", \\\"{x:1431,y:787,t:1527873210767};\\\", \\\"{x:1431,y:786,t:1527873210777};\\\", \\\"{x:1430,y:785,t:1527873210794};\\\", \\\"{x:1429,y:784,t:1527873210811};\\\", \\\"{x:1428,y:783,t:1527873210826};\\\", \\\"{x:1428,y:782,t:1527873210848};\\\", \\\"{x:1428,y:781,t:1527873210872};\\\", \\\"{x:1428,y:780,t:1527873210888};\\\", \\\"{x:1428,y:779,t:1527873210904};\\\", \\\"{x:1428,y:778,t:1527873210919};\\\", \\\"{x:1427,y:778,t:1527873210928};\\\", \\\"{x:1427,y:777,t:1527873210944};\\\", \\\"{x:1426,y:776,t:1527873210961};\\\", \\\"{x:1426,y:774,t:1527873210977};\\\", \\\"{x:1425,y:773,t:1527873210994};\\\", \\\"{x:1425,y:770,t:1527873211010};\\\", \\\"{x:1424,y:769,t:1527873211027};\\\", \\\"{x:1422,y:767,t:1527873211044};\\\", \\\"{x:1422,y:766,t:1527873211061};\\\", \\\"{x:1421,y:765,t:1527873211077};\\\", \\\"{x:1421,y:763,t:1527873211094};\\\", \\\"{x:1419,y:759,t:1527873211111};\\\", \\\"{x:1419,y:756,t:1527873211127};\\\", \\\"{x:1418,y:751,t:1527873211144};\\\", \\\"{x:1416,y:748,t:1527873211160};\\\", \\\"{x:1414,y:743,t:1527873211177};\\\", \\\"{x:1414,y:738,t:1527873211194};\\\", \\\"{x:1414,y:735,t:1527873211211};\\\", \\\"{x:1414,y:733,t:1527873211228};\\\", \\\"{x:1414,y:731,t:1527873211244};\\\", \\\"{x:1414,y:729,t:1527873211264};\\\", \\\"{x:1414,y:728,t:1527873211277};\\\", \\\"{x:1414,y:725,t:1527873211294};\\\", \\\"{x:1415,y:724,t:1527873211311};\\\", \\\"{x:1415,y:722,t:1527873211326};\\\", \\\"{x:1415,y:721,t:1527873212288};\\\", \\\"{x:1415,y:717,t:1527873212295};\\\", \\\"{x:1415,y:707,t:1527873212311};\\\", \\\"{x:1413,y:694,t:1527873212328};\\\", \\\"{x:1407,y:678,t:1527873212345};\\\", \\\"{x:1403,y:669,t:1527873212362};\\\", \\\"{x:1398,y:660,t:1527873212378};\\\", \\\"{x:1395,y:655,t:1527873212395};\\\", \\\"{x:1393,y:650,t:1527873212411};\\\", \\\"{x:1390,y:647,t:1527873212428};\\\", \\\"{x:1387,y:643,t:1527873212445};\\\", \\\"{x:1382,y:638,t:1527873212462};\\\", \\\"{x:1375,y:635,t:1527873212478};\\\", \\\"{x:1363,y:630,t:1527873212495};\\\", \\\"{x:1356,y:627,t:1527873212511};\\\", \\\"{x:1354,y:625,t:1527873212528};\\\", \\\"{x:1353,y:625,t:1527873212544};\\\", \\\"{x:1352,y:623,t:1527873212562};\\\", \\\"{x:1351,y:623,t:1527873212579};\\\", \\\"{x:1351,y:622,t:1527873212595};\\\", \\\"{x:1351,y:621,t:1527873212612};\\\", \\\"{x:1351,y:620,t:1527873212630};\\\", \\\"{x:1351,y:619,t:1527873212952};\\\", \\\"{x:1351,y:618,t:1527873212991};\\\", \\\"{x:1351,y:617,t:1527873212999};\\\", \\\"{x:1352,y:617,t:1527873213032};\\\", \\\"{x:1353,y:616,t:1527873213063};\\\", \\\"{x:1354,y:616,t:1527873213079};\\\", \\\"{x:1356,y:615,t:1527873213096};\\\", \\\"{x:1357,y:615,t:1527873213112};\\\", \\\"{x:1358,y:614,t:1527873213129};\\\", \\\"{x:1360,y:614,t:1527873213167};\\\", \\\"{x:1361,y:614,t:1527873213184};\\\", \\\"{x:1363,y:614,t:1527873213200};\\\", \\\"{x:1364,y:614,t:1527873213215};\\\", \\\"{x:1366,y:614,t:1527873213229};\\\", \\\"{x:1367,y:614,t:1527873213245};\\\", \\\"{x:1368,y:613,t:1527873213263};\\\", \\\"{x:1369,y:613,t:1527873213279};\\\", \\\"{x:1372,y:611,t:1527873213295};\\\", \\\"{x:1374,y:610,t:1527873213312};\\\", \\\"{x:1375,y:610,t:1527873213335};\\\", \\\"{x:1376,y:609,t:1527873213345};\\\", \\\"{x:1377,y:608,t:1527873213361};\\\", \\\"{x:1377,y:607,t:1527873213378};\\\", \\\"{x:1377,y:606,t:1527873213423};\\\", \\\"{x:1377,y:605,t:1527873213439};\\\", \\\"{x:1377,y:603,t:1527873213447};\\\", \\\"{x:1375,y:602,t:1527873213462};\\\", \\\"{x:1364,y:597,t:1527873213479};\\\", \\\"{x:1339,y:589,t:1527873213496};\\\", \\\"{x:1321,y:585,t:1527873213512};\\\", \\\"{x:1308,y:581,t:1527873213528};\\\", \\\"{x:1300,y:577,t:1527873213546};\\\", \\\"{x:1296,y:576,t:1527873213563};\\\", \\\"{x:1294,y:575,t:1527873213579};\\\", \\\"{x:1294,y:574,t:1527873213596};\\\", \\\"{x:1292,y:572,t:1527873213613};\\\", \\\"{x:1290,y:570,t:1527873213629};\\\", \\\"{x:1288,y:569,t:1527873213645};\\\", \\\"{x:1286,y:568,t:1527873213663};\\\", \\\"{x:1284,y:566,t:1527873213681};\\\", \\\"{x:1283,y:564,t:1527873213695};\\\", \\\"{x:1283,y:562,t:1527873213712};\\\", \\\"{x:1283,y:561,t:1527873213728};\\\", \\\"{x:1283,y:559,t:1527873213745};\\\", \\\"{x:1286,y:557,t:1527873213763};\\\", \\\"{x:1290,y:556,t:1527873213778};\\\", \\\"{x:1293,y:554,t:1527873213795};\\\", \\\"{x:1298,y:553,t:1527873213812};\\\", \\\"{x:1299,y:553,t:1527873213829};\\\", \\\"{x:1301,y:553,t:1527873213845};\\\", \\\"{x:1302,y:553,t:1527873213944};\\\", \\\"{x:1303,y:553,t:1527873214192};\\\", \\\"{x:1304,y:553,t:1527873214223};\\\", \\\"{x:1305,y:553,t:1527873214297};\\\", \\\"{x:1306,y:553,t:1527873214313};\\\", \\\"{x:1307,y:553,t:1527873214330};\\\", \\\"{x:1308,y:553,t:1527873214408};\\\", \\\"{x:1309,y:554,t:1527873216383};\\\", \\\"{x:1310,y:555,t:1527873216398};\\\", \\\"{x:1318,y:564,t:1527873216416};\\\", \\\"{x:1323,y:569,t:1527873216431};\\\", \\\"{x:1332,y:579,t:1527873216448};\\\", \\\"{x:1344,y:596,t:1527873216465};\\\", \\\"{x:1355,y:611,t:1527873216481};\\\", \\\"{x:1362,y:626,t:1527873216498};\\\", \\\"{x:1367,y:644,t:1527873216515};\\\", \\\"{x:1373,y:665,t:1527873216532};\\\", \\\"{x:1377,y:682,t:1527873216548};\\\", \\\"{x:1380,y:698,t:1527873216565};\\\", \\\"{x:1380,y:706,t:1527873216581};\\\", \\\"{x:1380,y:713,t:1527873216598};\\\", \\\"{x:1378,y:720,t:1527873216616};\\\", \\\"{x:1368,y:730,t:1527873216632};\\\", \\\"{x:1362,y:736,t:1527873216648};\\\", \\\"{x:1354,y:745,t:1527873216665};\\\", \\\"{x:1348,y:753,t:1527873216682};\\\", \\\"{x:1342,y:759,t:1527873216700};\\\", \\\"{x:1339,y:762,t:1527873216715};\\\", \\\"{x:1338,y:764,t:1527873216732};\\\", \\\"{x:1339,y:763,t:1527873217343};\\\", \\\"{x:1340,y:763,t:1527873217382};\\\", \\\"{x:1341,y:763,t:1527873217447};\\\", \\\"{x:1342,y:763,t:1527873217471};\\\", \\\"{x:1343,y:763,t:1527873217499};\\\", \\\"{x:1344,y:763,t:1527873217535};\\\", \\\"{x:1343,y:763,t:1527873220791};\\\", \\\"{x:1342,y:763,t:1527873220801};\\\", \\\"{x:1339,y:763,t:1527873220819};\\\", \\\"{x:1334,y:763,t:1527873220835};\\\", \\\"{x:1328,y:762,t:1527873220851};\\\", \\\"{x:1319,y:758,t:1527873220868};\\\", \\\"{x:1313,y:756,t:1527873220886};\\\", \\\"{x:1310,y:754,t:1527873220901};\\\", \\\"{x:1309,y:754,t:1527873220928};\\\", \\\"{x:1309,y:752,t:1527873221111};\\\", \\\"{x:1309,y:750,t:1527873221126};\\\", \\\"{x:1310,y:749,t:1527873221134};\\\", \\\"{x:1310,y:747,t:1527873221151};\\\", \\\"{x:1312,y:744,t:1527873221168};\\\", \\\"{x:1316,y:739,t:1527873221185};\\\", \\\"{x:1317,y:734,t:1527873221201};\\\", \\\"{x:1319,y:729,t:1527873221217};\\\", \\\"{x:1321,y:725,t:1527873221234};\\\", \\\"{x:1323,y:721,t:1527873221251};\\\", \\\"{x:1324,y:719,t:1527873221268};\\\", \\\"{x:1324,y:717,t:1527873221285};\\\", \\\"{x:1324,y:716,t:1527873221301};\\\", \\\"{x:1325,y:714,t:1527873221319};\\\", \\\"{x:1326,y:713,t:1527873221335};\\\", \\\"{x:1327,y:712,t:1527873221351};\\\", \\\"{x:1328,y:712,t:1527873221369};\\\", \\\"{x:1329,y:710,t:1527873221385};\\\", \\\"{x:1330,y:709,t:1527873221401};\\\", \\\"{x:1330,y:708,t:1527873221419};\\\", \\\"{x:1331,y:708,t:1527873221434};\\\", \\\"{x:1332,y:708,t:1527873221451};\\\", \\\"{x:1333,y:707,t:1527873221469};\\\", \\\"{x:1335,y:706,t:1527873221486};\\\", \\\"{x:1335,y:705,t:1527873221503};\\\", \\\"{x:1336,y:705,t:1527873221519};\\\", \\\"{x:1336,y:704,t:1527873221534};\\\", \\\"{x:1337,y:704,t:1527873221558};\\\", \\\"{x:1338,y:703,t:1527873221568};\\\", \\\"{x:1338,y:702,t:1527873221585};\\\", \\\"{x:1339,y:702,t:1527873221607};\\\", \\\"{x:1341,y:700,t:1527873221623};\\\", \\\"{x:1342,y:699,t:1527873221663};\\\", \\\"{x:1343,y:699,t:1527873221713};\\\", \\\"{x:1343,y:698,t:1527873221719};\\\", \\\"{x:1343,y:697,t:1527873221735};\\\", \\\"{x:1345,y:696,t:1527873224504};\\\", \\\"{x:1346,y:694,t:1527873224521};\\\", \\\"{x:1348,y:690,t:1527873224539};\\\", \\\"{x:1349,y:687,t:1527873224554};\\\", \\\"{x:1351,y:685,t:1527873224572};\\\", \\\"{x:1351,y:684,t:1527873224588};\\\", \\\"{x:1352,y:682,t:1527873224604};\\\", \\\"{x:1353,y:680,t:1527873224621};\\\", \\\"{x:1354,y:678,t:1527873224639};\\\", \\\"{x:1354,y:676,t:1527873224655};\\\", \\\"{x:1356,y:673,t:1527873224671};\\\", \\\"{x:1359,y:668,t:1527873224689};\\\", \\\"{x:1361,y:665,t:1527873224705};\\\", \\\"{x:1364,y:659,t:1527873224722};\\\", \\\"{x:1367,y:656,t:1527873224738};\\\", \\\"{x:1369,y:650,t:1527873224755};\\\", \\\"{x:1371,y:646,t:1527873224771};\\\", \\\"{x:1374,y:642,t:1527873224788};\\\", \\\"{x:1375,y:640,t:1527873224804};\\\", \\\"{x:1377,y:639,t:1527873224822};\\\", \\\"{x:1377,y:638,t:1527873224839};\\\", \\\"{x:1377,y:637,t:1527873224855};\\\", \\\"{x:1378,y:637,t:1527873224872};\\\", \\\"{x:1378,y:636,t:1527873224896};\\\", \\\"{x:1378,y:635,t:1527873224905};\\\", \\\"{x:1378,y:634,t:1527873224922};\\\", \\\"{x:1379,y:633,t:1527873224937};\\\", \\\"{x:1379,y:632,t:1527873224955};\\\", \\\"{x:1380,y:631,t:1527873224970};\\\", \\\"{x:1381,y:629,t:1527873224988};\\\", \\\"{x:1381,y:628,t:1527873225004};\\\", \\\"{x:1381,y:627,t:1527873225021};\\\", \\\"{x:1383,y:626,t:1527873225038};\\\", \\\"{x:1383,y:624,t:1527873225054};\\\", \\\"{x:1384,y:621,t:1527873225070};\\\", \\\"{x:1385,y:620,t:1527873225095};\\\", \\\"{x:1386,y:620,t:1527873225105};\\\", \\\"{x:1386,y:618,t:1527873225121};\\\", \\\"{x:1387,y:617,t:1527873225138};\\\", \\\"{x:1388,y:616,t:1527873225155};\\\", \\\"{x:1390,y:613,t:1527873225172};\\\", \\\"{x:1391,y:611,t:1527873225188};\\\", \\\"{x:1391,y:610,t:1527873225205};\\\", \\\"{x:1394,y:607,t:1527873225221};\\\", \\\"{x:1395,y:605,t:1527873225239};\\\", \\\"{x:1396,y:602,t:1527873225255};\\\", \\\"{x:1398,y:601,t:1527873225272};\\\", \\\"{x:1399,y:598,t:1527873225288};\\\", \\\"{x:1400,y:596,t:1527873225305};\\\", \\\"{x:1401,y:595,t:1527873225322};\\\", \\\"{x:1402,y:593,t:1527873225342};\\\", \\\"{x:1403,y:593,t:1527873225358};\\\", \\\"{x:1403,y:592,t:1527873225374};\\\", \\\"{x:1403,y:591,t:1527873225387};\\\", \\\"{x:1404,y:590,t:1527873225404};\\\", \\\"{x:1405,y:588,t:1527873225422};\\\", \\\"{x:1406,y:587,t:1527873225438};\\\", \\\"{x:1406,y:586,t:1527873225454};\\\", \\\"{x:1407,y:585,t:1527873225472};\\\", \\\"{x:1408,y:584,t:1527873225488};\\\", \\\"{x:1409,y:583,t:1527873225505};\\\", \\\"{x:1409,y:582,t:1527873225522};\\\", \\\"{x:1410,y:580,t:1527873225538};\\\", \\\"{x:1411,y:578,t:1527873225555};\\\", \\\"{x:1412,y:576,t:1527873225575};\\\", \\\"{x:1413,y:575,t:1527873225607};\\\", \\\"{x:1413,y:574,t:1527873225622};\\\", \\\"{x:1413,y:571,t:1527873225639};\\\", \\\"{x:1415,y:568,t:1527873225656};\\\", \\\"{x:1416,y:567,t:1527873225672};\\\", \\\"{x:1416,y:566,t:1527873225688};\\\", \\\"{x:1416,y:565,t:1527873225706};\\\", \\\"{x:1416,y:564,t:1527873225723};\\\", \\\"{x:1411,y:564,t:1527873248219};\\\", \\\"{x:1396,y:564,t:1527873248228};\\\", \\\"{x:1342,y:564,t:1527873248244};\\\", \\\"{x:1234,y:564,t:1527873248260};\\\", \\\"{x:1096,y:564,t:1527873248277};\\\", \\\"{x:935,y:564,t:1527873248295};\\\", \\\"{x:797,y:564,t:1527873248310};\\\", \\\"{x:689,y:564,t:1527873248326};\\\", \\\"{x:597,y:564,t:1527873248344};\\\", \\\"{x:542,y:564,t:1527873248360};\\\", \\\"{x:499,y:564,t:1527873248376};\\\", \\\"{x:462,y:567,t:1527873248394};\\\", \\\"{x:457,y:570,t:1527873248410};\\\", \\\"{x:456,y:571,t:1527873248427};\\\", \\\"{x:455,y:573,t:1527873248444};\\\", \\\"{x:455,y:575,t:1527873248460};\\\", \\\"{x:455,y:576,t:1527873248477};\\\", \\\"{x:455,y:578,t:1527873248494};\\\", \\\"{x:455,y:579,t:1527873248510};\\\", \\\"{x:455,y:581,t:1527873248527};\\\", \\\"{x:454,y:581,t:1527873248626};\\\", \\\"{x:452,y:581,t:1527873248644};\\\", \\\"{x:444,y:581,t:1527873248661};\\\", \\\"{x:430,y:577,t:1527873248677};\\\", \\\"{x:416,y:576,t:1527873248694};\\\", \\\"{x:394,y:575,t:1527873248711};\\\", \\\"{x:375,y:574,t:1527873248727};\\\", \\\"{x:350,y:574,t:1527873248746};\\\", \\\"{x:338,y:574,t:1527873248760};\\\", \\\"{x:332,y:574,t:1527873248777};\\\", \\\"{x:326,y:574,t:1527873248793};\\\", \\\"{x:318,y:577,t:1527873248810};\\\", \\\"{x:313,y:578,t:1527873248827};\\\", \\\"{x:306,y:578,t:1527873248843};\\\", \\\"{x:300,y:579,t:1527873248860};\\\", \\\"{x:291,y:580,t:1527873248876};\\\", \\\"{x:284,y:581,t:1527873248893};\\\", \\\"{x:280,y:582,t:1527873248910};\\\", \\\"{x:279,y:582,t:1527873248926};\\\", \\\"{x:277,y:582,t:1527873248943};\\\", \\\"{x:274,y:582,t:1527873248960};\\\", \\\"{x:270,y:582,t:1527873248977};\\\", \\\"{x:258,y:582,t:1527873248993};\\\", \\\"{x:245,y:582,t:1527873249011};\\\", \\\"{x:236,y:579,t:1527873249028};\\\", \\\"{x:233,y:578,t:1527873249045};\\\", \\\"{x:229,y:578,t:1527873249061};\\\", \\\"{x:228,y:576,t:1527873249078};\\\", \\\"{x:224,y:575,t:1527873249095};\\\", \\\"{x:218,y:570,t:1527873249113};\\\", \\\"{x:207,y:556,t:1527873249128};\\\", \\\"{x:191,y:537,t:1527873249146};\\\", \\\"{x:189,y:535,t:1527873249161};\\\", \\\"{x:186,y:531,t:1527873249178};\\\", \\\"{x:187,y:530,t:1527873249258};\\\", \\\"{x:194,y:532,t:1527873249266};\\\", \\\"{x:201,y:536,t:1527873249278};\\\", \\\"{x:228,y:540,t:1527873249295};\\\", \\\"{x:292,y:540,t:1527873249312};\\\", \\\"{x:384,y:540,t:1527873249329};\\\", \\\"{x:584,y:546,t:1527873249346};\\\", \\\"{x:717,y:546,t:1527873249362};\\\", \\\"{x:814,y:546,t:1527873249379};\\\", \\\"{x:870,y:546,t:1527873249395};\\\", \\\"{x:892,y:546,t:1527873249412};\\\", \\\"{x:903,y:546,t:1527873249428};\\\", \\\"{x:906,y:546,t:1527873249446};\\\", \\\"{x:907,y:546,t:1527873249461};\\\", \\\"{x:908,y:546,t:1527873249479};\\\", \\\"{x:912,y:546,t:1527873249496};\\\", \\\"{x:918,y:546,t:1527873249512};\\\", \\\"{x:925,y:546,t:1527873249528};\\\", \\\"{x:949,y:546,t:1527873249545};\\\", \\\"{x:957,y:546,t:1527873249563};\\\", \\\"{x:958,y:546,t:1527873249578};\\\", \\\"{x:956,y:546,t:1527873249618};\\\", \\\"{x:952,y:546,t:1527873249628};\\\", \\\"{x:943,y:548,t:1527873249646};\\\", \\\"{x:935,y:548,t:1527873249661};\\\", \\\"{x:919,y:550,t:1527873249678};\\\", \\\"{x:904,y:550,t:1527873249695};\\\", \\\"{x:886,y:550,t:1527873249713};\\\", \\\"{x:876,y:550,t:1527873249729};\\\", \\\"{x:864,y:550,t:1527873249746};\\\", \\\"{x:860,y:550,t:1527873249761};\\\", \\\"{x:859,y:550,t:1527873249786};\\\", \\\"{x:858,y:550,t:1527873249796};\\\", \\\"{x:857,y:550,t:1527873249826};\\\", \\\"{x:856,y:550,t:1527873249834};\\\", \\\"{x:855,y:550,t:1527873249850};\\\", \\\"{x:854,y:550,t:1527873249874};\\\", \\\"{x:851,y:550,t:1527873249891};\\\", \\\"{x:850,y:549,t:1527873249907};\\\", \\\"{x:849,y:549,t:1527873249914};\\\", \\\"{x:847,y:548,t:1527873249930};\\\", \\\"{x:846,y:547,t:1527873249946};\\\", \\\"{x:843,y:546,t:1527873249963};\\\", \\\"{x:842,y:546,t:1527873249980};\\\", \\\"{x:840,y:545,t:1527873249995};\\\", \\\"{x:839,y:545,t:1527873250018};\\\", \\\"{x:839,y:544,t:1527873250030};\\\", \\\"{x:843,y:544,t:1527873250233};\\\", \\\"{x:852,y:544,t:1527873250246};\\\", \\\"{x:878,y:544,t:1527873250262};\\\", \\\"{x:926,y:544,t:1527873250279};\\\", \\\"{x:1025,y:555,t:1527873250297};\\\", \\\"{x:1148,y:578,t:1527873250312};\\\", \\\"{x:1344,y:609,t:1527873250330};\\\", \\\"{x:1446,y:621,t:1527873250346};\\\", \\\"{x:1531,y:640,t:1527873250362};\\\", \\\"{x:1583,y:653,t:1527873250379};\\\", \\\"{x:1606,y:659,t:1527873250396};\\\", \\\"{x:1611,y:661,t:1527873250413};\\\", \\\"{x:1610,y:661,t:1527873250515};\\\", \\\"{x:1590,y:657,t:1527873250529};\\\", \\\"{x:1557,y:643,t:1527873250546};\\\", \\\"{x:1517,y:629,t:1527873250563};\\\", \\\"{x:1480,y:616,t:1527873250579};\\\", \\\"{x:1452,y:607,t:1527873250596};\\\", \\\"{x:1431,y:601,t:1527873250614};\\\", \\\"{x:1418,y:595,t:1527873250630};\\\", \\\"{x:1406,y:589,t:1527873250646};\\\", \\\"{x:1402,y:587,t:1527873250664};\\\", \\\"{x:1401,y:586,t:1527873250680};\\\", \\\"{x:1400,y:585,t:1527873250835};\\\", \\\"{x:1400,y:584,t:1527873250847};\\\", \\\"{x:1401,y:582,t:1527873250864};\\\", \\\"{x:1403,y:579,t:1527873250881};\\\", \\\"{x:1405,y:575,t:1527873250897};\\\", \\\"{x:1406,y:570,t:1527873250914};\\\", \\\"{x:1406,y:567,t:1527873250931};\\\", \\\"{x:1408,y:566,t:1527873250947};\\\", \\\"{x:1408,y:564,t:1527873250963};\\\", \\\"{x:1408,y:562,t:1527873250981};\\\", \\\"{x:1407,y:562,t:1527873261650};\\\", \\\"{x:1396,y:562,t:1527873261658};\\\", \\\"{x:1383,y:562,t:1527873261674};\\\", \\\"{x:1306,y:567,t:1527873261690};\\\", \\\"{x:1226,y:567,t:1527873261707};\\\", \\\"{x:1142,y:567,t:1527873261724};\\\", \\\"{x:1059,y:567,t:1527873261740};\\\", \\\"{x:984,y:567,t:1527873261758};\\\", \\\"{x:934,y:567,t:1527873261774};\\\", \\\"{x:878,y:560,t:1527873261791};\\\", \\\"{x:796,y:558,t:1527873261821};\\\", \\\"{x:771,y:557,t:1527873261838};\\\", \\\"{x:745,y:557,t:1527873261855};\\\", \\\"{x:721,y:558,t:1527873261872};\\\", \\\"{x:706,y:562,t:1527873261888};\\\", \\\"{x:690,y:568,t:1527873261905};\\\", \\\"{x:669,y:594,t:1527873261922};\\\", \\\"{x:653,y:630,t:1527873261939};\\\", \\\"{x:636,y:666,t:1527873261957};\\\", \\\"{x:621,y:702,t:1527873261971};\\\", \\\"{x:610,y:726,t:1527873261989};\\\", \\\"{x:599,y:753,t:1527873262006};\\\", \\\"{x:582,y:788,t:1527873262022};\\\", \\\"{x:574,y:799,t:1527873262039};\\\", \\\"{x:569,y:803,t:1527873262056};\\\", \\\"{x:567,y:803,t:1527873262098};\\\", \\\"{x:561,y:801,t:1527873262106};\\\", \\\"{x:549,y:791,t:1527873262123};\\\", \\\"{x:538,y:781,t:1527873262140};\\\", \\\"{x:530,y:773,t:1527873262156};\\\", \\\"{x:527,y:766,t:1527873262173};\\\", \\\"{x:525,y:762,t:1527873262189};\\\", \\\"{x:524,y:758,t:1527873262206};\\\", \\\"{x:524,y:756,t:1527873262223};\\\", \\\"{x:524,y:752,t:1527873262240};\\\", \\\"{x:523,y:749,t:1527873262256};\\\", \\\"{x:523,y:747,t:1527873262273};\\\", \\\"{x:523,y:746,t:1527873262290};\\\", \\\"{x:522,y:743,t:1527873262306};\\\", \\\"{x:522,y:742,t:1527873262323};\\\", \\\"{x:522,y:739,t:1527873262339};\\\", \\\"{x:522,y:738,t:1527873262356};\\\", \\\"{x:522,y:737,t:1527873262378};\\\", \\\"{x:523,y:736,t:1527873262938};\\\", \\\"{x:529,y:736,t:1527873262946};\\\", \\\"{x:540,y:733,t:1527873262956};\\\", \\\"{x:565,y:730,t:1527873262973};\\\", \\\"{x:591,y:729,t:1527873262990};\\\", \\\"{x:618,y:727,t:1527873263007};\\\", \\\"{x:644,y:725,t:1527873263023};\\\", \\\"{x:671,y:725,t:1527873263040};\\\", \\\"{x:697,y:725,t:1527873263057};\\\", \\\"{x:724,y:725,t:1527873263073};\\\", \\\"{x:755,y:725,t:1527873263090};\\\", \\\"{x:760,y:725,t:1527873263107};\\\", \\\"{x:760,y:723,t:1527873263625};\\\" ] }, { \\\"rt\\\": 52129, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 506227, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -I -E -J -I -J -11 AM-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:760,y:722,t:1527873263741};\\\", \\\"{x:761,y:722,t:1527873265555};\\\", \\\"{x:762,y:722,t:1527873265562};\\\", \\\"{x:763,y:722,t:1527873265575};\\\", \\\"{x:770,y:722,t:1527873265593};\\\", \\\"{x:776,y:722,t:1527873265608};\\\", \\\"{x:787,y:721,t:1527873265625};\\\", \\\"{x:808,y:721,t:1527873265642};\\\", \\\"{x:822,y:721,t:1527873265660};\\\", \\\"{x:831,y:721,t:1527873265676};\\\", \\\"{x:837,y:721,t:1527873265692};\\\", \\\"{x:844,y:721,t:1527873265709};\\\", \\\"{x:850,y:721,t:1527873265725};\\\", \\\"{x:855,y:722,t:1527873265743};\\\", \\\"{x:864,y:723,t:1527873265759};\\\", \\\"{x:874,y:725,t:1527873265776};\\\", \\\"{x:887,y:727,t:1527873265793};\\\", \\\"{x:903,y:729,t:1527873265809};\\\", \\\"{x:923,y:730,t:1527873265825};\\\", \\\"{x:923,y:731,t:1527873266594};\\\", \\\"{x:925,y:733,t:1527873266610};\\\", \\\"{x:926,y:734,t:1527873266626};\\\", \\\"{x:928,y:734,t:1527873266643};\\\", \\\"{x:930,y:735,t:1527873266859};\\\", \\\"{x:931,y:735,t:1527873266866};\\\", \\\"{x:938,y:736,t:1527873266922};\\\", \\\"{x:944,y:736,t:1527873266930};\\\", \\\"{x:947,y:735,t:1527873266946};\\\", \\\"{x:948,y:734,t:1527873266960};\\\", \\\"{x:959,y:734,t:1527873266976};\\\", \\\"{x:989,y:732,t:1527873266994};\\\", \\\"{x:1032,y:732,t:1527873267010};\\\", \\\"{x:1064,y:732,t:1527873267027};\\\", \\\"{x:1091,y:732,t:1527873267044};\\\", \\\"{x:1113,y:732,t:1527873267061};\\\", \\\"{x:1131,y:732,t:1527873267077};\\\", \\\"{x:1143,y:732,t:1527873267094};\\\", \\\"{x:1148,y:732,t:1527873267110};\\\", \\\"{x:1152,y:732,t:1527873267127};\\\", \\\"{x:1154,y:732,t:1527873267143};\\\", \\\"{x:1158,y:732,t:1527873267161};\\\", \\\"{x:1162,y:732,t:1527873267176};\\\", \\\"{x:1170,y:732,t:1527873267193};\\\", \\\"{x:1180,y:732,t:1527873267210};\\\", \\\"{x:1181,y:732,t:1527873267227};\\\", \\\"{x:1182,y:732,t:1527873267243};\\\", \\\"{x:1182,y:734,t:1527873267898};\\\", \\\"{x:1186,y:734,t:1527873267914};\\\", \\\"{x:1188,y:734,t:1527873267928};\\\", \\\"{x:1189,y:734,t:1527873267945};\\\", \\\"{x:1190,y:734,t:1527873268034};\\\", \\\"{x:1195,y:734,t:1527873268051};\\\", \\\"{x:1201,y:735,t:1527873268060};\\\", \\\"{x:1213,y:737,t:1527873268078};\\\", \\\"{x:1226,y:740,t:1527873268095};\\\", \\\"{x:1239,y:741,t:1527873268111};\\\", \\\"{x:1247,y:742,t:1527873268127};\\\", \\\"{x:1257,y:745,t:1527873268144};\\\", \\\"{x:1259,y:745,t:1527873268161};\\\", \\\"{x:1266,y:746,t:1527873268177};\\\", \\\"{x:1282,y:751,t:1527873268194};\\\", \\\"{x:1295,y:754,t:1527873268210};\\\", \\\"{x:1311,y:758,t:1527873268227};\\\", \\\"{x:1322,y:759,t:1527873268244};\\\", \\\"{x:1334,y:760,t:1527873268261};\\\", \\\"{x:1344,y:764,t:1527873268279};\\\", \\\"{x:1357,y:766,t:1527873268294};\\\", \\\"{x:1372,y:769,t:1527873268311};\\\", \\\"{x:1389,y:771,t:1527873268327};\\\", \\\"{x:1406,y:774,t:1527873268344};\\\", \\\"{x:1430,y:780,t:1527873268361};\\\", \\\"{x:1440,y:781,t:1527873268377};\\\", \\\"{x:1449,y:784,t:1527873268394};\\\", \\\"{x:1457,y:786,t:1527873268411};\\\", \\\"{x:1463,y:788,t:1527873268427};\\\", \\\"{x:1466,y:789,t:1527873268444};\\\", \\\"{x:1467,y:790,t:1527873268627};\\\", \\\"{x:1466,y:790,t:1527873268642};\\\", \\\"{x:1462,y:790,t:1527873268650};\\\", \\\"{x:1455,y:790,t:1527873268661};\\\", \\\"{x:1437,y:790,t:1527873268679};\\\", \\\"{x:1418,y:787,t:1527873268695};\\\", \\\"{x:1396,y:785,t:1527873268712};\\\", \\\"{x:1370,y:780,t:1527873268728};\\\", \\\"{x:1342,y:778,t:1527873268744};\\\", \\\"{x:1304,y:771,t:1527873268762};\\\", \\\"{x:1290,y:769,t:1527873268778};\\\", \\\"{x:1283,y:768,t:1527873268795};\\\", \\\"{x:1280,y:768,t:1527873268812};\\\", \\\"{x:1279,y:768,t:1527873268890};\\\", \\\"{x:1278,y:768,t:1527873268906};\\\", \\\"{x:1276,y:768,t:1527873268914};\\\", \\\"{x:1275,y:768,t:1527873268929};\\\", \\\"{x:1268,y:770,t:1527873268944};\\\", \\\"{x:1264,y:774,t:1527873268961};\\\", \\\"{x:1253,y:783,t:1527873268978};\\\", \\\"{x:1248,y:791,t:1527873268994};\\\", \\\"{x:1243,y:795,t:1527873269011};\\\", \\\"{x:1238,y:800,t:1527873269028};\\\", \\\"{x:1234,y:802,t:1527873269045};\\\", \\\"{x:1230,y:806,t:1527873269062};\\\", \\\"{x:1225,y:810,t:1527873269078};\\\", \\\"{x:1219,y:814,t:1527873269094};\\\", \\\"{x:1215,y:820,t:1527873269112};\\\", \\\"{x:1210,y:823,t:1527873269129};\\\", \\\"{x:1205,y:827,t:1527873269146};\\\", \\\"{x:1204,y:827,t:1527873269427};\\\", \\\"{x:1203,y:823,t:1527873269434};\\\", \\\"{x:1202,y:821,t:1527873269446};\\\", \\\"{x:1197,y:812,t:1527873269462};\\\", \\\"{x:1193,y:804,t:1527873269478};\\\", \\\"{x:1186,y:790,t:1527873269496};\\\", \\\"{x:1183,y:784,t:1527873269512};\\\", \\\"{x:1181,y:777,t:1527873269529};\\\", \\\"{x:1179,y:771,t:1527873269546};\\\", \\\"{x:1178,y:769,t:1527873269563};\\\", \\\"{x:1178,y:764,t:1527873276523};\\\", \\\"{x:1179,y:762,t:1527873276534};\\\", \\\"{x:1185,y:754,t:1527873276554};\\\", \\\"{x:1186,y:750,t:1527873276568};\\\", \\\"{x:1192,y:744,t:1527873276585};\\\", \\\"{x:1197,y:738,t:1527873276601};\\\", \\\"{x:1202,y:732,t:1527873276618};\\\", \\\"{x:1206,y:728,t:1527873276634};\\\", \\\"{x:1210,y:724,t:1527873276651};\\\", \\\"{x:1212,y:718,t:1527873276668};\\\", \\\"{x:1220,y:710,t:1527873276685};\\\", \\\"{x:1228,y:697,t:1527873276702};\\\", \\\"{x:1236,y:685,t:1527873276718};\\\", \\\"{x:1246,y:672,t:1527873276735};\\\", \\\"{x:1250,y:662,t:1527873276751};\\\", \\\"{x:1257,y:649,t:1527873276768};\\\", \\\"{x:1264,y:638,t:1527873276785};\\\", \\\"{x:1271,y:623,t:1527873276801};\\\", \\\"{x:1275,y:612,t:1527873276818};\\\", \\\"{x:1279,y:604,t:1527873276835};\\\", \\\"{x:1282,y:591,t:1527873276851};\\\", \\\"{x:1285,y:582,t:1527873276868};\\\", \\\"{x:1285,y:577,t:1527873276885};\\\", \\\"{x:1285,y:570,t:1527873276901};\\\", \\\"{x:1285,y:566,t:1527873276918};\\\", \\\"{x:1285,y:563,t:1527873276935};\\\", \\\"{x:1285,y:560,t:1527873276953};\\\", \\\"{x:1285,y:559,t:1527873277026};\\\", \\\"{x:1284,y:559,t:1527873277066};\\\", \\\"{x:1283,y:559,t:1527873279587};\\\", \\\"{x:1283,y:564,t:1527873283522};\\\", \\\"{x:1285,y:584,t:1527873283541};\\\", \\\"{x:1293,y:616,t:1527873283556};\\\", \\\"{x:1300,y:644,t:1527873283572};\\\", \\\"{x:1311,y:670,t:1527873283590};\\\", \\\"{x:1316,y:695,t:1527873283605};\\\", \\\"{x:1317,y:713,t:1527873283623};\\\", \\\"{x:1317,y:728,t:1527873283640};\\\", \\\"{x:1310,y:741,t:1527873283657};\\\", \\\"{x:1304,y:757,t:1527873283672};\\\", \\\"{x:1299,y:774,t:1527873283690};\\\", \\\"{x:1297,y:779,t:1527873283707};\\\", \\\"{x:1296,y:782,t:1527873283723};\\\", \\\"{x:1294,y:786,t:1527873283740};\\\", \\\"{x:1291,y:792,t:1527873283757};\\\", \\\"{x:1286,y:799,t:1527873283773};\\\", \\\"{x:1276,y:810,t:1527873283789};\\\", \\\"{x:1269,y:821,t:1527873283806};\\\", \\\"{x:1262,y:833,t:1527873283822};\\\", \\\"{x:1257,y:843,t:1527873283840};\\\", \\\"{x:1253,y:848,t:1527873283857};\\\", \\\"{x:1252,y:850,t:1527873283872};\\\", \\\"{x:1251,y:851,t:1527873283890};\\\", \\\"{x:1249,y:851,t:1527873283907};\\\", \\\"{x:1247,y:851,t:1527873284259};\\\", \\\"{x:1244,y:851,t:1527873284274};\\\", \\\"{x:1239,y:851,t:1527873284290};\\\", \\\"{x:1237,y:851,t:1527873284307};\\\", \\\"{x:1234,y:851,t:1527873284324};\\\", \\\"{x:1233,y:849,t:1527873284340};\\\", \\\"{x:1231,y:849,t:1527873284358};\\\", \\\"{x:1229,y:850,t:1527873284374};\\\", \\\"{x:1226,y:851,t:1527873284391};\\\", \\\"{x:1221,y:853,t:1527873284408};\\\", \\\"{x:1220,y:853,t:1527873284425};\\\", \\\"{x:1216,y:853,t:1527873284440};\\\", \\\"{x:1211,y:856,t:1527873284458};\\\", \\\"{x:1208,y:856,t:1527873284474};\\\", \\\"{x:1205,y:857,t:1527873284491};\\\", \\\"{x:1203,y:858,t:1527873284508};\\\", \\\"{x:1202,y:858,t:1527873284525};\\\", \\\"{x:1200,y:859,t:1527873284541};\\\", \\\"{x:1199,y:859,t:1527873285849};\\\", \\\"{x:1199,y:858,t:1527873285898};\\\", \\\"{x:1199,y:857,t:1527873285913};\\\", \\\"{x:1199,y:856,t:1527873285925};\\\", \\\"{x:1199,y:853,t:1527873285942};\\\", \\\"{x:1200,y:851,t:1527873285958};\\\", \\\"{x:1201,y:848,t:1527873285976};\\\", \\\"{x:1202,y:845,t:1527873285992};\\\", \\\"{x:1203,y:839,t:1527873286008};\\\", \\\"{x:1204,y:835,t:1527873286025};\\\", \\\"{x:1205,y:832,t:1527873286042};\\\", \\\"{x:1207,y:828,t:1527873286058};\\\", \\\"{x:1210,y:821,t:1527873286075};\\\", \\\"{x:1211,y:817,t:1527873286092};\\\", \\\"{x:1213,y:810,t:1527873286109};\\\", \\\"{x:1215,y:805,t:1527873286125};\\\", \\\"{x:1217,y:797,t:1527873286142};\\\", \\\"{x:1220,y:789,t:1527873286158};\\\", \\\"{x:1222,y:780,t:1527873286175};\\\", \\\"{x:1226,y:769,t:1527873286193};\\\", \\\"{x:1228,y:758,t:1527873286208};\\\", \\\"{x:1234,y:743,t:1527873286226};\\\", \\\"{x:1237,y:734,t:1527873286241};\\\", \\\"{x:1239,y:722,t:1527873286260};\\\", \\\"{x:1242,y:710,t:1527873286275};\\\", \\\"{x:1243,y:699,t:1527873286292};\\\", \\\"{x:1247,y:686,t:1527873286309};\\\", \\\"{x:1249,y:674,t:1527873286325};\\\", \\\"{x:1251,y:668,t:1527873286342};\\\", \\\"{x:1254,y:657,t:1527873286360};\\\", \\\"{x:1257,y:649,t:1527873286376};\\\", \\\"{x:1258,y:640,t:1527873286393};\\\", \\\"{x:1260,y:632,t:1527873286409};\\\", \\\"{x:1264,y:620,t:1527873286426};\\\", \\\"{x:1265,y:616,t:1527873286442};\\\", \\\"{x:1267,y:611,t:1527873286459};\\\", \\\"{x:1270,y:605,t:1527873286475};\\\", \\\"{x:1271,y:601,t:1527873286492};\\\", \\\"{x:1273,y:597,t:1527873286509};\\\", \\\"{x:1274,y:591,t:1527873286525};\\\", \\\"{x:1277,y:586,t:1527873286543};\\\", \\\"{x:1277,y:583,t:1527873286558};\\\", \\\"{x:1277,y:582,t:1527873286575};\\\", \\\"{x:1277,y:580,t:1527873286593};\\\", \\\"{x:1279,y:578,t:1527873286609};\\\", \\\"{x:1280,y:576,t:1527873286625};\\\", \\\"{x:1280,y:575,t:1527873286642};\\\", \\\"{x:1280,y:574,t:1527873286659};\\\", \\\"{x:1280,y:573,t:1527873286675};\\\", \\\"{x:1280,y:577,t:1527873305014};\\\", \\\"{x:1278,y:581,t:1527873305028};\\\", \\\"{x:1272,y:593,t:1527873305044};\\\", \\\"{x:1261,y:617,t:1527873305061};\\\", \\\"{x:1254,y:635,t:1527873305077};\\\", \\\"{x:1243,y:652,t:1527873305094};\\\", \\\"{x:1235,y:668,t:1527873305111};\\\", \\\"{x:1230,y:681,t:1527873305127};\\\", \\\"{x:1226,y:693,t:1527873305144};\\\", \\\"{x:1222,y:710,t:1527873305160};\\\", \\\"{x:1217,y:723,t:1527873305177};\\\", \\\"{x:1214,y:734,t:1527873305193};\\\", \\\"{x:1209,y:748,t:1527873305211};\\\", \\\"{x:1205,y:756,t:1527873305228};\\\", \\\"{x:1202,y:765,t:1527873305245};\\\", \\\"{x:1201,y:769,t:1527873305261};\\\", \\\"{x:1200,y:771,t:1527873305277};\\\", \\\"{x:1200,y:772,t:1527873305341};\\\", \\\"{x:1198,y:773,t:1527873305358};\\\", \\\"{x:1197,y:773,t:1527873305438};\\\", \\\"{x:1196,y:773,t:1527873305453};\\\", \\\"{x:1195,y:773,t:1527873305469};\\\", \\\"{x:1194,y:773,t:1527873305478};\\\", \\\"{x:1192,y:773,t:1527873305495};\\\", \\\"{x:1188,y:773,t:1527873305511};\\\", \\\"{x:1185,y:771,t:1527873305528};\\\", \\\"{x:1181,y:769,t:1527873305545};\\\", \\\"{x:1179,y:767,t:1527873305561};\\\", \\\"{x:1178,y:766,t:1527873305578};\\\", \\\"{x:1177,y:765,t:1527873305595};\\\", \\\"{x:1177,y:766,t:1527873309636};\\\", \\\"{x:1179,y:768,t:1527873309647};\\\", \\\"{x:1181,y:771,t:1527873309664};\\\", \\\"{x:1183,y:774,t:1527873309680};\\\", \\\"{x:1185,y:780,t:1527873309697};\\\", \\\"{x:1190,y:788,t:1527873309714};\\\", \\\"{x:1200,y:810,t:1527873309730};\\\", \\\"{x:1211,y:827,t:1527873309747};\\\", \\\"{x:1223,y:847,t:1527873309765};\\\", \\\"{x:1230,y:858,t:1527873309780};\\\", \\\"{x:1235,y:869,t:1527873309797};\\\", \\\"{x:1239,y:882,t:1527873309814};\\\", \\\"{x:1244,y:894,t:1527873309830};\\\", \\\"{x:1248,y:907,t:1527873309847};\\\", \\\"{x:1253,y:919,t:1527873309864};\\\", \\\"{x:1258,y:931,t:1527873309880};\\\", \\\"{x:1263,y:943,t:1527873309897};\\\", \\\"{x:1267,y:951,t:1527873309914};\\\", \\\"{x:1268,y:953,t:1527873309930};\\\", \\\"{x:1269,y:955,t:1527873309947};\\\", \\\"{x:1272,y:961,t:1527873309964};\\\", \\\"{x:1275,y:966,t:1527873309981};\\\", \\\"{x:1275,y:967,t:1527873309997};\\\", \\\"{x:1276,y:969,t:1527873310014};\\\", \\\"{x:1277,y:970,t:1527873310031};\\\", \\\"{x:1278,y:971,t:1527873310048};\\\", \\\"{x:1279,y:971,t:1527873310064};\\\", \\\"{x:1277,y:969,t:1527873310340};\\\", \\\"{x:1268,y:960,t:1527873310348};\\\", \\\"{x:1242,y:941,t:1527873310364};\\\", \\\"{x:1187,y:908,t:1527873310381};\\\", \\\"{x:1126,y:880,t:1527873310398};\\\", \\\"{x:1081,y:859,t:1527873310414};\\\", \\\"{x:1065,y:852,t:1527873310431};\\\", \\\"{x:1063,y:851,t:1527873310448};\\\", \\\"{x:1063,y:850,t:1527873310644};\\\", \\\"{x:1065,y:850,t:1527873310660};\\\", \\\"{x:1067,y:850,t:1527873310668};\\\", \\\"{x:1071,y:850,t:1527873310681};\\\", \\\"{x:1090,y:850,t:1527873310698};\\\", \\\"{x:1117,y:850,t:1527873310714};\\\", \\\"{x:1147,y:850,t:1527873310732};\\\", \\\"{x:1202,y:850,t:1527873310748};\\\", \\\"{x:1225,y:849,t:1527873310764};\\\", \\\"{x:1237,y:844,t:1527873310781};\\\", \\\"{x:1240,y:840,t:1527873310798};\\\", \\\"{x:1241,y:834,t:1527873310814};\\\", \\\"{x:1241,y:826,t:1527873310832};\\\", \\\"{x:1241,y:821,t:1527873310849};\\\", \\\"{x:1241,y:816,t:1527873310866};\\\", \\\"{x:1241,y:812,t:1527873310881};\\\", \\\"{x:1239,y:807,t:1527873310898};\\\", \\\"{x:1236,y:798,t:1527873310915};\\\", \\\"{x:1230,y:787,t:1527873310931};\\\", \\\"{x:1220,y:776,t:1527873310948};\\\", \\\"{x:1215,y:773,t:1527873310965};\\\", \\\"{x:1210,y:772,t:1527873310981};\\\", \\\"{x:1206,y:770,t:1527873310998};\\\", \\\"{x:1202,y:769,t:1527873311015};\\\", \\\"{x:1196,y:766,t:1527873311031};\\\", \\\"{x:1192,y:765,t:1527873311048};\\\", \\\"{x:1187,y:765,t:1527873311065};\\\", \\\"{x:1179,y:762,t:1527873311082};\\\", \\\"{x:1174,y:762,t:1527873311099};\\\", \\\"{x:1167,y:761,t:1527873311115};\\\", \\\"{x:1164,y:761,t:1527873311131};\\\", \\\"{x:1163,y:761,t:1527873311348};\\\", \\\"{x:1142,y:759,t:1527873311365};\\\", \\\"{x:1091,y:751,t:1527873311382};\\\", \\\"{x:991,y:736,t:1527873311398};\\\", \\\"{x:883,y:717,t:1527873311415};\\\", \\\"{x:761,y:686,t:1527873311432};\\\", \\\"{x:665,y:660,t:1527873311448};\\\", \\\"{x:600,y:639,t:1527873311465};\\\", \\\"{x:574,y:630,t:1527873311483};\\\", \\\"{x:565,y:625,t:1527873311498};\\\", \\\"{x:565,y:623,t:1527873311515};\\\", \\\"{x:565,y:619,t:1527873311530};\\\", \\\"{x:565,y:616,t:1527873311547};\\\", \\\"{x:561,y:605,t:1527873311563};\\\", \\\"{x:545,y:587,t:1527873311580};\\\", \\\"{x:522,y:575,t:1527873311598};\\\", \\\"{x:493,y:563,t:1527873311617};\\\", \\\"{x:467,y:550,t:1527873311634};\\\", \\\"{x:439,y:537,t:1527873311650};\\\", \\\"{x:417,y:524,t:1527873311666};\\\", \\\"{x:397,y:515,t:1527873311683};\\\", \\\"{x:381,y:507,t:1527873311700};\\\", \\\"{x:379,y:507,t:1527873311716};\\\", \\\"{x:377,y:507,t:1527873311763};\\\", \\\"{x:376,y:509,t:1527873311780};\\\", \\\"{x:375,y:510,t:1527873311788};\\\", \\\"{x:374,y:514,t:1527873311801};\\\", \\\"{x:369,y:516,t:1527873311817};\\\", \\\"{x:356,y:518,t:1527873311834};\\\", \\\"{x:341,y:519,t:1527873311850};\\\", \\\"{x:323,y:519,t:1527873311868};\\\", \\\"{x:304,y:517,t:1527873311883};\\\", \\\"{x:287,y:513,t:1527873311899};\\\", \\\"{x:286,y:512,t:1527873311916};\\\", \\\"{x:283,y:512,t:1527873311956};\\\", \\\"{x:282,y:510,t:1527873311967};\\\", \\\"{x:271,y:506,t:1527873311984};\\\", \\\"{x:266,y:504,t:1527873312000};\\\", \\\"{x:263,y:502,t:1527873312018};\\\", \\\"{x:260,y:501,t:1527873312033};\\\", \\\"{x:258,y:501,t:1527873312050};\\\", \\\"{x:254,y:501,t:1527873312067};\\\", \\\"{x:251,y:501,t:1527873312083};\\\", \\\"{x:249,y:501,t:1527873312100};\\\", \\\"{x:248,y:501,t:1527873312132};\\\", \\\"{x:246,y:501,t:1527873312163};\\\", \\\"{x:244,y:502,t:1527873312188};\\\", \\\"{x:242,y:503,t:1527873312212};\\\", \\\"{x:240,y:505,t:1527873312220};\\\", \\\"{x:238,y:506,t:1527873312233};\\\", \\\"{x:233,y:509,t:1527873312250};\\\", \\\"{x:230,y:512,t:1527873312267};\\\", \\\"{x:229,y:513,t:1527873312283};\\\", \\\"{x:227,y:513,t:1527873312300};\\\", \\\"{x:226,y:513,t:1527873312323};\\\", \\\"{x:226,y:512,t:1527873312333};\\\", \\\"{x:221,y:508,t:1527873312350};\\\", \\\"{x:219,y:507,t:1527873312367};\\\", \\\"{x:219,y:506,t:1527873312668};\\\", \\\"{x:220,y:507,t:1527873312836};\\\", \\\"{x:222,y:507,t:1527873312852};\\\", \\\"{x:223,y:505,t:1527873312867};\\\", \\\"{x:224,y:505,t:1527873312980};\\\", \\\"{x:225,y:505,t:1527873312988};\\\", \\\"{x:226,y:505,t:1527873313028};\\\", \\\"{x:228,y:505,t:1527873313044};\\\", \\\"{x:229,y:505,t:1527873313068};\\\", \\\"{x:230,y:505,t:1527873313268};\\\", \\\"{x:228,y:504,t:1527873313588};\\\", \\\"{x:224,y:503,t:1527873313601};\\\", \\\"{x:221,y:500,t:1527873313618};\\\", \\\"{x:219,y:500,t:1527873313676};\\\", \\\"{x:218,y:500,t:1527873313684};\\\", \\\"{x:212,y:500,t:1527873313701};\\\", \\\"{x:207,y:501,t:1527873313718};\\\", \\\"{x:204,y:501,t:1527873313734};\\\", \\\"{x:203,y:501,t:1527873313751};\\\", \\\"{x:199,y:501,t:1527873313769};\\\", \\\"{x:197,y:501,t:1527873313785};\\\", \\\"{x:195,y:501,t:1527873313801};\\\", \\\"{x:193,y:501,t:1527873313818};\\\", \\\"{x:191,y:502,t:1527873313834};\\\", \\\"{x:190,y:502,t:1527873313851};\\\", \\\"{x:186,y:502,t:1527873313869};\\\", \\\"{x:182,y:501,t:1527873313884};\\\", \\\"{x:179,y:500,t:1527873313901};\\\", \\\"{x:175,y:500,t:1527873313919};\\\", \\\"{x:171,y:498,t:1527873313934};\\\", \\\"{x:165,y:497,t:1527873313951};\\\", \\\"{x:161,y:496,t:1527873313969};\\\", \\\"{x:158,y:496,t:1527873313984};\\\", \\\"{x:157,y:496,t:1527873314001};\\\", \\\"{x:155,y:496,t:1527873314019};\\\", \\\"{x:154,y:496,t:1527873314044};\\\", \\\"{x:153,y:496,t:1527873314068};\\\", \\\"{x:154,y:497,t:1527873314540};\\\", \\\"{x:156,y:500,t:1527873314552};\\\", \\\"{x:161,y:505,t:1527873314568};\\\", \\\"{x:167,y:509,t:1527873314585};\\\", \\\"{x:172,y:516,t:1527873314603};\\\", \\\"{x:180,y:520,t:1527873314619};\\\", \\\"{x:190,y:525,t:1527873314636};\\\", \\\"{x:207,y:535,t:1527873314652};\\\", \\\"{x:221,y:543,t:1527873314668};\\\", \\\"{x:234,y:553,t:1527873314685};\\\", \\\"{x:245,y:561,t:1527873314703};\\\", \\\"{x:257,y:570,t:1527873314720};\\\", \\\"{x:270,y:579,t:1527873314735};\\\", \\\"{x:281,y:589,t:1527873314754};\\\", \\\"{x:291,y:599,t:1527873314769};\\\", \\\"{x:299,y:606,t:1527873314785};\\\", \\\"{x:305,y:615,t:1527873314803};\\\", \\\"{x:316,y:628,t:1527873314819};\\\", \\\"{x:332,y:650,t:1527873314836};\\\", \\\"{x:342,y:662,t:1527873314852};\\\", \\\"{x:352,y:673,t:1527873314870};\\\", \\\"{x:368,y:691,t:1527873314885};\\\", \\\"{x:379,y:704,t:1527873314902};\\\", \\\"{x:391,y:714,t:1527873314919};\\\", \\\"{x:403,y:722,t:1527873314936};\\\", \\\"{x:414,y:731,t:1527873314953};\\\", \\\"{x:427,y:740,t:1527873314970};\\\", \\\"{x:440,y:749,t:1527873314986};\\\", \\\"{x:448,y:755,t:1527873315002};\\\", \\\"{x:456,y:760,t:1527873315020};\\\", \\\"{x:471,y:771,t:1527873315036};\\\", \\\"{x:480,y:776,t:1527873315053};\\\", \\\"{x:486,y:779,t:1527873315069};\\\", \\\"{x:490,y:781,t:1527873315087};\\\", \\\"{x:492,y:782,t:1527873315103};\\\", \\\"{x:493,y:782,t:1527873315119};\\\", \\\"{x:494,y:782,t:1527873315137};\\\", \\\"{x:497,y:783,t:1527873315153};\\\", \\\"{x:502,y:785,t:1527873315170};\\\", \\\"{x:510,y:786,t:1527873315187};\\\", \\\"{x:520,y:787,t:1527873315203};\\\", \\\"{x:532,y:789,t:1527873315220};\\\", \\\"{x:541,y:790,t:1527873315236};\\\", \\\"{x:544,y:790,t:1527873315253};\\\", \\\"{x:548,y:790,t:1527873315270};\\\", \\\"{x:549,y:790,t:1527873315286};\\\", \\\"{x:553,y:789,t:1527873315303};\\\", \\\"{x:556,y:788,t:1527873315320};\\\", \\\"{x:560,y:787,t:1527873315337};\\\", \\\"{x:562,y:787,t:1527873315452};\\\", \\\"{x:562,y:786,t:1527873315499};\\\", \\\"{x:562,y:784,t:1527873315508};\\\", \\\"{x:562,y:777,t:1527873315521};\\\", \\\"{x:553,y:763,t:1527873315538};\\\", \\\"{x:546,y:754,t:1527873315554};\\\", \\\"{x:542,y:750,t:1527873315570};\\\", \\\"{x:540,y:748,t:1527873315586};\\\", \\\"{x:539,y:748,t:1527873315603};\\\", \\\"{x:537,y:746,t:1527873315668};\\\" ] }, { \\\"rt\\\": 14196, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 521634, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:746,t:1527873317356};\\\", \\\"{x:541,y:746,t:1527873317948};\\\", \\\"{x:551,y:746,t:1527873317957};\\\", \\\"{x:578,y:746,t:1527873317974};\\\", \\\"{x:616,y:748,t:1527873317990};\\\", \\\"{x:664,y:756,t:1527873318005};\\\", \\\"{x:717,y:764,t:1527873318021};\\\", \\\"{x:763,y:771,t:1527873318038};\\\", \\\"{x:791,y:775,t:1527873318054};\\\", \\\"{x:813,y:777,t:1527873318072};\\\", \\\"{x:835,y:781,t:1527873318088};\\\", \\\"{x:861,y:783,t:1527873318104};\\\", \\\"{x:884,y:789,t:1527873318121};\\\", \\\"{x:905,y:789,t:1527873318138};\\\", \\\"{x:925,y:789,t:1527873318154};\\\", \\\"{x:937,y:789,t:1527873318171};\\\", \\\"{x:938,y:789,t:1527873318187};\\\", \\\"{x:946,y:793,t:1527873318772};\\\", \\\"{x:956,y:796,t:1527873318787};\\\", \\\"{x:980,y:803,t:1527873318804};\\\", \\\"{x:1012,y:809,t:1527873318821};\\\", \\\"{x:1047,y:817,t:1527873318837};\\\", \\\"{x:1079,y:822,t:1527873318855};\\\", \\\"{x:1118,y:827,t:1527873318870};\\\", \\\"{x:1160,y:833,t:1527873318888};\\\", \\\"{x:1203,y:840,t:1527873318904};\\\", \\\"{x:1243,y:847,t:1527873318920};\\\", \\\"{x:1277,y:851,t:1527873318937};\\\", \\\"{x:1318,y:856,t:1527873318954};\\\", \\\"{x:1352,y:862,t:1527873318970};\\\", \\\"{x:1393,y:867,t:1527873318987};\\\", \\\"{x:1416,y:868,t:1527873319005};\\\", \\\"{x:1438,y:873,t:1527873319020};\\\", \\\"{x:1463,y:873,t:1527873319037};\\\", \\\"{x:1492,y:873,t:1527873319055};\\\", \\\"{x:1522,y:873,t:1527873319070};\\\", \\\"{x:1552,y:873,t:1527873319088};\\\", \\\"{x:1579,y:873,t:1527873319105};\\\", \\\"{x:1603,y:873,t:1527873319121};\\\", \\\"{x:1624,y:873,t:1527873319137};\\\", \\\"{x:1639,y:874,t:1527873319154};\\\", \\\"{x:1649,y:875,t:1527873319170};\\\", \\\"{x:1653,y:875,t:1527873319188};\\\", \\\"{x:1654,y:875,t:1527873319380};\\\", \\\"{x:1654,y:874,t:1527873319411};\\\", \\\"{x:1654,y:873,t:1527873319436};\\\", \\\"{x:1654,y:872,t:1527873319451};\\\", \\\"{x:1654,y:871,t:1527873319460};\\\", \\\"{x:1653,y:870,t:1527873319471};\\\", \\\"{x:1653,y:868,t:1527873319488};\\\", \\\"{x:1651,y:863,t:1527873319505};\\\", \\\"{x:1651,y:861,t:1527873319521};\\\", \\\"{x:1649,y:857,t:1527873319537};\\\", \\\"{x:1648,y:853,t:1527873319555};\\\", \\\"{x:1646,y:848,t:1527873319570};\\\", \\\"{x:1644,y:842,t:1527873319587};\\\", \\\"{x:1644,y:839,t:1527873319604};\\\", \\\"{x:1644,y:835,t:1527873319620};\\\", \\\"{x:1644,y:832,t:1527873319637};\\\", \\\"{x:1644,y:828,t:1527873319654};\\\", \\\"{x:1644,y:826,t:1527873319671};\\\", \\\"{x:1644,y:822,t:1527873319688};\\\", \\\"{x:1644,y:820,t:1527873319704};\\\", \\\"{x:1644,y:818,t:1527873319720};\\\", \\\"{x:1644,y:814,t:1527873319737};\\\", \\\"{x:1644,y:810,t:1527873319754};\\\", \\\"{x:1644,y:805,t:1527873319770};\\\", \\\"{x:1644,y:798,t:1527873319788};\\\", \\\"{x:1643,y:793,t:1527873319804};\\\", \\\"{x:1642,y:788,t:1527873319821};\\\", \\\"{x:1642,y:784,t:1527873319838};\\\", \\\"{x:1641,y:782,t:1527873319854};\\\", \\\"{x:1641,y:777,t:1527873319870};\\\", \\\"{x:1640,y:773,t:1527873319887};\\\", \\\"{x:1639,y:767,t:1527873319904};\\\", \\\"{x:1637,y:761,t:1527873319921};\\\", \\\"{x:1635,y:751,t:1527873319938};\\\", \\\"{x:1633,y:744,t:1527873319954};\\\", \\\"{x:1633,y:735,t:1527873319970};\\\", \\\"{x:1633,y:709,t:1527873319988};\\\", \\\"{x:1633,y:681,t:1527873320004};\\\", \\\"{x:1633,y:650,t:1527873320020};\\\", \\\"{x:1635,y:606,t:1527873320038};\\\", \\\"{x:1641,y:577,t:1527873320055};\\\", \\\"{x:1646,y:552,t:1527873320070};\\\", \\\"{x:1647,y:529,t:1527873320088};\\\", \\\"{x:1649,y:515,t:1527873320104};\\\", \\\"{x:1651,y:502,t:1527873320121};\\\", \\\"{x:1652,y:493,t:1527873320138};\\\", \\\"{x:1652,y:486,t:1527873320155};\\\", \\\"{x:1652,y:482,t:1527873320170};\\\", \\\"{x:1652,y:479,t:1527873320188};\\\", \\\"{x:1652,y:478,t:1527873320204};\\\", \\\"{x:1652,y:477,t:1527873320236};\\\", \\\"{x:1651,y:477,t:1527873320260};\\\", \\\"{x:1650,y:477,t:1527873320468};\\\", \\\"{x:1647,y:477,t:1527873320476};\\\", \\\"{x:1643,y:473,t:1527873320488};\\\", \\\"{x:1632,y:463,t:1527873320505};\\\", \\\"{x:1620,y:448,t:1527873320520};\\\", \\\"{x:1602,y:432,t:1527873320537};\\\", \\\"{x:1588,y:413,t:1527873320555};\\\", \\\"{x:1577,y:390,t:1527873320570};\\\", \\\"{x:1557,y:357,t:1527873320588};\\\", \\\"{x:1549,y:348,t:1527873320604};\\\", \\\"{x:1544,y:344,t:1527873320620};\\\", \\\"{x:1540,y:340,t:1527873320637};\\\", \\\"{x:1538,y:339,t:1527873320654};\\\", \\\"{x:1533,y:338,t:1527873320671};\\\", \\\"{x:1531,y:338,t:1527873320688};\\\", \\\"{x:1528,y:338,t:1527873320704};\\\", \\\"{x:1524,y:340,t:1527873320721};\\\", \\\"{x:1517,y:345,t:1527873320738};\\\", \\\"{x:1507,y:351,t:1527873320754};\\\", \\\"{x:1496,y:358,t:1527873320770};\\\", \\\"{x:1483,y:370,t:1527873320787};\\\", \\\"{x:1470,y:382,t:1527873320804};\\\", \\\"{x:1459,y:395,t:1527873320820};\\\", \\\"{x:1453,y:409,t:1527873320838};\\\", \\\"{x:1448,y:421,t:1527873320854};\\\", \\\"{x:1441,y:437,t:1527873320871};\\\", \\\"{x:1434,y:454,t:1527873320887};\\\", \\\"{x:1427,y:473,t:1527873320904};\\\", \\\"{x:1422,y:492,t:1527873320920};\\\", \\\"{x:1417,y:514,t:1527873320938};\\\", \\\"{x:1411,y:533,t:1527873320955};\\\", \\\"{x:1408,y:550,t:1527873320971};\\\", \\\"{x:1401,y:580,t:1527873320987};\\\", \\\"{x:1399,y:598,t:1527873321003};\\\", \\\"{x:1396,y:614,t:1527873321020};\\\", \\\"{x:1394,y:629,t:1527873321037};\\\", \\\"{x:1392,y:645,t:1527873321055};\\\", \\\"{x:1390,y:654,t:1527873321070};\\\", \\\"{x:1390,y:663,t:1527873321087};\\\", \\\"{x:1390,y:673,t:1527873321104};\\\", \\\"{x:1390,y:686,t:1527873321121};\\\", \\\"{x:1390,y:693,t:1527873321138};\\\", \\\"{x:1390,y:699,t:1527873321154};\\\", \\\"{x:1390,y:705,t:1527873321171};\\\", \\\"{x:1390,y:713,t:1527873321188};\\\", \\\"{x:1390,y:715,t:1527873321204};\\\", \\\"{x:1388,y:717,t:1527873321221};\\\", \\\"{x:1387,y:717,t:1527873321316};\\\", \\\"{x:1386,y:716,t:1527873321323};\\\", \\\"{x:1385,y:716,t:1527873321338};\\\", \\\"{x:1383,y:715,t:1527873321354};\\\", \\\"{x:1378,y:713,t:1527873321370};\\\", \\\"{x:1370,y:712,t:1527873321388};\\\", \\\"{x:1363,y:712,t:1527873321404};\\\", \\\"{x:1357,y:712,t:1527873321421};\\\", \\\"{x:1353,y:712,t:1527873321437};\\\", \\\"{x:1351,y:712,t:1527873321454};\\\", \\\"{x:1350,y:712,t:1527873321475};\\\", \\\"{x:1349,y:712,t:1527873321488};\\\", \\\"{x:1348,y:712,t:1527873321503};\\\", \\\"{x:1347,y:712,t:1527873321701};\\\", \\\"{x:1347,y:711,t:1527873321708};\\\", \\\"{x:1347,y:710,t:1527873321723};\\\", \\\"{x:1348,y:709,t:1527873321738};\\\", \\\"{x:1348,y:707,t:1527873321754};\\\", \\\"{x:1349,y:706,t:1527873321771};\\\", \\\"{x:1349,y:705,t:1527873321788};\\\", \\\"{x:1349,y:704,t:1527873321804};\\\", \\\"{x:1351,y:704,t:1527873321900};\\\", \\\"{x:1352,y:704,t:1527873321907};\\\", \\\"{x:1354,y:706,t:1527873321920};\\\", \\\"{x:1355,y:708,t:1527873321937};\\\", \\\"{x:1359,y:714,t:1527873321954};\\\", \\\"{x:1362,y:720,t:1527873321970};\\\", \\\"{x:1368,y:728,t:1527873321987};\\\", \\\"{x:1373,y:737,t:1527873322004};\\\", \\\"{x:1380,y:749,t:1527873322020};\\\", \\\"{x:1388,y:766,t:1527873322038};\\\", \\\"{x:1398,y:781,t:1527873322054};\\\", \\\"{x:1407,y:799,t:1527873322070};\\\", \\\"{x:1415,y:821,t:1527873322088};\\\", \\\"{x:1420,y:840,t:1527873322103};\\\", \\\"{x:1426,y:858,t:1527873322121};\\\", \\\"{x:1431,y:875,t:1527873322138};\\\", \\\"{x:1437,y:892,t:1527873322154};\\\", \\\"{x:1446,y:907,t:1527873322170};\\\", \\\"{x:1458,y:924,t:1527873322187};\\\", \\\"{x:1461,y:926,t:1527873322203};\\\", \\\"{x:1464,y:928,t:1527873322221};\\\", \\\"{x:1465,y:930,t:1527873322237};\\\", \\\"{x:1465,y:932,t:1527873322254};\\\", \\\"{x:1467,y:933,t:1527873322271};\\\", \\\"{x:1468,y:934,t:1527873322287};\\\", \\\"{x:1469,y:935,t:1527873322331};\\\", \\\"{x:1470,y:937,t:1527873322340};\\\", \\\"{x:1470,y:939,t:1527873322372};\\\", \\\"{x:1471,y:939,t:1527873322388};\\\", \\\"{x:1471,y:940,t:1527873322467};\\\", \\\"{x:1472,y:942,t:1527873322499};\\\", \\\"{x:1473,y:944,t:1527873322507};\\\", \\\"{x:1474,y:945,t:1527873322521};\\\", \\\"{x:1475,y:947,t:1527873322537};\\\", \\\"{x:1476,y:950,t:1527873322554};\\\", \\\"{x:1477,y:951,t:1527873322571};\\\", \\\"{x:1477,y:953,t:1527873322588};\\\", \\\"{x:1478,y:954,t:1527873322636};\\\", \\\"{x:1478,y:955,t:1527873322668};\\\", \\\"{x:1480,y:955,t:1527873322691};\\\", \\\"{x:1480,y:954,t:1527873323371};\\\", \\\"{x:1473,y:941,t:1527873323387};\\\", \\\"{x:1458,y:922,t:1527873323403};\\\", \\\"{x:1437,y:897,t:1527873323420};\\\", \\\"{x:1412,y:869,t:1527873323437};\\\", \\\"{x:1384,y:834,t:1527873323454};\\\", \\\"{x:1358,y:793,t:1527873323470};\\\", \\\"{x:1335,y:748,t:1527873323486};\\\", \\\"{x:1315,y:713,t:1527873323504};\\\", \\\"{x:1305,y:694,t:1527873323520};\\\", \\\"{x:1303,y:688,t:1527873323537};\\\", \\\"{x:1303,y:684,t:1527873323554};\\\", \\\"{x:1303,y:682,t:1527873323570};\\\", \\\"{x:1303,y:680,t:1527873323587};\\\", \\\"{x:1303,y:679,t:1527873323604};\\\", \\\"{x:1303,y:678,t:1527873323620};\\\", \\\"{x:1303,y:677,t:1527873323636};\\\", \\\"{x:1304,y:675,t:1527873323654};\\\", \\\"{x:1305,y:674,t:1527873323671};\\\", \\\"{x:1306,y:674,t:1527873323707};\\\", \\\"{x:1307,y:674,t:1527873323720};\\\", \\\"{x:1308,y:674,t:1527873323736};\\\", \\\"{x:1310,y:674,t:1527873323754};\\\", \\\"{x:1311,y:674,t:1527873323771};\\\", \\\"{x:1312,y:674,t:1527873323812};\\\", \\\"{x:1313,y:672,t:1527873323821};\\\", \\\"{x:1313,y:665,t:1527873323836};\\\", \\\"{x:1313,y:655,t:1527873323853};\\\", \\\"{x:1313,y:647,t:1527873323871};\\\", \\\"{x:1311,y:638,t:1527873323887};\\\", \\\"{x:1308,y:631,t:1527873323904};\\\", \\\"{x:1306,y:624,t:1527873323920};\\\", \\\"{x:1301,y:616,t:1527873323937};\\\", \\\"{x:1298,y:607,t:1527873323953};\\\", \\\"{x:1295,y:598,t:1527873323971};\\\", \\\"{x:1290,y:590,t:1527873323987};\\\", \\\"{x:1289,y:585,t:1527873324003};\\\", \\\"{x:1288,y:585,t:1527873324051};\\\", \\\"{x:1287,y:585,t:1527873324059};\\\", \\\"{x:1283,y:585,t:1527873324071};\\\", \\\"{x:1261,y:591,t:1527873324086};\\\", \\\"{x:1215,y:597,t:1527873324103};\\\", \\\"{x:1139,y:600,t:1527873324121};\\\", \\\"{x:1023,y:600,t:1527873324137};\\\", \\\"{x:895,y:600,t:1527873324154};\\\", \\\"{x:750,y:590,t:1527873324172};\\\", \\\"{x:617,y:569,t:1527873324188};\\\", \\\"{x:494,y:547,t:1527873324204};\\\", \\\"{x:455,y:536,t:1527873324227};\\\", \\\"{x:433,y:526,t:1527873324244};\\\", \\\"{x:430,y:524,t:1527873324261};\\\", \\\"{x:430,y:523,t:1527873324283};\\\", \\\"{x:429,y:522,t:1527873324564};\\\", \\\"{x:429,y:520,t:1527873324636};\\\", \\\"{x:431,y:520,t:1527873324644};\\\", \\\"{x:457,y:519,t:1527873324660};\\\", \\\"{x:493,y:519,t:1527873324677};\\\", \\\"{x:551,y:519,t:1527873324694};\\\", \\\"{x:618,y:519,t:1527873324711};\\\", \\\"{x:669,y:519,t:1527873324728};\\\", \\\"{x:708,y:519,t:1527873324745};\\\", \\\"{x:724,y:519,t:1527873324761};\\\", \\\"{x:729,y:518,t:1527873324777};\\\", \\\"{x:729,y:517,t:1527873324804};\\\", \\\"{x:725,y:516,t:1527873324843};\\\", \\\"{x:710,y:515,t:1527873324861};\\\", \\\"{x:691,y:511,t:1527873324878};\\\", \\\"{x:671,y:508,t:1527873324894};\\\", \\\"{x:653,y:505,t:1527873324910};\\\", \\\"{x:638,y:503,t:1527873324928};\\\", \\\"{x:624,y:501,t:1527873324943};\\\", \\\"{x:620,y:501,t:1527873324961};\\\", \\\"{x:617,y:501,t:1527873324978};\\\", \\\"{x:621,y:502,t:1527873325540};\\\", \\\"{x:634,y:506,t:1527873325547};\\\", \\\"{x:653,y:510,t:1527873325561};\\\", \\\"{x:712,y:528,t:1527873325578};\\\", \\\"{x:798,y:551,t:1527873325595};\\\", \\\"{x:942,y:590,t:1527873325611};\\\", \\\"{x:1031,y:617,t:1527873325628};\\\", \\\"{x:1114,y:640,t:1527873325645};\\\", \\\"{x:1175,y:657,t:1527873325662};\\\", \\\"{x:1217,y:676,t:1527873325678};\\\", \\\"{x:1244,y:687,t:1527873325694};\\\", \\\"{x:1255,y:693,t:1527873325712};\\\", \\\"{x:1260,y:695,t:1527873325728};\\\", \\\"{x:1260,y:696,t:1527873325744};\\\", \\\"{x:1271,y:694,t:1527873325830};\\\", \\\"{x:1279,y:688,t:1527873325845};\\\", \\\"{x:1289,y:681,t:1527873325862};\\\", \\\"{x:1301,y:670,t:1527873325879};\\\", \\\"{x:1305,y:661,t:1527873325894};\\\", \\\"{x:1308,y:655,t:1527873325912};\\\", \\\"{x:1308,y:650,t:1527873325929};\\\", \\\"{x:1309,y:647,t:1527873325945};\\\", \\\"{x:1309,y:642,t:1527873325961};\\\", \\\"{x:1309,y:640,t:1527873325979};\\\", \\\"{x:1309,y:636,t:1527873325995};\\\", \\\"{x:1309,y:630,t:1527873326011};\\\", \\\"{x:1309,y:626,t:1527873326029};\\\", \\\"{x:1309,y:623,t:1527873326044};\\\", \\\"{x:1309,y:620,t:1527873326062};\\\", \\\"{x:1307,y:617,t:1527873326079};\\\", \\\"{x:1304,y:610,t:1527873326095};\\\", \\\"{x:1303,y:606,t:1527873326112};\\\", \\\"{x:1300,y:601,t:1527873326128};\\\", \\\"{x:1299,y:595,t:1527873326145};\\\", \\\"{x:1297,y:591,t:1527873326162};\\\", \\\"{x:1297,y:588,t:1527873326179};\\\", \\\"{x:1296,y:586,t:1527873326195};\\\", \\\"{x:1296,y:584,t:1527873326212};\\\", \\\"{x:1296,y:583,t:1527873326244};\\\", \\\"{x:1296,y:585,t:1527873326628};\\\", \\\"{x:1297,y:587,t:1527873326643};\\\", \\\"{x:1299,y:590,t:1527873326651};\\\", \\\"{x:1299,y:591,t:1527873326662};\\\", \\\"{x:1301,y:594,t:1527873326678};\\\", \\\"{x:1301,y:595,t:1527873326708};\\\", \\\"{x:1301,y:596,t:1527873326748};\\\", \\\"{x:1301,y:597,t:1527873326796};\\\", \\\"{x:1302,y:598,t:1527873326820};\\\", \\\"{x:1302,y:599,t:1527873326828};\\\", \\\"{x:1303,y:599,t:1527873326846};\\\", \\\"{x:1304,y:600,t:1527873326863};\\\", \\\"{x:1304,y:602,t:1527873326879};\\\", \\\"{x:1305,y:603,t:1527873326896};\\\", \\\"{x:1306,y:605,t:1527873326913};\\\", \\\"{x:1307,y:607,t:1527873326929};\\\", \\\"{x:1307,y:609,t:1527873326946};\\\", \\\"{x:1310,y:613,t:1527873326962};\\\", \\\"{x:1313,y:618,t:1527873326979};\\\", \\\"{x:1316,y:623,t:1527873326995};\\\", \\\"{x:1318,y:625,t:1527873327013};\\\", \\\"{x:1321,y:630,t:1527873327030};\\\", \\\"{x:1323,y:634,t:1527873327046};\\\", \\\"{x:1326,y:637,t:1527873327063};\\\", \\\"{x:1329,y:642,t:1527873327080};\\\", \\\"{x:1332,y:647,t:1527873327096};\\\", \\\"{x:1336,y:652,t:1527873327112};\\\", \\\"{x:1342,y:660,t:1527873327130};\\\", \\\"{x:1348,y:669,t:1527873327146};\\\", \\\"{x:1355,y:681,t:1527873327163};\\\", \\\"{x:1366,y:708,t:1527873327180};\\\", \\\"{x:1373,y:727,t:1527873327195};\\\", \\\"{x:1382,y:747,t:1527873327213};\\\", \\\"{x:1391,y:763,t:1527873327230};\\\", \\\"{x:1399,y:775,t:1527873327246};\\\", \\\"{x:1405,y:786,t:1527873327263};\\\", \\\"{x:1413,y:803,t:1527873327280};\\\", \\\"{x:1422,y:821,t:1527873327296};\\\", \\\"{x:1432,y:833,t:1527873327312};\\\", \\\"{x:1441,y:848,t:1527873327330};\\\", \\\"{x:1451,y:863,t:1527873327345};\\\", \\\"{x:1456,y:873,t:1527873327363};\\\", \\\"{x:1461,y:886,t:1527873327380};\\\", \\\"{x:1463,y:888,t:1527873327396};\\\", \\\"{x:1464,y:892,t:1527873327413};\\\", \\\"{x:1465,y:896,t:1527873327430};\\\", \\\"{x:1466,y:902,t:1527873327447};\\\", \\\"{x:1468,y:908,t:1527873327463};\\\", \\\"{x:1471,y:919,t:1527873327480};\\\", \\\"{x:1473,y:925,t:1527873327498};\\\", \\\"{x:1474,y:930,t:1527873327513};\\\", \\\"{x:1474,y:931,t:1527873327530};\\\", \\\"{x:1474,y:933,t:1527873327548};\\\", \\\"{x:1474,y:934,t:1527873327563};\\\", \\\"{x:1474,y:936,t:1527873327581};\\\", \\\"{x:1474,y:937,t:1527873327598};\\\", \\\"{x:1474,y:938,t:1527873327627};\\\", \\\"{x:1474,y:939,t:1527873327732};\\\", \\\"{x:1473,y:939,t:1527873329116};\\\", \\\"{x:1463,y:939,t:1527873329131};\\\", \\\"{x:1386,y:916,t:1527873329148};\\\", \\\"{x:1278,y:888,t:1527873329165};\\\", \\\"{x:1173,y:857,t:1527873329181};\\\", \\\"{x:1073,y:830,t:1527873329198};\\\", \\\"{x:993,y:809,t:1527873329215};\\\", \\\"{x:935,y:792,t:1527873329231};\\\", \\\"{x:905,y:784,t:1527873329247};\\\", \\\"{x:889,y:779,t:1527873329265};\\\", \\\"{x:880,y:776,t:1527873329281};\\\", \\\"{x:873,y:774,t:1527873329298};\\\", \\\"{x:865,y:772,t:1527873329315};\\\", \\\"{x:855,y:771,t:1527873329332};\\\", \\\"{x:848,y:770,t:1527873329348};\\\", \\\"{x:831,y:768,t:1527873329365};\\\", \\\"{x:816,y:766,t:1527873329382};\\\", \\\"{x:800,y:761,t:1527873329398};\\\", \\\"{x:785,y:759,t:1527873329415};\\\", \\\"{x:777,y:757,t:1527873329432};\\\", \\\"{x:769,y:755,t:1527873329448};\\\", \\\"{x:761,y:752,t:1527873329465};\\\", \\\"{x:756,y:752,t:1527873329482};\\\", \\\"{x:750,y:749,t:1527873329498};\\\", \\\"{x:741,y:747,t:1527873329515};\\\", \\\"{x:720,y:738,t:1527873329532};\\\", \\\"{x:706,y:734,t:1527873329547};\\\", \\\"{x:693,y:733,t:1527873329565};\\\", \\\"{x:681,y:732,t:1527873329582};\\\", \\\"{x:672,y:731,t:1527873329598};\\\", \\\"{x:670,y:730,t:1527873329615};\\\", \\\"{x:668,y:730,t:1527873329632};\\\", \\\"{x:667,y:730,t:1527873329668};\\\", \\\"{x:665,y:730,t:1527873329692};\\\", \\\"{x:664,y:730,t:1527873329700};\\\", \\\"{x:661,y:730,t:1527873329715};\\\", \\\"{x:653,y:733,t:1527873329732};\\\", \\\"{x:644,y:736,t:1527873329749};\\\", \\\"{x:635,y:739,t:1527873329765};\\\", \\\"{x:621,y:744,t:1527873329782};\\\", \\\"{x:609,y:748,t:1527873329799};\\\", \\\"{x:596,y:752,t:1527873329815};\\\", \\\"{x:590,y:753,t:1527873329832};\\\", \\\"{x:588,y:754,t:1527873329849};\\\", \\\"{x:587,y:754,t:1527873329865};\\\", \\\"{x:586,y:755,t:1527873329882};\\\", \\\"{x:585,y:755,t:1527873330132};\\\", \\\"{x:584,y:756,t:1527873330149};\\\", \\\"{x:583,y:756,t:1527873330171};\\\", \\\"{x:583,y:757,t:1527873330203};\\\", \\\"{x:582,y:757,t:1527873330443};\\\", \\\"{x:581,y:757,t:1527873330467};\\\", \\\"{x:580,y:757,t:1527873330483};\\\", \\\"{x:579,y:757,t:1527873330499};\\\", \\\"{x:578,y:757,t:1527873330532};\\\", \\\"{x:577,y:757,t:1527873330540};\\\", \\\"{x:575,y:757,t:1527873330549};\\\", \\\"{x:574,y:756,t:1527873330566};\\\", \\\"{x:572,y:755,t:1527873330596};\\\", \\\"{x:572,y:754,t:1527873330636};\\\", \\\"{x:570,y:754,t:1527873330652};\\\", \\\"{x:570,y:752,t:1527873330667};\\\", \\\"{x:569,y:752,t:1527873330683};\\\", \\\"{x:567,y:751,t:1527873330699};\\\", \\\"{x:565,y:750,t:1527873330716};\\\", \\\"{x:564,y:750,t:1527873330796};\\\", \\\"{x:563,y:750,t:1527873330804};\\\", \\\"{x:562,y:750,t:1527873330820};\\\", \\\"{x:561,y:750,t:1527873330832};\\\", \\\"{x:558,y:749,t:1527873330849};\\\", \\\"{x:557,y:748,t:1527873330866};\\\", \\\"{x:554,y:747,t:1527873330882};\\\", \\\"{x:553,y:747,t:1527873330898};\\\", \\\"{x:549,y:746,t:1527873330916};\\\", \\\"{x:546,y:746,t:1527873330933};\\\", \\\"{x:542,y:745,t:1527873330949};\\\", \\\"{x:541,y:745,t:1527873330972};\\\", \\\"{x:539,y:743,t:1527873330982};\\\", \\\"{x:537,y:742,t:1527873330999};\\\", \\\"{x:535,y:740,t:1527873331016};\\\", \\\"{x:532,y:738,t:1527873331033};\\\", \\\"{x:530,y:736,t:1527873331049};\\\", \\\"{x:529,y:735,t:1527873331066};\\\", \\\"{x:529,y:734,t:1527873331116};\\\" ] }, { \\\"rt\\\": 10393, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 533328, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-L -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:734,t:1527873333420};\\\", \\\"{x:559,y:736,t:1527873333435};\\\", \\\"{x:607,y:742,t:1527873333453};\\\", \\\"{x:680,y:754,t:1527873333469};\\\", \\\"{x:750,y:764,t:1527873333484};\\\", \\\"{x:828,y:775,t:1527873333501};\\\", \\\"{x:886,y:783,t:1527873333518};\\\", \\\"{x:937,y:791,t:1527873333534};\\\", \\\"{x:967,y:792,t:1527873333551};\\\", \\\"{x:998,y:795,t:1527873333568};\\\", \\\"{x:1025,y:795,t:1527873333584};\\\", \\\"{x:1048,y:795,t:1527873333601};\\\", \\\"{x:1065,y:795,t:1527873333618};\\\", \\\"{x:1081,y:796,t:1527873333634};\\\", \\\"{x:1102,y:800,t:1527873333651};\\\", \\\"{x:1134,y:808,t:1527873333668};\\\", \\\"{x:1158,y:815,t:1527873333685};\\\", \\\"{x:1185,y:827,t:1527873333701};\\\", \\\"{x:1214,y:842,t:1527873333719};\\\", \\\"{x:1245,y:858,t:1527873333734};\\\", \\\"{x:1274,y:871,t:1527873333751};\\\", \\\"{x:1276,y:873,t:1527873333768};\\\", \\\"{x:1278,y:874,t:1527873334339};\\\", \\\"{x:1281,y:875,t:1527873334351};\\\", \\\"{x:1287,y:881,t:1527873334368};\\\", \\\"{x:1288,y:882,t:1527873334385};\\\", \\\"{x:1290,y:885,t:1527873334401};\\\", \\\"{x:1291,y:888,t:1527873334418};\\\", \\\"{x:1294,y:893,t:1527873334434};\\\", \\\"{x:1297,y:899,t:1527873334451};\\\", \\\"{x:1307,y:911,t:1527873334469};\\\", \\\"{x:1311,y:920,t:1527873334486};\\\", \\\"{x:1320,y:933,t:1527873334501};\\\", \\\"{x:1333,y:947,t:1527873334518};\\\", \\\"{x:1345,y:956,t:1527873334535};\\\", \\\"{x:1357,y:962,t:1527873334551};\\\", \\\"{x:1364,y:966,t:1527873334568};\\\", \\\"{x:1368,y:968,t:1527873334585};\\\", \\\"{x:1368,y:969,t:1527873334611};\\\", \\\"{x:1370,y:969,t:1527873334660};\\\", \\\"{x:1368,y:969,t:1527873334812};\\\", \\\"{x:1367,y:969,t:1527873334819};\\\", \\\"{x:1364,y:969,t:1527873334835};\\\", \\\"{x:1362,y:969,t:1527873334851};\\\", \\\"{x:1360,y:969,t:1527873334868};\\\", \\\"{x:1357,y:969,t:1527873334885};\\\", \\\"{x:1355,y:969,t:1527873334902};\\\", \\\"{x:1354,y:969,t:1527873334932};\\\", \\\"{x:1354,y:968,t:1527873335180};\\\", \\\"{x:1354,y:967,t:1527873335195};\\\", \\\"{x:1354,y:966,t:1527873335203};\\\", \\\"{x:1355,y:965,t:1527873335218};\\\", \\\"{x:1358,y:960,t:1527873335236};\\\", \\\"{x:1362,y:955,t:1527873335251};\\\", \\\"{x:1369,y:948,t:1527873335268};\\\", \\\"{x:1373,y:944,t:1527873335286};\\\", \\\"{x:1379,y:940,t:1527873335302};\\\", \\\"{x:1380,y:938,t:1527873335318};\\\", \\\"{x:1382,y:936,t:1527873335335};\\\", \\\"{x:1384,y:934,t:1527873335352};\\\", \\\"{x:1384,y:933,t:1527873335368};\\\", \\\"{x:1385,y:932,t:1527873335385};\\\", \\\"{x:1386,y:931,t:1527873335402};\\\", \\\"{x:1389,y:928,t:1527873335418};\\\", \\\"{x:1391,y:924,t:1527873335435};\\\", \\\"{x:1393,y:921,t:1527873335451};\\\", \\\"{x:1396,y:916,t:1527873335468};\\\", \\\"{x:1397,y:913,t:1527873335486};\\\", \\\"{x:1399,y:908,t:1527873335503};\\\", \\\"{x:1399,y:904,t:1527873335518};\\\", \\\"{x:1400,y:900,t:1527873335535};\\\", \\\"{x:1402,y:896,t:1527873335553};\\\", \\\"{x:1402,y:895,t:1527873335569};\\\", \\\"{x:1403,y:893,t:1527873335586};\\\", \\\"{x:1404,y:891,t:1527873335603};\\\", \\\"{x:1404,y:890,t:1527873335619};\\\", \\\"{x:1404,y:889,t:1527873335636};\\\", \\\"{x:1404,y:887,t:1527873335813};\\\", \\\"{x:1404,y:886,t:1527873335821};\\\", \\\"{x:1407,y:881,t:1527873335837};\\\", \\\"{x:1411,y:869,t:1527873335853};\\\", \\\"{x:1415,y:845,t:1527873335870};\\\", \\\"{x:1419,y:828,t:1527873335886};\\\", \\\"{x:1429,y:802,t:1527873335903};\\\", \\\"{x:1436,y:777,t:1527873335920};\\\", \\\"{x:1446,y:754,t:1527873335936};\\\", \\\"{x:1458,y:726,t:1527873335953};\\\", \\\"{x:1466,y:701,t:1527873335970};\\\", \\\"{x:1476,y:678,t:1527873335985};\\\", \\\"{x:1486,y:655,t:1527873336003};\\\", \\\"{x:1493,y:639,t:1527873336020};\\\", \\\"{x:1498,y:626,t:1527873336036};\\\", \\\"{x:1504,y:612,t:1527873336053};\\\", \\\"{x:1506,y:603,t:1527873336070};\\\", \\\"{x:1511,y:595,t:1527873336086};\\\", \\\"{x:1515,y:587,t:1527873336104};\\\", \\\"{x:1520,y:580,t:1527873336121};\\\", \\\"{x:1525,y:571,t:1527873336136};\\\", \\\"{x:1530,y:559,t:1527873336153};\\\", \\\"{x:1536,y:550,t:1527873336170};\\\", \\\"{x:1544,y:540,t:1527873336186};\\\", \\\"{x:1552,y:529,t:1527873336203};\\\", \\\"{x:1563,y:520,t:1527873336220};\\\", \\\"{x:1571,y:512,t:1527873336237};\\\", \\\"{x:1577,y:507,t:1527873336253};\\\", \\\"{x:1579,y:503,t:1527873336270};\\\", \\\"{x:1580,y:501,t:1527873336288};\\\", \\\"{x:1583,y:498,t:1527873336303};\\\", \\\"{x:1584,y:498,t:1527873336319};\\\", \\\"{x:1584,y:497,t:1527873336564};\\\", \\\"{x:1577,y:497,t:1527873336573};\\\", \\\"{x:1564,y:501,t:1527873336588};\\\", \\\"{x:1513,y:508,t:1527873336603};\\\", \\\"{x:1352,y:528,t:1527873336620};\\\", \\\"{x:1221,y:547,t:1527873336636};\\\", \\\"{x:1061,y:569,t:1527873336653};\\\", \\\"{x:873,y:596,t:1527873336670};\\\", \\\"{x:671,y:624,t:1527873336688};\\\", \\\"{x:500,y:648,t:1527873336703};\\\", \\\"{x:380,y:667,t:1527873336720};\\\", \\\"{x:311,y:677,t:1527873336737};\\\", \\\"{x:279,y:679,t:1527873336754};\\\", \\\"{x:264,y:679,t:1527873336770};\\\", \\\"{x:261,y:681,t:1527873336787};\\\", \\\"{x:261,y:677,t:1527873336891};\\\", \\\"{x:263,y:672,t:1527873336904};\\\", \\\"{x:273,y:656,t:1527873336921};\\\", \\\"{x:283,y:636,t:1527873336938};\\\", \\\"{x:294,y:616,t:1527873336955};\\\", \\\"{x:303,y:601,t:1527873336971};\\\", \\\"{x:310,y:589,t:1527873336988};\\\", \\\"{x:315,y:583,t:1527873337004};\\\", \\\"{x:319,y:579,t:1527873337022};\\\", \\\"{x:323,y:575,t:1527873337038};\\\", \\\"{x:331,y:570,t:1527873337054};\\\", \\\"{x:335,y:568,t:1527873337072};\\\", \\\"{x:338,y:567,t:1527873337088};\\\", \\\"{x:340,y:567,t:1527873337104};\\\", \\\"{x:344,y:567,t:1527873337122};\\\", \\\"{x:345,y:567,t:1527873337138};\\\", \\\"{x:347,y:568,t:1527873337155};\\\", \\\"{x:348,y:569,t:1527873337171};\\\", \\\"{x:351,y:570,t:1527873337188};\\\", \\\"{x:353,y:570,t:1527873337204};\\\", \\\"{x:357,y:570,t:1527873337221};\\\", \\\"{x:362,y:567,t:1527873337238};\\\", \\\"{x:364,y:564,t:1527873337256};\\\", \\\"{x:369,y:563,t:1527873337272};\\\", \\\"{x:374,y:560,t:1527873337289};\\\", \\\"{x:381,y:558,t:1527873337306};\\\", \\\"{x:386,y:553,t:1527873337321};\\\", \\\"{x:389,y:551,t:1527873337338};\\\", \\\"{x:390,y:549,t:1527873337354};\\\", \\\"{x:393,y:547,t:1527873337372};\\\", \\\"{x:396,y:544,t:1527873337387};\\\", \\\"{x:397,y:543,t:1527873337404};\\\", \\\"{x:398,y:542,t:1527873337452};\\\", \\\"{x:399,y:541,t:1527873337476};\\\", \\\"{x:397,y:541,t:1527873337940};\\\", \\\"{x:394,y:545,t:1527873337955};\\\", \\\"{x:387,y:555,t:1527873337973};\\\", \\\"{x:380,y:567,t:1527873337990};\\\", \\\"{x:380,y:574,t:1527873338005};\\\", \\\"{x:379,y:582,t:1527873338021};\\\", \\\"{x:379,y:589,t:1527873338038};\\\", \\\"{x:379,y:599,t:1527873338056};\\\", \\\"{x:379,y:609,t:1527873338071};\\\", \\\"{x:379,y:612,t:1527873338088};\\\", \\\"{x:379,y:615,t:1527873338105};\\\", \\\"{x:379,y:617,t:1527873338122};\\\", \\\"{x:379,y:619,t:1527873338139};\\\", \\\"{x:379,y:620,t:1527873338155};\\\", \\\"{x:379,y:624,t:1527873338884};\\\", \\\"{x:379,y:629,t:1527873338893};\\\", \\\"{x:383,y:634,t:1527873338906};\\\", \\\"{x:397,y:645,t:1527873338922};\\\", \\\"{x:412,y:657,t:1527873338938};\\\", \\\"{x:446,y:680,t:1527873338955};\\\", \\\"{x:466,y:697,t:1527873338972};\\\", \\\"{x:485,y:710,t:1527873338989};\\\", \\\"{x:506,y:725,t:1527873339005};\\\", \\\"{x:522,y:737,t:1527873339023};\\\", \\\"{x:536,y:747,t:1527873339040};\\\", \\\"{x:547,y:754,t:1527873339056};\\\", \\\"{x:556,y:764,t:1527873339073};\\\", \\\"{x:561,y:770,t:1527873339089};\\\", \\\"{x:564,y:778,t:1527873339107};\\\", \\\"{x:566,y:785,t:1527873339123};\\\", \\\"{x:567,y:802,t:1527873339139};\\\", \\\"{x:569,y:807,t:1527873339156};\\\", \\\"{x:569,y:811,t:1527873339173};\\\", \\\"{x:568,y:814,t:1527873339190};\\\", \\\"{x:566,y:819,t:1527873339207};\\\", \\\"{x:564,y:822,t:1527873339223};\\\", \\\"{x:564,y:824,t:1527873339240};\\\", \\\"{x:566,y:823,t:1527873342075};\\\", \\\"{x:568,y:821,t:1527873342091};\\\", \\\"{x:570,y:818,t:1527873342108};\\\", \\\"{x:570,y:814,t:1527873342125};\\\", \\\"{x:570,y:811,t:1527873342142};\\\", \\\"{x:570,y:807,t:1527873342158};\\\", \\\"{x:570,y:804,t:1527873342174};\\\", \\\"{x:570,y:802,t:1527873342192};\\\", \\\"{x:568,y:798,t:1527873342209};\\\", \\\"{x:565,y:795,t:1527873342225};\\\", \\\"{x:563,y:792,t:1527873342242};\\\", \\\"{x:560,y:788,t:1527873342258};\\\", \\\"{x:557,y:785,t:1527873342276};\\\", \\\"{x:554,y:778,t:1527873342292};\\\", \\\"{x:551,y:775,t:1527873342309};\\\", \\\"{x:550,y:772,t:1527873342326};\\\", \\\"{x:547,y:770,t:1527873342342};\\\", \\\"{x:547,y:768,t:1527873342360};\\\", \\\"{x:545,y:767,t:1527873342376};\\\", \\\"{x:544,y:766,t:1527873342392};\\\", \\\"{x:544,y:764,t:1527873342436};\\\", \\\"{x:543,y:762,t:1527873342453};\\\", \\\"{x:543,y:760,t:1527873342460};\\\", \\\"{x:543,y:758,t:1527873342476};\\\", \\\"{x:541,y:755,t:1527873342493};\\\", \\\"{x:541,y:754,t:1527873342510};\\\", \\\"{x:541,y:752,t:1527873342525};\\\", \\\"{x:541,y:749,t:1527873342542};\\\", \\\"{x:541,y:748,t:1527873342557};\\\", \\\"{x:541,y:742,t:1527873342573};\\\", \\\"{x:541,y:739,t:1527873342591};\\\", \\\"{x:541,y:737,t:1527873342607};\\\", \\\"{x:541,y:735,t:1527873342624};\\\", \\\"{x:540,y:733,t:1527873342641};\\\", \\\"{x:540,y:732,t:1527873342656};\\\", \\\"{x:540,y:731,t:1527873342673};\\\", \\\"{x:539,y:729,t:1527873342690};\\\", \\\"{x:538,y:726,t:1527873342707};\\\", \\\"{x:537,y:723,t:1527873342724};\\\", \\\"{x:537,y:722,t:1527873343107};\\\", \\\"{x:536,y:722,t:1527873343116};\\\", \\\"{x:535,y:722,t:1527873343125};\\\", \\\"{x:533,y:723,t:1527873343142};\\\", \\\"{x:532,y:723,t:1527873343188};\\\", \\\"{x:531,y:725,t:1527873343220};\\\", \\\"{x:530,y:725,t:1527873343403};\\\", \\\"{x:529,y:726,t:1527873343748};\\\", \\\"{x:529,y:727,t:1527873343771};\\\", \\\"{x:527,y:727,t:1527873343788};\\\" ] }, { \\\"rt\\\": 7650, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 542192, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:728,t:1527873345157};\\\", \\\"{x:527,y:731,t:1527873345164};\\\", \\\"{x:536,y:743,t:1527873345180};\\\", \\\"{x:547,y:754,t:1527873345196};\\\", \\\"{x:572,y:770,t:1527873345214};\\\", \\\"{x:613,y:792,t:1527873345230};\\\", \\\"{x:663,y:815,t:1527873345244};\\\", \\\"{x:708,y:836,t:1527873345261};\\\", \\\"{x:746,y:858,t:1527873345277};\\\", \\\"{x:780,y:874,t:1527873345294};\\\", \\\"{x:810,y:887,t:1527873345311};\\\", \\\"{x:830,y:896,t:1527873345328};\\\", \\\"{x:843,y:904,t:1527873345344};\\\", \\\"{x:855,y:913,t:1527873345361};\\\", \\\"{x:858,y:918,t:1527873345378};\\\", \\\"{x:858,y:923,t:1527873345394};\\\", \\\"{x:860,y:925,t:1527873345997};\\\", \\\"{x:870,y:925,t:1527873346011};\\\", \\\"{x:897,y:927,t:1527873346028};\\\", \\\"{x:914,y:927,t:1527873346045};\\\", \\\"{x:934,y:927,t:1527873346061};\\\", \\\"{x:954,y:927,t:1527873346078};\\\", \\\"{x:979,y:927,t:1527873346095};\\\", \\\"{x:1001,y:927,t:1527873346111};\\\", \\\"{x:1026,y:927,t:1527873346127};\\\", \\\"{x:1055,y:927,t:1527873346145};\\\", \\\"{x:1088,y:927,t:1527873346161};\\\", \\\"{x:1122,y:927,t:1527873346178};\\\", \\\"{x:1158,y:927,t:1527873346195};\\\", \\\"{x:1192,y:924,t:1527873346212};\\\", \\\"{x:1237,y:917,t:1527873346228};\\\", \\\"{x:1258,y:910,t:1527873346246};\\\", \\\"{x:1276,y:901,t:1527873346261};\\\", \\\"{x:1290,y:896,t:1527873346278};\\\", \\\"{x:1300,y:892,t:1527873346296};\\\", \\\"{x:1305,y:887,t:1527873346312};\\\", \\\"{x:1307,y:886,t:1527873346329};\\\", \\\"{x:1308,y:886,t:1527873346345};\\\", \\\"{x:1310,y:884,t:1527873346748};\\\", \\\"{x:1311,y:882,t:1527873346762};\\\", \\\"{x:1317,y:874,t:1527873346778};\\\", \\\"{x:1322,y:867,t:1527873346795};\\\", \\\"{x:1334,y:850,t:1527873346811};\\\", \\\"{x:1342,y:836,t:1527873346828};\\\", \\\"{x:1349,y:822,t:1527873346845};\\\", \\\"{x:1356,y:804,t:1527873346862};\\\", \\\"{x:1359,y:789,t:1527873346878};\\\", \\\"{x:1365,y:772,t:1527873346896};\\\", \\\"{x:1369,y:755,t:1527873346912};\\\", \\\"{x:1375,y:736,t:1527873346928};\\\", \\\"{x:1382,y:717,t:1527873346945};\\\", \\\"{x:1389,y:695,t:1527873346962};\\\", \\\"{x:1391,y:681,t:1527873346979};\\\", \\\"{x:1394,y:663,t:1527873346996};\\\", \\\"{x:1397,y:641,t:1527873347013};\\\", \\\"{x:1400,y:627,t:1527873347029};\\\", \\\"{x:1401,y:617,t:1527873347045};\\\", \\\"{x:1405,y:605,t:1527873347062};\\\", \\\"{x:1409,y:593,t:1527873347079};\\\", \\\"{x:1411,y:582,t:1527873347095};\\\", \\\"{x:1412,y:574,t:1527873347112};\\\", \\\"{x:1414,y:569,t:1527873347129};\\\", \\\"{x:1414,y:566,t:1527873347147};\\\", \\\"{x:1415,y:564,t:1527873347162};\\\", \\\"{x:1416,y:563,t:1527873347179};\\\", \\\"{x:1416,y:562,t:1527873347565};\\\", \\\"{x:1413,y:564,t:1527873347579};\\\", \\\"{x:1394,y:574,t:1527873347597};\\\", \\\"{x:1335,y:602,t:1527873347612};\\\", \\\"{x:1273,y:630,t:1527873347628};\\\", \\\"{x:1187,y:659,t:1527873347645};\\\", \\\"{x:1082,y:685,t:1527873347662};\\\", \\\"{x:979,y:715,t:1527873347679};\\\", \\\"{x:882,y:743,t:1527873347695};\\\", \\\"{x:810,y:763,t:1527873347712};\\\", \\\"{x:757,y:772,t:1527873347729};\\\", \\\"{x:721,y:778,t:1527873347745};\\\", \\\"{x:688,y:779,t:1527873347762};\\\", \\\"{x:663,y:779,t:1527873347779};\\\", \\\"{x:625,y:779,t:1527873347796};\\\", \\\"{x:594,y:779,t:1527873347811};\\\", \\\"{x:568,y:777,t:1527873347829};\\\", \\\"{x:538,y:771,t:1527873347846};\\\", \\\"{x:520,y:765,t:1527873347862};\\\", \\\"{x:503,y:760,t:1527873347879};\\\", \\\"{x:492,y:754,t:1527873347897};\\\", \\\"{x:484,y:751,t:1527873347912};\\\", \\\"{x:480,y:749,t:1527873347928};\\\", \\\"{x:478,y:747,t:1527873347946};\\\", \\\"{x:477,y:747,t:1527873347963};\\\", \\\"{x:476,y:741,t:1527873347979};\\\", \\\"{x:475,y:736,t:1527873347997};\\\", \\\"{x:471,y:725,t:1527873348013};\\\", \\\"{x:470,y:713,t:1527873348030};\\\", \\\"{x:469,y:701,t:1527873348047};\\\", \\\"{x:466,y:687,t:1527873348063};\\\", \\\"{x:465,y:672,t:1527873348080};\\\", \\\"{x:462,y:656,t:1527873348097};\\\", \\\"{x:460,y:642,t:1527873348114};\\\", \\\"{x:459,y:631,t:1527873348131};\\\", \\\"{x:457,y:622,t:1527873348146};\\\", \\\"{x:455,y:609,t:1527873348163};\\\", \\\"{x:451,y:596,t:1527873348180};\\\", \\\"{x:445,y:585,t:1527873348197};\\\", \\\"{x:440,y:577,t:1527873348214};\\\", \\\"{x:431,y:567,t:1527873348230};\\\", \\\"{x:426,y:561,t:1527873348247};\\\", \\\"{x:419,y:554,t:1527873348264};\\\", \\\"{x:414,y:548,t:1527873348281};\\\", \\\"{x:409,y:543,t:1527873348297};\\\", \\\"{x:402,y:540,t:1527873348314};\\\", \\\"{x:399,y:539,t:1527873348330};\\\", \\\"{x:394,y:539,t:1527873348346};\\\", \\\"{x:386,y:539,t:1527873348364};\\\", \\\"{x:374,y:539,t:1527873348381};\\\", \\\"{x:358,y:539,t:1527873348398};\\\", \\\"{x:335,y:539,t:1527873348414};\\\", \\\"{x:309,y:539,t:1527873348431};\\\", \\\"{x:282,y:539,t:1527873348448};\\\", \\\"{x:256,y:539,t:1527873348464};\\\", \\\"{x:241,y:538,t:1527873348481};\\\", \\\"{x:234,y:538,t:1527873348496};\\\", \\\"{x:237,y:538,t:1527873348620};\\\", \\\"{x:244,y:538,t:1527873348631};\\\", \\\"{x:267,y:538,t:1527873348647};\\\", \\\"{x:325,y:538,t:1527873348665};\\\", \\\"{x:420,y:538,t:1527873348680};\\\", \\\"{x:517,y:538,t:1527873348697};\\\", \\\"{x:619,y:538,t:1527873348714};\\\", \\\"{x:706,y:534,t:1527873348731};\\\", \\\"{x:773,y:534,t:1527873348747};\\\", \\\"{x:826,y:534,t:1527873348764};\\\", \\\"{x:834,y:534,t:1527873348781};\\\", \\\"{x:835,y:534,t:1527873348796};\\\", \\\"{x:836,y:534,t:1527873349044};\\\", \\\"{x:835,y:535,t:1527873349060};\\\", \\\"{x:835,y:537,t:1527873349068};\\\", \\\"{x:832,y:538,t:1527873349084};\\\", \\\"{x:832,y:540,t:1527873349100};\\\", \\\"{x:831,y:541,t:1527873349115};\\\", \\\"{x:831,y:542,t:1527873349616};\\\", \\\"{x:829,y:545,t:1527873349624};\\\", \\\"{x:827,y:546,t:1527873349636};\\\", \\\"{x:818,y:554,t:1527873349652};\\\", \\\"{x:811,y:559,t:1527873349670};\\\", \\\"{x:797,y:567,t:1527873349686};\\\", \\\"{x:785,y:573,t:1527873349702};\\\", \\\"{x:769,y:583,t:1527873349718};\\\", \\\"{x:732,y:603,t:1527873349738};\\\", \\\"{x:709,y:620,t:1527873349753};\\\", \\\"{x:689,y:634,t:1527873349769};\\\", \\\"{x:671,y:650,t:1527873349786};\\\", \\\"{x:658,y:663,t:1527873349801};\\\", \\\"{x:646,y:676,t:1527873349819};\\\", \\\"{x:641,y:683,t:1527873349835};\\\", \\\"{x:635,y:688,t:1527873349851};\\\", \\\"{x:630,y:693,t:1527873349869};\\\", \\\"{x:626,y:696,t:1527873349885};\\\", \\\"{x:623,y:698,t:1527873349902};\\\", \\\"{x:621,y:700,t:1527873349919};\\\", \\\"{x:618,y:703,t:1527873349935};\\\", \\\"{x:612,y:707,t:1527873349952};\\\", \\\"{x:609,y:710,t:1527873349969};\\\", \\\"{x:605,y:714,t:1527873349985};\\\", \\\"{x:599,y:717,t:1527873350003};\\\", \\\"{x:594,y:720,t:1527873350019};\\\", \\\"{x:590,y:723,t:1527873350035};\\\", \\\"{x:583,y:726,t:1527873350052};\\\", \\\"{x:575,y:729,t:1527873350069};\\\", \\\"{x:570,y:732,t:1527873350085};\\\", \\\"{x:565,y:735,t:1527873350102};\\\", \\\"{x:563,y:737,t:1527873350119};\\\", \\\"{x:561,y:738,t:1527873350134};\\\", \\\"{x:560,y:739,t:1527873350152};\\\", \\\"{x:558,y:739,t:1527873350168};\\\", \\\"{x:557,y:739,t:1527873350186};\\\", \\\"{x:556,y:740,t:1527873350204};\\\", \\\"{x:555,y:740,t:1527873350220};\\\", \\\"{x:554,y:741,t:1527873350256};\\\", \\\"{x:552,y:741,t:1527873350288};\\\", \\\"{x:551,y:742,t:1527873350304};\\\", \\\"{x:549,y:742,t:1527873350320};\\\", \\\"{x:548,y:742,t:1527873350337};\\\", \\\"{x:546,y:742,t:1527873350360};\\\", \\\"{x:545,y:742,t:1527873350417};\\\", \\\"{x:543,y:742,t:1527873350431};\\\", \\\"{x:542,y:743,t:1527873350456};\\\", \\\"{x:541,y:743,t:1527873350472};\\\", \\\"{x:540,y:743,t:1527873350520};\\\", \\\"{x:539,y:743,t:1527873350537};\\\", \\\"{x:536,y:743,t:1527873350554};\\\", \\\"{x:535,y:743,t:1527873350570};\\\", \\\"{x:533,y:743,t:1527873350587};\\\", \\\"{x:532,y:743,t:1527873350624};\\\", \\\"{x:531,y:743,t:1527873350637};\\\", \\\"{x:530,y:743,t:1527873350655};\\\", \\\"{x:529,y:743,t:1527873350671};\\\", \\\"{x:528,y:743,t:1527873350687};\\\", \\\"{x:527,y:743,t:1527873350704};\\\", \\\"{x:526,y:743,t:1527873350799};\\\", \\\"{x:525,y:743,t:1527873350839};\\\", \\\"{x:524,y:742,t:1527873350854};\\\", \\\"{x:524,y:741,t:1527873350870};\\\", \\\"{x:523,y:741,t:1527873350888};\\\" ] }, { \\\"rt\\\": 33850, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 577303, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 7, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -F -Z -1-N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:741,t:1527873354496};\\\", \\\"{x:541,y:742,t:1527873354504};\\\", \\\"{x:557,y:745,t:1527873354519};\\\", \\\"{x:620,y:755,t:1527873354538};\\\", \\\"{x:670,y:767,t:1527873354551};\\\", \\\"{x:728,y:782,t:1527873354573};\\\", \\\"{x:780,y:795,t:1527873354590};\\\", \\\"{x:827,y:805,t:1527873354606};\\\", \\\"{x:872,y:812,t:1527873354623};\\\", \\\"{x:914,y:819,t:1527873354639};\\\", \\\"{x:932,y:824,t:1527873354656};\\\", \\\"{x:945,y:827,t:1527873354673};\\\", \\\"{x:958,y:830,t:1527873354690};\\\", \\\"{x:968,y:832,t:1527873354706};\\\", \\\"{x:977,y:833,t:1527873354723};\\\", \\\"{x:989,y:834,t:1527873354741};\\\", \\\"{x:999,y:834,t:1527873354756};\\\", \\\"{x:1013,y:834,t:1527873354774};\\\", \\\"{x:1029,y:834,t:1527873354790};\\\", \\\"{x:1049,y:834,t:1527873354806};\\\", \\\"{x:1068,y:834,t:1527873354823};\\\", \\\"{x:1100,y:834,t:1527873354840};\\\", \\\"{x:1125,y:834,t:1527873354856};\\\", \\\"{x:1147,y:838,t:1527873354873};\\\", \\\"{x:1162,y:840,t:1527873354891};\\\", \\\"{x:1175,y:842,t:1527873354906};\\\", \\\"{x:1176,y:842,t:1527873354923};\\\", \\\"{x:1177,y:842,t:1527873355416};\\\", \\\"{x:1178,y:842,t:1527873355440};\\\", \\\"{x:1192,y:843,t:1527873355457};\\\", \\\"{x:1213,y:848,t:1527873355474};\\\", \\\"{x:1226,y:851,t:1527873355490};\\\", \\\"{x:1242,y:854,t:1527873355508};\\\", \\\"{x:1255,y:855,t:1527873355525};\\\", \\\"{x:1269,y:857,t:1527873355541};\\\", \\\"{x:1279,y:859,t:1527873355557};\\\", \\\"{x:1290,y:859,t:1527873355574};\\\", \\\"{x:1302,y:859,t:1527873355591};\\\", \\\"{x:1320,y:859,t:1527873355608};\\\", \\\"{x:1349,y:859,t:1527873355624};\\\", \\\"{x:1375,y:859,t:1527873355641};\\\", \\\"{x:1405,y:859,t:1527873355658};\\\", \\\"{x:1436,y:859,t:1527873355674};\\\", \\\"{x:1474,y:856,t:1527873355691};\\\", \\\"{x:1512,y:848,t:1527873355708};\\\", \\\"{x:1551,y:836,t:1527873355725};\\\", \\\"{x:1583,y:828,t:1527873355742};\\\", \\\"{x:1609,y:819,t:1527873355758};\\\", \\\"{x:1623,y:814,t:1527873355775};\\\", \\\"{x:1632,y:810,t:1527873355791};\\\", \\\"{x:1637,y:805,t:1527873355807};\\\", \\\"{x:1641,y:798,t:1527873355824};\\\", \\\"{x:1643,y:795,t:1527873355842};\\\", \\\"{x:1644,y:792,t:1527873355857};\\\", \\\"{x:1646,y:790,t:1527873355874};\\\", \\\"{x:1647,y:787,t:1527873355891};\\\", \\\"{x:1647,y:786,t:1527873355907};\\\", \\\"{x:1647,y:785,t:1527873356017};\\\", \\\"{x:1647,y:784,t:1527873356032};\\\", \\\"{x:1646,y:784,t:1527873356048};\\\", \\\"{x:1645,y:783,t:1527873356058};\\\", \\\"{x:1644,y:783,t:1527873356074};\\\", \\\"{x:1644,y:782,t:1527873356092};\\\", \\\"{x:1643,y:781,t:1527873356109};\\\", \\\"{x:1642,y:780,t:1527873356152};\\\", \\\"{x:1641,y:780,t:1527873356169};\\\", \\\"{x:1639,y:779,t:1527873356184};\\\", \\\"{x:1638,y:779,t:1527873356192};\\\", \\\"{x:1634,y:779,t:1527873356208};\\\", \\\"{x:1629,y:778,t:1527873356225};\\\", \\\"{x:1621,y:778,t:1527873356242};\\\", \\\"{x:1615,y:778,t:1527873356258};\\\", \\\"{x:1609,y:778,t:1527873356275};\\\", \\\"{x:1607,y:778,t:1527873356292};\\\", \\\"{x:1606,y:778,t:1527873356308};\\\", \\\"{x:1604,y:778,t:1527873356324};\\\", \\\"{x:1603,y:778,t:1527873356352};\\\", \\\"{x:1601,y:778,t:1527873356368};\\\", \\\"{x:1600,y:778,t:1527873356376};\\\", \\\"{x:1599,y:778,t:1527873356392};\\\", \\\"{x:1597,y:778,t:1527873356409};\\\", \\\"{x:1596,y:778,t:1527873356456};\\\", \\\"{x:1595,y:778,t:1527873356472};\\\", \\\"{x:1594,y:778,t:1527873356497};\\\", \\\"{x:1594,y:779,t:1527873356728};\\\", \\\"{x:1594,y:780,t:1527873356744};\\\", \\\"{x:1594,y:781,t:1527873356759};\\\", \\\"{x:1593,y:784,t:1527873356776};\\\", \\\"{x:1593,y:786,t:1527873356793};\\\", \\\"{x:1591,y:787,t:1527873356809};\\\", \\\"{x:1588,y:788,t:1527873356826};\\\", \\\"{x:1586,y:789,t:1527873356843};\\\", \\\"{x:1585,y:789,t:1527873356872};\\\", \\\"{x:1584,y:787,t:1527873356904};\\\", \\\"{x:1584,y:782,t:1527873356912};\\\", \\\"{x:1584,y:777,t:1527873356925};\\\", \\\"{x:1584,y:763,t:1527873356942};\\\", \\\"{x:1588,y:746,t:1527873356959};\\\", \\\"{x:1598,y:719,t:1527873356976};\\\", \\\"{x:1608,y:700,t:1527873356992};\\\", \\\"{x:1614,y:681,t:1527873357009};\\\", \\\"{x:1616,y:660,t:1527873357027};\\\", \\\"{x:1618,y:637,t:1527873357042};\\\", \\\"{x:1618,y:617,t:1527873357059};\\\", \\\"{x:1618,y:602,t:1527873357076};\\\", \\\"{x:1618,y:591,t:1527873357092};\\\", \\\"{x:1616,y:580,t:1527873357109};\\\", \\\"{x:1612,y:570,t:1527873357126};\\\", \\\"{x:1609,y:566,t:1527873357143};\\\", \\\"{x:1604,y:562,t:1527873357160};\\\", \\\"{x:1602,y:561,t:1527873357176};\\\", \\\"{x:1601,y:561,t:1527873357201};\\\", \\\"{x:1599,y:560,t:1527873357210};\\\", \\\"{x:1591,y:557,t:1527873357226};\\\", \\\"{x:1578,y:552,t:1527873357242};\\\", \\\"{x:1566,y:547,t:1527873357260};\\\", \\\"{x:1559,y:543,t:1527873357275};\\\", \\\"{x:1554,y:540,t:1527873357293};\\\", \\\"{x:1541,y:532,t:1527873357310};\\\", \\\"{x:1525,y:522,t:1527873357326};\\\", \\\"{x:1512,y:516,t:1527873357343};\\\", \\\"{x:1486,y:503,t:1527873357361};\\\", \\\"{x:1481,y:500,t:1527873357376};\\\", \\\"{x:1480,y:497,t:1527873357393};\\\", \\\"{x:1479,y:491,t:1527873357410};\\\", \\\"{x:1476,y:483,t:1527873357426};\\\", \\\"{x:1475,y:475,t:1527873357443};\\\", \\\"{x:1473,y:469,t:1527873357460};\\\", \\\"{x:1471,y:464,t:1527873357476};\\\", \\\"{x:1469,y:462,t:1527873357492};\\\", \\\"{x:1468,y:462,t:1527873357510};\\\", \\\"{x:1466,y:461,t:1527873357527};\\\", \\\"{x:1465,y:459,t:1527873357542};\\\", \\\"{x:1462,y:447,t:1527873357560};\\\", \\\"{x:1462,y:442,t:1527873357576};\\\", \\\"{x:1461,y:435,t:1527873357593};\\\", \\\"{x:1461,y:421,t:1527873357610};\\\", \\\"{x:1461,y:405,t:1527873357627};\\\", \\\"{x:1461,y:389,t:1527873357643};\\\", \\\"{x:1462,y:373,t:1527873357660};\\\", \\\"{x:1463,y:361,t:1527873357677};\\\", \\\"{x:1465,y:350,t:1527873357693};\\\", \\\"{x:1467,y:340,t:1527873357710};\\\", \\\"{x:1467,y:335,t:1527873357727};\\\", \\\"{x:1467,y:331,t:1527873357743};\\\", \\\"{x:1464,y:331,t:1527873357784};\\\", \\\"{x:1459,y:336,t:1527873357794};\\\", \\\"{x:1452,y:348,t:1527873357810};\\\", \\\"{x:1441,y:366,t:1527873357826};\\\", \\\"{x:1425,y:389,t:1527873357843};\\\", \\\"{x:1408,y:411,t:1527873357860};\\\", \\\"{x:1389,y:436,t:1527873357877};\\\", \\\"{x:1375,y:456,t:1527873357894};\\\", \\\"{x:1362,y:477,t:1527873357910};\\\", \\\"{x:1352,y:495,t:1527873357927};\\\", \\\"{x:1338,y:522,t:1527873357944};\\\", \\\"{x:1327,y:541,t:1527873357960};\\\", \\\"{x:1317,y:559,t:1527873357976};\\\", \\\"{x:1306,y:577,t:1527873357994};\\\", \\\"{x:1293,y:596,t:1527873358009};\\\", \\\"{x:1283,y:613,t:1527873358027};\\\", \\\"{x:1276,y:628,t:1527873358043};\\\", \\\"{x:1271,y:644,t:1527873358059};\\\", \\\"{x:1267,y:656,t:1527873358076};\\\", \\\"{x:1262,y:665,t:1527873358093};\\\", \\\"{x:1260,y:671,t:1527873358109};\\\", \\\"{x:1258,y:674,t:1527873358126};\\\", \\\"{x:1254,y:685,t:1527873358143};\\\", \\\"{x:1252,y:693,t:1527873358160};\\\", \\\"{x:1250,y:698,t:1527873358176};\\\", \\\"{x:1249,y:706,t:1527873358193};\\\", \\\"{x:1249,y:711,t:1527873358209};\\\", \\\"{x:1249,y:717,t:1527873358226};\\\", \\\"{x:1249,y:722,t:1527873358243};\\\", \\\"{x:1253,y:727,t:1527873358260};\\\", \\\"{x:1262,y:734,t:1527873358276};\\\", \\\"{x:1269,y:736,t:1527873358294};\\\", \\\"{x:1273,y:736,t:1527873358311};\\\", \\\"{x:1279,y:736,t:1527873358326};\\\", \\\"{x:1284,y:736,t:1527873358343};\\\", \\\"{x:1289,y:734,t:1527873358360};\\\", \\\"{x:1292,y:733,t:1527873358377};\\\", \\\"{x:1295,y:732,t:1527873358393};\\\", \\\"{x:1295,y:731,t:1527873358416};\\\", \\\"{x:1296,y:731,t:1527873358427};\\\", \\\"{x:1297,y:731,t:1527873358444};\\\", \\\"{x:1297,y:730,t:1527873358461};\\\", \\\"{x:1298,y:730,t:1527873358488};\\\", \\\"{x:1298,y:728,t:1527873358496};\\\", \\\"{x:1300,y:728,t:1527873358512};\\\", \\\"{x:1300,y:727,t:1527873358528};\\\", \\\"{x:1302,y:725,t:1527873358552};\\\", \\\"{x:1303,y:724,t:1527873358568};\\\", \\\"{x:1304,y:723,t:1527873358577};\\\", \\\"{x:1307,y:720,t:1527873358593};\\\", \\\"{x:1311,y:717,t:1527873358610};\\\", \\\"{x:1312,y:714,t:1527873358627};\\\", \\\"{x:1315,y:712,t:1527873358643};\\\", \\\"{x:1316,y:711,t:1527873358661};\\\", \\\"{x:1318,y:710,t:1527873358677};\\\", \\\"{x:1318,y:709,t:1527873358693};\\\", \\\"{x:1321,y:707,t:1527873358711};\\\", \\\"{x:1325,y:706,t:1527873358728};\\\", \\\"{x:1328,y:705,t:1527873358744};\\\", \\\"{x:1332,y:703,t:1527873358761};\\\", \\\"{x:1335,y:702,t:1527873358777};\\\", \\\"{x:1338,y:701,t:1527873358793};\\\", \\\"{x:1342,y:700,t:1527873358810};\\\", \\\"{x:1344,y:699,t:1527873358830};\\\", \\\"{x:1346,y:699,t:1527873358844};\\\", \\\"{x:1348,y:699,t:1527873358861};\\\", \\\"{x:1349,y:698,t:1527873358879};\\\", \\\"{x:1350,y:697,t:1527873358896};\\\", \\\"{x:1351,y:697,t:1527873358920};\\\", \\\"{x:1352,y:697,t:1527873358936};\\\", \\\"{x:1354,y:697,t:1527873358953};\\\", \\\"{x:1355,y:697,t:1527873358961};\\\", \\\"{x:1357,y:697,t:1527873358978};\\\", \\\"{x:1361,y:697,t:1527873358994};\\\", \\\"{x:1362,y:697,t:1527873359011};\\\", \\\"{x:1363,y:697,t:1527873359027};\\\", \\\"{x:1365,y:697,t:1527873359045};\\\", \\\"{x:1366,y:697,t:1527873359081};\\\", \\\"{x:1367,y:697,t:1527873359095};\\\", \\\"{x:1368,y:698,t:1527873359111};\\\", \\\"{x:1370,y:698,t:1527873359128};\\\", \\\"{x:1371,y:698,t:1527873359145};\\\", \\\"{x:1373,y:698,t:1527873359161};\\\", \\\"{x:1374,y:698,t:1527873359178};\\\", \\\"{x:1376,y:698,t:1527873359195};\\\", \\\"{x:1377,y:698,t:1527873359224};\\\", \\\"{x:1379,y:700,t:1527873359240};\\\", \\\"{x:1380,y:700,t:1527873359256};\\\", \\\"{x:1381,y:700,t:1527873359265};\\\", \\\"{x:1382,y:700,t:1527873359278};\\\", \\\"{x:1384,y:700,t:1527873359295};\\\", \\\"{x:1387,y:700,t:1527873359312};\\\", \\\"{x:1390,y:700,t:1527873359328};\\\", \\\"{x:1394,y:700,t:1527873359345};\\\", \\\"{x:1400,y:700,t:1527873359362};\\\", \\\"{x:1407,y:699,t:1527873359378};\\\", \\\"{x:1420,y:699,t:1527873359395};\\\", \\\"{x:1437,y:695,t:1527873359412};\\\", \\\"{x:1457,y:690,t:1527873359428};\\\", \\\"{x:1478,y:684,t:1527873359445};\\\", \\\"{x:1497,y:679,t:1527873359463};\\\", \\\"{x:1520,y:677,t:1527873359477};\\\", \\\"{x:1538,y:676,t:1527873359495};\\\", \\\"{x:1567,y:676,t:1527873359512};\\\", \\\"{x:1583,y:676,t:1527873359528};\\\", \\\"{x:1599,y:676,t:1527873359544};\\\", \\\"{x:1613,y:676,t:1527873359561};\\\", \\\"{x:1623,y:676,t:1527873359578};\\\", \\\"{x:1628,y:676,t:1527873359594};\\\", \\\"{x:1631,y:676,t:1527873359611};\\\", \\\"{x:1633,y:676,t:1527873359629};\\\", \\\"{x:1634,y:676,t:1527873359743};\\\", \\\"{x:1634,y:677,t:1527873359759};\\\", \\\"{x:1634,y:678,t:1527873359783};\\\", \\\"{x:1634,y:680,t:1527873359794};\\\", \\\"{x:1634,y:681,t:1527873359832};\\\", \\\"{x:1633,y:682,t:1527873359845};\\\", \\\"{x:1633,y:683,t:1527873359863};\\\", \\\"{x:1632,y:685,t:1527873359880};\\\", \\\"{x:1631,y:686,t:1527873359895};\\\", \\\"{x:1630,y:687,t:1527873359911};\\\", \\\"{x:1629,y:687,t:1527873359928};\\\", \\\"{x:1628,y:690,t:1527873359945};\\\", \\\"{x:1627,y:691,t:1527873359961};\\\", \\\"{x:1625,y:693,t:1527873359978};\\\", \\\"{x:1625,y:694,t:1527873359996};\\\", \\\"{x:1624,y:694,t:1527873360011};\\\", \\\"{x:1623,y:694,t:1527873360105};\\\", \\\"{x:1622,y:694,t:1527873360120};\\\", \\\"{x:1621,y:694,t:1527873360136};\\\", \\\"{x:1620,y:693,t:1527873360145};\\\", \\\"{x:1619,y:693,t:1527873360225};\\\", \\\"{x:1616,y:693,t:1527873360263};\\\", \\\"{x:1615,y:693,t:1527873360278};\\\", \\\"{x:1612,y:697,t:1527873360295};\\\", \\\"{x:1611,y:697,t:1527873360569};\\\", \\\"{x:1611,y:698,t:1527873360584};\\\", \\\"{x:1611,y:699,t:1527873360596};\\\", \\\"{x:1609,y:703,t:1527873360614};\\\", \\\"{x:1608,y:706,t:1527873360629};\\\", \\\"{x:1606,y:711,t:1527873360646};\\\", \\\"{x:1604,y:715,t:1527873360663};\\\", \\\"{x:1601,y:723,t:1527873360679};\\\", \\\"{x:1598,y:735,t:1527873360696};\\\", \\\"{x:1594,y:745,t:1527873360713};\\\", \\\"{x:1586,y:758,t:1527873360730};\\\", \\\"{x:1576,y:774,t:1527873360746};\\\", \\\"{x:1566,y:789,t:1527873360763};\\\", \\\"{x:1558,y:803,t:1527873360780};\\\", \\\"{x:1552,y:818,t:1527873360796};\\\", \\\"{x:1548,y:828,t:1527873360813};\\\", \\\"{x:1543,y:837,t:1527873360830};\\\", \\\"{x:1540,y:844,t:1527873360845};\\\", \\\"{x:1538,y:848,t:1527873360863};\\\", \\\"{x:1534,y:854,t:1527873360880};\\\", \\\"{x:1533,y:855,t:1527873360896};\\\", \\\"{x:1533,y:856,t:1527873360913};\\\", \\\"{x:1533,y:854,t:1527873360977};\\\", \\\"{x:1535,y:847,t:1527873360984};\\\", \\\"{x:1538,y:837,t:1527873360996};\\\", \\\"{x:1541,y:822,t:1527873361013};\\\", \\\"{x:1550,y:798,t:1527873361030};\\\", \\\"{x:1561,y:774,t:1527873361046};\\\", \\\"{x:1573,y:748,t:1527873361065};\\\", \\\"{x:1580,y:735,t:1527873361080};\\\", \\\"{x:1583,y:727,t:1527873361096};\\\", \\\"{x:1583,y:722,t:1527873361112};\\\", \\\"{x:1583,y:719,t:1527873361129};\\\", \\\"{x:1583,y:716,t:1527873361146};\\\", \\\"{x:1583,y:714,t:1527873361162};\\\", \\\"{x:1583,y:712,t:1527873361179};\\\", \\\"{x:1584,y:709,t:1527873361196};\\\", \\\"{x:1584,y:706,t:1527873361212};\\\", \\\"{x:1586,y:703,t:1527873361229};\\\", \\\"{x:1587,y:699,t:1527873361247};\\\", \\\"{x:1588,y:695,t:1527873361262};\\\", \\\"{x:1591,y:691,t:1527873361279};\\\", \\\"{x:1593,y:688,t:1527873361297};\\\", \\\"{x:1594,y:687,t:1527873361312};\\\", \\\"{x:1595,y:687,t:1527873361344};\\\", \\\"{x:1596,y:686,t:1527873361352};\\\", \\\"{x:1597,y:686,t:1527873361392};\\\", \\\"{x:1598,y:686,t:1527873361417};\\\", \\\"{x:1599,y:686,t:1527873361430};\\\", \\\"{x:1600,y:686,t:1527873361464};\\\", \\\"{x:1601,y:686,t:1527873361480};\\\", \\\"{x:1602,y:686,t:1527873361496};\\\", \\\"{x:1603,y:686,t:1527873361544};\\\", \\\"{x:1603,y:688,t:1527873361561};\\\", \\\"{x:1603,y:689,t:1527873361609};\\\", \\\"{x:1603,y:690,t:1527873361616};\\\", \\\"{x:1604,y:691,t:1527873361631};\\\", \\\"{x:1605,y:692,t:1527873361655};\\\", \\\"{x:1606,y:693,t:1527873363449};\\\", \\\"{x:1608,y:694,t:1527873364360};\\\", \\\"{x:1604,y:694,t:1527873366248};\\\", \\\"{x:1587,y:694,t:1527873366256};\\\", \\\"{x:1568,y:694,t:1527873366268};\\\", \\\"{x:1497,y:692,t:1527873366284};\\\", \\\"{x:1395,y:678,t:1527873366300};\\\", \\\"{x:1259,y:659,t:1527873366317};\\\", \\\"{x:1121,y:639,t:1527873366335};\\\", \\\"{x:999,y:625,t:1527873366350};\\\", \\\"{x:851,y:604,t:1527873366368};\\\", \\\"{x:783,y:591,t:1527873366385};\\\", \\\"{x:738,y:584,t:1527873366401};\\\", \\\"{x:709,y:582,t:1527873366416};\\\", \\\"{x:694,y:581,t:1527873366432};\\\", \\\"{x:690,y:581,t:1527873366450};\\\", \\\"{x:688,y:581,t:1527873366479};\\\", \\\"{x:686,y:581,t:1527873366487};\\\", \\\"{x:682,y:582,t:1527873366499};\\\", \\\"{x:661,y:584,t:1527873366516};\\\", \\\"{x:636,y:584,t:1527873366533};\\\", \\\"{x:604,y:584,t:1527873366549};\\\", \\\"{x:578,y:584,t:1527873366566};\\\", \\\"{x:562,y:584,t:1527873366582};\\\", \\\"{x:549,y:582,t:1527873366599};\\\", \\\"{x:546,y:582,t:1527873366615};\\\", \\\"{x:542,y:582,t:1527873366633};\\\", \\\"{x:535,y:580,t:1527873366650};\\\", \\\"{x:527,y:578,t:1527873366665};\\\", \\\"{x:513,y:574,t:1527873366683};\\\", \\\"{x:500,y:572,t:1527873366700};\\\", \\\"{x:484,y:571,t:1527873366718};\\\", \\\"{x:467,y:568,t:1527873366733};\\\", \\\"{x:451,y:566,t:1527873366749};\\\", \\\"{x:439,y:564,t:1527873366765};\\\", \\\"{x:432,y:563,t:1527873366782};\\\", \\\"{x:426,y:563,t:1527873366798};\\\", \\\"{x:425,y:563,t:1527873366815};\\\", \\\"{x:423,y:563,t:1527873366935};\\\", \\\"{x:422,y:563,t:1527873366960};\\\", \\\"{x:421,y:563,t:1527873366967};\\\", \\\"{x:420,y:563,t:1527873366982};\\\", \\\"{x:419,y:564,t:1527873366999};\\\", \\\"{x:418,y:566,t:1527873367016};\\\", \\\"{x:420,y:566,t:1527873367072};\\\", \\\"{x:425,y:564,t:1527873367081};\\\", \\\"{x:438,y:559,t:1527873367099};\\\", \\\"{x:460,y:552,t:1527873367116};\\\", \\\"{x:493,y:544,t:1527873367133};\\\", \\\"{x:535,y:537,t:1527873367149};\\\", \\\"{x:564,y:533,t:1527873367166};\\\", \\\"{x:592,y:530,t:1527873367183};\\\", \\\"{x:604,y:529,t:1527873367200};\\\", \\\"{x:609,y:527,t:1527873367216};\\\", \\\"{x:610,y:527,t:1527873367234};\\\", \\\"{x:611,y:527,t:1527873367295};\\\", \\\"{x:613,y:527,t:1527873367368};\\\", \\\"{x:617,y:527,t:1527873367384};\\\", \\\"{x:624,y:527,t:1527873367400};\\\", \\\"{x:641,y:527,t:1527873367417};\\\", \\\"{x:665,y:527,t:1527873367434};\\\", \\\"{x:692,y:527,t:1527873367450};\\\", \\\"{x:724,y:527,t:1527873367471};\\\", \\\"{x:752,y:527,t:1527873367484};\\\", \\\"{x:772,y:527,t:1527873367499};\\\", \\\"{x:785,y:527,t:1527873367516};\\\", \\\"{x:799,y:527,t:1527873367532};\\\", \\\"{x:807,y:527,t:1527873367549};\\\", \\\"{x:811,y:527,t:1527873367566};\\\", \\\"{x:812,y:527,t:1527873367582};\\\", \\\"{x:813,y:527,t:1527873367599};\\\", \\\"{x:814,y:527,t:1527873367672};\\\", \\\"{x:814,y:528,t:1527873367683};\\\", \\\"{x:813,y:531,t:1527873367699};\\\", \\\"{x:813,y:532,t:1527873367720};\\\", \\\"{x:813,y:534,t:1527873367784};\\\", \\\"{x:812,y:538,t:1527873367800};\\\", \\\"{x:808,y:546,t:1527873367817};\\\", \\\"{x:799,y:556,t:1527873367834};\\\", \\\"{x:790,y:566,t:1527873367850};\\\", \\\"{x:778,y:576,t:1527873367868};\\\", \\\"{x:763,y:587,t:1527873367884};\\\", \\\"{x:732,y:595,t:1527873367900};\\\", \\\"{x:676,y:603,t:1527873367918};\\\", \\\"{x:620,y:603,t:1527873367933};\\\", \\\"{x:571,y:606,t:1527873367950};\\\", \\\"{x:533,y:606,t:1527873367967};\\\", \\\"{x:510,y:606,t:1527873367984};\\\", \\\"{x:493,y:606,t:1527873368001};\\\", \\\"{x:483,y:605,t:1527873368017};\\\", \\\"{x:476,y:605,t:1527873368034};\\\", \\\"{x:472,y:603,t:1527873368050};\\\", \\\"{x:471,y:603,t:1527873368068};\\\", \\\"{x:471,y:602,t:1527873368084};\\\", \\\"{x:470,y:602,t:1527873368101};\\\", \\\"{x:469,y:602,t:1527873368120};\\\", \\\"{x:468,y:602,t:1527873368134};\\\", \\\"{x:465,y:602,t:1527873368151};\\\", \\\"{x:454,y:604,t:1527873368168};\\\", \\\"{x:448,y:605,t:1527873368183};\\\", \\\"{x:440,y:607,t:1527873368200};\\\", \\\"{x:427,y:608,t:1527873368217};\\\", \\\"{x:416,y:609,t:1527873368233};\\\", \\\"{x:409,y:609,t:1527873368251};\\\", \\\"{x:402,y:609,t:1527873368268};\\\", \\\"{x:398,y:609,t:1527873368283};\\\", \\\"{x:397,y:609,t:1527873368301};\\\", \\\"{x:395,y:609,t:1527873368318};\\\", \\\"{x:394,y:609,t:1527873368336};\\\", \\\"{x:393,y:609,t:1527873368352};\\\", \\\"{x:393,y:608,t:1527873368368};\\\", \\\"{x:391,y:604,t:1527873368386};\\\", \\\"{x:394,y:604,t:1527873368504};\\\", \\\"{x:398,y:604,t:1527873368518};\\\", \\\"{x:407,y:605,t:1527873368535};\\\", \\\"{x:424,y:605,t:1527873368551};\\\", \\\"{x:466,y:605,t:1527873368567};\\\", \\\"{x:500,y:609,t:1527873368587};\\\", \\\"{x:522,y:609,t:1527873368601};\\\", \\\"{x:541,y:611,t:1527873368617};\\\", \\\"{x:551,y:611,t:1527873368635};\\\", \\\"{x:554,y:611,t:1527873368651};\\\", \\\"{x:555,y:611,t:1527873368667};\\\", \\\"{x:557,y:611,t:1527873368719};\\\", \\\"{x:558,y:611,t:1527873368759};\\\", \\\"{x:560,y:611,t:1527873368783};\\\", \\\"{x:561,y:611,t:1527873368799};\\\", \\\"{x:562,y:612,t:1527873368807};\\\", \\\"{x:564,y:612,t:1527873368818};\\\", \\\"{x:565,y:613,t:1527873368835};\\\", \\\"{x:569,y:615,t:1527873368852};\\\", \\\"{x:572,y:617,t:1527873368868};\\\", \\\"{x:574,y:617,t:1527873368884};\\\", \\\"{x:577,y:618,t:1527873368901};\\\", \\\"{x:579,y:618,t:1527873368918};\\\", \\\"{x:580,y:618,t:1527873368935};\\\", \\\"{x:584,y:618,t:1527873368951};\\\", \\\"{x:585,y:618,t:1527873368967};\\\", \\\"{x:588,y:618,t:1527873368985};\\\", \\\"{x:589,y:618,t:1527873369002};\\\", \\\"{x:590,y:618,t:1527873369018};\\\", \\\"{x:591,y:618,t:1527873369046};\\\", \\\"{x:592,y:618,t:1527873369103};\\\", \\\"{x:593,y:618,t:1527873369118};\\\", \\\"{x:593,y:618,t:1527873369167};\\\", \\\"{x:594,y:618,t:1527873369383};\\\", \\\"{x:595,y:618,t:1527873369407};\\\", \\\"{x:596,y:618,t:1527873369419};\\\", \\\"{x:597,y:618,t:1527873369434};\\\", \\\"{x:598,y:618,t:1527873369452};\\\", \\\"{x:600,y:618,t:1527873369469};\\\", \\\"{x:602,y:618,t:1527873369485};\\\", \\\"{x:603,y:618,t:1527873369502};\\\", \\\"{x:604,y:618,t:1527873369583};\\\", \\\"{x:605,y:618,t:1527873369591};\\\", \\\"{x:605,y:618,t:1527873369661};\\\", \\\"{x:606,y:619,t:1527873369839};\\\", \\\"{x:605,y:620,t:1527873369904};\\\", \\\"{x:602,y:621,t:1527873369927};\\\", \\\"{x:600,y:622,t:1527873369936};\\\", \\\"{x:581,y:630,t:1527873369953};\\\", \\\"{x:545,y:642,t:1527873369970};\\\", \\\"{x:512,y:648,t:1527873369986};\\\", \\\"{x:461,y:655,t:1527873370003};\\\", \\\"{x:403,y:663,t:1527873370018};\\\", \\\"{x:339,y:672,t:1527873370037};\\\", \\\"{x:283,y:680,t:1527873370051};\\\", \\\"{x:237,y:687,t:1527873370068};\\\", \\\"{x:205,y:691,t:1527873370085};\\\", \\\"{x:184,y:691,t:1527873370102};\\\", \\\"{x:174,y:691,t:1527873370118};\\\", \\\"{x:171,y:691,t:1527873370135};\\\", \\\"{x:170,y:690,t:1527873370191};\\\", \\\"{x:169,y:689,t:1527873370203};\\\", \\\"{x:168,y:685,t:1527873370219};\\\", \\\"{x:166,y:682,t:1527873370235};\\\", \\\"{x:166,y:678,t:1527873370252};\\\", \\\"{x:166,y:674,t:1527873370268};\\\", \\\"{x:166,y:670,t:1527873370286};\\\", \\\"{x:166,y:666,t:1527873370304};\\\", \\\"{x:166,y:662,t:1527873370319};\\\", \\\"{x:164,y:659,t:1527873370336};\\\", \\\"{x:164,y:658,t:1527873370360};\\\", \\\"{x:163,y:658,t:1527873370375};\\\", \\\"{x:163,y:657,t:1527873370385};\\\", \\\"{x:161,y:656,t:1527873370403};\\\", \\\"{x:160,y:655,t:1527873370419};\\\", \\\"{x:159,y:654,t:1527873370480};\\\", \\\"{x:161,y:656,t:1527873371152};\\\", \\\"{x:168,y:662,t:1527873371170};\\\", \\\"{x:181,y:669,t:1527873371187};\\\", \\\"{x:198,y:683,t:1527873371204};\\\", \\\"{x:220,y:694,t:1527873371220};\\\", \\\"{x:244,y:707,t:1527873371237};\\\", \\\"{x:270,y:720,t:1527873371253};\\\", \\\"{x:288,y:729,t:1527873371270};\\\", \\\"{x:304,y:740,t:1527873371287};\\\", \\\"{x:323,y:750,t:1527873371303};\\\", \\\"{x:348,y:759,t:1527873371319};\\\", \\\"{x:363,y:762,t:1527873371337};\\\", \\\"{x:377,y:764,t:1527873371353};\\\", \\\"{x:390,y:766,t:1527873371370};\\\", \\\"{x:403,y:766,t:1527873371387};\\\", \\\"{x:411,y:766,t:1527873371403};\\\", \\\"{x:419,y:766,t:1527873371420};\\\", \\\"{x:423,y:765,t:1527873371437};\\\", \\\"{x:427,y:765,t:1527873371454};\\\", \\\"{x:429,y:763,t:1527873371470};\\\", \\\"{x:430,y:763,t:1527873371488};\\\", \\\"{x:432,y:763,t:1527873371503};\\\", \\\"{x:435,y:762,t:1527873371519};\\\", \\\"{x:439,y:761,t:1527873371537};\\\", \\\"{x:442,y:759,t:1527873371553};\\\", \\\"{x:446,y:758,t:1527873371570};\\\", \\\"{x:449,y:758,t:1527873371587};\\\", \\\"{x:453,y:756,t:1527873371603};\\\", \\\"{x:458,y:756,t:1527873371620};\\\", \\\"{x:464,y:756,t:1527873371637};\\\", \\\"{x:469,y:755,t:1527873371653};\\\", \\\"{x:472,y:754,t:1527873371671};\\\", \\\"{x:478,y:753,t:1527873371686};\\\", \\\"{x:480,y:752,t:1527873371704};\\\", \\\"{x:481,y:752,t:1527873371720};\\\", \\\"{x:482,y:751,t:1527873371743};\\\", \\\"{x:483,y:751,t:1527873371767};\\\", \\\"{x:484,y:751,t:1527873371799};\\\", \\\"{x:485,y:751,t:1527873371807};\\\", \\\"{x:486,y:750,t:1527873371831};\\\", \\\"{x:487,y:749,t:1527873371863};\\\", \\\"{x:489,y:748,t:1527873371880};\\\", \\\"{x:490,y:748,t:1527873371896};\\\", \\\"{x:490,y:747,t:1527873371928};\\\", \\\"{x:491,y:747,t:1527873371937};\\\", \\\"{x:492,y:746,t:1527873371960};\\\", \\\"{x:494,y:745,t:1527873371999};\\\", \\\"{x:496,y:743,t:1527873372024};\\\", \\\"{x:497,y:740,t:1527873372040};\\\", \\\"{x:498,y:739,t:1527873372054};\\\", \\\"{x:500,y:737,t:1527873372071};\\\", \\\"{x:502,y:736,t:1527873372087};\\\", \\\"{x:504,y:736,t:1527873373657};\\\", \\\"{x:523,y:744,t:1527873373671};\\\", \\\"{x:560,y:760,t:1527873373689};\\\", \\\"{x:628,y:785,t:1527873373706};\\\", \\\"{x:714,y:810,t:1527873373722};\\\", \\\"{x:805,y:835,t:1527873373739};\\\", \\\"{x:899,y:861,t:1527873373754};\\\", \\\"{x:987,y:882,t:1527873373772};\\\", \\\"{x:1062,y:902,t:1527873373789};\\\", \\\"{x:1121,y:922,t:1527873373805};\\\", \\\"{x:1160,y:934,t:1527873373822};\\\", \\\"{x:1194,y:944,t:1527873373839};\\\", \\\"{x:1200,y:946,t:1527873373855};\\\", \\\"{x:1206,y:947,t:1527873373872};\\\", \\\"{x:1207,y:947,t:1527873373945};\\\", \\\"{x:1209,y:947,t:1527873373955};\\\", \\\"{x:1217,y:947,t:1527873373972};\\\", \\\"{x:1236,y:947,t:1527873373989};\\\", \\\"{x:1265,y:947,t:1527873374006};\\\", \\\"{x:1321,y:947,t:1527873374022};\\\", \\\"{x:1426,y:947,t:1527873374039};\\\", \\\"{x:1501,y:947,t:1527873374055};\\\", \\\"{x:1579,y:947,t:1527873374072};\\\", \\\"{x:1640,y:947,t:1527873374089};\\\", \\\"{x:1690,y:938,t:1527873374106};\\\", \\\"{x:1724,y:926,t:1527873374123};\\\", \\\"{x:1745,y:919,t:1527873374139};\\\", \\\"{x:1755,y:914,t:1527873374156};\\\", \\\"{x:1757,y:913,t:1527873374172};\\\", \\\"{x:1758,y:913,t:1527873374189};\\\", \\\"{x:1758,y:912,t:1527873374272};\\\", \\\"{x:1758,y:908,t:1527873374289};\\\", \\\"{x:1753,y:895,t:1527873374307};\\\", \\\"{x:1737,y:876,t:1527873374323};\\\", \\\"{x:1711,y:852,t:1527873374340};\\\", \\\"{x:1692,y:834,t:1527873374357};\\\", \\\"{x:1682,y:815,t:1527873374373};\\\", \\\"{x:1669,y:795,t:1527873374390};\\\", \\\"{x:1658,y:772,t:1527873374406};\\\", \\\"{x:1651,y:758,t:1527873374424};\\\", \\\"{x:1651,y:757,t:1527873374440};\\\", \\\"{x:1649,y:753,t:1527873374457};\\\", \\\"{x:1648,y:751,t:1527873374474};\\\", \\\"{x:1648,y:750,t:1527873374489};\\\", \\\"{x:1645,y:747,t:1527873374507};\\\", \\\"{x:1645,y:744,t:1527873374523};\\\", \\\"{x:1645,y:741,t:1527873374540};\\\", \\\"{x:1645,y:737,t:1527873374557};\\\", \\\"{x:1645,y:733,t:1527873374573};\\\", \\\"{x:1645,y:728,t:1527873374590};\\\", \\\"{x:1645,y:722,t:1527873374607};\\\", \\\"{x:1646,y:716,t:1527873374624};\\\", \\\"{x:1646,y:715,t:1527873374640};\\\", \\\"{x:1645,y:713,t:1527873374656};\\\", \\\"{x:1644,y:713,t:1527873374674};\\\", \\\"{x:1643,y:712,t:1527873374689};\\\", \\\"{x:1642,y:711,t:1527873374706};\\\", \\\"{x:1639,y:710,t:1527873374723};\\\", \\\"{x:1633,y:710,t:1527873374740};\\\", \\\"{x:1628,y:708,t:1527873374756};\\\", \\\"{x:1623,y:707,t:1527873374773};\\\", \\\"{x:1619,y:705,t:1527873374790};\\\", \\\"{x:1616,y:703,t:1527873374807};\\\", \\\"{x:1615,y:703,t:1527873374824};\\\", \\\"{x:1613,y:703,t:1527873375113};\\\", \\\"{x:1612,y:704,t:1527873375123};\\\", \\\"{x:1608,y:709,t:1527873375141};\\\", \\\"{x:1604,y:716,t:1527873375156};\\\", \\\"{x:1600,y:726,t:1527873375173};\\\", \\\"{x:1595,y:738,t:1527873375191};\\\", \\\"{x:1588,y:753,t:1527873375206};\\\", \\\"{x:1581,y:769,t:1527873375223};\\\", \\\"{x:1569,y:798,t:1527873375240};\\\", \\\"{x:1560,y:816,t:1527873375256};\\\", \\\"{x:1552,y:832,t:1527873375273};\\\", \\\"{x:1545,y:848,t:1527873375290};\\\", \\\"{x:1541,y:859,t:1527873375307};\\\", \\\"{x:1540,y:865,t:1527873375323};\\\", \\\"{x:1538,y:871,t:1527873375341};\\\", \\\"{x:1536,y:876,t:1527873375357};\\\", \\\"{x:1533,y:882,t:1527873375374};\\\", \\\"{x:1528,y:891,t:1527873375391};\\\", \\\"{x:1518,y:906,t:1527873375408};\\\", \\\"{x:1515,y:911,t:1527873375424};\\\", \\\"{x:1507,y:923,t:1527873375440};\\\", \\\"{x:1503,y:927,t:1527873375457};\\\", \\\"{x:1498,y:932,t:1527873375474};\\\", \\\"{x:1494,y:939,t:1527873375491};\\\", \\\"{x:1492,y:944,t:1527873375508};\\\", \\\"{x:1489,y:948,t:1527873375524};\\\", \\\"{x:1485,y:954,t:1527873375540};\\\", \\\"{x:1483,y:958,t:1527873375557};\\\", \\\"{x:1481,y:961,t:1527873375574};\\\", \\\"{x:1479,y:964,t:1527873375590};\\\", \\\"{x:1478,y:966,t:1527873375608};\\\", \\\"{x:1477,y:967,t:1527873377713};\\\", \\\"{x:1476,y:967,t:1527873377726};\\\", \\\"{x:1471,y:959,t:1527873377742};\\\", \\\"{x:1466,y:953,t:1527873377758};\\\", \\\"{x:1457,y:945,t:1527873377776};\\\", \\\"{x:1454,y:941,t:1527873377792};\\\", \\\"{x:1452,y:938,t:1527873377809};\\\", \\\"{x:1450,y:935,t:1527873377826};\\\", \\\"{x:1448,y:931,t:1527873377842};\\\", \\\"{x:1446,y:926,t:1527873377859};\\\", \\\"{x:1444,y:921,t:1527873377876};\\\", \\\"{x:1442,y:918,t:1527873377892};\\\", \\\"{x:1439,y:914,t:1527873377908};\\\", \\\"{x:1437,y:910,t:1527873377926};\\\", \\\"{x:1434,y:906,t:1527873377942};\\\", \\\"{x:1429,y:895,t:1527873377959};\\\", \\\"{x:1426,y:886,t:1527873377976};\\\", \\\"{x:1421,y:877,t:1527873377993};\\\", \\\"{x:1415,y:865,t:1527873378010};\\\", \\\"{x:1409,y:850,t:1527873378025};\\\", \\\"{x:1401,y:837,t:1527873378043};\\\", \\\"{x:1396,y:820,t:1527873378059};\\\", \\\"{x:1388,y:800,t:1527873378075};\\\", \\\"{x:1378,y:778,t:1527873378093};\\\", \\\"{x:1368,y:757,t:1527873378110};\\\", \\\"{x:1359,y:734,t:1527873378125};\\\", \\\"{x:1347,y:718,t:1527873378143};\\\", \\\"{x:1339,y:704,t:1527873378160};\\\", \\\"{x:1336,y:699,t:1527873378176};\\\", \\\"{x:1336,y:696,t:1527873378193};\\\", \\\"{x:1334,y:693,t:1527873378210};\\\", \\\"{x:1333,y:690,t:1527873378226};\\\", \\\"{x:1333,y:685,t:1527873378242};\\\", \\\"{x:1332,y:679,t:1527873378259};\\\", \\\"{x:1329,y:673,t:1527873378276};\\\", \\\"{x:1325,y:666,t:1527873378293};\\\", \\\"{x:1321,y:660,t:1527873378310};\\\", \\\"{x:1318,y:655,t:1527873378326};\\\", \\\"{x:1315,y:651,t:1527873378342};\\\", \\\"{x:1306,y:635,t:1527873378360};\\\", \\\"{x:1294,y:618,t:1527873378376};\\\", \\\"{x:1274,y:596,t:1527873378393};\\\", \\\"{x:1237,y:574,t:1527873378409};\\\", \\\"{x:1198,y:563,t:1527873378427};\\\", \\\"{x:1130,y:551,t:1527873378443};\\\", \\\"{x:1021,y:545,t:1527873378460};\\\", \\\"{x:890,y:541,t:1527873378477};\\\", \\\"{x:757,y:537,t:1527873378492};\\\", \\\"{x:660,y:537,t:1527873378510};\\\", \\\"{x:614,y:535,t:1527873378526};\\\", \\\"{x:595,y:540,t:1527873378542};\\\", \\\"{x:574,y:547,t:1527873378559};\\\", \\\"{x:571,y:550,t:1527873378575};\\\", \\\"{x:566,y:558,t:1527873378592};\\\", \\\"{x:554,y:565,t:1527873378841};\\\", \\\"{x:532,y:575,t:1527873378859};\\\", \\\"{x:503,y:586,t:1527873378876};\\\", \\\"{x:458,y:599,t:1527873378894};\\\", \\\"{x:429,y:601,t:1527873378909};\\\", \\\"{x:407,y:608,t:1527873378926};\\\", \\\"{x:375,y:617,t:1527873378943};\\\", \\\"{x:354,y:623,t:1527873378960};\\\", \\\"{x:329,y:627,t:1527873378976};\\\", \\\"{x:300,y:631,t:1527873378992};\\\", \\\"{x:274,y:635,t:1527873379010};\\\", \\\"{x:252,y:638,t:1527873379026};\\\", \\\"{x:229,y:642,t:1527873379044};\\\", \\\"{x:205,y:642,t:1527873379060};\\\", \\\"{x:187,y:645,t:1527873379076};\\\", \\\"{x:170,y:647,t:1527873379093};\\\", \\\"{x:160,y:650,t:1527873379110};\\\", \\\"{x:154,y:650,t:1527873379125};\\\", \\\"{x:153,y:650,t:1527873379142};\\\", \\\"{x:152,y:651,t:1527873379208};\\\", \\\"{x:158,y:650,t:1527873379543};\\\", \\\"{x:236,y:638,t:1527873379561};\\\", \\\"{x:339,y:622,t:1527873379577};\\\", \\\"{x:466,y:610,t:1527873379593};\\\", \\\"{x:593,y:608,t:1527873379610};\\\", \\\"{x:682,y:608,t:1527873379627};\\\", \\\"{x:741,y:608,t:1527873379644};\\\", \\\"{x:756,y:608,t:1527873379659};\\\", \\\"{x:757,y:608,t:1527873379677};\\\", \\\"{x:753,y:608,t:1527873379848};\\\", \\\"{x:748,y:608,t:1527873379861};\\\", \\\"{x:739,y:608,t:1527873379877};\\\", \\\"{x:732,y:608,t:1527873379894};\\\", \\\"{x:727,y:609,t:1527873379910};\\\", \\\"{x:715,y:610,t:1527873379928};\\\", \\\"{x:701,y:611,t:1527873379944};\\\", \\\"{x:687,y:613,t:1527873379960};\\\", \\\"{x:669,y:613,t:1527873379977};\\\", \\\"{x:649,y:614,t:1527873379993};\\\", \\\"{x:630,y:614,t:1527873380011};\\\", \\\"{x:612,y:614,t:1527873380028};\\\", \\\"{x:602,y:614,t:1527873380043};\\\", \\\"{x:597,y:615,t:1527873380061};\\\", \\\"{x:595,y:615,t:1527873380077};\\\", \\\"{x:594,y:615,t:1527873380092};\\\", \\\"{x:592,y:615,t:1527873380110};\\\", \\\"{x:590,y:615,t:1527873380127};\\\", \\\"{x:591,y:615,t:1527873380391};\\\", \\\"{x:592,y:614,t:1527873380399};\\\", \\\"{x:594,y:614,t:1527873380411};\\\", \\\"{x:595,y:614,t:1527873380426};\\\", \\\"{x:596,y:614,t:1527873380447};\\\", \\\"{x:597,y:613,t:1527873380462};\\\", \\\"{x:598,y:613,t:1527873380479};\\\", \\\"{x:601,y:612,t:1527873380494};\\\", \\\"{x:603,y:612,t:1527873380519};\\\", \\\"{x:606,y:611,t:1527873380527};\\\", \\\"{x:608,y:610,t:1527873380544};\\\", \\\"{x:609,y:607,t:1527873380702};\\\", \\\"{x:609,y:602,t:1527873380711};\\\", \\\"{x:609,y:583,t:1527873380727};\\\", \\\"{x:609,y:561,t:1527873380745};\\\", \\\"{x:609,y:538,t:1527873380762};\\\", \\\"{x:609,y:519,t:1527873380777};\\\", \\\"{x:609,y:509,t:1527873380795};\\\", \\\"{x:609,y:502,t:1527873380810};\\\", \\\"{x:609,y:496,t:1527873380828};\\\", \\\"{x:609,y:493,t:1527873380843};\\\", \\\"{x:609,y:492,t:1527873380862};\\\", \\\"{x:608,y:492,t:1527873381144};\\\", \\\"{x:614,y:492,t:1527873381295};\\\", \\\"{x:637,y:492,t:1527873381311};\\\", \\\"{x:660,y:492,t:1527873381329};\\\", \\\"{x:694,y:492,t:1527873381345};\\\", \\\"{x:717,y:493,t:1527873381361};\\\", \\\"{x:725,y:494,t:1527873381378};\\\", \\\"{x:728,y:495,t:1527873381395};\\\", \\\"{x:729,y:495,t:1527873381415};\\\", \\\"{x:730,y:495,t:1527873381428};\\\", \\\"{x:732,y:495,t:1527873381445};\\\", \\\"{x:736,y:498,t:1527873381462};\\\", \\\"{x:741,y:499,t:1527873381479};\\\", \\\"{x:746,y:502,t:1527873381495};\\\", \\\"{x:749,y:502,t:1527873381511};\\\", \\\"{x:750,y:503,t:1527873381528};\\\", \\\"{x:752,y:504,t:1527873381545};\\\", \\\"{x:754,y:505,t:1527873381562};\\\", \\\"{x:755,y:505,t:1527873381579};\\\", \\\"{x:757,y:505,t:1527873381596};\\\", \\\"{x:758,y:506,t:1527873381612};\\\", \\\"{x:762,y:506,t:1527873381628};\\\", \\\"{x:767,y:508,t:1527873381645};\\\", \\\"{x:772,y:508,t:1527873381662};\\\", \\\"{x:776,y:508,t:1527873381678};\\\", \\\"{x:783,y:508,t:1527873381696};\\\", \\\"{x:790,y:508,t:1527873381711};\\\", \\\"{x:798,y:508,t:1527873381728};\\\", \\\"{x:801,y:508,t:1527873381745};\\\", \\\"{x:802,y:508,t:1527873381761};\\\", \\\"{x:803,y:508,t:1527873381783};\\\", \\\"{x:804,y:508,t:1527873381796};\\\", \\\"{x:805,y:508,t:1527873381812};\\\", \\\"{x:807,y:508,t:1527873381828};\\\", \\\"{x:809,y:507,t:1527873381846};\\\", \\\"{x:811,y:506,t:1527873381863};\\\", \\\"{x:812,y:505,t:1527873381879};\\\", \\\"{x:815,y:504,t:1527873381896};\\\", \\\"{x:817,y:504,t:1527873381911};\\\", \\\"{x:821,y:502,t:1527873381928};\\\", \\\"{x:823,y:502,t:1527873381945};\\\", \\\"{x:825,y:501,t:1527873381961};\\\", \\\"{x:827,y:501,t:1527873381979};\\\", \\\"{x:826,y:501,t:1527873382520};\\\", \\\"{x:824,y:502,t:1527873382531};\\\", \\\"{x:821,y:504,t:1527873382546};\\\", \\\"{x:817,y:508,t:1527873382562};\\\", \\\"{x:813,y:510,t:1527873382579};\\\", \\\"{x:806,y:516,t:1527873382596};\\\", \\\"{x:797,y:525,t:1527873382614};\\\", \\\"{x:786,y:534,t:1527873382629};\\\", \\\"{x:773,y:549,t:1527873382646};\\\", \\\"{x:757,y:568,t:1527873382663};\\\", \\\"{x:740,y:594,t:1527873382680};\\\", \\\"{x:726,y:613,t:1527873382696};\\\", \\\"{x:718,y:624,t:1527873382712};\\\", \\\"{x:705,y:635,t:1527873382729};\\\", \\\"{x:696,y:647,t:1527873382746};\\\", \\\"{x:689,y:654,t:1527873382762};\\\", \\\"{x:684,y:660,t:1527873382779};\\\", \\\"{x:680,y:663,t:1527873382796};\\\", \\\"{x:676,y:668,t:1527873382812};\\\", \\\"{x:670,y:674,t:1527873382829};\\\", \\\"{x:665,y:678,t:1527873382846};\\\", \\\"{x:658,y:682,t:1527873382862};\\\", \\\"{x:650,y:689,t:1527873382880};\\\", \\\"{x:643,y:693,t:1527873382896};\\\", \\\"{x:633,y:699,t:1527873382913};\\\", \\\"{x:627,y:701,t:1527873382929};\\\", \\\"{x:618,y:704,t:1527873382946};\\\", \\\"{x:611,y:705,t:1527873382962};\\\", \\\"{x:605,y:707,t:1527873382980};\\\", \\\"{x:598,y:709,t:1527873382997};\\\", \\\"{x:590,y:710,t:1527873383014};\\\", \\\"{x:582,y:711,t:1527873383030};\\\", \\\"{x:577,y:712,t:1527873383046};\\\", \\\"{x:571,y:713,t:1527873383064};\\\", \\\"{x:566,y:713,t:1527873383079};\\\", \\\"{x:563,y:713,t:1527873383097};\\\", \\\"{x:559,y:714,t:1527873383113};\\\", \\\"{x:556,y:715,t:1527873383130};\\\", \\\"{x:554,y:715,t:1527873383147};\\\", \\\"{x:553,y:715,t:1527873383164};\\\", \\\"{x:551,y:715,t:1527873383179};\\\", \\\"{x:550,y:715,t:1527873383196};\\\", \\\"{x:548,y:715,t:1527873383215};\\\", \\\"{x:547,y:716,t:1527873383230};\\\", \\\"{x:546,y:716,t:1527873383247};\\\", \\\"{x:545,y:717,t:1527873383263};\\\", \\\"{x:544,y:717,t:1527873383303};\\\", \\\"{x:543,y:717,t:1527873383328};\\\", \\\"{x:542,y:717,t:1527873383352};\\\", \\\"{x:541,y:718,t:1527873383384};\\\", \\\"{x:541,y:720,t:1527873383400};\\\", \\\"{x:541,y:721,t:1527873383414};\\\", \\\"{x:541,y:724,t:1527873383430};\\\", \\\"{x:541,y:728,t:1527873383446};\\\", \\\"{x:540,y:729,t:1527873383463};\\\", \\\"{x:540,y:731,t:1527873383480};\\\", \\\"{x:538,y:733,t:1527873383497};\\\", \\\"{x:537,y:734,t:1527873383519};\\\", \\\"{x:536,y:736,t:1527873383567};\\\", \\\"{x:535,y:736,t:1527873383580};\\\", \\\"{x:534,y:737,t:1527873383598};\\\", \\\"{x:532,y:740,t:1527873383614};\\\", \\\"{x:531,y:741,t:1527873383630};\\\", \\\"{x:528,y:743,t:1527873383648};\\\", \\\"{x:527,y:744,t:1527873383665};\\\", \\\"{x:524,y:746,t:1527873383682};\\\", \\\"{x:521,y:748,t:1527873383698};\\\", \\\"{x:519,y:750,t:1527873383714};\\\", \\\"{x:518,y:750,t:1527873383736};\\\", \\\"{x:517,y:750,t:1527873384136};\\\", \\\"{x:517,y:749,t:1527873384208};\\\", \\\"{x:517,y:748,t:1527873384215};\\\", \\\"{x:517,y:747,t:1527873384240};\\\", \\\"{x:517,y:746,t:1527873384256};\\\", \\\"{x:518,y:745,t:1527873384296};\\\" ] }, { \\\"rt\\\": 9708, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 588278, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:741,t:1527873388680};\\\", \\\"{x:524,y:737,t:1527873388687};\\\", \\\"{x:529,y:733,t:1527873388700};\\\", \\\"{x:814,y:736,t:1527873388813};\\\", \\\"{x:837,y:744,t:1527873388817};\\\", \\\"{x:863,y:752,t:1527873388834};\\\", \\\"{x:881,y:758,t:1527873388851};\\\", \\\"{x:892,y:766,t:1527873388867};\\\", \\\"{x:892,y:770,t:1527873388884};\\\", \\\"{x:892,y:771,t:1527873388902};\\\", \\\"{x:894,y:773,t:1527873389431};\\\", \\\"{x:899,y:774,t:1527873389448};\\\", \\\"{x:905,y:777,t:1527873389456};\\\", \\\"{x:907,y:778,t:1527873389471};\\\", \\\"{x:909,y:779,t:1527873389486};\\\", \\\"{x:922,y:783,t:1527873389503};\\\", \\\"{x:946,y:788,t:1527873389520};\\\", \\\"{x:966,y:795,t:1527873389537};\\\", \\\"{x:992,y:801,t:1527873389554};\\\", \\\"{x:1019,y:810,t:1527873389569};\\\", \\\"{x:1044,y:816,t:1527873389587};\\\", \\\"{x:1066,y:819,t:1527873389603};\\\", \\\"{x:1091,y:827,t:1527873389620};\\\", \\\"{x:1113,y:830,t:1527873389637};\\\", \\\"{x:1136,y:838,t:1527873389654};\\\", \\\"{x:1155,y:845,t:1527873389671};\\\", \\\"{x:1170,y:852,t:1527873389687};\\\", \\\"{x:1188,y:865,t:1527873389703};\\\", \\\"{x:1203,y:875,t:1527873389720};\\\", \\\"{x:1217,y:883,t:1527873389737};\\\", \\\"{x:1230,y:895,t:1527873389754};\\\", \\\"{x:1243,y:907,t:1527873389770};\\\", \\\"{x:1257,y:917,t:1527873389787};\\\", \\\"{x:1269,y:926,t:1527873389804};\\\", \\\"{x:1277,y:935,t:1527873389821};\\\", \\\"{x:1281,y:941,t:1527873389837};\\\", \\\"{x:1281,y:948,t:1527873389854};\\\", \\\"{x:1281,y:959,t:1527873389871};\\\", \\\"{x:1281,y:963,t:1527873389887};\\\", \\\"{x:1282,y:973,t:1527873389904};\\\", \\\"{x:1285,y:979,t:1527873389921};\\\", \\\"{x:1285,y:985,t:1527873389939};\\\", \\\"{x:1287,y:987,t:1527873389953};\\\", \\\"{x:1288,y:990,t:1527873389971};\\\", \\\"{x:1289,y:991,t:1527873389988};\\\", \\\"{x:1290,y:991,t:1527873390004};\\\", \\\"{x:1291,y:991,t:1527873390021};\\\", \\\"{x:1294,y:991,t:1527873390038};\\\", \\\"{x:1298,y:991,t:1527873390054};\\\", \\\"{x:1305,y:991,t:1527873390071};\\\", \\\"{x:1319,y:991,t:1527873390087};\\\", \\\"{x:1333,y:991,t:1527873390105};\\\", \\\"{x:1347,y:993,t:1527873390121};\\\", \\\"{x:1359,y:995,t:1527873390138};\\\", \\\"{x:1369,y:996,t:1527873390155};\\\", \\\"{x:1379,y:999,t:1527873390171};\\\", \\\"{x:1388,y:999,t:1527873390188};\\\", \\\"{x:1394,y:1000,t:1527873390205};\\\", \\\"{x:1400,y:1003,t:1527873390222};\\\", \\\"{x:1406,y:1004,t:1527873390238};\\\", \\\"{x:1409,y:1004,t:1527873390255};\\\", \\\"{x:1421,y:1005,t:1527873390272};\\\", \\\"{x:1430,y:1005,t:1527873390288};\\\", \\\"{x:1443,y:1005,t:1527873390305};\\\", \\\"{x:1458,y:1005,t:1527873390322};\\\", \\\"{x:1475,y:1007,t:1527873390338};\\\", \\\"{x:1486,y:1007,t:1527873390355};\\\", \\\"{x:1497,y:1007,t:1527873390372};\\\", \\\"{x:1505,y:1007,t:1527873390389};\\\", \\\"{x:1514,y:1007,t:1527873390405};\\\", \\\"{x:1524,y:1007,t:1527873390423};\\\", \\\"{x:1529,y:1007,t:1527873390439};\\\", \\\"{x:1538,y:1006,t:1527873390455};\\\", \\\"{x:1549,y:1006,t:1527873390472};\\\", \\\"{x:1558,y:1006,t:1527873390489};\\\", \\\"{x:1562,y:1006,t:1527873390506};\\\", \\\"{x:1565,y:1005,t:1527873390522};\\\", \\\"{x:1566,y:1004,t:1527873390539};\\\", \\\"{x:1567,y:1003,t:1527873390557};\\\", \\\"{x:1568,y:1002,t:1527873390572};\\\", \\\"{x:1569,y:1001,t:1527873390589};\\\", \\\"{x:1569,y:1000,t:1527873390608};\\\", \\\"{x:1569,y:999,t:1527873390622};\\\", \\\"{x:1570,y:995,t:1527873390639};\\\", \\\"{x:1570,y:990,t:1527873390656};\\\", \\\"{x:1570,y:988,t:1527873390673};\\\", \\\"{x:1570,y:984,t:1527873390689};\\\", \\\"{x:1570,y:982,t:1527873390706};\\\", \\\"{x:1570,y:980,t:1527873390723};\\\", \\\"{x:1569,y:978,t:1527873390744};\\\", \\\"{x:1569,y:977,t:1527873390759};\\\", \\\"{x:1569,y:976,t:1527873390773};\\\", \\\"{x:1568,y:976,t:1527873390790};\\\", \\\"{x:1566,y:975,t:1527873390920};\\\", \\\"{x:1565,y:974,t:1527873390942};\\\", \\\"{x:1563,y:973,t:1527873390974};\\\", \\\"{x:1561,y:973,t:1527873390990};\\\", \\\"{x:1561,y:972,t:1527873391007};\\\", \\\"{x:1560,y:971,t:1527873391030};\\\", \\\"{x:1559,y:970,t:1527873391055};\\\", \\\"{x:1558,y:970,t:1527873391144};\\\", \\\"{x:1557,y:968,t:1527873391168};\\\", \\\"{x:1556,y:968,t:1527873391183};\\\", \\\"{x:1555,y:968,t:1527873391199};\\\", \\\"{x:1555,y:967,t:1527873391440};\\\", \\\"{x:1555,y:965,t:1527873391458};\\\", \\\"{x:1553,y:961,t:1527873391475};\\\", \\\"{x:1546,y:950,t:1527873391491};\\\", \\\"{x:1536,y:940,t:1527873391508};\\\", \\\"{x:1524,y:926,t:1527873391525};\\\", \\\"{x:1508,y:914,t:1527873391541};\\\", \\\"{x:1493,y:906,t:1527873391558};\\\", \\\"{x:1483,y:898,t:1527873391575};\\\", \\\"{x:1479,y:894,t:1527873391591};\\\", \\\"{x:1478,y:894,t:1527873391608};\\\", \\\"{x:1477,y:893,t:1527873391626};\\\", \\\"{x:1477,y:892,t:1527873391642};\\\", \\\"{x:1477,y:889,t:1527873391658};\\\", \\\"{x:1477,y:887,t:1527873391675};\\\", \\\"{x:1477,y:885,t:1527873391692};\\\", \\\"{x:1477,y:882,t:1527873391709};\\\", \\\"{x:1477,y:879,t:1527873391725};\\\", \\\"{x:1477,y:875,t:1527873391742};\\\", \\\"{x:1477,y:872,t:1527873391759};\\\", \\\"{x:1477,y:870,t:1527873391775};\\\", \\\"{x:1477,y:868,t:1527873391792};\\\", \\\"{x:1477,y:866,t:1527873391809};\\\", \\\"{x:1478,y:861,t:1527873391825};\\\", \\\"{x:1478,y:856,t:1527873391842};\\\", \\\"{x:1480,y:851,t:1527873391859};\\\", \\\"{x:1482,y:846,t:1527873391875};\\\", \\\"{x:1482,y:842,t:1527873391892};\\\", \\\"{x:1484,y:840,t:1527873391910};\\\", \\\"{x:1484,y:839,t:1527873394472};\\\", \\\"{x:1483,y:835,t:1527873394485};\\\", \\\"{x:1462,y:819,t:1527873394498};\\\", \\\"{x:1429,y:792,t:1527873394514};\\\", \\\"{x:1381,y:757,t:1527873394532};\\\", \\\"{x:1313,y:719,t:1527873394548};\\\", \\\"{x:1255,y:691,t:1527873394564};\\\", \\\"{x:1205,y:660,t:1527873394582};\\\", \\\"{x:1154,y:618,t:1527873394599};\\\", \\\"{x:1127,y:590,t:1527873394615};\\\", \\\"{x:1109,y:568,t:1527873394632};\\\", \\\"{x:1095,y:555,t:1527873394649};\\\", \\\"{x:1089,y:547,t:1527873394665};\\\", \\\"{x:1089,y:546,t:1527873394687};\\\", \\\"{x:1088,y:546,t:1527873394703};\\\", \\\"{x:1088,y:544,t:1527873394727};\\\", \\\"{x:1088,y:542,t:1527873394744};\\\", \\\"{x:1088,y:541,t:1527873394751};\\\", \\\"{x:1088,y:539,t:1527873394766};\\\", \\\"{x:1088,y:536,t:1527873394782};\\\", \\\"{x:1091,y:529,t:1527873394800};\\\", \\\"{x:1093,y:524,t:1527873394816};\\\", \\\"{x:1093,y:523,t:1527873394833};\\\", \\\"{x:1093,y:519,t:1527873394849};\\\", \\\"{x:1093,y:516,t:1527873394866};\\\", \\\"{x:1091,y:511,t:1527873394883};\\\", \\\"{x:1083,y:507,t:1527873394899};\\\", \\\"{x:1066,y:502,t:1527873394916};\\\", \\\"{x:1038,y:499,t:1527873394933};\\\", \\\"{x:1003,y:495,t:1527873394949};\\\", \\\"{x:954,y:492,t:1527873394966};\\\", \\\"{x:851,y:492,t:1527873394985};\\\", \\\"{x:776,y:492,t:1527873395000};\\\", \\\"{x:725,y:492,t:1527873395015};\\\", \\\"{x:666,y:492,t:1527873395039};\\\", \\\"{x:643,y:492,t:1527873395056};\\\", \\\"{x:622,y:497,t:1527873395073};\\\", \\\"{x:605,y:499,t:1527873395090};\\\", \\\"{x:589,y:502,t:1527873395105};\\\", \\\"{x:575,y:504,t:1527873395123};\\\", \\\"{x:563,y:505,t:1527873395140};\\\", \\\"{x:555,y:507,t:1527873395156};\\\", \\\"{x:554,y:507,t:1527873395173};\\\", \\\"{x:553,y:507,t:1527873395512};\\\", \\\"{x:553,y:508,t:1527873395524};\\\", \\\"{x:551,y:509,t:1527873395540};\\\", \\\"{x:551,y:511,t:1527873395557};\\\", \\\"{x:548,y:516,t:1527873395573};\\\", \\\"{x:544,y:523,t:1527873395591};\\\", \\\"{x:539,y:531,t:1527873395607};\\\", \\\"{x:534,y:534,t:1527873395624};\\\", \\\"{x:530,y:536,t:1527873395640};\\\", \\\"{x:528,y:537,t:1527873395656};\\\", \\\"{x:527,y:537,t:1527873395678};\\\", \\\"{x:526,y:537,t:1527873395690};\\\", \\\"{x:523,y:537,t:1527873395706};\\\", \\\"{x:520,y:534,t:1527873395724};\\\", \\\"{x:517,y:529,t:1527873395740};\\\", \\\"{x:511,y:523,t:1527873395757};\\\", \\\"{x:508,y:520,t:1527873395774};\\\", \\\"{x:511,y:520,t:1527873395863};\\\", \\\"{x:515,y:520,t:1527873395874};\\\", \\\"{x:532,y:523,t:1527873395891};\\\", \\\"{x:557,y:529,t:1527873395910};\\\", \\\"{x:581,y:535,t:1527873395923};\\\", \\\"{x:607,y:540,t:1527873395941};\\\", \\\"{x:628,y:543,t:1527873395957};\\\", \\\"{x:649,y:551,t:1527873395974};\\\", \\\"{x:673,y:560,t:1527873395992};\\\", \\\"{x:679,y:563,t:1527873396007};\\\", \\\"{x:682,y:564,t:1527873396024};\\\", \\\"{x:684,y:565,t:1527873396041};\\\", \\\"{x:684,y:568,t:1527873396057};\\\", \\\"{x:690,y:578,t:1527873396074};\\\", \\\"{x:697,y:589,t:1527873396090};\\\", \\\"{x:705,y:605,t:1527873396107};\\\", \\\"{x:717,y:617,t:1527873396123};\\\", \\\"{x:723,y:623,t:1527873396140};\\\", \\\"{x:723,y:624,t:1527873396156};\\\", \\\"{x:723,y:630,t:1527873396173};\\\", \\\"{x:719,y:640,t:1527873396190};\\\", \\\"{x:710,y:651,t:1527873396206};\\\", \\\"{x:703,y:655,t:1527873396224};\\\", \\\"{x:692,y:660,t:1527873396241};\\\", \\\"{x:680,y:663,t:1527873396257};\\\", \\\"{x:674,y:664,t:1527873396273};\\\", \\\"{x:671,y:664,t:1527873396291};\\\", \\\"{x:668,y:664,t:1527873396307};\\\", \\\"{x:663,y:662,t:1527873396323};\\\", \\\"{x:659,y:658,t:1527873396341};\\\", \\\"{x:650,y:652,t:1527873396357};\\\", \\\"{x:642,y:642,t:1527873396374};\\\", \\\"{x:635,y:630,t:1527873396392};\\\", \\\"{x:631,y:622,t:1527873396407};\\\", \\\"{x:630,y:620,t:1527873396424};\\\", \\\"{x:628,y:617,t:1527873396440};\\\", \\\"{x:628,y:615,t:1527873396457};\\\", \\\"{x:626,y:611,t:1527873396474};\\\", \\\"{x:625,y:605,t:1527873396491};\\\", \\\"{x:625,y:599,t:1527873396508};\\\", \\\"{x:625,y:591,t:1527873396524};\\\", \\\"{x:624,y:587,t:1527873396541};\\\", \\\"{x:624,y:584,t:1527873396558};\\\", \\\"{x:624,y:581,t:1527873396574};\\\", \\\"{x:622,y:578,t:1527873396591};\\\", \\\"{x:622,y:576,t:1527873396607};\\\", \\\"{x:621,y:575,t:1527873396623};\\\", \\\"{x:620,y:575,t:1527873397032};\\\", \\\"{x:619,y:575,t:1527873397039};\\\", \\\"{x:616,y:575,t:1527873397056};\\\", \\\"{x:609,y:579,t:1527873397073};\\\", \\\"{x:597,y:589,t:1527873397089};\\\", \\\"{x:588,y:605,t:1527873397107};\\\", \\\"{x:575,y:626,t:1527873397123};\\\", \\\"{x:564,y:640,t:1527873397142};\\\", \\\"{x:552,y:657,t:1527873397158};\\\", \\\"{x:537,y:677,t:1527873397174};\\\", \\\"{x:529,y:686,t:1527873397191};\\\", \\\"{x:528,y:689,t:1527873397208};\\\", \\\"{x:527,y:692,t:1527873397224};\\\", \\\"{x:525,y:693,t:1527873397241};\\\", \\\"{x:523,y:696,t:1527873397258};\\\", \\\"{x:522,y:696,t:1527873397287};\\\", \\\"{x:522,y:697,t:1527873397311};\\\", \\\"{x:522,y:698,t:1527873397325};\\\", \\\"{x:520,y:701,t:1527873397342};\\\", \\\"{x:519,y:705,t:1527873397358};\\\", \\\"{x:517,y:710,t:1527873397376};\\\", \\\"{x:514,y:717,t:1527873397392};\\\", \\\"{x:511,y:726,t:1527873397410};\\\", \\\"{x:506,y:738,t:1527873397425};\\\", \\\"{x:502,y:751,t:1527873397442};\\\", \\\"{x:500,y:757,t:1527873397458};\\\", \\\"{x:499,y:759,t:1527873397475};\\\", \\\"{x:499,y:755,t:1527873397703};\\\", \\\"{x:499,y:752,t:1527873397712};\\\", \\\"{x:499,y:749,t:1527873397725};\\\", \\\"{x:501,y:746,t:1527873397742};\\\", \\\"{x:501,y:744,t:1527873397758};\\\", \\\"{x:503,y:740,t:1527873397775};\\\", \\\"{x:503,y:738,t:1527873397792};\\\", \\\"{x:505,y:738,t:1527873398224};\\\", \\\"{x:512,y:740,t:1527873398231};\\\", \\\"{x:517,y:744,t:1527873398242};\\\", \\\"{x:538,y:753,t:1527873398259};\\\", \\\"{x:564,y:766,t:1527873398275};\\\", \\\"{x:605,y:783,t:1527873398292};\\\", \\\"{x:638,y:796,t:1527873398309};\\\", \\\"{x:660,y:810,t:1527873398325};\\\", \\\"{x:681,y:817,t:1527873398342};\\\", \\\"{x:698,y:829,t:1527873398359};\\\", \\\"{x:701,y:830,t:1527873398375};\\\", \\\"{x:701,y:831,t:1527873398392};\\\" ] }, { \\\"rt\\\": 15655, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 605177, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-04 PM-03 PM-02 PM-02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:704,y:831,t:1527873401183};\\\", \\\"{x:711,y:834,t:1527873401194};\\\", \\\"{x:724,y:840,t:1527873401211};\\\", \\\"{x:743,y:847,t:1527873401228};\\\", \\\"{x:765,y:856,t:1527873401244};\\\", \\\"{x:788,y:864,t:1527873401261};\\\", \\\"{x:811,y:871,t:1527873401278};\\\", \\\"{x:832,y:871,t:1527873401294};\\\", \\\"{x:872,y:871,t:1527873401311};\\\", \\\"{x:903,y:867,t:1527873401328};\\\", \\\"{x:938,y:866,t:1527873401344};\\\", \\\"{x:972,y:866,t:1527873401361};\\\", \\\"{x:997,y:866,t:1527873401378};\\\", \\\"{x:1012,y:866,t:1527873401393};\\\", \\\"{x:1013,y:866,t:1527873401411};\\\", \\\"{x:1014,y:866,t:1527873401428};\\\", \\\"{x:1018,y:866,t:1527873402127};\\\", \\\"{x:1022,y:867,t:1527873402134};\\\", \\\"{x:1027,y:869,t:1527873402145};\\\", \\\"{x:1036,y:873,t:1527873402162};\\\", \\\"{x:1043,y:876,t:1527873402178};\\\", \\\"{x:1050,y:883,t:1527873402195};\\\", \\\"{x:1064,y:892,t:1527873402212};\\\", \\\"{x:1077,y:900,t:1527873402228};\\\", \\\"{x:1091,y:908,t:1527873402245};\\\", \\\"{x:1109,y:914,t:1527873402262};\\\", \\\"{x:1126,y:922,t:1527873402278};\\\", \\\"{x:1151,y:932,t:1527873402295};\\\", \\\"{x:1171,y:940,t:1527873402313};\\\", \\\"{x:1190,y:951,t:1527873402328};\\\", \\\"{x:1210,y:963,t:1527873402346};\\\", \\\"{x:1230,y:974,t:1527873402362};\\\", \\\"{x:1252,y:984,t:1527873402379};\\\", \\\"{x:1275,y:994,t:1527873402396};\\\", \\\"{x:1301,y:1001,t:1527873402413};\\\", \\\"{x:1324,y:1008,t:1527873402428};\\\", \\\"{x:1341,y:1012,t:1527873402445};\\\", \\\"{x:1360,y:1014,t:1527873402463};\\\", \\\"{x:1381,y:1017,t:1527873402479};\\\", \\\"{x:1391,y:1018,t:1527873402495};\\\", \\\"{x:1400,y:1018,t:1527873402512};\\\", \\\"{x:1402,y:1018,t:1527873402529};\\\", \\\"{x:1404,y:1018,t:1527873402545};\\\", \\\"{x:1404,y:1017,t:1527873402664};\\\", \\\"{x:1404,y:1016,t:1527873402679};\\\", \\\"{x:1404,y:1014,t:1527873402695};\\\", \\\"{x:1404,y:1013,t:1527873402713};\\\", \\\"{x:1403,y:1011,t:1527873402730};\\\", \\\"{x:1402,y:1011,t:1527873402746};\\\", \\\"{x:1400,y:1010,t:1527873402762};\\\", \\\"{x:1399,y:1009,t:1527873402780};\\\", \\\"{x:1399,y:1008,t:1527873402863};\\\", \\\"{x:1400,y:1007,t:1527873402920};\\\", \\\"{x:1402,y:1006,t:1527873402936};\\\", \\\"{x:1403,y:1006,t:1527873402960};\\\", \\\"{x:1405,y:1006,t:1527873402968};\\\", \\\"{x:1408,y:1006,t:1527873402980};\\\", \\\"{x:1415,y:1006,t:1527873402996};\\\", \\\"{x:1426,y:1006,t:1527873403012};\\\", \\\"{x:1438,y:1006,t:1527873403030};\\\", \\\"{x:1455,y:1006,t:1527873403046};\\\", \\\"{x:1471,y:1006,t:1527873403063};\\\", \\\"{x:1493,y:1006,t:1527873403079};\\\", \\\"{x:1507,y:1006,t:1527873403097};\\\", \\\"{x:1514,y:1006,t:1527873403112};\\\", \\\"{x:1517,y:1006,t:1527873403129};\\\", \\\"{x:1518,y:1005,t:1527873403147};\\\", \\\"{x:1519,y:1005,t:1527873403163};\\\", \\\"{x:1521,y:1004,t:1527873403180};\\\", \\\"{x:1523,y:1003,t:1527873403200};\\\", \\\"{x:1524,y:1002,t:1527873403223};\\\", \\\"{x:1525,y:1001,t:1527873403247};\\\", \\\"{x:1526,y:1001,t:1527873403295};\\\", \\\"{x:1527,y:1000,t:1527873403312};\\\", \\\"{x:1528,y:999,t:1527873403329};\\\", \\\"{x:1529,y:998,t:1527873403351};\\\", \\\"{x:1531,y:998,t:1527873403398};\\\", \\\"{x:1532,y:998,t:1527873403414};\\\", \\\"{x:1534,y:998,t:1527873403429};\\\", \\\"{x:1539,y:997,t:1527873403446};\\\", \\\"{x:1542,y:997,t:1527873403463};\\\", \\\"{x:1550,y:995,t:1527873403479};\\\", \\\"{x:1556,y:995,t:1527873403496};\\\", \\\"{x:1561,y:995,t:1527873403513};\\\", \\\"{x:1567,y:995,t:1527873403529};\\\", \\\"{x:1573,y:995,t:1527873403546};\\\", \\\"{x:1581,y:995,t:1527873403563};\\\", \\\"{x:1586,y:996,t:1527873403579};\\\", \\\"{x:1592,y:997,t:1527873403597};\\\", \\\"{x:1598,y:997,t:1527873403613};\\\", \\\"{x:1605,y:997,t:1527873403630};\\\", \\\"{x:1612,y:997,t:1527873403647};\\\", \\\"{x:1620,y:997,t:1527873403663};\\\", \\\"{x:1625,y:997,t:1527873403680};\\\", \\\"{x:1632,y:997,t:1527873403697};\\\", \\\"{x:1639,y:997,t:1527873403713};\\\", \\\"{x:1650,y:995,t:1527873403729};\\\", \\\"{x:1661,y:992,t:1527873403746};\\\", \\\"{x:1667,y:992,t:1527873403763};\\\", \\\"{x:1671,y:990,t:1527873403779};\\\", \\\"{x:1669,y:989,t:1527873403856};\\\", \\\"{x:1661,y:988,t:1527873403863};\\\", \\\"{x:1641,y:985,t:1527873403880};\\\", \\\"{x:1617,y:984,t:1527873403897};\\\", \\\"{x:1592,y:984,t:1527873403914};\\\", \\\"{x:1559,y:984,t:1527873403931};\\\", \\\"{x:1529,y:984,t:1527873403947};\\\", \\\"{x:1499,y:983,t:1527873403963};\\\", \\\"{x:1477,y:982,t:1527873403980};\\\", \\\"{x:1464,y:980,t:1527873403996};\\\", \\\"{x:1460,y:980,t:1527873404013};\\\", \\\"{x:1459,y:979,t:1527873404079};\\\", \\\"{x:1461,y:979,t:1527873404111};\\\", \\\"{x:1464,y:979,t:1527873404119};\\\", \\\"{x:1468,y:979,t:1527873404130};\\\", \\\"{x:1480,y:979,t:1527873404146};\\\", \\\"{x:1490,y:979,t:1527873404164};\\\", \\\"{x:1495,y:979,t:1527873404180};\\\", \\\"{x:1499,y:979,t:1527873404197};\\\", \\\"{x:1499,y:980,t:1527873404231};\\\", \\\"{x:1499,y:981,t:1527873404247};\\\", \\\"{x:1492,y:981,t:1527873404263};\\\", \\\"{x:1490,y:981,t:1527873404280};\\\", \\\"{x:1490,y:980,t:1527873404343};\\\", \\\"{x:1490,y:979,t:1527873404359};\\\", \\\"{x:1490,y:978,t:1527873404367};\\\", \\\"{x:1490,y:977,t:1527873404381};\\\", \\\"{x:1490,y:975,t:1527873404398};\\\", \\\"{x:1490,y:973,t:1527873404413};\\\", \\\"{x:1488,y:972,t:1527873404430};\\\", \\\"{x:1487,y:969,t:1527873404448};\\\", \\\"{x:1485,y:967,t:1527873404464};\\\", \\\"{x:1481,y:965,t:1527873404481};\\\", \\\"{x:1479,y:963,t:1527873404498};\\\", \\\"{x:1476,y:962,t:1527873404514};\\\", \\\"{x:1474,y:961,t:1527873404531};\\\", \\\"{x:1474,y:960,t:1527873404872};\\\", \\\"{x:1474,y:958,t:1527873404912};\\\", \\\"{x:1474,y:957,t:1527873404919};\\\", \\\"{x:1474,y:956,t:1527873404931};\\\", \\\"{x:1474,y:954,t:1527873404949};\\\", \\\"{x:1474,y:952,t:1527873404965};\\\", \\\"{x:1474,y:950,t:1527873404981};\\\", \\\"{x:1474,y:947,t:1527873404998};\\\", \\\"{x:1475,y:943,t:1527873405014};\\\", \\\"{x:1475,y:938,t:1527873405031};\\\", \\\"{x:1475,y:932,t:1527873405048};\\\", \\\"{x:1475,y:927,t:1527873405065};\\\", \\\"{x:1475,y:925,t:1527873405080};\\\", \\\"{x:1476,y:919,t:1527873405098};\\\", \\\"{x:1478,y:914,t:1527873405115};\\\", \\\"{x:1478,y:911,t:1527873405131};\\\", \\\"{x:1479,y:905,t:1527873405148};\\\", \\\"{x:1482,y:898,t:1527873405164};\\\", \\\"{x:1484,y:894,t:1527873405181};\\\", \\\"{x:1487,y:888,t:1527873405198};\\\", \\\"{x:1490,y:883,t:1527873405215};\\\", \\\"{x:1492,y:880,t:1527873405231};\\\", \\\"{x:1495,y:872,t:1527873405247};\\\", \\\"{x:1495,y:868,t:1527873405264};\\\", \\\"{x:1496,y:864,t:1527873405280};\\\", \\\"{x:1496,y:859,t:1527873405298};\\\", \\\"{x:1496,y:857,t:1527873405315};\\\", \\\"{x:1496,y:855,t:1527873405332};\\\", \\\"{x:1496,y:854,t:1527873405348};\\\", \\\"{x:1496,y:850,t:1527873405365};\\\", \\\"{x:1495,y:848,t:1527873405382};\\\", \\\"{x:1494,y:847,t:1527873405398};\\\", \\\"{x:1493,y:845,t:1527873405415};\\\", \\\"{x:1490,y:841,t:1527873405432};\\\", \\\"{x:1488,y:838,t:1527873405448};\\\", \\\"{x:1487,y:837,t:1527873405465};\\\", \\\"{x:1487,y:836,t:1527873405482};\\\", \\\"{x:1486,y:835,t:1527873405498};\\\", \\\"{x:1485,y:834,t:1527873405517};\\\", \\\"{x:1484,y:833,t:1527873405531};\\\", \\\"{x:1483,y:832,t:1527873405548};\\\", \\\"{x:1482,y:831,t:1527873405564};\\\", \\\"{x:1480,y:829,t:1527873405580};\\\", \\\"{x:1478,y:828,t:1527873405597};\\\", \\\"{x:1478,y:826,t:1527873407224};\\\", \\\"{x:1478,y:824,t:1527873407234};\\\", \\\"{x:1478,y:819,t:1527873407249};\\\", \\\"{x:1477,y:816,t:1527873407266};\\\", \\\"{x:1476,y:811,t:1527873407282};\\\", \\\"{x:1476,y:808,t:1527873407300};\\\", \\\"{x:1475,y:803,t:1527873407316};\\\", \\\"{x:1475,y:802,t:1527873407333};\\\", \\\"{x:1474,y:800,t:1527873407349};\\\", \\\"{x:1474,y:799,t:1527873407366};\\\", \\\"{x:1474,y:797,t:1527873407383};\\\", \\\"{x:1474,y:791,t:1527873407399};\\\", \\\"{x:1474,y:788,t:1527873407415};\\\", \\\"{x:1473,y:786,t:1527873407433};\\\", \\\"{x:1473,y:783,t:1527873407449};\\\", \\\"{x:1473,y:779,t:1527873407466};\\\", \\\"{x:1473,y:775,t:1527873407483};\\\", \\\"{x:1473,y:770,t:1527873407499};\\\", \\\"{x:1471,y:765,t:1527873407516};\\\", \\\"{x:1470,y:760,t:1527873407533};\\\", \\\"{x:1470,y:754,t:1527873407550};\\\", \\\"{x:1470,y:747,t:1527873407566};\\\", \\\"{x:1470,y:741,t:1527873407583};\\\", \\\"{x:1470,y:728,t:1527873407600};\\\", \\\"{x:1470,y:721,t:1527873407615};\\\", \\\"{x:1470,y:717,t:1527873407633};\\\", \\\"{x:1470,y:714,t:1527873407650};\\\", \\\"{x:1470,y:711,t:1527873407666};\\\", \\\"{x:1470,y:708,t:1527873407683};\\\", \\\"{x:1470,y:707,t:1527873407700};\\\", \\\"{x:1470,y:704,t:1527873407716};\\\", \\\"{x:1471,y:703,t:1527873407732};\\\", \\\"{x:1471,y:701,t:1527873407749};\\\", \\\"{x:1471,y:700,t:1527873407767};\\\", \\\"{x:1471,y:699,t:1527873407806};\\\", \\\"{x:1471,y:698,t:1527873407831};\\\", \\\"{x:1471,y:697,t:1527873407870};\\\", \\\"{x:1472,y:697,t:1527873407882};\\\", \\\"{x:1472,y:695,t:1527873407899};\\\", \\\"{x:1474,y:691,t:1527873407970};\\\", \\\"{x:1474,y:690,t:1527873408046};\\\", \\\"{x:1475,y:689,t:1527873408062};\\\", \\\"{x:1475,y:688,t:1527873408078};\\\", \\\"{x:1475,y:686,t:1527873408087};\\\", \\\"{x:1475,y:685,t:1527873408100};\\\", \\\"{x:1476,y:680,t:1527873408117};\\\", \\\"{x:1476,y:678,t:1527873408133};\\\", \\\"{x:1476,y:672,t:1527873408149};\\\", \\\"{x:1476,y:664,t:1527873408167};\\\", \\\"{x:1476,y:651,t:1527873408183};\\\", \\\"{x:1476,y:642,t:1527873408200};\\\", \\\"{x:1476,y:632,t:1527873408217};\\\", \\\"{x:1476,y:623,t:1527873408233};\\\", \\\"{x:1477,y:614,t:1527873408249};\\\", \\\"{x:1480,y:605,t:1527873408266};\\\", \\\"{x:1482,y:598,t:1527873408284};\\\", \\\"{x:1485,y:592,t:1527873408299};\\\", \\\"{x:1487,y:587,t:1527873408317};\\\", \\\"{x:1489,y:585,t:1527873408334};\\\", \\\"{x:1489,y:584,t:1527873408350};\\\", \\\"{x:1490,y:583,t:1527873408367};\\\", \\\"{x:1490,y:582,t:1527873408384};\\\", \\\"{x:1490,y:581,t:1527873408400};\\\", \\\"{x:1490,y:580,t:1527873408423};\\\", \\\"{x:1490,y:578,t:1527873408440};\\\", \\\"{x:1490,y:577,t:1527873408450};\\\", \\\"{x:1490,y:576,t:1527873408466};\\\", \\\"{x:1490,y:573,t:1527873408484};\\\", \\\"{x:1490,y:566,t:1527873408499};\\\", \\\"{x:1490,y:559,t:1527873408517};\\\", \\\"{x:1490,y:552,t:1527873408533};\\\", \\\"{x:1490,y:546,t:1527873408549};\\\", \\\"{x:1490,y:504,t:1527873408628};\\\", \\\"{x:1492,y:500,t:1527873408633};\\\", \\\"{x:1493,y:495,t:1527873408650};\\\", \\\"{x:1493,y:488,t:1527873408666};\\\", \\\"{x:1493,y:480,t:1527873408683};\\\", \\\"{x:1494,y:474,t:1527873408700};\\\", \\\"{x:1494,y:467,t:1527873408716};\\\", \\\"{x:1495,y:461,t:1527873408734};\\\", \\\"{x:1496,y:457,t:1527873408750};\\\", \\\"{x:1496,y:454,t:1527873408766};\\\", \\\"{x:1496,y:453,t:1527873408783};\\\", \\\"{x:1496,y:451,t:1527873408919};\\\", \\\"{x:1496,y:450,t:1527873408935};\\\", \\\"{x:1496,y:447,t:1527873408953};\\\", \\\"{x:1496,y:440,t:1527873408967};\\\", \\\"{x:1496,y:431,t:1527873408984};\\\", \\\"{x:1494,y:420,t:1527873409000};\\\", \\\"{x:1490,y:407,t:1527873409016};\\\", \\\"{x:1487,y:392,t:1527873409033};\\\", \\\"{x:1486,y:382,t:1527873409050};\\\", \\\"{x:1485,y:375,t:1527873409066};\\\", \\\"{x:1485,y:369,t:1527873409084};\\\", \\\"{x:1485,y:367,t:1527873409100};\\\", \\\"{x:1485,y:364,t:1527873409117};\\\", \\\"{x:1484,y:363,t:1527873409135};\\\", \\\"{x:1483,y:363,t:1527873409150};\\\", \\\"{x:1483,y:361,t:1527873409175};\\\", \\\"{x:1483,y:360,t:1527873409184};\\\", \\\"{x:1483,y:357,t:1527873409202};\\\", \\\"{x:1482,y:331,t:1527873409272};\\\", \\\"{x:1482,y:327,t:1527873409283};\\\", \\\"{x:1481,y:319,t:1527873409300};\\\", \\\"{x:1481,y:313,t:1527873409317};\\\", \\\"{x:1481,y:307,t:1527873409334};\\\", \\\"{x:1481,y:303,t:1527873409350};\\\", \\\"{x:1480,y:303,t:1527873410067};\\\", \\\"{x:1479,y:304,t:1527873410075};\\\", \\\"{x:1479,y:306,t:1527873410088};\\\", \\\"{x:1474,y:313,t:1527873410104};\\\", \\\"{x:1457,y:333,t:1527873410120};\\\", \\\"{x:1378,y:401,t:1527873410138};\\\", \\\"{x:1289,y:464,t:1527873410154};\\\", \\\"{x:1181,y:542,t:1527873410171};\\\", \\\"{x:1054,y:623,t:1527873410188};\\\", \\\"{x:910,y:694,t:1527873410205};\\\", \\\"{x:767,y:751,t:1527873410221};\\\", \\\"{x:663,y:790,t:1527873410237};\\\", \\\"{x:605,y:807,t:1527873410255};\\\", \\\"{x:577,y:810,t:1527873410270};\\\", \\\"{x:562,y:811,t:1527873410287};\\\", \\\"{x:556,y:810,t:1527873410304};\\\", \\\"{x:553,y:808,t:1527873410320};\\\", \\\"{x:552,y:800,t:1527873410337};\\\", \\\"{x:547,y:792,t:1527873410354};\\\", \\\"{x:541,y:786,t:1527873410370};\\\", \\\"{x:532,y:782,t:1527873410387};\\\", \\\"{x:526,y:779,t:1527873410404};\\\", \\\"{x:521,y:774,t:1527873410420};\\\", \\\"{x:517,y:765,t:1527873410438};\\\", \\\"{x:516,y:749,t:1527873410454};\\\", \\\"{x:514,y:732,t:1527873410470};\\\", \\\"{x:513,y:717,t:1527873410481};\\\", \\\"{x:513,y:700,t:1527873410498};\\\", \\\"{x:513,y:683,t:1527873410515};\\\", \\\"{x:513,y:665,t:1527873410531};\\\", \\\"{x:514,y:645,t:1527873410549};\\\", \\\"{x:514,y:634,t:1527873410564};\\\", \\\"{x:508,y:620,t:1527873410588};\\\", \\\"{x:501,y:612,t:1527873410606};\\\", \\\"{x:495,y:608,t:1527873410623};\\\", \\\"{x:491,y:606,t:1527873410639};\\\", \\\"{x:481,y:601,t:1527873410655};\\\", \\\"{x:474,y:600,t:1527873410672};\\\", \\\"{x:463,y:599,t:1527873410688};\\\", \\\"{x:439,y:599,t:1527873410706};\\\", \\\"{x:428,y:599,t:1527873410721};\\\", \\\"{x:426,y:599,t:1527873410738};\\\", \\\"{x:424,y:598,t:1527873410843};\\\", \\\"{x:423,y:597,t:1527873410858};\\\", \\\"{x:421,y:597,t:1527873410882};\\\", \\\"{x:420,y:597,t:1527873410930};\\\", \\\"{x:419,y:595,t:1527873410939};\\\", \\\"{x:418,y:595,t:1527873410970};\\\", \\\"{x:417,y:595,t:1527873411003};\\\", \\\"{x:416,y:595,t:1527873411050};\\\", \\\"{x:415,y:595,t:1527873411057};\\\", \\\"{x:414,y:595,t:1527873411081};\\\", \\\"{x:413,y:594,t:1527873411202};\\\", \\\"{x:412,y:594,t:1527873411226};\\\", \\\"{x:412,y:593,t:1527873411239};\\\", \\\"{x:410,y:592,t:1527873411256};\\\", \\\"{x:409,y:592,t:1527873411272};\\\", \\\"{x:406,y:592,t:1527873411290};\\\", \\\"{x:404,y:592,t:1527873411306};\\\", \\\"{x:400,y:592,t:1527873411322};\\\", \\\"{x:392,y:592,t:1527873411339};\\\", \\\"{x:385,y:592,t:1527873411355};\\\", \\\"{x:381,y:592,t:1527873411372};\\\", \\\"{x:380,y:592,t:1527873411390};\\\", \\\"{x:378,y:593,t:1527873411405};\\\", \\\"{x:375,y:593,t:1527873411422};\\\", \\\"{x:374,y:593,t:1527873411482};\\\", \\\"{x:375,y:593,t:1527873411857};\\\", \\\"{x:376,y:593,t:1527873411872};\\\", \\\"{x:378,y:592,t:1527873411888};\\\", \\\"{x:379,y:591,t:1527873411905};\\\", \\\"{x:383,y:590,t:1527873411922};\\\", \\\"{x:389,y:589,t:1527873411938};\\\", \\\"{x:405,y:587,t:1527873411956};\\\", \\\"{x:433,y:587,t:1527873411974};\\\", \\\"{x:463,y:587,t:1527873411989};\\\", \\\"{x:500,y:587,t:1527873412008};\\\", \\\"{x:527,y:587,t:1527873412022};\\\", \\\"{x:549,y:587,t:1527873412039};\\\", \\\"{x:567,y:587,t:1527873412056};\\\", \\\"{x:578,y:587,t:1527873412073};\\\", \\\"{x:580,y:587,t:1527873412090};\\\", \\\"{x:585,y:586,t:1527873412106};\\\", \\\"{x:588,y:586,t:1527873412123};\\\", \\\"{x:590,y:585,t:1527873412140};\\\", \\\"{x:591,y:585,t:1527873412157};\\\", \\\"{x:591,y:584,t:1527873412173};\\\", \\\"{x:592,y:584,t:1527873412283};\\\", \\\"{x:593,y:584,t:1527873412290};\\\", \\\"{x:595,y:585,t:1527873412306};\\\", \\\"{x:598,y:586,t:1527873412323};\\\", \\\"{x:599,y:588,t:1527873412340};\\\", \\\"{x:600,y:591,t:1527873412357};\\\", \\\"{x:601,y:591,t:1527873412373};\\\", \\\"{x:602,y:592,t:1527873412391};\\\", \\\"{x:604,y:594,t:1527873412407};\\\", \\\"{x:605,y:594,t:1527873412423};\\\", \\\"{x:606,y:595,t:1527873412440};\\\", \\\"{x:606,y:596,t:1527873413275};\\\", \\\"{x:606,y:598,t:1527873413291};\\\", \\\"{x:606,y:605,t:1527873413309};\\\", \\\"{x:601,y:622,t:1527873413326};\\\", \\\"{x:596,y:649,t:1527873413341};\\\", \\\"{x:582,y:699,t:1527873413358};\\\", \\\"{x:568,y:752,t:1527873413374};\\\", \\\"{x:550,y:803,t:1527873413390};\\\", \\\"{x:534,y:856,t:1527873413407};\\\", \\\"{x:525,y:890,t:1527873413424};\\\", \\\"{x:515,y:920,t:1527873413440};\\\", \\\"{x:502,y:953,t:1527873413457};\\\", \\\"{x:499,y:955,t:1527873413474};\\\", \\\"{x:499,y:954,t:1527873413858};\\\", \\\"{x:500,y:951,t:1527873413875};\\\", \\\"{x:503,y:946,t:1527873413892};\\\", \\\"{x:505,y:940,t:1527873413907};\\\", \\\"{x:508,y:929,t:1527873413925};\\\", \\\"{x:515,y:918,t:1527873413941};\\\", \\\"{x:525,y:902,t:1527873413958};\\\", \\\"{x:534,y:886,t:1527873413975};\\\", \\\"{x:537,y:873,t:1527873413992};\\\", \\\"{x:539,y:858,t:1527873414009};\\\", \\\"{x:540,y:850,t:1527873414024};\\\", \\\"{x:540,y:844,t:1527873414041};\\\", \\\"{x:540,y:842,t:1527873414059};\\\", \\\"{x:540,y:839,t:1527873414075};\\\", \\\"{x:540,y:837,t:1527873414092};\\\", \\\"{x:539,y:836,t:1527873414108};\\\", \\\"{x:538,y:834,t:1527873414125};\\\", \\\"{x:537,y:831,t:1527873414141};\\\", \\\"{x:535,y:830,t:1527873414159};\\\", \\\"{x:532,y:827,t:1527873414175};\\\", \\\"{x:530,y:825,t:1527873414192};\\\", \\\"{x:528,y:825,t:1527873414209};\\\", \\\"{x:527,y:824,t:1527873414225};\\\", \\\"{x:526,y:824,t:1527873414242};\\\", \\\"{x:525,y:823,t:1527873414259};\\\", \\\"{x:525,y:822,t:1527873414275};\\\", \\\"{x:524,y:822,t:1527873414292};\\\", \\\"{x:524,y:821,t:1527873414309};\\\", \\\"{x:522,y:819,t:1527873414325};\\\", \\\"{x:522,y:815,t:1527873414342};\\\", \\\"{x:522,y:811,t:1527873414359};\\\", \\\"{x:522,y:805,t:1527873414375};\\\", \\\"{x:520,y:796,t:1527873414392};\\\", \\\"{x:520,y:785,t:1527873414409};\\\", \\\"{x:520,y:772,t:1527873414426};\\\", \\\"{x:519,y:768,t:1527873414443};\\\", \\\"{x:519,y:765,t:1527873414458};\\\", \\\"{x:519,y:764,t:1527873414476};\\\", \\\"{x:519,y:762,t:1527873414492};\\\", \\\"{x:519,y:761,t:1527873414509};\\\", \\\"{x:519,y:760,t:1527873414525};\\\", \\\"{x:519,y:759,t:1527873414541};\\\", \\\"{x:519,y:756,t:1527873414558};\\\", \\\"{x:519,y:753,t:1527873414576};\\\", \\\"{x:519,y:749,t:1527873414592};\\\", \\\"{x:519,y:745,t:1527873414609};\\\", \\\"{x:519,y:744,t:1527873414625};\\\" ] }, { \\\"rt\\\": 68197, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 674677, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the 12 pm spot on the bottom axis and follow the diagonal line that's sloped to the right. Whichever nodes are on that line start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6943, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Philippines\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 682627, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9137, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 692788, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 32348, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 726469, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"1Z2H9\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"1Z2H9\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 133, dom: 922, initialDom: 1021",
  "javascriptErrors": []
}