var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "00b04c68fcafb7ad47f27fe0718d7e44",
  "created": "2018-05-29T14:12:41.6161862-07:00",
  "lastActivity": "2018-05-29T14:12:49.3569852-07:00",
  "pageViews": [
    {
      "id": "0529413089ff72e502543f0a0c3c0d460c571f4a",
      "startTime": "2018-05-29T14:12:41.6379852-07:00",
      "endTime": "2018-05-29T14:12:49.3569852-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7719,
      "engagementTime": 7719,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7719,
  "engagementTime": 7719,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XD9UF",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6057e3b49bc8ac254263cf286d2feed1",
  "gdpr": false
}