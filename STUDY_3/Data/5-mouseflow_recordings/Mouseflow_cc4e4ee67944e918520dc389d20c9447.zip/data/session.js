var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cc4e4ee67944e918520dc389d20c9447",
  "created": "2018-05-25T11:12:56.7204168-07:00",
  "lastActivity": "2018-05-25T11:13:03.6107903-07:00",
  "pageViews": [
    {
      "id": "0525562681ecc6a169d8e996d4cd904886ea7d62",
      "startTime": "2018-05-25T11:12:57.0081935-07:00",
      "endTime": "2018-05-25T11:13:03.6107903-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 6704,
      "engagementTime": 6704,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 6704,
  "engagementTime": 6704,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=4P01U",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "605fc858de2a9190b0e40b87e045e4b6",
  "gdpr": false
}