var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6cdd4ac1249914891cb334c2a4d47122",
  "created": "2018-05-29T11:01:33.4626101-07:00",
  "lastActivity": "2018-05-29T11:01:46.8356101-07:00",
  "pageViews": [
    {
      "id": "05293362a88e9cee9ab3b9be8b48878e0f2a33c5",
      "startTime": "2018-05-29T11:01:33.4626101-07:00",
      "endTime": "2018-05-29T11:01:46.8356101-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 13373,
      "engagementTime": 13323,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13373,
  "engagementTime": 13323,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1N858",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c927e6737cf194d2ead92f095b68b862",
  "gdpr": false
}