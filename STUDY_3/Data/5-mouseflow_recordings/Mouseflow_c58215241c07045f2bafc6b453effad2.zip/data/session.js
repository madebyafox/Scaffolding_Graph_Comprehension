var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c58215241c07045f2bafc6b453effad2",
  "created": "2018-05-29T16:08:55.0634423-07:00",
  "lastActivity": "2018-05-29T16:09:41.2104423-07:00",
  "pageViews": [
    {
      "id": "05295594d72574264d2cb50c5e54892af0509cd0",
      "startTime": "2018-05-29T16:08:55.0634423-07:00",
      "endTime": "2018-05-29T16:09:41.2104423-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 46147,
      "engagementTime": 43897,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 46147,
  "engagementTime": 43897,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93XU7",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "60283961452013e1002cff1e8884b04d",
  "gdpr": false
}