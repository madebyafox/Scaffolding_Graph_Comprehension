var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7d4af03a7ac5803ae1bcb1a84a7cb0e9",
  "created": "2018-05-24T12:16:31.8060302-07:00",
  "lastActivity": "2018-05-24T12:18:51.1540302-07:00",
  "pageViews": [
    {
      "id": "05243253c24592639130a1baa98176c7c8192daa",
      "startTime": "2018-05-24T12:16:31.8060302-07:00",
      "endTime": "2018-05-24T12:18:51.1540302-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 139348,
      "engagementTime": 107977,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 139348,
  "engagementTime": 107977,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=M3NXB",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6a5529d22ae81cbab36d435e4233e1dc",
  "gdpr": false
}