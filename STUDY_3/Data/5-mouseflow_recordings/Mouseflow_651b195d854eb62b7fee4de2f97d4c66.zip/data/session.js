var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "651b195d854eb62b7fee4de2f97d4c66",
  "created": "2018-06-04T12:14:19.8210678-07:00",
  "lastActivity": "2018-06-04T12:14:49.3573613-07:00",
  "pageViews": [
    {
      "id": "06041972719f9b4f4968f8f1f161895850809998",
      "startTime": "2018-06-04T12:14:19.9363613-07:00",
      "endTime": "2018-06-04T12:14:49.3573613-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 29421,
      "engagementTime": 29416,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29421,
  "engagementTime": 29416,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6GNVQ",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "478d9ef67f4b8ff1d3d7d21ed0bc1216",
  "gdpr": false
}