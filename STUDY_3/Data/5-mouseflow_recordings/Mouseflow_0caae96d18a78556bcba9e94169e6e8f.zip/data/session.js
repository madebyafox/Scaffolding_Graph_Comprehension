var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0caae96d18a78556bcba9e94169e6e8f",
  "created": "2018-05-31T12:12:56.9969153-07:00",
  "lastActivity": "2018-05-31T12:13:02.9649153-07:00",
  "pageViews": [
    {
      "id": "05315751a829f7b41ce7910916cb4ab16f52cead",
      "startTime": "2018-05-31T12:12:56.9969153-07:00",
      "endTime": "2018-05-31T12:13:02.9649153-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 5968,
      "engagementTime": 5968,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 5968,
  "engagementTime": 5968,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XQ4O8",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "db59d142b6fb4db17bd6707dc7b5ed3c",
  "gdpr": false
}