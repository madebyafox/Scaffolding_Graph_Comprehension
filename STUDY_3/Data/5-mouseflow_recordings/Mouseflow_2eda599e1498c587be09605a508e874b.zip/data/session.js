var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2eda599e1498c587be09605a508e874b",
  "created": "2018-05-25T11:10:14.7941942-07:00",
  "lastActivity": "2018-05-25T11:10:44.8331942-07:00",
  "pageViews": [
    {
      "id": "052514390f4eca9d3b7881172ed4e2455ed6fdff",
      "startTime": "2018-05-25T11:10:14.7941942-07:00",
      "endTime": "2018-05-25T11:10:44.8331942-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 30039,
      "engagementTime": 29989,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 30039,
  "engagementTime": 29989,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VB9NP",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "24a1b09d4831e82b9fe37a19369a111c",
  "gdpr": false
}