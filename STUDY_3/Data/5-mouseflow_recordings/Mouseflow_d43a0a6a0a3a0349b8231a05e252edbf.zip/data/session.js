var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d43a0a6a0a3a0349b8231a05e252edbf",
  "created": "2018-05-21T13:08:58.5112522-07:00",
  "lastActivity": "2018-05-21T13:09:25.2392522-07:00",
  "pageViews": [
    {
      "id": "052159208d1ea4e7ea3d67f7d9895e0be0a2eb19",
      "startTime": "2018-05-21T13:08:58.5112522-07:00",
      "endTime": "2018-05-21T13:09:25.2392522-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 26728,
      "engagementTime": 33700,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26728,
  "engagementTime": 33700,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5GELG",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "618f4d77eb209ac56d5df6b4c4fb8403",
  "gdpr": false
}