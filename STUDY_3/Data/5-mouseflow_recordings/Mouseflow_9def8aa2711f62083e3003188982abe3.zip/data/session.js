var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9def8aa2711f62083e3003188982abe3",
  "created": "2018-05-29T16:17:45.8535785-07:00",
  "lastActivity": "2018-05-29T16:19:52.1485785-07:00",
  "pageViews": [
    {
      "id": "052946195a06f79f7159bb47bc5b8691b25177d2",
      "startTime": "2018-05-29T16:17:45.8535785-07:00",
      "endTime": "2018-05-29T16:19:52.1485785-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 126295,
      "engagementTime": 118177,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 126295,
  "engagementTime": 118177,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=X2QZK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2590a49b0664ad3cec6a001190f26a61",
  "gdpr": false
}