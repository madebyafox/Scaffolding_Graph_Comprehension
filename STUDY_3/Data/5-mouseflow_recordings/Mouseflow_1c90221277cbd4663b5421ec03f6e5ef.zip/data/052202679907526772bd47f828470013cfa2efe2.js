var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052202679907526772bd47f828470013cfa2efe2"] = {
  "startTime": "2018-05-22T23:11:02.634647Z",
  "websitePageUrl": "/16",
  "visitTime": 83085,
  "engagementTime": 65541,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1c90221277cbd4663b5421ec03f6e5ef",
    "created": "2018-05-22T23:11:02.5362633+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=0QG7J",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "527ac669bf59901cbbd52a0de70e1ec6",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1c90221277cbd4663b5421ec03f6e5ef/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 208,
      "e": 208,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 208,
      "e": 208,
      "ty": 2,
      "x": 384,
      "y": 537
    },
    {
      "t": 252,
      "e": 252,
      "ty": 41,
      "x": 32026,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 345,
      "y": 556
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 341,
      "y": 557
    },
    {
      "t": 502,
      "e": 502,
      "ty": 2,
      "x": 451,
      "y": 575
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 39782,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 602,
      "e": 602,
      "ty": 2,
      "x": 466,
      "y": 569
    },
    {
      "t": 702,
      "e": 702,
      "ty": 2,
      "x": 506,
      "y": 528
    },
    {
      "t": 769,
      "e": 769,
      "ty": 7,
      "x": 518,
      "y": 500,
      "ta": "#strategyAnswer"
    },
    {
      "t": 771,
      "e": 771,
      "ty": 41,
      "x": 47314,
      "y": 12324,
      "ta": "#.strategy > p"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 517,
      "y": 497
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 421,
      "y": 487
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 403,
      "y": 494
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 34386,
      "y": 0,
      "ta": "#.strategy > p"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 396,
      "y": 507
    },
    {
      "t": 1134,
      "e": 1134,
      "ty": 6,
      "x": 393,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 383,
      "y": 561
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 31913,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 381,
      "y": 563
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 382,
      "y": 567
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 382,
      "y": 568
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 32026,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 388,
      "y": 571
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 2,
      "x": 388,
      "y": 573
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 32700,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 389,
      "y": 573
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 391,
      "y": 573
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 33037,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 2,
      "x": 392,
      "y": 573
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 33150,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 2,
      "x": 394,
      "y": 571
    },
    {
      "t": 3252,
      "e": 3252,
      "ty": 41,
      "x": 33375,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5987,
      "e": 5987,
      "ty": 3,
      "x": 394,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5988,
      "e": 5988,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6089,
      "e": 6089,
      "ty": 4,
      "x": 33375,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6089,
      "e": 6089,
      "ty": 5,
      "x": 394,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6371,
      "e": 6371,
      "ty": 7,
      "x": 474,
      "y": 651,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6402,
      "e": 6402,
      "ty": 2,
      "x": 593,
      "y": 738
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 987,
      "y": 938
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 14165,
      "y": 57298,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1268,
      "y": 1035
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1249,
      "y": 1004
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 32627,
      "y": 61595,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1250,
      "y": 994
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1254,
      "y": 972
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1236,
      "y": 969
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 58970,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[11] > text"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1200,
      "y": 966
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1193,
      "y": 941
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 28681,
      "y": 57441,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1190,
      "y": 940
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1187,
      "y": 943
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 28258,
      "y": 57656,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1185,
      "y": 944
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 28117,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9055,
      "e": 9055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9254,
      "e": 9254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 9254,
      "e": 9254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9349,
      "e": 9349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 9350,
      "e": 9350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 9518,
      "e": 9518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9519,
      "e": 9519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9605,
      "e": 9605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fo"
    },
    {
      "t": 9742,
      "e": 9742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9743,
      "e": 9743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9805,
      "e": 9805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fol"
    },
    {
      "t": 9885,
      "e": 9885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9885,
      "e": 9885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9981,
      "e": 9981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Foll"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10118,
      "e": 10118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10118,
      "e": 10118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10214,
      "e": 10214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10262,
      "e": 10262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 10262,
      "e": 10262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10374,
      "e": 10374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10503,
      "e": 10503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10629,
      "e": 10629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10677,
      "e": 10677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10677,
      "e": 10677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10789,
      "e": 10789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10837,
      "e": 10837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10837,
      "e": 10837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10982,
      "e": 10982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11039,
      "e": 11039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11039,
      "e": 11039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11125,
      "e": 11125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11181,
      "e": 11181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11181,
      "e": 11181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11269,
      "e": 11269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11414,
      "e": 11414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 11414,
      "e": 11414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11525,
      "e": 11525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 11654,
      "e": 11654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11655,
      "e": 11655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11782,
      "e": 11782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 11790,
      "e": 11790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11790,
      "e": 11790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11909,
      "e": 11909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12102,
      "e": 12102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 12103,
      "e": 12103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12204,
      "e": 12204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the diag"
    },
    {
      "t": 12214,
      "e": 12214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 12438,
      "e": 12438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12439,
      "e": 12439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12557,
      "e": 12557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 12646,
      "e": 12646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12646,
      "e": 12646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12741,
      "e": 12741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12774,
      "e": 12774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12774,
      "e": 12774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12878,
      "e": 12878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12926,
      "e": 12926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12927,
      "e": 12927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13062,
      "e": 13062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 13182,
      "e": 13182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13183,
      "e": 13183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13262,
      "e": 13262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13350,
      "e": 13350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 13350,
      "e": 13350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13446,
      "e": 13446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 13574,
      "e": 13574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13574,
      "e": 13574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13686,
      "e": 13686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13742,
      "e": 13742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13743,
      "e": 13743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13829,
      "e": 13829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 13877,
      "e": 13877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13877,
      "e": 13877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13981,
      "e": 13981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14006,
      "e": 14006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14007,
      "e": 14007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14085,
      "e": 14085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14203,
      "e": 14203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the diagonal line "
    },
    {
      "t": 14229,
      "e": 14229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14229,
      "e": 14229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14325,
      "e": 14325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14326,
      "e": 14326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14341,
      "e": 14341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 14429,
      "e": 14429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14534,
      "e": 14534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14535,
      "e": 14535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14605,
      "e": 14605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14694,
      "e": 14694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14695,
      "e": 14695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14782,
      "e": 14782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 14830,
      "e": 14830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14830,
      "e": 14830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14917,
      "e": 14917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 14933,
      "e": 14933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14933,
      "e": 14933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15013,
      "e": 15013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15110,
      "e": 15110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15110,
      "e": 15110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15294,
      "e": 15294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 15798,
      "e": 15798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15917,
      "e": 15917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the diagonal line going "
    },
    {
      "t": 15982,
      "e": 15982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15982,
      "e": 15982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16086,
      "e": 16086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16086,
      "e": 16086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16109,
      "e": 16109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fr"
    },
    {
      "t": 16198,
      "e": 16198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16198,
      "e": 16198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16214,
      "e": 16214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 16293,
      "e": 16293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16357,
      "e": 16357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16358,
      "e": 16358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16430,
      "e": 16430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 16606,
      "e": 16606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16606,
      "e": 16606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16693,
      "e": 16693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16803,
      "e": 16803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the diagonal line going from "
    },
    {
      "t": 17950,
      "e": 17950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 17950,
      "e": 17950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18061,
      "e": 18061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 18222,
      "e": 18222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 18223,
      "e": 18223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18317,
      "e": 18317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 18654,
      "e": 18654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18655,
      "e": 18655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18758,
      "e": 18758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 18878,
      "e": 18878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18879,
      "e": 18879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18950,
      "e": 18950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19110,
      "e": 19110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19110,
      "e": 19110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19197,
      "e": 19197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20269,
      "e": 20269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20269,
      "e": 20269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20365,
      "e": 20365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20390,
      "e": 20390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20390,
      "e": 20390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20485,
      "e": 20485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20686,
      "e": 20686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20686,
      "e": 20686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20757,
      "e": 20757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20861,
      "e": 20861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20862,
      "e": 20862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20990,
      "e": 20990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21429,
      "e": 21429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21429,
      "e": 21429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21542,
      "e": 21542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21614,
      "e": 21614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21614,
      "e": 21614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21702,
      "e": 21702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21782,
      "e": 21782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21783,
      "e": 21783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21869,
      "e": 21869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22261,
      "e": 22261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 22263,
      "e": 22263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22357,
      "e": 22357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 22622,
      "e": 22622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22623,
      "e": 22623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22677,
      "e": 22677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 22774,
      "e": 22774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22774,
      "e": 22774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22870,
      "e": 22870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 22894,
      "e": 22894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22894,
      "e": 22894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22973,
      "e": 22973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22973,
      "e": 22973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23005,
      "e": 23005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 23117,
      "e": 23117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23118,
      "e": 23118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23118,
      "e": 23118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23197,
      "e": 23197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23269,
      "e": 23269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 23269,
      "e": 23269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23373,
      "e": 23373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23398,
      "e": 23398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23399,
      "e": 23399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23509,
      "e": 23509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23518,
      "e": 23518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23518,
      "e": 23518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23645,
      "e": 23645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23662,
      "e": 23662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23662,
      "e": 23662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23766,
      "e": 23766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23774,
      "e": 23774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23775,
      "e": 23775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23877,
      "e": 23877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25402,
      "e": 25402,
      "ty": 2,
      "x": 915,
      "y": 962
    },
    {
      "t": 25502,
      "e": 25502,
      "ty": 2,
      "x": 850,
      "y": 1025
    },
    {
      "t": 25502,
      "e": 25502,
      "ty": 41,
      "x": 3172,
      "y": 65176,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 25601,
      "e": 25601,
      "ty": 2,
      "x": 695,
      "y": 1093
    },
    {
      "t": 25702,
      "e": 25702,
      "ty": 2,
      "x": 763,
      "y": 992
    },
    {
      "t": 25752,
      "e": 25752,
      "ty": 41,
      "x": 1888,
      "y": 56730,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 25802,
      "e": 25802,
      "ty": 2,
      "x": 527,
      "y": 764
    },
    {
      "t": 25902,
      "e": 25902,
      "ty": 2,
      "x": 494,
      "y": 720
    },
    {
      "t": 26001,
      "e": 26001,
      "ty": 2,
      "x": 487,
      "y": 715
    },
    {
      "t": 26003,
      "e": 26003,
      "ty": 41,
      "x": 43829,
      "y": 39165,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 26102,
      "e": 26102,
      "ty": 2,
      "x": 462,
      "y": 692
    },
    {
      "t": 26179,
      "e": 26179,
      "ty": 6,
      "x": 453,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 26201,
      "e": 26201,
      "ty": 2,
      "x": 453,
      "y": 688
    },
    {
      "t": 26252,
      "e": 26252,
      "ty": 41,
      "x": 61933,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 26302,
      "e": 26302,
      "ty": 2,
      "x": 450,
      "y": 685
    },
    {
      "t": 26402,
      "e": 26402,
      "ty": 2,
      "x": 446,
      "y": 682
    },
    {
      "t": 26442,
      "e": 26442,
      "ty": 3,
      "x": 445,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 26443,
      "e": 26443,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the diagonal line going from 12pm to the upper right"
    },
    {
      "t": 26443,
      "e": 26443,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26444,
      "e": 26444,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 26502,
      "e": 26502,
      "ty": 2,
      "x": 444,
      "y": 682
    },
    {
      "t": 26502,
      "e": 26502,
      "ty": 41,
      "x": 57564,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 26553,
      "e": 26553,
      "ty": 4,
      "x": 57564,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 26564,
      "e": 26564,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 26566,
      "e": 26566,
      "ty": 5,
      "x": 444,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 26569,
      "e": 26569,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 27202,
      "e": 27202,
      "ty": 2,
      "x": 445,
      "y": 682
    },
    {
      "t": 27251,
      "e": 27251,
      "ty": 41,
      "x": 15049,
      "y": 37337,
      "ta": "html > body"
    },
    {
      "t": 27571,
      "e": 27571,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 27801,
      "e": 27801,
      "ty": 2,
      "x": 444,
      "y": 680
    },
    {
      "t": 27902,
      "e": 27902,
      "ty": 2,
      "x": 447,
      "y": 669
    },
    {
      "t": 28001,
      "e": 28001,
      "ty": 2,
      "x": 490,
      "y": 637
    },
    {
      "t": 28002,
      "e": 28002,
      "ty": 41,
      "x": 16598,
      "y": 34844,
      "ta": "html > body"
    },
    {
      "t": 28102,
      "e": 28102,
      "ty": 2,
      "x": 568,
      "y": 602
    },
    {
      "t": 28202,
      "e": 28202,
      "ty": 2,
      "x": 714,
      "y": 575
    },
    {
      "t": 28252,
      "e": 28252,
      "ty": 41,
      "x": 27136,
      "y": 30911,
      "ta": "html > body"
    },
    {
      "t": 28256,
      "e": 28256,
      "ty": 6,
      "x": 821,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28288,
      "e": 28288,
      "ty": 7,
      "x": 868,
      "y": 553,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28302,
      "e": 28302,
      "ty": 2,
      "x": 868,
      "y": 553
    },
    {
      "t": 28401,
      "e": 28401,
      "ty": 2,
      "x": 892,
      "y": 546
    },
    {
      "t": 28502,
      "e": 28502,
      "ty": 2,
      "x": 895,
      "y": 545
    },
    {
      "t": 28503,
      "e": 28503,
      "ty": 41,
      "x": 18816,
      "y": 38757,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 28602,
      "e": 28602,
      "ty": 2,
      "x": 903,
      "y": 552
    },
    {
      "t": 28675,
      "e": 28675,
      "ty": 6,
      "x": 904,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28702,
      "e": 28702,
      "ty": 2,
      "x": 904,
      "y": 554
    },
    {
      "t": 28752,
      "e": 28752,
      "ty": 41,
      "x": 20979,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28802,
      "e": 28802,
      "ty": 2,
      "x": 905,
      "y": 556
    },
    {
      "t": 28902,
      "e": 28902,
      "ty": 2,
      "x": 905,
      "y": 557
    },
    {
      "t": 28946,
      "e": 28946,
      "ty": 3,
      "x": 905,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28947,
      "e": 28947,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29002,
      "e": 29002,
      "ty": 41,
      "x": 20979,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29058,
      "e": 29058,
      "ty": 4,
      "x": 20979,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29058,
      "e": 29058,
      "ty": 5,
      "x": 905,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29202,
      "e": 29202,
      "ty": 2,
      "x": 905,
      "y": 559
    },
    {
      "t": 29252,
      "e": 29252,
      "ty": 41,
      "x": 20979,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29806,
      "e": 29806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 29808,
      "e": 29808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29933,
      "e": 29933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 30001,
      "e": 30001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30431,
      "e": 30431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 30432,
      "e": 30432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30524,
      "e": 30524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 30613,
      "e": 30613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 30613,
      "e": 30613,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 30614,
      "e": 30614,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30615,
      "e": 30615,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30709,
      "e": 30709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 31029,
      "e": 31029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 31422,
      "e": 31422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 31422,
      "e": 31422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31526,
      "e": 31526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 31742,
      "e": 31742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 31743,
      "e": 31743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31853,
      "e": 31853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 31877,
      "e": 31877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 31877,
      "e": 31877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32002,
      "e": 32002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 32006,
      "e": 32006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 32189,
      "e": 32189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 32698,
      "e": 32698,
      "ty": 7,
      "x": 904,
      "y": 583,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32701,
      "e": 32701,
      "ty": 2,
      "x": 904,
      "y": 583
    },
    {
      "t": 32752,
      "e": 32752,
      "ty": 41,
      "x": 21196,
      "y": 51491,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 32801,
      "e": 32801,
      "ty": 2,
      "x": 906,
      "y": 623
    },
    {
      "t": 32843,
      "e": 32843,
      "ty": 6,
      "x": 915,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32901,
      "e": 32901,
      "ty": 2,
      "x": 925,
      "y": 661
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 2,
      "x": 928,
      "y": 663
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 41,
      "x": 25954,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33101,
      "e": 33101,
      "ty": 2,
      "x": 933,
      "y": 665
    },
    {
      "t": 33126,
      "e": 33126,
      "ty": 7,
      "x": 938,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33201,
      "e": 33201,
      "ty": 2,
      "x": 946,
      "y": 674
    },
    {
      "t": 33219,
      "e": 33219,
      "ty": 6,
      "x": 949,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33251,
      "e": 33251,
      "ty": 41,
      "x": 28902,
      "y": 5957,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33301,
      "e": 33301,
      "ty": 2,
      "x": 954,
      "y": 681
    },
    {
      "t": 33401,
      "e": 33401,
      "ty": 2,
      "x": 955,
      "y": 681
    },
    {
      "t": 33482,
      "e": 33482,
      "ty": 3,
      "x": 955,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33484,
      "e": 33484,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 33484,
      "e": 33484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33485,
      "e": 33485,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33501,
      "e": 33501,
      "ty": 41,
      "x": 30448,
      "y": 9929,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33577,
      "e": 33577,
      "ty": 4,
      "x": 30448,
      "y": 9929,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33578,
      "e": 33578,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33578,
      "e": 33578,
      "ty": 5,
      "x": 955,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33578,
      "e": 33578,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 34201,
      "e": 34201,
      "ty": 2,
      "x": 877,
      "y": 626
    },
    {
      "t": 34251,
      "e": 34251,
      "ty": 41,
      "x": 24347,
      "y": 30246,
      "ta": "html > body"
    },
    {
      "t": 34302,
      "e": 34302,
      "ty": 2,
      "x": 690,
      "y": 540
    },
    {
      "t": 34401,
      "e": 34401,
      "ty": 2,
      "x": 689,
      "y": 540
    },
    {
      "t": 34502,
      "e": 34502,
      "ty": 41,
      "x": 23452,
      "y": 29471,
      "ta": "html > body"
    },
    {
      "t": 34598,
      "e": 34598,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 34901,
      "e": 34901,
      "ty": 2,
      "x": 688,
      "y": 539
    },
    {
      "t": 35001,
      "e": 35001,
      "ty": 41,
      "x": 23417,
      "y": 29415,
      "ta": "html > body"
    },
    {
      "t": 35101,
      "e": 35101,
      "ty": 2,
      "x": 697,
      "y": 474
    },
    {
      "t": 35201,
      "e": 35201,
      "ty": 2,
      "x": 759,
      "y": 379
    },
    {
      "t": 35252,
      "e": 35252,
      "ty": 41,
      "x": 26034,
      "y": 20109,
      "ta": "html > body"
    },
    {
      "t": 35301,
      "e": 35301,
      "ty": 2,
      "x": 769,
      "y": 363
    },
    {
      "t": 35401,
      "e": 35401,
      "ty": 2,
      "x": 786,
      "y": 337
    },
    {
      "t": 35501,
      "e": 35501,
      "ty": 2,
      "x": 814,
      "y": 294
    },
    {
      "t": 35502,
      "e": 35502,
      "ty": 41,
      "x": 27756,
      "y": 15843,
      "ta": "html > body"
    },
    {
      "t": 35577,
      "e": 35577,
      "ty": 6,
      "x": 828,
      "y": 263,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 35601,
      "e": 35601,
      "ty": 2,
      "x": 829,
      "y": 260
    },
    {
      "t": 35611,
      "e": 35611,
      "ty": 7,
      "x": 830,
      "y": 256,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 35701,
      "e": 35701,
      "ty": 2,
      "x": 834,
      "y": 245
    },
    {
      "t": 35751,
      "e": 35751,
      "ty": 41,
      "x": 10299,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 35770,
      "e": 35770,
      "ty": 6,
      "x": 834,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 35801,
      "e": 35801,
      "ty": 2,
      "x": 834,
      "y": 244
    },
    {
      "t": 35901,
      "e": 35901,
      "ty": 2,
      "x": 834,
      "y": 241
    },
    {
      "t": 36001,
      "e": 36001,
      "ty": 2,
      "x": 834,
      "y": 240
    },
    {
      "t": 36001,
      "e": 36001,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36018,
      "e": 36018,
      "ty": 3,
      "x": 834,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36019,
      "e": 36019,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36101,
      "e": 36101,
      "ty": 2,
      "x": 834,
      "y": 239
    },
    {
      "t": 36121,
      "e": 36121,
      "ty": 4,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36121,
      "e": 36121,
      "ty": 5,
      "x": 834,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36121,
      "e": 36121,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 36251,
      "e": 36251,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36262,
      "e": 36262,
      "ty": 7,
      "x": 836,
      "y": 251,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36278,
      "e": 36278,
      "ty": 6,
      "x": 837,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 36296,
      "e": 36296,
      "ty": 7,
      "x": 840,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 36301,
      "e": 36301,
      "ty": 2,
      "x": 840,
      "y": 278
    },
    {
      "t": 36401,
      "e": 36401,
      "ty": 2,
      "x": 847,
      "y": 317
    },
    {
      "t": 36502,
      "e": 36502,
      "ty": 2,
      "x": 855,
      "y": 377
    },
    {
      "t": 36502,
      "e": 36502,
      "ty": 41,
      "x": 7968,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 36601,
      "e": 36601,
      "ty": 2,
      "x": 856,
      "y": 391
    },
    {
      "t": 36701,
      "e": 36701,
      "ty": 2,
      "x": 858,
      "y": 406
    },
    {
      "t": 36752,
      "e": 36702,
      "ty": 41,
      "x": 43988,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 36802,
      "e": 36752,
      "ty": 2,
      "x": 860,
      "y": 414
    },
    {
      "t": 37002,
      "e": 36952,
      "ty": 2,
      "x": 858,
      "y": 414
    },
    {
      "t": 37002,
      "e": 36952,
      "ty": 41,
      "x": 42818,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 37501,
      "e": 37451,
      "ty": 2,
      "x": 855,
      "y": 414
    },
    {
      "t": 37502,
      "e": 37452,
      "ty": 41,
      "x": 39306,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 37601,
      "e": 37551,
      "ty": 2,
      "x": 846,
      "y": 418
    },
    {
      "t": 37702,
      "e": 37652,
      "ty": 2,
      "x": 844,
      "y": 430
    },
    {
      "t": 37752,
      "e": 37702,
      "ty": 41,
      "x": 5358,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 37901,
      "e": 37851,
      "ty": 2,
      "x": 845,
      "y": 431
    },
    {
      "t": 38002,
      "e": 37952,
      "ty": 41,
      "x": 5595,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 38302,
      "e": 38252,
      "ty": 2,
      "x": 845,
      "y": 430
    },
    {
      "t": 38401,
      "e": 38351,
      "ty": 2,
      "x": 864,
      "y": 384
    },
    {
      "t": 38501,
      "e": 38451,
      "ty": 2,
      "x": 879,
      "y": 366
    },
    {
      "t": 38501,
      "e": 38451,
      "ty": 41,
      "x": 13664,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 38601,
      "e": 38551,
      "ty": 2,
      "x": 880,
      "y": 364
    },
    {
      "t": 38701,
      "e": 38651,
      "ty": 2,
      "x": 880,
      "y": 366
    },
    {
      "t": 38752,
      "e": 38702,
      "ty": 41,
      "x": 13902,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 38801,
      "e": 38751,
      "ty": 2,
      "x": 883,
      "y": 368
    },
    {
      "t": 38901,
      "e": 38851,
      "ty": 2,
      "x": 961,
      "y": 377
    },
    {
      "t": 39001,
      "e": 38951,
      "ty": 2,
      "x": 1044,
      "y": 378
    },
    {
      "t": 39002,
      "e": 38952,
      "ty": 41,
      "x": 52823,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 39102,
      "e": 39052,
      "ty": 2,
      "x": 1048,
      "y": 376
    },
    {
      "t": 39201,
      "e": 39151,
      "ty": 2,
      "x": 1042,
      "y": 382
    },
    {
      "t": 39252,
      "e": 39202,
      "ty": 41,
      "x": 42855,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 39301,
      "e": 39251,
      "ty": 2,
      "x": 905,
      "y": 464
    },
    {
      "t": 39401,
      "e": 39351,
      "ty": 2,
      "x": 864,
      "y": 505
    },
    {
      "t": 39501,
      "e": 39451,
      "ty": 2,
      "x": 860,
      "y": 506
    },
    {
      "t": 39502,
      "e": 39452,
      "ty": 41,
      "x": 34625,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 39602,
      "e": 39552,
      "ty": 2,
      "x": 852,
      "y": 510
    },
    {
      "t": 39701,
      "e": 39651,
      "ty": 2,
      "x": 851,
      "y": 511
    },
    {
      "t": 39752,
      "e": 39702,
      "ty": 41,
      "x": 7019,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 39801,
      "e": 39751,
      "ty": 2,
      "x": 848,
      "y": 499
    },
    {
      "t": 39902,
      "e": 39852,
      "ty": 2,
      "x": 840,
      "y": 436
    },
    {
      "t": 40001,
      "e": 39951,
      "ty": 2,
      "x": 840,
      "y": 433
    },
    {
      "t": 40001,
      "e": 39951,
      "ty": 41,
      "x": 14839,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 40198,
      "e": 40148,
      "ty": 6,
      "x": 836,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40202,
      "e": 40152,
      "ty": 2,
      "x": 836,
      "y": 436
    },
    {
      "t": 40251,
      "e": 40201,
      "ty": 41,
      "x": 38202,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40301,
      "e": 40251,
      "ty": 2,
      "x": 834,
      "y": 439
    },
    {
      "t": 40586,
      "e": 40536,
      "ty": 3,
      "x": 833,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40587,
      "e": 40537,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 40588,
      "e": 40538,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40601,
      "e": 40551,
      "ty": 2,
      "x": 833,
      "y": 440
    },
    {
      "t": 40698,
      "e": 40648,
      "ty": 4,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40698,
      "e": 40648,
      "ty": 5,
      "x": 833,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40699,
      "e": 40649,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 40751,
      "e": 40701,
      "ty": 41,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40832,
      "e": 40782,
      "ty": 7,
      "x": 837,
      "y": 454,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40901,
      "e": 40851,
      "ty": 2,
      "x": 922,
      "y": 631
    },
    {
      "t": 41001,
      "e": 40951,
      "ty": 2,
      "x": 942,
      "y": 694
    },
    {
      "t": 41002,
      "e": 40952,
      "ty": 41,
      "x": 30383,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 41101,
      "e": 41051,
      "ty": 2,
      "x": 942,
      "y": 689
    },
    {
      "t": 41201,
      "e": 41151,
      "ty": 2,
      "x": 858,
      "y": 628
    },
    {
      "t": 41252,
      "e": 41202,
      "ty": 41,
      "x": 8680,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 41302,
      "e": 41252,
      "ty": 2,
      "x": 858,
      "y": 627
    },
    {
      "t": 41502,
      "e": 41452,
      "ty": 41,
      "x": 8680,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 41601,
      "e": 41551,
      "ty": 2,
      "x": 858,
      "y": 633
    },
    {
      "t": 41701,
      "e": 41651,
      "ty": 2,
      "x": 858,
      "y": 645
    },
    {
      "t": 41752,
      "e": 41702,
      "ty": 41,
      "x": 8680,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 41801,
      "e": 41751,
      "ty": 2,
      "x": 855,
      "y": 660
    },
    {
      "t": 41902,
      "e": 41852,
      "ty": 2,
      "x": 851,
      "y": 676
    },
    {
      "t": 42002,
      "e": 41852,
      "ty": 2,
      "x": 851,
      "y": 682
    },
    {
      "t": 42004,
      "e": 41854,
      "ty": 41,
      "x": 7941,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 42101,
      "e": 41951,
      "ty": 2,
      "x": 851,
      "y": 689
    },
    {
      "t": 42201,
      "e": 42051,
      "ty": 2,
      "x": 851,
      "y": 694
    },
    {
      "t": 42251,
      "e": 42101,
      "ty": 41,
      "x": 7453,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 42302,
      "e": 42152,
      "ty": 2,
      "x": 849,
      "y": 701
    },
    {
      "t": 42401,
      "e": 42251,
      "ty": 2,
      "x": 847,
      "y": 701
    },
    {
      "t": 42501,
      "e": 42351,
      "ty": 2,
      "x": 847,
      "y": 702
    },
    {
      "t": 42502,
      "e": 42352,
      "ty": 41,
      "x": 6445,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 42602,
      "e": 42452,
      "ty": 2,
      "x": 846,
      "y": 703
    },
    {
      "t": 42752,
      "e": 42602,
      "ty": 41,
      "x": 6193,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 42902,
      "e": 42752,
      "ty": 2,
      "x": 844,
      "y": 704
    },
    {
      "t": 43001,
      "e": 42851,
      "ty": 6,
      "x": 835,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43002,
      "e": 42852,
      "ty": 2,
      "x": 835,
      "y": 702
    },
    {
      "t": 43002,
      "e": 42852,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43018,
      "e": 42868,
      "ty": 7,
      "x": 815,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43102,
      "e": 42952,
      "ty": 2,
      "x": 778,
      "y": 681
    },
    {
      "t": 43251,
      "e": 43101,
      "ty": 41,
      "x": 26517,
      "y": 37282,
      "ta": "html > body"
    },
    {
      "t": 43302,
      "e": 43152,
      "ty": 2,
      "x": 784,
      "y": 682
    },
    {
      "t": 43403,
      "e": 43253,
      "ty": 2,
      "x": 825,
      "y": 703
    },
    {
      "t": 43417,
      "e": 43267,
      "ty": 6,
      "x": 828,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43502,
      "e": 43352,
      "ty": 2,
      "x": 831,
      "y": 707
    },
    {
      "t": 43502,
      "e": 43352,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43702,
      "e": 43552,
      "ty": 2,
      "x": 826,
      "y": 699
    },
    {
      "t": 43752,
      "e": 43602,
      "ty": 41,
      "x": 0,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44101,
      "e": 43951,
      "ty": 2,
      "x": 827,
      "y": 698
    },
    {
      "t": 44251,
      "e": 44101,
      "ty": 41,
      "x": 2914,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44338,
      "e": 44188,
      "ty": 3,
      "x": 827,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44339,
      "e": 44189,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 44339,
      "e": 44189,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44481,
      "e": 44331,
      "ty": 4,
      "x": 2914,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44481,
      "e": 44331,
      "ty": 5,
      "x": 827,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44481,
      "e": 44331,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 44778,
      "e": 44628,
      "ty": 7,
      "x": 825,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44801,
      "e": 44651,
      "ty": 2,
      "x": 822,
      "y": 698
    },
    {
      "t": 44902,
      "e": 44752,
      "ty": 2,
      "x": 766,
      "y": 711
    },
    {
      "t": 45001,
      "e": 44851,
      "ty": 2,
      "x": 749,
      "y": 724
    },
    {
      "t": 45002,
      "e": 44852,
      "ty": 41,
      "x": 25518,
      "y": 39664,
      "ta": "html > body"
    },
    {
      "t": 45102,
      "e": 44952,
      "ty": 2,
      "x": 742,
      "y": 753
    },
    {
      "t": 45201,
      "e": 45051,
      "ty": 2,
      "x": 747,
      "y": 775
    },
    {
      "t": 45252,
      "e": 45102,
      "ty": 41,
      "x": 25552,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 45302,
      "e": 45152,
      "ty": 2,
      "x": 787,
      "y": 806
    },
    {
      "t": 45402,
      "e": 45252,
      "ty": 2,
      "x": 832,
      "y": 899
    },
    {
      "t": 45501,
      "e": 45351,
      "ty": 2,
      "x": 847,
      "y": 951
    },
    {
      "t": 45502,
      "e": 45352,
      "ty": 41,
      "x": 6070,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 45702,
      "e": 45552,
      "ty": 2,
      "x": 847,
      "y": 939
    },
    {
      "t": 45752,
      "e": 45602,
      "ty": 41,
      "x": 26845,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 45801,
      "e": 45651,
      "ty": 2,
      "x": 846,
      "y": 932
    },
    {
      "t": 46130,
      "e": 45980,
      "ty": 3,
      "x": 846,
      "y": 932,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 46132,
      "e": 45982,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 46216,
      "e": 46066,
      "ty": 4,
      "x": 26845,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 46216,
      "e": 46066,
      "ty": 5,
      "x": 846,
      "y": 932,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 46217,
      "e": 46067,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 46218,
      "e": 46068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 46402,
      "e": 46252,
      "ty": 2,
      "x": 855,
      "y": 972
    },
    {
      "t": 46502,
      "e": 46352,
      "ty": 2,
      "x": 857,
      "y": 990
    },
    {
      "t": 46502,
      "e": 46352,
      "ty": 41,
      "x": 35319,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 46571,
      "e": 46421,
      "ty": 6,
      "x": 877,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46601,
      "e": 46451,
      "ty": 2,
      "x": 885,
      "y": 1030
    },
    {
      "t": 46701,
      "e": 46551,
      "ty": 2,
      "x": 889,
      "y": 1036
    },
    {
      "t": 46752,
      "e": 46602,
      "ty": 41,
      "x": 32252,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46802,
      "e": 46652,
      "ty": 2,
      "x": 898,
      "y": 1027
    },
    {
      "t": 46902,
      "e": 46752,
      "ty": 2,
      "x": 898,
      "y": 1024
    },
    {
      "t": 46978,
      "e": 46828,
      "ty": 3,
      "x": 898,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46979,
      "e": 46829,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 46980,
      "e": 46830,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47002,
      "e": 46852,
      "ty": 2,
      "x": 898,
      "y": 1023
    },
    {
      "t": 47002,
      "e": 46852,
      "ty": 41,
      "x": 35344,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47090,
      "e": 46940,
      "ty": 4,
      "x": 35344,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47091,
      "e": 46941,
      "ty": 5,
      "x": 898,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47097,
      "e": 46947,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47100,
      "e": 46956,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 47100,
      "e": 46956,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 47201,
      "e": 47057,
      "ty": 2,
      "x": 909,
      "y": 1020
    },
    {
      "t": 47252,
      "e": 47108,
      "ty": 41,
      "x": 31028,
      "y": 56062,
      "ta": "html > body"
    },
    {
      "t": 47401,
      "e": 47257,
      "ty": 2,
      "x": 909,
      "y": 1017
    },
    {
      "t": 47501,
      "e": 47357,
      "ty": 2,
      "x": 906,
      "y": 997
    },
    {
      "t": 47502,
      "e": 47358,
      "ty": 41,
      "x": 30925,
      "y": 54787,
      "ta": "html > body"
    },
    {
      "t": 47601,
      "e": 47457,
      "ty": 2,
      "x": 902,
      "y": 973
    },
    {
      "t": 47701,
      "e": 47557,
      "ty": 2,
      "x": 921,
      "y": 879
    },
    {
      "t": 47752,
      "e": 47608,
      "ty": 41,
      "x": 32268,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 47801,
      "e": 47657,
      "ty": 2,
      "x": 946,
      "y": 711
    },
    {
      "t": 47901,
      "e": 47757,
      "ty": 2,
      "x": 958,
      "y": 663
    },
    {
      "t": 48002,
      "e": 47858,
      "ty": 2,
      "x": 959,
      "y": 607
    },
    {
      "t": 48002,
      "e": 47858,
      "ty": 41,
      "x": 32750,
      "y": 33182,
      "ta": "html > body"
    },
    {
      "t": 48102,
      "e": 47958,
      "ty": 2,
      "x": 944,
      "y": 577
    },
    {
      "t": 48195,
      "e": 48051,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 48201,
      "e": 48057,
      "ty": 2,
      "x": 933,
      "y": 573
    },
    {
      "t": 48252,
      "e": 48108,
      "ty": 41,
      "x": 31414,
      "y": 34919,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 48301,
      "e": 48157,
      "ty": 2,
      "x": 932,
      "y": 572
    },
    {
      "t": 48402,
      "e": 48258,
      "ty": 2,
      "x": 931,
      "y": 572
    },
    {
      "t": 48503,
      "e": 48359,
      "ty": 41,
      "x": 31365,
      "y": 34919,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 48902,
      "e": 48758,
      "ty": 2,
      "x": 603,
      "y": 510
    },
    {
      "t": 49002,
      "e": 48858,
      "ty": 2,
      "x": 325,
      "y": 435
    },
    {
      "t": 49002,
      "e": 48858,
      "ty": 41,
      "x": 1552,
      "y": 42531,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 49102,
      "e": 48958,
      "ty": 2,
      "x": 44,
      "y": 367
    },
    {
      "t": 49201,
      "e": 49057,
      "ty": 2,
      "x": 76,
      "y": 336
    },
    {
      "t": 49252,
      "e": 49108,
      "ty": 41,
      "x": 4545,
      "y": 17505,
      "ta": "> div.masterdiv"
    },
    {
      "t": 49302,
      "e": 49158,
      "ty": 2,
      "x": 326,
      "y": 324
    },
    {
      "t": 49402,
      "e": 49258,
      "ty": 2,
      "x": 485,
      "y": 324
    },
    {
      "t": 49502,
      "e": 49358,
      "ty": 2,
      "x": 646,
      "y": 338
    },
    {
      "t": 49502,
      "e": 49358,
      "ty": 41,
      "x": 17344,
      "y": 8228,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 49602,
      "e": 49458,
      "ty": 2,
      "x": 673,
      "y": 339
    },
    {
      "t": 49752,
      "e": 49608,
      "ty": 41,
      "x": 18672,
      "y": 10568,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 52906,
      "e": 52762,
      "ty": 2,
      "x": 602,
      "y": 419
    },
    {
      "t": 53006,
      "e": 52862,
      "ty": 2,
      "x": 558,
      "y": 450
    },
    {
      "t": 53007,
      "e": 52863,
      "ty": 41,
      "x": 13014,
      "y": 54234,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 53106,
      "e": 52962,
      "ty": 2,
      "x": 553,
      "y": 454
    },
    {
      "t": 53256,
      "e": 53112,
      "ty": 41,
      "x": 12768,
      "y": 57355,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 53406,
      "e": 53262,
      "ty": 2,
      "x": 553,
      "y": 455
    },
    {
      "t": 53506,
      "e": 53362,
      "ty": 41,
      "x": 12768,
      "y": 58135,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 60005,
      "e": 58362,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 75906,
      "e": 58362,
      "ty": 2,
      "x": 610,
      "y": 725
    },
    {
      "t": 76006,
      "e": 58462,
      "ty": 2,
      "x": 607,
      "y": 829
    },
    {
      "t": 76007,
      "e": 58463,
      "ty": 41,
      "x": 15425,
      "y": 35711,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 76106,
      "e": 58562,
      "ty": 2,
      "x": 649,
      "y": 849
    },
    {
      "t": 76206,
      "e": 58662,
      "ty": 2,
      "x": 824,
      "y": 882
    },
    {
      "t": 76257,
      "e": 58713,
      "ty": 41,
      "x": 27282,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 76306,
      "e": 58762,
      "ty": 2,
      "x": 966,
      "y": 929
    },
    {
      "t": 76405,
      "e": 58861,
      "ty": 2,
      "x": 1072,
      "y": 972
    },
    {
      "t": 76506,
      "e": 58962,
      "ty": 2,
      "x": 1055,
      "y": 989
    },
    {
      "t": 76507,
      "e": 58963,
      "ty": 41,
      "x": 37465,
      "y": 59739,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76606,
      "e": 59062,
      "ty": 2,
      "x": 1002,
      "y": 1054
    },
    {
      "t": 76706,
      "e": 59162,
      "ty": 2,
      "x": 992,
      "y": 1062
    },
    {
      "t": 76756,
      "e": 59212,
      "ty": 41,
      "x": 34366,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76806,
      "e": 59262,
      "ty": 2,
      "x": 991,
      "y": 1063
    },
    {
      "t": 76906,
      "e": 59362,
      "ty": 2,
      "x": 983,
      "y": 1067
    },
    {
      "t": 77006,
      "e": 59462,
      "ty": 2,
      "x": 980,
      "y": 1071
    },
    {
      "t": 77006,
      "e": 59462,
      "ty": 41,
      "x": 33776,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77053,
      "e": 59509,
      "ty": 6,
      "x": 977,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 77106,
      "e": 59562,
      "ty": 2,
      "x": 977,
      "y": 1072
    },
    {
      "t": 77206,
      "e": 59662,
      "ty": 2,
      "x": 968,
      "y": 1090
    },
    {
      "t": 77256,
      "e": 59712,
      "ty": 41,
      "x": 30856,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 77306,
      "e": 59762,
      "ty": 2,
      "x": 961,
      "y": 1099
    },
    {
      "t": 77406,
      "e": 59862,
      "ty": 2,
      "x": 955,
      "y": 1103
    },
    {
      "t": 77506,
      "e": 59962,
      "ty": 41,
      "x": 24848,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 79105,
      "e": 61561,
      "ty": 2,
      "x": 961,
      "y": 1102
    },
    {
      "t": 79205,
      "e": 61661,
      "ty": 2,
      "x": 967,
      "y": 1100
    },
    {
      "t": 79255,
      "e": 61711,
      "ty": 41,
      "x": 31402,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 80023,
      "e": 62479,
      "ty": 3,
      "x": 967,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 80023,
      "e": 62479,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 80845,
      "e": 63301,
      "ty": 4,
      "x": 31402,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 80847,
      "e": 63303,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 80848,
      "e": 63304,
      "ty": 5,
      "x": 967,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 80851,
      "e": 63307,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 81256,
      "e": 63712,
      "ty": 41,
      "x": 32888,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 81306,
      "e": 63762,
      "ty": 2,
      "x": 769,
      "y": 766
    },
    {
      "t": 81406,
      "e": 63862,
      "ty": 2,
      "x": 555,
      "y": 437
    },
    {
      "t": 81505,
      "e": 63961,
      "ty": 2,
      "x": 496,
      "y": 409
    },
    {
      "t": 81505,
      "e": 63961,
      "ty": 41,
      "x": 16805,
      "y": 22214,
      "ta": "html > body"
    },
    {
      "t": 81606,
      "e": 64062,
      "ty": 2,
      "x": 474,
      "y": 394
    },
    {
      "t": 81756,
      "e": 64212,
      "ty": 41,
      "x": 16047,
      "y": 21383,
      "ta": "html > body"
    },
    {
      "t": 81883,
      "e": 64339,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 83085,
      "e": 65541,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 216612, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 216618, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10496, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 228442, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10844, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 240296, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8996, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 250380, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 21071, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 272454, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 53511, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 327329, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-C -01 PM-A -08 AM-F -F -F -Z -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1092,y:898,t:1527030329917};\\\", \\\"{x:1075,y:879,t:1527030329927};\\\", \\\"{x:1003,y:798,t:1527030329943};\\\", \\\"{x:927,y:718,t:1527030329961};\\\", \\\"{x:852,y:653,t:1527030329976};\\\", \\\"{x:787,y:605,t:1527030329994};\\\", \\\"{x:735,y:571,t:1527030330011};\\\", \\\"{x:702,y:546,t:1527030330027};\\\", \\\"{x:701,y:545,t:1527030330043};\\\", \\\"{x:700,y:544,t:1527030330155};\\\", \\\"{x:697,y:542,t:1527030330172};\\\", \\\"{x:696,y:540,t:1527030330179};\\\", \\\"{x:696,y:539,t:1527030330193};\\\", \\\"{x:693,y:536,t:1527030330210};\\\", \\\"{x:692,y:536,t:1527030330227};\\\", \\\"{x:690,y:535,t:1527030330244};\\\", \\\"{x:689,y:534,t:1527030330260};\\\", \\\"{x:688,y:534,t:1527030330278};\\\", \\\"{x:686,y:534,t:1527030330293};\\\", \\\"{x:684,y:534,t:1527030330311};\\\", \\\"{x:680,y:532,t:1527030330328};\\\", \\\"{x:672,y:530,t:1527030330343};\\\", \\\"{x:664,y:527,t:1527030330360};\\\", \\\"{x:656,y:523,t:1527030330377};\\\", \\\"{x:651,y:520,t:1527030330393};\\\", \\\"{x:646,y:517,t:1527030330411};\\\", \\\"{x:640,y:512,t:1527030330427};\\\", \\\"{x:639,y:511,t:1527030330444};\\\", \\\"{x:638,y:511,t:1527030330476};\\\", \\\"{x:636,y:510,t:1527030331236};\\\", \\\"{x:634,y:510,t:1527030331245};\\\", \\\"{x:633,y:510,t:1527030331291};\\\", \\\"{x:631,y:510,t:1527030331315};\\\", \\\"{x:630,y:510,t:1527030331331};\\\", \\\"{x:628,y:510,t:1527030331356};\\\", \\\"{x:627,y:510,t:1527030331379};\\\", \\\"{x:625,y:510,t:1527030331403};\\\", \\\"{x:624,y:510,t:1527030331419};\\\", \\\"{x:622,y:510,t:1527030331429};\\\", \\\"{x:621,y:510,t:1527030331444};\\\", \\\"{x:620,y:510,t:1527030331462};\\\", \\\"{x:619,y:510,t:1527030331478};\\\", \\\"{x:618,y:510,t:1527030331588};\\\", \\\"{x:617,y:510,t:1527030334427};\\\", \\\"{x:617,y:512,t:1527030334947};\\\", \\\"{x:618,y:513,t:1527030334954};\\\", \\\"{x:619,y:514,t:1527030334963};\\\", \\\"{x:620,y:515,t:1527030334981};\\\", \\\"{x:621,y:516,t:1527030334997};\\\", \\\"{x:622,y:518,t:1527030335014};\\\", \\\"{x:626,y:522,t:1527030335031};\\\", \\\"{x:640,y:531,t:1527030335048};\\\", \\\"{x:673,y:553,t:1527030335064};\\\", \\\"{x:752,y:593,t:1527030335080};\\\", \\\"{x:856,y:636,t:1527030335098};\\\", \\\"{x:1019,y:698,t:1527030335115};\\\", \\\"{x:1112,y:734,t:1527030335130};\\\", \\\"{x:1200,y:769,t:1527030335147};\\\", \\\"{x:1283,y:808,t:1527030335165};\\\", \\\"{x:1362,y:852,t:1527030335180};\\\", \\\"{x:1415,y:886,t:1527030335198};\\\", \\\"{x:1436,y:900,t:1527030335215};\\\", \\\"{x:1441,y:903,t:1527030335230};\\\", \\\"{x:1436,y:903,t:1527030335307};\\\", \\\"{x:1426,y:900,t:1527030335315};\\\", \\\"{x:1388,y:882,t:1527030335331};\\\", \\\"{x:1331,y:862,t:1527030335348};\\\", \\\"{x:1247,y:832,t:1527030335365};\\\", \\\"{x:1167,y:797,t:1527030335382};\\\", \\\"{x:1081,y:761,t:1527030335398};\\\", \\\"{x:996,y:726,t:1527030335415};\\\", \\\"{x:935,y:696,t:1527030335432};\\\", \\\"{x:899,y:682,t:1527030335448};\\\", \\\"{x:885,y:676,t:1527030335465};\\\", \\\"{x:882,y:675,t:1527030335481};\\\", \\\"{x:883,y:675,t:1527030335612};\\\", \\\"{x:885,y:675,t:1527030335627};\\\", \\\"{x:888,y:675,t:1527030335635};\\\", \\\"{x:891,y:676,t:1527030335651};\\\", \\\"{x:893,y:677,t:1527030335665};\\\", \\\"{x:895,y:677,t:1527030335682};\\\", \\\"{x:897,y:677,t:1527030335698};\\\", \\\"{x:898,y:678,t:1527030335715};\\\", \\\"{x:902,y:680,t:1527030335732};\\\", \\\"{x:904,y:680,t:1527030335748};\\\", \\\"{x:909,y:680,t:1527030335765};\\\", \\\"{x:915,y:680,t:1527030335782};\\\", \\\"{x:920,y:680,t:1527030335798};\\\", \\\"{x:923,y:680,t:1527030335815};\\\", \\\"{x:924,y:680,t:1527030335832};\\\", \\\"{x:928,y:679,t:1527030335848};\\\", \\\"{x:931,y:679,t:1527030335865};\\\", \\\"{x:934,y:676,t:1527030335882};\\\", \\\"{x:939,y:674,t:1527030335899};\\\", \\\"{x:944,y:674,t:1527030335915};\\\", \\\"{x:945,y:674,t:1527030335931};\\\", \\\"{x:947,y:674,t:1527030335949};\\\", \\\"{x:948,y:674,t:1527030335965};\\\", \\\"{x:949,y:674,t:1527030335982};\\\", \\\"{x:951,y:673,t:1527030335999};\\\", \\\"{x:955,y:671,t:1527030336015};\\\", \\\"{x:958,y:668,t:1527030336032};\\\", \\\"{x:963,y:664,t:1527030336049};\\\", \\\"{x:969,y:656,t:1527030336065};\\\", \\\"{x:972,y:647,t:1527030336082};\\\", \\\"{x:978,y:634,t:1527030336099};\\\", \\\"{x:983,y:625,t:1527030336116};\\\", \\\"{x:986,y:618,t:1527030336132};\\\", \\\"{x:990,y:610,t:1527030336149};\\\", \\\"{x:994,y:604,t:1527030336165};\\\", \\\"{x:997,y:599,t:1527030336182};\\\", \\\"{x:999,y:597,t:1527030336199};\\\", \\\"{x:1001,y:595,t:1527030336216};\\\", \\\"{x:1002,y:594,t:1527030336236};\\\", \\\"{x:1003,y:593,t:1527030336249};\\\", \\\"{x:1004,y:593,t:1527030336266};\\\", \\\"{x:1006,y:592,t:1527030336283};\\\", \\\"{x:1007,y:591,t:1527030336364};\\\", \\\"{x:1007,y:590,t:1527030336379};\\\", \\\"{x:1009,y:590,t:1527030336428};\\\", \\\"{x:1010,y:590,t:1527030336436};\\\", \\\"{x:1012,y:590,t:1527030336450};\\\", \\\"{x:1019,y:596,t:1527030336466};\\\", \\\"{x:1031,y:608,t:1527030336483};\\\", \\\"{x:1058,y:637,t:1527030336499};\\\", \\\"{x:1075,y:656,t:1527030336517};\\\", \\\"{x:1101,y:687,t:1527030336533};\\\", \\\"{x:1141,y:736,t:1527030336549};\\\", \\\"{x:1179,y:790,t:1527030336567};\\\", \\\"{x:1213,y:833,t:1527030336585};\\\", \\\"{x:1237,y:863,t:1527030336599};\\\", \\\"{x:1249,y:883,t:1527030336615};\\\", \\\"{x:1258,y:898,t:1527030336632};\\\", \\\"{x:1261,y:908,t:1527030336648};\\\", \\\"{x:1262,y:913,t:1527030336665};\\\", \\\"{x:1264,y:920,t:1527030336683};\\\", \\\"{x:1267,y:924,t:1527030336698};\\\", \\\"{x:1273,y:927,t:1527030336716};\\\", \\\"{x:1277,y:927,t:1527030336733};\\\", \\\"{x:1280,y:927,t:1527030336748};\\\", \\\"{x:1281,y:927,t:1527030336766};\\\", \\\"{x:1282,y:927,t:1527030336811};\\\", \\\"{x:1282,y:925,t:1527030336818};\\\", \\\"{x:1281,y:923,t:1527030336833};\\\", \\\"{x:1280,y:919,t:1527030336848};\\\", \\\"{x:1280,y:918,t:1527030336866};\\\", \\\"{x:1280,y:917,t:1527030336883};\\\", \\\"{x:1279,y:915,t:1527030336899};\\\", \\\"{x:1279,y:911,t:1527030336915};\\\", \\\"{x:1279,y:908,t:1527030336933};\\\", \\\"{x:1278,y:904,t:1527030336948};\\\", \\\"{x:1278,y:900,t:1527030336966};\\\", \\\"{x:1278,y:895,t:1527030336983};\\\", \\\"{x:1278,y:889,t:1527030336998};\\\", \\\"{x:1276,y:881,t:1527030337016};\\\", \\\"{x:1271,y:868,t:1527030337032};\\\", \\\"{x:1267,y:854,t:1527030337049};\\\", \\\"{x:1263,y:843,t:1527030337066};\\\", \\\"{x:1262,y:837,t:1527030337082};\\\", \\\"{x:1262,y:836,t:1527030337099};\\\", \\\"{x:1262,y:834,t:1527030337180};\\\", \\\"{x:1262,y:832,t:1527030337203};\\\", \\\"{x:1263,y:832,t:1527030337216};\\\", \\\"{x:1264,y:829,t:1527030337232};\\\", \\\"{x:1266,y:827,t:1527030337250};\\\", \\\"{x:1267,y:826,t:1527030337265};\\\", \\\"{x:1268,y:824,t:1527030337283};\\\", \\\"{x:1269,y:824,t:1527030337300};\\\", \\\"{x:1268,y:824,t:1527030337379};\\\", \\\"{x:1267,y:826,t:1527030337388};\\\", \\\"{x:1267,y:829,t:1527030337400};\\\", \\\"{x:1266,y:832,t:1527030337416};\\\", \\\"{x:1266,y:837,t:1527030337432};\\\", \\\"{x:1267,y:839,t:1527030337449};\\\", \\\"{x:1270,y:841,t:1527030337466};\\\", \\\"{x:1274,y:847,t:1527030337483};\\\", \\\"{x:1280,y:855,t:1527030337500};\\\", \\\"{x:1296,y:870,t:1527030337516};\\\", \\\"{x:1314,y:891,t:1527030337533};\\\", \\\"{x:1339,y:914,t:1527030337550};\\\", \\\"{x:1357,y:931,t:1527030337567};\\\", \\\"{x:1369,y:948,t:1527030337583};\\\", \\\"{x:1375,y:962,t:1527030337600};\\\", \\\"{x:1379,y:973,t:1527030337616};\\\", \\\"{x:1379,y:981,t:1527030337633};\\\", \\\"{x:1379,y:989,t:1527030337649};\\\", \\\"{x:1379,y:1007,t:1527030337667};\\\", \\\"{x:1380,y:1023,t:1527030337682};\\\", \\\"{x:1382,y:1036,t:1527030337700};\\\", \\\"{x:1383,y:1040,t:1527030337717};\\\", \\\"{x:1383,y:1041,t:1527030337732};\\\", \\\"{x:1383,y:1042,t:1527030337819};\\\", \\\"{x:1383,y:1041,t:1527030337948};\\\", \\\"{x:1383,y:1040,t:1527030338060};\\\", \\\"{x:1385,y:1040,t:1527030338076};\\\", \\\"{x:1386,y:1040,t:1527030338084};\\\", \\\"{x:1390,y:1040,t:1527030338105};\\\", \\\"{x:1394,y:1040,t:1527030338117};\\\", \\\"{x:1401,y:1040,t:1527030338133};\\\", \\\"{x:1409,y:1040,t:1527030338149};\\\", \\\"{x:1417,y:1040,t:1527030338166};\\\", \\\"{x:1422,y:1040,t:1527030338184};\\\", \\\"{x:1429,y:1041,t:1527030338200};\\\", \\\"{x:1437,y:1042,t:1527030338217};\\\", \\\"{x:1447,y:1043,t:1527030338234};\\\", \\\"{x:1460,y:1047,t:1527030338249};\\\", \\\"{x:1477,y:1048,t:1527030338266};\\\", \\\"{x:1484,y:1049,t:1527030338284};\\\", \\\"{x:1492,y:1049,t:1527030338299};\\\", \\\"{x:1496,y:1049,t:1527030338316};\\\", \\\"{x:1500,y:1050,t:1527030338333};\\\", \\\"{x:1504,y:1050,t:1527030338350};\\\", \\\"{x:1509,y:1051,t:1527030338367};\\\", \\\"{x:1511,y:1051,t:1527030338384};\\\", \\\"{x:1512,y:1051,t:1527030338400};\\\", \\\"{x:1513,y:1051,t:1527030338417};\\\", \\\"{x:1514,y:1051,t:1527030338700};\\\", \\\"{x:1513,y:1050,t:1527030339411};\\\", \\\"{x:1513,y:1049,t:1527030339427};\\\", \\\"{x:1512,y:1049,t:1527030339579};\\\", \\\"{x:1511,y:1048,t:1527030339587};\\\", \\\"{x:1508,y:1047,t:1527030339601};\\\", \\\"{x:1501,y:1047,t:1527030339619};\\\", \\\"{x:1499,y:1047,t:1527030339635};\\\", \\\"{x:1496,y:1047,t:1527030341708};\\\", \\\"{x:1490,y:1044,t:1527030341720};\\\", \\\"{x:1477,y:1042,t:1527030341737};\\\", \\\"{x:1470,y:1041,t:1527030341754};\\\", \\\"{x:1464,y:1039,t:1527030341770};\\\", \\\"{x:1458,y:1035,t:1527030341786};\\\", \\\"{x:1444,y:1027,t:1527030341803};\\\", \\\"{x:1440,y:1024,t:1527030341821};\\\", \\\"{x:1437,y:1022,t:1527030341837};\\\", \\\"{x:1437,y:1021,t:1527030341853};\\\", \\\"{x:1435,y:1020,t:1527030341870};\\\", \\\"{x:1433,y:1020,t:1527030341892};\\\", \\\"{x:1432,y:1019,t:1527030342044};\\\", \\\"{x:1428,y:1012,t:1527030342053};\\\", \\\"{x:1423,y:993,t:1527030342071};\\\", \\\"{x:1418,y:977,t:1527030342088};\\\", \\\"{x:1414,y:965,t:1527030342104};\\\", \\\"{x:1407,y:951,t:1527030342120};\\\", \\\"{x:1401,y:943,t:1527030342137};\\\", \\\"{x:1396,y:938,t:1527030342153};\\\", \\\"{x:1393,y:937,t:1527030342170};\\\", \\\"{x:1388,y:933,t:1527030342186};\\\", \\\"{x:1385,y:930,t:1527030342203};\\\", \\\"{x:1383,y:929,t:1527030342235};\\\", \\\"{x:1382,y:928,t:1527030342251};\\\", \\\"{x:1380,y:928,t:1527030342275};\\\", \\\"{x:1378,y:928,t:1527030342287};\\\", \\\"{x:1365,y:929,t:1527030342303};\\\", \\\"{x:1347,y:932,t:1527030342320};\\\", \\\"{x:1327,y:934,t:1527030342338};\\\", \\\"{x:1312,y:937,t:1527030342353};\\\", \\\"{x:1301,y:938,t:1527030342371};\\\", \\\"{x:1287,y:940,t:1527030342387};\\\", \\\"{x:1282,y:942,t:1527030342404};\\\", \\\"{x:1280,y:942,t:1527030342421};\\\", \\\"{x:1278,y:942,t:1527030342437};\\\", \\\"{x:1277,y:942,t:1527030342475};\\\", \\\"{x:1276,y:943,t:1527030342491};\\\", \\\"{x:1277,y:943,t:1527030342604};\\\", \\\"{x:1278,y:943,t:1527030342627};\\\", \\\"{x:1279,y:943,t:1527030342638};\\\", \\\"{x:1280,y:943,t:1527030342655};\\\", \\\"{x:1280,y:942,t:1527030342670};\\\", \\\"{x:1281,y:942,t:1527030342852};\\\", \\\"{x:1281,y:943,t:1527030342876};\\\", \\\"{x:1281,y:944,t:1527030342888};\\\", \\\"{x:1281,y:945,t:1527030342904};\\\", \\\"{x:1281,y:947,t:1527030342921};\\\", \\\"{x:1281,y:948,t:1527030342938};\\\", \\\"{x:1281,y:949,t:1527030342964};\\\", \\\"{x:1281,y:950,t:1527030342980};\\\", \\\"{x:1281,y:951,t:1527030343028};\\\", \\\"{x:1281,y:952,t:1527030343052};\\\", \\\"{x:1283,y:952,t:1527030343316};\\\", \\\"{x:1285,y:952,t:1527030343332};\\\", \\\"{x:1287,y:950,t:1527030343348};\\\", \\\"{x:1288,y:949,t:1527030343355};\\\", \\\"{x:1291,y:944,t:1527030343371};\\\", \\\"{x:1296,y:939,t:1527030343389};\\\", \\\"{x:1300,y:931,t:1527030343404};\\\", \\\"{x:1306,y:917,t:1527030343422};\\\", \\\"{x:1313,y:900,t:1527030343439};\\\", \\\"{x:1320,y:887,t:1527030343455};\\\", \\\"{x:1325,y:875,t:1527030343472};\\\", \\\"{x:1329,y:868,t:1527030343488};\\\", \\\"{x:1331,y:863,t:1527030343503};\\\", \\\"{x:1334,y:861,t:1527030343521};\\\", \\\"{x:1334,y:859,t:1527030343538};\\\", \\\"{x:1335,y:859,t:1527030343554};\\\", \\\"{x:1334,y:860,t:1527030343747};\\\", \\\"{x:1333,y:861,t:1527030343755};\\\", \\\"{x:1330,y:866,t:1527030343771};\\\", \\\"{x:1328,y:868,t:1527030343788};\\\", \\\"{x:1326,y:871,t:1527030343806};\\\", \\\"{x:1325,y:872,t:1527030343821};\\\", \\\"{x:1324,y:873,t:1527030343838};\\\", \\\"{x:1323,y:873,t:1527030343859};\\\", \\\"{x:1322,y:874,t:1527030343872};\\\", \\\"{x:1321,y:875,t:1527030343888};\\\", \\\"{x:1321,y:876,t:1527030343908};\\\", \\\"{x:1320,y:876,t:1527030343923};\\\", \\\"{x:1318,y:876,t:1527030343988};\\\", \\\"{x:1318,y:877,t:1527030344020};\\\", \\\"{x:1317,y:877,t:1527030344035};\\\", \\\"{x:1317,y:878,t:1527030344067};\\\", \\\"{x:1315,y:878,t:1527030344091};\\\", \\\"{x:1314,y:878,t:1527030344107};\\\", \\\"{x:1314,y:879,t:1527030344121};\\\", \\\"{x:1312,y:879,t:1527030344138};\\\", \\\"{x:1310,y:879,t:1527030344154};\\\", \\\"{x:1309,y:879,t:1527030344172};\\\", \\\"{x:1307,y:879,t:1527030344187};\\\", \\\"{x:1306,y:879,t:1527030344205};\\\", \\\"{x:1304,y:879,t:1527030344222};\\\", \\\"{x:1303,y:879,t:1527030344238};\\\", \\\"{x:1301,y:879,t:1527030344255};\\\", \\\"{x:1299,y:878,t:1527030344272};\\\", \\\"{x:1298,y:878,t:1527030344290};\\\", \\\"{x:1298,y:877,t:1527030344339};\\\", \\\"{x:1298,y:875,t:1527030344355};\\\", \\\"{x:1297,y:872,t:1527030344372};\\\", \\\"{x:1297,y:868,t:1527030344389};\\\", \\\"{x:1296,y:864,t:1527030344405};\\\", \\\"{x:1295,y:863,t:1527030344422};\\\", \\\"{x:1295,y:861,t:1527030344438};\\\", \\\"{x:1295,y:860,t:1527030344455};\\\", \\\"{x:1295,y:858,t:1527030344472};\\\", \\\"{x:1295,y:856,t:1527030344488};\\\", \\\"{x:1295,y:854,t:1527030344505};\\\", \\\"{x:1295,y:851,t:1527030344522};\\\", \\\"{x:1295,y:847,t:1527030344540};\\\", \\\"{x:1295,y:845,t:1527030344556};\\\", \\\"{x:1295,y:844,t:1527030344572};\\\", \\\"{x:1295,y:841,t:1527030344589};\\\", \\\"{x:1295,y:839,t:1527030344606};\\\", \\\"{x:1295,y:836,t:1527030344623};\\\", \\\"{x:1295,y:832,t:1527030344639};\\\", \\\"{x:1295,y:831,t:1527030344655};\\\", \\\"{x:1295,y:829,t:1527030344673};\\\", \\\"{x:1295,y:828,t:1527030344690};\\\", \\\"{x:1295,y:826,t:1527030344706};\\\", \\\"{x:1295,y:825,t:1527030344747};\\\", \\\"{x:1294,y:825,t:1527030344948};\\\", \\\"{x:1293,y:825,t:1527030344979};\\\", \\\"{x:1292,y:825,t:1527030345011};\\\", \\\"{x:1291,y:825,t:1527030345059};\\\", \\\"{x:1290,y:825,t:1527030345101};\\\", \\\"{x:1289,y:825,t:1527030345124};\\\", \\\"{x:1287,y:825,t:1527030346124};\\\", \\\"{x:1286,y:825,t:1527030346556};\\\", \\\"{x:1284,y:824,t:1527030346572};\\\", \\\"{x:1283,y:824,t:1527030346595};\\\", \\\"{x:1282,y:824,t:1527030346608};\\\", \\\"{x:1280,y:823,t:1527030346699};\\\", \\\"{x:1278,y:823,t:1527030346707};\\\", \\\"{x:1272,y:823,t:1527030346724};\\\", \\\"{x:1269,y:823,t:1527030346741};\\\", \\\"{x:1269,y:824,t:1527030346757};\\\", \\\"{x:1268,y:823,t:1527030346794};\\\", \\\"{x:1268,y:822,t:1527030346807};\\\", \\\"{x:1266,y:819,t:1527030346824};\\\", \\\"{x:1260,y:814,t:1527030346841};\\\", \\\"{x:1251,y:809,t:1527030346857};\\\", \\\"{x:1233,y:798,t:1527030346875};\\\", \\\"{x:1202,y:773,t:1527030346891};\\\", \\\"{x:1152,y:741,t:1527030346906};\\\", \\\"{x:1115,y:721,t:1527030346925};\\\", \\\"{x:1070,y:701,t:1527030346940};\\\", \\\"{x:1027,y:684,t:1527030346958};\\\", \\\"{x:988,y:669,t:1527030346975};\\\", \\\"{x:960,y:657,t:1527030346991};\\\", \\\"{x:931,y:644,t:1527030347007};\\\", \\\"{x:897,y:628,t:1527030347025};\\\", \\\"{x:845,y:598,t:1527030347042};\\\", \\\"{x:780,y:564,t:1527030347058};\\\", \\\"{x:674,y:527,t:1527030347074};\\\", \\\"{x:623,y:513,t:1527030347091};\\\", \\\"{x:590,y:504,t:1527030347108};\\\", \\\"{x:563,y:496,t:1527030347124};\\\", \\\"{x:546,y:490,t:1527030347141};\\\", \\\"{x:533,y:484,t:1527030347157};\\\", \\\"{x:525,y:483,t:1527030347174};\\\", \\\"{x:513,y:483,t:1527030347191};\\\", \\\"{x:488,y:483,t:1527030347208};\\\", \\\"{x:450,y:483,t:1527030347224};\\\", \\\"{x:392,y:483,t:1527030347241};\\\", \\\"{x:350,y:483,t:1527030347258};\\\", \\\"{x:323,y:483,t:1527030347274};\\\", \\\"{x:314,y:481,t:1527030347291};\\\", \\\"{x:313,y:481,t:1527030347308};\\\", \\\"{x:313,y:480,t:1527030347325};\\\", \\\"{x:314,y:479,t:1527030347341};\\\", \\\"{x:316,y:478,t:1527030347358};\\\", \\\"{x:317,y:478,t:1527030347387};\\\", \\\"{x:319,y:478,t:1527030347402};\\\", \\\"{x:323,y:480,t:1527030347411};\\\", \\\"{x:328,y:488,t:1527030347425};\\\", \\\"{x:329,y:489,t:1527030348748};\\\", \\\"{x:330,y:490,t:1527030348762};\\\", \\\"{x:331,y:501,t:1527030348779};\\\", \\\"{x:334,y:509,t:1527030348797};\\\", \\\"{x:334,y:512,t:1527030348812};\\\", \\\"{x:334,y:514,t:1527030348826};\\\", \\\"{x:335,y:515,t:1527030348859};\\\", \\\"{x:337,y:515,t:1527030348877};\\\", \\\"{x:342,y:514,t:1527030348893};\\\", \\\"{x:349,y:512,t:1527030348910};\\\", \\\"{x:358,y:509,t:1527030348927};\\\", \\\"{x:365,y:507,t:1527030348942};\\\", \\\"{x:369,y:507,t:1527030348960};\\\", \\\"{x:372,y:507,t:1527030348979};\\\", \\\"{x:376,y:507,t:1527030348993};\\\", \\\"{x:394,y:507,t:1527030349009};\\\", \\\"{x:475,y:565,t:1527030349026};\\\", \\\"{x:525,y:627,t:1527030349043};\\\", \\\"{x:554,y:699,t:1527030349059};\\\", \\\"{x:572,y:768,t:1527030349076};\\\", \\\"{x:591,y:835,t:1527030349092};\\\", \\\"{x:611,y:891,t:1527030349109};\\\", \\\"{x:647,y:935,t:1527030349125};\\\", \\\"{x:710,y:975,t:1527030349142};\\\", \\\"{x:795,y:1008,t:1527030349159};\\\", \\\"{x:878,y:1032,t:1527030349175};\\\", \\\"{x:951,y:1043,t:1527030349192};\\\", \\\"{x:990,y:1043,t:1527030349210};\\\", \\\"{x:1021,y:1039,t:1527030349227};\\\", \\\"{x:1027,y:1034,t:1527030349243};\\\", \\\"{x:1030,y:1030,t:1527030349260};\\\", \\\"{x:1034,y:1027,t:1527030349276};\\\", \\\"{x:1041,y:1020,t:1527030349293};\\\", \\\"{x:1050,y:1013,t:1527030349309};\\\", \\\"{x:1061,y:1002,t:1527030349326};\\\", \\\"{x:1074,y:987,t:1527030349342};\\\", \\\"{x:1087,y:972,t:1527030349360};\\\", \\\"{x:1098,y:956,t:1527030349377};\\\", \\\"{x:1108,y:942,t:1527030349392};\\\", \\\"{x:1117,y:933,t:1527030349410};\\\", \\\"{x:1121,y:925,t:1527030349426};\\\", \\\"{x:1121,y:924,t:1527030349443};\\\", \\\"{x:1122,y:920,t:1527030349459};\\\", \\\"{x:1122,y:917,t:1527030349477};\\\", \\\"{x:1126,y:908,t:1527030349492};\\\", \\\"{x:1134,y:899,t:1527030349509};\\\", \\\"{x:1148,y:892,t:1527030349527};\\\", \\\"{x:1165,y:887,t:1527030349543};\\\", \\\"{x:1182,y:886,t:1527030349560};\\\", \\\"{x:1189,y:886,t:1527030349576};\\\", \\\"{x:1192,y:885,t:1527030349592};\\\", \\\"{x:1194,y:883,t:1527030349609};\\\", \\\"{x:1194,y:879,t:1527030349627};\\\", \\\"{x:1196,y:873,t:1527030349642};\\\", \\\"{x:1199,y:862,t:1527030349659};\\\", \\\"{x:1201,y:858,t:1527030349676};\\\", \\\"{x:1201,y:854,t:1527030349693};\\\", \\\"{x:1202,y:853,t:1527030349772};\\\", \\\"{x:1204,y:853,t:1527030349779};\\\", \\\"{x:1210,y:852,t:1527030349793};\\\", \\\"{x:1213,y:848,t:1527030349810};\\\", \\\"{x:1219,y:840,t:1527030349828};\\\", \\\"{x:1223,y:835,t:1527030349843};\\\", \\\"{x:1227,y:828,t:1527030349860};\\\", \\\"{x:1227,y:823,t:1527030349877};\\\", \\\"{x:1227,y:822,t:1527030349894};\\\", \\\"{x:1229,y:821,t:1527030349909};\\\", \\\"{x:1229,y:820,t:1527030349926};\\\", \\\"{x:1230,y:819,t:1527030349943};\\\", \\\"{x:1230,y:818,t:1527030349960};\\\", \\\"{x:1232,y:818,t:1527030350132};\\\", \\\"{x:1232,y:817,t:1527030350155};\\\", \\\"{x:1232,y:815,t:1527030350179};\\\", \\\"{x:1231,y:815,t:1527030350194};\\\", \\\"{x:1230,y:814,t:1527030350212};\\\", \\\"{x:1230,y:815,t:1527030350331};\\\", \\\"{x:1231,y:816,t:1527030350347};\\\", \\\"{x:1232,y:816,t:1527030350386};\\\", \\\"{x:1232,y:817,t:1527030350411};\\\", \\\"{x:1235,y:818,t:1527030350427};\\\", \\\"{x:1243,y:822,t:1527030350443};\\\", \\\"{x:1249,y:826,t:1527030350460};\\\", \\\"{x:1254,y:829,t:1527030350476};\\\", \\\"{x:1255,y:830,t:1527030350493};\\\", \\\"{x:1256,y:832,t:1527030350510};\\\", \\\"{x:1257,y:835,t:1527030350526};\\\", \\\"{x:1261,y:839,t:1527030350543};\\\", \\\"{x:1266,y:843,t:1527030350560};\\\", \\\"{x:1289,y:850,t:1527030350577};\\\", \\\"{x:1310,y:854,t:1527030350593};\\\", \\\"{x:1328,y:854,t:1527030350610};\\\", \\\"{x:1337,y:851,t:1527030350626};\\\", \\\"{x:1344,y:847,t:1527030350643};\\\", \\\"{x:1348,y:841,t:1527030350660};\\\", \\\"{x:1350,y:837,t:1527030350677};\\\", \\\"{x:1355,y:829,t:1527030350693};\\\", \\\"{x:1360,y:818,t:1527030350710};\\\", \\\"{x:1367,y:809,t:1527030350727};\\\", \\\"{x:1373,y:796,t:1527030350743};\\\", \\\"{x:1379,y:788,t:1527030350761};\\\", \\\"{x:1385,y:781,t:1527030350777};\\\", \\\"{x:1386,y:778,t:1527030350794};\\\", \\\"{x:1389,y:774,t:1527030350811};\\\", \\\"{x:1390,y:772,t:1527030350827};\\\", \\\"{x:1393,y:768,t:1527030350843};\\\", \\\"{x:1393,y:767,t:1527030350861};\\\", \\\"{x:1395,y:764,t:1527030350876};\\\", \\\"{x:1397,y:761,t:1527030350893};\\\", \\\"{x:1399,y:755,t:1527030350910};\\\", \\\"{x:1399,y:753,t:1527030350926};\\\", \\\"{x:1400,y:753,t:1527030350943};\\\", \\\"{x:1401,y:752,t:1527030350961};\\\", \\\"{x:1401,y:751,t:1527030350976};\\\", \\\"{x:1401,y:750,t:1527030350994};\\\", \\\"{x:1401,y:748,t:1527030351010};\\\", \\\"{x:1401,y:747,t:1527030351026};\\\", \\\"{x:1401,y:746,t:1527030351043};\\\", \\\"{x:1401,y:745,t:1527030351179};\\\", \\\"{x:1400,y:745,t:1527030351203};\\\", \\\"{x:1399,y:745,t:1527030351291};\\\", \\\"{x:1397,y:745,t:1527030351300};\\\", \\\"{x:1396,y:745,t:1527030351311};\\\", \\\"{x:1390,y:741,t:1527030351327};\\\", \\\"{x:1383,y:733,t:1527030351343};\\\", \\\"{x:1378,y:726,t:1527030351360};\\\", \\\"{x:1378,y:724,t:1527030351377};\\\", \\\"{x:1377,y:724,t:1527030351402};\\\", \\\"{x:1377,y:723,t:1527030351426};\\\", \\\"{x:1377,y:722,t:1527030351434};\\\", \\\"{x:1377,y:720,t:1527030351443};\\\", \\\"{x:1377,y:719,t:1527030351461};\\\", \\\"{x:1378,y:719,t:1527030351515};\\\", \\\"{x:1379,y:719,t:1527030351531};\\\", \\\"{x:1380,y:719,t:1527030351544};\\\", \\\"{x:1380,y:720,t:1527030351628};\\\", \\\"{x:1378,y:726,t:1527030351645};\\\", \\\"{x:1374,y:735,t:1527030351661};\\\", \\\"{x:1372,y:743,t:1527030351678};\\\", \\\"{x:1370,y:748,t:1527030351695};\\\", \\\"{x:1369,y:753,t:1527030351711};\\\", \\\"{x:1368,y:759,t:1527030351727};\\\", \\\"{x:1365,y:768,t:1527030351744};\\\", \\\"{x:1363,y:778,t:1527030351761};\\\", \\\"{x:1363,y:791,t:1527030351778};\\\", \\\"{x:1363,y:818,t:1527030351795};\\\", \\\"{x:1363,y:829,t:1527030351810};\\\", \\\"{x:1363,y:836,t:1527030351828};\\\", \\\"{x:1362,y:837,t:1527030351845};\\\", \\\"{x:1361,y:839,t:1527030351861};\\\", \\\"{x:1357,y:840,t:1527030351878};\\\", \\\"{x:1353,y:841,t:1527030351895};\\\", \\\"{x:1347,y:844,t:1527030351911};\\\", \\\"{x:1344,y:847,t:1527030351927};\\\", \\\"{x:1341,y:851,t:1527030351945};\\\", \\\"{x:1337,y:855,t:1527030351961};\\\", \\\"{x:1332,y:856,t:1527030351978};\\\", \\\"{x:1327,y:859,t:1527030351995};\\\", \\\"{x:1326,y:860,t:1527030352011};\\\", \\\"{x:1324,y:861,t:1527030352028};\\\", \\\"{x:1324,y:862,t:1527030352045};\\\", \\\"{x:1323,y:864,t:1527030352061};\\\", \\\"{x:1323,y:865,t:1527030352078};\\\", \\\"{x:1320,y:868,t:1527030352095};\\\", \\\"{x:1320,y:869,t:1527030352112};\\\", \\\"{x:1319,y:871,t:1527030352127};\\\", \\\"{x:1317,y:877,t:1527030352144};\\\", \\\"{x:1316,y:881,t:1527030352161};\\\", \\\"{x:1313,y:886,t:1527030352177};\\\", \\\"{x:1312,y:891,t:1527030352194};\\\", \\\"{x:1311,y:894,t:1527030352211};\\\", \\\"{x:1311,y:895,t:1527030352235};\\\", \\\"{x:1309,y:897,t:1527030352250};\\\", \\\"{x:1309,y:898,t:1527030352619};\\\", \\\"{x:1309,y:897,t:1527030352691};\\\", \\\"{x:1309,y:898,t:1527030353315};\\\", \\\"{x:1308,y:900,t:1527030353331};\\\", \\\"{x:1308,y:901,t:1527030353355};\\\", \\\"{x:1307,y:902,t:1527030353460};\\\", \\\"{x:1307,y:903,t:1527030353475};\\\", \\\"{x:1306,y:903,t:1527030353740};\\\", \\\"{x:1306,y:895,t:1527030353755};\\\", \\\"{x:1308,y:888,t:1527030353763};\\\", \\\"{x:1317,y:870,t:1527030353779};\\\", \\\"{x:1331,y:844,t:1527030353796};\\\", \\\"{x:1362,y:799,t:1527030353812};\\\", \\\"{x:1372,y:781,t:1527030353829};\\\", \\\"{x:1376,y:772,t:1527030353846};\\\", \\\"{x:1382,y:766,t:1527030353863};\\\", \\\"{x:1383,y:764,t:1527030353889};\\\", \\\"{x:1385,y:761,t:1527030353905};\\\", \\\"{x:1386,y:757,t:1527030353924};\\\", \\\"{x:1386,y:755,t:1527030353939};\\\", \\\"{x:1387,y:754,t:1527030353956};\\\", \\\"{x:1387,y:753,t:1527030353974};\\\", \\\"{x:1387,y:752,t:1527030353997};\\\", \\\"{x:1387,y:751,t:1527030354005};\\\", \\\"{x:1388,y:751,t:1527030354023};\\\", \\\"{x:1387,y:752,t:1527030354181};\\\", \\\"{x:1384,y:756,t:1527030354189};\\\", \\\"{x:1383,y:759,t:1527030354206};\\\", \\\"{x:1382,y:759,t:1527030354223};\\\", \\\"{x:1383,y:759,t:1527030354765};\\\", \\\"{x:1384,y:759,t:1527030354788};\\\", \\\"{x:1385,y:759,t:1527030358317};\\\", \\\"{x:1386,y:759,t:1527030361174};\\\", \\\"{x:1387,y:758,t:1527030361181};\\\", \\\"{x:1391,y:757,t:1527030361193};\\\", \\\"{x:1398,y:755,t:1527030361210};\\\", \\\"{x:1399,y:755,t:1527030361227};\\\", \\\"{x:1401,y:754,t:1527030361242};\\\", \\\"{x:1403,y:754,t:1527030361260};\\\", \\\"{x:1405,y:754,t:1527030361276};\\\", \\\"{x:1407,y:754,t:1527030361292};\\\", \\\"{x:1408,y:754,t:1527030361310};\\\", \\\"{x:1409,y:754,t:1527030361326};\\\", \\\"{x:1411,y:754,t:1527030361343};\\\", \\\"{x:1418,y:754,t:1527030361360};\\\", \\\"{x:1423,y:754,t:1527030361378};\\\", \\\"{x:1426,y:754,t:1527030361394};\\\", \\\"{x:1427,y:754,t:1527030361410};\\\", \\\"{x:1428,y:754,t:1527030361452};\\\", \\\"{x:1429,y:754,t:1527030361581};\\\", \\\"{x:1430,y:754,t:1527030361605};\\\", \\\"{x:1431,y:754,t:1527030361894};\\\", \\\"{x:1433,y:754,t:1527030361933};\\\", \\\"{x:1435,y:755,t:1527030361989};\\\", \\\"{x:1435,y:756,t:1527030362013};\\\", \\\"{x:1436,y:756,t:1527030362061};\\\", \\\"{x:1438,y:756,t:1527030362078};\\\", \\\"{x:1438,y:757,t:1527030362103};\\\", \\\"{x:1439,y:757,t:1527030362116};\\\", \\\"{x:1441,y:757,t:1527030362132};\\\", \\\"{x:1443,y:757,t:1527030362144};\\\", \\\"{x:1456,y:759,t:1527030362160};\\\", \\\"{x:1474,y:764,t:1527030362176};\\\", \\\"{x:1493,y:767,t:1527030362194};\\\", \\\"{x:1512,y:768,t:1527030362210};\\\", \\\"{x:1524,y:770,t:1527030362227};\\\", \\\"{x:1530,y:770,t:1527030362244};\\\", \\\"{x:1538,y:770,t:1527030362260};\\\", \\\"{x:1540,y:771,t:1527030362277};\\\", \\\"{x:1541,y:771,t:1527030362333};\\\", \\\"{x:1542,y:771,t:1527030362358};\\\", \\\"{x:1544,y:771,t:1527030362597};\\\", \\\"{x:1545,y:771,t:1527030362611};\\\", \\\"{x:1552,y:771,t:1527030362628};\\\", \\\"{x:1561,y:771,t:1527030362644};\\\", \\\"{x:1575,y:770,t:1527030362661};\\\", \\\"{x:1579,y:770,t:1527030362678};\\\", \\\"{x:1580,y:770,t:1527030362717};\\\", \\\"{x:1581,y:770,t:1527030362741};\\\", \\\"{x:1582,y:770,t:1527030362749};\\\", \\\"{x:1584,y:770,t:1527030362761};\\\", \\\"{x:1585,y:770,t:1527030362778};\\\", \\\"{x:1585,y:769,t:1527030363205};\\\", \\\"{x:1585,y:768,t:1527030363253};\\\", \\\"{x:1585,y:766,t:1527030363285};\\\", \\\"{x:1585,y:764,t:1527030363461};\\\", \\\"{x:1584,y:764,t:1527030363749};\\\", \\\"{x:1583,y:763,t:1527030363773};\\\", \\\"{x:1585,y:763,t:1527030364853};\\\", \\\"{x:1588,y:764,t:1527030364869};\\\", \\\"{x:1590,y:766,t:1527030364880};\\\", \\\"{x:1605,y:774,t:1527030364897};\\\", \\\"{x:1626,y:781,t:1527030364912};\\\", \\\"{x:1650,y:789,t:1527030364930};\\\", \\\"{x:1694,y:805,t:1527030364947};\\\", \\\"{x:1751,y:829,t:1527030364963};\\\", \\\"{x:1812,y:853,t:1527030364979};\\\", \\\"{x:1864,y:875,t:1527030364996};\\\", \\\"{x:1903,y:892,t:1527030365012};\\\", \\\"{x:1919,y:903,t:1527030365029};\\\", \\\"{x:1919,y:904,t:1527030365045};\\\", \\\"{x:1918,y:904,t:1527030365213};\\\", \\\"{x:1915,y:904,t:1527030365229};\\\", \\\"{x:1911,y:904,t:1527030365246};\\\", \\\"{x:1905,y:904,t:1527030365262};\\\", \\\"{x:1897,y:904,t:1527030365279};\\\", \\\"{x:1890,y:904,t:1527030365296};\\\", \\\"{x:1883,y:904,t:1527030365315};\\\", \\\"{x:1879,y:904,t:1527030365331};\\\", \\\"{x:1878,y:904,t:1527030365388};\\\", \\\"{x:1877,y:904,t:1527030365399};\\\", \\\"{x:1875,y:904,t:1527030365415};\\\", \\\"{x:1874,y:904,t:1527030365550};\\\", \\\"{x:1874,y:901,t:1527030365566};\\\", \\\"{x:1873,y:897,t:1527030365582};\\\", \\\"{x:1868,y:887,t:1527030365600};\\\", \\\"{x:1864,y:878,t:1527030365617};\\\", \\\"{x:1858,y:862,t:1527030365633};\\\", \\\"{x:1849,y:845,t:1527030365650};\\\", \\\"{x:1840,y:830,t:1527030365666};\\\", \\\"{x:1833,y:821,t:1527030365684};\\\", \\\"{x:1832,y:819,t:1527030365699};\\\", \\\"{x:1831,y:818,t:1527030365716};\\\", \\\"{x:1831,y:817,t:1527030365765};\\\", \\\"{x:1831,y:816,t:1527030365781};\\\", \\\"{x:1831,y:814,t:1527030365789};\\\", \\\"{x:1830,y:813,t:1527030365878};\\\", \\\"{x:1829,y:812,t:1527030365949};\\\", \\\"{x:1827,y:809,t:1527030365967};\\\", \\\"{x:1826,y:806,t:1527030365984};\\\", \\\"{x:1826,y:805,t:1527030366000};\\\", \\\"{x:1837,y:805,t:1527030366017};\\\", \\\"{x:1837,y:803,t:1527030367005};\\\", \\\"{x:1835,y:802,t:1527030367018};\\\", \\\"{x:1834,y:796,t:1527030367035};\\\", \\\"{x:1833,y:786,t:1527030367051};\\\", \\\"{x:1827,y:767,t:1527030367067};\\\", \\\"{x:1814,y:725,t:1527030367084};\\\", \\\"{x:1786,y:664,t:1527030367100};\\\", \\\"{x:1757,y:594,t:1527030367117};\\\", \\\"{x:1730,y:550,t:1527030367134};\\\", \\\"{x:1708,y:519,t:1527030367150};\\\", \\\"{x:1672,y:477,t:1527030367167};\\\", \\\"{x:1639,y:439,t:1527030367183};\\\", \\\"{x:1606,y:403,t:1527030367199};\\\", \\\"{x:1582,y:373,t:1527030367217};\\\", \\\"{x:1565,y:349,t:1527030367234};\\\", \\\"{x:1555,y:336,t:1527030367250};\\\", \\\"{x:1552,y:331,t:1527030367267};\\\", \\\"{x:1550,y:327,t:1527030367284};\\\", \\\"{x:1548,y:322,t:1527030367301};\\\", \\\"{x:1545,y:308,t:1527030367317};\\\", \\\"{x:1535,y:281,t:1527030367335};\\\", \\\"{x:1528,y:252,t:1527030367350};\\\", \\\"{x:1521,y:235,t:1527030367367};\\\", \\\"{x:1519,y:227,t:1527030367384};\\\", \\\"{x:1518,y:223,t:1527030367401};\\\", \\\"{x:1517,y:220,t:1527030367417};\\\", \\\"{x:1515,y:218,t:1527030367434};\\\", \\\"{x:1515,y:217,t:1527030367452};\\\", \\\"{x:1514,y:214,t:1527030367467};\\\", \\\"{x:1512,y:207,t:1527030367485};\\\", \\\"{x:1511,y:201,t:1527030367501};\\\", \\\"{x:1511,y:200,t:1527030367573};\\\", \\\"{x:1511,y:199,t:1527030367584};\\\", \\\"{x:1511,y:203,t:1527030367781};\\\", \\\"{x:1511,y:207,t:1527030367789};\\\", \\\"{x:1511,y:211,t:1527030367801};\\\", \\\"{x:1512,y:230,t:1527030367818};\\\", \\\"{x:1514,y:263,t:1527030367835};\\\", \\\"{x:1519,y:320,t:1527030367852};\\\", \\\"{x:1524,y:436,t:1527030367869};\\\", \\\"{x:1524,y:480,t:1527030367884};\\\", \\\"{x:1524,y:594,t:1527030367902};\\\", \\\"{x:1528,y:651,t:1527030367918};\\\", \\\"{x:1524,y:709,t:1527030367934};\\\", \\\"{x:1520,y:739,t:1527030367952};\\\", \\\"{x:1519,y:761,t:1527030367969};\\\", \\\"{x:1518,y:770,t:1527030367985};\\\", \\\"{x:1516,y:774,t:1527030368001};\\\", \\\"{x:1515,y:776,t:1527030368019};\\\", \\\"{x:1513,y:779,t:1527030368034};\\\", \\\"{x:1511,y:781,t:1527030368052};\\\", \\\"{x:1510,y:782,t:1527030368069};\\\", \\\"{x:1509,y:782,t:1527030368085};\\\", \\\"{x:1505,y:782,t:1527030368102};\\\", \\\"{x:1499,y:782,t:1527030368118};\\\", \\\"{x:1497,y:782,t:1527030368134};\\\", \\\"{x:1495,y:782,t:1527030368151};\\\", \\\"{x:1493,y:782,t:1527030368168};\\\", \\\"{x:1489,y:782,t:1527030368184};\\\", \\\"{x:1487,y:782,t:1527030368201};\\\", \\\"{x:1483,y:782,t:1527030368218};\\\", \\\"{x:1482,y:782,t:1527030368234};\\\", \\\"{x:1479,y:782,t:1527030368251};\\\", \\\"{x:1470,y:782,t:1527030368268};\\\", \\\"{x:1462,y:780,t:1527030368284};\\\", \\\"{x:1445,y:776,t:1527030368301};\\\", \\\"{x:1431,y:770,t:1527030368318};\\\", \\\"{x:1416,y:766,t:1527030368335};\\\", \\\"{x:1406,y:764,t:1527030368351};\\\", \\\"{x:1397,y:763,t:1527030368368};\\\", \\\"{x:1389,y:761,t:1527030368385};\\\", \\\"{x:1386,y:761,t:1527030368401};\\\", \\\"{x:1385,y:761,t:1527030368957};\\\", \\\"{x:1385,y:762,t:1527030368968};\\\", \\\"{x:1385,y:764,t:1527030368985};\\\", \\\"{x:1386,y:767,t:1527030369003};\\\", \\\"{x:1386,y:769,t:1527030369019};\\\", \\\"{x:1386,y:773,t:1527030369036};\\\", \\\"{x:1386,y:781,t:1527030369052};\\\", \\\"{x:1386,y:795,t:1527030369068};\\\", \\\"{x:1384,y:816,t:1527030369085};\\\", \\\"{x:1381,y:836,t:1527030369103};\\\", \\\"{x:1378,y:851,t:1527030369119};\\\", \\\"{x:1376,y:857,t:1527030369135};\\\", \\\"{x:1376,y:862,t:1527030369152};\\\", \\\"{x:1375,y:866,t:1527030369169};\\\", \\\"{x:1372,y:875,t:1527030369185};\\\", \\\"{x:1367,y:887,t:1527030369202};\\\", \\\"{x:1364,y:903,t:1527030369219};\\\", \\\"{x:1360,y:917,t:1527030369235};\\\", \\\"{x:1359,y:924,t:1527030369252};\\\", \\\"{x:1357,y:920,t:1527030369373};\\\", \\\"{x:1355,y:915,t:1527030369386};\\\", \\\"{x:1345,y:900,t:1527030369403};\\\", \\\"{x:1333,y:887,t:1527030369420};\\\", \\\"{x:1327,y:879,t:1527030369435};\\\", \\\"{x:1324,y:876,t:1527030369453};\\\", \\\"{x:1323,y:876,t:1527030369526};\\\", \\\"{x:1322,y:877,t:1527030369536};\\\", \\\"{x:1318,y:883,t:1527030369553};\\\", \\\"{x:1308,y:890,t:1527030369570};\\\", \\\"{x:1300,y:900,t:1527030369586};\\\", \\\"{x:1297,y:906,t:1527030369603};\\\", \\\"{x:1296,y:912,t:1527030369619};\\\", \\\"{x:1293,y:920,t:1527030369636};\\\", \\\"{x:1292,y:922,t:1527030369653};\\\", \\\"{x:1292,y:926,t:1527030369669};\\\", \\\"{x:1291,y:934,t:1527030369687};\\\", \\\"{x:1291,y:941,t:1527030369702};\\\", \\\"{x:1291,y:946,t:1527030369720};\\\", \\\"{x:1291,y:949,t:1527030369737};\\\", \\\"{x:1291,y:950,t:1527030369757};\\\", \\\"{x:1291,y:951,t:1527030369838};\\\", \\\"{x:1292,y:954,t:1527030369852};\\\", \\\"{x:1292,y:956,t:1527030369869};\\\", \\\"{x:1292,y:957,t:1527030370013};\\\", \\\"{x:1292,y:958,t:1527030370038};\\\", \\\"{x:1292,y:953,t:1527030370117};\\\", \\\"{x:1294,y:944,t:1527030370124};\\\", \\\"{x:1297,y:934,t:1527030370136};\\\", \\\"{x:1304,y:918,t:1527030370153};\\\", \\\"{x:1315,y:901,t:1527030370169};\\\", \\\"{x:1327,y:889,t:1527030370186};\\\", \\\"{x:1351,y:872,t:1527030370203};\\\", \\\"{x:1359,y:866,t:1527030370219};\\\", \\\"{x:1360,y:865,t:1527030370238};\\\", \\\"{x:1360,y:864,t:1527030370253};\\\", \\\"{x:1361,y:864,t:1527030370276};\\\", \\\"{x:1361,y:862,t:1527030370286};\\\", \\\"{x:1362,y:860,t:1527030370303};\\\", \\\"{x:1364,y:857,t:1527030370319};\\\", \\\"{x:1366,y:857,t:1527030370336};\\\", \\\"{x:1368,y:856,t:1527030370353};\\\", \\\"{x:1369,y:856,t:1527030370404};\\\", \\\"{x:1369,y:855,t:1527030370419};\\\", \\\"{x:1373,y:846,t:1527030370436};\\\", \\\"{x:1376,y:840,t:1527030370453};\\\", \\\"{x:1377,y:839,t:1527030370470};\\\", \\\"{x:1379,y:837,t:1527030370486};\\\", \\\"{x:1380,y:837,t:1527030370503};\\\", \\\"{x:1380,y:836,t:1527030370520};\\\", \\\"{x:1382,y:834,t:1527030370549};\\\", \\\"{x:1383,y:829,t:1527030370557};\\\", \\\"{x:1383,y:827,t:1527030370571};\\\", \\\"{x:1387,y:819,t:1527030370587};\\\", \\\"{x:1389,y:814,t:1527030370604};\\\", \\\"{x:1392,y:813,t:1527030370620};\\\", \\\"{x:1392,y:812,t:1527030370685};\\\", \\\"{x:1392,y:811,t:1527030370693};\\\", \\\"{x:1392,y:810,t:1527030370704};\\\", \\\"{x:1392,y:807,t:1527030370797};\\\", \\\"{x:1392,y:806,t:1527030370805};\\\", \\\"{x:1392,y:803,t:1527030370820};\\\", \\\"{x:1392,y:802,t:1527030370836};\\\", \\\"{x:1394,y:798,t:1527030370854};\\\", \\\"{x:1395,y:797,t:1527030370871};\\\", \\\"{x:1395,y:795,t:1527030370887};\\\", \\\"{x:1395,y:793,t:1527030370903};\\\", \\\"{x:1395,y:792,t:1527030370920};\\\", \\\"{x:1395,y:791,t:1527030370938};\\\", \\\"{x:1395,y:790,t:1527030370953};\\\", \\\"{x:1395,y:787,t:1527030370971};\\\", \\\"{x:1395,y:783,t:1527030370988};\\\", \\\"{x:1397,y:782,t:1527030371003};\\\", \\\"{x:1396,y:780,t:1527030371174};\\\", \\\"{x:1393,y:777,t:1527030371188};\\\", \\\"{x:1386,y:771,t:1527030371204};\\\", \\\"{x:1385,y:770,t:1527030371221};\\\", \\\"{x:1384,y:769,t:1527030371244};\\\", \\\"{x:1383,y:768,t:1527030371461};\\\", \\\"{x:1383,y:767,t:1527030371581};\\\", \\\"{x:1382,y:766,t:1527030371604};\\\", \\\"{x:1381,y:765,t:1527030371749};\\\", \\\"{x:1382,y:766,t:1527030372085};\\\", \\\"{x:1385,y:774,t:1527030372094};\\\", \\\"{x:1389,y:782,t:1527030372105};\\\", \\\"{x:1398,y:800,t:1527030372121};\\\", \\\"{x:1405,y:810,t:1527030372137};\\\", \\\"{x:1408,y:818,t:1527030372154};\\\", \\\"{x:1409,y:819,t:1527030372172};\\\", \\\"{x:1409,y:820,t:1527030372188};\\\", \\\"{x:1411,y:825,t:1527030372203};\\\", \\\"{x:1413,y:833,t:1527030372221};\\\", \\\"{x:1420,y:848,t:1527030372238};\\\", \\\"{x:1427,y:861,t:1527030372254};\\\", \\\"{x:1429,y:869,t:1527030372272};\\\", \\\"{x:1431,y:871,t:1527030372289};\\\", \\\"{x:1431,y:873,t:1527030372324};\\\", \\\"{x:1431,y:877,t:1527030372338};\\\", \\\"{x:1437,y:895,t:1527030372354};\\\", \\\"{x:1446,y:914,t:1527030372371};\\\", \\\"{x:1450,y:923,t:1527030372388};\\\", \\\"{x:1451,y:924,t:1527030372614};\\\", \\\"{x:1453,y:924,t:1527030372622};\\\", \\\"{x:1456,y:927,t:1527030372639};\\\", \\\"{x:1459,y:927,t:1527030372655};\\\", \\\"{x:1460,y:928,t:1527030372692};\\\", \\\"{x:1461,y:929,t:1527030372708};\\\", \\\"{x:1461,y:931,t:1527030372724};\\\", \\\"{x:1461,y:932,t:1527030372738};\\\", \\\"{x:1462,y:935,t:1527030372755};\\\", \\\"{x:1463,y:937,t:1527030372771};\\\", \\\"{x:1463,y:938,t:1527030372788};\\\", \\\"{x:1463,y:939,t:1527030372812};\\\", \\\"{x:1464,y:940,t:1527030372876};\\\", \\\"{x:1465,y:940,t:1527030372965};\\\", \\\"{x:1467,y:938,t:1527030372981};\\\", \\\"{x:1467,y:937,t:1527030372997};\\\", \\\"{x:1467,y:935,t:1527030373005};\\\", \\\"{x:1467,y:933,t:1527030373022};\\\", \\\"{x:1467,y:930,t:1527030373038};\\\", \\\"{x:1463,y:925,t:1527030373056};\\\", \\\"{x:1454,y:919,t:1527030373072};\\\", \\\"{x:1431,y:907,t:1527030373089};\\\", \\\"{x:1395,y:889,t:1527030373106};\\\", \\\"{x:1351,y:871,t:1527030373122};\\\", \\\"{x:1296,y:846,t:1527030373138};\\\", \\\"{x:1246,y:825,t:1527030373156};\\\", \\\"{x:1170,y:791,t:1527030373172};\\\", \\\"{x:1119,y:765,t:1527030373189};\\\", \\\"{x:1059,y:731,t:1527030373206};\\\", \\\"{x:1004,y:706,t:1527030373223};\\\", \\\"{x:960,y:688,t:1527030373238};\\\", \\\"{x:923,y:671,t:1527030373255};\\\", \\\"{x:892,y:651,t:1527030373273};\\\", \\\"{x:870,y:632,t:1527030373289};\\\", \\\"{x:831,y:605,t:1527030373307};\\\", \\\"{x:793,y:577,t:1527030373323};\\\", \\\"{x:741,y:543,t:1527030373338};\\\", \\\"{x:690,y:519,t:1527030373355};\\\", \\\"{x:647,y:495,t:1527030373371};\\\", \\\"{x:583,y:468,t:1527030373389};\\\", \\\"{x:555,y:461,t:1527030373405};\\\", \\\"{x:538,y:460,t:1527030373422};\\\", \\\"{x:527,y:458,t:1527030373438};\\\", \\\"{x:519,y:458,t:1527030373455};\\\", \\\"{x:513,y:458,t:1527030373472};\\\", \\\"{x:509,y:460,t:1527030373488};\\\", \\\"{x:507,y:462,t:1527030373505};\\\", \\\"{x:504,y:467,t:1527030373522};\\\", \\\"{x:501,y:474,t:1527030373538};\\\", \\\"{x:500,y:477,t:1527030373555};\\\", \\\"{x:500,y:480,t:1527030373571};\\\", \\\"{x:499,y:486,t:1527030373588};\\\", \\\"{x:499,y:487,t:1527030373605};\\\", \\\"{x:498,y:488,t:1527030373621};\\\", \\\"{x:496,y:490,t:1527030373638};\\\", \\\"{x:491,y:494,t:1527030373655};\\\", \\\"{x:483,y:497,t:1527030373671};\\\", \\\"{x:470,y:500,t:1527030373689};\\\", \\\"{x:447,y:501,t:1527030373706};\\\", \\\"{x:421,y:501,t:1527030373721};\\\", \\\"{x:403,y:501,t:1527030373738};\\\", \\\"{x:396,y:501,t:1527030373755};\\\", \\\"{x:395,y:502,t:1527030373796};\\\", \\\"{x:395,y:503,t:1527030373804};\\\", \\\"{x:395,y:504,t:1527030373829};\\\", \\\"{x:395,y:505,t:1527030373839};\\\", \\\"{x:395,y:506,t:1527030373855};\\\", \\\"{x:395,y:507,t:1527030373872};\\\", \\\"{x:395,y:510,t:1527030373890};\\\", \\\"{x:397,y:518,t:1527030373906};\\\", \\\"{x:402,y:527,t:1527030373922};\\\", \\\"{x:406,y:537,t:1527030373939};\\\", \\\"{x:407,y:539,t:1527030373956};\\\", \\\"{x:407,y:540,t:1527030373972};\\\", \\\"{x:407,y:543,t:1527030373989};\\\", \\\"{x:407,y:545,t:1527030374006};\\\", \\\"{x:407,y:546,t:1527030374028};\\\", \\\"{x:406,y:547,t:1527030374039};\\\", \\\"{x:405,y:547,t:1527030374140};\\\", \\\"{x:404,y:547,t:1527030374156};\\\", \\\"{x:402,y:549,t:1527030374173};\\\", \\\"{x:401,y:549,t:1527030374197};\\\", \\\"{x:400,y:549,t:1527030374228};\\\", \\\"{x:399,y:550,t:1527030374252};\\\", \\\"{x:397,y:550,t:1527030374269};\\\", \\\"{x:397,y:551,t:1527030374277};\\\", \\\"{x:396,y:551,t:1527030374289};\\\", \\\"{x:395,y:552,t:1527030374307};\\\", \\\"{x:394,y:552,t:1527030374389};\\\", \\\"{x:392,y:552,t:1527030374405};\\\", \\\"{x:391,y:552,t:1527030374412};\\\", \\\"{x:390,y:552,t:1527030374436};\\\", \\\"{x:389,y:552,t:1527030374444};\\\", \\\"{x:388,y:552,t:1527030374460};\\\", \\\"{x:389,y:552,t:1527030374716};\\\", \\\"{x:390,y:551,t:1527030374836};\\\", \\\"{x:391,y:551,t:1527030374852};\\\", \\\"{x:393,y:551,t:1527030374860};\\\", \\\"{x:394,y:551,t:1527030374874};\\\", \\\"{x:397,y:551,t:1527030374891};\\\", \\\"{x:398,y:551,t:1527030374906};\\\", \\\"{x:400,y:552,t:1527030374923};\\\", \\\"{x:410,y:562,t:1527030374940};\\\", \\\"{x:424,y:574,t:1527030374957};\\\", \\\"{x:441,y:589,t:1527030374974};\\\", \\\"{x:462,y:606,t:1527030374990};\\\", \\\"{x:480,y:617,t:1527030375007};\\\", \\\"{x:487,y:621,t:1527030375023};\\\", \\\"{x:488,y:622,t:1527030375040};\\\", \\\"{x:486,y:624,t:1527030375083};\\\", \\\"{x:486,y:626,t:1527030375092};\\\", \\\"{x:486,y:628,t:1527030375108};\\\", \\\"{x:486,y:630,t:1527030375123};\\\", \\\"{x:486,y:631,t:1527030375141};\\\", \\\"{x:486,y:633,t:1527030375164};\\\", \\\"{x:486,y:634,t:1527030375175};\\\", \\\"{x:483,y:643,t:1527030375191};\\\", \\\"{x:477,y:664,t:1527030375208};\\\", \\\"{x:475,y:687,t:1527030375224};\\\", \\\"{x:475,y:702,t:1527030375241};\\\", \\\"{x:475,y:706,t:1527030375257};\\\", \\\"{x:476,y:707,t:1527030375333};\\\", \\\"{x:477,y:707,t:1527030375405};\\\", \\\"{x:478,y:707,t:1527030375421};\\\", \\\"{x:479,y:707,t:1527030375429};\\\", \\\"{x:480,y:707,t:1527030375441};\\\", \\\"{x:481,y:707,t:1527030375458};\\\", \\\"{x:484,y:707,t:1527030375474};\\\", \\\"{x:485,y:707,t:1527030375501};\\\", \\\"{x:486,y:707,t:1527030375613};\\\", \\\"{x:486,y:706,t:1527030375644};\\\", \\\"{x:488,y:705,t:1527030375669};\\\", \\\"{x:488,y:704,t:1527030376243};\\\", \\\"{x:487,y:704,t:1527030378005};\\\", \\\"{x:486,y:704,t:1527030378013};\\\", \\\"{x:485,y:704,t:1527030378469};\\\", \\\"{x:485,y:705,t:1527030380381};\\\", \\\"{x:486,y:705,t:1527030380405};\\\", \\\"{x:486,y:706,t:1527030380757};\\\", \\\"{x:486,y:707,t:1527030380861};\\\", \\\"{x:485,y:708,t:1527030380989};\\\", \\\"{x:484,y:708,t:1527030381341};\\\", \\\"{x:483,y:708,t:1527030381365};\\\", \\\"{x:483,y:709,t:1527030381379};\\\", \\\"{x:482,y:709,t:1527030381397};\\\", \\\"{x:481,y:710,t:1527030381453};\\\", \\\"{x:481,y:711,t:1527030381492};\\\", \\\"{x:481,y:712,t:1527030381501};\\\", \\\"{x:481,y:713,t:1527030381513};\\\", \\\"{x:480,y:715,t:1527030381529};\\\", \\\"{x:481,y:715,t:1527030382453};\\\", \\\"{x:482,y:713,t:1527030382463};\\\", \\\"{x:484,y:708,t:1527030382479};\\\", \\\"{x:487,y:701,t:1527030382497};\\\", \\\"{x:488,y:695,t:1527030382513};\\\", \\\"{x:490,y:689,t:1527030382530};\\\", \\\"{x:492,y:682,t:1527030382546};\\\", \\\"{x:496,y:673,t:1527030382563};\\\", \\\"{x:498,y:663,t:1527030382580};\\\", \\\"{x:501,y:634,t:1527030382597};\\\", \\\"{x:503,y:620,t:1527030382612};\\\", \\\"{x:505,y:613,t:1527030382630};\\\", \\\"{x:505,y:606,t:1527030382647};\\\", \\\"{x:505,y:602,t:1527030382663};\\\", \\\"{x:505,y:598,t:1527030382680};\\\", \\\"{x:505,y:589,t:1527030382697};\\\", \\\"{x:505,y:572,t:1527030382713};\\\", \\\"{x:505,y:551,t:1527030382730};\\\", \\\"{x:505,y:529,t:1527030382747};\\\", \\\"{x:505,y:516,t:1527030382763};\\\", \\\"{x:505,y:508,t:1527030382780};\\\", \\\"{x:503,y:492,t:1527030382796};\\\", \\\"{x:500,y:481,t:1527030382813};\\\", \\\"{x:499,y:471,t:1527030382830};\\\", \\\"{x:496,y:452,t:1527030382847};\\\", \\\"{x:496,y:432,t:1527030382863};\\\", \\\"{x:496,y:412,t:1527030382880};\\\", \\\"{x:496,y:396,t:1527030382897};\\\", \\\"{x:496,y:387,t:1527030382914};\\\", \\\"{x:496,y:374,t:1527030382929};\\\", \\\"{x:496,y:364,t:1527030382947};\\\", \\\"{x:496,y:356,t:1527030382964};\\\", \\\"{x:501,y:300,t:1527030383021};\\\", \\\"{x:501,y:298,t:1527030383029};\\\", \\\"{x:501,y:296,t:1527030383046};\\\", \\\"{x:501,y:295,t:1527030383063};\\\", \\\"{x:501,y:293,t:1527030383079};\\\", \\\"{x:502,y:291,t:1527030383096};\\\" ] }, { \\\"rt\\\": 8296, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 336868, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:285,t:1527030383196};\\\", \\\"{x:507,y:284,t:1527030383517};\\\", \\\"{x:508,y:284,t:1527030383555};\\\", \\\"{x:508,y:288,t:1527030383572};\\\", \\\"{x:508,y:297,t:1527030383580};\\\", \\\"{x:535,y:403,t:1527030383696};\\\", \\\"{x:535,y:405,t:1527030383701};\\\", \\\"{x:535,y:407,t:1527030383714};\\\", \\\"{x:535,y:414,t:1527030383730};\\\", \\\"{x:532,y:433,t:1527030383747};\\\", \\\"{x:526,y:443,t:1527030383763};\\\", \\\"{x:523,y:451,t:1527030383780};\\\", \\\"{x:523,y:456,t:1527030383797};\\\", \\\"{x:523,y:461,t:1527030383813};\\\", \\\"{x:523,y:464,t:1527030383830};\\\", \\\"{x:523,y:466,t:1527030383848};\\\", \\\"{x:522,y:467,t:1527030383900};\\\", \\\"{x:520,y:467,t:1527030383981};\\\", \\\"{x:519,y:468,t:1527030383998};\\\", \\\"{x:519,y:467,t:1527030384388};\\\", \\\"{x:519,y:462,t:1527030384397};\\\", \\\"{x:520,y:455,t:1527030384415};\\\", \\\"{x:520,y:454,t:1527030385053};\\\", \\\"{x:518,y:454,t:1527030385065};\\\", \\\"{x:511,y:457,t:1527030385082};\\\", \\\"{x:506,y:462,t:1527030385099};\\\", \\\"{x:501,y:466,t:1527030385114};\\\", \\\"{x:495,y:473,t:1527030385132};\\\", \\\"{x:492,y:476,t:1527030385148};\\\", \\\"{x:489,y:480,t:1527030385164};\\\", \\\"{x:487,y:483,t:1527030385182};\\\", \\\"{x:486,y:486,t:1527030385199};\\\", \\\"{x:484,y:487,t:1527030385215};\\\", \\\"{x:484,y:488,t:1527030385309};\\\", \\\"{x:484,y:489,t:1527030385317};\\\", \\\"{x:484,y:491,t:1527030385444};\\\", \\\"{x:486,y:492,t:1527030385452};\\\", \\\"{x:493,y:496,t:1527030385466};\\\", \\\"{x:518,y:506,t:1527030385483};\\\", \\\"{x:557,y:523,t:1527030385498};\\\", \\\"{x:625,y:544,t:1527030385516};\\\", \\\"{x:678,y:559,t:1527030385531};\\\", \\\"{x:723,y:574,t:1527030385548};\\\", \\\"{x:769,y:589,t:1527030385565};\\\", \\\"{x:832,y:606,t:1527030385582};\\\", \\\"{x:913,y:633,t:1527030385599};\\\", \\\"{x:975,y:652,t:1527030385614};\\\", \\\"{x:1036,y:669,t:1527030385631};\\\", \\\"{x:1093,y:690,t:1527030385648};\\\", \\\"{x:1152,y:709,t:1527030385666};\\\", \\\"{x:1197,y:721,t:1527030385681};\\\", \\\"{x:1223,y:729,t:1527030385699};\\\", \\\"{x:1243,y:738,t:1527030385715};\\\", \\\"{x:1246,y:739,t:1527030385732};\\\", \\\"{x:1251,y:740,t:1527030385779};\\\", \\\"{x:1261,y:743,t:1527030385788};\\\", \\\"{x:1274,y:745,t:1527030385799};\\\", \\\"{x:1309,y:755,t:1527030385816};\\\", \\\"{x:1337,y:758,t:1527030385833};\\\", \\\"{x:1354,y:761,t:1527030385849};\\\", \\\"{x:1359,y:762,t:1527030385866};\\\", \\\"{x:1363,y:762,t:1527030385884};\\\", \\\"{x:1369,y:764,t:1527030385898};\\\", \\\"{x:1406,y:767,t:1527030385916};\\\", \\\"{x:1452,y:768,t:1527030385932};\\\", \\\"{x:1502,y:768,t:1527030385949};\\\", \\\"{x:1542,y:768,t:1527030385966};\\\", \\\"{x:1559,y:768,t:1527030385983};\\\", \\\"{x:1561,y:768,t:1527030385999};\\\", \\\"{x:1560,y:769,t:1527030386085};\\\", \\\"{x:1556,y:771,t:1527030386100};\\\", \\\"{x:1545,y:772,t:1527030386117};\\\", \\\"{x:1527,y:775,t:1527030386134};\\\", \\\"{x:1508,y:775,t:1527030386150};\\\", \\\"{x:1491,y:775,t:1527030386168};\\\", \\\"{x:1474,y:777,t:1527030386183};\\\", \\\"{x:1459,y:780,t:1527030386200};\\\", \\\"{x:1445,y:781,t:1527030386217};\\\", \\\"{x:1433,y:786,t:1527030386233};\\\", \\\"{x:1418,y:792,t:1527030386250};\\\", \\\"{x:1407,y:799,t:1527030386267};\\\", \\\"{x:1399,y:804,t:1527030386282};\\\", \\\"{x:1391,y:808,t:1527030386300};\\\", \\\"{x:1387,y:810,t:1527030386317};\\\", \\\"{x:1379,y:813,t:1527030386333};\\\", \\\"{x:1369,y:816,t:1527030386350};\\\", \\\"{x:1359,y:817,t:1527030386367};\\\", \\\"{x:1352,y:817,t:1527030386384};\\\", \\\"{x:1349,y:817,t:1527030386400};\\\", \\\"{x:1348,y:817,t:1527030386417};\\\", \\\"{x:1347,y:817,t:1527030386485};\\\", \\\"{x:1347,y:816,t:1527030386500};\\\", \\\"{x:1347,y:813,t:1527030386517};\\\", \\\"{x:1347,y:810,t:1527030386534};\\\", \\\"{x:1347,y:807,t:1527030386550};\\\", \\\"{x:1347,y:804,t:1527030386567};\\\", \\\"{x:1347,y:800,t:1527030386584};\\\", \\\"{x:1347,y:794,t:1527030386601};\\\", \\\"{x:1350,y:784,t:1527030386617};\\\", \\\"{x:1352,y:777,t:1527030386634};\\\", \\\"{x:1353,y:773,t:1527030386651};\\\", \\\"{x:1353,y:771,t:1527030386667};\\\", \\\"{x:1353,y:768,t:1527030386685};\\\", \\\"{x:1353,y:764,t:1527030386700};\\\", \\\"{x:1355,y:758,t:1527030386717};\\\", \\\"{x:1359,y:749,t:1527030386734};\\\", \\\"{x:1361,y:743,t:1527030386752};\\\", \\\"{x:1363,y:736,t:1527030386768};\\\", \\\"{x:1364,y:734,t:1527030386784};\\\", \\\"{x:1364,y:733,t:1527030386801};\\\", \\\"{x:1366,y:732,t:1527030386818};\\\", \\\"{x:1366,y:731,t:1527030386834};\\\", \\\"{x:1367,y:729,t:1527030386851};\\\", \\\"{x:1370,y:725,t:1527030386868};\\\", \\\"{x:1372,y:722,t:1527030386884};\\\", \\\"{x:1374,y:719,t:1527030386901};\\\", \\\"{x:1374,y:718,t:1527030386918};\\\", \\\"{x:1376,y:717,t:1527030386934};\\\", \\\"{x:1379,y:715,t:1527030386951};\\\", \\\"{x:1382,y:714,t:1527030386969};\\\", \\\"{x:1393,y:711,t:1527030386984};\\\", \\\"{x:1411,y:704,t:1527030387001};\\\", \\\"{x:1432,y:699,t:1527030387019};\\\", \\\"{x:1445,y:695,t:1527030387035};\\\", \\\"{x:1457,y:689,t:1527030387051};\\\", \\\"{x:1470,y:682,t:1527030387068};\\\", \\\"{x:1476,y:677,t:1527030387084};\\\", \\\"{x:1484,y:671,t:1527030387101};\\\", \\\"{x:1493,y:656,t:1527030387118};\\\", \\\"{x:1503,y:642,t:1527030387135};\\\", \\\"{x:1510,y:631,t:1527030387154};\\\", \\\"{x:1515,y:624,t:1527030387168};\\\", \\\"{x:1521,y:617,t:1527030387185};\\\", \\\"{x:1527,y:609,t:1527030387202};\\\", \\\"{x:1533,y:600,t:1527030387217};\\\", \\\"{x:1538,y:590,t:1527030387234};\\\", \\\"{x:1553,y:566,t:1527030387251};\\\", \\\"{x:1559,y:554,t:1527030387268};\\\", \\\"{x:1565,y:544,t:1527030387285};\\\", \\\"{x:1570,y:538,t:1527030387302};\\\", \\\"{x:1572,y:535,t:1527030387318};\\\", \\\"{x:1572,y:533,t:1527030387335};\\\", \\\"{x:1573,y:528,t:1527030387351};\\\", \\\"{x:1573,y:525,t:1527030387368};\\\", \\\"{x:1573,y:521,t:1527030387385};\\\", \\\"{x:1573,y:518,t:1527030387401};\\\", \\\"{x:1573,y:516,t:1527030387418};\\\", \\\"{x:1573,y:515,t:1527030387435};\\\", \\\"{x:1573,y:514,t:1527030387451};\\\", \\\"{x:1575,y:513,t:1527030387469};\\\", \\\"{x:1575,y:512,t:1527030387485};\\\", \\\"{x:1576,y:508,t:1527030387502};\\\", \\\"{x:1578,y:503,t:1527030387519};\\\", \\\"{x:1583,y:495,t:1527030387535};\\\", \\\"{x:1585,y:490,t:1527030387551};\\\", \\\"{x:1589,y:483,t:1527030387569};\\\", \\\"{x:1592,y:480,t:1527030387585};\\\", \\\"{x:1596,y:475,t:1527030387602};\\\", \\\"{x:1605,y:464,t:1527030387619};\\\", \\\"{x:1615,y:449,t:1527030387636};\\\", \\\"{x:1616,y:444,t:1527030387652};\\\", \\\"{x:1620,y:438,t:1527030387669};\\\", \\\"{x:1620,y:437,t:1527030387692};\\\", \\\"{x:1620,y:436,t:1527030387845};\\\", \\\"{x:1619,y:435,t:1527030387885};\\\", \\\"{x:1618,y:435,t:1527030387900};\\\", \\\"{x:1617,y:435,t:1527030387949};\\\", \\\"{x:1616,y:435,t:1527030387969};\\\", \\\"{x:1608,y:437,t:1527030387988};\\\", \\\"{x:1586,y:457,t:1527030388003};\\\", \\\"{x:1565,y:495,t:1527030388019};\\\", \\\"{x:1530,y:555,t:1527030388036};\\\", \\\"{x:1512,y:579,t:1527030388053};\\\", \\\"{x:1500,y:596,t:1527030388070};\\\", \\\"{x:1489,y:616,t:1527030388087};\\\", \\\"{x:1468,y:658,t:1527030388104};\\\", \\\"{x:1449,y:705,t:1527030388120};\\\", \\\"{x:1425,y:753,t:1527030388136};\\\", \\\"{x:1409,y:778,t:1527030388153};\\\", \\\"{x:1408,y:780,t:1527030388170};\\\", \\\"{x:1407,y:777,t:1527030388188};\\\", \\\"{x:1407,y:770,t:1527030388203};\\\", \\\"{x:1407,y:749,t:1527030388221};\\\", \\\"{x:1412,y:736,t:1527030388236};\\\", \\\"{x:1421,y:726,t:1527030388253};\\\", \\\"{x:1427,y:718,t:1527030388270};\\\", \\\"{x:1429,y:715,t:1527030388287};\\\", \\\"{x:1433,y:713,t:1527030388304};\\\", \\\"{x:1436,y:710,t:1527030388320};\\\", \\\"{x:1439,y:706,t:1527030388338};\\\", \\\"{x:1443,y:699,t:1527030388354};\\\", \\\"{x:1450,y:689,t:1527030388370};\\\", \\\"{x:1458,y:680,t:1527030388387};\\\", \\\"{x:1462,y:677,t:1527030388403};\\\", \\\"{x:1465,y:675,t:1527030388420};\\\", \\\"{x:1466,y:674,t:1527030388444};\\\", \\\"{x:1469,y:673,t:1527030388454};\\\", \\\"{x:1473,y:669,t:1527030388471};\\\", \\\"{x:1481,y:663,t:1527030388487};\\\", \\\"{x:1489,y:657,t:1527030388504};\\\", \\\"{x:1493,y:653,t:1527030388520};\\\", \\\"{x:1496,y:651,t:1527030388537};\\\", \\\"{x:1497,y:650,t:1527030388554};\\\", \\\"{x:1499,y:650,t:1527030388570};\\\", \\\"{x:1500,y:649,t:1527030388587};\\\", \\\"{x:1515,y:643,t:1527030388604};\\\", \\\"{x:1529,y:636,t:1527030388620};\\\", \\\"{x:1535,y:633,t:1527030388638};\\\", \\\"{x:1537,y:632,t:1527030388654};\\\", \\\"{x:1536,y:632,t:1527030388765};\\\", \\\"{x:1534,y:633,t:1527030388780};\\\", \\\"{x:1533,y:633,t:1527030388796};\\\", \\\"{x:1531,y:634,t:1527030388804};\\\", \\\"{x:1527,y:636,t:1527030388821};\\\", \\\"{x:1524,y:637,t:1527030388838};\\\", \\\"{x:1517,y:641,t:1527030388854};\\\", \\\"{x:1512,y:642,t:1527030388872};\\\", \\\"{x:1511,y:644,t:1527030388889};\\\", \\\"{x:1511,y:643,t:1527030388933};\\\", \\\"{x:1511,y:642,t:1527030388949};\\\", \\\"{x:1513,y:642,t:1527030388980};\\\", \\\"{x:1513,y:641,t:1527030389004};\\\", \\\"{x:1512,y:641,t:1527030389229};\\\", \\\"{x:1507,y:645,t:1527030389239};\\\", \\\"{x:1492,y:656,t:1527030389256};\\\", \\\"{x:1463,y:669,t:1527030389272};\\\", \\\"{x:1417,y:686,t:1527030389288};\\\", \\\"{x:1362,y:703,t:1527030389305};\\\", \\\"{x:1288,y:717,t:1527030389322};\\\", \\\"{x:1206,y:722,t:1527030389338};\\\", \\\"{x:1106,y:722,t:1527030389355};\\\", \\\"{x:929,y:722,t:1527030389372};\\\", \\\"{x:803,y:733,t:1527030389388};\\\", \\\"{x:716,y:748,t:1527030389405};\\\", \\\"{x:679,y:752,t:1527030389421};\\\", \\\"{x:669,y:752,t:1527030389438};\\\", \\\"{x:667,y:752,t:1527030389455};\\\", \\\"{x:667,y:751,t:1527030389484};\\\", \\\"{x:667,y:750,t:1527030389524};\\\", \\\"{x:667,y:746,t:1527030389538};\\\", \\\"{x:667,y:732,t:1527030389555};\\\", \\\"{x:665,y:716,t:1527030389572};\\\", \\\"{x:660,y:702,t:1527030389589};\\\", \\\"{x:656,y:692,t:1527030389604};\\\", \\\"{x:647,y:686,t:1527030389622};\\\", \\\"{x:624,y:681,t:1527030389639};\\\", \\\"{x:560,y:672,t:1527030389655};\\\", \\\"{x:469,y:648,t:1527030389673};\\\", \\\"{x:392,y:619,t:1527030389689};\\\", \\\"{x:336,y:592,t:1527030389706};\\\", \\\"{x:305,y:575,t:1527030389729};\\\", \\\"{x:294,y:569,t:1527030389746};\\\", \\\"{x:292,y:567,t:1527030389768};\\\", \\\"{x:292,y:565,t:1527030389827};\\\", \\\"{x:294,y:561,t:1527030389835};\\\", \\\"{x:299,y:555,t:1527030389852};\\\", \\\"{x:304,y:551,t:1527030389868};\\\", \\\"{x:306,y:551,t:1527030389885};\\\", \\\"{x:307,y:551,t:1527030389907};\\\", \\\"{x:309,y:551,t:1527030389923};\\\", \\\"{x:310,y:551,t:1527030389980};\\\", \\\"{x:312,y:551,t:1527030389988};\\\", \\\"{x:313,y:552,t:1527030390004};\\\", \\\"{x:316,y:552,t:1527030390019};\\\", \\\"{x:322,y:557,t:1527030390035};\\\", \\\"{x:324,y:558,t:1527030390053};\\\", \\\"{x:324,y:559,t:1527030390070};\\\", \\\"{x:325,y:559,t:1527030390085};\\\", \\\"{x:332,y:563,t:1527030390103};\\\", \\\"{x:343,y:569,t:1527030390120};\\\", \\\"{x:351,y:574,t:1527030390136};\\\", \\\"{x:355,y:577,t:1527030390153};\\\", \\\"{x:357,y:579,t:1527030390170};\\\", \\\"{x:358,y:579,t:1527030390186};\\\", \\\"{x:358,y:581,t:1527030390220};\\\", \\\"{x:359,y:581,t:1527030390236};\\\", \\\"{x:361,y:583,t:1527030390254};\\\", \\\"{x:365,y:585,t:1527030390268};\\\", \\\"{x:366,y:586,t:1527030390286};\\\", \\\"{x:369,y:586,t:1527030390303};\\\", \\\"{x:370,y:586,t:1527030390319};\\\", \\\"{x:371,y:586,t:1527030390419};\\\", \\\"{x:373,y:586,t:1527030390460};\\\", \\\"{x:374,y:586,t:1527030390541};\\\", \\\"{x:375,y:586,t:1527030390573};\\\", \\\"{x:375,y:589,t:1527030390828};\\\", \\\"{x:383,y:599,t:1527030390835};\\\", \\\"{x:416,y:622,t:1527030390853};\\\", \\\"{x:468,y:654,t:1527030390871};\\\", \\\"{x:517,y:684,t:1527030390886};\\\", \\\"{x:543,y:700,t:1527030390903};\\\", \\\"{x:554,y:706,t:1527030390920};\\\", \\\"{x:559,y:710,t:1527030390936};\\\", \\\"{x:562,y:713,t:1527030390953};\\\", \\\"{x:562,y:714,t:1527030391076};\\\", \\\"{x:561,y:714,t:1527030391092};\\\", \\\"{x:559,y:714,t:1527030391103};\\\", \\\"{x:558,y:714,t:1527030391124};\\\", \\\"{x:557,y:716,t:1527030391140};\\\", \\\"{x:556,y:716,t:1527030391153};\\\", \\\"{x:555,y:716,t:1527030391172};\\\", \\\"{x:554,y:717,t:1527030391186};\\\", \\\"{x:549,y:721,t:1527030391203};\\\", \\\"{x:542,y:726,t:1527030391220};\\\", \\\"{x:540,y:729,t:1527030391237};\\\", \\\"{x:538,y:730,t:1527030391253};\\\", \\\"{x:537,y:730,t:1527030391324};\\\", \\\"{x:536,y:730,t:1527030391387};\\\", \\\"{x:536,y:730,t:1527030391515};\\\", \\\"{x:535,y:730,t:1527030392365};\\\", \\\"{x:534,y:730,t:1527030392374};\\\", \\\"{x:533,y:730,t:1527030392388};\\\", \\\"{x:533,y:729,t:1527030392404};\\\", \\\"{x:531,y:728,t:1527030392421};\\\", \\\"{x:530,y:727,t:1527030392437};\\\", \\\"{x:528,y:726,t:1527030392454};\\\", \\\"{x:527,y:725,t:1527030392476};\\\", \\\"{x:526,y:724,t:1527030392492};\\\", \\\"{x:525,y:724,t:1527030392504};\\\", \\\"{x:522,y:723,t:1527030392558};\\\", \\\"{x:521,y:723,t:1527030392596};\\\", \\\"{x:520,y:723,t:1527030392627};\\\" ] }, { \\\"rt\\\": 12568, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 350669, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:721,t:1527030392726};\\\", \\\"{x:518,y:719,t:1527030393260};\\\", \\\"{x:517,y:718,t:1527030393272};\\\", \\\"{x:516,y:717,t:1527030393348};\\\", \\\"{x:516,y:715,t:1527030393355};\\\", \\\"{x:516,y:710,t:1527030393372};\\\", \\\"{x:514,y:704,t:1527030393388};\\\", \\\"{x:512,y:699,t:1527030393405};\\\", \\\"{x:508,y:691,t:1527030393422};\\\", \\\"{x:507,y:687,t:1527030393438};\\\", \\\"{x:506,y:684,t:1527030393455};\\\", \\\"{x:505,y:683,t:1527030393472};\\\", \\\"{x:504,y:682,t:1527030393488};\\\", \\\"{x:504,y:679,t:1527030393505};\\\", \\\"{x:504,y:674,t:1527030393522};\\\", \\\"{x:503,y:665,t:1527030393538};\\\", \\\"{x:498,y:651,t:1527030393555};\\\", \\\"{x:490,y:628,t:1527030393572};\\\", \\\"{x:487,y:620,t:1527030393587};\\\", \\\"{x:487,y:617,t:1527030393605};\\\", \\\"{x:487,y:614,t:1527030393621};\\\", \\\"{x:487,y:612,t:1527030393639};\\\", \\\"{x:487,y:606,t:1527030393655};\\\", \\\"{x:491,y:595,t:1527030393672};\\\", \\\"{x:494,y:581,t:1527030393690};\\\", \\\"{x:495,y:565,t:1527030393705};\\\", \\\"{x:497,y:552,t:1527030393721};\\\", \\\"{x:501,y:544,t:1527030393740};\\\", \\\"{x:501,y:537,t:1527030393755};\\\", \\\"{x:504,y:529,t:1527030393773};\\\", \\\"{x:505,y:522,t:1527030393789};\\\", \\\"{x:508,y:518,t:1527030393805};\\\", \\\"{x:508,y:515,t:1527030393822};\\\", \\\"{x:508,y:514,t:1527030393838};\\\", \\\"{x:509,y:512,t:1527030393855};\\\", \\\"{x:509,y:509,t:1527030393872};\\\", \\\"{x:509,y:505,t:1527030393889};\\\", \\\"{x:509,y:500,t:1527030393904};\\\", \\\"{x:509,y:497,t:1527030393922};\\\", \\\"{x:509,y:495,t:1527030393939};\\\", \\\"{x:509,y:494,t:1527030393956};\\\", \\\"{x:509,y:493,t:1527030394013};\\\", \\\"{x:509,y:492,t:1527030394028};\\\", \\\"{x:509,y:491,t:1527030394044};\\\", \\\"{x:509,y:490,t:1527030394061};\\\", \\\"{x:508,y:489,t:1527030394084};\\\", \\\"{x:507,y:488,t:1527030394092};\\\", \\\"{x:506,y:487,t:1527030394106};\\\", \\\"{x:503,y:487,t:1527030394123};\\\", \\\"{x:497,y:483,t:1527030394139};\\\", \\\"{x:489,y:479,t:1527030394156};\\\", \\\"{x:487,y:479,t:1527030394173};\\\", \\\"{x:486,y:478,t:1527030394189};\\\", \\\"{x:486,y:477,t:1527030394501};\\\", \\\"{x:486,y:476,t:1527030394508};\\\", \\\"{x:487,y:476,t:1527030394524};\\\", \\\"{x:497,y:473,t:1527030394540};\\\", \\\"{x:516,y:473,t:1527030394558};\\\", \\\"{x:535,y:473,t:1527030394573};\\\", \\\"{x:550,y:473,t:1527030394589};\\\", \\\"{x:570,y:473,t:1527030394607};\\\", \\\"{x:585,y:474,t:1527030394624};\\\", \\\"{x:599,y:475,t:1527030394640};\\\", \\\"{x:612,y:478,t:1527030394657};\\\", \\\"{x:630,y:478,t:1527030394674};\\\", \\\"{x:653,y:478,t:1527030394691};\\\", \\\"{x:670,y:478,t:1527030394707};\\\", \\\"{x:687,y:478,t:1527030394724};\\\", \\\"{x:689,y:478,t:1527030394740};\\\", \\\"{x:690,y:478,t:1527030394843};\\\", \\\"{x:691,y:478,t:1527030394860};\\\", \\\"{x:690,y:478,t:1527030395012};\\\", \\\"{x:688,y:478,t:1527030395024};\\\", \\\"{x:696,y:478,t:1527030395213};\\\", \\\"{x:701,y:478,t:1527030395225};\\\", \\\"{x:706,y:478,t:1527030395242};\\\", \\\"{x:710,y:478,t:1527030395258};\\\", \\\"{x:714,y:478,t:1527030395275};\\\", \\\"{x:723,y:484,t:1527030395292};\\\", \\\"{x:739,y:498,t:1527030395308};\\\", \\\"{x:778,y:526,t:1527030395325};\\\", \\\"{x:846,y:567,t:1527030395343};\\\", \\\"{x:939,y:615,t:1527030395358};\\\", \\\"{x:1040,y:658,t:1527030395373};\\\", \\\"{x:1129,y:695,t:1527030395390};\\\", \\\"{x:1200,y:722,t:1527030395407};\\\", \\\"{x:1236,y:737,t:1527030395423};\\\", \\\"{x:1253,y:745,t:1527030395440};\\\", \\\"{x:1262,y:749,t:1527030395457};\\\", \\\"{x:1280,y:756,t:1527030395473};\\\", \\\"{x:1302,y:761,t:1527030395490};\\\", \\\"{x:1320,y:764,t:1527030395507};\\\", \\\"{x:1333,y:767,t:1527030395523};\\\", \\\"{x:1339,y:767,t:1527030395539};\\\", \\\"{x:1341,y:767,t:1527030395558};\\\", \\\"{x:1342,y:768,t:1527030395573};\\\", \\\"{x:1344,y:768,t:1527030395628};\\\", \\\"{x:1345,y:768,t:1527030395644};\\\", \\\"{x:1347,y:770,t:1527030395657};\\\", \\\"{x:1348,y:771,t:1527030395672};\\\", \\\"{x:1349,y:771,t:1527030395690};\\\", \\\"{x:1350,y:774,t:1527030395707};\\\", \\\"{x:1350,y:780,t:1527030395723};\\\", \\\"{x:1350,y:795,t:1527030395739};\\\", \\\"{x:1348,y:808,t:1527030395757};\\\", \\\"{x:1344,y:820,t:1527030395773};\\\", \\\"{x:1340,y:829,t:1527030395790};\\\", \\\"{x:1337,y:837,t:1527030395807};\\\", \\\"{x:1335,y:841,t:1527030395823};\\\", \\\"{x:1331,y:846,t:1527030395840};\\\", \\\"{x:1329,y:848,t:1527030395857};\\\", \\\"{x:1327,y:849,t:1527030395874};\\\", \\\"{x:1326,y:849,t:1527030395890};\\\", \\\"{x:1323,y:849,t:1527030395907};\\\", \\\"{x:1319,y:849,t:1527030395924};\\\", \\\"{x:1316,y:849,t:1527030395939};\\\", \\\"{x:1314,y:849,t:1527030395957};\\\", \\\"{x:1313,y:851,t:1527030395974};\\\", \\\"{x:1311,y:852,t:1527030395990};\\\", \\\"{x:1308,y:855,t:1527030396007};\\\", \\\"{x:1303,y:859,t:1527030396024};\\\", \\\"{x:1297,y:865,t:1527030396040};\\\", \\\"{x:1291,y:871,t:1527030396058};\\\", \\\"{x:1285,y:876,t:1527030396074};\\\", \\\"{x:1279,y:881,t:1527030396090};\\\", \\\"{x:1272,y:885,t:1527030396107};\\\", \\\"{x:1266,y:886,t:1527030396124};\\\", \\\"{x:1259,y:888,t:1527030396140};\\\", \\\"{x:1251,y:889,t:1527030396158};\\\", \\\"{x:1238,y:890,t:1527030396175};\\\", \\\"{x:1223,y:890,t:1527030396190};\\\", \\\"{x:1204,y:890,t:1527030396207};\\\", \\\"{x:1184,y:886,t:1527030396224};\\\", \\\"{x:1170,y:883,t:1527030396240};\\\", \\\"{x:1166,y:883,t:1527030396258};\\\", \\\"{x:1162,y:883,t:1527030396274};\\\", \\\"{x:1158,y:883,t:1527030396291};\\\", \\\"{x:1153,y:883,t:1527030396308};\\\", \\\"{x:1148,y:884,t:1527030396324};\\\", \\\"{x:1144,y:886,t:1527030396341};\\\", \\\"{x:1142,y:886,t:1527030396357};\\\", \\\"{x:1141,y:886,t:1527030396374};\\\", \\\"{x:1140,y:886,t:1527030396435};\\\", \\\"{x:1141,y:884,t:1527030396443};\\\", \\\"{x:1142,y:880,t:1527030396457};\\\", \\\"{x:1145,y:874,t:1527030396474};\\\", \\\"{x:1152,y:865,t:1527030396491};\\\", \\\"{x:1155,y:861,t:1527030396507};\\\", \\\"{x:1161,y:856,t:1527030396524};\\\", \\\"{x:1168,y:851,t:1527030396541};\\\", \\\"{x:1172,y:848,t:1527030396557};\\\", \\\"{x:1176,y:845,t:1527030396574};\\\", \\\"{x:1181,y:841,t:1527030396591};\\\", \\\"{x:1184,y:839,t:1527030396607};\\\", \\\"{x:1185,y:837,t:1527030396624};\\\", \\\"{x:1186,y:837,t:1527030396660};\\\", \\\"{x:1187,y:836,t:1527030396683};\\\", \\\"{x:1188,y:834,t:1527030396691};\\\", \\\"{x:1189,y:833,t:1527030396708};\\\", \\\"{x:1192,y:830,t:1527030396725};\\\", \\\"{x:1195,y:829,t:1527030396845};\\\", \\\"{x:1198,y:829,t:1527030396909};\\\", \\\"{x:1204,y:832,t:1527030396925};\\\", \\\"{x:1222,y:842,t:1527030396942};\\\", \\\"{x:1246,y:854,t:1527030396960};\\\", \\\"{x:1266,y:859,t:1527030396974};\\\", \\\"{x:1274,y:861,t:1527030396992};\\\", \\\"{x:1278,y:863,t:1527030397009};\\\", \\\"{x:1278,y:867,t:1527030397025};\\\", \\\"{x:1280,y:881,t:1527030397042};\\\", \\\"{x:1289,y:901,t:1527030397059};\\\", \\\"{x:1299,y:923,t:1527030397075};\\\", \\\"{x:1306,y:939,t:1527030397091};\\\", \\\"{x:1315,y:953,t:1527030397108};\\\", \\\"{x:1316,y:956,t:1527030397124};\\\", \\\"{x:1316,y:958,t:1527030397141};\\\", \\\"{x:1316,y:959,t:1527030397180};\\\", \\\"{x:1316,y:961,t:1527030397196};\\\", \\\"{x:1316,y:963,t:1527030397209};\\\", \\\"{x:1318,y:966,t:1527030397225};\\\", \\\"{x:1319,y:969,t:1527030397241};\\\", \\\"{x:1319,y:970,t:1527030397469};\\\", \\\"{x:1318,y:970,t:1527030397484};\\\", \\\"{x:1314,y:969,t:1527030397492};\\\", \\\"{x:1311,y:968,t:1527030397508};\\\", \\\"{x:1302,y:963,t:1527030397526};\\\", \\\"{x:1293,y:958,t:1527030397542};\\\", \\\"{x:1285,y:954,t:1527030397559};\\\", \\\"{x:1279,y:950,t:1527030397575};\\\", \\\"{x:1278,y:949,t:1527030397592};\\\", \\\"{x:1276,y:949,t:1527030397608};\\\", \\\"{x:1276,y:948,t:1527030397625};\\\", \\\"{x:1275,y:947,t:1527030397641};\\\", \\\"{x:1275,y:945,t:1527030397658};\\\", \\\"{x:1273,y:942,t:1527030397676};\\\", \\\"{x:1271,y:939,t:1527030397692};\\\", \\\"{x:1266,y:935,t:1527030397708};\\\", \\\"{x:1263,y:932,t:1527030397726};\\\", \\\"{x:1261,y:930,t:1527030397741};\\\", \\\"{x:1261,y:929,t:1527030397760};\\\", \\\"{x:1259,y:929,t:1527030397775};\\\", \\\"{x:1259,y:928,t:1527030397792};\\\", \\\"{x:1259,y:927,t:1527030397808};\\\", \\\"{x:1258,y:925,t:1527030397828};\\\", \\\"{x:1258,y:922,t:1527030400237};\\\", \\\"{x:1257,y:915,t:1527030400245};\\\", \\\"{x:1263,y:899,t:1527030400260};\\\", \\\"{x:1291,y:869,t:1527030400278};\\\", \\\"{x:1313,y:848,t:1527030400294};\\\", \\\"{x:1317,y:845,t:1527030400310};\\\", \\\"{x:1316,y:843,t:1527030400332};\\\", \\\"{x:1314,y:840,t:1527030400344};\\\", \\\"{x:1312,y:838,t:1527030400360};\\\", \\\"{x:1311,y:838,t:1527030400500};\\\", \\\"{x:1310,y:838,t:1527030400510};\\\", \\\"{x:1305,y:838,t:1527030400527};\\\", \\\"{x:1300,y:838,t:1527030400543};\\\", \\\"{x:1299,y:838,t:1527030400560};\\\", \\\"{x:1297,y:838,t:1527030400577};\\\", \\\"{x:1296,y:838,t:1527030400594};\\\", \\\"{x:1296,y:839,t:1527030400610};\\\", \\\"{x:1295,y:839,t:1527030400627};\\\", \\\"{x:1290,y:841,t:1527030400644};\\\", \\\"{x:1289,y:842,t:1527030400660};\\\", \\\"{x:1288,y:842,t:1527030400678};\\\", \\\"{x:1287,y:844,t:1527030400757};\\\", \\\"{x:1287,y:845,t:1527030400765};\\\", \\\"{x:1287,y:846,t:1527030400777};\\\", \\\"{x:1287,y:849,t:1527030400794};\\\", \\\"{x:1287,y:852,t:1527030400810};\\\", \\\"{x:1287,y:853,t:1527030400827};\\\", \\\"{x:1287,y:855,t:1527030400843};\\\", \\\"{x:1290,y:860,t:1527030400860};\\\", \\\"{x:1296,y:871,t:1527030400877};\\\", \\\"{x:1301,y:879,t:1527030400894};\\\", \\\"{x:1303,y:883,t:1527030400910};\\\", \\\"{x:1305,y:886,t:1527030400927};\\\", \\\"{x:1305,y:889,t:1527030400944};\\\", \\\"{x:1307,y:891,t:1527030400960};\\\", \\\"{x:1307,y:895,t:1527030400977};\\\", \\\"{x:1307,y:901,t:1527030400994};\\\", \\\"{x:1307,y:908,t:1527030401010};\\\", \\\"{x:1307,y:912,t:1527030401027};\\\", \\\"{x:1307,y:915,t:1527030401045};\\\", \\\"{x:1307,y:917,t:1527030401084};\\\", \\\"{x:1307,y:919,t:1527030401095};\\\", \\\"{x:1307,y:927,t:1527030401110};\\\", \\\"{x:1307,y:934,t:1527030401128};\\\", \\\"{x:1307,y:937,t:1527030401144};\\\", \\\"{x:1307,y:938,t:1527030401162};\\\", \\\"{x:1307,y:939,t:1527030401204};\\\", \\\"{x:1307,y:941,t:1527030401213};\\\", \\\"{x:1307,y:946,t:1527030401228};\\\", \\\"{x:1307,y:959,t:1527030401244};\\\", \\\"{x:1308,y:962,t:1527030401261};\\\", \\\"{x:1308,y:963,t:1527030401278};\\\", \\\"{x:1306,y:963,t:1527030401476};\\\", \\\"{x:1295,y:960,t:1527030401495};\\\", \\\"{x:1286,y:955,t:1527030401511};\\\", \\\"{x:1281,y:952,t:1527030401528};\\\", \\\"{x:1278,y:951,t:1527030401544};\\\", \\\"{x:1277,y:951,t:1527030401562};\\\", \\\"{x:1275,y:950,t:1527030401578};\\\", \\\"{x:1274,y:950,t:1527030401676};\\\", \\\"{x:1272,y:948,t:1527030401684};\\\", \\\"{x:1269,y:946,t:1527030401695};\\\", \\\"{x:1265,y:942,t:1527030401712};\\\", \\\"{x:1260,y:937,t:1527030401728};\\\", \\\"{x:1253,y:932,t:1527030401745};\\\", \\\"{x:1247,y:927,t:1527030401762};\\\", \\\"{x:1240,y:919,t:1527030401778};\\\", \\\"{x:1235,y:915,t:1527030401795};\\\", \\\"{x:1235,y:914,t:1527030401949};\\\", \\\"{x:1235,y:911,t:1527030401961};\\\", \\\"{x:1235,y:910,t:1527030401978};\\\", \\\"{x:1235,y:908,t:1527030401995};\\\", \\\"{x:1235,y:904,t:1527030402012};\\\", \\\"{x:1235,y:898,t:1527030402029};\\\", \\\"{x:1235,y:893,t:1527030402044};\\\", \\\"{x:1235,y:891,t:1527030402062};\\\", \\\"{x:1235,y:889,t:1527030402079};\\\", \\\"{x:1236,y:887,t:1527030402095};\\\", \\\"{x:1236,y:891,t:1527030402172};\\\", \\\"{x:1240,y:898,t:1527030402180};\\\", \\\"{x:1247,y:908,t:1527030402195};\\\", \\\"{x:1260,y:927,t:1527030402212};\\\", \\\"{x:1290,y:962,t:1527030402228};\\\", \\\"{x:1315,y:990,t:1527030402246};\\\", \\\"{x:1341,y:1017,t:1527030402261};\\\", \\\"{x:1350,y:1028,t:1527030402279};\\\", \\\"{x:1351,y:1029,t:1527030402296};\\\", \\\"{x:1351,y:1026,t:1527030402364};\\\", \\\"{x:1351,y:1023,t:1527030402378};\\\", \\\"{x:1340,y:1004,t:1527030402396};\\\", \\\"{x:1331,y:998,t:1527030402411};\\\", \\\"{x:1318,y:988,t:1527030402429};\\\", \\\"{x:1298,y:976,t:1527030402445};\\\", \\\"{x:1272,y:960,t:1527030402461};\\\", \\\"{x:1251,y:947,t:1527030402478};\\\", \\\"{x:1243,y:938,t:1527030402496};\\\", \\\"{x:1240,y:926,t:1527030402512};\\\", \\\"{x:1238,y:911,t:1527030402529};\\\", \\\"{x:1238,y:900,t:1527030402545};\\\", \\\"{x:1238,y:891,t:1527030402561};\\\", \\\"{x:1238,y:890,t:1527030402578};\\\", \\\"{x:1239,y:890,t:1527030402612};\\\", \\\"{x:1240,y:889,t:1527030402629};\\\", \\\"{x:1247,y:884,t:1527030402645};\\\", \\\"{x:1272,y:864,t:1527030402662};\\\", \\\"{x:1322,y:819,t:1527030402679};\\\", \\\"{x:1365,y:757,t:1527030402696};\\\", \\\"{x:1419,y:682,t:1527030402712};\\\", \\\"{x:1474,y:616,t:1527030402729};\\\", \\\"{x:1526,y:560,t:1527030402746};\\\", \\\"{x:1580,y:520,t:1527030402762};\\\", \\\"{x:1619,y:493,t:1527030402779};\\\", \\\"{x:1660,y:463,t:1527030402795};\\\", \\\"{x:1673,y:455,t:1527030402812};\\\", \\\"{x:1678,y:450,t:1527030402829};\\\", \\\"{x:1678,y:449,t:1527030402846};\\\", \\\"{x:1677,y:448,t:1527030402972};\\\", \\\"{x:1669,y:449,t:1527030402979};\\\", \\\"{x:1647,y:458,t:1527030402995};\\\", \\\"{x:1628,y:467,t:1527030403012};\\\", \\\"{x:1614,y:473,t:1527030403029};\\\", \\\"{x:1606,y:477,t:1527030403046};\\\", \\\"{x:1596,y:481,t:1527030403063};\\\", \\\"{x:1583,y:487,t:1527030403080};\\\", \\\"{x:1564,y:489,t:1527030403096};\\\", \\\"{x:1548,y:489,t:1527030403113};\\\", \\\"{x:1522,y:479,t:1527030403129};\\\", \\\"{x:1476,y:462,t:1527030403146};\\\", \\\"{x:1395,y:436,t:1527030403163};\\\", \\\"{x:1232,y:391,t:1527030403180};\\\", \\\"{x:1103,y:359,t:1527030403196};\\\", \\\"{x:947,y:326,t:1527030403212};\\\", \\\"{x:742,y:296,t:1527030403230};\\\", \\\"{x:581,y:287,t:1527030403245};\\\", \\\"{x:492,y:287,t:1527030403263};\\\", \\\"{x:474,y:287,t:1527030403279};\\\", \\\"{x:473,y:287,t:1527030403295};\\\", \\\"{x:473,y:289,t:1527030403349};\\\", \\\"{x:474,y:291,t:1527030403362};\\\", \\\"{x:475,y:298,t:1527030403380};\\\", \\\"{x:481,y:318,t:1527030403395};\\\", \\\"{x:488,y:333,t:1527030403413};\\\", \\\"{x:494,y:345,t:1527030403430};\\\", \\\"{x:497,y:357,t:1527030403445};\\\", \\\"{x:501,y:366,t:1527030403463};\\\", \\\"{x:505,y:377,t:1527030403479};\\\", \\\"{x:506,y:387,t:1527030403496};\\\", \\\"{x:506,y:392,t:1527030403513};\\\", \\\"{x:502,y:399,t:1527030403530};\\\", \\\"{x:494,y:405,t:1527030403547};\\\", \\\"{x:481,y:413,t:1527030403562};\\\", \\\"{x:473,y:420,t:1527030403580};\\\", \\\"{x:462,y:437,t:1527030403596};\\\", \\\"{x:455,y:449,t:1527030403612};\\\", \\\"{x:449,y:464,t:1527030403630};\\\", \\\"{x:439,y:478,t:1527030403647};\\\", \\\"{x:432,y:485,t:1527030403662};\\\", \\\"{x:425,y:490,t:1527030403680};\\\", \\\"{x:421,y:494,t:1527030403697};\\\", \\\"{x:420,y:500,t:1527030403712};\\\", \\\"{x:419,y:503,t:1527030403729};\\\", \\\"{x:419,y:504,t:1527030403747};\\\", \\\"{x:419,y:505,t:1527030403772};\\\", \\\"{x:419,y:507,t:1527030403781};\\\", \\\"{x:419,y:515,t:1527030403796};\\\", \\\"{x:419,y:521,t:1527030403813};\\\", \\\"{x:422,y:527,t:1527030403830};\\\", \\\"{x:422,y:532,t:1527030403846};\\\", \\\"{x:422,y:533,t:1527030403863};\\\", \\\"{x:422,y:538,t:1527030403880};\\\", \\\"{x:420,y:545,t:1527030403898};\\\", \\\"{x:415,y:556,t:1527030403914};\\\", \\\"{x:411,y:561,t:1527030403931};\\\", \\\"{x:410,y:563,t:1527030403946};\\\", \\\"{x:409,y:564,t:1527030404035};\\\", \\\"{x:408,y:564,t:1527030404116};\\\", \\\"{x:408,y:563,t:1527030404131};\\\", \\\"{x:407,y:563,t:1527030404148};\\\", \\\"{x:407,y:564,t:1527030404452};\\\", \\\"{x:407,y:567,t:1527030404463};\\\", \\\"{x:407,y:576,t:1527030404480};\\\", \\\"{x:410,y:588,t:1527030404497};\\\", \\\"{x:424,y:614,t:1527030404514};\\\", \\\"{x:438,y:641,t:1527030404531};\\\", \\\"{x:451,y:669,t:1527030404547};\\\", \\\"{x:453,y:675,t:1527030404564};\\\", \\\"{x:453,y:679,t:1527030404580};\\\", \\\"{x:454,y:682,t:1527030404597};\\\", \\\"{x:456,y:683,t:1527030404614};\\\", \\\"{x:457,y:683,t:1527030404630};\\\", \\\"{x:458,y:684,t:1527030404647};\\\", \\\"{x:461,y:687,t:1527030404664};\\\", \\\"{x:465,y:693,t:1527030404680};\\\", \\\"{x:466,y:695,t:1527030404698};\\\", \\\"{x:467,y:697,t:1527030404714};\\\", \\\"{x:468,y:699,t:1527030404821};\\\", \\\"{x:469,y:699,t:1527030404830};\\\", \\\"{x:471,y:701,t:1527030404849};\\\", \\\"{x:474,y:703,t:1527030404891};\\\", \\\"{x:475,y:705,t:1527030404899};\\\", \\\"{x:478,y:709,t:1527030404914};\\\", \\\"{x:481,y:714,t:1527030404932};\\\", \\\"{x:483,y:717,t:1527030404948};\\\", \\\"{x:485,y:718,t:1527030404964};\\\", \\\"{x:486,y:718,t:1527030405700};\\\", \\\"{x:486,y:716,t:1527030405716};\\\", \\\"{x:486,y:713,t:1527030405731};\\\", \\\"{x:486,y:707,t:1527030405748};\\\", \\\"{x:486,y:703,t:1527030405765};\\\", \\\"{x:486,y:702,t:1527030405781};\\\", \\\"{x:486,y:701,t:1527030405798};\\\", \\\"{x:486,y:699,t:1527030405815};\\\", \\\"{x:487,y:697,t:1527030405831};\\\", \\\"{x:487,y:694,t:1527030405848};\\\", \\\"{x:487,y:692,t:1527030405866};\\\", \\\"{x:487,y:690,t:1527030405881};\\\", \\\"{x:487,y:689,t:1527030405899};\\\", \\\"{x:487,y:688,t:1527030406044};\\\", \\\"{x:487,y:687,t:1527030406052};\\\", \\\"{x:487,y:686,t:1527030406065};\\\", \\\"{x:487,y:684,t:1527030406082};\\\", \\\"{x:487,y:682,t:1527030406098};\\\", \\\"{x:487,y:681,t:1527030406115};\\\", \\\"{x:487,y:680,t:1527030406133};\\\", \\\"{x:487,y:678,t:1527030406148};\\\", \\\"{x:487,y:677,t:1527030406165};\\\", \\\"{x:486,y:676,t:1527030406183};\\\", \\\"{x:486,y:674,t:1527030406199};\\\", \\\"{x:485,y:672,t:1527030406220};\\\", \\\"{x:485,y:670,t:1527030406236};\\\", \\\"{x:484,y:670,t:1527030406248};\\\", \\\"{x:483,y:668,t:1527030406266};\\\", \\\"{x:482,y:667,t:1527030406283};\\\", \\\"{x:481,y:667,t:1527030406322};\\\", \\\"{x:480,y:667,t:1527030406363};\\\" ] }, { \\\"rt\\\": 9402, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 361272, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:667,t:1527030406491};\\\", \\\"{x:476,y:667,t:1527030406539};\\\", \\\"{x:475,y:667,t:1527030406548};\\\", \\\"{x:474,y:666,t:1527030406572};\\\", \\\"{x:475,y:667,t:1527030407131};\\\", \\\"{x:478,y:669,t:1527030407139};\\\", \\\"{x:482,y:673,t:1527030407149};\\\", \\\"{x:528,y:699,t:1527030407166};\\\", \\\"{x:636,y:750,t:1527030407182};\\\", \\\"{x:779,y:812,t:1527030407199};\\\", \\\"{x:978,y:898,t:1527030407217};\\\", \\\"{x:1176,y:987,t:1527030407233};\\\", \\\"{x:1341,y:1023,t:1527030407250};\\\", \\\"{x:1439,y:1031,t:1527030407267};\\\", \\\"{x:1491,y:1029,t:1527030407283};\\\", \\\"{x:1514,y:1021,t:1527030407300};\\\", \\\"{x:1516,y:1020,t:1527030407317};\\\", \\\"{x:1516,y:1013,t:1527030407332};\\\", \\\"{x:1509,y:999,t:1527030407349};\\\", \\\"{x:1498,y:987,t:1527030407367};\\\", \\\"{x:1483,y:973,t:1527030407383};\\\", \\\"{x:1464,y:961,t:1527030407400};\\\", \\\"{x:1451,y:954,t:1527030407417};\\\", \\\"{x:1438,y:948,t:1527030407432};\\\", \\\"{x:1433,y:946,t:1527030407450};\\\", \\\"{x:1431,y:945,t:1527030407580};\\\", \\\"{x:1430,y:944,t:1527030407588};\\\", \\\"{x:1424,y:942,t:1527030407601};\\\", \\\"{x:1406,y:936,t:1527030407617};\\\", \\\"{x:1380,y:928,t:1527030407634};\\\", \\\"{x:1350,y:921,t:1527030407650};\\\", \\\"{x:1308,y:915,t:1527030407667};\\\", \\\"{x:1223,y:904,t:1527030407684};\\\", \\\"{x:1173,y:896,t:1527030407701};\\\", \\\"{x:1140,y:890,t:1527030407718};\\\", \\\"{x:1118,y:886,t:1527030407734};\\\", \\\"{x:1105,y:884,t:1527030407750};\\\", \\\"{x:1100,y:884,t:1527030407767};\\\", \\\"{x:1100,y:883,t:1527030407784};\\\", \\\"{x:1101,y:881,t:1527030407812};\\\", \\\"{x:1104,y:879,t:1527030407820};\\\", \\\"{x:1110,y:876,t:1527030407834};\\\", \\\"{x:1126,y:868,t:1527030407850};\\\", \\\"{x:1145,y:858,t:1527030407867};\\\", \\\"{x:1174,y:846,t:1527030407884};\\\", \\\"{x:1188,y:842,t:1527030407900};\\\", \\\"{x:1199,y:840,t:1527030407917};\\\", \\\"{x:1203,y:840,t:1527030407934};\\\", \\\"{x:1208,y:840,t:1527030407950};\\\", \\\"{x:1226,y:846,t:1527030407967};\\\", \\\"{x:1256,y:859,t:1527030407984};\\\", \\\"{x:1286,y:872,t:1527030408001};\\\", \\\"{x:1316,y:886,t:1527030408017};\\\", \\\"{x:1335,y:897,t:1527030408034};\\\", \\\"{x:1346,y:906,t:1527030408051};\\\", \\\"{x:1351,y:917,t:1527030408067};\\\", \\\"{x:1355,y:937,t:1527030408084};\\\", \\\"{x:1355,y:939,t:1527030408101};\\\", \\\"{x:1356,y:939,t:1527030408148};\\\", \\\"{x:1357,y:939,t:1527030408156};\\\", \\\"{x:1358,y:939,t:1527030408167};\\\", \\\"{x:1360,y:939,t:1527030408184};\\\", \\\"{x:1363,y:938,t:1527030408202};\\\", \\\"{x:1367,y:934,t:1527030408217};\\\", \\\"{x:1374,y:924,t:1527030408234};\\\", \\\"{x:1385,y:905,t:1527030408251};\\\", \\\"{x:1397,y:886,t:1527030408267};\\\", \\\"{x:1423,y:854,t:1527030408284};\\\", \\\"{x:1437,y:839,t:1527030408301};\\\", \\\"{x:1450,y:824,t:1527030408317};\\\", \\\"{x:1465,y:805,t:1527030408334};\\\", \\\"{x:1479,y:792,t:1527030408350};\\\", \\\"{x:1492,y:782,t:1527030408366};\\\", \\\"{x:1499,y:777,t:1527030408383};\\\", \\\"{x:1503,y:774,t:1527030408401};\\\", \\\"{x:1505,y:772,t:1527030408417};\\\", \\\"{x:1505,y:771,t:1527030408433};\\\", \\\"{x:1504,y:770,t:1527030408484};\\\", \\\"{x:1502,y:770,t:1527030408501};\\\", \\\"{x:1500,y:769,t:1527030408518};\\\", \\\"{x:1499,y:767,t:1527030408534};\\\", \\\"{x:1496,y:764,t:1527030408551};\\\", \\\"{x:1490,y:759,t:1527030408568};\\\", \\\"{x:1486,y:756,t:1527030408584};\\\", \\\"{x:1485,y:755,t:1527030408601};\\\", \\\"{x:1484,y:754,t:1527030408618};\\\", \\\"{x:1484,y:751,t:1527030408634};\\\", \\\"{x:1483,y:747,t:1527030408651};\\\", \\\"{x:1481,y:744,t:1527030408668};\\\", \\\"{x:1480,y:742,t:1527030408684};\\\", \\\"{x:1480,y:741,t:1527030408701};\\\", \\\"{x:1479,y:741,t:1527030408718};\\\", \\\"{x:1478,y:740,t:1527030408734};\\\", \\\"{x:1477,y:740,t:1527030408751};\\\", \\\"{x:1475,y:740,t:1527030408769};\\\", \\\"{x:1461,y:729,t:1527030409109};\\\", \\\"{x:1428,y:720,t:1527030409118};\\\", \\\"{x:1359,y:713,t:1527030409135};\\\", \\\"{x:1270,y:713,t:1527030409151};\\\", \\\"{x:1173,y:713,t:1527030409168};\\\", \\\"{x:1090,y:713,t:1527030409185};\\\", \\\"{x:1044,y:712,t:1527030409201};\\\", \\\"{x:1002,y:706,t:1527030409218};\\\", \\\"{x:943,y:705,t:1527030409236};\\\", \\\"{x:870,y:701,t:1527030409251};\\\", \\\"{x:761,y:701,t:1527030409268};\\\", \\\"{x:700,y:701,t:1527030409285};\\\", \\\"{x:636,y:693,t:1527030409301};\\\", \\\"{x:593,y:686,t:1527030409318};\\\", \\\"{x:563,y:680,t:1527030409336};\\\", \\\"{x:538,y:670,t:1527030409352};\\\", \\\"{x:516,y:666,t:1527030409368};\\\", \\\"{x:502,y:663,t:1527030409385};\\\", \\\"{x:495,y:660,t:1527030409402};\\\", \\\"{x:494,y:660,t:1527030409418};\\\", \\\"{x:494,y:658,t:1527030409444};\\\", \\\"{x:494,y:656,t:1527030409452};\\\", \\\"{x:494,y:649,t:1527030409470};\\\", \\\"{x:491,y:643,t:1527030409484};\\\", \\\"{x:488,y:631,t:1527030409501};\\\", \\\"{x:485,y:618,t:1527030409518};\\\", \\\"{x:484,y:607,t:1527030409535};\\\", \\\"{x:485,y:593,t:1527030409552};\\\", \\\"{x:488,y:580,t:1527030409568};\\\", \\\"{x:490,y:567,t:1527030409585};\\\", \\\"{x:490,y:562,t:1527030409601};\\\", \\\"{x:491,y:557,t:1527030409618};\\\", \\\"{x:491,y:555,t:1527030409634};\\\", \\\"{x:491,y:553,t:1527030409651};\\\", \\\"{x:491,y:551,t:1527030409669};\\\", \\\"{x:491,y:549,t:1527030409684};\\\", \\\"{x:491,y:546,t:1527030409701};\\\", \\\"{x:492,y:544,t:1527030409723};\\\", \\\"{x:492,y:543,t:1527030409756};\\\", \\\"{x:492,y:541,t:1527030409787};\\\", \\\"{x:492,y:539,t:1527030409811};\\\", \\\"{x:492,y:538,t:1527030409835};\\\", \\\"{x:492,y:537,t:1527030409851};\\\", \\\"{x:493,y:536,t:1527030409870};\\\", \\\"{x:493,y:535,t:1527030409884};\\\", \\\"{x:493,y:534,t:1527030409932};\\\", \\\"{x:493,y:533,t:1527030409947};\\\", \\\"{x:493,y:531,t:1527030409955};\\\", \\\"{x:494,y:530,t:1527030409971};\\\", \\\"{x:494,y:529,t:1527030409985};\\\", \\\"{x:495,y:528,t:1527030410002};\\\", \\\"{x:497,y:526,t:1527030410018};\\\", \\\"{x:497,y:525,t:1527030410035};\\\", \\\"{x:498,y:524,t:1527030410051};\\\", \\\"{x:500,y:524,t:1527030410071};\\\", \\\"{x:502,y:522,t:1527030410091};\\\", \\\"{x:503,y:522,t:1527030410115};\\\", \\\"{x:504,y:521,t:1527030410131};\\\", \\\"{x:506,y:520,t:1527030410139};\\\", \\\"{x:510,y:519,t:1527030410152};\\\", \\\"{x:532,y:517,t:1527030410169};\\\", \\\"{x:562,y:515,t:1527030410186};\\\", \\\"{x:621,y:515,t:1527030410202};\\\", \\\"{x:707,y:515,t:1527030410219};\\\", \\\"{x:863,y:521,t:1527030410236};\\\", \\\"{x:988,y:535,t:1527030410251};\\\", \\\"{x:1104,y:553,t:1527030410269};\\\", \\\"{x:1231,y:568,t:1527030410286};\\\", \\\"{x:1358,y:598,t:1527030410301};\\\", \\\"{x:1472,y:635,t:1527030410319};\\\", \\\"{x:1568,y:675,t:1527030410336};\\\", \\\"{x:1615,y:695,t:1527030410352};\\\", \\\"{x:1636,y:707,t:1527030410369};\\\", \\\"{x:1645,y:714,t:1527030410386};\\\", \\\"{x:1656,y:721,t:1527030410402};\\\", \\\"{x:1683,y:735,t:1527030410418};\\\", \\\"{x:1734,y:758,t:1527030410435};\\\", \\\"{x:1769,y:778,t:1527030410452};\\\", \\\"{x:1784,y:786,t:1527030410469};\\\", \\\"{x:1790,y:790,t:1527030410486};\\\", \\\"{x:1791,y:792,t:1527030410502};\\\", \\\"{x:1793,y:793,t:1527030410519};\\\", \\\"{x:1793,y:796,t:1527030410536};\\\", \\\"{x:1793,y:802,t:1527030410552};\\\", \\\"{x:1793,y:809,t:1527030410569};\\\", \\\"{x:1793,y:819,t:1527030410585};\\\", \\\"{x:1790,y:831,t:1527030410602};\\\", \\\"{x:1784,y:847,t:1527030410619};\\\", \\\"{x:1769,y:867,t:1527030410636};\\\", \\\"{x:1756,y:880,t:1527030410652};\\\", \\\"{x:1746,y:894,t:1527030410669};\\\", \\\"{x:1735,y:906,t:1527030410686};\\\", \\\"{x:1726,y:920,t:1527030410702};\\\", \\\"{x:1719,y:926,t:1527030410719};\\\", \\\"{x:1712,y:929,t:1527030410736};\\\", \\\"{x:1708,y:930,t:1527030410752};\\\", \\\"{x:1703,y:930,t:1527030410769};\\\", \\\"{x:1702,y:930,t:1527030410786};\\\", \\\"{x:1701,y:930,t:1527030410820};\\\", \\\"{x:1700,y:930,t:1527030410836};\\\", \\\"{x:1699,y:930,t:1527030410852};\\\", \\\"{x:1695,y:930,t:1527030410868};\\\", \\\"{x:1693,y:930,t:1527030410886};\\\", \\\"{x:1688,y:930,t:1527030410902};\\\", \\\"{x:1683,y:932,t:1527030410918};\\\", \\\"{x:1671,y:933,t:1527030410936};\\\", \\\"{x:1650,y:938,t:1527030410952};\\\", \\\"{x:1623,y:943,t:1527030410969};\\\", \\\"{x:1588,y:945,t:1527030410985};\\\", \\\"{x:1558,y:950,t:1527030411001};\\\", \\\"{x:1544,y:952,t:1527030411019};\\\", \\\"{x:1540,y:952,t:1527030411035};\\\", \\\"{x:1540,y:950,t:1527030411108};\\\", \\\"{x:1540,y:947,t:1527030411119};\\\", \\\"{x:1541,y:937,t:1527030411136};\\\", \\\"{x:1547,y:921,t:1527030411152};\\\", \\\"{x:1551,y:907,t:1527030411169};\\\", \\\"{x:1555,y:894,t:1527030411186};\\\", \\\"{x:1558,y:887,t:1527030411202};\\\", \\\"{x:1559,y:884,t:1527030411219};\\\", \\\"{x:1560,y:884,t:1527030411261};\\\", \\\"{x:1561,y:883,t:1527030411276};\\\", \\\"{x:1562,y:883,t:1527030411300};\\\", \\\"{x:1562,y:882,t:1527030411379};\\\", \\\"{x:1562,y:877,t:1527030411387};\\\", \\\"{x:1557,y:870,t:1527030411402};\\\", \\\"{x:1540,y:845,t:1527030411419};\\\", \\\"{x:1492,y:791,t:1527030411435};\\\", \\\"{x:1460,y:766,t:1527030411451};\\\", \\\"{x:1435,y:749,t:1527030411468};\\\", \\\"{x:1417,y:736,t:1527030411485};\\\", \\\"{x:1407,y:729,t:1527030411501};\\\", \\\"{x:1398,y:711,t:1527030411519};\\\", \\\"{x:1384,y:688,t:1527030411536};\\\", \\\"{x:1367,y:662,t:1527030411552};\\\", \\\"{x:1346,y:633,t:1527030411569};\\\", \\\"{x:1335,y:622,t:1527030411585};\\\", \\\"{x:1331,y:614,t:1527030411602};\\\", \\\"{x:1330,y:612,t:1527030411618};\\\", \\\"{x:1330,y:608,t:1527030411636};\\\", \\\"{x:1333,y:603,t:1527030411652};\\\", \\\"{x:1336,y:598,t:1527030411669};\\\", \\\"{x:1338,y:592,t:1527030411686};\\\", \\\"{x:1342,y:587,t:1527030411702};\\\", \\\"{x:1344,y:584,t:1527030411719};\\\", \\\"{x:1345,y:583,t:1527030411736};\\\", \\\"{x:1349,y:580,t:1527030411752};\\\", \\\"{x:1356,y:575,t:1527030411768};\\\", \\\"{x:1364,y:571,t:1527030411785};\\\", \\\"{x:1369,y:567,t:1527030411802};\\\", \\\"{x:1371,y:566,t:1527030411819};\\\", \\\"{x:1372,y:564,t:1527030411836};\\\", \\\"{x:1373,y:564,t:1527030411876};\\\", \\\"{x:1373,y:563,t:1527030411916};\\\", \\\"{x:1373,y:562,t:1527030411940};\\\", \\\"{x:1373,y:561,t:1527030412085};\\\", \\\"{x:1372,y:561,t:1527030412093};\\\", \\\"{x:1369,y:561,t:1527030412103};\\\", \\\"{x:1358,y:565,t:1527030412120};\\\", \\\"{x:1339,y:573,t:1527030412137};\\\", \\\"{x:1313,y:583,t:1527030412152};\\\", \\\"{x:1265,y:597,t:1527030412169};\\\", \\\"{x:1211,y:608,t:1527030412186};\\\", \\\"{x:1158,y:616,t:1527030412202};\\\", \\\"{x:1105,y:624,t:1527030412219};\\\", \\\"{x:1055,y:636,t:1527030412236};\\\", \\\"{x:1027,y:651,t:1527030412252};\\\", \\\"{x:994,y:670,t:1527030412269};\\\", \\\"{x:957,y:691,t:1527030412286};\\\", \\\"{x:939,y:702,t:1527030412302};\\\", \\\"{x:925,y:706,t:1527030412319};\\\", \\\"{x:911,y:710,t:1527030412336};\\\", \\\"{x:897,y:711,t:1527030412352};\\\", \\\"{x:881,y:715,t:1527030412369};\\\", \\\"{x:864,y:717,t:1527030412385};\\\", \\\"{x:846,y:720,t:1527030412402};\\\", \\\"{x:820,y:723,t:1527030412419};\\\", \\\"{x:781,y:727,t:1527030412435};\\\", \\\"{x:752,y:727,t:1527030412452};\\\", \\\"{x:723,y:724,t:1527030412468};\\\", \\\"{x:686,y:714,t:1527030412485};\\\", \\\"{x:642,y:702,t:1527030412501};\\\", \\\"{x:588,y:686,t:1527030412518};\\\", \\\"{x:548,y:679,t:1527030412536};\\\", \\\"{x:523,y:673,t:1527030412552};\\\", \\\"{x:514,y:667,t:1527030412568};\\\", \\\"{x:512,y:661,t:1527030412586};\\\", \\\"{x:510,y:652,t:1527030412602};\\\", \\\"{x:508,y:645,t:1527030412619};\\\", \\\"{x:503,y:641,t:1527030412635};\\\", \\\"{x:501,y:640,t:1527030412652};\\\", \\\"{x:498,y:640,t:1527030412671};\\\", \\\"{x:497,y:639,t:1527030412715};\\\", \\\"{x:495,y:638,t:1527030412723};\\\", \\\"{x:492,y:632,t:1527030412738};\\\", \\\"{x:488,y:628,t:1527030412754};\\\", \\\"{x:479,y:623,t:1527030412771};\\\", \\\"{x:465,y:614,t:1527030412789};\\\", \\\"{x:460,y:613,t:1527030412804};\\\", \\\"{x:456,y:611,t:1527030412821};\\\", \\\"{x:453,y:610,t:1527030412837};\\\", \\\"{x:448,y:606,t:1527030412853};\\\", \\\"{x:443,y:602,t:1527030412870};\\\", \\\"{x:439,y:598,t:1527030412887};\\\", \\\"{x:438,y:597,t:1527030412903};\\\", \\\"{x:437,y:597,t:1527030412932};\\\", \\\"{x:437,y:596,t:1527030412947};\\\", \\\"{x:436,y:596,t:1527030412955};\\\", \\\"{x:435,y:596,t:1527030412971};\\\", \\\"{x:429,y:594,t:1527030412987};\\\", \\\"{x:425,y:594,t:1527030413004};\\\", \\\"{x:423,y:592,t:1527030413021};\\\", \\\"{x:422,y:591,t:1527030413037};\\\", \\\"{x:419,y:588,t:1527030413053};\\\", \\\"{x:416,y:586,t:1527030413071};\\\", \\\"{x:413,y:584,t:1527030413088};\\\", \\\"{x:410,y:582,t:1527030413104};\\\", \\\"{x:407,y:582,t:1527030413120};\\\", \\\"{x:406,y:582,t:1527030413138};\\\", \\\"{x:405,y:582,t:1527030413155};\\\", \\\"{x:400,y:582,t:1527030413171};\\\", \\\"{x:394,y:582,t:1527030413187};\\\", \\\"{x:390,y:582,t:1527030413204};\\\", \\\"{x:387,y:582,t:1527030413220};\\\", \\\"{x:380,y:582,t:1527030413237};\\\", \\\"{x:368,y:582,t:1527030413255};\\\", \\\"{x:353,y:582,t:1527030413271};\\\", \\\"{x:344,y:582,t:1527030413287};\\\", \\\"{x:337,y:581,t:1527030413305};\\\", \\\"{x:332,y:581,t:1527030413320};\\\", \\\"{x:328,y:580,t:1527030413338};\\\", \\\"{x:325,y:580,t:1527030413355};\\\", \\\"{x:321,y:580,t:1527030413372};\\\", \\\"{x:317,y:580,t:1527030413388};\\\", \\\"{x:314,y:580,t:1527030413405};\\\", \\\"{x:310,y:580,t:1527030413422};\\\", \\\"{x:305,y:580,t:1527030413439};\\\", \\\"{x:293,y:583,t:1527030413456};\\\", \\\"{x:270,y:590,t:1527030413474};\\\", \\\"{x:242,y:600,t:1527030413488};\\\", \\\"{x:218,y:609,t:1527030413504};\\\", \\\"{x:203,y:617,t:1527030413521};\\\", \\\"{x:201,y:617,t:1527030413537};\\\", \\\"{x:204,y:617,t:1527030413612};\\\", \\\"{x:212,y:614,t:1527030413621};\\\", \\\"{x:225,y:609,t:1527030413638};\\\", \\\"{x:241,y:604,t:1527030413655};\\\", \\\"{x:280,y:597,t:1527030413672};\\\", \\\"{x:320,y:583,t:1527030413688};\\\", \\\"{x:368,y:569,t:1527030413706};\\\", \\\"{x:415,y:555,t:1527030413722};\\\", \\\"{x:471,y:547,t:1527030413738};\\\", \\\"{x:514,y:546,t:1527030413756};\\\", \\\"{x:587,y:546,t:1527030413771};\\\", \\\"{x:624,y:546,t:1527030413788};\\\", \\\"{x:647,y:549,t:1527030413805};\\\", \\\"{x:662,y:554,t:1527030413822};\\\", \\\"{x:666,y:557,t:1527030413838};\\\", \\\"{x:674,y:562,t:1527030413855};\\\", \\\"{x:678,y:565,t:1527030413872};\\\", \\\"{x:680,y:567,t:1527030413888};\\\", \\\"{x:680,y:569,t:1527030413914};\\\", \\\"{x:679,y:570,t:1527030413931};\\\", \\\"{x:666,y:572,t:1527030413947};\\\", \\\"{x:652,y:574,t:1527030413964};\\\", \\\"{x:648,y:575,t:1527030413983};\\\", \\\"{x:648,y:574,t:1527030414044};\\\", \\\"{x:647,y:573,t:1527030414052};\\\", \\\"{x:646,y:571,t:1527030414064};\\\", \\\"{x:646,y:569,t:1527030414082};\\\", \\\"{x:646,y:568,t:1527030414098};\\\", \\\"{x:646,y:567,t:1527030414164};\\\", \\\"{x:646,y:566,t:1527030414181};\\\", \\\"{x:645,y:565,t:1527030414197};\\\", \\\"{x:643,y:564,t:1527030414278};\\\", \\\"{x:637,y:564,t:1527030414298};\\\", \\\"{x:625,y:564,t:1527030414314};\\\", \\\"{x:619,y:564,t:1527030414331};\\\", \\\"{x:617,y:564,t:1527030414348};\\\", \\\"{x:616,y:564,t:1527030414684};\\\", \\\"{x:612,y:568,t:1527030414698};\\\", \\\"{x:600,y:580,t:1527030414715};\\\", \\\"{x:587,y:599,t:1527030414732};\\\", \\\"{x:585,y:604,t:1527030414747};\\\", \\\"{x:581,y:616,t:1527030414764};\\\", \\\"{x:579,y:621,t:1527030414781};\\\", \\\"{x:577,y:624,t:1527030414797};\\\", \\\"{x:575,y:630,t:1527030414815};\\\", \\\"{x:574,y:635,t:1527030414830};\\\", \\\"{x:571,y:643,t:1527030414848};\\\", \\\"{x:568,y:650,t:1527030414865};\\\", \\\"{x:564,y:658,t:1527030414881};\\\", \\\"{x:561,y:660,t:1527030414898};\\\", \\\"{x:558,y:663,t:1527030414915};\\\", \\\"{x:557,y:664,t:1527030414933};\\\", \\\"{x:556,y:665,t:1527030414948};\\\", \\\"{x:554,y:666,t:1527030414965};\\\", \\\"{x:552,y:669,t:1527030414983};\\\", \\\"{x:552,y:671,t:1527030414998};\\\", \\\"{x:551,y:674,t:1527030415015};\\\", \\\"{x:550,y:675,t:1527030415032};\\\", \\\"{x:549,y:677,t:1527030415048};\\\", \\\"{x:548,y:679,t:1527030415065};\\\", \\\"{x:544,y:685,t:1527030415081};\\\", \\\"{x:542,y:690,t:1527030415097};\\\", \\\"{x:540,y:694,t:1527030415115};\\\", \\\"{x:539,y:696,t:1527030415133};\\\", \\\"{x:539,y:697,t:1527030415213};\\\", \\\"{x:539,y:699,t:1527030415229};\\\", \\\"{x:539,y:700,t:1527030415453};\\\", \\\"{x:539,y:702,t:1527030415466};\\\", \\\"{x:539,y:706,t:1527030415481};\\\", \\\"{x:539,y:709,t:1527030415498};\\\", \\\"{x:539,y:710,t:1527030415515};\\\", \\\"{x:539,y:712,t:1527030415763};\\\", \\\"{x:539,y:712,t:1527030415915};\\\", \\\"{x:538,y:714,t:1527030416229};\\\", \\\"{x:536,y:714,t:1527030416245};\\\", \\\"{x:536,y:715,t:1527030416261};\\\", \\\"{x:536,y:716,t:1527030416268};\\\", \\\"{x:536,y:717,t:1527030416301};\\\", \\\"{x:538,y:718,t:1527030416333};\\\", \\\"{x:546,y:720,t:1527030416348};\\\", \\\"{x:556,y:721,t:1527030416366};\\\", \\\"{x:570,y:722,t:1527030416383};\\\", \\\"{x:582,y:722,t:1527030416399};\\\", \\\"{x:592,y:722,t:1527030416416};\\\", \\\"{x:598,y:722,t:1527030416433};\\\", \\\"{x:600,y:722,t:1527030416448};\\\", \\\"{x:601,y:722,t:1527030416572};\\\", \\\"{x:602,y:722,t:1527030416588};\\\", \\\"{x:602,y:721,t:1527030416612};\\\", \\\"{x:602,y:719,t:1527030416628};\\\", \\\"{x:602,y:718,t:1527030416653};\\\", \\\"{x:602,y:716,t:1527030416725};\\\", \\\"{x:602,y:715,t:1527030416748};\\\" ] }, { \\\"rt\\\": 38958, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 401427, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -02 PM-01 PM-12 PM-I -08 AM-A -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:603,y:714,t:1527030417108};\\\", \\\"{x:604,y:713,t:1527030417119};\\\", \\\"{x:605,y:710,t:1527030417132};\\\", \\\"{x:607,y:706,t:1527030417150};\\\", \\\"{x:608,y:703,t:1527030417166};\\\", \\\"{x:608,y:702,t:1527030417195};\\\", \\\"{x:608,y:701,t:1527030417204};\\\", \\\"{x:608,y:700,t:1527030417217};\\\", \\\"{x:604,y:699,t:1527030417233};\\\", \\\"{x:601,y:698,t:1527030417250};\\\", \\\"{x:600,y:697,t:1527030417266};\\\", \\\"{x:597,y:696,t:1527030417509};\\\", \\\"{x:596,y:694,t:1527030417516};\\\", \\\"{x:594,y:692,t:1527030417534};\\\", \\\"{x:594,y:691,t:1527030417550};\\\", \\\"{x:593,y:690,t:1527030417568};\\\", \\\"{x:591,y:688,t:1527030417585};\\\", \\\"{x:591,y:665,t:1527030417659};\\\", \\\"{x:590,y:661,t:1527030417667};\\\", \\\"{x:587,y:652,t:1527030417684};\\\", \\\"{x:579,y:636,t:1527030417700};\\\", \\\"{x:560,y:614,t:1527030417717};\\\", \\\"{x:552,y:607,t:1527030417733};\\\", \\\"{x:548,y:604,t:1527030417749};\\\", \\\"{x:546,y:603,t:1527030417767};\\\", \\\"{x:544,y:602,t:1527030417783};\\\", \\\"{x:539,y:599,t:1527030417800};\\\", \\\"{x:535,y:597,t:1527030417817};\\\", \\\"{x:526,y:593,t:1527030417834};\\\", \\\"{x:519,y:590,t:1527030417850};\\\", \\\"{x:516,y:589,t:1527030417867};\\\", \\\"{x:514,y:587,t:1527030417884};\\\", \\\"{x:510,y:583,t:1527030417900};\\\", \\\"{x:506,y:577,t:1527030417917};\\\", \\\"{x:499,y:569,t:1527030417933};\\\", \\\"{x:493,y:561,t:1527030417952};\\\", \\\"{x:488,y:557,t:1527030417968};\\\", \\\"{x:485,y:554,t:1527030417984};\\\", \\\"{x:483,y:553,t:1527030418001};\\\", \\\"{x:482,y:553,t:1527030418017};\\\", \\\"{x:480,y:552,t:1527030418044};\\\", \\\"{x:479,y:552,t:1527030418077};\\\", \\\"{x:478,y:551,t:1527030418085};\\\", \\\"{x:477,y:550,t:1527030418100};\\\", \\\"{x:475,y:549,t:1527030418148};\\\", \\\"{x:474,y:548,t:1527030418237};\\\", \\\"{x:472,y:547,t:1527030418250};\\\", \\\"{x:470,y:547,t:1527030418267};\\\", \\\"{x:469,y:546,t:1527030418284};\\\", \\\"{x:467,y:546,t:1527030418309};\\\", \\\"{x:466,y:545,t:1527030418325};\\\", \\\"{x:465,y:545,t:1527030418333};\\\", \\\"{x:464,y:544,t:1527030418350};\\\", \\\"{x:463,y:544,t:1527030418368};\\\", \\\"{x:460,y:543,t:1527030418383};\\\", \\\"{x:452,y:540,t:1527030418400};\\\", \\\"{x:434,y:538,t:1527030418417};\\\", \\\"{x:411,y:534,t:1527030418434};\\\", \\\"{x:383,y:532,t:1527030418450};\\\", \\\"{x:345,y:527,t:1527030418468};\\\", \\\"{x:313,y:522,t:1527030418483};\\\", \\\"{x:285,y:518,t:1527030418501};\\\", \\\"{x:277,y:516,t:1527030418518};\\\", \\\"{x:272,y:514,t:1527030418534};\\\", \\\"{x:270,y:512,t:1527030418551};\\\", \\\"{x:268,y:511,t:1527030418567};\\\", \\\"{x:267,y:510,t:1527030418645};\\\", \\\"{x:267,y:507,t:1527030418653};\\\", \\\"{x:267,y:503,t:1527030418668};\\\", \\\"{x:274,y:486,t:1527030418684};\\\", \\\"{x:284,y:472,t:1527030418701};\\\", \\\"{x:292,y:463,t:1527030418718};\\\", \\\"{x:298,y:456,t:1527030418735};\\\", \\\"{x:300,y:453,t:1527030418753};\\\", \\\"{x:300,y:451,t:1527030418768};\\\", \\\"{x:300,y:449,t:1527030418785};\\\", \\\"{x:300,y:446,t:1527030418802};\\\", \\\"{x:300,y:444,t:1527030418821};\\\", \\\"{x:301,y:443,t:1527030418869};\\\", \\\"{x:302,y:443,t:1527030418885};\\\", \\\"{x:304,y:443,t:1527030418902};\\\", \\\"{x:305,y:443,t:1527030418933};\\\", \\\"{x:304,y:444,t:1527030419021};\\\", \\\"{x:304,y:446,t:1527030419036};\\\", \\\"{x:302,y:451,t:1527030419052};\\\", \\\"{x:302,y:453,t:1527030419068};\\\", \\\"{x:302,y:454,t:1527030419087};\\\", \\\"{x:302,y:455,t:1527030419109};\\\", \\\"{x:302,y:456,t:1527030419141};\\\", \\\"{x:302,y:457,t:1527030419181};\\\", \\\"{x:302,y:458,t:1527030419269};\\\", \\\"{x:303,y:459,t:1527030419309};\\\", \\\"{x:304,y:460,t:1527030419319};\\\", \\\"{x:305,y:460,t:1527030419336};\\\", \\\"{x:308,y:460,t:1527030419353};\\\", \\\"{x:309,y:460,t:1527030419370};\\\", \\\"{x:309,y:461,t:1527030419386};\\\", \\\"{x:311,y:461,t:1527030419403};\\\", \\\"{x:317,y:463,t:1527030419420};\\\", \\\"{x:324,y:465,t:1527030419436};\\\", \\\"{x:347,y:468,t:1527030419453};\\\", \\\"{x:362,y:469,t:1527030419470};\\\", \\\"{x:370,y:469,t:1527030419486};\\\", \\\"{x:378,y:469,t:1527030419503};\\\", \\\"{x:385,y:469,t:1527030419520};\\\", \\\"{x:389,y:470,t:1527030419537};\\\", \\\"{x:396,y:470,t:1527030419553};\\\", \\\"{x:411,y:470,t:1527030419570};\\\", \\\"{x:432,y:470,t:1527030419587};\\\", \\\"{x:449,y:466,t:1527030419603};\\\", \\\"{x:453,y:465,t:1527030419620};\\\", \\\"{x:456,y:464,t:1527030419637};\\\", \\\"{x:456,y:463,t:1527030419654};\\\", \\\"{x:458,y:463,t:1527030419677};\\\", \\\"{x:459,y:463,t:1527030419687};\\\", \\\"{x:465,y:460,t:1527030419703};\\\", \\\"{x:479,y:455,t:1527030419720};\\\", \\\"{x:496,y:450,t:1527030419738};\\\", \\\"{x:512,y:446,t:1527030419755};\\\", \\\"{x:531,y:444,t:1527030419770};\\\", \\\"{x:560,y:440,t:1527030419787};\\\", \\\"{x:589,y:439,t:1527030419804};\\\", \\\"{x:617,y:439,t:1527030419820};\\\", \\\"{x:660,y:439,t:1527030419837};\\\", \\\"{x:698,y:439,t:1527030419855};\\\", \\\"{x:735,y:439,t:1527030419870};\\\", \\\"{x:757,y:439,t:1527030419887};\\\", \\\"{x:768,y:439,t:1527030419904};\\\", \\\"{x:770,y:439,t:1527030419922};\\\", \\\"{x:772,y:439,t:1527030419937};\\\", \\\"{x:772,y:440,t:1527030420029};\\\", \\\"{x:771,y:442,t:1527030420037};\\\", \\\"{x:764,y:447,t:1527030420055};\\\", \\\"{x:750,y:455,t:1527030420071};\\\", \\\"{x:726,y:466,t:1527030420088};\\\", \\\"{x:695,y:475,t:1527030420104};\\\", \\\"{x:656,y:486,t:1527030420121};\\\", \\\"{x:619,y:497,t:1527030420139};\\\", \\\"{x:578,y:507,t:1527030420155};\\\", \\\"{x:536,y:520,t:1527030420173};\\\", \\\"{x:462,y:537,t:1527030420189};\\\", \\\"{x:412,y:549,t:1527030420219};\\\", \\\"{x:396,y:553,t:1527030420237};\\\", \\\"{x:395,y:553,t:1527030420429};\\\", \\\"{x:395,y:552,t:1527030420460};\\\", \\\"{x:395,y:551,t:1527030420476};\\\", \\\"{x:395,y:550,t:1527030420494};\\\", \\\"{x:396,y:549,t:1527030420502};\\\", \\\"{x:397,y:547,t:1527030420519};\\\", \\\"{x:397,y:546,t:1527030420535};\\\", \\\"{x:397,y:544,t:1527030420552};\\\", \\\"{x:398,y:544,t:1527030420569};\\\", \\\"{x:399,y:542,t:1527030420586};\\\", \\\"{x:400,y:541,t:1527030420602};\\\", \\\"{x:401,y:539,t:1527030420620};\\\", \\\"{x:404,y:537,t:1527030420636};\\\", \\\"{x:407,y:536,t:1527030420652};\\\", \\\"{x:411,y:534,t:1527030420668};\\\", \\\"{x:412,y:533,t:1527030420686};\\\", \\\"{x:413,y:532,t:1527030420703};\\\", \\\"{x:416,y:532,t:1527030420719};\\\", \\\"{x:417,y:532,t:1527030420797};\\\", \\\"{x:417,y:531,t:1527030420804};\\\", \\\"{x:418,y:530,t:1527030420820};\\\", \\\"{x:419,y:530,t:1527030420836};\\\", \\\"{x:420,y:530,t:1527030420852};\\\", \\\"{x:420,y:529,t:1527030420900};\\\", \\\"{x:421,y:529,t:1527030420932};\\\", \\\"{x:421,y:528,t:1527030421525};\\\", \\\"{x:422,y:528,t:1527030423093};\\\", \\\"{x:427,y:531,t:1527030423106};\\\", \\\"{x:441,y:542,t:1527030423121};\\\", \\\"{x:462,y:554,t:1527030423139};\\\", \\\"{x:490,y:566,t:1527030423156};\\\", \\\"{x:514,y:578,t:1527030423171};\\\", \\\"{x:533,y:586,t:1527030423188};\\\", \\\"{x:543,y:587,t:1527030423205};\\\", \\\"{x:557,y:589,t:1527030423221};\\\", \\\"{x:572,y:591,t:1527030423238};\\\", \\\"{x:584,y:593,t:1527030423255};\\\", \\\"{x:592,y:594,t:1527030423272};\\\", \\\"{x:599,y:595,t:1527030423288};\\\", \\\"{x:606,y:598,t:1527030423305};\\\", \\\"{x:615,y:602,t:1527030423322};\\\", \\\"{x:623,y:606,t:1527030423338};\\\", \\\"{x:636,y:614,t:1527030423355};\\\", \\\"{x:654,y:622,t:1527030423372};\\\", \\\"{x:705,y:636,t:1527030423389};\\\", \\\"{x:737,y:647,t:1527030423405};\\\", \\\"{x:756,y:651,t:1527030423422};\\\", \\\"{x:771,y:654,t:1527030423438};\\\", \\\"{x:789,y:662,t:1527030423455};\\\", \\\"{x:808,y:670,t:1527030423471};\\\", \\\"{x:832,y:680,t:1527030423488};\\\", \\\"{x:859,y:690,t:1527030423506};\\\", \\\"{x:885,y:702,t:1527030423521};\\\", \\\"{x:907,y:711,t:1527030423538};\\\", \\\"{x:925,y:720,t:1527030423555};\\\", \\\"{x:933,y:725,t:1527030423572};\\\", \\\"{x:947,y:742,t:1527030423588};\\\", \\\"{x:964,y:761,t:1527030423606};\\\", \\\"{x:988,y:790,t:1527030423621};\\\", \\\"{x:1001,y:810,t:1527030423638};\\\", \\\"{x:1003,y:819,t:1527030423656};\\\", \\\"{x:1005,y:822,t:1527030423672};\\\", \\\"{x:1005,y:823,t:1527030423688};\\\", \\\"{x:1006,y:826,t:1527030423705};\\\", \\\"{x:1010,y:832,t:1527030423722};\\\", \\\"{x:1015,y:842,t:1527030423737};\\\", \\\"{x:1024,y:855,t:1527030423755};\\\", \\\"{x:1035,y:870,t:1527030423772};\\\", \\\"{x:1038,y:874,t:1527030423788};\\\", \\\"{x:1039,y:876,t:1527030423804};\\\", \\\"{x:1042,y:879,t:1527030423822};\\\", \\\"{x:1046,y:882,t:1527030423838};\\\", \\\"{x:1055,y:889,t:1527030423855};\\\", \\\"{x:1064,y:895,t:1527030423872};\\\", \\\"{x:1078,y:904,t:1527030423888};\\\", \\\"{x:1091,y:910,t:1527030423905};\\\", \\\"{x:1100,y:914,t:1527030423922};\\\", \\\"{x:1102,y:916,t:1527030423938};\\\", \\\"{x:1107,y:920,t:1527030423955};\\\", \\\"{x:1123,y:929,t:1527030423971};\\\", \\\"{x:1146,y:942,t:1527030423988};\\\", \\\"{x:1166,y:952,t:1527030424005};\\\", \\\"{x:1177,y:957,t:1527030424022};\\\", \\\"{x:1181,y:961,t:1527030424038};\\\", \\\"{x:1183,y:961,t:1527030424055};\\\", \\\"{x:1184,y:962,t:1527030424084};\\\", \\\"{x:1187,y:963,t:1527030424092};\\\", \\\"{x:1192,y:963,t:1527030424105};\\\", \\\"{x:1208,y:963,t:1527030424122};\\\", \\\"{x:1225,y:963,t:1527030424138};\\\", \\\"{x:1239,y:963,t:1527030424155};\\\", \\\"{x:1246,y:961,t:1527030424171};\\\", \\\"{x:1247,y:956,t:1527030424187};\\\", \\\"{x:1247,y:951,t:1527030424205};\\\", \\\"{x:1247,y:944,t:1527030424222};\\\", \\\"{x:1247,y:933,t:1527030424238};\\\", \\\"{x:1250,y:917,t:1527030424255};\\\", \\\"{x:1255,y:903,t:1527030424272};\\\", \\\"{x:1263,y:886,t:1527030424287};\\\", \\\"{x:1269,y:870,t:1527030424305};\\\", \\\"{x:1273,y:857,t:1527030424322};\\\", \\\"{x:1274,y:845,t:1527030424337};\\\", \\\"{x:1276,y:838,t:1527030424355};\\\", \\\"{x:1276,y:832,t:1527030424373};\\\", \\\"{x:1276,y:831,t:1527030424388};\\\", \\\"{x:1276,y:830,t:1527030424412};\\\", \\\"{x:1276,y:828,t:1527030424422};\\\", \\\"{x:1276,y:825,t:1527030424438};\\\", \\\"{x:1276,y:824,t:1527030424455};\\\", \\\"{x:1277,y:823,t:1527030424812};\\\", \\\"{x:1278,y:822,t:1527030424827};\\\", \\\"{x:1279,y:822,t:1527030424838};\\\", \\\"{x:1285,y:819,t:1527030424855};\\\", \\\"{x:1292,y:816,t:1527030424872};\\\", \\\"{x:1299,y:815,t:1527030424889};\\\", \\\"{x:1303,y:813,t:1527030424905};\\\", \\\"{x:1308,y:811,t:1527030424922};\\\", \\\"{x:1316,y:804,t:1527030424939};\\\", \\\"{x:1328,y:791,t:1527030424956};\\\", \\\"{x:1359,y:754,t:1527030424972};\\\", \\\"{x:1390,y:724,t:1527030424989};\\\", \\\"{x:1429,y:690,t:1527030425006};\\\", \\\"{x:1442,y:671,t:1527030425022};\\\", \\\"{x:1455,y:648,t:1527030425039};\\\", \\\"{x:1463,y:631,t:1527030425055};\\\", \\\"{x:1467,y:613,t:1527030425073};\\\", \\\"{x:1473,y:594,t:1527030425090};\\\", \\\"{x:1477,y:576,t:1527030425105};\\\", \\\"{x:1482,y:560,t:1527030425123};\\\", \\\"{x:1488,y:547,t:1527030425140};\\\", \\\"{x:1496,y:531,t:1527030425155};\\\", \\\"{x:1506,y:508,t:1527030425172};\\\", \\\"{x:1514,y:489,t:1527030425189};\\\", \\\"{x:1516,y:476,t:1527030425206};\\\", \\\"{x:1516,y:466,t:1527030425222};\\\", \\\"{x:1515,y:460,t:1527030425240};\\\", \\\"{x:1509,y:452,t:1527030425256};\\\", \\\"{x:1503,y:448,t:1527030425273};\\\", \\\"{x:1499,y:444,t:1527030425289};\\\", \\\"{x:1494,y:439,t:1527030425305};\\\", \\\"{x:1488,y:435,t:1527030425322};\\\", \\\"{x:1483,y:433,t:1527030425339};\\\", \\\"{x:1478,y:432,t:1527030425355};\\\", \\\"{x:1467,y:432,t:1527030425372};\\\", \\\"{x:1458,y:431,t:1527030425389};\\\", \\\"{x:1452,y:428,t:1527030425405};\\\", \\\"{x:1448,y:427,t:1527030425422};\\\", \\\"{x:1446,y:427,t:1527030425439};\\\", \\\"{x:1442,y:427,t:1527030425532};\\\", \\\"{x:1432,y:427,t:1527030425540};\\\", \\\"{x:1426,y:427,t:1527030425555};\\\", \\\"{x:1400,y:427,t:1527030425572};\\\", \\\"{x:1382,y:427,t:1527030425590};\\\", \\\"{x:1361,y:430,t:1527030425605};\\\", \\\"{x:1340,y:438,t:1527030425623};\\\", \\\"{x:1317,y:449,t:1527030425639};\\\", \\\"{x:1303,y:460,t:1527030425655};\\\", \\\"{x:1291,y:473,t:1527030425672};\\\", \\\"{x:1285,y:480,t:1527030425690};\\\", \\\"{x:1279,y:488,t:1527030425705};\\\", \\\"{x:1274,y:493,t:1527030425722};\\\", \\\"{x:1268,y:499,t:1527030425739};\\\", \\\"{x:1265,y:503,t:1527030425755};\\\", \\\"{x:1265,y:504,t:1527030425781};\\\", \\\"{x:1269,y:504,t:1527030425877};\\\", \\\"{x:1278,y:504,t:1527030425889};\\\", \\\"{x:1299,y:497,t:1527030425905};\\\", \\\"{x:1322,y:487,t:1527030425923};\\\", \\\"{x:1336,y:478,t:1527030425939};\\\", \\\"{x:1338,y:473,t:1527030425956};\\\", \\\"{x:1340,y:470,t:1527030425973};\\\", \\\"{x:1340,y:469,t:1527030425990};\\\", \\\"{x:1340,y:472,t:1527030426133};\\\", \\\"{x:1341,y:479,t:1527030426140};\\\", \\\"{x:1345,y:494,t:1527030426157};\\\", \\\"{x:1345,y:507,t:1527030426173};\\\", \\\"{x:1348,y:522,t:1527030426190};\\\", \\\"{x:1351,y:541,t:1527030426207};\\\", \\\"{x:1356,y:560,t:1527030426222};\\\", \\\"{x:1362,y:579,t:1527030426240};\\\", \\\"{x:1364,y:598,t:1527030426257};\\\", \\\"{x:1367,y:615,t:1527030426272};\\\", \\\"{x:1369,y:630,t:1527030426290};\\\", \\\"{x:1371,y:639,t:1527030426307};\\\", \\\"{x:1371,y:641,t:1527030426323};\\\", \\\"{x:1371,y:642,t:1527030426340};\\\", \\\"{x:1371,y:646,t:1527030426357};\\\", \\\"{x:1371,y:653,t:1527030426373};\\\", \\\"{x:1371,y:659,t:1527030426389};\\\", \\\"{x:1370,y:668,t:1527030426407};\\\", \\\"{x:1366,y:676,t:1527030426422};\\\", \\\"{x:1362,y:682,t:1527030426439};\\\", \\\"{x:1358,y:687,t:1527030426456};\\\", \\\"{x:1356,y:689,t:1527030426472};\\\", \\\"{x:1351,y:692,t:1527030426489};\\\", \\\"{x:1348,y:695,t:1527030426507};\\\", \\\"{x:1344,y:699,t:1527030426522};\\\", \\\"{x:1339,y:702,t:1527030426539};\\\", \\\"{x:1330,y:705,t:1527030426556};\\\", \\\"{x:1328,y:705,t:1527030426573};\\\", \\\"{x:1327,y:706,t:1527030426661};\\\", \\\"{x:1326,y:707,t:1527030426672};\\\", \\\"{x:1325,y:708,t:1527030426690};\\\", \\\"{x:1325,y:706,t:1527030426813};\\\", \\\"{x:1325,y:705,t:1527030426823};\\\", \\\"{x:1325,y:702,t:1527030426840};\\\", \\\"{x:1325,y:697,t:1527030426857};\\\", \\\"{x:1325,y:692,t:1527030426873};\\\", \\\"{x:1325,y:688,t:1527030426889};\\\", \\\"{x:1325,y:683,t:1527030426907};\\\", \\\"{x:1325,y:681,t:1527030426922};\\\", \\\"{x:1325,y:680,t:1527030426939};\\\", \\\"{x:1324,y:675,t:1527030426956};\\\", \\\"{x:1322,y:670,t:1527030426973};\\\", \\\"{x:1322,y:665,t:1527030426990};\\\", \\\"{x:1322,y:659,t:1527030427006};\\\", \\\"{x:1322,y:654,t:1527030427023};\\\", \\\"{x:1321,y:648,t:1527030427039};\\\", \\\"{x:1321,y:646,t:1527030427056};\\\", \\\"{x:1321,y:645,t:1527030427072};\\\", \\\"{x:1321,y:644,t:1527030427140};\\\", \\\"{x:1321,y:642,t:1527030427156};\\\", \\\"{x:1321,y:641,t:1527030427173};\\\", \\\"{x:1321,y:640,t:1527030427189};\\\", \\\"{x:1320,y:638,t:1527030427206};\\\", \\\"{x:1318,y:639,t:1527030427413};\\\", \\\"{x:1318,y:641,t:1527030427424};\\\", \\\"{x:1314,y:647,t:1527030427440};\\\", \\\"{x:1311,y:654,t:1527030427457};\\\", \\\"{x:1309,y:662,t:1527030427474};\\\", \\\"{x:1309,y:667,t:1527030427489};\\\", \\\"{x:1309,y:670,t:1527030427507};\\\", \\\"{x:1309,y:672,t:1527030427532};\\\", \\\"{x:1309,y:675,t:1527030427557};\\\", \\\"{x:1309,y:679,t:1527030427573};\\\", \\\"{x:1309,y:688,t:1527030427590};\\\", \\\"{x:1309,y:693,t:1527030427606};\\\", \\\"{x:1309,y:696,t:1527030427624};\\\", \\\"{x:1309,y:697,t:1527030427669};\\\", \\\"{x:1309,y:698,t:1527030427676};\\\", \\\"{x:1309,y:699,t:1527030427690};\\\", \\\"{x:1309,y:702,t:1527030427707};\\\", \\\"{x:1309,y:705,t:1527030427724};\\\", \\\"{x:1309,y:710,t:1527030427740};\\\", \\\"{x:1309,y:716,t:1527030427756};\\\", \\\"{x:1309,y:721,t:1527030427774};\\\", \\\"{x:1310,y:727,t:1527030427789};\\\", \\\"{x:1313,y:737,t:1527030427807};\\\", \\\"{x:1314,y:743,t:1527030427824};\\\", \\\"{x:1315,y:748,t:1527030427840};\\\", \\\"{x:1316,y:753,t:1527030427857};\\\", \\\"{x:1316,y:757,t:1527030427874};\\\", \\\"{x:1316,y:764,t:1527030427890};\\\", \\\"{x:1320,y:776,t:1527030427906};\\\", \\\"{x:1325,y:790,t:1527030427924};\\\", \\\"{x:1330,y:804,t:1527030427940};\\\", \\\"{x:1331,y:813,t:1527030427956};\\\", \\\"{x:1331,y:815,t:1527030428053};\\\", \\\"{x:1330,y:816,t:1527030428060};\\\", \\\"{x:1330,y:817,t:1527030428074};\\\", \\\"{x:1328,y:818,t:1527030428090};\\\", \\\"{x:1327,y:819,t:1527030428107};\\\", \\\"{x:1325,y:820,t:1527030428123};\\\", \\\"{x:1324,y:821,t:1527030428140};\\\", \\\"{x:1323,y:821,t:1527030428165};\\\", \\\"{x:1323,y:822,t:1527030428174};\\\", \\\"{x:1322,y:822,t:1527030428191};\\\", \\\"{x:1321,y:822,t:1527030428207};\\\", \\\"{x:1319,y:822,t:1527030428228};\\\", \\\"{x:1316,y:821,t:1527030428240};\\\", \\\"{x:1304,y:803,t:1527030428257};\\\", \\\"{x:1287,y:783,t:1527030428274};\\\", \\\"{x:1271,y:765,t:1527030428290};\\\", \\\"{x:1250,y:751,t:1527030428307};\\\", \\\"{x:1228,y:746,t:1527030428325};\\\", \\\"{x:1217,y:746,t:1527030428340};\\\", \\\"{x:1209,y:746,t:1527030428356};\\\", \\\"{x:1191,y:748,t:1527030428373};\\\", \\\"{x:1158,y:752,t:1527030428390};\\\", \\\"{x:1116,y:759,t:1527030428407};\\\", \\\"{x:1077,y:769,t:1527030428424};\\\", \\\"{x:1053,y:777,t:1527030428440};\\\", \\\"{x:1046,y:782,t:1527030428456};\\\", \\\"{x:1046,y:779,t:1527030428532};\\\", \\\"{x:1048,y:770,t:1527030428540};\\\", \\\"{x:1057,y:750,t:1527030428556};\\\", \\\"{x:1079,y:711,t:1527030428574};\\\", \\\"{x:1116,y:653,t:1527030428590};\\\", \\\"{x:1153,y:590,t:1527030428607};\\\", \\\"{x:1176,y:537,t:1527030428623};\\\", \\\"{x:1193,y:491,t:1527030428641};\\\", \\\"{x:1202,y:466,t:1527030428657};\\\", \\\"{x:1211,y:448,t:1527030428673};\\\", \\\"{x:1219,y:436,t:1527030428690};\\\", \\\"{x:1235,y:420,t:1527030428707};\\\", \\\"{x:1248,y:405,t:1527030428723};\\\", \\\"{x:1263,y:388,t:1527030428741};\\\", \\\"{x:1268,y:384,t:1527030428756};\\\", \\\"{x:1272,y:380,t:1527030428773};\\\", \\\"{x:1273,y:380,t:1527030428790};\\\", \\\"{x:1275,y:380,t:1527030428812};\\\", \\\"{x:1277,y:382,t:1527030428823};\\\", \\\"{x:1288,y:397,t:1527030428840};\\\", \\\"{x:1298,y:405,t:1527030428856};\\\", \\\"{x:1307,y:408,t:1527030428873};\\\", \\\"{x:1311,y:408,t:1527030428890};\\\", \\\"{x:1311,y:409,t:1527030428906};\\\", \\\"{x:1312,y:409,t:1527030428932};\\\", \\\"{x:1313,y:409,t:1527030428940};\\\", \\\"{x:1322,y:420,t:1527030428956};\\\", \\\"{x:1333,y:436,t:1527030428973};\\\", \\\"{x:1339,y:447,t:1527030428990};\\\", \\\"{x:1340,y:450,t:1527030429006};\\\", \\\"{x:1341,y:450,t:1527030429023};\\\", \\\"{x:1341,y:451,t:1527030429212};\\\", \\\"{x:1341,y:453,t:1527030429236};\\\", \\\"{x:1341,y:454,t:1527030429252};\\\", \\\"{x:1340,y:454,t:1527030429260};\\\", \\\"{x:1340,y:456,t:1527030429273};\\\", \\\"{x:1339,y:458,t:1527030429290};\\\", \\\"{x:1339,y:459,t:1527030429307};\\\", \\\"{x:1339,y:460,t:1527030429323};\\\", \\\"{x:1339,y:461,t:1527030429341};\\\", \\\"{x:1338,y:463,t:1527030429356};\\\", \\\"{x:1338,y:464,t:1527030429380};\\\", \\\"{x:1338,y:465,t:1527030429391};\\\", \\\"{x:1337,y:466,t:1527030429406};\\\", \\\"{x:1337,y:468,t:1527030429423};\\\", \\\"{x:1337,y:469,t:1527030429444};\\\", \\\"{x:1336,y:470,t:1527030429461};\\\", \\\"{x:1335,y:471,t:1527030429477};\\\", \\\"{x:1334,y:472,t:1527030429491};\\\", \\\"{x:1332,y:474,t:1527030429507};\\\", \\\"{x:1332,y:475,t:1527030429523};\\\", \\\"{x:1330,y:476,t:1527030429541};\\\", \\\"{x:1330,y:477,t:1527030429637};\\\", \\\"{x:1330,y:478,t:1527030429645};\\\", \\\"{x:1329,y:479,t:1527030429661};\\\", \\\"{x:1329,y:481,t:1527030429693};\\\", \\\"{x:1329,y:482,t:1527030429724};\\\", \\\"{x:1329,y:484,t:1527030429773};\\\", \\\"{x:1329,y:485,t:1527030429797};\\\", \\\"{x:1329,y:487,t:1527030429813};\\\", \\\"{x:1329,y:489,t:1527030429824};\\\", \\\"{x:1329,y:497,t:1527030429841};\\\", \\\"{x:1332,y:513,t:1527030429858};\\\", \\\"{x:1338,y:534,t:1527030429874};\\\", \\\"{x:1347,y:556,t:1527030429890};\\\", \\\"{x:1360,y:581,t:1527030429907};\\\", \\\"{x:1374,y:605,t:1527030429924};\\\", \\\"{x:1394,y:640,t:1527030429940};\\\", \\\"{x:1401,y:656,t:1527030429958};\\\", \\\"{x:1407,y:667,t:1527030429974};\\\", \\\"{x:1412,y:676,t:1527030429991};\\\", \\\"{x:1420,y:687,t:1527030430008};\\\", \\\"{x:1425,y:693,t:1527030430023};\\\", \\\"{x:1428,y:700,t:1527030430041};\\\", \\\"{x:1433,y:712,t:1527030430058};\\\", \\\"{x:1437,y:728,t:1527030430074};\\\", \\\"{x:1444,y:752,t:1527030430091};\\\", \\\"{x:1457,y:791,t:1527030430108};\\\", \\\"{x:1477,y:851,t:1527030430124};\\\", \\\"{x:1523,y:954,t:1527030430140};\\\", \\\"{x:1551,y:1003,t:1527030430158};\\\", \\\"{x:1560,y:1017,t:1527030430174};\\\", \\\"{x:1562,y:1018,t:1527030430191};\\\", \\\"{x:1563,y:1018,t:1527030430208};\\\", \\\"{x:1564,y:1019,t:1527030430223};\\\", \\\"{x:1565,y:1019,t:1527030430241};\\\", \\\"{x:1566,y:1024,t:1527030430258};\\\", \\\"{x:1566,y:1029,t:1527030430274};\\\", \\\"{x:1566,y:1034,t:1527030430290};\\\", \\\"{x:1566,y:1036,t:1527030430307};\\\", \\\"{x:1565,y:1036,t:1527030430413};\\\", \\\"{x:1564,y:1035,t:1527030430424};\\\", \\\"{x:1563,y:1033,t:1527030430441};\\\", \\\"{x:1562,y:1031,t:1527030430458};\\\", \\\"{x:1561,y:1029,t:1527030430474};\\\", \\\"{x:1558,y:1026,t:1527030430491};\\\", \\\"{x:1554,y:1021,t:1527030430508};\\\", \\\"{x:1550,y:1017,t:1527030430524};\\\", \\\"{x:1541,y:1010,t:1527030430541};\\\", \\\"{x:1528,y:1003,t:1527030430558};\\\", \\\"{x:1512,y:993,t:1527030430574};\\\", \\\"{x:1497,y:983,t:1527030430590};\\\", \\\"{x:1485,y:977,t:1527030430607};\\\", \\\"{x:1477,y:975,t:1527030430624};\\\", \\\"{x:1475,y:973,t:1527030430640};\\\", \\\"{x:1473,y:973,t:1527030430658};\\\", \\\"{x:1472,y:972,t:1527030430674};\\\", \\\"{x:1471,y:971,t:1527030430701};\\\", \\\"{x:1471,y:970,t:1527030430709};\\\", \\\"{x:1470,y:970,t:1527030430789};\\\", \\\"{x:1469,y:970,t:1527030430797};\\\", \\\"{x:1467,y:969,t:1527030430813};\\\", \\\"{x:1465,y:967,t:1527030430829};\\\", \\\"{x:1463,y:966,t:1527030430841};\\\", \\\"{x:1460,y:965,t:1527030430858};\\\", \\\"{x:1459,y:964,t:1527030430876};\\\", \\\"{x:1457,y:963,t:1527030430891};\\\", \\\"{x:1456,y:963,t:1527030431021};\\\", \\\"{x:1456,y:962,t:1527030431669};\\\", \\\"{x:1454,y:961,t:1527030431797};\\\", \\\"{x:1452,y:961,t:1527030431808};\\\", \\\"{x:1447,y:963,t:1527030431825};\\\", \\\"{x:1437,y:967,t:1527030431842};\\\", \\\"{x:1427,y:972,t:1527030431858};\\\", \\\"{x:1416,y:978,t:1527030431875};\\\", \\\"{x:1408,y:982,t:1527030431891};\\\", \\\"{x:1394,y:987,t:1527030431909};\\\", \\\"{x:1377,y:995,t:1527030431924};\\\", \\\"{x:1369,y:996,t:1527030431941};\\\", \\\"{x:1366,y:996,t:1527030431957};\\\", \\\"{x:1365,y:995,t:1527030432100};\\\", \\\"{x:1365,y:994,t:1527030432108};\\\", \\\"{x:1365,y:990,t:1527030432124};\\\", \\\"{x:1365,y:988,t:1527030432142};\\\", \\\"{x:1364,y:987,t:1527030432213};\\\", \\\"{x:1362,y:987,t:1527030432225};\\\", \\\"{x:1352,y:982,t:1527030432242};\\\", \\\"{x:1336,y:977,t:1527030432258};\\\", \\\"{x:1318,y:972,t:1527030432275};\\\", \\\"{x:1305,y:968,t:1527030432292};\\\", \\\"{x:1293,y:966,t:1527030432308};\\\", \\\"{x:1292,y:965,t:1527030432325};\\\", \\\"{x:1291,y:964,t:1527030432549};\\\", \\\"{x:1292,y:962,t:1527030432589};\\\", \\\"{x:1293,y:960,t:1527030432605};\\\", \\\"{x:1293,y:959,t:1527030432621};\\\", \\\"{x:1295,y:957,t:1527030432636};\\\", \\\"{x:1296,y:955,t:1527030432644};\\\", \\\"{x:1298,y:951,t:1527030432660};\\\", \\\"{x:1299,y:948,t:1527030432675};\\\", \\\"{x:1301,y:943,t:1527030432692};\\\", \\\"{x:1304,y:934,t:1527030432707};\\\", \\\"{x:1307,y:915,t:1527030432725};\\\", \\\"{x:1307,y:893,t:1527030432742};\\\", \\\"{x:1307,y:873,t:1527030432758};\\\", \\\"{x:1307,y:846,t:1527030432775};\\\", \\\"{x:1307,y:812,t:1527030432792};\\\", \\\"{x:1305,y:791,t:1527030432808};\\\", \\\"{x:1302,y:779,t:1527030432825};\\\", \\\"{x:1302,y:776,t:1527030432842};\\\", \\\"{x:1302,y:770,t:1527030432857};\\\", \\\"{x:1300,y:760,t:1527030432875};\\\", \\\"{x:1298,y:744,t:1527030432892};\\\", \\\"{x:1293,y:728,t:1527030432908};\\\", \\\"{x:1290,y:707,t:1527030432925};\\\", \\\"{x:1288,y:696,t:1527030432942};\\\", \\\"{x:1285,y:684,t:1527030432958};\\\", \\\"{x:1283,y:677,t:1527030432975};\\\", \\\"{x:1283,y:671,t:1527030432992};\\\", \\\"{x:1282,y:659,t:1527030433008};\\\", \\\"{x:1282,y:643,t:1527030433025};\\\", \\\"{x:1281,y:633,t:1527030433042};\\\", \\\"{x:1278,y:621,t:1527030433058};\\\", \\\"{x:1277,y:608,t:1527030433075};\\\", \\\"{x:1276,y:598,t:1527030433092};\\\", \\\"{x:1276,y:588,t:1527030433108};\\\", \\\"{x:1276,y:566,t:1527030433125};\\\", \\\"{x:1276,y:551,t:1527030433142};\\\", \\\"{x:1276,y:535,t:1527030433158};\\\", \\\"{x:1276,y:526,t:1527030433175};\\\", \\\"{x:1276,y:524,t:1527030433192};\\\", \\\"{x:1276,y:523,t:1527030433209};\\\", \\\"{x:1276,y:520,t:1527030433225};\\\", \\\"{x:1276,y:515,t:1527030433242};\\\", \\\"{x:1280,y:504,t:1527030433259};\\\", \\\"{x:1283,y:496,t:1527030433275};\\\", \\\"{x:1285,y:492,t:1527030433293};\\\", \\\"{x:1288,y:487,t:1527030433309};\\\", \\\"{x:1290,y:486,t:1527030433325};\\\", \\\"{x:1291,y:484,t:1527030433373};\\\", \\\"{x:1294,y:481,t:1527030433381};\\\", \\\"{x:1298,y:479,t:1527030433392};\\\", \\\"{x:1304,y:475,t:1527030433409};\\\", \\\"{x:1307,y:471,t:1527030433426};\\\", \\\"{x:1310,y:470,t:1527030433441};\\\", \\\"{x:1311,y:470,t:1527030433460};\\\", \\\"{x:1312,y:470,t:1527030433508};\\\", \\\"{x:1313,y:470,t:1527030433524};\\\", \\\"{x:1314,y:472,t:1527030433613};\\\", \\\"{x:1315,y:479,t:1527030433625};\\\", \\\"{x:1316,y:486,t:1527030433642};\\\", \\\"{x:1317,y:490,t:1527030433659};\\\", \\\"{x:1317,y:491,t:1527030433675};\\\", \\\"{x:1317,y:492,t:1527030433749};\\\", \\\"{x:1317,y:493,t:1527030433764};\\\", \\\"{x:1317,y:494,t:1527030436141};\\\", \\\"{x:1317,y:495,t:1527030436148};\\\", \\\"{x:1317,y:497,t:1527030436159};\\\", \\\"{x:1317,y:500,t:1527030436176};\\\", \\\"{x:1315,y:503,t:1527030436194};\\\", \\\"{x:1314,y:504,t:1527030436209};\\\", \\\"{x:1314,y:505,t:1527030436226};\\\", \\\"{x:1314,y:506,t:1527030436244};\\\", \\\"{x:1314,y:507,t:1527030436268};\\\", \\\"{x:1313,y:508,t:1527030436291};\\\", \\\"{x:1313,y:509,t:1527030436323};\\\", \\\"{x:1313,y:510,t:1527030436332};\\\", \\\"{x:1313,y:511,t:1527030436343};\\\", \\\"{x:1313,y:512,t:1527030436358};\\\", \\\"{x:1311,y:513,t:1527030436376};\\\", \\\"{x:1311,y:515,t:1527030436392};\\\", \\\"{x:1310,y:516,t:1527030436408};\\\", \\\"{x:1310,y:517,t:1527030436476};\\\", \\\"{x:1310,y:518,t:1527030436492};\\\", \\\"{x:1309,y:518,t:1527030436508};\\\", \\\"{x:1309,y:519,t:1527030436532};\\\", \\\"{x:1309,y:520,t:1527030436564};\\\", \\\"{x:1309,y:521,t:1527030436576};\\\", \\\"{x:1307,y:524,t:1527030436593};\\\", \\\"{x:1307,y:526,t:1527030436609};\\\", \\\"{x:1306,y:530,t:1527030436626};\\\", \\\"{x:1302,y:537,t:1527030436643};\\\", \\\"{x:1287,y:561,t:1527030436659};\\\", \\\"{x:1241,y:628,t:1527030436676};\\\", \\\"{x:1139,y:798,t:1527030436693};\\\", \\\"{x:1079,y:922,t:1527030436709};\\\", \\\"{x:1057,y:990,t:1527030436726};\\\", \\\"{x:1051,y:1015,t:1527030436743};\\\", \\\"{x:1048,y:1023,t:1527030436759};\\\", \\\"{x:1048,y:1026,t:1527030436776};\\\", \\\"{x:1048,y:1028,t:1527030436793};\\\", \\\"{x:1048,y:1035,t:1527030436809};\\\", \\\"{x:1048,y:1044,t:1527030436826};\\\", \\\"{x:1048,y:1056,t:1527030436843};\\\", \\\"{x:1047,y:1067,t:1527030436859};\\\", \\\"{x:1044,y:1080,t:1527030436876};\\\", \\\"{x:1043,y:1082,t:1527030436893};\\\", \\\"{x:1043,y:1080,t:1527030436973};\\\", \\\"{x:1043,y:1077,t:1527030436980};\\\", \\\"{x:1043,y:1073,t:1527030436993};\\\", \\\"{x:1043,y:1067,t:1527030437010};\\\", \\\"{x:1043,y:1062,t:1527030437026};\\\", \\\"{x:1043,y:1056,t:1527030437043};\\\", \\\"{x:1044,y:1048,t:1527030437061};\\\", \\\"{x:1049,y:1034,t:1527030437076};\\\", \\\"{x:1055,y:1017,t:1527030437093};\\\", \\\"{x:1063,y:997,t:1527030437110};\\\", \\\"{x:1071,y:970,t:1527030437127};\\\", \\\"{x:1079,y:945,t:1527030437143};\\\", \\\"{x:1086,y:921,t:1527030437159};\\\", \\\"{x:1095,y:896,t:1527030437175};\\\", \\\"{x:1107,y:870,t:1527030437192};\\\", \\\"{x:1117,y:849,t:1527030437210};\\\", \\\"{x:1126,y:826,t:1527030437226};\\\", \\\"{x:1134,y:805,t:1527030437243};\\\", \\\"{x:1137,y:783,t:1527030437260};\\\", \\\"{x:1141,y:770,t:1527030437275};\\\", \\\"{x:1146,y:758,t:1527030437292};\\\", \\\"{x:1152,y:741,t:1527030437309};\\\", \\\"{x:1163,y:720,t:1527030437326};\\\", \\\"{x:1175,y:702,t:1527030437343};\\\", \\\"{x:1185,y:688,t:1527030437359};\\\", \\\"{x:1191,y:680,t:1527030437376};\\\", \\\"{x:1194,y:676,t:1527030437393};\\\", \\\"{x:1198,y:671,t:1527030437410};\\\", \\\"{x:1200,y:667,t:1527030437426};\\\", \\\"{x:1205,y:661,t:1527030437443};\\\", \\\"{x:1222,y:648,t:1527030437460};\\\", \\\"{x:1230,y:644,t:1527030437476};\\\", \\\"{x:1238,y:636,t:1527030437493};\\\", \\\"{x:1241,y:633,t:1527030437510};\\\", \\\"{x:1243,y:631,t:1527030437526};\\\", \\\"{x:1246,y:629,t:1527030437543};\\\", \\\"{x:1252,y:622,t:1527030437560};\\\", \\\"{x:1258,y:617,t:1527030437576};\\\", \\\"{x:1263,y:613,t:1527030437593};\\\", \\\"{x:1268,y:609,t:1527030437610};\\\", \\\"{x:1275,y:604,t:1527030437626};\\\", \\\"{x:1279,y:602,t:1527030437643};\\\", \\\"{x:1279,y:601,t:1527030437660};\\\", \\\"{x:1281,y:601,t:1527030437749};\\\", \\\"{x:1283,y:602,t:1527030437765};\\\", \\\"{x:1285,y:602,t:1527030437776};\\\", \\\"{x:1292,y:608,t:1527030437793};\\\", \\\"{x:1308,y:621,t:1527030437810};\\\", \\\"{x:1332,y:641,t:1527030437826};\\\", \\\"{x:1366,y:680,t:1527030437843};\\\", \\\"{x:1388,y:703,t:1527030437860};\\\", \\\"{x:1418,y:729,t:1527030437876};\\\", \\\"{x:1427,y:742,t:1527030437893};\\\", \\\"{x:1432,y:759,t:1527030437910};\\\", \\\"{x:1434,y:778,t:1527030437926};\\\", \\\"{x:1437,y:810,t:1527030437943};\\\", \\\"{x:1451,y:857,t:1527030437959};\\\", \\\"{x:1465,y:907,t:1527030437977};\\\", \\\"{x:1473,y:935,t:1527030437993};\\\", \\\"{x:1479,y:946,t:1527030438010};\\\", \\\"{x:1479,y:947,t:1527030438084};\\\", \\\"{x:1481,y:949,t:1527030438100};\\\", \\\"{x:1482,y:952,t:1527030438109};\\\", \\\"{x:1483,y:956,t:1527030438127};\\\", \\\"{x:1485,y:963,t:1527030438143};\\\", \\\"{x:1485,y:966,t:1527030438160};\\\", \\\"{x:1485,y:967,t:1527030438436};\\\", \\\"{x:1484,y:967,t:1527030438468};\\\", \\\"{x:1483,y:967,t:1527030438476};\\\", \\\"{x:1482,y:967,t:1527030438493};\\\", \\\"{x:1481,y:966,t:1527030438516};\\\", \\\"{x:1479,y:966,t:1527030438532};\\\", \\\"{x:1478,y:965,t:1527030438548};\\\", \\\"{x:1478,y:964,t:1527030438572};\\\", \\\"{x:1477,y:964,t:1527030439037};\\\", \\\"{x:1475,y:964,t:1527030439045};\\\", \\\"{x:1462,y:964,t:1527030439061};\\\", \\\"{x:1443,y:963,t:1527030439077};\\\", \\\"{x:1424,y:963,t:1527030439093};\\\", \\\"{x:1404,y:963,t:1527030439111};\\\", \\\"{x:1388,y:963,t:1527030439127};\\\", \\\"{x:1378,y:963,t:1527030439143};\\\", \\\"{x:1371,y:963,t:1527030439160};\\\", \\\"{x:1369,y:963,t:1527030439176};\\\", \\\"{x:1368,y:963,t:1527030439212};\\\", \\\"{x:1367,y:963,t:1527030439236};\\\", \\\"{x:1366,y:963,t:1527030439244};\\\", \\\"{x:1363,y:964,t:1527030439260};\\\", \\\"{x:1359,y:964,t:1527030439277};\\\", \\\"{x:1354,y:964,t:1527030439294};\\\", \\\"{x:1349,y:964,t:1527030439310};\\\", \\\"{x:1342,y:964,t:1527030439327};\\\", \\\"{x:1333,y:964,t:1527030439344};\\\", \\\"{x:1324,y:964,t:1527030439360};\\\", \\\"{x:1318,y:964,t:1527030439377};\\\", \\\"{x:1312,y:963,t:1527030439394};\\\", \\\"{x:1306,y:963,t:1527030439410};\\\", \\\"{x:1303,y:963,t:1527030439427};\\\", \\\"{x:1300,y:963,t:1527030439444};\\\", \\\"{x:1300,y:964,t:1527030439460};\\\", \\\"{x:1296,y:964,t:1527030439477};\\\", \\\"{x:1295,y:964,t:1527030439613};\\\", \\\"{x:1294,y:964,t:1527030439628};\\\", \\\"{x:1293,y:965,t:1527030439645};\\\", \\\"{x:1291,y:965,t:1527030439660};\\\", \\\"{x:1288,y:965,t:1527030440261};\\\", \\\"{x:1282,y:965,t:1527030440278};\\\", \\\"{x:1272,y:965,t:1527030440294};\\\", \\\"{x:1262,y:964,t:1527030440311};\\\", \\\"{x:1256,y:963,t:1527030440327};\\\", \\\"{x:1253,y:963,t:1527030440345};\\\", \\\"{x:1253,y:962,t:1527030440361};\\\", \\\"{x:1252,y:962,t:1527030440377};\\\", \\\"{x:1251,y:962,t:1527030440565};\\\", \\\"{x:1253,y:960,t:1527030440581};\\\", \\\"{x:1255,y:959,t:1527030440597};\\\", \\\"{x:1257,y:959,t:1527030440611};\\\", \\\"{x:1263,y:959,t:1527030440628};\\\", \\\"{x:1271,y:959,t:1527030440645};\\\", \\\"{x:1276,y:959,t:1527030440661};\\\", \\\"{x:1280,y:958,t:1527030440678};\\\", \\\"{x:1282,y:958,t:1527030440695};\\\", \\\"{x:1283,y:957,t:1527030440716};\\\", \\\"{x:1285,y:956,t:1527030440749};\\\", \\\"{x:1286,y:955,t:1527030440789};\\\", \\\"{x:1286,y:956,t:1527030442261};\\\", \\\"{x:1285,y:957,t:1527030442278};\\\", \\\"{x:1284,y:957,t:1527030442709};\\\", \\\"{x:1280,y:959,t:1527030445629};\\\", \\\"{x:1277,y:960,t:1527030445645};\\\", \\\"{x:1275,y:960,t:1527030445663};\\\", \\\"{x:1273,y:960,t:1527030445765};\\\", \\\"{x:1275,y:960,t:1527030446405};\\\", \\\"{x:1277,y:961,t:1527030446412};\\\", \\\"{x:1279,y:962,t:1527030446430};\\\", \\\"{x:1280,y:962,t:1527030446446};\\\", \\\"{x:1281,y:963,t:1527030446463};\\\", \\\"{x:1283,y:963,t:1527030446480};\\\", \\\"{x:1283,y:964,t:1527030446541};\\\", \\\"{x:1283,y:963,t:1527030447308};\\\", \\\"{x:1283,y:962,t:1527030447332};\\\", \\\"{x:1283,y:961,t:1527030447346};\\\", \\\"{x:1283,y:960,t:1527030447363};\\\", \\\"{x:1283,y:959,t:1527030447411};\\\", \\\"{x:1283,y:958,t:1527030447429};\\\", \\\"{x:1283,y:957,t:1527030447446};\\\", \\\"{x:1283,y:956,t:1527030447468};\\\", \\\"{x:1282,y:955,t:1527030447479};\\\", \\\"{x:1282,y:954,t:1527030447496};\\\", \\\"{x:1282,y:953,t:1527030447516};\\\", \\\"{x:1282,y:952,t:1527030447529};\\\", \\\"{x:1282,y:951,t:1527030447545};\\\", \\\"{x:1282,y:947,t:1527030447562};\\\", \\\"{x:1281,y:941,t:1527030447579};\\\", \\\"{x:1280,y:939,t:1527030447595};\\\", \\\"{x:1280,y:938,t:1527030447613};\\\", \\\"{x:1280,y:937,t:1527030447651};\\\", \\\"{x:1280,y:936,t:1527030447663};\\\", \\\"{x:1279,y:931,t:1527030447679};\\\", \\\"{x:1279,y:922,t:1527030447696};\\\", \\\"{x:1279,y:914,t:1527030447713};\\\", \\\"{x:1278,y:909,t:1527030447729};\\\", \\\"{x:1277,y:905,t:1527030447745};\\\", \\\"{x:1277,y:904,t:1527030447763};\\\", \\\"{x:1277,y:902,t:1527030447779};\\\", \\\"{x:1275,y:898,t:1527030447796};\\\", \\\"{x:1274,y:887,t:1527030447813};\\\", \\\"{x:1273,y:880,t:1527030447829};\\\", \\\"{x:1272,y:875,t:1527030447846};\\\", \\\"{x:1272,y:870,t:1527030447863};\\\", \\\"{x:1271,y:869,t:1527030447879};\\\", \\\"{x:1271,y:867,t:1527030447899};\\\", \\\"{x:1271,y:866,t:1527030447916};\\\", \\\"{x:1271,y:864,t:1527030447929};\\\", \\\"{x:1271,y:858,t:1527030447946};\\\", \\\"{x:1271,y:851,t:1527030447963};\\\", \\\"{x:1271,y:847,t:1527030447979};\\\", \\\"{x:1271,y:843,t:1527030447996};\\\", \\\"{x:1271,y:841,t:1527030448035};\\\", \\\"{x:1271,y:838,t:1527030448046};\\\", \\\"{x:1275,y:828,t:1527030448063};\\\", \\\"{x:1276,y:821,t:1527030448079};\\\", \\\"{x:1279,y:814,t:1527030448096};\\\", \\\"{x:1279,y:811,t:1527030448113};\\\", \\\"{x:1280,y:809,t:1527030448129};\\\", \\\"{x:1280,y:808,t:1527030448147};\\\", \\\"{x:1280,y:807,t:1527030448163};\\\", \\\"{x:1280,y:806,t:1527030448179};\\\", \\\"{x:1280,y:797,t:1527030448196};\\\", \\\"{x:1280,y:793,t:1527030448213};\\\", \\\"{x:1280,y:789,t:1527030448229};\\\", \\\"{x:1280,y:787,t:1527030448246};\\\", \\\"{x:1280,y:786,t:1527030448263};\\\", \\\"{x:1280,y:784,t:1527030448279};\\\", \\\"{x:1280,y:781,t:1527030448296};\\\", \\\"{x:1280,y:775,t:1527030448313};\\\", \\\"{x:1280,y:764,t:1527030448329};\\\", \\\"{x:1280,y:750,t:1527030448346};\\\", \\\"{x:1279,y:739,t:1527030448363};\\\", \\\"{x:1278,y:731,t:1527030448379};\\\", \\\"{x:1278,y:727,t:1527030448396};\\\", \\\"{x:1277,y:719,t:1527030448413};\\\", \\\"{x:1271,y:696,t:1527030448429};\\\", \\\"{x:1261,y:675,t:1527030448447};\\\", \\\"{x:1255,y:662,t:1527030448464};\\\", \\\"{x:1252,y:653,t:1527030448479};\\\", \\\"{x:1251,y:649,t:1527030448496};\\\", \\\"{x:1251,y:645,t:1527030448513};\\\", \\\"{x:1251,y:640,t:1527030448529};\\\", \\\"{x:1250,y:638,t:1527030448546};\\\", \\\"{x:1249,y:638,t:1527030448989};\\\", \\\"{x:1249,y:636,t:1527030448996};\\\", \\\"{x:1249,y:625,t:1527030449013};\\\", \\\"{x:1250,y:616,t:1527030449031};\\\", \\\"{x:1251,y:613,t:1527030449047};\\\", \\\"{x:1251,y:609,t:1527030449064};\\\", \\\"{x:1251,y:606,t:1527030449081};\\\", \\\"{x:1252,y:604,t:1527030449096};\\\", \\\"{x:1254,y:596,t:1527030449114};\\\", \\\"{x:1257,y:587,t:1527030449131};\\\", \\\"{x:1260,y:580,t:1527030449146};\\\", \\\"{x:1261,y:578,t:1527030449163};\\\", \\\"{x:1262,y:576,t:1527030449179};\\\", \\\"{x:1263,y:574,t:1527030449203};\\\", \\\"{x:1263,y:573,t:1527030449252};\\\", \\\"{x:1264,y:570,t:1527030449263};\\\", \\\"{x:1265,y:568,t:1527030449280};\\\", \\\"{x:1266,y:567,t:1527030449296};\\\", \\\"{x:1267,y:566,t:1527030449332};\\\", \\\"{x:1268,y:566,t:1527030449356};\\\", \\\"{x:1268,y:564,t:1527030449363};\\\", \\\"{x:1270,y:561,t:1527030449380};\\\", \\\"{x:1273,y:557,t:1527030449396};\\\", \\\"{x:1275,y:555,t:1527030449414};\\\", \\\"{x:1275,y:554,t:1527030449430};\\\", \\\"{x:1276,y:554,t:1527030449447};\\\", \\\"{x:1277,y:553,t:1527030449573};\\\", \\\"{x:1278,y:552,t:1527030449683};\\\", \\\"{x:1279,y:552,t:1527030449716};\\\", \\\"{x:1280,y:550,t:1527030449755};\\\", \\\"{x:1281,y:549,t:1527030449764};\\\", \\\"{x:1288,y:542,t:1527030449780};\\\", \\\"{x:1292,y:538,t:1527030449796};\\\", \\\"{x:1299,y:532,t:1527030449813};\\\", \\\"{x:1300,y:530,t:1527030449830};\\\", \\\"{x:1302,y:529,t:1527030449846};\\\", \\\"{x:1304,y:527,t:1527030449875};\\\", \\\"{x:1306,y:525,t:1527030449891};\\\", \\\"{x:1308,y:523,t:1527030449899};\\\", \\\"{x:1309,y:522,t:1527030449913};\\\", \\\"{x:1315,y:516,t:1527030449930};\\\", \\\"{x:1317,y:514,t:1527030449947};\\\", \\\"{x:1319,y:512,t:1527030449963};\\\", \\\"{x:1320,y:512,t:1527030449980};\\\", \\\"{x:1321,y:512,t:1527030450027};\\\", \\\"{x:1322,y:512,t:1527030450035};\\\", \\\"{x:1324,y:515,t:1527030450052};\\\", \\\"{x:1327,y:519,t:1527030450064};\\\", \\\"{x:1333,y:532,t:1527030450080};\\\", \\\"{x:1337,y:537,t:1527030450097};\\\", \\\"{x:1341,y:542,t:1527030450113};\\\", \\\"{x:1345,y:548,t:1527030450130};\\\", \\\"{x:1348,y:553,t:1527030450147};\\\", \\\"{x:1353,y:563,t:1527030450164};\\\", \\\"{x:1368,y:597,t:1527030450180};\\\", \\\"{x:1386,y:620,t:1527030450197};\\\", \\\"{x:1402,y:644,t:1527030450213};\\\", \\\"{x:1417,y:660,t:1527030450230};\\\", \\\"{x:1425,y:671,t:1527030450247};\\\", \\\"{x:1432,y:685,t:1527030450263};\\\", \\\"{x:1448,y:712,t:1527030450280};\\\", \\\"{x:1473,y:744,t:1527030450297};\\\", \\\"{x:1494,y:769,t:1527030450313};\\\", \\\"{x:1510,y:787,t:1527030450330};\\\", \\\"{x:1523,y:801,t:1527030450347};\\\", \\\"{x:1533,y:814,t:1527030450364};\\\", \\\"{x:1544,y:832,t:1527030450380};\\\", \\\"{x:1546,y:842,t:1527030450398};\\\", \\\"{x:1546,y:850,t:1527030450413};\\\", \\\"{x:1546,y:859,t:1527030450430};\\\", \\\"{x:1546,y:870,t:1527030450447};\\\", \\\"{x:1546,y:881,t:1527030450463};\\\", \\\"{x:1546,y:890,t:1527030450480};\\\", \\\"{x:1544,y:893,t:1527030450498};\\\", \\\"{x:1544,y:894,t:1527030450513};\\\", \\\"{x:1544,y:895,t:1527030450530};\\\", \\\"{x:1544,y:896,t:1527030450547};\\\", \\\"{x:1544,y:903,t:1527030450564};\\\", \\\"{x:1544,y:915,t:1527030450580};\\\", \\\"{x:1546,y:921,t:1527030450597};\\\", \\\"{x:1548,y:924,t:1527030450613};\\\", \\\"{x:1548,y:925,t:1527030450630};\\\", \\\"{x:1548,y:926,t:1527030450647};\\\", \\\"{x:1549,y:932,t:1527030450663};\\\", \\\"{x:1552,y:938,t:1527030450680};\\\", \\\"{x:1554,y:942,t:1527030450697};\\\", \\\"{x:1555,y:945,t:1527030450713};\\\", \\\"{x:1555,y:946,t:1527030450915};\\\", \\\"{x:1554,y:947,t:1527030450980};\\\", \\\"{x:1553,y:947,t:1527030450995};\\\", \\\"{x:1553,y:948,t:1527030451003};\\\", \\\"{x:1552,y:948,t:1527030451014};\\\", \\\"{x:1550,y:948,t:1527030451030};\\\", \\\"{x:1549,y:948,t:1527030451172};\\\", \\\"{x:1548,y:948,t:1527030451187};\\\", \\\"{x:1547,y:948,t:1527030451197};\\\", \\\"{x:1547,y:947,t:1527030451235};\\\", \\\"{x:1546,y:946,t:1527030451248};\\\", \\\"{x:1546,y:945,t:1527030451264};\\\", \\\"{x:1546,y:944,t:1527030451499};\\\", \\\"{x:1546,y:941,t:1527030451514};\\\", \\\"{x:1546,y:931,t:1527030451530};\\\", \\\"{x:1546,y:915,t:1527030451546};\\\", \\\"{x:1540,y:880,t:1527030451564};\\\", \\\"{x:1523,y:821,t:1527030451580};\\\", \\\"{x:1502,y:754,t:1527030451597};\\\", \\\"{x:1479,y:689,t:1527030451614};\\\", \\\"{x:1447,y:625,t:1527030451630};\\\", \\\"{x:1420,y:583,t:1527030451647};\\\", \\\"{x:1396,y:547,t:1527030451664};\\\", \\\"{x:1375,y:522,t:1527030451680};\\\", \\\"{x:1357,y:502,t:1527030451697};\\\", \\\"{x:1342,y:487,t:1527030451713};\\\", \\\"{x:1327,y:474,t:1527030451730};\\\", \\\"{x:1311,y:461,t:1527030451747};\\\", \\\"{x:1295,y:447,t:1527030451764};\\\", \\\"{x:1291,y:443,t:1527030451780};\\\", \\\"{x:1290,y:442,t:1527030451851};\\\", \\\"{x:1292,y:443,t:1527030451916};\\\", \\\"{x:1295,y:448,t:1527030451930};\\\", \\\"{x:1306,y:462,t:1527030451947};\\\", \\\"{x:1315,y:478,t:1527030451964};\\\", \\\"{x:1317,y:482,t:1527030451979};\\\", \\\"{x:1320,y:491,t:1527030451997};\\\", \\\"{x:1321,y:505,t:1527030452013};\\\", \\\"{x:1328,y:530,t:1527030452030};\\\", \\\"{x:1338,y:560,t:1527030452048};\\\", \\\"{x:1344,y:586,t:1527030452064};\\\", \\\"{x:1348,y:602,t:1527030452080};\\\", \\\"{x:1348,y:608,t:1527030452097};\\\", \\\"{x:1346,y:616,t:1527030452114};\\\", \\\"{x:1342,y:622,t:1527030452131};\\\", \\\"{x:1342,y:623,t:1527030452147};\\\", \\\"{x:1340,y:627,t:1527030452164};\\\", \\\"{x:1340,y:629,t:1527030452181};\\\", \\\"{x:1340,y:632,t:1527030452197};\\\", \\\"{x:1340,y:636,t:1527030452214};\\\", \\\"{x:1340,y:640,t:1527030452230};\\\", \\\"{x:1339,y:643,t:1527030452247};\\\", \\\"{x:1337,y:644,t:1527030452264};\\\", \\\"{x:1337,y:646,t:1527030452282};\\\", \\\"{x:1337,y:647,t:1527030452297};\\\", \\\"{x:1337,y:648,t:1527030452476};\\\", \\\"{x:1336,y:648,t:1527030452483};\\\", \\\"{x:1334,y:648,t:1527030452497};\\\", \\\"{x:1331,y:645,t:1527030452514};\\\", \\\"{x:1330,y:645,t:1527030452531};\\\", \\\"{x:1329,y:644,t:1527030452547};\\\", \\\"{x:1328,y:642,t:1527030452564};\\\", \\\"{x:1326,y:640,t:1527030452581};\\\", \\\"{x:1324,y:634,t:1527030452597};\\\", \\\"{x:1321,y:628,t:1527030452615};\\\", \\\"{x:1321,y:622,t:1527030452631};\\\", \\\"{x:1320,y:621,t:1527030452647};\\\", \\\"{x:1320,y:620,t:1527030452747};\\\", \\\"{x:1318,y:620,t:1527030452940};\\\", \\\"{x:1316,y:622,t:1527030452947};\\\", \\\"{x:1311,y:628,t:1527030452965};\\\", \\\"{x:1307,y:631,t:1527030452982};\\\", \\\"{x:1302,y:635,t:1527030452997};\\\", \\\"{x:1299,y:639,t:1527030453015};\\\", \\\"{x:1297,y:642,t:1527030453031};\\\", \\\"{x:1295,y:644,t:1527030453047};\\\", \\\"{x:1293,y:646,t:1527030453065};\\\", \\\"{x:1293,y:648,t:1527030453081};\\\", \\\"{x:1293,y:649,t:1527030453100};\\\", \\\"{x:1293,y:650,t:1527030453114};\\\", \\\"{x:1293,y:651,t:1527030453131};\\\", \\\"{x:1297,y:653,t:1527030453147};\\\", \\\"{x:1298,y:655,t:1527030453165};\\\", \\\"{x:1302,y:658,t:1527030453182};\\\", \\\"{x:1306,y:666,t:1527030453198};\\\", \\\"{x:1309,y:670,t:1527030453214};\\\", \\\"{x:1313,y:677,t:1527030453232};\\\", \\\"{x:1314,y:683,t:1527030453247};\\\", \\\"{x:1316,y:686,t:1527030453265};\\\", \\\"{x:1316,y:689,t:1527030453281};\\\", \\\"{x:1316,y:695,t:1527030453297};\\\", \\\"{x:1316,y:705,t:1527030453314};\\\", \\\"{x:1315,y:714,t:1527030453332};\\\", \\\"{x:1311,y:731,t:1527030453348};\\\", \\\"{x:1307,y:738,t:1527030453364};\\\", \\\"{x:1306,y:742,t:1527030453381};\\\", \\\"{x:1305,y:743,t:1527030453397};\\\", \\\"{x:1302,y:746,t:1527030453414};\\\", \\\"{x:1298,y:750,t:1527030453431};\\\", \\\"{x:1286,y:754,t:1527030453448};\\\", \\\"{x:1262,y:762,t:1527030453465};\\\", \\\"{x:1208,y:767,t:1527030453481};\\\", \\\"{x:1111,y:767,t:1527030453498};\\\", \\\"{x:1008,y:767,t:1527030453514};\\\", \\\"{x:902,y:767,t:1527030453531};\\\", \\\"{x:866,y:767,t:1527030453547};\\\", \\\"{x:855,y:766,t:1527030453564};\\\", \\\"{x:851,y:764,t:1527030453581};\\\", \\\"{x:849,y:763,t:1527030453599};\\\", \\\"{x:847,y:762,t:1527030453615};\\\", \\\"{x:845,y:760,t:1527030453631};\\\", \\\"{x:839,y:756,t:1527030453648};\\\", \\\"{x:830,y:748,t:1527030453664};\\\", \\\"{x:819,y:738,t:1527030453682};\\\", \\\"{x:805,y:725,t:1527030453698};\\\", \\\"{x:785,y:711,t:1527030453714};\\\", \\\"{x:765,y:699,t:1527030453731};\\\", \\\"{x:733,y:687,t:1527030453747};\\\", \\\"{x:719,y:683,t:1527030453764};\\\", \\\"{x:701,y:682,t:1527030453781};\\\", \\\"{x:671,y:680,t:1527030453798};\\\", \\\"{x:628,y:675,t:1527030453815};\\\", \\\"{x:608,y:673,t:1527030453831};\\\", \\\"{x:597,y:668,t:1527030453848};\\\", \\\"{x:593,y:665,t:1527030453865};\\\", \\\"{x:591,y:662,t:1527030453882};\\\", \\\"{x:590,y:661,t:1527030453898};\\\", \\\"{x:589,y:659,t:1527030453914};\\\", \\\"{x:586,y:655,t:1527030453929};\\\", \\\"{x:582,y:646,t:1527030453946};\\\", \\\"{x:578,y:635,t:1527030453963};\\\", \\\"{x:575,y:622,t:1527030453979};\\\", \\\"{x:571,y:603,t:1527030453996};\\\", \\\"{x:571,y:594,t:1527030454014};\\\", \\\"{x:571,y:586,t:1527030454029};\\\", \\\"{x:571,y:581,t:1527030454047};\\\", \\\"{x:571,y:572,t:1527030454063};\\\", \\\"{x:572,y:564,t:1527030454080};\\\", \\\"{x:579,y:555,t:1527030454097};\\\", \\\"{x:589,y:546,t:1527030454113};\\\", \\\"{x:596,y:542,t:1527030454130};\\\", \\\"{x:597,y:541,t:1527030454147};\\\", \\\"{x:599,y:540,t:1527030454163};\\\", \\\"{x:601,y:540,t:1527030454244};\\\", \\\"{x:602,y:540,t:1527030454252};\\\", \\\"{x:604,y:540,t:1527030454264};\\\", \\\"{x:610,y:540,t:1527030454281};\\\", \\\"{x:619,y:540,t:1527030454296};\\\", \\\"{x:628,y:543,t:1527030454314};\\\", \\\"{x:634,y:543,t:1527030454331};\\\", \\\"{x:639,y:543,t:1527030454348};\\\", \\\"{x:648,y:543,t:1527030454364};\\\", \\\"{x:655,y:543,t:1527030454380};\\\", \\\"{x:664,y:545,t:1527030454396};\\\", \\\"{x:679,y:549,t:1527030454413};\\\", \\\"{x:699,y:552,t:1527030454431};\\\", \\\"{x:726,y:554,t:1527030454447};\\\", \\\"{x:754,y:555,t:1527030454463};\\\", \\\"{x:780,y:555,t:1527030454481};\\\", \\\"{x:803,y:555,t:1527030454496};\\\", \\\"{x:809,y:555,t:1527030454514};\\\", \\\"{x:811,y:553,t:1527030454564};\\\", \\\"{x:814,y:551,t:1527030454580};\\\", \\\"{x:819,y:546,t:1527030454597};\\\", \\\"{x:831,y:538,t:1527030454614};\\\", \\\"{x:841,y:530,t:1527030454630};\\\", \\\"{x:845,y:527,t:1527030454647};\\\", \\\"{x:842,y:528,t:1527030455100};\\\", \\\"{x:830,y:539,t:1527030455114};\\\", \\\"{x:794,y:562,t:1527030455131};\\\", \\\"{x:754,y:587,t:1527030455148};\\\", \\\"{x:737,y:598,t:1527030455164};\\\", \\\"{x:723,y:605,t:1527030455181};\\\", \\\"{x:718,y:608,t:1527030455197};\\\", \\\"{x:707,y:616,t:1527030455215};\\\", \\\"{x:690,y:629,t:1527030455231};\\\", \\\"{x:669,y:641,t:1527030455247};\\\", \\\"{x:653,y:651,t:1527030455264};\\\", \\\"{x:642,y:657,t:1527030455280};\\\", \\\"{x:635,y:661,t:1527030455297};\\\", \\\"{x:632,y:663,t:1527030455314};\\\", \\\"{x:627,y:667,t:1527030455332};\\\", \\\"{x:620,y:676,t:1527030455348};\\\", \\\"{x:610,y:683,t:1527030455364};\\\", \\\"{x:603,y:689,t:1527030455381};\\\", \\\"{x:599,y:692,t:1527030455397};\\\", \\\"{x:596,y:694,t:1527030455414};\\\", \\\"{x:591,y:698,t:1527030455432};\\\", \\\"{x:584,y:701,t:1527030455447};\\\", \\\"{x:572,y:708,t:1527030455465};\\\", \\\"{x:557,y:718,t:1527030455482};\\\", \\\"{x:545,y:724,t:1527030455498};\\\", \\\"{x:541,y:726,t:1527030455514};\\\", \\\"{x:540,y:727,t:1527030455531};\\\", \\\"{x:540,y:727,t:1527030455964};\\\", \\\"{x:539,y:727,t:1527030456637};\\\", \\\"{x:539,y:726,t:1527030456651};\\\", \\\"{x:539,y:725,t:1527030456665};\\\", \\\"{x:539,y:724,t:1527030456681};\\\", \\\"{x:539,y:723,t:1527030456884};\\\", \\\"{x:539,y:722,t:1527030456900};\\\", \\\"{x:539,y:721,t:1527030456915};\\\", \\\"{x:539,y:720,t:1527030456932};\\\" ] }, { \\\"rt\\\": 9887, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 412671, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:719,t:1527030457836};\\\", \\\"{x:540,y:711,t:1527030457850};\\\", \\\"{x:531,y:689,t:1527030457867};\\\", \\\"{x:523,y:669,t:1527030457882};\\\", \\\"{x:523,y:649,t:1527030457899};\\\", \\\"{x:533,y:591,t:1527030457968};\\\", \\\"{x:533,y:576,t:1527030457982};\\\", \\\"{x:532,y:560,t:1527030457999};\\\", \\\"{x:528,y:548,t:1527030458016};\\\", \\\"{x:526,y:539,t:1527030458033};\\\", \\\"{x:524,y:532,t:1527030458049};\\\", \\\"{x:521,y:523,t:1527030458066};\\\", \\\"{x:518,y:501,t:1527030458084};\\\", \\\"{x:518,y:486,t:1527030458100};\\\", \\\"{x:523,y:468,t:1527030458116};\\\", \\\"{x:536,y:453,t:1527030458133};\\\", \\\"{x:546,y:444,t:1527030458149};\\\", \\\"{x:557,y:438,t:1527030458166};\\\", \\\"{x:561,y:436,t:1527030458183};\\\", \\\"{x:563,y:436,t:1527030458199};\\\", \\\"{x:565,y:434,t:1527030458216};\\\", \\\"{x:572,y:430,t:1527030458233};\\\", \\\"{x:583,y:427,t:1527030458249};\\\", \\\"{x:605,y:419,t:1527030458266};\\\", \\\"{x:668,y:412,t:1527030458283};\\\", \\\"{x:705,y:412,t:1527030458299};\\\", \\\"{x:736,y:420,t:1527030458317};\\\", \\\"{x:757,y:430,t:1527030458334};\\\", \\\"{x:764,y:435,t:1527030458349};\\\", \\\"{x:765,y:435,t:1527030458367};\\\", \\\"{x:766,y:435,t:1527030458388};\\\", \\\"{x:767,y:436,t:1527030458523};\\\", \\\"{x:768,y:438,t:1527030458547};\\\", \\\"{x:769,y:438,t:1527030458563};\\\", \\\"{x:769,y:440,t:1527030458612};\\\", \\\"{x:769,y:441,t:1527030458636};\\\", \\\"{x:769,y:443,t:1527030458668};\\\", \\\"{x:769,y:444,t:1527030458699};\\\", \\\"{x:768,y:445,t:1527030458772};\\\", \\\"{x:768,y:446,t:1527030458819};\\\", \\\"{x:768,y:447,t:1527030459091};\\\", \\\"{x:767,y:447,t:1527030459108};\\\", \\\"{x:767,y:449,t:1527030459219};\\\", \\\"{x:767,y:453,t:1527030459234};\\\", \\\"{x:767,y:458,t:1527030459251};\\\", \\\"{x:767,y:460,t:1527030459268};\\\", \\\"{x:767,y:461,t:1527030459324};\\\", \\\"{x:767,y:462,t:1527030459334};\\\", \\\"{x:767,y:463,t:1527030459350};\\\", \\\"{x:768,y:465,t:1527030459556};\\\", \\\"{x:770,y:466,t:1527030459567};\\\", \\\"{x:773,y:466,t:1527030459584};\\\", \\\"{x:775,y:466,t:1527030459601};\\\", \\\"{x:779,y:466,t:1527030459617};\\\", \\\"{x:780,y:465,t:1527030459634};\\\", \\\"{x:780,y:464,t:1527030459652};\\\", \\\"{x:781,y:464,t:1527030459675};\\\", \\\"{x:782,y:464,t:1527030459691};\\\", \\\"{x:784,y:464,t:1527030459702};\\\", \\\"{x:788,y:464,t:1527030459717};\\\", \\\"{x:791,y:464,t:1527030459734};\\\", \\\"{x:793,y:464,t:1527030459751};\\\", \\\"{x:794,y:464,t:1527030459767};\\\", \\\"{x:795,y:464,t:1527030459784};\\\", \\\"{x:796,y:464,t:1527030459801};\\\", \\\"{x:798,y:464,t:1527030459819};\\\", \\\"{x:799,y:464,t:1527030459836};\\\", \\\"{x:806,y:464,t:1527030459851};\\\", \\\"{x:814,y:464,t:1527030459867};\\\", \\\"{x:819,y:463,t:1527030459884};\\\", \\\"{x:823,y:459,t:1527030459901};\\\", \\\"{x:826,y:452,t:1527030459917};\\\", \\\"{x:827,y:447,t:1527030459935};\\\", \\\"{x:827,y:445,t:1527030459952};\\\", \\\"{x:828,y:444,t:1527030459967};\\\", \\\"{x:830,y:444,t:1527030459984};\\\", \\\"{x:834,y:444,t:1527030460002};\\\", \\\"{x:836,y:445,t:1527030460017};\\\", \\\"{x:837,y:445,t:1527030460035};\\\", \\\"{x:837,y:451,t:1527030460051};\\\", \\\"{x:839,y:468,t:1527030460069};\\\", \\\"{x:848,y:494,t:1527030460085};\\\", \\\"{x:868,y:522,t:1527030460102};\\\", \\\"{x:888,y:537,t:1527030460118};\\\", \\\"{x:912,y:545,t:1527030460134};\\\", \\\"{x:941,y:545,t:1527030460151};\\\", \\\"{x:959,y:539,t:1527030460167};\\\", \\\"{x:960,y:537,t:1527030460184};\\\", \\\"{x:960,y:533,t:1527030460201};\\\", \\\"{x:954,y:532,t:1527030460217};\\\", \\\"{x:950,y:532,t:1527030460235};\\\", \\\"{x:955,y:533,t:1527030460332};\\\", \\\"{x:967,y:538,t:1527030460339};\\\", \\\"{x:985,y:546,t:1527030460352};\\\", \\\"{x:1042,y:566,t:1527030460368};\\\", \\\"{x:1110,y:589,t:1527030460384};\\\", \\\"{x:1154,y:595,t:1527030460401};\\\", \\\"{x:1172,y:596,t:1527030460418};\\\", \\\"{x:1178,y:596,t:1527030460435};\\\", \\\"{x:1180,y:596,t:1527030460451};\\\", \\\"{x:1182,y:596,t:1527030460469};\\\", \\\"{x:1183,y:596,t:1527030460485};\\\", \\\"{x:1185,y:596,t:1527030460516};\\\", \\\"{x:1186,y:595,t:1527030460524};\\\", \\\"{x:1187,y:594,t:1527030460556};\\\", \\\"{x:1187,y:593,t:1527030460579};\\\", \\\"{x:1188,y:593,t:1527030460588};\\\", \\\"{x:1188,y:592,t:1527030460627};\\\", \\\"{x:1188,y:591,t:1527030460651};\\\", \\\"{x:1188,y:590,t:1527030460669};\\\", \\\"{x:1189,y:587,t:1527030460685};\\\", \\\"{x:1192,y:582,t:1527030460701};\\\", \\\"{x:1193,y:580,t:1527030460719};\\\", \\\"{x:1193,y:578,t:1527030460734};\\\", \\\"{x:1194,y:575,t:1527030460752};\\\", \\\"{x:1195,y:574,t:1527030460771};\\\", \\\"{x:1195,y:573,t:1527030460795};\\\", \\\"{x:1196,y:572,t:1527030460812};\\\", \\\"{x:1197,y:571,t:1527030461044};\\\", \\\"{x:1198,y:571,t:1527030461083};\\\", \\\"{x:1199,y:571,t:1527030461091};\\\", \\\"{x:1201,y:571,t:1527030461102};\\\", \\\"{x:1212,y:571,t:1527030461119};\\\", \\\"{x:1235,y:571,t:1527030461135};\\\", \\\"{x:1271,y:571,t:1527030461152};\\\", \\\"{x:1324,y:571,t:1527030461169};\\\", \\\"{x:1367,y:568,t:1527030461185};\\\", \\\"{x:1388,y:567,t:1527030461202};\\\", \\\"{x:1395,y:566,t:1527030461219};\\\", \\\"{x:1396,y:565,t:1527030461236};\\\", \\\"{x:1398,y:565,t:1527030461251};\\\", \\\"{x:1414,y:565,t:1527030461270};\\\", \\\"{x:1441,y:565,t:1527030461287};\\\", \\\"{x:1464,y:565,t:1527030461301};\\\", \\\"{x:1479,y:567,t:1527030461318};\\\", \\\"{x:1481,y:567,t:1527030461335};\\\", \\\"{x:1482,y:567,t:1527030461412};\\\", \\\"{x:1483,y:567,t:1527030461628};\\\", \\\"{x:1484,y:567,t:1527030461635};\\\", \\\"{x:1487,y:567,t:1527030461653};\\\", \\\"{x:1489,y:567,t:1527030461669};\\\", \\\"{x:1492,y:567,t:1527030461685};\\\", \\\"{x:1494,y:567,t:1527030461724};\\\", \\\"{x:1497,y:567,t:1527030461736};\\\", \\\"{x:1519,y:570,t:1527030461753};\\\", \\\"{x:1581,y:578,t:1527030461769};\\\", \\\"{x:1675,y:589,t:1527030461785};\\\", \\\"{x:1758,y:589,t:1527030461803};\\\", \\\"{x:1817,y:589,t:1527030461819};\\\", \\\"{x:1848,y:588,t:1527030461836};\\\", \\\"{x:1851,y:587,t:1527030461853};\\\", \\\"{x:1852,y:586,t:1527030461869};\\\", \\\"{x:1851,y:586,t:1527030462125};\\\", \\\"{x:1850,y:586,t:1527030462136};\\\", \\\"{x:1849,y:586,t:1527030462153};\\\", \\\"{x:1847,y:587,t:1527030462169};\\\", \\\"{x:1847,y:588,t:1527030462186};\\\", \\\"{x:1846,y:588,t:1527030462202};\\\", \\\"{x:1844,y:588,t:1527030462219};\\\", \\\"{x:1843,y:588,t:1527030462235};\\\", \\\"{x:1841,y:588,t:1527030462253};\\\", \\\"{x:1839,y:589,t:1527030462270};\\\", \\\"{x:1838,y:589,t:1527030462286};\\\", \\\"{x:1836,y:589,t:1527030462316};\\\", \\\"{x:1835,y:589,t:1527030462324};\\\", \\\"{x:1832,y:589,t:1527030462347};\\\", \\\"{x:1829,y:589,t:1527030462355};\\\", \\\"{x:1827,y:589,t:1527030462370};\\\", \\\"{x:1818,y:589,t:1527030462386};\\\", \\\"{x:1807,y:589,t:1527030462403};\\\", \\\"{x:1788,y:589,t:1527030462420};\\\", \\\"{x:1770,y:589,t:1527030462436};\\\", \\\"{x:1748,y:589,t:1527030462452};\\\", \\\"{x:1715,y:589,t:1527030462469};\\\", \\\"{x:1667,y:589,t:1527030462486};\\\", \\\"{x:1601,y:589,t:1527030462503};\\\", \\\"{x:1525,y:589,t:1527030462520};\\\", \\\"{x:1465,y:594,t:1527030462535};\\\", \\\"{x:1433,y:605,t:1527030462553};\\\", \\\"{x:1411,y:617,t:1527030462570};\\\", \\\"{x:1395,y:623,t:1527030462586};\\\", \\\"{x:1378,y:631,t:1527030462603};\\\", \\\"{x:1367,y:631,t:1527030462619};\\\", \\\"{x:1356,y:630,t:1527030462636};\\\", \\\"{x:1343,y:626,t:1527030462652};\\\", \\\"{x:1333,y:625,t:1527030462670};\\\", \\\"{x:1316,y:624,t:1527030462685};\\\", \\\"{x:1291,y:624,t:1527030462702};\\\", \\\"{x:1264,y:624,t:1527030462720};\\\", \\\"{x:1231,y:624,t:1527030462736};\\\", \\\"{x:1169,y:624,t:1527030462753};\\\", \\\"{x:1094,y:624,t:1527030462770};\\\", \\\"{x:1019,y:623,t:1527030462786};\\\", \\\"{x:943,y:610,t:1527030462803};\\\", \\\"{x:811,y:591,t:1527030462820};\\\", \\\"{x:727,y:588,t:1527030462836};\\\", \\\"{x:639,y:580,t:1527030462854};\\\", \\\"{x:572,y:580,t:1527030462871};\\\", \\\"{x:499,y:577,t:1527030462887};\\\", \\\"{x:407,y:563,t:1527030462904};\\\", \\\"{x:350,y:558,t:1527030462921};\\\", \\\"{x:314,y:552,t:1527030462937};\\\", \\\"{x:301,y:549,t:1527030462954};\\\", \\\"{x:300,y:547,t:1527030462970};\\\", \\\"{x:300,y:541,t:1527030462987};\\\", \\\"{x:295,y:523,t:1527030463003};\\\", \\\"{x:288,y:515,t:1527030463021};\\\", \\\"{x:287,y:513,t:1527030463037};\\\", \\\"{x:286,y:512,t:1527030463054};\\\", \\\"{x:286,y:509,t:1527030463071};\\\", \\\"{x:286,y:504,t:1527030463087};\\\", \\\"{x:289,y:499,t:1527030463104};\\\", \\\"{x:291,y:496,t:1527030463121};\\\", \\\"{x:295,y:491,t:1527030463136};\\\", \\\"{x:301,y:488,t:1527030463153};\\\", \\\"{x:312,y:484,t:1527030463171};\\\", \\\"{x:319,y:484,t:1527030463186};\\\", \\\"{x:336,y:487,t:1527030463204};\\\", \\\"{x:343,y:492,t:1527030463220};\\\", \\\"{x:344,y:492,t:1527030463275};\\\", \\\"{x:349,y:492,t:1527030463287};\\\", \\\"{x:364,y:492,t:1527030463304};\\\", \\\"{x:380,y:493,t:1527030463320};\\\", \\\"{x:400,y:496,t:1527030463338};\\\", \\\"{x:409,y:497,t:1527030463353};\\\", \\\"{x:410,y:497,t:1527030463370};\\\", \\\"{x:418,y:496,t:1527030463387};\\\", \\\"{x:446,y:495,t:1527030463405};\\\", \\\"{x:532,y:495,t:1527030463421};\\\", \\\"{x:642,y:504,t:1527030463438};\\\", \\\"{x:706,y:504,t:1527030463454};\\\", \\\"{x:719,y:504,t:1527030463470};\\\", \\\"{x:720,y:504,t:1527030463488};\\\", \\\"{x:718,y:503,t:1527030463580};\\\", \\\"{x:716,y:501,t:1527030463587};\\\", \\\"{x:712,y:498,t:1527030463604};\\\", \\\"{x:709,y:496,t:1527030463621};\\\", \\\"{x:705,y:494,t:1527030463638};\\\", \\\"{x:704,y:494,t:1527030463654};\\\", \\\"{x:701,y:494,t:1527030463671};\\\", \\\"{x:698,y:494,t:1527030463687};\\\", \\\"{x:690,y:495,t:1527030463705};\\\", \\\"{x:674,y:496,t:1527030463721};\\\", \\\"{x:651,y:496,t:1527030463737};\\\", \\\"{x:638,y:496,t:1527030463755};\\\", \\\"{x:635,y:497,t:1527030463770};\\\", \\\"{x:634,y:497,t:1527030463795};\\\", \\\"{x:633,y:497,t:1527030463805};\\\", \\\"{x:632,y:497,t:1527030463820};\\\", \\\"{x:631,y:497,t:1527030463956};\\\", \\\"{x:627,y:497,t:1527030464043};\\\", \\\"{x:625,y:499,t:1527030464055};\\\", \\\"{x:620,y:501,t:1527030464072};\\\", \\\"{x:616,y:503,t:1527030464088};\\\", \\\"{x:615,y:504,t:1527030464105};\\\", \\\"{x:614,y:504,t:1527030464122};\\\", \\\"{x:614,y:505,t:1527030464363};\\\", \\\"{x:612,y:507,t:1527030464372};\\\", \\\"{x:598,y:520,t:1527030464388};\\\", \\\"{x:577,y:534,t:1527030464404};\\\", \\\"{x:547,y:548,t:1527030464421};\\\", \\\"{x:502,y:561,t:1527030464439};\\\", \\\"{x:462,y:568,t:1527030464455};\\\", \\\"{x:425,y:573,t:1527030464472};\\\", \\\"{x:393,y:576,t:1527030464489};\\\", \\\"{x:370,y:580,t:1527030464505};\\\", \\\"{x:356,y:584,t:1527030464522};\\\", \\\"{x:352,y:586,t:1527030464538};\\\", \\\"{x:347,y:589,t:1527030464554};\\\", \\\"{x:345,y:589,t:1527030464571};\\\", \\\"{x:344,y:589,t:1527030464603};\\\", \\\"{x:345,y:587,t:1527030464652};\\\", \\\"{x:347,y:585,t:1527030464660};\\\", \\\"{x:348,y:585,t:1527030464672};\\\", \\\"{x:349,y:584,t:1527030464688};\\\", \\\"{x:350,y:583,t:1527030464706};\\\", \\\"{x:351,y:583,t:1527030464721};\\\", \\\"{x:354,y:583,t:1527030464738};\\\", \\\"{x:370,y:583,t:1527030464755};\\\", \\\"{x:379,y:583,t:1527030464773};\\\", \\\"{x:381,y:583,t:1527030464789};\\\", \\\"{x:383,y:583,t:1527030464805};\\\", \\\"{x:384,y:583,t:1527030464836};\\\", \\\"{x:386,y:583,t:1527030464851};\\\", \\\"{x:389,y:584,t:1527030464859};\\\", \\\"{x:392,y:585,t:1527030464871};\\\", \\\"{x:395,y:586,t:1527030464888};\\\", \\\"{x:396,y:586,t:1527030464905};\\\", \\\"{x:399,y:586,t:1527030464920};\\\", \\\"{x:399,y:585,t:1527030464938};\\\", \\\"{x:400,y:585,t:1527030464954};\\\", \\\"{x:401,y:585,t:1527030464987};\\\", \\\"{x:402,y:585,t:1527030465003};\\\", \\\"{x:403,y:585,t:1527030465027};\\\", \\\"{x:403,y:586,t:1527030465092};\\\", \\\"{x:402,y:588,t:1527030465107};\\\", \\\"{x:400,y:590,t:1527030465121};\\\", \\\"{x:396,y:594,t:1527030465139};\\\", \\\"{x:392,y:599,t:1527030465155};\\\", \\\"{x:390,y:601,t:1527030465172};\\\", \\\"{x:388,y:604,t:1527030465189};\\\", \\\"{x:388,y:605,t:1527030465206};\\\", \\\"{x:389,y:606,t:1527030465260};\\\", \\\"{x:391,y:606,t:1527030465271};\\\", \\\"{x:408,y:606,t:1527030465289};\\\", \\\"{x:431,y:606,t:1527030465306};\\\", \\\"{x:461,y:601,t:1527030465322};\\\", \\\"{x:490,y:596,t:1527030465339};\\\", \\\"{x:518,y:589,t:1527030465356};\\\", \\\"{x:541,y:581,t:1527030465372};\\\", \\\"{x:571,y:575,t:1527030465389};\\\", \\\"{x:617,y:566,t:1527030465406};\\\", \\\"{x:653,y:557,t:1527030465423};\\\", \\\"{x:679,y:548,t:1527030465439};\\\", \\\"{x:698,y:542,t:1527030465455};\\\", \\\"{x:715,y:536,t:1527030465473};\\\", \\\"{x:731,y:535,t:1527030465490};\\\", \\\"{x:746,y:535,t:1527030465505};\\\", \\\"{x:759,y:535,t:1527030465521};\\\", \\\"{x:774,y:535,t:1527030465538};\\\", \\\"{x:799,y:535,t:1527030465556};\\\", \\\"{x:818,y:540,t:1527030465572};\\\", \\\"{x:835,y:549,t:1527030465588};\\\", \\\"{x:851,y:558,t:1527030465606};\\\", \\\"{x:869,y:567,t:1527030465623};\\\", \\\"{x:878,y:572,t:1527030465639};\\\", \\\"{x:879,y:572,t:1527030465655};\\\", \\\"{x:881,y:572,t:1527030465715};\\\", \\\"{x:882,y:571,t:1527030465731};\\\", \\\"{x:882,y:568,t:1527030465739};\\\", \\\"{x:884,y:563,t:1527030465755};\\\", \\\"{x:884,y:561,t:1527030465773};\\\", \\\"{x:884,y:559,t:1527030465790};\\\", \\\"{x:882,y:554,t:1527030465806};\\\", \\\"{x:878,y:552,t:1527030465823};\\\", \\\"{x:877,y:551,t:1527030465891};\\\", \\\"{x:876,y:551,t:1527030465905};\\\", \\\"{x:873,y:551,t:1527030465923};\\\", \\\"{x:866,y:551,t:1527030465939};\\\", \\\"{x:863,y:551,t:1527030465956};\\\", \\\"{x:861,y:551,t:1527030465972};\\\", \\\"{x:858,y:549,t:1527030466012};\\\", \\\"{x:855,y:548,t:1527030466023};\\\", \\\"{x:851,y:544,t:1527030466040};\\\", \\\"{x:844,y:540,t:1527030466056};\\\", \\\"{x:838,y:536,t:1527030466072};\\\", \\\"{x:834,y:535,t:1527030466115};\\\", \\\"{x:835,y:534,t:1527030466251};\\\", \\\"{x:835,y:534,t:1527030466345};\\\", \\\"{x:834,y:535,t:1527030466403};\\\", \\\"{x:825,y:541,t:1527030466412};\\\", \\\"{x:818,y:546,t:1527030466423};\\\", \\\"{x:793,y:557,t:1527030466440};\\\", \\\"{x:751,y:570,t:1527030466457};\\\", \\\"{x:695,y:587,t:1527030466474};\\\", \\\"{x:645,y:609,t:1527030466491};\\\", \\\"{x:590,y:633,t:1527030466507};\\\", \\\"{x:537,y:656,t:1527030466522};\\\", \\\"{x:486,y:679,t:1527030466540};\\\", \\\"{x:472,y:689,t:1527030466557};\\\", \\\"{x:466,y:697,t:1527030466574};\\\", \\\"{x:464,y:701,t:1527030466590};\\\", \\\"{x:463,y:705,t:1527030466606};\\\", \\\"{x:463,y:710,t:1527030466624};\\\", \\\"{x:463,y:723,t:1527030466640};\\\", \\\"{x:463,y:738,t:1527030466657};\\\", \\\"{x:462,y:751,t:1527030466673};\\\", \\\"{x:459,y:757,t:1527030466691};\\\", \\\"{x:459,y:758,t:1527030466710};\\\", \\\"{x:458,y:758,t:1527030466747};\\\", \\\"{x:458,y:756,t:1527030466891};\\\", \\\"{x:459,y:756,t:1527030466907};\\\", \\\"{x:460,y:754,t:1527030466924};\\\", \\\"{x:461,y:753,t:1527030466939};\\\", \\\"{x:461,y:752,t:1527030466957};\\\", \\\"{x:463,y:752,t:1527030466974};\\\", \\\"{x:464,y:750,t:1527030466991};\\\", \\\"{x:467,y:749,t:1527030467006};\\\", \\\"{x:469,y:748,t:1527030467024};\\\", \\\"{x:469,y:745,t:1527030467979};\\\", \\\"{x:469,y:742,t:1527030467991};\\\", \\\"{x:469,y:736,t:1527030468008};\\\", \\\"{x:469,y:730,t:1527030468024};\\\", \\\"{x:466,y:724,t:1527030468041};\\\", \\\"{x:465,y:722,t:1527030468058};\\\", \\\"{x:465,y:721,t:1527030468084};\\\", \\\"{x:464,y:720,t:1527030468115};\\\", \\\"{x:464,y:717,t:1527030468139};\\\", \\\"{x:463,y:716,t:1527030468155};\\\", \\\"{x:463,y:714,t:1527030468196};\\\", \\\"{x:463,y:713,t:1527030468211};\\\", \\\"{x:463,y:711,t:1527030468227};\\\", \\\"{x:463,y:710,t:1527030468243};\\\", \\\"{x:462,y:707,t:1527030468257};\\\", \\\"{x:462,y:704,t:1527030468274};\\\", \\\"{x:462,y:703,t:1527030468291};\\\", \\\"{x:460,y:700,t:1527030468351};\\\" ] }, { \\\"rt\\\": 19045, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 433523, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:475,y:682,t:1527030469102};\\\", \\\"{x:481,y:685,t:1527030469111};\\\", \\\"{x:487,y:696,t:1527030469125};\\\", \\\"{x:489,y:701,t:1527030469142};\\\", \\\"{x:489,y:703,t:1527030469158};\\\", \\\"{x:489,y:705,t:1527030469184};\\\", \\\"{x:489,y:706,t:1527030469195};\\\", \\\"{x:487,y:708,t:1527030469219};\\\", \\\"{x:486,y:709,t:1527030469443};\\\", \\\"{x:486,y:710,t:1527030469459};\\\", \\\"{x:486,y:715,t:1527030469476};\\\", \\\"{x:486,y:719,t:1527030469492};\\\", \\\"{x:486,y:721,t:1527030469509};\\\", \\\"{x:487,y:723,t:1527030469526};\\\", \\\"{x:488,y:723,t:1527030469541};\\\", \\\"{x:492,y:725,t:1527030469559};\\\", \\\"{x:497,y:727,t:1527030469575};\\\", \\\"{x:506,y:729,t:1527030469591};\\\", \\\"{x:552,y:711,t:1527030469685};\\\", \\\"{x:555,y:711,t:1527030469694};\\\", \\\"{x:561,y:707,t:1527030469710};\\\", \\\"{x:567,y:704,t:1527030469726};\\\", \\\"{x:577,y:698,t:1527030469743};\\\", \\\"{x:583,y:695,t:1527030469758};\\\", \\\"{x:586,y:694,t:1527030469776};\\\", \\\"{x:588,y:693,t:1527030469792};\\\", \\\"{x:589,y:693,t:1527030469811};\\\", \\\"{x:590,y:693,t:1527030469924};\\\", \\\"{x:590,y:695,t:1527030469931};\\\", \\\"{x:591,y:695,t:1527030470091};\\\", \\\"{x:593,y:695,t:1527030470140};\\\", \\\"{x:593,y:694,t:1527030470155};\\\", \\\"{x:595,y:692,t:1527030470172};\\\", \\\"{x:595,y:691,t:1527030470187};\\\", \\\"{x:596,y:689,t:1527030470220};\\\", \\\"{x:596,y:690,t:1527030470516};\\\", \\\"{x:596,y:691,t:1527030470526};\\\", \\\"{x:596,y:692,t:1527030470660};\\\", \\\"{x:594,y:692,t:1527030470677};\\\", \\\"{x:586,y:686,t:1527030470693};\\\", \\\"{x:572,y:676,t:1527030470710};\\\", \\\"{x:557,y:666,t:1527030470727};\\\", \\\"{x:541,y:655,t:1527030470743};\\\", \\\"{x:513,y:634,t:1527030470760};\\\", \\\"{x:470,y:604,t:1527030470777};\\\", \\\"{x:430,y:573,t:1527030470794};\\\", \\\"{x:398,y:550,t:1527030470810};\\\", \\\"{x:379,y:527,t:1527030470827};\\\", \\\"{x:369,y:514,t:1527030470843};\\\", \\\"{x:360,y:502,t:1527030470859};\\\", \\\"{x:360,y:500,t:1527030470877};\\\", \\\"{x:359,y:498,t:1527030470894};\\\", \\\"{x:358,y:498,t:1527030471139};\\\", \\\"{x:357,y:499,t:1527030471427};\\\", \\\"{x:354,y:502,t:1527030471445};\\\", \\\"{x:351,y:507,t:1527030471462};\\\", \\\"{x:353,y:507,t:1527030472499};\\\", \\\"{x:354,y:507,t:1527030472514};\\\", \\\"{x:357,y:507,t:1527030472531};\\\", \\\"{x:359,y:505,t:1527030472547};\\\", \\\"{x:361,y:505,t:1527030472564};\\\", \\\"{x:363,y:504,t:1527030472581};\\\", \\\"{x:364,y:503,t:1527030472599};\\\", \\\"{x:366,y:502,t:1527030472614};\\\", \\\"{x:368,y:501,t:1527030472631};\\\", \\\"{x:369,y:499,t:1527030472648};\\\", \\\"{x:372,y:496,t:1527030472665};\\\", \\\"{x:375,y:494,t:1527030472682};\\\", \\\"{x:376,y:492,t:1527030472700};\\\", \\\"{x:379,y:490,t:1527030472715};\\\", \\\"{x:381,y:489,t:1527030472731};\\\", \\\"{x:383,y:489,t:1527030472743};\\\", \\\"{x:387,y:487,t:1527030472760};\\\", \\\"{x:391,y:486,t:1527030472777};\\\", \\\"{x:392,y:486,t:1527030472793};\\\", \\\"{x:394,y:486,t:1527030472868};\\\", \\\"{x:395,y:486,t:1527030472878};\\\", \\\"{x:397,y:486,t:1527030472895};\\\", \\\"{x:398,y:486,t:1527030472915};\\\", \\\"{x:399,y:486,t:1527030472928};\\\", \\\"{x:401,y:486,t:1527030472945};\\\", \\\"{x:405,y:486,t:1527030472962};\\\", \\\"{x:413,y:486,t:1527030472978};\\\", \\\"{x:431,y:486,t:1527030472995};\\\", \\\"{x:445,y:486,t:1527030473012};\\\", \\\"{x:456,y:486,t:1527030473028};\\\", \\\"{x:468,y:486,t:1527030473045};\\\", \\\"{x:478,y:486,t:1527030473061};\\\", \\\"{x:483,y:486,t:1527030473078};\\\", \\\"{x:492,y:483,t:1527030473095};\\\", \\\"{x:501,y:481,t:1527030473111};\\\", \\\"{x:512,y:478,t:1527030473128};\\\", \\\"{x:526,y:477,t:1527030473146};\\\", \\\"{x:537,y:476,t:1527030473161};\\\", \\\"{x:541,y:474,t:1527030473178};\\\", \\\"{x:546,y:472,t:1527030473195};\\\", \\\"{x:561,y:471,t:1527030473212};\\\", \\\"{x:576,y:468,t:1527030473229};\\\", \\\"{x:592,y:466,t:1527030473245};\\\", \\\"{x:601,y:462,t:1527030473261};\\\", \\\"{x:608,y:460,t:1527030473279};\\\", \\\"{x:612,y:459,t:1527030473295};\\\", \\\"{x:616,y:458,t:1527030473312};\\\", \\\"{x:617,y:457,t:1527030473332};\\\", \\\"{x:618,y:457,t:1527030473355};\\\", \\\"{x:618,y:456,t:1527030473388};\\\", \\\"{x:619,y:456,t:1527030473404};\\\", \\\"{x:620,y:455,t:1527030473411};\\\", \\\"{x:621,y:455,t:1527030473428};\\\", \\\"{x:622,y:455,t:1527030473445};\\\", \\\"{x:624,y:455,t:1527030473476};\\\", \\\"{x:626,y:455,t:1527030473492};\\\", \\\"{x:628,y:455,t:1527030473500};\\\", \\\"{x:630,y:455,t:1527030473511};\\\", \\\"{x:637,y:455,t:1527030473528};\\\", \\\"{x:651,y:455,t:1527030473545};\\\", \\\"{x:667,y:455,t:1527030473561};\\\", \\\"{x:688,y:455,t:1527030473579};\\\", \\\"{x:720,y:455,t:1527030473596};\\\", \\\"{x:742,y:455,t:1527030473612};\\\", \\\"{x:769,y:455,t:1527030473628};\\\", \\\"{x:807,y:464,t:1527030473646};\\\", \\\"{x:846,y:474,t:1527030473661};\\\", \\\"{x:912,y:493,t:1527030473680};\\\", \\\"{x:987,y:515,t:1527030473696};\\\", \\\"{x:1056,y:542,t:1527030473712};\\\", \\\"{x:1123,y:573,t:1527030473729};\\\", \\\"{x:1178,y:609,t:1527030473746};\\\", \\\"{x:1220,y:654,t:1527030473762};\\\", \\\"{x:1261,y:737,t:1527030473780};\\\", \\\"{x:1280,y:770,t:1527030473795};\\\", \\\"{x:1292,y:789,t:1527030473812};\\\", \\\"{x:1293,y:797,t:1527030473830};\\\", \\\"{x:1293,y:799,t:1527030473846};\\\", \\\"{x:1293,y:800,t:1527030473862};\\\", \\\"{x:1293,y:801,t:1527030473892};\\\", \\\"{x:1293,y:802,t:1527030473900};\\\", \\\"{x:1294,y:803,t:1527030473913};\\\", \\\"{x:1296,y:805,t:1527030473935};\\\", \\\"{x:1298,y:807,t:1527030473953};\\\", \\\"{x:1299,y:807,t:1527030473977};\\\", \\\"{x:1301,y:807,t:1527030474009};\\\", \\\"{x:1302,y:807,t:1527030474042};\\\", \\\"{x:1302,y:806,t:1527030474057};\\\", \\\"{x:1301,y:805,t:1527030474069};\\\", \\\"{x:1298,y:803,t:1527030474085};\\\", \\\"{x:1294,y:802,t:1527030474102};\\\", \\\"{x:1288,y:801,t:1527030474118};\\\", \\\"{x:1283,y:800,t:1527030474135};\\\", \\\"{x:1277,y:800,t:1527030474152};\\\", \\\"{x:1274,y:800,t:1527030474168};\\\", \\\"{x:1270,y:800,t:1527030474185};\\\", \\\"{x:1262,y:802,t:1527030474202};\\\", \\\"{x:1259,y:802,t:1527030474219};\\\", \\\"{x:1257,y:802,t:1527030474235};\\\", \\\"{x:1254,y:802,t:1527030474253};\\\", \\\"{x:1252,y:802,t:1527030474269};\\\", \\\"{x:1251,y:802,t:1527030474285};\\\", \\\"{x:1249,y:802,t:1527030474303};\\\", \\\"{x:1247,y:802,t:1527030474318};\\\", \\\"{x:1246,y:802,t:1527030474337};\\\", \\\"{x:1245,y:802,t:1527030474402};\\\", \\\"{x:1242,y:799,t:1527030474475};\\\", \\\"{x:1241,y:798,t:1527030474485};\\\", \\\"{x:1236,y:792,t:1527030474502};\\\", \\\"{x:1228,y:782,t:1527030474520};\\\", \\\"{x:1220,y:775,t:1527030474535};\\\", \\\"{x:1208,y:765,t:1527030474553};\\\", \\\"{x:1188,y:747,t:1527030474570};\\\", \\\"{x:1169,y:734,t:1527030474586};\\\", \\\"{x:1154,y:723,t:1527030474603};\\\", \\\"{x:1142,y:714,t:1527030474619};\\\", \\\"{x:1136,y:709,t:1527030474636};\\\", \\\"{x:1134,y:707,t:1527030474653};\\\", \\\"{x:1132,y:706,t:1527030474669};\\\", \\\"{x:1129,y:706,t:1527030474685};\\\", \\\"{x:1127,y:706,t:1527030474702};\\\", \\\"{x:1126,y:706,t:1527030474719};\\\", \\\"{x:1125,y:706,t:1527030474754};\\\", \\\"{x:1124,y:706,t:1527030474769};\\\", \\\"{x:1123,y:706,t:1527030474835};\\\", \\\"{x:1121,y:705,t:1527030474852};\\\", \\\"{x:1120,y:697,t:1527030474870};\\\", \\\"{x:1120,y:690,t:1527030474885};\\\", \\\"{x:1120,y:684,t:1527030474902};\\\", \\\"{x:1124,y:679,t:1527030474920};\\\", \\\"{x:1130,y:676,t:1527030474935};\\\", \\\"{x:1141,y:671,t:1527030474953};\\\", \\\"{x:1151,y:668,t:1527030474970};\\\", \\\"{x:1169,y:661,t:1527030474986};\\\", \\\"{x:1182,y:656,t:1527030475003};\\\", \\\"{x:1196,y:653,t:1527030475019};\\\", \\\"{x:1205,y:650,t:1527030475037};\\\", \\\"{x:1213,y:650,t:1527030475052};\\\", \\\"{x:1221,y:650,t:1527030475069};\\\", \\\"{x:1230,y:650,t:1527030475087};\\\", \\\"{x:1247,y:650,t:1527030475103};\\\", \\\"{x:1264,y:650,t:1527030475119};\\\", \\\"{x:1281,y:648,t:1527030475137};\\\", \\\"{x:1293,y:645,t:1527030475153};\\\", \\\"{x:1301,y:643,t:1527030475170};\\\", \\\"{x:1304,y:641,t:1527030475186};\\\", \\\"{x:1308,y:640,t:1527030475218};\\\", \\\"{x:1311,y:640,t:1527030475226};\\\", \\\"{x:1314,y:639,t:1527030475237};\\\", \\\"{x:1324,y:636,t:1527030475252};\\\", \\\"{x:1331,y:633,t:1527030475269};\\\", \\\"{x:1338,y:630,t:1527030475287};\\\", \\\"{x:1341,y:629,t:1527030475303};\\\", \\\"{x:1346,y:628,t:1527030475320};\\\", \\\"{x:1354,y:627,t:1527030475337};\\\", \\\"{x:1371,y:627,t:1527030475352};\\\", \\\"{x:1397,y:627,t:1527030475370};\\\", \\\"{x:1406,y:625,t:1527030475386};\\\", \\\"{x:1409,y:624,t:1527030475403};\\\", \\\"{x:1412,y:624,t:1527030475419};\\\", \\\"{x:1415,y:624,t:1527030475436};\\\", \\\"{x:1418,y:623,t:1527030475452};\\\", \\\"{x:1419,y:623,t:1527030475474};\\\", \\\"{x:1420,y:623,t:1527030475486};\\\", \\\"{x:1425,y:622,t:1527030475503};\\\", \\\"{x:1429,y:621,t:1527030475520};\\\", \\\"{x:1440,y:621,t:1527030475536};\\\", \\\"{x:1457,y:621,t:1527030475554};\\\", \\\"{x:1463,y:621,t:1527030475570};\\\", \\\"{x:1465,y:621,t:1527030475586};\\\", \\\"{x:1468,y:621,t:1527030475604};\\\", \\\"{x:1470,y:621,t:1527030475620};\\\", \\\"{x:1471,y:621,t:1527030475666};\\\", \\\"{x:1471,y:620,t:1527030475714};\\\", \\\"{x:1473,y:620,t:1527030475730};\\\", \\\"{x:1474,y:620,t:1527030475746};\\\", \\\"{x:1476,y:620,t:1527030475754};\\\", \\\"{x:1478,y:620,t:1527030475770};\\\", \\\"{x:1479,y:620,t:1527030475786};\\\", \\\"{x:1478,y:621,t:1527030477794};\\\", \\\"{x:1477,y:621,t:1527030478354};\\\", \\\"{x:1476,y:621,t:1527030478409};\\\", \\\"{x:1475,y:621,t:1527030478421};\\\", \\\"{x:1474,y:621,t:1527030478449};\\\", \\\"{x:1474,y:622,t:1527030478480};\\\", \\\"{x:1473,y:623,t:1527030478537};\\\", \\\"{x:1472,y:623,t:1527030478618};\\\", \\\"{x:1471,y:623,t:1527030478675};\\\", \\\"{x:1470,y:623,t:1527030478802};\\\", \\\"{x:1470,y:624,t:1527030478825};\\\", \\\"{x:1469,y:624,t:1527030478930};\\\", \\\"{x:1468,y:624,t:1527030478954};\\\", \\\"{x:1467,y:625,t:1527030478994};\\\", \\\"{x:1466,y:625,t:1527030479005};\\\", \\\"{x:1463,y:626,t:1527030479022};\\\", \\\"{x:1460,y:628,t:1527030479039};\\\", \\\"{x:1454,y:632,t:1527030479056};\\\", \\\"{x:1446,y:638,t:1527030479072};\\\", \\\"{x:1437,y:643,t:1527030479088};\\\", \\\"{x:1426,y:650,t:1527030479106};\\\", \\\"{x:1417,y:655,t:1527030479122};\\\", \\\"{x:1412,y:659,t:1527030479139};\\\", \\\"{x:1403,y:665,t:1527030479155};\\\", \\\"{x:1400,y:668,t:1527030479172};\\\", \\\"{x:1396,y:670,t:1527030479189};\\\", \\\"{x:1395,y:671,t:1527030479206};\\\", \\\"{x:1393,y:672,t:1527030479221};\\\", \\\"{x:1392,y:673,t:1527030479241};\\\", \\\"{x:1391,y:674,t:1527030479258};\\\", \\\"{x:1390,y:674,t:1527030479274};\\\", \\\"{x:1390,y:675,t:1527030479298};\\\", \\\"{x:1389,y:675,t:1527030479330};\\\", \\\"{x:1389,y:676,t:1527030479339};\\\", \\\"{x:1387,y:677,t:1527030479355};\\\", \\\"{x:1387,y:678,t:1527030479371};\\\", \\\"{x:1386,y:680,t:1527030479388};\\\", \\\"{x:1386,y:681,t:1527030479405};\\\", \\\"{x:1384,y:683,t:1527030479421};\\\", \\\"{x:1382,y:685,t:1527030479438};\\\", \\\"{x:1381,y:688,t:1527030479455};\\\", \\\"{x:1380,y:689,t:1527030479471};\\\", \\\"{x:1379,y:691,t:1527030479488};\\\", \\\"{x:1378,y:693,t:1527030479505};\\\", \\\"{x:1377,y:694,t:1527030479522};\\\", \\\"{x:1376,y:696,t:1527030479538};\\\", \\\"{x:1376,y:700,t:1527030479556};\\\", \\\"{x:1376,y:702,t:1527030479571};\\\", \\\"{x:1376,y:704,t:1527030479589};\\\", \\\"{x:1376,y:707,t:1527030479605};\\\", \\\"{x:1376,y:709,t:1527030479625};\\\", \\\"{x:1376,y:710,t:1527030479649};\\\", \\\"{x:1376,y:712,t:1527030479681};\\\", \\\"{x:1376,y:713,t:1527030479723};\\\", \\\"{x:1377,y:713,t:1527030479739};\\\", \\\"{x:1382,y:716,t:1527030479755};\\\", \\\"{x:1388,y:717,t:1527030479772};\\\", \\\"{x:1397,y:720,t:1527030479789};\\\", \\\"{x:1406,y:723,t:1527030479806};\\\", \\\"{x:1411,y:723,t:1527030479823};\\\", \\\"{x:1426,y:727,t:1527030479839};\\\", \\\"{x:1445,y:732,t:1527030479855};\\\", \\\"{x:1469,y:739,t:1527030479872};\\\", \\\"{x:1494,y:747,t:1527030479889};\\\", \\\"{x:1520,y:753,t:1527030479905};\\\", \\\"{x:1521,y:753,t:1527030479985};\\\", \\\"{x:1522,y:753,t:1527030480025};\\\", \\\"{x:1521,y:753,t:1527030485034};\\\", \\\"{x:1520,y:753,t:1527030485050};\\\", \\\"{x:1519,y:753,t:1527030485065};\\\", \\\"{x:1518,y:753,t:1527030485075};\\\", \\\"{x:1517,y:753,t:1527030485092};\\\", \\\"{x:1516,y:754,t:1527030485109};\\\", \\\"{x:1515,y:755,t:1527030485126};\\\", \\\"{x:1514,y:757,t:1527030485142};\\\", \\\"{x:1513,y:758,t:1527030485162};\\\", \\\"{x:1511,y:761,t:1527030485175};\\\", \\\"{x:1508,y:763,t:1527030485192};\\\", \\\"{x:1505,y:766,t:1527030485208};\\\", \\\"{x:1501,y:771,t:1527030485225};\\\", \\\"{x:1500,y:772,t:1527030485242};\\\", \\\"{x:1498,y:774,t:1527030485258};\\\", \\\"{x:1497,y:775,t:1527030485275};\\\", \\\"{x:1495,y:775,t:1527030485291};\\\", \\\"{x:1494,y:775,t:1527030485308};\\\", \\\"{x:1490,y:775,t:1527030485325};\\\", \\\"{x:1484,y:775,t:1527030485342};\\\", \\\"{x:1471,y:775,t:1527030485359};\\\", \\\"{x:1449,y:775,t:1527030485376};\\\", \\\"{x:1423,y:769,t:1527030485392};\\\", \\\"{x:1373,y:756,t:1527030485409};\\\", \\\"{x:1246,y:726,t:1527030485425};\\\", \\\"{x:1142,y:699,t:1527030485443};\\\", \\\"{x:1021,y:670,t:1527030485460};\\\", \\\"{x:910,y:654,t:1527030485476};\\\", \\\"{x:804,y:636,t:1527030485493};\\\", \\\"{x:718,y:625,t:1527030485510};\\\", \\\"{x:631,y:611,t:1527030485525};\\\", \\\"{x:559,y:610,t:1527030485542};\\\", \\\"{x:500,y:610,t:1527030485561};\\\", \\\"{x:490,y:610,t:1527030485578};\\\", \\\"{x:489,y:609,t:1527030485673};\\\", \\\"{x:491,y:607,t:1527030485681};\\\", \\\"{x:493,y:606,t:1527030485694};\\\", \\\"{x:503,y:601,t:1527030485712};\\\", \\\"{x:517,y:594,t:1527030485729};\\\", \\\"{x:532,y:588,t:1527030485745};\\\", \\\"{x:557,y:580,t:1527030485761};\\\", \\\"{x:579,y:578,t:1527030485778};\\\", \\\"{x:624,y:576,t:1527030485795};\\\", \\\"{x:682,y:576,t:1527030485812};\\\", \\\"{x:735,y:576,t:1527030485829};\\\", \\\"{x:771,y:576,t:1527030485844};\\\", \\\"{x:782,y:576,t:1527030485861};\\\", \\\"{x:783,y:576,t:1527030485878};\\\", \\\"{x:784,y:576,t:1527030485894};\\\", \\\"{x:786,y:575,t:1527030485911};\\\", \\\"{x:792,y:575,t:1527030485928};\\\", \\\"{x:810,y:571,t:1527030485944};\\\", \\\"{x:855,y:565,t:1527030485961};\\\", \\\"{x:879,y:562,t:1527030485980};\\\", \\\"{x:891,y:559,t:1527030485994};\\\", \\\"{x:893,y:559,t:1527030486012};\\\", \\\"{x:894,y:558,t:1527030486090};\\\", \\\"{x:894,y:557,t:1527030486097};\\\", \\\"{x:894,y:556,t:1527030486112};\\\", \\\"{x:892,y:554,t:1527030486130};\\\", \\\"{x:889,y:552,t:1527030486145};\\\", \\\"{x:886,y:550,t:1527030486161};\\\", \\\"{x:884,y:549,t:1527030486179};\\\", \\\"{x:880,y:546,t:1527030486195};\\\", \\\"{x:872,y:541,t:1527030486211};\\\", \\\"{x:865,y:536,t:1527030486229};\\\", \\\"{x:860,y:535,t:1527030486246};\\\", \\\"{x:858,y:533,t:1527030486262};\\\", \\\"{x:854,y:534,t:1527030486278};\\\", \\\"{x:846,y:540,t:1527030486295};\\\", \\\"{x:840,y:547,t:1527030486311};\\\", \\\"{x:835,y:556,t:1527030486329};\\\", \\\"{x:832,y:560,t:1527030486345};\\\", \\\"{x:832,y:561,t:1527030486361};\\\", \\\"{x:832,y:562,t:1527030486378};\\\", \\\"{x:832,y:564,t:1527030486409};\\\", \\\"{x:833,y:567,t:1527030486417};\\\", \\\"{x:834,y:570,t:1527030486428};\\\", \\\"{x:837,y:575,t:1527030486445};\\\", \\\"{x:838,y:578,t:1527030486462};\\\", \\\"{x:838,y:579,t:1527030486488};\\\", \\\"{x:837,y:579,t:1527030486776};\\\", \\\"{x:829,y:579,t:1527030486784};\\\", \\\"{x:818,y:579,t:1527030486796};\\\", \\\"{x:800,y:579,t:1527030486812};\\\", \\\"{x:780,y:579,t:1527030486828};\\\", \\\"{x:748,y:579,t:1527030486845};\\\", \\\"{x:715,y:573,t:1527030486863};\\\", \\\"{x:693,y:570,t:1527030486879};\\\", \\\"{x:678,y:568,t:1527030486895};\\\", \\\"{x:662,y:565,t:1527030486913};\\\", \\\"{x:643,y:563,t:1527030486929};\\\", \\\"{x:641,y:563,t:1527030486945};\\\", \\\"{x:640,y:563,t:1527030487058};\\\", \\\"{x:640,y:565,t:1527030487065};\\\", \\\"{x:638,y:568,t:1527030487080};\\\", \\\"{x:636,y:572,t:1527030487096};\\\", \\\"{x:632,y:576,t:1527030487112};\\\", \\\"{x:627,y:582,t:1527030487128};\\\", \\\"{x:626,y:583,t:1527030487145};\\\", \\\"{x:625,y:583,t:1527030487201};\\\", \\\"{x:624,y:583,t:1527030487217};\\\", \\\"{x:623,y:583,t:1527030487412};\\\", \\\"{x:622,y:584,t:1527030487440};\\\", \\\"{x:622,y:585,t:1527030487449};\\\", \\\"{x:621,y:587,t:1527030487462};\\\", \\\"{x:616,y:593,t:1527030487480};\\\", \\\"{x:607,y:602,t:1527030487497};\\\", \\\"{x:589,y:618,t:1527030487512};\\\", \\\"{x:555,y:646,t:1527030487530};\\\", \\\"{x:525,y:672,t:1527030487547};\\\", \\\"{x:506,y:697,t:1527030487562};\\\", \\\"{x:489,y:723,t:1527030487580};\\\", \\\"{x:475,y:740,t:1527030487597};\\\", \\\"{x:462,y:747,t:1527030487613};\\\", \\\"{x:448,y:747,t:1527030487629};\\\", \\\"{x:446,y:744,t:1527030487646};\\\", \\\"{x:446,y:743,t:1527030487705};\\\", \\\"{x:446,y:741,t:1527030487714};\\\", \\\"{x:451,y:739,t:1527030487729};\\\", \\\"{x:453,y:737,t:1527030487747};\\\", \\\"{x:459,y:735,t:1527030487764};\\\", \\\"{x:468,y:733,t:1527030487779};\\\", \\\"{x:472,y:731,t:1527030487796};\\\", \\\"{x:476,y:729,t:1527030487813};\\\", \\\"{x:484,y:725,t:1527030487829};\\\", \\\"{x:492,y:724,t:1527030487847};\\\", \\\"{x:498,y:721,t:1527030487864};\\\", \\\"{x:500,y:721,t:1527030487879};\\\", \\\"{x:501,y:721,t:1527030487896};\\\", \\\"{x:502,y:721,t:1527030487921};\\\", \\\"{x:503,y:721,t:1527030487937};\\\", \\\"{x:504,y:721,t:1527030488026};\\\", \\\"{x:506,y:722,t:1527030488034};\\\", \\\"{x:507,y:724,t:1527030488042};\\\", \\\"{x:508,y:728,t:1527030488063};\\\", \\\"{x:508,y:729,t:1527030488080};\\\", \\\"{x:509,y:732,t:1527030488096};\\\", \\\"{x:509,y:732,t:1527030488164};\\\", \\\"{x:509,y:733,t:1527030488241};\\\", \\\"{x:510,y:733,t:1527030488248};\\\", \\\"{x:510,y:734,t:1527030489129};\\\", \\\"{x:510,y:732,t:1527030489179};\\\", \\\"{x:511,y:731,t:1527030489198};\\\", \\\"{x:511,y:729,t:1527030489214};\\\", \\\"{x:511,y:728,t:1527030489230};\\\", \\\"{x:512,y:727,t:1527030489247};\\\" ] }, { \\\"rt\\\": 52765, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 487503, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -F -F -G -B -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:728,t:1527030489521};\\\", \\\"{x:512,y:729,t:1527030489531};\\\", \\\"{x:512,y:732,t:1527030489548};\\\", \\\"{x:511,y:735,t:1527030489564};\\\", \\\"{x:510,y:740,t:1527030489582};\\\", \\\"{x:509,y:743,t:1527030489597};\\\", \\\"{x:508,y:746,t:1527030489614};\\\", \\\"{x:508,y:747,t:1527030489631};\\\", \\\"{x:508,y:749,t:1527030489648};\\\", \\\"{x:508,y:750,t:1527030489664};\\\", \\\"{x:508,y:752,t:1527030489682};\\\", \\\"{x:507,y:755,t:1527030489819};\\\", \\\"{x:506,y:757,t:1527030489872};\\\", \\\"{x:505,y:758,t:1527030489881};\\\", \\\"{x:503,y:761,t:1527030489898};\\\", \\\"{x:501,y:764,t:1527030489915};\\\", \\\"{x:501,y:765,t:1527030489932};\\\", \\\"{x:499,y:767,t:1527030489948};\\\", \\\"{x:498,y:768,t:1527030490033};\\\", \\\"{x:496,y:767,t:1527030490049};\\\", \\\"{x:495,y:767,t:1527030490130};\\\", \\\"{x:495,y:766,t:1527030490137};\\\", \\\"{x:494,y:761,t:1527030490149};\\\", \\\"{x:493,y:757,t:1527030490165};\\\", \\\"{x:492,y:753,t:1527030490182};\\\", \\\"{x:492,y:751,t:1527030490199};\\\", \\\"{x:491,y:751,t:1527030490214};\\\", \\\"{x:491,y:750,t:1527030490231};\\\", \\\"{x:491,y:751,t:1527030490338};\\\", \\\"{x:491,y:753,t:1527030490348};\\\", \\\"{x:491,y:758,t:1527030490365};\\\", \\\"{x:491,y:759,t:1527030490381};\\\", \\\"{x:490,y:761,t:1527030490398};\\\", \\\"{x:489,y:762,t:1527030490642};\\\", \\\"{x:489,y:763,t:1527030490680};\\\", \\\"{x:488,y:763,t:1527030490688};\\\", \\\"{x:488,y:764,t:1527030490729};\\\", \\\"{x:488,y:766,t:1527030490809};\\\", \\\"{x:488,y:767,t:1527030490816};\\\", \\\"{x:488,y:769,t:1527030490832};\\\", \\\"{x:489,y:771,t:1527030490849};\\\", \\\"{x:489,y:772,t:1527030490873};\\\", \\\"{x:489,y:773,t:1527030491154};\\\", \\\"{x:490,y:773,t:1527030491185};\\\", \\\"{x:491,y:773,t:1527030491200};\\\", \\\"{x:493,y:772,t:1527030491216};\\\", \\\"{x:495,y:772,t:1527030491241};\\\", \\\"{x:496,y:770,t:1527030491250};\\\", \\\"{x:501,y:768,t:1527030491266};\\\", \\\"{x:506,y:765,t:1527030491282};\\\", \\\"{x:512,y:762,t:1527030491300};\\\", \\\"{x:517,y:760,t:1527030491316};\\\", \\\"{x:522,y:757,t:1527030491333};\\\", \\\"{x:529,y:752,t:1527030491351};\\\", \\\"{x:534,y:748,t:1527030491365};\\\", \\\"{x:539,y:745,t:1527030491383};\\\", \\\"{x:547,y:740,t:1527030491399};\\\", \\\"{x:556,y:737,t:1527030491415};\\\", \\\"{x:574,y:732,t:1527030491433};\\\", \\\"{x:586,y:728,t:1527030491449};\\\", \\\"{x:593,y:725,t:1527030491465};\\\", \\\"{x:597,y:723,t:1527030491482};\\\", \\\"{x:598,y:723,t:1527030491500};\\\", \\\"{x:599,y:723,t:1527030491529};\\\", \\\"{x:600,y:723,t:1527030491553};\\\", \\\"{x:602,y:722,t:1527030491569};\\\", \\\"{x:603,y:722,t:1527030491681};\\\", \\\"{x:603,y:724,t:1527030491802};\\\", \\\"{x:603,y:725,t:1527030491826};\\\", \\\"{x:603,y:726,t:1527030491834};\\\", \\\"{x:603,y:727,t:1527030491850};\\\", \\\"{x:603,y:729,t:1527030491867};\\\", \\\"{x:603,y:731,t:1527030491882};\\\", \\\"{x:600,y:733,t:1527030491900};\\\", \\\"{x:598,y:735,t:1527030491917};\\\", \\\"{x:597,y:736,t:1527030491933};\\\", \\\"{x:596,y:736,t:1527030492234};\\\", \\\"{x:596,y:735,t:1527030492250};\\\", \\\"{x:595,y:733,t:1527030492266};\\\", \\\"{x:595,y:732,t:1527030492284};\\\", \\\"{x:594,y:731,t:1527030492440};\\\", \\\"{x:592,y:731,t:1527030492449};\\\", \\\"{x:590,y:731,t:1527030492466};\\\", \\\"{x:586,y:731,t:1527030492484};\\\", \\\"{x:581,y:732,t:1527030492500};\\\", \\\"{x:578,y:732,t:1527030492517};\\\", \\\"{x:574,y:734,t:1527030492533};\\\", \\\"{x:569,y:737,t:1527030492550};\\\", \\\"{x:566,y:740,t:1527030492567};\\\", \\\"{x:563,y:741,t:1527030492584};\\\", \\\"{x:562,y:742,t:1527030492601};\\\", \\\"{x:561,y:742,t:1527030492617};\\\", \\\"{x:561,y:743,t:1527030492641};\\\", \\\"{x:560,y:743,t:1527030492650};\\\", \\\"{x:558,y:745,t:1527030492666};\\\", \\\"{x:556,y:747,t:1527030492683};\\\", \\\"{x:555,y:749,t:1527030492701};\\\", \\\"{x:553,y:751,t:1527030492717};\\\", \\\"{x:552,y:753,t:1527030492733};\\\", \\\"{x:550,y:756,t:1527030492751};\\\", \\\"{x:546,y:760,t:1527030492766};\\\", \\\"{x:545,y:760,t:1527030492783};\\\", \\\"{x:543,y:761,t:1527030492801};\\\", \\\"{x:542,y:762,t:1527030492825};\\\", \\\"{x:541,y:763,t:1527030492840};\\\", \\\"{x:540,y:763,t:1527030492851};\\\", \\\"{x:539,y:764,t:1527030492866};\\\", \\\"{x:538,y:765,t:1527030492906};\\\", \\\"{x:537,y:765,t:1527030493050};\\\", \\\"{x:540,y:765,t:1527030493290};\\\", \\\"{x:542,y:764,t:1527030493301};\\\", \\\"{x:548,y:761,t:1527030493318};\\\", \\\"{x:551,y:758,t:1527030493334};\\\", \\\"{x:555,y:754,t:1527030493352};\\\", \\\"{x:558,y:749,t:1527030493367};\\\", \\\"{x:560,y:740,t:1527030493384};\\\", \\\"{x:561,y:736,t:1527030493400};\\\", \\\"{x:565,y:730,t:1527030493418};\\\", \\\"{x:566,y:726,t:1527030493434};\\\", \\\"{x:569,y:722,t:1527030493451};\\\", \\\"{x:571,y:720,t:1527030493468};\\\", \\\"{x:573,y:718,t:1527030493484};\\\", \\\"{x:575,y:715,t:1527030493501};\\\", \\\"{x:579,y:712,t:1527030493517};\\\", \\\"{x:586,y:708,t:1527030493535};\\\", \\\"{x:595,y:704,t:1527030493550};\\\", \\\"{x:607,y:699,t:1527030493567};\\\", \\\"{x:633,y:689,t:1527030493585};\\\", \\\"{x:653,y:684,t:1527030493601};\\\", \\\"{x:672,y:678,t:1527030493618};\\\", \\\"{x:693,y:671,t:1527030493635};\\\", \\\"{x:704,y:668,t:1527030493651};\\\", \\\"{x:709,y:666,t:1527030493668};\\\", \\\"{x:712,y:664,t:1527030493685};\\\", \\\"{x:715,y:663,t:1527030493701};\\\", \\\"{x:717,y:660,t:1527030493718};\\\", \\\"{x:718,y:660,t:1527030493735};\\\", \\\"{x:718,y:658,t:1527030493753};\\\", \\\"{x:719,y:656,t:1527030493768};\\\", \\\"{x:720,y:649,t:1527030493785};\\\", \\\"{x:720,y:642,t:1527030493801};\\\", \\\"{x:720,y:627,t:1527030493819};\\\", \\\"{x:716,y:604,t:1527030493835};\\\", \\\"{x:694,y:564,t:1527030493852};\\\", \\\"{x:666,y:535,t:1527030493868};\\\", \\\"{x:666,y:532,t:1527030493885};\\\", \\\"{x:666,y:531,t:1527030493901};\\\", \\\"{x:666,y:529,t:1527030493918};\\\", \\\"{x:667,y:529,t:1527030493945};\\\", \\\"{x:665,y:529,t:1527030494082};\\\", \\\"{x:662,y:529,t:1527030494089};\\\", \\\"{x:659,y:529,t:1527030494102};\\\", \\\"{x:648,y:529,t:1527030494118};\\\", \\\"{x:632,y:531,t:1527030494136};\\\", \\\"{x:617,y:532,t:1527030494152};\\\", \\\"{x:596,y:534,t:1527030494167};\\\", \\\"{x:548,y:534,t:1527030494185};\\\", \\\"{x:492,y:534,t:1527030494202};\\\", \\\"{x:431,y:534,t:1527030494219};\\\", \\\"{x:378,y:534,t:1527030494235};\\\", \\\"{x:341,y:534,t:1527030494251};\\\", \\\"{x:311,y:534,t:1527030494268};\\\", \\\"{x:282,y:534,t:1527030494284};\\\", \\\"{x:259,y:534,t:1527030494303};\\\", \\\"{x:244,y:534,t:1527030494318};\\\", \\\"{x:236,y:534,t:1527030494334};\\\", \\\"{x:232,y:534,t:1527030494351};\\\", \\\"{x:229,y:534,t:1527030494377};\\\", \\\"{x:226,y:534,t:1527030494384};\\\", \\\"{x:221,y:534,t:1527030494402};\\\", \\\"{x:220,y:532,t:1527030494419};\\\", \\\"{x:219,y:532,t:1527030494436};\\\", \\\"{x:219,y:530,t:1527030494452};\\\", \\\"{x:219,y:529,t:1527030494469};\\\", \\\"{x:220,y:524,t:1527030494487};\\\", \\\"{x:223,y:520,t:1527030494503};\\\", \\\"{x:226,y:513,t:1527030494520};\\\", \\\"{x:228,y:508,t:1527030494535};\\\", \\\"{x:234,y:503,t:1527030494551};\\\", \\\"{x:242,y:497,t:1527030494568};\\\", \\\"{x:246,y:493,t:1527030494585};\\\", \\\"{x:248,y:493,t:1527030494602};\\\", \\\"{x:248,y:492,t:1527030494619};\\\", \\\"{x:249,y:490,t:1527030494640};\\\", \\\"{x:249,y:489,t:1527030494652};\\\", \\\"{x:251,y:487,t:1527030494668};\\\", \\\"{x:252,y:486,t:1527030494686};\\\", \\\"{x:252,y:485,t:1527030494922};\\\", \\\"{x:253,y:485,t:1527030494936};\\\", \\\"{x:257,y:481,t:1527030494952};\\\", \\\"{x:267,y:473,t:1527030494969};\\\", \\\"{x:276,y:467,t:1527030494985};\\\", \\\"{x:283,y:460,t:1527030495002};\\\", \\\"{x:287,y:457,t:1527030495019};\\\", \\\"{x:289,y:454,t:1527030495035};\\\", \\\"{x:290,y:453,t:1527030495266};\\\", \\\"{x:293,y:452,t:1527030495273};\\\", \\\"{x:296,y:451,t:1527030495285};\\\", \\\"{x:305,y:449,t:1527030495302};\\\", \\\"{x:318,y:446,t:1527030495319};\\\", \\\"{x:331,y:446,t:1527030495335};\\\", \\\"{x:344,y:446,t:1527030495352};\\\", \\\"{x:362,y:447,t:1527030495369};\\\", \\\"{x:375,y:451,t:1527030495385};\\\", \\\"{x:395,y:454,t:1527030495402};\\\", \\\"{x:426,y:459,t:1527030495418};\\\", \\\"{x:468,y:465,t:1527030495436};\\\", \\\"{x:511,y:466,t:1527030495452};\\\", \\\"{x:535,y:466,t:1527030495468};\\\", \\\"{x:549,y:466,t:1527030495485};\\\", \\\"{x:555,y:466,t:1527030495503};\\\", \\\"{x:560,y:465,t:1527030495518};\\\", \\\"{x:561,y:465,t:1527030495535};\\\", \\\"{x:563,y:465,t:1527030495552};\\\", \\\"{x:565,y:465,t:1527030495568};\\\", \\\"{x:572,y:461,t:1527030495585};\\\", \\\"{x:585,y:452,t:1527030495602};\\\", \\\"{x:600,y:441,t:1527030495618};\\\", \\\"{x:611,y:434,t:1527030495636};\\\", \\\"{x:615,y:432,t:1527030495652};\\\", \\\"{x:616,y:432,t:1527030495881};\\\", \\\"{x:619,y:434,t:1527030495889};\\\", \\\"{x:622,y:440,t:1527030495902};\\\", \\\"{x:628,y:446,t:1527030495918};\\\", \\\"{x:632,y:449,t:1527030495935};\\\", \\\"{x:631,y:449,t:1527030495977};\\\", \\\"{x:628,y:448,t:1527030495985};\\\", \\\"{x:624,y:447,t:1527030496002};\\\", \\\"{x:617,y:447,t:1527030496018};\\\", \\\"{x:608,y:450,t:1527030496034};\\\", \\\"{x:598,y:458,t:1527030496051};\\\", \\\"{x:592,y:464,t:1527030496068};\\\", \\\"{x:585,y:469,t:1527030496085};\\\", \\\"{x:581,y:471,t:1527030496102};\\\", \\\"{x:578,y:472,t:1527030496117};\\\", \\\"{x:577,y:470,t:1527030496193};\\\", \\\"{x:576,y:468,t:1527030496201};\\\", \\\"{x:574,y:467,t:1527030496218};\\\", \\\"{x:571,y:465,t:1527030496235};\\\", \\\"{x:560,y:462,t:1527030496252};\\\", \\\"{x:551,y:457,t:1527030496268};\\\", \\\"{x:544,y:453,t:1527030496285};\\\", \\\"{x:542,y:452,t:1527030496302};\\\", \\\"{x:541,y:451,t:1527030496370};\\\", \\\"{x:534,y:450,t:1527030496384};\\\", \\\"{x:529,y:450,t:1527030496402};\\\", \\\"{x:528,y:449,t:1527030496418};\\\", \\\"{x:526,y:449,t:1527030496504};\\\", \\\"{x:525,y:449,t:1527030496536};\\\", \\\"{x:522,y:452,t:1527030496552};\\\", \\\"{x:520,y:452,t:1527030496568};\\\", \\\"{x:513,y:456,t:1527030496585};\\\", \\\"{x:510,y:458,t:1527030496602};\\\", \\\"{x:506,y:460,t:1527030496617};\\\", \\\"{x:506,y:461,t:1527030496635};\\\", \\\"{x:505,y:462,t:1527030496978};\\\", \\\"{x:505,y:463,t:1527030497210};\\\", \\\"{x:506,y:463,t:1527030497218};\\\", \\\"{x:510,y:461,t:1527030497236};\\\", \\\"{x:513,y:458,t:1527030497251};\\\", \\\"{x:517,y:456,t:1527030497268};\\\", \\\"{x:518,y:454,t:1527030497285};\\\", \\\"{x:519,y:454,t:1527030497301};\\\", \\\"{x:519,y:453,t:1527030497318};\\\", \\\"{x:520,y:452,t:1527030497490};\\\", \\\"{x:521,y:451,t:1527030497505};\\\", \\\"{x:522,y:451,t:1527030497518};\\\", \\\"{x:524,y:451,t:1527030497536};\\\", \\\"{x:525,y:451,t:1527030497551};\\\", \\\"{x:530,y:448,t:1527030497568};\\\", \\\"{x:539,y:448,t:1527030497585};\\\", \\\"{x:544,y:447,t:1527030497601};\\\", \\\"{x:548,y:447,t:1527030497617};\\\", \\\"{x:555,y:447,t:1527030497635};\\\", \\\"{x:568,y:447,t:1527030497650};\\\", \\\"{x:576,y:447,t:1527030497667};\\\", \\\"{x:581,y:447,t:1527030497685};\\\", \\\"{x:585,y:447,t:1527030497701};\\\", \\\"{x:588,y:447,t:1527030497717};\\\", \\\"{x:592,y:447,t:1527030497735};\\\", \\\"{x:598,y:447,t:1527030497751};\\\", \\\"{x:609,y:447,t:1527030497768};\\\", \\\"{x:625,y:447,t:1527030497785};\\\", \\\"{x:633,y:447,t:1527030497801};\\\", \\\"{x:638,y:447,t:1527030497818};\\\", \\\"{x:641,y:447,t:1527030497835};\\\", \\\"{x:642,y:448,t:1527030497851};\\\", \\\"{x:643,y:448,t:1527030497868};\\\", \\\"{x:644,y:449,t:1527030497884};\\\", \\\"{x:644,y:450,t:1527030497901};\\\", \\\"{x:645,y:450,t:1527030497919};\\\", \\\"{x:645,y:451,t:1527030497945};\\\", \\\"{x:645,y:453,t:1527030498074};\\\", \\\"{x:645,y:454,t:1527030498097};\\\", \\\"{x:645,y:456,t:1527030498113};\\\", \\\"{x:645,y:457,t:1527030498129};\\\", \\\"{x:644,y:457,t:1527030498138};\\\", \\\"{x:642,y:457,t:1527030498177};\\\", \\\"{x:642,y:458,t:1527030498306};\\\", \\\"{x:642,y:459,t:1527030498321};\\\", \\\"{x:642,y:460,t:1527030498522};\\\", \\\"{x:642,y:462,t:1527030498534};\\\", \\\"{x:643,y:462,t:1527030498626};\\\", \\\"{x:646,y:462,t:1527030498634};\\\", \\\"{x:649,y:459,t:1527030498651};\\\", \\\"{x:653,y:456,t:1527030498669};\\\", \\\"{x:655,y:455,t:1527030498684};\\\", \\\"{x:656,y:455,t:1527030498713};\\\", \\\"{x:657,y:455,t:1527030498746};\\\", \\\"{x:658,y:455,t:1527030498753};\\\", \\\"{x:660,y:455,t:1527030498777};\\\", \\\"{x:662,y:455,t:1527030498785};\\\", \\\"{x:665,y:457,t:1527030498800};\\\", \\\"{x:670,y:460,t:1527030498817};\\\", \\\"{x:673,y:461,t:1527030498833};\\\", \\\"{x:674,y:461,t:1527030498851};\\\", \\\"{x:675,y:461,t:1527030498872};\\\", \\\"{x:676,y:461,t:1527030498889};\\\", \\\"{x:677,y:461,t:1527030498901};\\\", \\\"{x:681,y:456,t:1527030498918};\\\", \\\"{x:682,y:455,t:1527030498934};\\\", \\\"{x:683,y:454,t:1527030498951};\\\", \\\"{x:683,y:453,t:1527030499146};\\\", \\\"{x:684,y:452,t:1527030499153};\\\", \\\"{x:683,y:452,t:1527030499218};\\\", \\\"{x:677,y:454,t:1527030499234};\\\", \\\"{x:666,y:460,t:1527030499251};\\\", \\\"{x:656,y:465,t:1527030499267};\\\", \\\"{x:650,y:468,t:1527030499285};\\\", \\\"{x:646,y:469,t:1527030499301};\\\", \\\"{x:644,y:469,t:1527030499317};\\\", \\\"{x:643,y:469,t:1527030499334};\\\", \\\"{x:642,y:469,t:1527030499351};\\\", \\\"{x:639,y:468,t:1527030499368};\\\", \\\"{x:638,y:468,t:1527030499384};\\\", \\\"{x:634,y:467,t:1527030499400};\\\", \\\"{x:630,y:467,t:1527030499417};\\\", \\\"{x:625,y:467,t:1527030499433};\\\", \\\"{x:622,y:467,t:1527030499451};\\\", \\\"{x:619,y:467,t:1527030499467};\\\", \\\"{x:616,y:468,t:1527030499484};\\\", \\\"{x:615,y:468,t:1527030499746};\\\", \\\"{x:615,y:467,t:1527030500178};\\\", \\\"{x:620,y:466,t:1527030500185};\\\", \\\"{x:643,y:463,t:1527030500201};\\\", \\\"{x:695,y:463,t:1527030500217};\\\", \\\"{x:792,y:463,t:1527030500234};\\\", \\\"{x:900,y:463,t:1527030500251};\\\", \\\"{x:995,y:466,t:1527030500268};\\\", \\\"{x:1079,y:481,t:1527030500285};\\\", \\\"{x:1135,y:487,t:1527030500301};\\\", \\\"{x:1150,y:490,t:1527030500318};\\\", \\\"{x:1148,y:490,t:1527030500506};\\\", \\\"{x:1141,y:490,t:1527030500517};\\\", \\\"{x:1116,y:490,t:1527030500534};\\\", \\\"{x:1086,y:490,t:1527030500551};\\\", \\\"{x:1041,y:490,t:1527030500567};\\\", \\\"{x:986,y:488,t:1527030500585};\\\", \\\"{x:933,y:480,t:1527030500601};\\\", \\\"{x:864,y:470,t:1527030500617};\\\", \\\"{x:830,y:465,t:1527030500634};\\\", \\\"{x:805,y:460,t:1527030500650};\\\", \\\"{x:786,y:459,t:1527030500667};\\\", \\\"{x:770,y:459,t:1527030500684};\\\", \\\"{x:752,y:459,t:1527030500701};\\\", \\\"{x:730,y:460,t:1527030500717};\\\", \\\"{x:702,y:465,t:1527030500734};\\\", \\\"{x:665,y:466,t:1527030500751};\\\", \\\"{x:606,y:466,t:1527030500768};\\\", \\\"{x:551,y:466,t:1527030500784};\\\", \\\"{x:506,y:466,t:1527030500801};\\\", \\\"{x:457,y:466,t:1527030500817};\\\", \\\"{x:431,y:462,t:1527030500834};\\\", \\\"{x:411,y:457,t:1527030500851};\\\", \\\"{x:404,y:454,t:1527030500867};\\\", \\\"{x:403,y:454,t:1527030500884};\\\", \\\"{x:402,y:454,t:1527030500977};\\\", \\\"{x:400,y:454,t:1527030500985};\\\", \\\"{x:398,y:454,t:1527030501000};\\\", \\\"{x:397,y:454,t:1527030501017};\\\", \\\"{x:396,y:454,t:1527030501113};\\\", \\\"{x:398,y:454,t:1527030501186};\\\", \\\"{x:400,y:454,t:1527030501200};\\\", \\\"{x:422,y:454,t:1527030501217};\\\", \\\"{x:454,y:454,t:1527030501234};\\\", \\\"{x:513,y:454,t:1527030501251};\\\", \\\"{x:575,y:452,t:1527030501267};\\\", \\\"{x:648,y:447,t:1527030501284};\\\", \\\"{x:701,y:441,t:1527030501301};\\\", \\\"{x:758,y:437,t:1527030501317};\\\", \\\"{x:814,y:437,t:1527030501334};\\\", \\\"{x:867,y:437,t:1527030501351};\\\", \\\"{x:898,y:437,t:1527030501367};\\\", \\\"{x:936,y:438,t:1527030501385};\\\", \\\"{x:980,y:443,t:1527030501401};\\\", \\\"{x:1053,y:455,t:1527030501417};\\\", \\\"{x:1092,y:462,t:1527030501435};\\\", \\\"{x:1116,y:465,t:1527030501450};\\\", \\\"{x:1134,y:468,t:1527030501468};\\\", \\\"{x:1145,y:468,t:1527030501485};\\\", \\\"{x:1155,y:468,t:1527030501500};\\\", \\\"{x:1160,y:468,t:1527030501518};\\\", \\\"{x:1164,y:468,t:1527030501534};\\\", \\\"{x:1165,y:468,t:1527030501602};\\\", \\\"{x:1165,y:469,t:1527030501786};\\\", \\\"{x:1163,y:471,t:1527030501800};\\\", \\\"{x:1158,y:475,t:1527030501817};\\\", \\\"{x:1150,y:482,t:1527030501834};\\\", \\\"{x:1140,y:492,t:1527030501850};\\\", \\\"{x:1131,y:501,t:1527030501868};\\\", \\\"{x:1122,y:508,t:1527030501883};\\\", \\\"{x:1116,y:509,t:1527030501901};\\\", \\\"{x:1113,y:510,t:1527030501918};\\\", \\\"{x:1112,y:510,t:1527030501933};\\\", \\\"{x:1116,y:510,t:1527030502049};\\\", \\\"{x:1129,y:510,t:1527030502068};\\\", \\\"{x:1148,y:510,t:1527030502084};\\\", \\\"{x:1175,y:510,t:1527030502101};\\\", \\\"{x:1209,y:513,t:1527030502118};\\\", \\\"{x:1251,y:517,t:1527030502134};\\\", \\\"{x:1291,y:520,t:1527030502150};\\\", \\\"{x:1323,y:520,t:1527030502167};\\\", \\\"{x:1350,y:520,t:1527030502183};\\\", \\\"{x:1364,y:520,t:1527030502201};\\\", \\\"{x:1369,y:520,t:1527030502218};\\\", \\\"{x:1369,y:521,t:1527030502314};\\\", \\\"{x:1369,y:522,t:1527030502330};\\\", \\\"{x:1367,y:524,t:1527030502337};\\\", \\\"{x:1365,y:524,t:1527030502351};\\\", \\\"{x:1361,y:525,t:1527030502368};\\\", \\\"{x:1353,y:528,t:1527030502384};\\\", \\\"{x:1346,y:528,t:1527030502400};\\\", \\\"{x:1329,y:530,t:1527030502416};\\\", \\\"{x:1313,y:532,t:1527030502433};\\\", \\\"{x:1306,y:533,t:1527030502450};\\\", \\\"{x:1299,y:534,t:1527030502467};\\\", \\\"{x:1294,y:534,t:1527030502483};\\\", \\\"{x:1293,y:535,t:1527030502500};\\\", \\\"{x:1292,y:535,t:1527030502517};\\\", \\\"{x:1291,y:536,t:1527030502720};\\\", \\\"{x:1290,y:536,t:1527030502733};\\\", \\\"{x:1289,y:538,t:1527030502750};\\\", \\\"{x:1287,y:539,t:1527030502767};\\\", \\\"{x:1287,y:540,t:1527030502783};\\\", \\\"{x:1287,y:541,t:1527030502857};\\\", \\\"{x:1285,y:543,t:1527030502867};\\\", \\\"{x:1284,y:545,t:1527030502889};\\\", \\\"{x:1284,y:546,t:1527030502913};\\\", \\\"{x:1284,y:547,t:1527030502929};\\\", \\\"{x:1284,y:548,t:1527030502945};\\\", \\\"{x:1284,y:549,t:1527030502977};\\\", \\\"{x:1284,y:550,t:1527030503146};\\\", \\\"{x:1284,y:552,t:1527030503161};\\\", \\\"{x:1285,y:553,t:1527030503177};\\\", \\\"{x:1285,y:554,t:1527030503402};\\\", \\\"{x:1285,y:555,t:1527030503649};\\\", \\\"{x:1286,y:561,t:1527030503670};\\\", \\\"{x:1290,y:568,t:1527030503683};\\\", \\\"{x:1294,y:577,t:1527030503700};\\\", \\\"{x:1296,y:591,t:1527030503716};\\\", \\\"{x:1300,y:608,t:1527030503733};\\\", \\\"{x:1303,y:629,t:1527030503750};\\\", \\\"{x:1306,y:652,t:1527030503766};\\\", \\\"{x:1310,y:678,t:1527030503783};\\\", \\\"{x:1312,y:700,t:1527030503800};\\\", \\\"{x:1316,y:719,t:1527030503816};\\\", \\\"{x:1321,y:736,t:1527030503833};\\\", \\\"{x:1324,y:741,t:1527030503851};\\\", \\\"{x:1325,y:745,t:1527030503867};\\\", \\\"{x:1326,y:748,t:1527030503883};\\\", \\\"{x:1328,y:754,t:1527030503901};\\\", \\\"{x:1330,y:758,t:1527030503917};\\\", \\\"{x:1331,y:760,t:1527030503934};\\\", \\\"{x:1332,y:760,t:1527030504000};\\\", \\\"{x:1333,y:761,t:1527030504017};\\\", \\\"{x:1337,y:766,t:1527030504033};\\\", \\\"{x:1337,y:767,t:1527030504050};\\\", \\\"{x:1338,y:767,t:1527030504067};\\\", \\\"{x:1339,y:767,t:1527030504089};\\\", \\\"{x:1340,y:767,t:1527030504161};\\\", \\\"{x:1341,y:767,t:1527030504314};\\\", \\\"{x:1342,y:767,t:1527030504322};\\\", \\\"{x:1343,y:766,t:1527030504338};\\\", \\\"{x:1344,y:765,t:1527030504350};\\\", \\\"{x:1345,y:764,t:1527030504366};\\\", \\\"{x:1345,y:766,t:1527030504858};\\\", \\\"{x:1344,y:767,t:1527030504866};\\\", \\\"{x:1344,y:769,t:1527030504890};\\\", \\\"{x:1344,y:770,t:1527030504900};\\\", \\\"{x:1342,y:772,t:1527030504917};\\\", \\\"{x:1342,y:773,t:1527030504934};\\\", \\\"{x:1342,y:775,t:1527030504950};\\\", \\\"{x:1341,y:777,t:1527030504967};\\\", \\\"{x:1340,y:778,t:1527030504985};\\\", \\\"{x:1340,y:781,t:1527030505000};\\\", \\\"{x:1338,y:784,t:1527030505017};\\\", \\\"{x:1338,y:781,t:1527030505257};\\\", \\\"{x:1338,y:780,t:1527030505282};\\\", \\\"{x:1338,y:778,t:1527030505362};\\\", \\\"{x:1336,y:774,t:1527030505369};\\\", \\\"{x:1332,y:770,t:1527030505384};\\\", \\\"{x:1329,y:764,t:1527030505399};\\\", \\\"{x:1326,y:760,t:1527030505417};\\\", \\\"{x:1325,y:760,t:1527030505458};\\\", \\\"{x:1323,y:760,t:1527030505474};\\\", \\\"{x:1322,y:760,t:1527030505484};\\\", \\\"{x:1320,y:760,t:1527030505499};\\\", \\\"{x:1319,y:760,t:1527030505516};\\\", \\\"{x:1318,y:760,t:1527030505602};\\\", \\\"{x:1316,y:758,t:1527030505617};\\\", \\\"{x:1315,y:756,t:1527030505634};\\\", \\\"{x:1313,y:755,t:1527030505649};\\\", \\\"{x:1312,y:754,t:1527030505667};\\\", \\\"{x:1311,y:754,t:1527030505683};\\\", \\\"{x:1310,y:754,t:1527030505706};\\\", \\\"{x:1309,y:754,t:1527030506354};\\\", \\\"{x:1309,y:756,t:1527030506370};\\\", \\\"{x:1309,y:757,t:1527030506385};\\\", \\\"{x:1309,y:759,t:1527030506401};\\\", \\\"{x:1309,y:758,t:1527030506674};\\\", \\\"{x:1309,y:757,t:1527030506689};\\\", \\\"{x:1310,y:756,t:1527030506938};\\\", \\\"{x:1311,y:755,t:1527030506953};\\\", \\\"{x:1311,y:754,t:1527030507394};\\\", \\\"{x:1312,y:752,t:1527030507401};\\\", \\\"{x:1313,y:750,t:1527030507418};\\\", \\\"{x:1314,y:748,t:1527030507441};\\\", \\\"{x:1314,y:747,t:1527030507457};\\\", \\\"{x:1314,y:746,t:1527030507473};\\\", \\\"{x:1315,y:745,t:1527030507483};\\\", \\\"{x:1316,y:744,t:1527030507500};\\\", \\\"{x:1317,y:743,t:1527030507530};\\\", \\\"{x:1319,y:741,t:1527030507585};\\\", \\\"{x:1319,y:740,t:1527030507599};\\\", \\\"{x:1320,y:734,t:1527030507616};\\\", \\\"{x:1322,y:729,t:1527030507633};\\\", \\\"{x:1324,y:721,t:1527030507649};\\\", \\\"{x:1325,y:717,t:1527030507666};\\\", \\\"{x:1326,y:716,t:1527030507689};\\\", \\\"{x:1326,y:715,t:1527030507722};\\\", \\\"{x:1327,y:715,t:1527030507732};\\\", \\\"{x:1328,y:713,t:1527030507749};\\\", \\\"{x:1330,y:711,t:1527030507765};\\\", \\\"{x:1331,y:708,t:1527030507782};\\\", \\\"{x:1333,y:706,t:1527030507816};\\\", \\\"{x:1334,y:705,t:1527030507840};\\\", \\\"{x:1335,y:704,t:1527030507848};\\\", \\\"{x:1339,y:698,t:1527030507865};\\\", \\\"{x:1341,y:696,t:1527030507882};\\\", \\\"{x:1343,y:695,t:1527030507900};\\\", \\\"{x:1344,y:694,t:1527030508082};\\\", \\\"{x:1344,y:693,t:1527030508100};\\\", \\\"{x:1344,y:691,t:1527030508117};\\\", \\\"{x:1345,y:691,t:1527030508132};\\\", \\\"{x:1346,y:690,t:1527030508148};\\\", \\\"{x:1347,y:689,t:1527030508338};\\\", \\\"{x:1348,y:689,t:1527030510026};\\\", \\\"{x:1349,y:689,t:1527030510041};\\\", \\\"{x:1350,y:689,t:1527030510066};\\\", \\\"{x:1351,y:689,t:1527030510083};\\\", \\\"{x:1352,y:689,t:1527030510099};\\\", \\\"{x:1353,y:688,t:1527030510116};\\\", \\\"{x:1354,y:687,t:1527030510132};\\\", \\\"{x:1357,y:685,t:1527030510149};\\\", \\\"{x:1361,y:682,t:1527030510166};\\\", \\\"{x:1366,y:678,t:1527030510182};\\\", \\\"{x:1375,y:671,t:1527030510198};\\\", \\\"{x:1389,y:660,t:1527030510215};\\\", \\\"{x:1400,y:652,t:1527030510232};\\\", \\\"{x:1416,y:639,t:1527030510249};\\\", \\\"{x:1422,y:633,t:1527030510265};\\\", \\\"{x:1426,y:628,t:1527030510282};\\\", \\\"{x:1429,y:623,t:1527030510299};\\\", \\\"{x:1431,y:618,t:1527030510315};\\\", \\\"{x:1431,y:616,t:1527030510331};\\\", \\\"{x:1433,y:612,t:1527030510349};\\\", \\\"{x:1433,y:608,t:1527030510365};\\\", \\\"{x:1433,y:607,t:1527030510381};\\\", \\\"{x:1433,y:605,t:1527030510417};\\\", \\\"{x:1433,y:604,t:1527030510481};\\\", \\\"{x:1433,y:602,t:1527030510505};\\\", \\\"{x:1433,y:601,t:1527030510520};\\\", \\\"{x:1433,y:598,t:1527030510537};\\\", \\\"{x:1433,y:596,t:1527030510548};\\\", \\\"{x:1432,y:591,t:1527030510565};\\\", \\\"{x:1432,y:588,t:1527030510582};\\\", \\\"{x:1432,y:584,t:1527030510599};\\\", \\\"{x:1430,y:583,t:1527030510615};\\\", \\\"{x:1429,y:581,t:1527030510633};\\\", \\\"{x:1429,y:580,t:1527030510746};\\\", \\\"{x:1429,y:578,t:1527030510761};\\\", \\\"{x:1429,y:577,t:1527030510769};\\\", \\\"{x:1428,y:576,t:1527030510781};\\\", \\\"{x:1428,y:575,t:1527030510798};\\\", \\\"{x:1427,y:574,t:1527030510814};\\\", \\\"{x:1426,y:573,t:1527030510831};\\\", \\\"{x:1426,y:572,t:1527030511009};\\\", \\\"{x:1426,y:571,t:1527030511017};\\\", \\\"{x:1425,y:570,t:1527030511242};\\\", \\\"{x:1425,y:569,t:1527030511249};\\\", \\\"{x:1423,y:568,t:1527030511266};\\\", \\\"{x:1422,y:567,t:1527030511282};\\\", \\\"{x:1421,y:566,t:1527030511299};\\\", \\\"{x:1420,y:565,t:1527030511315};\\\", \\\"{x:1419,y:565,t:1527030511332};\\\", \\\"{x:1418,y:565,t:1527030511348};\\\", \\\"{x:1417,y:565,t:1527030511368};\\\", \\\"{x:1416,y:565,t:1527030511385};\\\", \\\"{x:1414,y:564,t:1527030511398};\\\", \\\"{x:1411,y:564,t:1527030513706};\\\", \\\"{x:1405,y:568,t:1527030513716};\\\", \\\"{x:1387,y:575,t:1527030513731};\\\", \\\"{x:1371,y:583,t:1527030513748};\\\", \\\"{x:1350,y:593,t:1527030513765};\\\", \\\"{x:1323,y:601,t:1527030513781};\\\", \\\"{x:1283,y:607,t:1527030513798};\\\", \\\"{x:1180,y:611,t:1527030513815};\\\", \\\"{x:1055,y:611,t:1527030513831};\\\", \\\"{x:895,y:611,t:1527030513850};\\\", \\\"{x:588,y:608,t:1527030513866};\\\", \\\"{x:413,y:599,t:1527030513881};\\\", \\\"{x:270,y:587,t:1527030513918};\\\", \\\"{x:265,y:586,t:1527030513934};\\\", \\\"{x:263,y:586,t:1527030513950};\\\", \\\"{x:263,y:584,t:1527030513984};\\\", \\\"{x:267,y:579,t:1527030514000};\\\", \\\"{x:276,y:575,t:1527030514018};\\\", \\\"{x:291,y:569,t:1527030514035};\\\", \\\"{x:307,y:561,t:1527030514050};\\\", \\\"{x:321,y:555,t:1527030514068};\\\", \\\"{x:337,y:551,t:1527030514084};\\\", \\\"{x:350,y:548,t:1527030514101};\\\", \\\"{x:364,y:545,t:1527030514118};\\\", \\\"{x:375,y:545,t:1527030514135};\\\", \\\"{x:385,y:545,t:1527030514151};\\\", \\\"{x:392,y:545,t:1527030514167};\\\", \\\"{x:424,y:549,t:1527030514185};\\\", \\\"{x:456,y:556,t:1527030514202};\\\", \\\"{x:487,y:558,t:1527030514218};\\\", \\\"{x:519,y:558,t:1527030514234};\\\", \\\"{x:548,y:557,t:1527030514251};\\\", \\\"{x:574,y:554,t:1527030514268};\\\", \\\"{x:597,y:551,t:1527030514285};\\\", \\\"{x:620,y:548,t:1527030514302};\\\", \\\"{x:643,y:544,t:1527030514318};\\\", \\\"{x:657,y:543,t:1527030514335};\\\", \\\"{x:664,y:541,t:1527030514352};\\\", \\\"{x:677,y:541,t:1527030514368};\\\", \\\"{x:706,y:541,t:1527030514384};\\\", \\\"{x:717,y:541,t:1527030514401};\\\", \\\"{x:719,y:541,t:1527030514417};\\\", \\\"{x:720,y:541,t:1527030514474};\\\", \\\"{x:723,y:541,t:1527030514484};\\\", \\\"{x:734,y:541,t:1527030514502};\\\", \\\"{x:744,y:541,t:1527030514517};\\\", \\\"{x:745,y:541,t:1527030514535};\\\", \\\"{x:747,y:541,t:1527030514577};\\\", \\\"{x:749,y:541,t:1527030514584};\\\", \\\"{x:762,y:541,t:1527030514601};\\\", \\\"{x:787,y:543,t:1527030514619};\\\", \\\"{x:812,y:548,t:1527030514635};\\\", \\\"{x:824,y:549,t:1527030514652};\\\", \\\"{x:827,y:549,t:1527030514669};\\\", \\\"{x:829,y:549,t:1527030514684};\\\", \\\"{x:829,y:550,t:1527030515289};\\\", \\\"{x:829,y:551,t:1527030515329};\\\", \\\"{x:829,y:553,t:1527030515354};\\\", \\\"{x:829,y:554,t:1527030515376};\\\", \\\"{x:829,y:555,t:1527030515393};\\\", \\\"{x:829,y:556,t:1527030515417};\\\", \\\"{x:829,y:557,t:1527030515865};\\\", \\\"{x:830,y:557,t:1527030515881};\\\", \\\"{x:831,y:557,t:1527030515889};\\\", \\\"{x:831,y:558,t:1527030516473};\\\", \\\"{x:831,y:559,t:1527030516489};\\\", \\\"{x:831,y:560,t:1527030516503};\\\", \\\"{x:831,y:566,t:1527030516523};\\\", \\\"{x:831,y:571,t:1527030516536};\\\", \\\"{x:831,y:573,t:1527030516553};\\\", \\\"{x:831,y:574,t:1527030516569};\\\", \\\"{x:830,y:576,t:1527030516624};\\\", \\\"{x:829,y:576,t:1527030516637};\\\", \\\"{x:823,y:577,t:1527030516653};\\\", \\\"{x:806,y:579,t:1527030516669};\\\", \\\"{x:781,y:580,t:1527030516686};\\\", \\\"{x:753,y:580,t:1527030516703};\\\", \\\"{x:724,y:580,t:1527030516720};\\\", \\\"{x:687,y:577,t:1527030516738};\\\", \\\"{x:670,y:575,t:1527030516752};\\\", \\\"{x:658,y:572,t:1527030516770};\\\", \\\"{x:645,y:569,t:1527030516786};\\\", \\\"{x:635,y:565,t:1527030516804};\\\", \\\"{x:622,y:558,t:1527030516820};\\\", \\\"{x:615,y:553,t:1527030516837};\\\", \\\"{x:608,y:548,t:1527030516854};\\\", \\\"{x:597,y:541,t:1527030516870};\\\", \\\"{x:578,y:531,t:1527030516887};\\\", \\\"{x:562,y:521,t:1527030516904};\\\", \\\"{x:546,y:511,t:1527030516920};\\\", \\\"{x:539,y:506,t:1527030516937};\\\", \\\"{x:535,y:502,t:1527030516953};\\\", \\\"{x:533,y:498,t:1527030516970};\\\", \\\"{x:531,y:496,t:1527030516987};\\\", \\\"{x:529,y:493,t:1527030517004};\\\", \\\"{x:528,y:491,t:1527030517021};\\\", \\\"{x:526,y:488,t:1527030517037};\\\", \\\"{x:525,y:485,t:1527030517055};\\\", \\\"{x:524,y:480,t:1527030517071};\\\", \\\"{x:522,y:477,t:1527030517087};\\\", \\\"{x:522,y:475,t:1527030517103};\\\", \\\"{x:522,y:473,t:1527030517121};\\\", \\\"{x:522,y:471,t:1527030517137};\\\", \\\"{x:522,y:468,t:1527030517154};\\\", \\\"{x:521,y:467,t:1527030517171};\\\", \\\"{x:521,y:465,t:1527030517188};\\\", \\\"{x:521,y:464,t:1527030517204};\\\", \\\"{x:521,y:462,t:1527030517221};\\\", \\\"{x:521,y:461,t:1527030517241};\\\", \\\"{x:521,y:459,t:1527030517257};\\\", \\\"{x:521,y:458,t:1527030517281};\\\", \\\"{x:521,y:456,t:1527030517313};\\\", \\\"{x:521,y:455,t:1527030517369};\\\", \\\"{x:522,y:455,t:1527030517417};\\\", \\\"{x:523,y:455,t:1527030517441};\\\", \\\"{x:524,y:455,t:1527030517455};\\\", \\\"{x:528,y:455,t:1527030517472};\\\", \\\"{x:540,y:455,t:1527030517488};\\\", \\\"{x:582,y:466,t:1527030517505};\\\", \\\"{x:631,y:481,t:1527030517522};\\\", \\\"{x:711,y:503,t:1527030517540};\\\", \\\"{x:819,y:534,t:1527030517556};\\\", \\\"{x:954,y:570,t:1527030517571};\\\", \\\"{x:1107,y:617,t:1527030517587};\\\", \\\"{x:1248,y:660,t:1527030517603};\\\", \\\"{x:1371,y:707,t:1527030517621};\\\", \\\"{x:1430,y:736,t:1527030517637};\\\", \\\"{x:1440,y:748,t:1527030517653};\\\", \\\"{x:1441,y:750,t:1527030517671};\\\", \\\"{x:1441,y:751,t:1527030517688};\\\", \\\"{x:1439,y:752,t:1527030517704};\\\", \\\"{x:1428,y:756,t:1527030517720};\\\", \\\"{x:1418,y:759,t:1527030517738};\\\", \\\"{x:1412,y:762,t:1527030517754};\\\", \\\"{x:1411,y:762,t:1527030517771};\\\", \\\"{x:1410,y:763,t:1527030517787};\\\", \\\"{x:1408,y:763,t:1527030517808};\\\", \\\"{x:1405,y:763,t:1527030517821};\\\", \\\"{x:1395,y:761,t:1527030517837};\\\", \\\"{x:1386,y:760,t:1527030517855};\\\", \\\"{x:1374,y:760,t:1527030517871};\\\", \\\"{x:1365,y:760,t:1527030517888};\\\", \\\"{x:1357,y:760,t:1527030517905};\\\", \\\"{x:1350,y:760,t:1527030517920};\\\", \\\"{x:1342,y:760,t:1527030517938};\\\", \\\"{x:1337,y:760,t:1527030517955};\\\", \\\"{x:1334,y:760,t:1527030517971};\\\", \\\"{x:1336,y:760,t:1527030518242};\\\", \\\"{x:1337,y:759,t:1527030518257};\\\", \\\"{x:1339,y:759,t:1527030518281};\\\", \\\"{x:1340,y:759,t:1527030518289};\\\", \\\"{x:1344,y:758,t:1527030518305};\\\", \\\"{x:1347,y:758,t:1527030518322};\\\", \\\"{x:1351,y:758,t:1527030518339};\\\", \\\"{x:1353,y:758,t:1527030518355};\\\", \\\"{x:1354,y:758,t:1527030518372};\\\", \\\"{x:1355,y:758,t:1527030518464};\\\", \\\"{x:1356,y:758,t:1527030518576};\\\", \\\"{x:1355,y:758,t:1527030518872};\\\", \\\"{x:1354,y:758,t:1527030518888};\\\", \\\"{x:1353,y:758,t:1527030518905};\\\", \\\"{x:1352,y:758,t:1527030518928};\\\", \\\"{x:1351,y:759,t:1527030518992};\\\", \\\"{x:1351,y:760,t:1527030519022};\\\", \\\"{x:1350,y:760,t:1527030519096};\\\", \\\"{x:1349,y:760,t:1527030519241};\\\", \\\"{x:1348,y:760,t:1527030519426};\\\", \\\"{x:1347,y:760,t:1527030519448};\\\", \\\"{x:1346,y:760,t:1527030519488};\\\", \\\"{x:1345,y:760,t:1527030519593};\\\", \\\"{x:1344,y:759,t:1527030522282};\\\", \\\"{x:1343,y:759,t:1527030523610};\\\", \\\"{x:1343,y:758,t:1527030525610};\\\", \\\"{x:1343,y:757,t:1527030529305};\\\", \\\"{x:1343,y:755,t:1527030529360};\\\", \\\"{x:1343,y:754,t:1527030529416};\\\", \\\"{x:1344,y:754,t:1527030532337};\\\", \\\"{x:1345,y:754,t:1527030532351};\\\", \\\"{x:1346,y:754,t:1527030532440};\\\", \\\"{x:1346,y:755,t:1527030532689};\\\", \\\"{x:1346,y:756,t:1527030532701};\\\", \\\"{x:1346,y:757,t:1527030532719};\\\", \\\"{x:1347,y:757,t:1527030532735};\\\", \\\"{x:1348,y:758,t:1527030533050};\\\", \\\"{x:1348,y:759,t:1527030533473};\\\", \\\"{x:1348,y:760,t:1527030533486};\\\", \\\"{x:1348,y:761,t:1527030533503};\\\", \\\"{x:1348,y:762,t:1527030533521};\\\", \\\"{x:1348,y:763,t:1527030533545};\\\", \\\"{x:1348,y:764,t:1527030533560};\\\", \\\"{x:1347,y:766,t:1527030533584};\\\", \\\"{x:1346,y:766,t:1527030540989};\\\", \\\"{x:1342,y:766,t:1527030540997};\\\", \\\"{x:1336,y:766,t:1527030541013};\\\", \\\"{x:1324,y:766,t:1527030541030};\\\", \\\"{x:1302,y:766,t:1527030541047};\\\", \\\"{x:1279,y:766,t:1527030541063};\\\", \\\"{x:1253,y:766,t:1527030541080};\\\", \\\"{x:1204,y:756,t:1527030541097};\\\", \\\"{x:1108,y:736,t:1527030541113};\\\", \\\"{x:1002,y:714,t:1527030541130};\\\", \\\"{x:893,y:679,t:1527030541147};\\\", \\\"{x:769,y:643,t:1527030541162};\\\", \\\"{x:655,y:610,t:1527030541181};\\\", \\\"{x:530,y:574,t:1527030541197};\\\", \\\"{x:486,y:562,t:1527030541229};\\\", \\\"{x:482,y:560,t:1527030541240};\\\", \\\"{x:481,y:559,t:1527030541257};\\\", \\\"{x:479,y:559,t:1527030541356};\\\", \\\"{x:476,y:559,t:1527030541363};\\\", \\\"{x:474,y:559,t:1527030541374};\\\", \\\"{x:463,y:567,t:1527030541391};\\\", \\\"{x:454,y:590,t:1527030541407};\\\", \\\"{x:453,y:609,t:1527030541428};\\\", \\\"{x:456,y:628,t:1527030541443};\\\", \\\"{x:462,y:650,t:1527030541461};\\\", \\\"{x:467,y:660,t:1527030541477};\\\", \\\"{x:470,y:668,t:1527030541493};\\\", \\\"{x:474,y:677,t:1527030541511};\\\", \\\"{x:476,y:682,t:1527030541527};\\\", \\\"{x:478,y:687,t:1527030541543};\\\", \\\"{x:478,y:688,t:1527030541560};\\\", \\\"{x:478,y:691,t:1527030541577};\\\", \\\"{x:478,y:693,t:1527030541619};\\\", \\\"{x:478,y:696,t:1527030541627};\\\", \\\"{x:481,y:700,t:1527030541643};\\\", \\\"{x:487,y:703,t:1527030541660};\\\", \\\"{x:489,y:705,t:1527030541678};\\\", \\\"{x:492,y:708,t:1527030541694};\\\", \\\"{x:493,y:709,t:1527030541711};\\\", \\\"{x:494,y:711,t:1527030541732};\\\", \\\"{x:495,y:715,t:1527030541745};\\\", \\\"{x:497,y:724,t:1527030541761};\\\", \\\"{x:497,y:730,t:1527030541777};\\\", \\\"{x:497,y:735,t:1527030541794};\\\", \\\"{x:497,y:739,t:1527030541810};\\\", \\\"{x:497,y:740,t:1527030541924};\\\", \\\"{x:497,y:739,t:1527030542212};\\\", \\\"{x:497,y:738,t:1527030542227};\\\", \\\"{x:497,y:737,t:1527030542244};\\\", \\\"{x:497,y:736,t:1527030542261};\\\", \\\"{x:496,y:735,t:1527030542283};\\\", \\\"{x:496,y:734,t:1527030542428};\\\", \\\"{x:496,y:733,t:1527030542444};\\\", \\\"{x:496,y:731,t:1527030542461};\\\", \\\"{x:496,y:730,t:1527030542478};\\\", \\\"{x:496,y:729,t:1527030542494};\\\", \\\"{x:494,y:728,t:1527030542511};\\\", \\\"{x:494,y:727,t:1527030542527};\\\" ] }, { \\\"rt\\\": 60605, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 549333, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -06 PM-06 PM-J -J -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:726,t:1527030547965};\\\", \\\"{x:495,y:723,t:1527030547985};\\\", \\\"{x:496,y:714,t:1527030548001};\\\", \\\"{x:498,y:704,t:1527030548016};\\\", \\\"{x:500,y:690,t:1527030548031};\\\", \\\"{x:500,y:671,t:1527030548048};\\\", \\\"{x:501,y:645,t:1527030548066};\\\", \\\"{x:504,y:627,t:1527030548082};\\\", \\\"{x:504,y:619,t:1527030548099};\\\", \\\"{x:504,y:613,t:1527030548115};\\\", \\\"{x:504,y:611,t:1527030548132};\\\", \\\"{x:505,y:607,t:1527030548148};\\\", \\\"{x:505,y:605,t:1527030548165};\\\", \\\"{x:505,y:603,t:1527030548182};\\\", \\\"{x:505,y:602,t:1527030548199};\\\", \\\"{x:505,y:601,t:1527030548215};\\\", \\\"{x:505,y:600,t:1527030548244};\\\", \\\"{x:505,y:598,t:1527030548268};\\\", \\\"{x:505,y:597,t:1527030548282};\\\", \\\"{x:502,y:591,t:1527030548300};\\\", \\\"{x:500,y:589,t:1527030548315};\\\", \\\"{x:499,y:588,t:1527030548333};\\\", \\\"{x:497,y:586,t:1527030548351};\\\", \\\"{x:497,y:585,t:1527030548365};\\\", \\\"{x:495,y:583,t:1527030548412};\\\", \\\"{x:494,y:579,t:1527030548419};\\\", \\\"{x:491,y:575,t:1527030548433};\\\", \\\"{x:482,y:564,t:1527030548450};\\\", \\\"{x:476,y:555,t:1527030548466};\\\", \\\"{x:473,y:553,t:1527030548483};\\\", \\\"{x:472,y:551,t:1527030548499};\\\", \\\"{x:471,y:550,t:1527030548516};\\\", \\\"{x:467,y:546,t:1527030548533};\\\", \\\"{x:462,y:541,t:1527030548549};\\\", \\\"{x:456,y:538,t:1527030548567};\\\", \\\"{x:453,y:536,t:1527030548582};\\\", \\\"{x:450,y:533,t:1527030548599};\\\", \\\"{x:449,y:532,t:1527030548617};\\\", \\\"{x:444,y:527,t:1527030548633};\\\", \\\"{x:435,y:516,t:1527030548650};\\\", \\\"{x:427,y:504,t:1527030548667};\\\", \\\"{x:414,y:490,t:1527030548683};\\\", \\\"{x:405,y:481,t:1527030548700};\\\", \\\"{x:403,y:478,t:1527030548716};\\\", \\\"{x:401,y:476,t:1527030548732};\\\", \\\"{x:398,y:473,t:1527030548749};\\\", \\\"{x:397,y:469,t:1527030548767};\\\", \\\"{x:396,y:467,t:1527030548782};\\\", \\\"{x:396,y:464,t:1527030548799};\\\", \\\"{x:395,y:464,t:1527030548816};\\\", \\\"{x:394,y:463,t:1527030548832};\\\", \\\"{x:394,y:462,t:1527030548884};\\\", \\\"{x:395,y:461,t:1527030551724};\\\", \\\"{x:396,y:460,t:1527030551980};\\\", \\\"{x:398,y:459,t:1527030552021};\\\", \\\"{x:402,y:457,t:1527030552045};\\\", \\\"{x:405,y:456,t:1527030552052};\\\", \\\"{x:422,y:452,t:1527030552084};\\\", \\\"{x:427,y:451,t:1527030552091};\\\", \\\"{x:428,y:451,t:1527030552102};\\\", \\\"{x:435,y:449,t:1527030552118};\\\", \\\"{x:436,y:449,t:1527030552135};\\\", \\\"{x:437,y:449,t:1527030552171};\\\", \\\"{x:438,y:449,t:1527030552188};\\\", \\\"{x:440,y:449,t:1527030552211};\\\", \\\"{x:441,y:449,t:1527030552219};\\\", \\\"{x:443,y:449,t:1527030552235};\\\", \\\"{x:445,y:448,t:1527030552251};\\\", \\\"{x:445,y:449,t:1527030553188};\\\", \\\"{x:444,y:449,t:1527030553219};\\\", \\\"{x:443,y:449,t:1527030553364};\\\", \\\"{x:442,y:450,t:1527030553372};\\\", \\\"{x:440,y:451,t:1527030553579};\\\", \\\"{x:439,y:453,t:1527030553587};\\\", \\\"{x:438,y:453,t:1527030553603};\\\", \\\"{x:436,y:455,t:1527030553619};\\\", \\\"{x:432,y:457,t:1527030553637};\\\", \\\"{x:427,y:459,t:1527030553653};\\\", \\\"{x:424,y:461,t:1527030553670};\\\", \\\"{x:419,y:463,t:1527030553686};\\\", \\\"{x:415,y:464,t:1527030553703};\\\", \\\"{x:416,y:464,t:1527030554116};\\\", \\\"{x:417,y:464,t:1527030554124};\\\", \\\"{x:418,y:463,t:1527030554137};\\\", \\\"{x:421,y:463,t:1527030554156};\\\", \\\"{x:423,y:462,t:1527030554170};\\\", \\\"{x:431,y:461,t:1527030554187};\\\", \\\"{x:457,y:461,t:1527030554204};\\\", \\\"{x:486,y:461,t:1527030554219};\\\", \\\"{x:538,y:461,t:1527030554237};\\\", \\\"{x:623,y:454,t:1527030554254};\\\", \\\"{x:720,y:442,t:1527030554270};\\\", \\\"{x:824,y:434,t:1527030554287};\\\", \\\"{x:905,y:434,t:1527030554304};\\\", \\\"{x:966,y:434,t:1527030554320};\\\", \\\"{x:1002,y:434,t:1527030554338};\\\", \\\"{x:1016,y:433,t:1527030554356};\\\", \\\"{x:1020,y:432,t:1527030554370};\\\", \\\"{x:1021,y:431,t:1527030554387};\\\", \\\"{x:1022,y:430,t:1527030554405};\\\", \\\"{x:1023,y:430,t:1527030554421};\\\", \\\"{x:1023,y:429,t:1527030554437};\\\", \\\"{x:1022,y:429,t:1527030554525};\\\", \\\"{x:1018,y:429,t:1527030554537};\\\", \\\"{x:1002,y:430,t:1527030554553};\\\", \\\"{x:978,y:433,t:1527030554572};\\\", \\\"{x:945,y:437,t:1527030554587};\\\", \\\"{x:863,y:444,t:1527030554604};\\\", \\\"{x:802,y:444,t:1527030554621};\\\", \\\"{x:729,y:444,t:1527030554637};\\\", \\\"{x:671,y:444,t:1527030554653};\\\", \\\"{x:626,y:444,t:1527030554671};\\\", \\\"{x:603,y:444,t:1527030554686};\\\", \\\"{x:593,y:444,t:1527030554704};\\\", \\\"{x:591,y:444,t:1527030554721};\\\", \\\"{x:591,y:446,t:1527030555268};\\\", \\\"{x:592,y:446,t:1527030555276};\\\", \\\"{x:593,y:447,t:1527030555292};\\\", \\\"{x:594,y:448,t:1527030555305};\\\", \\\"{x:596,y:450,t:1527030555321};\\\", \\\"{x:598,y:451,t:1527030555338};\\\", \\\"{x:600,y:453,t:1527030555355};\\\", \\\"{x:602,y:453,t:1527030555371};\\\", \\\"{x:603,y:454,t:1527030555411};\\\", \\\"{x:604,y:454,t:1527030555916};\\\", \\\"{x:605,y:454,t:1527030555923};\\\", \\\"{x:606,y:454,t:1527030555938};\\\", \\\"{x:607,y:454,t:1527030556468};\\\", \\\"{x:613,y:453,t:1527030556747};\\\", \\\"{x:629,y:454,t:1527030556755};\\\", \\\"{x:664,y:460,t:1527030556772};\\\", \\\"{x:715,y:468,t:1527030556789};\\\", \\\"{x:768,y:475,t:1527030556806};\\\", \\\"{x:822,y:479,t:1527030556821};\\\", \\\"{x:871,y:483,t:1527030556839};\\\", \\\"{x:911,y:489,t:1527030556856};\\\", \\\"{x:943,y:492,t:1527030556872};\\\", \\\"{x:969,y:497,t:1527030556889};\\\", \\\"{x:991,y:501,t:1527030556906};\\\", \\\"{x:1004,y:504,t:1527030556922};\\\", \\\"{x:1016,y:513,t:1527030556939};\\\", \\\"{x:1031,y:523,t:1527030556957};\\\", \\\"{x:1055,y:534,t:1527030556973};\\\", \\\"{x:1084,y:544,t:1527030556989};\\\", \\\"{x:1117,y:553,t:1527030557007};\\\", \\\"{x:1144,y:563,t:1527030557023};\\\", \\\"{x:1162,y:568,t:1527030557040};\\\", \\\"{x:1173,y:572,t:1527030557057};\\\", \\\"{x:1181,y:576,t:1527030557074};\\\", \\\"{x:1185,y:579,t:1527030557090};\\\", \\\"{x:1192,y:586,t:1527030557107};\\\", \\\"{x:1216,y:602,t:1527030557123};\\\", \\\"{x:1237,y:614,t:1527030557141};\\\", \\\"{x:1256,y:625,t:1527030557157};\\\", \\\"{x:1276,y:637,t:1527030557173};\\\", \\\"{x:1290,y:645,t:1527030557191};\\\", \\\"{x:1296,y:652,t:1527030557207};\\\", \\\"{x:1301,y:655,t:1527030557224};\\\", \\\"{x:1301,y:657,t:1527030557241};\\\", \\\"{x:1301,y:658,t:1527030557259};\\\", \\\"{x:1301,y:660,t:1527030557273};\\\", \\\"{x:1301,y:661,t:1527030557292};\\\", \\\"{x:1301,y:663,t:1527030557308};\\\", \\\"{x:1301,y:665,t:1527030557324};\\\", \\\"{x:1300,y:668,t:1527030557341};\\\", \\\"{x:1300,y:670,t:1527030557358};\\\", \\\"{x:1300,y:673,t:1527030557376};\\\", \\\"{x:1300,y:677,t:1527030557392};\\\", \\\"{x:1300,y:681,t:1527030557408};\\\", \\\"{x:1300,y:684,t:1527030557425};\\\", \\\"{x:1300,y:685,t:1527030557443};\\\", \\\"{x:1299,y:687,t:1527030557458};\\\", \\\"{x:1299,y:688,t:1527030557476};\\\", \\\"{x:1297,y:689,t:1527030557492};\\\", \\\"{x:1296,y:690,t:1527030557509};\\\", \\\"{x:1294,y:695,t:1527030557526};\\\", \\\"{x:1293,y:701,t:1527030557542};\\\", \\\"{x:1293,y:705,t:1527030557559};\\\", \\\"{x:1291,y:709,t:1527030557575};\\\", \\\"{x:1291,y:713,t:1527030557592};\\\", \\\"{x:1291,y:716,t:1527030557609};\\\", \\\"{x:1291,y:718,t:1527030557626};\\\", \\\"{x:1291,y:720,t:1527030557642};\\\", \\\"{x:1291,y:723,t:1527030557659};\\\", \\\"{x:1292,y:730,t:1527030557676};\\\", \\\"{x:1293,y:734,t:1527030557693};\\\", \\\"{x:1295,y:738,t:1527030557709};\\\", \\\"{x:1295,y:741,t:1527030557727};\\\", \\\"{x:1297,y:744,t:1527030557743};\\\", \\\"{x:1298,y:745,t:1527030557759};\\\", \\\"{x:1299,y:748,t:1527030557777};\\\", \\\"{x:1300,y:748,t:1527030557794};\\\", \\\"{x:1300,y:749,t:1527030557810};\\\", \\\"{x:1301,y:750,t:1527030557826};\\\", \\\"{x:1302,y:751,t:1527030557844};\\\", \\\"{x:1304,y:756,t:1527030557860};\\\", \\\"{x:1308,y:760,t:1527030557877};\\\", \\\"{x:1311,y:763,t:1527030557893};\\\", \\\"{x:1313,y:766,t:1527030557910};\\\", \\\"{x:1314,y:767,t:1527030557928};\\\", \\\"{x:1315,y:768,t:1527030557944};\\\", \\\"{x:1317,y:768,t:1527030558124};\\\", \\\"{x:1319,y:768,t:1527030558132};\\\", \\\"{x:1320,y:768,t:1527030558145};\\\", \\\"{x:1322,y:768,t:1527030558161};\\\", \\\"{x:1323,y:768,t:1527030558229};\\\", \\\"{x:1324,y:767,t:1527030558245};\\\", \\\"{x:1325,y:767,t:1527030558268};\\\", \\\"{x:1326,y:767,t:1527030558316};\\\", \\\"{x:1327,y:767,t:1527030558332};\\\", \\\"{x:1328,y:767,t:1527030558346};\\\", \\\"{x:1329,y:767,t:1527030558362};\\\", \\\"{x:1333,y:767,t:1527030558379};\\\", \\\"{x:1337,y:767,t:1527030558396};\\\", \\\"{x:1342,y:767,t:1527030558412};\\\", \\\"{x:1345,y:767,t:1527030558432};\\\", \\\"{x:1347,y:767,t:1527030558462};\\\", \\\"{x:1348,y:766,t:1527030558483};\\\", \\\"{x:1350,y:765,t:1527030558515};\\\", \\\"{x:1351,y:765,t:1527030558528};\\\", \\\"{x:1353,y:764,t:1527030558546};\\\", \\\"{x:1353,y:763,t:1527030558693};\\\", \\\"{x:1353,y:762,t:1527030558708};\\\", \\\"{x:1352,y:762,t:1527030559212};\\\", \\\"{x:1351,y:762,t:1527030559220};\\\", \\\"{x:1350,y:762,t:1527030559508};\\\", \\\"{x:1348,y:763,t:1527030559524};\\\", \\\"{x:1347,y:763,t:1527030559612};\\\", \\\"{x:1344,y:763,t:1527030559627};\\\", \\\"{x:1343,y:763,t:1527030559636};\\\", \\\"{x:1342,y:763,t:1527030559651};\\\", \\\"{x:1341,y:763,t:1527030559668};\\\", \\\"{x:1340,y:763,t:1527030559756};\\\", \\\"{x:1340,y:762,t:1527030559788};\\\", \\\"{x:1338,y:761,t:1527030561940};\\\", \\\"{x:1327,y:757,t:1527030561948};\\\", \\\"{x:1301,y:751,t:1527030561960};\\\", \\\"{x:1221,y:729,t:1527030561976};\\\", \\\"{x:1139,y:703,t:1527030561993};\\\", \\\"{x:1046,y:663,t:1527030562009};\\\", \\\"{x:948,y:631,t:1527030562027};\\\", \\\"{x:859,y:606,t:1527030562042};\\\", \\\"{x:756,y:576,t:1527030562059};\\\", \\\"{x:706,y:562,t:1527030562078};\\\", \\\"{x:680,y:557,t:1527030562094};\\\", \\\"{x:662,y:555,t:1527030562111};\\\", \\\"{x:649,y:551,t:1527030562127};\\\", \\\"{x:636,y:550,t:1527030562144};\\\", \\\"{x:628,y:546,t:1527030562160};\\\", \\\"{x:622,y:544,t:1527030562176};\\\", \\\"{x:608,y:541,t:1527030562194};\\\", \\\"{x:587,y:535,t:1527030562210};\\\", \\\"{x:553,y:525,t:1527030562227};\\\", \\\"{x:533,y:520,t:1527030562244};\\\", \\\"{x:516,y:514,t:1527030562260};\\\", \\\"{x:502,y:509,t:1527030562277};\\\", \\\"{x:487,y:503,t:1527030562295};\\\", \\\"{x:477,y:498,t:1527030562310};\\\", \\\"{x:463,y:493,t:1527030562327};\\\", \\\"{x:453,y:488,t:1527030562344};\\\", \\\"{x:442,y:483,t:1527030562360};\\\", \\\"{x:430,y:479,t:1527030562377};\\\", \\\"{x:418,y:475,t:1527030562394};\\\", \\\"{x:406,y:472,t:1527030562411};\\\", \\\"{x:399,y:470,t:1527030562427};\\\", \\\"{x:396,y:469,t:1527030562444};\\\", \\\"{x:393,y:468,t:1527030562461};\\\", \\\"{x:392,y:467,t:1527030562491};\\\", \\\"{x:391,y:467,t:1527030562588};\\\", \\\"{x:391,y:465,t:1527030566420};\\\", \\\"{x:396,y:463,t:1527030566430};\\\", \\\"{x:402,y:459,t:1527030566447};\\\", \\\"{x:408,y:456,t:1527030566465};\\\", \\\"{x:414,y:455,t:1527030566481};\\\", \\\"{x:419,y:451,t:1527030566497};\\\", \\\"{x:426,y:451,t:1527030566514};\\\", \\\"{x:429,y:451,t:1527030566530};\\\", \\\"{x:438,y:451,t:1527030566548};\\\", \\\"{x:443,y:451,t:1527030566563};\\\", \\\"{x:445,y:451,t:1527030566581};\\\", \\\"{x:447,y:451,t:1527030566598};\\\", \\\"{x:453,y:452,t:1527030566614};\\\", \\\"{x:459,y:452,t:1527030566631};\\\", \\\"{x:461,y:452,t:1527030566647};\\\", \\\"{x:463,y:452,t:1527030566665};\\\", \\\"{x:464,y:452,t:1527030566680};\\\", \\\"{x:465,y:452,t:1527030566698};\\\", \\\"{x:466,y:452,t:1527030566724};\\\", \\\"{x:467,y:452,t:1527030566740};\\\", \\\"{x:469,y:453,t:1527030566748};\\\", \\\"{x:473,y:455,t:1527030566764};\\\", \\\"{x:480,y:457,t:1527030566781};\\\", \\\"{x:482,y:459,t:1527030566797};\\\", \\\"{x:484,y:459,t:1527030566815};\\\", \\\"{x:485,y:460,t:1527030566830};\\\", \\\"{x:487,y:461,t:1527030566892};\\\", \\\"{x:488,y:461,t:1527030566907};\\\", \\\"{x:490,y:462,t:1527030566916};\\\", \\\"{x:491,y:463,t:1527030566932};\\\", \\\"{x:492,y:463,t:1527030567268};\\\", \\\"{x:491,y:464,t:1527030567284};\\\", \\\"{x:491,y:465,t:1527030567324};\\\", \\\"{x:491,y:464,t:1527030567524};\\\", \\\"{x:492,y:464,t:1527030567532};\\\", \\\"{x:492,y:463,t:1527030567548};\\\", \\\"{x:493,y:462,t:1527030567620};\\\", \\\"{x:494,y:462,t:1527030567676};\\\", \\\"{x:495,y:462,t:1527030567812};\\\", \\\"{x:495,y:461,t:1527030567836};\\\", \\\"{x:496,y:460,t:1527030567867};\\\", \\\"{x:497,y:460,t:1527030568108};\\\", \\\"{x:497,y:462,t:1527030568123};\\\", \\\"{x:497,y:463,t:1527030568132};\\\", \\\"{x:497,y:464,t:1527030568180};\\\", \\\"{x:497,y:463,t:1527030568348};\\\", \\\"{x:497,y:462,t:1527030568492};\\\", \\\"{x:497,y:461,t:1527030568499};\\\", \\\"{x:497,y:460,t:1527030568516};\\\", \\\"{x:500,y:459,t:1527030568707};\\\", \\\"{x:511,y:459,t:1527030568715};\\\", \\\"{x:550,y:467,t:1527030568732};\\\", \\\"{x:633,y:490,t:1527030568750};\\\", \\\"{x:790,y:555,t:1527030568766};\\\", \\\"{x:947,y:622,t:1527030568783};\\\", \\\"{x:1132,y:712,t:1527030568799};\\\", \\\"{x:1316,y:810,t:1527030568815};\\\", \\\"{x:1501,y:898,t:1527030568832};\\\", \\\"{x:1667,y:956,t:1527030568849};\\\", \\\"{x:1753,y:979,t:1527030568865};\\\", \\\"{x:1776,y:985,t:1527030568882};\\\", \\\"{x:1772,y:985,t:1527030568940};\\\", \\\"{x:1766,y:985,t:1527030568949};\\\", \\\"{x:1747,y:977,t:1527030568967};\\\", \\\"{x:1720,y:966,t:1527030568982};\\\", \\\"{x:1665,y:944,t:1527030568999};\\\", \\\"{x:1597,y:919,t:1527030569016};\\\", \\\"{x:1506,y:894,t:1527030569032};\\\", \\\"{x:1426,y:873,t:1527030569050};\\\", \\\"{x:1349,y:853,t:1527030569066};\\\", \\\"{x:1288,y:836,t:1527030569082};\\\", \\\"{x:1231,y:818,t:1527030569099};\\\", \\\"{x:1211,y:812,t:1527030569116};\\\", \\\"{x:1204,y:808,t:1527030569132};\\\", \\\"{x:1201,y:806,t:1527030569149};\\\", \\\"{x:1199,y:803,t:1527030569166};\\\", \\\"{x:1198,y:800,t:1527030569182};\\\", \\\"{x:1197,y:797,t:1527030569199};\\\", \\\"{x:1196,y:795,t:1527030569216};\\\", \\\"{x:1195,y:795,t:1527030569387};\\\", \\\"{x:1194,y:795,t:1527030569403};\\\", \\\"{x:1194,y:796,t:1527030569427};\\\", \\\"{x:1194,y:797,t:1527030569443};\\\", \\\"{x:1194,y:798,t:1527030569451};\\\", \\\"{x:1194,y:799,t:1527030569467};\\\", \\\"{x:1192,y:803,t:1527030569483};\\\", \\\"{x:1192,y:811,t:1527030569499};\\\", \\\"{x:1192,y:817,t:1527030569517};\\\", \\\"{x:1192,y:820,t:1527030569533};\\\", \\\"{x:1193,y:822,t:1527030569549};\\\", \\\"{x:1193,y:823,t:1527030569567};\\\", \\\"{x:1193,y:824,t:1527030569612};\\\", \\\"{x:1194,y:824,t:1527030569708};\\\", \\\"{x:1195,y:824,t:1527030569724};\\\", \\\"{x:1196,y:824,t:1527030569734};\\\", \\\"{x:1198,y:822,t:1527030569749};\\\", \\\"{x:1200,y:821,t:1527030569767};\\\", \\\"{x:1201,y:821,t:1527030569783};\\\", \\\"{x:1202,y:820,t:1527030569800};\\\", \\\"{x:1202,y:819,t:1527030570268};\\\", \\\"{x:1201,y:815,t:1527030570284};\\\", \\\"{x:1200,y:814,t:1527030570301};\\\", \\\"{x:1198,y:811,t:1527030570317};\\\", \\\"{x:1194,y:806,t:1527030570334};\\\", \\\"{x:1192,y:803,t:1527030570351};\\\", \\\"{x:1191,y:801,t:1527030570368};\\\", \\\"{x:1190,y:799,t:1527030570384};\\\", \\\"{x:1189,y:798,t:1527030570400};\\\", \\\"{x:1188,y:797,t:1527030570417};\\\", \\\"{x:1187,y:796,t:1527030570467};\\\", \\\"{x:1186,y:795,t:1527030570507};\\\", \\\"{x:1187,y:796,t:1527030570651};\\\", \\\"{x:1203,y:806,t:1527030570668};\\\", \\\"{x:1218,y:813,t:1527030570683};\\\", \\\"{x:1223,y:816,t:1527030570700};\\\", \\\"{x:1224,y:816,t:1527030570718};\\\", \\\"{x:1226,y:816,t:1527030570733};\\\", \\\"{x:1227,y:816,t:1527030570763};\\\", \\\"{x:1228,y:816,t:1527030570852};\\\", \\\"{x:1227,y:816,t:1527030570964};\\\", \\\"{x:1226,y:815,t:1527030570972};\\\", \\\"{x:1225,y:815,t:1527030570985};\\\", \\\"{x:1220,y:814,t:1527030571001};\\\", \\\"{x:1217,y:813,t:1527030571017};\\\", \\\"{x:1212,y:812,t:1527030571035};\\\", \\\"{x:1209,y:812,t:1527030571052};\\\", \\\"{x:1204,y:812,t:1527030571068};\\\", \\\"{x:1201,y:812,t:1527030571085};\\\", \\\"{x:1196,y:812,t:1527030571101};\\\", \\\"{x:1192,y:812,t:1527030571117};\\\", \\\"{x:1189,y:812,t:1527030571135};\\\", \\\"{x:1188,y:812,t:1527030571151};\\\", \\\"{x:1187,y:813,t:1527030571168};\\\", \\\"{x:1185,y:813,t:1527030571185};\\\", \\\"{x:1189,y:812,t:1527030572996};\\\", \\\"{x:1198,y:812,t:1527030573004};\\\", \\\"{x:1223,y:812,t:1527030573020};\\\", \\\"{x:1254,y:812,t:1527030573036};\\\", \\\"{x:1290,y:812,t:1527030573053};\\\", \\\"{x:1323,y:812,t:1527030573070};\\\", \\\"{x:1349,y:811,t:1527030573086};\\\", \\\"{x:1361,y:809,t:1527030573103};\\\", \\\"{x:1366,y:807,t:1527030573120};\\\", \\\"{x:1367,y:806,t:1527030573171};\\\", \\\"{x:1370,y:805,t:1527030573185};\\\", \\\"{x:1372,y:801,t:1527030573202};\\\", \\\"{x:1373,y:794,t:1527030573218};\\\", \\\"{x:1373,y:789,t:1527030573235};\\\", \\\"{x:1373,y:784,t:1527030573253};\\\", \\\"{x:1373,y:782,t:1527030573269};\\\", \\\"{x:1373,y:781,t:1527030573285};\\\", \\\"{x:1372,y:781,t:1527030573302};\\\", \\\"{x:1372,y:779,t:1527030573319};\\\", \\\"{x:1372,y:777,t:1527030573336};\\\", \\\"{x:1371,y:775,t:1527030573352};\\\", \\\"{x:1371,y:774,t:1527030573370};\\\", \\\"{x:1370,y:774,t:1527030573385};\\\", \\\"{x:1370,y:773,t:1527030573403};\\\", \\\"{x:1369,y:772,t:1527030573460};\\\", \\\"{x:1369,y:771,t:1527030573469};\\\", \\\"{x:1365,y:768,t:1527030573487};\\\", \\\"{x:1363,y:765,t:1527030573503};\\\", \\\"{x:1361,y:763,t:1527030573520};\\\", \\\"{x:1359,y:761,t:1527030573537};\\\", \\\"{x:1358,y:759,t:1527030573553};\\\", \\\"{x:1355,y:757,t:1527030573570};\\\", \\\"{x:1351,y:755,t:1527030573587};\\\", \\\"{x:1349,y:753,t:1527030573603};\\\", \\\"{x:1347,y:752,t:1527030573619};\\\", \\\"{x:1346,y:752,t:1527030573692};\\\", \\\"{x:1345,y:752,t:1527030573715};\\\", \\\"{x:1343,y:752,t:1527030573740};\\\", \\\"{x:1342,y:752,t:1527030573764};\\\", \\\"{x:1341,y:752,t:1527030573772};\\\", \\\"{x:1338,y:755,t:1527030573787};\\\", \\\"{x:1334,y:760,t:1527030573803};\\\", \\\"{x:1324,y:770,t:1527030573820};\\\", \\\"{x:1316,y:779,t:1527030573837};\\\", \\\"{x:1310,y:788,t:1527030573854};\\\", \\\"{x:1304,y:797,t:1527030573870};\\\", \\\"{x:1302,y:799,t:1527030573887};\\\", \\\"{x:1301,y:802,t:1527030573905};\\\", \\\"{x:1300,y:803,t:1527030573920};\\\", \\\"{x:1300,y:804,t:1527030573937};\\\", \\\"{x:1300,y:806,t:1527030573954};\\\", \\\"{x:1299,y:808,t:1527030573970};\\\", \\\"{x:1299,y:810,t:1527030573988};\\\", \\\"{x:1299,y:814,t:1527030574004};\\\", \\\"{x:1299,y:816,t:1527030574020};\\\", \\\"{x:1299,y:819,t:1527030574037};\\\", \\\"{x:1299,y:820,t:1527030574054};\\\", \\\"{x:1299,y:822,t:1527030574070};\\\", \\\"{x:1299,y:824,t:1527030574087};\\\", \\\"{x:1299,y:826,t:1527030574104};\\\", \\\"{x:1299,y:829,t:1527030574120};\\\", \\\"{x:1299,y:832,t:1527030574137};\\\", \\\"{x:1299,y:835,t:1527030574154};\\\", \\\"{x:1299,y:836,t:1527030574170};\\\", \\\"{x:1299,y:840,t:1527030574187};\\\", \\\"{x:1299,y:843,t:1527030574204};\\\", \\\"{x:1298,y:845,t:1527030574221};\\\", \\\"{x:1297,y:848,t:1527030574237};\\\", \\\"{x:1296,y:852,t:1527030574254};\\\", \\\"{x:1296,y:855,t:1527030574270};\\\", \\\"{x:1295,y:859,t:1527030574287};\\\", \\\"{x:1292,y:864,t:1527030574304};\\\", \\\"{x:1291,y:868,t:1527030574321};\\\", \\\"{x:1289,y:872,t:1527030574337};\\\", \\\"{x:1287,y:877,t:1527030574354};\\\", \\\"{x:1286,y:880,t:1527030574371};\\\", \\\"{x:1284,y:885,t:1527030574387};\\\", \\\"{x:1280,y:891,t:1527030574403};\\\", \\\"{x:1277,y:897,t:1527030574421};\\\", \\\"{x:1276,y:898,t:1527030574437};\\\", \\\"{x:1274,y:900,t:1527030574454};\\\", \\\"{x:1274,y:901,t:1527030574476};\\\", \\\"{x:1273,y:902,t:1527030574500};\\\", \\\"{x:1273,y:903,t:1527030574516};\\\", \\\"{x:1271,y:903,t:1527030574524};\\\", \\\"{x:1271,y:904,t:1527030574537};\\\", \\\"{x:1268,y:906,t:1527030574554};\\\", \\\"{x:1266,y:908,t:1527030574571};\\\", \\\"{x:1265,y:909,t:1527030574587};\\\", \\\"{x:1262,y:911,t:1527030574604};\\\", \\\"{x:1260,y:912,t:1527030574622};\\\", \\\"{x:1259,y:914,t:1527030574637};\\\", \\\"{x:1258,y:914,t:1527030574654};\\\", \\\"{x:1255,y:917,t:1527030574671};\\\", \\\"{x:1254,y:918,t:1527030574687};\\\", \\\"{x:1253,y:918,t:1527030574704};\\\", \\\"{x:1252,y:919,t:1527030574721};\\\", \\\"{x:1251,y:920,t:1527030574740};\\\", \\\"{x:1250,y:921,t:1527030574754};\\\", \\\"{x:1250,y:922,t:1527030574772};\\\", \\\"{x:1249,y:924,t:1527030574788};\\\", \\\"{x:1248,y:925,t:1527030574811};\\\", \\\"{x:1248,y:926,t:1527030574821};\\\", \\\"{x:1248,y:927,t:1527030574838};\\\", \\\"{x:1247,y:928,t:1527030574854};\\\", \\\"{x:1247,y:932,t:1527030574871};\\\", \\\"{x:1245,y:937,t:1527030574888};\\\", \\\"{x:1245,y:941,t:1527030574904};\\\", \\\"{x:1245,y:945,t:1527030574921};\\\", \\\"{x:1244,y:948,t:1527030574938};\\\", \\\"{x:1244,y:950,t:1527030574956};\\\", \\\"{x:1243,y:950,t:1527030574995};\\\", \\\"{x:1243,y:951,t:1527030575020};\\\", \\\"{x:1243,y:953,t:1527030575044};\\\", \\\"{x:1244,y:950,t:1527030575260};\\\", \\\"{x:1246,y:949,t:1527030575271};\\\", \\\"{x:1256,y:940,t:1527030575288};\\\", \\\"{x:1264,y:932,t:1527030575305};\\\", \\\"{x:1273,y:924,t:1527030575321};\\\", \\\"{x:1280,y:915,t:1527030575338};\\\", \\\"{x:1285,y:907,t:1527030575356};\\\", \\\"{x:1287,y:905,t:1527030575371};\\\", \\\"{x:1291,y:899,t:1527030575389};\\\", \\\"{x:1291,y:896,t:1527030575405};\\\", \\\"{x:1291,y:894,t:1527030575421};\\\", \\\"{x:1292,y:894,t:1527030575439};\\\", \\\"{x:1292,y:893,t:1527030575492};\\\", \\\"{x:1293,y:890,t:1527030575505};\\\", \\\"{x:1294,y:884,t:1527030575522};\\\", \\\"{x:1296,y:877,t:1527030575538};\\\", \\\"{x:1299,y:866,t:1527030575555};\\\", \\\"{x:1300,y:864,t:1527030575571};\\\", \\\"{x:1302,y:861,t:1527030575588};\\\", \\\"{x:1302,y:860,t:1527030575605};\\\", \\\"{x:1302,y:859,t:1527030575635};\\\", \\\"{x:1303,y:856,t:1527030575644};\\\", \\\"{x:1304,y:853,t:1527030575655};\\\", \\\"{x:1306,y:844,t:1527030575672};\\\", \\\"{x:1311,y:836,t:1527030575688};\\\", \\\"{x:1312,y:830,t:1527030575706};\\\", \\\"{x:1314,y:828,t:1527030575723};\\\", \\\"{x:1314,y:827,t:1527030575738};\\\", \\\"{x:1315,y:825,t:1527030575756};\\\", \\\"{x:1318,y:822,t:1527030575772};\\\", \\\"{x:1322,y:816,t:1527030575788};\\\", \\\"{x:1325,y:809,t:1527030575805};\\\", \\\"{x:1327,y:805,t:1527030575822};\\\", \\\"{x:1328,y:803,t:1527030575838};\\\", \\\"{x:1329,y:801,t:1527030575892};\\\", \\\"{x:1331,y:798,t:1527030575907};\\\", \\\"{x:1334,y:797,t:1527030575922};\\\", \\\"{x:1341,y:792,t:1527030575938};\\\", \\\"{x:1345,y:788,t:1527030575955};\\\", \\\"{x:1346,y:787,t:1527030575973};\\\", \\\"{x:1346,y:786,t:1527030575996};\\\", \\\"{x:1347,y:785,t:1527030576012};\\\", \\\"{x:1347,y:784,t:1527030576052};\\\", \\\"{x:1347,y:783,t:1527030576068};\\\", \\\"{x:1347,y:782,t:1527030576100};\\\", \\\"{x:1348,y:781,t:1527030576115};\\\", \\\"{x:1348,y:778,t:1527030576204};\\\", \\\"{x:1348,y:773,t:1527030576223};\\\", \\\"{x:1348,y:771,t:1527030576239};\\\", \\\"{x:1348,y:769,t:1527030576255};\\\", \\\"{x:1348,y:768,t:1527030576272};\\\", \\\"{x:1348,y:767,t:1527030576660};\\\", \\\"{x:1346,y:767,t:1527030576672};\\\", \\\"{x:1340,y:769,t:1527030576690};\\\", \\\"{x:1332,y:778,t:1527030576707};\\\", \\\"{x:1321,y:788,t:1527030576722};\\\", \\\"{x:1308,y:800,t:1527030576740};\\\", \\\"{x:1301,y:808,t:1527030576755};\\\", \\\"{x:1301,y:811,t:1527030576772};\\\", \\\"{x:1300,y:816,t:1527030576789};\\\", \\\"{x:1300,y:820,t:1527030576806};\\\", \\\"{x:1300,y:825,t:1527030576822};\\\", \\\"{x:1300,y:830,t:1527030576839};\\\", \\\"{x:1300,y:834,t:1527030576856};\\\", \\\"{x:1300,y:838,t:1527030576872};\\\", \\\"{x:1300,y:840,t:1527030576892};\\\", \\\"{x:1300,y:841,t:1527030576908};\\\", \\\"{x:1300,y:843,t:1527030576923};\\\", \\\"{x:1298,y:845,t:1527030576939};\\\", \\\"{x:1296,y:850,t:1527030576955};\\\", \\\"{x:1293,y:855,t:1527030576973};\\\", \\\"{x:1290,y:859,t:1527030576989};\\\", \\\"{x:1287,y:864,t:1527030577006};\\\", \\\"{x:1283,y:867,t:1527030577023};\\\", \\\"{x:1279,y:871,t:1527030577040};\\\", \\\"{x:1275,y:876,t:1527030577057};\\\", \\\"{x:1270,y:883,t:1527030577073};\\\", \\\"{x:1266,y:890,t:1527030577089};\\\", \\\"{x:1265,y:895,t:1527030577106};\\\", \\\"{x:1262,y:900,t:1527030577123};\\\", \\\"{x:1262,y:901,t:1527030577139};\\\", \\\"{x:1261,y:903,t:1527030577157};\\\", \\\"{x:1261,y:905,t:1527030577172};\\\", \\\"{x:1260,y:908,t:1527030577189};\\\", \\\"{x:1260,y:909,t:1527030577206};\\\", \\\"{x:1260,y:911,t:1527030577243};\\\", \\\"{x:1260,y:913,t:1527030577291};\\\", \\\"{x:1260,y:915,t:1527030577306};\\\", \\\"{x:1260,y:920,t:1527030577323};\\\", \\\"{x:1260,y:927,t:1527030577339};\\\", \\\"{x:1260,y:928,t:1527030577412};\\\", \\\"{x:1259,y:929,t:1527030577424};\\\", \\\"{x:1259,y:932,t:1527030577440};\\\", \\\"{x:1259,y:936,t:1527030577456};\\\", \\\"{x:1259,y:940,t:1527030577473};\\\", \\\"{x:1259,y:941,t:1527030577490};\\\", \\\"{x:1259,y:942,t:1527030577506};\\\", \\\"{x:1257,y:942,t:1527030577676};\\\", \\\"{x:1256,y:942,t:1527030577690};\\\", \\\"{x:1253,y:942,t:1527030577707};\\\", \\\"{x:1252,y:942,t:1527030577724};\\\", \\\"{x:1249,y:943,t:1527030577740};\\\", \\\"{x:1246,y:944,t:1527030577756};\\\", \\\"{x:1246,y:945,t:1527030578149};\\\", \\\"{x:1246,y:946,t:1527030578188};\\\", \\\"{x:1246,y:947,t:1527030578212};\\\", \\\"{x:1246,y:948,t:1527030578228};\\\", \\\"{x:1246,y:950,t:1527030578240};\\\", \\\"{x:1247,y:953,t:1527030578257};\\\", \\\"{x:1247,y:954,t:1527030578276};\\\", \\\"{x:1247,y:955,t:1527030578388};\\\", \\\"{x:1247,y:956,t:1527030578404};\\\", \\\"{x:1248,y:957,t:1527030578565};\\\", \\\"{x:1249,y:957,t:1527030578700};\\\", \\\"{x:1250,y:957,t:1527030578716};\\\", \\\"{x:1250,y:958,t:1527030578724};\\\", \\\"{x:1250,y:960,t:1527030578741};\\\", \\\"{x:1250,y:961,t:1527030578757};\\\", \\\"{x:1250,y:962,t:1527030578916};\\\", \\\"{x:1249,y:962,t:1527030578956};\\\", \\\"{x:1248,y:962,t:1527030579021};\\\", \\\"{x:1247,y:962,t:1527030582228};\\\", \\\"{x:1238,y:953,t:1527030600152};\\\", \\\"{x:1221,y:943,t:1527030600161};\\\", \\\"{x:1142,y:886,t:1527030600177};\\\", \\\"{x:1046,y:829,t:1527030600194};\\\", \\\"{x:933,y:754,t:1527030600211};\\\", \\\"{x:824,y:673,t:1527030600228};\\\", \\\"{x:708,y:593,t:1527030600245};\\\", \\\"{x:629,y:536,t:1527030600261};\\\", \\\"{x:594,y:500,t:1527030600279};\\\", \\\"{x:590,y:493,t:1527030600295};\\\", \\\"{x:590,y:490,t:1527030600312};\\\", \\\"{x:587,y:484,t:1527030600328};\\\", \\\"{x:583,y:476,t:1527030600345};\\\", \\\"{x:578,y:468,t:1527030600361};\\\", \\\"{x:572,y:461,t:1527030600379};\\\", \\\"{x:567,y:457,t:1527030600395};\\\", \\\"{x:564,y:454,t:1527030600411};\\\", \\\"{x:562,y:452,t:1527030600428};\\\", \\\"{x:561,y:451,t:1527030600446};\\\", \\\"{x:545,y:448,t:1527030600462};\\\", \\\"{x:532,y:446,t:1527030600478};\\\", \\\"{x:520,y:445,t:1527030600496};\\\", \\\"{x:510,y:445,t:1527030600512};\\\", \\\"{x:498,y:447,t:1527030600528};\\\", \\\"{x:490,y:451,t:1527030600546};\\\", \\\"{x:481,y:457,t:1527030600562};\\\", \\\"{x:473,y:462,t:1527030600578};\\\", \\\"{x:466,y:465,t:1527030600595};\\\", \\\"{x:462,y:465,t:1527030600612};\\\", \\\"{x:454,y:468,t:1527030600628};\\\", \\\"{x:437,y:471,t:1527030600646};\\\", \\\"{x:407,y:481,t:1527030600662};\\\", \\\"{x:389,y:486,t:1527030600678};\\\", \\\"{x:382,y:487,t:1527030600697};\\\", \\\"{x:379,y:489,t:1527030600712};\\\", \\\"{x:376,y:490,t:1527030600760};\\\", \\\"{x:368,y:493,t:1527030600779};\\\", \\\"{x:349,y:499,t:1527030600795};\\\", \\\"{x:338,y:502,t:1527030600812};\\\", \\\"{x:332,y:503,t:1527030600829};\\\", \\\"{x:330,y:504,t:1527030600845};\\\", \\\"{x:328,y:504,t:1527030600895};\\\", \\\"{x:325,y:504,t:1527030600903};\\\", \\\"{x:320,y:504,t:1527030600912};\\\", \\\"{x:305,y:504,t:1527030600929};\\\", \\\"{x:291,y:504,t:1527030600945};\\\", \\\"{x:281,y:504,t:1527030600962};\\\", \\\"{x:272,y:501,t:1527030600981};\\\", \\\"{x:267,y:499,t:1527030600995};\\\", \\\"{x:265,y:499,t:1527030601012};\\\", \\\"{x:258,y:499,t:1527030601029};\\\", \\\"{x:228,y:499,t:1527030601046};\\\", \\\"{x:201,y:499,t:1527030601062};\\\", \\\"{x:179,y:499,t:1527030601079};\\\", \\\"{x:166,y:499,t:1527030601096};\\\", \\\"{x:160,y:499,t:1527030601112};\\\", \\\"{x:157,y:498,t:1527030601130};\\\", \\\"{x:155,y:498,t:1527030601145};\\\", \\\"{x:154,y:498,t:1527030601174};\\\", \\\"{x:153,y:498,t:1527030601199};\\\", \\\"{x:152,y:498,t:1527030601215};\\\", \\\"{x:157,y:500,t:1527030601519};\\\", \\\"{x:164,y:505,t:1527030601529};\\\", \\\"{x:183,y:519,t:1527030601546};\\\", \\\"{x:222,y:547,t:1527030601563};\\\", \\\"{x:286,y:591,t:1527030601579};\\\", \\\"{x:361,y:643,t:1527030601596};\\\", \\\"{x:444,y:698,t:1527030601612};\\\", \\\"{x:517,y:750,t:1527030601630};\\\", \\\"{x:607,y:817,t:1527030601646};\\\", \\\"{x:630,y:833,t:1527030601663};\\\", \\\"{x:639,y:839,t:1527030601679};\\\", \\\"{x:640,y:840,t:1527030601696};\\\", \\\"{x:643,y:840,t:1527030601774};\\\", \\\"{x:643,y:836,t:1527030601782};\\\", \\\"{x:643,y:833,t:1527030601796};\\\", \\\"{x:643,y:832,t:1527030601814};\\\", \\\"{x:643,y:830,t:1527030601838};\\\", \\\"{x:643,y:829,t:1527030601846};\\\", \\\"{x:638,y:823,t:1527030601863};\\\", \\\"{x:626,y:814,t:1527030601879};\\\", \\\"{x:608,y:804,t:1527030601896};\\\", \\\"{x:590,y:796,t:1527030601913};\\\", \\\"{x:575,y:791,t:1527030601929};\\\", \\\"{x:567,y:787,t:1527030601946};\\\", \\\"{x:565,y:787,t:1527030601964};\\\", \\\"{x:563,y:786,t:1527030601979};\\\", \\\"{x:563,y:785,t:1527030601996};\\\", \\\"{x:559,y:785,t:1527030602013};\\\", \\\"{x:552,y:785,t:1527030602030};\\\", \\\"{x:539,y:784,t:1527030602046};\\\", \\\"{x:528,y:778,t:1527030602064};\\\", \\\"{x:510,y:763,t:1527030602079};\\\", \\\"{x:490,y:744,t:1527030602097};\\\", \\\"{x:454,y:713,t:1527030602114};\\\", \\\"{x:427,y:692,t:1527030602130};\\\", \\\"{x:390,y:667,t:1527030602147};\\\", \\\"{x:368,y:655,t:1527030602163};\\\", \\\"{x:351,y:645,t:1527030602180};\\\", \\\"{x:336,y:636,t:1527030602196};\\\", \\\"{x:326,y:630,t:1527030602213};\\\", \\\"{x:311,y:622,t:1527030602229};\\\", \\\"{x:287,y:609,t:1527030602246};\\\", \\\"{x:275,y:598,t:1527030602264};\\\", \\\"{x:266,y:591,t:1527030602280};\\\", \\\"{x:262,y:586,t:1527030602296};\\\", \\\"{x:260,y:583,t:1527030602314};\\\", \\\"{x:259,y:582,t:1527030602329};\\\", \\\"{x:258,y:581,t:1527030602346};\\\", \\\"{x:256,y:578,t:1527030602363};\\\", \\\"{x:252,y:574,t:1527030602379};\\\", \\\"{x:248,y:571,t:1527030602396};\\\", \\\"{x:243,y:567,t:1527030602413};\\\", \\\"{x:240,y:566,t:1527030602430};\\\", \\\"{x:237,y:563,t:1527030602446};\\\", \\\"{x:234,y:560,t:1527030602464};\\\", \\\"{x:231,y:556,t:1527030602479};\\\", \\\"{x:226,y:552,t:1527030602497};\\\", \\\"{x:219,y:545,t:1527030602513};\\\", \\\"{x:216,y:543,t:1527030602530};\\\", \\\"{x:213,y:542,t:1527030602548};\\\", \\\"{x:209,y:538,t:1527030602564};\\\", \\\"{x:207,y:536,t:1527030602580};\\\", \\\"{x:204,y:533,t:1527030602597};\\\", \\\"{x:198,y:527,t:1527030602613};\\\", \\\"{x:190,y:520,t:1527030602630};\\\", \\\"{x:185,y:517,t:1527030602648};\\\", \\\"{x:183,y:515,t:1527030602663};\\\", \\\"{x:182,y:514,t:1527030602694};\\\", \\\"{x:181,y:514,t:1527030602703};\\\", \\\"{x:180,y:512,t:1527030602719};\\\", \\\"{x:179,y:511,t:1527030602740};\\\", \\\"{x:178,y:511,t:1527030602746};\\\", \\\"{x:176,y:508,t:1527030602763};\\\", \\\"{x:176,y:507,t:1527030602780};\\\", \\\"{x:175,y:507,t:1527030602797};\\\", \\\"{x:175,y:506,t:1527030602813};\\\", \\\"{x:174,y:505,t:1527030602831};\\\", \\\"{x:173,y:504,t:1527030602847};\\\", \\\"{x:173,y:503,t:1527030602864};\\\", \\\"{x:172,y:503,t:1527030602927};\\\", \\\"{x:174,y:503,t:1527030603078};\\\", \\\"{x:178,y:503,t:1527030603086};\\\", \\\"{x:181,y:503,t:1527030603097};\\\", \\\"{x:186,y:504,t:1527030603114};\\\", \\\"{x:201,y:515,t:1527030603131};\\\", \\\"{x:214,y:533,t:1527030603148};\\\", \\\"{x:233,y:549,t:1527030603164};\\\", \\\"{x:259,y:567,t:1527030603180};\\\", \\\"{x:285,y:587,t:1527030603198};\\\", \\\"{x:308,y:604,t:1527030603214};\\\", \\\"{x:318,y:615,t:1527030603231};\\\", \\\"{x:325,y:625,t:1527030603247};\\\", \\\"{x:331,y:634,t:1527030603265};\\\", \\\"{x:335,y:638,t:1527030603280};\\\", \\\"{x:338,y:643,t:1527030603298};\\\", \\\"{x:348,y:652,t:1527030603314};\\\", \\\"{x:367,y:663,t:1527030603330};\\\", \\\"{x:387,y:674,t:1527030603348};\\\", \\\"{x:404,y:684,t:1527030603364};\\\", \\\"{x:420,y:692,t:1527030603381};\\\", \\\"{x:433,y:700,t:1527030603398};\\\", \\\"{x:444,y:708,t:1527030603414};\\\", \\\"{x:449,y:712,t:1527030603431};\\\", \\\"{x:450,y:712,t:1527030603448};\\\", \\\"{x:451,y:712,t:1527030603551};\\\", \\\"{x:452,y:712,t:1527030603565};\\\", \\\"{x:455,y:712,t:1527030603581};\\\", \\\"{x:458,y:714,t:1527030603597};\\\", \\\"{x:466,y:718,t:1527030603614};\\\", \\\"{x:467,y:719,t:1527030603631};\\\", \\\"{x:469,y:720,t:1527030603648};\\\", \\\"{x:471,y:721,t:1527030603664};\\\", \\\"{x:472,y:721,t:1527030603681};\\\", \\\"{x:474,y:723,t:1527030603697};\\\", \\\"{x:477,y:726,t:1527030603714};\\\", \\\"{x:480,y:729,t:1527030603732};\\\", \\\"{x:481,y:730,t:1527030603806};\\\", \\\"{x:482,y:731,t:1527030603822};\\\", \\\"{x:483,y:732,t:1527030603831};\\\", \\\"{x:483,y:733,t:1527030603849};\\\", \\\"{x:485,y:735,t:1527030603878};\\\", \\\"{x:485,y:737,t:1527030603977};\\\", \\\"{x:485,y:740,t:1527030603998};\\\", \\\"{x:489,y:741,t:1527030604014};\\\", \\\"{x:490,y:741,t:1527030604031};\\\", \\\"{x:489,y:741,t:1527030604086};\\\", \\\"{x:487,y:740,t:1527030604098};\\\", \\\"{x:486,y:739,t:1527030604114};\\\", \\\"{x:485,y:739,t:1527030604199};\\\", \\\"{x:484,y:739,t:1527030604223};\\\", \\\"{x:483,y:739,t:1527030604399};\\\", \\\"{x:482,y:739,t:1527030604439};\\\", \\\"{x:481,y:739,t:1527030604471};\\\", \\\"{x:480,y:737,t:1527030604494};\\\", \\\"{x:479,y:737,t:1527030604510};\\\", \\\"{x:478,y:736,t:1527030604527};\\\", \\\"{x:478,y:735,t:1527030605118};\\\", \\\"{x:477,y:733,t:1527030605132};\\\", \\\"{x:475,y:731,t:1527030605148};\\\", \\\"{x:473,y:727,t:1527030605165};\\\", \\\"{x:469,y:723,t:1527030605182};\\\", \\\"{x:467,y:721,t:1527030605200};\\\", \\\"{x:464,y:716,t:1527030605215};\\\", \\\"{x:462,y:710,t:1527030605232};\\\", \\\"{x:460,y:706,t:1527030605250};\\\", \\\"{x:457,y:697,t:1527030605265};\\\", \\\"{x:455,y:686,t:1527030605283};\\\", \\\"{x:455,y:678,t:1527030605299};\\\", \\\"{x:455,y:673,t:1527030605315};\\\", \\\"{x:455,y:671,t:1527030605333};\\\" ] }, { \\\"rt\\\": 7555, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 558460, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:444,y:670,t:1527030605532};\\\", \\\"{x:443,y:671,t:1527030605605};\\\", \\\"{x:442,y:671,t:1527030605791};\\\", \\\"{x:441,y:672,t:1527030605903};\\\", \\\"{x:438,y:674,t:1527030605916};\\\", \\\"{x:433,y:676,t:1527030605932};\\\", \\\"{x:429,y:677,t:1527030605950};\\\", \\\"{x:427,y:677,t:1527030605966};\\\", \\\"{x:426,y:677,t:1527030605982};\\\", \\\"{x:426,y:671,t:1527030606038};\\\", \\\"{x:427,y:663,t:1527030606050};\\\", \\\"{x:432,y:649,t:1527030606067};\\\", \\\"{x:434,y:636,t:1527030606083};\\\", \\\"{x:435,y:622,t:1527030606099};\\\", \\\"{x:436,y:611,t:1527030606117};\\\", \\\"{x:437,y:603,t:1527030606133};\\\", \\\"{x:439,y:591,t:1527030606150};\\\", \\\"{x:441,y:576,t:1527030606166};\\\", \\\"{x:444,y:566,t:1527030606183};\\\", \\\"{x:448,y:558,t:1527030606199};\\\", \\\"{x:449,y:553,t:1527030606217};\\\", \\\"{x:449,y:551,t:1527030606233};\\\", \\\"{x:450,y:549,t:1527030606249};\\\", \\\"{x:451,y:547,t:1527030606267};\\\", \\\"{x:452,y:544,t:1527030606283};\\\", \\\"{x:452,y:541,t:1527030606299};\\\", \\\"{x:453,y:537,t:1527030606316};\\\", \\\"{x:454,y:533,t:1527030606334};\\\", \\\"{x:454,y:530,t:1527030606350};\\\", \\\"{x:455,y:525,t:1527030606366};\\\", \\\"{x:456,y:520,t:1527030606384};\\\", \\\"{x:459,y:511,t:1527030606399};\\\", \\\"{x:461,y:505,t:1527030606416};\\\", \\\"{x:464,y:501,t:1527030606434};\\\", \\\"{x:466,y:498,t:1527030606450};\\\", \\\"{x:467,y:496,t:1527030606467};\\\", \\\"{x:469,y:495,t:1527030606483};\\\", \\\"{x:469,y:494,t:1527030606500};\\\", \\\"{x:471,y:493,t:1527030606516};\\\", \\\"{x:471,y:492,t:1527030606533};\\\", \\\"{x:472,y:492,t:1527030606550};\\\", \\\"{x:474,y:491,t:1527030606615};\\\", \\\"{x:475,y:491,t:1527030606622};\\\", \\\"{x:476,y:490,t:1527030606633};\\\", \\\"{x:480,y:488,t:1527030606650};\\\", \\\"{x:485,y:485,t:1527030606668};\\\", \\\"{x:491,y:482,t:1527030606684};\\\", \\\"{x:494,y:480,t:1527030606700};\\\", \\\"{x:495,y:480,t:1527030606716};\\\", \\\"{x:497,y:479,t:1527030606733};\\\", \\\"{x:498,y:478,t:1527030606751};\\\", \\\"{x:500,y:478,t:1527030606774};\\\", \\\"{x:501,y:478,t:1527030606783};\\\", \\\"{x:503,y:478,t:1527030606801};\\\", \\\"{x:505,y:478,t:1527030606816};\\\", \\\"{x:506,y:478,t:1527030606834};\\\", \\\"{x:511,y:478,t:1527030606851};\\\", \\\"{x:524,y:478,t:1527030606867};\\\", \\\"{x:544,y:483,t:1527030606884};\\\", \\\"{x:557,y:486,t:1527030606901};\\\", \\\"{x:572,y:491,t:1527030606919};\\\", \\\"{x:588,y:494,t:1527030606933};\\\", \\\"{x:594,y:494,t:1527030606950};\\\", \\\"{x:597,y:495,t:1527030606967};\\\", \\\"{x:602,y:496,t:1527030606984};\\\", \\\"{x:616,y:498,t:1527030607000};\\\", \\\"{x:650,y:502,t:1527030607018};\\\", \\\"{x:731,y:515,t:1527030607034};\\\", \\\"{x:831,y:528,t:1527030607051};\\\", \\\"{x:937,y:544,t:1527030607067};\\\", \\\"{x:1036,y:558,t:1527030607084};\\\", \\\"{x:1139,y:574,t:1527030607100};\\\", \\\"{x:1232,y:605,t:1527030607118};\\\", \\\"{x:1292,y:631,t:1527030607134};\\\", \\\"{x:1330,y:654,t:1527030607150};\\\", \\\"{x:1336,y:658,t:1527030607167};\\\", \\\"{x:1338,y:664,t:1527030607185};\\\", \\\"{x:1338,y:672,t:1527030607200};\\\", \\\"{x:1340,y:690,t:1527030607217};\\\", \\\"{x:1348,y:709,t:1527030607234};\\\", \\\"{x:1359,y:725,t:1527030607251};\\\", \\\"{x:1369,y:736,t:1527030607268};\\\", \\\"{x:1375,y:739,t:1527030607284};\\\", \\\"{x:1377,y:739,t:1527030607301};\\\", \\\"{x:1378,y:739,t:1527030607319};\\\", \\\"{x:1379,y:739,t:1527030607520};\\\", \\\"{x:1379,y:740,t:1527030607551};\\\", \\\"{x:1379,y:742,t:1527030607569};\\\", \\\"{x:1379,y:748,t:1527030607585};\\\", \\\"{x:1377,y:755,t:1527030607601};\\\", \\\"{x:1374,y:760,t:1527030607619};\\\", \\\"{x:1369,y:766,t:1527030607635};\\\", \\\"{x:1365,y:769,t:1527030607652};\\\", \\\"{x:1362,y:773,t:1527030607669};\\\", \\\"{x:1361,y:774,t:1527030607684};\\\", \\\"{x:1361,y:777,t:1527030607702};\\\", \\\"{x:1361,y:779,t:1527030607719};\\\", \\\"{x:1360,y:779,t:1527030607807};\\\", \\\"{x:1358,y:777,t:1527030607819};\\\", \\\"{x:1356,y:772,t:1527030607836};\\\", \\\"{x:1354,y:768,t:1527030607852};\\\", \\\"{x:1351,y:763,t:1527030607872};\\\", \\\"{x:1349,y:761,t:1527030607886};\\\", \\\"{x:1346,y:758,t:1527030607901};\\\", \\\"{x:1343,y:754,t:1527030607919};\\\", \\\"{x:1341,y:751,t:1527030607936};\\\", \\\"{x:1338,y:743,t:1527030607952};\\\", \\\"{x:1335,y:732,t:1527030607968};\\\", \\\"{x:1334,y:725,t:1527030607986};\\\", \\\"{x:1332,y:717,t:1527030608002};\\\", \\\"{x:1331,y:712,t:1527030608018};\\\", \\\"{x:1330,y:709,t:1527030608035};\\\", \\\"{x:1330,y:708,t:1527030608054};\\\", \\\"{x:1330,y:707,t:1527030608070};\\\", \\\"{x:1330,y:706,t:1527030608086};\\\", \\\"{x:1330,y:705,t:1527030608119};\\\", \\\"{x:1330,y:704,t:1527030608126};\\\", \\\"{x:1330,y:703,t:1527030608136};\\\", \\\"{x:1331,y:703,t:1527030608153};\\\", \\\"{x:1332,y:702,t:1527030608170};\\\", \\\"{x:1334,y:701,t:1527030608186};\\\", \\\"{x:1336,y:699,t:1527030608202};\\\", \\\"{x:1338,y:699,t:1527030608220};\\\", \\\"{x:1339,y:698,t:1527030608236};\\\", \\\"{x:1341,y:697,t:1527030608253};\\\", \\\"{x:1342,y:695,t:1527030608271};\\\", \\\"{x:1344,y:693,t:1527030608286};\\\", \\\"{x:1344,y:692,t:1527030608303};\\\", \\\"{x:1345,y:692,t:1527030608326};\\\", \\\"{x:1345,y:693,t:1527030609095};\\\", \\\"{x:1345,y:695,t:1527030609119};\\\", \\\"{x:1345,y:696,t:1527030609135};\\\", \\\"{x:1345,y:697,t:1527030609311};\\\", \\\"{x:1345,y:698,t:1527030609322};\\\", \\\"{x:1344,y:700,t:1527030609338};\\\", \\\"{x:1344,y:701,t:1527030609355};\\\", \\\"{x:1343,y:702,t:1527030609373};\\\", \\\"{x:1342,y:702,t:1527030609967};\\\", \\\"{x:1341,y:699,t:1527030609975};\\\", \\\"{x:1340,y:697,t:1527030609990};\\\", \\\"{x:1334,y:689,t:1527030610006};\\\", \\\"{x:1307,y:659,t:1527030610022};\\\", \\\"{x:1279,y:633,t:1527030610041};\\\", \\\"{x:1251,y:608,t:1527030610056};\\\", \\\"{x:1220,y:580,t:1527030610073};\\\", \\\"{x:1201,y:565,t:1527030610090};\\\", \\\"{x:1193,y:556,t:1527030610106};\\\", \\\"{x:1189,y:550,t:1527030610124};\\\", \\\"{x:1183,y:544,t:1527030610140};\\\", \\\"{x:1181,y:540,t:1527030610157};\\\", \\\"{x:1178,y:536,t:1527030610173};\\\", \\\"{x:1176,y:534,t:1527030610191};\\\", \\\"{x:1173,y:532,t:1527030610207};\\\", \\\"{x:1172,y:531,t:1527030610223};\\\", \\\"{x:1169,y:531,t:1527030610536};\\\", \\\"{x:1162,y:531,t:1527030610543};\\\", \\\"{x:1151,y:530,t:1527030610557};\\\", \\\"{x:1118,y:525,t:1527030610575};\\\", \\\"{x:987,y:511,t:1527030610590};\\\", \\\"{x:865,y:493,t:1527030610608};\\\", \\\"{x:748,y:474,t:1527030610623};\\\", \\\"{x:679,y:466,t:1527030610640};\\\", \\\"{x:653,y:458,t:1527030610663};\\\", \\\"{x:652,y:457,t:1527030610680};\\\", \\\"{x:650,y:457,t:1527030610774};\\\", \\\"{x:648,y:457,t:1527030610782};\\\", \\\"{x:644,y:459,t:1527030610796};\\\", \\\"{x:638,y:461,t:1527030610813};\\\", \\\"{x:629,y:467,t:1527030610829};\\\", \\\"{x:620,y:470,t:1527030610847};\\\", \\\"{x:615,y:472,t:1527030610864};\\\", \\\"{x:612,y:473,t:1527030610902};\\\", \\\"{x:610,y:474,t:1527030610918};\\\", \\\"{x:607,y:476,t:1527030610931};\\\", \\\"{x:601,y:481,t:1527030610947};\\\", \\\"{x:596,y:490,t:1527030610964};\\\", \\\"{x:592,y:495,t:1527030610980};\\\", \\\"{x:591,y:500,t:1527030611004};\\\", \\\"{x:590,y:502,t:1527030611020};\\\", \\\"{x:591,y:502,t:1527030611126};\\\", \\\"{x:593,y:502,t:1527030611150};\\\", \\\"{x:594,y:502,t:1527030611206};\\\", \\\"{x:596,y:502,t:1527030611238};\\\", \\\"{x:597,y:502,t:1527030611342};\\\", \\\"{x:599,y:502,t:1527030611390};\\\", \\\"{x:600,y:502,t:1527030611446};\\\", \\\"{x:600,y:502,t:1527030611511};\\\", \\\"{x:600,y:505,t:1527030611630};\\\", \\\"{x:594,y:514,t:1527030611638};\\\", \\\"{x:585,y:528,t:1527030611655};\\\", \\\"{x:570,y:547,t:1527030611671};\\\", \\\"{x:555,y:566,t:1527030611688};\\\", \\\"{x:545,y:586,t:1527030611704};\\\", \\\"{x:536,y:607,t:1527030611721};\\\", \\\"{x:528,y:625,t:1527030611737};\\\", \\\"{x:521,y:641,t:1527030611755};\\\", \\\"{x:521,y:646,t:1527030611770};\\\", \\\"{x:521,y:649,t:1527030611787};\\\", \\\"{x:521,y:650,t:1527030611806};\\\", \\\"{x:521,y:651,t:1527030611821};\\\", \\\"{x:525,y:652,t:1527030611838};\\\", \\\"{x:526,y:652,t:1527030611854};\\\", \\\"{x:529,y:653,t:1527030611877};\\\", \\\"{x:529,y:655,t:1527030611893};\\\", \\\"{x:530,y:663,t:1527030611904};\\\", \\\"{x:535,y:683,t:1527030611921};\\\", \\\"{x:536,y:704,t:1527030611938};\\\", \\\"{x:537,y:722,t:1527030611955};\\\", \\\"{x:539,y:734,t:1527030611970};\\\", \\\"{x:540,y:738,t:1527030611988};\\\", \\\"{x:541,y:741,t:1527030612004};\\\", \\\"{x:542,y:742,t:1527030612022};\\\", \\\"{x:542,y:744,t:1527030612038};\\\", \\\"{x:544,y:747,t:1527030612053};\\\", \\\"{x:547,y:751,t:1527030612071};\\\", \\\"{x:548,y:750,t:1527030612278};\\\", \\\"{x:550,y:746,t:1527030612287};\\\", \\\"{x:550,y:741,t:1527030612303};\\\", \\\"{x:550,y:739,t:1527030612321};\\\", \\\"{x:550,y:737,t:1527030612337};\\\", \\\"{x:550,y:734,t:1527030612353};\\\", \\\"{x:550,y:731,t:1527030612371};\\\", \\\"{x:551,y:728,t:1527030612388};\\\", \\\"{x:551,y:723,t:1527030612404};\\\", \\\"{x:551,y:724,t:1527030612590};\\\", \\\"{x:550,y:725,t:1527030612604};\\\", \\\"{x:550,y:726,t:1527030612622};\\\", \\\"{x:548,y:727,t:1527030613791};\\\", \\\"{x:547,y:728,t:1527030613822};\\\", \\\"{x:546,y:728,t:1527030613951};\\\" ] }, { \\\"rt\\\": 9632, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 569379, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:728,t:1527030614375};\\\", \\\"{x:542,y:728,t:1527030614526};\\\", \\\"{x:541,y:728,t:1527030614557};\\\", \\\"{x:539,y:728,t:1527030614733};\\\", \\\"{x:537,y:727,t:1527030614742};\\\", \\\"{x:537,y:726,t:1527030614756};\\\", \\\"{x:534,y:722,t:1527030614772};\\\", \\\"{x:529,y:715,t:1527030614790};\\\", \\\"{x:527,y:712,t:1527030614807};\\\", \\\"{x:525,y:704,t:1527030614824};\\\", \\\"{x:525,y:693,t:1527030614840};\\\", \\\"{x:525,y:673,t:1527030614857};\\\", \\\"{x:525,y:652,t:1527030614874};\\\", \\\"{x:532,y:545,t:1527030614986};\\\", \\\"{x:531,y:538,t:1527030614990};\\\", \\\"{x:528,y:530,t:1527030615007};\\\", \\\"{x:527,y:528,t:1527030615024};\\\", \\\"{x:526,y:526,t:1527030615040};\\\", \\\"{x:525,y:524,t:1527030615057};\\\", \\\"{x:522,y:520,t:1527030615074};\\\", \\\"{x:520,y:519,t:1527030615094};\\\", \\\"{x:516,y:516,t:1527030615107};\\\", \\\"{x:502,y:513,t:1527030615124};\\\", \\\"{x:496,y:511,t:1527030615140};\\\", \\\"{x:495,y:511,t:1527030615156};\\\", \\\"{x:494,y:510,t:1527030615174};\\\", \\\"{x:493,y:509,t:1527030615189};\\\", \\\"{x:492,y:509,t:1527030615238};\\\", \\\"{x:491,y:509,t:1527030615318};\\\", \\\"{x:490,y:509,t:1527030615333};\\\", \\\"{x:490,y:508,t:1527030615342};\\\", \\\"{x:489,y:508,t:1527030615358};\\\", \\\"{x:488,y:507,t:1527030615382};\\\", \\\"{x:487,y:506,t:1527030615397};\\\", \\\"{x:485,y:506,t:1527030615407};\\\", \\\"{x:484,y:504,t:1527030615424};\\\", \\\"{x:482,y:501,t:1527030615441};\\\", \\\"{x:480,y:497,t:1527030615456};\\\", \\\"{x:480,y:493,t:1527030615473};\\\", \\\"{x:480,y:489,t:1527030615490};\\\", \\\"{x:480,y:487,t:1527030615507};\\\", \\\"{x:481,y:483,t:1527030615524};\\\", \\\"{x:485,y:479,t:1527030615541};\\\", \\\"{x:489,y:475,t:1527030615557};\\\", \\\"{x:494,y:472,t:1527030615573};\\\", \\\"{x:497,y:469,t:1527030615590};\\\", \\\"{x:499,y:467,t:1527030615608};\\\", \\\"{x:501,y:466,t:1527030615624};\\\", \\\"{x:501,y:465,t:1527030615814};\\\", \\\"{x:502,y:465,t:1527030615991};\\\", \\\"{x:502,y:466,t:1527030615998};\\\", \\\"{x:503,y:466,t:1527030616023};\\\", \\\"{x:503,y:467,t:1527030616270};\\\", \\\"{x:503,y:468,t:1527030616350};\\\", \\\"{x:502,y:470,t:1527030616359};\\\", \\\"{x:494,y:477,t:1527030616375};\\\", \\\"{x:483,y:490,t:1527030616392};\\\", \\\"{x:470,y:505,t:1527030616408};\\\", \\\"{x:463,y:516,t:1527030616425};\\\", \\\"{x:459,y:521,t:1527030616441};\\\", \\\"{x:458,y:523,t:1527030616458};\\\", \\\"{x:458,y:524,t:1527030616582};\\\", \\\"{x:459,y:524,t:1527030616597};\\\", \\\"{x:461,y:524,t:1527030616608};\\\", \\\"{x:463,y:523,t:1527030616624};\\\", \\\"{x:465,y:522,t:1527030616642};\\\", \\\"{x:470,y:519,t:1527030616658};\\\", \\\"{x:476,y:516,t:1527030616675};\\\", \\\"{x:500,y:507,t:1527030616691};\\\", \\\"{x:529,y:503,t:1527030616708};\\\", \\\"{x:563,y:500,t:1527030616724};\\\", \\\"{x:637,y:499,t:1527030616742};\\\", \\\"{x:676,y:499,t:1527030616758};\\\", \\\"{x:732,y:499,t:1527030616775};\\\", \\\"{x:804,y:508,t:1527030616791};\\\", \\\"{x:891,y:521,t:1527030616808};\\\", \\\"{x:995,y:531,t:1527030616824};\\\", \\\"{x:1115,y:535,t:1527030616841};\\\", \\\"{x:1218,y:537,t:1527030616859};\\\", \\\"{x:1310,y:537,t:1527030616875};\\\", \\\"{x:1398,y:537,t:1527030616892};\\\", \\\"{x:1474,y:537,t:1527030616909};\\\", \\\"{x:1615,y:537,t:1527030616926};\\\", \\\"{x:1693,y:537,t:1527030616942};\\\", \\\"{x:1713,y:540,t:1527030616959};\\\", \\\"{x:1725,y:541,t:1527030616975};\\\", \\\"{x:1726,y:542,t:1527030616991};\\\", \\\"{x:1727,y:547,t:1527030617009};\\\", \\\"{x:1728,y:559,t:1527030617025};\\\", \\\"{x:1728,y:574,t:1527030617042};\\\", \\\"{x:1728,y:586,t:1527030617058};\\\", \\\"{x:1728,y:595,t:1527030617076};\\\", \\\"{x:1728,y:607,t:1527030617092};\\\", \\\"{x:1727,y:621,t:1527030617109};\\\", \\\"{x:1709,y:646,t:1527030617125};\\\", \\\"{x:1689,y:661,t:1527030617143};\\\", \\\"{x:1660,y:686,t:1527030617160};\\\", \\\"{x:1619,y:719,t:1527030617175};\\\", \\\"{x:1582,y:746,t:1527030617193};\\\", \\\"{x:1561,y:764,t:1527030617210};\\\", \\\"{x:1542,y:785,t:1527030617226};\\\", \\\"{x:1528,y:803,t:1527030617243};\\\", \\\"{x:1515,y:824,t:1527030617260};\\\", \\\"{x:1500,y:850,t:1527030617277};\\\", \\\"{x:1480,y:876,t:1527030617293};\\\", \\\"{x:1455,y:911,t:1527030617310};\\\", \\\"{x:1441,y:926,t:1527030617327};\\\", \\\"{x:1432,y:933,t:1527030617344};\\\", \\\"{x:1431,y:933,t:1527030617360};\\\", \\\"{x:1430,y:934,t:1527030617558};\\\", \\\"{x:1428,y:934,t:1527030617590};\\\", \\\"{x:1427,y:934,t:1527030617598};\\\", \\\"{x:1425,y:934,t:1527030617614};\\\", \\\"{x:1424,y:934,t:1527030617630};\\\", \\\"{x:1421,y:935,t:1527030617644};\\\", \\\"{x:1415,y:938,t:1527030617661};\\\", \\\"{x:1407,y:945,t:1527030617678};\\\", \\\"{x:1403,y:947,t:1527030617694};\\\", \\\"{x:1403,y:949,t:1527030617718};\\\", \\\"{x:1402,y:950,t:1527030617728};\\\", \\\"{x:1399,y:953,t:1527030617745};\\\", \\\"{x:1394,y:960,t:1527030617761};\\\", \\\"{x:1390,y:967,t:1527030617778};\\\", \\\"{x:1388,y:970,t:1527030617795};\\\", \\\"{x:1387,y:972,t:1527030617812};\\\", \\\"{x:1385,y:972,t:1527030617960};\\\", \\\"{x:1383,y:971,t:1527030617967};\\\", \\\"{x:1381,y:969,t:1527030617980};\\\", \\\"{x:1370,y:963,t:1527030617996};\\\", \\\"{x:1356,y:956,t:1527030618012};\\\", \\\"{x:1343,y:951,t:1527030618029};\\\", \\\"{x:1327,y:946,t:1527030618046};\\\", \\\"{x:1324,y:945,t:1527030618063};\\\", \\\"{x:1323,y:944,t:1527030618175};\\\", \\\"{x:1324,y:944,t:1527030618183};\\\", \\\"{x:1327,y:941,t:1527030618196};\\\", \\\"{x:1337,y:936,t:1527030618213};\\\", \\\"{x:1349,y:926,t:1527030618229};\\\", \\\"{x:1369,y:907,t:1527030618247};\\\", \\\"{x:1379,y:897,t:1527030618266};\\\", \\\"{x:1385,y:892,t:1527030618280};\\\", \\\"{x:1389,y:889,t:1527030618296};\\\", \\\"{x:1391,y:886,t:1527030618313};\\\", \\\"{x:1392,y:884,t:1527030618329};\\\", \\\"{x:1394,y:881,t:1527030618346};\\\", \\\"{x:1396,y:871,t:1527030618363};\\\", \\\"{x:1401,y:855,t:1527030618380};\\\", \\\"{x:1402,y:848,t:1527030618396};\\\", \\\"{x:1404,y:843,t:1527030618412};\\\", \\\"{x:1404,y:841,t:1527030618478};\\\", \\\"{x:1404,y:838,t:1527030618486};\\\", \\\"{x:1404,y:836,t:1527030618497};\\\", \\\"{x:1406,y:830,t:1527030618514};\\\", \\\"{x:1408,y:825,t:1527030618529};\\\", \\\"{x:1409,y:820,t:1527030618547};\\\", \\\"{x:1412,y:812,t:1527030618564};\\\", \\\"{x:1412,y:810,t:1527030618581};\\\", \\\"{x:1413,y:802,t:1527030618597};\\\", \\\"{x:1419,y:782,t:1527030618614};\\\", \\\"{x:1425,y:765,t:1527030618631};\\\", \\\"{x:1428,y:749,t:1527030618647};\\\", \\\"{x:1432,y:739,t:1527030618664};\\\", \\\"{x:1434,y:730,t:1527030618680};\\\", \\\"{x:1437,y:721,t:1527030618698};\\\", \\\"{x:1439,y:711,t:1527030618713};\\\", \\\"{x:1443,y:696,t:1527030618731};\\\", \\\"{x:1449,y:687,t:1527030618747};\\\", \\\"{x:1452,y:679,t:1527030618764};\\\", \\\"{x:1456,y:673,t:1527030618781};\\\", \\\"{x:1459,y:666,t:1527030618798};\\\", \\\"{x:1464,y:654,t:1527030618815};\\\", \\\"{x:1471,y:643,t:1527030618830};\\\", \\\"{x:1480,y:629,t:1527030618848};\\\", \\\"{x:1489,y:618,t:1527030618865};\\\", \\\"{x:1495,y:611,t:1527030618881};\\\", \\\"{x:1500,y:606,t:1527030618898};\\\", \\\"{x:1504,y:599,t:1527030618915};\\\", \\\"{x:1509,y:594,t:1527030618932};\\\", \\\"{x:1521,y:583,t:1527030618948};\\\", \\\"{x:1542,y:563,t:1527030618965};\\\", \\\"{x:1572,y:537,t:1527030618982};\\\", \\\"{x:1582,y:528,t:1527030618998};\\\", \\\"{x:1585,y:524,t:1527030619015};\\\", \\\"{x:1586,y:520,t:1527030619032};\\\", \\\"{x:1587,y:518,t:1527030619049};\\\", \\\"{x:1587,y:517,t:1527030619065};\\\", \\\"{x:1587,y:515,t:1527030619082};\\\", \\\"{x:1587,y:513,t:1527030619099};\\\", \\\"{x:1587,y:512,t:1527030619116};\\\", \\\"{x:1587,y:511,t:1527030619132};\\\", \\\"{x:1587,y:510,t:1527030619149};\\\", \\\"{x:1587,y:509,t:1527030619166};\\\", \\\"{x:1587,y:508,t:1527030619197};\\\", \\\"{x:1587,y:507,t:1527030619206};\\\", \\\"{x:1587,y:506,t:1527030619222};\\\", \\\"{x:1584,y:509,t:1527030620054};\\\", \\\"{x:1576,y:513,t:1527030620067};\\\", \\\"{x:1532,y:524,t:1527030620085};\\\", \\\"{x:1391,y:564,t:1527030620102};\\\", \\\"{x:1246,y:593,t:1527030620119};\\\", \\\"{x:1116,y:610,t:1527030620135};\\\", \\\"{x:1003,y:620,t:1527030620152};\\\", \\\"{x:905,y:638,t:1527030620169};\\\", \\\"{x:830,y:647,t:1527030620185};\\\", \\\"{x:772,y:661,t:1527030620202};\\\", \\\"{x:735,y:671,t:1527030620219};\\\", \\\"{x:705,y:679,t:1527030620235};\\\", \\\"{x:683,y:686,t:1527030620252};\\\", \\\"{x:667,y:687,t:1527030620269};\\\", \\\"{x:655,y:687,t:1527030620286};\\\", \\\"{x:650,y:687,t:1527030620302};\\\", \\\"{x:648,y:686,t:1527030620333};\\\", \\\"{x:648,y:683,t:1527030620342};\\\", \\\"{x:648,y:678,t:1527030620352};\\\", \\\"{x:647,y:663,t:1527030620368};\\\", \\\"{x:643,y:642,t:1527030620386};\\\", \\\"{x:639,y:628,t:1527030620403};\\\", \\\"{x:637,y:616,t:1527030620419};\\\", \\\"{x:637,y:612,t:1527030620436};\\\", \\\"{x:637,y:605,t:1527030620460};\\\", \\\"{x:637,y:603,t:1527030620477};\\\", \\\"{x:635,y:595,t:1527030620494};\\\", \\\"{x:615,y:586,t:1527030620511};\\\", \\\"{x:577,y:576,t:1527030620528};\\\", \\\"{x:533,y:572,t:1527030620545};\\\", \\\"{x:502,y:567,t:1527030620561};\\\", \\\"{x:485,y:564,t:1527030620578};\\\", \\\"{x:481,y:563,t:1527030620594};\\\", \\\"{x:479,y:562,t:1527030620612};\\\", \\\"{x:477,y:560,t:1527030620628};\\\", \\\"{x:473,y:558,t:1527030620645};\\\", \\\"{x:465,y:556,t:1527030620662};\\\", \\\"{x:463,y:555,t:1527030620679};\\\", \\\"{x:461,y:555,t:1527030620695};\\\", \\\"{x:460,y:554,t:1527030620711};\\\", \\\"{x:455,y:551,t:1527030620727};\\\", \\\"{x:442,y:544,t:1527030620745};\\\", \\\"{x:427,y:536,t:1527030620760};\\\", \\\"{x:416,y:531,t:1527030620778};\\\", \\\"{x:411,y:528,t:1527030620795};\\\", \\\"{x:409,y:527,t:1527030620812};\\\", \\\"{x:407,y:526,t:1527030620827};\\\", \\\"{x:406,y:526,t:1527030620845};\\\", \\\"{x:404,y:525,t:1527030620861};\\\", \\\"{x:398,y:525,t:1527030620877};\\\", \\\"{x:392,y:525,t:1527030620895};\\\", \\\"{x:387,y:525,t:1527030620912};\\\", \\\"{x:385,y:525,t:1527030620928};\\\", \\\"{x:384,y:525,t:1527030620944};\\\", \\\"{x:382,y:525,t:1527030620962};\\\", \\\"{x:381,y:525,t:1527030620977};\\\", \\\"{x:379,y:525,t:1527030620995};\\\", \\\"{x:376,y:525,t:1527030621012};\\\", \\\"{x:375,y:525,t:1527030621206};\\\", \\\"{x:374,y:525,t:1527030621229};\\\", \\\"{x:374,y:526,t:1527030621270};\\\", \\\"{x:373,y:526,t:1527030621294};\\\", \\\"{x:372,y:527,t:1527030621318};\\\", \\\"{x:372,y:528,t:1527030621342};\\\", \\\"{x:372,y:529,t:1527030621582};\\\", \\\"{x:373,y:529,t:1527030621596};\\\", \\\"{x:375,y:533,t:1527030621612};\\\", \\\"{x:377,y:537,t:1527030621628};\\\", \\\"{x:380,y:541,t:1527030621644};\\\", \\\"{x:383,y:546,t:1527030621661};\\\", \\\"{x:386,y:553,t:1527030621678};\\\", \\\"{x:387,y:554,t:1527030621694};\\\", \\\"{x:387,y:555,t:1527030621712};\\\", \\\"{x:387,y:556,t:1527030621729};\\\", \\\"{x:387,y:558,t:1527030621750};\\\", \\\"{x:387,y:559,t:1527030621762};\\\", \\\"{x:387,y:562,t:1527030621779};\\\", \\\"{x:387,y:565,t:1527030621796};\\\", \\\"{x:387,y:567,t:1527030621812};\\\", \\\"{x:387,y:568,t:1527030621829};\\\", \\\"{x:387,y:569,t:1527030621910};\\\", \\\"{x:387,y:570,t:1527030621926};\\\", \\\"{x:387,y:571,t:1527030621934};\\\", \\\"{x:387,y:570,t:1527030622054};\\\", \\\"{x:387,y:568,t:1527030622063};\\\", \\\"{x:387,y:561,t:1527030622080};\\\", \\\"{x:387,y:558,t:1527030622096};\\\", \\\"{x:388,y:554,t:1527030622112};\\\", \\\"{x:388,y:553,t:1527030622128};\\\", \\\"{x:388,y:551,t:1527030622146};\\\", \\\"{x:388,y:550,t:1527030622166};\\\", \\\"{x:388,y:549,t:1527030622182};\\\", \\\"{x:388,y:548,t:1527030622196};\\\", \\\"{x:388,y:547,t:1527030622213};\\\", \\\"{x:388,y:546,t:1527030622229};\\\", \\\"{x:388,y:545,t:1527030622335};\\\", \\\"{x:389,y:545,t:1527030622462};\\\", \\\"{x:390,y:547,t:1527030622485};\\\", \\\"{x:390,y:551,t:1527030622496};\\\", \\\"{x:392,y:561,t:1527030622514};\\\", \\\"{x:392,y:570,t:1527030622530};\\\", \\\"{x:393,y:577,t:1527030622546};\\\", \\\"{x:394,y:581,t:1527030622563};\\\", \\\"{x:395,y:582,t:1527030622579};\\\", \\\"{x:395,y:585,t:1527030622597};\\\", \\\"{x:395,y:587,t:1527030622613};\\\", \\\"{x:395,y:592,t:1527030622630};\\\", \\\"{x:395,y:596,t:1527030622646};\\\", \\\"{x:395,y:598,t:1527030622663};\\\", \\\"{x:395,y:599,t:1527030622680};\\\", \\\"{x:395,y:600,t:1527030622782};\\\", \\\"{x:394,y:600,t:1527030622798};\\\", \\\"{x:391,y:601,t:1527030622864};\\\", \\\"{x:387,y:605,t:1527030622881};\\\", \\\"{x:385,y:610,t:1527030622896};\\\", \\\"{x:383,y:614,t:1527030622913};\\\", \\\"{x:381,y:618,t:1527030622929};\\\", \\\"{x:382,y:618,t:1527030623261};\\\", \\\"{x:383,y:618,t:1527030623270};\\\", \\\"{x:385,y:619,t:1527030623280};\\\", \\\"{x:391,y:625,t:1527030623297};\\\", \\\"{x:401,y:634,t:1527030623315};\\\", \\\"{x:419,y:656,t:1527030623330};\\\", \\\"{x:450,y:692,t:1527030623348};\\\", \\\"{x:482,y:730,t:1527030623364};\\\", \\\"{x:504,y:756,t:1527030623380};\\\", \\\"{x:509,y:761,t:1527030623397};\\\", \\\"{x:510,y:763,t:1527030623414};\\\", \\\"{x:512,y:763,t:1527030623477};\\\", \\\"{x:513,y:763,t:1527030623485};\\\", \\\"{x:514,y:762,t:1527030623497};\\\", \\\"{x:515,y:762,t:1527030623514};\\\", \\\"{x:516,y:760,t:1527030623531};\\\", \\\"{x:517,y:760,t:1527030623547};\\\", \\\"{x:518,y:759,t:1527030623564};\\\", \\\"{x:520,y:757,t:1527030623581};\\\", \\\"{x:525,y:751,t:1527030623598};\\\", \\\"{x:527,y:746,t:1527030623614};\\\", \\\"{x:530,y:740,t:1527030623630};\\\", \\\"{x:531,y:735,t:1527030623647};\\\", \\\"{x:531,y:733,t:1527030623663};\\\", \\\"{x:533,y:730,t:1527030623679};\\\", \\\"{x:534,y:728,t:1527030623734};\\\", \\\"{x:535,y:727,t:1527030623750};\\\", \\\"{x:536,y:723,t:1527030623763};\\\", \\\"{x:536,y:722,t:1527030623782};\\\", \\\"{x:537,y:721,t:1527030623797};\\\", \\\"{x:536,y:721,t:1527030623925};\\\", \\\"{x:535,y:722,t:1527030623934};\\\", \\\"{x:533,y:725,t:1527030623947};\\\", \\\"{x:533,y:727,t:1527030623964};\\\", \\\"{x:532,y:730,t:1527030623981};\\\", \\\"{x:532,y:730,t:1527030624019};\\\", \\\"{x:532,y:731,t:1527030624462};\\\", \\\"{x:531,y:731,t:1527030624469};\\\", \\\"{x:530,y:731,t:1527030624481};\\\", \\\"{x:528,y:732,t:1527030624498};\\\", \\\"{x:527,y:732,t:1527030624515};\\\", \\\"{x:525,y:733,t:1527030624533};\\\", \\\"{x:524,y:734,t:1527030624565};\\\", \\\"{x:523,y:735,t:1527030624589};\\\", \\\"{x:521,y:735,t:1527030624629};\\\", \\\"{x:520,y:737,t:1527030624653};\\\", \\\"{x:518,y:737,t:1527030624669};\\\", \\\"{x:517,y:738,t:1527030624685};\\\", \\\"{x:516,y:738,t:1527030624698};\\\", \\\"{x:513,y:740,t:1527030624715};\\\", \\\"{x:511,y:741,t:1527030624731};\\\", \\\"{x:508,y:742,t:1527030624748};\\\", \\\"{x:507,y:742,t:1527030624765};\\\" ] }, { \\\"rt\\\": 8806, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 579716, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -G -7-7\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:743,t:1527030625565};\\\", \\\"{x:507,y:744,t:1527030625983};\\\", \\\"{x:498,y:735,t:1527030626001};\\\", \\\"{x:490,y:720,t:1527030626017};\\\", \\\"{x:481,y:705,t:1527030626033};\\\", \\\"{x:453,y:626,t:1527030626105};\\\", \\\"{x:452,y:619,t:1527030626117};\\\", \\\"{x:450,y:607,t:1527030626133};\\\", \\\"{x:450,y:598,t:1527030626149};\\\", \\\"{x:450,y:586,t:1527030626166};\\\", \\\"{x:450,y:578,t:1527030626182};\\\", \\\"{x:450,y:575,t:1527030626199};\\\", \\\"{x:450,y:573,t:1527030626216};\\\", \\\"{x:450,y:572,t:1527030626232};\\\", \\\"{x:450,y:571,t:1527030626254};\\\", \\\"{x:450,y:569,t:1527030626269};\\\", \\\"{x:449,y:566,t:1527030626678};\\\", \\\"{x:447,y:559,t:1527030626687};\\\", \\\"{x:444,y:553,t:1527030626700};\\\", \\\"{x:437,y:537,t:1527030626716};\\\", \\\"{x:430,y:521,t:1527030626732};\\\", \\\"{x:422,y:506,t:1527030626750};\\\", \\\"{x:409,y:485,t:1527030626767};\\\", \\\"{x:400,y:470,t:1527030626783};\\\", \\\"{x:389,y:454,t:1527030626800};\\\", \\\"{x:375,y:438,t:1527030626817};\\\", \\\"{x:368,y:430,t:1527030626833};\\\", \\\"{x:362,y:425,t:1527030626850};\\\", \\\"{x:361,y:423,t:1527030626866};\\\", \\\"{x:360,y:423,t:1527030626886};\\\", \\\"{x:359,y:422,t:1527030626990};\\\", \\\"{x:359,y:423,t:1527030627590};\\\", \\\"{x:359,y:426,t:1527030627600};\\\", \\\"{x:361,y:431,t:1527030627617};\\\", \\\"{x:362,y:432,t:1527030627634};\\\", \\\"{x:363,y:433,t:1527030627651};\\\", \\\"{x:365,y:435,t:1527030627667};\\\", \\\"{x:369,y:438,t:1527030627684};\\\", \\\"{x:370,y:439,t:1527030627701};\\\", \\\"{x:372,y:440,t:1527030627717};\\\", \\\"{x:373,y:442,t:1527030627734};\\\", \\\"{x:373,y:444,t:1527030627751};\\\", \\\"{x:374,y:445,t:1527030627768};\\\", \\\"{x:374,y:448,t:1527030627785};\\\", \\\"{x:374,y:450,t:1527030627801};\\\", \\\"{x:376,y:452,t:1527030627818};\\\", \\\"{x:376,y:454,t:1527030627834};\\\", \\\"{x:377,y:454,t:1527030627861};\\\", \\\"{x:377,y:455,t:1527030627950};\\\", \\\"{x:377,y:456,t:1527030627974};\\\", \\\"{x:378,y:457,t:1527030627985};\\\", \\\"{x:378,y:458,t:1527030628022};\\\", \\\"{x:378,y:459,t:1527030628035};\\\", \\\"{x:378,y:460,t:1527030628052};\\\", \\\"{x:379,y:461,t:1527030628068};\\\", \\\"{x:381,y:461,t:1527030628254};\\\", \\\"{x:387,y:461,t:1527030628268};\\\", \\\"{x:413,y:461,t:1527030628285};\\\", \\\"{x:444,y:461,t:1527030628301};\\\", \\\"{x:486,y:461,t:1527030628318};\\\", \\\"{x:508,y:461,t:1527030628336};\\\", \\\"{x:519,y:461,t:1527030628351};\\\", \\\"{x:524,y:460,t:1527030628368};\\\", \\\"{x:527,y:459,t:1527030628385};\\\", \\\"{x:528,y:459,t:1527030628401};\\\", \\\"{x:531,y:459,t:1527030628419};\\\", \\\"{x:532,y:458,t:1527030628436};\\\", \\\"{x:535,y:458,t:1527030628453};\\\", \\\"{x:537,y:458,t:1527030628468};\\\", \\\"{x:540,y:458,t:1527030628485};\\\", \\\"{x:544,y:458,t:1527030628502};\\\", \\\"{x:546,y:458,t:1527030628519};\\\", \\\"{x:547,y:458,t:1527030628536};\\\", \\\"{x:548,y:458,t:1527030628552};\\\", \\\"{x:549,y:458,t:1527030628568};\\\", \\\"{x:550,y:458,t:1527030628585};\\\", \\\"{x:552,y:458,t:1527030628911};\\\", \\\"{x:555,y:456,t:1527030628919};\\\", \\\"{x:564,y:452,t:1527030628936};\\\", \\\"{x:566,y:451,t:1527030628952};\\\", \\\"{x:566,y:448,t:1527030628989};\\\", \\\"{x:564,y:446,t:1527030629002};\\\", \\\"{x:563,y:445,t:1527030629019};\\\", \\\"{x:564,y:443,t:1527030629036};\\\", \\\"{x:568,y:440,t:1527030629053};\\\", \\\"{x:574,y:437,t:1527030629069};\\\", \\\"{x:581,y:433,t:1527030629086};\\\", \\\"{x:582,y:433,t:1527030629142};\\\", \\\"{x:583,y:433,t:1527030629152};\\\", \\\"{x:594,y:441,t:1527030629169};\\\", \\\"{x:602,y:447,t:1527030629187};\\\", \\\"{x:607,y:448,t:1527030629203};\\\", \\\"{x:613,y:449,t:1527030629219};\\\", \\\"{x:617,y:452,t:1527030629236};\\\", \\\"{x:626,y:463,t:1527030629253};\\\", \\\"{x:655,y:493,t:1527030629270};\\\", \\\"{x:726,y:535,t:1527030629287};\\\", \\\"{x:806,y:568,t:1527030629304};\\\", \\\"{x:864,y:584,t:1527030629317};\\\", \\\"{x:991,y:618,t:1527030629333};\\\", \\\"{x:1158,y:655,t:1527030629351};\\\", \\\"{x:1208,y:667,t:1527030629368};\\\", \\\"{x:1221,y:672,t:1527030629385};\\\", \\\"{x:1224,y:673,t:1527030629402};\\\", \\\"{x:1224,y:678,t:1527030629419};\\\", \\\"{x:1224,y:683,t:1527030629435};\\\", \\\"{x:1225,y:689,t:1527030629452};\\\", \\\"{x:1235,y:695,t:1527030629468};\\\", \\\"{x:1240,y:696,t:1527030629486};\\\", \\\"{x:1260,y:696,t:1527030629501};\\\", \\\"{x:1273,y:696,t:1527030629518};\\\", \\\"{x:1279,y:698,t:1527030629536};\\\", \\\"{x:1281,y:699,t:1527030629552};\\\", \\\"{x:1282,y:699,t:1527030629569};\\\", \\\"{x:1283,y:699,t:1527030629622};\\\", \\\"{x:1285,y:699,t:1527030629637};\\\", \\\"{x:1287,y:699,t:1527030629652};\\\", \\\"{x:1293,y:699,t:1527030629668};\\\", \\\"{x:1298,y:699,t:1527030629686};\\\", \\\"{x:1300,y:699,t:1527030629702};\\\", \\\"{x:1301,y:699,t:1527030629718};\\\", \\\"{x:1303,y:699,t:1527030629735};\\\", \\\"{x:1309,y:699,t:1527030629752};\\\", \\\"{x:1320,y:698,t:1527030629768};\\\", \\\"{x:1330,y:695,t:1527030629785};\\\", \\\"{x:1340,y:693,t:1527030629802};\\\", \\\"{x:1344,y:693,t:1527030629821};\\\", \\\"{x:1346,y:693,t:1527030629835};\\\", \\\"{x:1345,y:694,t:1527030630078};\\\", \\\"{x:1345,y:695,t:1527030630085};\\\", \\\"{x:1345,y:693,t:1527030630166};\\\", \\\"{x:1349,y:687,t:1527030630175};\\\", \\\"{x:1357,y:678,t:1527030630187};\\\", \\\"{x:1364,y:665,t:1527030630202};\\\", \\\"{x:1369,y:654,t:1527030630220};\\\", \\\"{x:1371,y:646,t:1527030630237};\\\", \\\"{x:1373,y:638,t:1527030630252};\\\", \\\"{x:1374,y:626,t:1527030630269};\\\", \\\"{x:1379,y:605,t:1527030630286};\\\", \\\"{x:1385,y:588,t:1527030630302};\\\", \\\"{x:1390,y:577,t:1527030630319};\\\", \\\"{x:1394,y:569,t:1527030630337};\\\", \\\"{x:1396,y:565,t:1527030630352};\\\", \\\"{x:1397,y:565,t:1527030630370};\\\", \\\"{x:1397,y:563,t:1527030630386};\\\", \\\"{x:1399,y:562,t:1527030630414};\\\", \\\"{x:1400,y:560,t:1527030630421};\\\", \\\"{x:1401,y:559,t:1527030630438};\\\", \\\"{x:1402,y:557,t:1527030630454};\\\", \\\"{x:1403,y:555,t:1527030630486};\\\", \\\"{x:1404,y:554,t:1527030630526};\\\", \\\"{x:1404,y:553,t:1527030630537};\\\", \\\"{x:1406,y:551,t:1527030630552};\\\", \\\"{x:1408,y:550,t:1527030630570};\\\", \\\"{x:1410,y:547,t:1527030630586};\\\", \\\"{x:1411,y:546,t:1527030630604};\\\", \\\"{x:1412,y:545,t:1527030630619};\\\", \\\"{x:1413,y:545,t:1527030630637};\\\", \\\"{x:1414,y:543,t:1527030630678};\\\", \\\"{x:1415,y:542,t:1527030630701};\\\", \\\"{x:1408,y:542,t:1527030631142};\\\", \\\"{x:1384,y:542,t:1527030631153};\\\", \\\"{x:1302,y:539,t:1527030631170};\\\", \\\"{x:1210,y:539,t:1527030631186};\\\", \\\"{x:1113,y:535,t:1527030631204};\\\", \\\"{x:1021,y:535,t:1527030631221};\\\", \\\"{x:929,y:535,t:1527030631236};\\\", \\\"{x:815,y:535,t:1527030631254};\\\", \\\"{x:765,y:535,t:1527030631269};\\\", \\\"{x:723,y:535,t:1527030631287};\\\", \\\"{x:696,y:535,t:1527030631303};\\\", \\\"{x:681,y:535,t:1527030631320};\\\", \\\"{x:673,y:536,t:1527030631336};\\\", \\\"{x:669,y:539,t:1527030631353};\\\", \\\"{x:661,y:543,t:1527030631370};\\\", \\\"{x:651,y:547,t:1527030631386};\\\", \\\"{x:639,y:549,t:1527030631403};\\\", \\\"{x:633,y:550,t:1527030631421};\\\", \\\"{x:632,y:550,t:1527030631436};\\\", \\\"{x:631,y:550,t:1527030631453};\\\", \\\"{x:626,y:548,t:1527030631470};\\\", \\\"{x:623,y:545,t:1527030631488};\\\", \\\"{x:620,y:543,t:1527030631504};\\\", \\\"{x:617,y:539,t:1527030631521};\\\", \\\"{x:617,y:537,t:1527030631537};\\\", \\\"{x:617,y:534,t:1527030631553};\\\", \\\"{x:617,y:533,t:1527030631570};\\\", \\\"{x:617,y:531,t:1527030631587};\\\", \\\"{x:616,y:530,t:1527030631623};\\\", \\\"{x:613,y:529,t:1527030631637};\\\", \\\"{x:595,y:529,t:1527030631653};\\\", \\\"{x:575,y:529,t:1527030631670};\\\", \\\"{x:557,y:529,t:1527030631687};\\\", \\\"{x:545,y:529,t:1527030631703};\\\", \\\"{x:539,y:529,t:1527030631720};\\\", \\\"{x:529,y:529,t:1527030631737};\\\", \\\"{x:511,y:529,t:1527030631754};\\\", \\\"{x:491,y:529,t:1527030631771};\\\", \\\"{x:471,y:529,t:1527030631787};\\\", \\\"{x:456,y:530,t:1527030631804};\\\", \\\"{x:450,y:531,t:1527030631821};\\\", \\\"{x:446,y:531,t:1527030631838};\\\", \\\"{x:444,y:531,t:1527030631854};\\\", \\\"{x:441,y:531,t:1527030631871};\\\", \\\"{x:431,y:531,t:1527030631887};\\\", \\\"{x:414,y:531,t:1527030631904};\\\", \\\"{x:388,y:536,t:1527030631921};\\\", \\\"{x:357,y:539,t:1527030631937};\\\", \\\"{x:325,y:539,t:1527030631954};\\\", \\\"{x:292,y:539,t:1527030631970};\\\", \\\"{x:263,y:539,t:1527030631988};\\\", \\\"{x:233,y:539,t:1527030632003};\\\", \\\"{x:205,y:542,t:1527030632020};\\\", \\\"{x:178,y:547,t:1527030632037};\\\", \\\"{x:175,y:548,t:1527030632054};\\\", \\\"{x:174,y:548,t:1527030632142};\\\", \\\"{x:172,y:549,t:1527030632154};\\\", \\\"{x:167,y:552,t:1527030632170};\\\", \\\"{x:163,y:553,t:1527030632187};\\\", \\\"{x:162,y:555,t:1527030632204};\\\", \\\"{x:162,y:557,t:1527030632278};\\\", \\\"{x:162,y:560,t:1527030632287};\\\", \\\"{x:163,y:565,t:1527030632305};\\\", \\\"{x:168,y:566,t:1527030632321};\\\", \\\"{x:172,y:567,t:1527030632337};\\\", \\\"{x:190,y:567,t:1527030632354};\\\", \\\"{x:223,y:564,t:1527030632371};\\\", \\\"{x:299,y:553,t:1527030632388};\\\", \\\"{x:433,y:541,t:1527030632405};\\\", \\\"{x:685,y:519,t:1527030632422};\\\", \\\"{x:836,y:501,t:1527030632438};\\\", \\\"{x:946,y:495,t:1527030632454};\\\", \\\"{x:1026,y:495,t:1527030632471};\\\", \\\"{x:1063,y:495,t:1527030632487};\\\", \\\"{x:1079,y:495,t:1527030632505};\\\", \\\"{x:1086,y:495,t:1527030632521};\\\", \\\"{x:1086,y:494,t:1527030632582};\\\", \\\"{x:1086,y:493,t:1527030632590};\\\", \\\"{x:1084,y:493,t:1527030632605};\\\", \\\"{x:1070,y:493,t:1527030632621};\\\", \\\"{x:1059,y:493,t:1527030632638};\\\", \\\"{x:1013,y:497,t:1527030632654};\\\", \\\"{x:979,y:503,t:1527030632671};\\\", \\\"{x:956,y:510,t:1527030632688};\\\", \\\"{x:951,y:512,t:1527030632704};\\\", \\\"{x:950,y:513,t:1527030632722};\\\", \\\"{x:948,y:515,t:1527030632739};\\\", \\\"{x:947,y:518,t:1527030632755};\\\", \\\"{x:942,y:523,t:1527030632771};\\\", \\\"{x:938,y:526,t:1527030632789};\\\", \\\"{x:929,y:531,t:1527030632804};\\\", \\\"{x:900,y:539,t:1527030632821};\\\", \\\"{x:889,y:541,t:1527030632837};\\\", \\\"{x:887,y:541,t:1527030632854};\\\", \\\"{x:886,y:541,t:1527030632902};\\\", \\\"{x:885,y:541,t:1527030632917};\\\", \\\"{x:884,y:539,t:1527030632925};\\\", \\\"{x:883,y:539,t:1527030632938};\\\", \\\"{x:882,y:538,t:1527030632966};\\\", \\\"{x:881,y:538,t:1527030632974};\\\", \\\"{x:880,y:537,t:1527030632988};\\\", \\\"{x:879,y:537,t:1527030633004};\\\", \\\"{x:877,y:536,t:1527030633029};\\\", \\\"{x:875,y:536,t:1527030633045};\\\", \\\"{x:873,y:536,t:1527030633054};\\\", \\\"{x:870,y:535,t:1527030633071};\\\", \\\"{x:868,y:535,t:1527030633089};\\\", \\\"{x:867,y:535,t:1527030633104};\\\", \\\"{x:859,y:535,t:1527030633121};\\\", \\\"{x:851,y:536,t:1527030633139};\\\", \\\"{x:847,y:536,t:1527030633155};\\\", \\\"{x:843,y:536,t:1527030633171};\\\", \\\"{x:842,y:536,t:1527030633188};\\\", \\\"{x:840,y:536,t:1527030633204};\\\", \\\"{x:838,y:536,t:1527030633221};\\\", \\\"{x:837,y:536,t:1527030633294};\\\", \\\"{x:834,y:536,t:1527030633518};\\\", \\\"{x:828,y:538,t:1527030633526};\\\", \\\"{x:818,y:544,t:1527030633539};\\\", \\\"{x:793,y:558,t:1527030633556};\\\", \\\"{x:759,y:576,t:1527030633572};\\\", \\\"{x:721,y:598,t:1527030633589};\\\", \\\"{x:681,y:620,t:1527030633606};\\\", \\\"{x:662,y:631,t:1527030633622};\\\", \\\"{x:651,y:639,t:1527030633639};\\\", \\\"{x:644,y:644,t:1527030633655};\\\", \\\"{x:640,y:649,t:1527030633672};\\\", \\\"{x:634,y:656,t:1527030633688};\\\", \\\"{x:628,y:664,t:1527030633705};\\\", \\\"{x:626,y:667,t:1527030633722};\\\", \\\"{x:624,y:669,t:1527030633739};\\\", \\\"{x:624,y:670,t:1527030633756};\\\", \\\"{x:623,y:671,t:1527030633772};\\\", \\\"{x:620,y:675,t:1527030633789};\\\", \\\"{x:615,y:681,t:1527030633806};\\\", \\\"{x:609,y:685,t:1527030633823};\\\", \\\"{x:606,y:688,t:1527030633840};\\\", \\\"{x:603,y:691,t:1527030633855};\\\", \\\"{x:601,y:691,t:1527030633872};\\\", \\\"{x:599,y:692,t:1527030633890};\\\", \\\"{x:593,y:695,t:1527030633906};\\\", \\\"{x:583,y:700,t:1527030633922};\\\", \\\"{x:572,y:709,t:1527030633939};\\\", \\\"{x:562,y:715,t:1527030633957};\\\", \\\"{x:552,y:723,t:1527030633974};\\\", \\\"{x:551,y:724,t:1527030633990};\\\", \\\"{x:549,y:724,t:1527030634014};\\\", \\\"{x:548,y:724,t:1527030634029};\\\", \\\"{x:546,y:724,t:1527030634045};\\\", \\\"{x:543,y:726,t:1527030634055};\\\", \\\"{x:540,y:727,t:1527030634072};\\\", \\\"{x:537,y:730,t:1527030634089};\\\", \\\"{x:534,y:731,t:1527030634105};\\\", \\\"{x:533,y:732,t:1527030634286};\\\", \\\"{x:533,y:732,t:1527030634356};\\\", \\\"{x:532,y:732,t:1527030634413};\\\", \\\"{x:533,y:731,t:1527030634566};\\\", \\\"{x:534,y:728,t:1527030634574};\\\", \\\"{x:539,y:723,t:1527030634590};\\\", \\\"{x:554,y:710,t:1527030634606};\\\", \\\"{x:577,y:695,t:1527030634623};\\\", \\\"{x:609,y:672,t:1527030634639};\\\", \\\"{x:641,y:649,t:1527030634656};\\\", \\\"{x:675,y:623,t:1527030634673};\\\", \\\"{x:705,y:600,t:1527030634689};\\\", \\\"{x:732,y:577,t:1527030634706};\\\", \\\"{x:764,y:553,t:1527030634723};\\\", \\\"{x:797,y:533,t:1527030634740};\\\", \\\"{x:826,y:510,t:1527030634757};\\\", \\\"{x:843,y:495,t:1527030634772};\\\", \\\"{x:858,y:483,t:1527030634789};\\\", \\\"{x:861,y:479,t:1527030634807};\\\", \\\"{x:862,y:478,t:1527030634822};\\\", \\\"{x:863,y:478,t:1527030634839};\\\", \\\"{x:864,y:478,t:1527030634870};\\\", \\\"{x:864,y:479,t:1527030635038};\\\", \\\"{x:864,y:480,t:1527030635045};\\\", \\\"{x:864,y:481,t:1527030635070};\\\", \\\"{x:861,y:482,t:1527030635086};\\\", \\\"{x:861,y:483,t:1527030635094};\\\", \\\"{x:859,y:483,t:1527030635107};\\\", \\\"{x:857,y:485,t:1527030635123};\\\", \\\"{x:856,y:485,t:1527030635139};\\\", \\\"{x:854,y:485,t:1527030635156};\\\", \\\"{x:848,y:488,t:1527030635173};\\\", \\\"{x:847,y:489,t:1527030635190};\\\", \\\"{x:841,y:491,t:1527030635207};\\\", \\\"{x:839,y:492,t:1527030635224};\\\", \\\"{x:837,y:493,t:1527030635240};\\\", \\\"{x:836,y:494,t:1527030635256};\\\", \\\"{x:835,y:494,t:1527030635285};\\\", \\\"{x:835,y:495,t:1527030635293};\\\", \\\"{x:834,y:495,t:1527030635309};\\\", \\\"{x:833,y:495,t:1527030635333};\\\", \\\"{x:832,y:496,t:1527030635349};\\\", \\\"{x:832,y:497,t:1527030635382};\\\", \\\"{x:832,y:498,t:1527030635413};\\\", \\\"{x:831,y:498,t:1527030635429};\\\" ] }, { \\\"rt\\\": 10209, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 591146, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:828,y:512,t:1527030635559};\\\", \\\"{x:827,y:514,t:1527030635591};\\\", \\\"{x:826,y:515,t:1527030635629};\\\", \\\"{x:825,y:517,t:1527030635710};\\\", \\\"{x:825,y:518,t:1527030635724};\\\", \\\"{x:822,y:522,t:1527030635744};\\\", \\\"{x:820,y:524,t:1527030635757};\\\", \\\"{x:818,y:526,t:1527030635774};\\\", \\\"{x:818,y:528,t:1527030635791};\\\", \\\"{x:817,y:529,t:1527030635806};\\\", \\\"{x:816,y:530,t:1527030635825};\\\", \\\"{x:816,y:531,t:1527030635840};\\\", \\\"{x:813,y:533,t:1527030635858};\\\", \\\"{x:811,y:535,t:1527030635873};\\\", \\\"{x:810,y:536,t:1527030635891};\\\", \\\"{x:806,y:539,t:1527030635908};\\\", \\\"{x:799,y:544,t:1527030635923};\\\", \\\"{x:794,y:547,t:1527030635940};\\\", \\\"{x:790,y:550,t:1527030635957};\\\", \\\"{x:789,y:550,t:1527030635997};\\\", \\\"{x:788,y:550,t:1527030636008};\\\", \\\"{x:785,y:550,t:1527030636024};\\\", \\\"{x:775,y:554,t:1527030636041};\\\", \\\"{x:761,y:558,t:1527030636058};\\\", \\\"{x:697,y:564,t:1527030636116};\\\", \\\"{x:683,y:564,t:1527030636130};\\\", \\\"{x:679,y:564,t:1527030636140};\\\", \\\"{x:674,y:564,t:1527030636157};\\\", \\\"{x:673,y:564,t:1527030636173};\\\", \\\"{x:672,y:564,t:1527030636190};\\\", \\\"{x:671,y:564,t:1527030636207};\\\", \\\"{x:668,y:564,t:1527030636223};\\\", \\\"{x:666,y:564,t:1527030636240};\\\", \\\"{x:665,y:563,t:1527030636257};\\\", \\\"{x:661,y:559,t:1527030636274};\\\", \\\"{x:657,y:554,t:1527030636291};\\\", \\\"{x:648,y:547,t:1527030636308};\\\", \\\"{x:636,y:541,t:1527030636324};\\\", \\\"{x:621,y:533,t:1527030636340};\\\", \\\"{x:599,y:525,t:1527030636357};\\\", \\\"{x:577,y:516,t:1527030636374};\\\", \\\"{x:548,y:505,t:1527030636390};\\\", \\\"{x:527,y:499,t:1527030636407};\\\", \\\"{x:512,y:496,t:1527030636424};\\\", \\\"{x:505,y:494,t:1527030636440};\\\", \\\"{x:503,y:494,t:1527030636457};\\\", \\\"{x:503,y:493,t:1527030636474};\\\", \\\"{x:503,y:492,t:1527030636550};\\\", \\\"{x:505,y:491,t:1527030636557};\\\", \\\"{x:510,y:489,t:1527030636574};\\\", \\\"{x:516,y:486,t:1527030636591};\\\", \\\"{x:523,y:483,t:1527030636607};\\\", \\\"{x:529,y:479,t:1527030636625};\\\", \\\"{x:534,y:476,t:1527030636642};\\\", \\\"{x:537,y:473,t:1527030636658};\\\", \\\"{x:543,y:469,t:1527030636675};\\\", \\\"{x:547,y:467,t:1527030636691};\\\", \\\"{x:548,y:466,t:1527030636707};\\\", \\\"{x:550,y:465,t:1527030636724};\\\", \\\"{x:552,y:464,t:1527030636742};\\\", \\\"{x:553,y:463,t:1527030636758};\\\", \\\"{x:555,y:462,t:1527030636775};\\\", \\\"{x:556,y:461,t:1527030636830};\\\", \\\"{x:559,y:462,t:1527030636975};\\\", \\\"{x:570,y:470,t:1527030636992};\\\", \\\"{x:592,y:477,t:1527030637009};\\\", \\\"{x:623,y:481,t:1527030637025};\\\", \\\"{x:665,y:488,t:1527030637044};\\\", \\\"{x:718,y:495,t:1527030637059};\\\", \\\"{x:785,y:505,t:1527030637075};\\\", \\\"{x:860,y:516,t:1527030637092};\\\", \\\"{x:952,y:527,t:1527030637109};\\\", \\\"{x:1027,y:540,t:1527030637125};\\\", \\\"{x:1115,y:551,t:1527030637141};\\\", \\\"{x:1153,y:553,t:1527030637157};\\\", \\\"{x:1175,y:553,t:1527030637175};\\\", \\\"{x:1184,y:553,t:1527030637191};\\\", \\\"{x:1191,y:554,t:1527030637209};\\\", \\\"{x:1192,y:555,t:1527030637225};\\\", \\\"{x:1196,y:556,t:1527030637242};\\\", \\\"{x:1202,y:556,t:1527030637259};\\\", \\\"{x:1206,y:556,t:1527030637275};\\\", \\\"{x:1210,y:556,t:1527030637291};\\\", \\\"{x:1213,y:556,t:1527030637308};\\\", \\\"{x:1217,y:556,t:1527030637325};\\\", \\\"{x:1220,y:558,t:1527030637591};\\\", \\\"{x:1222,y:559,t:1527030637599};\\\", \\\"{x:1228,y:562,t:1527030637609};\\\", \\\"{x:1247,y:574,t:1527030637627};\\\", \\\"{x:1274,y:593,t:1527030637642};\\\", \\\"{x:1318,y:619,t:1527030637659};\\\", \\\"{x:1366,y:641,t:1527030637676};\\\", \\\"{x:1413,y:663,t:1527030637692};\\\", \\\"{x:1463,y:684,t:1527030637709};\\\", \\\"{x:1562,y:718,t:1527030637727};\\\", \\\"{x:1644,y:738,t:1527030637743};\\\", \\\"{x:1717,y:760,t:1527030637759};\\\", \\\"{x:1759,y:767,t:1527030637776};\\\", \\\"{x:1776,y:768,t:1527030637792};\\\", \\\"{x:1782,y:767,t:1527030637810};\\\", \\\"{x:1784,y:766,t:1527030637879};\\\", \\\"{x:1786,y:766,t:1527030637893};\\\", \\\"{x:1791,y:764,t:1527030637909};\\\", \\\"{x:1811,y:762,t:1527030637927};\\\", \\\"{x:1829,y:756,t:1527030637942};\\\", \\\"{x:1843,y:751,t:1527030637960};\\\", \\\"{x:1848,y:748,t:1527030637976};\\\", \\\"{x:1849,y:748,t:1527030637994};\\\", \\\"{x:1846,y:748,t:1527030638127};\\\", \\\"{x:1820,y:750,t:1527030638143};\\\", \\\"{x:1790,y:755,t:1527030638160};\\\", \\\"{x:1762,y:758,t:1527030638176};\\\", \\\"{x:1740,y:763,t:1527030638194};\\\", \\\"{x:1725,y:763,t:1527030638210};\\\", \\\"{x:1712,y:763,t:1527030638226};\\\", \\\"{x:1710,y:763,t:1527030638243};\\\", \\\"{x:1708,y:762,t:1527030638261};\\\", \\\"{x:1707,y:761,t:1527030638277};\\\", \\\"{x:1705,y:758,t:1527030638293};\\\", \\\"{x:1701,y:751,t:1527030638310};\\\", \\\"{x:1698,y:745,t:1527030638326};\\\", \\\"{x:1698,y:741,t:1527030638343};\\\", \\\"{x:1698,y:736,t:1527030638362};\\\", \\\"{x:1697,y:731,t:1527030638376};\\\", \\\"{x:1696,y:727,t:1527030638393};\\\", \\\"{x:1694,y:724,t:1527030638411};\\\", \\\"{x:1693,y:724,t:1527030638431};\\\", \\\"{x:1692,y:724,t:1527030638446};\\\", \\\"{x:1691,y:724,t:1527030638463};\\\", \\\"{x:1690,y:724,t:1527030638478};\\\", \\\"{x:1688,y:724,t:1527030638494};\\\", \\\"{x:1682,y:724,t:1527030638511};\\\", \\\"{x:1676,y:724,t:1527030638526};\\\", \\\"{x:1670,y:724,t:1527030638544};\\\", \\\"{x:1665,y:724,t:1527030638562};\\\", \\\"{x:1657,y:724,t:1527030638577};\\\", \\\"{x:1646,y:722,t:1527030638593};\\\", \\\"{x:1641,y:720,t:1527030638610};\\\", \\\"{x:1639,y:720,t:1527030638626};\\\", \\\"{x:1637,y:719,t:1527030638643};\\\", \\\"{x:1636,y:718,t:1527030638660};\\\", \\\"{x:1635,y:718,t:1527030638677};\\\", \\\"{x:1635,y:717,t:1527030638693};\\\", \\\"{x:1634,y:716,t:1527030638710};\\\", \\\"{x:1634,y:715,t:1527030638773};\\\", \\\"{x:1634,y:714,t:1527030638789};\\\", \\\"{x:1633,y:714,t:1527030638798};\\\", \\\"{x:1633,y:713,t:1527030638809};\\\", \\\"{x:1633,y:712,t:1527030638827};\\\", \\\"{x:1633,y:711,t:1527030638843};\\\", \\\"{x:1632,y:710,t:1527030638862};\\\", \\\"{x:1631,y:710,t:1527030638878};\\\", \\\"{x:1631,y:708,t:1527030638894};\\\", \\\"{x:1630,y:708,t:1527030638910};\\\", \\\"{x:1630,y:707,t:1527030638927};\\\", \\\"{x:1628,y:705,t:1527030638944};\\\", \\\"{x:1625,y:702,t:1527030638961};\\\", \\\"{x:1624,y:702,t:1527030638977};\\\", \\\"{x:1623,y:701,t:1527030638994};\\\", \\\"{x:1621,y:699,t:1527030639010};\\\", \\\"{x:1620,y:699,t:1527030639027};\\\", \\\"{x:1619,y:697,t:1527030639045};\\\", \\\"{x:1617,y:697,t:1527030639060};\\\", \\\"{x:1616,y:696,t:1527030639077};\\\", \\\"{x:1614,y:695,t:1527030639094};\\\", \\\"{x:1613,y:695,t:1527030639126};\\\", \\\"{x:1612,y:695,t:1527030639144};\\\", \\\"{x:1611,y:694,t:1527030639182};\\\", \\\"{x:1610,y:694,t:1527030639198};\\\", \\\"{x:1609,y:694,t:1527030639210};\\\", \\\"{x:1608,y:694,t:1527030639352};\\\", \\\"{x:1609,y:694,t:1527030639559};\\\", \\\"{x:1610,y:694,t:1527030639577};\\\", \\\"{x:1611,y:694,t:1527030639598};\\\", \\\"{x:1613,y:694,t:1527030639646};\\\", \\\"{x:1614,y:694,t:1527030639661};\\\", \\\"{x:1615,y:695,t:1527030639678};\\\", \\\"{x:1616,y:695,t:1527030639702};\\\", \\\"{x:1617,y:696,t:1527030640799};\\\", \\\"{x:1616,y:697,t:1527030640847};\\\", \\\"{x:1614,y:697,t:1527030640862};\\\", \\\"{x:1612,y:699,t:1527030640879};\\\", \\\"{x:1611,y:701,t:1527030640895};\\\", \\\"{x:1608,y:703,t:1527030640913};\\\", \\\"{x:1606,y:706,t:1527030640930};\\\", \\\"{x:1604,y:708,t:1527030640945};\\\", \\\"{x:1602,y:710,t:1527030640962};\\\", \\\"{x:1601,y:713,t:1527030640979};\\\", \\\"{x:1598,y:717,t:1527030640995};\\\", \\\"{x:1595,y:721,t:1527030641013};\\\", \\\"{x:1594,y:723,t:1527030641030};\\\", \\\"{x:1592,y:727,t:1527030641046};\\\", \\\"{x:1590,y:732,t:1527030641063};\\\", \\\"{x:1589,y:736,t:1527030641079};\\\", \\\"{x:1586,y:738,t:1527030641096};\\\", \\\"{x:1583,y:743,t:1527030641113};\\\", \\\"{x:1582,y:746,t:1527030641129};\\\", \\\"{x:1580,y:751,t:1527030641146};\\\", \\\"{x:1578,y:755,t:1527030641162};\\\", \\\"{x:1576,y:759,t:1527030641180};\\\", \\\"{x:1574,y:763,t:1527030641197};\\\", \\\"{x:1571,y:771,t:1527030641213};\\\", \\\"{x:1567,y:786,t:1527030641230};\\\", \\\"{x:1562,y:800,t:1527030641247};\\\", \\\"{x:1561,y:804,t:1527030641263};\\\", \\\"{x:1560,y:807,t:1527030641280};\\\", \\\"{x:1558,y:810,t:1527030641297};\\\", \\\"{x:1558,y:813,t:1527030641312};\\\", \\\"{x:1557,y:816,t:1527030641329};\\\", \\\"{x:1556,y:823,t:1527030641346};\\\", \\\"{x:1552,y:837,t:1527030641363};\\\", \\\"{x:1549,y:847,t:1527030641379};\\\", \\\"{x:1549,y:850,t:1527030641396};\\\", \\\"{x:1548,y:851,t:1527030641412};\\\", \\\"{x:1548,y:852,t:1527030641428};\\\", \\\"{x:1548,y:853,t:1527030641446};\\\", \\\"{x:1546,y:855,t:1527030641463};\\\", \\\"{x:1546,y:856,t:1527030641479};\\\", \\\"{x:1544,y:861,t:1527030641495};\\\", \\\"{x:1542,y:865,t:1527030641513};\\\", \\\"{x:1540,y:869,t:1527030641529};\\\", \\\"{x:1537,y:873,t:1527030641546};\\\", \\\"{x:1534,y:876,t:1527030641563};\\\", \\\"{x:1532,y:879,t:1527030641579};\\\", \\\"{x:1528,y:884,t:1527030641596};\\\", \\\"{x:1523,y:892,t:1527030641613};\\\", \\\"{x:1516,y:899,t:1527030641629};\\\", \\\"{x:1508,y:912,t:1527030641646};\\\", \\\"{x:1503,y:919,t:1527030641663};\\\", \\\"{x:1499,y:923,t:1527030641679};\\\", \\\"{x:1496,y:928,t:1527030641696};\\\", \\\"{x:1493,y:931,t:1527030641713};\\\", \\\"{x:1492,y:933,t:1527030641730};\\\", \\\"{x:1492,y:934,t:1527030641746};\\\", \\\"{x:1490,y:937,t:1527030641763};\\\", \\\"{x:1490,y:939,t:1527030641780};\\\", \\\"{x:1489,y:940,t:1527030641796};\\\", \\\"{x:1489,y:941,t:1527030641887};\\\", \\\"{x:1488,y:942,t:1527030641896};\\\", \\\"{x:1488,y:944,t:1527030641919};\\\", \\\"{x:1487,y:944,t:1527030641931};\\\", \\\"{x:1487,y:945,t:1527030641951};\\\", \\\"{x:1486,y:945,t:1527030641964};\\\", \\\"{x:1486,y:946,t:1527030641982};\\\", \\\"{x:1486,y:947,t:1527030641997};\\\", \\\"{x:1486,y:948,t:1527030642013};\\\", \\\"{x:1485,y:949,t:1527030642030};\\\", \\\"{x:1484,y:951,t:1527030642070};\\\", \\\"{x:1484,y:952,t:1527030642111};\\\", \\\"{x:1483,y:953,t:1527030642118};\\\", \\\"{x:1483,y:954,t:1527030642135};\\\", \\\"{x:1482,y:956,t:1527030642146};\\\", \\\"{x:1482,y:958,t:1527030642166};\\\", \\\"{x:1480,y:959,t:1527030642471};\\\", \\\"{x:1480,y:960,t:1527030642481};\\\", \\\"{x:1479,y:961,t:1527030642498};\\\", \\\"{x:1479,y:962,t:1527030642515};\\\", \\\"{x:1479,y:963,t:1527030642531};\\\", \\\"{x:1477,y:964,t:1527030642548};\\\", \\\"{x:1476,y:966,t:1527030642565};\\\", \\\"{x:1477,y:966,t:1527030642775};\\\", \\\"{x:1479,y:960,t:1527030642782};\\\", \\\"{x:1479,y:948,t:1527030642798};\\\", \\\"{x:1479,y:910,t:1527030642815};\\\", \\\"{x:1464,y:862,t:1527030642831};\\\", \\\"{x:1436,y:801,t:1527030642847};\\\", \\\"{x:1405,y:744,t:1527030642865};\\\", \\\"{x:1373,y:699,t:1527030642882};\\\", \\\"{x:1348,y:660,t:1527030642898};\\\", \\\"{x:1323,y:623,t:1527030642915};\\\", \\\"{x:1305,y:589,t:1527030642931};\\\", \\\"{x:1289,y:562,t:1527030642947};\\\", \\\"{x:1276,y:540,t:1527030642964};\\\", \\\"{x:1266,y:521,t:1527030642981};\\\", \\\"{x:1254,y:505,t:1527030642997};\\\", \\\"{x:1234,y:483,t:1527030643014};\\\", \\\"{x:1217,y:472,t:1527030643031};\\\", \\\"{x:1205,y:465,t:1527030643047};\\\", \\\"{x:1197,y:461,t:1527030643064};\\\", \\\"{x:1190,y:458,t:1527030643081};\\\", \\\"{x:1180,y:453,t:1527030643097};\\\", \\\"{x:1164,y:450,t:1527030643114};\\\", \\\"{x:1135,y:450,t:1527030643131};\\\", \\\"{x:1101,y:450,t:1527030643147};\\\", \\\"{x:1074,y:452,t:1527030643164};\\\", \\\"{x:1048,y:462,t:1527030643181};\\\", \\\"{x:1011,y:477,t:1527030643198};\\\", \\\"{x:992,y:487,t:1527030643214};\\\", \\\"{x:973,y:496,t:1527030643231};\\\", \\\"{x:955,y:501,t:1527030643248};\\\", \\\"{x:940,y:509,t:1527030643265};\\\", \\\"{x:913,y:524,t:1527030643282};\\\", \\\"{x:866,y:545,t:1527030643298};\\\", \\\"{x:808,y:559,t:1527030643312};\\\", \\\"{x:739,y:559,t:1527030643329};\\\", \\\"{x:694,y:559,t:1527030643346};\\\", \\\"{x:671,y:557,t:1527030643363};\\\", \\\"{x:657,y:553,t:1527030643380};\\\", \\\"{x:650,y:551,t:1527030643396};\\\", \\\"{x:642,y:549,t:1527030643414};\\\", \\\"{x:627,y:547,t:1527030643430};\\\", \\\"{x:614,y:546,t:1527030643447};\\\", \\\"{x:604,y:546,t:1527030643463};\\\", \\\"{x:597,y:546,t:1527030643481};\\\", \\\"{x:595,y:546,t:1527030643497};\\\", \\\"{x:594,y:546,t:1527030643534};\\\", \\\"{x:593,y:546,t:1527030643547};\\\", \\\"{x:588,y:546,t:1527030643563};\\\", \\\"{x:575,y:548,t:1527030643580};\\\", \\\"{x:561,y:548,t:1527030643597};\\\", \\\"{x:551,y:549,t:1527030643614};\\\", \\\"{x:549,y:549,t:1527030643630};\\\", \\\"{x:549,y:545,t:1527030643694};\\\", \\\"{x:552,y:541,t:1527030643702};\\\", \\\"{x:556,y:535,t:1527030643714};\\\", \\\"{x:567,y:527,t:1527030643731};\\\", \\\"{x:575,y:522,t:1527030643748};\\\", \\\"{x:580,y:518,t:1527030643764};\\\", \\\"{x:582,y:517,t:1527030643780};\\\", \\\"{x:583,y:516,t:1527030643797};\\\", \\\"{x:588,y:514,t:1527030643814};\\\", \\\"{x:591,y:512,t:1527030643829};\\\", \\\"{x:596,y:511,t:1527030643846};\\\", \\\"{x:597,y:509,t:1527030643863};\\\", \\\"{x:598,y:509,t:1527030643880};\\\", \\\"{x:599,y:509,t:1527030643897};\\\", \\\"{x:600,y:509,t:1527030643959};\\\", \\\"{x:600,y:508,t:1527030644045};\\\", \\\"{x:602,y:508,t:1527030644181};\\\", \\\"{x:606,y:508,t:1527030644196};\\\", \\\"{x:630,y:501,t:1527030644214};\\\", \\\"{x:654,y:494,t:1527030644231};\\\", \\\"{x:675,y:489,t:1527030644247};\\\", \\\"{x:693,y:483,t:1527030644264};\\\", \\\"{x:707,y:479,t:1527030644281};\\\", \\\"{x:715,y:479,t:1527030644297};\\\", \\\"{x:719,y:479,t:1527030644314};\\\", \\\"{x:724,y:479,t:1527030644330};\\\", \\\"{x:738,y:479,t:1527030644346};\\\", \\\"{x:760,y:479,t:1527030644363};\\\", \\\"{x:776,y:479,t:1527030644380};\\\", \\\"{x:784,y:479,t:1527030644397};\\\", \\\"{x:789,y:480,t:1527030644413};\\\", \\\"{x:796,y:484,t:1527030644431};\\\", \\\"{x:803,y:489,t:1527030644448};\\\", \\\"{x:805,y:491,t:1527030644464};\\\", \\\"{x:806,y:492,t:1527030644486};\\\", \\\"{x:806,y:493,t:1527030644501};\\\", \\\"{x:807,y:494,t:1527030644518};\\\", \\\"{x:808,y:494,t:1527030644532};\\\", \\\"{x:810,y:497,t:1527030644548};\\\", \\\"{x:812,y:499,t:1527030644565};\\\", \\\"{x:813,y:500,t:1527030644581};\\\", \\\"{x:814,y:502,t:1527030644598};\\\", \\\"{x:816,y:504,t:1527030644614};\\\", \\\"{x:821,y:504,t:1527030644632};\\\", \\\"{x:826,y:504,t:1527030644650};\\\", \\\"{x:830,y:504,t:1527030644665};\\\", \\\"{x:826,y:504,t:1527030644941};\\\", \\\"{x:808,y:510,t:1527030644949};\\\", \\\"{x:783,y:518,t:1527030644965};\\\", \\\"{x:718,y:537,t:1527030644981};\\\", \\\"{x:584,y:582,t:1527030644998};\\\", \\\"{x:539,y:605,t:1527030645016};\\\", \\\"{x:529,y:623,t:1527030645031};\\\", \\\"{x:529,y:639,t:1527030645049};\\\", \\\"{x:529,y:661,t:1527030645065};\\\", \\\"{x:525,y:686,t:1527030645080};\\\", \\\"{x:518,y:706,t:1527030645098};\\\", \\\"{x:509,y:728,t:1527030645116};\\\", \\\"{x:499,y:740,t:1527030645131};\\\", \\\"{x:485,y:744,t:1527030645148};\\\", \\\"{x:480,y:745,t:1527030645165};\\\", \\\"{x:478,y:745,t:1527030645181};\\\", \\\"{x:474,y:742,t:1527030645198};\\\", \\\"{x:476,y:742,t:1527030645359};\\\", \\\"{x:476,y:741,t:1527030645365};\\\", \\\"{x:477,y:740,t:1527030645381};\\\", \\\"{x:479,y:740,t:1527030645461};\\\", \\\"{x:481,y:740,t:1527030645470};\\\", \\\"{x:484,y:740,t:1527030645482};\\\", \\\"{x:486,y:739,t:1527030645498};\\\", \\\"{x:487,y:739,t:1527030645549};\\\", \\\"{x:488,y:739,t:1527030645565};\\\", \\\"{x:489,y:739,t:1527030645581};\\\", \\\"{x:491,y:738,t:1527030645605};\\\", \\\"{x:491,y:737,t:1527030646774};\\\", \\\"{x:493,y:736,t:1527030646792};\\\", \\\"{x:494,y:736,t:1527030646799};\\\", \\\"{x:495,y:736,t:1527030646815};\\\", \\\"{x:496,y:736,t:1527030646833};\\\", \\\"{x:497,y:736,t:1527030646861};\\\" ] }, { \\\"rt\\\": 5367, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 597727, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:736,t:1527030646999};\\\", \\\"{x:499,y:736,t:1527030647021};\\\", \\\"{x:500,y:736,t:1527030647133};\\\", \\\"{x:502,y:736,t:1527030647149};\\\", \\\"{x:504,y:736,t:1527030647166};\\\", \\\"{x:506,y:734,t:1527030647183};\\\", \\\"{x:507,y:734,t:1527030647200};\\\", \\\"{x:508,y:734,t:1527030647390};\\\", \\\"{x:510,y:732,t:1527030647814};\\\", \\\"{x:510,y:730,t:1527030647822};\\\", \\\"{x:510,y:725,t:1527030647834};\\\", \\\"{x:514,y:716,t:1527030647851};\\\", \\\"{x:517,y:704,t:1527030647867};\\\", \\\"{x:519,y:695,t:1527030647883};\\\", \\\"{x:520,y:685,t:1527030647900};\\\", \\\"{x:521,y:680,t:1527030647917};\\\", \\\"{x:522,y:673,t:1527030647933};\\\", \\\"{x:522,y:669,t:1527030647950};\\\", \\\"{x:522,y:665,t:1527030647967};\\\", \\\"{x:522,y:659,t:1527030647984};\\\", \\\"{x:522,y:654,t:1527030648000};\\\", \\\"{x:522,y:650,t:1527030648017};\\\", \\\"{x:524,y:644,t:1527030648034};\\\", \\\"{x:524,y:641,t:1527030648050};\\\", \\\"{x:524,y:636,t:1527030648067};\\\", \\\"{x:524,y:629,t:1527030648085};\\\", \\\"{x:524,y:623,t:1527030648100};\\\", \\\"{x:524,y:617,t:1527030648117};\\\", \\\"{x:524,y:612,t:1527030648133};\\\", \\\"{x:524,y:611,t:1527030648150};\\\", \\\"{x:524,y:610,t:1527030648167};\\\", \\\"{x:525,y:609,t:1527030648302};\\\", \\\"{x:526,y:609,t:1527030648318};\\\", \\\"{x:527,y:607,t:1527030648334};\\\", \\\"{x:529,y:607,t:1527030648422};\\\", \\\"{x:535,y:612,t:1527030648434};\\\", \\\"{x:573,y:627,t:1527030648451};\\\", \\\"{x:654,y:652,t:1527030648469};\\\", \\\"{x:764,y:683,t:1527030648484};\\\", \\\"{x:891,y:719,t:1527030648501};\\\", \\\"{x:1034,y:749,t:1527030648517};\\\", \\\"{x:1248,y:775,t:1527030648534};\\\", \\\"{x:1373,y:796,t:1527030648551};\\\", \\\"{x:1520,y:815,t:1527030648567};\\\", \\\"{x:1644,y:832,t:1527030648584};\\\", \\\"{x:1747,y:848,t:1527030648601};\\\", \\\"{x:1821,y:855,t:1527030648617};\\\", \\\"{x:1853,y:862,t:1527030648634};\\\", \\\"{x:1860,y:868,t:1527030648651};\\\", \\\"{x:1863,y:871,t:1527030648667};\\\", \\\"{x:1863,y:875,t:1527030648684};\\\", \\\"{x:1864,y:877,t:1527030648702};\\\", \\\"{x:1871,y:890,t:1527030648717};\\\", \\\"{x:1874,y:896,t:1527030648734};\\\", \\\"{x:1874,y:898,t:1527030648752};\\\", \\\"{x:1871,y:905,t:1527030648769};\\\", \\\"{x:1853,y:916,t:1527030648784};\\\", \\\"{x:1832,y:926,t:1527030648801};\\\", \\\"{x:1803,y:935,t:1527030648818};\\\", \\\"{x:1778,y:941,t:1527030648835};\\\", \\\"{x:1756,y:944,t:1527030648851};\\\", \\\"{x:1741,y:945,t:1527030648868};\\\", \\\"{x:1718,y:945,t:1527030648884};\\\", \\\"{x:1680,y:942,t:1527030648901};\\\", \\\"{x:1583,y:928,t:1527030648918};\\\", \\\"{x:1528,y:920,t:1527030648935};\\\", \\\"{x:1473,y:908,t:1527030648952};\\\", \\\"{x:1438,y:897,t:1527030648969};\\\", \\\"{x:1426,y:896,t:1527030648985};\\\", \\\"{x:1427,y:896,t:1527030649079};\\\", \\\"{x:1429,y:897,t:1527030649087};\\\", \\\"{x:1432,y:899,t:1527030649102};\\\", \\\"{x:1443,y:910,t:1527030649118};\\\", \\\"{x:1452,y:917,t:1527030649136};\\\", \\\"{x:1458,y:922,t:1527030649152};\\\", \\\"{x:1463,y:926,t:1527030649168};\\\", \\\"{x:1467,y:927,t:1527030649186};\\\", \\\"{x:1471,y:928,t:1527030649202};\\\", \\\"{x:1473,y:928,t:1527030649219};\\\", \\\"{x:1475,y:928,t:1527030649235};\\\", \\\"{x:1480,y:928,t:1527030649252};\\\", \\\"{x:1482,y:928,t:1527030649268};\\\", \\\"{x:1484,y:928,t:1527030649286};\\\", \\\"{x:1485,y:927,t:1527030649301};\\\", \\\"{x:1486,y:917,t:1527030649319};\\\", \\\"{x:1491,y:907,t:1527030649336};\\\", \\\"{x:1495,y:899,t:1527030649352};\\\", \\\"{x:1498,y:891,t:1527030649369};\\\", \\\"{x:1500,y:887,t:1527030649386};\\\", \\\"{x:1500,y:883,t:1527030649402};\\\", \\\"{x:1500,y:878,t:1527030649418};\\\", \\\"{x:1500,y:872,t:1527030649435};\\\", \\\"{x:1498,y:864,t:1527030649452};\\\", \\\"{x:1497,y:853,t:1527030649469};\\\", \\\"{x:1494,y:839,t:1527030649486};\\\", \\\"{x:1493,y:834,t:1527030649501};\\\", \\\"{x:1488,y:825,t:1527030649519};\\\", \\\"{x:1483,y:819,t:1527030649536};\\\", \\\"{x:1476,y:815,t:1527030649551};\\\", \\\"{x:1472,y:813,t:1527030649570};\\\", \\\"{x:1467,y:811,t:1527030649586};\\\", \\\"{x:1466,y:811,t:1527030649631};\\\", \\\"{x:1465,y:810,t:1527030649646};\\\", \\\"{x:1464,y:809,t:1527030649670};\\\", \\\"{x:1462,y:807,t:1527030649686};\\\", \\\"{x:1460,y:805,t:1527030649702};\\\", \\\"{x:1458,y:802,t:1527030649719};\\\", \\\"{x:1454,y:796,t:1527030649736};\\\", \\\"{x:1450,y:791,t:1527030649753};\\\", \\\"{x:1446,y:785,t:1527030649769};\\\", \\\"{x:1443,y:781,t:1527030649786};\\\", \\\"{x:1441,y:778,t:1527030649802};\\\", \\\"{x:1439,y:775,t:1527030649818};\\\", \\\"{x:1438,y:771,t:1527030649835};\\\", \\\"{x:1436,y:766,t:1527030649853};\\\", \\\"{x:1434,y:762,t:1527030649868};\\\", \\\"{x:1428,y:750,t:1527030649885};\\\", \\\"{x:1422,y:739,t:1527030649901};\\\", \\\"{x:1413,y:728,t:1527030649918};\\\", \\\"{x:1402,y:714,t:1527030649935};\\\", \\\"{x:1388,y:700,t:1527030649952};\\\", \\\"{x:1367,y:683,t:1527030649968};\\\", \\\"{x:1346,y:669,t:1527030649985};\\\", \\\"{x:1324,y:656,t:1527030650003};\\\", \\\"{x:1299,y:644,t:1527030650018};\\\", \\\"{x:1275,y:636,t:1527030650035};\\\", \\\"{x:1248,y:629,t:1527030650053};\\\", \\\"{x:1217,y:619,t:1527030650070};\\\", \\\"{x:1133,y:584,t:1527030650085};\\\", \\\"{x:1071,y:561,t:1527030650102};\\\", \\\"{x:1047,y:561,t:1527030650120};\\\", \\\"{x:1041,y:565,t:1527030650136};\\\", \\\"{x:1037,y:566,t:1527030650152};\\\", \\\"{x:1031,y:570,t:1527030650169};\\\", \\\"{x:1017,y:576,t:1527030650186};\\\", \\\"{x:1003,y:584,t:1527030650203};\\\", \\\"{x:987,y:590,t:1527030650220};\\\", \\\"{x:967,y:596,t:1527030650235};\\\", \\\"{x:959,y:597,t:1527030650253};\\\", \\\"{x:957,y:598,t:1527030650269};\\\", \\\"{x:961,y:604,t:1527030650285};\\\", \\\"{x:960,y:604,t:1527030650711};\\\", \\\"{x:934,y:603,t:1527030650721};\\\", \\\"{x:902,y:600,t:1527030650736};\\\", \\\"{x:870,y:600,t:1527030650751};\\\", \\\"{x:844,y:597,t:1527030650770};\\\", \\\"{x:820,y:597,t:1527030650785};\\\", \\\"{x:811,y:597,t:1527030650802};\\\", \\\"{x:806,y:598,t:1527030650819};\\\", \\\"{x:795,y:601,t:1527030650836};\\\", \\\"{x:782,y:602,t:1527030650852};\\\", \\\"{x:761,y:603,t:1527030650869};\\\", \\\"{x:747,y:603,t:1527030650885};\\\", \\\"{x:731,y:599,t:1527030650902};\\\", \\\"{x:709,y:594,t:1527030650919};\\\", \\\"{x:678,y:583,t:1527030650937};\\\", \\\"{x:650,y:577,t:1527030650953};\\\", \\\"{x:625,y:575,t:1527030650970};\\\", \\\"{x:606,y:571,t:1527030650986};\\\", \\\"{x:589,y:568,t:1527030651003};\\\", \\\"{x:580,y:566,t:1527030651019};\\\", \\\"{x:575,y:563,t:1527030651036};\\\", \\\"{x:576,y:563,t:1527030651174};\\\", \\\"{x:580,y:564,t:1527030651187};\\\", \\\"{x:589,y:568,t:1527030651203};\\\", \\\"{x:591,y:569,t:1527030651219};\\\", \\\"{x:594,y:571,t:1527030651236};\\\", \\\"{x:596,y:572,t:1527030651253};\\\", \\\"{x:599,y:574,t:1527030651270};\\\", \\\"{x:600,y:575,t:1527030651288};\\\", \\\"{x:602,y:576,t:1527030651327};\\\", \\\"{x:603,y:577,t:1527030651336};\\\", \\\"{x:605,y:579,t:1527030651354};\\\", \\\"{x:606,y:579,t:1527030651371};\\\", \\\"{x:606,y:580,t:1527030651582};\\\", \\\"{x:606,y:580,t:1527030651590};\\\", \\\"{x:605,y:583,t:1527030651603};\\\", \\\"{x:594,y:589,t:1527030651620};\\\", \\\"{x:585,y:601,t:1527030651637};\\\", \\\"{x:578,y:620,t:1527030651653};\\\", \\\"{x:576,y:627,t:1527030651670};\\\", \\\"{x:575,y:633,t:1527030651686};\\\", \\\"{x:574,y:636,t:1527030651703};\\\", \\\"{x:572,y:641,t:1527030651720};\\\", \\\"{x:567,y:652,t:1527030651736};\\\", \\\"{x:562,y:664,t:1527030651753};\\\", \\\"{x:557,y:677,t:1527030651770};\\\", \\\"{x:554,y:687,t:1527030651787};\\\", \\\"{x:552,y:691,t:1527030651803};\\\", \\\"{x:551,y:693,t:1527030651820};\\\", \\\"{x:550,y:695,t:1527030651836};\\\", \\\"{x:550,y:696,t:1527030651869};\\\", \\\"{x:549,y:697,t:1527030651886};\\\", \\\"{x:547,y:699,t:1527030651903};\\\", \\\"{x:547,y:702,t:1527030651919};\\\", \\\"{x:547,y:704,t:1527030651937};\\\", \\\"{x:547,y:705,t:1527030651966};\\\", \\\"{x:546,y:706,t:1527030651974};\\\", \\\"{x:545,y:707,t:1527030651987};\\\", \\\"{x:545,y:711,t:1527030652004};\\\", \\\"{x:545,y:716,t:1527030652020};\\\", \\\"{x:547,y:721,t:1527030652038};\\\", \\\"{x:548,y:722,t:1527030652053};\\\", \\\"{x:549,y:722,t:1527030652141};\\\", \\\"{x:550,y:722,t:1527030652173};\\\", \\\"{x:551,y:722,t:1527030653006};\\\", \\\"{x:557,y:721,t:1527030653022};\\\", \\\"{x:559,y:719,t:1527030653038};\\\", \\\"{x:561,y:719,t:1527030653085};\\\", \\\"{x:561,y:718,t:1527030653094};\\\", \\\"{x:565,y:717,t:1527030653105};\\\", \\\"{x:571,y:713,t:1527030653121};\\\", \\\"{x:575,y:710,t:1527030653138};\\\", \\\"{x:577,y:708,t:1527030653155};\\\", \\\"{x:578,y:707,t:1527030653174};\\\", \\\"{x:578,y:706,t:1527030653190};\\\", \\\"{x:579,y:705,t:1527030653204};\\\", \\\"{x:585,y:701,t:1527030653222};\\\", \\\"{x:587,y:699,t:1527030653238};\\\", \\\"{x:587,y:698,t:1527030653277};\\\", \\\"{x:587,y:696,t:1527030653293};\\\", \\\"{x:587,y:693,t:1527030653305};\\\", \\\"{x:587,y:690,t:1527030653321};\\\", \\\"{x:587,y:688,t:1527030653339};\\\" ] }, { \\\"rt\\\": 7961, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 606919, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:590,y:687,t:1527030654008};\\\", \\\"{x:590,y:686,t:1527030654029};\\\", \\\"{x:589,y:684,t:1527030654038};\\\", \\\"{x:587,y:683,t:1527030654055};\\\", \\\"{x:582,y:681,t:1527030654072};\\\", \\\"{x:576,y:677,t:1527030654088};\\\", \\\"{x:573,y:674,t:1527030654106};\\\", \\\"{x:567,y:668,t:1527030654122};\\\", \\\"{x:560,y:659,t:1527030654138};\\\", \\\"{x:543,y:637,t:1527030654156};\\\", \\\"{x:521,y:617,t:1527030654176};\\\", \\\"{x:499,y:595,t:1527030654192};\\\", \\\"{x:473,y:569,t:1527030654208};\\\", \\\"{x:462,y:561,t:1527030654225};\\\", \\\"{x:455,y:556,t:1527030654241};\\\", \\\"{x:452,y:553,t:1527030654258};\\\", \\\"{x:447,y:549,t:1527030654276};\\\", \\\"{x:438,y:537,t:1527030654291};\\\", \\\"{x:427,y:522,t:1527030654309};\\\", \\\"{x:414,y:505,t:1527030654325};\\\", \\\"{x:397,y:485,t:1527030654343};\\\", \\\"{x:382,y:471,t:1527030654358};\\\", \\\"{x:372,y:461,t:1527030654375};\\\", \\\"{x:368,y:457,t:1527030654392};\\\", \\\"{x:364,y:452,t:1527030654408};\\\", \\\"{x:357,y:441,t:1527030654426};\\\", \\\"{x:348,y:430,t:1527030654443};\\\", \\\"{x:337,y:414,t:1527030654459};\\\", \\\"{x:330,y:406,t:1527030654476};\\\", \\\"{x:327,y:404,t:1527030654492};\\\", \\\"{x:325,y:402,t:1527030654509};\\\", \\\"{x:326,y:401,t:1527030654826};\\\", \\\"{x:330,y:399,t:1527030654843};\\\", \\\"{x:334,y:398,t:1527030654860};\\\", \\\"{x:341,y:397,t:1527030654876};\\\", \\\"{x:348,y:397,t:1527030654893};\\\", \\\"{x:358,y:397,t:1527030654910};\\\", \\\"{x:370,y:397,t:1527030654925};\\\", \\\"{x:389,y:397,t:1527030654942};\\\", \\\"{x:410,y:400,t:1527030654960};\\\", \\\"{x:423,y:401,t:1527030654975};\\\", \\\"{x:433,y:401,t:1527030654993};\\\", \\\"{x:437,y:403,t:1527030655010};\\\", \\\"{x:439,y:404,t:1527030655027};\\\", \\\"{x:441,y:404,t:1527030655043};\\\", \\\"{x:444,y:405,t:1527030655060};\\\", \\\"{x:446,y:405,t:1527030655114};\\\", \\\"{x:446,y:406,t:1527030655218};\\\", \\\"{x:447,y:406,t:1527030655257};\\\", \\\"{x:447,y:407,t:1527030655273};\\\", \\\"{x:448,y:407,t:1527030655290};\\\", \\\"{x:449,y:408,t:1527030655313};\\\", \\\"{x:450,y:408,t:1527030655338};\\\", \\\"{x:450,y:409,t:1527030655345};\\\", \\\"{x:451,y:409,t:1527030655360};\\\", \\\"{x:458,y:416,t:1527030655378};\\\", \\\"{x:462,y:422,t:1527030655393};\\\", \\\"{x:465,y:427,t:1527030655411};\\\", \\\"{x:466,y:430,t:1527030655427};\\\", \\\"{x:468,y:433,t:1527030655444};\\\", \\\"{x:468,y:434,t:1527030655465};\\\", \\\"{x:468,y:435,t:1527030655481};\\\", \\\"{x:468,y:437,t:1527030655497};\\\", \\\"{x:468,y:438,t:1527030655513};\\\", \\\"{x:468,y:439,t:1527030655527};\\\", \\\"{x:468,y:440,t:1527030655545};\\\", \\\"{x:468,y:442,t:1527030655560};\\\", \\\"{x:468,y:443,t:1527030655577};\\\", \\\"{x:467,y:444,t:1527030655594};\\\", \\\"{x:467,y:445,t:1527030655617};\\\", \\\"{x:466,y:446,t:1527030655634};\\\", \\\"{x:466,y:447,t:1527030655645};\\\", \\\"{x:465,y:447,t:1527030655665};\\\", \\\"{x:465,y:448,t:1527030655697};\\\", \\\"{x:464,y:449,t:1527030655713};\\\", \\\"{x:463,y:450,t:1527030655730};\\\", \\\"{x:462,y:452,t:1527030655745};\\\", \\\"{x:461,y:452,t:1527030655762};\\\", \\\"{x:460,y:453,t:1527030655777};\\\", \\\"{x:459,y:454,t:1527030655794};\\\", \\\"{x:459,y:455,t:1527030655898};\\\", \\\"{x:459,y:457,t:1527030655911};\\\", \\\"{x:459,y:458,t:1527030655927};\\\", \\\"{x:460,y:462,t:1527030655944};\\\", \\\"{x:466,y:467,t:1527030655961};\\\", \\\"{x:472,y:470,t:1527030655978};\\\", \\\"{x:480,y:474,t:1527030655994};\\\", \\\"{x:490,y:480,t:1527030656011};\\\", \\\"{x:515,y:493,t:1527030656027};\\\", \\\"{x:563,y:515,t:1527030656045};\\\", \\\"{x:625,y:547,t:1527030656061};\\\", \\\"{x:690,y:584,t:1527030656078};\\\", \\\"{x:835,y:668,t:1527030656111};\\\", \\\"{x:903,y:705,t:1527030656126};\\\", \\\"{x:974,y:732,t:1527030656143};\\\", \\\"{x:1072,y:764,t:1527030656161};\\\", \\\"{x:1125,y:778,t:1527030656177};\\\", \\\"{x:1178,y:794,t:1527030656194};\\\", \\\"{x:1226,y:810,t:1527030656211};\\\", \\\"{x:1253,y:818,t:1527030656226};\\\", \\\"{x:1263,y:823,t:1527030656244};\\\", \\\"{x:1265,y:824,t:1527030656260};\\\", \\\"{x:1266,y:825,t:1527030656277};\\\", \\\"{x:1268,y:826,t:1527030656330};\\\", \\\"{x:1268,y:827,t:1527030656344};\\\", \\\"{x:1270,y:832,t:1527030656361};\\\", \\\"{x:1273,y:839,t:1527030656377};\\\", \\\"{x:1281,y:851,t:1527030656394};\\\", \\\"{x:1298,y:868,t:1527030656411};\\\", \\\"{x:1315,y:881,t:1527030656427};\\\", \\\"{x:1322,y:887,t:1527030656444};\\\", \\\"{x:1326,y:889,t:1527030656461};\\\", \\\"{x:1327,y:890,t:1527030656478};\\\", \\\"{x:1328,y:891,t:1527030656495};\\\", \\\"{x:1329,y:891,t:1527030656514};\\\", \\\"{x:1333,y:893,t:1527030656528};\\\", \\\"{x:1353,y:902,t:1527030656545};\\\", \\\"{x:1397,y:920,t:1527030656561};\\\", \\\"{x:1413,y:927,t:1527030656578};\\\", \\\"{x:1419,y:929,t:1527030656594};\\\", \\\"{x:1420,y:929,t:1527030656611};\\\", \\\"{x:1421,y:929,t:1527030656770};\\\", \\\"{x:1422,y:930,t:1527030656778};\\\", \\\"{x:1435,y:934,t:1527030656794};\\\", \\\"{x:1453,y:939,t:1527030656811};\\\", \\\"{x:1473,y:946,t:1527030656828};\\\", \\\"{x:1490,y:950,t:1527030656844};\\\", \\\"{x:1503,y:951,t:1527030656861};\\\", \\\"{x:1506,y:952,t:1527030656878};\\\", \\\"{x:1507,y:952,t:1527030656894};\\\", \\\"{x:1508,y:952,t:1527030656911};\\\", \\\"{x:1509,y:953,t:1527030656928};\\\", \\\"{x:1530,y:953,t:1527030656944};\\\", \\\"{x:1553,y:956,t:1527030656961};\\\", \\\"{x:1574,y:960,t:1527030656979};\\\", \\\"{x:1582,y:960,t:1527030656995};\\\", \\\"{x:1583,y:960,t:1527030657011};\\\", \\\"{x:1581,y:960,t:1527030657122};\\\", \\\"{x:1577,y:960,t:1527030657130};\\\", \\\"{x:1567,y:958,t:1527030657145};\\\", \\\"{x:1552,y:957,t:1527030657161};\\\", \\\"{x:1536,y:955,t:1527030657178};\\\", \\\"{x:1524,y:955,t:1527030657195};\\\", \\\"{x:1511,y:954,t:1527030657212};\\\", \\\"{x:1497,y:953,t:1527030657229};\\\", \\\"{x:1484,y:950,t:1527030657245};\\\", \\\"{x:1475,y:950,t:1527030657262};\\\", \\\"{x:1469,y:950,t:1527030657279};\\\", \\\"{x:1465,y:950,t:1527030657295};\\\", \\\"{x:1461,y:950,t:1527030657311};\\\", \\\"{x:1459,y:950,t:1527030657328};\\\", \\\"{x:1456,y:950,t:1527030657345};\\\", \\\"{x:1455,y:950,t:1527030657386};\\\", \\\"{x:1458,y:949,t:1527030657481};\\\", \\\"{x:1460,y:947,t:1527030657495};\\\", \\\"{x:1467,y:942,t:1527030657512};\\\", \\\"{x:1474,y:934,t:1527030657528};\\\", \\\"{x:1480,y:922,t:1527030657545};\\\", \\\"{x:1481,y:916,t:1527030657562};\\\", \\\"{x:1481,y:912,t:1527030657578};\\\", \\\"{x:1481,y:908,t:1527030657595};\\\", \\\"{x:1482,y:903,t:1527030657612};\\\", \\\"{x:1484,y:897,t:1527030657628};\\\", \\\"{x:1484,y:890,t:1527030657645};\\\", \\\"{x:1484,y:885,t:1527030657662};\\\", \\\"{x:1484,y:881,t:1527030657677};\\\", \\\"{x:1484,y:878,t:1527030657696};\\\", \\\"{x:1484,y:876,t:1527030657713};\\\", \\\"{x:1483,y:875,t:1527030657728};\\\", \\\"{x:1483,y:872,t:1527030657745};\\\", \\\"{x:1483,y:868,t:1527030657762};\\\", \\\"{x:1483,y:864,t:1527030657778};\\\", \\\"{x:1483,y:862,t:1527030657795};\\\", \\\"{x:1483,y:861,t:1527030657812};\\\", \\\"{x:1483,y:858,t:1527030657828};\\\", \\\"{x:1481,y:857,t:1527030657845};\\\", \\\"{x:1481,y:855,t:1527030657862};\\\", \\\"{x:1481,y:853,t:1527030657880};\\\", \\\"{x:1481,y:852,t:1527030657895};\\\", \\\"{x:1481,y:849,t:1527030657912};\\\", \\\"{x:1480,y:846,t:1527030657929};\\\", \\\"{x:1480,y:845,t:1527030657953};\\\", \\\"{x:1479,y:843,t:1527030657977};\\\", \\\"{x:1478,y:842,t:1527030657985};\\\", \\\"{x:1478,y:841,t:1527030658009};\\\", \\\"{x:1478,y:840,t:1527030658017};\\\", \\\"{x:1478,y:839,t:1527030658030};\\\", \\\"{x:1477,y:838,t:1527030658045};\\\", \\\"{x:1477,y:837,t:1527030658170};\\\", \\\"{x:1477,y:836,t:1527030658186};\\\", \\\"{x:1476,y:836,t:1527030658195};\\\", \\\"{x:1476,y:835,t:1527030658218};\\\", \\\"{x:1476,y:834,t:1527030658314};\\\", \\\"{x:1475,y:833,t:1527030658338};\\\", \\\"{x:1474,y:829,t:1527030658346};\\\", \\\"{x:1470,y:824,t:1527030658362};\\\", \\\"{x:1463,y:815,t:1527030658380};\\\", \\\"{x:1447,y:799,t:1527030658396};\\\", \\\"{x:1413,y:761,t:1527030658412};\\\", \\\"{x:1360,y:712,t:1527030658430};\\\", \\\"{x:1281,y:653,t:1527030658446};\\\", \\\"{x:1187,y:587,t:1527030658463};\\\", \\\"{x:1079,y:518,t:1527030658479};\\\", \\\"{x:970,y:459,t:1527030658496};\\\", \\\"{x:854,y:406,t:1527030658512};\\\", \\\"{x:695,y:355,t:1527030658529};\\\", \\\"{x:584,y:335,t:1527030658546};\\\", \\\"{x:481,y:321,t:1527030658562};\\\", \\\"{x:395,y:308,t:1527030658579};\\\", \\\"{x:342,y:308,t:1527030658596};\\\", \\\"{x:310,y:308,t:1527030658612};\\\", \\\"{x:294,y:313,t:1527030658630};\\\", \\\"{x:286,y:316,t:1527030658646};\\\", \\\"{x:281,y:319,t:1527030658662};\\\", \\\"{x:275,y:324,t:1527030658679};\\\", \\\"{x:262,y:338,t:1527030658696};\\\", \\\"{x:244,y:352,t:1527030658712};\\\", \\\"{x:212,y:362,t:1527030658729};\\\", \\\"{x:201,y:365,t:1527030658747};\\\", \\\"{x:200,y:366,t:1527030658763};\\\", \\\"{x:200,y:368,t:1527030658779};\\\", \\\"{x:201,y:371,t:1527030658796};\\\", \\\"{x:206,y:377,t:1527030658813};\\\", \\\"{x:218,y:386,t:1527030658829};\\\", \\\"{x:234,y:395,t:1527030658846};\\\", \\\"{x:256,y:405,t:1527030658863};\\\", \\\"{x:295,y:421,t:1527030658880};\\\", \\\"{x:347,y:444,t:1527030658896};\\\", \\\"{x:451,y:489,t:1527030658914};\\\", \\\"{x:520,y:518,t:1527030658931};\\\", \\\"{x:560,y:541,t:1527030658947};\\\", \\\"{x:566,y:546,t:1527030658957};\\\", \\\"{x:575,y:552,t:1527030658974};\\\", \\\"{x:575,y:553,t:1527030659032};\\\", \\\"{x:575,y:556,t:1527030659040};\\\", \\\"{x:575,y:564,t:1527030659057};\\\", \\\"{x:576,y:569,t:1527030659073};\\\", \\\"{x:577,y:571,t:1527030659227};\\\", \\\"{x:578,y:572,t:1527030659240};\\\", \\\"{x:580,y:575,t:1527030659263};\\\", \\\"{x:582,y:575,t:1527030659280};\\\", \\\"{x:584,y:575,t:1527030659296};\\\", \\\"{x:587,y:578,t:1527030659313};\\\", \\\"{x:593,y:580,t:1527030659330};\\\", \\\"{x:602,y:584,t:1527030659346};\\\", \\\"{x:609,y:587,t:1527030659362};\\\", \\\"{x:616,y:588,t:1527030659380};\\\", \\\"{x:622,y:588,t:1527030659396};\\\", \\\"{x:624,y:588,t:1527030659413};\\\", \\\"{x:625,y:588,t:1527030659430};\\\", \\\"{x:627,y:588,t:1527030659446};\\\", \\\"{x:628,y:588,t:1527030659464};\\\", \\\"{x:627,y:588,t:1527030659665};\\\", \\\"{x:625,y:588,t:1527030659680};\\\", \\\"{x:621,y:589,t:1527030659697};\\\", \\\"{x:620,y:589,t:1527030659721};\\\", \\\"{x:619,y:589,t:1527030659737};\\\", \\\"{x:618,y:589,t:1527030659850};\\\", \\\"{x:617,y:589,t:1527030659865};\\\", \\\"{x:616,y:589,t:1527030659897};\\\", \\\"{x:615,y:590,t:1527030659945};\\\", \\\"{x:613,y:590,t:1527030659969};\\\", \\\"{x:612,y:590,t:1527030659981};\\\", \\\"{x:609,y:590,t:1527030659985};\\\", \\\"{x:608,y:590,t:1527030659998};\\\", \\\"{x:605,y:590,t:1527030660012};\\\", \\\"{x:592,y:591,t:1527030660030};\\\", \\\"{x:570,y:591,t:1527030660047};\\\", \\\"{x:527,y:591,t:1527030660064};\\\", \\\"{x:436,y:585,t:1527030660081};\\\", \\\"{x:318,y:567,t:1527030660097};\\\", \\\"{x:270,y:559,t:1527030660113};\\\", \\\"{x:250,y:557,t:1527030660130};\\\", \\\"{x:249,y:556,t:1527030660147};\\\", \\\"{x:251,y:556,t:1527030660282};\\\", \\\"{x:255,y:557,t:1527030660297};\\\", \\\"{x:258,y:558,t:1527030660314};\\\", \\\"{x:263,y:561,t:1527030660331};\\\", \\\"{x:270,y:565,t:1527030660347};\\\", \\\"{x:280,y:570,t:1527030660365};\\\", \\\"{x:291,y:574,t:1527030660381};\\\", \\\"{x:303,y:578,t:1527030660398};\\\", \\\"{x:311,y:580,t:1527030660414};\\\", \\\"{x:313,y:580,t:1527030660430};\\\", \\\"{x:317,y:580,t:1527030660447};\\\", \\\"{x:321,y:583,t:1527030660464};\\\", \\\"{x:325,y:585,t:1527030660481};\\\", \\\"{x:326,y:585,t:1527030660497};\\\", \\\"{x:327,y:585,t:1527030660537};\\\", \\\"{x:330,y:585,t:1527030660547};\\\", \\\"{x:347,y:588,t:1527030660564};\\\", \\\"{x:366,y:589,t:1527030660581};\\\", \\\"{x:379,y:589,t:1527030660598};\\\", \\\"{x:377,y:589,t:1527030660896};\\\", \\\"{x:377,y:589,t:1527030660901};\\\", \\\"{x:377,y:590,t:1527030660937};\\\", \\\"{x:378,y:590,t:1527030660948};\\\", \\\"{x:380,y:593,t:1527030660963};\\\", \\\"{x:383,y:595,t:1527030660981};\\\", \\\"{x:386,y:600,t:1527030660998};\\\", \\\"{x:392,y:608,t:1527030661014};\\\", \\\"{x:409,y:626,t:1527030661031};\\\", \\\"{x:446,y:660,t:1527030661049};\\\", \\\"{x:484,y:692,t:1527030661065};\\\", \\\"{x:535,y:728,t:1527030661081};\\\", \\\"{x:556,y:739,t:1527030661098};\\\", \\\"{x:560,y:741,t:1527030661115};\\\", \\\"{x:561,y:742,t:1527030661193};\\\", \\\"{x:560,y:742,t:1527030661266};\\\", \\\"{x:558,y:742,t:1527030661283};\\\", \\\"{x:556,y:742,t:1527030661298};\\\", \\\"{x:553,y:742,t:1527030661315};\\\", \\\"{x:550,y:742,t:1527030661332};\\\", \\\"{x:547,y:742,t:1527030661350};\\\", \\\"{x:546,y:742,t:1527030661432};\\\", \\\"{x:545,y:742,t:1527030661448};\\\", \\\"{x:541,y:743,t:1527030661465};\\\", \\\"{x:538,y:745,t:1527030661481};\\\", \\\"{x:537,y:746,t:1527030661505};\\\", \\\"{x:537,y:746,t:1527030661559};\\\", \\\"{x:536,y:746,t:1527030661565};\\\", \\\"{x:535,y:746,t:1527030661696};\\\", \\\"{x:535,y:747,t:1527030661729};\\\", \\\"{x:534,y:747,t:1527030661745};\\\", \\\"{x:532,y:748,t:1527030661802};\\\", \\\"{x:530,y:748,t:1527030661866};\\\", \\\"{x:521,y:744,t:1527030661882};\\\", \\\"{x:512,y:737,t:1527030661898};\\\", \\\"{x:503,y:733,t:1527030661915};\\\", \\\"{x:496,y:727,t:1527030661933};\\\", \\\"{x:490,y:722,t:1527030661948};\\\", \\\"{x:481,y:712,t:1527030661965};\\\", \\\"{x:471,y:701,t:1527030661983};\\\", \\\"{x:458,y:688,t:1527030661998};\\\", \\\"{x:444,y:675,t:1527030662015};\\\", \\\"{x:429,y:665,t:1527030662033};\\\", \\\"{x:413,y:654,t:1527030662048};\\\", \\\"{x:404,y:647,t:1527030662065};\\\", \\\"{x:398,y:643,t:1527030662082};\\\", \\\"{x:397,y:642,t:1527030662098};\\\", \\\"{x:395,y:642,t:1527030662115};\\\", \\\"{x:394,y:642,t:1527030662132};\\\", \\\"{x:393,y:641,t:1527030662153};\\\", \\\"{x:393,y:640,t:1527030662297};\\\", \\\"{x:393,y:639,t:1527030662337};\\\", \\\"{x:393,y:637,t:1527030662349};\\\", \\\"{x:391,y:625,t:1527030662366};\\\", \\\"{x:390,y:618,t:1527030662382};\\\", \\\"{x:390,y:612,t:1527030662399};\\\", \\\"{x:390,y:609,t:1527030662415};\\\", \\\"{x:390,y:607,t:1527030662432};\\\", \\\"{x:394,y:599,t:1527030662448};\\\", \\\"{x:397,y:593,t:1527030662465};\\\", \\\"{x:398,y:591,t:1527030662482};\\\", \\\"{x:400,y:589,t:1527030662521};\\\", \\\"{x:402,y:587,t:1527030662532};\\\", \\\"{x:405,y:584,t:1527030662549};\\\", \\\"{x:408,y:576,t:1527030662570};\\\", \\\"{x:408,y:573,t:1527030662582};\\\", \\\"{x:409,y:566,t:1527030662598};\\\", \\\"{x:411,y:563,t:1527030662616};\\\", \\\"{x:411,y:561,t:1527030662632};\\\" ] }, { \\\"rt\\\": 26349, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 634498, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Follow the diagonal line going from 12pm to the upper right\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6008, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 641511, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12497, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 655031, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 32663, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 688781, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"0QG7J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"0QG7J\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 102, dom: 596, initialDom: 721",
  "javascriptErrors": []
}