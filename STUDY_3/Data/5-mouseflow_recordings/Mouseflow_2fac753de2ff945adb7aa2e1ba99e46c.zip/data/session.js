var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2fac753de2ff945adb7aa2e1ba99e46c",
  "created": "2018-05-18T11:14:37.5860018-07:00",
  "lastActivity": "2018-05-18T11:15:09.6710332-07:00",
  "pageViews": [
    {
      "id": "051837904d38341110ecfca8cd5b4a0850c4a461",
      "startTime": "2018-05-18T11:14:37.5980332-07:00",
      "endTime": "2018-05-18T11:15:09.6710332-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 32073,
      "engagementTime": 32041,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32073,
  "engagementTime": 32041,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=E3YN6",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "38581305f6336c4d8495d458e2c741ca",
  "gdpr": false
}