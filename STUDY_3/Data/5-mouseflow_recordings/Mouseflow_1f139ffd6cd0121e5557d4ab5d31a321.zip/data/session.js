var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1f139ffd6cd0121e5557d4ab5d31a321",
  "created": "2018-05-22T16:13:36.6813038-07:00",
  "lastActivity": "2018-05-22T16:13:51.5135163-07:00",
  "pageViews": [
    {
      "id": "05223606f68043e3e9924d483beac7838be79693",
      "startTime": "2018-05-22T16:13:36.8531537-07:00",
      "endTime": "2018-05-22T16:13:51.5135163-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 14798,
      "engagementTime": 14798,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14798,
  "engagementTime": 14798,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OU2PE",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ec4b55c6c59ada6d8fe1abb5694f51da",
  "gdpr": false
}