var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "495769de208da384f6cdb83bbb08453b",
  "created": "2018-05-15T14:04:50.87156-07:00",
  "lastActivity": "2018-05-15T14:05:08.57856-07:00",
  "pageViews": [
    {
      "id": "051551606f578a8c67458e53b9af5e25084fd8c6",
      "startTime": "2018-05-15T14:04:50.87156-07:00",
      "endTime": "2018-05-15T14:05:08.57856-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 17707,
      "engagementTime": 17688,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17707,
  "engagementTime": 17688,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B4LD9",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "49c73f0a00bb308725b4ee1e4f04fc8b",
  "gdpr": false
}