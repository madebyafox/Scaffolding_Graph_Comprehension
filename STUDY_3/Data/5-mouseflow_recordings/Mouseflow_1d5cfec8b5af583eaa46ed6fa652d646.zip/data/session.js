var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1d5cfec8b5af583eaa46ed6fa652d646",
  "created": "2018-05-29T10:06:55.2287576-07:00",
  "lastActivity": "2018-05-29T10:07:16.783366-07:00",
  "pageViews": [
    {
      "id": "05295531453dd9d024b3acb7b5014ba43457307a",
      "startTime": "2018-05-29T10:06:55.283366-07:00",
      "endTime": "2018-05-29T10:07:16.783366-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 21500,
      "engagementTime": 21349,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21500,
  "engagementTime": 21349,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=53WYU",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "00214aa5eda0ad36a23f7a660b5f6030",
  "gdpr": false
}