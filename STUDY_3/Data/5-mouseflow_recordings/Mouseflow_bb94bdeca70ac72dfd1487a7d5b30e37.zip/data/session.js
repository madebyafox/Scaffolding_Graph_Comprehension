var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bb94bdeca70ac72dfd1487a7d5b30e37",
  "created": "2018-05-25T11:04:23.6696721-07:00",
  "lastActivity": "2018-05-25T11:09:46.4126966-07:00",
  "pageViews": [
    {
      "id": "05252389a2ccba1bc011268d00d44269ce141a33",
      "startTime": "2018-05-25T11:04:23.6696721-07:00",
      "endTime": "2018-05-25T11:09:46.4126966-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 323004,
      "engagementTime": 87402,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 323004,
  "engagementTime": 87402,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.44",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6450eba94ae0b945fbe5915048d94fd8",
  "gdpr": false
}