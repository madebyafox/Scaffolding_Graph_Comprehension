var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "584d71fbf9fdf8b5b18726e7d9412790",
  "created": "2018-05-15T17:05:30.4613388-07:00",
  "lastActivity": "2018-05-15T17:06:13.3436307-07:00",
  "pageViews": [
    {
      "id": "05153036dae5d773ec7fa2196ab888a868b8f839",
      "startTime": "2018-05-15T17:05:30.7707432-07:00",
      "endTime": "2018-05-15T17:06:13.3436307-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 42837,
      "engagementTime": 39642,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 42837,
  "engagementTime": 39642,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TVQKD",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0032a4f28de0aaee72c35772bebd51a5",
  "gdpr": false
}