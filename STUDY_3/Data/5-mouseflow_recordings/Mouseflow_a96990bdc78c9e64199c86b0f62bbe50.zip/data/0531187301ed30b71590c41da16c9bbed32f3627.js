var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0531187301ed30b71590c41da16c9bbed32f3627"] = {
  "startTime": "2018-05-31T19:13:19.0185977Z",
  "websitePageUrl": "/16",
  "visitTime": 145068,
  "engagementTime": 112659,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a96990bdc78c9e64199c86b0f62bbe50",
    "created": "2018-05-31T19:13:19.0185977+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=LW2XG",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f3701295832c39cb5d48728d7f849957",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a96990bdc78c9e64199c86b0f62bbe50/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 182,
      "e": 182,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 182,
      "e": 182,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 584,
      "y": 704
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 54620,
      "y": 38396,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2792,
      "e": 2792,
      "ty": 6,
      "x": 574,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 574,
      "y": 545
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 562,
      "y": 502
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 52260,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3090,
      "e": 3090,
      "ty": 3,
      "x": 562,
      "y": 502,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3090,
      "e": 3090,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3192,
      "e": 3192,
      "ty": 4,
      "x": 52260,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3192,
      "e": 3192,
      "ty": 5,
      "x": 562,
      "y": 502,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3342,
      "e": 3342,
      "ty": 7,
      "x": 542,
      "y": 579,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3402,
      "e": 3402,
      "ty": 2,
      "x": 489,
      "y": 696
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 2,
      "x": 390,
      "y": 818
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 32925,
      "y": 49288,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3602,
      "e": 3602,
      "ty": 2,
      "x": 325,
      "y": 834
    },
    {
      "t": 3702,
      "e": 3702,
      "ty": 2,
      "x": 322,
      "y": 834
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 25281,
      "y": 50261,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10001,
      "e": 8752,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 19748,
      "e": 8752,
      "ty": 41,
      "x": 25618,
      "y": 50261,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 19798,
      "e": 8802,
      "ty": 2,
      "x": 325,
      "y": 834
    },
    {
      "t": 19898,
      "e": 8902,
      "ty": 2,
      "x": 336,
      "y": 833
    },
    {
      "t": 19999,
      "e": 9003,
      "ty": 41,
      "x": 26855,
      "y": 50200,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 20749,
      "e": 9753,
      "ty": 41,
      "x": 26855,
      "y": 50140,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 20799,
      "e": 9803,
      "ty": 2,
      "x": 336,
      "y": 832
    },
    {
      "t": 22099,
      "e": 11103,
      "ty": 2,
      "x": 343,
      "y": 832
    },
    {
      "t": 22249,
      "e": 11253,
      "ty": 41,
      "x": 27642,
      "y": 50140,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 22899,
      "e": 11903,
      "ty": 2,
      "x": 344,
      "y": 833
    },
    {
      "t": 22999,
      "e": 12003,
      "ty": 41,
      "x": 27754,
      "y": 50200,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 24499,
      "e": 13503,
      "ty": 2,
      "x": 374,
      "y": 817
    },
    {
      "t": 24500,
      "e": 13504,
      "ty": 41,
      "x": 31127,
      "y": 49227,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 24599,
      "e": 13603,
      "ty": 2,
      "x": 385,
      "y": 812
    },
    {
      "t": 24749,
      "e": 13753,
      "ty": 41,
      "x": 32363,
      "y": 48923,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 29998,
      "e": 18753,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40999,
      "e": 18753,
      "ty": 2,
      "x": 388,
      "y": 810
    },
    {
      "t": 41000,
      "e": 18754,
      "ty": 41,
      "x": 32700,
      "y": 48801,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 41012,
      "e": 18766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41012,
      "e": 18766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41081,
      "e": 18835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 41097,
      "e": 18851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41098,
      "e": 18852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41154,
      "e": 18908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to"
    },
    {
      "t": 41162,
      "e": 18916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41162,
      "e": 18916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41273,
      "e": 19027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to "
    },
    {
      "t": 41298,
      "e": 19052,
      "ty": 2,
      "x": 389,
      "y": 809
    },
    {
      "t": 41329,
      "e": 19083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41329,
      "e": 19083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41398,
      "e": 19152,
      "ty": 2,
      "x": 389,
      "y": 808
    },
    {
      "t": 41417,
      "e": 19171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to s"
    },
    {
      "t": 41481,
      "e": 19235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41482,
      "e": 19236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41499,
      "e": 19253,
      "ty": 41,
      "x": 32813,
      "y": 48679,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 41522,
      "e": 19276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41602,
      "e": 19356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41603,
      "e": 19357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41713,
      "e": 19467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41713,
      "e": 19467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41715,
      "e": 19469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41810,
      "e": 19564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42506,
      "e": 20260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 42507,
      "e": 20261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42570,
      "e": 20324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42571,
      "e": 20325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42578,
      "e": 20332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 42641,
      "e": 20395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42641,
      "e": 20395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42665,
      "e": 20419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 42729,
      "e": 20483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42730,
      "e": 20484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42749,
      "e": 20503,
      "ty": 41,
      "x": 32813,
      "y": 48618,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 42778,
      "e": 20532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42798,
      "e": 20552,
      "ty": 2,
      "x": 399,
      "y": 802
    },
    {
      "t": 42810,
      "e": 20564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42810,
      "e": 20564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42825,
      "e": 20579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42897,
      "e": 20651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42899,
      "e": 20653,
      "ty": 2,
      "x": 401,
      "y": 800
    },
    {
      "t": 42999,
      "e": 20753,
      "ty": 41,
      "x": 34162,
      "y": 48192,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43001,
      "e": 20755,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see what "
    },
    {
      "t": 43749,
      "e": 21503,
      "ty": 41,
      "x": 35061,
      "y": 47949,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43799,
      "e": 21553,
      "ty": 2,
      "x": 457,
      "y": 773
    },
    {
      "t": 43899,
      "e": 21653,
      "ty": 2,
      "x": 495,
      "y": 754
    },
    {
      "t": 43999,
      "e": 21753,
      "ty": 41,
      "x": 44728,
      "y": 45393,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 44099,
      "e": 21853,
      "ty": 2,
      "x": 501,
      "y": 751
    },
    {
      "t": 44199,
      "e": 21953,
      "ty": 2,
      "x": 564,
      "y": 722
    },
    {
      "t": 44249,
      "e": 22003,
      "ty": 41,
      "x": 59903,
      "y": 41621,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 44299,
      "e": 22053,
      "ty": 2,
      "x": 683,
      "y": 668
    },
    {
      "t": 44398,
      "e": 22152,
      "ty": 2,
      "x": 756,
      "y": 630
    },
    {
      "t": 44499,
      "e": 22253,
      "ty": 2,
      "x": 811,
      "y": 600
    },
    {
      "t": 44500,
      "e": 22254,
      "ty": 41,
      "x": 3327,
      "y": 50511,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 44599,
      "e": 22353,
      "ty": 2,
      "x": 1048,
      "y": 196
    },
    {
      "t": 44699,
      "e": 22453,
      "ty": 2,
      "x": 1076,
      "y": 103
    },
    {
      "t": 44749,
      "e": 22503,
      "ty": 41,
      "x": 20436,
      "y": 1289,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 45378,
      "e": 23132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45762,
      "e": 23516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see what"
    },
    {
      "t": 45866,
      "e": 23620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45930,
      "e": 23684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see wha"
    },
    {
      "t": 46034,
      "e": 23788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46073,
      "e": 23827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see wh"
    },
    {
      "t": 46169,
      "e": 23923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46234,
      "e": 23988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see w"
    },
    {
      "t": 46602,
      "e": 24356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46602,
      "e": 24356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46770,
      "e": 24524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 46810,
      "e": 24564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46810,
      "e": 24564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46890,
      "e": 24644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46906,
      "e": 24660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 46906,
      "e": 24660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47001,
      "e": 24755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47002,
      "e": 24756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47017,
      "e": 24771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 47065,
      "e": 24819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47066,
      "e": 24820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47082,
      "e": 24836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47162,
      "e": 24916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47354,
      "e": 25108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 47355,
      "e": 25109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47434,
      "e": 25188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 47481,
      "e": 25235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47481,
      "e": 25235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47538,
      "e": 25292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 47609,
      "e": 25363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47610,
      "e": 25364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47674,
      "e": 25428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47754,
      "e": 25508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47754,
      "e": 25508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47826,
      "e": 25580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47898,
      "e": 25652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47899,
      "e": 25653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47977,
      "e": 25731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47978,
      "e": 25732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48025,
      "e": 25779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 48074,
      "e": 25828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48210,
      "e": 25964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48211,
      "e": 25965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48281,
      "e": 26035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 48400,
      "e": 26154,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letters"
    },
    {
      "t": 48458,
      "e": 26212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48458,
      "e": 26212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48554,
      "e": 26308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48898,
      "e": 26652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48953,
      "e": 26707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letters"
    },
    {
      "t": 49049,
      "e": 26803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49113,
      "e": 26867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter"
    },
    {
      "t": 49771,
      "e": 26868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49922,
      "e": 27019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 49922,
      "e": 27019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49977,
      "e": 27074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 49993,
      "e": 27090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50073,
      "e": 27170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50073,
      "e": 27170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50170,
      "e": 27267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 50402,
      "e": 27499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50498,
      "e": 27595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 50498,
      "e": 27595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50586,
      "e": 27683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 50594,
      "e": 27691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50746,
      "e": 27843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50746,
      "e": 27843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50841,
      "e": 27938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53522,
      "e": 30619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53522,
      "e": 30619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53601,
      "e": 30698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53602,
      "e": 30699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53658,
      "e": 30755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 53659,
      "e": 30756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53659,
      "e": 30756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53705,
      "e": 30802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53745,
      "e": 30842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54058,
      "e": 31155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 54058,
      "e": 31155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54113,
      "e": 31210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54113,
      "e": 31210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54154,
      "e": 31251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 54218,
      "e": 31315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54225,
      "e": 31322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54226,
      "e": 31323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54314,
      "e": 31411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54370,
      "e": 31467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54370,
      "e": 31467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54402,
      "e": 31499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54402,
      "e": 31499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54433,
      "e": 31530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 54482,
      "e": 31579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54522,
      "e": 31619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54522,
      "e": 31619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54570,
      "e": 31667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54570,
      "e": 31667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54601,
      "e": 31698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 54698,
      "e": 31795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55194,
      "e": 32291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55694,
      "e": 32791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55726,
      "e": 32823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55737,
      "e": 32834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) in on t"
    },
    {
      "t": 55882,
      "e": 32979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55946,
      "e": 33043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) in on "
    },
    {
      "t": 56050,
      "e": 33147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56105,
      "e": 33202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) in on"
    },
    {
      "t": 56202,
      "e": 33299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56249,
      "e": 33346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) in o"
    },
    {
      "t": 56353,
      "e": 33450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56417,
      "e": 33514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) in "
    },
    {
      "t": 57138,
      "e": 34235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57185,
      "e": 34282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) in"
    },
    {
      "t": 57289,
      "e": 34386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57345,
      "e": 34442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) i"
    },
    {
      "t": 57442,
      "e": 34539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57505,
      "e": 34602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) "
    },
    {
      "t": 57738,
      "e": 34835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 57739,
      "e": 34836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57769,
      "e": 34866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 57770,
      "e": 34867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57809,
      "e": 34906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ob"
    },
    {
      "t": 57849,
      "e": 34946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58202,
      "e": 35299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 58204,
      "e": 35301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58241,
      "e": 35338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 58401,
      "e": 35498,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) ob="
    },
    {
      "t": 58570,
      "e": 35667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58625,
      "e": 35722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) ob"
    },
    {
      "t": 58714,
      "e": 35811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58777,
      "e": 35874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) o"
    },
    {
      "t": 59281,
      "e": 36378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59283,
      "e": 36380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59345,
      "e": 36442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59345,
      "e": 36442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59353,
      "e": 36450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 59449,
      "e": 36546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59449,
      "e": 36546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59457,
      "e": 36554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59481,
      "e": 36578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 59481,
      "e": 36578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59521,
      "e": 36618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 59545,
      "e": 36642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59593,
      "e": 36690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59593,
      "e": 36690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59641,
      "e": 36738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59641,
      "e": 36738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59681,
      "e": 36778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 59753,
      "e": 36850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59999,
      "e": 37096,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 63506,
      "e": 40603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 63507,
      "e": 40604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63594,
      "e": 40691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 63739,
      "e": 40836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 63739,
      "e": 40836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63801,
      "e": 40898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 63897,
      "e": 40994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63897,
      "e": 40994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63969,
      "e": 41066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 64025,
      "e": 41122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64026,
      "e": 41123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64113,
      "e": 41210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 64122,
      "e": 41219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64122,
      "e": 41219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64209,
      "e": 41306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64265,
      "e": 41362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 64266,
      "e": 41363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64330,
      "e": 41427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 64330,
      "e": 41427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64354,
      "e": 41451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 64394,
      "e": 41491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64394,
      "e": 41491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64434,
      "e": 41531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64490,
      "e": 41587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66482,
      "e": 43579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 66484,
      "e": 43581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66537,
      "e": 43634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 66609,
      "e": 43706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66609,
      "e": 43706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66690,
      "e": 43787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66690,
      "e": 43787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66714,
      "e": 43811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 66762,
      "e": 43859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66858,
      "e": 43955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66858,
      "e": 43955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66921,
      "e": 44018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 66961,
      "e": 44058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66961,
      "e": 44058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67017,
      "e": 44114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 67090,
      "e": 44187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 67090,
      "e": 44187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67153,
      "e": 44250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 67154,
      "e": 44251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 67155,
      "e": 44252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67257,
      "e": 44354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 67265,
      "e": 44362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 67266,
      "e": 44363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67322,
      "e": 44419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67322,
      "e": 44419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67329,
      "e": 44426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 67401,
      "e": 44498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67522,
      "e": 44619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67523,
      "e": 44620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67585,
      "e": 44682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67601,
      "e": 44698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67602,
      "e": 44699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67650,
      "e": 44747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67651,
      "e": 44748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67673,
      "e": 44770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 67745,
      "e": 44842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68281,
      "e": 45378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68282,
      "e": 45379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68329,
      "e": 45426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68329,
      "e": 45426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68353,
      "e": 45450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 68417,
      "e": 45514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68433,
      "e": 45530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68433,
      "e": 45530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68489,
      "e": 45586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68490,
      "e": 45587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68537,
      "e": 45634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 68617,
      "e": 45714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69530,
      "e": 46627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 69999,
      "e": 47096,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70030,
      "e": 47127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70063,
      "e": 47160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70094,
      "e": 47191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70127,
      "e": 47224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70160,
      "e": 47257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70194,
      "e": 47291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70226,
      "e": 47323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70261,
      "e": 47358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70292,
      "e": 47389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70325,
      "e": 47422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70359,
      "e": 47456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70392,
      "e": 47489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70401,
      "e": 47498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot is ver"
    },
    {
      "t": 70562,
      "e": 47659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70641,
      "e": 47738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot is ve"
    },
    {
      "t": 70745,
      "e": 47842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70802,
      "e": 47899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot is v"
    },
    {
      "t": 70922,
      "e": 48019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70985,
      "e": 48082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot is "
    },
    {
      "t": 72034,
      "e": 49131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72081,
      "e": 49178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot is"
    },
    {
      "t": 72186,
      "e": 49283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72233,
      "e": 49330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot i"
    },
    {
      "t": 72337,
      "e": 49434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72401,
      "e": 49498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot "
    },
    {
      "t": 72826,
      "e": 49923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72826,
      "e": 49923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72897,
      "e": 49994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72897,
      "e": 49994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72953,
      "e": 50050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 73001,
      "e": 50098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 73001,
      "e": 50098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73009,
      "e": 50106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 73082,
      "e": 50179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73114,
      "e": 50211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 73115,
      "e": 50212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73169,
      "e": 50266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 73225,
      "e": 50322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 73225,
      "e": 50322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73281,
      "e": 50378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 73305,
      "e": 50402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73305,
      "e": 50402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73426,
      "e": 50523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73426,
      "e": 50523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73457,
      "e": 50554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 73529,
      "e": 50626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73601,
      "e": 50698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73602,
      "e": 50699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73722,
      "e": 50819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73723,
      "e": 50820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73740,
      "e": 50837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 73857,
      "e": 50954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74162,
      "e": 51259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74208,
      "e": 51305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot indicats"
    },
    {
      "t": 74305,
      "e": 51402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74377,
      "e": 51474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot indicat"
    },
    {
      "t": 74474,
      "e": 51571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 74474,
      "e": 51571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74529,
      "e": 51626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74529,
      "e": 51626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74553,
      "e": 51650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 74606,
      "e": 51703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74607,
      "e": 51704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74646,
      "e": 51743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74719,
      "e": 51816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76182,
      "e": 53279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76683,
      "e": 53780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76714,
      "e": 53811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76748,
      "e": 53845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76781,
      "e": 53878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76814,
      "e": 53911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76847,
      "e": 53944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76854,
      "e": 53951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot ind"
    },
    {
      "t": 76982,
      "e": 54079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77070,
      "e": 54167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot in"
    },
    {
      "t": 77175,
      "e": 54272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77254,
      "e": 54272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot i"
    },
    {
      "t": 77350,
      "e": 54368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77414,
      "e": 54432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot "
    },
    {
      "t": 77622,
      "e": 54640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 77623,
      "e": 54641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77758,
      "e": 54776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 77798,
      "e": 54816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 77798,
      "e": 54816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77879,
      "e": 54897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 77880,
      "e": 54898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77926,
      "e": 54944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 77966,
      "e": 54984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 77967,
      "e": 54985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78022,
      "e": 55040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 78038,
      "e": 55056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78246,
      "e": 55264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78303,
      "e": 55321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot oin"
    },
    {
      "t": 78391,
      "e": 55409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78430,
      "e": 55448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot oi"
    },
    {
      "t": 78543,
      "e": 55561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78582,
      "e": 55600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot o"
    },
    {
      "t": 78687,
      "e": 55705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78749,
      "e": 55767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot "
    },
    {
      "t": 78973,
      "e": 55991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79022,
      "e": 56040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plot"
    },
    {
      "t": 79111,
      "e": 56129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79182,
      "e": 56200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the plo"
    },
    {
      "t": 79263,
      "e": 56281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79327,
      "e": 56345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the pl"
    },
    {
      "t": 79438,
      "e": 56456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79502,
      "e": 56520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the p"
    },
    {
      "t": 79622,
      "e": 56640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79687,
      "e": 56705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the "
    },
    {
      "t": 79798,
      "e": 56816,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the "
    },
    {
      "t": 80087,
      "e": 57105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 80089,
      "e": 57107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80166,
      "e": 57184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 80166,
      "e": 57184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80174,
      "e": 57192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 80238,
      "e": 57256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80254,
      "e": 57272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 80254,
      "e": 57272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80375,
      "e": 57393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 80431,
      "e": 57449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 80431,
      "e": 57449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80494,
      "e": 57512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 80597,
      "e": 57615,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the diag"
    },
    {
      "t": 80598,
      "e": 57616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 80598,
      "e": 57616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80686,
      "e": 57704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 80686,
      "e": 57704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80694,
      "e": 57712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 80742,
      "e": 57760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 80743,
      "e": 57761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80782,
      "e": 57800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 80823,
      "e": 57841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80862,
      "e": 57880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80863,
      "e": 57881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80949,
      "e": 57967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81182,
      "e": 58200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 81184,
      "e": 58202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81270,
      "e": 58288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 81358,
      "e": 58376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 81359,
      "e": 58377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81455,
      "e": 58473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 81456,
      "e": 58474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81486,
      "e": 58504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 81519,
      "e": 58537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 81519,
      "e": 58537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81574,
      "e": 58592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 81606,
      "e": 58624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81607,
      "e": 58625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81646,
      "e": 58664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 81686,
      "e": 58704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81751,
      "e": 58769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 81751,
      "e": 58769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81830,
      "e": 58769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81831,
      "e": 58770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81854,
      "e": 58793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 81926,
      "e": 58865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 82022,
      "e": 58961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 82022,
      "e": 58961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82069,
      "e": 59008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 82078,
      "e": 59017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 82078,
      "e": 59017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82166,
      "e": 59105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 82174,
      "e": 59113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82175,
      "e": 59114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82254,
      "e": 59193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82903,
      "e": 59842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 82903,
      "e": 59842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82966,
      "e": 59905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 82966,
      "e": 59905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83022,
      "e": 59961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 83055,
      "e": 59994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83526,
      "e": 60465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 83614,
      "e": 60553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83654,
      "e": 60593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 83655,
      "e": 60594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83749,
      "e": 60688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 83750,
      "e": 60689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83790,
      "e": 60729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||PM"
    },
    {
      "t": 83870,
      "e": 60809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83886,
      "e": 60825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 83951,
      "e": 60890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84459,
      "e": 61398,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 84496,
      "e": 61435,
      "ty": 2,
      "x": 1165,
      "y": 16
    },
    {
      "t": 84497,
      "e": 61436,
      "ty": 41,
      "x": 39844,
      "y": 486,
      "ta": "> div.stimulus"
    },
    {
      "t": 84896,
      "e": 61835,
      "ty": 2,
      "x": 1144,
      "y": 200
    },
    {
      "t": 84996,
      "e": 61935,
      "ty": 2,
      "x": 443,
      "y": 363
    },
    {
      "t": 84996,
      "e": 61935,
      "ty": 41,
      "x": 38883,
      "y": 21601,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 85096,
      "e": 62035,
      "ty": 2,
      "x": 0,
      "y": 410
    },
    {
      "t": 85187,
      "e": 62126,
      "ty": 6,
      "x": 162,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85196,
      "e": 62135,
      "ty": 2,
      "x": 162,
      "y": 531
    },
    {
      "t": 85203,
      "e": 62142,
      "ty": 7,
      "x": 207,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85246,
      "e": 62185,
      "ty": 41,
      "x": 23707,
      "y": 36083,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 85253,
      "e": 62192,
      "ty": 6,
      "x": 343,
      "y": 605,
      "ta": "#strategyButton"
    },
    {
      "t": 85296,
      "e": 62235,
      "ty": 2,
      "x": 392,
      "y": 602
    },
    {
      "t": 85303,
      "e": 62242,
      "ty": 7,
      "x": 419,
      "y": 597,
      "ta": "#strategyButton"
    },
    {
      "t": 85395,
      "e": 62334,
      "ty": 2,
      "x": 480,
      "y": 596
    },
    {
      "t": 85496,
      "e": 62435,
      "ty": 2,
      "x": 486,
      "y": 619
    },
    {
      "t": 85496,
      "e": 62435,
      "ty": 41,
      "x": 43716,
      "y": 37179,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 85570,
      "e": 62509,
      "ty": 6,
      "x": 449,
      "y": 633,
      "ta": "#strategyButton"
    },
    {
      "t": 85596,
      "e": 62535,
      "ty": 2,
      "x": 447,
      "y": 633
    },
    {
      "t": 85695,
      "e": 62634,
      "ty": 2,
      "x": 445,
      "y": 634
    },
    {
      "t": 85746,
      "e": 62685,
      "ty": 41,
      "x": 58111,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 85763,
      "e": 62702,
      "ty": 3,
      "x": 445,
      "y": 634,
      "ta": "#strategyButton"
    },
    {
      "t": 85764,
      "e": 62703,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to see which letter(s) on the diagram points to 12PM"
    },
    {
      "t": 85765,
      "e": 62704,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85766,
      "e": 62705,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 85842,
      "e": 62781,
      "ty": 4,
      "x": 58111,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 85853,
      "e": 62792,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 85854,
      "e": 62793,
      "ty": 5,
      "x": 445,
      "y": 634,
      "ta": "#strategyButton"
    },
    {
      "t": 85859,
      "e": 62798,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 86860,
      "e": 63799,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 87696,
      "e": 64635,
      "ty": 2,
      "x": 730,
      "y": 599
    },
    {
      "t": 87746,
      "e": 64685,
      "ty": 41,
      "x": 6704,
      "y": 35233,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 87796,
      "e": 64735,
      "ty": 2,
      "x": 884,
      "y": 570
    },
    {
      "t": 87896,
      "e": 64835,
      "ty": 2,
      "x": 953,
      "y": 538
    },
    {
      "t": 87955,
      "e": 64894,
      "ty": 6,
      "x": 967,
      "y": 521,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87996,
      "e": 64935,
      "ty": 2,
      "x": 969,
      "y": 517
    },
    {
      "t": 87996,
      "e": 64935,
      "ty": 41,
      "x": 34822,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88096,
      "e": 65035,
      "ty": 2,
      "x": 972,
      "y": 513
    },
    {
      "t": 88196,
      "e": 65135,
      "ty": 2,
      "x": 973,
      "y": 513
    },
    {
      "t": 88227,
      "e": 65166,
      "ty": 3,
      "x": 973,
      "y": 513,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88228,
      "e": 65167,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88246,
      "e": 65185,
      "ty": 41,
      "x": 35687,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88322,
      "e": 65261,
      "ty": 4,
      "x": 35687,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88322,
      "e": 65261,
      "ty": 5,
      "x": 973,
      "y": 513,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89996,
      "e": 66935,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90311,
      "e": 67250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 90312,
      "e": 67251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90381,
      "e": 67320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 91839,
      "e": 68778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "52"
    },
    {
      "t": 91840,
      "e": 68779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91926,
      "e": 68865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 92094,
      "e": 69033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 92096,
      "e": 69035,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 92096,
      "e": 69035,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92097,
      "e": 69036,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92166,
      "e": 69105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 92471,
      "e": 69410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 92567,
      "e": 69506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 92671,
      "e": 69610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 92671,
      "e": 69610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92750,
      "e": 69689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 92758,
      "e": 69697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 92790,
      "e": 69729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 92790,
      "e": 69729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92838,
      "e": 69777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 92870,
      "e": 69809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 92870,
      "e": 69809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92886,
      "e": 69825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 92942,
      "e": 69881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 92942,
      "e": 69881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92974,
      "e": 69913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 92975,
      "e": 69914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92990,
      "e": 69929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 93047,
      "e": 69986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 93062,
      "e": 70001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 93190,
      "e": 70129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 93191,
      "e": 70130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93270,
      "e": 70209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 94094,
      "e": 71033,
      "ty": 7,
      "x": 1070,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94096,
      "e": 71035,
      "ty": 2,
      "x": 1070,
      "y": 556
    },
    {
      "t": 94126,
      "e": 71065,
      "ty": 6,
      "x": 1079,
      "y": 594,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94143,
      "e": 71082,
      "ty": 7,
      "x": 1062,
      "y": 615,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94195,
      "e": 71134,
      "ty": 2,
      "x": 1041,
      "y": 634
    },
    {
      "t": 94245,
      "e": 71184,
      "ty": 41,
      "x": 35539,
      "y": 39187,
      "ta": "html > body"
    },
    {
      "t": 94295,
      "e": 71234,
      "ty": 2,
      "x": 1039,
      "y": 649
    },
    {
      "t": 94377,
      "e": 71316,
      "ty": 6,
      "x": 1019,
      "y": 646,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94395,
      "e": 71334,
      "ty": 2,
      "x": 1017,
      "y": 646
    },
    {
      "t": 94459,
      "e": 71398,
      "ty": 3,
      "x": 1017,
      "y": 646,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94459,
      "e": 71398,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China\n"
    },
    {
      "t": 94460,
      "e": 71399,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94461,
      "e": 71400,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94495,
      "e": 71434,
      "ty": 41,
      "x": 62402,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94546,
      "e": 71485,
      "ty": 4,
      "x": 62402,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94547,
      "e": 71486,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94547,
      "e": 71486,
      "ty": 5,
      "x": 1017,
      "y": 646,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94547,
      "e": 71486,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 94695,
      "e": 71634,
      "ty": 2,
      "x": 1020,
      "y": 646
    },
    {
      "t": 94745,
      "e": 71684,
      "ty": 41,
      "x": 34850,
      "y": 38822,
      "ta": "html > body"
    },
    {
      "t": 95565,
      "e": 72504,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 95795,
      "e": 72734,
      "ty": 2,
      "x": 933,
      "y": 620
    },
    {
      "t": 95895,
      "e": 72834,
      "ty": 2,
      "x": 929,
      "y": 618
    },
    {
      "t": 95995,
      "e": 72934,
      "ty": 41,
      "x": 28884,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 96495,
      "e": 73434,
      "ty": 2,
      "x": 934,
      "y": 615
    },
    {
      "t": 96495,
      "e": 73434,
      "ty": 41,
      "x": 30227,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 96595,
      "e": 73534,
      "ty": 2,
      "x": 981,
      "y": 348
    },
    {
      "t": 96695,
      "e": 73634,
      "ty": 2,
      "x": 972,
      "y": 261
    },
    {
      "t": 96746,
      "e": 73685,
      "ty": 41,
      "x": 45310,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 96795,
      "e": 73734,
      "ty": 2,
      "x": 959,
      "y": 241
    },
    {
      "t": 96895,
      "e": 73834,
      "ty": 2,
      "x": 940,
      "y": 246
    },
    {
      "t": 96996,
      "e": 73935,
      "ty": 2,
      "x": 917,
      "y": 229
    },
    {
      "t": 96996,
      "e": 73935,
      "ty": 41,
      "x": 22683,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 97096,
      "e": 74035,
      "ty": 2,
      "x": 892,
      "y": 184
    },
    {
      "t": 97195,
      "e": 74134,
      "ty": 2,
      "x": 889,
      "y": 177
    },
    {
      "t": 97246,
      "e": 74185,
      "ty": 41,
      "x": 55337,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97395,
      "e": 74334,
      "ty": 2,
      "x": 887,
      "y": 182
    },
    {
      "t": 97496,
      "e": 74435,
      "ty": 41,
      "x": 53699,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97907,
      "e": 74846,
      "ty": 3,
      "x": 887,
      "y": 182,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97962,
      "e": 74901,
      "ty": 4,
      "x": 53699,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97962,
      "e": 74901,
      "ty": 5,
      "x": 887,
      "y": 182,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97962,
      "e": 74901,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 97963,
      "e": 74902,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 98096,
      "e": 75035,
      "ty": 2,
      "x": 887,
      "y": 191
    },
    {
      "t": 98196,
      "e": 75135,
      "ty": 2,
      "x": 985,
      "y": 275
    },
    {
      "t": 98247,
      "e": 75137,
      "ty": 41,
      "x": 39058,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 98296,
      "e": 75186,
      "ty": 2,
      "x": 986,
      "y": 275
    },
    {
      "t": 98496,
      "e": 75386,
      "ty": 2,
      "x": 984,
      "y": 275
    },
    {
      "t": 98496,
      "e": 75386,
      "ty": 41,
      "x": 38583,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 98595,
      "e": 75485,
      "ty": 2,
      "x": 977,
      "y": 268
    },
    {
      "t": 98695,
      "e": 75585,
      "ty": 2,
      "x": 975,
      "y": 258
    },
    {
      "t": 98746,
      "e": 75636,
      "ty": 41,
      "x": 36447,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 98795,
      "e": 75685,
      "ty": 2,
      "x": 975,
      "y": 246
    },
    {
      "t": 98867,
      "e": 75757,
      "ty": 3,
      "x": 975,
      "y": 244,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 98868,
      "e": 75758,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98895,
      "e": 75785,
      "ty": 2,
      "x": 975,
      "y": 244
    },
    {
      "t": 98946,
      "e": 75836,
      "ty": 4,
      "x": 48131,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 98946,
      "e": 75836,
      "ty": 5,
      "x": 975,
      "y": 244,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 98946,
      "e": 75836,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 98946,
      "e": 75836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 98996,
      "e": 75886,
      "ty": 41,
      "x": 48131,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 99096,
      "e": 75986,
      "ty": 2,
      "x": 975,
      "y": 243
    },
    {
      "t": 99245,
      "e": 76135,
      "ty": 41,
      "x": 48131,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 99396,
      "e": 76286,
      "ty": 2,
      "x": 901,
      "y": 207
    },
    {
      "t": 99496,
      "e": 76386,
      "ty": 2,
      "x": 869,
      "y": 191
    },
    {
      "t": 99496,
      "e": 76386,
      "ty": 41,
      "x": 38960,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 99596,
      "e": 76486,
      "ty": 2,
      "x": 868,
      "y": 189
    },
    {
      "t": 99746,
      "e": 76636,
      "ty": 41,
      "x": 38141,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 99796,
      "e": 76686,
      "ty": 2,
      "x": 868,
      "y": 186
    },
    {
      "t": 99895,
      "e": 76785,
      "ty": 2,
      "x": 870,
      "y": 176
    },
    {
      "t": 99996,
      "e": 76886,
      "ty": 41,
      "x": 39779,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 100245,
      "e": 77135,
      "ty": 41,
      "x": 39779,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 100295,
      "e": 77185,
      "ty": 2,
      "x": 891,
      "y": 234
    },
    {
      "t": 100396,
      "e": 77286,
      "ty": 2,
      "x": 929,
      "y": 304
    },
    {
      "t": 100495,
      "e": 77385,
      "ty": 2,
      "x": 977,
      "y": 374
    },
    {
      "t": 100496,
      "e": 77386,
      "ty": 41,
      "x": 36922,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 100596,
      "e": 77486,
      "ty": 2,
      "x": 984,
      "y": 379
    },
    {
      "t": 100746,
      "e": 77636,
      "ty": 41,
      "x": 38583,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 100896,
      "e": 77786,
      "ty": 2,
      "x": 981,
      "y": 382
    },
    {
      "t": 100996,
      "e": 77886,
      "ty": 2,
      "x": 912,
      "y": 380
    },
    {
      "t": 100996,
      "e": 77886,
      "ty": 41,
      "x": 21496,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 101095,
      "e": 77985,
      "ty": 2,
      "x": 880,
      "y": 379
    },
    {
      "t": 101195,
      "e": 78085,
      "ty": 2,
      "x": 877,
      "y": 380
    },
    {
      "t": 101246,
      "e": 78136,
      "ty": 41,
      "x": 44393,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 101495,
      "e": 78385,
      "ty": 2,
      "x": 876,
      "y": 351
    },
    {
      "t": 101496,
      "e": 78386,
      "ty": 41,
      "x": 12952,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 101595,
      "e": 78485,
      "ty": 2,
      "x": 861,
      "y": 236
    },
    {
      "t": 101696,
      "e": 78586,
      "ty": 2,
      "x": 851,
      "y": 167
    },
    {
      "t": 101746,
      "e": 78636,
      "ty": 41,
      "x": 6544,
      "y": 12028,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 101796,
      "e": 78686,
      "ty": 2,
      "x": 849,
      "y": 155
    },
    {
      "t": 101896,
      "e": 78786,
      "ty": 2,
      "x": 846,
      "y": 176
    },
    {
      "t": 101996,
      "e": 78886,
      "ty": 2,
      "x": 846,
      "y": 184
    },
    {
      "t": 101996,
      "e": 78886,
      "ty": 41,
      "x": 20126,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 102096,
      "e": 78986,
      "ty": 2,
      "x": 853,
      "y": 198
    },
    {
      "t": 102196,
      "e": 79086,
      "ty": 2,
      "x": 855,
      "y": 201
    },
    {
      "t": 102246,
      "e": 79136,
      "ty": 41,
      "x": 7968,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 102296,
      "e": 79186,
      "ty": 2,
      "x": 863,
      "y": 194
    },
    {
      "t": 102395,
      "e": 79285,
      "ty": 2,
      "x": 870,
      "y": 186
    },
    {
      "t": 102495,
      "e": 79385,
      "ty": 2,
      "x": 872,
      "y": 182
    },
    {
      "t": 102496,
      "e": 79386,
      "ty": 41,
      "x": 41416,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 102506,
      "e": 79396,
      "ty": 3,
      "x": 872,
      "y": 182,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 102507,
      "e": 79397,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 102585,
      "e": 79475,
      "ty": 4,
      "x": 41416,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 102585,
      "e": 79475,
      "ty": 5,
      "x": 872,
      "y": 182,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 102586,
      "e": 79476,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 102586,
      "e": 79476,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 102746,
      "e": 79636,
      "ty": 41,
      "x": 18173,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 102796,
      "e": 79686,
      "ty": 2,
      "x": 914,
      "y": 476
    },
    {
      "t": 102896,
      "e": 79786,
      "ty": 2,
      "x": 915,
      "y": 521
    },
    {
      "t": 102996,
      "e": 79886,
      "ty": 2,
      "x": 890,
      "y": 469
    },
    {
      "t": 102996,
      "e": 79886,
      "ty": 41,
      "x": 16275,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 103096,
      "e": 79986,
      "ty": 2,
      "x": 869,
      "y": 429
    },
    {
      "t": 103196,
      "e": 80086,
      "ty": 2,
      "x": 868,
      "y": 424
    },
    {
      "t": 103246,
      "e": 80136,
      "ty": 41,
      "x": 49233,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 103362,
      "e": 80252,
      "ty": 3,
      "x": 868,
      "y": 424,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 103363,
      "e": 80253,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 103434,
      "e": 80324,
      "ty": 4,
      "x": 49233,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 103434,
      "e": 80324,
      "ty": 5,
      "x": 868,
      "y": 424,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 103436,
      "e": 80326,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103437,
      "e": 80327,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 103596,
      "e": 80486,
      "ty": 2,
      "x": 868,
      "y": 425
    },
    {
      "t": 103696,
      "e": 80586,
      "ty": 2,
      "x": 879,
      "y": 371
    },
    {
      "t": 103746,
      "e": 80636,
      "ty": 41,
      "x": 15563,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 103796,
      "e": 80686,
      "ty": 2,
      "x": 894,
      "y": 274
    },
    {
      "t": 103896,
      "e": 80786,
      "ty": 2,
      "x": 897,
      "y": 261
    },
    {
      "t": 103996,
      "e": 80886,
      "ty": 2,
      "x": 899,
      "y": 255
    },
    {
      "t": 103996,
      "e": 80886,
      "ty": 41,
      "x": 18411,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 104096,
      "e": 80986,
      "ty": 2,
      "x": 906,
      "y": 235
    },
    {
      "t": 104178,
      "e": 81068,
      "ty": 3,
      "x": 906,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 104180,
      "e": 81070,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 104243,
      "e": 81133,
      "ty": 4,
      "x": 26506,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 104243,
      "e": 81133,
      "ty": 5,
      "x": 906,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 104243,
      "e": 81133,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 104246,
      "e": 81136,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 104247,
      "e": 81137,
      "ty": 41,
      "x": 26506,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 104395,
      "e": 81285,
      "ty": 2,
      "x": 901,
      "y": 243
    },
    {
      "t": 104496,
      "e": 81386,
      "ty": 2,
      "x": 905,
      "y": 266
    },
    {
      "t": 104496,
      "e": 81386,
      "ty": 41,
      "x": 19835,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 104745,
      "e": 81635,
      "ty": 41,
      "x": 18411,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 104796,
      "e": 81686,
      "ty": 2,
      "x": 893,
      "y": 230
    },
    {
      "t": 104896,
      "e": 81786,
      "ty": 2,
      "x": 871,
      "y": 185
    },
    {
      "t": 104996,
      "e": 81886,
      "ty": 41,
      "x": 40597,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 105459,
      "e": 82349,
      "ty": 3,
      "x": 871,
      "y": 185,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 105459,
      "e": 82349,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 105529,
      "e": 82419,
      "ty": 4,
      "x": 40597,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 105529,
      "e": 82419,
      "ty": 5,
      "x": 871,
      "y": 185,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 105530,
      "e": 82420,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 105531,
      "e": 82421,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 105695,
      "e": 82585,
      "ty": 2,
      "x": 910,
      "y": 329
    },
    {
      "t": 105746,
      "e": 82636,
      "ty": 41,
      "x": 38821,
      "y": 8936,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 105795,
      "e": 82685,
      "ty": 2,
      "x": 1016,
      "y": 737
    },
    {
      "t": 105896,
      "e": 82786,
      "ty": 2,
      "x": 1017,
      "y": 748
    },
    {
      "t": 105996,
      "e": 82886,
      "ty": 41,
      "x": 46415,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 106495,
      "e": 83385,
      "ty": 2,
      "x": 1017,
      "y": 746
    },
    {
      "t": 106496,
      "e": 83386,
      "ty": 41,
      "x": 46415,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 106696,
      "e": 83586,
      "ty": 2,
      "x": 1014,
      "y": 745
    },
    {
      "t": 106746,
      "e": 83636,
      "ty": 41,
      "x": 44516,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 106796,
      "e": 83686,
      "ty": 2,
      "x": 981,
      "y": 747
    },
    {
      "t": 106896,
      "e": 83786,
      "ty": 2,
      "x": 907,
      "y": 754
    },
    {
      "t": 106996,
      "e": 83886,
      "ty": 2,
      "x": 902,
      "y": 754
    },
    {
      "t": 106996,
      "e": 83886,
      "ty": 41,
      "x": 47560,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 107196,
      "e": 84086,
      "ty": 2,
      "x": 902,
      "y": 752
    },
    {
      "t": 107246,
      "e": 84136,
      "ty": 41,
      "x": 48740,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 107296,
      "e": 84186,
      "ty": 2,
      "x": 905,
      "y": 763
    },
    {
      "t": 107496,
      "e": 84386,
      "ty": 2,
      "x": 916,
      "y": 777
    },
    {
      "t": 107496,
      "e": 84386,
      "ty": 41,
      "x": 22445,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 107596,
      "e": 84486,
      "ty": 2,
      "x": 917,
      "y": 785
    },
    {
      "t": 107696,
      "e": 84586,
      "ty": 2,
      "x": 915,
      "y": 787
    },
    {
      "t": 107746,
      "e": 84636,
      "ty": 41,
      "x": 64522,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 107795,
      "e": 84685,
      "ty": 2,
      "x": 911,
      "y": 785
    },
    {
      "t": 107895,
      "e": 84785,
      "ty": 2,
      "x": 915,
      "y": 776
    },
    {
      "t": 107996,
      "e": 84886,
      "ty": 2,
      "x": 912,
      "y": 782
    },
    {
      "t": 107996,
      "e": 84886,
      "ty": 41,
      "x": 63817,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 108096,
      "e": 84986,
      "ty": 2,
      "x": 908,
      "y": 785
    },
    {
      "t": 108196,
      "e": 85086,
      "ty": 2,
      "x": 906,
      "y": 786
    },
    {
      "t": 108246,
      "e": 85136,
      "ty": 41,
      "x": 59590,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 108396,
      "e": 85286,
      "ty": 2,
      "x": 918,
      "y": 754
    },
    {
      "t": 108495,
      "e": 85385,
      "ty": 2,
      "x": 966,
      "y": 677
    },
    {
      "t": 108495,
      "e": 85385,
      "ty": 41,
      "x": 36287,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 108596,
      "e": 85486,
      "ty": 2,
      "x": 973,
      "y": 665
    },
    {
      "t": 108696,
      "e": 85586,
      "ty": 2,
      "x": 987,
      "y": 663
    },
    {
      "t": 108746,
      "e": 85636,
      "ty": 41,
      "x": 40957,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 108796,
      "e": 85686,
      "ty": 2,
      "x": 997,
      "y": 664
    },
    {
      "t": 108896,
      "e": 85786,
      "ty": 2,
      "x": 1016,
      "y": 679
    },
    {
      "t": 108995,
      "e": 85885,
      "ty": 41,
      "x": 48836,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 109396,
      "e": 86286,
      "ty": 2,
      "x": 1007,
      "y": 692
    },
    {
      "t": 109496,
      "e": 86386,
      "ty": 2,
      "x": 960,
      "y": 715
    },
    {
      "t": 109496,
      "e": 86386,
      "ty": 41,
      "x": 57822,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 109596,
      "e": 86486,
      "ty": 2,
      "x": 946,
      "y": 719
    },
    {
      "t": 109746,
      "e": 86636,
      "ty": 41,
      "x": 51146,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 109796,
      "e": 86686,
      "ty": 2,
      "x": 944,
      "y": 704
    },
    {
      "t": 109996,
      "e": 86886,
      "ty": 41,
      "x": 51146,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 110196,
      "e": 87086,
      "ty": 2,
      "x": 915,
      "y": 715
    },
    {
      "t": 110247,
      "e": 87137,
      "ty": 41,
      "x": 17936,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 110296,
      "e": 87186,
      "ty": 2,
      "x": 897,
      "y": 722
    },
    {
      "t": 110396,
      "e": 87286,
      "ty": 2,
      "x": 896,
      "y": 722
    },
    {
      "t": 110496,
      "e": 87386,
      "ty": 41,
      "x": 17699,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 110796,
      "e": 87686,
      "ty": 2,
      "x": 896,
      "y": 726
    },
    {
      "t": 110896,
      "e": 87786,
      "ty": 2,
      "x": 896,
      "y": 728
    },
    {
      "t": 110996,
      "e": 87886,
      "ty": 2,
      "x": 903,
      "y": 739
    },
    {
      "t": 110997,
      "e": 87887,
      "ty": 41,
      "x": 45669,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 111096,
      "e": 87986,
      "ty": 2,
      "x": 910,
      "y": 752
    },
    {
      "t": 111196,
      "e": 88086,
      "ty": 2,
      "x": 911,
      "y": 755
    },
    {
      "t": 111247,
      "e": 88137,
      "ty": 41,
      "x": 52872,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 111396,
      "e": 88286,
      "ty": 2,
      "x": 911,
      "y": 760
    },
    {
      "t": 111497,
      "e": 88387,
      "ty": 41,
      "x": 52872,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 112283,
      "e": 89173,
      "ty": 3,
      "x": 911,
      "y": 760,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 112285,
      "e": 89175,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 112386,
      "e": 89276,
      "ty": 4,
      "x": 52872,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 112386,
      "e": 89276,
      "ty": 5,
      "x": 911,
      "y": 760,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 112386,
      "e": 89276,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 112387,
      "e": 89277,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 112496,
      "e": 89386,
      "ty": 2,
      "x": 911,
      "y": 761
    },
    {
      "t": 112496,
      "e": 89386,
      "ty": 41,
      "x": 52872,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 112695,
      "e": 89585,
      "ty": 2,
      "x": 884,
      "y": 816
    },
    {
      "t": 112746,
      "e": 89636,
      "ty": 41,
      "x": 50874,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 112796,
      "e": 89686,
      "ty": 2,
      "x": 850,
      "y": 879
    },
    {
      "t": 112826,
      "e": 89716,
      "ty": 6,
      "x": 836,
      "y": 884,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 112896,
      "e": 89786,
      "ty": 2,
      "x": 833,
      "y": 885
    },
    {
      "t": 112996,
      "e": 89886,
      "ty": 2,
      "x": 837,
      "y": 884
    },
    {
      "t": 112997,
      "e": 89887,
      "ty": 41,
      "x": 53325,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113051,
      "e": 89941,
      "ty": 3,
      "x": 837,
      "y": 884,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113052,
      "e": 89942,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 113053,
      "e": 89943,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113097,
      "e": 89987,
      "ty": 4,
      "x": 53325,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113097,
      "e": 89987,
      "ty": 5,
      "x": 837,
      "y": 884,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113098,
      "e": 89988,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 113196,
      "e": 90086,
      "ty": 2,
      "x": 838,
      "y": 883
    },
    {
      "t": 113210,
      "e": 90100,
      "ty": 7,
      "x": 843,
      "y": 886,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113243,
      "e": 90133,
      "ty": 6,
      "x": 912,
      "y": 963,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113246,
      "e": 90136,
      "ty": 41,
      "x": 42559,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113275,
      "e": 90165,
      "ty": 7,
      "x": 937,
      "y": 992,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113296,
      "e": 90186,
      "ty": 2,
      "x": 942,
      "y": 997
    },
    {
      "t": 113396,
      "e": 90286,
      "ty": 2,
      "x": 942,
      "y": 996
    },
    {
      "t": 113426,
      "e": 90316,
      "ty": 6,
      "x": 942,
      "y": 983,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113496,
      "e": 90386,
      "ty": 2,
      "x": 936,
      "y": 961
    },
    {
      "t": 113496,
      "e": 90386,
      "ty": 41,
      "x": 54929,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113587,
      "e": 90477,
      "ty": 3,
      "x": 934,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113589,
      "e": 90479,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 113589,
      "e": 90479,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113596,
      "e": 90486,
      "ty": 2,
      "x": 934,
      "y": 960
    },
    {
      "t": 113658,
      "e": 90548,
      "ty": 4,
      "x": 53898,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113659,
      "e": 90549,
      "ty": 5,
      "x": 934,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113663,
      "e": 90553,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113664,
      "e": 90554,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 113665,
      "e": 90555,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 113746,
      "e": 90636,
      "ty": 41,
      "x": 31923,
      "y": 57746,
      "ta": "html > body"
    },
    {
      "t": 113796,
      "e": 90686,
      "ty": 2,
      "x": 942,
      "y": 953
    },
    {
      "t": 113896,
      "e": 90786,
      "ty": 2,
      "x": 1087,
      "y": 838
    },
    {
      "t": 113996,
      "e": 90886,
      "ty": 2,
      "x": 1093,
      "y": 824
    },
    {
      "t": 113996,
      "e": 90886,
      "ty": 41,
      "x": 37364,
      "y": 49653,
      "ta": "html > body"
    },
    {
      "t": 114197,
      "e": 91087,
      "ty": 2,
      "x": 1093,
      "y": 823
    },
    {
      "t": 114246,
      "e": 91136,
      "ty": 41,
      "x": 37364,
      "y": 49592,
      "ta": "html > body"
    },
    {
      "t": 115020,
      "e": 91910,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 115695,
      "e": 92585,
      "ty": 2,
      "x": 1092,
      "y": 822
    },
    {
      "t": 115746,
      "e": 92636,
      "ty": 41,
      "x": 39286,
      "y": 3510,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 115796,
      "e": 92637,
      "ty": 2,
      "x": 1092,
      "y": 821
    },
    {
      "t": 117195,
      "e": 94036,
      "ty": 2,
      "x": 1090,
      "y": 820
    },
    {
      "t": 117245,
      "e": 94086,
      "ty": 41,
      "x": 38990,
      "y": 62235,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 117296,
      "e": 94137,
      "ty": 2,
      "x": 1071,
      "y": 819
    },
    {
      "t": 117395,
      "e": 94236,
      "ty": 2,
      "x": 1037,
      "y": 827
    },
    {
      "t": 117495,
      "e": 94336,
      "ty": 2,
      "x": 1035,
      "y": 831
    },
    {
      "t": 117495,
      "e": 94336,
      "ty": 41,
      "x": 36481,
      "y": 26916,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 117595,
      "e": 94436,
      "ty": 2,
      "x": 1035,
      "y": 833
    },
    {
      "t": 117746,
      "e": 94587,
      "ty": 41,
      "x": 36481,
      "y": 31597,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 129996,
      "e": 99587,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 131996,
      "e": 99587,
      "ty": 2,
      "x": 1034,
      "y": 832
    },
    {
      "t": 131996,
      "e": 99587,
      "ty": 41,
      "x": 36432,
      "y": 29256,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 134693,
      "e": 102284,
      "ty": 2,
      "x": 1034,
      "y": 831
    },
    {
      "t": 134744,
      "e": 102335,
      "ty": 41,
      "x": 36432,
      "y": 26916,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 134794,
      "e": 102385,
      "ty": 2,
      "x": 1034,
      "y": 830
    },
    {
      "t": 134994,
      "e": 102585,
      "ty": 41,
      "x": 36432,
      "y": 24575,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 135493,
      "e": 103084,
      "ty": 2,
      "x": 1031,
      "y": 830
    },
    {
      "t": 135493,
      "e": 103084,
      "ty": 41,
      "x": 36285,
      "y": 24575,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 135594,
      "e": 103185,
      "ty": 2,
      "x": 1004,
      "y": 831
    },
    {
      "t": 135694,
      "e": 103285,
      "ty": 2,
      "x": 982,
      "y": 834
    },
    {
      "t": 135744,
      "e": 103335,
      "ty": 41,
      "x": 33874,
      "y": 33937,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 136492,
      "e": 104083,
      "ty": 2,
      "x": 990,
      "y": 831
    },
    {
      "t": 136493,
      "e": 104084,
      "ty": 41,
      "x": 34268,
      "y": 26916,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 136592,
      "e": 104183,
      "ty": 2,
      "x": 998,
      "y": 827
    },
    {
      "t": 136693,
      "e": 104284,
      "ty": 2,
      "x": 1003,
      "y": 825
    },
    {
      "t": 136742,
      "e": 104333,
      "ty": 41,
      "x": 35153,
      "y": 10532,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 136793,
      "e": 104384,
      "ty": 2,
      "x": 1019,
      "y": 819
    },
    {
      "t": 136892,
      "e": 104483,
      "ty": 2,
      "x": 1028,
      "y": 812
    },
    {
      "t": 136993,
      "e": 104584,
      "ty": 2,
      "x": 1028,
      "y": 811
    },
    {
      "t": 136993,
      "e": 104584,
      "ty": 41,
      "x": 36137,
      "y": 61308,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 137093,
      "e": 104684,
      "ty": 2,
      "x": 1028,
      "y": 810
    },
    {
      "t": 137192,
      "e": 104783,
      "ty": 2,
      "x": 1026,
      "y": 810
    },
    {
      "t": 137243,
      "e": 104834,
      "ty": 41,
      "x": 35596,
      "y": 61656,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 137293,
      "e": 104884,
      "ty": 2,
      "x": 1013,
      "y": 818
    },
    {
      "t": 137493,
      "e": 105084,
      "ty": 41,
      "x": 35399,
      "y": 62119,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 137743,
      "e": 105334,
      "ty": 41,
      "x": 35153,
      "y": 62119,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 137793,
      "e": 105384,
      "ty": 2,
      "x": 1004,
      "y": 818
    },
    {
      "t": 137893,
      "e": 105484,
      "ty": 2,
      "x": 967,
      "y": 823
    },
    {
      "t": 137993,
      "e": 105584,
      "ty": 2,
      "x": 883,
      "y": 848
    },
    {
      "t": 137993,
      "e": 105584,
      "ty": 41,
      "x": 29003,
      "y": 55700,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 138093,
      "e": 105684,
      "ty": 2,
      "x": 826,
      "y": 884
    },
    {
      "t": 138193,
      "e": 105784,
      "ty": 2,
      "x": 826,
      "y": 887
    },
    {
      "t": 138243,
      "e": 105834,
      "ty": 41,
      "x": 26199,
      "y": 58666,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139242,
      "e": 106833,
      "ty": 41,
      "x": 26199,
      "y": 58590,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139293,
      "e": 106884,
      "ty": 2,
      "x": 826,
      "y": 886
    },
    {
      "t": 139592,
      "e": 107183,
      "ty": 2,
      "x": 826,
      "y": 884
    },
    {
      "t": 139743,
      "e": 107334,
      "ty": 41,
      "x": 26199,
      "y": 58438,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139993,
      "e": 107584,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140243,
      "e": 107834,
      "ty": 41,
      "x": 26248,
      "y": 58362,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 140293,
      "e": 107884,
      "ty": 2,
      "x": 827,
      "y": 883
    },
    {
      "t": 140393,
      "e": 107984,
      "ty": 2,
      "x": 832,
      "y": 882
    },
    {
      "t": 140493,
      "e": 108084,
      "ty": 41,
      "x": 26494,
      "y": 58286,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141393,
      "e": 108984,
      "ty": 2,
      "x": 844,
      "y": 880
    },
    {
      "t": 141492,
      "e": 109083,
      "ty": 2,
      "x": 940,
      "y": 900
    },
    {
      "t": 141493,
      "e": 109084,
      "ty": 41,
      "x": 31808,
      "y": 59655,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141592,
      "e": 109183,
      "ty": 2,
      "x": 972,
      "y": 927
    },
    {
      "t": 141692,
      "e": 109283,
      "ty": 2,
      "x": 982,
      "y": 958
    },
    {
      "t": 141743,
      "e": 109334,
      "ty": 41,
      "x": 33874,
      "y": 64599,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141792,
      "e": 109383,
      "ty": 2,
      "x": 980,
      "y": 971
    },
    {
      "t": 141893,
      "e": 109484,
      "ty": 2,
      "x": 979,
      "y": 975
    },
    {
      "t": 141910,
      "e": 109501,
      "ty": 6,
      "x": 979,
      "y": 978,
      "ta": "#start"
    },
    {
      "t": 141993,
      "e": 109584,
      "ty": 2,
      "x": 978,
      "y": 980
    },
    {
      "t": 141993,
      "e": 109584,
      "ty": 41,
      "x": 37409,
      "y": 5210,
      "ta": "#start"
    },
    {
      "t": 142092,
      "e": 109683,
      "ty": 2,
      "x": 978,
      "y": 981
    },
    {
      "t": 142243,
      "e": 109834,
      "ty": 41,
      "x": 37409,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 143065,
      "e": 110656,
      "ty": 3,
      "x": 978,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 143065,
      "e": 110656,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 143167,
      "e": 110758,
      "ty": 4,
      "x": 37409,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 143168,
      "e": 110759,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 143168,
      "e": 110759,
      "ty": 5,
      "x": 978,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 143168,
      "e": 110759,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 143793,
      "e": 111384,
      "ty": 2,
      "x": 978,
      "y": 982
    },
    {
      "t": 143993,
      "e": 111584,
      "ty": 41,
      "x": 33404,
      "y": 59267,
      "ta": "html > body"
    },
    {
      "t": 144194,
      "e": 111785,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 145068,
      "e": 112659,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 56721, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 56728, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14992, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 72827, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10753, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"uniform\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\\n\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 84587, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9719, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 95410, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10634, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 107048, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 16206, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 124468, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:854,y:707,t:1527793584775};\\\", \\\"{x:856,y:707,t:1527793584792};\\\", \\\"{x:856,y:706,t:1527793584808};\\\", \\\"{x:858,y:706,t:1527793584825};\\\", \\\"{x:861,y:705,t:1527793584842};\\\", \\\"{x:863,y:705,t:1527793584858};\\\", \\\"{x:868,y:705,t:1527793584875};\\\", \\\"{x:875,y:703,t:1527793584892};\\\", \\\"{x:882,y:703,t:1527793584908};\\\", \\\"{x:896,y:701,t:1527793584925};\\\", \\\"{x:914,y:698,t:1527793584943};\\\", \\\"{x:929,y:692,t:1527793584958};\\\", \\\"{x:945,y:685,t:1527793584975};\\\", \\\"{x:954,y:679,t:1527793584992};\\\", \\\"{x:962,y:673,t:1527793585008};\\\", \\\"{x:970,y:666,t:1527793585025};\\\", \\\"{x:977,y:658,t:1527793585042};\\\", \\\"{x:985,y:648,t:1527793585059};\\\", \\\"{x:987,y:646,t:1527793585076};\\\", \\\"{x:989,y:645,t:1527793585091};\\\", \\\"{x:988,y:645,t:1527793585343};\\\", \\\"{x:986,y:648,t:1527793585359};\\\", \\\"{x:982,y:652,t:1527793585376};\\\", \\\"{x:981,y:653,t:1527793585392};\\\", \\\"{x:981,y:655,t:1527793585409};\\\", \\\"{x:981,y:659,t:1527793585425};\\\", \\\"{x:981,y:660,t:1527793585442};\\\", \\\"{x:982,y:660,t:1527793585783};\\\", \\\"{x:985,y:660,t:1527793585792};\\\", \\\"{x:988,y:660,t:1527793585809};\\\", \\\"{x:989,y:660,t:1527793585831};\\\", \\\"{x:990,y:660,t:1527793585847};\\\", \\\"{x:991,y:660,t:1527793585871};\\\", \\\"{x:992,y:660,t:1527793585881};\\\", \\\"{x:994,y:660,t:1527793585892};\\\", \\\"{x:1002,y:660,t:1527793585909};\\\", \\\"{x:1022,y:660,t:1527793585926};\\\", \\\"{x:1043,y:660,t:1527793585941};\\\", \\\"{x:1067,y:660,t:1527793585958};\\\", \\\"{x:1096,y:660,t:1527793585975};\\\", \\\"{x:1131,y:663,t:1527793585991};\\\", \\\"{x:1165,y:671,t:1527793586009};\\\", \\\"{x:1187,y:685,t:1527793586026};\\\", \\\"{x:1209,y:702,t:1527793586042};\\\", \\\"{x:1229,y:730,t:1527793586058};\\\", \\\"{x:1239,y:765,t:1527793586076};\\\", \\\"{x:1239,y:799,t:1527793586093};\\\", \\\"{x:1237,y:830,t:1527793586109};\\\", \\\"{x:1228,y:862,t:1527793586125};\\\", \\\"{x:1226,y:888,t:1527793586141};\\\", \\\"{x:1226,y:908,t:1527793586159};\\\", \\\"{x:1224,y:923,t:1527793586176};\\\", \\\"{x:1220,y:937,t:1527793586193};\\\", \\\"{x:1213,y:945,t:1527793586208};\\\", \\\"{x:1208,y:949,t:1527793586226};\\\", \\\"{x:1203,y:951,t:1527793586243};\\\", \\\"{x:1202,y:951,t:1527793586295};\\\", \\\"{x:1203,y:950,t:1527793586335};\\\", \\\"{x:1207,y:945,t:1527793586343};\\\", \\\"{x:1212,y:938,t:1527793586359};\\\", \\\"{x:1217,y:936,t:1527793586376};\\\", \\\"{x:1226,y:934,t:1527793586393};\\\", \\\"{x:1232,y:933,t:1527793586409};\\\", \\\"{x:1235,y:932,t:1527793586426};\\\", \\\"{x:1237,y:930,t:1527793586444};\\\", \\\"{x:1240,y:927,t:1527793586460};\\\", \\\"{x:1243,y:925,t:1527793586476};\\\", \\\"{x:1250,y:921,t:1527793586494};\\\", \\\"{x:1255,y:919,t:1527793586509};\\\", \\\"{x:1257,y:919,t:1527793586526};\\\", \\\"{x:1258,y:918,t:1527793586543};\\\", \\\"{x:1259,y:918,t:1527793586559};\\\", \\\"{x:1260,y:918,t:1527793586576};\\\", \\\"{x:1262,y:917,t:1527793586593};\\\", \\\"{x:1266,y:917,t:1527793586610};\\\", \\\"{x:1273,y:917,t:1527793586627};\\\", \\\"{x:1278,y:917,t:1527793586643};\\\", \\\"{x:1279,y:919,t:1527793586660};\\\", \\\"{x:1280,y:919,t:1527793586694};\\\", \\\"{x:1280,y:916,t:1527793586711};\\\", \\\"{x:1280,y:913,t:1527793586727};\\\", \\\"{x:1280,y:912,t:1527793586743};\\\", \\\"{x:1280,y:910,t:1527793586760};\\\", \\\"{x:1280,y:909,t:1527793586776};\\\", \\\"{x:1280,y:908,t:1527793586807};\\\", \\\"{x:1280,y:907,t:1527793586831};\\\", \\\"{x:1280,y:906,t:1527793586855};\\\", \\\"{x:1280,y:904,t:1527793586871};\\\", \\\"{x:1280,y:903,t:1527793586879};\\\", \\\"{x:1280,y:900,t:1527793586895};\\\", \\\"{x:1280,y:898,t:1527793586910};\\\", \\\"{x:1280,y:893,t:1527793586927};\\\", \\\"{x:1280,y:884,t:1527793586943};\\\", \\\"{x:1280,y:868,t:1527793586960};\\\", \\\"{x:1280,y:853,t:1527793586976};\\\", \\\"{x:1280,y:838,t:1527793586994};\\\", \\\"{x:1280,y:820,t:1527793587010};\\\", \\\"{x:1280,y:808,t:1527793587026};\\\", \\\"{x:1280,y:800,t:1527793587043};\\\", \\\"{x:1279,y:793,t:1527793587061};\\\", \\\"{x:1279,y:789,t:1527793587078};\\\", \\\"{x:1279,y:785,t:1527793587093};\\\", \\\"{x:1279,y:777,t:1527793587113};\\\", \\\"{x:1279,y:774,t:1527793587127};\\\", \\\"{x:1279,y:770,t:1527793587143};\\\", \\\"{x:1280,y:768,t:1527793587159};\\\", \\\"{x:1280,y:767,t:1527793587177};\\\", \\\"{x:1281,y:765,t:1527793587192};\\\", \\\"{x:1282,y:764,t:1527793587222};\\\", \\\"{x:1282,y:763,t:1527793587254};\\\", \\\"{x:1273,y:760,t:1527793587358};\\\", \\\"{x:1256,y:759,t:1527793587365};\\\", \\\"{x:1233,y:756,t:1527793587376};\\\", \\\"{x:1130,y:740,t:1527793587392};\\\", \\\"{x:972,y:714,t:1527793587409};\\\", \\\"{x:773,y:663,t:1527793587427};\\\", \\\"{x:559,y:610,t:1527793587443};\\\", \\\"{x:366,y:559,t:1527793587461};\\\", \\\"{x:217,y:520,t:1527793587478};\\\", \\\"{x:139,y:496,t:1527793587492};\\\", \\\"{x:99,y:474,t:1527793587510};\\\", \\\"{x:96,y:472,t:1527793587527};\\\", \\\"{x:99,y:469,t:1527793587549};\\\", \\\"{x:102,y:469,t:1527793587560};\\\", \\\"{x:112,y:468,t:1527793587576};\\\", \\\"{x:117,y:466,t:1527793587593};\\\", \\\"{x:121,y:462,t:1527793587611};\\\", \\\"{x:128,y:453,t:1527793587626};\\\", \\\"{x:131,y:450,t:1527793587644};\\\", \\\"{x:137,y:449,t:1527793587660};\\\", \\\"{x:143,y:448,t:1527793587677};\\\", \\\"{x:168,y:452,t:1527793587694};\\\", \\\"{x:178,y:458,t:1527793587711};\\\", \\\"{x:199,y:466,t:1527793587728};\\\", \\\"{x:228,y:477,t:1527793587744};\\\", \\\"{x:242,y:483,t:1527793587761};\\\", \\\"{x:250,y:485,t:1527793587778};\\\", \\\"{x:261,y:485,t:1527793587793};\\\", \\\"{x:270,y:485,t:1527793587811};\\\", \\\"{x:286,y:485,t:1527793587826};\\\", \\\"{x:299,y:485,t:1527793587844};\\\", \\\"{x:316,y:485,t:1527793587860};\\\", \\\"{x:328,y:486,t:1527793587878};\\\", \\\"{x:334,y:486,t:1527793587894};\\\", \\\"{x:338,y:487,t:1527793587911};\\\", \\\"{x:340,y:487,t:1527793587928};\\\", \\\"{x:342,y:486,t:1527793587967};\\\", \\\"{x:344,y:486,t:1527793587982};\\\", \\\"{x:346,y:486,t:1527793587994};\\\", \\\"{x:351,y:484,t:1527793588010};\\\", \\\"{x:357,y:483,t:1527793588029};\\\", \\\"{x:359,y:482,t:1527793588044};\\\", \\\"{x:364,y:480,t:1527793588060};\\\", \\\"{x:368,y:478,t:1527793588078};\\\", \\\"{x:369,y:478,t:1527793588093};\\\", \\\"{x:369,y:477,t:1527793588110};\\\", \\\"{x:371,y:477,t:1527793588128};\\\", \\\"{x:372,y:475,t:1527793588144};\\\", \\\"{x:373,y:475,t:1527793588160};\\\", \\\"{x:374,y:475,t:1527793588206};\\\", \\\"{x:375,y:474,t:1527793588213};\\\", \\\"{x:376,y:473,t:1527793588229};\\\", \\\"{x:378,y:472,t:1527793588253};\\\", \\\"{x:379,y:472,t:1527793588294};\\\", \\\"{x:381,y:472,t:1527793592919};\\\", \\\"{x:387,y:472,t:1527793592931};\\\", \\\"{x:416,y:474,t:1527793592949};\\\", \\\"{x:461,y:485,t:1527793592963};\\\", \\\"{x:507,y:503,t:1527793592979};\\\", \\\"{x:541,y:530,t:1527793592995};\\\", \\\"{x:554,y:554,t:1527793593012};\\\", \\\"{x:557,y:578,t:1527793593029};\\\", \\\"{x:557,y:598,t:1527793593045};\\\", \\\"{x:551,y:624,t:1527793593062};\\\", \\\"{x:550,y:663,t:1527793593080};\\\", \\\"{x:550,y:700,t:1527793593095};\\\", \\\"{x:550,y:722,t:1527793593112};\\\", \\\"{x:549,y:736,t:1527793593129};\\\", \\\"{x:549,y:737,t:1527793593145};\\\", \\\"{x:549,y:734,t:1527793593195};\\\", \\\"{x:547,y:726,t:1527793593212};\\\", \\\"{x:543,y:718,t:1527793593229};\\\", \\\"{x:538,y:710,t:1527793593245};\\\", \\\"{x:533,y:706,t:1527793593262};\\\", \\\"{x:532,y:701,t:1527793593278};\\\", \\\"{x:525,y:689,t:1527793593295};\\\", \\\"{x:523,y:683,t:1527793593312};\\\", \\\"{x:521,y:679,t:1527793593328};\\\", \\\"{x:520,y:673,t:1527793593345};\\\", \\\"{x:520,y:669,t:1527793593362};\\\", \\\"{x:520,y:668,t:1527793593379};\\\", \\\"{x:520,y:667,t:1527793593516};\\\", \\\"{x:520,y:666,t:1527793595892};\\\" ] }, { \\\"rt\\\": 17679, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 143433, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -Z -Z -Z -D -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:664,t:1527793600555};\\\", \\\"{x:520,y:662,t:1527793600875};\\\", \\\"{x:520,y:661,t:1527793601324};\\\", \\\"{x:520,y:660,t:1527793601355};\\\", \\\"{x:520,y:659,t:1527793601404};\\\", \\\"{x:520,y:658,t:1527793601419};\\\", \\\"{x:520,y:656,t:1527793601436};\\\", \\\"{x:520,y:653,t:1527793601453};\\\", \\\"{x:520,y:650,t:1527793601469};\\\", \\\"{x:520,y:647,t:1527793601486};\\\", \\\"{x:520,y:644,t:1527793601503};\\\", \\\"{x:521,y:639,t:1527793601518};\\\", \\\"{x:524,y:635,t:1527793601535};\\\", \\\"{x:525,y:626,t:1527793601553};\\\", \\\"{x:529,y:620,t:1527793601568};\\\", \\\"{x:530,y:617,t:1527793601585};\\\", \\\"{x:531,y:615,t:1527793601602};\\\", \\\"{x:531,y:613,t:1527793601634};\\\", \\\"{x:531,y:612,t:1527793601650};\\\", \\\"{x:532,y:609,t:1527793601659};\\\", \\\"{x:532,y:608,t:1527793601674};\\\", \\\"{x:532,y:607,t:1527793603123};\\\", \\\"{x:532,y:606,t:1527793603531};\\\", \\\"{x:533,y:606,t:1527793603539};\\\", \\\"{x:535,y:606,t:1527793603554};\\\", \\\"{x:554,y:606,t:1527793603571};\\\", \\\"{x:587,y:609,t:1527793603587};\\\", \\\"{x:647,y:618,t:1527793603603};\\\", \\\"{x:730,y:631,t:1527793603621};\\\", \\\"{x:838,y:645,t:1527793603637};\\\", \\\"{x:939,y:661,t:1527793603654};\\\", \\\"{x:1044,y:675,t:1527793603671};\\\", \\\"{x:1141,y:691,t:1527793603688};\\\", \\\"{x:1224,y:709,t:1527793603704};\\\", \\\"{x:1280,y:719,t:1527793603720};\\\", \\\"{x:1315,y:725,t:1527793603738};\\\", \\\"{x:1344,y:734,t:1527793603754};\\\", \\\"{x:1364,y:739,t:1527793603771};\\\", \\\"{x:1371,y:743,t:1527793603787};\\\", \\\"{x:1377,y:744,t:1527793603804};\\\", \\\"{x:1383,y:745,t:1527793603821};\\\", \\\"{x:1384,y:745,t:1527793603838};\\\", \\\"{x:1385,y:745,t:1527793603853};\\\", \\\"{x:1385,y:746,t:1527793603891};\\\", \\\"{x:1385,y:748,t:1527793603915};\\\", \\\"{x:1385,y:749,t:1527793603932};\\\", \\\"{x:1385,y:751,t:1527793603947};\\\", \\\"{x:1385,y:753,t:1527793603955};\\\", \\\"{x:1389,y:757,t:1527793603971};\\\", \\\"{x:1392,y:760,t:1527793603987};\\\", \\\"{x:1394,y:762,t:1527793604003};\\\", \\\"{x:1396,y:763,t:1527793604020};\\\", \\\"{x:1398,y:764,t:1527793604038};\\\", \\\"{x:1402,y:766,t:1527793604055};\\\", \\\"{x:1407,y:766,t:1527793604072};\\\", \\\"{x:1411,y:767,t:1527793604088};\\\", \\\"{x:1414,y:767,t:1527793604105};\\\", \\\"{x:1415,y:767,t:1527793604121};\\\", \\\"{x:1416,y:767,t:1527793604172};\\\", \\\"{x:1418,y:767,t:1527793604188};\\\", \\\"{x:1420,y:767,t:1527793604205};\\\", \\\"{x:1423,y:768,t:1527793604221};\\\", \\\"{x:1424,y:768,t:1527793604238};\\\", \\\"{x:1427,y:769,t:1527793604255};\\\", \\\"{x:1434,y:769,t:1527793604271};\\\", \\\"{x:1440,y:771,t:1527793604288};\\\", \\\"{x:1447,y:771,t:1527793604304};\\\", \\\"{x:1452,y:772,t:1527793604321};\\\", \\\"{x:1462,y:776,t:1527793604338};\\\", \\\"{x:1474,y:779,t:1527793604355};\\\", \\\"{x:1483,y:782,t:1527793604373};\\\", \\\"{x:1487,y:783,t:1527793604389};\\\", \\\"{x:1490,y:783,t:1527793604405};\\\", \\\"{x:1494,y:783,t:1527793604421};\\\", \\\"{x:1496,y:783,t:1527793604467};\\\", \\\"{x:1498,y:783,t:1527793604476};\\\", \\\"{x:1501,y:783,t:1527793604488};\\\", \\\"{x:1508,y:783,t:1527793604505};\\\", \\\"{x:1516,y:783,t:1527793604521};\\\", \\\"{x:1522,y:783,t:1527793604538};\\\", \\\"{x:1525,y:783,t:1527793604555};\\\", \\\"{x:1521,y:783,t:1527793604603};\\\", \\\"{x:1514,y:782,t:1527793604611};\\\", \\\"{x:1506,y:780,t:1527793604622};\\\", \\\"{x:1497,y:780,t:1527793604638};\\\", \\\"{x:1488,y:780,t:1527793604655};\\\", \\\"{x:1476,y:780,t:1527793604672};\\\", \\\"{x:1461,y:780,t:1527793604688};\\\", \\\"{x:1444,y:783,t:1527793604705};\\\", \\\"{x:1424,y:785,t:1527793604722};\\\", \\\"{x:1406,y:789,t:1527793604738};\\\", \\\"{x:1392,y:797,t:1527793604755};\\\", \\\"{x:1386,y:803,t:1527793604771};\\\", \\\"{x:1374,y:815,t:1527793604787};\\\", \\\"{x:1363,y:825,t:1527793604804};\\\", \\\"{x:1360,y:828,t:1527793604821};\\\", \\\"{x:1356,y:832,t:1527793604837};\\\", \\\"{x:1351,y:835,t:1527793604854};\\\", \\\"{x:1348,y:836,t:1527793604872};\\\", \\\"{x:1347,y:837,t:1527793604888};\\\", \\\"{x:1345,y:838,t:1527793604904};\\\", \\\"{x:1344,y:839,t:1527793604922};\\\", \\\"{x:1343,y:840,t:1527793604938};\\\", \\\"{x:1342,y:841,t:1527793604955};\\\", \\\"{x:1342,y:842,t:1527793604972};\\\", \\\"{x:1343,y:842,t:1527793605123};\\\", \\\"{x:1344,y:841,t:1527793605138};\\\", \\\"{x:1351,y:838,t:1527793605156};\\\", \\\"{x:1355,y:836,t:1527793605172};\\\", \\\"{x:1359,y:834,t:1527793605188};\\\", \\\"{x:1363,y:833,t:1527793605205};\\\", \\\"{x:1365,y:832,t:1527793605222};\\\", \\\"{x:1368,y:830,t:1527793605239};\\\", \\\"{x:1373,y:827,t:1527793605255};\\\", \\\"{x:1382,y:822,t:1527793605271};\\\", \\\"{x:1391,y:817,t:1527793605289};\\\", \\\"{x:1399,y:813,t:1527793605305};\\\", \\\"{x:1405,y:811,t:1527793605322};\\\", \\\"{x:1420,y:802,t:1527793605339};\\\", \\\"{x:1428,y:797,t:1527793605355};\\\", \\\"{x:1442,y:786,t:1527793605372};\\\", \\\"{x:1456,y:773,t:1527793605389};\\\", \\\"{x:1470,y:761,t:1527793605404};\\\", \\\"{x:1484,y:747,t:1527793605422};\\\", \\\"{x:1494,y:735,t:1527793605438};\\\", \\\"{x:1504,y:721,t:1527793605455};\\\", \\\"{x:1514,y:704,t:1527793605472};\\\", \\\"{x:1524,y:690,t:1527793605489};\\\", \\\"{x:1529,y:682,t:1527793605506};\\\", \\\"{x:1534,y:670,t:1527793605521};\\\", \\\"{x:1544,y:653,t:1527793605539};\\\", \\\"{x:1547,y:644,t:1527793605555};\\\", \\\"{x:1550,y:637,t:1527793605572};\\\", \\\"{x:1553,y:626,t:1527793605589};\\\", \\\"{x:1556,y:614,t:1527793605605};\\\", \\\"{x:1558,y:601,t:1527793605622};\\\", \\\"{x:1559,y:587,t:1527793605638};\\\", \\\"{x:1562,y:573,t:1527793605656};\\\", \\\"{x:1564,y:558,t:1527793605671};\\\", \\\"{x:1567,y:537,t:1527793605688};\\\", \\\"{x:1569,y:516,t:1527793605706};\\\", \\\"{x:1572,y:498,t:1527793605722};\\\", \\\"{x:1579,y:469,t:1527793605739};\\\", \\\"{x:1583,y:454,t:1527793605755};\\\", \\\"{x:1586,y:444,t:1527793605771};\\\", \\\"{x:1589,y:434,t:1527793605788};\\\", \\\"{x:1591,y:423,t:1527793605806};\\\", \\\"{x:1591,y:417,t:1527793605822};\\\", \\\"{x:1592,y:414,t:1527793605839};\\\", \\\"{x:1594,y:408,t:1527793605856};\\\", \\\"{x:1598,y:400,t:1527793605872};\\\", \\\"{x:1601,y:394,t:1527793605889};\\\", \\\"{x:1602,y:391,t:1527793605906};\\\", \\\"{x:1603,y:389,t:1527793605922};\\\", \\\"{x:1605,y:387,t:1527793605939};\\\", \\\"{x:1605,y:386,t:1527793605956};\\\", \\\"{x:1605,y:384,t:1527793605972};\\\", \\\"{x:1606,y:384,t:1527793606036};\\\", \\\"{x:1606,y:383,t:1527793606043};\\\", \\\"{x:1607,y:383,t:1527793606056};\\\", \\\"{x:1608,y:381,t:1527793606073};\\\", \\\"{x:1610,y:379,t:1527793606089};\\\", \\\"{x:1611,y:379,t:1527793606163};\\\", \\\"{x:1607,y:380,t:1527793606396};\\\", \\\"{x:1605,y:386,t:1527793606405};\\\", \\\"{x:1600,y:402,t:1527793606423};\\\", \\\"{x:1596,y:419,t:1527793606439};\\\", \\\"{x:1594,y:433,t:1527793606455};\\\", \\\"{x:1590,y:445,t:1527793606473};\\\", \\\"{x:1589,y:459,t:1527793606489};\\\", \\\"{x:1583,y:488,t:1527793606506};\\\", \\\"{x:1563,y:557,t:1527793606523};\\\", \\\"{x:1552,y:597,t:1527793606539};\\\", \\\"{x:1544,y:620,t:1527793606556};\\\", \\\"{x:1536,y:642,t:1527793606573};\\\", \\\"{x:1529,y:659,t:1527793606590};\\\", \\\"{x:1521,y:676,t:1527793606606};\\\", \\\"{x:1512,y:696,t:1527793606623};\\\", \\\"{x:1507,y:708,t:1527793606640};\\\", \\\"{x:1503,y:716,t:1527793606656};\\\", \\\"{x:1497,y:722,t:1527793606673};\\\", \\\"{x:1491,y:728,t:1527793606690};\\\", \\\"{x:1485,y:732,t:1527793606706};\\\", \\\"{x:1479,y:736,t:1527793606723};\\\", \\\"{x:1475,y:740,t:1527793606740};\\\", \\\"{x:1471,y:742,t:1527793606756};\\\", \\\"{x:1466,y:747,t:1527793606773};\\\", \\\"{x:1461,y:749,t:1527793606791};\\\", \\\"{x:1453,y:755,t:1527793606805};\\\", \\\"{x:1447,y:760,t:1527793606823};\\\", \\\"{x:1441,y:766,t:1527793606839};\\\", \\\"{x:1436,y:772,t:1527793606856};\\\", \\\"{x:1433,y:777,t:1527793606873};\\\", \\\"{x:1432,y:779,t:1527793606891};\\\", \\\"{x:1431,y:782,t:1527793606906};\\\", \\\"{x:1431,y:784,t:1527793606923};\\\", \\\"{x:1430,y:785,t:1527793606940};\\\", \\\"{x:1430,y:786,t:1527793606963};\\\", \\\"{x:1430,y:787,t:1527793606973};\\\", \\\"{x:1430,y:788,t:1527793606995};\\\", \\\"{x:1429,y:789,t:1527793607007};\\\", \\\"{x:1429,y:790,t:1527793607131};\\\", \\\"{x:1430,y:789,t:1527793607188};\\\", \\\"{x:1436,y:786,t:1527793607195};\\\", \\\"{x:1446,y:778,t:1527793607207};\\\", \\\"{x:1470,y:751,t:1527793607223};\\\", \\\"{x:1500,y:713,t:1527793607240};\\\", \\\"{x:1529,y:657,t:1527793607257};\\\", \\\"{x:1547,y:588,t:1527793607273};\\\", \\\"{x:1561,y:509,t:1527793607290};\\\", \\\"{x:1564,y:441,t:1527793607307};\\\", \\\"{x:1566,y:419,t:1527793607323};\\\", \\\"{x:1569,y:404,t:1527793607340};\\\", \\\"{x:1569,y:396,t:1527793607357};\\\", \\\"{x:1569,y:391,t:1527793607373};\\\", \\\"{x:1569,y:386,t:1527793607391};\\\", \\\"{x:1569,y:384,t:1527793607407};\\\", \\\"{x:1572,y:378,t:1527793607424};\\\", \\\"{x:1572,y:374,t:1527793607440};\\\", \\\"{x:1573,y:368,t:1527793607457};\\\", \\\"{x:1575,y:359,t:1527793607473};\\\", \\\"{x:1578,y:356,t:1527793607490};\\\", \\\"{x:1581,y:352,t:1527793607507};\\\", \\\"{x:1582,y:351,t:1527793607523};\\\", \\\"{x:1584,y:349,t:1527793607540};\\\", \\\"{x:1592,y:343,t:1527793607557};\\\", \\\"{x:1599,y:339,t:1527793607574};\\\", \\\"{x:1602,y:338,t:1527793607590};\\\", \\\"{x:1603,y:338,t:1527793607619};\\\", \\\"{x:1605,y:338,t:1527793607627};\\\", \\\"{x:1605,y:339,t:1527793607643};\\\", \\\"{x:1605,y:342,t:1527793607657};\\\", \\\"{x:1605,y:345,t:1527793607674};\\\", \\\"{x:1605,y:349,t:1527793607691};\\\", \\\"{x:1608,y:358,t:1527793607707};\\\", \\\"{x:1608,y:364,t:1527793607724};\\\", \\\"{x:1608,y:376,t:1527793607741};\\\", \\\"{x:1608,y:391,t:1527793607757};\\\", \\\"{x:1611,y:406,t:1527793607774};\\\", \\\"{x:1614,y:420,t:1527793607790};\\\", \\\"{x:1619,y:436,t:1527793607806};\\\", \\\"{x:1627,y:449,t:1527793607823};\\\", \\\"{x:1631,y:460,t:1527793607840};\\\", \\\"{x:1631,y:464,t:1527793607856};\\\", \\\"{x:1631,y:465,t:1527793607873};\\\", \\\"{x:1631,y:467,t:1527793607891};\\\", \\\"{x:1631,y:468,t:1527793607907};\\\", \\\"{x:1631,y:470,t:1527793607923};\\\", \\\"{x:1631,y:471,t:1527793607941};\\\", \\\"{x:1630,y:474,t:1527793607957};\\\", \\\"{x:1629,y:476,t:1527793607974};\\\", \\\"{x:1627,y:480,t:1527793607991};\\\", \\\"{x:1625,y:484,t:1527793608007};\\\", \\\"{x:1622,y:489,t:1527793608024};\\\", \\\"{x:1619,y:495,t:1527793608040};\\\", \\\"{x:1615,y:502,t:1527793608057};\\\", \\\"{x:1611,y:508,t:1527793608074};\\\", \\\"{x:1609,y:513,t:1527793608091};\\\", \\\"{x:1607,y:515,t:1527793608107};\\\", \\\"{x:1606,y:516,t:1527793608147};\\\", \\\"{x:1608,y:517,t:1527793608932};\\\", \\\"{x:1610,y:517,t:1527793608947};\\\", \\\"{x:1611,y:517,t:1527793608971};\\\", \\\"{x:1612,y:517,t:1527793609052};\\\", \\\"{x:1613,y:517,t:1527793609059};\\\", \\\"{x:1614,y:517,t:1527793609075};\\\", \\\"{x:1615,y:517,t:1527793609099};\\\", \\\"{x:1613,y:517,t:1527793613372};\\\", \\\"{x:1605,y:517,t:1527793613379};\\\", \\\"{x:1590,y:517,t:1527793613394};\\\", \\\"{x:1460,y:515,t:1527793613411};\\\", \\\"{x:1341,y:501,t:1527793613428};\\\", \\\"{x:1207,y:490,t:1527793613444};\\\", \\\"{x:1056,y:480,t:1527793613462};\\\", \\\"{x:926,y:480,t:1527793613479};\\\", \\\"{x:826,y:478,t:1527793613494};\\\", \\\"{x:759,y:478,t:1527793613511};\\\", \\\"{x:719,y:478,t:1527793613528};\\\", \\\"{x:694,y:481,t:1527793613544};\\\", \\\"{x:676,y:488,t:1527793613563};\\\", \\\"{x:649,y:497,t:1527793613579};\\\", \\\"{x:638,y:498,t:1527793613595};\\\", \\\"{x:631,y:501,t:1527793613611};\\\", \\\"{x:624,y:503,t:1527793613628};\\\", \\\"{x:622,y:503,t:1527793613646};\\\", \\\"{x:619,y:505,t:1527793613662};\\\", \\\"{x:618,y:506,t:1527793614284};\\\", \\\"{x:618,y:507,t:1527793614296};\\\", \\\"{x:618,y:512,t:1527793614313};\\\", \\\"{x:618,y:519,t:1527793614331};\\\", \\\"{x:618,y:521,t:1527793614346};\\\", \\\"{x:618,y:523,t:1527793614363};\\\", \\\"{x:618,y:529,t:1527793614381};\\\", \\\"{x:629,y:540,t:1527793614396};\\\", \\\"{x:647,y:551,t:1527793614412};\\\", \\\"{x:675,y:559,t:1527793614429};\\\", \\\"{x:702,y:565,t:1527793614446};\\\", \\\"{x:723,y:566,t:1527793614463};\\\", \\\"{x:735,y:566,t:1527793614478};\\\", \\\"{x:739,y:566,t:1527793614495};\\\", \\\"{x:743,y:566,t:1527793614513};\\\", \\\"{x:748,y:564,t:1527793614529};\\\", \\\"{x:748,y:562,t:1527793614546};\\\", \\\"{x:748,y:560,t:1527793614563};\\\", \\\"{x:743,y:556,t:1527793614579};\\\", \\\"{x:724,y:553,t:1527793614595};\\\", \\\"{x:694,y:547,t:1527793614613};\\\", \\\"{x:652,y:547,t:1527793614629};\\\", \\\"{x:575,y:547,t:1527793614646};\\\", \\\"{x:467,y:547,t:1527793614664};\\\", \\\"{x:375,y:547,t:1527793614680};\\\", \\\"{x:314,y:547,t:1527793614696};\\\", \\\"{x:288,y:547,t:1527793614713};\\\", \\\"{x:280,y:547,t:1527793614729};\\\", \\\"{x:284,y:548,t:1527793614753};\\\", \\\"{x:287,y:549,t:1527793614762};\\\", \\\"{x:291,y:551,t:1527793614779};\\\", \\\"{x:292,y:551,t:1527793614795};\\\", \\\"{x:295,y:551,t:1527793614812};\\\", \\\"{x:298,y:551,t:1527793614830};\\\", \\\"{x:302,y:547,t:1527793614845};\\\", \\\"{x:309,y:540,t:1527793614862};\\\", \\\"{x:326,y:530,t:1527793614879};\\\", \\\"{x:346,y:521,t:1527793614896};\\\", \\\"{x:360,y:514,t:1527793614913};\\\", \\\"{x:376,y:509,t:1527793614931};\\\", \\\"{x:387,y:504,t:1527793614947};\\\", \\\"{x:385,y:504,t:1527793615051};\\\", \\\"{x:379,y:506,t:1527793615064};\\\", \\\"{x:360,y:513,t:1527793615081};\\\", \\\"{x:330,y:524,t:1527793615097};\\\", \\\"{x:306,y:529,t:1527793615113};\\\", \\\"{x:289,y:535,t:1527793615129};\\\", \\\"{x:271,y:537,t:1527793615147};\\\", \\\"{x:264,y:539,t:1527793615162};\\\", \\\"{x:259,y:543,t:1527793615180};\\\", \\\"{x:254,y:548,t:1527793615196};\\\", \\\"{x:248,y:553,t:1527793615213};\\\", \\\"{x:244,y:556,t:1527793615230};\\\", \\\"{x:239,y:556,t:1527793615247};\\\", \\\"{x:233,y:559,t:1527793615263};\\\", \\\"{x:229,y:560,t:1527793615281};\\\", \\\"{x:221,y:563,t:1527793615297};\\\", \\\"{x:217,y:564,t:1527793615313};\\\", \\\"{x:211,y:567,t:1527793615330};\\\", \\\"{x:200,y:569,t:1527793615346};\\\", \\\"{x:192,y:574,t:1527793615364};\\\", \\\"{x:185,y:579,t:1527793615380};\\\", \\\"{x:179,y:583,t:1527793615396};\\\", \\\"{x:177,y:586,t:1527793615413};\\\", \\\"{x:175,y:587,t:1527793615430};\\\", \\\"{x:173,y:589,t:1527793615447};\\\", \\\"{x:167,y:593,t:1527793615463};\\\", \\\"{x:163,y:595,t:1527793615480};\\\", \\\"{x:161,y:595,t:1527793615497};\\\", \\\"{x:160,y:596,t:1527793615513};\\\", \\\"{x:160,y:595,t:1527793615675};\\\", \\\"{x:161,y:595,t:1527793615683};\\\", \\\"{x:162,y:595,t:1527793615698};\\\", \\\"{x:165,y:594,t:1527793616075};\\\", \\\"{x:173,y:592,t:1527793616083};\\\", \\\"{x:183,y:591,t:1527793616099};\\\", \\\"{x:217,y:590,t:1527793616115};\\\", \\\"{x:310,y:594,t:1527793616133};\\\", \\\"{x:393,y:617,t:1527793616148};\\\", \\\"{x:449,y:628,t:1527793616163};\\\", \\\"{x:476,y:630,t:1527793616181};\\\", \\\"{x:495,y:634,t:1527793616197};\\\", \\\"{x:500,y:635,t:1527793616214};\\\", \\\"{x:500,y:634,t:1527793616363};\\\", \\\"{x:498,y:633,t:1527793616370};\\\", \\\"{x:493,y:630,t:1527793616381};\\\", \\\"{x:469,y:622,t:1527793616398};\\\", \\\"{x:405,y:605,t:1527793616416};\\\", \\\"{x:304,y:583,t:1527793616432};\\\", \\\"{x:206,y:564,t:1527793616449};\\\", \\\"{x:142,y:555,t:1527793616465};\\\", \\\"{x:118,y:555,t:1527793616481};\\\", \\\"{x:109,y:555,t:1527793616498};\\\", \\\"{x:105,y:555,t:1527793616514};\\\", \\\"{x:104,y:556,t:1527793616531};\\\", \\\"{x:104,y:558,t:1527793616554};\\\", \\\"{x:104,y:559,t:1527793616564};\\\", \\\"{x:99,y:562,t:1527793616582};\\\", \\\"{x:93,y:565,t:1527793616598};\\\", \\\"{x:91,y:568,t:1527793616616};\\\", \\\"{x:91,y:573,t:1527793616631};\\\", \\\"{x:98,y:581,t:1527793616647};\\\", \\\"{x:111,y:589,t:1527793616665};\\\", \\\"{x:121,y:594,t:1527793616681};\\\", \\\"{x:128,y:595,t:1527793616698};\\\", \\\"{x:142,y:593,t:1527793616714};\\\", \\\"{x:156,y:587,t:1527793616731};\\\", \\\"{x:168,y:580,t:1527793616747};\\\", \\\"{x:177,y:573,t:1527793616766};\\\", \\\"{x:184,y:570,t:1527793616781};\\\", \\\"{x:184,y:569,t:1527793617050};\\\", \\\"{x:183,y:569,t:1527793617122};\\\", \\\"{x:181,y:569,t:1527793617132};\\\", \\\"{x:178,y:569,t:1527793617148};\\\", \\\"{x:174,y:571,t:1527793617165};\\\", \\\"{x:174,y:576,t:1527793617182};\\\", \\\"{x:179,y:582,t:1527793617198};\\\", \\\"{x:193,y:590,t:1527793617215};\\\", \\\"{x:207,y:595,t:1527793617231};\\\", \\\"{x:229,y:599,t:1527793617248};\\\", \\\"{x:269,y:612,t:1527793617265};\\\", \\\"{x:336,y:631,t:1527793617282};\\\", \\\"{x:412,y:655,t:1527793617298};\\\", \\\"{x:476,y:676,t:1527793617316};\\\", \\\"{x:494,y:684,t:1527793617332};\\\", \\\"{x:497,y:684,t:1527793617348};\\\", \\\"{x:498,y:683,t:1527793617395};\\\", \\\"{x:498,y:681,t:1527793617411};\\\", \\\"{x:498,y:679,t:1527793617418};\\\", \\\"{x:498,y:677,t:1527793617432};\\\", \\\"{x:498,y:676,t:1527793617682};\\\", \\\"{x:498,y:675,t:1527793617770};\\\", \\\"{x:498,y:674,t:1527793617834};\\\", \\\"{x:499,y:674,t:1527793617849};\\\", \\\"{x:508,y:671,t:1527793617865};\\\", \\\"{x:513,y:667,t:1527793617882};\\\", \\\"{x:513,y:666,t:1527793617900};\\\" ] }, { \\\"rt\\\": 41898, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 186647, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:666,t:1527793619562};\\\", \\\"{x:515,y:665,t:1527793619570};\\\", \\\"{x:518,y:665,t:1527793619586};\\\", \\\"{x:528,y:664,t:1527793619602};\\\", \\\"{x:599,y:664,t:1527793619619};\\\", \\\"{x:682,y:664,t:1527793619634};\\\", \\\"{x:779,y:664,t:1527793619650};\\\", \\\"{x:882,y:664,t:1527793619666};\\\", \\\"{x:979,y:665,t:1527793619683};\\\", \\\"{x:1052,y:677,t:1527793619701};\\\", \\\"{x:1098,y:684,t:1527793619716};\\\", \\\"{x:1120,y:689,t:1527793619734};\\\", \\\"{x:1127,y:691,t:1527793619750};\\\", \\\"{x:1128,y:692,t:1527793619766};\\\", \\\"{x:1128,y:694,t:1527793619794};\\\", \\\"{x:1127,y:694,t:1527793619802};\\\", \\\"{x:1126,y:694,t:1527793619816};\\\", \\\"{x:1121,y:694,t:1527793619833};\\\", \\\"{x:1116,y:694,t:1527793619850};\\\", \\\"{x:1112,y:694,t:1527793619866};\\\", \\\"{x:1106,y:694,t:1527793619884};\\\", \\\"{x:1101,y:694,t:1527793619901};\\\", \\\"{x:1099,y:695,t:1527793619916};\\\", \\\"{x:1098,y:695,t:1527793619933};\\\", \\\"{x:1097,y:695,t:1527793619970};\\\", \\\"{x:1095,y:695,t:1527793621435};\\\", \\\"{x:1092,y:695,t:1527793621450};\\\", \\\"{x:1087,y:695,t:1527793621467};\\\", \\\"{x:1083,y:695,t:1527793621484};\\\", \\\"{x:1080,y:694,t:1527793621501};\\\", \\\"{x:1076,y:693,t:1527793621516};\\\", \\\"{x:1073,y:693,t:1527793621533};\\\", \\\"{x:1069,y:692,t:1527793621551};\\\", \\\"{x:1063,y:692,t:1527793621567};\\\", \\\"{x:1050,y:688,t:1527793621583};\\\", \\\"{x:1030,y:685,t:1527793621601};\\\", \\\"{x:1009,y:684,t:1527793621617};\\\", \\\"{x:989,y:684,t:1527793621634};\\\", \\\"{x:961,y:684,t:1527793621651};\\\", \\\"{x:946,y:684,t:1527793621667};\\\", \\\"{x:938,y:684,t:1527793621683};\\\", \\\"{x:933,y:684,t:1527793621701};\\\", \\\"{x:930,y:683,t:1527793621716};\\\", \\\"{x:925,y:683,t:1527793621733};\\\", \\\"{x:923,y:683,t:1527793621750};\\\", \\\"{x:922,y:683,t:1527793621771};\\\", \\\"{x:921,y:683,t:1527793621859};\\\", \\\"{x:920,y:682,t:1527793623763};\\\", \\\"{x:919,y:682,t:1527793625371};\\\", \\\"{x:919,y:683,t:1527793625386};\\\", \\\"{x:918,y:683,t:1527793625500};\\\", \\\"{x:917,y:683,t:1527793625555};\\\", \\\"{x:916,y:683,t:1527793625675};\\\", \\\"{x:915,y:683,t:1527793626291};\\\", \\\"{x:914,y:683,t:1527793628836};\\\", \\\"{x:915,y:683,t:1527793643178};\\\", \\\"{x:916,y:682,t:1527793647411};\\\", \\\"{x:916,y:681,t:1527793647611};\\\", \\\"{x:915,y:681,t:1527793649051};\\\", \\\"{x:913,y:681,t:1527793649066};\\\", \\\"{x:912,y:681,t:1527793649075};\\\", \\\"{x:920,y:681,t:1527793649179};\\\", \\\"{x:927,y:681,t:1527793649186};\\\", \\\"{x:955,y:681,t:1527793649203};\\\", \\\"{x:993,y:685,t:1527793649220};\\\", \\\"{x:1060,y:693,t:1527793649236};\\\", \\\"{x:1136,y:708,t:1527793649253};\\\", \\\"{x:1222,y:719,t:1527793649269};\\\", \\\"{x:1311,y:734,t:1527793649286};\\\", \\\"{x:1394,y:745,t:1527793649303};\\\", \\\"{x:1458,y:761,t:1527793649319};\\\", \\\"{x:1501,y:775,t:1527793649336};\\\", \\\"{x:1522,y:783,t:1527793649353};\\\", \\\"{x:1524,y:785,t:1527793649369};\\\", \\\"{x:1523,y:785,t:1527793649395};\\\", \\\"{x:1518,y:785,t:1527793649403};\\\", \\\"{x:1504,y:785,t:1527793649419};\\\", \\\"{x:1488,y:784,t:1527793649435};\\\", \\\"{x:1481,y:781,t:1527793649455};\\\", \\\"{x:1469,y:778,t:1527793649469};\\\", \\\"{x:1462,y:774,t:1527793649485};\\\", \\\"{x:1456,y:772,t:1527793649502};\\\", \\\"{x:1449,y:770,t:1527793649518};\\\", \\\"{x:1437,y:768,t:1527793649536};\\\", \\\"{x:1417,y:766,t:1527793649552};\\\", \\\"{x:1400,y:763,t:1527793649568};\\\", \\\"{x:1394,y:763,t:1527793649586};\\\", \\\"{x:1393,y:763,t:1527793649659};\\\", \\\"{x:1390,y:763,t:1527793649668};\\\", \\\"{x:1383,y:763,t:1527793649685};\\\", \\\"{x:1371,y:763,t:1527793649702};\\\", \\\"{x:1357,y:763,t:1527793649719};\\\", \\\"{x:1343,y:763,t:1527793649736};\\\", \\\"{x:1334,y:763,t:1527793649753};\\\", \\\"{x:1327,y:763,t:1527793649769};\\\", \\\"{x:1322,y:763,t:1527793649786};\\\", \\\"{x:1314,y:763,t:1527793649803};\\\", \\\"{x:1311,y:763,t:1527793649818};\\\", \\\"{x:1308,y:763,t:1527793649836};\\\", \\\"{x:1306,y:763,t:1527793649853};\\\", \\\"{x:1305,y:763,t:1527793649869};\\\", \\\"{x:1304,y:763,t:1527793649886};\\\", \\\"{x:1302,y:763,t:1527793649903};\\\", \\\"{x:1301,y:763,t:1527793649919};\\\", \\\"{x:1300,y:763,t:1527793649936};\\\", \\\"{x:1300,y:769,t:1527793649953};\\\", \\\"{x:1300,y:772,t:1527793649969};\\\", \\\"{x:1301,y:775,t:1527793649986};\\\", \\\"{x:1301,y:776,t:1527793650003};\\\", \\\"{x:1301,y:777,t:1527793650019};\\\", \\\"{x:1299,y:777,t:1527793650036};\\\", \\\"{x:1296,y:777,t:1527793650053};\\\", \\\"{x:1294,y:777,t:1527793650075};\\\", \\\"{x:1293,y:777,t:1527793650086};\\\", \\\"{x:1291,y:777,t:1527793650115};\\\", \\\"{x:1290,y:777,t:1527793650147};\\\", \\\"{x:1289,y:777,t:1527793650187};\\\", \\\"{x:1288,y:777,t:1527793650259};\\\", \\\"{x:1287,y:777,t:1527793650269};\\\", \\\"{x:1286,y:777,t:1527793650286};\\\", \\\"{x:1285,y:777,t:1527793650302};\\\", \\\"{x:1283,y:778,t:1527793650318};\\\", \\\"{x:1281,y:779,t:1527793650355};\\\", \\\"{x:1280,y:779,t:1527793650387};\\\", \\\"{x:1283,y:779,t:1527793650563};\\\", \\\"{x:1286,y:778,t:1527793650570};\\\", \\\"{x:1284,y:778,t:1527793651475};\\\", \\\"{x:1283,y:778,t:1527793651486};\\\", \\\"{x:1278,y:780,t:1527793651503};\\\", \\\"{x:1274,y:781,t:1527793651520};\\\", \\\"{x:1267,y:781,t:1527793651536};\\\", \\\"{x:1260,y:783,t:1527793651553};\\\", \\\"{x:1255,y:783,t:1527793651569};\\\", \\\"{x:1248,y:783,t:1527793651586};\\\", \\\"{x:1241,y:785,t:1527793651603};\\\", \\\"{x:1236,y:785,t:1527793651619};\\\", \\\"{x:1235,y:785,t:1527793651650};\\\", \\\"{x:1234,y:785,t:1527793651659};\\\", \\\"{x:1233,y:785,t:1527793651683};\\\", \\\"{x:1232,y:785,t:1527793651723};\\\", \\\"{x:1231,y:785,t:1527793651737};\\\", \\\"{x:1230,y:785,t:1527793651753};\\\", \\\"{x:1228,y:785,t:1527793651769};\\\", \\\"{x:1227,y:785,t:1527793651786};\\\", \\\"{x:1225,y:785,t:1527793651803};\\\", \\\"{x:1224,y:785,t:1527793651819};\\\", \\\"{x:1223,y:785,t:1527793651867};\\\", \\\"{x:1222,y:785,t:1527793651875};\\\", \\\"{x:1221,y:785,t:1527793651887};\\\", \\\"{x:1219,y:783,t:1527793651904};\\\", \\\"{x:1218,y:781,t:1527793651920};\\\", \\\"{x:1217,y:780,t:1527793651936};\\\", \\\"{x:1217,y:779,t:1527793651954};\\\", \\\"{x:1217,y:778,t:1527793652523};\\\", \\\"{x:1217,y:777,t:1527793652536};\\\", \\\"{x:1217,y:776,t:1527793652553};\\\", \\\"{x:1217,y:775,t:1527793652619};\\\", \\\"{x:1218,y:775,t:1527793653783};\\\", \\\"{x:1218,y:773,t:1527793653799};\\\", \\\"{x:1219,y:771,t:1527793653818};\\\", \\\"{x:1222,y:765,t:1527793653831};\\\", \\\"{x:1222,y:765,t:1527793653832};\\\", \\\"{x:1224,y:760,t:1527793653849};\\\", \\\"{x:1224,y:759,t:1527793653858};\\\", \\\"{x:1227,y:755,t:1527793653876};\\\", \\\"{x:1230,y:751,t:1527793653891};\\\", \\\"{x:1231,y:748,t:1527793653908};\\\", \\\"{x:1237,y:739,t:1527793653925};\\\", \\\"{x:1242,y:728,t:1527793653942};\\\", \\\"{x:1246,y:723,t:1527793653959};\\\", \\\"{x:1246,y:722,t:1527793653975};\\\", \\\"{x:1247,y:721,t:1527793654015};\\\", \\\"{x:1248,y:719,t:1527793654031};\\\", \\\"{x:1250,y:714,t:1527793654042};\\\", \\\"{x:1252,y:710,t:1527793654059};\\\", \\\"{x:1255,y:703,t:1527793654076};\\\", \\\"{x:1257,y:696,t:1527793654093};\\\", \\\"{x:1262,y:686,t:1527793654109};\\\", \\\"{x:1272,y:668,t:1527793654126};\\\", \\\"{x:1288,y:647,t:1527793654143};\\\", \\\"{x:1299,y:628,t:1527793654159};\\\", \\\"{x:1308,y:612,t:1527793654176};\\\", \\\"{x:1312,y:607,t:1527793654193};\\\", \\\"{x:1317,y:600,t:1527793654208};\\\", \\\"{x:1324,y:587,t:1527793654226};\\\", \\\"{x:1332,y:575,t:1527793654242};\\\", \\\"{x:1339,y:559,t:1527793654258};\\\", \\\"{x:1348,y:543,t:1527793654275};\\\", \\\"{x:1353,y:533,t:1527793654293};\\\", \\\"{x:1353,y:532,t:1527793654309};\\\", \\\"{x:1353,y:539,t:1527793654687};\\\", \\\"{x:1353,y:542,t:1527793654695};\\\", \\\"{x:1355,y:542,t:1527793654767};\\\", \\\"{x:1362,y:542,t:1527793654776};\\\", \\\"{x:1378,y:535,t:1527793654793};\\\", \\\"{x:1395,y:521,t:1527793654810};\\\", \\\"{x:1407,y:504,t:1527793654826};\\\", \\\"{x:1417,y:484,t:1527793654843};\\\", \\\"{x:1431,y:445,t:1527793654860};\\\", \\\"{x:1443,y:410,t:1527793654876};\\\", \\\"{x:1452,y:386,t:1527793654893};\\\", \\\"{x:1459,y:373,t:1527793654910};\\\", \\\"{x:1462,y:365,t:1527793654926};\\\", \\\"{x:1470,y:346,t:1527793654943};\\\", \\\"{x:1475,y:326,t:1527793654960};\\\", \\\"{x:1477,y:309,t:1527793654976};\\\", \\\"{x:1480,y:298,t:1527793654993};\\\", \\\"{x:1482,y:290,t:1527793655010};\\\", \\\"{x:1484,y:284,t:1527793655026};\\\", \\\"{x:1485,y:281,t:1527793655043};\\\", \\\"{x:1489,y:270,t:1527793655060};\\\", \\\"{x:1490,y:256,t:1527793655077};\\\", \\\"{x:1493,y:241,t:1527793655094};\\\", \\\"{x:1494,y:232,t:1527793655109};\\\", \\\"{x:1496,y:225,t:1527793655127};\\\", \\\"{x:1498,y:220,t:1527793655143};\\\", \\\"{x:1499,y:210,t:1527793655159};\\\", \\\"{x:1502,y:201,t:1527793655177};\\\", \\\"{x:1503,y:194,t:1527793655193};\\\", \\\"{x:1504,y:186,t:1527793655210};\\\", \\\"{x:1504,y:182,t:1527793655227};\\\", \\\"{x:1507,y:178,t:1527793655243};\\\", \\\"{x:1507,y:176,t:1527793655260};\\\", \\\"{x:1508,y:175,t:1527793655552};\\\", \\\"{x:1509,y:175,t:1527793655560};\\\", \\\"{x:1510,y:175,t:1527793655578};\\\", \\\"{x:1510,y:174,t:1527793655594};\\\", \\\"{x:1512,y:174,t:1527793655611};\\\", \\\"{x:1513,y:174,t:1527793655627};\\\", \\\"{x:1514,y:175,t:1527793656343};\\\", \\\"{x:1514,y:178,t:1527793656351};\\\", \\\"{x:1514,y:179,t:1527793656361};\\\", \\\"{x:1514,y:187,t:1527793656378};\\\", \\\"{x:1514,y:193,t:1527793656394};\\\", \\\"{x:1514,y:199,t:1527793656411};\\\", \\\"{x:1514,y:207,t:1527793656428};\\\", \\\"{x:1514,y:223,t:1527793656444};\\\", \\\"{x:1514,y:242,t:1527793656461};\\\", \\\"{x:1514,y:259,t:1527793656478};\\\", \\\"{x:1516,y:277,t:1527793656494};\\\", \\\"{x:1518,y:290,t:1527793656511};\\\", \\\"{x:1518,y:299,t:1527793656528};\\\", \\\"{x:1519,y:309,t:1527793656544};\\\", \\\"{x:1521,y:323,t:1527793656560};\\\", \\\"{x:1522,y:336,t:1527793656579};\\\", \\\"{x:1523,y:342,t:1527793656593};\\\", \\\"{x:1523,y:345,t:1527793656611};\\\", \\\"{x:1523,y:347,t:1527793656627};\\\", \\\"{x:1523,y:352,t:1527793656644};\\\", \\\"{x:1523,y:358,t:1527793656661};\\\", \\\"{x:1523,y:365,t:1527793656679};\\\", \\\"{x:1523,y:369,t:1527793656694};\\\", \\\"{x:1523,y:373,t:1527793656711};\\\", \\\"{x:1523,y:375,t:1527793656728};\\\", \\\"{x:1523,y:376,t:1527793656745};\\\", \\\"{x:1523,y:378,t:1527793656761};\\\", \\\"{x:1523,y:382,t:1527793656779};\\\", \\\"{x:1523,y:383,t:1527793656796};\\\", \\\"{x:1523,y:384,t:1527793656811};\\\", \\\"{x:1523,y:385,t:1527793656831};\\\", \\\"{x:1524,y:384,t:1527793656992};\\\", \\\"{x:1526,y:376,t:1527793656999};\\\", \\\"{x:1526,y:365,t:1527793657011};\\\", \\\"{x:1528,y:336,t:1527793657028};\\\", \\\"{x:1532,y:295,t:1527793657045};\\\", \\\"{x:1535,y:251,t:1527793657061};\\\", \\\"{x:1536,y:211,t:1527793657078};\\\", \\\"{x:1536,y:172,t:1527793657096};\\\", \\\"{x:1536,y:148,t:1527793657111};\\\", \\\"{x:1536,y:136,t:1527793657128};\\\", \\\"{x:1536,y:133,t:1527793657145};\\\", \\\"{x:1536,y:130,t:1527793657162};\\\", \\\"{x:1536,y:129,t:1527793657178};\\\", \\\"{x:1535,y:134,t:1527793657320};\\\", \\\"{x:1532,y:146,t:1527793657328};\\\", \\\"{x:1529,y:172,t:1527793657346};\\\", \\\"{x:1527,y:191,t:1527793657362};\\\", \\\"{x:1527,y:210,t:1527793657378};\\\", \\\"{x:1527,y:225,t:1527793657395};\\\", \\\"{x:1527,y:235,t:1527793657412};\\\", \\\"{x:1527,y:245,t:1527793657429};\\\", \\\"{x:1527,y:256,t:1527793657445};\\\", \\\"{x:1527,y:264,t:1527793657462};\\\", \\\"{x:1528,y:272,t:1527793657479};\\\", \\\"{x:1528,y:277,t:1527793657496};\\\", \\\"{x:1528,y:281,t:1527793657512};\\\", \\\"{x:1529,y:285,t:1527793657529};\\\", \\\"{x:1530,y:292,t:1527793657546};\\\", \\\"{x:1532,y:299,t:1527793657562};\\\", \\\"{x:1532,y:305,t:1527793657578};\\\", \\\"{x:1532,y:311,t:1527793657595};\\\", \\\"{x:1533,y:317,t:1527793657612};\\\", \\\"{x:1534,y:325,t:1527793657630};\\\", \\\"{x:1537,y:342,t:1527793657645};\\\", \\\"{x:1538,y:357,t:1527793657662};\\\", \\\"{x:1542,y:377,t:1527793657679};\\\", \\\"{x:1542,y:386,t:1527793657696};\\\", \\\"{x:1542,y:393,t:1527793657712};\\\", \\\"{x:1542,y:401,t:1527793657729};\\\", \\\"{x:1544,y:414,t:1527793657745};\\\", \\\"{x:1546,y:424,t:1527793657762};\\\", \\\"{x:1547,y:433,t:1527793657779};\\\", \\\"{x:1547,y:440,t:1527793657794};\\\", \\\"{x:1547,y:446,t:1527793657812};\\\", \\\"{x:1547,y:449,t:1527793657829};\\\", \\\"{x:1547,y:454,t:1527793657844};\\\", \\\"{x:1546,y:465,t:1527793657862};\\\", \\\"{x:1545,y:475,t:1527793657878};\\\", \\\"{x:1543,y:484,t:1527793657895};\\\", \\\"{x:1542,y:492,t:1527793657912};\\\", \\\"{x:1542,y:496,t:1527793657929};\\\", \\\"{x:1542,y:501,t:1527793657945};\\\", \\\"{x:1542,y:503,t:1527793657962};\\\", \\\"{x:1541,y:508,t:1527793657979};\\\", \\\"{x:1540,y:518,t:1527793657995};\\\", \\\"{x:1537,y:534,t:1527793658012};\\\", \\\"{x:1536,y:547,t:1527793658029};\\\", \\\"{x:1533,y:558,t:1527793658046};\\\", \\\"{x:1533,y:565,t:1527793658062};\\\", \\\"{x:1532,y:575,t:1527793658078};\\\", \\\"{x:1532,y:579,t:1527793658095};\\\", \\\"{x:1532,y:586,t:1527793658112};\\\", \\\"{x:1532,y:590,t:1527793658129};\\\", \\\"{x:1532,y:593,t:1527793658146};\\\", \\\"{x:1532,y:594,t:1527793658167};\\\", \\\"{x:1532,y:595,t:1527793658179};\\\", \\\"{x:1532,y:597,t:1527793658196};\\\", \\\"{x:1532,y:603,t:1527793658212};\\\", \\\"{x:1532,y:608,t:1527793658228};\\\", \\\"{x:1532,y:610,t:1527793658246};\\\", \\\"{x:1533,y:611,t:1527793658261};\\\", \\\"{x:1533,y:616,t:1527793658280};\\\", \\\"{x:1533,y:621,t:1527793658295};\\\", \\\"{x:1533,y:630,t:1527793658312};\\\", \\\"{x:1534,y:636,t:1527793658330};\\\", \\\"{x:1535,y:640,t:1527793658346};\\\", \\\"{x:1535,y:641,t:1527793658368};\\\", \\\"{x:1535,y:642,t:1527793658379};\\\", \\\"{x:1536,y:644,t:1527793658395};\\\", \\\"{x:1537,y:648,t:1527793658411};\\\", \\\"{x:1537,y:650,t:1527793658429};\\\", \\\"{x:1537,y:653,t:1527793658446};\\\", \\\"{x:1540,y:655,t:1527793658461};\\\", \\\"{x:1541,y:658,t:1527793658479};\\\", \\\"{x:1541,y:659,t:1527793658664};\\\", \\\"{x:1533,y:661,t:1527793658679};\\\", \\\"{x:1509,y:658,t:1527793658696};\\\", \\\"{x:1475,y:658,t:1527793658713};\\\", \\\"{x:1404,y:663,t:1527793658729};\\\", \\\"{x:1297,y:671,t:1527793658746};\\\", \\\"{x:1178,y:671,t:1527793658762};\\\", \\\"{x:1059,y:671,t:1527793658778};\\\", \\\"{x:943,y:671,t:1527793658796};\\\", \\\"{x:860,y:662,t:1527793658813};\\\", \\\"{x:821,y:653,t:1527793658829};\\\", \\\"{x:810,y:649,t:1527793658846};\\\", \\\"{x:810,y:648,t:1527793658863};\\\", \\\"{x:810,y:642,t:1527793658879};\\\", \\\"{x:810,y:639,t:1527793658896};\\\", \\\"{x:810,y:633,t:1527793658913};\\\", \\\"{x:810,y:632,t:1527793658930};\\\", \\\"{x:809,y:630,t:1527793658945};\\\", \\\"{x:807,y:629,t:1527793658963};\\\", \\\"{x:797,y:624,t:1527793658980};\\\", \\\"{x:776,y:618,t:1527793658995};\\\", \\\"{x:729,y:604,t:1527793659013};\\\", \\\"{x:640,y:591,t:1527793659031};\\\", \\\"{x:550,y:572,t:1527793659046};\\\", \\\"{x:437,y:555,t:1527793659063};\\\", \\\"{x:391,y:547,t:1527793659080};\\\", \\\"{x:365,y:542,t:1527793659096};\\\", \\\"{x:356,y:540,t:1527793659113};\\\", \\\"{x:352,y:540,t:1527793659130};\\\", \\\"{x:350,y:540,t:1527793659145};\\\", \\\"{x:345,y:540,t:1527793659163};\\\", \\\"{x:336,y:537,t:1527793659180};\\\", \\\"{x:334,y:535,t:1527793659196};\\\", \\\"{x:334,y:534,t:1527793659212};\\\", \\\"{x:334,y:531,t:1527793659229};\\\", \\\"{x:337,y:528,t:1527793659247};\\\", \\\"{x:347,y:527,t:1527793659262};\\\", \\\"{x:357,y:528,t:1527793659280};\\\", \\\"{x:368,y:530,t:1527793659297};\\\", \\\"{x:379,y:532,t:1527793659313};\\\", \\\"{x:385,y:532,t:1527793659330};\\\", \\\"{x:389,y:533,t:1527793659346};\\\", \\\"{x:390,y:533,t:1527793659363};\\\", \\\"{x:391,y:534,t:1527793659406};\\\", \\\"{x:391,y:535,t:1527793659415};\\\", \\\"{x:391,y:536,t:1527793659431};\\\", \\\"{x:392,y:538,t:1527793659447};\\\", \\\"{x:393,y:539,t:1527793659462};\\\", \\\"{x:394,y:544,t:1527793659999};\\\", \\\"{x:398,y:555,t:1527793660014};\\\", \\\"{x:418,y:579,t:1527793660031};\\\", \\\"{x:440,y:600,t:1527793660047};\\\", \\\"{x:468,y:616,t:1527793660064};\\\", \\\"{x:488,y:628,t:1527793660079};\\\", \\\"{x:504,y:636,t:1527793660097};\\\", \\\"{x:516,y:645,t:1527793660114};\\\", \\\"{x:527,y:652,t:1527793660132};\\\", \\\"{x:534,y:657,t:1527793660147};\\\", \\\"{x:535,y:658,t:1527793660164};\\\", \\\"{x:536,y:659,t:1527793660248};\\\", \\\"{x:536,y:660,t:1527793660367};\\\", \\\"{x:536,y:661,t:1527793660407};\\\", \\\"{x:537,y:662,t:1527793661087};\\\", \\\"{x:538,y:662,t:1527793661098};\\\", \\\"{x:550,y:662,t:1527793661115};\\\", \\\"{x:567,y:663,t:1527793661131};\\\", \\\"{x:585,y:666,t:1527793661148};\\\", \\\"{x:607,y:668,t:1527793661165};\\\", \\\"{x:625,y:673,t:1527793661181};\\\", \\\"{x:634,y:673,t:1527793661198};\\\" ] }, { \\\"rt\\\": 17967, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 205846, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -E -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:635,y:673,t:1527793662758};\\\", \\\"{x:636,y:673,t:1527793662775};\\\", \\\"{x:637,y:673,t:1527793662783};\\\", \\\"{x:638,y:673,t:1527793662799};\\\", \\\"{x:639,y:673,t:1527793662817};\\\", \\\"{x:640,y:673,t:1527793662846};\\\", \\\"{x:640,y:674,t:1527793664214};\\\", \\\"{x:641,y:674,t:1527793665328};\\\", \\\"{x:642,y:674,t:1527793665352};\\\", \\\"{x:643,y:675,t:1527793665399};\\\", \\\"{x:645,y:675,t:1527793665463};\\\", \\\"{x:646,y:675,t:1527793665592};\\\", \\\"{x:647,y:675,t:1527793665639};\\\", \\\"{x:648,y:675,t:1527793665920};\\\", \\\"{x:649,y:675,t:1527793665935};\\\", \\\"{x:649,y:674,t:1527793665999};\\\", \\\"{x:649,y:672,t:1527793666007};\\\", \\\"{x:649,y:671,t:1527793666072};\\\", \\\"{x:649,y:670,t:1527793666111};\\\", \\\"{x:650,y:669,t:1527793666127};\\\", \\\"{x:651,y:669,t:1527793666191};\\\", \\\"{x:652,y:669,t:1527793666215};\\\", \\\"{x:653,y:669,t:1527793670024};\\\", \\\"{x:658,y:667,t:1527793670039};\\\", \\\"{x:666,y:657,t:1527793670055};\\\", \\\"{x:777,y:599,t:1527793670072};\\\", \\\"{x:885,y:551,t:1527793670091};\\\", \\\"{x:1005,y:507,t:1527793670104};\\\", \\\"{x:1124,y:456,t:1527793670121};\\\", \\\"{x:1226,y:411,t:1527793670138};\\\", \\\"{x:1294,y:375,t:1527793670155};\\\", \\\"{x:1336,y:340,t:1527793670172};\\\", \\\"{x:1347,y:321,t:1527793670188};\\\", \\\"{x:1349,y:308,t:1527793670206};\\\", \\\"{x:1349,y:307,t:1527793670222};\\\", \\\"{x:1353,y:304,t:1527793670239};\\\", \\\"{x:1357,y:304,t:1527793670255};\\\", \\\"{x:1366,y:304,t:1527793670272};\\\", \\\"{x:1388,y:303,t:1527793670290};\\\", \\\"{x:1440,y:303,t:1527793670306};\\\", \\\"{x:1497,y:299,t:1527793670323};\\\", \\\"{x:1517,y:300,t:1527793670339};\\\", \\\"{x:1530,y:310,t:1527793670356};\\\", \\\"{x:1545,y:328,t:1527793670372};\\\", \\\"{x:1557,y:348,t:1527793670389};\\\", \\\"{x:1567,y:365,t:1527793670405};\\\", \\\"{x:1571,y:375,t:1527793670422};\\\", \\\"{x:1576,y:382,t:1527793670439};\\\", \\\"{x:1577,y:384,t:1527793670456};\\\", \\\"{x:1577,y:385,t:1527793670488};\\\", \\\"{x:1577,y:386,t:1527793670512};\\\", \\\"{x:1579,y:386,t:1527793670552};\\\", \\\"{x:1580,y:386,t:1527793670560};\\\", \\\"{x:1583,y:386,t:1527793670573};\\\", \\\"{x:1585,y:386,t:1527793670590};\\\", \\\"{x:1586,y:386,t:1527793670608};\\\", \\\"{x:1587,y:385,t:1527793670623};\\\", \\\"{x:1590,y:385,t:1527793670639};\\\", \\\"{x:1594,y:384,t:1527793670657};\\\", \\\"{x:1596,y:384,t:1527793670673};\\\", \\\"{x:1597,y:383,t:1527793670690};\\\", \\\"{x:1598,y:383,t:1527793670707};\\\", \\\"{x:1599,y:383,t:1527793670728};\\\", \\\"{x:1601,y:383,t:1527793670740};\\\", \\\"{x:1607,y:381,t:1527793670757};\\\", \\\"{x:1611,y:380,t:1527793670776};\\\", \\\"{x:1612,y:380,t:1527793670840};\\\", \\\"{x:1612,y:381,t:1527793670952};\\\", \\\"{x:1612,y:383,t:1527793670961};\\\", \\\"{x:1612,y:386,t:1527793670974};\\\", \\\"{x:1612,y:394,t:1527793670990};\\\", \\\"{x:1612,y:403,t:1527793671007};\\\", \\\"{x:1612,y:414,t:1527793671024};\\\", \\\"{x:1612,y:423,t:1527793671041};\\\", \\\"{x:1612,y:431,t:1527793671057};\\\", \\\"{x:1612,y:436,t:1527793671074};\\\", \\\"{x:1612,y:440,t:1527793671091};\\\", \\\"{x:1612,y:448,t:1527793671107};\\\", \\\"{x:1612,y:454,t:1527793671124};\\\", \\\"{x:1612,y:461,t:1527793671141};\\\", \\\"{x:1612,y:466,t:1527793671157};\\\", \\\"{x:1612,y:470,t:1527793671173};\\\", \\\"{x:1612,y:474,t:1527793671191};\\\", \\\"{x:1612,y:478,t:1527793671207};\\\", \\\"{x:1612,y:485,t:1527793671224};\\\", \\\"{x:1612,y:491,t:1527793671242};\\\", \\\"{x:1612,y:495,t:1527793671257};\\\", \\\"{x:1611,y:497,t:1527793671274};\\\", \\\"{x:1611,y:498,t:1527793671295};\\\", \\\"{x:1611,y:499,t:1527793671308};\\\", \\\"{x:1611,y:501,t:1527793671323};\\\", \\\"{x:1611,y:506,t:1527793671341};\\\", \\\"{x:1614,y:512,t:1527793671357};\\\", \\\"{x:1614,y:515,t:1527793671374};\\\", \\\"{x:1614,y:517,t:1527793671392};\\\", \\\"{x:1614,y:518,t:1527793671408};\\\", \\\"{x:1615,y:521,t:1527793671424};\\\", \\\"{x:1616,y:525,t:1527793671441};\\\", \\\"{x:1616,y:526,t:1527793671458};\\\", \\\"{x:1616,y:527,t:1527793671474};\\\", \\\"{x:1617,y:530,t:1527793671491};\\\", \\\"{x:1617,y:531,t:1527793671512};\\\", \\\"{x:1617,y:533,t:1527793671525};\\\", \\\"{x:1618,y:538,t:1527793671541};\\\", \\\"{x:1618,y:541,t:1527793671559};\\\", \\\"{x:1618,y:545,t:1527793671575};\\\", \\\"{x:1618,y:549,t:1527793671591};\\\", \\\"{x:1619,y:551,t:1527793671608};\\\", \\\"{x:1619,y:552,t:1527793671625};\\\", \\\"{x:1619,y:554,t:1527793671641};\\\", \\\"{x:1619,y:556,t:1527793671658};\\\", \\\"{x:1619,y:560,t:1527793671675};\\\", \\\"{x:1619,y:563,t:1527793671691};\\\", \\\"{x:1619,y:567,t:1527793671708};\\\", \\\"{x:1619,y:571,t:1527793671725};\\\", \\\"{x:1619,y:572,t:1527793671741};\\\", \\\"{x:1619,y:576,t:1527793671758};\\\", \\\"{x:1619,y:579,t:1527793671774};\\\", \\\"{x:1619,y:584,t:1527793671792};\\\", \\\"{x:1619,y:586,t:1527793671808};\\\", \\\"{x:1619,y:589,t:1527793671825};\\\", \\\"{x:1619,y:594,t:1527793671842};\\\", \\\"{x:1619,y:599,t:1527793671857};\\\", \\\"{x:1622,y:607,t:1527793671874};\\\", \\\"{x:1624,y:613,t:1527793671891};\\\", \\\"{x:1625,y:621,t:1527793671908};\\\", \\\"{x:1626,y:627,t:1527793671924};\\\", \\\"{x:1627,y:633,t:1527793671942};\\\", \\\"{x:1628,y:637,t:1527793671957};\\\", \\\"{x:1628,y:646,t:1527793671974};\\\", \\\"{x:1628,y:654,t:1527793671992};\\\", \\\"{x:1629,y:661,t:1527793672008};\\\", \\\"{x:1629,y:668,t:1527793672025};\\\", \\\"{x:1629,y:674,t:1527793672041};\\\", \\\"{x:1630,y:683,t:1527793672058};\\\", \\\"{x:1630,y:689,t:1527793672074};\\\", \\\"{x:1630,y:701,t:1527793672092};\\\", \\\"{x:1630,y:711,t:1527793672108};\\\", \\\"{x:1627,y:722,t:1527793672124};\\\", \\\"{x:1626,y:729,t:1527793672141};\\\", \\\"{x:1624,y:738,t:1527793672158};\\\", \\\"{x:1622,y:742,t:1527793672175};\\\", \\\"{x:1620,y:749,t:1527793672191};\\\", \\\"{x:1620,y:758,t:1527793672208};\\\", \\\"{x:1620,y:764,t:1527793672225};\\\", \\\"{x:1620,y:769,t:1527793672242};\\\", \\\"{x:1618,y:773,t:1527793672259};\\\", \\\"{x:1616,y:780,t:1527793672274};\\\", \\\"{x:1613,y:790,t:1527793672291};\\\", \\\"{x:1612,y:798,t:1527793672309};\\\", \\\"{x:1612,y:808,t:1527793672326};\\\", \\\"{x:1612,y:816,t:1527793672342};\\\", \\\"{x:1610,y:823,t:1527793672358};\\\", \\\"{x:1609,y:826,t:1527793672375};\\\", \\\"{x:1609,y:832,t:1527793672391};\\\", \\\"{x:1609,y:837,t:1527793672409};\\\", \\\"{x:1609,y:840,t:1527793672425};\\\", \\\"{x:1609,y:843,t:1527793672442};\\\", \\\"{x:1609,y:845,t:1527793672459};\\\", \\\"{x:1609,y:847,t:1527793672476};\\\", \\\"{x:1608,y:850,t:1527793672492};\\\", \\\"{x:1608,y:854,t:1527793672508};\\\", \\\"{x:1608,y:858,t:1527793672525};\\\", \\\"{x:1608,y:861,t:1527793672543};\\\", \\\"{x:1608,y:864,t:1527793672558};\\\", \\\"{x:1608,y:867,t:1527793672575};\\\", \\\"{x:1608,y:872,t:1527793672593};\\\", \\\"{x:1608,y:876,t:1527793672608};\\\", \\\"{x:1608,y:881,t:1527793672626};\\\", \\\"{x:1608,y:883,t:1527793672643};\\\", \\\"{x:1608,y:886,t:1527793672659};\\\", \\\"{x:1609,y:892,t:1527793672675};\\\", \\\"{x:1612,y:899,t:1527793672692};\\\", \\\"{x:1613,y:903,t:1527793672708};\\\", \\\"{x:1613,y:905,t:1527793672726};\\\", \\\"{x:1613,y:903,t:1527793672751};\\\", \\\"{x:1613,y:897,t:1527793672759};\\\", \\\"{x:1609,y:876,t:1527793672776};\\\", \\\"{x:1600,y:823,t:1527793672793};\\\", \\\"{x:1596,y:755,t:1527793672809};\\\", \\\"{x:1596,y:705,t:1527793672826};\\\", \\\"{x:1601,y:668,t:1527793672843};\\\", \\\"{x:1607,y:631,t:1527793672860};\\\", \\\"{x:1616,y:593,t:1527793672875};\\\", \\\"{x:1616,y:548,t:1527793672893};\\\", \\\"{x:1616,y:509,t:1527793672909};\\\", \\\"{x:1620,y:494,t:1527793672927};\\\", \\\"{x:1627,y:484,t:1527793672943};\\\", \\\"{x:1629,y:482,t:1527793672960};\\\", \\\"{x:1630,y:481,t:1527793672976};\\\", \\\"{x:1630,y:480,t:1527793672999};\\\", \\\"{x:1630,y:478,t:1527793673010};\\\", \\\"{x:1630,y:475,t:1527793673026};\\\", \\\"{x:1631,y:471,t:1527793673042};\\\", \\\"{x:1631,y:469,t:1527793673060};\\\", \\\"{x:1631,y:468,t:1527793673076};\\\", \\\"{x:1631,y:467,t:1527793673119};\\\", \\\"{x:1631,y:466,t:1527793673127};\\\", \\\"{x:1631,y:465,t:1527793673143};\\\", \\\"{x:1631,y:464,t:1527793673184};\\\", \\\"{x:1631,y:462,t:1527793673193};\\\", \\\"{x:1631,y:461,t:1527793673210};\\\", \\\"{x:1630,y:459,t:1527793673227};\\\", \\\"{x:1629,y:457,t:1527793673243};\\\", \\\"{x:1629,y:456,t:1527793673260};\\\", \\\"{x:1628,y:455,t:1527793673277};\\\", \\\"{x:1627,y:451,t:1527793673296};\\\", \\\"{x:1627,y:449,t:1527793673310};\\\", \\\"{x:1626,y:444,t:1527793673327};\\\", \\\"{x:1625,y:443,t:1527793673343};\\\", \\\"{x:1625,y:442,t:1527793673360};\\\", \\\"{x:1625,y:441,t:1527793673377};\\\", \\\"{x:1625,y:439,t:1527793673395};\\\", \\\"{x:1625,y:438,t:1527793673410};\\\", \\\"{x:1625,y:437,t:1527793673427};\\\", \\\"{x:1625,y:436,t:1527793673487};\\\", \\\"{x:1625,y:433,t:1527793673495};\\\", \\\"{x:1625,y:429,t:1527793673511};\\\", \\\"{x:1623,y:424,t:1527793673527};\\\", \\\"{x:1621,y:418,t:1527793673543};\\\", \\\"{x:1619,y:414,t:1527793673561};\\\", \\\"{x:1616,y:409,t:1527793673577};\\\", \\\"{x:1614,y:404,t:1527793673594};\\\", \\\"{x:1611,y:397,t:1527793673611};\\\", \\\"{x:1609,y:393,t:1527793673627};\\\", \\\"{x:1609,y:391,t:1527793673645};\\\", \\\"{x:1609,y:389,t:1527793673661};\\\", \\\"{x:1608,y:387,t:1527793673677};\\\", \\\"{x:1608,y:384,t:1527793673695};\\\", \\\"{x:1608,y:383,t:1527793673720};\\\", \\\"{x:1602,y:383,t:1527793674136};\\\", \\\"{x:1590,y:386,t:1527793674145};\\\", \\\"{x:1565,y:394,t:1527793674161};\\\", \\\"{x:1537,y:402,t:1527793674178};\\\", \\\"{x:1500,y:409,t:1527793674195};\\\", \\\"{x:1478,y:414,t:1527793674211};\\\", \\\"{x:1459,y:420,t:1527793674228};\\\", \\\"{x:1420,y:434,t:1527793674246};\\\", \\\"{x:1353,y:453,t:1527793674262};\\\", \\\"{x:1283,y:474,t:1527793674278};\\\", \\\"{x:1200,y:497,t:1527793674296};\\\", \\\"{x:1160,y:504,t:1527793674311};\\\", \\\"{x:1121,y:510,t:1527793674328};\\\", \\\"{x:1094,y:516,t:1527793674345};\\\", \\\"{x:1062,y:522,t:1527793674363};\\\", \\\"{x:1045,y:526,t:1527793674378};\\\", \\\"{x:1035,y:528,t:1527793674395};\\\", \\\"{x:1028,y:528,t:1527793674412};\\\", \\\"{x:1020,y:529,t:1527793674428};\\\", \\\"{x:1019,y:529,t:1527793675479};\\\", \\\"{x:1016,y:529,t:1527793675498};\\\", \\\"{x:1012,y:529,t:1527793675513};\\\", \\\"{x:1010,y:528,t:1527793675530};\\\", \\\"{x:1009,y:528,t:1527793675559};\\\", \\\"{x:1008,y:528,t:1527793675576};\\\", \\\"{x:1007,y:527,t:1527793675583};\\\", \\\"{x:1004,y:527,t:1527793675599};\\\", \\\"{x:1000,y:527,t:1527793675614};\\\", \\\"{x:990,y:527,t:1527793675630};\\\", \\\"{x:979,y:527,t:1527793675647};\\\", \\\"{x:969,y:527,t:1527793675663};\\\", \\\"{x:955,y:527,t:1527793675680};\\\", \\\"{x:940,y:527,t:1527793675697};\\\", \\\"{x:924,y:529,t:1527793675714};\\\", \\\"{x:906,y:530,t:1527793675730};\\\", \\\"{x:881,y:531,t:1527793675747};\\\", \\\"{x:862,y:531,t:1527793675759};\\\", \\\"{x:842,y:531,t:1527793675777};\\\", \\\"{x:821,y:533,t:1527793675794};\\\", \\\"{x:800,y:535,t:1527793675809};\\\", \\\"{x:783,y:535,t:1527793675827};\\\", \\\"{x:763,y:535,t:1527793675844};\\\", \\\"{x:750,y:535,t:1527793675859};\\\", \\\"{x:739,y:535,t:1527793675876};\\\", \\\"{x:727,y:535,t:1527793675895};\\\", \\\"{x:726,y:535,t:1527793675910};\\\", \\\"{x:719,y:535,t:1527793675927};\\\", \\\"{x:718,y:535,t:1527793675944};\\\", \\\"{x:716,y:535,t:1527793675960};\\\", \\\"{x:715,y:536,t:1527793675976};\\\", \\\"{x:713,y:536,t:1527793675994};\\\", \\\"{x:712,y:536,t:1527793676009};\\\", \\\"{x:710,y:538,t:1527793677327};\\\", \\\"{x:709,y:539,t:1527793677345};\\\", \\\"{x:709,y:545,t:1527793677362};\\\", \\\"{x:709,y:549,t:1527793677378};\\\", \\\"{x:709,y:551,t:1527793677395};\\\", \\\"{x:709,y:553,t:1527793677412};\\\", \\\"{x:701,y:556,t:1527793677428};\\\", \\\"{x:689,y:562,t:1527793677446};\\\", \\\"{x:677,y:565,t:1527793677462};\\\", \\\"{x:675,y:566,t:1527793677478};\\\", \\\"{x:673,y:566,t:1527793677503};\\\", \\\"{x:672,y:565,t:1527793677511};\\\", \\\"{x:667,y:564,t:1527793677528};\\\", \\\"{x:660,y:561,t:1527793677544};\\\", \\\"{x:648,y:559,t:1527793677562};\\\", \\\"{x:641,y:558,t:1527793677578};\\\", \\\"{x:639,y:558,t:1527793677595};\\\", \\\"{x:637,y:558,t:1527793677647};\\\", \\\"{x:631,y:558,t:1527793677662};\\\", \\\"{x:620,y:558,t:1527793677678};\\\", \\\"{x:597,y:559,t:1527793677695};\\\", \\\"{x:573,y:562,t:1527793677713};\\\", \\\"{x:542,y:564,t:1527793677728};\\\", \\\"{x:489,y:564,t:1527793677745};\\\", \\\"{x:433,y:564,t:1527793677761};\\\", \\\"{x:386,y:564,t:1527793677777};\\\", \\\"{x:351,y:564,t:1527793677795};\\\", \\\"{x:340,y:564,t:1527793677811};\\\", \\\"{x:339,y:564,t:1527793677864};\\\", \\\"{x:337,y:564,t:1527793677912};\\\", \\\"{x:335,y:564,t:1527793677929};\\\", \\\"{x:333,y:564,t:1527793677945};\\\", \\\"{x:324,y:559,t:1527793677962};\\\", \\\"{x:310,y:556,t:1527793677978};\\\", \\\"{x:299,y:554,t:1527793677995};\\\", \\\"{x:293,y:553,t:1527793678011};\\\", \\\"{x:291,y:552,t:1527793678029};\\\", \\\"{x:287,y:548,t:1527793678046};\\\", \\\"{x:283,y:544,t:1527793678061};\\\", \\\"{x:282,y:542,t:1527793678078};\\\", \\\"{x:282,y:540,t:1527793678096};\\\", \\\"{x:282,y:538,t:1527793678112};\\\", \\\"{x:287,y:534,t:1527793678129};\\\", \\\"{x:293,y:530,t:1527793678146};\\\", \\\"{x:304,y:525,t:1527793678162};\\\", \\\"{x:338,y:520,t:1527793678179};\\\", \\\"{x:399,y:511,t:1527793678196};\\\", \\\"{x:482,y:500,t:1527793678212};\\\", \\\"{x:571,y:487,t:1527793678229};\\\", \\\"{x:641,y:476,t:1527793678248};\\\", \\\"{x:686,y:469,t:1527793678262};\\\", \\\"{x:730,y:463,t:1527793678279};\\\", \\\"{x:750,y:461,t:1527793678296};\\\", \\\"{x:767,y:458,t:1527793678312};\\\", \\\"{x:781,y:458,t:1527793678329};\\\", \\\"{x:792,y:458,t:1527793678346};\\\", \\\"{x:807,y:458,t:1527793678362};\\\", \\\"{x:834,y:458,t:1527793678379};\\\", \\\"{x:856,y:458,t:1527793678395};\\\", \\\"{x:866,y:458,t:1527793678412};\\\", \\\"{x:871,y:458,t:1527793678429};\\\", \\\"{x:869,y:458,t:1527793678568};\\\", \\\"{x:865,y:459,t:1527793678579};\\\", \\\"{x:855,y:463,t:1527793678596};\\\", \\\"{x:832,y:468,t:1527793678613};\\\", \\\"{x:805,y:471,t:1527793678629};\\\", \\\"{x:773,y:476,t:1527793678646};\\\", \\\"{x:712,y:481,t:1527793678663};\\\", \\\"{x:678,y:481,t:1527793678678};\\\", \\\"{x:654,y:482,t:1527793678696};\\\", \\\"{x:634,y:486,t:1527793678713};\\\", \\\"{x:624,y:487,t:1527793678728};\\\", \\\"{x:620,y:488,t:1527793678746};\\\", \\\"{x:616,y:491,t:1527793678763};\\\", \\\"{x:614,y:492,t:1527793678779};\\\", \\\"{x:613,y:492,t:1527793678796};\\\", \\\"{x:611,y:493,t:1527793678812};\\\", \\\"{x:610,y:494,t:1527793678829};\\\", \\\"{x:610,y:503,t:1527793678846};\\\", \\\"{x:647,y:519,t:1527793678863};\\\", \\\"{x:687,y:526,t:1527793678879};\\\", \\\"{x:731,y:526,t:1527793678896};\\\", \\\"{x:771,y:526,t:1527793678913};\\\", \\\"{x:803,y:526,t:1527793678929};\\\", \\\"{x:826,y:526,t:1527793678946};\\\", \\\"{x:840,y:524,t:1527793678963};\\\", \\\"{x:850,y:521,t:1527793678980};\\\", \\\"{x:850,y:520,t:1527793678995};\\\", \\\"{x:850,y:522,t:1527793679081};\\\", \\\"{x:846,y:528,t:1527793679095};\\\", \\\"{x:843,y:539,t:1527793679112};\\\", \\\"{x:843,y:546,t:1527793679129};\\\", \\\"{x:842,y:551,t:1527793679145};\\\", \\\"{x:841,y:551,t:1527793679438};\\\", \\\"{x:838,y:551,t:1527793679447};\\\", \\\"{x:821,y:555,t:1527793679462};\\\", \\\"{x:789,y:567,t:1527793679480};\\\", \\\"{x:730,y:587,t:1527793679496};\\\", \\\"{x:658,y:605,t:1527793679512};\\\", \\\"{x:589,y:623,t:1527793679529};\\\", \\\"{x:530,y:634,t:1527793679547};\\\", \\\"{x:483,y:639,t:1527793679563};\\\", \\\"{x:461,y:642,t:1527793679580};\\\", \\\"{x:447,y:642,t:1527793679597};\\\", \\\"{x:440,y:642,t:1527793679613};\\\", \\\"{x:432,y:642,t:1527793679630};\\\", \\\"{x:430,y:642,t:1527793679646};\\\", \\\"{x:430,y:644,t:1527793679735};\\\", \\\"{x:437,y:651,t:1527793679747};\\\", \\\"{x:455,y:663,t:1527793679765};\\\", \\\"{x:470,y:668,t:1527793679780};\\\", \\\"{x:479,y:672,t:1527793679796};\\\", \\\"{x:482,y:672,t:1527793679812};\\\", \\\"{x:483,y:672,t:1527793679830};\\\", \\\"{x:485,y:672,t:1527793679846};\\\", \\\"{x:494,y:670,t:1527793679862};\\\", \\\"{x:502,y:668,t:1527793679880};\\\", \\\"{x:506,y:667,t:1527793679896};\\\", \\\"{x:511,y:665,t:1527793679913};\\\", \\\"{x:514,y:665,t:1527793680151};\\\", \\\"{x:518,y:665,t:1527793680164};\\\", \\\"{x:539,y:662,t:1527793680179};\\\", \\\"{x:564,y:659,t:1527793680197};\\\", \\\"{x:610,y:653,t:1527793680214};\\\", \\\"{x:677,y:641,t:1527793680229};\\\", \\\"{x:790,y:625,t:1527793680246};\\\", \\\"{x:854,y:616,t:1527793680263};\\\", \\\"{x:891,y:612,t:1527793680280};\\\", \\\"{x:906,y:610,t:1527793680297};\\\", \\\"{x:911,y:609,t:1527793680314};\\\", \\\"{x:913,y:609,t:1527793680330};\\\" ] }, { \\\"rt\\\": 12365, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 219453, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:913,y:608,t:1527793687815};\\\", \\\"{x:914,y:608,t:1527793690767};\\\", \\\"{x:915,y:608,t:1527793690832};\\\", \\\"{x:913,y:608,t:1527793690984};\\\", \\\"{x:911,y:608,t:1527793690991};\\\", \\\"{x:908,y:606,t:1527793691006};\\\", \\\"{x:899,y:602,t:1527793691023};\\\", \\\"{x:885,y:597,t:1527793691039};\\\", \\\"{x:866,y:588,t:1527793691055};\\\", \\\"{x:845,y:577,t:1527793691072};\\\", \\\"{x:819,y:566,t:1527793691091};\\\", \\\"{x:794,y:559,t:1527793691105};\\\", \\\"{x:747,y:557,t:1527793691122};\\\", \\\"{x:689,y:557,t:1527793691140};\\\", \\\"{x:633,y:557,t:1527793691157};\\\", \\\"{x:577,y:557,t:1527793691173};\\\", \\\"{x:515,y:553,t:1527793691189};\\\", \\\"{x:472,y:553,t:1527793691207};\\\", \\\"{x:456,y:553,t:1527793691222};\\\", \\\"{x:446,y:553,t:1527793691239};\\\", \\\"{x:442,y:553,t:1527793691256};\\\", \\\"{x:441,y:553,t:1527793691272};\\\", \\\"{x:449,y:553,t:1527793691303};\\\", \\\"{x:465,y:553,t:1527793691310};\\\", \\\"{x:496,y:553,t:1527793691323};\\\", \\\"{x:588,y:551,t:1527793691340};\\\", \\\"{x:718,y:535,t:1527793691357};\\\", \\\"{x:855,y:524,t:1527793691373};\\\", \\\"{x:962,y:514,t:1527793691389};\\\", \\\"{x:1020,y:509,t:1527793691406};\\\", \\\"{x:1026,y:507,t:1527793691423};\\\", \\\"{x:1023,y:507,t:1527793691463};\\\", \\\"{x:1019,y:507,t:1527793691473};\\\", \\\"{x:1016,y:507,t:1527793691489};\\\", \\\"{x:1012,y:506,t:1527793691506};\\\", \\\"{x:1007,y:506,t:1527793691523};\\\", \\\"{x:996,y:506,t:1527793691539};\\\", \\\"{x:968,y:506,t:1527793691556};\\\", \\\"{x:944,y:502,t:1527793691573};\\\", \\\"{x:930,y:502,t:1527793691589};\\\", \\\"{x:910,y:497,t:1527793691606};\\\", \\\"{x:902,y:497,t:1527793691623};\\\", \\\"{x:895,y:497,t:1527793691639};\\\", \\\"{x:894,y:496,t:1527793691695};\\\", \\\"{x:893,y:495,t:1527793691706};\\\", \\\"{x:892,y:494,t:1527793691723};\\\", \\\"{x:888,y:493,t:1527793691739};\\\", \\\"{x:887,y:492,t:1527793691757};\\\", \\\"{x:887,y:491,t:1527793691816};\\\", \\\"{x:886,y:490,t:1527793691823};\\\", \\\"{x:885,y:488,t:1527793691840};\\\", \\\"{x:884,y:487,t:1527793691856};\\\", \\\"{x:882,y:487,t:1527793691879};\\\", \\\"{x:881,y:487,t:1527793691891};\\\", \\\"{x:875,y:487,t:1527793691907};\\\", \\\"{x:868,y:487,t:1527793691924};\\\", \\\"{x:863,y:487,t:1527793691940};\\\", \\\"{x:862,y:487,t:1527793691956};\\\", \\\"{x:860,y:487,t:1527793691974};\\\", \\\"{x:859,y:487,t:1527793692383};\\\", \\\"{x:857,y:488,t:1527793693047};\\\", \\\"{x:852,y:489,t:1527793693057};\\\", \\\"{x:836,y:497,t:1527793693076};\\\", \\\"{x:818,y:508,t:1527793693090};\\\", \\\"{x:797,y:517,t:1527793693107};\\\", \\\"{x:773,y:530,t:1527793693125};\\\", \\\"{x:749,y:544,t:1527793693141};\\\", \\\"{x:728,y:557,t:1527793693157};\\\", \\\"{x:689,y:576,t:1527793693175};\\\", \\\"{x:669,y:590,t:1527793693191};\\\", \\\"{x:651,y:603,t:1527793693207};\\\", \\\"{x:637,y:615,t:1527793693225};\\\", \\\"{x:632,y:623,t:1527793693241};\\\", \\\"{x:632,y:628,t:1527793693257};\\\", \\\"{x:631,y:632,t:1527793693274};\\\", \\\"{x:627,y:639,t:1527793693292};\\\", \\\"{x:617,y:648,t:1527793693307};\\\", \\\"{x:607,y:653,t:1527793693325};\\\", \\\"{x:600,y:657,t:1527793693342};\\\", \\\"{x:596,y:658,t:1527793693357};\\\", \\\"{x:587,y:661,t:1527793693374};\\\", \\\"{x:574,y:663,t:1527793693391};\\\", \\\"{x:559,y:667,t:1527793693408};\\\", \\\"{x:543,y:671,t:1527793693424};\\\", \\\"{x:530,y:675,t:1527793693442};\\\", \\\"{x:526,y:676,t:1527793693457};\\\", \\\"{x:524,y:677,t:1527793693475};\\\", \\\"{x:521,y:679,t:1527793693491};\\\", \\\"{x:521,y:677,t:1527793693920};\\\", \\\"{x:525,y:673,t:1527793693927};\\\", \\\"{x:526,y:670,t:1527793693942};\\\", \\\"{x:531,y:662,t:1527793693958};\\\", \\\"{x:534,y:656,t:1527793693975};\\\", \\\"{x:539,y:648,t:1527793693992};\\\", \\\"{x:543,y:640,t:1527793694008};\\\", \\\"{x:549,y:630,t:1527793694025};\\\", \\\"{x:556,y:626,t:1527793694042};\\\", \\\"{x:563,y:625,t:1527793694058};\\\", \\\"{x:575,y:625,t:1527793694074};\\\", \\\"{x:577,y:625,t:1527793694091};\\\" ] }, { \\\"rt\\\": 28160, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 248843, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -F -F -J -08 PM-04 PM-E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:578,y:625,t:1527793695743};\\\", \\\"{x:580,y:622,t:1527793695760};\\\", \\\"{x:580,y:621,t:1527793695847};\\\", \\\"{x:580,y:620,t:1527793695863};\\\", \\\"{x:581,y:617,t:1527793695877};\\\", \\\"{x:585,y:605,t:1527793695894};\\\", \\\"{x:592,y:589,t:1527793695910};\\\", \\\"{x:597,y:561,t:1527793695928};\\\", \\\"{x:592,y:539,t:1527793695945};\\\", \\\"{x:579,y:519,t:1527793695959};\\\", \\\"{x:568,y:500,t:1527793695977};\\\", \\\"{x:565,y:493,t:1527793695993};\\\", \\\"{x:565,y:489,t:1527793696009};\\\", \\\"{x:565,y:484,t:1527793696026};\\\", \\\"{x:565,y:481,t:1527793696044};\\\", \\\"{x:565,y:479,t:1527793696059};\\\", \\\"{x:564,y:478,t:1527793696079};\\\", \\\"{x:564,y:477,t:1527793696111};\\\", \\\"{x:563,y:476,t:1527793696126};\\\", \\\"{x:559,y:473,t:1527793696143};\\\", \\\"{x:553,y:472,t:1527793696159};\\\", \\\"{x:546,y:472,t:1527793696177};\\\", \\\"{x:545,y:472,t:1527793696194};\\\", \\\"{x:545,y:471,t:1527793697056};\\\", \\\"{x:548,y:471,t:1527793697078};\\\", \\\"{x:552,y:468,t:1527793697094};\\\", \\\"{x:556,y:468,t:1527793697110};\\\", \\\"{x:559,y:467,t:1527793697128};\\\", \\\"{x:560,y:466,t:1527793697145};\\\", \\\"{x:563,y:466,t:1527793697327};\\\", \\\"{x:578,y:470,t:1527793697345};\\\", \\\"{x:591,y:474,t:1527793697362};\\\", \\\"{x:609,y:480,t:1527793697378};\\\", \\\"{x:640,y:489,t:1527793697394};\\\", \\\"{x:682,y:502,t:1527793697410};\\\", \\\"{x:728,y:511,t:1527793697428};\\\", \\\"{x:800,y:520,t:1527793697444};\\\", \\\"{x:899,y:543,t:1527793697461};\\\", \\\"{x:1007,y:576,t:1527793697478};\\\", \\\"{x:1147,y:638,t:1527793697495};\\\", \\\"{x:1194,y:660,t:1527793697511};\\\", \\\"{x:1212,y:672,t:1527793697528};\\\", \\\"{x:1228,y:683,t:1527793697545};\\\", \\\"{x:1239,y:694,t:1527793697561};\\\", \\\"{x:1240,y:698,t:1527793697578};\\\", \\\"{x:1240,y:699,t:1527793697598};\\\", \\\"{x:1240,y:700,t:1527793697611};\\\", \\\"{x:1238,y:700,t:1527793697628};\\\", \\\"{x:1237,y:700,t:1527793697644};\\\", \\\"{x:1236,y:700,t:1527793697661};\\\", \\\"{x:1236,y:699,t:1527793698159};\\\", \\\"{x:1236,y:697,t:1527793698175};\\\", \\\"{x:1236,y:696,t:1527793698200};\\\", \\\"{x:1236,y:695,t:1527793698212};\\\", \\\"{x:1236,y:694,t:1527793698229};\\\", \\\"{x:1236,y:693,t:1527793698246};\\\", \\\"{x:1236,y:691,t:1527793698262};\\\", \\\"{x:1236,y:689,t:1527793698279};\\\", \\\"{x:1236,y:687,t:1527793698296};\\\", \\\"{x:1237,y:685,t:1527793698313};\\\", \\\"{x:1238,y:683,t:1527793698329};\\\", \\\"{x:1240,y:679,t:1527793698346};\\\", \\\"{x:1241,y:677,t:1527793698363};\\\", \\\"{x:1243,y:673,t:1527793698379};\\\", \\\"{x:1245,y:667,t:1527793698396};\\\", \\\"{x:1247,y:663,t:1527793698413};\\\", \\\"{x:1250,y:657,t:1527793698429};\\\", \\\"{x:1253,y:650,t:1527793698447};\\\", \\\"{x:1263,y:634,t:1527793698463};\\\", \\\"{x:1268,y:625,t:1527793698479};\\\", \\\"{x:1271,y:618,t:1527793698496};\\\", \\\"{x:1276,y:612,t:1527793698514};\\\", \\\"{x:1286,y:603,t:1527793698529};\\\", \\\"{x:1295,y:595,t:1527793698546};\\\", \\\"{x:1296,y:595,t:1527793698563};\\\", \\\"{x:1295,y:595,t:1527793699023};\\\", \\\"{x:1293,y:595,t:1527793699039};\\\", \\\"{x:1289,y:597,t:1527793699047};\\\", \\\"{x:1284,y:598,t:1527793699063};\\\", \\\"{x:1278,y:602,t:1527793699080};\\\", \\\"{x:1271,y:611,t:1527793699097};\\\", \\\"{x:1263,y:620,t:1527793699112};\\\", \\\"{x:1250,y:631,t:1527793699129};\\\", \\\"{x:1235,y:642,t:1527793699147};\\\", \\\"{x:1222,y:657,t:1527793699163};\\\", \\\"{x:1211,y:671,t:1527793699180};\\\", \\\"{x:1201,y:683,t:1527793699196};\\\", \\\"{x:1195,y:694,t:1527793699213};\\\", \\\"{x:1190,y:705,t:1527793699230};\\\", \\\"{x:1185,y:717,t:1527793699246};\\\", \\\"{x:1183,y:724,t:1527793699264};\\\", \\\"{x:1182,y:727,t:1527793699280};\\\", \\\"{x:1181,y:729,t:1527793699297};\\\", \\\"{x:1181,y:730,t:1527793699314};\\\", \\\"{x:1182,y:730,t:1527793699447};\\\", \\\"{x:1183,y:729,t:1527793699465};\\\", \\\"{x:1184,y:728,t:1527793699503};\\\", \\\"{x:1185,y:728,t:1527793699536};\\\", \\\"{x:1186,y:728,t:1527793699551};\\\", \\\"{x:1186,y:727,t:1527793699565};\\\", \\\"{x:1188,y:726,t:1527793699581};\\\", \\\"{x:1188,y:725,t:1527793699597};\\\", \\\"{x:1189,y:724,t:1527793699615};\\\", \\\"{x:1189,y:723,t:1527793699639};\\\", \\\"{x:1189,y:722,t:1527793699655};\\\", \\\"{x:1190,y:721,t:1527793699672};\\\", \\\"{x:1190,y:720,t:1527793699682};\\\", \\\"{x:1191,y:719,t:1527793699697};\\\", \\\"{x:1192,y:718,t:1527793699714};\\\", \\\"{x:1193,y:715,t:1527793699731};\\\", \\\"{x:1196,y:709,t:1527793699746};\\\", \\\"{x:1200,y:700,t:1527793699764};\\\", \\\"{x:1206,y:684,t:1527793699780};\\\", \\\"{x:1211,y:667,t:1527793699798};\\\", \\\"{x:1217,y:650,t:1527793699813};\\\", \\\"{x:1228,y:624,t:1527793699831};\\\", \\\"{x:1234,y:609,t:1527793699848};\\\", \\\"{x:1244,y:592,t:1527793699863};\\\", \\\"{x:1249,y:577,t:1527793699881};\\\", \\\"{x:1254,y:567,t:1527793699898};\\\", \\\"{x:1259,y:556,t:1527793699914};\\\", \\\"{x:1263,y:549,t:1527793699930};\\\", \\\"{x:1265,y:544,t:1527793699948};\\\", \\\"{x:1267,y:540,t:1527793699964};\\\", \\\"{x:1268,y:538,t:1527793699981};\\\", \\\"{x:1270,y:534,t:1527793699998};\\\", \\\"{x:1271,y:534,t:1527793700014};\\\", \\\"{x:1273,y:530,t:1527793700031};\\\", \\\"{x:1275,y:527,t:1527793700049};\\\", \\\"{x:1275,y:526,t:1527793700064};\\\", \\\"{x:1277,y:525,t:1527793700103};\\\", \\\"{x:1277,y:524,t:1527793700119};\\\", \\\"{x:1277,y:523,t:1527793700131};\\\", \\\"{x:1277,y:519,t:1527793700149};\\\", \\\"{x:1279,y:516,t:1527793700166};\\\", \\\"{x:1280,y:514,t:1527793700666};\\\", \\\"{x:1280,y:513,t:1527793700682};\\\", \\\"{x:1280,y:511,t:1527793700702};\\\", \\\"{x:1281,y:511,t:1527793700719};\\\", \\\"{x:1281,y:513,t:1527793701447};\\\", \\\"{x:1281,y:515,t:1527793701455};\\\", \\\"{x:1281,y:518,t:1527793701467};\\\", \\\"{x:1282,y:522,t:1527793701483};\\\", \\\"{x:1283,y:526,t:1527793701501};\\\", \\\"{x:1285,y:531,t:1527793701516};\\\", \\\"{x:1286,y:535,t:1527793701533};\\\", \\\"{x:1289,y:540,t:1527793701550};\\\", \\\"{x:1294,y:551,t:1527793701566};\\\", \\\"{x:1299,y:563,t:1527793701583};\\\", \\\"{x:1303,y:567,t:1527793701600};\\\", \\\"{x:1305,y:572,t:1527793701616};\\\", \\\"{x:1306,y:575,t:1527793701633};\\\", \\\"{x:1308,y:579,t:1527793701651};\\\", \\\"{x:1311,y:585,t:1527793701666};\\\", \\\"{x:1316,y:590,t:1527793701684};\\\", \\\"{x:1318,y:593,t:1527793701701};\\\", \\\"{x:1318,y:596,t:1527793701716};\\\", \\\"{x:1322,y:600,t:1527793701732};\\\", \\\"{x:1325,y:604,t:1527793701749};\\\", \\\"{x:1326,y:607,t:1527793701766};\\\", \\\"{x:1328,y:609,t:1527793701782};\\\", \\\"{x:1328,y:611,t:1527793701800};\\\", \\\"{x:1328,y:613,t:1527793701817};\\\", \\\"{x:1330,y:619,t:1527793701833};\\\", \\\"{x:1333,y:622,t:1527793701850};\\\", \\\"{x:1335,y:624,t:1527793701867};\\\", \\\"{x:1337,y:626,t:1527793701883};\\\", \\\"{x:1337,y:629,t:1527793701900};\\\", \\\"{x:1338,y:630,t:1527793701917};\\\", \\\"{x:1339,y:631,t:1527793701933};\\\", \\\"{x:1340,y:632,t:1527793701950};\\\", \\\"{x:1341,y:633,t:1527793701967};\\\", \\\"{x:1341,y:634,t:1527793701983};\\\", \\\"{x:1342,y:636,t:1527793702007};\\\", \\\"{x:1343,y:636,t:1527793702023};\\\", \\\"{x:1343,y:637,t:1527793702033};\\\", \\\"{x:1344,y:638,t:1527793702248};\\\", \\\"{x:1345,y:639,t:1527793702256};\\\", \\\"{x:1346,y:639,t:1527793704758};\\\", \\\"{x:1348,y:639,t:1527793704770};\\\", \\\"{x:1349,y:639,t:1527793704814};\\\", \\\"{x:1349,y:641,t:1527793705455};\\\", \\\"{x:1345,y:651,t:1527793705472};\\\", \\\"{x:1340,y:662,t:1527793705489};\\\", \\\"{x:1328,y:683,t:1527793705504};\\\", \\\"{x:1310,y:707,t:1527793705522};\\\", \\\"{x:1289,y:729,t:1527793705539};\\\", \\\"{x:1272,y:742,t:1527793705555};\\\", \\\"{x:1254,y:758,t:1527793705572};\\\", \\\"{x:1240,y:775,t:1527793705589};\\\", \\\"{x:1230,y:786,t:1527793705604};\\\", \\\"{x:1223,y:793,t:1527793705622};\\\", \\\"{x:1219,y:799,t:1527793705639};\\\", \\\"{x:1216,y:801,t:1527793705654};\\\", \\\"{x:1214,y:801,t:1527793705671};\\\", \\\"{x:1211,y:801,t:1527793705688};\\\", \\\"{x:1210,y:801,t:1527793705711};\\\", \\\"{x:1210,y:800,t:1527793705727};\\\", \\\"{x:1210,y:799,t:1527793705738};\\\", \\\"{x:1210,y:796,t:1527793705755};\\\", \\\"{x:1211,y:792,t:1527793705771};\\\", \\\"{x:1212,y:789,t:1527793705789};\\\", \\\"{x:1213,y:786,t:1527793705806};\\\", \\\"{x:1215,y:785,t:1527793705822};\\\", \\\"{x:1215,y:784,t:1527793705839};\\\", \\\"{x:1215,y:783,t:1527793705856};\\\", \\\"{x:1216,y:782,t:1527793705896};\\\", \\\"{x:1216,y:781,t:1527793705905};\\\", \\\"{x:1217,y:781,t:1527793705935};\\\", \\\"{x:1218,y:781,t:1527793707231};\\\", \\\"{x:1220,y:779,t:1527793709433};\\\", \\\"{x:1231,y:779,t:1527793709443};\\\", \\\"{x:1274,y:785,t:1527793709460};\\\", \\\"{x:1380,y:805,t:1527793709477};\\\", \\\"{x:1503,y:830,t:1527793709493};\\\", \\\"{x:1620,y:863,t:1527793709510};\\\", \\\"{x:1784,y:900,t:1527793709527};\\\", \\\"{x:1853,y:919,t:1527793709543};\\\", \\\"{x:1872,y:928,t:1527793709560};\\\", \\\"{x:1879,y:932,t:1527793709577};\\\", \\\"{x:1878,y:933,t:1527793709607};\\\", \\\"{x:1871,y:935,t:1527793709615};\\\", \\\"{x:1865,y:935,t:1527793709627};\\\", \\\"{x:1850,y:935,t:1527793709643};\\\", \\\"{x:1830,y:935,t:1527793709660};\\\", \\\"{x:1811,y:935,t:1527793709677};\\\", \\\"{x:1785,y:935,t:1527793709693};\\\", \\\"{x:1762,y:937,t:1527793709709};\\\", \\\"{x:1730,y:937,t:1527793709727};\\\", \\\"{x:1710,y:937,t:1527793709743};\\\", \\\"{x:1686,y:937,t:1527793709760};\\\", \\\"{x:1664,y:937,t:1527793709777};\\\", \\\"{x:1647,y:937,t:1527793709794};\\\", \\\"{x:1630,y:937,t:1527793709810};\\\", \\\"{x:1621,y:937,t:1527793709827};\\\", \\\"{x:1616,y:937,t:1527793709844};\\\", \\\"{x:1615,y:937,t:1527793709860};\\\", \\\"{x:1615,y:936,t:1527793710071};\\\", \\\"{x:1615,y:935,t:1527793710159};\\\", \\\"{x:1615,y:934,t:1527793710288};\\\", \\\"{x:1615,y:933,t:1527793710303};\\\", \\\"{x:1615,y:932,t:1527793710391};\\\", \\\"{x:1616,y:932,t:1527793710423};\\\", \\\"{x:1616,y:931,t:1527793710720};\\\", \\\"{x:1617,y:930,t:1527793710920};\\\", \\\"{x:1618,y:930,t:1527793710927};\\\", \\\"{x:1619,y:929,t:1527793713660};\\\", \\\"{x:1619,y:927,t:1527793713668};\\\", \\\"{x:1618,y:924,t:1527793713679};\\\", \\\"{x:1613,y:917,t:1527793713695};\\\", \\\"{x:1603,y:900,t:1527793713712};\\\", \\\"{x:1596,y:872,t:1527793713729};\\\", \\\"{x:1570,y:821,t:1527793713745};\\\", \\\"{x:1530,y:755,t:1527793713761};\\\", \\\"{x:1490,y:667,t:1527793713779};\\\", \\\"{x:1457,y:582,t:1527793713795};\\\", \\\"{x:1403,y:469,t:1527793713812};\\\", \\\"{x:1373,y:427,t:1527793713828};\\\", \\\"{x:1349,y:386,t:1527793713845};\\\", \\\"{x:1325,y:347,t:1527793713862};\\\", \\\"{x:1308,y:324,t:1527793713879};\\\", \\\"{x:1299,y:314,t:1527793713895};\\\", \\\"{x:1295,y:311,t:1527793713912};\\\", \\\"{x:1292,y:309,t:1527793713929};\\\", \\\"{x:1286,y:308,t:1527793713945};\\\", \\\"{x:1281,y:307,t:1527793713961};\\\", \\\"{x:1275,y:307,t:1527793713979};\\\", \\\"{x:1267,y:307,t:1527793713995};\\\", \\\"{x:1260,y:305,t:1527793714012};\\\", \\\"{x:1251,y:304,t:1527793714029};\\\", \\\"{x:1244,y:304,t:1527793714046};\\\", \\\"{x:1236,y:303,t:1527793714063};\\\", \\\"{x:1221,y:300,t:1527793714079};\\\", \\\"{x:1209,y:299,t:1527793714096};\\\", \\\"{x:1194,y:298,t:1527793714112};\\\", \\\"{x:1178,y:298,t:1527793714129};\\\", \\\"{x:1167,y:298,t:1527793714146};\\\", \\\"{x:1161,y:298,t:1527793714162};\\\", \\\"{x:1157,y:300,t:1527793714179};\\\", \\\"{x:1152,y:325,t:1527793714195};\\\", \\\"{x:1151,y:346,t:1527793714212};\\\", \\\"{x:1150,y:366,t:1527793714229};\\\", \\\"{x:1150,y:389,t:1527793714246};\\\", \\\"{x:1150,y:407,t:1527793714262};\\\", \\\"{x:1150,y:422,t:1527793714279};\\\", \\\"{x:1150,y:431,t:1527793714296};\\\", \\\"{x:1150,y:437,t:1527793714314};\\\", \\\"{x:1150,y:441,t:1527793714329};\\\", \\\"{x:1150,y:442,t:1527793714346};\\\", \\\"{x:1150,y:445,t:1527793714363};\\\", \\\"{x:1149,y:448,t:1527793714379};\\\", \\\"{x:1149,y:453,t:1527793714397};\\\", \\\"{x:1149,y:455,t:1527793714414};\\\", \\\"{x:1149,y:456,t:1527793714429};\\\", \\\"{x:1149,y:457,t:1527793714446};\\\", \\\"{x:1149,y:458,t:1527793714547};\\\", \\\"{x:1150,y:459,t:1527793714596};\\\", \\\"{x:1152,y:463,t:1527793714613};\\\", \\\"{x:1162,y:471,t:1527793714630};\\\", \\\"{x:1175,y:482,t:1527793714646};\\\", \\\"{x:1188,y:489,t:1527793714663};\\\", \\\"{x:1202,y:496,t:1527793714680};\\\", \\\"{x:1212,y:501,t:1527793714696};\\\", \\\"{x:1220,y:503,t:1527793714713};\\\", \\\"{x:1225,y:504,t:1527793714730};\\\", \\\"{x:1226,y:505,t:1527793714746};\\\", \\\"{x:1230,y:505,t:1527793714763};\\\", \\\"{x:1237,y:505,t:1527793714780};\\\", \\\"{x:1244,y:506,t:1527793714796};\\\", \\\"{x:1252,y:506,t:1527793714813};\\\", \\\"{x:1259,y:506,t:1527793714829};\\\", \\\"{x:1267,y:506,t:1527793714847};\\\", \\\"{x:1274,y:506,t:1527793714863};\\\", \\\"{x:1279,y:506,t:1527793714880};\\\", \\\"{x:1284,y:507,t:1527793714896};\\\", \\\"{x:1288,y:509,t:1527793714913};\\\", \\\"{x:1289,y:509,t:1527793714929};\\\", \\\"{x:1290,y:509,t:1527793714964};\\\", \\\"{x:1290,y:510,t:1527793715285};\\\", \\\"{x:1289,y:510,t:1527793715316};\\\", \\\"{x:1288,y:510,t:1527793715549};\\\", \\\"{x:1286,y:510,t:1527793715565};\\\", \\\"{x:1283,y:510,t:1527793715581};\\\", \\\"{x:1281,y:510,t:1527793715597};\\\", \\\"{x:1280,y:510,t:1527793715614};\\\", \\\"{x:1279,y:510,t:1527793715660};\\\", \\\"{x:1280,y:510,t:1527793717900};\\\", \\\"{x:1295,y:510,t:1527793717918};\\\", \\\"{x:1309,y:510,t:1527793717933};\\\", \\\"{x:1326,y:510,t:1527793717951};\\\", \\\"{x:1335,y:510,t:1527793717967};\\\", \\\"{x:1343,y:510,t:1527793717984};\\\", \\\"{x:1345,y:510,t:1527793718001};\\\", \\\"{x:1346,y:510,t:1527793718018};\\\", \\\"{x:1347,y:510,t:1527793718035};\\\", \\\"{x:1350,y:510,t:1527793718050};\\\", \\\"{x:1356,y:510,t:1527793718068};\\\", \\\"{x:1369,y:510,t:1527793718084};\\\", \\\"{x:1379,y:511,t:1527793718100};\\\", \\\"{x:1387,y:512,t:1527793718118};\\\", \\\"{x:1391,y:512,t:1527793718134};\\\", \\\"{x:1392,y:512,t:1527793718151};\\\", \\\"{x:1393,y:512,t:1527793718196};\\\", \\\"{x:1396,y:512,t:1527793718205};\\\", \\\"{x:1398,y:513,t:1527793718218};\\\", \\\"{x:1399,y:513,t:1527793718252};\\\", \\\"{x:1400,y:513,t:1527793718267};\\\", \\\"{x:1401,y:513,t:1527793718285};\\\", \\\"{x:1404,y:513,t:1527793718316};\\\", \\\"{x:1405,y:513,t:1527793718335};\\\", \\\"{x:1407,y:513,t:1527793718352};\\\", \\\"{x:1410,y:513,t:1527793718368};\\\", \\\"{x:1411,y:513,t:1527793718384};\\\", \\\"{x:1412,y:513,t:1527793718401};\\\", \\\"{x:1411,y:513,t:1527793718660};\\\", \\\"{x:1400,y:513,t:1527793718670};\\\", \\\"{x:1338,y:513,t:1527793718685};\\\", \\\"{x:1210,y:511,t:1527793718701};\\\", \\\"{x:1038,y:502,t:1527793718717};\\\", \\\"{x:872,y:498,t:1527793718734};\\\", \\\"{x:748,y:485,t:1527793718751};\\\", \\\"{x:659,y:485,t:1527793718768};\\\", \\\"{x:615,y:485,t:1527793718789};\\\", \\\"{x:614,y:485,t:1527793718806};\\\", \\\"{x:614,y:483,t:1527793718827};\\\", \\\"{x:616,y:483,t:1527793718839};\\\", \\\"{x:622,y:483,t:1527793718856};\\\", \\\"{x:627,y:482,t:1527793718873};\\\", \\\"{x:629,y:482,t:1527793718924};\\\", \\\"{x:632,y:482,t:1527793718938};\\\", \\\"{x:643,y:482,t:1527793718956};\\\", \\\"{x:649,y:482,t:1527793718972};\\\", \\\"{x:658,y:485,t:1527793718993};\\\", \\\"{x:673,y:493,t:1527793719009};\\\", \\\"{x:678,y:495,t:1527793719026};\\\", \\\"{x:679,y:495,t:1527793719075};\\\", \\\"{x:679,y:492,t:1527793719092};\\\", \\\"{x:679,y:484,t:1527793719110};\\\", \\\"{x:674,y:475,t:1527793719126};\\\", \\\"{x:661,y:464,t:1527793719144};\\\", \\\"{x:655,y:459,t:1527793719159};\\\", \\\"{x:652,y:457,t:1527793719176};\\\", \\\"{x:649,y:457,t:1527793719193};\\\", \\\"{x:645,y:455,t:1527793719210};\\\", \\\"{x:642,y:454,t:1527793719226};\\\", \\\"{x:639,y:454,t:1527793719243};\\\", \\\"{x:635,y:454,t:1527793719260};\\\", \\\"{x:632,y:454,t:1527793719276};\\\", \\\"{x:630,y:454,t:1527793719293};\\\", \\\"{x:627,y:455,t:1527793719310};\\\", \\\"{x:626,y:455,t:1527793719326};\\\", \\\"{x:625,y:455,t:1527793719364};\\\", \\\"{x:623,y:455,t:1527793719547};\\\", \\\"{x:620,y:456,t:1527793719560};\\\", \\\"{x:602,y:460,t:1527793719577};\\\", \\\"{x:572,y:462,t:1527793719593};\\\", \\\"{x:530,y:469,t:1527793719610};\\\", \\\"{x:469,y:485,t:1527793719627};\\\", \\\"{x:405,y:495,t:1527793719643};\\\", \\\"{x:350,y:504,t:1527793719660};\\\", \\\"{x:324,y:508,t:1527793719677};\\\", \\\"{x:297,y:512,t:1527793719693};\\\", \\\"{x:279,y:513,t:1527793719709};\\\", \\\"{x:267,y:516,t:1527793719728};\\\", \\\"{x:255,y:517,t:1527793719743};\\\", \\\"{x:231,y:520,t:1527793719760};\\\", \\\"{x:199,y:522,t:1527793719777};\\\", \\\"{x:166,y:522,t:1527793719795};\\\", \\\"{x:143,y:520,t:1527793719811};\\\", \\\"{x:129,y:520,t:1527793719827};\\\", \\\"{x:128,y:520,t:1527793719843};\\\", \\\"{x:129,y:520,t:1527793719884};\\\", \\\"{x:132,y:520,t:1527793719894};\\\", \\\"{x:133,y:520,t:1527793719910};\\\", \\\"{x:134,y:520,t:1527793720036};\\\", \\\"{x:136,y:520,t:1527793720043};\\\", \\\"{x:139,y:520,t:1527793720060};\\\", \\\"{x:145,y:520,t:1527793720077};\\\", \\\"{x:151,y:520,t:1527793720094};\\\", \\\"{x:164,y:515,t:1527793720111};\\\", \\\"{x:181,y:508,t:1527793720128};\\\", \\\"{x:201,y:502,t:1527793720146};\\\", \\\"{x:220,y:500,t:1527793720159};\\\", \\\"{x:235,y:499,t:1527793720177};\\\", \\\"{x:258,y:502,t:1527793720194};\\\", \\\"{x:277,y:508,t:1527793720210};\\\", \\\"{x:303,y:522,t:1527793720227};\\\", \\\"{x:339,y:542,t:1527793720243};\\\", \\\"{x:360,y:551,t:1527793720261};\\\", \\\"{x:372,y:556,t:1527793720277};\\\", \\\"{x:375,y:558,t:1527793720295};\\\", \\\"{x:377,y:558,t:1527793720311};\\\", \\\"{x:377,y:559,t:1527793720347};\\\", \\\"{x:376,y:559,t:1527793720361};\\\", \\\"{x:376,y:560,t:1527793720377};\\\", \\\"{x:380,y:569,t:1527793720394};\\\", \\\"{x:388,y:574,t:1527793720411};\\\", \\\"{x:396,y:578,t:1527793720428};\\\", \\\"{x:411,y:580,t:1527793720444};\\\", \\\"{x:427,y:582,t:1527793720461};\\\", \\\"{x:450,y:580,t:1527793720477};\\\", \\\"{x:505,y:571,t:1527793720494};\\\", \\\"{x:564,y:560,t:1527793720511};\\\", \\\"{x:618,y:555,t:1527793720527};\\\", \\\"{x:646,y:549,t:1527793720544};\\\", \\\"{x:668,y:547,t:1527793720561};\\\", \\\"{x:685,y:545,t:1527793720577};\\\", \\\"{x:711,y:540,t:1527793720594};\\\", \\\"{x:741,y:535,t:1527793720611};\\\", \\\"{x:767,y:533,t:1527793720627};\\\", \\\"{x:792,y:530,t:1527793720644};\\\", \\\"{x:802,y:528,t:1527793720661};\\\", \\\"{x:810,y:525,t:1527793720677};\\\", \\\"{x:815,y:523,t:1527793720694};\\\", \\\"{x:821,y:518,t:1527793720711};\\\", \\\"{x:825,y:514,t:1527793720728};\\\", \\\"{x:826,y:510,t:1527793720744};\\\", \\\"{x:832,y:508,t:1527793720762};\\\", \\\"{x:846,y:507,t:1527793720777};\\\", \\\"{x:862,y:503,t:1527793720794};\\\", \\\"{x:874,y:499,t:1527793720812};\\\", \\\"{x:875,y:498,t:1527793720828};\\\", \\\"{x:876,y:497,t:1527793720868};\\\", \\\"{x:876,y:495,t:1527793720884};\\\", \\\"{x:876,y:492,t:1527793720900};\\\", \\\"{x:876,y:491,t:1527793720911};\\\", \\\"{x:876,y:488,t:1527793720928};\\\", \\\"{x:876,y:487,t:1527793720972};\\\", \\\"{x:876,y:486,t:1527793720980};\\\", \\\"{x:865,y:492,t:1527793721356};\\\", \\\"{x:849,y:502,t:1527793721363};\\\", \\\"{x:825,y:515,t:1527793721378};\\\", \\\"{x:753,y:548,t:1527793721396};\\\", \\\"{x:661,y:589,t:1527793721412};\\\", \\\"{x:524,y:651,t:1527793721428};\\\", \\\"{x:482,y:674,t:1527793721446};\\\", \\\"{x:464,y:684,t:1527793721461};\\\", \\\"{x:461,y:688,t:1527793721478};\\\", \\\"{x:459,y:693,t:1527793721495};\\\", \\\"{x:459,y:695,t:1527793721512};\\\", \\\"{x:460,y:699,t:1527793721528};\\\", \\\"{x:462,y:699,t:1527793721545};\\\", \\\"{x:464,y:699,t:1527793721571};\\\", \\\"{x:469,y:698,t:1527793721580};\\\", \\\"{x:477,y:695,t:1527793721595};\\\", \\\"{x:511,y:673,t:1527793721612};\\\", \\\"{x:533,y:657,t:1527793721628};\\\", \\\"{x:569,y:629,t:1527793721646};\\\", \\\"{x:613,y:603,t:1527793721662};\\\", \\\"{x:657,y:578,t:1527793721679};\\\", \\\"{x:673,y:568,t:1527793721694};\\\", \\\"{x:690,y:563,t:1527793721712};\\\", \\\"{x:708,y:562,t:1527793721728};\\\", \\\"{x:723,y:560,t:1527793721745};\\\", \\\"{x:730,y:559,t:1527793721763};\\\", \\\"{x:733,y:559,t:1527793721778};\\\", \\\"{x:735,y:559,t:1527793721795};\\\", \\\"{x:736,y:559,t:1527793721860};\\\", \\\"{x:736,y:558,t:1527793721868};\\\", \\\"{x:739,y:556,t:1527793721878};\\\", \\\"{x:745,y:545,t:1527793721897};\\\", \\\"{x:755,y:528,t:1527793721912};\\\", \\\"{x:767,y:512,t:1527793721929};\\\", \\\"{x:781,y:502,t:1527793721946};\\\", \\\"{x:789,y:495,t:1527793721962};\\\", \\\"{x:796,y:490,t:1527793721978};\\\", \\\"{x:807,y:480,t:1527793721995};\\\", \\\"{x:810,y:478,t:1527793722012};\\\", \\\"{x:811,y:476,t:1527793722028};\\\", \\\"{x:814,y:479,t:1527793722099};\\\", \\\"{x:815,y:480,t:1527793722112};\\\", \\\"{x:820,y:485,t:1527793722128};\\\", \\\"{x:823,y:488,t:1527793722145};\\\", \\\"{x:824,y:489,t:1527793722164};\\\", \\\"{x:826,y:490,t:1527793722178};\\\", \\\"{x:825,y:494,t:1527793722403};\\\", \\\"{x:810,y:502,t:1527793722413};\\\", \\\"{x:771,y:527,t:1527793722429};\\\", \\\"{x:692,y:572,t:1527793722446};\\\", \\\"{x:605,y:626,t:1527793722462};\\\", \\\"{x:532,y:661,t:1527793722479};\\\", \\\"{x:477,y:684,t:1527793722495};\\\", \\\"{x:447,y:697,t:1527793722511};\\\", \\\"{x:438,y:703,t:1527793722529};\\\", \\\"{x:435,y:706,t:1527793722545};\\\", \\\"{x:434,y:707,t:1527793722562};\\\", \\\"{x:435,y:707,t:1527793722684};\\\", \\\"{x:440,y:705,t:1527793722696};\\\", \\\"{x:442,y:704,t:1527793722713};\\\", \\\"{x:444,y:702,t:1527793722788};\\\", \\\"{x:450,y:700,t:1527793722798};\\\", \\\"{x:462,y:691,t:1527793722813};\\\", \\\"{x:474,y:685,t:1527793722829};\\\", \\\"{x:480,y:681,t:1527793722846};\\\", \\\"{x:486,y:679,t:1527793722862};\\\", \\\"{x:489,y:679,t:1527793723155};\\\", \\\"{x:491,y:679,t:1527793723163};\\\", \\\"{x:495,y:679,t:1527793723179};\\\", \\\"{x:504,y:677,t:1527793723196};\\\" ] }, { \\\"rt\\\": 13876, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 264012, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:677,t:1527793726269};\\\", \\\"{x:507,y:677,t:1527793726292};\\\", \\\"{x:509,y:677,t:1527793726323};\\\", \\\"{x:511,y:676,t:1527793726340};\\\", \\\"{x:513,y:676,t:1527793726348};\\\", \\\"{x:517,y:676,t:1527793726365};\\\", \\\"{x:522,y:676,t:1527793726382};\\\", \\\"{x:527,y:676,t:1527793726398};\\\", \\\"{x:537,y:675,t:1527793726416};\\\", \\\"{x:547,y:674,t:1527793726432};\\\", \\\"{x:557,y:673,t:1527793726449};\\\", \\\"{x:567,y:672,t:1527793726466};\\\", \\\"{x:581,y:670,t:1527793726483};\\\", \\\"{x:595,y:670,t:1527793726498};\\\", \\\"{x:613,y:670,t:1527793726515};\\\", \\\"{x:618,y:670,t:1527793726532};\\\", \\\"{x:621,y:670,t:1527793726549};\\\", \\\"{x:623,y:669,t:1527793726596};\\\", \\\"{x:626,y:669,t:1527793726603};\\\", \\\"{x:628,y:668,t:1527793726615};\\\", \\\"{x:632,y:665,t:1527793726632};\\\", \\\"{x:633,y:665,t:1527793732564};\\\", \\\"{x:634,y:666,t:1527793735421};\\\", \\\"{x:636,y:666,t:1527793735428};\\\", \\\"{x:639,y:666,t:1527793735440};\\\", \\\"{x:646,y:664,t:1527793735456};\\\", \\\"{x:653,y:657,t:1527793735472};\\\", \\\"{x:653,y:656,t:1527793735489};\\\", \\\"{x:660,y:646,t:1527793735506};\\\", \\\"{x:662,y:633,t:1527793735523};\\\", \\\"{x:669,y:590,t:1527793735539};\\\", \\\"{x:673,y:568,t:1527793735557};\\\", \\\"{x:684,y:548,t:1527793735572};\\\", \\\"{x:696,y:530,t:1527793735590};\\\", \\\"{x:703,y:520,t:1527793735607};\\\", \\\"{x:706,y:515,t:1527793735623};\\\", \\\"{x:708,y:512,t:1527793735639};\\\", \\\"{x:708,y:510,t:1527793735657};\\\", \\\"{x:707,y:506,t:1527793735673};\\\", \\\"{x:693,y:506,t:1527793735690};\\\", \\\"{x:672,y:506,t:1527793735706};\\\", \\\"{x:648,y:505,t:1527793735723};\\\", \\\"{x:614,y:503,t:1527793735739};\\\", \\\"{x:589,y:498,t:1527793735757};\\\", \\\"{x:566,y:494,t:1527793735774};\\\", \\\"{x:559,y:491,t:1527793735789};\\\", \\\"{x:557,y:489,t:1527793735806};\\\", \\\"{x:557,y:486,t:1527793735824};\\\", \\\"{x:561,y:480,t:1527793735839};\\\", \\\"{x:565,y:476,t:1527793735857};\\\", \\\"{x:569,y:472,t:1527793735874};\\\", \\\"{x:575,y:468,t:1527793735890};\\\", \\\"{x:581,y:465,t:1527793735907};\\\", \\\"{x:596,y:461,t:1527793735924};\\\", \\\"{x:608,y:457,t:1527793735940};\\\", \\\"{x:618,y:457,t:1527793735957};\\\", \\\"{x:635,y:457,t:1527793735975};\\\", \\\"{x:656,y:458,t:1527793735990};\\\", \\\"{x:674,y:455,t:1527793736006};\\\", \\\"{x:687,y:448,t:1527793736024};\\\", \\\"{x:702,y:441,t:1527793736040};\\\", \\\"{x:714,y:436,t:1527793736057};\\\", \\\"{x:728,y:435,t:1527793736075};\\\", \\\"{x:739,y:434,t:1527793736090};\\\", \\\"{x:753,y:434,t:1527793736107};\\\", \\\"{x:782,y:434,t:1527793736123};\\\", \\\"{x:794,y:434,t:1527793736140};\\\", \\\"{x:797,y:434,t:1527793736157};\\\", \\\"{x:799,y:434,t:1527793736173};\\\", \\\"{x:801,y:434,t:1527793736190};\\\", \\\"{x:809,y:439,t:1527793736207};\\\", \\\"{x:819,y:444,t:1527793736224};\\\", \\\"{x:824,y:449,t:1527793736240};\\\", \\\"{x:827,y:451,t:1527793736258};\\\", \\\"{x:828,y:451,t:1527793736274};\\\", \\\"{x:829,y:452,t:1527793736539};\\\", \\\"{x:829,y:455,t:1527793736547};\\\", \\\"{x:813,y:458,t:1527793736558};\\\", \\\"{x:766,y:479,t:1527793736575};\\\", \\\"{x:688,y:513,t:1527793736591};\\\", \\\"{x:572,y:548,t:1527793736607};\\\", \\\"{x:437,y:578,t:1527793736624};\\\", \\\"{x:310,y:597,t:1527793736641};\\\", \\\"{x:227,y:606,t:1527793736657};\\\", \\\"{x:192,y:611,t:1527793736674};\\\", \\\"{x:178,y:612,t:1527793736691};\\\", \\\"{x:171,y:612,t:1527793736707};\\\", \\\"{x:167,y:612,t:1527793736724};\\\", \\\"{x:167,y:609,t:1527793736740};\\\", \\\"{x:166,y:605,t:1527793736757};\\\", \\\"{x:157,y:595,t:1527793736773};\\\", \\\"{x:150,y:585,t:1527793736791};\\\", \\\"{x:148,y:581,t:1527793736808};\\\", \\\"{x:147,y:573,t:1527793736825};\\\", \\\"{x:149,y:567,t:1527793736841};\\\", \\\"{x:155,y:554,t:1527793736858};\\\", \\\"{x:161,y:542,t:1527793736875};\\\", \\\"{x:167,y:530,t:1527793736891};\\\", \\\"{x:175,y:514,t:1527793736908};\\\", \\\"{x:180,y:501,t:1527793736926};\\\", \\\"{x:181,y:488,t:1527793736941};\\\", \\\"{x:181,y:479,t:1527793736958};\\\", \\\"{x:181,y:475,t:1527793736974};\\\", \\\"{x:183,y:472,t:1527793736991};\\\", \\\"{x:183,y:470,t:1527793737052};\\\", \\\"{x:183,y:469,t:1527793737068};\\\", \\\"{x:183,y:471,t:1527793737363};\\\", \\\"{x:182,y:473,t:1527793737375};\\\", \\\"{x:182,y:479,t:1527793737392};\\\", \\\"{x:180,y:480,t:1527793737408};\\\", \\\"{x:180,y:483,t:1527793737643};\\\", \\\"{x:183,y:484,t:1527793737657};\\\", \\\"{x:210,y:503,t:1527793737676};\\\", \\\"{x:313,y:570,t:1527793737691};\\\", \\\"{x:388,y:620,t:1527793737708};\\\", \\\"{x:449,y:661,t:1527793737725};\\\", \\\"{x:491,y:691,t:1527793737742};\\\", \\\"{x:517,y:707,t:1527793737758};\\\", \\\"{x:526,y:713,t:1527793737775};\\\", \\\"{x:528,y:714,t:1527793737791};\\\", \\\"{x:528,y:712,t:1527793737917};\\\", \\\"{x:527,y:709,t:1527793737925};\\\", \\\"{x:527,y:708,t:1527793737948};\\\", \\\"{x:527,y:707,t:1527793737980};\\\", \\\"{x:527,y:704,t:1527793738012};\\\", \\\"{x:526,y:702,t:1527793738025};\\\", \\\"{x:525,y:698,t:1527793738043};\\\", \\\"{x:523,y:695,t:1527793738059};\\\", \\\"{x:523,y:694,t:1527793738074};\\\" ] }, { \\\"rt\\\": 48773, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 314056, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -J -B -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:693,t:1527793740477};\\\", \\\"{x:522,y:693,t:1527793740587};\\\", \\\"{x:520,y:693,t:1527793740595};\\\", \\\"{x:519,y:692,t:1527793740610};\\\", \\\"{x:512,y:689,t:1527793740626};\\\", \\\"{x:496,y:684,t:1527793740643};\\\", \\\"{x:483,y:680,t:1527793740661};\\\", \\\"{x:474,y:678,t:1527793740677};\\\", \\\"{x:471,y:677,t:1527793740694};\\\", \\\"{x:470,y:677,t:1527793740711};\\\", \\\"{x:469,y:677,t:1527793740727};\\\", \\\"{x:468,y:677,t:1527793740828};\\\", \\\"{x:467,y:677,t:1527793740844};\\\", \\\"{x:467,y:678,t:1527793740908};\\\", \\\"{x:467,y:679,t:1527793741652};\\\", \\\"{x:467,y:680,t:1527793741692};\\\", \\\"{x:468,y:680,t:1527793741724};\\\", \\\"{x:469,y:680,t:1527793741732};\\\", \\\"{x:470,y:681,t:1527793741748};\\\", \\\"{x:472,y:682,t:1527793741772};\\\", \\\"{x:473,y:682,t:1527793741780};\\\", \\\"{x:475,y:682,t:1527793742100};\\\", \\\"{x:481,y:683,t:1527793742111};\\\", \\\"{x:485,y:683,t:1527793742129};\\\", \\\"{x:486,y:683,t:1527793742612};\\\", \\\"{x:487,y:684,t:1527793742683};\\\", \\\"{x:488,y:684,t:1527793743356};\\\", \\\"{x:489,y:684,t:1527793744555};\\\", \\\"{x:490,y:682,t:1527793745139};\\\", \\\"{x:491,y:680,t:1527793745146};\\\", \\\"{x:492,y:677,t:1527793745163};\\\", \\\"{x:492,y:676,t:1527793745180};\\\", \\\"{x:492,y:675,t:1527793745451};\\\", \\\"{x:492,y:673,t:1527793745464};\\\", \\\"{x:493,y:672,t:1527793745482};\\\", \\\"{x:492,y:673,t:1527793745651};\\\", \\\"{x:491,y:674,t:1527793745664};\\\", \\\"{x:490,y:675,t:1527793745739};\\\", \\\"{x:492,y:675,t:1527793746524};\\\", \\\"{x:496,y:675,t:1527793746531};\\\", \\\"{x:507,y:675,t:1527793746548};\\\", \\\"{x:523,y:675,t:1527793746565};\\\", \\\"{x:554,y:675,t:1527793746581};\\\", \\\"{x:626,y:675,t:1527793746598};\\\", \\\"{x:726,y:675,t:1527793746615};\\\", \\\"{x:826,y:675,t:1527793746631};\\\", \\\"{x:937,y:662,t:1527793746648};\\\", \\\"{x:1029,y:645,t:1527793746665};\\\", \\\"{x:1090,y:628,t:1527793746681};\\\", \\\"{x:1118,y:621,t:1527793746698};\\\", \\\"{x:1136,y:612,t:1527793746715};\\\", \\\"{x:1140,y:609,t:1527793746731};\\\", \\\"{x:1144,y:604,t:1527793746748};\\\", \\\"{x:1154,y:593,t:1527793746765};\\\", \\\"{x:1165,y:578,t:1527793746781};\\\", \\\"{x:1173,y:567,t:1527793746798};\\\", \\\"{x:1174,y:565,t:1527793746815};\\\", \\\"{x:1177,y:561,t:1527793746831};\\\", \\\"{x:1178,y:557,t:1527793746848};\\\", \\\"{x:1178,y:554,t:1527793746865};\\\", \\\"{x:1178,y:551,t:1527793746881};\\\", \\\"{x:1182,y:546,t:1527793746898};\\\", \\\"{x:1190,y:535,t:1527793746915};\\\", \\\"{x:1199,y:524,t:1527793746931};\\\", \\\"{x:1209,y:517,t:1527793746948};\\\", \\\"{x:1225,y:506,t:1527793746965};\\\", \\\"{x:1245,y:501,t:1527793746981};\\\", \\\"{x:1267,y:496,t:1527793746998};\\\", \\\"{x:1286,y:494,t:1527793747016};\\\", \\\"{x:1306,y:491,t:1527793747032};\\\", \\\"{x:1316,y:489,t:1527793747048};\\\", \\\"{x:1323,y:486,t:1527793747065};\\\", \\\"{x:1325,y:486,t:1527793747082};\\\", \\\"{x:1327,y:485,t:1527793747268};\\\", \\\"{x:1327,y:484,t:1527793747282};\\\", \\\"{x:1327,y:482,t:1527793747298};\\\", \\\"{x:1327,y:480,t:1527793747316};\\\", \\\"{x:1327,y:479,t:1527793747333};\\\", \\\"{x:1327,y:477,t:1527793747348};\\\", \\\"{x:1327,y:473,t:1527793747365};\\\", \\\"{x:1327,y:470,t:1527793747382};\\\", \\\"{x:1327,y:469,t:1527793747398};\\\", \\\"{x:1327,y:468,t:1527793747415};\\\", \\\"{x:1327,y:467,t:1527793747507};\\\", \\\"{x:1327,y:466,t:1527793747523};\\\", \\\"{x:1327,y:465,t:1527793747532};\\\", \\\"{x:1328,y:463,t:1527793747548};\\\", \\\"{x:1328,y:462,t:1527793747579};\\\", \\\"{x:1328,y:461,t:1527793747587};\\\", \\\"{x:1328,y:460,t:1527793747603};\\\", \\\"{x:1328,y:459,t:1527793747615};\\\", \\\"{x:1328,y:458,t:1527793747635};\\\", \\\"{x:1329,y:457,t:1527793748395};\\\", \\\"{x:1329,y:459,t:1527793748444};\\\", \\\"{x:1328,y:461,t:1527793748451};\\\", \\\"{x:1327,y:462,t:1527793748466};\\\", \\\"{x:1324,y:465,t:1527793748482};\\\", \\\"{x:1320,y:469,t:1527793748499};\\\", \\\"{x:1314,y:473,t:1527793748516};\\\", \\\"{x:1308,y:477,t:1527793748532};\\\", \\\"{x:1303,y:479,t:1527793748549};\\\", \\\"{x:1301,y:481,t:1527793748566};\\\", \\\"{x:1300,y:483,t:1527793748582};\\\", \\\"{x:1297,y:486,t:1527793748599};\\\", \\\"{x:1295,y:488,t:1527793748616};\\\", \\\"{x:1294,y:493,t:1527793748632};\\\", \\\"{x:1293,y:494,t:1527793748649};\\\", \\\"{x:1293,y:495,t:1527793748666};\\\", \\\"{x:1291,y:498,t:1527793748682};\\\", \\\"{x:1289,y:500,t:1527793748699};\\\", \\\"{x:1289,y:501,t:1527793748716};\\\", \\\"{x:1288,y:504,t:1527793748732};\\\", \\\"{x:1287,y:505,t:1527793748755};\\\", \\\"{x:1286,y:505,t:1527793748766};\\\", \\\"{x:1285,y:507,t:1527793748784};\\\", \\\"{x:1284,y:509,t:1527793748799};\\\", \\\"{x:1283,y:510,t:1527793748816};\\\", \\\"{x:1282,y:510,t:1527793748859};\\\", \\\"{x:1281,y:510,t:1527793750980};\\\", \\\"{x:1279,y:510,t:1527793750987};\\\", \\\"{x:1278,y:511,t:1527793751002};\\\", \\\"{x:1277,y:512,t:1527793751018};\\\", \\\"{x:1277,y:513,t:1527793751404};\\\", \\\"{x:1277,y:519,t:1527793751419};\\\", \\\"{x:1277,y:526,t:1527793751434};\\\", \\\"{x:1277,y:540,t:1527793751451};\\\", \\\"{x:1278,y:550,t:1527793751468};\\\", \\\"{x:1278,y:557,t:1527793751484};\\\", \\\"{x:1278,y:568,t:1527793751502};\\\", \\\"{x:1276,y:579,t:1527793751519};\\\", \\\"{x:1276,y:593,t:1527793751535};\\\", \\\"{x:1276,y:607,t:1527793751552};\\\", \\\"{x:1280,y:623,t:1527793751569};\\\", \\\"{x:1286,y:640,t:1527793751584};\\\", \\\"{x:1292,y:653,t:1527793751602};\\\", \\\"{x:1300,y:667,t:1527793751619};\\\", \\\"{x:1310,y:680,t:1527793751634};\\\", \\\"{x:1325,y:691,t:1527793751651};\\\", \\\"{x:1335,y:696,t:1527793751669};\\\", \\\"{x:1335,y:697,t:1527793751685};\\\", \\\"{x:1337,y:699,t:1527793751701};\\\", \\\"{x:1338,y:699,t:1527793751747};\\\", \\\"{x:1340,y:700,t:1527793752355};\\\", \\\"{x:1341,y:701,t:1527793752371};\\\", \\\"{x:1341,y:702,t:1527793752386};\\\", \\\"{x:1342,y:704,t:1527793752402};\\\", \\\"{x:1344,y:707,t:1527793752419};\\\", \\\"{x:1346,y:713,t:1527793752435};\\\", \\\"{x:1349,y:720,t:1527793752453};\\\", \\\"{x:1352,y:728,t:1527793752468};\\\", \\\"{x:1360,y:740,t:1527793752485};\\\", \\\"{x:1363,y:744,t:1527793752503};\\\", \\\"{x:1363,y:746,t:1527793752518};\\\", \\\"{x:1363,y:747,t:1527793752535};\\\", \\\"{x:1364,y:748,t:1527793752552};\\\", \\\"{x:1365,y:748,t:1527793752568};\\\", \\\"{x:1365,y:747,t:1527793752587};\\\", \\\"{x:1365,y:746,t:1527793752602};\\\", \\\"{x:1365,y:744,t:1527793752618};\\\", \\\"{x:1364,y:742,t:1527793752635};\\\", \\\"{x:1361,y:740,t:1527793752652};\\\", \\\"{x:1358,y:739,t:1527793752669};\\\", \\\"{x:1355,y:739,t:1527793752685};\\\", \\\"{x:1351,y:738,t:1527793752703};\\\", \\\"{x:1342,y:738,t:1527793752719};\\\", \\\"{x:1330,y:738,t:1527793752736};\\\", \\\"{x:1313,y:740,t:1527793752753};\\\", \\\"{x:1289,y:749,t:1527793752768};\\\", \\\"{x:1262,y:761,t:1527793752786};\\\", \\\"{x:1238,y:769,t:1527793752802};\\\", \\\"{x:1221,y:774,t:1527793752818};\\\", \\\"{x:1215,y:778,t:1527793752835};\\\", \\\"{x:1214,y:778,t:1527793752875};\\\", \\\"{x:1214,y:779,t:1527793752898};\\\", \\\"{x:1214,y:780,t:1527793752931};\\\", \\\"{x:1214,y:781,t:1527793752938};\\\", \\\"{x:1215,y:782,t:1527793752952};\\\", \\\"{x:1218,y:782,t:1527793752969};\\\", \\\"{x:1222,y:782,t:1527793752986};\\\", \\\"{x:1226,y:782,t:1527793753002};\\\", \\\"{x:1230,y:781,t:1527793753019};\\\", \\\"{x:1231,y:780,t:1527793753035};\\\", \\\"{x:1230,y:779,t:1527793754107};\\\", \\\"{x:1229,y:777,t:1527793754124};\\\", \\\"{x:1228,y:776,t:1527793754137};\\\", \\\"{x:1226,y:774,t:1527793754155};\\\", \\\"{x:1225,y:773,t:1527793754171};\\\", \\\"{x:1225,y:772,t:1527793754187};\\\", \\\"{x:1224,y:770,t:1527793754204};\\\", \\\"{x:1222,y:767,t:1527793754220};\\\", \\\"{x:1221,y:765,t:1527793754237};\\\", \\\"{x:1219,y:762,t:1527793754254};\\\", \\\"{x:1219,y:761,t:1527793754283};\\\", \\\"{x:1218,y:761,t:1527793754291};\\\", \\\"{x:1218,y:760,t:1527793754304};\\\", \\\"{x:1218,y:759,t:1527793754320};\\\", \\\"{x:1216,y:757,t:1527793754336};\\\", \\\"{x:1215,y:755,t:1527793754354};\\\", \\\"{x:1214,y:754,t:1527793754370};\\\", \\\"{x:1214,y:752,t:1527793754386};\\\", \\\"{x:1211,y:747,t:1527793754403};\\\", \\\"{x:1208,y:743,t:1527793754419};\\\", \\\"{x:1206,y:741,t:1527793754437};\\\", \\\"{x:1204,y:738,t:1527793754454};\\\", \\\"{x:1202,y:735,t:1527793754470};\\\", \\\"{x:1200,y:734,t:1527793754487};\\\", \\\"{x:1195,y:731,t:1527793754504};\\\", \\\"{x:1191,y:728,t:1527793754520};\\\", \\\"{x:1183,y:725,t:1527793754536};\\\", \\\"{x:1179,y:723,t:1527793754553};\\\", \\\"{x:1175,y:720,t:1527793754570};\\\", \\\"{x:1173,y:719,t:1527793754587};\\\", \\\"{x:1173,y:718,t:1527793754604};\\\", \\\"{x:1173,y:717,t:1527793754659};\\\", \\\"{x:1173,y:716,t:1527793754675};\\\", \\\"{x:1173,y:714,t:1527793754691};\\\", \\\"{x:1173,y:713,t:1527793754715};\\\", \\\"{x:1173,y:712,t:1527793754731};\\\", \\\"{x:1173,y:711,t:1527793754739};\\\", \\\"{x:1173,y:710,t:1527793754755};\\\", \\\"{x:1173,y:709,t:1527793754771};\\\", \\\"{x:1173,y:708,t:1527793754787};\\\", \\\"{x:1174,y:708,t:1527793760725};\\\", \\\"{x:1202,y:708,t:1527793760742};\\\", \\\"{x:1229,y:709,t:1527793760758};\\\", \\\"{x:1289,y:713,t:1527793760774};\\\", \\\"{x:1347,y:719,t:1527793760791};\\\", \\\"{x:1371,y:722,t:1527793760808};\\\", \\\"{x:1381,y:722,t:1527793760824};\\\", \\\"{x:1383,y:722,t:1527793760841};\\\", \\\"{x:1384,y:722,t:1527793760876};\\\", \\\"{x:1384,y:721,t:1527793760892};\\\", \\\"{x:1384,y:719,t:1527793760908};\\\", \\\"{x:1386,y:719,t:1527793760926};\\\", \\\"{x:1387,y:719,t:1527793761005};\\\", \\\"{x:1386,y:719,t:1527793761092};\\\", \\\"{x:1384,y:718,t:1527793761108};\\\", \\\"{x:1382,y:717,t:1527793761124};\\\", \\\"{x:1381,y:717,t:1527793761147};\\\", \\\"{x:1380,y:717,t:1527793761588};\\\", \\\"{x:1379,y:717,t:1527793761596};\\\", \\\"{x:1378,y:717,t:1527793761609};\\\", \\\"{x:1377,y:717,t:1527793761635};\\\", \\\"{x:1375,y:717,t:1527793761644};\\\", \\\"{x:1374,y:717,t:1527793761660};\\\", \\\"{x:1371,y:717,t:1527793761676};\\\", \\\"{x:1370,y:717,t:1527793761691};\\\", \\\"{x:1369,y:717,t:1527793761708};\\\", \\\"{x:1366,y:717,t:1527793761725};\\\", \\\"{x:1365,y:717,t:1527793761742};\\\", \\\"{x:1362,y:717,t:1527793761759};\\\", \\\"{x:1361,y:717,t:1527793761779};\\\", \\\"{x:1360,y:717,t:1527793761796};\\\", \\\"{x:1359,y:717,t:1527793761808};\\\", \\\"{x:1358,y:717,t:1527793761826};\\\", \\\"{x:1358,y:716,t:1527793761876};\\\", \\\"{x:1357,y:716,t:1527793761893};\\\", \\\"{x:1356,y:716,t:1527793762229};\\\", \\\"{x:1355,y:716,t:1527793764724};\\\", \\\"{x:1355,y:715,t:1527793764780};\\\", \\\"{x:1354,y:714,t:1527793764794};\\\", \\\"{x:1353,y:713,t:1527793764812};\\\", \\\"{x:1353,y:712,t:1527793764828};\\\", \\\"{x:1352,y:712,t:1527793764876};\\\", \\\"{x:1352,y:711,t:1527793764892};\\\", \\\"{x:1352,y:710,t:1527793767988};\\\", \\\"{x:1352,y:709,t:1527793768020};\\\", \\\"{x:1352,y:708,t:1527793768035};\\\", \\\"{x:1354,y:708,t:1527793768821};\\\", \\\"{x:1358,y:708,t:1527793768830};\\\", \\\"{x:1372,y:709,t:1527793768847};\\\", \\\"{x:1386,y:710,t:1527793768864};\\\", \\\"{x:1397,y:710,t:1527793768881};\\\", \\\"{x:1407,y:712,t:1527793768898};\\\", \\\"{x:1413,y:712,t:1527793768914};\\\", \\\"{x:1418,y:712,t:1527793768930};\\\", \\\"{x:1424,y:712,t:1527793768946};\\\", \\\"{x:1427,y:714,t:1527793768963};\\\", \\\"{x:1431,y:715,t:1527793768980};\\\", \\\"{x:1436,y:717,t:1527793768996};\\\", \\\"{x:1442,y:719,t:1527793769014};\\\", \\\"{x:1446,y:720,t:1527793769030};\\\", \\\"{x:1449,y:721,t:1527793769046};\\\", \\\"{x:1452,y:723,t:1527793769064};\\\", \\\"{x:1454,y:724,t:1527793769081};\\\", \\\"{x:1456,y:725,t:1527793769096};\\\", \\\"{x:1459,y:730,t:1527793769113};\\\", \\\"{x:1461,y:736,t:1527793769130};\\\", \\\"{x:1463,y:741,t:1527793769146};\\\", \\\"{x:1463,y:745,t:1527793769163};\\\", \\\"{x:1463,y:746,t:1527793769181};\\\", \\\"{x:1463,y:748,t:1527793769196};\\\", \\\"{x:1463,y:750,t:1527793769214};\\\", \\\"{x:1463,y:752,t:1527793769230};\\\", \\\"{x:1463,y:755,t:1527793769246};\\\", \\\"{x:1465,y:756,t:1527793769263};\\\", \\\"{x:1465,y:757,t:1527793769281};\\\", \\\"{x:1466,y:757,t:1527793769307};\\\", \\\"{x:1468,y:757,t:1527793769315};\\\", \\\"{x:1470,y:759,t:1527793769331};\\\", \\\"{x:1473,y:760,t:1527793769346};\\\", \\\"{x:1475,y:761,t:1527793769364};\\\", \\\"{x:1475,y:762,t:1527793769381};\\\", \\\"{x:1476,y:762,t:1527793769397};\\\", \\\"{x:1476,y:763,t:1527793769452};\\\", \\\"{x:1476,y:764,t:1527793769467};\\\", \\\"{x:1477,y:765,t:1527793769480};\\\", \\\"{x:1479,y:768,t:1527793769515};\\\", \\\"{x:1480,y:769,t:1527793769530};\\\", \\\"{x:1483,y:773,t:1527793769548};\\\", \\\"{x:1483,y:774,t:1527793769581};\\\", \\\"{x:1484,y:774,t:1527793769900};\\\", \\\"{x:1485,y:774,t:1527793769915};\\\", \\\"{x:1485,y:773,t:1527793769931};\\\", \\\"{x:1488,y:769,t:1527793769949};\\\", \\\"{x:1491,y:765,t:1527793769964};\\\", \\\"{x:1495,y:760,t:1527793769981};\\\", \\\"{x:1498,y:752,t:1527793769997};\\\", \\\"{x:1504,y:743,t:1527793770015};\\\", \\\"{x:1508,y:739,t:1527793770031};\\\", \\\"{x:1511,y:731,t:1527793770047};\\\", \\\"{x:1519,y:720,t:1527793770065};\\\", \\\"{x:1528,y:705,t:1527793770081};\\\", \\\"{x:1535,y:688,t:1527793770098};\\\", \\\"{x:1544,y:671,t:1527793770115};\\\", \\\"{x:1551,y:656,t:1527793770130};\\\", \\\"{x:1562,y:639,t:1527793770147};\\\", \\\"{x:1573,y:621,t:1527793770165};\\\", \\\"{x:1583,y:601,t:1527793770181};\\\", \\\"{x:1592,y:578,t:1527793770198};\\\", \\\"{x:1602,y:560,t:1527793770215};\\\", \\\"{x:1611,y:547,t:1527793770231};\\\", \\\"{x:1617,y:535,t:1527793770248};\\\", \\\"{x:1622,y:521,t:1527793770265};\\\", \\\"{x:1626,y:508,t:1527793770280};\\\", \\\"{x:1628,y:497,t:1527793770298};\\\", \\\"{x:1628,y:492,t:1527793770315};\\\", \\\"{x:1630,y:490,t:1527793770331};\\\", \\\"{x:1630,y:489,t:1527793770356};\\\", \\\"{x:1630,y:488,t:1527793770372};\\\", \\\"{x:1630,y:487,t:1527793770382};\\\", \\\"{x:1631,y:484,t:1527793770398};\\\", \\\"{x:1632,y:482,t:1527793770415};\\\", \\\"{x:1632,y:481,t:1527793770432};\\\", \\\"{x:1633,y:480,t:1527793770448};\\\", \\\"{x:1634,y:479,t:1527793770468};\\\", \\\"{x:1634,y:477,t:1527793770482};\\\", \\\"{x:1637,y:472,t:1527793770498};\\\", \\\"{x:1639,y:466,t:1527793770515};\\\", \\\"{x:1645,y:459,t:1527793770531};\\\", \\\"{x:1648,y:454,t:1527793770548};\\\", \\\"{x:1650,y:453,t:1527793770565};\\\", \\\"{x:1651,y:451,t:1527793770582};\\\", \\\"{x:1652,y:450,t:1527793770598};\\\", \\\"{x:1653,y:450,t:1527793770615};\\\", \\\"{x:1653,y:448,t:1527793770632};\\\", \\\"{x:1654,y:448,t:1527793770648};\\\", \\\"{x:1655,y:448,t:1527793771005};\\\", \\\"{x:1655,y:449,t:1527793771693};\\\", \\\"{x:1655,y:450,t:1527793771716};\\\", \\\"{x:1654,y:450,t:1527793771740};\\\", \\\"{x:1653,y:450,t:1527793772691};\\\", \\\"{x:1652,y:450,t:1527793772699};\\\", \\\"{x:1651,y:450,t:1527793772723};\\\", \\\"{x:1649,y:450,t:1527793772732};\\\", \\\"{x:1648,y:450,t:1527793772749};\\\", \\\"{x:1647,y:450,t:1527793775394};\\\", \\\"{x:1640,y:453,t:1527793779866};\\\", \\\"{x:1637,y:457,t:1527793779872};\\\", \\\"{x:1637,y:466,t:1527793779885};\\\", \\\"{x:1625,y:478,t:1527793779901};\\\", \\\"{x:1614,y:483,t:1527793779918};\\\", \\\"{x:1610,y:485,t:1527793779935};\\\", \\\"{x:1607,y:485,t:1527793779993};\\\", \\\"{x:1595,y:477,t:1527793780001};\\\", \\\"{x:1556,y:459,t:1527793780018};\\\", \\\"{x:1484,y:441,t:1527793780036};\\\", \\\"{x:1359,y:424,t:1527793780052};\\\", \\\"{x:1216,y:411,t:1527793780068};\\\", \\\"{x:1075,y:392,t:1527793780085};\\\", \\\"{x:997,y:379,t:1527793780102};\\\", \\\"{x:945,y:375,t:1527793780119};\\\", \\\"{x:894,y:375,t:1527793780135};\\\", \\\"{x:847,y:375,t:1527793780151};\\\", \\\"{x:781,y:383,t:1527793780169};\\\", \\\"{x:744,y:389,t:1527793780185};\\\", \\\"{x:714,y:397,t:1527793780201};\\\", \\\"{x:676,y:405,t:1527793780218};\\\", \\\"{x:631,y:412,t:1527793780235};\\\", \\\"{x:594,y:418,t:1527793780251};\\\", \\\"{x:571,y:420,t:1527793780268};\\\", \\\"{x:560,y:425,t:1527793780286};\\\", \\\"{x:558,y:427,t:1527793780301};\\\", \\\"{x:557,y:429,t:1527793780318};\\\", \\\"{x:555,y:431,t:1527793780335};\\\", \\\"{x:550,y:437,t:1527793780353};\\\", \\\"{x:541,y:448,t:1527793780367};\\\", \\\"{x:537,y:453,t:1527793780385};\\\", \\\"{x:534,y:457,t:1527793780407};\\\", \\\"{x:531,y:460,t:1527793780423};\\\", \\\"{x:530,y:460,t:1527793780696};\\\", \\\"{x:523,y:460,t:1527793780707};\\\", \\\"{x:518,y:460,t:1527793780723};\\\", \\\"{x:506,y:460,t:1527793780740};\\\", \\\"{x:495,y:461,t:1527793780758};\\\", \\\"{x:481,y:462,t:1527793780773};\\\", \\\"{x:466,y:462,t:1527793780791};\\\", \\\"{x:447,y:462,t:1527793780807};\\\", \\\"{x:421,y:462,t:1527793780824};\\\", \\\"{x:408,y:462,t:1527793780840};\\\", \\\"{x:397,y:462,t:1527793780857};\\\", \\\"{x:392,y:462,t:1527793780874};\\\", \\\"{x:391,y:462,t:1527793780891};\\\", \\\"{x:390,y:462,t:1527793781473};\\\", \\\"{x:389,y:462,t:1527793781480};\\\", \\\"{x:388,y:462,t:1527793781569};\\\", \\\"{x:387,y:462,t:1527793781576};\\\", \\\"{x:386,y:462,t:1527793781592};\\\", \\\"{x:384,y:461,t:1527793781608};\\\", \\\"{x:379,y:460,t:1527793781625};\\\", \\\"{x:374,y:459,t:1527793781641};\\\", \\\"{x:366,y:457,t:1527793781658};\\\", \\\"{x:360,y:457,t:1527793781674};\\\", \\\"{x:350,y:457,t:1527793781691};\\\", \\\"{x:330,y:457,t:1527793781708};\\\", \\\"{x:304,y:457,t:1527793781725};\\\", \\\"{x:268,y:457,t:1527793781741};\\\", \\\"{x:241,y:457,t:1527793781758};\\\", \\\"{x:218,y:457,t:1527793781775};\\\", \\\"{x:199,y:457,t:1527793781791};\\\", \\\"{x:190,y:455,t:1527793781808};\\\", \\\"{x:188,y:455,t:1527793781825};\\\", \\\"{x:188,y:454,t:1527793781841};\\\", \\\"{x:189,y:453,t:1527793781858};\\\", \\\"{x:189,y:452,t:1527793781875};\\\", \\\"{x:189,y:451,t:1527793781905};\\\", \\\"{x:189,y:450,t:1527793781912};\\\", \\\"{x:189,y:449,t:1527793781928};\\\", \\\"{x:188,y:449,t:1527793781953};\\\", \\\"{x:189,y:449,t:1527793783640};\\\", \\\"{x:195,y:449,t:1527793783649};\\\", \\\"{x:206,y:449,t:1527793783661};\\\", \\\"{x:229,y:453,t:1527793783677};\\\", \\\"{x:253,y:456,t:1527793783694};\\\", \\\"{x:277,y:464,t:1527793783712};\\\", \\\"{x:295,y:471,t:1527793783726};\\\", \\\"{x:315,y:478,t:1527793783744};\\\", \\\"{x:340,y:495,t:1527793783759};\\\", \\\"{x:376,y:526,t:1527793783777};\\\", \\\"{x:408,y:547,t:1527793783794};\\\", \\\"{x:430,y:566,t:1527793783810};\\\", \\\"{x:469,y:597,t:1527793783826};\\\", \\\"{x:511,y:625,t:1527793783843};\\\", \\\"{x:571,y:661,t:1527793783860};\\\", \\\"{x:629,y:697,t:1527793783876};\\\", \\\"{x:667,y:719,t:1527793783893};\\\", \\\"{x:691,y:733,t:1527793783910};\\\", \\\"{x:695,y:739,t:1527793783926};\\\", \\\"{x:695,y:741,t:1527793783943};\\\", \\\"{x:695,y:742,t:1527793784009};\\\", \\\"{x:691,y:742,t:1527793785729};\\\", \\\"{x:646,y:742,t:1527793785745};\\\", \\\"{x:555,y:742,t:1527793785762};\\\", \\\"{x:460,y:742,t:1527793785778};\\\", \\\"{x:369,y:731,t:1527793785796};\\\", \\\"{x:293,y:715,t:1527793785811};\\\", \\\"{x:243,y:702,t:1527793785829};\\\", \\\"{x:225,y:693,t:1527793785845};\\\", \\\"{x:220,y:685,t:1527793785861};\\\", \\\"{x:220,y:672,t:1527793785878};\\\", \\\"{x:222,y:660,t:1527793785896};\\\", \\\"{x:227,y:648,t:1527793785912};\\\", \\\"{x:227,y:636,t:1527793785928};\\\", \\\"{x:227,y:623,t:1527793785945};\\\", \\\"{x:230,y:610,t:1527793785963};\\\", \\\"{x:232,y:597,t:1527793785978};\\\", \\\"{x:236,y:584,t:1527793785996};\\\", \\\"{x:241,y:574,t:1527793786013};\\\", \\\"{x:248,y:565,t:1527793786028};\\\", \\\"{x:251,y:560,t:1527793786045};\\\", \\\"{x:256,y:548,t:1527793786061};\\\", \\\"{x:266,y:533,t:1527793786079};\\\", \\\"{x:275,y:523,t:1527793786096};\\\", \\\"{x:294,y:513,t:1527793786112};\\\", \\\"{x:312,y:508,t:1527793786128};\\\", \\\"{x:333,y:504,t:1527793786145};\\\", \\\"{x:356,y:498,t:1527793786162};\\\", \\\"{x:384,y:490,t:1527793786178};\\\", \\\"{x:405,y:482,t:1527793786195};\\\", \\\"{x:419,y:478,t:1527793786212};\\\", \\\"{x:425,y:475,t:1527793786228};\\\", \\\"{x:428,y:473,t:1527793786245};\\\", \\\"{x:429,y:472,t:1527793786261};\\\", \\\"{x:430,y:472,t:1527793786296};\\\", \\\"{x:430,y:471,t:1527793786328};\\\", \\\"{x:430,y:469,t:1527793786344};\\\", \\\"{x:430,y:468,t:1527793786362};\\\", \\\"{x:430,y:467,t:1527793786379};\\\", \\\"{x:430,y:466,t:1527793786473};\\\", \\\"{x:427,y:463,t:1527793786481};\\\", \\\"{x:411,y:463,t:1527793786495};\\\", \\\"{x:327,y:461,t:1527793786511};\\\", \\\"{x:260,y:453,t:1527793786529};\\\", \\\"{x:202,y:444,t:1527793786545};\\\", \\\"{x:156,y:437,t:1527793786562};\\\", \\\"{x:136,y:433,t:1527793786579};\\\", \\\"{x:133,y:433,t:1527793786595};\\\", \\\"{x:132,y:433,t:1527793786639};\\\", \\\"{x:132,y:435,t:1527793786649};\\\", \\\"{x:132,y:437,t:1527793786662};\\\", \\\"{x:131,y:440,t:1527793786679};\\\", \\\"{x:131,y:442,t:1527793786695};\\\", \\\"{x:129,y:445,t:1527793786712};\\\", \\\"{x:128,y:447,t:1527793786729};\\\", \\\"{x:129,y:447,t:1527793786824};\\\", \\\"{x:132,y:447,t:1527793786832};\\\", \\\"{x:134,y:447,t:1527793786846};\\\", \\\"{x:144,y:447,t:1527793786862};\\\", \\\"{x:160,y:447,t:1527793786881};\\\", \\\"{x:168,y:447,t:1527793786896};\\\", \\\"{x:171,y:447,t:1527793786912};\\\", \\\"{x:177,y:445,t:1527793787146};\\\", \\\"{x:181,y:445,t:1527793787162};\\\", \\\"{x:201,y:445,t:1527793787179};\\\", \\\"{x:225,y:445,t:1527793787196};\\\", \\\"{x:259,y:445,t:1527793787211};\\\", \\\"{x:301,y:445,t:1527793787229};\\\", \\\"{x:340,y:445,t:1527793787246};\\\", \\\"{x:360,y:445,t:1527793787262};\\\", \\\"{x:369,y:445,t:1527793787280};\\\", \\\"{x:372,y:445,t:1527793787296};\\\", \\\"{x:374,y:445,t:1527793787312};\\\", \\\"{x:376,y:444,t:1527793787329};\\\", \\\"{x:377,y:443,t:1527793787346};\\\", \\\"{x:382,y:443,t:1527793787362};\\\", \\\"{x:387,y:442,t:1527793787379};\\\", \\\"{x:388,y:442,t:1527793787396};\\\", \\\"{x:387,y:443,t:1527793787520};\\\", \\\"{x:386,y:444,t:1527793787529};\\\", \\\"{x:384,y:444,t:1527793787546};\\\", \\\"{x:382,y:446,t:1527793787563};\\\", \\\"{x:383,y:448,t:1527793787796};\\\", \\\"{x:398,y:460,t:1527793787813};\\\", \\\"{x:431,y:503,t:1527793787831};\\\", \\\"{x:471,y:566,t:1527793787847};\\\", \\\"{x:496,y:619,t:1527793787863};\\\", \\\"{x:517,y:659,t:1527793787879};\\\", \\\"{x:527,y:681,t:1527793787896};\\\", \\\"{x:530,y:690,t:1527793787913};\\\", \\\"{x:531,y:695,t:1527793787929};\\\", \\\"{x:532,y:696,t:1527793787946};\\\", \\\"{x:532,y:697,t:1527793788000};\\\", \\\"{x:532,y:698,t:1527793788013};\\\", \\\"{x:532,y:699,t:1527793788029};\\\", \\\"{x:531,y:699,t:1527793788073};\\\", \\\"{x:531,y:698,t:1527793788121};\\\", \\\"{x:530,y:697,t:1527793788130};\\\", \\\"{x:530,y:694,t:1527793788297};\\\", \\\"{x:530,y:692,t:1527793788313};\\\", \\\"{x:530,y:690,t:1527793788330};\\\", \\\"{x:530,y:689,t:1527793788347};\\\", \\\"{x:531,y:689,t:1527793788577};\\\", \\\"{x:543,y:689,t:1527793788585};\\\", \\\"{x:556,y:693,t:1527793788597};\\\", \\\"{x:622,y:711,t:1527793788613};\\\", \\\"{x:732,y:740,t:1527793788630};\\\", \\\"{x:831,y:768,t:1527793788648};\\\", \\\"{x:903,y:789,t:1527793788664};\\\", \\\"{x:947,y:802,t:1527793788680};\\\", \\\"{x:951,y:803,t:1527793788697};\\\", \\\"{x:953,y:799,t:1527793788714};\\\" ] }, { \\\"rt\\\": 16734, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 332031, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:950,y:799,t:1527793791577};\\\", \\\"{x:942,y:799,t:1527793791584};\\\", \\\"{x:934,y:799,t:1527793791600};\\\", \\\"{x:903,y:795,t:1527793791617};\\\", \\\"{x:892,y:793,t:1527793791633};\\\", \\\"{x:885,y:790,t:1527793791650};\\\", \\\"{x:884,y:790,t:1527793791667};\\\", \\\"{x:887,y:790,t:1527793796688};\\\", \\\"{x:893,y:790,t:1527793796705};\\\", \\\"{x:894,y:789,t:1527793798897};\\\", \\\"{x:895,y:788,t:1527793798905};\\\", \\\"{x:903,y:787,t:1527793798922};\\\", \\\"{x:914,y:786,t:1527793798939};\\\", \\\"{x:938,y:785,t:1527793798956};\\\", \\\"{x:970,y:782,t:1527793798972};\\\", \\\"{x:1005,y:781,t:1527793798990};\\\", \\\"{x:1054,y:778,t:1527793799006};\\\", \\\"{x:1109,y:772,t:1527793799022};\\\", \\\"{x:1162,y:765,t:1527793799039};\\\", \\\"{x:1215,y:763,t:1527793799057};\\\", \\\"{x:1242,y:763,t:1527793799073};\\\", \\\"{x:1258,y:763,t:1527793799090};\\\", \\\"{x:1273,y:763,t:1527793799106};\\\", \\\"{x:1284,y:763,t:1527793799122};\\\", \\\"{x:1292,y:761,t:1527793799139};\\\", \\\"{x:1293,y:761,t:1527793799157};\\\", \\\"{x:1296,y:761,t:1527793799172};\\\", \\\"{x:1301,y:762,t:1527793799189};\\\", \\\"{x:1305,y:762,t:1527793799207};\\\", \\\"{x:1306,y:762,t:1527793799233};\\\", \\\"{x:1306,y:763,t:1527793799257};\\\", \\\"{x:1306,y:764,t:1527793799272};\\\", \\\"{x:1306,y:765,t:1527793799337};\\\", \\\"{x:1305,y:765,t:1527793799528};\\\", \\\"{x:1301,y:765,t:1527793799539};\\\", \\\"{x:1290,y:765,t:1527793799556};\\\", \\\"{x:1272,y:765,t:1527793799573};\\\", \\\"{x:1255,y:769,t:1527793799589};\\\", \\\"{x:1240,y:770,t:1527793799606};\\\", \\\"{x:1229,y:773,t:1527793799623};\\\", \\\"{x:1222,y:773,t:1527793799639};\\\", \\\"{x:1216,y:773,t:1527793799658};\\\", \\\"{x:1212,y:773,t:1527793799672};\\\", \\\"{x:1211,y:773,t:1527793799689};\\\", \\\"{x:1210,y:773,t:1527793800097};\\\", \\\"{x:1208,y:773,t:1527793800546};\\\", \\\"{x:1205,y:771,t:1527793800557};\\\", \\\"{x:1202,y:768,t:1527793800574};\\\", \\\"{x:1198,y:765,t:1527793800590};\\\", \\\"{x:1195,y:759,t:1527793800608};\\\", \\\"{x:1192,y:754,t:1527793800623};\\\", \\\"{x:1191,y:746,t:1527793800641};\\\", \\\"{x:1191,y:742,t:1527793800657};\\\", \\\"{x:1190,y:738,t:1527793800674};\\\", \\\"{x:1190,y:737,t:1527793800691};\\\", \\\"{x:1190,y:736,t:1527793800708};\\\", \\\"{x:1190,y:734,t:1527793800725};\\\", \\\"{x:1190,y:732,t:1527793800741};\\\", \\\"{x:1190,y:730,t:1527793800758};\\\", \\\"{x:1189,y:729,t:1527793800774};\\\", \\\"{x:1189,y:728,t:1527793800793};\\\", \\\"{x:1189,y:727,t:1527793800873};\\\", \\\"{x:1189,y:726,t:1527793800921};\\\", \\\"{x:1189,y:725,t:1527793800961};\\\", \\\"{x:1188,y:724,t:1527793801041};\\\", \\\"{x:1187,y:724,t:1527793801058};\\\", \\\"{x:1186,y:724,t:1527793801080};\\\", \\\"{x:1185,y:724,t:1527793801137};\\\", \\\"{x:1185,y:723,t:1527793803232};\\\", \\\"{x:1184,y:723,t:1527793803242};\\\", \\\"{x:1174,y:722,t:1527793803259};\\\", \\\"{x:1143,y:718,t:1527793803275};\\\", \\\"{x:1100,y:711,t:1527793803292};\\\", \\\"{x:1023,y:700,t:1527793803309};\\\", \\\"{x:929,y:678,t:1527793803326};\\\", \\\"{x:820,y:637,t:1527793803342};\\\", \\\"{x:718,y:596,t:1527793803359};\\\", \\\"{x:586,y:531,t:1527793803376};\\\", \\\"{x:512,y:490,t:1527793803392};\\\", \\\"{x:462,y:459,t:1527793803409};\\\", \\\"{x:441,y:442,t:1527793803426};\\\", \\\"{x:434,y:437,t:1527793803443};\\\", \\\"{x:435,y:436,t:1527793803463};\\\", \\\"{x:438,y:436,t:1527793803476};\\\", \\\"{x:461,y:436,t:1527793803492};\\\", \\\"{x:477,y:436,t:1527793803509};\\\", \\\"{x:485,y:432,t:1527793803526};\\\", \\\"{x:489,y:432,t:1527793803542};\\\", \\\"{x:486,y:432,t:1527793803592};\\\", \\\"{x:474,y:432,t:1527793803600};\\\", \\\"{x:457,y:432,t:1527793803609};\\\", \\\"{x:400,y:444,t:1527793803627};\\\", \\\"{x:335,y:456,t:1527793803644};\\\", \\\"{x:271,y:464,t:1527793803660};\\\", \\\"{x:245,y:465,t:1527793803676};\\\", \\\"{x:220,y:468,t:1527793803693};\\\", \\\"{x:206,y:468,t:1527793803710};\\\", \\\"{x:204,y:468,t:1527793803726};\\\", \\\"{x:204,y:467,t:1527793803825};\\\", \\\"{x:205,y:466,t:1527793803848};\\\", \\\"{x:205,y:465,t:1527793803865};\\\", \\\"{x:205,y:464,t:1527793803877};\\\", \\\"{x:205,y:462,t:1527793803893};\\\", \\\"{x:205,y:460,t:1527793803909};\\\", \\\"{x:199,y:457,t:1527793803926};\\\", \\\"{x:193,y:455,t:1527793803943};\\\", \\\"{x:187,y:453,t:1527793803960};\\\", \\\"{x:181,y:453,t:1527793803977};\\\", \\\"{x:175,y:453,t:1527793803993};\\\", \\\"{x:174,y:453,t:1527793804010};\\\", \\\"{x:173,y:453,t:1527793804088};\\\", \\\"{x:176,y:453,t:1527793804400};\\\", \\\"{x:186,y:454,t:1527793804409};\\\", \\\"{x:206,y:458,t:1527793804427};\\\", \\\"{x:236,y:469,t:1527793804443};\\\", \\\"{x:277,y:493,t:1527793804460};\\\", \\\"{x:328,y:529,t:1527793804478};\\\", \\\"{x:360,y:560,t:1527793804493};\\\", \\\"{x:382,y:586,t:1527793804510};\\\", \\\"{x:414,y:629,t:1527793804527};\\\", \\\"{x:437,y:661,t:1527793804543};\\\", \\\"{x:461,y:695,t:1527793804561};\\\", \\\"{x:475,y:710,t:1527793804578};\\\", \\\"{x:482,y:721,t:1527793804593};\\\", \\\"{x:485,y:725,t:1527793804609};\\\", \\\"{x:489,y:730,t:1527793804627};\\\", \\\"{x:491,y:730,t:1527793804688};\\\", \\\"{x:492,y:730,t:1527793804696};\\\", \\\"{x:495,y:729,t:1527793804710};\\\", \\\"{x:500,y:721,t:1527793804726};\\\", \\\"{x:502,y:712,t:1527793804743};\\\", \\\"{x:506,y:698,t:1527793804761};\\\", \\\"{x:509,y:692,t:1527793804776};\\\", \\\"{x:510,y:681,t:1527793804793};\\\", \\\"{x:510,y:673,t:1527793804810};\\\", \\\"{x:510,y:669,t:1527793804827};\\\", \\\"{x:510,y:666,t:1527793804844};\\\", \\\"{x:510,y:664,t:1527793804860};\\\", \\\"{x:510,y:661,t:1527793804877};\\\", \\\"{x:511,y:660,t:1527793804894};\\\", \\\"{x:512,y:659,t:1527793804910};\\\", \\\"{x:512,y:658,t:1527793804967};\\\", \\\"{x:513,y:657,t:1527793804977};\\\", \\\"{x:513,y:656,t:1527793805801};\\\", \\\"{x:512,y:656,t:1527793805937};\\\", \\\"{x:511,y:655,t:1527793805946};\\\", \\\"{x:513,y:660,t:1527793805977};\\\", \\\"{x:518,y:667,t:1527793805985};\\\", \\\"{x:523,y:676,t:1527793805995};\\\", \\\"{x:529,y:684,t:1527793806011};\\\", \\\"{x:530,y:691,t:1527793806028};\\\", \\\"{x:531,y:692,t:1527793806044};\\\", \\\"{x:531,y:693,t:1527793806288};\\\", \\\"{x:531,y:694,t:1527793806295};\\\", \\\"{x:532,y:696,t:1527793806311};\\\", \\\"{x:538,y:698,t:1527793806328};\\\", \\\"{x:539,y:699,t:1527793806345};\\\" ] }, { \\\"rt\\\": 37481, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 370759, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:699,t:1527793808760};\\\", \\\"{x:541,y:699,t:1527793808817};\\\", \\\"{x:542,y:699,t:1527793808840};\\\", \\\"{x:542,y:698,t:1527793808857};\\\", \\\"{x:542,y:696,t:1527793808874};\\\", \\\"{x:541,y:695,t:1527793808880};\\\", \\\"{x:540,y:695,t:1527793808892};\\\", \\\"{x:539,y:695,t:1527793808909};\\\", \\\"{x:539,y:694,t:1527793808977};\\\", \\\"{x:538,y:693,t:1527793809000};\\\", \\\"{x:536,y:693,t:1527793809009};\\\", \\\"{x:535,y:693,t:1527793809026};\\\", \\\"{x:533,y:693,t:1527793809042};\\\", \\\"{x:533,y:692,t:1527793809059};\\\", \\\"{x:532,y:691,t:1527793809075};\\\", \\\"{x:530,y:689,t:1527793809092};\\\", \\\"{x:530,y:687,t:1527793809249};\\\", \\\"{x:530,y:686,t:1527793810545};\\\", \\\"{x:530,y:685,t:1527793810616};\\\", \\\"{x:531,y:683,t:1527793810624};\\\", \\\"{x:532,y:682,t:1527793820712};\\\", \\\"{x:535,y:681,t:1527793820721};\\\", \\\"{x:539,y:679,t:1527793820731};\\\", \\\"{x:542,y:678,t:1527793820748};\\\", \\\"{x:545,y:677,t:1527793820766};\\\", \\\"{x:546,y:677,t:1527793820781};\\\", \\\"{x:548,y:679,t:1527793824275};\\\", \\\"{x:549,y:680,t:1527793824289};\\\", \\\"{x:550,y:681,t:1527793824344};\\\", \\\"{x:552,y:681,t:1527793824361};\\\", \\\"{x:554,y:681,t:1527793824372};\\\", \\\"{x:556,y:681,t:1527793824389};\\\", \\\"{x:556,y:679,t:1527793824406};\\\", \\\"{x:558,y:678,t:1527793824776};\\\", \\\"{x:560,y:678,t:1527793824789};\\\", \\\"{x:562,y:678,t:1527793824805};\\\", \\\"{x:563,y:677,t:1527793824848};\\\", \\\"{x:565,y:676,t:1527793824922};\\\", \\\"{x:569,y:676,t:1527793824938};\\\", \\\"{x:571,y:676,t:1527793824954};\\\", \\\"{x:575,y:676,t:1527793824971};\\\", \\\"{x:579,y:676,t:1527793824993};\\\", \\\"{x:580,y:676,t:1527793825976};\\\", \\\"{x:582,y:676,t:1527793825991};\\\", \\\"{x:583,y:676,t:1527793825999};\\\", \\\"{x:585,y:676,t:1527793826011};\\\", \\\"{x:590,y:675,t:1527793826028};\\\", \\\"{x:598,y:675,t:1527793826044};\\\", \\\"{x:612,y:674,t:1527793826060};\\\", \\\"{x:627,y:674,t:1527793826078};\\\", \\\"{x:637,y:672,t:1527793826094};\\\", \\\"{x:647,y:671,t:1527793826111};\\\", \\\"{x:664,y:665,t:1527793826127};\\\", \\\"{x:673,y:663,t:1527793826144};\\\", \\\"{x:675,y:662,t:1527793826161};\\\", \\\"{x:677,y:661,t:1527793826178};\\\", \\\"{x:678,y:661,t:1527793826195};\\\", \\\"{x:679,y:661,t:1527793826232};\\\", \\\"{x:680,y:661,t:1527793826296};\\\", \\\"{x:682,y:661,t:1527793826328};\\\", \\\"{x:683,y:660,t:1527793826346};\\\", \\\"{x:683,y:659,t:1527793826363};\\\", \\\"{x:683,y:658,t:1527793826379};\\\", \\\"{x:684,y:658,t:1527793835046};\\\", \\\"{x:684,y:656,t:1527793835061};\\\", \\\"{x:684,y:655,t:1527793835074};\\\", \\\"{x:656,y:650,t:1527793835091};\\\", \\\"{x:585,y:655,t:1527793835107};\\\", \\\"{x:521,y:655,t:1527793835125};\\\", \\\"{x:477,y:655,t:1527793835141};\\\", \\\"{x:461,y:658,t:1527793835157};\\\", \\\"{x:457,y:660,t:1527793835174};\\\", \\\"{x:457,y:663,t:1527793835191};\\\", \\\"{x:462,y:666,t:1527793835207};\\\", \\\"{x:491,y:668,t:1527793835225};\\\", \\\"{x:561,y:668,t:1527793835241};\\\", \\\"{x:624,y:662,t:1527793835257};\\\", \\\"{x:651,y:649,t:1527793835265};\\\", \\\"{x:699,y:625,t:1527793835283};\\\", \\\"{x:744,y:601,t:1527793835299};\\\", \\\"{x:773,y:592,t:1527793835315};\\\", \\\"{x:802,y:576,t:1527793835333};\\\", \\\"{x:813,y:567,t:1527793835349};\\\", \\\"{x:818,y:563,t:1527793835366};\\\", \\\"{x:820,y:562,t:1527793835382};\\\", \\\"{x:826,y:559,t:1527793835400};\\\", \\\"{x:841,y:558,t:1527793835416};\\\", \\\"{x:861,y:555,t:1527793835433};\\\", \\\"{x:880,y:553,t:1527793835450};\\\", \\\"{x:890,y:549,t:1527793835467};\\\", \\\"{x:888,y:549,t:1527793835558};\\\", \\\"{x:887,y:549,t:1527793835566};\\\", \\\"{x:885,y:550,t:1527793835583};\\\", \\\"{x:881,y:552,t:1527793835601};\\\", \\\"{x:876,y:554,t:1527793835616};\\\", \\\"{x:867,y:557,t:1527793835634};\\\", \\\"{x:860,y:558,t:1527793835650};\\\", \\\"{x:850,y:562,t:1527793835667};\\\", \\\"{x:843,y:566,t:1527793835683};\\\", \\\"{x:839,y:567,t:1527793835700};\\\", \\\"{x:838,y:568,t:1527793835717};\\\", \\\"{x:837,y:568,t:1527793835782};\\\", \\\"{x:837,y:569,t:1527793836382};\\\", \\\"{x:836,y:569,t:1527793837118};\\\", \\\"{x:835,y:569,t:1527793837221};\\\", \\\"{x:834,y:571,t:1527793837234};\\\", \\\"{x:833,y:573,t:1527793837251};\\\", \\\"{x:833,y:580,t:1527793837268};\\\", \\\"{x:829,y:591,t:1527793837285};\\\", \\\"{x:827,y:597,t:1527793837301};\\\", \\\"{x:826,y:600,t:1527793837317};\\\", \\\"{x:823,y:606,t:1527793837334};\\\", \\\"{x:821,y:609,t:1527793837350};\\\", \\\"{x:819,y:614,t:1527793837368};\\\", \\\"{x:818,y:617,t:1527793837385};\\\", \\\"{x:816,y:620,t:1527793837401};\\\", \\\"{x:814,y:624,t:1527793837418};\\\", \\\"{x:814,y:626,t:1527793837435};\\\", \\\"{x:813,y:627,t:1527793837461};\\\", \\\"{x:812,y:628,t:1527793837485};\\\", \\\"{x:812,y:629,t:1527793837549};\\\", \\\"{x:809,y:630,t:1527793844430};\\\", \\\"{x:797,y:630,t:1527793844441};\\\", \\\"{x:774,y:630,t:1527793844457};\\\", \\\"{x:760,y:632,t:1527793844474};\\\", \\\"{x:748,y:636,t:1527793844491};\\\", \\\"{x:735,y:640,t:1527793844507};\\\", \\\"{x:726,y:642,t:1527793844524};\\\", \\\"{x:715,y:647,t:1527793844540};\\\", \\\"{x:695,y:652,t:1527793844557};\\\", \\\"{x:676,y:658,t:1527793844574};\\\", \\\"{x:650,y:670,t:1527793844591};\\\", \\\"{x:619,y:683,t:1527793844608};\\\", \\\"{x:590,y:693,t:1527793844623};\\\", \\\"{x:568,y:698,t:1527793844641};\\\", \\\"{x:556,y:699,t:1527793844659};\\\", \\\"{x:554,y:700,t:1527793844674};\\\", \\\"{x:551,y:700,t:1527793844691};\\\", \\\"{x:550,y:700,t:1527793844707};\\\", \\\"{x:547,y:700,t:1527793844723};\\\", \\\"{x:543,y:699,t:1527793844740};\\\", \\\"{x:533,y:697,t:1527793844756};\\\", \\\"{x:531,y:697,t:1527793844774};\\\", \\\"{x:528,y:696,t:1527793844790};\\\", \\\"{x:527,y:695,t:1527793844807};\\\", \\\"{x:526,y:694,t:1527793844824};\\\", \\\"{x:525,y:694,t:1527793845182};\\\" ] }, { \\\"rt\\\": 23745, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 395732, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:694,t:1527793847070};\\\", \\\"{x:550,y:694,t:1527793847099};\\\", \\\"{x:565,y:694,t:1527793847111};\\\", \\\"{x:588,y:699,t:1527793847127};\\\", \\\"{x:611,y:703,t:1527793847142};\\\", \\\"{x:633,y:709,t:1527793847159};\\\", \\\"{x:654,y:715,t:1527793847176};\\\", \\\"{x:671,y:719,t:1527793847192};\\\", \\\"{x:683,y:721,t:1527793847210};\\\", \\\"{x:685,y:721,t:1527793847226};\\\", \\\"{x:686,y:721,t:1527793847243};\\\", \\\"{x:687,y:721,t:1527793848806};\\\", \\\"{x:687,y:722,t:1527793848861};\\\", \\\"{x:688,y:722,t:1527793851709};\\\", \\\"{x:690,y:722,t:1527793851725};\\\", \\\"{x:692,y:720,t:1527793851733};\\\", \\\"{x:694,y:720,t:1527793851747};\\\", \\\"{x:699,y:718,t:1527793851764};\\\", \\\"{x:703,y:717,t:1527793851780};\\\", \\\"{x:708,y:717,t:1527793851798};\\\", \\\"{x:709,y:716,t:1527793851902};\\\", \\\"{x:710,y:715,t:1527793851966};\\\", \\\"{x:711,y:715,t:1527793852102};\\\", \\\"{x:711,y:714,t:1527793852118};\\\", \\\"{x:712,y:714,t:1527793852131};\\\", \\\"{x:712,y:713,t:1527793852147};\\\", \\\"{x:712,y:712,t:1527793852165};\\\", \\\"{x:713,y:711,t:1527793852181};\\\", \\\"{x:713,y:710,t:1527793852197};\\\", \\\"{x:714,y:708,t:1527793852581};\\\", \\\"{x:715,y:706,t:1527793852597};\\\", \\\"{x:717,y:706,t:1527793852621};\\\", \\\"{x:717,y:705,t:1527793852653};\\\", \\\"{x:718,y:704,t:1527793852702};\\\", \\\"{x:718,y:703,t:1527793856092};\\\", \\\"{x:720,y:703,t:1527793856542};\\\", \\\"{x:722,y:703,t:1527793856551};\\\", \\\"{x:732,y:698,t:1527793856567};\\\", \\\"{x:733,y:698,t:1527793857934};\\\", \\\"{x:734,y:698,t:1527793857941};\\\", \\\"{x:736,y:698,t:1527793857957};\\\", \\\"{x:738,y:698,t:1527793857969};\\\", \\\"{x:743,y:698,t:1527793857985};\\\", \\\"{x:748,y:696,t:1527793858002};\\\", \\\"{x:752,y:696,t:1527793858019};\\\", \\\"{x:759,y:696,t:1527793858035};\\\", \\\"{x:769,y:696,t:1527793858052};\\\", \\\"{x:786,y:696,t:1527793858069};\\\", \\\"{x:802,y:694,t:1527793858085};\\\", \\\"{x:818,y:686,t:1527793858102};\\\", \\\"{x:831,y:679,t:1527793858120};\\\", \\\"{x:846,y:671,t:1527793858136};\\\", \\\"{x:860,y:661,t:1527793858152};\\\", \\\"{x:879,y:648,t:1527793858169};\\\", \\\"{x:894,y:637,t:1527793858185};\\\", \\\"{x:906,y:629,t:1527793858203};\\\", \\\"{x:917,y:623,t:1527793858220};\\\", \\\"{x:924,y:618,t:1527793858235};\\\", \\\"{x:932,y:614,t:1527793858253};\\\", \\\"{x:947,y:609,t:1527793858269};\\\", \\\"{x:955,y:608,t:1527793858286};\\\", \\\"{x:960,y:605,t:1527793858302};\\\", \\\"{x:965,y:604,t:1527793858319};\\\", \\\"{x:968,y:601,t:1527793858336};\\\", \\\"{x:979,y:596,t:1527793858352};\\\", \\\"{x:992,y:589,t:1527793858370};\\\", \\\"{x:1003,y:580,t:1527793858386};\\\", \\\"{x:1012,y:566,t:1527793858402};\\\", \\\"{x:1015,y:556,t:1527793858420};\\\", \\\"{x:1016,y:542,t:1527793858437};\\\", \\\"{x:1018,y:528,t:1527793858453};\\\", \\\"{x:1021,y:504,t:1527793858469};\\\", \\\"{x:1021,y:493,t:1527793858487};\\\", \\\"{x:1024,y:486,t:1527793858502};\\\", \\\"{x:1025,y:481,t:1527793858520};\\\", \\\"{x:1026,y:477,t:1527793858537};\\\", \\\"{x:1026,y:476,t:1527793858581};\\\", \\\"{x:1027,y:475,t:1527793858590};\\\", \\\"{x:1027,y:474,t:1527793858613};\\\", \\\"{x:1027,y:473,t:1527793858621};\\\", \\\"{x:1027,y:472,t:1527793858637};\\\", \\\"{x:1027,y:471,t:1527793858694};\\\", \\\"{x:1027,y:470,t:1527793858704};\\\", \\\"{x:1027,y:466,t:1527793858719};\\\", \\\"{x:1027,y:465,t:1527793858736};\\\", \\\"{x:1026,y:463,t:1527793858902};\\\", \\\"{x:1025,y:463,t:1527793858909};\\\", \\\"{x:1024,y:463,t:1527793858919};\\\", \\\"{x:1023,y:463,t:1527793858937};\\\", \\\"{x:1020,y:460,t:1527793858954};\\\", \\\"{x:1019,y:460,t:1527793858974};\\\", \\\"{x:1018,y:460,t:1527793858997};\\\", \\\"{x:1016,y:460,t:1527793859349};\\\", \\\"{x:1014,y:460,t:1527793859357};\\\", \\\"{x:1013,y:460,t:1527793859370};\\\", \\\"{x:1012,y:460,t:1527793859390};\\\", \\\"{x:1012,y:461,t:1527793859438};\\\", \\\"{x:1012,y:462,t:1527793859765};\\\", \\\"{x:1012,y:464,t:1527793859773};\\\", \\\"{x:1012,y:469,t:1527793859787};\\\", \\\"{x:1012,y:487,t:1527793859803};\\\", \\\"{x:1012,y:504,t:1527793859820};\\\", \\\"{x:1012,y:520,t:1527793859836};\\\", \\\"{x:1012,y:532,t:1527793859853};\\\", \\\"{x:1012,y:541,t:1527793859870};\\\", \\\"{x:1012,y:552,t:1527793859886};\\\", \\\"{x:1012,y:568,t:1527793859902};\\\", \\\"{x:1011,y:585,t:1527793859920};\\\", \\\"{x:1011,y:603,t:1527793859936};\\\", \\\"{x:1011,y:615,t:1527793859953};\\\", \\\"{x:1011,y:620,t:1527793859970};\\\", \\\"{x:1010,y:626,t:1527793859986};\\\", \\\"{x:1010,y:631,t:1527793860003};\\\", \\\"{x:1010,y:641,t:1527793860020};\\\", \\\"{x:1012,y:658,t:1527793860037};\\\", \\\"{x:1013,y:665,t:1527793860053};\\\", \\\"{x:1014,y:668,t:1527793860070};\\\", \\\"{x:1014,y:670,t:1527793860087};\\\", \\\"{x:1014,y:673,t:1527793860103};\\\", \\\"{x:1014,y:677,t:1527793860120};\\\", \\\"{x:1014,y:679,t:1527793860137};\\\", \\\"{x:1014,y:679,t:1527793860287};\\\", \\\"{x:1010,y:681,t:1527793860334};\\\", \\\"{x:997,y:685,t:1527793860342};\\\", \\\"{x:983,y:691,t:1527793860354};\\\", \\\"{x:951,y:700,t:1527793860370};\\\", \\\"{x:920,y:710,t:1527793860387};\\\", \\\"{x:884,y:719,t:1527793860404};\\\", \\\"{x:860,y:724,t:1527793860421};\\\", \\\"{x:839,y:727,t:1527793860437};\\\", \\\"{x:838,y:727,t:1527793860749};\\\", \\\"{x:836,y:727,t:1527793862198};\\\", \\\"{x:835,y:727,t:1527793862205};\\\", \\\"{x:836,y:727,t:1527793862284};\\\", \\\"{x:837,y:727,t:1527793862293};\\\", \\\"{x:839,y:727,t:1527793862305};\\\", \\\"{x:847,y:727,t:1527793862322};\\\", \\\"{x:859,y:727,t:1527793862338};\\\", \\\"{x:881,y:729,t:1527793862355};\\\", \\\"{x:907,y:732,t:1527793862372};\\\", \\\"{x:996,y:761,t:1527793862389};\\\", \\\"{x:1060,y:778,t:1527793862405};\\\", \\\"{x:1132,y:798,t:1527793862423};\\\", \\\"{x:1188,y:814,t:1527793862439};\\\", \\\"{x:1222,y:823,t:1527793862455};\\\", \\\"{x:1245,y:832,t:1527793862472};\\\", \\\"{x:1269,y:844,t:1527793862490};\\\", \\\"{x:1289,y:855,t:1527793862506};\\\", \\\"{x:1319,y:874,t:1527793862522};\\\", \\\"{x:1349,y:893,t:1527793862539};\\\", \\\"{x:1373,y:904,t:1527793862555};\\\", \\\"{x:1392,y:912,t:1527793862572};\\\", \\\"{x:1394,y:913,t:1527793862589};\\\", \\\"{x:1389,y:913,t:1527793862638};\\\", \\\"{x:1387,y:913,t:1527793862645};\\\", \\\"{x:1385,y:913,t:1527793862655};\\\", \\\"{x:1382,y:911,t:1527793862672};\\\", \\\"{x:1381,y:911,t:1527793862689};\\\", \\\"{x:1377,y:910,t:1527793862707};\\\", \\\"{x:1371,y:909,t:1527793862723};\\\", \\\"{x:1361,y:906,t:1527793862740};\\\", \\\"{x:1359,y:905,t:1527793862756};\\\", \\\"{x:1357,y:905,t:1527793862773};\\\", \\\"{x:1354,y:905,t:1527793862790};\\\", \\\"{x:1352,y:905,t:1527793862821};\\\", \\\"{x:1350,y:907,t:1527793862840};\\\", \\\"{x:1346,y:912,t:1527793862857};\\\", \\\"{x:1343,y:914,t:1527793862872};\\\", \\\"{x:1337,y:915,t:1527793862890};\\\", \\\"{x:1333,y:916,t:1527793862907};\\\", \\\"{x:1332,y:917,t:1527793862923};\\\", \\\"{x:1334,y:917,t:1527793863110};\\\", \\\"{x:1335,y:916,t:1527793863123};\\\", \\\"{x:1337,y:914,t:1527793863140};\\\", \\\"{x:1338,y:913,t:1527793863157};\\\", \\\"{x:1338,y:912,t:1527793863173};\\\", \\\"{x:1339,y:912,t:1527793863293};\\\", \\\"{x:1339,y:911,t:1527793863326};\\\", \\\"{x:1340,y:911,t:1527793863340};\\\", \\\"{x:1341,y:911,t:1527793863357};\\\", \\\"{x:1338,y:908,t:1527793863430};\\\", \\\"{x:1321,y:901,t:1527793863440};\\\", \\\"{x:1254,y:881,t:1527793863456};\\\", \\\"{x:1133,y:848,t:1527793863474};\\\", \\\"{x:975,y:799,t:1527793863491};\\\", \\\"{x:809,y:747,t:1527793863507};\\\", \\\"{x:668,y:708,t:1527793863524};\\\", \\\"{x:569,y:685,t:1527793863540};\\\", \\\"{x:517,y:665,t:1527793863556};\\\", \\\"{x:484,y:647,t:1527793863573};\\\", \\\"{x:479,y:639,t:1527793863590};\\\", \\\"{x:477,y:629,t:1527793863606};\\\", \\\"{x:475,y:620,t:1527793863623};\\\", \\\"{x:475,y:616,t:1527793863641};\\\", \\\"{x:475,y:615,t:1527793863668};\\\", \\\"{x:474,y:615,t:1527793864094};\\\", \\\"{x:472,y:615,t:1527793864106};\\\", \\\"{x:471,y:615,t:1527793864123};\\\", \\\"{x:470,y:613,t:1527793864139};\\\", \\\"{x:470,y:612,t:1527793864157};\\\", \\\"{x:470,y:611,t:1527793864173};\\\", \\\"{x:470,y:608,t:1527793864190};\\\", \\\"{x:470,y:603,t:1527793864206};\\\", \\\"{x:474,y:598,t:1527793864223};\\\", \\\"{x:479,y:593,t:1527793864239};\\\", \\\"{x:484,y:589,t:1527793864256};\\\", \\\"{x:486,y:587,t:1527793864273};\\\", \\\"{x:487,y:586,t:1527793864289};\\\", \\\"{x:488,y:585,t:1527793864310};\\\", \\\"{x:489,y:585,t:1527793864324};\\\", \\\"{x:492,y:584,t:1527793864340};\\\", \\\"{x:494,y:583,t:1527793864356};\\\", \\\"{x:502,y:582,t:1527793864373};\\\", \\\"{x:510,y:582,t:1527793864390};\\\", \\\"{x:523,y:582,t:1527793864406};\\\", \\\"{x:534,y:581,t:1527793864423};\\\", \\\"{x:547,y:579,t:1527793864440};\\\", \\\"{x:551,y:579,t:1527793864457};\\\", \\\"{x:554,y:578,t:1527793864474};\\\", \\\"{x:555,y:578,t:1527793864677};\\\", \\\"{x:556,y:579,t:1527793865749};\\\", \\\"{x:558,y:579,t:1527793865764};\\\", \\\"{x:560,y:578,t:1527793865774};\\\", \\\"{x:571,y:572,t:1527793865791};\\\", \\\"{x:586,y:564,t:1527793865808};\\\", \\\"{x:599,y:553,t:1527793865825};\\\", \\\"{x:616,y:535,t:1527793865842};\\\", \\\"{x:633,y:516,t:1527793865859};\\\", \\\"{x:649,y:499,t:1527793865875};\\\", \\\"{x:665,y:484,t:1527793865891};\\\", \\\"{x:675,y:465,t:1527793865908};\\\", \\\"{x:706,y:446,t:1527793865925};\\\", \\\"{x:725,y:442,t:1527793865941};\\\", \\\"{x:736,y:441,t:1527793865958};\\\", \\\"{x:738,y:441,t:1527793865974};\\\", \\\"{x:739,y:441,t:1527793866061};\\\", \\\"{x:742,y:441,t:1527793866074};\\\", \\\"{x:745,y:441,t:1527793866091};\\\", \\\"{x:746,y:441,t:1527793866109};\\\", \\\"{x:740,y:441,t:1527793866221};\\\", \\\"{x:732,y:443,t:1527793866229};\\\", \\\"{x:725,y:445,t:1527793866242};\\\", \\\"{x:710,y:447,t:1527793866259};\\\", \\\"{x:699,y:448,t:1527793866276};\\\", \\\"{x:700,y:448,t:1527793866333};\\\", \\\"{x:711,y:447,t:1527793866342};\\\", \\\"{x:738,y:444,t:1527793866359};\\\", \\\"{x:759,y:443,t:1527793866375};\\\", \\\"{x:783,y:443,t:1527793866392};\\\", \\\"{x:796,y:443,t:1527793866408};\\\", \\\"{x:807,y:443,t:1527793866425};\\\", \\\"{x:814,y:443,t:1527793866442};\\\", \\\"{x:824,y:447,t:1527793866459};\\\", \\\"{x:837,y:451,t:1527793866476};\\\", \\\"{x:846,y:453,t:1527793866491};\\\", \\\"{x:847,y:453,t:1527793866509};\\\", \\\"{x:848,y:453,t:1527793866525};\\\", \\\"{x:837,y:453,t:1527793866758};\\\", \\\"{x:774,y:458,t:1527793866775};\\\", \\\"{x:677,y:468,t:1527793866793};\\\", \\\"{x:560,y:487,t:1527793866809};\\\", \\\"{x:453,y:499,t:1527793866825};\\\", \\\"{x:345,y:512,t:1527793866843};\\\", \\\"{x:263,y:516,t:1527793866858};\\\", \\\"{x:221,y:516,t:1527793866875};\\\", \\\"{x:202,y:516,t:1527793866892};\\\", \\\"{x:201,y:516,t:1527793866908};\\\", \\\"{x:198,y:516,t:1527793866964};\\\", \\\"{x:195,y:515,t:1527793866976};\\\", \\\"{x:194,y:513,t:1527793866992};\\\", \\\"{x:194,y:511,t:1527793867053};\\\", \\\"{x:194,y:509,t:1527793867061};\\\", \\\"{x:194,y:507,t:1527793867075};\\\", \\\"{x:194,y:505,t:1527793867092};\\\", \\\"{x:194,y:503,t:1527793867109};\\\", \\\"{x:194,y:502,t:1527793867133};\\\", \\\"{x:193,y:502,t:1527793867189};\\\", \\\"{x:192,y:501,t:1527793867196};\\\", \\\"{x:192,y:500,t:1527793867685};\\\", \\\"{x:192,y:499,t:1527793867693};\\\", \\\"{x:192,y:498,t:1527793867710};\\\", \\\"{x:192,y:496,t:1527793867727};\\\", \\\"{x:189,y:495,t:1527793867743};\\\", \\\"{x:185,y:492,t:1527793867759};\\\", \\\"{x:183,y:491,t:1527793867776};\\\", \\\"{x:182,y:490,t:1527793867793};\\\", \\\"{x:181,y:490,t:1527793867861};\\\", \\\"{x:191,y:492,t:1527793868437};\\\", \\\"{x:207,y:497,t:1527793868446};\\\", \\\"{x:245,y:511,t:1527793868461};\\\", \\\"{x:274,y:518,t:1527793868477};\\\", \\\"{x:297,y:529,t:1527793868493};\\\", \\\"{x:319,y:540,t:1527793868510};\\\", \\\"{x:326,y:544,t:1527793868527};\\\", \\\"{x:327,y:549,t:1527793868544};\\\", \\\"{x:328,y:556,t:1527793868560};\\\", \\\"{x:330,y:572,t:1527793868576};\\\", \\\"{x:331,y:586,t:1527793868594};\\\", \\\"{x:333,y:593,t:1527793868610};\\\", \\\"{x:333,y:594,t:1527793868626};\\\", \\\"{x:334,y:595,t:1527793868668};\\\", \\\"{x:338,y:600,t:1527793868677};\\\", \\\"{x:352,y:605,t:1527793868693};\\\", \\\"{x:364,y:611,t:1527793868710};\\\", \\\"{x:373,y:613,t:1527793868727};\\\", \\\"{x:375,y:613,t:1527793868743};\\\", \\\"{x:375,y:603,t:1527793868761};\\\", \\\"{x:364,y:579,t:1527793868778};\\\", \\\"{x:336,y:554,t:1527793868794};\\\", \\\"{x:291,y:532,t:1527793868811};\\\", \\\"{x:247,y:514,t:1527793868828};\\\", \\\"{x:225,y:508,t:1527793868844};\\\", \\\"{x:198,y:504,t:1527793868860};\\\", \\\"{x:190,y:503,t:1527793868876};\\\", \\\"{x:185,y:501,t:1527793868894};\\\", \\\"{x:181,y:500,t:1527793868910};\\\", \\\"{x:179,y:499,t:1527793868933};\\\", \\\"{x:177,y:498,t:1527793868949};\\\", \\\"{x:174,y:497,t:1527793868960};\\\", \\\"{x:169,y:494,t:1527793868977};\\\", \\\"{x:167,y:493,t:1527793868993};\\\", \\\"{x:166,y:493,t:1527793869010};\\\", \\\"{x:167,y:494,t:1527793869213};\\\", \\\"{x:180,y:498,t:1527793869227};\\\", \\\"{x:266,y:528,t:1527793869245};\\\", \\\"{x:326,y:550,t:1527793869261};\\\", \\\"{x:374,y:565,t:1527793869277};\\\", \\\"{x:423,y:584,t:1527793869295};\\\", \\\"{x:455,y:602,t:1527793869310};\\\", \\\"{x:470,y:611,t:1527793869327};\\\", \\\"{x:475,y:616,t:1527793869344};\\\", \\\"{x:476,y:617,t:1527793869361};\\\", \\\"{x:477,y:619,t:1527793869377};\\\", \\\"{x:478,y:623,t:1527793869394};\\\", \\\"{x:480,y:627,t:1527793869410};\\\", \\\"{x:484,y:632,t:1527793869427};\\\", \\\"{x:488,y:639,t:1527793869445};\\\", \\\"{x:489,y:640,t:1527793869461};\\\", \\\"{x:489,y:641,t:1527793869532};\\\", \\\"{x:489,y:642,t:1527793869548};\\\", \\\"{x:489,y:643,t:1527793869565};\\\", \\\"{x:491,y:645,t:1527793869580};\\\", \\\"{x:492,y:648,t:1527793869593};\\\", \\\"{x:499,y:656,t:1527793869611};\\\", \\\"{x:506,y:663,t:1527793869628};\\\", \\\"{x:510,y:669,t:1527793869644};\\\", \\\"{x:511,y:670,t:1527793869660};\\\", \\\"{x:514,y:674,t:1527793869677};\\\", \\\"{x:516,y:677,t:1527793869695};\\\", \\\"{x:518,y:679,t:1527793869711};\\\", \\\"{x:519,y:680,t:1527793869727};\\\", \\\"{x:520,y:682,t:1527793869744};\\\", \\\"{x:522,y:684,t:1527793869761};\\\", \\\"{x:523,y:686,t:1527793869777};\\\", \\\"{x:524,y:686,t:1527793869795};\\\", \\\"{x:524,y:687,t:1527793869812};\\\", \\\"{x:525,y:687,t:1527793869837};\\\", \\\"{x:526,y:687,t:1527793869988};\\\", \\\"{x:528,y:687,t:1527793870029};\\\", \\\"{x:529,y:687,t:1527793870053};\\\" ] }, { \\\"rt\\\": 5281, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 402256, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:687,t:1527793871972};\\\", \\\"{x:554,y:691,t:1527793871980};\\\", \\\"{x:578,y:695,t:1527793871999};\\\", \\\"{x:612,y:697,t:1527793872014};\\\", \\\"{x:657,y:703,t:1527793872029};\\\", \\\"{x:699,y:708,t:1527793872046};\\\", \\\"{x:737,y:711,t:1527793872062};\\\", \\\"{x:766,y:715,t:1527793872080};\\\", \\\"{x:788,y:719,t:1527793872097};\\\", \\\"{x:798,y:720,t:1527793872113};\\\", \\\"{x:799,y:720,t:1527793872198};\\\", \\\"{x:798,y:720,t:1527793874797};\\\", \\\"{x:789,y:721,t:1527793874816};\\\", \\\"{x:771,y:711,t:1527793874832};\\\", \\\"{x:745,y:689,t:1527793874849};\\\", \\\"{x:720,y:661,t:1527793874865};\\\", \\\"{x:706,y:633,t:1527793874883};\\\", \\\"{x:696,y:609,t:1527793874899};\\\", \\\"{x:686,y:584,t:1527793874915};\\\", \\\"{x:680,y:563,t:1527793874934};\\\", \\\"{x:675,y:541,t:1527793874949};\\\", \\\"{x:667,y:521,t:1527793874965};\\\", \\\"{x:642,y:500,t:1527793874999};\\\", \\\"{x:639,y:499,t:1527793875016};\\\", \\\"{x:632,y:497,t:1527793875031};\\\", \\\"{x:614,y:493,t:1527793875049};\\\", \\\"{x:586,y:493,t:1527793875066};\\\", \\\"{x:571,y:493,t:1527793875081};\\\", \\\"{x:558,y:499,t:1527793875099};\\\", \\\"{x:547,y:504,t:1527793875116};\\\", \\\"{x:540,y:506,t:1527793875132};\\\", \\\"{x:537,y:506,t:1527793875148};\\\", \\\"{x:521,y:504,t:1527793875166};\\\", \\\"{x:492,y:495,t:1527793875182};\\\", \\\"{x:441,y:480,t:1527793875199};\\\", \\\"{x:396,y:472,t:1527793875216};\\\", \\\"{x:335,y:466,t:1527793875232};\\\", \\\"{x:274,y:457,t:1527793875249};\\\", \\\"{x:228,y:448,t:1527793875266};\\\", \\\"{x:192,y:444,t:1527793875283};\\\", \\\"{x:167,y:440,t:1527793875299};\\\", \\\"{x:153,y:440,t:1527793875315};\\\", \\\"{x:142,y:440,t:1527793875333};\\\", \\\"{x:137,y:442,t:1527793875349};\\\", \\\"{x:134,y:451,t:1527793875366};\\\", \\\"{x:133,y:457,t:1527793875383};\\\", \\\"{x:132,y:465,t:1527793875399};\\\", \\\"{x:131,y:469,t:1527793875416};\\\", \\\"{x:131,y:475,t:1527793875434};\\\", \\\"{x:134,y:479,t:1527793875450};\\\", \\\"{x:136,y:480,t:1527793875465};\\\", \\\"{x:139,y:480,t:1527793875483};\\\", \\\"{x:142,y:480,t:1527793875499};\\\", \\\"{x:147,y:480,t:1527793875516};\\\", \\\"{x:158,y:480,t:1527793875533};\\\", \\\"{x:160,y:480,t:1527793875549};\\\", \\\"{x:161,y:480,t:1527793875566};\\\", \\\"{x:167,y:484,t:1527793875788};\\\", \\\"{x:182,y:492,t:1527793875800};\\\", \\\"{x:240,y:517,t:1527793875816};\\\", \\\"{x:306,y:546,t:1527793875833};\\\", \\\"{x:376,y:583,t:1527793875849};\\\", \\\"{x:453,y:625,t:1527793875865};\\\", \\\"{x:503,y:660,t:1527793875883};\\\", \\\"{x:537,y:684,t:1527793875900};\\\", \\\"{x:554,y:699,t:1527793875916};\\\", \\\"{x:560,y:703,t:1527793875933};\\\", \\\"{x:560,y:704,t:1527793876260};\\\", \\\"{x:558,y:703,t:1527793876268};\\\", \\\"{x:557,y:702,t:1527793876283};\\\", \\\"{x:554,y:698,t:1527793876301};\\\", \\\"{x:547,y:695,t:1527793876316};\\\", \\\"{x:546,y:694,t:1527793876332};\\\", \\\"{x:545,y:694,t:1527793876350};\\\", \\\"{x:544,y:694,t:1527793876564};\\\", \\\"{x:543,y:695,t:1527793876572};\\\", \\\"{x:542,y:695,t:1527793876588};\\\", \\\"{x:542,y:696,t:1527793876599};\\\" ] }, { \\\"rt\\\": 48159, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 451665, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:697,t:1527793877715};\\\", \\\"{x:546,y:697,t:1527793878989};\\\", \\\"{x:573,y:695,t:1527793879027};\\\", \\\"{x:585,y:695,t:1527793879036};\\\", \\\"{x:610,y:698,t:1527793879052};\\\", \\\"{x:659,y:703,t:1527793879069};\\\", \\\"{x:683,y:707,t:1527793879086};\\\", \\\"{x:701,y:709,t:1527793879102};\\\", \\\"{x:711,y:709,t:1527793879119};\\\", \\\"{x:715,y:709,t:1527793879135};\\\", \\\"{x:716,y:709,t:1527793879152};\\\", \\\"{x:717,y:709,t:1527793879169};\\\", \\\"{x:718,y:709,t:1527793879221};\\\", \\\"{x:720,y:709,t:1527793879428};\\\", \\\"{x:723,y:709,t:1527793879436};\\\", \\\"{x:727,y:711,t:1527793879453};\\\", \\\"{x:731,y:714,t:1527793879469};\\\", \\\"{x:735,y:714,t:1527793879487};\\\", \\\"{x:736,y:714,t:1527793879533};\\\", \\\"{x:737,y:714,t:1527793883469};\\\", \\\"{x:738,y:714,t:1527793883541};\\\", \\\"{x:741,y:714,t:1527793883870};\\\", \\\"{x:742,y:714,t:1527793883877};\\\", \\\"{x:744,y:715,t:1527793883893};\\\", \\\"{x:745,y:715,t:1527793883907};\\\", \\\"{x:748,y:716,t:1527793883922};\\\", \\\"{x:752,y:716,t:1527793883939};\\\", \\\"{x:753,y:716,t:1527793883989};\\\", \\\"{x:753,y:715,t:1527793894138};\\\", \\\"{x:753,y:714,t:1527793894154};\\\", \\\"{x:753,y:712,t:1527793894162};\\\", \\\"{x:753,y:711,t:1527793894178};\\\", \\\"{x:753,y:709,t:1527793894195};\\\", \\\"{x:752,y:706,t:1527793894267};\\\", \\\"{x:751,y:703,t:1527793894278};\\\", \\\"{x:751,y:701,t:1527793894295};\\\", \\\"{x:750,y:698,t:1527793894312};\\\", \\\"{x:749,y:698,t:1527793894328};\\\", \\\"{x:755,y:697,t:1527793895346};\\\", \\\"{x:828,y:697,t:1527793895362};\\\", \\\"{x:966,y:682,t:1527793895379};\\\", \\\"{x:1104,y:665,t:1527793895397};\\\", \\\"{x:1255,y:625,t:1527793895413};\\\", \\\"{x:1396,y:584,t:1527793895429};\\\", \\\"{x:1513,y:547,t:1527793895446};\\\", \\\"{x:1614,y:496,t:1527793895463};\\\", \\\"{x:1661,y:463,t:1527793895479};\\\", \\\"{x:1677,y:441,t:1527793895496};\\\", \\\"{x:1686,y:423,t:1527793895513};\\\", \\\"{x:1691,y:411,t:1527793895529};\\\", \\\"{x:1699,y:399,t:1527793895546};\\\", \\\"{x:1716,y:389,t:1527793895563};\\\", \\\"{x:1746,y:379,t:1527793895580};\\\", \\\"{x:1769,y:375,t:1527793895597};\\\", \\\"{x:1778,y:373,t:1527793895613};\\\", \\\"{x:1775,y:373,t:1527793895650};\\\", \\\"{x:1766,y:376,t:1527793895663};\\\", \\\"{x:1738,y:383,t:1527793895680};\\\", \\\"{x:1696,y:397,t:1527793895698};\\\", \\\"{x:1684,y:401,t:1527793895713};\\\", \\\"{x:1661,y:411,t:1527793895730};\\\", \\\"{x:1641,y:416,t:1527793895747};\\\", \\\"{x:1639,y:417,t:1527793895763};\\\", \\\"{x:1637,y:417,t:1527793895779};\\\", \\\"{x:1636,y:420,t:1527793895962};\\\", \\\"{x:1635,y:420,t:1527793895970};\\\", \\\"{x:1634,y:422,t:1527793895985};\\\", \\\"{x:1633,y:422,t:1527793896026};\\\", \\\"{x:1632,y:422,t:1527793896042};\\\", \\\"{x:1632,y:421,t:1527793896050};\\\", \\\"{x:1631,y:421,t:1527793896063};\\\", \\\"{x:1631,y:420,t:1527793896080};\\\", \\\"{x:1631,y:417,t:1527793896097};\\\", \\\"{x:1631,y:413,t:1527793896113};\\\", \\\"{x:1630,y:408,t:1527793896130};\\\", \\\"{x:1628,y:405,t:1527793896146};\\\", \\\"{x:1626,y:403,t:1527793896163};\\\", \\\"{x:1625,y:402,t:1527793896186};\\\", \\\"{x:1624,y:402,t:1527793896210};\\\", \\\"{x:1622,y:400,t:1527793896226};\\\", \\\"{x:1621,y:400,t:1527793896234};\\\", \\\"{x:1619,y:399,t:1527793896246};\\\", \\\"{x:1618,y:399,t:1527793896263};\\\", \\\"{x:1618,y:398,t:1527793896280};\\\", \\\"{x:1617,y:398,t:1527793896298};\\\", \\\"{x:1616,y:397,t:1527793896323};\\\", \\\"{x:1617,y:394,t:1527793896531};\\\", \\\"{x:1616,y:398,t:1527793897322};\\\", \\\"{x:1614,y:404,t:1527793897330};\\\", \\\"{x:1609,y:416,t:1527793897347};\\\", \\\"{x:1604,y:427,t:1527793897364};\\\", \\\"{x:1601,y:439,t:1527793897382};\\\", \\\"{x:1599,y:446,t:1527793897397};\\\", \\\"{x:1598,y:456,t:1527793897414};\\\", \\\"{x:1596,y:463,t:1527793897432};\\\", \\\"{x:1596,y:465,t:1527793897447};\\\", \\\"{x:1596,y:466,t:1527793897490};\\\", \\\"{x:1594,y:465,t:1527793897530};\\\", \\\"{x:1592,y:461,t:1527793897548};\\\", \\\"{x:1591,y:456,t:1527793897564};\\\", \\\"{x:1591,y:454,t:1527793897581};\\\", \\\"{x:1591,y:453,t:1527793897598};\\\", \\\"{x:1591,y:451,t:1527793897625};\\\", \\\"{x:1591,y:450,t:1527793897633};\\\", \\\"{x:1592,y:449,t:1527793897647};\\\", \\\"{x:1593,y:448,t:1527793897663};\\\", \\\"{x:1593,y:447,t:1527793897899};\\\", \\\"{x:1591,y:447,t:1527793898122};\\\", \\\"{x:1589,y:447,t:1527793898132};\\\", \\\"{x:1585,y:447,t:1527793898151};\\\", \\\"{x:1583,y:446,t:1527793898164};\\\", \\\"{x:1582,y:446,t:1527793898181};\\\", \\\"{x:1581,y:446,t:1527793903329};\\\", \\\"{x:1580,y:446,t:1527793903345};\\\", \\\"{x:1579,y:446,t:1527793903369};\\\", \\\"{x:1576,y:446,t:1527793906266};\\\", \\\"{x:1575,y:446,t:1527793906313};\\\", \\\"{x:1576,y:444,t:1527793910562};\\\", \\\"{x:1580,y:442,t:1527793910574};\\\", \\\"{x:1587,y:434,t:1527793910591};\\\", \\\"{x:1596,y:424,t:1527793910607};\\\", \\\"{x:1604,y:415,t:1527793910624};\\\", \\\"{x:1610,y:405,t:1527793910641};\\\", \\\"{x:1613,y:397,t:1527793910658};\\\", \\\"{x:1617,y:390,t:1527793910674};\\\", \\\"{x:1617,y:388,t:1527793910691};\\\", \\\"{x:1617,y:386,t:1527793910707};\\\", \\\"{x:1618,y:384,t:1527793910725};\\\", \\\"{x:1618,y:383,t:1527793910741};\\\", \\\"{x:1620,y:384,t:1527793911705};\\\", \\\"{x:1620,y:387,t:1527793911712};\\\", \\\"{x:1621,y:391,t:1527793911726};\\\", \\\"{x:1621,y:395,t:1527793911741};\\\", \\\"{x:1622,y:398,t:1527793911758};\\\", \\\"{x:1622,y:401,t:1527793911775};\\\", \\\"{x:1622,y:407,t:1527793911791};\\\", \\\"{x:1622,y:417,t:1527793911808};\\\", \\\"{x:1622,y:448,t:1527793911825};\\\", \\\"{x:1622,y:475,t:1527793911842};\\\", \\\"{x:1622,y:503,t:1527793911859};\\\", \\\"{x:1622,y:526,t:1527793911876};\\\", \\\"{x:1622,y:538,t:1527793911892};\\\", \\\"{x:1622,y:555,t:1527793911908};\\\", \\\"{x:1627,y:584,t:1527793911925};\\\", \\\"{x:1635,y:627,t:1527793911942};\\\", \\\"{x:1640,y:658,t:1527793911959};\\\", \\\"{x:1644,y:678,t:1527793911975};\\\", \\\"{x:1645,y:686,t:1527793911992};\\\", \\\"{x:1645,y:690,t:1527793912008};\\\", \\\"{x:1645,y:691,t:1527793912041};\\\", \\\"{x:1644,y:691,t:1527793912145};\\\", \\\"{x:1643,y:688,t:1527793912158};\\\", \\\"{x:1638,y:677,t:1527793912175};\\\", \\\"{x:1633,y:667,t:1527793912192};\\\", \\\"{x:1633,y:662,t:1527793912208};\\\", \\\"{x:1633,y:657,t:1527793912225};\\\", \\\"{x:1633,y:655,t:1527793912242};\\\", \\\"{x:1633,y:653,t:1527793912258};\\\", \\\"{x:1633,y:650,t:1527793912275};\\\", \\\"{x:1633,y:649,t:1527793912293};\\\", \\\"{x:1632,y:648,t:1527793912345};\\\", \\\"{x:1631,y:648,t:1527793912369};\\\", \\\"{x:1630,y:648,t:1527793912393};\\\", \\\"{x:1629,y:648,t:1527793912417};\\\", \\\"{x:1628,y:648,t:1527793912433};\\\", \\\"{x:1627,y:648,t:1527793912442};\\\", \\\"{x:1626,y:648,t:1527793912465};\\\", \\\"{x:1625,y:648,t:1527793912488};\\\", \\\"{x:1623,y:648,t:1527793912529};\\\", \\\"{x:1622,y:648,t:1527793912560};\\\", \\\"{x:1621,y:648,t:1527793912577};\\\", \\\"{x:1620,y:648,t:1527793912593};\\\", \\\"{x:1619,y:649,t:1527793912746};\\\", \\\"{x:1619,y:653,t:1527793912759};\\\", \\\"{x:1621,y:664,t:1527793912776};\\\", \\\"{x:1621,y:669,t:1527793912777};\\\", \\\"{x:1622,y:673,t:1527793912793};\\\", \\\"{x:1626,y:693,t:1527793912809};\\\", \\\"{x:1627,y:707,t:1527793912827};\\\", \\\"{x:1629,y:717,t:1527793912843};\\\", \\\"{x:1630,y:726,t:1527793912859};\\\", \\\"{x:1631,y:737,t:1527793912877};\\\", \\\"{x:1632,y:748,t:1527793912892};\\\", \\\"{x:1635,y:762,t:1527793912910};\\\", \\\"{x:1636,y:774,t:1527793912926};\\\", \\\"{x:1636,y:785,t:1527793912944};\\\", \\\"{x:1636,y:791,t:1527793912960};\\\", \\\"{x:1636,y:797,t:1527793912976};\\\", \\\"{x:1636,y:809,t:1527793912993};\\\", \\\"{x:1636,y:818,t:1527793913009};\\\", \\\"{x:1636,y:825,t:1527793913027};\\\", \\\"{x:1636,y:831,t:1527793913044};\\\", \\\"{x:1636,y:837,t:1527793913060};\\\", \\\"{x:1635,y:840,t:1527793913076};\\\", \\\"{x:1634,y:843,t:1527793913094};\\\", \\\"{x:1634,y:846,t:1527793913111};\\\", \\\"{x:1632,y:849,t:1527793913127};\\\", \\\"{x:1632,y:852,t:1527793913144};\\\", \\\"{x:1631,y:855,t:1527793913161};\\\", \\\"{x:1631,y:856,t:1527793913185};\\\", \\\"{x:1631,y:857,t:1527793913193};\\\", \\\"{x:1631,y:858,t:1527793913210};\\\", \\\"{x:1631,y:859,t:1527793913227};\\\", \\\"{x:1631,y:860,t:1527793913233};\\\", \\\"{x:1631,y:861,t:1527793913244};\\\", \\\"{x:1631,y:862,t:1527793913274};\\\", \\\"{x:1631,y:863,t:1527793913314};\\\", \\\"{x:1631,y:865,t:1527793913554};\\\", \\\"{x:1631,y:866,t:1527793913570};\\\", \\\"{x:1631,y:867,t:1527793913578};\\\", \\\"{x:1631,y:870,t:1527793913595};\\\", \\\"{x:1631,y:875,t:1527793913612};\\\", \\\"{x:1632,y:879,t:1527793913627};\\\", \\\"{x:1632,y:883,t:1527793913644};\\\", \\\"{x:1633,y:885,t:1527793913662};\\\", \\\"{x:1634,y:887,t:1527793913679};\\\", \\\"{x:1634,y:888,t:1527793913695};\\\", \\\"{x:1634,y:889,t:1527793913714};\\\", \\\"{x:1634,y:890,t:1527793913730};\\\", \\\"{x:1634,y:892,t:1527793913795};\\\", \\\"{x:1633,y:892,t:1527793913810};\\\", \\\"{x:1632,y:893,t:1527793913826};\\\", \\\"{x:1631,y:894,t:1527793913834};\\\", \\\"{x:1630,y:895,t:1527793913850};\\\", \\\"{x:1629,y:895,t:1527793913863};\\\", \\\"{x:1628,y:896,t:1527793913879};\\\", \\\"{x:1626,y:898,t:1527793913895};\\\", \\\"{x:1624,y:899,t:1527793913913};\\\", \\\"{x:1622,y:901,t:1527793913929};\\\", \\\"{x:1622,y:898,t:1527793914146};\\\", \\\"{x:1622,y:887,t:1527793914164};\\\", \\\"{x:1624,y:878,t:1527793914180};\\\", \\\"{x:1624,y:864,t:1527793914197};\\\", \\\"{x:1624,y:852,t:1527793914214};\\\", \\\"{x:1624,y:842,t:1527793914230};\\\", \\\"{x:1623,y:829,t:1527793914247};\\\", \\\"{x:1623,y:823,t:1527793914264};\\\", \\\"{x:1623,y:813,t:1527793914281};\\\", \\\"{x:1623,y:794,t:1527793914298};\\\", \\\"{x:1623,y:779,t:1527793914314};\\\", \\\"{x:1623,y:769,t:1527793914331};\\\", \\\"{x:1623,y:762,t:1527793914348};\\\", \\\"{x:1623,y:753,t:1527793914364};\\\", \\\"{x:1623,y:744,t:1527793914381};\\\", \\\"{x:1623,y:736,t:1527793914398};\\\", \\\"{x:1623,y:727,t:1527793914414};\\\", \\\"{x:1623,y:719,t:1527793914431};\\\", \\\"{x:1623,y:710,t:1527793914448};\\\", \\\"{x:1623,y:706,t:1527793914466};\\\", \\\"{x:1623,y:703,t:1527793914481};\\\", \\\"{x:1623,y:696,t:1527793914499};\\\", \\\"{x:1623,y:691,t:1527793914515};\\\", \\\"{x:1623,y:689,t:1527793914531};\\\", \\\"{x:1625,y:685,t:1527793914548};\\\", \\\"{x:1625,y:684,t:1527793914565};\\\", \\\"{x:1625,y:681,t:1527793914582};\\\", \\\"{x:1625,y:679,t:1527793914598};\\\", \\\"{x:1625,y:678,t:1527793914615};\\\", \\\"{x:1624,y:675,t:1527793914632};\\\", \\\"{x:1624,y:672,t:1527793914648};\\\", \\\"{x:1622,y:670,t:1527793914665};\\\", \\\"{x:1622,y:668,t:1527793914682};\\\", \\\"{x:1622,y:666,t:1527793914698};\\\", \\\"{x:1622,y:664,t:1527793914715};\\\", \\\"{x:1622,y:661,t:1527793914732};\\\", \\\"{x:1621,y:656,t:1527793914749};\\\", \\\"{x:1621,y:654,t:1527793914765};\\\", \\\"{x:1621,y:651,t:1527793914782};\\\", \\\"{x:1620,y:648,t:1527793914799};\\\", \\\"{x:1620,y:647,t:1527793914816};\\\", \\\"{x:1620,y:646,t:1527793914832};\\\", \\\"{x:1619,y:645,t:1527793914866};\\\", \\\"{x:1618,y:645,t:1527793916106};\\\", \\\"{x:1618,y:644,t:1527793916121};\\\", \\\"{x:1616,y:644,t:1527793916218};\\\", \\\"{x:1615,y:643,t:1527793916234};\\\", \\\"{x:1614,y:642,t:1527793916258};\\\", \\\"{x:1614,y:641,t:1527793918010};\\\", \\\"{x:1614,y:640,t:1527793918113};\\\", \\\"{x:1614,y:639,t:1527793919858};\\\", \\\"{x:1614,y:638,t:1527793919866};\\\", \\\"{x:1613,y:637,t:1527793920618};\\\", \\\"{x:1612,y:637,t:1527793920882};\\\", \\\"{x:1611,y:637,t:1527793920889};\\\", \\\"{x:1610,y:637,t:1527793920902};\\\", \\\"{x:1608,y:637,t:1527793920920};\\\", \\\"{x:1606,y:637,t:1527793920937};\\\", \\\"{x:1605,y:637,t:1527793920952};\\\", \\\"{x:1605,y:638,t:1527793920970};\\\", \\\"{x:1604,y:639,t:1527793920987};\\\", \\\"{x:1603,y:640,t:1527793921346};\\\", \\\"{x:1599,y:640,t:1527793921426};\\\", \\\"{x:1588,y:640,t:1527793921438};\\\", \\\"{x:1544,y:624,t:1527793921454};\\\", \\\"{x:1442,y:598,t:1527793921471};\\\", \\\"{x:1332,y:576,t:1527793921488};\\\", \\\"{x:1220,y:554,t:1527793921503};\\\", \\\"{x:1093,y:522,t:1527793921520};\\\", \\\"{x:1037,y:512,t:1527793921537};\\\", \\\"{x:999,y:504,t:1527793921554};\\\", \\\"{x:980,y:503,t:1527793921571};\\\", \\\"{x:960,y:499,t:1527793921588};\\\", \\\"{x:940,y:496,t:1527793921605};\\\", \\\"{x:923,y:493,t:1527793921621};\\\", \\\"{x:893,y:488,t:1527793921638};\\\", \\\"{x:844,y:479,t:1527793921651};\\\", \\\"{x:786,y:473,t:1527793921667};\\\", \\\"{x:746,y:466,t:1527793921684};\\\", \\\"{x:717,y:464,t:1527793921701};\\\", \\\"{x:701,y:464,t:1527793921718};\\\", \\\"{x:690,y:464,t:1527793921733};\\\", \\\"{x:676,y:464,t:1527793921750};\\\", \\\"{x:663,y:464,t:1527793921768};\\\", \\\"{x:659,y:464,t:1527793921784};\\\", \\\"{x:654,y:464,t:1527793921801};\\\", \\\"{x:649,y:465,t:1527793921817};\\\", \\\"{x:645,y:467,t:1527793921834};\\\", \\\"{x:644,y:467,t:1527793921850};\\\", \\\"{x:643,y:467,t:1527793921868};\\\", \\\"{x:643,y:468,t:1527793921961};\\\", \\\"{x:643,y:469,t:1527793921970};\\\", \\\"{x:643,y:471,t:1527793921985};\\\", \\\"{x:643,y:475,t:1527793922005};\\\", \\\"{x:644,y:477,t:1527793922018};\\\", \\\"{x:645,y:479,t:1527793922579};\\\", \\\"{x:640,y:480,t:1527793922587};\\\", \\\"{x:628,y:481,t:1527793922602};\\\", \\\"{x:612,y:483,t:1527793922618};\\\", \\\"{x:593,y:484,t:1527793922635};\\\", \\\"{x:570,y:484,t:1527793922652};\\\", \\\"{x:544,y:484,t:1527793922667};\\\", \\\"{x:519,y:484,t:1527793922685};\\\", \\\"{x:488,y:484,t:1527793922703};\\\", \\\"{x:455,y:484,t:1527793922718};\\\", \\\"{x:413,y:484,t:1527793922735};\\\", \\\"{x:376,y:484,t:1527793922752};\\\", \\\"{x:342,y:484,t:1527793922769};\\\", \\\"{x:298,y:484,t:1527793922785};\\\", \\\"{x:277,y:484,t:1527793922802};\\\", \\\"{x:262,y:484,t:1527793922819};\\\", \\\"{x:258,y:484,t:1527793922835};\\\", \\\"{x:256,y:484,t:1527793922857};\\\", \\\"{x:256,y:485,t:1527793923042};\\\", \\\"{x:256,y:486,t:1527793923057};\\\", \\\"{x:256,y:487,t:1527793923068};\\\", \\\"{x:256,y:489,t:1527793923090};\\\", \\\"{x:256,y:491,t:1527793923102};\\\", \\\"{x:256,y:493,t:1527793923118};\\\", \\\"{x:257,y:497,t:1527793923135};\\\", \\\"{x:257,y:505,t:1527793923152};\\\", \\\"{x:257,y:513,t:1527793923168};\\\", \\\"{x:256,y:520,t:1527793923185};\\\", \\\"{x:256,y:521,t:1527793923209};\\\", \\\"{x:256,y:522,t:1527793923225};\\\", \\\"{x:255,y:524,t:1527793923236};\\\", \\\"{x:255,y:531,t:1527793923252};\\\", \\\"{x:257,y:536,t:1527793923269};\\\", \\\"{x:263,y:540,t:1527793923286};\\\", \\\"{x:268,y:542,t:1527793923302};\\\", \\\"{x:276,y:544,t:1527793923319};\\\", \\\"{x:282,y:544,t:1527793923334};\\\", \\\"{x:294,y:545,t:1527793923352};\\\", \\\"{x:324,y:545,t:1527793923370};\\\", \\\"{x:348,y:545,t:1527793923385};\\\", \\\"{x:376,y:545,t:1527793923402};\\\", \\\"{x:410,y:545,t:1527793923419};\\\", \\\"{x:443,y:545,t:1527793923435};\\\", \\\"{x:480,y:545,t:1527793923452};\\\", \\\"{x:518,y:544,t:1527793923469};\\\", \\\"{x:542,y:539,t:1527793923486};\\\", \\\"{x:556,y:537,t:1527793923502};\\\", \\\"{x:565,y:534,t:1527793923519};\\\", \\\"{x:575,y:532,t:1527793923536};\\\", \\\"{x:576,y:530,t:1527793923552};\\\", \\\"{x:578,y:527,t:1527793923569};\\\", \\\"{x:580,y:523,t:1527793923586};\\\", \\\"{x:584,y:519,t:1527793923602};\\\", \\\"{x:587,y:515,t:1527793923619};\\\", \\\"{x:587,y:513,t:1527793923637};\\\", \\\"{x:587,y:509,t:1527793923653};\\\", \\\"{x:590,y:505,t:1527793923669};\\\", \\\"{x:590,y:499,t:1527793923686};\\\", \\\"{x:587,y:486,t:1527793923701};\\\", \\\"{x:572,y:470,t:1527793923720};\\\", \\\"{x:549,y:458,t:1527793923736};\\\", \\\"{x:502,y:457,t:1527793923752};\\\", \\\"{x:436,y:457,t:1527793923770};\\\", \\\"{x:408,y:457,t:1527793923786};\\\", \\\"{x:390,y:457,t:1527793923804};\\\", \\\"{x:382,y:456,t:1527793923819};\\\", \\\"{x:381,y:455,t:1527793924345};\\\", \\\"{x:375,y:454,t:1527793924353};\\\", \\\"{x:354,y:450,t:1527793924370};\\\", \\\"{x:331,y:447,t:1527793924386};\\\", \\\"{x:296,y:442,t:1527793924403};\\\", \\\"{x:260,y:438,t:1527793924421};\\\", \\\"{x:225,y:433,t:1527793924436};\\\", \\\"{x:204,y:430,t:1527793924453};\\\", \\\"{x:197,y:429,t:1527793924470};\\\", \\\"{x:197,y:428,t:1527793924486};\\\", \\\"{x:198,y:429,t:1527793924850};\\\", \\\"{x:198,y:430,t:1527793924857};\\\", \\\"{x:198,y:432,t:1527793924906};\\\", \\\"{x:197,y:433,t:1527793924920};\\\", \\\"{x:188,y:438,t:1527793924938};\\\", \\\"{x:182,y:441,t:1527793924955};\\\", \\\"{x:179,y:441,t:1527793924970};\\\", \\\"{x:177,y:443,t:1527793924986};\\\", \\\"{x:172,y:444,t:1527793925004};\\\", \\\"{x:171,y:445,t:1527793925019};\\\", \\\"{x:175,y:445,t:1527793925281};\\\", \\\"{x:186,y:445,t:1527793925288};\\\", \\\"{x:196,y:450,t:1527793925304};\\\", \\\"{x:224,y:463,t:1527793925320};\\\", \\\"{x:311,y:513,t:1527793925338};\\\", \\\"{x:343,y:532,t:1527793925354};\\\", \\\"{x:370,y:552,t:1527793925371};\\\", \\\"{x:390,y:570,t:1527793925388};\\\", \\\"{x:404,y:587,t:1527793925405};\\\", \\\"{x:420,y:602,t:1527793925420};\\\", \\\"{x:433,y:614,t:1527793925437};\\\", \\\"{x:446,y:626,t:1527793925455};\\\", \\\"{x:453,y:630,t:1527793925470};\\\", \\\"{x:455,y:633,t:1527793925487};\\\", \\\"{x:460,y:640,t:1527793925504};\\\", \\\"{x:463,y:643,t:1527793925521};\\\", \\\"{x:464,y:643,t:1527793925545};\\\", \\\"{x:465,y:643,t:1527793925578};\\\", \\\"{x:469,y:644,t:1527793925587};\\\", \\\"{x:484,y:654,t:1527793925605};\\\", \\\"{x:490,y:657,t:1527793925621};\\\", \\\"{x:492,y:658,t:1527793925637};\\\", \\\"{x:493,y:659,t:1527793925655};\\\", \\\"{x:494,y:660,t:1527793925690};\\\", \\\"{x:496,y:662,t:1527793925704};\\\", \\\"{x:505,y:669,t:1527793925723};\\\", \\\"{x:505,y:670,t:1527793925793};\\\", \\\"{x:506,y:671,t:1527793925944};\\\", \\\"{x:507,y:671,t:1527793925969};\\\", \\\"{x:508,y:671,t:1527793925977};\\\", \\\"{x:509,y:671,t:1527793925988};\\\", \\\"{x:510,y:671,t:1527793926004};\\\", \\\"{x:511,y:670,t:1527793926021};\\\", \\\"{x:515,y:667,t:1527793926038};\\\" ] }, { \\\"rt\\\": 58103, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 511020, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -P -P \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:666,t:1527793928003};\\\", \\\"{x:525,y:666,t:1527793928024};\\\", \\\"{x:535,y:665,t:1527793928039};\\\", \\\"{x:549,y:665,t:1527793928056};\\\", \\\"{x:559,y:665,t:1527793928072};\\\", \\\"{x:582,y:665,t:1527793928089};\\\", \\\"{x:604,y:665,t:1527793928106};\\\", \\\"{x:626,y:666,t:1527793928123};\\\", \\\"{x:655,y:670,t:1527793928140};\\\", \\\"{x:687,y:675,t:1527793928156};\\\", \\\"{x:726,y:680,t:1527793928173};\\\", \\\"{x:755,y:686,t:1527793928189};\\\", \\\"{x:774,y:691,t:1527793928206};\\\", \\\"{x:789,y:696,t:1527793928222};\\\", \\\"{x:798,y:698,t:1527793928239};\\\", \\\"{x:803,y:698,t:1527793928257};\\\", \\\"{x:804,y:698,t:1527793928281};\\\", \\\"{x:798,y:701,t:1527793949147};\\\", \\\"{x:734,y:706,t:1527793949156};\\\", \\\"{x:456,y:706,t:1527793949171};\\\", \\\"{x:136,y:668,t:1527793949189};\\\", \\\"{x:16,y:651,t:1527793949205};\\\", \\\"{x:20,y:650,t:1527793949226};\\\", \\\"{x:22,y:649,t:1527793949238};\\\", \\\"{x:22,y:644,t:1527793949281};\\\", \\\"{x:15,y:629,t:1527793949290};\\\", \\\"{x:0,y:602,t:1527793949306};\\\", \\\"{x:0,y:600,t:1527793949321};\\\", \\\"{x:0,y:597,t:1527793949338};\\\", \\\"{x:3,y:597,t:1527793949666};\\\", \\\"{x:9,y:595,t:1527793949673};\\\", \\\"{x:20,y:595,t:1527793949689};\\\", \\\"{x:70,y:589,t:1527793949707};\\\", \\\"{x:102,y:588,t:1527793949722};\\\", \\\"{x:128,y:582,t:1527793949739};\\\", \\\"{x:144,y:577,t:1527793949757};\\\", \\\"{x:151,y:575,t:1527793949773};\\\", \\\"{x:155,y:573,t:1527793949790};\\\", \\\"{x:158,y:572,t:1527793949807};\\\", \\\"{x:160,y:571,t:1527793949824};\\\", \\\"{x:161,y:571,t:1527793949841};\\\", \\\"{x:174,y:573,t:1527793950153};\\\", \\\"{x:202,y:582,t:1527793950161};\\\", \\\"{x:233,y:592,t:1527793950175};\\\", \\\"{x:323,y:627,t:1527793950192};\\\", \\\"{x:415,y:659,t:1527793950207};\\\", \\\"{x:496,y:685,t:1527793950224};\\\", \\\"{x:562,y:706,t:1527793950241};\\\", \\\"{x:581,y:708,t:1527793950257};\\\", \\\"{x:587,y:710,t:1527793950275};\\\", \\\"{x:588,y:710,t:1527793950522};\\\", \\\"{x:587,y:707,t:1527793950530};\\\", \\\"{x:578,y:705,t:1527793950542};\\\", \\\"{x:563,y:701,t:1527793950559};\\\", \\\"{x:542,y:696,t:1527793950575};\\\", \\\"{x:526,y:691,t:1527793950591};\\\", \\\"{x:516,y:689,t:1527793950607};\\\", \\\"{x:514,y:689,t:1527793950624};\\\", \\\"{x:514,y:688,t:1527793950641};\\\", \\\"{x:514,y:687,t:1527793952098};\\\", \\\"{x:512,y:687,t:1527793952426};\\\", \\\"{x:502,y:686,t:1527793952442};\\\", \\\"{x:488,y:679,t:1527793952459};\\\", \\\"{x:468,y:670,t:1527793952475};\\\", \\\"{x:445,y:660,t:1527793952492};\\\", \\\"{x:421,y:651,t:1527793952508};\\\", \\\"{x:397,y:642,t:1527793952524};\\\", \\\"{x:379,y:636,t:1527793952542};\\\", \\\"{x:369,y:634,t:1527793952559};\\\", \\\"{x:363,y:633,t:1527793952577};\\\", \\\"{x:354,y:631,t:1527793952592};\\\", \\\"{x:347,y:628,t:1527793952609};\\\", \\\"{x:342,y:626,t:1527793952627};\\\", \\\"{x:338,y:623,t:1527793952642};\\\", \\\"{x:332,y:619,t:1527793952659};\\\", \\\"{x:329,y:616,t:1527793952677};\\\", \\\"{x:329,y:615,t:1527793952692};\\\", \\\"{x:326,y:611,t:1527793952709};\\\", \\\"{x:315,y:602,t:1527793952727};\\\", \\\"{x:285,y:585,t:1527793952744};\\\", \\\"{x:249,y:564,t:1527793952760};\\\", \\\"{x:242,y:559,t:1527793952776};\\\", \\\"{x:201,y:553,t:1527793952793};\\\", \\\"{x:172,y:548,t:1527793952809};\\\", \\\"{x:150,y:545,t:1527793952827};\\\", \\\"{x:126,y:541,t:1527793952844};\\\", \\\"{x:108,y:541,t:1527793952860};\\\", \\\"{x:102,y:541,t:1527793952876};\\\", \\\"{x:102,y:543,t:1527793952929};\\\", \\\"{x:104,y:546,t:1527793952944};\\\", \\\"{x:108,y:556,t:1527793952961};\\\", \\\"{x:112,y:561,t:1527793952976};\\\", \\\"{x:114,y:562,t:1527793953001};\\\", \\\"{x:116,y:562,t:1527793953011};\\\", \\\"{x:121,y:564,t:1527793953026};\\\", \\\"{x:127,y:565,t:1527793953044};\\\", \\\"{x:130,y:565,t:1527793953061};\\\", \\\"{x:134,y:565,t:1527793953077};\\\", \\\"{x:137,y:565,t:1527793953093};\\\", \\\"{x:141,y:565,t:1527793953110};\\\", \\\"{x:144,y:565,t:1527793953126};\\\", \\\"{x:147,y:565,t:1527793953143};\\\", \\\"{x:148,y:564,t:1527793953161};\\\", \\\"{x:150,y:564,t:1527793953178};\\\", \\\"{x:152,y:563,t:1527793953193};\\\", \\\"{x:153,y:563,t:1527793953211};\\\", \\\"{x:154,y:563,t:1527793953232};\\\", \\\"{x:156,y:562,t:1527793953257};\\\", \\\"{x:159,y:562,t:1527793953534};\\\", \\\"{x:166,y:563,t:1527793953541};\\\", \\\"{x:179,y:566,t:1527793953558};\\\", \\\"{x:239,y:581,t:1527793953574};\\\", \\\"{x:308,y:589,t:1527793953591};\\\", \\\"{x:394,y:610,t:1527793953608};\\\", \\\"{x:472,y:634,t:1527793953625};\\\", \\\"{x:541,y:654,t:1527793953640};\\\", \\\"{x:594,y:670,t:1527793953658};\\\", \\\"{x:633,y:686,t:1527793953675};\\\", \\\"{x:654,y:698,t:1527793953691};\\\", \\\"{x:665,y:706,t:1527793953708};\\\", \\\"{x:669,y:709,t:1527793953724};\\\", \\\"{x:670,y:711,t:1527793953740};\\\", \\\"{x:671,y:713,t:1527793953758};\\\", \\\"{x:673,y:719,t:1527793953774};\\\", \\\"{x:678,y:727,t:1527793953791};\\\", \\\"{x:681,y:730,t:1527793953807};\\\", \\\"{x:682,y:732,t:1527793953824};\\\", \\\"{x:682,y:733,t:1527793953840};\\\", \\\"{x:690,y:734,t:1527793954799};\\\", \\\"{x:703,y:734,t:1527793954807};\\\", \\\"{x:732,y:738,t:1527793954824};\\\", \\\"{x:784,y:741,t:1527793954841};\\\", \\\"{x:875,y:752,t:1527793954857};\\\", \\\"{x:984,y:768,t:1527793954875};\\\", \\\"{x:1116,y:802,t:1527793954891};\\\", \\\"{x:1236,y:825,t:1527793954906};\\\", \\\"{x:1325,y:840,t:1527793954923};\\\", \\\"{x:1373,y:848,t:1527793954941};\\\", \\\"{x:1393,y:849,t:1527793954957};\\\", \\\"{x:1396,y:850,t:1527793954973};\\\", \\\"{x:1391,y:848,t:1527793955063};\\\", \\\"{x:1391,y:847,t:1527793955102};\\\", \\\"{x:1392,y:847,t:1527793955727};\\\", \\\"{x:1393,y:847,t:1527793955743};\\\", \\\"{x:1394,y:847,t:1527793955757};\\\", \\\"{x:1398,y:847,t:1527793955775};\\\", \\\"{x:1400,y:847,t:1527793955790};\\\", \\\"{x:1416,y:842,t:1527793955806};\\\", \\\"{x:1438,y:832,t:1527793955824};\\\", \\\"{x:1462,y:815,t:1527793955840};\\\", \\\"{x:1491,y:784,t:1527793955857};\\\", \\\"{x:1519,y:749,t:1527793955874};\\\", \\\"{x:1548,y:693,t:1527793955890};\\\", \\\"{x:1575,y:624,t:1527793955907};\\\", \\\"{x:1599,y:543,t:1527793955924};\\\", \\\"{x:1616,y:482,t:1527793955940};\\\", \\\"{x:1625,y:451,t:1527793955958};\\\", \\\"{x:1630,y:442,t:1527793955975};\\\", \\\"{x:1635,y:433,t:1527793955990};\\\", \\\"{x:1635,y:420,t:1527793956007};\\\", \\\"{x:1635,y:407,t:1527793956023};\\\", \\\"{x:1632,y:388,t:1527793956040};\\\", \\\"{x:1628,y:374,t:1527793956057};\\\", \\\"{x:1626,y:369,t:1527793956073};\\\", \\\"{x:1623,y:365,t:1527793956090};\\\", \\\"{x:1620,y:362,t:1527793956107};\\\", \\\"{x:1616,y:359,t:1527793956124};\\\", \\\"{x:1613,y:357,t:1527793956141};\\\", \\\"{x:1608,y:353,t:1527793956158};\\\", \\\"{x:1604,y:350,t:1527793956173};\\\", \\\"{x:1600,y:345,t:1527793956191};\\\", \\\"{x:1598,y:344,t:1527793956207};\\\", \\\"{x:1598,y:343,t:1527793956263};\\\", \\\"{x:1598,y:342,t:1527793956351};\\\", \\\"{x:1598,y:341,t:1527793956365};\\\", \\\"{x:1598,y:340,t:1527793956373};\\\", \\\"{x:1597,y:340,t:1527793956454};\\\", \\\"{x:1594,y:340,t:1527793956462};\\\", \\\"{x:1589,y:342,t:1527793956472};\\\", \\\"{x:1571,y:354,t:1527793956490};\\\", \\\"{x:1549,y:374,t:1527793956507};\\\", \\\"{x:1530,y:392,t:1527793956523};\\\", \\\"{x:1511,y:407,t:1527793956539};\\\", \\\"{x:1501,y:413,t:1527793956556};\\\", \\\"{x:1494,y:417,t:1527793956573};\\\", \\\"{x:1487,y:423,t:1527793956590};\\\", \\\"{x:1484,y:430,t:1527793956605};\\\", \\\"{x:1481,y:435,t:1527793956623};\\\", \\\"{x:1478,y:444,t:1527793956640};\\\", \\\"{x:1475,y:451,t:1527793956657};\\\", \\\"{x:1473,y:460,t:1527793956673};\\\", \\\"{x:1469,y:468,t:1527793956690};\\\", \\\"{x:1466,y:475,t:1527793956707};\\\", \\\"{x:1462,y:484,t:1527793956723};\\\", \\\"{x:1457,y:497,t:1527793956740};\\\", \\\"{x:1454,y:509,t:1527793956756};\\\", \\\"{x:1449,y:522,t:1527793956773};\\\", \\\"{x:1441,y:539,t:1527793956790};\\\", \\\"{x:1439,y:548,t:1527793956807};\\\", \\\"{x:1437,y:553,t:1527793956824};\\\", \\\"{x:1436,y:559,t:1527793956840};\\\", \\\"{x:1436,y:562,t:1527793956856};\\\", \\\"{x:1436,y:565,t:1527793956873};\\\", \\\"{x:1436,y:566,t:1527793956890};\\\", \\\"{x:1436,y:568,t:1527793956919};\\\", \\\"{x:1437,y:569,t:1527793956927};\\\", \\\"{x:1439,y:571,t:1527793956940};\\\", \\\"{x:1445,y:573,t:1527793956957};\\\", \\\"{x:1452,y:575,t:1527793956973};\\\", \\\"{x:1453,y:575,t:1527793956989};\\\", \\\"{x:1455,y:575,t:1527793957006};\\\", \\\"{x:1455,y:576,t:1527793957207};\\\", \\\"{x:1453,y:576,t:1527793957231};\\\", \\\"{x:1452,y:576,t:1527793957240};\\\", \\\"{x:1451,y:576,t:1527793957256};\\\", \\\"{x:1450,y:577,t:1527793957272};\\\", \\\"{x:1449,y:578,t:1527793957317};\\\", \\\"{x:1449,y:579,t:1527793957325};\\\", \\\"{x:1447,y:579,t:1527793957349};\\\", \\\"{x:1448,y:579,t:1527793957917};\\\", \\\"{x:1448,y:578,t:1527793957925};\\\", \\\"{x:1449,y:577,t:1527793957939};\\\", \\\"{x:1452,y:572,t:1527793957956};\\\", \\\"{x:1454,y:566,t:1527793957973};\\\", \\\"{x:1457,y:553,t:1527793957989};\\\", \\\"{x:1461,y:528,t:1527793958005};\\\", \\\"{x:1463,y:517,t:1527793958022};\\\", \\\"{x:1463,y:508,t:1527793958039};\\\", \\\"{x:1467,y:492,t:1527793958055};\\\", \\\"{x:1471,y:479,t:1527793958073};\\\", \\\"{x:1474,y:470,t:1527793958089};\\\", \\\"{x:1479,y:459,t:1527793958106};\\\", \\\"{x:1484,y:450,t:1527793958123};\\\", \\\"{x:1488,y:443,t:1527793958139};\\\", \\\"{x:1490,y:433,t:1527793958156};\\\", \\\"{x:1494,y:421,t:1527793958173};\\\", \\\"{x:1501,y:410,t:1527793958189};\\\", \\\"{x:1512,y:397,t:1527793958206};\\\", \\\"{x:1517,y:391,t:1527793958222};\\\", \\\"{x:1522,y:384,t:1527793958239};\\\", \\\"{x:1525,y:380,t:1527793958256};\\\", \\\"{x:1528,y:376,t:1527793958272};\\\", \\\"{x:1531,y:371,t:1527793958289};\\\", \\\"{x:1537,y:363,t:1527793958306};\\\", \\\"{x:1541,y:359,t:1527793958321};\\\", \\\"{x:1542,y:357,t:1527793958339};\\\", \\\"{x:1544,y:357,t:1527793958356};\\\", \\\"{x:1547,y:355,t:1527793958372};\\\", \\\"{x:1548,y:353,t:1527793958389};\\\", \\\"{x:1551,y:351,t:1527793958406};\\\", \\\"{x:1552,y:350,t:1527793958430};\\\", \\\"{x:1553,y:348,t:1527793958446};\\\", \\\"{x:1554,y:347,t:1527793958456};\\\", \\\"{x:1554,y:345,t:1527793958472};\\\", \\\"{x:1557,y:342,t:1527793958489};\\\", \\\"{x:1557,y:340,t:1527793958506};\\\", \\\"{x:1558,y:338,t:1527793958521};\\\", \\\"{x:1559,y:336,t:1527793958543};\\\", \\\"{x:1560,y:336,t:1527793958559};\\\", \\\"{x:1560,y:335,t:1527793958572};\\\", \\\"{x:1561,y:333,t:1527793958589};\\\", \\\"{x:1565,y:329,t:1527793958606};\\\", \\\"{x:1566,y:328,t:1527793958622};\\\", \\\"{x:1567,y:328,t:1527793958639};\\\", \\\"{x:1569,y:327,t:1527793958657};\\\", \\\"{x:1569,y:326,t:1527793958673};\\\", \\\"{x:1570,y:326,t:1527793958690};\\\", \\\"{x:1571,y:325,t:1527793958706};\\\", \\\"{x:1573,y:324,t:1527793958723};\\\", \\\"{x:1575,y:323,t:1527793958759};\\\", \\\"{x:1576,y:322,t:1527793958791};\\\", \\\"{x:1577,y:321,t:1527793958863};\\\", \\\"{x:1577,y:320,t:1527793959255};\\\", \\\"{x:1577,y:317,t:1527793959272};\\\", \\\"{x:1579,y:313,t:1527793959289};\\\", \\\"{x:1579,y:311,t:1527793959305};\\\", \\\"{x:1581,y:308,t:1527793959322};\\\", \\\"{x:1581,y:307,t:1527793960574};\\\", \\\"{x:1583,y:306,t:1527793960967};\\\", \\\"{x:1584,y:305,t:1527793961070};\\\", \\\"{x:1585,y:304,t:1527793962007};\\\", \\\"{x:1583,y:305,t:1527793965080};\\\", \\\"{x:1581,y:306,t:1527793965087};\\\", \\\"{x:1575,y:307,t:1527793965105};\\\", \\\"{x:1572,y:305,t:1527793965120};\\\", \\\"{x:1570,y:304,t:1527793965137};\\\", \\\"{x:1568,y:300,t:1527793965154};\\\", \\\"{x:1567,y:296,t:1527793965170};\\\", \\\"{x:1564,y:289,t:1527793965187};\\\", \\\"{x:1563,y:283,t:1527793965204};\\\", \\\"{x:1560,y:278,t:1527793965220};\\\", \\\"{x:1556,y:272,t:1527793965237};\\\", \\\"{x:1556,y:270,t:1527793965254};\\\", \\\"{x:1555,y:267,t:1527793965269};\\\", \\\"{x:1554,y:260,t:1527793965286};\\\", \\\"{x:1554,y:257,t:1527793965303};\\\", \\\"{x:1554,y:256,t:1527793965319};\\\", \\\"{x:1554,y:254,t:1527793965407};\\\", \\\"{x:1554,y:253,t:1527793965463};\\\", \\\"{x:1554,y:251,t:1527793965511};\\\", \\\"{x:1554,y:250,t:1527793965575};\\\", \\\"{x:1553,y:249,t:1527793965631};\\\", \\\"{x:1553,y:248,t:1527793965711};\\\", \\\"{x:1552,y:247,t:1527793965791};\\\", \\\"{x:1551,y:247,t:1527793969863};\\\", \\\"{x:1550,y:247,t:1527793969871};\\\", \\\"{x:1549,y:247,t:1527793969895};\\\", \\\"{x:1546,y:247,t:1527793969919};\\\", \\\"{x:1545,y:247,t:1527793969944};\\\", \\\"{x:1544,y:247,t:1527793969951};\\\", \\\"{x:1541,y:246,t:1527793969967};\\\", \\\"{x:1539,y:246,t:1527793969985};\\\", \\\"{x:1537,y:246,t:1527793970005};\\\", \\\"{x:1536,y:246,t:1527793971544};\\\", \\\"{x:1536,y:247,t:1527793973527};\\\", \\\"{x:1535,y:248,t:1527793979287};\\\", \\\"{x:1536,y:248,t:1527793980391};\\\", \\\"{x:1536,y:247,t:1527793982647};\\\", \\\"{x:1536,y:246,t:1527793982663};\\\", \\\"{x:1536,y:245,t:1527793982791};\\\", \\\"{x:1537,y:245,t:1527793982910};\\\", \\\"{x:1538,y:244,t:1527793982951};\\\", \\\"{x:1537,y:244,t:1527793982991};\\\", \\\"{x:1532,y:245,t:1527793982998};\\\", \\\"{x:1520,y:251,t:1527793983012};\\\", \\\"{x:1477,y:267,t:1527793983029};\\\", \\\"{x:1370,y:272,t:1527793983046};\\\", \\\"{x:1259,y:272,t:1527793983063};\\\", \\\"{x:1099,y:272,t:1527793983079};\\\", \\\"{x:922,y:271,t:1527793983097};\\\", \\\"{x:734,y:269,t:1527793983112};\\\", \\\"{x:545,y:272,t:1527793983129};\\\", \\\"{x:374,y:274,t:1527793983147};\\\", \\\"{x:262,y:295,t:1527793983163};\\\", \\\"{x:191,y:322,t:1527793983180};\\\", \\\"{x:145,y:347,t:1527793983196};\\\", \\\"{x:130,y:357,t:1527793983212};\\\", \\\"{x:129,y:362,t:1527793983230};\\\", \\\"{x:141,y:373,t:1527793983246};\\\", \\\"{x:174,y:396,t:1527793983262};\\\", \\\"{x:210,y:413,t:1527793983279};\\\", \\\"{x:233,y:421,t:1527793983297};\\\", \\\"{x:259,y:428,t:1527793983313};\\\", \\\"{x:298,y:439,t:1527793983331};\\\", \\\"{x:359,y:454,t:1527793983346};\\\", \\\"{x:421,y:465,t:1527793983362};\\\", \\\"{x:481,y:484,t:1527793983381};\\\", \\\"{x:498,y:488,t:1527793983399};\\\", \\\"{x:511,y:491,t:1527793983416};\\\", \\\"{x:526,y:491,t:1527793983431};\\\", \\\"{x:541,y:491,t:1527793983448};\\\", \\\"{x:553,y:491,t:1527793983465};\\\", \\\"{x:562,y:491,t:1527793983482};\\\", \\\"{x:573,y:489,t:1527793983499};\\\", \\\"{x:588,y:488,t:1527793983515};\\\", \\\"{x:600,y:488,t:1527793983533};\\\", \\\"{x:611,y:486,t:1527793983548};\\\", \\\"{x:611,y:485,t:1527793983581};\\\", \\\"{x:601,y:485,t:1527793983599};\\\", \\\"{x:579,y:485,t:1527793983616};\\\", \\\"{x:550,y:483,t:1527793983632};\\\", \\\"{x:515,y:483,t:1527793983649};\\\", \\\"{x:493,y:481,t:1527793983666};\\\", \\\"{x:478,y:481,t:1527793983682};\\\", \\\"{x:469,y:481,t:1527793983699};\\\", \\\"{x:461,y:481,t:1527793983716};\\\", \\\"{x:455,y:481,t:1527793983732};\\\", \\\"{x:453,y:481,t:1527793983749};\\\", \\\"{x:452,y:481,t:1527793983766};\\\", \\\"{x:451,y:480,t:1527793983782};\\\", \\\"{x:450,y:480,t:1527793983799};\\\", \\\"{x:446,y:479,t:1527793983816};\\\", \\\"{x:440,y:477,t:1527793983832};\\\", \\\"{x:429,y:474,t:1527793983849};\\\", \\\"{x:427,y:474,t:1527793983866};\\\", \\\"{x:424,y:470,t:1527793983882};\\\", \\\"{x:423,y:470,t:1527793983899};\\\", \\\"{x:422,y:470,t:1527793983916};\\\", \\\"{x:420,y:470,t:1527793983932};\\\", \\\"{x:419,y:469,t:1527793983974};\\\", \\\"{x:418,y:468,t:1527793984205};\\\", \\\"{x:417,y:467,t:1527793984216};\\\", \\\"{x:416,y:466,t:1527793984233};\\\", \\\"{x:415,y:462,t:1527793984250};\\\", \\\"{x:414,y:460,t:1527793984266};\\\", \\\"{x:413,y:459,t:1527793984283};\\\", \\\"{x:412,y:459,t:1527793984298};\\\", \\\"{x:411,y:457,t:1527793984316};\\\", \\\"{x:411,y:456,t:1527793984333};\\\", \\\"{x:410,y:455,t:1527793984349};\\\", \\\"{x:409,y:454,t:1527793984366};\\\", \\\"{x:411,y:462,t:1527793984558};\\\", \\\"{x:425,y:482,t:1527793984566};\\\", \\\"{x:453,y:533,t:1527793984584};\\\", \\\"{x:477,y:591,t:1527793984601};\\\", \\\"{x:491,y:641,t:1527793984616};\\\", \\\"{x:520,y:709,t:1527793984633};\\\", \\\"{x:549,y:749,t:1527793984650};\\\", \\\"{x:574,y:783,t:1527793984666};\\\", \\\"{x:587,y:804,t:1527793984683};\\\", \\\"{x:595,y:816,t:1527793984699};\\\", \\\"{x:601,y:824,t:1527793984715};\\\", \\\"{x:600,y:821,t:1527793984750};\\\", \\\"{x:595,y:804,t:1527793984766};\\\", \\\"{x:591,y:780,t:1527793984783};\\\", \\\"{x:589,y:761,t:1527793984799};\\\", \\\"{x:589,y:752,t:1527793984816};\\\", \\\"{x:589,y:747,t:1527793984834};\\\", \\\"{x:589,y:744,t:1527793984850};\\\", \\\"{x:589,y:741,t:1527793984866};\\\", \\\"{x:589,y:735,t:1527793984883};\\\", \\\"{x:585,y:727,t:1527793984899};\\\", \\\"{x:579,y:719,t:1527793984916};\\\", \\\"{x:574,y:715,t:1527793984933};\\\", \\\"{x:571,y:714,t:1527793984949};\\\", \\\"{x:562,y:712,t:1527793984967};\\\", \\\"{x:552,y:710,t:1527793984983};\\\", \\\"{x:538,y:709,t:1527793985000};\\\", \\\"{x:521,y:704,t:1527793985016};\\\", \\\"{x:508,y:699,t:1527793985034};\\\", \\\"{x:503,y:696,t:1527793985049};\\\", \\\"{x:501,y:696,t:1527793985066};\\\", \\\"{x:501,y:695,t:1527793985309};\\\" ] }, { \\\"rt\\\": 11507, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 523733, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:695,t:1527793987024};\\\", \\\"{x:516,y:695,t:1527793987036};\\\", \\\"{x:518,y:695,t:1527793987053};\\\", \\\"{x:520,y:695,t:1527793987070};\\\", \\\"{x:521,y:695,t:1527793987094};\\\", \\\"{x:522,y:695,t:1527793987109};\\\", \\\"{x:523,y:695,t:1527793987126};\\\", \\\"{x:524,y:694,t:1527793987137};\\\", \\\"{x:524,y:693,t:1527793987154};\\\", \\\"{x:525,y:693,t:1527793987170};\\\", \\\"{x:526,y:693,t:1527793987187};\\\", \\\"{x:527,y:693,t:1527793987204};\\\", \\\"{x:529,y:692,t:1527793987221};\\\", \\\"{x:532,y:692,t:1527793987246};\\\", \\\"{x:533,y:692,t:1527793987254};\\\", \\\"{x:538,y:692,t:1527793987271};\\\", \\\"{x:543,y:692,t:1527793987287};\\\", \\\"{x:545,y:690,t:1527793987305};\\\", \\\"{x:547,y:689,t:1527793988823};\\\", \\\"{x:551,y:689,t:1527793988831};\\\", \\\"{x:555,y:688,t:1527793988844};\\\", \\\"{x:558,y:687,t:1527793988861};\\\", \\\"{x:566,y:687,t:1527793988879};\\\", \\\"{x:584,y:686,t:1527793988894};\\\", \\\"{x:597,y:686,t:1527793988911};\\\", \\\"{x:608,y:686,t:1527793988920};\\\", \\\"{x:627,y:686,t:1527793988936};\\\", \\\"{x:649,y:686,t:1527793988953};\\\", \\\"{x:666,y:686,t:1527793988970};\\\", \\\"{x:680,y:686,t:1527793988986};\\\", \\\"{x:693,y:686,t:1527793989003};\\\", \\\"{x:698,y:687,t:1527793989020};\\\", \\\"{x:701,y:687,t:1527793989036};\\\", \\\"{x:703,y:687,t:1527793989053};\\\", \\\"{x:705,y:687,t:1527793989070};\\\", \\\"{x:708,y:687,t:1527793989086};\\\", \\\"{x:710,y:687,t:1527793989103};\\\", \\\"{x:711,y:687,t:1527793989120};\\\", \\\"{x:713,y:687,t:1527793989142};\\\", \\\"{x:714,y:687,t:1527793989154};\\\", \\\"{x:715,y:687,t:1527793989182};\\\", \\\"{x:716,y:688,t:1527793989206};\\\", \\\"{x:717,y:688,t:1527793995767};\\\", \\\"{x:720,y:688,t:1527793995776};\\\", \\\"{x:723,y:685,t:1527793995792};\\\", \\\"{x:724,y:678,t:1527793995809};\\\", \\\"{x:724,y:661,t:1527793995825};\\\", \\\"{x:717,y:632,t:1527793995842};\\\", \\\"{x:700,y:596,t:1527793995860};\\\", \\\"{x:683,y:557,t:1527793995876};\\\", \\\"{x:672,y:533,t:1527793995894};\\\", \\\"{x:656,y:512,t:1527793995909};\\\", \\\"{x:633,y:490,t:1527793995926};\\\", \\\"{x:622,y:483,t:1527793995943};\\\", \\\"{x:612,y:478,t:1527793995959};\\\", \\\"{x:608,y:476,t:1527793995975};\\\", \\\"{x:605,y:475,t:1527793995993};\\\", \\\"{x:603,y:475,t:1527793996013};\\\", \\\"{x:601,y:476,t:1527793996029};\\\", \\\"{x:598,y:477,t:1527793996042};\\\", \\\"{x:582,y:483,t:1527793996060};\\\", \\\"{x:558,y:486,t:1527793996076};\\\", \\\"{x:529,y:489,t:1527793996093};\\\", \\\"{x:498,y:489,t:1527793996109};\\\", \\\"{x:453,y:489,t:1527793996125};\\\", \\\"{x:430,y:489,t:1527793996142};\\\", \\\"{x:417,y:489,t:1527793996159};\\\", \\\"{x:411,y:489,t:1527793996175};\\\", \\\"{x:410,y:489,t:1527793996193};\\\", \\\"{x:409,y:489,t:1527793996210};\\\", \\\"{x:410,y:489,t:1527793996229};\\\", \\\"{x:410,y:486,t:1527793996247};\\\", \\\"{x:410,y:483,t:1527793996261};\\\", \\\"{x:410,y:480,t:1527793996275};\\\", \\\"{x:410,y:476,t:1527793996293};\\\", \\\"{x:409,y:469,t:1527793996310};\\\", \\\"{x:407,y:466,t:1527793996325};\\\", \\\"{x:406,y:465,t:1527793996342};\\\", \\\"{x:406,y:464,t:1527793996366};\\\", \\\"{x:406,y:468,t:1527793996629};\\\", \\\"{x:410,y:481,t:1527793996643};\\\", \\\"{x:425,y:509,t:1527793996660};\\\", \\\"{x:445,y:549,t:1527793996677};\\\", \\\"{x:477,y:602,t:1527793996693};\\\", \\\"{x:508,y:649,t:1527793996710};\\\", \\\"{x:514,y:657,t:1527793996726};\\\", \\\"{x:518,y:668,t:1527793996742};\\\", \\\"{x:519,y:674,t:1527793996760};\\\", \\\"{x:520,y:674,t:1527793996902};\\\", \\\"{x:520,y:672,t:1527793996927};\\\", \\\"{x:518,y:668,t:1527793996943};\\\", \\\"{x:512,y:667,t:1527793996960};\\\", \\\"{x:505,y:662,t:1527793996977};\\\", \\\"{x:491,y:656,t:1527793996993};\\\", \\\"{x:474,y:643,t:1527793997011};\\\", \\\"{x:453,y:628,t:1527793997028};\\\", \\\"{x:407,y:602,t:1527793997043};\\\", \\\"{x:361,y:578,t:1527793997060};\\\", \\\"{x:328,y:565,t:1527793997076};\\\", \\\"{x:304,y:552,t:1527793997094};\\\", \\\"{x:300,y:546,t:1527793997109};\\\", \\\"{x:297,y:536,t:1527793997127};\\\", \\\"{x:297,y:528,t:1527793997143};\\\", \\\"{x:297,y:519,t:1527793997160};\\\", \\\"{x:301,y:514,t:1527793997177};\\\", \\\"{x:301,y:511,t:1527793997193};\\\", \\\"{x:304,y:507,t:1527793997210};\\\", \\\"{x:305,y:504,t:1527793997226};\\\", \\\"{x:307,y:504,t:1527793997243};\\\", \\\"{x:311,y:502,t:1527793997261};\\\", \\\"{x:320,y:499,t:1527793997277};\\\", \\\"{x:331,y:499,t:1527793997293};\\\", \\\"{x:336,y:499,t:1527793997310};\\\", \\\"{x:346,y:504,t:1527793997326};\\\", \\\"{x:362,y:506,t:1527793997344};\\\", \\\"{x:378,y:514,t:1527793997360};\\\", \\\"{x:405,y:528,t:1527793997378};\\\", \\\"{x:432,y:544,t:1527793997394};\\\", \\\"{x:466,y:575,t:1527793997411};\\\", \\\"{x:501,y:616,t:1527793997427};\\\", \\\"{x:528,y:660,t:1527793997443};\\\", \\\"{x:541,y:688,t:1527793997461};\\\", \\\"{x:546,y:709,t:1527793997477};\\\", \\\"{x:550,y:737,t:1527793997494};\\\", \\\"{x:550,y:750,t:1527793997511};\\\", \\\"{x:551,y:759,t:1527793997526};\\\", \\\"{x:551,y:762,t:1527793997544};\\\", \\\"{x:551,y:763,t:1527793997561};\\\", \\\"{x:550,y:763,t:1527793997577};\\\", \\\"{x:546,y:754,t:1527793997594};\\\", \\\"{x:544,y:745,t:1527793997611};\\\", \\\"{x:543,y:742,t:1527793997627};\\\", \\\"{x:542,y:740,t:1527793997644};\\\", \\\"{x:541,y:738,t:1527793997661};\\\", \\\"{x:538,y:733,t:1527793997678};\\\", \\\"{x:534,y:724,t:1527793997693};\\\", \\\"{x:526,y:710,t:1527793997712};\\\", \\\"{x:521,y:699,t:1527793997727};\\\", \\\"{x:520,y:696,t:1527793997743};\\\", \\\"{x:519,y:695,t:1527793997760};\\\", \\\"{x:521,y:695,t:1527793998062};\\\", \\\"{x:528,y:700,t:1527793998077};\\\", \\\"{x:542,y:706,t:1527793998093};\\\", \\\"{x:563,y:713,t:1527793998111};\\\", \\\"{x:581,y:721,t:1527793998128};\\\", \\\"{x:582,y:721,t:1527793998144};\\\", \\\"{x:583,y:721,t:1527793998161};\\\", \\\"{x:584,y:721,t:1527793998178};\\\" ] }, { \\\"rt\\\": 85662, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 610607, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"to see which letter(s) on the diagram points to 12PM\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7687, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"24\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\\n\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 619300, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 18098, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 638416, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 28154, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 667921, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"LW2XG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"LW2XG\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 272, dom: 775, initialDom: 864",
  "javascriptErrors": []
}