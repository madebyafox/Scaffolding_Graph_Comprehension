var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "99197fbded5c570c835e47dd83109c90",
  "created": "2018-06-04T13:17:23.7263989-07:00",
  "lastActivity": "2018-06-04T13:17:51.7463989-07:00",
  "pageViews": [
    {
      "id": "06042369ddc2e8204817f06ea5ab1f04ef59f9e3",
      "startTime": "2018-06-04T13:17:23.7263989-07:00",
      "endTime": "2018-06-04T13:17:51.7463989-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 28020,
      "engagementTime": 12395,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28020,
  "engagementTime": 12395,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K0CNH",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "37d96b77c95d71a191894bd2ac3d7e6b",
  "gdpr": false
}