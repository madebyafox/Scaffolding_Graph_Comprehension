var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f2e88e9af415abab94e17e06c79d2871",
  "created": "2018-05-21T12:07:16.7000107-07:00",
  "lastActivity": "2018-05-21T12:10:45.6790107-07:00",
  "pageViews": [
    {
      "id": "052116883a05d87648f2515814dc5fba02d2788d",
      "startTime": "2018-05-21T12:07:16.7000107-07:00",
      "endTime": "2018-05-21T12:10:45.6790107-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 208979,
      "engagementTime": 98777,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 208979,
  "engagementTime": 98777,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a2d8186be8d39786097f96522cd81712",
  "gdpr": false
}