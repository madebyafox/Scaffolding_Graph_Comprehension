var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "96f5914b582394f5efe3abf708be6eb4",
  "created": "2018-05-24T12:06:04.28569-07:00",
  "lastActivity": "2018-05-24T12:06:25.3170588-07:00",
  "pageViews": [
    {
      "id": "0524040849596b0e9dcaf3685cc67d431d5f3cdc",
      "startTime": "2018-05-24T12:06:04.28569-07:00",
      "endTime": "2018-05-24T12:06:25.3170588-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 21089,
      "engagementTime": 11889,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21089,
  "engagementTime": 11889,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZUJQV",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1e138fe2a936178938b3c68ed25e8ccd",
  "gdpr": false
}