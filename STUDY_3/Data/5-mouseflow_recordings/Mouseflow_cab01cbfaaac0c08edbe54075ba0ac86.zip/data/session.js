var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cab01cbfaaac0c08edbe54075ba0ac86",
  "created": "2018-05-22T15:08:44.2328632-07:00",
  "lastActivity": "2018-05-22T15:09:06.2038632-07:00",
  "pageViews": [
    {
      "id": "05224450b4b548cb181ba537d551b3cda59a7ef9",
      "startTime": "2018-05-22T15:08:44.2328632-07:00",
      "endTime": "2018-05-22T15:09:06.2038632-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 21971,
      "engagementTime": 21971,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21971,
  "engagementTime": 21971,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CMMGH",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dc49a3fc5fe4201b3d4a027db62c31e1",
  "gdpr": false
}