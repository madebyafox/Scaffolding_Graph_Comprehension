var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c7f99204c446e5d7a3573661fbc4a02f",
  "created": "2018-06-04T13:17:26.6751558-07:00",
  "lastActivity": "2018-06-04T13:17:34.6801558-07:00",
  "pageViews": [
    {
      "id": "06042615b5011e8c7a943ead838c7e98e305393c",
      "startTime": "2018-06-04T13:17:26.6751558-07:00",
      "endTime": "2018-06-04T13:17:34.6801558-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 8005,
      "engagementTime": 8005,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 8005,
  "engagementTime": 8005,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=06217",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ff6b7ebd478c19fa93eb42c5b9d0acca",
  "gdpr": false
}