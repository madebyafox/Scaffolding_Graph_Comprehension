var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060429488a208270284de1725d3c00aedbbca890"] = {
  "startTime": "2018-06-04T19:17:29.4057101Z",
  "websitePageUrl": "/16",
  "visitTime": 90475,
  "engagementTime": 87943,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "800416a5df6bfaf676e054c08f56bf08",
    "created": "2018-06-04T19:17:28.961219+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=8EQOW",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "86f006687b86a358a3b5c59b3ca10fc9",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/800416a5df6bfaf676e054c08f56bf08/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 201,
      "e": 201,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 1806,
      "y": 595
    },
    {
      "t": 266,
      "e": 266,
      "ty": 41,
      "x": 64622,
      "y": 32447,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 600,
      "e": 600,
      "ty": 2,
      "x": 1611,
      "y": 590
    },
    {
      "t": 823,
      "e": 823,
      "ty": 2,
      "x": 1160,
      "y": 589
    },
    {
      "t": 824,
      "e": 824,
      "ty": 41,
      "x": 26356,
      "y": 32301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 826,
      "e": 826,
      "ty": 6,
      "x": 674,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 422,
      "y": 573
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 374,
      "y": 549
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 31127,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1930,
      "e": 1930,
      "ty": 3,
      "x": 374,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1931,
      "e": 1931,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2043,
      "e": 2043,
      "ty": 4,
      "x": 31127,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2043,
      "e": 2043,
      "ty": 5,
      "x": 374,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 32026,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2268,
      "e": 2268,
      "ty": 7,
      "x": 442,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 539,
      "y": 462
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 637,
      "y": 342
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 638,
      "y": 335
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 60803,
      "y": 18114,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6840,
      "e": 6840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7015,
      "e": 7015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 7016,
      "e": 7016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7070,
      "e": 7070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 7118,
      "e": 7118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 7224,
      "e": 7224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7224,
      "e": 7224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7311,
      "e": 7311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 7382,
      "e": 7382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7383,
      "e": 7383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7463,
      "e": 7463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 7575,
      "e": 7575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 7575,
      "e": 7575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7703,
      "e": 7703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7703,
      "e": 7703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7743,
      "e": 7743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look "
    },
    {
      "t": 7854,
      "e": 7854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8070,
      "e": 8070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8143,
      "e": 8143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 8256,
      "e": 8256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8318,
      "e": 8318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 8415,
      "e": 8415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8495,
      "e": 8495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 8583,
      "e": 8583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8654,
      "e": 8654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 8791,
      "e": 8791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8871,
      "e": 8871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9263,
      "e": 9263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9391,
      "e": 9391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 9392,
      "e": 9392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9438,
      "e": 9438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 9478,
      "e": 9478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 9478,
      "e": 9478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 9479,
      "e": 9479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9558,
      "e": 9558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 9679,
      "e": 9679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9680,
      "e": 9680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9774,
      "e": 9774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 9775,
      "e": 9775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 9775,
      "e": 9775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9854,
      "e": 9854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find"
    },
    {
      "t": 9886,
      "e": 9886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9887,
      "e": 9887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find "
    },
    {
      "t": 10023,
      "e": 10023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11367,
      "e": 11367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11368,
      "e": 11368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11478,
      "e": 11478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11639,
      "e": 11639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11640,
      "e": 11640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11782,
      "e": 11782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12415,
      "e": 12415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12462,
      "e": 12462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find t"
    },
    {
      "t": 12574,
      "e": 12574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12671,
      "e": 12671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find "
    },
    {
      "t": 12695,
      "e": 12695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 12696,
      "e": 12696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12782,
      "e": 12782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 12887,
      "e": 12887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 12887,
      "e": 12887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12959,
      "e": 12959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 13935,
      "e": 13935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13936,
      "e": 13936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14046,
      "e": 14046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14086,
      "e": 14086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14086,
      "e": 14086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14202,
      "e": 14202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 p"
    },
    {
      "t": 14247,
      "e": 14247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14247,
      "e": 14247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14326,
      "e": 14326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14326,
      "e": 14326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14342,
      "e": 14342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm "
    },
    {
      "t": 14406,
      "e": 14406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14551,
      "e": 14551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14551,
      "e": 14551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14566,
      "e": 14566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 14751,
      "e": 14751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14751,
      "e": 14751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14774,
      "e": 14774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 14902,
      "e": 14902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14902,
      "e": 14902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14942,
      "e": 14942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14998,
      "e": 14998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14998,
      "e": 14998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15046,
      "e": 15046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15094,
      "e": 15094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15126,
      "e": 15126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15126,
      "e": 15126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15246,
      "e": 15246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15246,
      "e": 15246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15278,
      "e": 15278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 15326,
      "e": 15326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15566,
      "e": 15566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15622,
      "e": 15622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm pn th"
    },
    {
      "t": 15726,
      "e": 15726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15782,
      "e": 15782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm pn t"
    },
    {
      "t": 15879,
      "e": 15879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15934,
      "e": 15934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm pn "
    },
    {
      "t": 16038,
      "e": 16038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16111,
      "e": 16111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm pn"
    },
    {
      "t": 16207,
      "e": 16207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16270,
      "e": 16270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm p"
    },
    {
      "t": 16390,
      "e": 16390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16447,
      "e": 16447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm "
    },
    {
      "t": 16871,
      "e": 16871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16872,
      "e": 16872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16998,
      "e": 16998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16998,
      "e": 16998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17111,
      "e": 17111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 17119,
      "e": 17119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17120,
      "e": 17120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17142,
      "e": 17142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17206,
      "e": 17206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17206,
      "e": 17206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17253,
      "e": 17253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17294,
      "e": 17294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17310,
      "e": 17310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17310,
      "e": 17310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17439,
      "e": 17439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17440,
      "e": 17440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17440,
      "e": 17440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17526,
      "e": 17526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17534,
      "e": 17534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17534,
      "e": 17534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17671,
      "e": 17671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18023,
      "e": 18023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18024,
      "e": 18024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18199,
      "e": 18199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18303,
      "e": 18303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18304,
      "e": 18304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18422,
      "e": 18422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18438,
      "e": 18438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18438,
      "e": 18438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18526,
      "e": 18526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18639,
      "e": 18639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18639,
      "e": 18639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18726,
      "e": 18726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19086,
      "e": 19086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 19086,
      "e": 19086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19158,
      "e": 19158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 19206,
      "e": 19206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19206,
      "e": 19206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19319,
      "e": 19319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19320,
      "e": 19320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19366,
      "e": 19366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 19431,
      "e": 19431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19431,
      "e": 19431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19438,
      "e": 19438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19494,
      "e": 19494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19602,
      "e": 19602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizont"
    },
    {
      "t": 19655,
      "e": 19655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19656,
      "e": 19656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19734,
      "e": 19734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19750,
      "e": 19750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 19750,
      "e": 19750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19879,
      "e": 19879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19880,
      "e": 19880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19925,
      "e": 19925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20014,
      "e": 20014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20110,
      "e": 20110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20110,
      "e": 20110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20198,
      "e": 20198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20351,
      "e": 20351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 20351,
      "e": 20351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20422,
      "e": 20422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 20486,
      "e": 20486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20486,
      "e": 20486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20599,
      "e": 20599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20599,
      "e": 20599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20607,
      "e": 20607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 20661,
      "e": 20661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20702,
      "e": 20702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20702,
      "e": 20702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20822,
      "e": 20822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21071,
      "e": 21071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21071,
      "e": 21071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21182,
      "e": 21182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 21206,
      "e": 21206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21206,
      "e": 21206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21343,
      "e": 21343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21375,
      "e": 21375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21375,
      "e": 21375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21470,
      "e": 21470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24750,
      "e": 24750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24751,
      "e": 24751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24862,
      "e": 24862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24878,
      "e": 24878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24878,
      "e": 24878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24951,
      "e": 24951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 24983,
      "e": 24983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24983,
      "e": 24983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25069,
      "e": 25069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25182,
      "e": 25182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25183,
      "e": 25183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25238,
      "e": 25238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25304,
      "e": 25304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25304,
      "e": 25304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25389,
      "e": 25389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25503,
      "e": 25503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25503,
      "e": 25503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25566,
      "e": 25566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 25567,
      "e": 25567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25614,
      "e": 25614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 25654,
      "e": 25654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25670,
      "e": 25670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25670,
      "e": 25670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25782,
      "e": 25782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25798,
      "e": 25798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25798,
      "e": 25798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25862,
      "e": 25862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25862,
      "e": 25862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25870,
      "e": 25870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 25974,
      "e": 25974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25982,
      "e": 25982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25982,
      "e": 25982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26046,
      "e": 26046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26046,
      "e": 26046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26070,
      "e": 26070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 26150,
      "e": 26150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26207,
      "e": 26207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26208,
      "e": 26208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26294,
      "e": 26294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 26310,
      "e": 26310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26310,
      "e": 26310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26422,
      "e": 26422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26430,
      "e": 26430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26431,
      "e": 26431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26510,
      "e": 26510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26663,
      "e": 26663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26663,
      "e": 26663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26726,
      "e": 26726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26726,
      "e": 26726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26741,
      "e": 26741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 26862,
      "e": 26862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26863,
      "e": 26863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26886,
      "e": 26886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 26991,
      "e": 26991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26991,
      "e": 26991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26998,
      "e": 26998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27054,
      "e": 27054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27062,
      "e": 27062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27062,
      "e": 27062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27182,
      "e": 27182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27182,
      "e": 27182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27230,
      "e": 27230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 27328,
      "e": 27328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27414,
      "e": 27414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27414,
      "e": 27414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27559,
      "e": 27559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27559,
      "e": 27559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27646,
      "e": 27646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 27678,
      "e": 27678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28063,
      "e": 28063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28064,
      "e": 28064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28174,
      "e": 28174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28205,
      "e": 28205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28206,
      "e": 28206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28294,
      "e": 28294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28318,
      "e": 28318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28319,
      "e": 28319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28415,
      "e": 28415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28438,
      "e": 28438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28439,
      "e": 28439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28502,
      "e": 28502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28510,
      "e": 28510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28511,
      "e": 28511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28613,
      "e": 28613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28654,
      "e": 28654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28654,
      "e": 28654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28743,
      "e": 28743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28895,
      "e": 28895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28896,
      "e": 28896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28958,
      "e": 28958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29151,
      "e": 29151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29152,
      "e": 29152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29270,
      "e": 29270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29310,
      "e": 29310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29310,
      "e": 29310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29374,
      "e": 29374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 29623,
      "e": 29623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29624,
      "e": 29624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29703,
      "e": 29703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 29821,
      "e": 29821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29821,
      "e": 29821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29966,
      "e": 29966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 29966,
      "e": 29966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30029,
      "e": 30029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||op"
    },
    {
      "t": 30102,
      "e": 30102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30103,
      "e": 30103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30166,
      "e": 30166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30206,
      "e": 30206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30470,
      "e": 30470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30471,
      "e": 30471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30534,
      "e": 30534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 31134,
      "e": 31134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31135,
      "e": 31135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31270,
      "e": 31270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31431,
      "e": 31431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 31431,
      "e": 31431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31589,
      "e": 31589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31590,
      "e": 31590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31606,
      "e": 31606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 31742,
      "e": 31742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31983,
      "e": 31983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31983,
      "e": 31983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32061,
      "e": 32061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 32165,
      "e": 32165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32167,
      "e": 32167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32230,
      "e": 32230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 32350,
      "e": 32350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32351,
      "e": 32351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32381,
      "e": 32381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 32517,
      "e": 32517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32518,
      "e": 32518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32574,
      "e": 32574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35974,
      "e": 35974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 35975,
      "e": 35975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36030,
      "e": 36030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 36150,
      "e": 36150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36150,
      "e": 36150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36238,
      "e": 36238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36311,
      "e": 36311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36342,
      "e": 36342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36343,
      "e": 36343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36397,
      "e": 36397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 36430,
      "e": 36430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36430,
      "e": 36430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36437,
      "e": 36437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36493,
      "e": 36493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36603,
      "e": 36603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. An"
    },
    {
      "t": 36630,
      "e": 36630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 36631,
      "e": 36631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36718,
      "e": 36718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36718,
      "e": 36718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36750,
      "e": 36750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 36853,
      "e": 36853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 36853,
      "e": 36853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36934,
      "e": 36934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 36966,
      "e": 36966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36966,
      "e": 36966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37158,
      "e": 37158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37198,
      "e": 37198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37201,
      "e": 37201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37294,
      "e": 37294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37326,
      "e": 37326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37479,
      "e": 37479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37480,
      "e": 37480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37590,
      "e": 37590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37622,
      "e": 37622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37622,
      "e": 37622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37726,
      "e": 37726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37814,
      "e": 37814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37815,
      "e": 37815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37942,
      "e": 37942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37942,
      "e": 37942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37965,
      "e": 37965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 38038,
      "e": 38038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38038,
      "e": 38038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38039,
      "e": 38039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38203,
      "e": 38203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point al"
    },
    {
      "t": 38222,
      "e": 38222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38222,
      "e": 38222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38318,
      "e": 38318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lo"
    },
    {
      "t": 38471,
      "e": 38471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38471,
      "e": 38471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38486,
      "e": 38486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 38582,
      "e": 38582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 38582,
      "e": 38582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38598,
      "e": 38598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 38686,
      "e": 38686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38766,
      "e": 38766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38767,
      "e": 38767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38886,
      "e": 38886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38959,
      "e": 38959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38959,
      "e": 38959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39030,
      "e": 39030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39030,
      "e": 39030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39038,
      "e": 39038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 39149,
      "e": 39149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39150,
      "e": 39150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39205,
      "e": 39205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39262,
      "e": 39262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39262,
      "e": 39262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39327,
      "e": 39327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39342,
      "e": 39342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39430,
      "e": 39430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39431,
      "e": 39431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39550,
      "e": 39550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39613,
      "e": 39613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39614,
      "e": 39614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39727,
      "e": 39727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39727,
      "e": 39727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39798,
      "e": 39798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 39822,
      "e": 39822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39822,
      "e": 39822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39894,
      "e": 39894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39917,
      "e": 39917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39918,
      "e": 39918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39950,
      "e": 39950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40006,
      "e": 40006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40006,
      "e": 40006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40014,
      "e": 40014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40133,
      "e": 40133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40149,
      "e": 40149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 40149,
      "e": 40149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40222,
      "e": 40222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40222,
      "e": 40222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40237,
      "e": 40237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||be"
    },
    {
      "t": 40277,
      "e": 40277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40402,
      "e": 40402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line be"
    },
    {
      "t": 40414,
      "e": 40414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 40415,
      "e": 40415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40478,
      "e": 40478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 40478,
      "e": 40478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40478,
      "e": 40478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40582,
      "e": 40582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40582,
      "e": 40582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40654,
      "e": 40654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 40686,
      "e": 40686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40687,
      "e": 40687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40693,
      "e": 40693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40765,
      "e": 40765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40789,
      "e": 40789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40789,
      "e": 40789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40910,
      "e": 40910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40918,
      "e": 40918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40918,
      "e": 40918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40999,
      "e": 40999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 42174,
      "e": 42174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42175,
      "e": 42175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42246,
      "e": 42246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49617,
      "e": 47246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49674,
      "e": 47303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins a"
    },
    {
      "t": 49793,
      "e": 47422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49849,
      "e": 47478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins "
    },
    {
      "t": 49954,
      "e": 47583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50004,
      "e": 47633,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50026,
      "e": 47655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins"
    },
    {
      "t": 50114,
      "e": 47743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50562,
      "e": 48191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begin"
    },
    {
      "t": 50690,
      "e": 48319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50721,
      "e": 48350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begi"
    },
    {
      "t": 50865,
      "e": 48494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50938,
      "e": 48567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line beg"
    },
    {
      "t": 51050,
      "e": 48679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51137,
      "e": 48766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line be"
    },
    {
      "t": 51594,
      "e": 49223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51657,
      "e": 49286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line b"
    },
    {
      "t": 51810,
      "e": 49439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51873,
      "e": 49502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line "
    },
    {
      "t": 52006,
      "e": 49635,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line "
    },
    {
      "t": 52506,
      "e": 50135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 52509,
      "e": 50136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52585,
      "e": 50212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 52601,
      "e": 50228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52602,
      "e": 50229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52674,
      "e": 50301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52802,
      "e": 50429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 52802,
      "e": 50429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52865,
      "e": 50492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52866,
      "e": 50493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52873,
      "e": 50500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gi"
    },
    {
      "t": 52953,
      "e": 50580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52954,
      "e": 50581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53034,
      "e": 50661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53042,
      "e": 50669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 53043,
      "e": 50670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53074,
      "e": 50701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 53130,
      "e": 50757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53154,
      "e": 50781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53155,
      "e": 50782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53257,
      "e": 50884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53273,
      "e": 50900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53274,
      "e": 50901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53346,
      "e": 50973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 53466,
      "e": 51093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53466,
      "e": 51093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53473,
      "e": 51100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53474,
      "e": 51101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53505,
      "e": 51132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 53529,
      "e": 51156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53553,
      "e": 51180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53554,
      "e": 51181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53633,
      "e": 51260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54322,
      "e": 51949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54385,
      "e": 52012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins art"
    },
    {
      "t": 54489,
      "e": 52116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54562,
      "e": 52189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins ar"
    },
    {
      "t": 54649,
      "e": 52276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54793,
      "e": 52420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins a"
    },
    {
      "t": 55058,
      "e": 52685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55059,
      "e": 52686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55137,
      "e": 52764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55218,
      "e": 52845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55218,
      "e": 52845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55305,
      "e": 52932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55338,
      "e": 52965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 55339,
      "e": 52966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55450,
      "e": 53077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 55546,
      "e": 53173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 55547,
      "e": 53174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55633,
      "e": 53260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 55904,
      "e": 53531,
      "ty": 2,
      "x": 737,
      "y": 309
    },
    {
      "t": 56004,
      "e": 53631,
      "ty": 2,
      "x": 884,
      "y": 639
    },
    {
      "t": 56005,
      "e": 53632,
      "ty": 41,
      "x": 6906,
      "y": 35883,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 56103,
      "e": 53730,
      "ty": 2,
      "x": 456,
      "y": 1199
    },
    {
      "t": 56204,
      "e": 53831,
      "ty": 2,
      "x": 186,
      "y": 989
    },
    {
      "t": 56254,
      "e": 53881,
      "ty": 41,
      "x": 14377,
      "y": 51962,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 56303,
      "e": 53930,
      "ty": 2,
      "x": 488,
      "y": 812
    },
    {
      "t": 56382,
      "e": 54009,
      "ty": 6,
      "x": 658,
      "y": 588,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56404,
      "e": 54031,
      "ty": 2,
      "x": 624,
      "y": 554
    },
    {
      "t": 56415,
      "e": 54042,
      "ty": 7,
      "x": 567,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56503,
      "e": 54130,
      "ty": 2,
      "x": 364,
      "y": 467
    },
    {
      "t": 56504,
      "e": 54131,
      "ty": 41,
      "x": 30002,
      "y": 25427,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 56565,
      "e": 54192,
      "ty": 6,
      "x": 342,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56581,
      "e": 54208,
      "ty": 7,
      "x": 363,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56604,
      "e": 54231,
      "ty": 2,
      "x": 388,
      "y": 646
    },
    {
      "t": 56616,
      "e": 54243,
      "ty": 6,
      "x": 411,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 56632,
      "e": 54259,
      "ty": 7,
      "x": 427,
      "y": 693,
      "ta": "#strategyButton"
    },
    {
      "t": 56704,
      "e": 54331,
      "ty": 2,
      "x": 444,
      "y": 713
    },
    {
      "t": 56754,
      "e": 54381,
      "ty": 41,
      "x": 58703,
      "y": 59810,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 56865,
      "e": 54492,
      "ty": 6,
      "x": 450,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 56904,
      "e": 54531,
      "ty": 2,
      "x": 450,
      "y": 681
    },
    {
      "t": 57004,
      "e": 54631,
      "ty": 2,
      "x": 449,
      "y": 677
    },
    {
      "t": 57004,
      "e": 54631,
      "ty": 41,
      "x": 60295,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 57071,
      "e": 54698,
      "ty": 3,
      "x": 449,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 57073,
      "e": 54698,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins at 12"
    },
    {
      "t": 57075,
      "e": 54700,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57077,
      "e": 54702,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 57157,
      "e": 54782,
      "ty": 4,
      "x": 60295,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 57167,
      "e": 54792,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 57169,
      "e": 54794,
      "ty": 5,
      "x": 449,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 57175,
      "e": 54800,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 57254,
      "e": 54879,
      "ty": 41,
      "x": 16082,
      "y": 37282,
      "ta": "html > body"
    },
    {
      "t": 57304,
      "e": 54929,
      "ty": 2,
      "x": 601,
      "y": 688
    },
    {
      "t": 57404,
      "e": 55029,
      "ty": 2,
      "x": 1484,
      "y": 574
    },
    {
      "t": 57504,
      "e": 55129,
      "ty": 2,
      "x": 1917,
      "y": 554
    },
    {
      "t": 57603,
      "e": 55228,
      "ty": 2,
      "x": 1919,
      "y": 555
    },
    {
      "t": 57804,
      "e": 55429,
      "ty": 2,
      "x": 1908,
      "y": 552
    },
    {
      "t": 57904,
      "e": 55529,
      "ty": 2,
      "x": 1891,
      "y": 549
    },
    {
      "t": 58004,
      "e": 55629,
      "ty": 2,
      "x": 1889,
      "y": 548
    },
    {
      "t": 58004,
      "e": 55629,
      "ty": 41,
      "x": 64777,
      "y": 29914,
      "ta": "html > body"
    },
    {
      "t": 58104,
      "e": 55729,
      "ty": 2,
      "x": 1811,
      "y": 514
    },
    {
      "t": 58175,
      "e": 55800,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 58204,
      "e": 55829,
      "ty": 2,
      "x": 1803,
      "y": 505
    },
    {
      "t": 58254,
      "e": 55879,
      "ty": 41,
      "x": 61712,
      "y": 27477,
      "ta": "html > body"
    },
    {
      "t": 58304,
      "e": 55929,
      "ty": 2,
      "x": 1800,
      "y": 504
    },
    {
      "t": 58703,
      "e": 56328,
      "ty": 2,
      "x": 1735,
      "y": 487
    },
    {
      "t": 58754,
      "e": 56379,
      "ty": 41,
      "x": 47420,
      "y": 25150,
      "ta": "html > body"
    },
    {
      "t": 58804,
      "e": 56429,
      "ty": 2,
      "x": 956,
      "y": 519
    },
    {
      "t": 58903,
      "e": 56528,
      "ty": 2,
      "x": 812,
      "y": 536
    },
    {
      "t": 59004,
      "e": 56629,
      "ty": 2,
      "x": 820,
      "y": 540
    },
    {
      "t": 59004,
      "e": 56629,
      "ty": 41,
      "x": 2595,
      "y": 35233,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 59051,
      "e": 56676,
      "ty": 6,
      "x": 839,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59084,
      "e": 56709,
      "ty": 7,
      "x": 847,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59103,
      "e": 56728,
      "ty": 2,
      "x": 847,
      "y": 577
    },
    {
      "t": 59254,
      "e": 56879,
      "ty": 41,
      "x": 8435,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 59335,
      "e": 56960,
      "ty": 6,
      "x": 847,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59404,
      "e": 57029,
      "ty": 2,
      "x": 847,
      "y": 562
    },
    {
      "t": 59504,
      "e": 57129,
      "ty": 41,
      "x": 8435,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59909,
      "e": 57534,
      "ty": 3,
      "x": 847,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59910,
      "e": 57535,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60038,
      "e": 57663,
      "ty": 4,
      "x": 8435,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60039,
      "e": 57664,
      "ty": 5,
      "x": 847,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60217,
      "e": 57842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 60217,
      "e": 57842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60281,
      "e": 57906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 60361,
      "e": 57986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 60363,
      "e": 57988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60458,
      "e": 58083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 60510,
      "e": 58135,
      "ty": 7,
      "x": 844,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60604,
      "e": 58229,
      "ty": 2,
      "x": 822,
      "y": 717
    },
    {
      "t": 60704,
      "e": 58329,
      "ty": 2,
      "x": 822,
      "y": 718
    },
    {
      "t": 60755,
      "e": 58380,
      "ty": 41,
      "x": 28238,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 60804,
      "e": 58429,
      "ty": 2,
      "x": 844,
      "y": 696
    },
    {
      "t": 60903,
      "e": 58528,
      "ty": 2,
      "x": 860,
      "y": 685
    },
    {
      "t": 61004,
      "e": 58629,
      "ty": 2,
      "x": 874,
      "y": 675
    },
    {
      "t": 61005,
      "e": 58630,
      "ty": 41,
      "x": 14274,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 61036,
      "e": 58661,
      "ty": 6,
      "x": 886,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61104,
      "e": 58729,
      "ty": 2,
      "x": 900,
      "y": 657
    },
    {
      "t": 61254,
      "e": 58879,
      "ty": 41,
      "x": 19898,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61279,
      "e": 58904,
      "ty": 3,
      "x": 900,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61280,
      "e": 58905,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 61280,
      "e": 58905,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61280,
      "e": 58905,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61349,
      "e": 58974,
      "ty": 4,
      "x": 19898,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61349,
      "e": 58974,
      "ty": 5,
      "x": 900,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62058,
      "e": 59683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 62185,
      "e": 59810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 62187,
      "e": 59812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62249,
      "e": 59874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 62289,
      "e": 59914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 62418,
      "e": 60043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 62418,
      "e": 60043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62522,
      "e": 60147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 62523,
      "e": 60148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62554,
      "e": 60179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 62641,
      "e": 60266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 62713,
      "e": 60338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 62714,
      "e": 60339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62786,
      "e": 60411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 62802,
      "e": 60427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 62802,
      "e": 60427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62881,
      "e": 60506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 62969,
      "e": 60594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 62969,
      "e": 60594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63057,
      "e": 60682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 63059,
      "e": 60684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63064,
      "e": 60689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 63145,
      "e": 60770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 63201,
      "e": 60826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63233,
      "e": 60858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 63233,
      "e": 60858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63257,
      "e": 60882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 63313,
      "e": 60938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63361,
      "e": 60986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63363,
      "e": 60988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63434,
      "e": 61059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 63441,
      "e": 61066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 63442,
      "e": 61067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63520,
      "e": 61145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63521,
      "e": 61146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63529,
      "e": 61154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 63601,
      "e": 61226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 63633,
      "e": 61258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 63633,
      "e": 61258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63697,
      "e": 61322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 63786,
      "e": 61411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 63786,
      "e": 61411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63866,
      "e": 61491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 64022,
      "e": 61647,
      "ty": 7,
      "x": 964,
      "y": 626,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64104,
      "e": 61729,
      "ty": 2,
      "x": 1024,
      "y": 601
    },
    {
      "t": 64254,
      "e": 61879,
      "ty": 41,
      "x": 46718,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 64404,
      "e": 62029,
      "ty": 2,
      "x": 1016,
      "y": 628
    },
    {
      "t": 64421,
      "e": 62046,
      "ty": 6,
      "x": 1002,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64439,
      "e": 62047,
      "ty": 7,
      "x": 993,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64440,
      "e": 62048,
      "ty": 6,
      "x": 993,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64504,
      "e": 62112,
      "ty": 2,
      "x": 970,
      "y": 702
    },
    {
      "t": 64504,
      "e": 62112,
      "ty": 41,
      "x": 38179,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64505,
      "e": 62113,
      "ty": 7,
      "x": 967,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64604,
      "e": 62212,
      "ty": 2,
      "x": 955,
      "y": 725
    },
    {
      "t": 64689,
      "e": 62297,
      "ty": 6,
      "x": 956,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64704,
      "e": 62312,
      "ty": 2,
      "x": 956,
      "y": 707
    },
    {
      "t": 64754,
      "e": 62362,
      "ty": 41,
      "x": 31479,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64804,
      "e": 62412,
      "ty": 2,
      "x": 958,
      "y": 702
    },
    {
      "t": 64905,
      "e": 62513,
      "ty": 2,
      "x": 961,
      "y": 695
    },
    {
      "t": 64935,
      "e": 62543,
      "ty": 3,
      "x": 961,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64935,
      "e": 62543,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 64936,
      "e": 62544,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64936,
      "e": 62544,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65005,
      "e": 62613,
      "ty": 41,
      "x": 33540,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65013,
      "e": 62621,
      "ty": 4,
      "x": 33540,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65014,
      "e": 62622,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65014,
      "e": 62622,
      "ty": 5,
      "x": 961,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65014,
      "e": 62622,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 65204,
      "e": 62812,
      "ty": 2,
      "x": 1314,
      "y": 655
    },
    {
      "t": 65254,
      "e": 62862,
      "ty": 41,
      "x": 58062,
      "y": 33072,
      "ta": "html > body"
    },
    {
      "t": 65305,
      "e": 62913,
      "ty": 2,
      "x": 1819,
      "y": 586
    },
    {
      "t": 65404,
      "e": 63012,
      "ty": 2,
      "x": 1862,
      "y": 575
    },
    {
      "t": 65504,
      "e": 63112,
      "ty": 41,
      "x": 63847,
      "y": 31410,
      "ta": "html > body"
    },
    {
      "t": 66005,
      "e": 63613,
      "ty": 2,
      "x": 1866,
      "y": 573
    },
    {
      "t": 66005,
      "e": 63613,
      "ty": 41,
      "x": 63985,
      "y": 31299,
      "ta": "html > body"
    },
    {
      "t": 66028,
      "e": 63636,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 66105,
      "e": 63713,
      "ty": 2,
      "x": 1919,
      "y": 515
    },
    {
      "t": 66204,
      "e": 63812,
      "ty": 2,
      "x": 1919,
      "y": 540
    },
    {
      "t": 66304,
      "e": 63912,
      "ty": 2,
      "x": 1883,
      "y": 608
    },
    {
      "t": 66404,
      "e": 64012,
      "ty": 2,
      "x": 1868,
      "y": 621
    },
    {
      "t": 66504,
      "e": 64112,
      "ty": 41,
      "x": 64054,
      "y": 33958,
      "ta": "html > body"
    },
    {
      "t": 66604,
      "e": 64212,
      "ty": 2,
      "x": 1866,
      "y": 620
    },
    {
      "t": 66704,
      "e": 64312,
      "ty": 2,
      "x": 1227,
      "y": 309
    },
    {
      "t": 66754,
      "e": 64362,
      "ty": 41,
      "x": 46178,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 66804,
      "e": 64412,
      "ty": 2,
      "x": 1012,
      "y": 289
    },
    {
      "t": 66905,
      "e": 64513,
      "ty": 2,
      "x": 1013,
      "y": 290
    },
    {
      "t": 67005,
      "e": 64613,
      "ty": 41,
      "x": 60040,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 67254,
      "e": 64862,
      "ty": 41,
      "x": 59100,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 67304,
      "e": 64912,
      "ty": 2,
      "x": 981,
      "y": 275
    },
    {
      "t": 67404,
      "e": 65012,
      "ty": 2,
      "x": 878,
      "y": 238
    },
    {
      "t": 67504,
      "e": 65112,
      "ty": 2,
      "x": 814,
      "y": 220
    },
    {
      "t": 67505,
      "e": 65113,
      "ty": 41,
      "x": 27756,
      "y": 11744,
      "ta": "html > body"
    },
    {
      "t": 67604,
      "e": 65212,
      "ty": 2,
      "x": 813,
      "y": 220
    },
    {
      "t": 67705,
      "e": 65313,
      "ty": 2,
      "x": 813,
      "y": 238
    },
    {
      "t": 67755,
      "e": 65363,
      "ty": 41,
      "x": 27722,
      "y": 13073,
      "ta": "html > body"
    },
    {
      "t": 67804,
      "e": 65412,
      "ty": 2,
      "x": 813,
      "y": 244
    },
    {
      "t": 67904,
      "e": 65512,
      "ty": 2,
      "x": 823,
      "y": 244
    },
    {
      "t": 67959,
      "e": 65567,
      "ty": 6,
      "x": 826,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68004,
      "e": 65612,
      "ty": 2,
      "x": 827,
      "y": 240
    },
    {
      "t": 68005,
      "e": 65613,
      "ty": 41,
      "x": 2914,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68104,
      "e": 65712,
      "ty": 2,
      "x": 834,
      "y": 238
    },
    {
      "t": 68206,
      "e": 65814,
      "ty": 3,
      "x": 834,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68208,
      "e": 65816,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68255,
      "e": 65863,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68325,
      "e": 65933,
      "ty": 4,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68326,
      "e": 65934,
      "ty": 5,
      "x": 834,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68327,
      "e": 65935,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 68328,
      "e": 65936,
      "ty": 7,
      "x": 834,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68328,
      "e": 65936,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 68686,
      "e": 66294,
      "ty": 6,
      "x": 836,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68693,
      "e": 66301,
      "ty": 7,
      "x": 839,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68705,
      "e": 66313,
      "ty": 2,
      "x": 839,
      "y": 252
    },
    {
      "t": 68754,
      "e": 66362,
      "ty": 41,
      "x": 11150,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 68804,
      "e": 66412,
      "ty": 2,
      "x": 877,
      "y": 361
    },
    {
      "t": 68904,
      "e": 66512,
      "ty": 2,
      "x": 886,
      "y": 402
    },
    {
      "t": 69005,
      "e": 66613,
      "ty": 2,
      "x": 910,
      "y": 499
    },
    {
      "t": 69005,
      "e": 66613,
      "ty": 41,
      "x": 21021,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 69104,
      "e": 66712,
      "ty": 2,
      "x": 917,
      "y": 544
    },
    {
      "t": 69254,
      "e": 66862,
      "ty": 41,
      "x": 62485,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 69304,
      "e": 66912,
      "ty": 2,
      "x": 913,
      "y": 547
    },
    {
      "t": 69705,
      "e": 67313,
      "ty": 2,
      "x": 898,
      "y": 547
    },
    {
      "t": 69754,
      "e": 67362,
      "ty": 41,
      "x": 31781,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 69804,
      "e": 67412,
      "ty": 2,
      "x": 836,
      "y": 547
    },
    {
      "t": 69904,
      "e": 67512,
      "ty": 2,
      "x": 822,
      "y": 540
    },
    {
      "t": 70004,
      "e": 67612,
      "ty": 2,
      "x": 817,
      "y": 518
    },
    {
      "t": 70004,
      "e": 67612,
      "ty": 41,
      "x": 27860,
      "y": 28252,
      "ta": "html > body"
    },
    {
      "t": 70005,
      "e": 67613,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70104,
      "e": 67712,
      "ty": 2,
      "x": 823,
      "y": 509
    },
    {
      "t": 70204,
      "e": 67812,
      "ty": 2,
      "x": 831,
      "y": 508
    },
    {
      "t": 70244,
      "e": 67852,
      "ty": 6,
      "x": 835,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 70254,
      "e": 67862,
      "ty": 41,
      "x": 43243,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 70304,
      "e": 67912,
      "ty": 2,
      "x": 837,
      "y": 495
    },
    {
      "t": 70343,
      "e": 67951,
      "ty": 7,
      "x": 837,
      "y": 491,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 70404,
      "e": 68012,
      "ty": 2,
      "x": 837,
      "y": 488
    },
    {
      "t": 70504,
      "e": 68112,
      "ty": 41,
      "x": 3697,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 70604,
      "e": 68212,
      "ty": 2,
      "x": 834,
      "y": 490
    },
    {
      "t": 70705,
      "e": 68313,
      "ty": 2,
      "x": 833,
      "y": 491
    },
    {
      "t": 70755,
      "e": 68363,
      "ty": 41,
      "x": 10391,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 70823,
      "e": 68431,
      "ty": 3,
      "x": 833,
      "y": 491,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 70824,
      "e": 68432,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70941,
      "e": 68549,
      "ty": 4,
      "x": 10391,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 70941,
      "e": 68549,
      "ty": 5,
      "x": 833,
      "y": 491,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 70942,
      "e": 68550,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 70942,
      "e": 68550,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 71070,
      "e": 68678,
      "ty": 6,
      "x": 833,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 71104,
      "e": 68712,
      "ty": 2,
      "x": 833,
      "y": 492
    },
    {
      "t": 71160,
      "e": 68768,
      "ty": 7,
      "x": 844,
      "y": 503,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 71205,
      "e": 68813,
      "ty": 2,
      "x": 875,
      "y": 512
    },
    {
      "t": 71254,
      "e": 68862,
      "ty": 41,
      "x": 33837,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 71304,
      "e": 68912,
      "ty": 2,
      "x": 1039,
      "y": 560
    },
    {
      "t": 71404,
      "e": 69012,
      "ty": 2,
      "x": 1050,
      "y": 565
    },
    {
      "t": 71505,
      "e": 69113,
      "ty": 2,
      "x": 1057,
      "y": 595
    },
    {
      "t": 71505,
      "e": 69113,
      "ty": 41,
      "x": 55908,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 71604,
      "e": 69212,
      "ty": 2,
      "x": 1028,
      "y": 722
    },
    {
      "t": 71704,
      "e": 69312,
      "ty": 2,
      "x": 1004,
      "y": 771
    },
    {
      "t": 71755,
      "e": 69363,
      "ty": 41,
      "x": 43330,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 71905,
      "e": 69513,
      "ty": 2,
      "x": 1011,
      "y": 772
    },
    {
      "t": 72004,
      "e": 69612,
      "ty": 2,
      "x": 1014,
      "y": 774
    },
    {
      "t": 72005,
      "e": 69613,
      "ty": 41,
      "x": 45703,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 72704,
      "e": 70312,
      "ty": 2,
      "x": 1009,
      "y": 760
    },
    {
      "t": 72754,
      "e": 70362,
      "ty": 41,
      "x": 43330,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 72805,
      "e": 70413,
      "ty": 2,
      "x": 998,
      "y": 744
    },
    {
      "t": 72904,
      "e": 70512,
      "ty": 2,
      "x": 985,
      "y": 735
    },
    {
      "t": 73004,
      "e": 70612,
      "ty": 2,
      "x": 967,
      "y": 740
    },
    {
      "t": 73005,
      "e": 70613,
      "ty": 41,
      "x": 36538,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 73105,
      "e": 70713,
      "ty": 2,
      "x": 927,
      "y": 775
    },
    {
      "t": 73205,
      "e": 70813,
      "ty": 2,
      "x": 891,
      "y": 825
    },
    {
      "t": 73255,
      "e": 70863,
      "ty": 41,
      "x": 14614,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 73305,
      "e": 70913,
      "ty": 2,
      "x": 879,
      "y": 835
    },
    {
      "t": 73405,
      "e": 71013,
      "ty": 2,
      "x": 855,
      "y": 840
    },
    {
      "t": 73429,
      "e": 71037,
      "ty": 6,
      "x": 834,
      "y": 840,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 73462,
      "e": 71070,
      "ty": 7,
      "x": 824,
      "y": 839,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 73504,
      "e": 71112,
      "ty": 2,
      "x": 823,
      "y": 837
    },
    {
      "t": 73504,
      "e": 71112,
      "ty": 41,
      "x": 1111,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 73604,
      "e": 71212,
      "ty": 2,
      "x": 823,
      "y": 815
    },
    {
      "t": 73705,
      "e": 71313,
      "ty": 2,
      "x": 823,
      "y": 813
    },
    {
      "t": 73747,
      "e": 71314,
      "ty": 6,
      "x": 826,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73755,
      "e": 71322,
      "ty": 41,
      "x": 0,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73763,
      "e": 71330,
      "ty": 7,
      "x": 827,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73804,
      "e": 71371,
      "ty": 2,
      "x": 828,
      "y": 824
    },
    {
      "t": 73905,
      "e": 71472,
      "ty": 2,
      "x": 836,
      "y": 822
    },
    {
      "t": 74004,
      "e": 71571,
      "ty": 2,
      "x": 855,
      "y": 777
    },
    {
      "t": 74005,
      "e": 71572,
      "ty": 41,
      "x": 18798,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 74105,
      "e": 71672,
      "ty": 2,
      "x": 860,
      "y": 739
    },
    {
      "t": 74205,
      "e": 71772,
      "ty": 2,
      "x": 858,
      "y": 735
    },
    {
      "t": 74255,
      "e": 71822,
      "ty": 41,
      "x": 8427,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 74304,
      "e": 71871,
      "ty": 2,
      "x": 853,
      "y": 735
    },
    {
      "t": 74405,
      "e": 71972,
      "ty": 2,
      "x": 850,
      "y": 733
    },
    {
      "t": 74504,
      "e": 72071,
      "ty": 2,
      "x": 844,
      "y": 723
    },
    {
      "t": 74505,
      "e": 72072,
      "ty": 41,
      "x": 5666,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 74563,
      "e": 72130,
      "ty": 6,
      "x": 838,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74604,
      "e": 72171,
      "ty": 2,
      "x": 836,
      "y": 698
    },
    {
      "t": 74612,
      "e": 72179,
      "ty": 7,
      "x": 835,
      "y": 693,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74704,
      "e": 72271,
      "ty": 2,
      "x": 835,
      "y": 686
    },
    {
      "t": 74754,
      "e": 72321,
      "ty": 41,
      "x": 3645,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 74805,
      "e": 72372,
      "ty": 2,
      "x": 835,
      "y": 683
    },
    {
      "t": 74846,
      "e": 72413,
      "ty": 6,
      "x": 833,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 74905,
      "e": 72472,
      "ty": 2,
      "x": 828,
      "y": 678
    },
    {
      "t": 75005,
      "e": 72572,
      "ty": 41,
      "x": 7955,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 75504,
      "e": 73071,
      "ty": 2,
      "x": 827,
      "y": 678
    },
    {
      "t": 75505,
      "e": 73072,
      "ty": 41,
      "x": 2914,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 75514,
      "e": 73081,
      "ty": 7,
      "x": 826,
      "y": 682,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 75605,
      "e": 73172,
      "ty": 2,
      "x": 817,
      "y": 724
    },
    {
      "t": 75704,
      "e": 73271,
      "ty": 2,
      "x": 812,
      "y": 743
    },
    {
      "t": 75754,
      "e": 73321,
      "ty": 41,
      "x": 27619,
      "y": 40993,
      "ta": "html > body"
    },
    {
      "t": 75804,
      "e": 73371,
      "ty": 2,
      "x": 809,
      "y": 751
    },
    {
      "t": 76005,
      "e": 73572,
      "ty": 41,
      "x": 27584,
      "y": 41160,
      "ta": "html > body"
    },
    {
      "t": 76104,
      "e": 73671,
      "ty": 2,
      "x": 811,
      "y": 755
    },
    {
      "t": 76204,
      "e": 73771,
      "ty": 2,
      "x": 817,
      "y": 762
    },
    {
      "t": 76255,
      "e": 73822,
      "ty": 41,
      "x": 27894,
      "y": 41935,
      "ta": "html > body"
    },
    {
      "t": 76305,
      "e": 73872,
      "ty": 2,
      "x": 822,
      "y": 768
    },
    {
      "t": 76404,
      "e": 73971,
      "ty": 2,
      "x": 825,
      "y": 770
    },
    {
      "t": 76505,
      "e": 74072,
      "ty": 2,
      "x": 832,
      "y": 766
    },
    {
      "t": 76505,
      "e": 74072,
      "ty": 41,
      "x": 4413,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 76531,
      "e": 74098,
      "ty": 6,
      "x": 833,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 76604,
      "e": 74171,
      "ty": 2,
      "x": 833,
      "y": 764
    },
    {
      "t": 76705,
      "e": 74272,
      "ty": 2,
      "x": 835,
      "y": 756
    },
    {
      "t": 76755,
      "e": 74322,
      "ty": 41,
      "x": 43243,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 76805,
      "e": 74372,
      "ty": 2,
      "x": 835,
      "y": 755
    },
    {
      "t": 76904,
      "e": 74471,
      "ty": 2,
      "x": 835,
      "y": 757
    },
    {
      "t": 76966,
      "e": 74533,
      "ty": 7,
      "x": 838,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 77005,
      "e": 74572,
      "ty": 2,
      "x": 841,
      "y": 772
    },
    {
      "t": 77005,
      "e": 74572,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 77105,
      "e": 74672,
      "ty": 2,
      "x": 843,
      "y": 780
    },
    {
      "t": 77203,
      "e": 74770,
      "ty": 2,
      "x": 845,
      "y": 791
    },
    {
      "t": 77254,
      "e": 74821,
      "ty": 41,
      "x": 13199,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 77303,
      "e": 74870,
      "ty": 2,
      "x": 845,
      "y": 800
    },
    {
      "t": 77404,
      "e": 74971,
      "ty": 2,
      "x": 845,
      "y": 815
    },
    {
      "t": 77504,
      "e": 75071,
      "ty": 2,
      "x": 847,
      "y": 819
    },
    {
      "t": 77505,
      "e": 75072,
      "ty": 41,
      "x": 15097,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 77603,
      "e": 75170,
      "ty": 2,
      "x": 846,
      "y": 829
    },
    {
      "t": 77704,
      "e": 75271,
      "ty": 2,
      "x": 843,
      "y": 837
    },
    {
      "t": 77754,
      "e": 75321,
      "ty": 41,
      "x": 13793,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 77799,
      "e": 75366,
      "ty": 6,
      "x": 838,
      "y": 844,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77804,
      "e": 75371,
      "ty": 2,
      "x": 838,
      "y": 844
    },
    {
      "t": 77904,
      "e": 75471,
      "ty": 2,
      "x": 837,
      "y": 847
    },
    {
      "t": 78004,
      "e": 75571,
      "ty": 2,
      "x": 835,
      "y": 848
    },
    {
      "t": 78004,
      "e": 75571,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 78166,
      "e": 75733,
      "ty": 7,
      "x": 836,
      "y": 833,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 78199,
      "e": 75766,
      "ty": 6,
      "x": 837,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78204,
      "e": 75771,
      "ty": 2,
      "x": 837,
      "y": 818
    },
    {
      "t": 78233,
      "e": 75800,
      "ty": 7,
      "x": 839,
      "y": 804,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78254,
      "e": 75821,
      "ty": 41,
      "x": 4409,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 78304,
      "e": 75871,
      "ty": 2,
      "x": 841,
      "y": 788
    },
    {
      "t": 78404,
      "e": 75971,
      "ty": 2,
      "x": 846,
      "y": 771
    },
    {
      "t": 78504,
      "e": 76071,
      "ty": 2,
      "x": 850,
      "y": 744
    },
    {
      "t": 78504,
      "e": 76071,
      "ty": 41,
      "x": 6782,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 78604,
      "e": 76171,
      "ty": 2,
      "x": 853,
      "y": 725
    },
    {
      "t": 78704,
      "e": 76271,
      "ty": 2,
      "x": 855,
      "y": 716
    },
    {
      "t": 78754,
      "e": 76321,
      "ty": 41,
      "x": 7968,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 78803,
      "e": 76370,
      "ty": 2,
      "x": 855,
      "y": 713
    },
    {
      "t": 78903,
      "e": 76470,
      "ty": 2,
      "x": 856,
      "y": 711
    },
    {
      "t": 79003,
      "e": 76570,
      "ty": 41,
      "x": 8713,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79204,
      "e": 76771,
      "ty": 2,
      "x": 856,
      "y": 705
    },
    {
      "t": 79253,
      "e": 76820,
      "ty": 41,
      "x": 8713,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79503,
      "e": 77070,
      "ty": 2,
      "x": 842,
      "y": 708
    },
    {
      "t": 79503,
      "e": 77070,
      "ty": 41,
      "x": 5185,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79603,
      "e": 77170,
      "ty": 2,
      "x": 839,
      "y": 709
    },
    {
      "t": 79754,
      "e": 77321,
      "ty": 41,
      "x": 4429,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79803,
      "e": 77370,
      "ty": 2,
      "x": 838,
      "y": 709
    },
    {
      "t": 80004,
      "e": 77571,
      "ty": 41,
      "x": 4177,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 80006,
      "e": 77573,
      "ty": 6,
      "x": 838,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80104,
      "e": 77671,
      "ty": 2,
      "x": 834,
      "y": 700
    },
    {
      "t": 80254,
      "e": 77821,
      "ty": 41,
      "x": 38202,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80270,
      "e": 77837,
      "ty": 3,
      "x": 834,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80271,
      "e": 77838,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 80272,
      "e": 77839,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80340,
      "e": 77907,
      "ty": 4,
      "x": 38202,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80341,
      "e": 77908,
      "ty": 5,
      "x": 834,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80341,
      "e": 77908,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 80469,
      "e": 78036,
      "ty": 7,
      "x": 835,
      "y": 713,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80484,
      "e": 78051,
      "ty": 6,
      "x": 838,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80501,
      "e": 78068,
      "ty": 7,
      "x": 846,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80503,
      "e": 78070,
      "ty": 2,
      "x": 846,
      "y": 750
    },
    {
      "t": 80503,
      "e": 78070,
      "ty": 41,
      "x": 10255,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 80604,
      "e": 78171,
      "ty": 2,
      "x": 877,
      "y": 864
    },
    {
      "t": 80704,
      "e": 78271,
      "ty": 2,
      "x": 886,
      "y": 965
    },
    {
      "t": 80753,
      "e": 78320,
      "ty": 41,
      "x": 46575,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 80804,
      "e": 78371,
      "ty": 2,
      "x": 872,
      "y": 977
    },
    {
      "t": 80903,
      "e": 78470,
      "ty": 2,
      "x": 850,
      "y": 962
    },
    {
      "t": 81004,
      "e": 78571,
      "ty": 2,
      "x": 841,
      "y": 957
    },
    {
      "t": 81004,
      "e": 78571,
      "ty": 41,
      "x": 15837,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81104,
      "e": 78671,
      "ty": 2,
      "x": 841,
      "y": 956
    },
    {
      "t": 81254,
      "e": 78821,
      "ty": 41,
      "x": 15028,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81262,
      "e": 78829,
      "ty": 6,
      "x": 839,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81304,
      "e": 78871,
      "ty": 2,
      "x": 836,
      "y": 959
    },
    {
      "t": 81404,
      "e": 78971,
      "ty": 2,
      "x": 830,
      "y": 963
    },
    {
      "t": 81504,
      "e": 79071,
      "ty": 2,
      "x": 826,
      "y": 964
    },
    {
      "t": 81504,
      "e": 79071,
      "ty": 41,
      "x": 0,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81567,
      "e": 79134,
      "ty": 3,
      "x": 826,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81568,
      "e": 79135,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 81569,
      "e": 79136,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81660,
      "e": 79227,
      "ty": 4,
      "x": 0,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81661,
      "e": 79228,
      "ty": 5,
      "x": 826,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81661,
      "e": 79228,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 81742,
      "e": 79309,
      "ty": 7,
      "x": 825,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81754,
      "e": 79321,
      "ty": 41,
      "x": 5321,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81803,
      "e": 79370,
      "ty": 2,
      "x": 854,
      "y": 997
    },
    {
      "t": 81902,
      "e": 79370,
      "ty": 6,
      "x": 871,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81904,
      "e": 79372,
      "ty": 2,
      "x": 871,
      "y": 1007
    },
    {
      "t": 82004,
      "e": 79472,
      "ty": 2,
      "x": 877,
      "y": 1011
    },
    {
      "t": 82004,
      "e": 79472,
      "ty": 41,
      "x": 24521,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82104,
      "e": 79572,
      "ty": 2,
      "x": 893,
      "y": 1034
    },
    {
      "t": 82213,
      "e": 79681,
      "ty": 3,
      "x": 893,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82214,
      "e": 79682,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 82215,
      "e": 79683,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82254,
      "e": 79722,
      "ty": 41,
      "x": 32767,
      "y": 57591,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82284,
      "e": 79752,
      "ty": 4,
      "x": 32767,
      "y": 57591,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82285,
      "e": 79753,
      "ty": 5,
      "x": 893,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82287,
      "e": 79755,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82288,
      "e": 79756,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 82290,
      "e": 79758,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 82404,
      "e": 79872,
      "ty": 2,
      "x": 897,
      "y": 1036
    },
    {
      "t": 82503,
      "e": 79971,
      "ty": 2,
      "x": 1002,
      "y": 1036
    },
    {
      "t": 82505,
      "e": 79973,
      "ty": 41,
      "x": 34231,
      "y": 56948,
      "ta": "html > body"
    },
    {
      "t": 82604,
      "e": 80072,
      "ty": 2,
      "x": 1349,
      "y": 942
    },
    {
      "t": 82704,
      "e": 80172,
      "ty": 2,
      "x": 1725,
      "y": 739
    },
    {
      "t": 82754,
      "e": 80222,
      "ty": 41,
      "x": 59542,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 82804,
      "e": 80272,
      "ty": 2,
      "x": 1623,
      "y": 594
    },
    {
      "t": 82904,
      "e": 80372,
      "ty": 2,
      "x": 1517,
      "y": 544
    },
    {
      "t": 83004,
      "e": 80472,
      "ty": 2,
      "x": 1512,
      "y": 543
    },
    {
      "t": 83005,
      "e": 80473,
      "ty": 41,
      "x": 51794,
      "y": 29637,
      "ta": "html > body"
    },
    {
      "t": 83304,
      "e": 80772,
      "ty": 2,
      "x": 1511,
      "y": 542
    },
    {
      "t": 83404,
      "e": 80872,
      "ty": 2,
      "x": 1511,
      "y": 541
    },
    {
      "t": 83504,
      "e": 80972,
      "ty": 41,
      "x": 51759,
      "y": 29526,
      "ta": "html > body"
    },
    {
      "t": 83638,
      "e": 81106,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 85104,
      "e": 82572,
      "ty": 2,
      "x": 1509,
      "y": 523
    },
    {
      "t": 85204,
      "e": 82672,
      "ty": 2,
      "x": 1509,
      "y": 522
    },
    {
      "t": 85254,
      "e": 82722,
      "ty": 41,
      "x": 59801,
      "y": 15414,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85604,
      "e": 83072,
      "ty": 2,
      "x": 1508,
      "y": 521
    },
    {
      "t": 85704,
      "e": 83172,
      "ty": 2,
      "x": 1504,
      "y": 524
    },
    {
      "t": 85755,
      "e": 83223,
      "ty": 41,
      "x": 59555,
      "y": 16194,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85904,
      "e": 83372,
      "ty": 2,
      "x": 1495,
      "y": 531
    },
    {
      "t": 86004,
      "e": 83472,
      "ty": 2,
      "x": 1485,
      "y": 549
    },
    {
      "t": 86005,
      "e": 83473,
      "ty": 41,
      "x": 58620,
      "y": 25947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86104,
      "e": 83572,
      "ty": 2,
      "x": 1373,
      "y": 627
    },
    {
      "t": 86204,
      "e": 83672,
      "ty": 2,
      "x": 1065,
      "y": 1041
    },
    {
      "t": 86254,
      "e": 83722,
      "ty": 41,
      "x": 54534,
      "y": 35628,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 86304,
      "e": 83772,
      "ty": 2,
      "x": 1000,
      "y": 1152
    },
    {
      "t": 86504,
      "e": 83972,
      "ty": 41,
      "x": 51725,
      "y": 43938,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 86704,
      "e": 84172,
      "ty": 2,
      "x": 1000,
      "y": 1150
    },
    {
      "t": 86754,
      "e": 84222,
      "ty": 41,
      "x": 52662,
      "y": 40614,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 86804,
      "e": 84272,
      "ty": 2,
      "x": 1005,
      "y": 1136
    },
    {
      "t": 86904,
      "e": 84372,
      "ty": 2,
      "x": 1007,
      "y": 1114
    },
    {
      "t": 86907,
      "e": 84375,
      "ty": 6,
      "x": 1008,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 87004,
      "e": 84472,
      "ty": 2,
      "x": 1013,
      "y": 1082
    },
    {
      "t": 87004,
      "e": 84472,
      "ty": 41,
      "x": 56523,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 87104,
      "e": 84572,
      "ty": 2,
      "x": 1008,
      "y": 1084
    },
    {
      "t": 87204,
      "e": 84672,
      "ty": 2,
      "x": 996,
      "y": 1090
    },
    {
      "t": 87254,
      "e": 84722,
      "ty": 41,
      "x": 47239,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 88406,
      "e": 85874,
      "ty": 3,
      "x": 996,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 88407,
      "e": 85875,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 88476,
      "e": 85944,
      "ty": 4,
      "x": 47239,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 88477,
      "e": 85945,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 88478,
      "e": 85946,
      "ty": 5,
      "x": 996,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 88478,
      "e": 85946,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88604,
      "e": 86072,
      "ty": 2,
      "x": 994,
      "y": 1090
    },
    {
      "t": 88704,
      "e": 86172,
      "ty": 2,
      "x": 1874,
      "y": 829
    },
    {
      "t": 88804,
      "e": 86272,
      "ty": 2,
      "x": 1919,
      "y": 733
    },
    {
      "t": 88904,
      "e": 86372,
      "ty": 2,
      "x": 1879,
      "y": 702
    },
    {
      "t": 89004,
      "e": 86472,
      "ty": 2,
      "x": 1710,
      "y": 645
    },
    {
      "t": 89004,
      "e": 86472,
      "ty": 41,
      "x": 58613,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 89104,
      "e": 86572,
      "ty": 2,
      "x": 1586,
      "y": 605
    },
    {
      "t": 89203,
      "e": 86671,
      "ty": 2,
      "x": 1577,
      "y": 600
    },
    {
      "t": 89254,
      "e": 86722,
      "ty": 41,
      "x": 54032,
      "y": 32795,
      "ta": "html > body"
    },
    {
      "t": 89512,
      "e": 86980,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 90089,
      "e": 87557,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90475,
      "e": 87943,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 611765, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 611769, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9015, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 622123, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9588, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 632715, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14777, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 648583, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6872, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 656459, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 21145, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 678972, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-11 AM-C -F -10 AM-C -C -C -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1480,y:747,t:1528139548560};\\\", \\\"{x:1502,y:741,t:1528139548567};\\\", \\\"{x:1529,y:735,t:1528139548580};\\\", \\\"{x:1583,y:733,t:1528139548597};\\\", \\\"{x:1659,y:731,t:1528139548614};\\\", \\\"{x:1733,y:726,t:1528139548631};\\\", \\\"{x:1778,y:726,t:1528139548647};\\\", \\\"{x:1812,y:726,t:1528139548664};\\\", \\\"{x:1829,y:725,t:1528139548681};\\\", \\\"{x:1838,y:724,t:1528139548697};\\\", \\\"{x:1846,y:722,t:1528139548714};\\\", \\\"{x:1851,y:722,t:1528139548731};\\\", \\\"{x:1853,y:722,t:1528139548747};\\\", \\\"{x:1854,y:722,t:1528139548764};\\\", \\\"{x:1855,y:721,t:1528139548888};\\\", \\\"{x:1857,y:720,t:1528139548910};\\\", \\\"{x:1859,y:718,t:1528139548918};\\\", \\\"{x:1860,y:718,t:1528139548942};\\\", \\\"{x:1865,y:714,t:1528139549576};\\\", \\\"{x:1875,y:710,t:1528139549584};\\\", \\\"{x:1895,y:699,t:1528139549599};\\\", \\\"{x:1915,y:691,t:1528139549616};\\\", \\\"{x:1919,y:685,t:1528139549631};\\\", \\\"{x:1919,y:679,t:1528139549648};\\\", \\\"{x:1919,y:675,t:1528139549664};\\\", \\\"{x:1919,y:671,t:1528139549681};\\\", \\\"{x:1919,y:669,t:1528139549698};\\\", \\\"{x:1918,y:668,t:1528139550590};\\\", \\\"{x:1912,y:670,t:1528139550598};\\\", \\\"{x:1867,y:709,t:1528139550615};\\\", \\\"{x:1824,y:758,t:1528139550632};\\\", \\\"{x:1782,y:812,t:1528139550649};\\\", \\\"{x:1749,y:862,t:1528139550666};\\\", \\\"{x:1715,y:912,t:1528139550682};\\\", \\\"{x:1688,y:952,t:1528139550699};\\\", \\\"{x:1670,y:983,t:1528139550716};\\\", \\\"{x:1655,y:1003,t:1528139550733};\\\", \\\"{x:1636,y:1020,t:1528139550749};\\\", \\\"{x:1615,y:1042,t:1528139550766};\\\", \\\"{x:1601,y:1056,t:1528139550782};\\\", \\\"{x:1587,y:1070,t:1528139550799};\\\", \\\"{x:1569,y:1078,t:1528139550816};\\\", \\\"{x:1550,y:1082,t:1528139550832};\\\", \\\"{x:1529,y:1084,t:1528139550849};\\\", \\\"{x:1518,y:1084,t:1528139550866};\\\", \\\"{x:1509,y:1084,t:1528139550882};\\\", \\\"{x:1500,y:1080,t:1528139550899};\\\", \\\"{x:1485,y:1071,t:1528139550916};\\\", \\\"{x:1468,y:1060,t:1528139550932};\\\", \\\"{x:1452,y:1053,t:1528139550949};\\\", \\\"{x:1425,y:1043,t:1528139550966};\\\", \\\"{x:1400,y:1036,t:1528139550982};\\\", \\\"{x:1380,y:1030,t:1528139550999};\\\", \\\"{x:1360,y:1025,t:1528139551016};\\\", \\\"{x:1338,y:1020,t:1528139551033};\\\", \\\"{x:1316,y:1013,t:1528139551049};\\\", \\\"{x:1300,y:1011,t:1528139551066};\\\", \\\"{x:1289,y:1009,t:1528139551083};\\\", \\\"{x:1277,y:1008,t:1528139551100};\\\", \\\"{x:1265,y:1008,t:1528139551116};\\\", \\\"{x:1253,y:1006,t:1528139551134};\\\", \\\"{x:1248,y:1006,t:1528139551149};\\\", \\\"{x:1245,y:1005,t:1528139551166};\\\", \\\"{x:1245,y:1003,t:1528139551199};\\\", \\\"{x:1247,y:1001,t:1528139551216};\\\", \\\"{x:1248,y:999,t:1528139551233};\\\", \\\"{x:1253,y:996,t:1528139551250};\\\", \\\"{x:1257,y:993,t:1528139551267};\\\", \\\"{x:1264,y:990,t:1528139551284};\\\", \\\"{x:1272,y:986,t:1528139551299};\\\", \\\"{x:1278,y:984,t:1528139551317};\\\", \\\"{x:1284,y:981,t:1528139551333};\\\", \\\"{x:1288,y:978,t:1528139551349};\\\", \\\"{x:1292,y:976,t:1528139551366};\\\", \\\"{x:1293,y:975,t:1528139551383};\\\", \\\"{x:1295,y:973,t:1528139551399};\\\", \\\"{x:1296,y:973,t:1528139551416};\\\", \\\"{x:1296,y:972,t:1528139551433};\\\", \\\"{x:1295,y:972,t:1528139551800};\\\", \\\"{x:1295,y:971,t:1528139551817};\\\", \\\"{x:1294,y:970,t:1528139551834};\\\", \\\"{x:1294,y:969,t:1528139551864};\\\", \\\"{x:1293,y:969,t:1528139551984};\\\", \\\"{x:1291,y:969,t:1528139552001};\\\", \\\"{x:1290,y:969,t:1528139552018};\\\", \\\"{x:1289,y:969,t:1528139552034};\\\", \\\"{x:1288,y:969,t:1528139552104};\\\", \\\"{x:1287,y:966,t:1528139552120};\\\", \\\"{x:1286,y:964,t:1528139552134};\\\", \\\"{x:1285,y:956,t:1528139552151};\\\", \\\"{x:1284,y:947,t:1528139552168};\\\", \\\"{x:1284,y:946,t:1528139552184};\\\", \\\"{x:1283,y:945,t:1528139552512};\\\", \\\"{x:1282,y:942,t:1528139552615};\\\", \\\"{x:1281,y:938,t:1528139552624};\\\", \\\"{x:1280,y:933,t:1528139552635};\\\", \\\"{x:1277,y:926,t:1528139552651};\\\", \\\"{x:1276,y:918,t:1528139552668};\\\", \\\"{x:1272,y:911,t:1528139552685};\\\", \\\"{x:1269,y:903,t:1528139552701};\\\", \\\"{x:1264,y:894,t:1528139552718};\\\", \\\"{x:1258,y:886,t:1528139552736};\\\", \\\"{x:1254,y:878,t:1528139552752};\\\", \\\"{x:1251,y:873,t:1528139552768};\\\", \\\"{x:1247,y:864,t:1528139552785};\\\", \\\"{x:1241,y:855,t:1528139552802};\\\", \\\"{x:1235,y:845,t:1528139552818};\\\", \\\"{x:1232,y:842,t:1528139552835};\\\", \\\"{x:1229,y:838,t:1528139552852};\\\", \\\"{x:1227,y:837,t:1528139552868};\\\", \\\"{x:1226,y:836,t:1528139552885};\\\", \\\"{x:1225,y:836,t:1528139552902};\\\", \\\"{x:1224,y:834,t:1528139552918};\\\", \\\"{x:1220,y:831,t:1528139552944};\\\", \\\"{x:1217,y:829,t:1528139552967};\\\", \\\"{x:1218,y:829,t:1528139556054};\\\", \\\"{x:1232,y:829,t:1528139556071};\\\", \\\"{x:1252,y:830,t:1528139556087};\\\", \\\"{x:1270,y:832,t:1528139556103};\\\", \\\"{x:1286,y:834,t:1528139556120};\\\", \\\"{x:1299,y:834,t:1528139556136};\\\", \\\"{x:1312,y:834,t:1528139556153};\\\", \\\"{x:1328,y:830,t:1528139556170};\\\", \\\"{x:1340,y:825,t:1528139556188};\\\", \\\"{x:1350,y:818,t:1528139556203};\\\", \\\"{x:1362,y:812,t:1528139556220};\\\", \\\"{x:1375,y:806,t:1528139556237};\\\", \\\"{x:1389,y:799,t:1528139556254};\\\", \\\"{x:1406,y:785,t:1528139556270};\\\", \\\"{x:1411,y:779,t:1528139556288};\\\", \\\"{x:1415,y:774,t:1528139556304};\\\", \\\"{x:1418,y:768,t:1528139556320};\\\", \\\"{x:1423,y:762,t:1528139556337};\\\", \\\"{x:1423,y:759,t:1528139556353};\\\", \\\"{x:1423,y:757,t:1528139556370};\\\", \\\"{x:1422,y:757,t:1528139556407};\\\", \\\"{x:1420,y:758,t:1528139556423};\\\", \\\"{x:1417,y:759,t:1528139556438};\\\", \\\"{x:1412,y:761,t:1528139556454};\\\", \\\"{x:1407,y:763,t:1528139556471};\\\", \\\"{x:1404,y:764,t:1528139556488};\\\", \\\"{x:1403,y:765,t:1528139556511};\\\", \\\"{x:1401,y:766,t:1528139556527};\\\", \\\"{x:1400,y:767,t:1528139556538};\\\", \\\"{x:1397,y:768,t:1528139556553};\\\", \\\"{x:1394,y:769,t:1528139556571};\\\", \\\"{x:1394,y:770,t:1528139556587};\\\", \\\"{x:1392,y:770,t:1528139556605};\\\", \\\"{x:1390,y:770,t:1528139556621};\\\", \\\"{x:1388,y:770,t:1528139556655};\\\", \\\"{x:1386,y:769,t:1528139556671};\\\", \\\"{x:1382,y:767,t:1528139556691};\\\", \\\"{x:1380,y:767,t:1528139556704};\\\", \\\"{x:1380,y:766,t:1528139556782};\\\", \\\"{x:1379,y:765,t:1528139556791};\\\", \\\"{x:1378,y:764,t:1528139556804};\\\", \\\"{x:1376,y:763,t:1528139556820};\\\", \\\"{x:1376,y:762,t:1528139556838};\\\", \\\"{x:1369,y:761,t:1528139557744};\\\", \\\"{x:1354,y:761,t:1528139557755};\\\", \\\"{x:1307,y:761,t:1528139557772};\\\", \\\"{x:1238,y:761,t:1528139557789};\\\", \\\"{x:1151,y:757,t:1528139557806};\\\", \\\"{x:1069,y:752,t:1528139557821};\\\", \\\"{x:973,y:738,t:1528139557838};\\\", \\\"{x:920,y:730,t:1528139557855};\\\", \\\"{x:874,y:722,t:1528139557872};\\\", \\\"{x:851,y:720,t:1528139557888};\\\", \\\"{x:838,y:719,t:1528139557906};\\\", \\\"{x:826,y:718,t:1528139557921};\\\", \\\"{x:809,y:717,t:1528139557939};\\\", \\\"{x:790,y:715,t:1528139557955};\\\", \\\"{x:761,y:712,t:1528139557972};\\\", \\\"{x:729,y:707,t:1528139557989};\\\", \\\"{x:706,y:703,t:1528139558006};\\\", \\\"{x:687,y:700,t:1528139558021};\\\", \\\"{x:647,y:694,t:1528139558039};\\\", \\\"{x:601,y:681,t:1528139558057};\\\", \\\"{x:544,y:663,t:1528139558072};\\\", \\\"{x:496,y:647,t:1528139558088};\\\", \\\"{x:457,y:636,t:1528139558105};\\\", \\\"{x:406,y:625,t:1528139558122};\\\", \\\"{x:345,y:619,t:1528139558139};\\\", \\\"{x:263,y:613,t:1528139558156};\\\", \\\"{x:179,y:611,t:1528139558171};\\\", \\\"{x:109,y:611,t:1528139558189};\\\", \\\"{x:78,y:611,t:1528139558206};\\\", \\\"{x:45,y:611,t:1528139558222};\\\", \\\"{x:36,y:612,t:1528139558238};\\\", \\\"{x:33,y:614,t:1528139558256};\\\", \\\"{x:33,y:615,t:1528139558273};\\\", \\\"{x:33,y:618,t:1528139558289};\\\", \\\"{x:37,y:618,t:1528139558384};\\\", \\\"{x:45,y:613,t:1528139558391};\\\", \\\"{x:51,y:608,t:1528139558407};\\\", \\\"{x:73,y:598,t:1528139558422};\\\", \\\"{x:95,y:590,t:1528139558438};\\\", \\\"{x:118,y:581,t:1528139558456};\\\", \\\"{x:141,y:572,t:1528139558473};\\\", \\\"{x:154,y:563,t:1528139558489};\\\", \\\"{x:160,y:558,t:1528139558505};\\\", \\\"{x:165,y:553,t:1528139558522};\\\", \\\"{x:167,y:551,t:1528139558538};\\\", \\\"{x:168,y:550,t:1528139558556};\\\", \\\"{x:168,y:549,t:1528139558710};\\\", \\\"{x:172,y:548,t:1528139558990};\\\", \\\"{x:183,y:548,t:1528139559005};\\\", \\\"{x:239,y:551,t:1528139559023};\\\", \\\"{x:298,y:559,t:1528139559041};\\\", \\\"{x:362,y:568,t:1528139559056};\\\", \\\"{x:420,y:576,t:1528139559073};\\\", \\\"{x:490,y:587,t:1528139559090};\\\", \\\"{x:528,y:592,t:1528139559108};\\\", \\\"{x:556,y:597,t:1528139559122};\\\", \\\"{x:576,y:599,t:1528139559139};\\\", \\\"{x:601,y:604,t:1528139559157};\\\", \\\"{x:626,y:605,t:1528139559173};\\\", \\\"{x:655,y:606,t:1528139559190};\\\", \\\"{x:678,y:606,t:1528139559205};\\\", \\\"{x:711,y:606,t:1528139559222};\\\", \\\"{x:727,y:606,t:1528139559241};\\\", \\\"{x:736,y:606,t:1528139559255};\\\", \\\"{x:739,y:606,t:1528139559272};\\\", \\\"{x:740,y:606,t:1528139559350};\\\", \\\"{x:741,y:606,t:1528139559366};\\\", \\\"{x:743,y:604,t:1528139559374};\\\", \\\"{x:747,y:602,t:1528139559389};\\\", \\\"{x:756,y:595,t:1528139559406};\\\", \\\"{x:762,y:592,t:1528139559422};\\\", \\\"{x:771,y:588,t:1528139559439};\\\", \\\"{x:783,y:586,t:1528139559456};\\\", \\\"{x:798,y:583,t:1528139559472};\\\", \\\"{x:815,y:582,t:1528139559489};\\\", \\\"{x:829,y:580,t:1528139559506};\\\", \\\"{x:842,y:577,t:1528139559524};\\\", \\\"{x:851,y:577,t:1528139559539};\\\", \\\"{x:856,y:575,t:1528139559557};\\\", \\\"{x:859,y:575,t:1528139559573};\\\", \\\"{x:853,y:576,t:1528139559623};\\\", \\\"{x:845,y:579,t:1528139559640};\\\", \\\"{x:834,y:586,t:1528139559657};\\\", \\\"{x:815,y:598,t:1528139559673};\\\", \\\"{x:789,y:612,t:1528139559689};\\\", \\\"{x:756,y:626,t:1528139559707};\\\", \\\"{x:733,y:638,t:1528139559723};\\\", \\\"{x:710,y:649,t:1528139559741};\\\", \\\"{x:693,y:657,t:1528139559757};\\\", \\\"{x:681,y:660,t:1528139559774};\\\", \\\"{x:672,y:662,t:1528139559789};\\\", \\\"{x:659,y:663,t:1528139559806};\\\", \\\"{x:643,y:663,t:1528139559823};\\\", \\\"{x:617,y:661,t:1528139559839};\\\", \\\"{x:589,y:655,t:1528139559857};\\\", \\\"{x:564,y:648,t:1528139559874};\\\", \\\"{x:535,y:643,t:1528139559889};\\\", \\\"{x:497,y:635,t:1528139559908};\\\", \\\"{x:472,y:631,t:1528139559923};\\\", \\\"{x:465,y:630,t:1528139559940};\\\", \\\"{x:463,y:630,t:1528139559956};\\\", \\\"{x:462,y:630,t:1528139559974};\\\", \\\"{x:459,y:630,t:1528139559990};\\\", \\\"{x:454,y:632,t:1528139560006};\\\", \\\"{x:447,y:632,t:1528139560023};\\\", \\\"{x:439,y:632,t:1528139560040};\\\", \\\"{x:430,y:635,t:1528139560058};\\\", \\\"{x:420,y:636,t:1528139560074};\\\", \\\"{x:404,y:640,t:1528139560091};\\\", \\\"{x:385,y:641,t:1528139560108};\\\", \\\"{x:367,y:643,t:1528139560124};\\\", \\\"{x:357,y:645,t:1528139560140};\\\", \\\"{x:354,y:645,t:1528139560157};\\\", \\\"{x:353,y:645,t:1528139560207};\\\", \\\"{x:353,y:641,t:1528139560215};\\\", \\\"{x:353,y:637,t:1528139560224};\\\", \\\"{x:356,y:624,t:1528139560241};\\\", \\\"{x:361,y:615,t:1528139560259};\\\", \\\"{x:365,y:610,t:1528139560276};\\\", \\\"{x:370,y:604,t:1528139560290};\\\", \\\"{x:376,y:599,t:1528139560307};\\\", \\\"{x:380,y:596,t:1528139560324};\\\", \\\"{x:382,y:594,t:1528139560340};\\\", \\\"{x:383,y:593,t:1528139560742};\\\", \\\"{x:387,y:593,t:1528139560757};\\\", \\\"{x:411,y:608,t:1528139560774};\\\", \\\"{x:439,y:625,t:1528139560790};\\\", \\\"{x:472,y:646,t:1528139560807};\\\", \\\"{x:538,y:674,t:1528139560825};\\\", \\\"{x:629,y:712,t:1528139560841};\\\", \\\"{x:735,y:753,t:1528139560858};\\\", \\\"{x:858,y:793,t:1528139560875};\\\", \\\"{x:963,y:838,t:1528139560890};\\\", \\\"{x:1062,y:883,t:1528139560907};\\\", \\\"{x:1136,y:915,t:1528139560924};\\\", \\\"{x:1197,y:952,t:1528139560940};\\\", \\\"{x:1248,y:989,t:1528139560958};\\\", \\\"{x:1285,y:1019,t:1528139560974};\\\", \\\"{x:1306,y:1031,t:1528139560990};\\\", \\\"{x:1326,y:1042,t:1528139561008};\\\", \\\"{x:1342,y:1050,t:1528139561025};\\\", \\\"{x:1350,y:1051,t:1528139561040};\\\", \\\"{x:1352,y:1051,t:1528139561104};\\\", \\\"{x:1352,y:1050,t:1528139561111};\\\", \\\"{x:1352,y:1048,t:1528139561126};\\\", \\\"{x:1352,y:1038,t:1528139561142};\\\", \\\"{x:1348,y:1031,t:1528139561158};\\\", \\\"{x:1343,y:1026,t:1528139561175};\\\", \\\"{x:1334,y:1020,t:1528139561191};\\\", \\\"{x:1319,y:1012,t:1528139561208};\\\", \\\"{x:1290,y:1000,t:1528139561225};\\\", \\\"{x:1266,y:992,t:1528139561241};\\\", \\\"{x:1253,y:989,t:1528139561258};\\\", \\\"{x:1241,y:985,t:1528139561275};\\\", \\\"{x:1232,y:982,t:1528139561291};\\\", \\\"{x:1227,y:981,t:1528139561308};\\\", \\\"{x:1221,y:980,t:1528139561325};\\\", \\\"{x:1213,y:977,t:1528139561342};\\\", \\\"{x:1206,y:974,t:1528139561358};\\\", \\\"{x:1203,y:973,t:1528139561375};\\\", \\\"{x:1202,y:972,t:1528139561392};\\\", \\\"{x:1202,y:970,t:1528139561448};\\\", \\\"{x:1203,y:968,t:1528139561459};\\\", \\\"{x:1204,y:967,t:1528139561475};\\\", \\\"{x:1205,y:966,t:1528139561492};\\\", \\\"{x:1207,y:964,t:1528139561508};\\\", \\\"{x:1210,y:964,t:1528139561525};\\\", \\\"{x:1212,y:962,t:1528139561542};\\\", \\\"{x:1215,y:962,t:1528139561559};\\\", \\\"{x:1232,y:962,t:1528139561575};\\\", \\\"{x:1243,y:962,t:1528139561593};\\\", \\\"{x:1254,y:962,t:1528139561609};\\\", \\\"{x:1264,y:962,t:1528139561625};\\\", \\\"{x:1271,y:962,t:1528139561642};\\\", \\\"{x:1276,y:962,t:1528139561659};\\\", \\\"{x:1278,y:962,t:1528139561675};\\\", \\\"{x:1279,y:962,t:1528139561692};\\\", \\\"{x:1280,y:962,t:1528139561719};\\\", \\\"{x:1281,y:961,t:1528139561727};\\\", \\\"{x:1284,y:961,t:1528139561743};\\\", \\\"{x:1290,y:961,t:1528139561759};\\\", \\\"{x:1294,y:961,t:1528139561775};\\\", \\\"{x:1292,y:961,t:1528139561894};\\\", \\\"{x:1290,y:962,t:1528139561908};\\\", \\\"{x:1287,y:963,t:1528139561925};\\\", \\\"{x:1286,y:963,t:1528139561942};\\\", \\\"{x:1284,y:963,t:1528139561958};\\\", \\\"{x:1283,y:963,t:1528139561975};\\\", \\\"{x:1282,y:963,t:1528139562006};\\\", \\\"{x:1280,y:963,t:1528139562014};\\\", \\\"{x:1280,y:961,t:1528139562025};\\\", \\\"{x:1277,y:952,t:1528139562042};\\\", \\\"{x:1268,y:938,t:1528139562058};\\\", \\\"{x:1257,y:921,t:1528139562075};\\\", \\\"{x:1246,y:896,t:1528139562091};\\\", \\\"{x:1238,y:882,t:1528139562108};\\\", \\\"{x:1232,y:873,t:1528139562125};\\\", \\\"{x:1228,y:868,t:1528139562142};\\\", \\\"{x:1224,y:865,t:1528139562158};\\\", \\\"{x:1224,y:864,t:1528139562175};\\\", \\\"{x:1223,y:863,t:1528139562192};\\\", \\\"{x:1222,y:862,t:1528139562208};\\\", \\\"{x:1221,y:861,t:1528139562225};\\\", \\\"{x:1221,y:858,t:1528139562242};\\\", \\\"{x:1221,y:854,t:1528139562258};\\\", \\\"{x:1219,y:846,t:1528139562275};\\\", \\\"{x:1219,y:843,t:1528139562293};\\\", \\\"{x:1217,y:838,t:1528139562308};\\\", \\\"{x:1215,y:833,t:1528139562331};\\\", \\\"{x:1210,y:824,t:1528139562343};\\\", \\\"{x:1205,y:813,t:1528139562375};\\\", \\\"{x:1205,y:814,t:1528139562640};\\\", \\\"{x:1205,y:817,t:1528139562658};\\\", \\\"{x:1206,y:821,t:1528139562673};\\\", \\\"{x:1206,y:823,t:1528139562690};\\\", \\\"{x:1206,y:825,t:1528139562706};\\\", \\\"{x:1207,y:827,t:1528139562722};\\\", \\\"{x:1207,y:829,t:1528139562740};\\\", \\\"{x:1207,y:830,t:1528139562758};\\\", \\\"{x:1207,y:832,t:1528139562798};\\\", \\\"{x:1209,y:835,t:1528139562814};\\\", \\\"{x:1209,y:836,t:1528139562830};\\\", \\\"{x:1210,y:837,t:1528139563031};\\\", \\\"{x:1211,y:837,t:1528139563040};\\\", \\\"{x:1212,y:837,t:1528139563062};\\\", \\\"{x:1213,y:837,t:1528139563086};\\\", \\\"{x:1215,y:837,t:1528139563094};\\\", \\\"{x:1216,y:836,t:1528139563118};\\\", \\\"{x:1217,y:836,t:1528139563198};\\\", \\\"{x:1218,y:836,t:1528139563279};\\\", \\\"{x:1218,y:835,t:1528139563290};\\\", \\\"{x:1219,y:835,t:1528139563307};\\\", \\\"{x:1220,y:835,t:1528139563324};\\\", \\\"{x:1221,y:833,t:1528139563632};\\\", \\\"{x:1221,y:832,t:1528139563655};\\\", \\\"{x:1220,y:830,t:1528139563677};\\\", \\\"{x:1219,y:829,t:1528139563688};\\\", \\\"{x:1218,y:829,t:1528139563710};\\\", \\\"{x:1217,y:829,t:1528139563790};\\\", \\\"{x:1215,y:829,t:1528139563798};\\\", \\\"{x:1214,y:829,t:1528139563809};\\\", \\\"{x:1211,y:829,t:1528139563826};\\\", \\\"{x:1213,y:826,t:1528139565575};\\\", \\\"{x:1250,y:817,t:1528139565595};\\\", \\\"{x:1298,y:810,t:1528139565609};\\\", \\\"{x:1333,y:801,t:1528139565625};\\\", \\\"{x:1359,y:792,t:1528139565645};\\\", \\\"{x:1376,y:784,t:1528139565662};\\\", \\\"{x:1385,y:778,t:1528139565678};\\\", \\\"{x:1391,y:774,t:1528139565694};\\\", \\\"{x:1392,y:774,t:1528139565725};\\\", \\\"{x:1393,y:773,t:1528139565733};\\\", \\\"{x:1395,y:772,t:1528139565758};\\\", \\\"{x:1396,y:772,t:1528139565790};\\\", \\\"{x:1396,y:771,t:1528139565806};\\\", \\\"{x:1396,y:769,t:1528139565830};\\\", \\\"{x:1396,y:768,t:1528139565862};\\\", \\\"{x:1396,y:766,t:1528139565878};\\\", \\\"{x:1394,y:764,t:1528139565895};\\\", \\\"{x:1391,y:761,t:1528139565912};\\\", \\\"{x:1389,y:761,t:1528139565929};\\\", \\\"{x:1388,y:760,t:1528139565944};\\\", \\\"{x:1387,y:760,t:1528139566007};\\\", \\\"{x:1386,y:760,t:1528139566027};\\\", \\\"{x:1386,y:759,t:1528139566086};\\\", \\\"{x:1385,y:759,t:1528139566103};\\\", \\\"{x:1384,y:759,t:1528139566111};\\\", \\\"{x:1383,y:759,t:1528139566129};\\\", \\\"{x:1382,y:759,t:1528139566182};\\\", \\\"{x:1377,y:760,t:1528139567287};\\\", \\\"{x:1364,y:760,t:1528139567297};\\\", \\\"{x:1325,y:760,t:1528139567312};\\\", \\\"{x:1239,y:760,t:1528139567330};\\\", \\\"{x:1107,y:751,t:1528139567346};\\\", \\\"{x:968,y:729,t:1528139567363};\\\", \\\"{x:854,y:711,t:1528139567379};\\\", \\\"{x:749,y:678,t:1528139567396};\\\", \\\"{x:672,y:660,t:1528139567413};\\\", \\\"{x:643,y:655,t:1528139567430};\\\", \\\"{x:640,y:655,t:1528139567446};\\\", \\\"{x:637,y:657,t:1528139567462};\\\", \\\"{x:633,y:660,t:1528139567480};\\\", \\\"{x:628,y:664,t:1528139567496};\\\", \\\"{x:617,y:674,t:1528139567512};\\\", \\\"{x:597,y:688,t:1528139567530};\\\", \\\"{x:579,y:698,t:1528139567547};\\\", \\\"{x:565,y:706,t:1528139567563};\\\", \\\"{x:559,y:710,t:1528139567580};\\\", \\\"{x:552,y:716,t:1528139567596};\\\", \\\"{x:545,y:723,t:1528139567612};\\\", \\\"{x:540,y:734,t:1528139567630};\\\", \\\"{x:537,y:738,t:1528139567646};\\\", \\\"{x:534,y:741,t:1528139567662};\\\", \\\"{x:531,y:742,t:1528139567679};\\\", \\\"{x:527,y:745,t:1528139567696};\\\", \\\"{x:524,y:749,t:1528139567712};\\\", \\\"{x:522,y:753,t:1528139567730};\\\", \\\"{x:521,y:756,t:1528139567747};\\\", \\\"{x:520,y:761,t:1528139567763};\\\", \\\"{x:519,y:762,t:1528139567780};\\\", \\\"{x:518,y:763,t:1528139567797};\\\", \\\"{x:519,y:763,t:1528139568326};\\\", \\\"{x:524,y:761,t:1528139568334};\\\", \\\"{x:529,y:760,t:1528139568347};\\\", \\\"{x:534,y:756,t:1528139568364};\\\", \\\"{x:538,y:754,t:1528139568380};\\\", \\\"{x:540,y:753,t:1528139568397};\\\", \\\"{x:544,y:750,t:1528139568414};\\\", \\\"{x:549,y:749,t:1528139568429};\\\", \\\"{x:554,y:746,t:1528139568446};\\\", \\\"{x:563,y:742,t:1528139568463};\\\", \\\"{x:584,y:737,t:1528139568481};\\\", \\\"{x:618,y:734,t:1528139568497};\\\", \\\"{x:665,y:729,t:1528139568514};\\\", \\\"{x:735,y:729,t:1528139568531};\\\", \\\"{x:829,y:729,t:1528139568546};\\\", \\\"{x:954,y:730,t:1528139568564};\\\", \\\"{x:1117,y:753,t:1528139568580};\\\", \\\"{x:1283,y:779,t:1528139568597};\\\", \\\"{x:1526,y:823,t:1528139568614};\\\", \\\"{x:1669,y:858,t:1528139568630};\\\", \\\"{x:1807,y:895,t:1528139568647};\\\", \\\"{x:1919,y:920,t:1528139568664};\\\", \\\"{x:1919,y:938,t:1528139568681};\\\", \\\"{x:1919,y:943,t:1528139568696};\\\", \\\"{x:1919,y:945,t:1528139568878};\\\", \\\"{x:1919,y:946,t:1528139568886};\\\", \\\"{x:1918,y:947,t:1528139568897};\\\", \\\"{x:1912,y:949,t:1528139568914};\\\", \\\"{x:1902,y:950,t:1528139568931};\\\", \\\"{x:1892,y:950,t:1528139568948};\\\", \\\"{x:1880,y:950,t:1528139568964};\\\", \\\"{x:1870,y:950,t:1528139568981};\\\", \\\"{x:1845,y:950,t:1528139568998};\\\", \\\"{x:1812,y:950,t:1528139569013};\\\", \\\"{x:1737,y:939,t:1528139569031};\\\", \\\"{x:1633,y:919,t:1528139569048};\\\", \\\"{x:1519,y:901,t:1528139569064};\\\", \\\"{x:1435,y:888,t:1528139569081};\\\", \\\"{x:1352,y:886,t:1528139569098};\\\", \\\"{x:1288,y:886,t:1528139569114};\\\", \\\"{x:1258,y:886,t:1528139569130};\\\" ] }, { \\\"rt\\\": 25315, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 705496, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1254,y:888,t:1528139570238};\\\", \\\"{x:1253,y:887,t:1528139570575};\\\", \\\"{x:1252,y:887,t:1528139570583};\\\", \\\"{x:1248,y:887,t:1528139570599};\\\", \\\"{x:1247,y:887,t:1528139570615};\\\", \\\"{x:1248,y:887,t:1528139572823};\\\", \\\"{x:1249,y:887,t:1528139572839};\\\", \\\"{x:1252,y:887,t:1528139572851};\\\", \\\"{x:1253,y:887,t:1528139572867};\\\", \\\"{x:1254,y:887,t:1528139572883};\\\", \\\"{x:1255,y:886,t:1528139572900};\\\", \\\"{x:1256,y:885,t:1528139572917};\\\", \\\"{x:1261,y:884,t:1528139572933};\\\", \\\"{x:1266,y:884,t:1528139572950};\\\", \\\"{x:1271,y:884,t:1528139572966};\\\", \\\"{x:1277,y:884,t:1528139572984};\\\", \\\"{x:1286,y:884,t:1528139573001};\\\", \\\"{x:1296,y:885,t:1528139573017};\\\", \\\"{x:1301,y:885,t:1528139573034};\\\", \\\"{x:1307,y:886,t:1528139573050};\\\", \\\"{x:1312,y:887,t:1528139573067};\\\", \\\"{x:1316,y:887,t:1528139573084};\\\", \\\"{x:1317,y:887,t:1528139573100};\\\", \\\"{x:1319,y:887,t:1528139573118};\\\", \\\"{x:1320,y:887,t:1528139573134};\\\", \\\"{x:1321,y:888,t:1528139573150};\\\", \\\"{x:1322,y:888,t:1528139573343};\\\", \\\"{x:1324,y:889,t:1528139573366};\\\", \\\"{x:1324,y:890,t:1528139573584};\\\", \\\"{x:1324,y:891,t:1528139573607};\\\", \\\"{x:1324,y:892,t:1528139573631};\\\", \\\"{x:1324,y:893,t:1528139573639};\\\", \\\"{x:1324,y:895,t:1528139573652};\\\", \\\"{x:1324,y:897,t:1528139573668};\\\", \\\"{x:1326,y:899,t:1528139573685};\\\", \\\"{x:1326,y:901,t:1528139573702};\\\", \\\"{x:1326,y:902,t:1528139573734};\\\", \\\"{x:1326,y:903,t:1528139573751};\\\", \\\"{x:1326,y:904,t:1528139573816};\\\", \\\"{x:1327,y:904,t:1528139573832};\\\", \\\"{x:1327,y:905,t:1528139573848};\\\", \\\"{x:1328,y:906,t:1528139573871};\\\", \\\"{x:1328,y:908,t:1528139573887};\\\", \\\"{x:1329,y:908,t:1528139573901};\\\", \\\"{x:1331,y:909,t:1528139573991};\\\", \\\"{x:1333,y:911,t:1528139574002};\\\", \\\"{x:1336,y:913,t:1528139574018};\\\", \\\"{x:1337,y:915,t:1528139574034};\\\", \\\"{x:1337,y:916,t:1528139574055};\\\", \\\"{x:1337,y:917,t:1528139574070};\\\", \\\"{x:1337,y:918,t:1528139574087};\\\", \\\"{x:1338,y:918,t:1528139574102};\\\", \\\"{x:1339,y:920,t:1528139574119};\\\", \\\"{x:1340,y:920,t:1528139574247};\\\", \\\"{x:1341,y:921,t:1528139574887};\\\", \\\"{x:1343,y:921,t:1528139574902};\\\", \\\"{x:1356,y:923,t:1528139574919};\\\", \\\"{x:1366,y:926,t:1528139574936};\\\", \\\"{x:1379,y:927,t:1528139574953};\\\", \\\"{x:1397,y:930,t:1528139574969};\\\", \\\"{x:1425,y:934,t:1528139574985};\\\", \\\"{x:1473,y:934,t:1528139575002};\\\", \\\"{x:1556,y:934,t:1528139575018};\\\", \\\"{x:1664,y:934,t:1528139575036};\\\", \\\"{x:1771,y:913,t:1528139575053};\\\", \\\"{x:1870,y:868,t:1528139575069};\\\", \\\"{x:1919,y:805,t:1528139575086};\\\", \\\"{x:1919,y:634,t:1528139575102};\\\", \\\"{x:1919,y:470,t:1528139575119};\\\", \\\"{x:1919,y:346,t:1528139575137};\\\", \\\"{x:1918,y:251,t:1528139575154};\\\", \\\"{x:1896,y:181,t:1528139575170};\\\", \\\"{x:1874,y:134,t:1528139575186};\\\", \\\"{x:1851,y:98,t:1528139575203};\\\", \\\"{x:1828,y:77,t:1528139575218};\\\", \\\"{x:1804,y:63,t:1528139575236};\\\", \\\"{x:1759,y:49,t:1528139575253};\\\", \\\"{x:1709,y:41,t:1528139575268};\\\", \\\"{x:1649,y:33,t:1528139575286};\\\", \\\"{x:1619,y:26,t:1528139575303};\\\", \\\"{x:1602,y:23,t:1528139575319};\\\", \\\"{x:1593,y:24,t:1528139575336};\\\", \\\"{x:1587,y:29,t:1528139575353};\\\", \\\"{x:1580,y:43,t:1528139575369};\\\", \\\"{x:1579,y:82,t:1528139575386};\\\", \\\"{x:1579,y:165,t:1528139575403};\\\", \\\"{x:1594,y:271,t:1528139575419};\\\", \\\"{x:1617,y:357,t:1528139575436};\\\", \\\"{x:1634,y:423,t:1528139575453};\\\", \\\"{x:1648,y:473,t:1528139575470};\\\", \\\"{x:1655,y:529,t:1528139575486};\\\", \\\"{x:1659,y:558,t:1528139575503};\\\", \\\"{x:1659,y:576,t:1528139575519};\\\", \\\"{x:1659,y:582,t:1528139575536};\\\", \\\"{x:1655,y:586,t:1528139575553};\\\", \\\"{x:1651,y:590,t:1528139575569};\\\", \\\"{x:1650,y:591,t:1528139575586};\\\", \\\"{x:1649,y:591,t:1528139575603};\\\", \\\"{x:1645,y:591,t:1528139575621};\\\", \\\"{x:1634,y:584,t:1528139575636};\\\", \\\"{x:1617,y:569,t:1528139575653};\\\", \\\"{x:1604,y:554,t:1528139575669};\\\", \\\"{x:1594,y:529,t:1528139575686};\\\", \\\"{x:1589,y:513,t:1528139575703};\\\", \\\"{x:1586,y:504,t:1528139575720};\\\", \\\"{x:1584,y:494,t:1528139575736};\\\", \\\"{x:1584,y:490,t:1528139575754};\\\", \\\"{x:1584,y:482,t:1528139575770};\\\", \\\"{x:1584,y:479,t:1528139575786};\\\", \\\"{x:1585,y:476,t:1528139575803};\\\", \\\"{x:1587,y:472,t:1528139575821};\\\", \\\"{x:1587,y:469,t:1528139575836};\\\", \\\"{x:1590,y:465,t:1528139575854};\\\", \\\"{x:1596,y:458,t:1528139575870};\\\", \\\"{x:1603,y:450,t:1528139575886};\\\", \\\"{x:1609,y:436,t:1528139575904};\\\", \\\"{x:1615,y:423,t:1528139575921};\\\", \\\"{x:1616,y:416,t:1528139575937};\\\", \\\"{x:1617,y:414,t:1528139575953};\\\", \\\"{x:1617,y:413,t:1528139575970};\\\", \\\"{x:1617,y:411,t:1528139575990};\\\", \\\"{x:1617,y:410,t:1528139576005};\\\", \\\"{x:1617,y:409,t:1528139576063};\\\", \\\"{x:1614,y:409,t:1528139576079};\\\", \\\"{x:1610,y:411,t:1528139576087};\\\", \\\"{x:1605,y:416,t:1528139576104};\\\", \\\"{x:1602,y:423,t:1528139576121};\\\", \\\"{x:1599,y:430,t:1528139576138};\\\", \\\"{x:1596,y:436,t:1528139576154};\\\", \\\"{x:1595,y:439,t:1528139576171};\\\", \\\"{x:1597,y:439,t:1528139576285};\\\", \\\"{x:1599,y:439,t:1528139576293};\\\", \\\"{x:1600,y:439,t:1528139576303};\\\", \\\"{x:1605,y:438,t:1528139576320};\\\", \\\"{x:1608,y:436,t:1528139576337};\\\", \\\"{x:1609,y:435,t:1528139576353};\\\", \\\"{x:1610,y:435,t:1528139576519};\\\", \\\"{x:1611,y:434,t:1528139576529};\\\", \\\"{x:1611,y:433,t:1528139576537};\\\", \\\"{x:1611,y:432,t:1528139576554};\\\", \\\"{x:1612,y:432,t:1528139576570};\\\", \\\"{x:1614,y:429,t:1528139576586};\\\", \\\"{x:1615,y:428,t:1528139576603};\\\", \\\"{x:1617,y:426,t:1528139576619};\\\", \\\"{x:1618,y:425,t:1528139576766};\\\", \\\"{x:1620,y:425,t:1528139580207};\\\", \\\"{x:1619,y:425,t:1528139580973};\\\", \\\"{x:1616,y:427,t:1528139580991};\\\", \\\"{x:1614,y:427,t:1528139581007};\\\", \\\"{x:1612,y:429,t:1528139581024};\\\", \\\"{x:1609,y:433,t:1528139592170};\\\", \\\"{x:1563,y:449,t:1528139592182};\\\", \\\"{x:1472,y:477,t:1528139592200};\\\", \\\"{x:1350,y:513,t:1528139592217};\\\", \\\"{x:1214,y:551,t:1528139592233};\\\", \\\"{x:1069,y:579,t:1528139592249};\\\", \\\"{x:938,y:607,t:1528139592267};\\\", \\\"{x:818,y:630,t:1528139592284};\\\", \\\"{x:720,y:647,t:1528139592300};\\\", \\\"{x:627,y:665,t:1528139592317};\\\", \\\"{x:495,y:686,t:1528139592335};\\\", \\\"{x:420,y:694,t:1528139592350};\\\", \\\"{x:361,y:704,t:1528139592366};\\\", \\\"{x:319,y:704,t:1528139592384};\\\", \\\"{x:292,y:704,t:1528139592400};\\\", \\\"{x:277,y:704,t:1528139592416};\\\", \\\"{x:271,y:705,t:1528139592434};\\\", \\\"{x:268,y:706,t:1528139592449};\\\", \\\"{x:266,y:707,t:1528139592467};\\\", \\\"{x:265,y:707,t:1528139592510};\\\", \\\"{x:267,y:701,t:1528139592518};\\\", \\\"{x:280,y:686,t:1528139592534};\\\", \\\"{x:293,y:673,t:1528139592549};\\\", \\\"{x:306,y:663,t:1528139592567};\\\", \\\"{x:321,y:655,t:1528139592585};\\\", \\\"{x:331,y:649,t:1528139592600};\\\", \\\"{x:335,y:646,t:1528139592617};\\\", \\\"{x:336,y:644,t:1528139592633};\\\", \\\"{x:337,y:644,t:1528139592649};\\\", \\\"{x:338,y:643,t:1528139592667};\\\", \\\"{x:340,y:643,t:1528139592749};\\\", \\\"{x:342,y:641,t:1528139592766};\\\", \\\"{x:347,y:638,t:1528139592783};\\\", \\\"{x:351,y:634,t:1528139592801};\\\", \\\"{x:355,y:634,t:1528139592816};\\\", \\\"{x:357,y:632,t:1528139592833};\\\", \\\"{x:358,y:631,t:1528139592850};\\\", \\\"{x:359,y:631,t:1528139592867};\\\", \\\"{x:360,y:631,t:1528139592884};\\\", \\\"{x:362,y:630,t:1528139592901};\\\", \\\"{x:366,y:628,t:1528139592917};\\\", \\\"{x:368,y:627,t:1528139592934};\\\", \\\"{x:369,y:626,t:1528139592950};\\\", \\\"{x:370,y:626,t:1528139592974};\\\", \\\"{x:371,y:626,t:1528139593207};\\\", \\\"{x:373,y:626,t:1528139593216};\\\", \\\"{x:382,y:635,t:1528139593234};\\\", \\\"{x:396,y:651,t:1528139593251};\\\", \\\"{x:408,y:665,t:1528139593267};\\\", \\\"{x:423,y:675,t:1528139593284};\\\", \\\"{x:438,y:684,t:1528139593300};\\\", \\\"{x:449,y:691,t:1528139593317};\\\", \\\"{x:463,y:701,t:1528139593333};\\\", \\\"{x:470,y:707,t:1528139593350};\\\", \\\"{x:478,y:713,t:1528139593366};\\\", \\\"{x:487,y:724,t:1528139593383};\\\", \\\"{x:488,y:727,t:1528139593401};\\\", \\\"{x:490,y:729,t:1528139593417};\\\", \\\"{x:491,y:731,t:1528139593434};\\\", \\\"{x:493,y:735,t:1528139593451};\\\", \\\"{x:494,y:736,t:1528139593466};\\\", \\\"{x:495,y:737,t:1528139593484};\\\", \\\"{x:495,y:739,t:1528139593502};\\\", \\\"{x:497,y:741,t:1528139593517};\\\", \\\"{x:497,y:742,t:1528139593534};\\\", \\\"{x:495,y:734,t:1528139593614};\\\", \\\"{x:485,y:727,t:1528139593622};\\\", \\\"{x:475,y:716,t:1528139593635};\\\", \\\"{x:458,y:696,t:1528139593651};\\\", \\\"{x:437,y:672,t:1528139593668};\\\", \\\"{x:411,y:641,t:1528139593685};\\\", \\\"{x:391,y:623,t:1528139593700};\\\", \\\"{x:378,y:617,t:1528139593718};\\\", \\\"{x:378,y:623,t:1528139593855};\\\", \\\"{x:380,y:629,t:1528139593868};\\\", \\\"{x:384,y:636,t:1528139593884};\\\", \\\"{x:386,y:640,t:1528139593901};\\\", \\\"{x:387,y:640,t:1528139594173};\\\", \\\"{x:389,y:640,t:1528139594205};\\\", \\\"{x:392,y:642,t:1528139594217};\\\", \\\"{x:411,y:658,t:1528139594235};\\\", \\\"{x:436,y:677,t:1528139594251};\\\", \\\"{x:460,y:697,t:1528139594268};\\\", \\\"{x:485,y:715,t:1528139594284};\\\", \\\"{x:508,y:734,t:1528139594301};\\\", \\\"{x:516,y:743,t:1528139594318};\\\", \\\"{x:520,y:745,t:1528139594335};\\\", \\\"{x:521,y:747,t:1528139594351};\\\", \\\"{x:521,y:749,t:1528139594374};\\\", \\\"{x:521,y:750,t:1528139594542};\\\", \\\"{x:522,y:750,t:1528139595070};\\\", \\\"{x:524,y:750,t:1528139595119};\\\", \\\"{x:526,y:750,t:1528139595136};\\\", \\\"{x:527,y:749,t:1528139595166};\\\", \\\"{x:529,y:748,t:1528139595206};\\\", \\\"{x:530,y:747,t:1528139595246};\\\", \\\"{x:531,y:746,t:1528139595278};\\\", \\\"{x:532,y:746,t:1528139595294};\\\", \\\"{x:533,y:746,t:1528139595325};\\\", \\\"{x:534,y:746,t:1528139595342};\\\", \\\"{x:535,y:745,t:1528139595358};\\\", \\\"{x:536,y:745,t:1528139595369};\\\", \\\"{x:538,y:744,t:1528139595386};\\\", \\\"{x:540,y:742,t:1528139595403};\\\", \\\"{x:543,y:740,t:1528139595419};\\\", \\\"{x:545,y:739,t:1528139595435};\\\", \\\"{x:550,y:736,t:1528139595453};\\\", \\\"{x:562,y:730,t:1528139595469};\\\", \\\"{x:586,y:717,t:1528139595486};\\\", \\\"{x:603,y:706,t:1528139595503};\\\", \\\"{x:625,y:696,t:1528139595519};\\\", \\\"{x:658,y:681,t:1528139595536};\\\", \\\"{x:723,y:658,t:1528139595552};\\\", \\\"{x:841,y:633,t:1528139595568};\\\", \\\"{x:952,y:617,t:1528139595586};\\\", \\\"{x:1088,y:596,t:1528139595602};\\\", \\\"{x:1229,y:575,t:1528139595619};\\\", \\\"{x:1378,y:557,t:1528139595635};\\\", \\\"{x:1501,y:553,t:1528139595653};\\\", \\\"{x:1645,y:553,t:1528139595669};\\\", \\\"{x:1704,y:553,t:1528139595689};\\\", \\\"{x:1728,y:553,t:1528139595706};\\\", \\\"{x:1736,y:553,t:1528139595756};\\\", \\\"{x:1737,y:553,t:1528139595792};\\\", \\\"{x:1736,y:554,t:1528139595806};\\\", \\\"{x:1733,y:555,t:1528139595823};\\\" ] }, { \\\"rt\\\": 20288, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 727026, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1728,y:558,t:1528139595945};\\\", \\\"{x:1727,y:559,t:1528139595971};\\\", \\\"{x:1720,y:563,t:1528139599099};\\\", \\\"{x:1706,y:570,t:1528139599109};\\\", \\\"{x:1658,y:601,t:1528139599126};\\\", \\\"{x:1586,y:649,t:1528139599143};\\\", \\\"{x:1506,y:704,t:1528139599160};\\\", \\\"{x:1432,y:745,t:1528139599176};\\\", \\\"{x:1314,y:802,t:1528139599193};\\\", \\\"{x:1253,y:828,t:1528139599210};\\\", \\\"{x:1215,y:844,t:1528139599227};\\\", \\\"{x:1193,y:853,t:1528139599243};\\\", \\\"{x:1174,y:858,t:1528139599259};\\\", \\\"{x:1161,y:860,t:1528139599276};\\\", \\\"{x:1154,y:863,t:1528139599293};\\\", \\\"{x:1157,y:863,t:1528139599425};\\\", \\\"{x:1163,y:858,t:1528139599433};\\\", \\\"{x:1168,y:857,t:1528139599442};\\\", \\\"{x:1176,y:852,t:1528139599459};\\\", \\\"{x:1181,y:849,t:1528139599476};\\\", \\\"{x:1186,y:847,t:1528139599493};\\\", \\\"{x:1191,y:844,t:1528139599510};\\\", \\\"{x:1195,y:842,t:1528139599527};\\\", \\\"{x:1196,y:841,t:1528139599610};\\\", \\\"{x:1197,y:840,t:1528139599627};\\\", \\\"{x:1199,y:840,t:1528139599643};\\\", \\\"{x:1199,y:838,t:1528139599659};\\\", \\\"{x:1200,y:837,t:1528139599677};\\\", \\\"{x:1203,y:834,t:1528139599693};\\\", \\\"{x:1204,y:833,t:1528139599710};\\\", \\\"{x:1206,y:831,t:1528139599727};\\\", \\\"{x:1207,y:830,t:1528139599779};\\\", \\\"{x:1208,y:829,t:1528139599811};\\\", \\\"{x:1209,y:829,t:1528139599840};\\\", \\\"{x:1212,y:828,t:1528139599859};\\\", \\\"{x:1213,y:827,t:1528139599876};\\\", \\\"{x:1214,y:827,t:1528139599937};\\\", \\\"{x:1215,y:827,t:1528139600106};\\\", \\\"{x:1216,y:827,t:1528139611994};\\\", \\\"{x:1227,y:823,t:1528139612006};\\\", \\\"{x:1264,y:808,t:1528139612020};\\\", \\\"{x:1317,y:794,t:1528139612036};\\\", \\\"{x:1354,y:785,t:1528139612053};\\\", \\\"{x:1384,y:777,t:1528139612070};\\\", \\\"{x:1412,y:773,t:1528139612086};\\\", \\\"{x:1425,y:773,t:1528139612103};\\\", \\\"{x:1430,y:773,t:1528139612120};\\\", \\\"{x:1430,y:772,t:1528139612136};\\\", \\\"{x:1431,y:772,t:1528139612225};\\\", \\\"{x:1431,y:771,t:1528139612236};\\\", \\\"{x:1426,y:768,t:1528139612253};\\\", \\\"{x:1418,y:765,t:1528139612270};\\\", \\\"{x:1408,y:762,t:1528139612287};\\\", \\\"{x:1399,y:760,t:1528139612303};\\\", \\\"{x:1394,y:760,t:1528139612320};\\\", \\\"{x:1386,y:758,t:1528139612337};\\\", \\\"{x:1383,y:758,t:1528139612356};\\\", \\\"{x:1381,y:758,t:1528139612513};\\\", \\\"{x:1380,y:758,t:1528139612545};\\\", \\\"{x:1377,y:758,t:1528139613634};\\\", \\\"{x:1367,y:758,t:1528139613641};\\\", \\\"{x:1346,y:756,t:1528139613654};\\\", \\\"{x:1274,y:745,t:1528139613671};\\\", \\\"{x:1171,y:731,t:1528139613688};\\\", \\\"{x:1057,y:715,t:1528139613704};\\\", \\\"{x:919,y:694,t:1528139613720};\\\", \\\"{x:855,y:681,t:1528139613738};\\\", \\\"{x:811,y:671,t:1528139613754};\\\", \\\"{x:778,y:665,t:1528139613771};\\\", \\\"{x:756,y:662,t:1528139613787};\\\", \\\"{x:743,y:660,t:1528139613803};\\\", \\\"{x:733,y:659,t:1528139613821};\\\", \\\"{x:717,y:657,t:1528139613838};\\\", \\\"{x:690,y:652,t:1528139613854};\\\", \\\"{x:662,y:648,t:1528139613871};\\\", \\\"{x:634,y:647,t:1528139613888};\\\", \\\"{x:594,y:645,t:1528139613905};\\\", \\\"{x:570,y:641,t:1528139613920};\\\", \\\"{x:542,y:636,t:1528139613938};\\\", \\\"{x:504,y:629,t:1528139613955};\\\", \\\"{x:465,y:623,t:1528139613972};\\\", \\\"{x:431,y:617,t:1528139613988};\\\", \\\"{x:400,y:613,t:1528139614004};\\\", \\\"{x:374,y:609,t:1528139614022};\\\", \\\"{x:359,y:608,t:1528139614038};\\\", \\\"{x:346,y:605,t:1528139614055};\\\", \\\"{x:341,y:604,t:1528139614072};\\\", \\\"{x:335,y:603,t:1528139614087};\\\", \\\"{x:333,y:602,t:1528139614105};\\\", \\\"{x:333,y:601,t:1528139614129};\\\", \\\"{x:334,y:600,t:1528139614138};\\\", \\\"{x:337,y:600,t:1528139614155};\\\", \\\"{x:342,y:597,t:1528139614172};\\\", \\\"{x:348,y:594,t:1528139614189};\\\", \\\"{x:353,y:593,t:1528139614205};\\\", \\\"{x:357,y:593,t:1528139614222};\\\", \\\"{x:360,y:593,t:1528139614239};\\\", \\\"{x:367,y:593,t:1528139614256};\\\", \\\"{x:368,y:593,t:1528139614272};\\\", \\\"{x:370,y:594,t:1528139614289};\\\", \\\"{x:374,y:594,t:1528139614561};\\\", \\\"{x:378,y:599,t:1528139614574};\\\", \\\"{x:384,y:612,t:1528139614590};\\\", \\\"{x:398,y:631,t:1528139614607};\\\", \\\"{x:410,y:651,t:1528139614621};\\\", \\\"{x:430,y:673,t:1528139614637};\\\", \\\"{x:443,y:690,t:1528139614655};\\\", \\\"{x:456,y:701,t:1528139614671};\\\", \\\"{x:471,y:715,t:1528139614688};\\\", \\\"{x:476,y:720,t:1528139614704};\\\", \\\"{x:479,y:725,t:1528139614722};\\\", \\\"{x:482,y:729,t:1528139614739};\\\", \\\"{x:483,y:730,t:1528139614756};\\\", \\\"{x:483,y:731,t:1528139614817};\\\", \\\"{x:483,y:732,t:1528139614849};\\\", \\\"{x:484,y:733,t:1528139614856};\\\", \\\"{x:484,y:734,t:1528139614881};\\\", \\\"{x:484,y:735,t:1528139614897};\\\", \\\"{x:484,y:736,t:1528139614921};\\\", \\\"{x:484,y:731,t:1528139614985};\\\", \\\"{x:476,y:718,t:1528139614993};\\\", \\\"{x:472,y:703,t:1528139615007};\\\", \\\"{x:451,y:656,t:1528139615024};\\\", \\\"{x:419,y:604,t:1528139615041};\\\", \\\"{x:397,y:575,t:1528139615057};\\\", \\\"{x:379,y:563,t:1528139615073};\\\", \\\"{x:375,y:559,t:1528139615089};\\\", \\\"{x:374,y:559,t:1528139615226};\\\", \\\"{x:374,y:564,t:1528139615240};\\\", \\\"{x:374,y:579,t:1528139615258};\\\", \\\"{x:374,y:582,t:1528139615272};\\\", \\\"{x:374,y:586,t:1528139615289};\\\", \\\"{x:375,y:592,t:1528139615307};\\\", \\\"{x:376,y:596,t:1528139615323};\\\", \\\"{x:376,y:597,t:1528139615339};\\\", \\\"{x:376,y:598,t:1528139615606};\\\", \\\"{x:380,y:604,t:1528139615623};\\\", \\\"{x:384,y:611,t:1528139615639};\\\", \\\"{x:393,y:631,t:1528139615657};\\\", \\\"{x:418,y:658,t:1528139615673};\\\", \\\"{x:436,y:680,t:1528139615689};\\\", \\\"{x:454,y:694,t:1528139615706};\\\", \\\"{x:464,y:702,t:1528139615723};\\\", \\\"{x:470,y:706,t:1528139615739};\\\", \\\"{x:473,y:709,t:1528139615757};\\\", \\\"{x:476,y:711,t:1528139615773};\\\", \\\"{x:477,y:712,t:1528139615793};\\\", \\\"{x:477,y:714,t:1528139615817};\\\", \\\"{x:478,y:715,t:1528139615825};\\\", \\\"{x:479,y:716,t:1528139615839};\\\", \\\"{x:481,y:718,t:1528139615856};\\\", \\\"{x:481,y:720,t:1528139615873};\\\", \\\"{x:482,y:722,t:1528139615896};\\\", \\\"{x:483,y:723,t:1528139615907};\\\", \\\"{x:486,y:729,t:1528139615924};\\\", \\\"{x:488,y:735,t:1528139615939};\\\", \\\"{x:492,y:743,t:1528139615959};\\\", \\\"{x:494,y:749,t:1528139615973};\\\", \\\"{x:495,y:750,t:1528139615990};\\\", \\\"{x:495,y:751,t:1528139616006};\\\", \\\"{x:496,y:751,t:1528139616041};\\\", \\\"{x:500,y:749,t:1528139616289};\\\", \\\"{x:504,y:746,t:1528139616296};\\\", \\\"{x:512,y:743,t:1528139616306};\\\", \\\"{x:539,y:734,t:1528139616323};\\\", \\\"{x:586,y:720,t:1528139616340};\\\", \\\"{x:649,y:695,t:1528139616355};\\\", \\\"{x:726,y:663,t:1528139616373};\\\", \\\"{x:791,y:631,t:1528139616390};\\\", \\\"{x:854,y:603,t:1528139616406};\\\", \\\"{x:915,y:579,t:1528139616423};\\\", \\\"{x:969,y:559,t:1528139616440};\\\", \\\"{x:990,y:550,t:1528139616456};\\\", \\\"{x:1007,y:541,t:1528139616473};\\\", \\\"{x:1012,y:539,t:1528139616490};\\\", \\\"{x:1012,y:538,t:1528139616601};\\\", \\\"{x:1014,y:537,t:1528139616609};\\\", \\\"{x:1014,y:536,t:1528139616666};\\\", \\\"{x:1014,y:535,t:1528139616673};\\\", \\\"{x:1014,y:534,t:1528139616690};\\\", \\\"{x:1014,y:533,t:1528139617305};\\\", \\\"{x:1013,y:533,t:1528139617312};\\\", \\\"{x:1012,y:533,t:1528139617324};\\\" ] }, { \\\"rt\\\": 16742, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 745018, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1004,y:537,t:1528139617483};\\\", \\\"{x:1002,y:540,t:1528139620698};\\\", \\\"{x:1001,y:540,t:1528139620712};\\\", \\\"{x:1001,y:541,t:1528139620727};\\\", \\\"{x:997,y:544,t:1528139620743};\\\", \\\"{x:991,y:572,t:1528139620760};\\\", \\\"{x:986,y:613,t:1528139620776};\\\", \\\"{x:982,y:652,t:1528139620794};\\\", \\\"{x:981,y:689,t:1528139620811};\\\", \\\"{x:981,y:716,t:1528139620827};\\\", \\\"{x:982,y:750,t:1528139620843};\\\", \\\"{x:994,y:807,t:1528139620860};\\\", \\\"{x:1011,y:849,t:1528139620877};\\\", \\\"{x:1018,y:873,t:1528139620894};\\\", \\\"{x:1026,y:894,t:1528139620910};\\\", \\\"{x:1042,y:917,t:1528139620927};\\\", \\\"{x:1061,y:934,t:1528139620943};\\\", \\\"{x:1094,y:961,t:1528139620960};\\\", \\\"{x:1122,y:978,t:1528139620977};\\\", \\\"{x:1159,y:997,t:1528139620994};\\\", \\\"{x:1214,y:1019,t:1528139621010};\\\", \\\"{x:1283,y:1040,t:1528139621027};\\\", \\\"{x:1372,y:1063,t:1528139621044};\\\", \\\"{x:1471,y:1091,t:1528139621060};\\\", \\\"{x:1563,y:1118,t:1528139621077};\\\", \\\"{x:1643,y:1139,t:1528139621094};\\\", \\\"{x:1718,y:1150,t:1528139621111};\\\", \\\"{x:1767,y:1159,t:1528139621127};\\\", \\\"{x:1797,y:1164,t:1528139621144};\\\", \\\"{x:1819,y:1168,t:1528139621161};\\\", \\\"{x:1822,y:1169,t:1528139621177};\\\", \\\"{x:1822,y:1171,t:1528139621514};\\\", \\\"{x:1817,y:1171,t:1528139621528};\\\", \\\"{x:1807,y:1162,t:1528139621545};\\\", \\\"{x:1804,y:1157,t:1528139621561};\\\", \\\"{x:1801,y:1151,t:1528139621577};\\\", \\\"{x:1793,y:1138,t:1528139621594};\\\", \\\"{x:1779,y:1121,t:1528139621611};\\\", \\\"{x:1763,y:1100,t:1528139621628};\\\", \\\"{x:1740,y:1074,t:1528139621645};\\\", \\\"{x:1725,y:1057,t:1528139621663};\\\", \\\"{x:1713,y:1047,t:1528139621678};\\\", \\\"{x:1703,y:1037,t:1528139621695};\\\", \\\"{x:1699,y:1030,t:1528139621712};\\\", \\\"{x:1698,y:1028,t:1528139621728};\\\", \\\"{x:1695,y:1025,t:1528139621745};\\\", \\\"{x:1691,y:1019,t:1528139621762};\\\", \\\"{x:1686,y:1013,t:1528139621778};\\\", \\\"{x:1683,y:1010,t:1528139621794};\\\", \\\"{x:1682,y:1010,t:1528139621812};\\\", \\\"{x:1681,y:1010,t:1528139621833};\\\", \\\"{x:1680,y:1009,t:1528139621858};\\\", \\\"{x:1677,y:1006,t:1528139621873};\\\", \\\"{x:1673,y:1005,t:1528139621882};\\\", \\\"{x:1670,y:1002,t:1528139621895};\\\", \\\"{x:1665,y:998,t:1528139621912};\\\", \\\"{x:1662,y:997,t:1528139621928};\\\", \\\"{x:1657,y:994,t:1528139621945};\\\", \\\"{x:1651,y:991,t:1528139621961};\\\", \\\"{x:1646,y:987,t:1528139621978};\\\", \\\"{x:1642,y:986,t:1528139621995};\\\", \\\"{x:1641,y:984,t:1528139622012};\\\", \\\"{x:1640,y:984,t:1528139622028};\\\", \\\"{x:1639,y:984,t:1528139622045};\\\", \\\"{x:1636,y:982,t:1528139622062};\\\", \\\"{x:1633,y:981,t:1528139622079};\\\", \\\"{x:1631,y:979,t:1528139622095};\\\", \\\"{x:1628,y:978,t:1528139622111};\\\", \\\"{x:1624,y:974,t:1528139622129};\\\", \\\"{x:1621,y:972,t:1528139622145};\\\", \\\"{x:1618,y:969,t:1528139622162};\\\", \\\"{x:1617,y:966,t:1528139622180};\\\", \\\"{x:1616,y:964,t:1528139622195};\\\", \\\"{x:1614,y:961,t:1528139622212};\\\", \\\"{x:1613,y:961,t:1528139622234};\\\", \\\"{x:1613,y:960,t:1528139622249};\\\", \\\"{x:1613,y:959,t:1528139622265};\\\", \\\"{x:1612,y:958,t:1528139622278};\\\", \\\"{x:1611,y:955,t:1528139622295};\\\", \\\"{x:1611,y:954,t:1528139622311};\\\", \\\"{x:1611,y:953,t:1528139622328};\\\", \\\"{x:1610,y:953,t:1528139622345};\\\", \\\"{x:1610,y:956,t:1528139622562};\\\", \\\"{x:1610,y:957,t:1528139622579};\\\", \\\"{x:1610,y:958,t:1528139622596};\\\", \\\"{x:1610,y:959,t:1528139622642};\\\", \\\"{x:1610,y:960,t:1528139622649};\\\", \\\"{x:1610,y:962,t:1528139622681};\\\", \\\"{x:1610,y:963,t:1528139622697};\\\", \\\"{x:1610,y:966,t:1528139622713};\\\", \\\"{x:1610,y:968,t:1528139622730};\\\", \\\"{x:1610,y:969,t:1528139622770};\\\", \\\"{x:1610,y:970,t:1528139622785};\\\", \\\"{x:1610,y:972,t:1528139622795};\\\", \\\"{x:1610,y:973,t:1528139622812};\\\", \\\"{x:1610,y:975,t:1528139622829};\\\", \\\"{x:1610,y:976,t:1528139622845};\\\", \\\"{x:1610,y:977,t:1528139622863};\\\", \\\"{x:1610,y:978,t:1528139622914};\\\", \\\"{x:1611,y:978,t:1528139623266};\\\", \\\"{x:1615,y:977,t:1528139623279};\\\", \\\"{x:1619,y:971,t:1528139623296};\\\", \\\"{x:1624,y:961,t:1528139623314};\\\", \\\"{x:1625,y:957,t:1528139623328};\\\", \\\"{x:1626,y:956,t:1528139623345};\\\", \\\"{x:1625,y:956,t:1528139623569};\\\", \\\"{x:1624,y:956,t:1528139623580};\\\", \\\"{x:1623,y:956,t:1528139623650};\\\", \\\"{x:1622,y:957,t:1528139623689};\\\", \\\"{x:1621,y:958,t:1528139623705};\\\", \\\"{x:1620,y:958,t:1528139623737};\\\", \\\"{x:1619,y:959,t:1528139623745};\\\", \\\"{x:1619,y:957,t:1528139623970};\\\", \\\"{x:1620,y:953,t:1528139623980};\\\", \\\"{x:1625,y:942,t:1528139623997};\\\", \\\"{x:1630,y:928,t:1528139624014};\\\", \\\"{x:1637,y:917,t:1528139624029};\\\", \\\"{x:1639,y:910,t:1528139624046};\\\", \\\"{x:1641,y:908,t:1528139624062};\\\", \\\"{x:1641,y:907,t:1528139624241};\\\", \\\"{x:1641,y:906,t:1528139624249};\\\", \\\"{x:1641,y:905,t:1528139624263};\\\", \\\"{x:1644,y:902,t:1528139624280};\\\", \\\"{x:1647,y:898,t:1528139624297};\\\", \\\"{x:1649,y:896,t:1528139624314};\\\", \\\"{x:1647,y:899,t:1528139625450};\\\", \\\"{x:1646,y:904,t:1528139625464};\\\", \\\"{x:1643,y:912,t:1528139625480};\\\", \\\"{x:1642,y:915,t:1528139625498};\\\", \\\"{x:1641,y:917,t:1528139625536};\\\", \\\"{x:1641,y:918,t:1528139625585};\\\", \\\"{x:1641,y:919,t:1528139625597};\\\", \\\"{x:1641,y:922,t:1528139625615};\\\", \\\"{x:1641,y:928,t:1528139625630};\\\", \\\"{x:1640,y:934,t:1528139625648};\\\", \\\"{x:1636,y:941,t:1528139625664};\\\", \\\"{x:1636,y:945,t:1528139625681};\\\", \\\"{x:1636,y:947,t:1528139625698};\\\", \\\"{x:1635,y:949,t:1528139625714};\\\", \\\"{x:1634,y:951,t:1528139625731};\\\", \\\"{x:1634,y:954,t:1528139625748};\\\", \\\"{x:1633,y:958,t:1528139625764};\\\", \\\"{x:1631,y:961,t:1528139625780};\\\", \\\"{x:1630,y:964,t:1528139625798};\\\", \\\"{x:1629,y:966,t:1528139625815};\\\", \\\"{x:1628,y:968,t:1528139625831};\\\", \\\"{x:1627,y:969,t:1528139625848};\\\", \\\"{x:1626,y:969,t:1528139625897};\\\", \\\"{x:1625,y:969,t:1528139626202};\\\", \\\"{x:1625,y:968,t:1528139626215};\\\", \\\"{x:1625,y:967,t:1528139626232};\\\", \\\"{x:1625,y:966,t:1528139626248};\\\", \\\"{x:1623,y:962,t:1528139626266};\\\", \\\"{x:1622,y:961,t:1528139626289};\\\", \\\"{x:1622,y:960,t:1528139626368};\\\", \\\"{x:1622,y:958,t:1528139626381};\\\", \\\"{x:1623,y:951,t:1528139626397};\\\", \\\"{x:1624,y:951,t:1528139627018};\\\", \\\"{x:1626,y:951,t:1528139627033};\\\", \\\"{x:1627,y:951,t:1528139627137};\\\", \\\"{x:1625,y:952,t:1528139627170};\\\", \\\"{x:1624,y:952,t:1528139627182};\\\", \\\"{x:1622,y:954,t:1528139627201};\\\", \\\"{x:1621,y:954,t:1528139627217};\\\", \\\"{x:1620,y:954,t:1528139627232};\\\", \\\"{x:1619,y:954,t:1528139627250};\\\", \\\"{x:1617,y:954,t:1528139627280};\\\", \\\"{x:1616,y:954,t:1528139627288};\\\", \\\"{x:1615,y:954,t:1528139627298};\\\", \\\"{x:1612,y:954,t:1528139627316};\\\", \\\"{x:1610,y:953,t:1528139627333};\\\", \\\"{x:1608,y:953,t:1528139627349};\\\", \\\"{x:1607,y:953,t:1528139627366};\\\", \\\"{x:1606,y:953,t:1528139627382};\\\", \\\"{x:1605,y:953,t:1528139627399};\\\", \\\"{x:1604,y:953,t:1528139627417};\\\", \\\"{x:1601,y:951,t:1528139627433};\\\", \\\"{x:1597,y:946,t:1528139627448};\\\", \\\"{x:1591,y:934,t:1528139627465};\\\", \\\"{x:1582,y:914,t:1528139627483};\\\", \\\"{x:1571,y:876,t:1528139627498};\\\", \\\"{x:1550,y:817,t:1528139627515};\\\", \\\"{x:1525,y:751,t:1528139627532};\\\", \\\"{x:1502,y:678,t:1528139627549};\\\", \\\"{x:1469,y:596,t:1528139627566};\\\", \\\"{x:1431,y:531,t:1528139627583};\\\", \\\"{x:1406,y:490,t:1528139627598};\\\", \\\"{x:1397,y:475,t:1528139627615};\\\", \\\"{x:1393,y:469,t:1528139627632};\\\", \\\"{x:1392,y:468,t:1528139627656};\\\", \\\"{x:1391,y:468,t:1528139627672};\\\", \\\"{x:1390,y:468,t:1528139627720};\\\", \\\"{x:1387,y:472,t:1528139627736};\\\", \\\"{x:1387,y:483,t:1528139627749};\\\", \\\"{x:1387,y:498,t:1528139627765};\\\", \\\"{x:1387,y:508,t:1528139627783};\\\", \\\"{x:1387,y:512,t:1528139627800};\\\", \\\"{x:1387,y:514,t:1528139627816};\\\", \\\"{x:1387,y:519,t:1528139627832};\\\", \\\"{x:1387,y:524,t:1528139627849};\\\", \\\"{x:1387,y:530,t:1528139627866};\\\", \\\"{x:1387,y:534,t:1528139627882};\\\", \\\"{x:1388,y:539,t:1528139627900};\\\", \\\"{x:1390,y:544,t:1528139627916};\\\", \\\"{x:1392,y:547,t:1528139627933};\\\", \\\"{x:1395,y:550,t:1528139627950};\\\", \\\"{x:1398,y:552,t:1528139627966};\\\", \\\"{x:1403,y:555,t:1528139627983};\\\", \\\"{x:1406,y:558,t:1528139628000};\\\", \\\"{x:1410,y:561,t:1528139628023};\\\", \\\"{x:1411,y:562,t:1528139628032};\\\", \\\"{x:1412,y:562,t:1528139628056};\\\", \\\"{x:1413,y:563,t:1528139632313};\\\", \\\"{x:1405,y:569,t:1528139632324};\\\", \\\"{x:1353,y:574,t:1528139632337};\\\", \\\"{x:1237,y:574,t:1528139632353};\\\", \\\"{x:1079,y:574,t:1528139632369};\\\", \\\"{x:916,y:571,t:1528139632387};\\\", \\\"{x:752,y:572,t:1528139632402};\\\", \\\"{x:614,y:591,t:1528139632420};\\\", \\\"{x:485,y:604,t:1528139632438};\\\", \\\"{x:393,y:617,t:1528139632453};\\\", \\\"{x:332,y:626,t:1528139632470};\\\", \\\"{x:304,y:628,t:1528139632486};\\\", \\\"{x:294,y:629,t:1528139632503};\\\", \\\"{x:291,y:629,t:1528139632520};\\\", \\\"{x:290,y:629,t:1528139632537};\\\", \\\"{x:291,y:629,t:1528139632593};\\\", \\\"{x:292,y:628,t:1528139632608};\\\", \\\"{x:294,y:628,t:1528139632620};\\\", \\\"{x:314,y:629,t:1528139632636};\\\", \\\"{x:369,y:640,t:1528139632653};\\\", \\\"{x:451,y:646,t:1528139632669};\\\", \\\"{x:509,y:646,t:1528139632687};\\\", \\\"{x:554,y:646,t:1528139632703};\\\", \\\"{x:593,y:637,t:1528139632720};\\\", \\\"{x:616,y:627,t:1528139632737};\\\", \\\"{x:619,y:620,t:1528139632754};\\\", \\\"{x:619,y:611,t:1528139632770};\\\", \\\"{x:619,y:603,t:1528139632787};\\\", \\\"{x:618,y:601,t:1528139632865};\\\", \\\"{x:611,y:600,t:1528139632872};\\\", \\\"{x:604,y:600,t:1528139632886};\\\", \\\"{x:595,y:597,t:1528139632904};\\\", \\\"{x:592,y:594,t:1528139632920};\\\", \\\"{x:591,y:590,t:1528139632937};\\\", \\\"{x:591,y:588,t:1528139632954};\\\", \\\"{x:591,y:587,t:1528139633177};\\\", \\\"{x:592,y:587,t:1528139633225};\\\", \\\"{x:594,y:588,t:1528139633237};\\\", \\\"{x:598,y:595,t:1528139633253};\\\", \\\"{x:599,y:599,t:1528139633271};\\\", \\\"{x:601,y:603,t:1528139633287};\\\", \\\"{x:602,y:604,t:1528139633304};\\\", \\\"{x:602,y:605,t:1528139633680};\\\", \\\"{x:603,y:607,t:1528139633688};\\\", \\\"{x:603,y:609,t:1528139633704};\\\", \\\"{x:604,y:611,t:1528139633721};\\\", \\\"{x:604,y:612,t:1528139633744};\\\", \\\"{x:605,y:613,t:1528139633754};\\\", \\\"{x:605,y:614,t:1528139633792};\\\", \\\"{x:605,y:615,t:1528139633817};\\\", \\\"{x:605,y:616,t:1528139633825};\\\", \\\"{x:605,y:617,t:1528139633837};\\\", \\\"{x:604,y:623,t:1528139633855};\\\", \\\"{x:599,y:631,t:1528139633872};\\\", \\\"{x:593,y:643,t:1528139633888};\\\", \\\"{x:583,y:659,t:1528139633905};\\\", \\\"{x:563,y:689,t:1528139633921};\\\", \\\"{x:549,y:712,t:1528139633938};\\\", \\\"{x:537,y:731,t:1528139633954};\\\", \\\"{x:528,y:741,t:1528139633972};\\\", \\\"{x:522,y:748,t:1528139633988};\\\", \\\"{x:519,y:754,t:1528139634005};\\\", \\\"{x:518,y:756,t:1528139634021};\\\", \\\"{x:518,y:757,t:1528139634037};\\\", \\\"{x:517,y:757,t:1528139634056};\\\", \\\"{x:516,y:756,t:1528139634242};\\\", \\\"{x:516,y:754,t:1528139634255};\\\", \\\"{x:517,y:752,t:1528139634271};\\\", \\\"{x:531,y:747,t:1528139634288};\\\", \\\"{x:565,y:742,t:1528139634303};\\\", \\\"{x:631,y:726,t:1528139634320};\\\", \\\"{x:696,y:712,t:1528139634337};\\\", \\\"{x:766,y:691,t:1528139634355};\\\", \\\"{x:814,y:667,t:1528139634371};\\\", \\\"{x:893,y:637,t:1528139634388};\\\", \\\"{x:944,y:608,t:1528139634404};\\\", \\\"{x:974,y:593,t:1528139634421};\\\", \\\"{x:995,y:581,t:1528139634437};\\\", \\\"{x:1004,y:576,t:1528139634454};\\\", \\\"{x:1011,y:573,t:1528139634472};\\\", \\\"{x:1016,y:570,t:1528139634487};\\\", \\\"{x:1022,y:567,t:1528139634504};\\\", \\\"{x:1027,y:563,t:1528139634522};\\\", \\\"{x:1031,y:560,t:1528139634538};\\\", \\\"{x:1037,y:554,t:1528139634554};\\\", \\\"{x:1043,y:548,t:1528139634571};\\\", \\\"{x:1045,y:544,t:1528139634588};\\\", \\\"{x:1047,y:540,t:1528139634604};\\\", \\\"{x:1049,y:537,t:1528139634621};\\\", \\\"{x:1049,y:536,t:1528139634637};\\\", \\\"{x:1050,y:533,t:1528139634655};\\\", \\\"{x:1051,y:530,t:1528139634671};\\\", \\\"{x:1051,y:528,t:1528139634688};\\\", \\\"{x:1052,y:525,t:1528139634705};\\\", \\\"{x:1053,y:523,t:1528139634722};\\\", \\\"{x:1053,y:522,t:1528139634738};\\\", \\\"{x:1053,y:521,t:1528139634755};\\\", \\\"{x:1053,y:520,t:1528139634772};\\\", \\\"{x:1053,y:519,t:1528139634788};\\\", \\\"{x:1053,y:518,t:1528139634805};\\\", \\\"{x:1054,y:517,t:1528139634833};\\\", \\\"{x:1054,y:516,t:1528139634864};\\\", \\\"{x:1054,y:515,t:1528139634873};\\\", \\\"{x:1053,y:514,t:1528139634888};\\\", \\\"{x:1050,y:513,t:1528139634905};\\\", \\\"{x:1048,y:511,t:1528139634922};\\\", \\\"{x:1047,y:511,t:1528139635065};\\\", \\\"{x:1044,y:511,t:1528139635073};\\\", \\\"{x:1041,y:511,t:1528139635089};\\\", \\\"{x:1038,y:511,t:1528139635105};\\\", \\\"{x:1035,y:513,t:1528139635122};\\\", \\\"{x:1033,y:514,t:1528139635139};\\\", \\\"{x:1030,y:514,t:1528139635155};\\\" ] }, { \\\"rt\\\": 49942, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 796236, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -C -11 AM-12 PM-11 AM-C -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1028,y:514,t:1528139635577};\\\", \\\"{x:1027,y:514,t:1528139640010};\\\", \\\"{x:1027,y:513,t:1528139640027};\\\", \\\"{x:1027,y:511,t:1528139640042};\\\", \\\"{x:1028,y:509,t:1528139640060};\\\", \\\"{x:1029,y:508,t:1528139640076};\\\", \\\"{x:1031,y:506,t:1528139640093};\\\", \\\"{x:1031,y:504,t:1528139640110};\\\", \\\"{x:1032,y:503,t:1528139640126};\\\", \\\"{x:1034,y:502,t:1528139640143};\\\", \\\"{x:1035,y:501,t:1528139640160};\\\", \\\"{x:1036,y:501,t:1528139640176};\\\", \\\"{x:1036,y:500,t:1528139640193};\\\", \\\"{x:1037,y:500,t:1528139640217};\\\", \\\"{x:1038,y:499,t:1528139640249};\\\", \\\"{x:1039,y:499,t:1528139640306};\\\", \\\"{x:1039,y:498,t:1528139640329};\\\", \\\"{x:1040,y:498,t:1528139640343};\\\", \\\"{x:1042,y:497,t:1528139640360};\\\", \\\"{x:1055,y:494,t:1528139640377};\\\", \\\"{x:1075,y:491,t:1528139640393};\\\", \\\"{x:1103,y:490,t:1528139640410};\\\", \\\"{x:1132,y:490,t:1528139640426};\\\", \\\"{x:1171,y:490,t:1528139640443};\\\", \\\"{x:1218,y:490,t:1528139640461};\\\", \\\"{x:1260,y:490,t:1528139640477};\\\", \\\"{x:1297,y:490,t:1528139640493};\\\", \\\"{x:1318,y:490,t:1528139640509};\\\", \\\"{x:1330,y:490,t:1528139640527};\\\", \\\"{x:1333,y:490,t:1528139640544};\\\", \\\"{x:1334,y:490,t:1528139640578};\\\", \\\"{x:1335,y:490,t:1528139640594};\\\", \\\"{x:1336,y:490,t:1528139640609};\\\", \\\"{x:1337,y:490,t:1528139640633};\\\", \\\"{x:1339,y:489,t:1528139640643};\\\", \\\"{x:1336,y:489,t:1528139640729};\\\", \\\"{x:1333,y:491,t:1528139640743};\\\", \\\"{x:1327,y:493,t:1528139640760};\\\", \\\"{x:1322,y:496,t:1528139640777};\\\", \\\"{x:1319,y:496,t:1528139640800};\\\", \\\"{x:1317,y:498,t:1528139640985};\\\", \\\"{x:1316,y:498,t:1528139641385};\\\", \\\"{x:1316,y:500,t:1528139661260};\\\", \\\"{x:1325,y:516,t:1528139661274};\\\", \\\"{x:1376,y:565,t:1528139661287};\\\", \\\"{x:1384,y:623,t:1528139661305};\\\", \\\"{x:1383,y:682,t:1528139661313};\\\", \\\"{x:1357,y:808,t:1528139661330};\\\", \\\"{x:1293,y:1008,t:1528139661347};\\\", \\\"{x:1251,y:1157,t:1528139661363};\\\", \\\"{x:1210,y:1199,t:1528139661380};\\\", \\\"{x:1193,y:1199,t:1528139661397};\\\", \\\"{x:1167,y:1199,t:1528139661413};\\\", \\\"{x:1157,y:1199,t:1528139661430};\\\", \\\"{x:1148,y:1199,t:1528139661447};\\\", \\\"{x:1149,y:1199,t:1528139661467};\\\", \\\"{x:1150,y:1199,t:1528139661483};\\\", \\\"{x:1151,y:1199,t:1528139661500};\\\", \\\"{x:1152,y:1198,t:1528139661513};\\\", \\\"{x:1156,y:1190,t:1528139661530};\\\", \\\"{x:1157,y:1145,t:1528139661548};\\\", \\\"{x:1157,y:1094,t:1528139661564};\\\", \\\"{x:1165,y:1038,t:1528139661580};\\\", \\\"{x:1173,y:982,t:1528139661597};\\\", \\\"{x:1180,y:935,t:1528139661614};\\\", \\\"{x:1186,y:892,t:1528139661630};\\\", \\\"{x:1194,y:855,t:1528139661648};\\\", \\\"{x:1200,y:838,t:1528139661665};\\\", \\\"{x:1204,y:833,t:1528139661680};\\\", \\\"{x:1206,y:830,t:1528139661697};\\\", \\\"{x:1207,y:830,t:1528139661715};\\\", \\\"{x:1212,y:830,t:1528139661734};\\\", \\\"{x:1221,y:832,t:1528139661749};\\\", \\\"{x:1229,y:839,t:1528139661764};\\\", \\\"{x:1243,y:859,t:1528139661780};\\\", \\\"{x:1257,y:881,t:1528139661798};\\\", \\\"{x:1267,y:896,t:1528139661814};\\\", \\\"{x:1269,y:906,t:1528139661830};\\\", \\\"{x:1275,y:923,t:1528139661847};\\\", \\\"{x:1280,y:941,t:1528139661864};\\\", \\\"{x:1284,y:960,t:1528139661881};\\\", \\\"{x:1292,y:973,t:1528139661898};\\\", \\\"{x:1295,y:977,t:1528139661915};\\\", \\\"{x:1296,y:977,t:1528139661947};\\\", \\\"{x:1297,y:977,t:1528139661964};\\\", \\\"{x:1300,y:976,t:1528139661981};\\\", \\\"{x:1303,y:969,t:1528139661997};\\\", \\\"{x:1303,y:967,t:1528139662014};\\\", \\\"{x:1303,y:966,t:1528139662031};\\\", \\\"{x:1304,y:965,t:1528139662124};\\\", \\\"{x:1305,y:965,t:1528139662132};\\\", \\\"{x:1306,y:965,t:1528139662148};\\\", \\\"{x:1307,y:965,t:1528139662165};\\\", \\\"{x:1308,y:965,t:1528139662204};\\\", \\\"{x:1310,y:965,t:1528139662215};\\\", \\\"{x:1311,y:965,t:1528139662232};\\\", \\\"{x:1312,y:965,t:1528139662248};\\\", \\\"{x:1313,y:965,t:1528139662292};\\\", \\\"{x:1314,y:964,t:1528139662573};\\\", \\\"{x:1315,y:964,t:1528139664156};\\\", \\\"{x:1316,y:963,t:1528139670437};\\\", \\\"{x:1315,y:954,t:1528139670444};\\\", \\\"{x:1315,y:944,t:1528139670454};\\\", \\\"{x:1313,y:927,t:1528139670472};\\\", \\\"{x:1309,y:920,t:1528139670489};\\\", \\\"{x:1308,y:915,t:1528139670505};\\\", \\\"{x:1308,y:913,t:1528139670522};\\\", \\\"{x:1308,y:912,t:1528139670539};\\\", \\\"{x:1307,y:911,t:1528139670836};\\\", \\\"{x:1307,y:910,t:1528139670844};\\\", \\\"{x:1308,y:909,t:1528139670856};\\\", \\\"{x:1312,y:909,t:1528139670872};\\\", \\\"{x:1317,y:905,t:1528139670888};\\\", \\\"{x:1319,y:904,t:1528139670905};\\\", \\\"{x:1320,y:902,t:1528139670922};\\\", \\\"{x:1321,y:901,t:1528139670939};\\\", \\\"{x:1322,y:901,t:1528139671300};\\\", \\\"{x:1323,y:903,t:1528139671308};\\\", \\\"{x:1323,y:905,t:1528139671324};\\\", \\\"{x:1323,y:907,t:1528139671340};\\\", \\\"{x:1323,y:913,t:1528139671356};\\\", \\\"{x:1324,y:918,t:1528139671374};\\\", \\\"{x:1324,y:920,t:1528139671389};\\\", \\\"{x:1324,y:924,t:1528139671406};\\\", \\\"{x:1324,y:926,t:1528139671424};\\\", \\\"{x:1324,y:929,t:1528139671439};\\\", \\\"{x:1325,y:931,t:1528139671456};\\\", \\\"{x:1325,y:933,t:1528139671472};\\\", \\\"{x:1325,y:934,t:1528139671488};\\\", \\\"{x:1325,y:936,t:1528139671505};\\\", \\\"{x:1325,y:937,t:1528139671523};\\\", \\\"{x:1325,y:935,t:1528139671701};\\\", \\\"{x:1325,y:933,t:1528139671707};\\\", \\\"{x:1325,y:932,t:1528139671723};\\\", \\\"{x:1325,y:927,t:1528139671739};\\\", \\\"{x:1324,y:926,t:1528139671756};\\\", \\\"{x:1324,y:925,t:1528139671780};\\\", \\\"{x:1323,y:925,t:1528139671861};\\\", \\\"{x:1321,y:927,t:1528139671875};\\\", \\\"{x:1320,y:932,t:1528139671890};\\\", \\\"{x:1319,y:937,t:1528139671905};\\\", \\\"{x:1316,y:943,t:1528139671923};\\\", \\\"{x:1312,y:955,t:1528139671939};\\\", \\\"{x:1308,y:967,t:1528139671956};\\\", \\\"{x:1307,y:973,t:1528139671973};\\\", \\\"{x:1306,y:982,t:1528139671990};\\\", \\\"{x:1304,y:987,t:1528139672006};\\\", \\\"{x:1304,y:989,t:1528139672023};\\\", \\\"{x:1304,y:990,t:1528139672040};\\\", \\\"{x:1303,y:990,t:1528139672057};\\\", \\\"{x:1303,y:991,t:1528139672156};\\\", \\\"{x:1308,y:991,t:1528139672173};\\\", \\\"{x:1321,y:982,t:1528139672190};\\\", \\\"{x:1330,y:974,t:1528139672208};\\\", \\\"{x:1337,y:965,t:1528139672224};\\\", \\\"{x:1339,y:960,t:1528139672241};\\\", \\\"{x:1339,y:957,t:1528139672257};\\\", \\\"{x:1340,y:954,t:1528139672273};\\\", \\\"{x:1340,y:953,t:1528139672387};\\\", \\\"{x:1338,y:953,t:1528139672403};\\\", \\\"{x:1335,y:953,t:1528139672411};\\\", \\\"{x:1332,y:955,t:1528139672424};\\\", \\\"{x:1327,y:956,t:1528139672440};\\\", \\\"{x:1323,y:958,t:1528139672456};\\\", \\\"{x:1320,y:959,t:1528139672473};\\\", \\\"{x:1319,y:960,t:1528139672490};\\\", \\\"{x:1317,y:962,t:1528139672741};\\\", \\\"{x:1316,y:964,t:1528139672758};\\\", \\\"{x:1313,y:969,t:1528139672775};\\\", \\\"{x:1312,y:970,t:1528139672790};\\\", \\\"{x:1312,y:971,t:1528139672812};\\\", \\\"{x:1312,y:970,t:1528139673292};\\\", \\\"{x:1313,y:966,t:1528139673308};\\\", \\\"{x:1314,y:962,t:1528139673324};\\\", \\\"{x:1313,y:962,t:1528139673660};\\\", \\\"{x:1310,y:962,t:1528139673675};\\\", \\\"{x:1306,y:962,t:1528139673691};\\\", \\\"{x:1305,y:962,t:1528139673707};\\\", \\\"{x:1304,y:962,t:1528139673771};\\\", \\\"{x:1303,y:962,t:1528139673779};\\\", \\\"{x:1302,y:962,t:1528139673803};\\\", \\\"{x:1300,y:963,t:1528139673811};\\\", \\\"{x:1299,y:963,t:1528139673835};\\\", \\\"{x:1298,y:964,t:1528139673851};\\\", \\\"{x:1297,y:965,t:1528139673875};\\\", \\\"{x:1294,y:966,t:1528139673891};\\\", \\\"{x:1293,y:966,t:1528139673908};\\\", \\\"{x:1292,y:966,t:1528139673925};\\\", \\\"{x:1291,y:967,t:1528139673941};\\\", \\\"{x:1290,y:967,t:1528139674348};\\\", \\\"{x:1288,y:968,t:1528139674358};\\\", \\\"{x:1284,y:969,t:1528139674376};\\\", \\\"{x:1283,y:970,t:1528139674392};\\\", \\\"{x:1280,y:971,t:1528139674408};\\\", \\\"{x:1276,y:971,t:1528139674425};\\\", \\\"{x:1274,y:972,t:1528139674443};\\\", \\\"{x:1273,y:972,t:1528139674458};\\\", \\\"{x:1272,y:972,t:1528139674652};\\\", \\\"{x:1272,y:971,t:1528139674659};\\\", \\\"{x:1275,y:968,t:1528139674675};\\\", \\\"{x:1279,y:966,t:1528139674692};\\\", \\\"{x:1283,y:963,t:1528139674709};\\\", \\\"{x:1286,y:960,t:1528139674725};\\\", \\\"{x:1284,y:960,t:1528139675188};\\\", \\\"{x:1283,y:960,t:1528139675196};\\\", \\\"{x:1282,y:960,t:1528139675209};\\\", \\\"{x:1281,y:961,t:1528139675226};\\\", \\\"{x:1280,y:961,t:1528139675283};\\\", \\\"{x:1279,y:961,t:1528139675293};\\\", \\\"{x:1278,y:961,t:1528139675309};\\\", \\\"{x:1276,y:960,t:1528139675325};\\\", \\\"{x:1275,y:959,t:1528139675342};\\\", \\\"{x:1275,y:957,t:1528139675358};\\\", \\\"{x:1274,y:956,t:1528139675375};\\\", \\\"{x:1272,y:953,t:1528139675393};\\\", \\\"{x:1270,y:949,t:1528139675408};\\\", \\\"{x:1268,y:942,t:1528139675426};\\\", \\\"{x:1263,y:933,t:1528139675443};\\\", \\\"{x:1261,y:927,t:1528139675459};\\\", \\\"{x:1259,y:925,t:1528139675476};\\\", \\\"{x:1257,y:921,t:1528139675493};\\\", \\\"{x:1257,y:920,t:1528139675539};\\\", \\\"{x:1257,y:919,t:1528139675595};\\\", \\\"{x:1257,y:918,t:1528139675609};\\\", \\\"{x:1255,y:916,t:1528139675627};\\\", \\\"{x:1252,y:910,t:1528139675643};\\\", \\\"{x:1248,y:901,t:1528139675660};\\\", \\\"{x:1243,y:890,t:1528139675677};\\\", \\\"{x:1241,y:885,t:1528139675693};\\\", \\\"{x:1238,y:877,t:1528139675710};\\\", \\\"{x:1235,y:873,t:1528139675727};\\\", \\\"{x:1235,y:872,t:1528139675743};\\\", \\\"{x:1233,y:866,t:1528139675760};\\\", \\\"{x:1231,y:858,t:1528139675777};\\\", \\\"{x:1227,y:844,t:1528139675794};\\\", \\\"{x:1222,y:833,t:1528139675810};\\\", \\\"{x:1221,y:828,t:1528139675826};\\\", \\\"{x:1219,y:818,t:1528139675843};\\\", \\\"{x:1218,y:812,t:1528139675860};\\\", \\\"{x:1217,y:807,t:1528139675876};\\\", \\\"{x:1217,y:806,t:1528139675894};\\\", \\\"{x:1216,y:805,t:1528139675910};\\\", \\\"{x:1214,y:804,t:1528139676020};\\\", \\\"{x:1210,y:805,t:1528139676028};\\\", \\\"{x:1203,y:813,t:1528139676044};\\\", \\\"{x:1201,y:818,t:1528139676060};\\\", \\\"{x:1200,y:822,t:1528139676077};\\\", \\\"{x:1200,y:823,t:1528139676093};\\\", \\\"{x:1200,y:824,t:1528139676110};\\\", \\\"{x:1199,y:825,t:1528139676155};\\\", \\\"{x:1201,y:825,t:1528139676291};\\\", \\\"{x:1202,y:825,t:1528139676644};\\\", \\\"{x:1204,y:825,t:1528139676661};\\\", \\\"{x:1207,y:825,t:1528139676684};\\\", \\\"{x:1207,y:827,t:1528139676892};\\\", \\\"{x:1207,y:828,t:1528139676900};\\\", \\\"{x:1207,y:829,t:1528139676912};\\\", \\\"{x:1207,y:830,t:1528139676927};\\\", \\\"{x:1207,y:831,t:1528139676944};\\\", \\\"{x:1208,y:832,t:1528139677468};\\\", \\\"{x:1209,y:831,t:1528139677791};\\\", \\\"{x:1250,y:807,t:1528139677812};\\\", \\\"{x:1286,y:784,t:1528139677827};\\\", \\\"{x:1357,y:745,t:1528139677843};\\\", \\\"{x:1410,y:709,t:1528139677860};\\\", \\\"{x:1458,y:670,t:1528139677876};\\\", \\\"{x:1500,y:635,t:1528139677893};\\\", \\\"{x:1529,y:602,t:1528139677910};\\\", \\\"{x:1544,y:564,t:1528139677926};\\\", \\\"{x:1548,y:528,t:1528139677943};\\\", \\\"{x:1547,y:490,t:1528139677960};\\\", \\\"{x:1540,y:462,t:1528139677976};\\\", \\\"{x:1524,y:430,t:1528139677993};\\\", \\\"{x:1506,y:377,t:1528139678010};\\\", \\\"{x:1485,y:313,t:1528139678027};\\\", \\\"{x:1473,y:294,t:1528139678043};\\\", \\\"{x:1464,y:291,t:1528139678060};\\\", \\\"{x:1446,y:294,t:1528139678077};\\\", \\\"{x:1423,y:306,t:1528139678093};\\\", \\\"{x:1400,y:321,t:1528139678110};\\\", \\\"{x:1380,y:345,t:1528139678127};\\\", \\\"{x:1365,y:374,t:1528139678142};\\\", \\\"{x:1354,y:400,t:1528139678160};\\\", \\\"{x:1348,y:424,t:1528139678177};\\\", \\\"{x:1347,y:444,t:1528139678193};\\\", \\\"{x:1347,y:461,t:1528139678210};\\\", \\\"{x:1349,y:476,t:1528139678226};\\\", \\\"{x:1351,y:483,t:1528139678243};\\\", \\\"{x:1353,y:486,t:1528139678260};\\\", \\\"{x:1354,y:488,t:1528139678277};\\\", \\\"{x:1354,y:493,t:1528139678293};\\\", \\\"{x:1355,y:501,t:1528139678310};\\\", \\\"{x:1355,y:507,t:1528139678327};\\\", \\\"{x:1355,y:513,t:1528139678343};\\\", \\\"{x:1355,y:515,t:1528139678360};\\\", \\\"{x:1355,y:518,t:1528139678377};\\\", \\\"{x:1353,y:520,t:1528139678393};\\\", \\\"{x:1349,y:522,t:1528139678410};\\\", \\\"{x:1348,y:523,t:1528139678427};\\\", \\\"{x:1346,y:523,t:1528139678443};\\\", \\\"{x:1344,y:523,t:1528139678508};\\\", \\\"{x:1343,y:523,t:1528139678523};\\\", \\\"{x:1341,y:523,t:1528139678532};\\\", \\\"{x:1340,y:522,t:1528139678545};\\\", \\\"{x:1337,y:521,t:1528139678561};\\\", \\\"{x:1336,y:519,t:1528139678578};\\\", \\\"{x:1335,y:518,t:1528139678596};\\\", \\\"{x:1335,y:517,t:1528139678612};\\\", \\\"{x:1333,y:514,t:1528139678628};\\\", \\\"{x:1332,y:513,t:1528139678644};\\\", \\\"{x:1331,y:512,t:1528139678660};\\\", \\\"{x:1330,y:512,t:1528139678677};\\\", \\\"{x:1329,y:511,t:1528139678698};\\\", \\\"{x:1328,y:511,t:1528139678710};\\\", \\\"{x:1327,y:510,t:1528139678727};\\\", \\\"{x:1326,y:510,t:1528139678755};\\\", \\\"{x:1326,y:509,t:1528139678770};\\\", \\\"{x:1325,y:509,t:1528139678779};\\\", \\\"{x:1325,y:508,t:1528139678794};\\\", \\\"{x:1322,y:506,t:1528139678810};\\\", \\\"{x:1321,y:506,t:1528139678827};\\\", \\\"{x:1320,y:505,t:1528139678844};\\\", \\\"{x:1320,y:504,t:1528139678860};\\\", \\\"{x:1319,y:503,t:1528139678883};\\\", \\\"{x:1318,y:503,t:1528139678956};\\\", \\\"{x:1318,y:501,t:1528139678991};\\\", \\\"{x:1318,y:500,t:1528139679010};\\\", \\\"{x:1317,y:500,t:1528139679028};\\\", \\\"{x:1315,y:498,t:1528139679044};\\\", \\\"{x:1315,y:497,t:1528139679061};\\\", \\\"{x:1314,y:496,t:1528139679077};\\\", \\\"{x:1314,y:495,t:1528139681156};\\\", \\\"{x:1314,y:494,t:1528139681172};\\\", \\\"{x:1314,y:492,t:1528139681196};\\\", \\\"{x:1312,y:492,t:1528139682749};\\\", \\\"{x:1288,y:499,t:1528139682766};\\\", \\\"{x:1230,y:522,t:1528139682779};\\\", \\\"{x:1144,y:545,t:1528139682796};\\\", \\\"{x:1044,y:563,t:1528139682815};\\\", \\\"{x:944,y:579,t:1528139682832};\\\", \\\"{x:863,y:589,t:1528139682848};\\\", \\\"{x:804,y:599,t:1528139682866};\\\", \\\"{x:761,y:606,t:1528139682881};\\\", \\\"{x:733,y:613,t:1528139682898};\\\", \\\"{x:716,y:624,t:1528139682915};\\\", \\\"{x:707,y:631,t:1528139682931};\\\", \\\"{x:701,y:635,t:1528139682948};\\\", \\\"{x:700,y:635,t:1528139682965};\\\", \\\"{x:709,y:631,t:1528139683003};\\\", \\\"{x:718,y:627,t:1528139683015};\\\", \\\"{x:737,y:618,t:1528139683031};\\\", \\\"{x:749,y:612,t:1528139683048};\\\", \\\"{x:765,y:605,t:1528139683065};\\\", \\\"{x:782,y:600,t:1528139683081};\\\", \\\"{x:787,y:598,t:1528139683098};\\\", \\\"{x:789,y:596,t:1528139683115};\\\", \\\"{x:790,y:595,t:1528139683147};\\\", \\\"{x:791,y:594,t:1528139683155};\\\", \\\"{x:792,y:593,t:1528139683171};\\\", \\\"{x:794,y:592,t:1528139683182};\\\", \\\"{x:794,y:591,t:1528139683198};\\\", \\\"{x:794,y:590,t:1528139683215};\\\", \\\"{x:794,y:589,t:1528139683232};\\\", \\\"{x:794,y:585,t:1528139683248};\\\", \\\"{x:797,y:578,t:1528139683265};\\\", \\\"{x:804,y:570,t:1528139683281};\\\", \\\"{x:810,y:566,t:1528139683298};\\\", \\\"{x:815,y:563,t:1528139683315};\\\", \\\"{x:817,y:562,t:1528139683332};\\\", \\\"{x:818,y:561,t:1528139683348};\\\", \\\"{x:817,y:562,t:1528139683724};\\\", \\\"{x:815,y:564,t:1528139683733};\\\", \\\"{x:809,y:572,t:1528139683748};\\\", \\\"{x:798,y:580,t:1528139683766};\\\", \\\"{x:785,y:588,t:1528139683784};\\\", \\\"{x:773,y:599,t:1528139683800};\\\", \\\"{x:762,y:617,t:1528139683815};\\\", \\\"{x:751,y:635,t:1528139683832};\\\", \\\"{x:743,y:649,t:1528139683849};\\\", \\\"{x:737,y:658,t:1528139683864};\\\", \\\"{x:737,y:659,t:1528139683882};\\\", \\\"{x:737,y:660,t:1528139683931};\\\", \\\"{x:746,y:657,t:1528139683938};\\\", \\\"{x:752,y:652,t:1528139683949};\\\", \\\"{x:766,y:640,t:1528139683965};\\\", \\\"{x:777,y:625,t:1528139683982};\\\", \\\"{x:786,y:614,t:1528139684000};\\\", \\\"{x:795,y:600,t:1528139684015};\\\", \\\"{x:800,y:593,t:1528139684033};\\\", \\\"{x:802,y:590,t:1528139684049};\\\", \\\"{x:802,y:589,t:1528139684065};\\\", \\\"{x:803,y:589,t:1528139684082};\\\", \\\"{x:805,y:586,t:1528139684099};\\\", \\\"{x:807,y:585,t:1528139684117};\\\", \\\"{x:809,y:583,t:1528139684132};\\\", \\\"{x:809,y:581,t:1528139684149};\\\", \\\"{x:809,y:580,t:1528139684165};\\\", \\\"{x:810,y:579,t:1528139684183};\\\", \\\"{x:812,y:578,t:1528139684199};\\\", \\\"{x:813,y:577,t:1528139684215};\\\", \\\"{x:817,y:574,t:1528139684233};\\\", \\\"{x:820,y:572,t:1528139684249};\\\", \\\"{x:823,y:571,t:1528139684265};\\\", \\\"{x:827,y:568,t:1528139684283};\\\", \\\"{x:828,y:568,t:1528139684299};\\\", \\\"{x:829,y:567,t:1528139684347};\\\", \\\"{x:829,y:566,t:1528139684363};\\\", \\\"{x:830,y:566,t:1528139684379};\\\", \\\"{x:826,y:566,t:1528139684506};\\\", \\\"{x:820,y:569,t:1528139684516};\\\", \\\"{x:811,y:576,t:1528139684533};\\\", \\\"{x:798,y:586,t:1528139684548};\\\", \\\"{x:786,y:592,t:1528139684566};\\\", \\\"{x:775,y:599,t:1528139684584};\\\", \\\"{x:760,y:613,t:1528139684599};\\\", \\\"{x:742,y:626,t:1528139684616};\\\", \\\"{x:726,y:639,t:1528139684634};\\\", \\\"{x:708,y:654,t:1528139684649};\\\", \\\"{x:693,y:666,t:1528139684666};\\\", \\\"{x:674,y:676,t:1528139684684};\\\", \\\"{x:663,y:682,t:1528139684699};\\\", \\\"{x:640,y:692,t:1528139684716};\\\", \\\"{x:613,y:703,t:1528139684734};\\\", \\\"{x:583,y:710,t:1528139684749};\\\", \\\"{x:542,y:719,t:1528139684767};\\\", \\\"{x:506,y:730,t:1528139684782};\\\", \\\"{x:472,y:735,t:1528139684799};\\\", \\\"{x:447,y:741,t:1528139684816};\\\", \\\"{x:435,y:747,t:1528139684833};\\\", \\\"{x:431,y:748,t:1528139684849};\\\", \\\"{x:430,y:748,t:1528139684866};\\\", \\\"{x:429,y:748,t:1528139684907};\\\", \\\"{x:429,y:750,t:1528139684916};\\\", \\\"{x:433,y:755,t:1528139684934};\\\", \\\"{x:444,y:764,t:1528139684951};\\\", \\\"{x:466,y:771,t:1528139684966};\\\", \\\"{x:498,y:783,t:1528139684983};\\\", \\\"{x:529,y:788,t:1528139685000};\\\", \\\"{x:561,y:794,t:1528139685016};\\\", \\\"{x:575,y:796,t:1528139685033};\\\", \\\"{x:579,y:797,t:1528139685050};\\\", \\\"{x:580,y:797,t:1528139685116};\\\", \\\"{x:580,y:794,t:1528139685134};\\\", \\\"{x:577,y:783,t:1528139685150};\\\", \\\"{x:570,y:775,t:1528139685166};\\\", \\\"{x:557,y:766,t:1528139685184};\\\", \\\"{x:552,y:764,t:1528139685201};\\\", \\\"{x:548,y:763,t:1528139685216};\\\", \\\"{x:546,y:762,t:1528139685233};\\\", \\\"{x:543,y:762,t:1528139685250};\\\", \\\"{x:540,y:762,t:1528139685266};\\\", \\\"{x:537,y:762,t:1528139685283};\\\", \\\"{x:537,y:761,t:1528139685522};\\\", \\\"{x:540,y:759,t:1528139685532};\\\", \\\"{x:565,y:749,t:1528139685550};\\\", \\\"{x:616,y:740,t:1528139685566};\\\", \\\"{x:722,y:726,t:1528139685583};\\\", \\\"{x:852,y:707,t:1528139685600};\\\", \\\"{x:1010,y:685,t:1528139685617};\\\", \\\"{x:1186,y:662,t:1528139685633};\\\", \\\"{x:1366,y:640,t:1528139685650};\\\", \\\"{x:1619,y:624,t:1528139685667};\\\", \\\"{x:1753,y:618,t:1528139685683};\\\", \\\"{x:1853,y:616,t:1528139685700};\\\", \\\"{x:1914,y:616,t:1528139685717};\\\", \\\"{x:1919,y:613,t:1528139685733};\\\", \\\"{x:1919,y:612,t:1528139685750};\\\", \\\"{x:1919,y:611,t:1528139685767};\\\" ] }, { \\\"rt\\\": 16448, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 813908, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -G -G -E -I -I -E -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1919,y:610,t:1528139686907};\\\", \\\"{x:1919,y:609,t:1528139686931};\\\", \\\"{x:1919,y:608,t:1528139687108};\\\", \\\"{x:1918,y:607,t:1528139688836};\\\", \\\"{x:1912,y:609,t:1528139688853};\\\", \\\"{x:1906,y:613,t:1528139688870};\\\", \\\"{x:1903,y:614,t:1528139688887};\\\", \\\"{x:1898,y:615,t:1528139688905};\\\", \\\"{x:1896,y:615,t:1528139688919};\\\", \\\"{x:1892,y:616,t:1528139688936};\\\", \\\"{x:1890,y:617,t:1528139688953};\\\", \\\"{x:1885,y:619,t:1528139688969};\\\", \\\"{x:1875,y:622,t:1528139688986};\\\", \\\"{x:1849,y:629,t:1528139689003};\\\", \\\"{x:1826,y:631,t:1528139689019};\\\", \\\"{x:1798,y:631,t:1528139689037};\\\", \\\"{x:1762,y:631,t:1528139689053};\\\", \\\"{x:1715,y:631,t:1528139689069};\\\", \\\"{x:1670,y:631,t:1528139689086};\\\", \\\"{x:1633,y:631,t:1528139689103};\\\", \\\"{x:1588,y:631,t:1528139689121};\\\", \\\"{x:1538,y:631,t:1528139689136};\\\", \\\"{x:1481,y:629,t:1528139689153};\\\", \\\"{x:1397,y:614,t:1528139689169};\\\", \\\"{x:1268,y:584,t:1528139689187};\\\", \\\"{x:1217,y:568,t:1528139689203};\\\", \\\"{x:1164,y:552,t:1528139689220};\\\", \\\"{x:1108,y:536,t:1528139689236};\\\", \\\"{x:1059,y:524,t:1528139689254};\\\", \\\"{x:1030,y:514,t:1528139689271};\\\", \\\"{x:1015,y:509,t:1528139689286};\\\", \\\"{x:1010,y:506,t:1528139689304};\\\", \\\"{x:1004,y:501,t:1528139689321};\\\", \\\"{x:1000,y:497,t:1528139689336};\\\", \\\"{x:998,y:494,t:1528139689354};\\\", \\\"{x:998,y:493,t:1528139689371};\\\", \\\"{x:999,y:491,t:1528139689386};\\\", \\\"{x:1009,y:486,t:1528139689403};\\\", \\\"{x:1017,y:480,t:1528139689421};\\\", \\\"{x:1030,y:474,t:1528139689437};\\\", \\\"{x:1040,y:470,t:1528139689454};\\\", \\\"{x:1049,y:466,t:1528139689471};\\\", \\\"{x:1059,y:460,t:1528139689487};\\\", \\\"{x:1061,y:458,t:1528139689504};\\\", \\\"{x:1061,y:457,t:1528139689521};\\\", \\\"{x:1062,y:457,t:1528139689537};\\\", \\\"{x:1062,y:456,t:1528139689620};\\\", \\\"{x:1064,y:456,t:1528139689667};\\\", \\\"{x:1065,y:456,t:1528139689691};\\\", \\\"{x:1067,y:456,t:1528139689703};\\\", \\\"{x:1071,y:456,t:1528139689720};\\\", \\\"{x:1076,y:460,t:1528139689737};\\\", \\\"{x:1082,y:467,t:1528139689754};\\\", \\\"{x:1096,y:486,t:1528139689770};\\\", \\\"{x:1102,y:495,t:1528139689787};\\\", \\\"{x:1107,y:502,t:1528139689804};\\\", \\\"{x:1112,y:513,t:1528139689821};\\\", \\\"{x:1116,y:526,t:1528139689837};\\\", \\\"{x:1120,y:544,t:1528139689854};\\\", \\\"{x:1127,y:571,t:1528139689870};\\\", \\\"{x:1133,y:596,t:1528139689887};\\\", \\\"{x:1136,y:615,t:1528139689903};\\\", \\\"{x:1137,y:625,t:1528139689921};\\\", \\\"{x:1138,y:633,t:1528139689938};\\\", \\\"{x:1139,y:640,t:1528139689953};\\\", \\\"{x:1140,y:645,t:1528139689970};\\\", \\\"{x:1140,y:646,t:1528139689987};\\\", \\\"{x:1141,y:645,t:1528139690043};\\\", \\\"{x:1142,y:641,t:1528139690055};\\\", \\\"{x:1146,y:629,t:1528139690070};\\\", \\\"{x:1151,y:614,t:1528139690088};\\\", \\\"{x:1158,y:594,t:1528139690104};\\\", \\\"{x:1162,y:582,t:1528139690120};\\\", \\\"{x:1166,y:574,t:1528139690138};\\\", \\\"{x:1172,y:569,t:1528139690154};\\\", \\\"{x:1184,y:563,t:1528139690170};\\\", \\\"{x:1204,y:560,t:1528139690187};\\\", \\\"{x:1214,y:560,t:1528139690205};\\\", \\\"{x:1225,y:560,t:1528139690221};\\\", \\\"{x:1239,y:560,t:1528139690238};\\\", \\\"{x:1258,y:560,t:1528139690255};\\\", \\\"{x:1276,y:558,t:1528139690270};\\\", \\\"{x:1296,y:554,t:1528139690288};\\\", \\\"{x:1312,y:554,t:1528139690305};\\\", \\\"{x:1320,y:554,t:1528139690321};\\\", \\\"{x:1324,y:554,t:1528139690338};\\\", \\\"{x:1332,y:554,t:1528139690355};\\\", \\\"{x:1339,y:554,t:1528139690371};\\\", \\\"{x:1348,y:555,t:1528139690387};\\\", \\\"{x:1356,y:556,t:1528139690404};\\\", \\\"{x:1369,y:557,t:1528139690421};\\\", \\\"{x:1381,y:557,t:1528139690437};\\\", \\\"{x:1393,y:557,t:1528139690455};\\\", \\\"{x:1397,y:557,t:1528139690471};\\\", \\\"{x:1398,y:557,t:1528139690487};\\\", \\\"{x:1400,y:557,t:1528139690620};\\\", \\\"{x:1403,y:557,t:1528139690628};\\\", \\\"{x:1408,y:557,t:1528139690638};\\\", \\\"{x:1415,y:557,t:1528139690655};\\\", \\\"{x:1419,y:557,t:1528139690673};\\\", \\\"{x:1416,y:559,t:1528139690895};\\\", \\\"{x:1416,y:560,t:1528139690905};\\\", \\\"{x:1412,y:563,t:1528139690921};\\\", \\\"{x:1410,y:564,t:1528139690938};\\\", \\\"{x:1410,y:565,t:1528139691131};\\\", \\\"{x:1411,y:565,t:1528139691147};\\\", \\\"{x:1412,y:565,t:1528139691179};\\\", \\\"{x:1413,y:564,t:1528139691188};\\\", \\\"{x:1413,y:563,t:1528139691332};\\\", \\\"{x:1413,y:562,t:1528139691347};\\\", \\\"{x:1414,y:562,t:1528139691355};\\\", \\\"{x:1414,y:560,t:1528139691372};\\\", \\\"{x:1415,y:558,t:1528139691389};\\\", \\\"{x:1416,y:557,t:1528139691407};\\\", \\\"{x:1417,y:555,t:1528139691422};\\\", \\\"{x:1416,y:555,t:1528139691724};\\\", \\\"{x:1416,y:556,t:1528139691739};\\\", \\\"{x:1414,y:562,t:1528139691756};\\\", \\\"{x:1413,y:566,t:1528139691772};\\\", \\\"{x:1411,y:568,t:1528139691790};\\\", \\\"{x:1409,y:571,t:1528139691806};\\\", \\\"{x:1406,y:574,t:1528139691823};\\\", \\\"{x:1399,y:578,t:1528139691839};\\\", \\\"{x:1387,y:585,t:1528139691856};\\\", \\\"{x:1370,y:595,t:1528139691874};\\\", \\\"{x:1352,y:602,t:1528139691889};\\\", \\\"{x:1331,y:611,t:1528139691906};\\\", \\\"{x:1296,y:625,t:1528139691924};\\\", \\\"{x:1263,y:637,t:1528139691940};\\\", \\\"{x:1228,y:643,t:1528139691956};\\\", \\\"{x:1202,y:643,t:1528139691973};\\\", \\\"{x:1182,y:643,t:1528139691989};\\\", \\\"{x:1161,y:643,t:1528139692006};\\\", \\\"{x:1143,y:642,t:1528139692023};\\\", \\\"{x:1132,y:640,t:1528139692039};\\\", \\\"{x:1123,y:636,t:1528139692056};\\\", \\\"{x:1121,y:633,t:1528139692074};\\\", \\\"{x:1118,y:626,t:1528139692089};\\\", \\\"{x:1117,y:616,t:1528139692106};\\\", \\\"{x:1117,y:602,t:1528139692124};\\\", \\\"{x:1120,y:597,t:1528139692140};\\\", \\\"{x:1126,y:594,t:1528139692156};\\\", \\\"{x:1134,y:590,t:1528139692173};\\\", \\\"{x:1141,y:587,t:1528139692190};\\\", \\\"{x:1150,y:585,t:1528139692206};\\\", \\\"{x:1159,y:583,t:1528139692223};\\\", \\\"{x:1169,y:581,t:1528139692241};\\\", \\\"{x:1182,y:579,t:1528139692256};\\\", \\\"{x:1195,y:577,t:1528139692275};\\\", \\\"{x:1213,y:575,t:1528139692290};\\\", \\\"{x:1223,y:575,t:1528139692307};\\\", \\\"{x:1232,y:575,t:1528139692324};\\\", \\\"{x:1238,y:572,t:1528139692339};\\\", \\\"{x:1239,y:572,t:1528139692356};\\\", \\\"{x:1240,y:572,t:1528139692373};\\\", \\\"{x:1242,y:571,t:1528139692390};\\\", \\\"{x:1242,y:570,t:1528139692420};\\\", \\\"{x:1244,y:570,t:1528139692428};\\\", \\\"{x:1245,y:569,t:1528139692440};\\\", \\\"{x:1250,y:568,t:1528139692456};\\\", \\\"{x:1254,y:565,t:1528139692473};\\\", \\\"{x:1259,y:564,t:1528139692490};\\\", \\\"{x:1264,y:562,t:1528139692507};\\\", \\\"{x:1268,y:560,t:1528139692523};\\\", \\\"{x:1269,y:559,t:1528139692540};\\\", \\\"{x:1270,y:558,t:1528139692571};\\\", \\\"{x:1271,y:558,t:1528139692590};\\\", \\\"{x:1272,y:558,t:1528139692607};\\\", \\\"{x:1273,y:558,t:1528139692796};\\\", \\\"{x:1274,y:558,t:1528139692820};\\\", \\\"{x:1275,y:558,t:1528139692843};\\\", \\\"{x:1276,y:558,t:1528139692875};\\\", \\\"{x:1276,y:559,t:1528139692924};\\\", \\\"{x:1277,y:559,t:1528139692988};\\\", \\\"{x:1278,y:560,t:1528139693007};\\\", \\\"{x:1279,y:561,t:1528139693023};\\\", \\\"{x:1281,y:562,t:1528139693040};\\\", \\\"{x:1281,y:563,t:1528139693059};\\\", \\\"{x:1282,y:564,t:1528139693075};\\\", \\\"{x:1283,y:565,t:1528139693147};\\\", \\\"{x:1284,y:565,t:1528139693875};\\\", \\\"{x:1284,y:564,t:1528139693891};\\\", \\\"{x:1284,y:563,t:1528139693907};\\\", \\\"{x:1284,y:562,t:1528139693924};\\\", \\\"{x:1283,y:561,t:1528139693947};\\\", \\\"{x:1282,y:560,t:1528139694196};\\\", \\\"{x:1282,y:559,t:1528139694220};\\\", \\\"{x:1279,y:559,t:1528139694716};\\\", \\\"{x:1272,y:564,t:1528139694726};\\\", \\\"{x:1265,y:567,t:1528139694741};\\\", \\\"{x:1258,y:573,t:1528139694757};\\\", \\\"{x:1252,y:579,t:1528139694774};\\\", \\\"{x:1243,y:587,t:1528139694791};\\\", \\\"{x:1235,y:597,t:1528139694807};\\\", \\\"{x:1226,y:608,t:1528139694825};\\\", \\\"{x:1217,y:620,t:1528139694842};\\\", \\\"{x:1207,y:638,t:1528139694858};\\\", \\\"{x:1196,y:668,t:1528139694874};\\\", \\\"{x:1190,y:681,t:1528139694892};\\\", \\\"{x:1185,y:696,t:1528139694907};\\\", \\\"{x:1182,y:711,t:1528139694925};\\\", \\\"{x:1182,y:733,t:1528139694941};\\\", \\\"{x:1182,y:759,t:1528139694957};\\\", \\\"{x:1182,y:778,t:1528139694975};\\\", \\\"{x:1182,y:793,t:1528139694991};\\\", \\\"{x:1182,y:801,t:1528139695008};\\\", \\\"{x:1181,y:807,t:1528139695024};\\\", \\\"{x:1180,y:810,t:1528139695042};\\\", \\\"{x:1180,y:811,t:1528139695057};\\\", \\\"{x:1179,y:811,t:1528139695099};\\\", \\\"{x:1178,y:811,t:1528139695108};\\\", \\\"{x:1177,y:809,t:1528139695124};\\\", \\\"{x:1176,y:798,t:1528139695141};\\\", \\\"{x:1174,y:788,t:1528139695158};\\\", \\\"{x:1174,y:780,t:1528139695175};\\\", \\\"{x:1174,y:772,t:1528139695191};\\\", \\\"{x:1173,y:767,t:1528139695208};\\\", \\\"{x:1173,y:764,t:1528139695225};\\\", \\\"{x:1172,y:760,t:1528139695241};\\\", \\\"{x:1172,y:758,t:1528139695259};\\\", \\\"{x:1172,y:757,t:1528139695274};\\\", \\\"{x:1172,y:756,t:1528139695292};\\\", \\\"{x:1173,y:755,t:1528139695309};\\\", \\\"{x:1176,y:754,t:1528139695325};\\\", \\\"{x:1178,y:752,t:1528139695341};\\\", \\\"{x:1179,y:752,t:1528139695359};\\\", \\\"{x:1181,y:752,t:1528139695376};\\\", \\\"{x:1184,y:750,t:1528139695392};\\\", \\\"{x:1186,y:750,t:1528139695409};\\\", \\\"{x:1189,y:748,t:1528139695426};\\\", \\\"{x:1193,y:747,t:1528139695443};\\\", \\\"{x:1208,y:740,t:1528139695468};\\\", \\\"{x:1213,y:738,t:1528139695476};\\\", \\\"{x:1246,y:713,t:1528139695512};\\\", \\\"{x:1261,y:694,t:1528139695525};\\\", \\\"{x:1268,y:673,t:1528139695542};\\\", \\\"{x:1275,y:645,t:1528139695559};\\\", \\\"{x:1279,y:620,t:1528139695575};\\\", \\\"{x:1280,y:597,t:1528139695592};\\\", \\\"{x:1281,y:586,t:1528139695608};\\\", \\\"{x:1283,y:576,t:1528139695625};\\\", \\\"{x:1283,y:563,t:1528139695641};\\\", \\\"{x:1283,y:546,t:1528139695659};\\\", \\\"{x:1282,y:539,t:1528139695675};\\\", \\\"{x:1282,y:534,t:1528139695691};\\\", \\\"{x:1282,y:533,t:1528139695708};\\\", \\\"{x:1282,y:532,t:1528139695726};\\\", \\\"{x:1282,y:531,t:1528139695741};\\\", \\\"{x:1282,y:532,t:1528139695843};\\\", \\\"{x:1282,y:541,t:1528139695859};\\\", \\\"{x:1281,y:550,t:1528139695875};\\\", \\\"{x:1279,y:557,t:1528139695892};\\\", \\\"{x:1279,y:561,t:1528139695909};\\\", \\\"{x:1279,y:562,t:1528139695942};\\\", \\\"{x:1279,y:564,t:1528139696004};\\\", \\\"{x:1279,y:565,t:1528139696028};\\\", \\\"{x:1279,y:566,t:1528139696042};\\\", \\\"{x:1278,y:567,t:1528139696748};\\\", \\\"{x:1273,y:568,t:1528139696761};\\\", \\\"{x:1257,y:575,t:1528139696776};\\\", \\\"{x:1242,y:580,t:1528139696793};\\\", \\\"{x:1210,y:583,t:1528139696810};\\\", \\\"{x:1151,y:583,t:1528139696827};\\\", \\\"{x:1010,y:583,t:1528139696844};\\\", \\\"{x:913,y:583,t:1528139696861};\\\", \\\"{x:840,y:583,t:1528139696876};\\\", \\\"{x:779,y:583,t:1528139696892};\\\", \\\"{x:738,y:586,t:1528139696910};\\\", \\\"{x:714,y:589,t:1528139696927};\\\", \\\"{x:702,y:591,t:1528139696942};\\\", \\\"{x:694,y:591,t:1528139696959};\\\", \\\"{x:690,y:593,t:1528139696977};\\\", \\\"{x:686,y:594,t:1528139696993};\\\", \\\"{x:681,y:594,t:1528139697010};\\\", \\\"{x:675,y:595,t:1528139697026};\\\", \\\"{x:672,y:596,t:1528139697042};\\\", \\\"{x:670,y:596,t:1528139697060};\\\", \\\"{x:666,y:597,t:1528139697077};\\\", \\\"{x:662,y:598,t:1528139697092};\\\", \\\"{x:656,y:598,t:1528139697109};\\\", \\\"{x:651,y:598,t:1528139697126};\\\", \\\"{x:642,y:598,t:1528139697143};\\\", \\\"{x:632,y:598,t:1528139697159};\\\", \\\"{x:619,y:598,t:1528139697176};\\\", \\\"{x:600,y:598,t:1528139697192};\\\", \\\"{x:588,y:598,t:1528139697209};\\\", \\\"{x:569,y:598,t:1528139697226};\\\", \\\"{x:547,y:598,t:1528139697244};\\\", \\\"{x:523,y:598,t:1528139697259};\\\", \\\"{x:490,y:602,t:1528139697277};\\\", \\\"{x:467,y:604,t:1528139697293};\\\", \\\"{x:441,y:604,t:1528139697310};\\\", \\\"{x:416,y:604,t:1528139697326};\\\", \\\"{x:393,y:604,t:1528139697344};\\\", \\\"{x:372,y:604,t:1528139697360};\\\", \\\"{x:354,y:604,t:1528139697376};\\\", \\\"{x:344,y:604,t:1528139697394};\\\", \\\"{x:336,y:601,t:1528139697409};\\\", \\\"{x:328,y:593,t:1528139697427};\\\", \\\"{x:324,y:587,t:1528139697443};\\\", \\\"{x:320,y:581,t:1528139697459};\\\", \\\"{x:319,y:578,t:1528139697476};\\\", \\\"{x:319,y:575,t:1528139697493};\\\", \\\"{x:319,y:570,t:1528139697510};\\\", \\\"{x:322,y:566,t:1528139697527};\\\", \\\"{x:327,y:562,t:1528139697544};\\\", \\\"{x:333,y:559,t:1528139697559};\\\", \\\"{x:339,y:556,t:1528139697576};\\\", \\\"{x:352,y:549,t:1528139697595};\\\", \\\"{x:365,y:544,t:1528139697610};\\\", \\\"{x:373,y:540,t:1528139697626};\\\", \\\"{x:375,y:540,t:1528139697643};\\\", \\\"{x:375,y:539,t:1528139699179};\\\", \\\"{x:377,y:538,t:1528139699195};\\\", \\\"{x:378,y:537,t:1528139699220};\\\", \\\"{x:379,y:537,t:1528139700099};\\\", \\\"{x:379,y:541,t:1528139700115};\\\", \\\"{x:378,y:544,t:1528139700129};\\\", \\\"{x:378,y:548,t:1528139700146};\\\", \\\"{x:377,y:551,t:1528139700162};\\\", \\\"{x:377,y:556,t:1528139700181};\\\", \\\"{x:377,y:558,t:1528139700196};\\\", \\\"{x:377,y:559,t:1528139700266};\\\", \\\"{x:377,y:560,t:1528139700278};\\\", \\\"{x:377,y:561,t:1528139700296};\\\", \\\"{x:377,y:562,t:1528139700312};\\\", \\\"{x:380,y:562,t:1528139700330};\\\", \\\"{x:391,y:562,t:1528139700346};\\\", \\\"{x:421,y:562,t:1528139700362};\\\", \\\"{x:453,y:562,t:1528139700379};\\\", \\\"{x:503,y:562,t:1528139700396};\\\", \\\"{x:543,y:562,t:1528139700412};\\\", \\\"{x:583,y:555,t:1528139700431};\\\", \\\"{x:610,y:549,t:1528139700446};\\\", \\\"{x:624,y:546,t:1528139700463};\\\", \\\"{x:629,y:544,t:1528139700478};\\\", \\\"{x:629,y:543,t:1528139700496};\\\", \\\"{x:629,y:541,t:1528139700513};\\\", \\\"{x:631,y:539,t:1528139700528};\\\", \\\"{x:631,y:537,t:1528139700545};\\\", \\\"{x:635,y:530,t:1528139700562};\\\", \\\"{x:635,y:527,t:1528139700579};\\\", \\\"{x:636,y:523,t:1528139700596};\\\", \\\"{x:636,y:518,t:1528139700612};\\\", \\\"{x:637,y:512,t:1528139700630};\\\", \\\"{x:637,y:506,t:1528139700645};\\\", \\\"{x:638,y:504,t:1528139700662};\\\", \\\"{x:639,y:500,t:1528139700679};\\\", \\\"{x:639,y:497,t:1528139700695};\\\", \\\"{x:639,y:496,t:1528139700712};\\\", \\\"{x:639,y:494,t:1528139700730};\\\", \\\"{x:639,y:491,t:1528139700746};\\\", \\\"{x:636,y:489,t:1528139700763};\\\", \\\"{x:634,y:489,t:1528139700780};\\\", \\\"{x:633,y:488,t:1528139700796};\\\", \\\"{x:630,y:488,t:1528139700813};\\\", \\\"{x:629,y:488,t:1528139700830};\\\", \\\"{x:628,y:488,t:1528139700846};\\\", \\\"{x:627,y:489,t:1528139700862};\\\", \\\"{x:625,y:490,t:1528139700880};\\\", \\\"{x:623,y:491,t:1528139700896};\\\", \\\"{x:621,y:491,t:1528139700913};\\\", \\\"{x:619,y:492,t:1528139700929};\\\", \\\"{x:617,y:493,t:1528139700946};\\\", \\\"{x:616,y:494,t:1528139700963};\\\", \\\"{x:614,y:494,t:1528139700980};\\\", \\\"{x:613,y:494,t:1528139700996};\\\", \\\"{x:612,y:496,t:1528139701227};\\\", \\\"{x:607,y:501,t:1528139701234};\\\", \\\"{x:598,y:505,t:1528139701247};\\\", \\\"{x:580,y:513,t:1528139701264};\\\", \\\"{x:553,y:520,t:1528139701280};\\\", \\\"{x:517,y:531,t:1528139701297};\\\", \\\"{x:480,y:543,t:1528139701314};\\\", \\\"{x:448,y:553,t:1528139701329};\\\", \\\"{x:397,y:574,t:1528139701347};\\\", \\\"{x:354,y:583,t:1528139701363};\\\", \\\"{x:313,y:586,t:1528139701380};\\\", \\\"{x:286,y:586,t:1528139701396};\\\", \\\"{x:276,y:586,t:1528139701412};\\\", \\\"{x:272,y:586,t:1528139701430};\\\", \\\"{x:271,y:586,t:1528139701490};\\\", \\\"{x:270,y:586,t:1528139701507};\\\", \\\"{x:269,y:586,t:1528139701522};\\\", \\\"{x:267,y:586,t:1528139701530};\\\", \\\"{x:266,y:586,t:1528139701546};\\\", \\\"{x:264,y:586,t:1528139701563};\\\", \\\"{x:273,y:585,t:1528139701629};\\\", \\\"{x:297,y:579,t:1528139701647};\\\", \\\"{x:343,y:577,t:1528139701663};\\\", \\\"{x:405,y:577,t:1528139701680};\\\", \\\"{x:488,y:577,t:1528139701697};\\\", \\\"{x:570,y:571,t:1528139701715};\\\", \\\"{x:648,y:571,t:1528139701730};\\\", \\\"{x:734,y:571,t:1528139701747};\\\", \\\"{x:774,y:571,t:1528139701764};\\\", \\\"{x:797,y:571,t:1528139701780};\\\", \\\"{x:810,y:571,t:1528139701796};\\\", \\\"{x:817,y:571,t:1528139701814};\\\", \\\"{x:823,y:570,t:1528139701830};\\\", \\\"{x:829,y:570,t:1528139701847};\\\", \\\"{x:836,y:569,t:1528139701863};\\\", \\\"{x:840,y:566,t:1528139701880};\\\", \\\"{x:846,y:565,t:1528139701897};\\\", \\\"{x:854,y:561,t:1528139701914};\\\", \\\"{x:858,y:558,t:1528139701930};\\\", \\\"{x:860,y:557,t:1528139701947};\\\", \\\"{x:861,y:557,t:1528139701964};\\\", \\\"{x:861,y:556,t:1528139701987};\\\", \\\"{x:861,y:555,t:1528139702013};\\\", \\\"{x:861,y:554,t:1528139702031};\\\", \\\"{x:861,y:552,t:1528139702047};\\\", \\\"{x:860,y:551,t:1528139702064};\\\", \\\"{x:860,y:549,t:1528139702081};\\\", \\\"{x:857,y:547,t:1528139702097};\\\", \\\"{x:855,y:544,t:1528139702114};\\\", \\\"{x:846,y:539,t:1528139702130};\\\", \\\"{x:843,y:537,t:1528139702146};\\\", \\\"{x:842,y:536,t:1528139702163};\\\", \\\"{x:840,y:536,t:1528139702378};\\\", \\\"{x:834,y:536,t:1528139702386};\\\", \\\"{x:824,y:544,t:1528139702397};\\\", \\\"{x:807,y:558,t:1528139702414};\\\", \\\"{x:795,y:574,t:1528139702430};\\\", \\\"{x:785,y:593,t:1528139702447};\\\", \\\"{x:773,y:615,t:1528139702464};\\\", \\\"{x:754,y:637,t:1528139702481};\\\", \\\"{x:739,y:649,t:1528139702498};\\\", \\\"{x:724,y:661,t:1528139702513};\\\", \\\"{x:702,y:678,t:1528139702530};\\\", \\\"{x:689,y:688,t:1528139702548};\\\", \\\"{x:674,y:697,t:1528139702564};\\\", \\\"{x:657,y:707,t:1528139702580};\\\", \\\"{x:639,y:718,t:1528139702597};\\\", \\\"{x:620,y:726,t:1528139702614};\\\", \\\"{x:603,y:730,t:1528139702630};\\\", \\\"{x:592,y:736,t:1528139702647};\\\", \\\"{x:582,y:739,t:1528139702664};\\\", \\\"{x:574,y:741,t:1528139702680};\\\", \\\"{x:569,y:742,t:1528139702697};\\\", \\\"{x:568,y:743,t:1528139702714};\\\", \\\"{x:566,y:743,t:1528139702731};\\\", \\\"{x:564,y:744,t:1528139702821};\\\", \\\"{x:562,y:744,t:1528139702842};\\\", \\\"{x:561,y:745,t:1528139702850};\\\", \\\"{x:560,y:745,t:1528139702864};\\\", \\\"{x:551,y:745,t:1528139702881};\\\", \\\"{x:533,y:745,t:1528139702897};\\\", \\\"{x:518,y:745,t:1528139702914};\\\", \\\"{x:514,y:745,t:1528139702930};\\\", \\\"{x:513,y:745,t:1528139702947};\\\", \\\"{x:512,y:745,t:1528139702970};\\\", \\\"{x:513,y:745,t:1528139703202};\\\", \\\"{x:519,y:744,t:1528139703214};\\\", \\\"{x:544,y:740,t:1528139703232};\\\", \\\"{x:582,y:740,t:1528139703248};\\\", \\\"{x:628,y:737,t:1528139703264};\\\", \\\"{x:678,y:731,t:1528139703282};\\\", \\\"{x:734,y:731,t:1528139703298};\\\", \\\"{x:842,y:731,t:1528139703314};\\\", \\\"{x:918,y:731,t:1528139703332};\\\", \\\"{x:1009,y:731,t:1528139703348};\\\", \\\"{x:1106,y:731,t:1528139703365};\\\", \\\"{x:1195,y:731,t:1528139703382};\\\", \\\"{x:1262,y:731,t:1528139703398};\\\", \\\"{x:1299,y:724,t:1528139703415};\\\", \\\"{x:1320,y:720,t:1528139703432};\\\", \\\"{x:1337,y:716,t:1528139703448};\\\", \\\"{x:1346,y:715,t:1528139703464};\\\", \\\"{x:1348,y:715,t:1528139703587};\\\", \\\"{x:1349,y:715,t:1528139703602};\\\", \\\"{x:1349,y:714,t:1528139703619};\\\", \\\"{x:1351,y:712,t:1528139704235};\\\", \\\"{x:1353,y:711,t:1528139704249};\\\" ] }, { \\\"rt\\\": 12815, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 827979, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1532,y:646,t:1528139704371};\\\", \\\"{x:1643,y:617,t:1528139704399};\\\", \\\"{x:1726,y:595,t:1528139704416};\\\", \\\"{x:1801,y:573,t:1528139704432};\\\", \\\"{x:1873,y:553,t:1528139704448};\\\", \\\"{x:1919,y:543,t:1528139704466};\\\", \\\"{x:1919,y:539,t:1528139704482};\\\", \\\"{x:1918,y:539,t:1528139704634};\\\", \\\"{x:1917,y:540,t:1528139704649};\\\", \\\"{x:1914,y:542,t:1528139704666};\\\", \\\"{x:1912,y:542,t:1528139704715};\\\", \\\"{x:1909,y:545,t:1528139704844};\\\", \\\"{x:1908,y:545,t:1528139704870};\\\", \\\"{x:1907,y:546,t:1528139704883};\\\", \\\"{x:1901,y:546,t:1528139710428};\\\", \\\"{x:1888,y:546,t:1528139710439};\\\", \\\"{x:1862,y:543,t:1528139710453};\\\", \\\"{x:1836,y:539,t:1528139710470};\\\", \\\"{x:1804,y:536,t:1528139710487};\\\", \\\"{x:1776,y:532,t:1528139710503};\\\", \\\"{x:1745,y:527,t:1528139710520};\\\", \\\"{x:1716,y:526,t:1528139710537};\\\", \\\"{x:1677,y:520,t:1528139710554};\\\", \\\"{x:1666,y:520,t:1528139710570};\\\", \\\"{x:1663,y:520,t:1528139710587};\\\", \\\"{x:1662,y:520,t:1528139710610};\\\", \\\"{x:1660,y:520,t:1528139710620};\\\", \\\"{x:1656,y:521,t:1528139710637};\\\", \\\"{x:1650,y:523,t:1528139710654};\\\", \\\"{x:1640,y:528,t:1528139710670};\\\", \\\"{x:1627,y:537,t:1528139710687};\\\", \\\"{x:1607,y:552,t:1528139710705};\\\", \\\"{x:1592,y:572,t:1528139710721};\\\", \\\"{x:1580,y:588,t:1528139710737};\\\", \\\"{x:1559,y:604,t:1528139710754};\\\", \\\"{x:1542,y:611,t:1528139710770};\\\", \\\"{x:1525,y:617,t:1528139710787};\\\", \\\"{x:1509,y:622,t:1528139710804};\\\", \\\"{x:1499,y:626,t:1528139710820};\\\", \\\"{x:1495,y:628,t:1528139710837};\\\", \\\"{x:1493,y:630,t:1528139710854};\\\", \\\"{x:1490,y:631,t:1528139710871};\\\", \\\"{x:1484,y:631,t:1528139710887};\\\", \\\"{x:1467,y:631,t:1528139710904};\\\", \\\"{x:1441,y:631,t:1528139710920};\\\", \\\"{x:1420,y:631,t:1528139710937};\\\", \\\"{x:1395,y:633,t:1528139710955};\\\", \\\"{x:1382,y:636,t:1528139710970};\\\", \\\"{x:1371,y:639,t:1528139710987};\\\", \\\"{x:1362,y:640,t:1528139711004};\\\", \\\"{x:1359,y:641,t:1528139711021};\\\", \\\"{x:1360,y:641,t:1528139711115};\\\", \\\"{x:1364,y:641,t:1528139711123};\\\", \\\"{x:1366,y:641,t:1528139711137};\\\", \\\"{x:1374,y:639,t:1528139711155};\\\", \\\"{x:1379,y:639,t:1528139711171};\\\", \\\"{x:1389,y:639,t:1528139711187};\\\", \\\"{x:1402,y:639,t:1528139711205};\\\", \\\"{x:1413,y:639,t:1528139711222};\\\", \\\"{x:1425,y:639,t:1528139711238};\\\", \\\"{x:1440,y:639,t:1528139711255};\\\", \\\"{x:1451,y:639,t:1528139711271};\\\", \\\"{x:1459,y:638,t:1528139711288};\\\", \\\"{x:1465,y:635,t:1528139711305};\\\", \\\"{x:1467,y:634,t:1528139711322};\\\", \\\"{x:1469,y:634,t:1528139711338};\\\", \\\"{x:1471,y:632,t:1528139711363};\\\", \\\"{x:1471,y:631,t:1528139711483};\\\", \\\"{x:1469,y:630,t:1528139711500};\\\", \\\"{x:1466,y:630,t:1528139711507};\\\", \\\"{x:1463,y:629,t:1528139711522};\\\", \\\"{x:1455,y:628,t:1528139711539};\\\", \\\"{x:1452,y:628,t:1528139711558};\\\", \\\"{x:1449,y:628,t:1528139711571};\\\", \\\"{x:1444,y:628,t:1528139712019};\\\", \\\"{x:1432,y:628,t:1528139712029};\\\", \\\"{x:1413,y:625,t:1528139712039};\\\", \\\"{x:1353,y:614,t:1528139712055};\\\", \\\"{x:1272,y:603,t:1528139712071};\\\", \\\"{x:1178,y:589,t:1528139712088};\\\", \\\"{x:1080,y:574,t:1528139712105};\\\", \\\"{x:989,y:560,t:1528139712121};\\\", \\\"{x:851,y:541,t:1528139712139};\\\", \\\"{x:787,y:533,t:1528139712156};\\\", \\\"{x:741,y:528,t:1528139712171};\\\", \\\"{x:708,y:528,t:1528139712188};\\\", \\\"{x:681,y:528,t:1528139712205};\\\", \\\"{x:659,y:528,t:1528139712222};\\\", \\\"{x:638,y:529,t:1528139712240};\\\", \\\"{x:617,y:531,t:1528139712256};\\\", \\\"{x:594,y:535,t:1528139712272};\\\", \\\"{x:573,y:540,t:1528139712289};\\\", \\\"{x:557,y:546,t:1528139712305};\\\", \\\"{x:535,y:556,t:1528139712322};\\\", \\\"{x:521,y:560,t:1528139712339};\\\", \\\"{x:507,y:563,t:1528139712356};\\\", \\\"{x:495,y:566,t:1528139712372};\\\", \\\"{x:490,y:567,t:1528139712389};\\\", \\\"{x:489,y:567,t:1528139712450};\\\", \\\"{x:486,y:567,t:1528139712458};\\\", \\\"{x:484,y:567,t:1528139712472};\\\", \\\"{x:481,y:567,t:1528139712489};\\\", \\\"{x:477,y:566,t:1528139712506};\\\", \\\"{x:475,y:564,t:1528139712522};\\\", \\\"{x:470,y:560,t:1528139712540};\\\", \\\"{x:455,y:557,t:1528139712556};\\\", \\\"{x:432,y:556,t:1528139712572};\\\", \\\"{x:413,y:556,t:1528139712589};\\\", \\\"{x:395,y:556,t:1528139712606};\\\", \\\"{x:376,y:556,t:1528139712622};\\\", \\\"{x:358,y:556,t:1528139712639};\\\", \\\"{x:342,y:556,t:1528139712657};\\\", \\\"{x:324,y:556,t:1528139712672};\\\", \\\"{x:302,y:557,t:1528139712689};\\\", \\\"{x:277,y:565,t:1528139712707};\\\", \\\"{x:265,y:566,t:1528139712723};\\\", \\\"{x:247,y:570,t:1528139712739};\\\", \\\"{x:225,y:575,t:1528139712755};\\\", \\\"{x:206,y:577,t:1528139712772};\\\", \\\"{x:189,y:577,t:1528139712789};\\\", \\\"{x:175,y:580,t:1528139712806};\\\", \\\"{x:161,y:584,t:1528139712822};\\\", \\\"{x:154,y:587,t:1528139712839};\\\", \\\"{x:150,y:588,t:1528139712856};\\\", \\\"{x:149,y:589,t:1528139712890};\\\", \\\"{x:149,y:588,t:1528139713091};\\\", \\\"{x:152,y:583,t:1528139713106};\\\", \\\"{x:163,y:575,t:1528139713122};\\\", \\\"{x:168,y:569,t:1528139713139};\\\", \\\"{x:170,y:567,t:1528139713157};\\\", \\\"{x:171,y:566,t:1528139713402};\\\", \\\"{x:169,y:566,t:1528139713450};\\\", \\\"{x:172,y:563,t:1528139713826};\\\", \\\"{x:176,y:562,t:1528139713840};\\\", \\\"{x:190,y:555,t:1528139713858};\\\", \\\"{x:199,y:552,t:1528139713873};\\\", \\\"{x:219,y:546,t:1528139713890};\\\", \\\"{x:230,y:542,t:1528139713907};\\\", \\\"{x:239,y:539,t:1528139713923};\\\", \\\"{x:247,y:539,t:1528139713940};\\\", \\\"{x:255,y:538,t:1528139713957};\\\", \\\"{x:259,y:538,t:1528139713973};\\\", \\\"{x:262,y:538,t:1528139713990};\\\", \\\"{x:263,y:538,t:1528139714034};\\\", \\\"{x:263,y:540,t:1528139714066};\\\", \\\"{x:262,y:543,t:1528139714074};\\\", \\\"{x:260,y:548,t:1528139714090};\\\", \\\"{x:258,y:553,t:1528139714108};\\\", \\\"{x:257,y:558,t:1528139714123};\\\", \\\"{x:252,y:566,t:1528139714141};\\\", \\\"{x:250,y:572,t:1528139714157};\\\", \\\"{x:247,y:577,t:1528139714173};\\\", \\\"{x:242,y:583,t:1528139714190};\\\", \\\"{x:238,y:586,t:1528139714207};\\\", \\\"{x:234,y:591,t:1528139714224};\\\", \\\"{x:231,y:594,t:1528139714240};\\\", \\\"{x:227,y:597,t:1528139714257};\\\", \\\"{x:224,y:601,t:1528139714274};\\\", \\\"{x:223,y:601,t:1528139714330};\\\", \\\"{x:221,y:601,t:1528139714354};\\\", \\\"{x:223,y:601,t:1528139714410};\\\", \\\"{x:225,y:601,t:1528139714424};\\\", \\\"{x:231,y:602,t:1528139714440};\\\", \\\"{x:238,y:602,t:1528139714458};\\\", \\\"{x:254,y:602,t:1528139714474};\\\", \\\"{x:273,y:602,t:1528139714492};\\\", \\\"{x:297,y:602,t:1528139714507};\\\", \\\"{x:320,y:602,t:1528139714524};\\\", \\\"{x:346,y:602,t:1528139714540};\\\", \\\"{x:373,y:602,t:1528139714557};\\\", \\\"{x:391,y:602,t:1528139714574};\\\", \\\"{x:407,y:602,t:1528139714590};\\\", \\\"{x:423,y:602,t:1528139714607};\\\", \\\"{x:432,y:598,t:1528139714624};\\\", \\\"{x:439,y:597,t:1528139714640};\\\", \\\"{x:442,y:595,t:1528139714657};\\\", \\\"{x:446,y:592,t:1528139714674};\\\", \\\"{x:453,y:588,t:1528139714691};\\\", \\\"{x:464,y:584,t:1528139714707};\\\", \\\"{x:480,y:577,t:1528139714724};\\\", \\\"{x:496,y:570,t:1528139714741};\\\", \\\"{x:513,y:563,t:1528139714758};\\\", \\\"{x:528,y:556,t:1528139714774};\\\", \\\"{x:544,y:550,t:1528139714791};\\\", \\\"{x:559,y:543,t:1528139714807};\\\", \\\"{x:575,y:536,t:1528139714824};\\\", \\\"{x:587,y:532,t:1528139714841};\\\", \\\"{x:593,y:527,t:1528139714857};\\\", \\\"{x:615,y:520,t:1528139714874};\\\", \\\"{x:635,y:518,t:1528139714891};\\\", \\\"{x:661,y:515,t:1528139714908};\\\", \\\"{x:683,y:515,t:1528139714924};\\\", \\\"{x:702,y:515,t:1528139714941};\\\", \\\"{x:720,y:515,t:1528139714957};\\\", \\\"{x:739,y:515,t:1528139714975};\\\", \\\"{x:760,y:517,t:1528139714991};\\\", \\\"{x:778,y:521,t:1528139715007};\\\", \\\"{x:794,y:523,t:1528139715024};\\\", \\\"{x:807,y:526,t:1528139715041};\\\", \\\"{x:817,y:530,t:1528139715057};\\\", \\\"{x:829,y:533,t:1528139715075};\\\", \\\"{x:831,y:534,t:1528139715091};\\\", \\\"{x:832,y:535,t:1528139715146};\\\", \\\"{x:834,y:539,t:1528139715162};\\\", \\\"{x:834,y:542,t:1528139715174};\\\", \\\"{x:834,y:547,t:1528139715191};\\\", \\\"{x:834,y:552,t:1528139715209};\\\", \\\"{x:834,y:555,t:1528139715224};\\\", \\\"{x:834,y:557,t:1528139715242};\\\", \\\"{x:830,y:564,t:1528139715258};\\\", \\\"{x:825,y:571,t:1528139715274};\\\", \\\"{x:819,y:576,t:1528139715291};\\\", \\\"{x:810,y:582,t:1528139715307};\\\", \\\"{x:800,y:587,t:1528139715324};\\\", \\\"{x:787,y:591,t:1528139715341};\\\", \\\"{x:768,y:594,t:1528139715358};\\\", \\\"{x:751,y:596,t:1528139715374};\\\", \\\"{x:737,y:597,t:1528139715391};\\\", \\\"{x:719,y:597,t:1528139715408};\\\", \\\"{x:700,y:597,t:1528139715425};\\\", \\\"{x:680,y:597,t:1528139715441};\\\", \\\"{x:660,y:597,t:1528139715458};\\\", \\\"{x:655,y:597,t:1528139715475};\\\", \\\"{x:653,y:597,t:1528139715493};\\\", \\\"{x:648,y:597,t:1528139715508};\\\", \\\"{x:644,y:597,t:1528139715525};\\\", \\\"{x:640,y:597,t:1528139715542};\\\", \\\"{x:638,y:597,t:1528139715558};\\\", \\\"{x:636,y:599,t:1528139715576};\\\", \\\"{x:633,y:602,t:1528139715593};\\\", \\\"{x:630,y:606,t:1528139715609};\\\", \\\"{x:629,y:610,t:1528139715625};\\\", \\\"{x:629,y:611,t:1528139715650};\\\", \\\"{x:628,y:612,t:1528139715682};\\\", \\\"{x:628,y:613,t:1528139715691};\\\", \\\"{x:627,y:614,t:1528139715708};\\\", \\\"{x:625,y:614,t:1528139715731};\\\", \\\"{x:624,y:615,t:1528139715741};\\\", \\\"{x:621,y:617,t:1528139715758};\\\", \\\"{x:620,y:618,t:1528139715775};\\\", \\\"{x:619,y:618,t:1528139715803};\\\", \\\"{x:618,y:618,t:1528139715811};\\\", \\\"{x:617,y:620,t:1528139715825};\\\", \\\"{x:615,y:620,t:1528139715842};\\\", \\\"{x:614,y:621,t:1528139715858};\\\", \\\"{x:612,y:621,t:1528139716072};\\\", \\\"{x:611,y:621,t:1528139716104};\\\", \\\"{x:610,y:619,t:1528139716135};\\\", \\\"{x:607,y:620,t:1528139716415};\\\", \\\"{x:598,y:624,t:1528139716430};\\\", \\\"{x:578,y:642,t:1528139716446};\\\", \\\"{x:564,y:653,t:1528139716464};\\\", \\\"{x:545,y:661,t:1528139716479};\\\", \\\"{x:532,y:669,t:1528139716496};\\\", \\\"{x:522,y:674,t:1528139716513};\\\", \\\"{x:518,y:680,t:1528139716530};\\\", \\\"{x:517,y:680,t:1528139716546};\\\", \\\"{x:517,y:681,t:1528139716564};\\\", \\\"{x:516,y:682,t:1528139716579};\\\", \\\"{x:516,y:684,t:1528139716597};\\\", \\\"{x:516,y:685,t:1528139716614};\\\", \\\"{x:516,y:687,t:1528139716631};\\\", \\\"{x:516,y:689,t:1528139716646};\\\", \\\"{x:516,y:691,t:1528139716663};\\\", \\\"{x:516,y:694,t:1528139716680};\\\", \\\"{x:516,y:695,t:1528139716718};\\\", \\\"{x:516,y:696,t:1528139716759};\\\", \\\"{x:516,y:698,t:1528139716767};\\\", \\\"{x:516,y:700,t:1528139716779};\\\", \\\"{x:519,y:703,t:1528139716797};\\\", \\\"{x:521,y:707,t:1528139716814};\\\", \\\"{x:522,y:709,t:1528139716830};\\\", \\\"{x:523,y:711,t:1528139716847};\\\", \\\"{x:524,y:715,t:1528139716864};\\\", \\\"{x:524,y:719,t:1528139716880};\\\", \\\"{x:526,y:722,t:1528139716898};\\\", \\\"{x:527,y:723,t:1528139716914};\\\", \\\"{x:528,y:726,t:1528139716929};\\\", \\\"{x:528,y:727,t:1528139716958};\\\", \\\"{x:528,y:728,t:1528139716966};\\\", \\\"{x:529,y:729,t:1528139716982};\\\", \\\"{x:530,y:728,t:1528139717262};\\\", \\\"{x:535,y:726,t:1528139717270};\\\", \\\"{x:540,y:722,t:1528139717281};\\\", \\\"{x:553,y:711,t:1528139717297};\\\", \\\"{x:570,y:700,t:1528139717314};\\\", \\\"{x:587,y:693,t:1528139717331};\\\", \\\"{x:600,y:688,t:1528139717348};\\\", \\\"{x:609,y:686,t:1528139717363};\\\", \\\"{x:618,y:683,t:1528139717381};\\\", \\\"{x:625,y:682,t:1528139717397};\\\", \\\"{x:633,y:681,t:1528139717413};\\\", \\\"{x:645,y:678,t:1528139717431};\\\", \\\"{x:659,y:678,t:1528139717447};\\\", \\\"{x:676,y:675,t:1528139717464};\\\", \\\"{x:693,y:667,t:1528139717482};\\\", \\\"{x:708,y:661,t:1528139717497};\\\", \\\"{x:721,y:658,t:1528139717514};\\\", \\\"{x:738,y:655,t:1528139717531};\\\", \\\"{x:758,y:652,t:1528139717547};\\\", \\\"{x:779,y:645,t:1528139717564};\\\", \\\"{x:796,y:641,t:1528139717581};\\\", \\\"{x:806,y:640,t:1528139717597};\\\", \\\"{x:815,y:638,t:1528139717614};\\\", \\\"{x:822,y:637,t:1528139717630};\\\", \\\"{x:826,y:637,t:1528139717648};\\\", \\\"{x:827,y:637,t:1528139717664};\\\", \\\"{x:828,y:637,t:1528139717680};\\\", \\\"{x:829,y:637,t:1528139717767};\\\", \\\"{x:830,y:638,t:1528139717783};\\\", \\\"{x:830,y:639,t:1528139717839};\\\", \\\"{x:830,y:640,t:1528139717879};\\\", \\\"{x:831,y:637,t:1528139718064};\\\", \\\"{x:833,y:635,t:1528139718071};\\\", \\\"{x:834,y:633,t:1528139718082};\\\", \\\"{x:838,y:626,t:1528139718098};\\\", \\\"{x:841,y:621,t:1528139718115};\\\", \\\"{x:843,y:616,t:1528139718132};\\\", \\\"{x:845,y:610,t:1528139718148};\\\", \\\"{x:847,y:606,t:1528139718165};\\\", \\\"{x:849,y:603,t:1528139718182};\\\", \\\"{x:853,y:594,t:1528139718249};\\\", \\\"{x:853,y:592,t:1528139718265};\\\", \\\"{x:854,y:587,t:1528139718281};\\\", \\\"{x:855,y:585,t:1528139718298};\\\", \\\"{x:855,y:582,t:1528139718315};\\\", \\\"{x:856,y:581,t:1528139718331};\\\", \\\"{x:856,y:579,t:1528139718349};\\\", \\\"{x:856,y:577,t:1528139718365};\\\" ] }, { \\\"rt\\\": 29779, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 859048, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:853,y:558,t:1528139718476};\\\", \\\"{x:852,y:555,t:1528139718485};\\\", \\\"{x:850,y:548,t:1528139718516};\\\", \\\"{x:848,y:545,t:1528139718531};\\\", \\\"{x:847,y:541,t:1528139718548};\\\", \\\"{x:844,y:537,t:1528139718568};\\\", \\\"{x:843,y:535,t:1528139718581};\\\", \\\"{x:842,y:534,t:1528139718598};\\\", \\\"{x:841,y:533,t:1528139718622};\\\", \\\"{x:841,y:532,t:1528139718974};\\\", \\\"{x:841,y:531,t:1528139719135};\\\", \\\"{x:841,y:530,t:1528139719147};\\\", \\\"{x:841,y:529,t:1528139719263};\\\", \\\"{x:841,y:528,t:1528139719327};\\\", \\\"{x:840,y:527,t:1528139719425};\\\", \\\"{x:840,y:526,t:1528139719439};\\\", \\\"{x:840,y:525,t:1528139719600};\\\", \\\"{x:840,y:524,t:1528139719624};\\\", \\\"{x:840,y:522,t:1528139722576};\\\", \\\"{x:840,y:521,t:1528139722599};\\\", \\\"{x:842,y:520,t:1528139723463};\\\", \\\"{x:843,y:519,t:1528139723470};\\\", \\\"{x:845,y:519,t:1528139723486};\\\", \\\"{x:845,y:518,t:1528139723503};\\\", \\\"{x:847,y:518,t:1528139724248};\\\", \\\"{x:848,y:518,t:1528139724262};\\\", \\\"{x:851,y:516,t:1528139724279};\\\", \\\"{x:853,y:516,t:1528139724285};\\\", \\\"{x:859,y:514,t:1528139724303};\\\", \\\"{x:875,y:510,t:1528139724320};\\\", \\\"{x:906,y:504,t:1528139724336};\\\", \\\"{x:934,y:498,t:1528139724352};\\\", \\\"{x:956,y:495,t:1528139724370};\\\", \\\"{x:979,y:489,t:1528139724386};\\\", \\\"{x:1007,y:487,t:1528139724403};\\\", \\\"{x:1032,y:487,t:1528139724420};\\\", \\\"{x:1055,y:487,t:1528139724436};\\\", \\\"{x:1075,y:487,t:1528139724453};\\\", \\\"{x:1087,y:487,t:1528139724470};\\\", \\\"{x:1095,y:487,t:1528139724486};\\\", \\\"{x:1096,y:488,t:1528139724503};\\\", \\\"{x:1098,y:490,t:1528139724520};\\\", \\\"{x:1100,y:493,t:1528139724537};\\\", \\\"{x:1100,y:495,t:1528139724553};\\\", \\\"{x:1102,y:499,t:1528139724570};\\\", \\\"{x:1102,y:505,t:1528139724587};\\\", \\\"{x:1102,y:510,t:1528139724603};\\\", \\\"{x:1102,y:517,t:1528139724620};\\\", \\\"{x:1100,y:526,t:1528139724637};\\\", \\\"{x:1095,y:537,t:1528139724654};\\\", \\\"{x:1093,y:547,t:1528139724670};\\\", \\\"{x:1089,y:564,t:1528139724687};\\\", \\\"{x:1087,y:568,t:1528139724703};\\\", \\\"{x:1085,y:572,t:1528139724720};\\\", \\\"{x:1082,y:575,t:1528139724738};\\\", \\\"{x:1082,y:576,t:1528139724753};\\\", \\\"{x:1082,y:575,t:1528139725032};\\\", \\\"{x:1082,y:572,t:1528139725039};\\\", \\\"{x:1081,y:568,t:1528139725054};\\\", \\\"{x:1081,y:564,t:1528139725070};\\\", \\\"{x:1079,y:557,t:1528139725087};\\\", \\\"{x:1079,y:552,t:1528139725104};\\\", \\\"{x:1079,y:545,t:1528139725120};\\\", \\\"{x:1079,y:538,t:1528139725137};\\\", \\\"{x:1079,y:531,t:1528139725154};\\\", \\\"{x:1079,y:526,t:1528139725170};\\\", \\\"{x:1079,y:523,t:1528139725187};\\\", \\\"{x:1079,y:521,t:1528139725204};\\\", \\\"{x:1079,y:519,t:1528139725220};\\\", \\\"{x:1079,y:518,t:1528139725246};\\\", \\\"{x:1079,y:517,t:1528139725255};\\\", \\\"{x:1079,y:516,t:1528139725270};\\\", \\\"{x:1079,y:514,t:1528139725287};\\\", \\\"{x:1080,y:513,t:1528139725304};\\\", \\\"{x:1080,y:511,t:1528139725320};\\\", \\\"{x:1080,y:509,t:1528139725337};\\\", \\\"{x:1080,y:506,t:1528139725355};\\\", \\\"{x:1080,y:504,t:1528139725371};\\\", \\\"{x:1082,y:501,t:1528139725387};\\\", \\\"{x:1082,y:500,t:1528139725404};\\\", \\\"{x:1082,y:499,t:1528139725496};\\\", \\\"{x:1084,y:497,t:1528139725505};\\\", \\\"{x:1085,y:496,t:1528139725521};\\\", \\\"{x:1087,y:495,t:1528139725538};\\\", \\\"{x:1090,y:493,t:1528139725555};\\\", \\\"{x:1093,y:492,t:1528139725572};\\\", \\\"{x:1099,y:492,t:1528139725588};\\\", \\\"{x:1107,y:490,t:1528139725605};\\\", \\\"{x:1119,y:490,t:1528139725622};\\\", \\\"{x:1127,y:490,t:1528139725638};\\\", \\\"{x:1144,y:490,t:1528139725655};\\\", \\\"{x:1157,y:490,t:1528139725671};\\\", \\\"{x:1166,y:490,t:1528139725688};\\\", \\\"{x:1176,y:490,t:1528139725705};\\\", \\\"{x:1187,y:490,t:1528139725721};\\\", \\\"{x:1199,y:490,t:1528139725737};\\\", \\\"{x:1209,y:490,t:1528139725755};\\\", \\\"{x:1221,y:490,t:1528139725772};\\\", \\\"{x:1237,y:490,t:1528139725789};\\\", \\\"{x:1249,y:490,t:1528139725805};\\\", \\\"{x:1264,y:490,t:1528139725821};\\\", \\\"{x:1282,y:489,t:1528139725838};\\\", \\\"{x:1299,y:488,t:1528139725855};\\\", \\\"{x:1323,y:488,t:1528139725872};\\\", \\\"{x:1333,y:488,t:1528139725889};\\\", \\\"{x:1343,y:485,t:1528139725905};\\\", \\\"{x:1353,y:485,t:1528139725922};\\\", \\\"{x:1366,y:485,t:1528139725939};\\\", \\\"{x:1375,y:485,t:1528139725955};\\\", \\\"{x:1389,y:485,t:1528139725972};\\\", \\\"{x:1406,y:485,t:1528139725988};\\\", \\\"{x:1425,y:485,t:1528139726005};\\\", \\\"{x:1448,y:485,t:1528139726022};\\\", \\\"{x:1468,y:485,t:1528139726039};\\\", \\\"{x:1486,y:485,t:1528139726055};\\\", \\\"{x:1509,y:485,t:1528139726072};\\\", \\\"{x:1526,y:486,t:1528139726089};\\\", \\\"{x:1540,y:489,t:1528139726104};\\\", \\\"{x:1550,y:490,t:1528139726122};\\\", \\\"{x:1559,y:492,t:1528139726139};\\\", \\\"{x:1562,y:493,t:1528139726155};\\\", \\\"{x:1563,y:493,t:1528139726171};\\\", \\\"{x:1567,y:495,t:1528139726188};\\\", \\\"{x:1569,y:495,t:1528139726208};\\\", \\\"{x:1571,y:497,t:1528139726256};\\\", \\\"{x:1573,y:497,t:1528139726271};\\\", \\\"{x:1578,y:498,t:1528139726291};\\\", \\\"{x:1581,y:499,t:1528139726305};\\\", \\\"{x:1583,y:499,t:1528139726326};\\\", \\\"{x:1584,y:499,t:1528139726358};\\\", \\\"{x:1586,y:499,t:1528139726382};\\\", \\\"{x:1585,y:499,t:1528139733040};\\\", \\\"{x:1580,y:499,t:1528139733047};\\\", \\\"{x:1576,y:499,t:1528139733060};\\\", \\\"{x:1566,y:499,t:1528139733077};\\\", \\\"{x:1555,y:499,t:1528139733093};\\\", \\\"{x:1541,y:504,t:1528139733110};\\\", \\\"{x:1527,y:510,t:1528139733128};\\\", \\\"{x:1505,y:523,t:1528139733143};\\\", \\\"{x:1473,y:553,t:1528139733160};\\\", \\\"{x:1417,y:614,t:1528139733177};\\\", \\\"{x:1355,y:674,t:1528139733193};\\\", \\\"{x:1297,y:723,t:1528139733211};\\\", \\\"{x:1225,y:787,t:1528139733227};\\\", \\\"{x:1176,y:823,t:1528139733244};\\\", \\\"{x:1176,y:824,t:1528139733260};\\\", \\\"{x:1175,y:825,t:1528139733919};\\\", \\\"{x:1179,y:824,t:1528139733976};\\\", \\\"{x:1189,y:818,t:1528139733983};\\\", \\\"{x:1192,y:815,t:1528139733995};\\\", \\\"{x:1208,y:808,t:1528139734011};\\\", \\\"{x:1219,y:802,t:1528139734028};\\\", \\\"{x:1222,y:799,t:1528139734045};\\\", \\\"{x:1227,y:795,t:1528139734061};\\\", \\\"{x:1238,y:790,t:1528139734077};\\\", \\\"{x:1265,y:782,t:1528139734095};\\\", \\\"{x:1285,y:777,t:1528139734112};\\\", \\\"{x:1309,y:774,t:1528139734128};\\\", \\\"{x:1338,y:769,t:1528139734145};\\\", \\\"{x:1363,y:765,t:1528139734161};\\\", \\\"{x:1384,y:763,t:1528139734178};\\\", \\\"{x:1394,y:762,t:1528139734194};\\\", \\\"{x:1401,y:760,t:1528139734211};\\\", \\\"{x:1405,y:758,t:1528139734228};\\\", \\\"{x:1400,y:759,t:1528139734368};\\\", \\\"{x:1397,y:759,t:1528139734378};\\\", \\\"{x:1389,y:761,t:1528139734395};\\\", \\\"{x:1380,y:762,t:1528139734412};\\\", \\\"{x:1372,y:763,t:1528139734428};\\\", \\\"{x:1365,y:764,t:1528139734446};\\\", \\\"{x:1361,y:764,t:1528139734461};\\\", \\\"{x:1354,y:765,t:1528139734478};\\\", \\\"{x:1353,y:765,t:1528139734495};\\\", \\\"{x:1352,y:765,t:1528139734512};\\\", \\\"{x:1351,y:765,t:1528139734529};\\\", \\\"{x:1351,y:766,t:1528139734544};\\\", \\\"{x:1351,y:767,t:1528139734639};\\\", \\\"{x:1350,y:767,t:1528139734967};\\\", \\\"{x:1349,y:767,t:1528139734983};\\\", \\\"{x:1349,y:766,t:1528139735183};\\\", \\\"{x:1349,y:765,t:1528139735196};\\\", \\\"{x:1348,y:764,t:1528139735212};\\\", \\\"{x:1348,y:763,t:1528139735239};\\\", \\\"{x:1348,y:762,t:1528139735246};\\\", \\\"{x:1347,y:760,t:1528139735262};\\\", \\\"{x:1346,y:760,t:1528139735736};\\\", \\\"{x:1346,y:761,t:1528139735751};\\\", \\\"{x:1345,y:762,t:1528139735763};\\\", \\\"{x:1343,y:765,t:1528139735779};\\\", \\\"{x:1342,y:768,t:1528139735797};\\\", \\\"{x:1341,y:771,t:1528139735813};\\\", \\\"{x:1340,y:773,t:1528139735830};\\\", \\\"{x:1339,y:775,t:1528139735846};\\\", \\\"{x:1337,y:778,t:1528139735863};\\\", \\\"{x:1336,y:781,t:1528139735880};\\\", \\\"{x:1334,y:784,t:1528139735896};\\\", \\\"{x:1334,y:786,t:1528139735913};\\\", \\\"{x:1333,y:789,t:1528139735930};\\\", \\\"{x:1333,y:792,t:1528139735946};\\\", \\\"{x:1331,y:797,t:1528139735963};\\\", \\\"{x:1328,y:802,t:1528139735980};\\\", \\\"{x:1326,y:807,t:1528139735996};\\\", \\\"{x:1321,y:814,t:1528139736013};\\\", \\\"{x:1318,y:824,t:1528139736030};\\\", \\\"{x:1315,y:842,t:1528139736047};\\\", \\\"{x:1304,y:868,t:1528139736064};\\\", \\\"{x:1293,y:887,t:1528139736080};\\\", \\\"{x:1284,y:904,t:1528139736097};\\\", \\\"{x:1279,y:919,t:1528139736113};\\\", \\\"{x:1274,y:933,t:1528139736130};\\\", \\\"{x:1269,y:947,t:1528139736146};\\\", \\\"{x:1265,y:957,t:1528139736163};\\\", \\\"{x:1262,y:963,t:1528139736180};\\\", \\\"{x:1260,y:968,t:1528139736197};\\\", \\\"{x:1259,y:971,t:1528139736213};\\\", \\\"{x:1256,y:974,t:1528139736230};\\\", \\\"{x:1255,y:978,t:1528139736247};\\\", \\\"{x:1253,y:979,t:1528139736263};\\\", \\\"{x:1253,y:980,t:1528139736279};\\\", \\\"{x:1252,y:981,t:1528139736318};\\\", \\\"{x:1250,y:981,t:1528139736390};\\\", \\\"{x:1249,y:981,t:1528139736398};\\\", \\\"{x:1249,y:980,t:1528139736414};\\\", \\\"{x:1248,y:977,t:1528139736430};\\\", \\\"{x:1247,y:974,t:1528139736447};\\\", \\\"{x:1246,y:972,t:1528139736463};\\\", \\\"{x:1246,y:970,t:1528139736479};\\\", \\\"{x:1246,y:969,t:1528139736497};\\\", \\\"{x:1246,y:966,t:1528139736513};\\\", \\\"{x:1246,y:964,t:1528139736530};\\\", \\\"{x:1246,y:963,t:1528139736547};\\\", \\\"{x:1246,y:962,t:1528139736936};\\\", \\\"{x:1247,y:962,t:1528139736984};\\\", \\\"{x:1248,y:964,t:1528139737000};\\\", \\\"{x:1249,y:964,t:1528139737023};\\\", \\\"{x:1249,y:965,t:1528139737047};\\\", \\\"{x:1250,y:966,t:1528139739951};\\\", \\\"{x:1252,y:965,t:1528139739975};\\\", \\\"{x:1252,y:964,t:1528139739983};\\\", \\\"{x:1253,y:963,t:1528139740007};\\\", \\\"{x:1252,y:963,t:1528139740455};\\\", \\\"{x:1251,y:964,t:1528139740471};\\\", \\\"{x:1240,y:963,t:1528139746271};\\\", \\\"{x:1173,y:944,t:1528139746288};\\\", \\\"{x:1123,y:930,t:1528139746305};\\\", \\\"{x:1092,y:913,t:1528139746322};\\\", \\\"{x:1048,y:898,t:1528139746338};\\\", \\\"{x:993,y:877,t:1528139746355};\\\", \\\"{x:958,y:856,t:1528139746372};\\\", \\\"{x:935,y:842,t:1528139746388};\\\", \\\"{x:918,y:826,t:1528139746404};\\\", \\\"{x:907,y:811,t:1528139746421};\\\", \\\"{x:881,y:759,t:1528139746438};\\\", \\\"{x:848,y:711,t:1528139746455};\\\", \\\"{x:799,y:672,t:1528139746471};\\\", \\\"{x:757,y:632,t:1528139746487};\\\", \\\"{x:737,y:614,t:1528139746504};\\\", \\\"{x:715,y:597,t:1528139746521};\\\", \\\"{x:682,y:569,t:1528139746539};\\\", \\\"{x:656,y:549,t:1528139746556};\\\", \\\"{x:646,y:543,t:1528139746572};\\\", \\\"{x:638,y:536,t:1528139746588};\\\", \\\"{x:626,y:529,t:1528139746605};\\\", \\\"{x:598,y:516,t:1528139746622};\\\", \\\"{x:587,y:513,t:1528139746638};\\\", \\\"{x:581,y:511,t:1528139746654};\\\", \\\"{x:571,y:513,t:1528139746671};\\\", \\\"{x:556,y:522,t:1528139746688};\\\", \\\"{x:547,y:528,t:1528139746705};\\\", \\\"{x:541,y:534,t:1528139746722};\\\", \\\"{x:541,y:537,t:1528139746738};\\\", \\\"{x:541,y:538,t:1528139746758};\\\", \\\"{x:544,y:537,t:1528139746771};\\\", \\\"{x:563,y:531,t:1528139746788};\\\", \\\"{x:595,y:520,t:1528139746805};\\\", \\\"{x:687,y:494,t:1528139746822};\\\", \\\"{x:751,y:475,t:1528139746839};\\\", \\\"{x:805,y:456,t:1528139746854};\\\", \\\"{x:845,y:445,t:1528139746871};\\\", \\\"{x:859,y:440,t:1528139746888};\\\", \\\"{x:863,y:438,t:1528139746904};\\\", \\\"{x:863,y:440,t:1528139747015};\\\", \\\"{x:865,y:446,t:1528139747023};\\\", \\\"{x:865,y:458,t:1528139747039};\\\", \\\"{x:864,y:474,t:1528139747055};\\\", \\\"{x:859,y:486,t:1528139747072};\\\", \\\"{x:856,y:496,t:1528139747090};\\\", \\\"{x:856,y:501,t:1528139747105};\\\", \\\"{x:855,y:503,t:1528139747121};\\\", \\\"{x:853,y:506,t:1528139747214};\\\", \\\"{x:852,y:506,t:1528139747222};\\\", \\\"{x:850,y:507,t:1528139747238};\\\", \\\"{x:847,y:508,t:1528139747255};\\\", \\\"{x:843,y:509,t:1528139747272};\\\", \\\"{x:841,y:509,t:1528139747288};\\\", \\\"{x:839,y:510,t:1528139747305};\\\", \\\"{x:838,y:510,t:1528139747350};\\\", \\\"{x:837,y:510,t:1528139747606};\\\", \\\"{x:820,y:521,t:1528139747623};\\\", \\\"{x:790,y:547,t:1528139747639};\\\", \\\"{x:744,y:585,t:1528139747656};\\\", \\\"{x:701,y:618,t:1528139747673};\\\", \\\"{x:667,y:642,t:1528139747689};\\\", \\\"{x:630,y:669,t:1528139747706};\\\", \\\"{x:601,y:688,t:1528139747722};\\\", \\\"{x:578,y:709,t:1528139747738};\\\", \\\"{x:561,y:726,t:1528139747756};\\\", \\\"{x:549,y:749,t:1528139747773};\\\", \\\"{x:534,y:767,t:1528139747789};\\\", \\\"{x:529,y:772,t:1528139747806};\\\", \\\"{x:531,y:771,t:1528139747885};\\\", \\\"{x:531,y:770,t:1528139747893};\\\", \\\"{x:532,y:770,t:1528139747906};\\\", \\\"{x:534,y:769,t:1528139747923};\\\", \\\"{x:538,y:767,t:1528139747938};\\\", \\\"{x:543,y:762,t:1528139747956};\\\", \\\"{x:549,y:750,t:1528139747973};\\\", \\\"{x:550,y:736,t:1528139747989};\\\", \\\"{x:551,y:726,t:1528139748006};\\\", \\\"{x:551,y:725,t:1528139748021};\\\", \\\"{x:552,y:724,t:1528139748374};\\\", \\\"{x:557,y:721,t:1528139748390};\\\", \\\"{x:569,y:719,t:1528139748406};\\\", \\\"{x:595,y:717,t:1528139748423};\\\", \\\"{x:638,y:717,t:1528139748439};\\\", \\\"{x:727,y:717,t:1528139748456};\\\", \\\"{x:843,y:715,t:1528139748473};\\\", \\\"{x:1007,y:711,t:1528139748490};\\\", \\\"{x:1163,y:702,t:1528139748506};\\\", \\\"{x:1317,y:689,t:1528139748523};\\\", \\\"{x:1444,y:672,t:1528139748540};\\\", \\\"{x:1539,y:659,t:1528139748556};\\\", \\\"{x:1608,y:650,t:1528139748573};\\\", \\\"{x:1653,y:640,t:1528139748589};\\\", \\\"{x:1661,y:639,t:1528139748606};\\\", \\\"{x:1658,y:639,t:1528139748943};\\\", \\\"{x:1656,y:639,t:1528139748958};\\\", \\\"{x:1655,y:639,t:1528139748991};\\\", \\\"{x:1654,y:639,t:1528139749007};\\\", \\\"{x:1653,y:639,t:1528139749030};\\\", \\\"{x:1652,y:639,t:1528139749078};\\\" ] }, { \\\"rt\\\": 30626, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 890891, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -B -B -09 AM-09 AM-08 AM-I -10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1651,y:640,t:1528139751928};\\\", \\\"{x:1648,y:641,t:1528139751942};\\\", \\\"{x:1638,y:645,t:1528139751963};\\\", \\\"{x:1632,y:648,t:1528139751975};\\\", \\\"{x:1629,y:650,t:1528139751992};\\\", \\\"{x:1623,y:654,t:1528139752009};\\\", \\\"{x:1610,y:661,t:1528139752026};\\\", \\\"{x:1589,y:672,t:1528139752042};\\\", \\\"{x:1557,y:691,t:1528139752059};\\\", \\\"{x:1501,y:727,t:1528139752076};\\\", \\\"{x:1429,y:763,t:1528139752092};\\\", \\\"{x:1365,y:789,t:1528139752109};\\\", \\\"{x:1279,y:814,t:1528139752126};\\\", \\\"{x:1235,y:826,t:1528139752142};\\\", \\\"{x:1194,y:842,t:1528139752159};\\\", \\\"{x:1155,y:859,t:1528139752176};\\\", \\\"{x:1116,y:877,t:1528139752192};\\\", \\\"{x:1084,y:888,t:1528139752209};\\\", \\\"{x:1036,y:914,t:1528139752226};\\\", \\\"{x:1017,y:934,t:1528139752242};\\\", \\\"{x:1025,y:932,t:1528139752351};\\\", \\\"{x:1045,y:928,t:1528139752359};\\\", \\\"{x:1068,y:925,t:1528139752376};\\\", \\\"{x:1085,y:920,t:1528139752393};\\\", \\\"{x:1100,y:915,t:1528139752409};\\\", \\\"{x:1111,y:911,t:1528139752426};\\\", \\\"{x:1118,y:908,t:1528139752443};\\\", \\\"{x:1122,y:906,t:1528139752460};\\\", \\\"{x:1124,y:903,t:1528139752476};\\\", \\\"{x:1126,y:901,t:1528139752493};\\\", \\\"{x:1134,y:894,t:1528139752509};\\\", \\\"{x:1158,y:878,t:1528139752526};\\\", \\\"{x:1177,y:867,t:1528139752543};\\\", \\\"{x:1188,y:856,t:1528139752560};\\\", \\\"{x:1200,y:844,t:1528139752576};\\\", \\\"{x:1204,y:839,t:1528139752593};\\\", \\\"{x:1214,y:833,t:1528139752612};\\\", \\\"{x:1221,y:830,t:1528139752627};\\\", \\\"{x:1225,y:828,t:1528139752643};\\\", \\\"{x:1225,y:827,t:1528139752659};\\\", \\\"{x:1225,y:828,t:1528139752782};\\\", \\\"{x:1224,y:829,t:1528139752794};\\\", \\\"{x:1222,y:832,t:1528139752809};\\\", \\\"{x:1222,y:833,t:1528139752862};\\\", \\\"{x:1222,y:834,t:1528139752877};\\\", \\\"{x:1222,y:838,t:1528139752893};\\\", \\\"{x:1222,y:839,t:1528139752910};\\\", \\\"{x:1221,y:846,t:1528139752926};\\\", \\\"{x:1221,y:854,t:1528139752944};\\\", \\\"{x:1221,y:858,t:1528139752961};\\\", \\\"{x:1221,y:861,t:1528139752976};\\\", \\\"{x:1221,y:865,t:1528139752994};\\\", \\\"{x:1221,y:868,t:1528139753010};\\\", \\\"{x:1221,y:872,t:1528139753026};\\\", \\\"{x:1221,y:875,t:1528139753044};\\\", \\\"{x:1221,y:879,t:1528139753061};\\\", \\\"{x:1221,y:880,t:1528139753079};\\\", \\\"{x:1222,y:882,t:1528139753126};\\\", \\\"{x:1223,y:883,t:1528139753165};\\\", \\\"{x:1224,y:883,t:1528139753190};\\\", \\\"{x:1225,y:883,t:1528139753221};\\\", \\\"{x:1227,y:883,t:1528139753238};\\\", \\\"{x:1228,y:883,t:1528139753245};\\\", \\\"{x:1229,y:882,t:1528139753260};\\\", \\\"{x:1232,y:877,t:1528139753276};\\\", \\\"{x:1235,y:874,t:1528139753294};\\\", \\\"{x:1235,y:873,t:1528139753310};\\\", \\\"{x:1237,y:875,t:1528139753375};\\\", \\\"{x:1239,y:878,t:1528139753383};\\\", \\\"{x:1240,y:879,t:1528139753394};\\\", \\\"{x:1244,y:885,t:1528139753411};\\\", \\\"{x:1246,y:889,t:1528139753427};\\\", \\\"{x:1247,y:891,t:1528139753443};\\\", \\\"{x:1250,y:894,t:1528139753460};\\\", \\\"{x:1251,y:895,t:1528139753478};\\\", \\\"{x:1251,y:896,t:1528139753494};\\\", \\\"{x:1253,y:899,t:1528139753511};\\\", \\\"{x:1254,y:900,t:1528139753528};\\\", \\\"{x:1254,y:901,t:1528139753544};\\\", \\\"{x:1256,y:903,t:1528139753561};\\\", \\\"{x:1257,y:904,t:1528139753583};\\\", \\\"{x:1257,y:905,t:1528139753599};\\\", \\\"{x:1258,y:907,t:1528139753679};\\\", \\\"{x:1260,y:908,t:1528139753694};\\\", \\\"{x:1260,y:913,t:1528139753711};\\\", \\\"{x:1261,y:914,t:1528139753727};\\\", \\\"{x:1263,y:918,t:1528139753744};\\\", \\\"{x:1263,y:919,t:1528139753783};\\\", \\\"{x:1264,y:920,t:1528139753799};\\\", \\\"{x:1265,y:920,t:1528139754279};\\\", \\\"{x:1266,y:920,t:1528139754294};\\\", \\\"{x:1266,y:919,t:1528139754350};\\\", \\\"{x:1265,y:919,t:1528139754382};\\\", \\\"{x:1264,y:919,t:1528139754394};\\\", \\\"{x:1263,y:917,t:1528139754411};\\\", \\\"{x:1262,y:916,t:1528139754427};\\\", \\\"{x:1261,y:915,t:1528139754462};\\\", \\\"{x:1260,y:914,t:1528139754478};\\\", \\\"{x:1258,y:911,t:1528139754494};\\\", \\\"{x:1254,y:909,t:1528139754511};\\\", \\\"{x:1253,y:907,t:1528139754528};\\\", \\\"{x:1251,y:906,t:1528139754639};\\\", \\\"{x:1250,y:905,t:1528139754655};\\\", \\\"{x:1249,y:904,t:1528139754759};\\\", \\\"{x:1249,y:903,t:1528139754847};\\\", \\\"{x:1248,y:901,t:1528139754862};\\\", \\\"{x:1246,y:897,t:1528139754879};\\\", \\\"{x:1246,y:896,t:1528139754894};\\\", \\\"{x:1245,y:896,t:1528139754911};\\\", \\\"{x:1245,y:894,t:1528139755759};\\\", \\\"{x:1245,y:893,t:1528139755767};\\\", \\\"{x:1245,y:892,t:1528139755778};\\\", \\\"{x:1245,y:891,t:1528139755796};\\\", \\\"{x:1245,y:888,t:1528139755812};\\\", \\\"{x:1245,y:887,t:1528139755828};\\\", \\\"{x:1245,y:886,t:1528139755862};\\\", \\\"{x:1250,y:885,t:1528139758175};\\\", \\\"{x:1256,y:882,t:1528139758182};\\\", \\\"{x:1262,y:878,t:1528139758197};\\\", \\\"{x:1282,y:870,t:1528139758213};\\\", \\\"{x:1323,y:849,t:1528139758230};\\\", \\\"{x:1342,y:833,t:1528139758247};\\\", \\\"{x:1355,y:818,t:1528139758263};\\\", \\\"{x:1365,y:796,t:1528139758281};\\\", \\\"{x:1371,y:776,t:1528139758298};\\\", \\\"{x:1373,y:767,t:1528139758313};\\\", \\\"{x:1374,y:761,t:1528139758330};\\\", \\\"{x:1375,y:759,t:1528139758347};\\\", \\\"{x:1375,y:758,t:1528139758398};\\\", \\\"{x:1374,y:758,t:1528139758429};\\\", \\\"{x:1368,y:758,t:1528139758447};\\\", \\\"{x:1359,y:758,t:1528139758463};\\\", \\\"{x:1352,y:758,t:1528139758480};\\\", \\\"{x:1346,y:760,t:1528139758498};\\\", \\\"{x:1342,y:760,t:1528139758514};\\\", \\\"{x:1341,y:761,t:1528139758783};\\\", \\\"{x:1341,y:762,t:1528139758798};\\\", \\\"{x:1341,y:763,t:1528139758823};\\\", \\\"{x:1342,y:764,t:1528139759014};\\\", \\\"{x:1343,y:765,t:1528139759031};\\\", \\\"{x:1344,y:766,t:1528139759061};\\\", \\\"{x:1344,y:767,t:1528139759078};\\\", \\\"{x:1346,y:767,t:1528139759101};\\\", \\\"{x:1346,y:768,t:1528139759126};\\\", \\\"{x:1347,y:768,t:1528139759134};\\\", \\\"{x:1347,y:769,t:1528139759150};\\\", \\\"{x:1349,y:770,t:1528139759165};\\\", \\\"{x:1350,y:771,t:1528139759246};\\\", \\\"{x:1352,y:772,t:1528139759270};\\\", \\\"{x:1352,y:773,t:1528139759285};\\\", \\\"{x:1353,y:773,t:1528139759494};\\\", \\\"{x:1355,y:775,t:1528139759502};\\\", \\\"{x:1355,y:776,t:1528139759515};\\\", \\\"{x:1357,y:778,t:1528139759532};\\\", \\\"{x:1361,y:779,t:1528139759548};\\\", \\\"{x:1363,y:781,t:1528139759565};\\\", \\\"{x:1365,y:783,t:1528139759582};\\\", \\\"{x:1366,y:784,t:1528139759597};\\\", \\\"{x:1367,y:785,t:1528139759615};\\\", \\\"{x:1369,y:788,t:1528139759632};\\\", \\\"{x:1371,y:792,t:1528139759650};\\\", \\\"{x:1372,y:792,t:1528139759665};\\\", \\\"{x:1373,y:794,t:1528139759684};\\\", \\\"{x:1373,y:795,t:1528139759699};\\\", \\\"{x:1374,y:795,t:1528139759727};\\\", \\\"{x:1374,y:796,t:1528139759735};\\\", \\\"{x:1376,y:797,t:1528139759749};\\\", \\\"{x:1376,y:798,t:1528139759765};\\\", \\\"{x:1379,y:801,t:1528139759783};\\\", \\\"{x:1379,y:800,t:1528139759895};\\\", \\\"{x:1379,y:796,t:1528139759901};\\\", \\\"{x:1378,y:795,t:1528139759914};\\\", \\\"{x:1376,y:790,t:1528139759931};\\\", \\\"{x:1374,y:784,t:1528139759948};\\\", \\\"{x:1362,y:772,t:1528139759966};\\\", \\\"{x:1361,y:771,t:1528139759981};\\\", \\\"{x:1358,y:767,t:1528139759999};\\\", \\\"{x:1356,y:764,t:1528139760015};\\\", \\\"{x:1352,y:760,t:1528139760031};\\\", \\\"{x:1349,y:758,t:1528139760048};\\\", \\\"{x:1349,y:759,t:1528139760646};\\\", \\\"{x:1349,y:760,t:1528139760654};\\\", \\\"{x:1349,y:761,t:1528139760666};\\\", \\\"{x:1350,y:763,t:1528139760684};\\\", \\\"{x:1351,y:767,t:1528139760698};\\\", \\\"{x:1351,y:768,t:1528139760716};\\\", \\\"{x:1352,y:769,t:1528139760732};\\\", \\\"{x:1353,y:771,t:1528139760748};\\\", \\\"{x:1354,y:772,t:1528139760765};\\\", \\\"{x:1356,y:774,t:1528139760782};\\\", \\\"{x:1356,y:775,t:1528139760799};\\\", \\\"{x:1357,y:778,t:1528139760815};\\\", \\\"{x:1360,y:781,t:1528139760832};\\\", \\\"{x:1362,y:783,t:1528139760848};\\\", \\\"{x:1364,y:785,t:1528139760866};\\\", \\\"{x:1366,y:787,t:1528139760883};\\\", \\\"{x:1367,y:789,t:1528139760898};\\\", \\\"{x:1368,y:791,t:1528139760915};\\\", \\\"{x:1370,y:793,t:1528139760933};\\\", \\\"{x:1371,y:794,t:1528139760948};\\\", \\\"{x:1372,y:797,t:1528139760966};\\\", \\\"{x:1373,y:798,t:1528139760981};\\\", \\\"{x:1373,y:799,t:1528139761000};\\\", \\\"{x:1373,y:800,t:1528139761015};\\\", \\\"{x:1375,y:804,t:1528139761033};\\\", \\\"{x:1377,y:805,t:1528139761049};\\\", \\\"{x:1378,y:808,t:1528139761065};\\\", \\\"{x:1380,y:810,t:1528139761083};\\\", \\\"{x:1382,y:812,t:1528139761099};\\\", \\\"{x:1383,y:814,t:1528139761116};\\\", \\\"{x:1385,y:818,t:1528139761132};\\\", \\\"{x:1388,y:822,t:1528139761149};\\\", \\\"{x:1391,y:825,t:1528139761166};\\\", \\\"{x:1393,y:827,t:1528139761182};\\\", \\\"{x:1395,y:829,t:1528139761199};\\\", \\\"{x:1396,y:831,t:1528139761216};\\\", \\\"{x:1396,y:832,t:1528139761233};\\\", \\\"{x:1397,y:832,t:1528139761250};\\\", \\\"{x:1397,y:833,t:1528139761266};\\\", \\\"{x:1398,y:833,t:1528139761284};\\\", \\\"{x:1399,y:834,t:1528139761300};\\\", \\\"{x:1400,y:835,t:1528139761316};\\\", \\\"{x:1402,y:837,t:1528139761333};\\\", \\\"{x:1403,y:838,t:1528139761350};\\\", \\\"{x:1404,y:839,t:1528139761367};\\\", \\\"{x:1408,y:841,t:1528139761383};\\\", \\\"{x:1409,y:843,t:1528139761400};\\\", \\\"{x:1411,y:845,t:1528139761416};\\\", \\\"{x:1414,y:847,t:1528139761433};\\\", \\\"{x:1416,y:848,t:1528139761450};\\\", \\\"{x:1417,y:849,t:1528139761467};\\\", \\\"{x:1419,y:851,t:1528139761484};\\\", \\\"{x:1420,y:851,t:1528139761500};\\\", \\\"{x:1422,y:853,t:1528139761518};\\\", \\\"{x:1424,y:854,t:1528139761532};\\\", \\\"{x:1425,y:854,t:1528139761550};\\\", \\\"{x:1427,y:857,t:1528139761567};\\\", \\\"{x:1428,y:859,t:1528139761583};\\\", \\\"{x:1429,y:860,t:1528139761600};\\\", \\\"{x:1430,y:862,t:1528139761623};\\\", \\\"{x:1431,y:863,t:1528139761633};\\\", \\\"{x:1431,y:864,t:1528139761650};\\\", \\\"{x:1431,y:865,t:1528139761667};\\\", \\\"{x:1432,y:867,t:1528139761685};\\\", \\\"{x:1433,y:869,t:1528139761700};\\\", \\\"{x:1435,y:872,t:1528139761718};\\\", \\\"{x:1435,y:873,t:1528139761733};\\\", \\\"{x:1437,y:876,t:1528139761750};\\\", \\\"{x:1440,y:881,t:1528139761766};\\\", \\\"{x:1441,y:883,t:1528139761784};\\\", \\\"{x:1442,y:885,t:1528139761800};\\\", \\\"{x:1445,y:887,t:1528139761817};\\\", \\\"{x:1446,y:889,t:1528139761834};\\\", \\\"{x:1448,y:891,t:1528139761850};\\\", \\\"{x:1449,y:893,t:1528139761867};\\\", \\\"{x:1451,y:897,t:1528139761884};\\\", \\\"{x:1452,y:898,t:1528139761900};\\\", \\\"{x:1454,y:901,t:1528139761917};\\\", \\\"{x:1456,y:904,t:1528139761934};\\\", \\\"{x:1458,y:906,t:1528139761950};\\\", \\\"{x:1461,y:911,t:1528139761967};\\\", \\\"{x:1463,y:914,t:1528139761984};\\\", \\\"{x:1465,y:917,t:1528139762000};\\\", \\\"{x:1469,y:924,t:1528139762017};\\\", \\\"{x:1471,y:928,t:1528139762034};\\\", \\\"{x:1473,y:933,t:1528139762050};\\\", \\\"{x:1475,y:938,t:1528139762067};\\\", \\\"{x:1477,y:945,t:1528139762084};\\\", \\\"{x:1478,y:948,t:1528139762100};\\\", \\\"{x:1480,y:949,t:1528139762117};\\\", \\\"{x:1480,y:951,t:1528139762134};\\\", \\\"{x:1481,y:951,t:1528139762159};\\\", \\\"{x:1482,y:953,t:1528139762183};\\\", \\\"{x:1483,y:955,t:1528139762190};\\\", \\\"{x:1484,y:956,t:1528139762200};\\\", \\\"{x:1488,y:959,t:1528139762217};\\\", \\\"{x:1494,y:965,t:1528139762234};\\\", \\\"{x:1498,y:968,t:1528139762250};\\\", \\\"{x:1502,y:970,t:1528139762267};\\\", \\\"{x:1504,y:971,t:1528139762284};\\\", \\\"{x:1504,y:972,t:1528139762310};\\\", \\\"{x:1505,y:972,t:1528139762383};\\\", \\\"{x:1506,y:972,t:1528139762695};\\\", \\\"{x:1507,y:972,t:1528139762710};\\\", \\\"{x:1508,y:972,t:1528139762742};\\\", \\\"{x:1508,y:971,t:1528139762975};\\\", \\\"{x:1508,y:969,t:1528139762990};\\\", \\\"{x:1508,y:967,t:1528139763001};\\\", \\\"{x:1508,y:965,t:1528139763018};\\\", \\\"{x:1508,y:962,t:1528139763034};\\\", \\\"{x:1509,y:960,t:1528139763051};\\\", \\\"{x:1509,y:958,t:1528139763068};\\\", \\\"{x:1509,y:956,t:1528139763084};\\\", \\\"{x:1509,y:955,t:1528139763101};\\\", \\\"{x:1510,y:955,t:1528139763118};\\\", \\\"{x:1510,y:954,t:1528139763215};\\\", \\\"{x:1510,y:953,t:1528139763407};\\\", \\\"{x:1510,y:952,t:1528139763462};\\\", \\\"{x:1510,y:951,t:1528139764719};\\\", \\\"{x:1510,y:950,t:1528139765543};\\\", \\\"{x:1510,y:949,t:1528139765566};\\\", \\\"{x:1510,y:947,t:1528139765919};\\\", \\\"{x:1510,y:946,t:1528139765937};\\\", \\\"{x:1510,y:945,t:1528139765953};\\\", \\\"{x:1510,y:944,t:1528139765970};\\\", \\\"{x:1510,y:943,t:1528139765986};\\\", \\\"{x:1510,y:942,t:1528139766119};\\\", \\\"{x:1510,y:940,t:1528139766136};\\\", \\\"{x:1510,y:939,t:1528139766153};\\\", \\\"{x:1510,y:938,t:1528139766170};\\\", \\\"{x:1509,y:936,t:1528139766191};\\\", \\\"{x:1509,y:934,t:1528139766294};\\\", \\\"{x:1508,y:933,t:1528139766319};\\\", \\\"{x:1508,y:932,t:1528139766359};\\\", \\\"{x:1508,y:931,t:1528139766370};\\\", \\\"{x:1508,y:930,t:1528139766671};\\\", \\\"{x:1507,y:929,t:1528139768159};\\\", \\\"{x:1503,y:927,t:1528139768171};\\\", \\\"{x:1492,y:924,t:1528139768188};\\\", \\\"{x:1480,y:920,t:1528139768206};\\\", \\\"{x:1465,y:915,t:1528139768221};\\\", \\\"{x:1439,y:903,t:1528139768238};\\\", \\\"{x:1422,y:892,t:1528139768255};\\\", \\\"{x:1403,y:880,t:1528139768271};\\\", \\\"{x:1384,y:871,t:1528139768289};\\\", \\\"{x:1373,y:863,t:1528139768304};\\\", \\\"{x:1362,y:853,t:1528139768321};\\\", \\\"{x:1343,y:845,t:1528139768337};\\\", \\\"{x:1321,y:842,t:1528139768354};\\\", \\\"{x:1304,y:840,t:1528139768371};\\\", \\\"{x:1295,y:840,t:1528139768387};\\\", \\\"{x:1286,y:840,t:1528139768404};\\\", \\\"{x:1274,y:840,t:1528139768421};\\\", \\\"{x:1263,y:840,t:1528139768437};\\\", \\\"{x:1259,y:840,t:1528139768454};\\\", \\\"{x:1258,y:840,t:1528139768470};\\\", \\\"{x:1257,y:841,t:1528139768493};\\\", \\\"{x:1255,y:841,t:1528139768591};\\\", \\\"{x:1252,y:842,t:1528139768605};\\\", \\\"{x:1230,y:842,t:1528139768623};\\\", \\\"{x:1217,y:842,t:1528139768638};\\\", \\\"{x:1208,y:842,t:1528139768656};\\\", \\\"{x:1200,y:842,t:1528139768673};\\\", \\\"{x:1193,y:842,t:1528139768687};\\\", \\\"{x:1191,y:842,t:1528139768705};\\\", \\\"{x:1189,y:842,t:1528139768721};\\\", \\\"{x:1187,y:842,t:1528139768737};\\\", \\\"{x:1183,y:844,t:1528139768754};\\\", \\\"{x:1176,y:847,t:1528139768772};\\\", \\\"{x:1169,y:860,t:1528139768787};\\\", \\\"{x:1164,y:873,t:1528139768805};\\\", \\\"{x:1158,y:889,t:1528139768822};\\\", \\\"{x:1155,y:899,t:1528139768837};\\\", \\\"{x:1152,y:907,t:1528139768855};\\\", \\\"{x:1149,y:914,t:1528139768871};\\\", \\\"{x:1147,y:919,t:1528139768888};\\\", \\\"{x:1145,y:926,t:1528139768905};\\\", \\\"{x:1143,y:932,t:1528139768922};\\\", \\\"{x:1143,y:942,t:1528139768937};\\\", \\\"{x:1143,y:951,t:1528139768955};\\\", \\\"{x:1143,y:960,t:1528139768971};\\\", \\\"{x:1143,y:963,t:1528139768987};\\\", \\\"{x:1143,y:965,t:1528139769004};\\\", \\\"{x:1143,y:966,t:1528139769022};\\\", \\\"{x:1143,y:968,t:1528139769054};\\\", \\\"{x:1143,y:971,t:1528139769072};\\\", \\\"{x:1143,y:973,t:1528139769088};\\\", \\\"{x:1143,y:975,t:1528139769104};\\\", \\\"{x:1143,y:976,t:1528139769122};\\\", \\\"{x:1143,y:977,t:1528139769138};\\\", \\\"{x:1143,y:974,t:1528139769365};\\\", \\\"{x:1143,y:973,t:1528139769373};\\\", \\\"{x:1143,y:972,t:1528139769389};\\\", \\\"{x:1143,y:971,t:1528139769405};\\\", \\\"{x:1143,y:970,t:1528139769421};\\\", \\\"{x:1143,y:969,t:1528139769461};\\\", \\\"{x:1143,y:968,t:1528139769486};\\\", \\\"{x:1143,y:967,t:1528139769526};\\\", \\\"{x:1143,y:964,t:1528139769539};\\\", \\\"{x:1143,y:961,t:1528139769556};\\\", \\\"{x:1144,y:957,t:1528139769572};\\\", \\\"{x:1144,y:956,t:1528139769589};\\\", \\\"{x:1146,y:952,t:1528139769606};\\\", \\\"{x:1147,y:950,t:1528139769622};\\\", \\\"{x:1147,y:949,t:1528139769639};\\\", \\\"{x:1146,y:949,t:1528139770559};\\\", \\\"{x:1143,y:949,t:1528139770573};\\\", \\\"{x:1141,y:950,t:1528139770591};\\\", \\\"{x:1141,y:952,t:1528139771008};\\\", \\\"{x:1139,y:961,t:1528139771023};\\\", \\\"{x:1139,y:965,t:1528139771040};\\\", \\\"{x:1139,y:969,t:1528139771057};\\\", \\\"{x:1139,y:970,t:1528139774055};\\\", \\\"{x:1139,y:971,t:1528139774062};\\\", \\\"{x:1138,y:973,t:1528139774075};\\\", \\\"{x:1131,y:973,t:1528139774092};\\\", \\\"{x:1124,y:973,t:1528139774109};\\\", \\\"{x:1118,y:972,t:1528139774125};\\\", \\\"{x:1101,y:971,t:1528139774142};\\\", \\\"{x:1094,y:971,t:1528139774158};\\\", \\\"{x:1088,y:971,t:1528139774175};\\\", \\\"{x:1081,y:971,t:1528139774192};\\\", \\\"{x:1077,y:971,t:1528139774208};\\\", \\\"{x:1075,y:972,t:1528139774226};\\\", \\\"{x:1074,y:972,t:1528139774242};\\\", \\\"{x:1074,y:970,t:1528139774334};\\\", \\\"{x:1074,y:968,t:1528139774342};\\\", \\\"{x:1075,y:960,t:1528139774359};\\\", \\\"{x:1079,y:946,t:1528139774376};\\\", \\\"{x:1089,y:931,t:1528139774392};\\\", \\\"{x:1099,y:916,t:1528139774409};\\\", \\\"{x:1112,y:901,t:1528139774426};\\\", \\\"{x:1122,y:889,t:1528139774442};\\\", \\\"{x:1127,y:876,t:1528139774459};\\\", \\\"{x:1134,y:859,t:1528139774476};\\\", \\\"{x:1139,y:837,t:1528139774492};\\\", \\\"{x:1143,y:808,t:1528139774509};\\\", \\\"{x:1144,y:764,t:1528139774526};\\\", \\\"{x:1144,y:760,t:1528139774542};\\\", \\\"{x:1144,y:757,t:1528139774559};\\\", \\\"{x:1144,y:755,t:1528139774576};\\\", \\\"{x:1144,y:754,t:1528139774592};\\\", \\\"{x:1144,y:752,t:1528139774609};\\\", \\\"{x:1144,y:751,t:1528139774626};\\\", \\\"{x:1144,y:750,t:1528139774642};\\\", \\\"{x:1144,y:748,t:1528139774659};\\\", \\\"{x:1149,y:748,t:1528139775431};\\\", \\\"{x:1157,y:747,t:1528139775443};\\\", \\\"{x:1177,y:747,t:1528139775461};\\\", \\\"{x:1200,y:752,t:1528139775477};\\\", \\\"{x:1239,y:767,t:1528139775493};\\\", \\\"{x:1274,y:782,t:1528139775510};\\\", \\\"{x:1294,y:789,t:1528139775526};\\\", \\\"{x:1310,y:791,t:1528139775544};\\\", \\\"{x:1320,y:793,t:1528139775560};\\\", \\\"{x:1334,y:793,t:1528139775576};\\\", \\\"{x:1341,y:793,t:1528139775593};\\\", \\\"{x:1344,y:793,t:1528139775610};\\\", \\\"{x:1346,y:792,t:1528139775628};\\\", \\\"{x:1347,y:792,t:1528139775646};\\\", \\\"{x:1348,y:791,t:1528139775661};\\\", \\\"{x:1349,y:791,t:1528139775677};\\\", \\\"{x:1350,y:789,t:1528139775693};\\\", \\\"{x:1351,y:786,t:1528139775710};\\\", \\\"{x:1352,y:784,t:1528139775728};\\\", \\\"{x:1353,y:782,t:1528139775743};\\\", \\\"{x:1355,y:779,t:1528139775760};\\\", \\\"{x:1355,y:777,t:1528139775777};\\\", \\\"{x:1357,y:771,t:1528139775793};\\\", \\\"{x:1358,y:770,t:1528139775811};\\\", \\\"{x:1359,y:768,t:1528139775828};\\\", \\\"{x:1359,y:767,t:1528139775844};\\\", \\\"{x:1357,y:767,t:1528139776090};\\\", \\\"{x:1353,y:769,t:1528139776098};\\\", \\\"{x:1339,y:783,t:1528139776113};\\\", \\\"{x:1332,y:803,t:1528139776130};\\\", \\\"{x:1324,y:830,t:1528139776147};\\\", \\\"{x:1318,y:852,t:1528139776163};\\\", \\\"{x:1313,y:868,t:1528139776181};\\\", \\\"{x:1309,y:884,t:1528139776197};\\\", \\\"{x:1303,y:896,t:1528139776214};\\\", \\\"{x:1298,y:905,t:1528139776230};\\\", \\\"{x:1290,y:918,t:1528139776248};\\\", \\\"{x:1285,y:930,t:1528139776264};\\\", \\\"{x:1280,y:940,t:1528139776281};\\\", \\\"{x:1274,y:953,t:1528139776297};\\\", \\\"{x:1270,y:958,t:1528139776314};\\\", \\\"{x:1266,y:962,t:1528139776331};\\\", \\\"{x:1262,y:966,t:1528139776347};\\\", \\\"{x:1259,y:968,t:1528139776363};\\\", \\\"{x:1255,y:971,t:1528139776381};\\\", \\\"{x:1250,y:975,t:1528139776397};\\\", \\\"{x:1243,y:978,t:1528139776413};\\\", \\\"{x:1235,y:982,t:1528139776431};\\\", \\\"{x:1219,y:988,t:1528139776448};\\\", \\\"{x:1191,y:993,t:1528139776464};\\\", \\\"{x:1160,y:998,t:1528139776481};\\\", \\\"{x:1121,y:999,t:1528139776498};\\\", \\\"{x:1102,y:999,t:1528139776514};\\\", \\\"{x:1081,y:997,t:1528139776531};\\\", \\\"{x:1060,y:988,t:1528139776547};\\\", \\\"{x:1030,y:970,t:1528139776563};\\\", \\\"{x:985,y:940,t:1528139776580};\\\", \\\"{x:939,y:904,t:1528139776598};\\\", \\\"{x:901,y:864,t:1528139776614};\\\", \\\"{x:869,y:826,t:1528139776630};\\\", \\\"{x:842,y:793,t:1528139776648};\\\", \\\"{x:830,y:777,t:1528139776665};\\\", \\\"{x:814,y:756,t:1528139776680};\\\", \\\"{x:790,y:726,t:1528139776697};\\\", \\\"{x:775,y:715,t:1528139776715};\\\", \\\"{x:760,y:704,t:1528139776730};\\\", \\\"{x:742,y:695,t:1528139776747};\\\", \\\"{x:732,y:688,t:1528139776764};\\\", \\\"{x:726,y:685,t:1528139776780};\\\", \\\"{x:719,y:680,t:1528139776798};\\\", \\\"{x:709,y:672,t:1528139776815};\\\", \\\"{x:695,y:657,t:1528139776831};\\\", \\\"{x:681,y:642,t:1528139776848};\\\", \\\"{x:670,y:623,t:1528139776866};\\\", \\\"{x:660,y:603,t:1528139776880};\\\", \\\"{x:656,y:585,t:1528139776897};\\\", \\\"{x:656,y:581,t:1528139776913};\\\", \\\"{x:656,y:577,t:1528139776924};\\\", \\\"{x:660,y:562,t:1528139776942};\\\", \\\"{x:665,y:549,t:1528139776959};\\\", \\\"{x:666,y:532,t:1528139776983};\\\", \\\"{x:665,y:526,t:1528139776999};\\\", \\\"{x:657,y:520,t:1528139777017};\\\", \\\"{x:616,y:519,t:1528139777033};\\\", \\\"{x:587,y:519,t:1528139777049};\\\", \\\"{x:561,y:523,t:1528139777067};\\\", \\\"{x:540,y:526,t:1528139777084};\\\", \\\"{x:522,y:529,t:1528139777100};\\\", \\\"{x:512,y:533,t:1528139777116};\\\", \\\"{x:505,y:536,t:1528139777133};\\\", \\\"{x:500,y:540,t:1528139777150};\\\", \\\"{x:498,y:540,t:1528139777168};\\\", \\\"{x:493,y:543,t:1528139777183};\\\", \\\"{x:488,y:543,t:1528139777200};\\\", \\\"{x:476,y:543,t:1528139777217};\\\", \\\"{x:472,y:543,t:1528139777233};\\\", \\\"{x:470,y:543,t:1528139777251};\\\", \\\"{x:459,y:538,t:1528139777266};\\\", \\\"{x:438,y:530,t:1528139777284};\\\", \\\"{x:413,y:524,t:1528139777301};\\\", \\\"{x:395,y:521,t:1528139777316};\\\", \\\"{x:378,y:519,t:1528139777334};\\\", \\\"{x:363,y:517,t:1528139777351};\\\", \\\"{x:349,y:515,t:1528139777367};\\\", \\\"{x:330,y:515,t:1528139777383};\\\", \\\"{x:301,y:515,t:1528139777401};\\\", \\\"{x:268,y:515,t:1528139777417};\\\", \\\"{x:231,y:511,t:1528139777433};\\\", \\\"{x:210,y:508,t:1528139777450};\\\", \\\"{x:189,y:505,t:1528139777466};\\\", \\\"{x:173,y:505,t:1528139777483};\\\", \\\"{x:151,y:503,t:1528139777500};\\\", \\\"{x:141,y:500,t:1528139777516};\\\", \\\"{x:136,y:500,t:1528139777533};\\\", \\\"{x:136,y:499,t:1528139777601};\\\", \\\"{x:137,y:497,t:1528139777616};\\\", \\\"{x:139,y:496,t:1528139777634};\\\", \\\"{x:144,y:494,t:1528139777650};\\\", \\\"{x:146,y:493,t:1528139777668};\\\", \\\"{x:148,y:493,t:1528139777684};\\\", \\\"{x:149,y:492,t:1528139777705};\\\", \\\"{x:151,y:492,t:1528139777721};\\\", \\\"{x:153,y:492,t:1528139777986};\\\", \\\"{x:162,y:503,t:1528139778001};\\\", \\\"{x:180,y:520,t:1528139778019};\\\", \\\"{x:209,y:546,t:1528139778033};\\\", \\\"{x:251,y:582,t:1528139778051};\\\", \\\"{x:291,y:613,t:1528139778068};\\\", \\\"{x:314,y:626,t:1528139778084};\\\", \\\"{x:329,y:636,t:1528139778100};\\\", \\\"{x:353,y:648,t:1528139778118};\\\", \\\"{x:371,y:658,t:1528139778134};\\\", \\\"{x:380,y:664,t:1528139778151};\\\", \\\"{x:388,y:667,t:1528139778168};\\\", \\\"{x:401,y:674,t:1528139778185};\\\", \\\"{x:407,y:678,t:1528139778200};\\\", \\\"{x:428,y:692,t:1528139778217};\\\", \\\"{x:444,y:704,t:1528139778234};\\\", \\\"{x:456,y:713,t:1528139778251};\\\", \\\"{x:457,y:714,t:1528139778267};\\\", \\\"{x:458,y:715,t:1528139778284};\\\", \\\"{x:458,y:712,t:1528139778410};\\\", \\\"{x:456,y:704,t:1528139778419};\\\", \\\"{x:425,y:673,t:1528139778435};\\\", \\\"{x:368,y:629,t:1528139778452};\\\", \\\"{x:289,y:568,t:1528139778469};\\\", \\\"{x:227,y:522,t:1528139778485};\\\", \\\"{x:202,y:503,t:1528139778501};\\\", \\\"{x:195,y:497,t:1528139778517};\\\", \\\"{x:193,y:496,t:1528139778534};\\\", \\\"{x:193,y:495,t:1528139778673};\\\", \\\"{x:191,y:495,t:1528139778684};\\\", \\\"{x:185,y:497,t:1528139778700};\\\", \\\"{x:179,y:500,t:1528139778717};\\\", \\\"{x:175,y:501,t:1528139778733};\\\", \\\"{x:173,y:502,t:1528139778750};\\\", \\\"{x:171,y:503,t:1528139778768};\\\", \\\"{x:171,y:504,t:1528139778783};\\\", \\\"{x:170,y:504,t:1528139778800};\\\", \\\"{x:168,y:504,t:1528139778816};\\\", \\\"{x:168,y:513,t:1528139779057};\\\", \\\"{x:182,y:538,t:1528139779068};\\\", \\\"{x:228,y:584,t:1528139779084};\\\", \\\"{x:306,y:639,t:1528139779102};\\\", \\\"{x:379,y:693,t:1528139779119};\\\", \\\"{x:436,y:726,t:1528139779135};\\\", \\\"{x:469,y:746,t:1528139779152};\\\", \\\"{x:501,y:765,t:1528139779168};\\\", \\\"{x:516,y:772,t:1528139779184};\\\", \\\"{x:525,y:777,t:1528139779201};\\\", \\\"{x:532,y:778,t:1528139779218};\\\", \\\"{x:533,y:779,t:1528139779234};\\\", \\\"{x:534,y:779,t:1528139779252};\\\", \\\"{x:536,y:779,t:1528139779272};\\\", \\\"{x:537,y:779,t:1528139779285};\\\", \\\"{x:538,y:778,t:1528139779301};\\\", \\\"{x:538,y:777,t:1528139779369};\\\", \\\"{x:533,y:775,t:1528139779385};\\\", \\\"{x:523,y:770,t:1528139779402};\\\", \\\"{x:514,y:765,t:1528139779418};\\\", \\\"{x:510,y:760,t:1528139779435};\\\", \\\"{x:508,y:749,t:1528139779452};\\\", \\\"{x:505,y:733,t:1528139779468};\\\", \\\"{x:502,y:721,t:1528139779485};\\\", \\\"{x:498,y:711,t:1528139779503};\\\", \\\"{x:496,y:707,t:1528139779518};\\\", \\\"{x:496,y:706,t:1528139779536};\\\", \\\"{x:497,y:710,t:1528139779787};\\\", \\\"{x:501,y:720,t:1528139779803};\\\", \\\"{x:503,y:728,t:1528139779818};\\\", \\\"{x:503,y:729,t:1528139779835};\\\", \\\"{x:503,y:730,t:1528139779905};\\\", \\\"{x:503,y:731,t:1528139779928};\\\", \\\"{x:503,y:732,t:1528139779936};\\\", \\\"{x:503,y:734,t:1528139779953};\\\", \\\"{x:503,y:735,t:1528139779968};\\\", \\\"{x:506,y:736,t:1528139780168};\\\", \\\"{x:536,y:733,t:1528139780185};\\\", \\\"{x:597,y:733,t:1528139780202};\\\", \\\"{x:697,y:719,t:1528139780219};\\\", \\\"{x:814,y:703,t:1528139780235};\\\", \\\"{x:960,y:686,t:1528139780252};\\\", \\\"{x:1097,y:677,t:1528139780269};\\\", \\\"{x:1212,y:667,t:1528139780286};\\\", \\\"{x:1326,y:665,t:1528139780302};\\\", \\\"{x:1429,y:661,t:1528139780319};\\\", \\\"{x:1516,y:661,t:1528139780335};\\\", \\\"{x:1581,y:652,t:1528139780352};\\\", \\\"{x:1604,y:644,t:1528139780368};\\\", \\\"{x:1617,y:637,t:1528139780385};\\\", \\\"{x:1624,y:635,t:1528139780402};\\\", \\\"{x:1632,y:630,t:1528139780419};\\\", \\\"{x:1634,y:630,t:1528139780435};\\\", \\\"{x:1636,y:628,t:1528139780453};\\\", \\\"{x:1636,y:626,t:1528139780469};\\\", \\\"{x:1636,y:625,t:1528139780486};\\\", \\\"{x:1636,y:623,t:1528139780502};\\\", \\\"{x:1636,y:621,t:1528139780519};\\\", \\\"{x:1636,y:619,t:1528139780535};\\\", \\\"{x:1637,y:611,t:1528139780552};\\\", \\\"{x:1636,y:604,t:1528139780569};\\\", \\\"{x:1630,y:595,t:1528139780586};\\\", \\\"{x:1624,y:588,t:1528139780602};\\\", \\\"{x:1615,y:579,t:1528139780619};\\\", \\\"{x:1613,y:576,t:1528139780636};\\\", \\\"{x:1612,y:575,t:1528139780652};\\\", \\\"{x:1610,y:574,t:1528139780669};\\\", \\\"{x:1608,y:572,t:1528139780686};\\\", \\\"{x:1608,y:568,t:1528139781184};\\\", \\\"{x:1608,y:560,t:1528139781192};\\\", \\\"{x:1609,y:552,t:1528139781203};\\\" ] }, { \\\"rt\\\": 10435, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 902632, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1223,y:377,t:1528139781409};\\\", \\\"{x:1221,y:378,t:1528139782545};\\\", \\\"{x:1220,y:385,t:1528139782555};\\\", \\\"{x:1215,y:394,t:1528139782572};\\\", \\\"{x:1208,y:399,t:1528139782588};\\\", \\\"{x:1202,y:402,t:1528139782605};\\\", \\\"{x:1200,y:404,t:1528139782621};\\\", \\\"{x:1199,y:404,t:1528139782638};\\\", \\\"{x:1199,y:405,t:1528139782655};\\\", \\\"{x:1199,y:408,t:1528139782672};\\\", \\\"{x:1201,y:409,t:1528139782688};\\\", \\\"{x:1203,y:411,t:1528139782705};\\\", \\\"{x:1204,y:411,t:1528139782721};\\\", \\\"{x:1204,y:412,t:1528139782738};\\\", \\\"{x:1204,y:413,t:1528139782755};\\\", \\\"{x:1204,y:412,t:1528139783169};\\\", \\\"{x:1204,y:411,t:1528139783177};\\\", \\\"{x:1204,y:410,t:1528139783188};\\\", \\\"{x:1205,y:408,t:1528139783205};\\\", \\\"{x:1205,y:407,t:1528139783222};\\\", \\\"{x:1206,y:407,t:1528139783239};\\\", \\\"{x:1209,y:405,t:1528139783394};\\\", \\\"{x:1211,y:405,t:1528139783405};\\\", \\\"{x:1226,y:405,t:1528139783422};\\\", \\\"{x:1242,y:417,t:1528139783439};\\\", \\\"{x:1259,y:436,t:1528139783455};\\\", \\\"{x:1281,y:457,t:1528139783471};\\\", \\\"{x:1291,y:468,t:1528139783488};\\\", \\\"{x:1303,y:497,t:1528139783504};\\\", \\\"{x:1325,y:524,t:1528139783521};\\\", \\\"{x:1344,y:552,t:1528139783539};\\\", \\\"{x:1373,y:596,t:1528139783555};\\\", \\\"{x:1391,y:650,t:1528139783571};\\\", \\\"{x:1394,y:672,t:1528139783589};\\\", \\\"{x:1394,y:679,t:1528139783605};\\\", \\\"{x:1394,y:682,t:1528139783621};\\\", \\\"{x:1394,y:684,t:1528139783638};\\\", \\\"{x:1392,y:686,t:1528139783654};\\\", \\\"{x:1391,y:686,t:1528139783672};\\\", \\\"{x:1390,y:690,t:1528139783688};\\\", \\\"{x:1386,y:694,t:1528139783704};\\\", \\\"{x:1382,y:698,t:1528139783722};\\\", \\\"{x:1378,y:702,t:1528139783739};\\\", \\\"{x:1375,y:707,t:1528139783755};\\\", \\\"{x:1375,y:711,t:1528139783772};\\\", \\\"{x:1372,y:718,t:1528139783789};\\\", \\\"{x:1368,y:728,t:1528139783806};\\\", \\\"{x:1362,y:740,t:1528139783822};\\\", \\\"{x:1356,y:751,t:1528139783839};\\\", \\\"{x:1354,y:754,t:1528139783856};\\\", \\\"{x:1353,y:755,t:1528139783871};\\\", \\\"{x:1353,y:756,t:1528139784194};\\\", \\\"{x:1354,y:757,t:1528139784207};\\\", \\\"{x:1354,y:762,t:1528139784222};\\\", \\\"{x:1354,y:765,t:1528139784239};\\\", \\\"{x:1355,y:770,t:1528139784256};\\\", \\\"{x:1357,y:776,t:1528139784273};\\\", \\\"{x:1357,y:779,t:1528139784290};\\\", \\\"{x:1358,y:779,t:1528139784402};\\\", \\\"{x:1360,y:779,t:1528139784409};\\\", \\\"{x:1363,y:779,t:1528139784424};\\\", \\\"{x:1366,y:779,t:1528139784439};\\\", \\\"{x:1368,y:779,t:1528139784456};\\\", \\\"{x:1371,y:777,t:1528139784706};\\\", \\\"{x:1372,y:777,t:1528139784724};\\\", \\\"{x:1373,y:776,t:1528139784739};\\\", \\\"{x:1373,y:772,t:1528139784834};\\\", \\\"{x:1373,y:769,t:1528139784842};\\\", \\\"{x:1373,y:764,t:1528139784855};\\\", \\\"{x:1366,y:749,t:1528139784873};\\\", \\\"{x:1360,y:733,t:1528139784890};\\\", \\\"{x:1349,y:721,t:1528139784905};\\\", \\\"{x:1342,y:712,t:1528139784923};\\\", \\\"{x:1337,y:703,t:1528139784940};\\\", \\\"{x:1329,y:692,t:1528139784955};\\\", \\\"{x:1320,y:679,t:1528139784972};\\\", \\\"{x:1304,y:663,t:1528139784990};\\\", \\\"{x:1266,y:637,t:1528139785006};\\\", \\\"{x:1213,y:610,t:1528139785022};\\\", \\\"{x:1168,y:590,t:1528139785039};\\\", \\\"{x:1110,y:573,t:1528139785056};\\\", \\\"{x:1014,y:561,t:1528139785073};\\\", \\\"{x:964,y:561,t:1528139785089};\\\", \\\"{x:911,y:561,t:1528139785106};\\\", \\\"{x:837,y:565,t:1528139785123};\\\", \\\"{x:749,y:577,t:1528139785139};\\\", \\\"{x:670,y:590,t:1528139785156};\\\", \\\"{x:601,y:598,t:1528139785173};\\\", \\\"{x:548,y:606,t:1528139785190};\\\", \\\"{x:495,y:606,t:1528139785207};\\\", \\\"{x:436,y:606,t:1528139785222};\\\", \\\"{x:377,y:606,t:1528139785240};\\\", \\\"{x:337,y:606,t:1528139785256};\\\", \\\"{x:333,y:606,t:1528139785273};\\\", \\\"{x:332,y:606,t:1528139785304};\\\", \\\"{x:331,y:606,t:1528139785320};\\\", \\\"{x:331,y:605,t:1528139785329};\\\", \\\"{x:331,y:602,t:1528139785340};\\\", \\\"{x:331,y:597,t:1528139785357};\\\", \\\"{x:331,y:590,t:1528139785374};\\\", \\\"{x:333,y:581,t:1528139785390};\\\", \\\"{x:339,y:570,t:1528139785406};\\\", \\\"{x:357,y:558,t:1528139785424};\\\", \\\"{x:382,y:541,t:1528139785440};\\\", \\\"{x:405,y:526,t:1528139785457};\\\", \\\"{x:428,y:513,t:1528139785474};\\\", \\\"{x:453,y:503,t:1528139785489};\\\", \\\"{x:478,y:496,t:1528139785506};\\\", \\\"{x:495,y:491,t:1528139785523};\\\", \\\"{x:504,y:488,t:1528139785541};\\\", \\\"{x:509,y:486,t:1528139785557};\\\", \\\"{x:511,y:486,t:1528139785573};\\\", \\\"{x:514,y:484,t:1528139785590};\\\", \\\"{x:516,y:484,t:1528139785649};\\\", \\\"{x:520,y:485,t:1528139785656};\\\", \\\"{x:534,y:495,t:1528139785674};\\\", \\\"{x:555,y:501,t:1528139785691};\\\", \\\"{x:571,y:502,t:1528139785706};\\\", \\\"{x:579,y:502,t:1528139785724};\\\", \\\"{x:581,y:502,t:1528139785741};\\\", \\\"{x:582,y:502,t:1528139785777};\\\", \\\"{x:583,y:502,t:1528139785791};\\\", \\\"{x:587,y:502,t:1528139785808};\\\", \\\"{x:590,y:500,t:1528139785823};\\\", \\\"{x:591,y:500,t:1528139785841};\\\", \\\"{x:593,y:500,t:1528139785857};\\\", \\\"{x:595,y:499,t:1528139785896};\\\", \\\"{x:595,y:498,t:1528139785993};\\\", \\\"{x:595,y:497,t:1528139790305};\\\", \\\"{x:594,y:497,t:1528139790330};\\\", \\\"{x:593,y:498,t:1528139790513};\\\", \\\"{x:592,y:502,t:1528139790521};\\\", \\\"{x:591,y:512,t:1528139790536};\\\", \\\"{x:591,y:541,t:1528139790554};\\\", \\\"{x:592,y:572,t:1528139790568};\\\", \\\"{x:594,y:580,t:1528139790593};\\\", \\\"{x:595,y:582,t:1528139790610};\\\", \\\"{x:596,y:582,t:1528139790648};\\\", \\\"{x:598,y:581,t:1528139790660};\\\", \\\"{x:606,y:570,t:1528139790676};\\\", \\\"{x:612,y:556,t:1528139790694};\\\", \\\"{x:613,y:546,t:1528139790710};\\\", \\\"{x:614,y:541,t:1528139790728};\\\", \\\"{x:614,y:538,t:1528139790809};\\\", \\\"{x:614,y:534,t:1528139790817};\\\", \\\"{x:614,y:531,t:1528139790827};\\\", \\\"{x:616,y:523,t:1528139790845};\\\", \\\"{x:616,y:517,t:1528139790862};\\\", \\\"{x:616,y:511,t:1528139790878};\\\", \\\"{x:616,y:509,t:1528139790895};\\\", \\\"{x:617,y:506,t:1528139790910};\\\", \\\"{x:618,y:498,t:1528139790928};\\\", \\\"{x:618,y:494,t:1528139790944};\\\", \\\"{x:618,y:493,t:1528139790961};\\\", \\\"{x:616,y:493,t:1528139791152};\\\", \\\"{x:615,y:495,t:1528139791161};\\\", \\\"{x:612,y:507,t:1528139791178};\\\", \\\"{x:612,y:522,t:1528139791194};\\\", \\\"{x:610,y:539,t:1528139791212};\\\", \\\"{x:609,y:553,t:1528139791228};\\\", \\\"{x:606,y:565,t:1528139791245};\\\", \\\"{x:605,y:580,t:1528139791262};\\\", \\\"{x:605,y:599,t:1528139791278};\\\", \\\"{x:602,y:622,t:1528139791295};\\\", \\\"{x:599,y:650,t:1528139791313};\\\", \\\"{x:595,y:676,t:1528139791328};\\\", \\\"{x:593,y:690,t:1528139791344};\\\", \\\"{x:590,y:705,t:1528139791361};\\\", \\\"{x:587,y:719,t:1528139791378};\\\", \\\"{x:582,y:730,t:1528139791394};\\\", \\\"{x:574,y:744,t:1528139791412};\\\", \\\"{x:564,y:758,t:1528139791428};\\\", \\\"{x:554,y:766,t:1528139791445};\\\", \\\"{x:546,y:774,t:1528139791461};\\\", \\\"{x:540,y:778,t:1528139791477};\\\", \\\"{x:537,y:780,t:1528139791495};\\\", \\\"{x:536,y:780,t:1528139791513};\\\", \\\"{x:535,y:779,t:1528139791569};\\\", \\\"{x:535,y:772,t:1528139791578};\\\", \\\"{x:535,y:760,t:1528139791594};\\\", \\\"{x:532,y:744,t:1528139791613};\\\", \\\"{x:531,y:736,t:1528139791629};\\\", \\\"{x:531,y:732,t:1528139791644};\\\", \\\"{x:529,y:731,t:1528139791661};\\\", \\\"{x:529,y:728,t:1528139791680};\\\", \\\"{x:529,y:727,t:1528139791713};\\\", \\\"{x:529,y:726,t:1528139791727};\\\", \\\"{x:532,y:724,t:1528139791904};\\\", \\\"{x:540,y:720,t:1528139791912};\\\", \\\"{x:570,y:717,t:1528139791928};\\\", \\\"{x:640,y:704,t:1528139791944};\\\", \\\"{x:746,y:688,t:1528139791962};\\\", \\\"{x:849,y:672,t:1528139791978};\\\", \\\"{x:950,y:653,t:1528139791994};\\\", \\\"{x:1054,y:631,t:1528139792012};\\\", \\\"{x:1143,y:602,t:1528139792028};\\\", \\\"{x:1240,y:574,t:1528139792045};\\\", \\\"{x:1346,y:539,t:1528139792062};\\\", \\\"{x:1442,y:501,t:1528139792078};\\\", \\\"{x:1519,y:467,t:1528139792096};\\\", \\\"{x:1580,y:430,t:1528139792112};\\\", \\\"{x:1639,y:389,t:1528139792129};\\\", \\\"{x:1663,y:371,t:1528139792146};\\\", \\\"{x:1679,y:358,t:1528139792162};\\\", \\\"{x:1687,y:350,t:1528139792179};\\\", \\\"{x:1692,y:342,t:1528139792196};\\\", \\\"{x:1697,y:329,t:1528139792211};\\\", \\\"{x:1702,y:306,t:1528139792229};\\\", \\\"{x:1706,y:262,t:1528139792246};\\\", \\\"{x:1710,y:220,t:1528139792261};\\\", \\\"{x:1710,y:178,t:1528139792279};\\\", \\\"{x:1710,y:148,t:1528139792296};\\\", \\\"{x:1703,y:133,t:1528139792312};\\\", \\\"{x:1694,y:126,t:1528139792328};\\\", \\\"{x:1679,y:125,t:1528139792346};\\\", \\\"{x:1660,y:125,t:1528139792362};\\\", \\\"{x:1641,y:125,t:1528139792379};\\\", \\\"{x:1629,y:125,t:1528139792396};\\\", \\\"{x:1622,y:125,t:1528139792412};\\\", \\\"{x:1614,y:125,t:1528139792428};\\\", \\\"{x:1603,y:125,t:1528139792446};\\\", \\\"{x:1593,y:125,t:1528139792463};\\\", \\\"{x:1589,y:125,t:1528139792479};\\\", \\\"{x:1588,y:125,t:1528139792553};\\\", \\\"{x:1585,y:125,t:1528139792563};\\\", \\\"{x:1576,y:125,t:1528139792578};\\\", \\\"{x:1570,y:126,t:1528139792595};\\\", \\\"{x:1566,y:127,t:1528139792613};\\\", \\\"{x:1564,y:127,t:1528139792629};\\\", \\\"{x:1562,y:127,t:1528139792665};\\\", \\\"{x:1561,y:128,t:1528139792689};\\\", \\\"{x:1560,y:129,t:1528139792697};\\\" ] }, { \\\"rt\\\": 6910, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 910795, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1559,y:129,t:1528139793273};\\\", \\\"{x:1558,y:130,t:1528139793280};\\\", \\\"{x:1557,y:130,t:1528139793304};\\\", \\\"{x:1556,y:131,t:1528139793336};\\\", \\\"{x:1555,y:131,t:1528139793401};\\\", \\\"{x:1554,y:132,t:1528139793546};\\\", \\\"{x:1554,y:133,t:1528139793816};\\\", \\\"{x:1555,y:134,t:1528139793829};\\\", \\\"{x:1556,y:136,t:1528139793847};\\\", \\\"{x:1557,y:138,t:1528139793864};\\\", \\\"{x:1561,y:141,t:1528139793880};\\\", \\\"{x:1562,y:143,t:1528139793897};\\\", \\\"{x:1565,y:146,t:1528139793913};\\\", \\\"{x:1566,y:150,t:1528139793929};\\\", \\\"{x:1569,y:154,t:1528139793947};\\\", \\\"{x:1572,y:158,t:1528139793964};\\\", \\\"{x:1573,y:159,t:1528139793980};\\\", \\\"{x:1573,y:160,t:1528139794041};\\\", \\\"{x:1574,y:160,t:1528139794064};\\\", \\\"{x:1574,y:162,t:1528139795177};\\\", \\\"{x:1571,y:163,t:1528139795185};\\\", \\\"{x:1567,y:166,t:1528139795199};\\\", \\\"{x:1556,y:184,t:1528139795214};\\\", \\\"{x:1546,y:228,t:1528139795232};\\\", \\\"{x:1528,y:308,t:1528139795249};\\\", \\\"{x:1493,y:414,t:1528139795265};\\\", \\\"{x:1417,y:594,t:1528139795282};\\\", \\\"{x:1367,y:702,t:1528139795298};\\\", \\\"{x:1323,y:794,t:1528139795316};\\\", \\\"{x:1286,y:902,t:1528139795332};\\\", \\\"{x:1266,y:1017,t:1528139795349};\\\", \\\"{x:1255,y:1095,t:1528139795365};\\\", \\\"{x:1253,y:1118,t:1528139795381};\\\", \\\"{x:1250,y:1131,t:1528139795399};\\\", \\\"{x:1251,y:1142,t:1528139795416};\\\", \\\"{x:1257,y:1153,t:1528139795431};\\\", \\\"{x:1263,y:1163,t:1528139795448};\\\", \\\"{x:1269,y:1170,t:1528139795465};\\\", \\\"{x:1277,y:1173,t:1528139795482};\\\", \\\"{x:1289,y:1178,t:1528139795499};\\\", \\\"{x:1302,y:1181,t:1528139795515};\\\", \\\"{x:1309,y:1183,t:1528139795531};\\\", \\\"{x:1316,y:1183,t:1528139795547};\\\", \\\"{x:1324,y:1177,t:1528139795565};\\\", \\\"{x:1325,y:1167,t:1528139795581};\\\", \\\"{x:1329,y:1150,t:1528139795598};\\\", \\\"{x:1331,y:1128,t:1528139795615};\\\", \\\"{x:1335,y:1093,t:1528139795631};\\\", \\\"{x:1335,y:1066,t:1528139795647};\\\", \\\"{x:1337,y:1037,t:1528139795665};\\\", \\\"{x:1339,y:1026,t:1528139795682};\\\", \\\"{x:1339,y:1016,t:1528139795698};\\\", \\\"{x:1339,y:1008,t:1528139795714};\\\", \\\"{x:1339,y:1004,t:1528139795731};\\\", \\\"{x:1339,y:1001,t:1528139795748};\\\", \\\"{x:1339,y:998,t:1528139795765};\\\", \\\"{x:1344,y:996,t:1528139795781};\\\", \\\"{x:1348,y:994,t:1528139795798};\\\", \\\"{x:1349,y:988,t:1528139795815};\\\", \\\"{x:1350,y:979,t:1528139795832};\\\", \\\"{x:1351,y:964,t:1528139795849};\\\", \\\"{x:1353,y:955,t:1528139795866};\\\", \\\"{x:1356,y:944,t:1528139795882};\\\", \\\"{x:1360,y:927,t:1528139795899};\\\", \\\"{x:1361,y:910,t:1528139795915};\\\", \\\"{x:1362,y:901,t:1528139795932};\\\", \\\"{x:1363,y:896,t:1528139795949};\\\", \\\"{x:1363,y:890,t:1528139795965};\\\", \\\"{x:1363,y:884,t:1528139795982};\\\", \\\"{x:1363,y:880,t:1528139796000};\\\", \\\"{x:1363,y:878,t:1528139796015};\\\", \\\"{x:1363,y:877,t:1528139796032};\\\", \\\"{x:1364,y:876,t:1528139796050};\\\", \\\"{x:1365,y:875,t:1528139796065};\\\", \\\"{x:1366,y:874,t:1528139796082};\\\", \\\"{x:1367,y:873,t:1528139796105};\\\", \\\"{x:1367,y:872,t:1528139796116};\\\", \\\"{x:1368,y:872,t:1528139796132};\\\", \\\"{x:1371,y:870,t:1528139796201};\\\", \\\"{x:1372,y:870,t:1528139796217};\\\", \\\"{x:1373,y:869,t:1528139796233};\\\", \\\"{x:1374,y:868,t:1528139796249};\\\", \\\"{x:1375,y:868,t:1528139796297};\\\", \\\"{x:1377,y:868,t:1528139796329};\\\", \\\"{x:1378,y:867,t:1528139796346};\\\", \\\"{x:1378,y:866,t:1528139796969};\\\", \\\"{x:1377,y:858,t:1528139796983};\\\", \\\"{x:1351,y:840,t:1528139797000};\\\", \\\"{x:1279,y:793,t:1528139797017};\\\", \\\"{x:1213,y:768,t:1528139797033};\\\", \\\"{x:1150,y:751,t:1528139797049};\\\", \\\"{x:1085,y:739,t:1528139797067};\\\", \\\"{x:1026,y:730,t:1528139797083};\\\", \\\"{x:968,y:722,t:1528139797100};\\\", \\\"{x:912,y:714,t:1528139797116};\\\", \\\"{x:869,y:707,t:1528139797134};\\\", \\\"{x:842,y:702,t:1528139797149};\\\", \\\"{x:818,y:699,t:1528139797166};\\\", \\\"{x:795,y:697,t:1528139797183};\\\", \\\"{x:770,y:692,t:1528139797201};\\\", \\\"{x:721,y:684,t:1528139797217};\\\", \\\"{x:670,y:668,t:1528139797233};\\\", \\\"{x:623,y:654,t:1528139797250};\\\", \\\"{x:590,y:643,t:1528139797267};\\\", \\\"{x:561,y:634,t:1528139797284};\\\", \\\"{x:532,y:619,t:1528139797302};\\\", \\\"{x:513,y:607,t:1528139797316};\\\", \\\"{x:505,y:598,t:1528139797333};\\\", \\\"{x:496,y:590,t:1528139797350};\\\", \\\"{x:487,y:580,t:1528139797366};\\\", \\\"{x:476,y:570,t:1528139797382};\\\", \\\"{x:468,y:557,t:1528139797400};\\\", \\\"{x:468,y:546,t:1528139797417};\\\", \\\"{x:469,y:535,t:1528139797432};\\\", \\\"{x:474,y:525,t:1528139797450};\\\", \\\"{x:480,y:520,t:1528139797466};\\\", \\\"{x:496,y:512,t:1528139797483};\\\", \\\"{x:521,y:503,t:1528139797501};\\\", \\\"{x:545,y:497,t:1528139797516};\\\", \\\"{x:563,y:492,t:1528139797533};\\\", \\\"{x:574,y:489,t:1528139797550};\\\", \\\"{x:579,y:487,t:1528139797566};\\\", \\\"{x:581,y:487,t:1528139797583};\\\", \\\"{x:580,y:487,t:1528139797648};\\\", \\\"{x:576,y:489,t:1528139797657};\\\", \\\"{x:570,y:492,t:1528139797667};\\\", \\\"{x:558,y:499,t:1528139797683};\\\", \\\"{x:544,y:507,t:1528139797700};\\\", \\\"{x:527,y:514,t:1528139797717};\\\", \\\"{x:516,y:519,t:1528139797734};\\\", \\\"{x:508,y:523,t:1528139797750};\\\", \\\"{x:498,y:530,t:1528139797767};\\\", \\\"{x:486,y:537,t:1528139797784};\\\", \\\"{x:481,y:542,t:1528139797800};\\\", \\\"{x:479,y:543,t:1528139797817};\\\", \\\"{x:477,y:544,t:1528139797873};\\\", \\\"{x:473,y:544,t:1528139797888};\\\", \\\"{x:468,y:544,t:1528139797900};\\\", \\\"{x:451,y:544,t:1528139797917};\\\", \\\"{x:431,y:542,t:1528139797932};\\\", \\\"{x:408,y:539,t:1528139797950};\\\", \\\"{x:388,y:539,t:1528139797967};\\\", \\\"{x:380,y:539,t:1528139797984};\\\", \\\"{x:378,y:539,t:1528139798000};\\\", \\\"{x:377,y:539,t:1528139798017};\\\", \\\"{x:374,y:539,t:1528139798034};\\\", \\\"{x:373,y:540,t:1528139798050};\\\", \\\"{x:372,y:540,t:1528139798617};\\\", \\\"{x:371,y:557,t:1528139798634};\\\", \\\"{x:371,y:574,t:1528139798651};\\\", \\\"{x:371,y:590,t:1528139798667};\\\", \\\"{x:371,y:599,t:1528139798684};\\\", \\\"{x:376,y:611,t:1528139798702};\\\", \\\"{x:380,y:618,t:1528139798716};\\\", \\\"{x:383,y:624,t:1528139798734};\\\", \\\"{x:384,y:630,t:1528139798752};\\\", \\\"{x:384,y:636,t:1528139798768};\\\", \\\"{x:384,y:637,t:1528139798783};\\\", \\\"{x:384,y:638,t:1528139798801};\\\", \\\"{x:386,y:637,t:1528139798937};\\\", \\\"{x:386,y:632,t:1528139798951};\\\", \\\"{x:386,y:622,t:1528139798970};\\\", \\\"{x:386,y:618,t:1528139798984};\\\", \\\"{x:386,y:615,t:1528139799001};\\\", \\\"{x:386,y:614,t:1528139799018};\\\", \\\"{x:390,y:614,t:1528139799288};\\\", \\\"{x:408,y:626,t:1528139799301};\\\", \\\"{x:472,y:670,t:1528139799318};\\\", \\\"{x:521,y:706,t:1528139799335};\\\", \\\"{x:540,y:722,t:1528139799351};\\\", \\\"{x:546,y:732,t:1528139799367};\\\", \\\"{x:546,y:733,t:1528139799384};\\\", \\\"{x:547,y:735,t:1528139799408};\\\", \\\"{x:547,y:736,t:1528139799418};\\\", \\\"{x:549,y:743,t:1528139799435};\\\", \\\"{x:550,y:750,t:1528139799451};\\\", \\\"{x:550,y:757,t:1528139799469};\\\", \\\"{x:550,y:762,t:1528139799485};\\\", \\\"{x:550,y:763,t:1528139799501};\\\", \\\"{x:547,y:758,t:1528139799706};\\\", \\\"{x:544,y:751,t:1528139799720};\\\", \\\"{x:537,y:736,t:1528139799735};\\\", \\\"{x:525,y:722,t:1528139799752};\\\", \\\"{x:530,y:721,t:1528139800177};\\\", \\\"{x:541,y:721,t:1528139800185};\\\", \\\"{x:586,y:721,t:1528139800201};\\\", \\\"{x:669,y:721,t:1528139800219};\\\", \\\"{x:771,y:721,t:1528139800235};\\\", \\\"{x:888,y:721,t:1528139800252};\\\", \\\"{x:988,y:721,t:1528139800269};\\\", \\\"{x:1090,y:721,t:1528139800286};\\\", \\\"{x:1215,y:721,t:1528139800302};\\\", \\\"{x:1337,y:717,t:1528139800319};\\\", \\\"{x:1493,y:715,t:1528139800336};\\\", \\\"{x:1543,y:709,t:1528139800352};\\\", \\\"{x:1573,y:706,t:1528139800369};\\\", \\\"{x:1579,y:706,t:1528139800386};\\\", \\\"{x:1566,y:702,t:1528139800577};\\\", \\\"{x:1541,y:696,t:1528139800586};\\\", \\\"{x:1456,y:675,t:1528139800602};\\\", \\\"{x:1388,y:659,t:1528139800619};\\\", \\\"{x:1345,y:652,t:1528139800637};\\\", \\\"{x:1318,y:650,t:1528139800653};\\\", \\\"{x:1300,y:646,t:1528139800669};\\\", \\\"{x:1284,y:641,t:1528139800686};\\\", \\\"{x:1273,y:640,t:1528139800704};\\\", \\\"{x:1266,y:640,t:1528139800720};\\\", \\\"{x:1265,y:640,t:1528139800736};\\\", \\\"{x:1264,y:640,t:1528139800769};\\\", \\\"{x:1259,y:640,t:1528139800786};\\\", \\\"{x:1250,y:640,t:1528139800803};\\\", \\\"{x:1237,y:640,t:1528139800819};\\\", \\\"{x:1221,y:640,t:1528139800836};\\\", \\\"{x:1205,y:637,t:1528139800854};\\\", \\\"{x:1187,y:631,t:1528139800869};\\\", \\\"{x:1170,y:626,t:1528139800886};\\\", \\\"{x:1150,y:617,t:1528139800904};\\\", \\\"{x:1130,y:608,t:1528139800920};\\\", \\\"{x:1104,y:596,t:1528139800937};\\\", \\\"{x:1097,y:592,t:1528139800953};\\\", \\\"{x:1096,y:592,t:1528139800970};\\\" ] }, { \\\"rt\\\": 9128, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 921139, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1078,y:585,t:1528139801218};\\\", \\\"{x:1075,y:583,t:1528139801243};\\\", \\\"{x:1072,y:583,t:1528139801252};\\\", \\\"{x:1071,y:581,t:1528139801269};\\\", \\\"{x:1070,y:581,t:1528139801286};\\\", \\\"{x:1069,y:580,t:1528139801302};\\\", \\\"{x:1068,y:580,t:1528139801319};\\\", \\\"{x:1065,y:577,t:1528139801336};\\\", \\\"{x:1063,y:577,t:1528139801353};\\\", \\\"{x:1062,y:576,t:1528139801376};\\\", \\\"{x:1060,y:576,t:1528139802873};\\\", \\\"{x:1059,y:576,t:1528139802887};\\\", \\\"{x:1051,y:578,t:1528139802903};\\\", \\\"{x:1049,y:579,t:1528139802921};\\\", \\\"{x:1046,y:580,t:1528139802937};\\\", \\\"{x:1045,y:582,t:1528139802954};\\\", \\\"{x:1048,y:582,t:1528139803120};\\\", \\\"{x:1052,y:582,t:1528139803128};\\\", \\\"{x:1056,y:581,t:1528139803137};\\\", \\\"{x:1071,y:581,t:1528139803154};\\\", \\\"{x:1094,y:586,t:1528139803171};\\\", \\\"{x:1129,y:604,t:1528139803187};\\\", \\\"{x:1177,y:628,t:1528139803204};\\\", \\\"{x:1216,y:653,t:1528139803221};\\\", \\\"{x:1237,y:669,t:1528139803237};\\\", \\\"{x:1248,y:682,t:1528139803254};\\\", \\\"{x:1255,y:694,t:1528139803271};\\\", \\\"{x:1266,y:714,t:1528139803288};\\\", \\\"{x:1269,y:723,t:1528139803304};\\\", \\\"{x:1273,y:728,t:1528139803321};\\\", \\\"{x:1284,y:737,t:1528139803338};\\\", \\\"{x:1300,y:742,t:1528139803354};\\\", \\\"{x:1314,y:742,t:1528139803371};\\\", \\\"{x:1320,y:742,t:1528139803388};\\\", \\\"{x:1322,y:742,t:1528139803404};\\\", \\\"{x:1323,y:741,t:1528139803496};\\\", \\\"{x:1323,y:738,t:1528139803504};\\\", \\\"{x:1324,y:738,t:1528139803521};\\\", \\\"{x:1324,y:737,t:1528139803539};\\\", \\\"{x:1325,y:736,t:1528139803576};\\\", \\\"{x:1326,y:733,t:1528139803588};\\\", \\\"{x:1330,y:727,t:1528139803605};\\\", \\\"{x:1333,y:720,t:1528139803621};\\\", \\\"{x:1334,y:716,t:1528139803638};\\\", \\\"{x:1336,y:713,t:1528139803655};\\\", \\\"{x:1336,y:712,t:1528139803673};\\\", \\\"{x:1337,y:709,t:1528139803689};\\\", \\\"{x:1339,y:708,t:1528139803705};\\\", \\\"{x:1342,y:705,t:1528139803722};\\\", \\\"{x:1344,y:704,t:1528139803739};\\\", \\\"{x:1344,y:703,t:1528139803761};\\\", \\\"{x:1345,y:702,t:1528139804185};\\\", \\\"{x:1345,y:701,t:1528139804228};\\\", \\\"{x:1346,y:701,t:1528139805217};\\\", \\\"{x:1346,y:700,t:1528139805225};\\\", \\\"{x:1343,y:700,t:1528139805240};\\\", \\\"{x:1330,y:708,t:1528139805258};\\\", \\\"{x:1323,y:711,t:1528139805273};\\\", \\\"{x:1315,y:713,t:1528139805290};\\\", \\\"{x:1309,y:717,t:1528139805307};\\\", \\\"{x:1297,y:718,t:1528139805323};\\\", \\\"{x:1275,y:721,t:1528139805340};\\\", \\\"{x:1246,y:722,t:1528139805357};\\\", \\\"{x:1216,y:722,t:1528139805373};\\\", \\\"{x:1185,y:722,t:1528139805390};\\\", \\\"{x:1154,y:722,t:1528139805407};\\\", \\\"{x:1126,y:722,t:1528139805423};\\\", \\\"{x:1108,y:722,t:1528139805440};\\\", \\\"{x:1088,y:720,t:1528139805457};\\\", \\\"{x:1082,y:720,t:1528139805473};\\\", \\\"{x:1078,y:719,t:1528139805490};\\\", \\\"{x:1075,y:719,t:1528139806090};\\\", \\\"{x:1049,y:719,t:1528139806107};\\\", \\\"{x:1025,y:719,t:1528139806124};\\\", \\\"{x:999,y:719,t:1528139806141};\\\", \\\"{x:960,y:719,t:1528139806157};\\\", \\\"{x:901,y:719,t:1528139806174};\\\", \\\"{x:856,y:719,t:1528139806190};\\\", \\\"{x:822,y:719,t:1528139806207};\\\", \\\"{x:799,y:719,t:1528139806224};\\\", \\\"{x:777,y:719,t:1528139806241};\\\", \\\"{x:760,y:719,t:1528139806257};\\\", \\\"{x:746,y:719,t:1528139806274};\\\", \\\"{x:733,y:719,t:1528139806290};\\\", \\\"{x:717,y:716,t:1528139806307};\\\", \\\"{x:694,y:710,t:1528139806324};\\\", \\\"{x:671,y:701,t:1528139806341};\\\", \\\"{x:649,y:689,t:1528139806357};\\\", \\\"{x:639,y:674,t:1528139806374};\\\", \\\"{x:632,y:661,t:1528139806390};\\\", \\\"{x:624,y:642,t:1528139806407};\\\", \\\"{x:610,y:618,t:1528139806426};\\\", \\\"{x:583,y:583,t:1528139806442};\\\", \\\"{x:540,y:545,t:1528139806474};\\\", \\\"{x:518,y:532,t:1528139806490};\\\", \\\"{x:502,y:522,t:1528139806507};\\\", \\\"{x:485,y:514,t:1528139806524};\\\", \\\"{x:468,y:509,t:1528139806540};\\\", \\\"{x:453,y:509,t:1528139806557};\\\", \\\"{x:435,y:509,t:1528139806573};\\\", \\\"{x:417,y:509,t:1528139806590};\\\", \\\"{x:405,y:509,t:1528139806607};\\\", \\\"{x:404,y:509,t:1528139806623};\\\", \\\"{x:403,y:509,t:1528139806704};\\\", \\\"{x:403,y:511,t:1528139806712};\\\", \\\"{x:405,y:513,t:1528139806724};\\\", \\\"{x:411,y:513,t:1528139806740};\\\", \\\"{x:412,y:513,t:1528139806757};\\\", \\\"{x:413,y:514,t:1528139806775};\\\", \\\"{x:406,y:518,t:1528139806790};\\\", \\\"{x:373,y:534,t:1528139806807};\\\", \\\"{x:317,y:557,t:1528139806824};\\\", \\\"{x:284,y:564,t:1528139806841};\\\", \\\"{x:253,y:569,t:1528139806858};\\\", \\\"{x:219,y:578,t:1528139806874};\\\", \\\"{x:198,y:589,t:1528139806890};\\\", \\\"{x:181,y:603,t:1528139806908};\\\", \\\"{x:169,y:620,t:1528139806925};\\\", \\\"{x:160,y:632,t:1528139806941};\\\", \\\"{x:154,y:639,t:1528139806958};\\\", \\\"{x:150,y:643,t:1528139806975};\\\", \\\"{x:143,y:647,t:1528139806992};\\\", \\\"{x:142,y:647,t:1528139807007};\\\", \\\"{x:141,y:647,t:1528139807024};\\\", \\\"{x:141,y:648,t:1528139807249};\\\", \\\"{x:141,y:647,t:1528139807258};\\\", \\\"{x:161,y:643,t:1528139807276};\\\", \\\"{x:225,y:644,t:1528139807292};\\\", \\\"{x:314,y:644,t:1528139807310};\\\", \\\"{x:433,y:644,t:1528139807325};\\\", \\\"{x:545,y:637,t:1528139807341};\\\", \\\"{x:636,y:631,t:1528139807358};\\\", \\\"{x:700,y:621,t:1528139807374};\\\", \\\"{x:743,y:614,t:1528139807392};\\\", \\\"{x:802,y:603,t:1528139807408};\\\", \\\"{x:832,y:595,t:1528139807425};\\\", \\\"{x:860,y:593,t:1528139807442};\\\", \\\"{x:892,y:588,t:1528139807458};\\\", \\\"{x:931,y:583,t:1528139807474};\\\", \\\"{x:964,y:583,t:1528139807492};\\\", \\\"{x:999,y:581,t:1528139807508};\\\", \\\"{x:1018,y:577,t:1528139807524};\\\", \\\"{x:1016,y:575,t:1528139807568};\\\", \\\"{x:1009,y:572,t:1528139807575};\\\", \\\"{x:1000,y:567,t:1528139807591};\\\", \\\"{x:955,y:549,t:1528139807608};\\\", \\\"{x:922,y:537,t:1528139807624};\\\", \\\"{x:886,y:528,t:1528139807641};\\\", \\\"{x:856,y:518,t:1528139807659};\\\", \\\"{x:840,y:517,t:1528139807674};\\\", \\\"{x:833,y:517,t:1528139807691};\\\", \\\"{x:831,y:516,t:1528139807708};\\\", \\\"{x:830,y:516,t:1528139807736};\\\", \\\"{x:829,y:516,t:1528139807760};\\\", \\\"{x:828,y:516,t:1528139807808};\\\", \\\"{x:828,y:518,t:1528139807826};\\\", \\\"{x:828,y:524,t:1528139807842};\\\", \\\"{x:828,y:532,t:1528139807859};\\\", \\\"{x:828,y:537,t:1528139807875};\\\", \\\"{x:828,y:540,t:1528139807891};\\\", \\\"{x:828,y:544,t:1528139807908};\\\", \\\"{x:828,y:546,t:1528139807925};\\\", \\\"{x:828,y:550,t:1528139807941};\\\", \\\"{x:828,y:551,t:1528139807959};\\\", \\\"{x:828,y:552,t:1528139807984};\\\", \\\"{x:824,y:558,t:1528139808267};\\\", \\\"{x:821,y:565,t:1528139808275};\\\", \\\"{x:803,y:581,t:1528139808291};\\\", \\\"{x:782,y:594,t:1528139808308};\\\", \\\"{x:768,y:602,t:1528139808326};\\\", \\\"{x:752,y:609,t:1528139808342};\\\", \\\"{x:736,y:620,t:1528139808359};\\\", \\\"{x:721,y:632,t:1528139808376};\\\", \\\"{x:716,y:637,t:1528139808392};\\\", \\\"{x:720,y:636,t:1528139808423};\\\", \\\"{x:727,y:631,t:1528139808432};\\\", \\\"{x:732,y:627,t:1528139808442};\\\", \\\"{x:743,y:620,t:1528139808458};\\\", \\\"{x:762,y:607,t:1528139808475};\\\", \\\"{x:781,y:594,t:1528139808492};\\\", \\\"{x:797,y:577,t:1528139808509};\\\", \\\"{x:806,y:567,t:1528139808526};\\\", \\\"{x:809,y:562,t:1528139808543};\\\", \\\"{x:809,y:557,t:1528139808559};\\\", \\\"{x:810,y:556,t:1528139808575};\\\", \\\"{x:810,y:554,t:1528139808593};\\\", \\\"{x:810,y:553,t:1528139808609};\\\", \\\"{x:810,y:552,t:1528139808626};\\\", \\\"{x:810,y:551,t:1528139808642};\\\", \\\"{x:810,y:549,t:1528139808659};\\\", \\\"{x:810,y:544,t:1528139808676};\\\", \\\"{x:810,y:543,t:1528139808692};\\\", \\\"{x:811,y:540,t:1528139808745};\\\", \\\"{x:814,y:539,t:1528139808759};\\\", \\\"{x:817,y:536,t:1528139808775};\\\", \\\"{x:819,y:536,t:1528139808793};\\\", \\\"{x:820,y:535,t:1528139808809};\\\", \\\"{x:821,y:535,t:1528139808833};\\\", \\\"{x:820,y:535,t:1528139809201};\\\", \\\"{x:820,y:536,t:1528139809210};\\\", \\\"{x:822,y:537,t:1528139809227};\\\", \\\"{x:826,y:537,t:1528139809243};\\\", \\\"{x:827,y:537,t:1528139809260};\\\", \\\"{x:828,y:537,t:1528139809280};\\\", \\\"{x:831,y:537,t:1528139809292};\\\", \\\"{x:826,y:538,t:1528139809528};\\\", \\\"{x:813,y:544,t:1528139809544};\\\", \\\"{x:791,y:559,t:1528139809559};\\\", \\\"{x:766,y:587,t:1528139809576};\\\", \\\"{x:743,y:601,t:1528139809593};\\\", \\\"{x:717,y:617,t:1528139809610};\\\", \\\"{x:696,y:624,t:1528139809626};\\\", \\\"{x:677,y:632,t:1528139809644};\\\", \\\"{x:659,y:641,t:1528139809660};\\\", \\\"{x:633,y:650,t:1528139809676};\\\", \\\"{x:611,y:658,t:1528139809693};\\\", \\\"{x:586,y:669,t:1528139809709};\\\", \\\"{x:566,y:679,t:1528139809727};\\\", \\\"{x:550,y:691,t:1528139809743};\\\", \\\"{x:535,y:701,t:1528139809759};\\\", \\\"{x:509,y:722,t:1528139809777};\\\", \\\"{x:494,y:733,t:1528139809794};\\\", \\\"{x:484,y:749,t:1528139809810};\\\", \\\"{x:476,y:767,t:1528139809827};\\\", \\\"{x:466,y:783,t:1528139809843};\\\", \\\"{x:461,y:796,t:1528139809859};\\\", \\\"{x:461,y:797,t:1528139809876};\\\", \\\"{x:462,y:797,t:1528139809968};\\\", \\\"{x:468,y:792,t:1528139809977};\\\", \\\"{x:483,y:781,t:1528139809993};\\\", \\\"{x:497,y:770,t:1528139810010};\\\", \\\"{x:510,y:758,t:1528139810026};\\\", \\\"{x:514,y:754,t:1528139810044};\\\", \\\"{x:516,y:753,t:1528139810060};\\\", \\\"{x:517,y:751,t:1528139810076};\\\", \\\"{x:518,y:750,t:1528139810094};\\\", \\\"{x:521,y:748,t:1528139810109};\\\", \\\"{x:522,y:746,t:1528139810127};\\\", \\\"{x:523,y:745,t:1528139810143};\\\", \\\"{x:524,y:744,t:1528139810160};\\\", \\\"{x:524,y:742,t:1528139810177};\\\", \\\"{x:525,y:741,t:1528139810194};\\\", \\\"{x:525,y:739,t:1528139810209};\\\", \\\"{x:526,y:738,t:1528139810241};\\\", \\\"{x:530,y:738,t:1528139810455};\\\", \\\"{x:537,y:735,t:1528139810463};\\\", \\\"{x:550,y:728,t:1528139810477};\\\", \\\"{x:602,y:714,t:1528139810493};\\\", \\\"{x:705,y:702,t:1528139810510};\\\", \\\"{x:848,y:687,t:1528139810527};\\\", \\\"{x:990,y:681,t:1528139810543};\\\", \\\"{x:1217,y:678,t:1528139810559};\\\", \\\"{x:1366,y:676,t:1528139810577};\\\", \\\"{x:1499,y:676,t:1528139810594};\\\", \\\"{x:1594,y:676,t:1528139810610};\\\", \\\"{x:1671,y:676,t:1528139810628};\\\", \\\"{x:1722,y:676,t:1528139810643};\\\", \\\"{x:1752,y:676,t:1528139810660};\\\", \\\"{x:1774,y:676,t:1528139810677};\\\", \\\"{x:1787,y:673,t:1528139810693};\\\", \\\"{x:1791,y:673,t:1528139810710};\\\", \\\"{x:1793,y:673,t:1528139810728};\\\", \\\"{x:1792,y:673,t:1528139810889};\\\", \\\"{x:1790,y:673,t:1528139810897};\\\", \\\"{x:1786,y:673,t:1528139810911};\\\", \\\"{x:1780,y:673,t:1528139810928};\\\", \\\"{x:1778,y:673,t:1528139810944};\\\", \\\"{x:1776,y:673,t:1528139810961};\\\", \\\"{x:1773,y:673,t:1528139810977};\\\", \\\"{x:1771,y:673,t:1528139811008};\\\" ] }, { \\\"rt\\\": 9773, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 932187, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-D -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1773,y:673,t:1528139811671};\\\", \\\"{x:1783,y:669,t:1528139811679};\\\", \\\"{x:1792,y:669,t:1528139811694};\\\", \\\"{x:1816,y:669,t:1528139811711};\\\", \\\"{x:1866,y:669,t:1528139811728};\\\", \\\"{x:1919,y:669,t:1528139811744};\\\", \\\"{x:1919,y:670,t:1528139811815};\\\", \\\"{x:1919,y:671,t:1528139811828};\\\", \\\"{x:1919,y:676,t:1528139811844};\\\", \\\"{x:1919,y:679,t:1528139811861};\\\", \\\"{x:1919,y:681,t:1528139811878};\\\", \\\"{x:1919,y:682,t:1528139811894};\\\", \\\"{x:1918,y:682,t:1528139813505};\\\", \\\"{x:1915,y:683,t:1528139813512};\\\", \\\"{x:1909,y:685,t:1528139813530};\\\", \\\"{x:1888,y:694,t:1528139813546};\\\", \\\"{x:1849,y:708,t:1528139813564};\\\", \\\"{x:1793,y:733,t:1528139813580};\\\", \\\"{x:1722,y:765,t:1528139813597};\\\", \\\"{x:1647,y:798,t:1528139813614};\\\", \\\"{x:1575,y:830,t:1528139813630};\\\", \\\"{x:1520,y:855,t:1528139813648};\\\", \\\"{x:1473,y:884,t:1528139813665};\\\", \\\"{x:1423,y:922,t:1528139813681};\\\", \\\"{x:1401,y:952,t:1528139813697};\\\", \\\"{x:1387,y:971,t:1528139813714};\\\", \\\"{x:1378,y:982,t:1528139813732};\\\", \\\"{x:1374,y:989,t:1528139813747};\\\", \\\"{x:1372,y:991,t:1528139813765};\\\", \\\"{x:1371,y:992,t:1528139813781};\\\", \\\"{x:1371,y:994,t:1528139813797};\\\", \\\"{x:1372,y:994,t:1528139813897};\\\", \\\"{x:1377,y:991,t:1528139813914};\\\", \\\"{x:1390,y:986,t:1528139813931};\\\", \\\"{x:1402,y:981,t:1528139813948};\\\", \\\"{x:1410,y:978,t:1528139813964};\\\", \\\"{x:1422,y:975,t:1528139813981};\\\", \\\"{x:1433,y:972,t:1528139813998};\\\", \\\"{x:1442,y:968,t:1528139814015};\\\", \\\"{x:1453,y:966,t:1528139814031};\\\", \\\"{x:1464,y:963,t:1528139814047};\\\", \\\"{x:1480,y:959,t:1528139814064};\\\", \\\"{x:1490,y:956,t:1528139814080};\\\", \\\"{x:1502,y:953,t:1528139814097};\\\", \\\"{x:1513,y:951,t:1528139814114};\\\", \\\"{x:1522,y:951,t:1528139814130};\\\", \\\"{x:1529,y:951,t:1528139814148};\\\", \\\"{x:1535,y:951,t:1528139814165};\\\", \\\"{x:1542,y:951,t:1528139814182};\\\", \\\"{x:1548,y:949,t:1528139814198};\\\", \\\"{x:1555,y:949,t:1528139814214};\\\", \\\"{x:1562,y:949,t:1528139814231};\\\", \\\"{x:1566,y:949,t:1528139814247};\\\", \\\"{x:1570,y:949,t:1528139814265};\\\", \\\"{x:1572,y:949,t:1528139814282};\\\", \\\"{x:1577,y:949,t:1528139814298};\\\", \\\"{x:1588,y:949,t:1528139814315};\\\", \\\"{x:1598,y:948,t:1528139814332};\\\", \\\"{x:1612,y:947,t:1528139814349};\\\", \\\"{x:1628,y:944,t:1528139814365};\\\", \\\"{x:1643,y:942,t:1528139814382};\\\", \\\"{x:1659,y:937,t:1528139814399};\\\", \\\"{x:1673,y:931,t:1528139814415};\\\", \\\"{x:1687,y:924,t:1528139814432};\\\", \\\"{x:1709,y:900,t:1528139814448};\\\", \\\"{x:1724,y:872,t:1528139814465};\\\", \\\"{x:1743,y:832,t:1528139814483};\\\", \\\"{x:1756,y:790,t:1528139814500};\\\", \\\"{x:1766,y:746,t:1528139814516};\\\", \\\"{x:1774,y:701,t:1528139814532};\\\", \\\"{x:1775,y:666,t:1528139814549};\\\", \\\"{x:1772,y:628,t:1528139814566};\\\", \\\"{x:1762,y:596,t:1528139814582};\\\", \\\"{x:1747,y:572,t:1528139814599};\\\", \\\"{x:1729,y:550,t:1528139814616};\\\", \\\"{x:1702,y:525,t:1528139814633};\\\", \\\"{x:1686,y:512,t:1528139814649};\\\", \\\"{x:1675,y:504,t:1528139814666};\\\", \\\"{x:1669,y:501,t:1528139814683};\\\", \\\"{x:1668,y:501,t:1528139814699};\\\", \\\"{x:1667,y:501,t:1528139814729};\\\", \\\"{x:1665,y:501,t:1528139814744};\\\", \\\"{x:1664,y:501,t:1528139814753};\\\", \\\"{x:1662,y:501,t:1528139814766};\\\", \\\"{x:1657,y:513,t:1528139814783};\\\", \\\"{x:1650,y:534,t:1528139814799};\\\", \\\"{x:1642,y:571,t:1528139814817};\\\", \\\"{x:1638,y:594,t:1528139814833};\\\", \\\"{x:1636,y:612,t:1528139814850};\\\", \\\"{x:1635,y:625,t:1528139814866};\\\", \\\"{x:1635,y:634,t:1528139814883};\\\", \\\"{x:1634,y:641,t:1528139814900};\\\", \\\"{x:1633,y:648,t:1528139814916};\\\", \\\"{x:1632,y:658,t:1528139814934};\\\", \\\"{x:1631,y:669,t:1528139814950};\\\", \\\"{x:1631,y:676,t:1528139814967};\\\", \\\"{x:1631,y:677,t:1528139814983};\\\", \\\"{x:1629,y:679,t:1528139815057};\\\", \\\"{x:1626,y:680,t:1528139815073};\\\", \\\"{x:1624,y:682,t:1528139815083};\\\", \\\"{x:1622,y:683,t:1528139815101};\\\", \\\"{x:1618,y:686,t:1528139815117};\\\", \\\"{x:1616,y:691,t:1528139815133};\\\", \\\"{x:1612,y:695,t:1528139815151};\\\", \\\"{x:1611,y:697,t:1528139815167};\\\", \\\"{x:1609,y:699,t:1528139815184};\\\", \\\"{x:1607,y:704,t:1528139815201};\\\", \\\"{x:1603,y:711,t:1528139815217};\\\", \\\"{x:1602,y:714,t:1528139815234};\\\", \\\"{x:1602,y:715,t:1528139815250};\\\", \\\"{x:1601,y:716,t:1528139815267};\\\", \\\"{x:1601,y:718,t:1528139815593};\\\", \\\"{x:1599,y:721,t:1528139815601};\\\", \\\"{x:1594,y:727,t:1528139815618};\\\", \\\"{x:1591,y:732,t:1528139815635};\\\", \\\"{x:1588,y:736,t:1528139815651};\\\", \\\"{x:1587,y:739,t:1528139815668};\\\", \\\"{x:1585,y:744,t:1528139815685};\\\", \\\"{x:1583,y:746,t:1528139815702};\\\", \\\"{x:1582,y:749,t:1528139815718};\\\", \\\"{x:1580,y:753,t:1528139815736};\\\", \\\"{x:1579,y:754,t:1528139815752};\\\", \\\"{x:1576,y:759,t:1528139815768};\\\", \\\"{x:1575,y:761,t:1528139815785};\\\", \\\"{x:1574,y:764,t:1528139815802};\\\", \\\"{x:1572,y:768,t:1528139815818};\\\", \\\"{x:1568,y:776,t:1528139815835};\\\", \\\"{x:1564,y:785,t:1528139815851};\\\", \\\"{x:1561,y:795,t:1528139815868};\\\", \\\"{x:1558,y:799,t:1528139815884};\\\", \\\"{x:1556,y:805,t:1528139815902};\\\", \\\"{x:1554,y:809,t:1528139815918};\\\", \\\"{x:1552,y:812,t:1528139815934};\\\", \\\"{x:1552,y:814,t:1528139815952};\\\", \\\"{x:1551,y:816,t:1528139815967};\\\", \\\"{x:1551,y:817,t:1528139816008};\\\", \\\"{x:1551,y:818,t:1528139816019};\\\", \\\"{x:1550,y:819,t:1528139816035};\\\", \\\"{x:1550,y:820,t:1528139816056};\\\", \\\"{x:1550,y:821,t:1528139816069};\\\", \\\"{x:1549,y:821,t:1528139816085};\\\", \\\"{x:1549,y:822,t:1528139816104};\\\", \\\"{x:1549,y:823,t:1528139816120};\\\", \\\"{x:1549,y:824,t:1528139816153};\\\", \\\"{x:1547,y:826,t:1528139816169};\\\", \\\"{x:1547,y:827,t:1528139816185};\\\", \\\"{x:1546,y:829,t:1528139816201};\\\", \\\"{x:1545,y:830,t:1528139816219};\\\", \\\"{x:1545,y:832,t:1528139816236};\\\", \\\"{x:1543,y:836,t:1528139816253};\\\", \\\"{x:1541,y:841,t:1528139816269};\\\", \\\"{x:1539,y:846,t:1528139816286};\\\", \\\"{x:1535,y:852,t:1528139816303};\\\", \\\"{x:1533,y:854,t:1528139816319};\\\", \\\"{x:1531,y:859,t:1528139816336};\\\", \\\"{x:1530,y:861,t:1528139816352};\\\", \\\"{x:1529,y:864,t:1528139816369};\\\", \\\"{x:1528,y:867,t:1528139816386};\\\", \\\"{x:1527,y:869,t:1528139816403};\\\", \\\"{x:1526,y:872,t:1528139816420};\\\", \\\"{x:1524,y:876,t:1528139816436};\\\", \\\"{x:1523,y:880,t:1528139816453};\\\", \\\"{x:1522,y:886,t:1528139816470};\\\", \\\"{x:1521,y:892,t:1528139816486};\\\", \\\"{x:1521,y:897,t:1528139816503};\\\", \\\"{x:1520,y:903,t:1528139816521};\\\", \\\"{x:1520,y:909,t:1528139816537};\\\", \\\"{x:1519,y:913,t:1528139816553};\\\", \\\"{x:1519,y:917,t:1528139816570};\\\", \\\"{x:1517,y:922,t:1528139816587};\\\", \\\"{x:1516,y:927,t:1528139816603};\\\", \\\"{x:1514,y:930,t:1528139816620};\\\", \\\"{x:1511,y:933,t:1528139816637};\\\", \\\"{x:1508,y:937,t:1528139816653};\\\", \\\"{x:1505,y:940,t:1528139816670};\\\", \\\"{x:1504,y:943,t:1528139816687};\\\", \\\"{x:1502,y:944,t:1528139816704};\\\", \\\"{x:1495,y:949,t:1528139816720};\\\", \\\"{x:1487,y:953,t:1528139816737};\\\", \\\"{x:1482,y:956,t:1528139816754};\\\", \\\"{x:1478,y:959,t:1528139816770};\\\", \\\"{x:1474,y:960,t:1528139816787};\\\", \\\"{x:1473,y:961,t:1528139816804};\\\", \\\"{x:1474,y:961,t:1528139817097};\\\", \\\"{x:1475,y:961,t:1528139817113};\\\", \\\"{x:1477,y:961,t:1528139817121};\\\", \\\"{x:1479,y:961,t:1528139817139};\\\", \\\"{x:1480,y:960,t:1528139817154};\\\", \\\"{x:1480,y:956,t:1528139818426};\\\", \\\"{x:1455,y:929,t:1528139818440};\\\", \\\"{x:1400,y:881,t:1528139818457};\\\", \\\"{x:1302,y:828,t:1528139818474};\\\", \\\"{x:1154,y:750,t:1528139818491};\\\", \\\"{x:967,y:671,t:1528139818506};\\\", \\\"{x:785,y:617,t:1528139818524};\\\", \\\"{x:607,y:583,t:1528139818541};\\\", \\\"{x:526,y:572,t:1528139818550};\\\", \\\"{x:430,y:574,t:1528139818567};\\\", \\\"{x:428,y:574,t:1528139818825};\\\", \\\"{x:428,y:573,t:1528139818841};\\\", \\\"{x:432,y:572,t:1528139818851};\\\", \\\"{x:455,y:566,t:1528139818868};\\\", \\\"{x:497,y:561,t:1528139818885};\\\", \\\"{x:540,y:554,t:1528139818901};\\\", \\\"{x:566,y:548,t:1528139818918};\\\", \\\"{x:582,y:542,t:1528139818934};\\\", \\\"{x:593,y:538,t:1528139818951};\\\", \\\"{x:595,y:536,t:1528139818967};\\\", \\\"{x:596,y:530,t:1528139818984};\\\", \\\"{x:596,y:524,t:1528139819001};\\\", \\\"{x:596,y:522,t:1528139819017};\\\", \\\"{x:596,y:517,t:1528139819035};\\\", \\\"{x:596,y:513,t:1528139819051};\\\", \\\"{x:596,y:506,t:1528139819068};\\\", \\\"{x:595,y:501,t:1528139819084};\\\", \\\"{x:593,y:493,t:1528139819101};\\\", \\\"{x:593,y:489,t:1528139819117};\\\", \\\"{x:593,y:487,t:1528139819134};\\\", \\\"{x:593,y:486,t:1528139819151};\\\", \\\"{x:593,y:485,t:1528139819167};\\\", \\\"{x:594,y:484,t:1528139819184};\\\", \\\"{x:595,y:483,t:1528139819201};\\\", \\\"{x:597,y:483,t:1528139819345};\\\", \\\"{x:597,y:484,t:1528139819352};\\\", \\\"{x:599,y:487,t:1528139819369};\\\", \\\"{x:600,y:489,t:1528139819384};\\\", \\\"{x:602,y:494,t:1528139819401};\\\", \\\"{x:603,y:497,t:1528139819418};\\\", \\\"{x:606,y:500,t:1528139819434};\\\", \\\"{x:607,y:501,t:1528139819451};\\\", \\\"{x:607,y:504,t:1528139819467};\\\", \\\"{x:607,y:505,t:1528139819484};\\\", \\\"{x:607,y:506,t:1528139819502};\\\", \\\"{x:610,y:507,t:1528139819734};\\\", \\\"{x:642,y:507,t:1528139819752};\\\", \\\"{x:670,y:507,t:1528139819767};\\\", \\\"{x:700,y:507,t:1528139819784};\\\", \\\"{x:731,y:507,t:1528139819802};\\\", \\\"{x:754,y:507,t:1528139819818};\\\", \\\"{x:768,y:506,t:1528139819835};\\\", \\\"{x:781,y:505,t:1528139819852};\\\", \\\"{x:789,y:505,t:1528139819868};\\\", \\\"{x:794,y:505,t:1528139819884};\\\", \\\"{x:800,y:505,t:1528139819902};\\\", \\\"{x:803,y:505,t:1528139819918};\\\", \\\"{x:804,y:505,t:1528139819935};\\\", \\\"{x:810,y:505,t:1528139819952};\\\", \\\"{x:811,y:505,t:1528139819968};\\\", \\\"{x:814,y:505,t:1528139820049};\\\", \\\"{x:815,y:505,t:1528139820056};\\\", \\\"{x:817,y:505,t:1528139820068};\\\", \\\"{x:820,y:505,t:1528139820085};\\\", \\\"{x:821,y:505,t:1528139820417};\\\", \\\"{x:822,y:505,t:1528139820425};\\\", \\\"{x:823,y:505,t:1528139820436};\\\", \\\"{x:826,y:507,t:1528139820453};\\\", \\\"{x:827,y:507,t:1528139820469};\\\", \\\"{x:828,y:507,t:1528139820486};\\\", \\\"{x:829,y:507,t:1528139820545};\\\", \\\"{x:830,y:507,t:1528139820552};\\\", \\\"{x:832,y:507,t:1528139820568};\\\", \\\"{x:832,y:506,t:1528139820586};\\\", \\\"{x:829,y:507,t:1528139820799};\\\", \\\"{x:823,y:512,t:1528139820807};\\\", \\\"{x:817,y:516,t:1528139820818};\\\", \\\"{x:804,y:528,t:1528139820836};\\\", \\\"{x:792,y:545,t:1528139820851};\\\", \\\"{x:780,y:561,t:1528139820869};\\\", \\\"{x:763,y:582,t:1528139820886};\\\", \\\"{x:739,y:603,t:1528139820902};\\\", \\\"{x:712,y:621,t:1528139820920};\\\", \\\"{x:674,y:650,t:1528139820936};\\\", \\\"{x:650,y:664,t:1528139820953};\\\", \\\"{x:626,y:675,t:1528139820968};\\\", \\\"{x:607,y:685,t:1528139820985};\\\", \\\"{x:595,y:693,t:1528139821003};\\\", \\\"{x:585,y:700,t:1528139821019};\\\", \\\"{x:577,y:705,t:1528139821036};\\\", \\\"{x:571,y:709,t:1528139821053};\\\", \\\"{x:560,y:715,t:1528139821068};\\\", \\\"{x:547,y:722,t:1528139821086};\\\", \\\"{x:534,y:725,t:1528139821103};\\\", \\\"{x:527,y:727,t:1528139821119};\\\", \\\"{x:517,y:728,t:1528139821135};\\\", \\\"{x:512,y:730,t:1528139821153};\\\", \\\"{x:509,y:730,t:1528139821170};\\\", \\\"{x:508,y:732,t:1528139821185};\\\", \\\"{x:506,y:733,t:1528139821203};\\\", \\\"{x:505,y:735,t:1528139821219};\\\", \\\"{x:503,y:737,t:1528139821236};\\\", \\\"{x:502,y:739,t:1528139821253};\\\", \\\"{x:501,y:740,t:1528139821270};\\\", \\\"{x:504,y:740,t:1528139821479};\\\", \\\"{x:510,y:740,t:1528139821487};\\\", \\\"{x:518,y:739,t:1528139821503};\\\", \\\"{x:546,y:730,t:1528139821519};\\\", \\\"{x:569,y:722,t:1528139821536};\\\", \\\"{x:618,y:710,t:1528139821553};\\\", \\\"{x:693,y:699,t:1528139821570};\\\", \\\"{x:769,y:689,t:1528139821585};\\\", \\\"{x:858,y:674,t:1528139821603};\\\", \\\"{x:936,y:663,t:1528139821620};\\\", \\\"{x:1000,y:655,t:1528139821636};\\\", \\\"{x:1043,y:649,t:1528139821653};\\\", \\\"{x:1069,y:643,t:1528139821670};\\\", \\\"{x:1086,y:637,t:1528139821686};\\\", \\\"{x:1102,y:630,t:1528139821702};\\\", \\\"{x:1119,y:622,t:1528139821719};\\\", \\\"{x:1126,y:619,t:1528139821735};\\\", \\\"{x:1128,y:617,t:1528139821753};\\\", \\\"{x:1134,y:612,t:1528139821769};\\\", \\\"{x:1137,y:609,t:1528139821786};\\\", \\\"{x:1143,y:604,t:1528139821803};\\\", \\\"{x:1147,y:600,t:1528139821820};\\\", \\\"{x:1153,y:596,t:1528139821835};\\\", \\\"{x:1157,y:594,t:1528139821853};\\\", \\\"{x:1158,y:593,t:1528139821870};\\\", \\\"{x:1161,y:591,t:1528139821887};\\\", \\\"{x:1162,y:587,t:1528139821903};\\\", \\\"{x:1167,y:575,t:1528139821919};\\\", \\\"{x:1169,y:565,t:1528139821936};\\\", \\\"{x:1171,y:562,t:1528139821953};\\\", \\\"{x:1173,y:558,t:1528139821969};\\\", \\\"{x:1174,y:554,t:1528139821987};\\\", \\\"{x:1174,y:550,t:1528139822002};\\\", \\\"{x:1176,y:545,t:1528139822020};\\\", \\\"{x:1178,y:540,t:1528139822036};\\\", \\\"{x:1181,y:535,t:1528139822053};\\\", \\\"{x:1182,y:532,t:1528139822070};\\\", \\\"{x:1183,y:530,t:1528139822087};\\\", \\\"{x:1185,y:526,t:1528139822103};\\\", \\\"{x:1188,y:521,t:1528139822120};\\\", \\\"{x:1192,y:516,t:1528139822136};\\\", \\\"{x:1197,y:509,t:1528139822153};\\\", \\\"{x:1199,y:506,t:1528139822170};\\\", \\\"{x:1203,y:501,t:1528139822187};\\\", \\\"{x:1205,y:499,t:1528139822203};\\\", \\\"{x:1206,y:497,t:1528139822220};\\\", \\\"{x:1207,y:496,t:1528139822237};\\\" ] }, { \\\"rt\\\": 8825, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 942271, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-04 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1207,y:494,t:1528139822976};\\\", \\\"{x:1207,y:491,t:1528139822987};\\\", \\\"{x:1207,y:488,t:1528139823004};\\\", \\\"{x:1207,y:487,t:1528139823021};\\\", \\\"{x:1207,y:484,t:1528139823037};\\\", \\\"{x:1207,y:483,t:1528139823056};\\\", \\\"{x:1207,y:482,t:1528139823071};\\\", \\\"{x:1207,y:480,t:1528139823087};\\\", \\\"{x:1207,y:479,t:1528139823104};\\\", \\\"{x:1206,y:477,t:1528139823121};\\\", \\\"{x:1206,y:475,t:1528139823260};\\\", \\\"{x:1204,y:475,t:1528139823735};\\\", \\\"{x:1202,y:476,t:1528139823744};\\\", \\\"{x:1193,y:481,t:1528139823755};\\\", \\\"{x:1159,y:502,t:1528139823771};\\\", \\\"{x:1114,y:530,t:1528139823787};\\\", \\\"{x:1089,y:538,t:1528139823805};\\\", \\\"{x:1074,y:541,t:1528139823821};\\\", \\\"{x:1069,y:542,t:1528139823837};\\\", \\\"{x:1068,y:544,t:1528139824193};\\\", \\\"{x:1074,y:554,t:1528139824206};\\\", \\\"{x:1106,y:570,t:1528139824222};\\\", \\\"{x:1167,y:596,t:1528139824238};\\\", \\\"{x:1244,y:628,t:1528139824255};\\\", \\\"{x:1385,y:671,t:1528139824272};\\\", \\\"{x:1490,y:695,t:1528139824288};\\\", \\\"{x:1578,y:730,t:1528139824304};\\\", \\\"{x:1634,y:759,t:1528139824322};\\\", \\\"{x:1650,y:774,t:1528139824338};\\\", \\\"{x:1652,y:774,t:1528139824977};\\\", \\\"{x:1651,y:774,t:1528139825008};\\\", \\\"{x:1645,y:774,t:1528139825023};\\\", \\\"{x:1628,y:780,t:1528139825040};\\\", \\\"{x:1598,y:788,t:1528139825057};\\\", \\\"{x:1567,y:798,t:1528139825073};\\\", \\\"{x:1524,y:811,t:1528139825089};\\\", \\\"{x:1493,y:819,t:1528139825107};\\\", \\\"{x:1460,y:823,t:1528139825123};\\\", \\\"{x:1431,y:827,t:1528139825140};\\\", \\\"{x:1401,y:831,t:1528139825156};\\\", \\\"{x:1372,y:836,t:1528139825173};\\\", \\\"{x:1347,y:841,t:1528139825189};\\\", \\\"{x:1326,y:847,t:1528139825207};\\\", \\\"{x:1311,y:854,t:1528139825223};\\\", \\\"{x:1300,y:858,t:1528139825239};\\\", \\\"{x:1295,y:862,t:1528139825257};\\\", \\\"{x:1295,y:865,t:1528139825272};\\\", \\\"{x:1297,y:871,t:1528139825289};\\\", \\\"{x:1307,y:876,t:1528139825306};\\\", \\\"{x:1322,y:883,t:1528139825324};\\\", \\\"{x:1345,y:895,t:1528139825340};\\\", \\\"{x:1380,y:919,t:1528139825356};\\\", \\\"{x:1435,y:951,t:1528139825373};\\\", \\\"{x:1492,y:982,t:1528139825390};\\\", \\\"{x:1553,y:1010,t:1528139825408};\\\", \\\"{x:1584,y:1024,t:1528139825424};\\\", \\\"{x:1603,y:1034,t:1528139825440};\\\", \\\"{x:1618,y:1043,t:1528139825457};\\\", \\\"{x:1620,y:1043,t:1528139825474};\\\", \\\"{x:1622,y:1043,t:1528139825490};\\\", \\\"{x:1624,y:1043,t:1528139825507};\\\", \\\"{x:1625,y:1040,t:1528139825523};\\\", \\\"{x:1625,y:1039,t:1528139825540};\\\", \\\"{x:1625,y:1038,t:1528139825556};\\\", \\\"{x:1626,y:1037,t:1528139825574};\\\", \\\"{x:1628,y:1035,t:1528139825590};\\\", \\\"{x:1630,y:1031,t:1528139825607};\\\", \\\"{x:1635,y:1024,t:1528139825624};\\\", \\\"{x:1639,y:1021,t:1528139825640};\\\", \\\"{x:1642,y:1014,t:1528139825657};\\\", \\\"{x:1643,y:1011,t:1528139825674};\\\", \\\"{x:1646,y:1005,t:1528139825690};\\\", \\\"{x:1648,y:1003,t:1528139825706};\\\", \\\"{x:1648,y:1002,t:1528139825723};\\\", \\\"{x:1648,y:1001,t:1528139825740};\\\", \\\"{x:1648,y:999,t:1528139825756};\\\", \\\"{x:1645,y:989,t:1528139825774};\\\", \\\"{x:1625,y:980,t:1528139825791};\\\", \\\"{x:1610,y:979,t:1528139825806};\\\", \\\"{x:1591,y:979,t:1528139825824};\\\", \\\"{x:1552,y:979,t:1528139825841};\\\", \\\"{x:1527,y:979,t:1528139825857};\\\", \\\"{x:1512,y:979,t:1528139825874};\\\", \\\"{x:1508,y:979,t:1528139825891};\\\", \\\"{x:1510,y:979,t:1528139826081};\\\", \\\"{x:1512,y:978,t:1528139826091};\\\", \\\"{x:1516,y:976,t:1528139826107};\\\", \\\"{x:1517,y:976,t:1528139826123};\\\", \\\"{x:1518,y:976,t:1528139826140};\\\", \\\"{x:1519,y:975,t:1528139826157};\\\", \\\"{x:1520,y:975,t:1528139826172};\\\", \\\"{x:1521,y:974,t:1528139826190};\\\", \\\"{x:1522,y:974,t:1528139826207};\\\", \\\"{x:1525,y:971,t:1528139826223};\\\", \\\"{x:1528,y:969,t:1528139826240};\\\", \\\"{x:1529,y:969,t:1528139826264};\\\", \\\"{x:1531,y:969,t:1528139826312};\\\", \\\"{x:1532,y:968,t:1528139826323};\\\", \\\"{x:1538,y:966,t:1528139826340};\\\", \\\"{x:1541,y:965,t:1528139826357};\\\", \\\"{x:1543,y:964,t:1528139826373};\\\", \\\"{x:1544,y:964,t:1528139826633};\\\", \\\"{x:1546,y:962,t:1528139826641};\\\", \\\"{x:1548,y:962,t:1528139826658};\\\", \\\"{x:1549,y:961,t:1528139826689};\\\", \\\"{x:1549,y:960,t:1528139826849};\\\", \\\"{x:1549,y:956,t:1528139826858};\\\", \\\"{x:1548,y:944,t:1528139826874};\\\", \\\"{x:1543,y:934,t:1528139826891};\\\", \\\"{x:1537,y:923,t:1528139826907};\\\", \\\"{x:1534,y:917,t:1528139826924};\\\", \\\"{x:1532,y:913,t:1528139826941};\\\", \\\"{x:1530,y:909,t:1528139826958};\\\", \\\"{x:1526,y:904,t:1528139826975};\\\", \\\"{x:1521,y:897,t:1528139826992};\\\", \\\"{x:1515,y:891,t:1528139827007};\\\", \\\"{x:1510,y:889,t:1528139827024};\\\", \\\"{x:1505,y:887,t:1528139827042};\\\", \\\"{x:1498,y:886,t:1528139827058};\\\", \\\"{x:1490,y:882,t:1528139827075};\\\", \\\"{x:1485,y:880,t:1528139827092};\\\", \\\"{x:1481,y:877,t:1528139827108};\\\", \\\"{x:1479,y:874,t:1528139827125};\\\", \\\"{x:1476,y:872,t:1528139827142};\\\", \\\"{x:1474,y:867,t:1528139827158};\\\", \\\"{x:1473,y:865,t:1528139827175};\\\", \\\"{x:1471,y:862,t:1528139827191};\\\", \\\"{x:1471,y:858,t:1528139827208};\\\", \\\"{x:1470,y:851,t:1528139827225};\\\", \\\"{x:1469,y:844,t:1528139827242};\\\", \\\"{x:1467,y:836,t:1528139827258};\\\", \\\"{x:1466,y:830,t:1528139827275};\\\", \\\"{x:1466,y:823,t:1528139827292};\\\", \\\"{x:1466,y:819,t:1528139827308};\\\", \\\"{x:1466,y:815,t:1528139827325};\\\", \\\"{x:1466,y:812,t:1528139827342};\\\", \\\"{x:1465,y:810,t:1528139827358};\\\", \\\"{x:1464,y:807,t:1528139827375};\\\", \\\"{x:1464,y:806,t:1528139827391};\\\", \\\"{x:1464,y:805,t:1528139827408};\\\", \\\"{x:1464,y:801,t:1528139827424};\\\", \\\"{x:1464,y:800,t:1528139827441};\\\", \\\"{x:1463,y:797,t:1528139827458};\\\", \\\"{x:1462,y:794,t:1528139827474};\\\", \\\"{x:1462,y:792,t:1528139827491};\\\", \\\"{x:1462,y:790,t:1528139827508};\\\", \\\"{x:1462,y:789,t:1528139827524};\\\", \\\"{x:1460,y:784,t:1528139827541};\\\", \\\"{x:1459,y:783,t:1528139827558};\\\", \\\"{x:1457,y:775,t:1528139827574};\\\", \\\"{x:1454,y:767,t:1528139827591};\\\", \\\"{x:1445,y:749,t:1528139827608};\\\", \\\"{x:1439,y:736,t:1528139827624};\\\", \\\"{x:1435,y:724,t:1528139827641};\\\", \\\"{x:1432,y:711,t:1528139827658};\\\", \\\"{x:1427,y:700,t:1528139827675};\\\", \\\"{x:1421,y:690,t:1528139827691};\\\", \\\"{x:1414,y:677,t:1528139827708};\\\", \\\"{x:1409,y:668,t:1528139827724};\\\", \\\"{x:1405,y:662,t:1528139827741};\\\", \\\"{x:1402,y:656,t:1528139827759};\\\", \\\"{x:1397,y:646,t:1528139827774};\\\", \\\"{x:1389,y:636,t:1528139827791};\\\", \\\"{x:1381,y:624,t:1528139827808};\\\", \\\"{x:1376,y:620,t:1528139827825};\\\", \\\"{x:1374,y:617,t:1528139827841};\\\", \\\"{x:1371,y:611,t:1528139827858};\\\", \\\"{x:1366,y:605,t:1528139827876};\\\", \\\"{x:1358,y:597,t:1528139827891};\\\", \\\"{x:1354,y:591,t:1528139827909};\\\", \\\"{x:1349,y:584,t:1528139827926};\\\", \\\"{x:1339,y:576,t:1528139827942};\\\", \\\"{x:1325,y:566,t:1528139827959};\\\", \\\"{x:1307,y:558,t:1528139827975};\\\", \\\"{x:1287,y:554,t:1528139827992};\\\", \\\"{x:1246,y:551,t:1528139828008};\\\", \\\"{x:1185,y:551,t:1528139828025};\\\", \\\"{x:1111,y:553,t:1528139828042};\\\", \\\"{x:1027,y:566,t:1528139828059};\\\", \\\"{x:928,y:580,t:1528139828077};\\\", \\\"{x:827,y:596,t:1528139828091};\\\", \\\"{x:722,y:612,t:1528139828108};\\\", \\\"{x:561,y:643,t:1528139828141};\\\", \\\"{x:485,y:658,t:1528139828159};\\\", \\\"{x:426,y:670,t:1528139828175};\\\", \\\"{x:380,y:677,t:1528139828191};\\\", \\\"{x:351,y:685,t:1528139828208};\\\", \\\"{x:342,y:686,t:1528139828225};\\\", \\\"{x:340,y:687,t:1528139828242};\\\", \\\"{x:340,y:688,t:1528139828258};\\\", \\\"{x:340,y:686,t:1528139828295};\\\", \\\"{x:343,y:680,t:1528139828308};\\\", \\\"{x:353,y:672,t:1528139828325};\\\", \\\"{x:367,y:657,t:1528139828342};\\\", \\\"{x:383,y:644,t:1528139828359};\\\", \\\"{x:398,y:634,t:1528139828375};\\\", \\\"{x:430,y:614,t:1528139828392};\\\", \\\"{x:475,y:589,t:1528139828409};\\\", \\\"{x:523,y:566,t:1528139828426};\\\", \\\"{x:548,y:555,t:1528139828443};\\\", \\\"{x:567,y:546,t:1528139828458};\\\", \\\"{x:580,y:541,t:1528139828475};\\\", \\\"{x:596,y:535,t:1528139828492};\\\", \\\"{x:617,y:528,t:1528139828509};\\\", \\\"{x:641,y:523,t:1528139828525};\\\", \\\"{x:659,y:522,t:1528139828542};\\\", \\\"{x:670,y:522,t:1528139828558};\\\", \\\"{x:677,y:522,t:1528139828575};\\\", \\\"{x:697,y:530,t:1528139828592};\\\", \\\"{x:713,y:540,t:1528139828608};\\\", \\\"{x:733,y:556,t:1528139828625};\\\", \\\"{x:747,y:570,t:1528139828642};\\\", \\\"{x:752,y:579,t:1528139828659};\\\", \\\"{x:754,y:581,t:1528139828675};\\\", \\\"{x:754,y:585,t:1528139828692};\\\", \\\"{x:754,y:591,t:1528139828709};\\\", \\\"{x:754,y:597,t:1528139828725};\\\", \\\"{x:742,y:608,t:1528139828742};\\\", \\\"{x:725,y:617,t:1528139828759};\\\", \\\"{x:691,y:629,t:1528139828776};\\\", \\\"{x:661,y:630,t:1528139828792};\\\", \\\"{x:625,y:631,t:1528139828808};\\\", \\\"{x:592,y:635,t:1528139828825};\\\", \\\"{x:560,y:635,t:1528139828842};\\\", \\\"{x:534,y:635,t:1528139828859};\\\", \\\"{x:515,y:639,t:1528139828875};\\\", \\\"{x:492,y:640,t:1528139828892};\\\", \\\"{x:471,y:642,t:1528139828908};\\\", \\\"{x:461,y:642,t:1528139828925};\\\", \\\"{x:458,y:642,t:1528139828942};\\\", \\\"{x:455,y:642,t:1528139828976};\\\", \\\"{x:447,y:642,t:1528139828992};\\\", \\\"{x:441,y:643,t:1528139829009};\\\", \\\"{x:436,y:645,t:1528139829025};\\\", \\\"{x:426,y:647,t:1528139829042};\\\", \\\"{x:416,y:650,t:1528139829060};\\\", \\\"{x:396,y:652,t:1528139829076};\\\", \\\"{x:378,y:655,t:1528139829092};\\\", \\\"{x:360,y:660,t:1528139829110};\\\", \\\"{x:345,y:664,t:1528139829126};\\\", \\\"{x:330,y:667,t:1528139829142};\\\", \\\"{x:305,y:673,t:1528139829161};\\\", \\\"{x:284,y:675,t:1528139829176};\\\", \\\"{x:256,y:675,t:1528139829192};\\\", \\\"{x:228,y:675,t:1528139829208};\\\", \\\"{x:205,y:675,t:1528139829226};\\\", \\\"{x:185,y:675,t:1528139829242};\\\", \\\"{x:168,y:674,t:1528139829259};\\\", \\\"{x:152,y:667,t:1528139829277};\\\", \\\"{x:135,y:658,t:1528139829292};\\\", \\\"{x:120,y:648,t:1528139829309};\\\", \\\"{x:115,y:643,t:1528139829326};\\\", \\\"{x:114,y:631,t:1528139829343};\\\", \\\"{x:111,y:615,t:1528139829359};\\\", \\\"{x:109,y:597,t:1528139829376};\\\", \\\"{x:109,y:582,t:1528139829393};\\\", \\\"{x:113,y:569,t:1528139829409};\\\", \\\"{x:130,y:548,t:1528139829427};\\\", \\\"{x:159,y:527,t:1528139829442};\\\", \\\"{x:181,y:511,t:1528139829460};\\\", \\\"{x:200,y:497,t:1528139829477};\\\", \\\"{x:218,y:486,t:1528139829493};\\\", \\\"{x:235,y:475,t:1528139829509};\\\", \\\"{x:267,y:462,t:1528139829526};\\\", \\\"{x:332,y:448,t:1528139829542};\\\", \\\"{x:391,y:439,t:1528139829559};\\\", \\\"{x:448,y:439,t:1528139829575};\\\", \\\"{x:481,y:439,t:1528139829592};\\\", \\\"{x:518,y:439,t:1528139829609};\\\", \\\"{x:550,y:439,t:1528139829626};\\\", \\\"{x:581,y:439,t:1528139829642};\\\", \\\"{x:597,y:441,t:1528139829659};\\\", \\\"{x:610,y:443,t:1528139829676};\\\", \\\"{x:619,y:444,t:1528139829693};\\\", \\\"{x:629,y:445,t:1528139829709};\\\", \\\"{x:638,y:447,t:1528139829726};\\\", \\\"{x:646,y:449,t:1528139829743};\\\", \\\"{x:650,y:451,t:1528139829759};\\\", \\\"{x:656,y:454,t:1528139829776};\\\", \\\"{x:668,y:458,t:1528139829792};\\\", \\\"{x:679,y:462,t:1528139829809};\\\", \\\"{x:688,y:465,t:1528139829827};\\\", \\\"{x:696,y:469,t:1528139829843};\\\", \\\"{x:704,y:472,t:1528139829860};\\\", \\\"{x:719,y:478,t:1528139829876};\\\", \\\"{x:733,y:484,t:1528139829892};\\\", \\\"{x:752,y:490,t:1528139829911};\\\", \\\"{x:773,y:496,t:1528139829925};\\\", \\\"{x:791,y:501,t:1528139829943};\\\", \\\"{x:805,y:505,t:1528139829959};\\\", \\\"{x:808,y:507,t:1528139829976};\\\", \\\"{x:813,y:508,t:1528139829993};\\\", \\\"{x:816,y:509,t:1528139830009};\\\", \\\"{x:821,y:509,t:1528139830026};\\\", \\\"{x:823,y:509,t:1528139830043};\\\", \\\"{x:825,y:509,t:1528139830088};\\\", \\\"{x:825,y:510,t:1528139830233};\\\", \\\"{x:825,y:511,t:1528139830244};\\\", \\\"{x:823,y:512,t:1528139830259};\\\", \\\"{x:822,y:513,t:1528139830276};\\\", \\\"{x:819,y:513,t:1528139830293};\\\", \\\"{x:819,y:514,t:1528139830433};\\\", \\\"{x:818,y:514,t:1528139830444};\\\", \\\"{x:810,y:516,t:1528139830460};\\\", \\\"{x:788,y:518,t:1528139830478};\\\", \\\"{x:748,y:523,t:1528139830493};\\\", \\\"{x:711,y:529,t:1528139830511};\\\", \\\"{x:685,y:539,t:1528139830527};\\\", \\\"{x:644,y:559,t:1528139830544};\\\", \\\"{x:625,y:571,t:1528139830561};\\\", \\\"{x:611,y:580,t:1528139830577};\\\", \\\"{x:605,y:584,t:1528139830593};\\\", \\\"{x:603,y:587,t:1528139830610};\\\", \\\"{x:603,y:588,t:1528139830752};\\\", \\\"{x:604,y:588,t:1528139830776};\\\", \\\"{x:604,y:597,t:1528139831024};\\\", \\\"{x:604,y:609,t:1528139831032};\\\", \\\"{x:604,y:621,t:1528139831044};\\\", \\\"{x:604,y:639,t:1528139831061};\\\", \\\"{x:604,y:658,t:1528139831077};\\\", \\\"{x:599,y:674,t:1528139831094};\\\", \\\"{x:595,y:683,t:1528139831110};\\\", \\\"{x:587,y:694,t:1528139831128};\\\", \\\"{x:578,y:702,t:1528139831144};\\\", \\\"{x:566,y:713,t:1528139831161};\\\", \\\"{x:550,y:729,t:1528139831178};\\\", \\\"{x:543,y:734,t:1528139831194};\\\", \\\"{x:537,y:738,t:1528139831211};\\\", \\\"{x:531,y:741,t:1528139831227};\\\", \\\"{x:524,y:744,t:1528139831244};\\\", \\\"{x:516,y:748,t:1528139831261};\\\", \\\"{x:513,y:748,t:1528139831277};\\\", \\\"{x:512,y:749,t:1528139831294};\\\", \\\"{x:510,y:749,t:1528139831328};\\\", \\\"{x:509,y:749,t:1528139831351};\\\", \\\"{x:506,y:749,t:1528139831471};\\\", \\\"{x:503,y:746,t:1528139831479};\\\", \\\"{x:498,y:744,t:1528139831511};\\\", \\\"{x:495,y:740,t:1528139831527};\\\", \\\"{x:494,y:738,t:1528139831544};\\\", \\\"{x:494,y:737,t:1528139831575};\\\", \\\"{x:494,y:735,t:1528139831583};\\\", \\\"{x:495,y:734,t:1528139831594};\\\", \\\"{x:497,y:731,t:1528139831611};\\\", \\\"{x:500,y:727,t:1528139831627};\\\", \\\"{x:503,y:725,t:1528139831644};\\\", \\\"{x:503,y:724,t:1528139831728};\\\", \\\"{x:519,y:721,t:1528139831744};\\\", \\\"{x:566,y:714,t:1528139831761};\\\", \\\"{x:657,y:700,t:1528139831778};\\\", \\\"{x:785,y:662,t:1528139831794};\\\", \\\"{x:951,y:633,t:1528139831811};\\\", \\\"{x:1133,y:587,t:1528139831828};\\\", \\\"{x:1329,y:537,t:1528139831844};\\\", \\\"{x:1548,y:488,t:1528139831862};\\\", \\\"{x:1759,y:448,t:1528139831878};\\\", \\\"{x:1919,y:407,t:1528139831894};\\\", \\\"{x:1919,y:371,t:1528139831911};\\\", \\\"{x:1919,y:340,t:1528139831928};\\\", \\\"{x:1919,y:327,t:1528139831944};\\\", \\\"{x:1919,y:319,t:1528139831961};\\\", \\\"{x:1919,y:317,t:1528139831979};\\\", \\\"{x:1919,y:316,t:1528139831995};\\\", \\\"{x:1918,y:316,t:1528139832280};\\\", \\\"{x:1917,y:316,t:1528139832294};\\\", \\\"{x:1914,y:317,t:1528139832311};\\\", \\\"{x:1913,y:317,t:1528139832328};\\\", \\\"{x:1912,y:318,t:1528139832351};\\\", \\\"{x:1911,y:318,t:1528139832384};\\\", \\\"{x:1911,y:319,t:1528139832432};\\\", \\\"{x:1910,y:319,t:1528139832456};\\\", \\\"{x:1909,y:319,t:1528139832464};\\\", \\\"{x:1908,y:319,t:1528139832480};\\\", \\\"{x:1900,y:323,t:1528139832540};\\\", \\\"{x:1899,y:324,t:1528139832551};\\\", \\\"{x:1898,y:325,t:1528139832566};\\\", \\\"{x:1897,y:325,t:1528139832578};\\\", \\\"{x:1895,y:327,t:1528139832595};\\\", \\\"{x:1894,y:327,t:1528139832611};\\\" ] }, { \\\"rt\\\": 15699, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 959213, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -01 PM-02 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1888,y:330,t:1528139832722};\\\", \\\"{x:1887,y:330,t:1528139832731};\\\", \\\"{x:1884,y:332,t:1528139832796};\\\", \\\"{x:1883,y:332,t:1528139832825};\\\", \\\"{x:1882,y:332,t:1528139832839};\\\", \\\"{x:1877,y:335,t:1528139836254};\\\", \\\"{x:1870,y:338,t:1528139836269};\\\", \\\"{x:1862,y:343,t:1528139836287};\\\", \\\"{x:1850,y:353,t:1528139836303};\\\", \\\"{x:1834,y:365,t:1528139836320};\\\", \\\"{x:1818,y:382,t:1528139836336};\\\", \\\"{x:1801,y:405,t:1528139836353};\\\", \\\"{x:1789,y:423,t:1528139836369};\\\", \\\"{x:1778,y:438,t:1528139836386};\\\", \\\"{x:1769,y:457,t:1528139836403};\\\", \\\"{x:1758,y:478,t:1528139836419};\\\", \\\"{x:1744,y:513,t:1528139836435};\\\", \\\"{x:1734,y:542,t:1528139836453};\\\", \\\"{x:1716,y:569,t:1528139836469};\\\", \\\"{x:1691,y:601,t:1528139836486};\\\", \\\"{x:1667,y:631,t:1528139836503};\\\", \\\"{x:1639,y:662,t:1528139836519};\\\", \\\"{x:1610,y:695,t:1528139836537};\\\", \\\"{x:1581,y:728,t:1528139836554};\\\", \\\"{x:1552,y:768,t:1528139836569};\\\", \\\"{x:1517,y:819,t:1528139836586};\\\", \\\"{x:1468,y:883,t:1528139836602};\\\", \\\"{x:1408,y:947,t:1528139836619};\\\", \\\"{x:1299,y:1028,t:1528139836636};\\\", \\\"{x:1260,y:1057,t:1528139836652};\\\", \\\"{x:1263,y:1057,t:1528139837093};\\\", \\\"{x:1265,y:1057,t:1528139837104};\\\", \\\"{x:1284,y:1051,t:1528139837121};\\\", \\\"{x:1315,y:1040,t:1528139837136};\\\", \\\"{x:1348,y:1031,t:1528139837153};\\\", \\\"{x:1367,y:1023,t:1528139837170};\\\", \\\"{x:1377,y:1017,t:1528139837186};\\\", \\\"{x:1381,y:1013,t:1528139837203};\\\", \\\"{x:1383,y:1010,t:1528139837220};\\\", \\\"{x:1385,y:1008,t:1528139837237};\\\", \\\"{x:1388,y:1005,t:1528139837252};\\\", \\\"{x:1391,y:1003,t:1528139837270};\\\", \\\"{x:1391,y:1002,t:1528139837287};\\\", \\\"{x:1393,y:1001,t:1528139837303};\\\", \\\"{x:1396,y:999,t:1528139837320};\\\", \\\"{x:1400,y:996,t:1528139837337};\\\", \\\"{x:1411,y:989,t:1528139837353};\\\", \\\"{x:1425,y:981,t:1528139837370};\\\", \\\"{x:1435,y:974,t:1528139837387};\\\", \\\"{x:1443,y:970,t:1528139837403};\\\", \\\"{x:1450,y:966,t:1528139837420};\\\", \\\"{x:1454,y:963,t:1528139837437};\\\", \\\"{x:1458,y:961,t:1528139837454};\\\", \\\"{x:1459,y:961,t:1528139837471};\\\", \\\"{x:1459,y:960,t:1528139837492};\\\", \\\"{x:1460,y:960,t:1528139837508};\\\", \\\"{x:1462,y:959,t:1528139837524};\\\", \\\"{x:1462,y:958,t:1528139837548};\\\", \\\"{x:1464,y:958,t:1528139837645};\\\", \\\"{x:1465,y:958,t:1528139837655};\\\", \\\"{x:1467,y:958,t:1528139837671};\\\", \\\"{x:1471,y:958,t:1528139837688};\\\", \\\"{x:1476,y:958,t:1528139837705};\\\", \\\"{x:1479,y:958,t:1528139837720};\\\", \\\"{x:1481,y:959,t:1528139837804};\\\", \\\"{x:1482,y:959,t:1528139837819};\\\", \\\"{x:1482,y:960,t:1528139837940};\\\", \\\"{x:1482,y:962,t:1528139837956};\\\", \\\"{x:1482,y:963,t:1528139837972};\\\", \\\"{x:1482,y:964,t:1528139837988};\\\", \\\"{x:1482,y:965,t:1528139838004};\\\", \\\"{x:1482,y:966,t:1528139838020};\\\", \\\"{x:1482,y:968,t:1528139838261};\\\", \\\"{x:1480,y:969,t:1528139838293};\\\", \\\"{x:1479,y:969,t:1528139838316};\\\", \\\"{x:1479,y:970,t:1528139838397};\\\", \\\"{x:1479,y:969,t:1528139840117};\\\", \\\"{x:1480,y:964,t:1528139840125};\\\", \\\"{x:1483,y:958,t:1528139840140};\\\", \\\"{x:1491,y:948,t:1528139840155};\\\", \\\"{x:1497,y:939,t:1528139840171};\\\", \\\"{x:1498,y:937,t:1528139840189};\\\", \\\"{x:1498,y:936,t:1528139840268};\\\", \\\"{x:1499,y:933,t:1528139840276};\\\", \\\"{x:1499,y:928,t:1528139840289};\\\", \\\"{x:1499,y:921,t:1528139840305};\\\", \\\"{x:1499,y:914,t:1528139840322};\\\", \\\"{x:1499,y:910,t:1528139840339};\\\", \\\"{x:1499,y:905,t:1528139840355};\\\", \\\"{x:1499,y:896,t:1528139840372};\\\", \\\"{x:1499,y:890,t:1528139840389};\\\", \\\"{x:1499,y:884,t:1528139840405};\\\", \\\"{x:1499,y:883,t:1528139840422};\\\", \\\"{x:1499,y:880,t:1528139840439};\\\", \\\"{x:1498,y:876,t:1528139840455};\\\", \\\"{x:1497,y:873,t:1528139840472};\\\", \\\"{x:1496,y:870,t:1528139840489};\\\", \\\"{x:1495,y:865,t:1528139840506};\\\", \\\"{x:1492,y:859,t:1528139840522};\\\", \\\"{x:1490,y:853,t:1528139840539};\\\", \\\"{x:1487,y:846,t:1528139840556};\\\", \\\"{x:1487,y:844,t:1528139840572};\\\", \\\"{x:1486,y:842,t:1528139840589};\\\", \\\"{x:1485,y:839,t:1528139840606};\\\", \\\"{x:1485,y:836,t:1528139840622};\\\", \\\"{x:1485,y:834,t:1528139840639};\\\", \\\"{x:1485,y:833,t:1528139840655};\\\", \\\"{x:1485,y:832,t:1528139840692};\\\", \\\"{x:1485,y:831,t:1528139840708};\\\", \\\"{x:1484,y:830,t:1528139841341};\\\", \\\"{x:1483,y:830,t:1528139841356};\\\", \\\"{x:1482,y:830,t:1528139841373};\\\", \\\"{x:1479,y:831,t:1528139844141};\\\", \\\"{x:1449,y:835,t:1528139844158};\\\", \\\"{x:1377,y:824,t:1528139844175};\\\", \\\"{x:1281,y:801,t:1528139844191};\\\", \\\"{x:1210,y:774,t:1528139844207};\\\", \\\"{x:1159,y:749,t:1528139844226};\\\", \\\"{x:1118,y:733,t:1528139844242};\\\", \\\"{x:1088,y:720,t:1528139844258};\\\", \\\"{x:1067,y:705,t:1528139844275};\\\", \\\"{x:1050,y:690,t:1528139844292};\\\", \\\"{x:1044,y:680,t:1528139844308};\\\", \\\"{x:1036,y:673,t:1528139844325};\\\", \\\"{x:1020,y:664,t:1528139844342};\\\", \\\"{x:981,y:650,t:1528139844358};\\\", \\\"{x:934,y:637,t:1528139844376};\\\", \\\"{x:913,y:628,t:1528139844392};\\\", \\\"{x:897,y:623,t:1528139844408};\\\", \\\"{x:873,y:618,t:1528139844426};\\\", \\\"{x:848,y:608,t:1528139844443};\\\", \\\"{x:818,y:596,t:1528139844459};\\\", \\\"{x:773,y:573,t:1528139844475};\\\", \\\"{x:750,y:558,t:1528139844493};\\\", \\\"{x:728,y:547,t:1528139844509};\\\", \\\"{x:701,y:537,t:1528139844526};\\\", \\\"{x:663,y:528,t:1528139844544};\\\", \\\"{x:612,y:513,t:1528139844559};\\\", \\\"{x:576,y:504,t:1528139844576};\\\", \\\"{x:552,y:500,t:1528139844593};\\\", \\\"{x:534,y:499,t:1528139844609};\\\", \\\"{x:525,y:496,t:1528139844626};\\\", \\\"{x:516,y:496,t:1528139844642};\\\", \\\"{x:511,y:496,t:1528139844659};\\\", \\\"{x:500,y:501,t:1528139844676};\\\", \\\"{x:481,y:513,t:1528139844694};\\\", \\\"{x:464,y:527,t:1528139844709};\\\", \\\"{x:449,y:548,t:1528139844727};\\\", \\\"{x:437,y:567,t:1528139844743};\\\", \\\"{x:432,y:575,t:1528139844760};\\\", \\\"{x:428,y:582,t:1528139844776};\\\", \\\"{x:423,y:589,t:1528139844793};\\\", \\\"{x:419,y:593,t:1528139844809};\\\", \\\"{x:412,y:598,t:1528139844826};\\\", \\\"{x:407,y:602,t:1528139844843};\\\", \\\"{x:405,y:603,t:1528139844859};\\\", \\\"{x:403,y:605,t:1528139844875};\\\", \\\"{x:400,y:606,t:1528139844931};\\\", \\\"{x:397,y:606,t:1528139844943};\\\", \\\"{x:393,y:606,t:1528139844959};\\\", \\\"{x:390,y:606,t:1528139844976};\\\", \\\"{x:389,y:606,t:1528139844993};\\\", \\\"{x:388,y:607,t:1528139845028};\\\", \\\"{x:386,y:608,t:1528139845062};\\\", \\\"{x:384,y:609,t:1528139845076};\\\", \\\"{x:382,y:609,t:1528139845093};\\\", \\\"{x:383,y:609,t:1528139845228};\\\", \\\"{x:384,y:608,t:1528139845243};\\\", \\\"{x:389,y:606,t:1528139845260};\\\", \\\"{x:394,y:604,t:1528139845276};\\\", \\\"{x:397,y:603,t:1528139845293};\\\", \\\"{x:398,y:602,t:1528139845310};\\\", \\\"{x:399,y:602,t:1528139845332};\\\", \\\"{x:400,y:601,t:1528139845413};\\\", \\\"{x:403,y:600,t:1528139845427};\\\", \\\"{x:404,y:599,t:1528139845443};\\\", \\\"{x:411,y:594,t:1528139845460};\\\", \\\"{x:416,y:590,t:1528139845477};\\\", \\\"{x:419,y:586,t:1528139845494};\\\", \\\"{x:419,y:583,t:1528139845510};\\\", \\\"{x:421,y:580,t:1528139845527};\\\", \\\"{x:423,y:576,t:1528139845543};\\\", \\\"{x:429,y:571,t:1528139845560};\\\", \\\"{x:441,y:565,t:1528139845577};\\\", \\\"{x:456,y:556,t:1528139845593};\\\", \\\"{x:472,y:549,t:1528139845609};\\\", \\\"{x:485,y:541,t:1528139845627};\\\", \\\"{x:499,y:535,t:1528139845644};\\\", \\\"{x:527,y:528,t:1528139845660};\\\", \\\"{x:550,y:524,t:1528139845677};\\\", \\\"{x:575,y:523,t:1528139845693};\\\", \\\"{x:590,y:521,t:1528139845710};\\\", \\\"{x:599,y:521,t:1528139845727};\\\", \\\"{x:607,y:521,t:1528139845745};\\\", \\\"{x:613,y:521,t:1528139845760};\\\", \\\"{x:620,y:521,t:1528139845778};\\\", \\\"{x:631,y:528,t:1528139845794};\\\", \\\"{x:639,y:535,t:1528139845811};\\\", \\\"{x:649,y:540,t:1528139845827};\\\", \\\"{x:650,y:542,t:1528139845843};\\\", \\\"{x:652,y:544,t:1528139845859};\\\", \\\"{x:653,y:551,t:1528139845876};\\\", \\\"{x:654,y:558,t:1528139845893};\\\", \\\"{x:657,y:564,t:1528139845910};\\\", \\\"{x:657,y:568,t:1528139845926};\\\", \\\"{x:657,y:571,t:1528139845944};\\\", \\\"{x:657,y:574,t:1528139845959};\\\", \\\"{x:657,y:577,t:1528139845978};\\\", \\\"{x:657,y:579,t:1528139845994};\\\", \\\"{x:655,y:585,t:1528139846010};\\\", \\\"{x:652,y:588,t:1528139846027};\\\", \\\"{x:645,y:592,t:1528139846044};\\\", \\\"{x:642,y:594,t:1528139846061};\\\", \\\"{x:634,y:597,t:1528139846077};\\\", \\\"{x:629,y:599,t:1528139846094};\\\", \\\"{x:627,y:600,t:1528139846111};\\\", \\\"{x:625,y:601,t:1528139846127};\\\", \\\"{x:624,y:602,t:1528139846145};\\\", \\\"{x:622,y:602,t:1528139846161};\\\", \\\"{x:621,y:603,t:1528139846177};\\\", \\\"{x:620,y:603,t:1528139846381};\\\", \\\"{x:618,y:603,t:1528139846394};\\\", \\\"{x:617,y:602,t:1528139846411};\\\", \\\"{x:616,y:600,t:1528139846427};\\\", \\\"{x:616,y:599,t:1528139846444};\\\", \\\"{x:616,y:598,t:1528139846461};\\\", \\\"{x:611,y:597,t:1528139846715};\\\", \\\"{x:602,y:597,t:1528139846727};\\\", \\\"{x:561,y:597,t:1528139846745};\\\", \\\"{x:533,y:597,t:1528139846760};\\\", \\\"{x:518,y:597,t:1528139846777};\\\", \\\"{x:500,y:600,t:1528139846794};\\\", \\\"{x:476,y:603,t:1528139846810};\\\", \\\"{x:459,y:604,t:1528139846827};\\\", \\\"{x:442,y:604,t:1528139846844};\\\", \\\"{x:426,y:607,t:1528139846861};\\\", \\\"{x:415,y:608,t:1528139846879};\\\", \\\"{x:407,y:610,t:1528139846894};\\\", \\\"{x:405,y:612,t:1528139846911};\\\", \\\"{x:404,y:612,t:1528139846928};\\\", \\\"{x:403,y:612,t:1528139846971};\\\", \\\"{x:401,y:613,t:1528139846980};\\\", \\\"{x:400,y:614,t:1528139846995};\\\", \\\"{x:399,y:614,t:1528139847148};\\\", \\\"{x:397,y:614,t:1528139847161};\\\", \\\"{x:392,y:608,t:1528139847178};\\\", \\\"{x:390,y:602,t:1528139847196};\\\", \\\"{x:387,y:599,t:1528139847211};\\\", \\\"{x:385,y:597,t:1528139847228};\\\", \\\"{x:385,y:596,t:1528139847252};\\\", \\\"{x:388,y:598,t:1528139847635};\\\", \\\"{x:396,y:608,t:1528139847645};\\\", \\\"{x:412,y:629,t:1528139847663};\\\", \\\"{x:425,y:648,t:1528139847678};\\\", \\\"{x:440,y:667,t:1528139847695};\\\", \\\"{x:449,y:679,t:1528139847712};\\\", \\\"{x:458,y:689,t:1528139847728};\\\", \\\"{x:463,y:694,t:1528139847745};\\\", \\\"{x:468,y:697,t:1528139847762};\\\", \\\"{x:473,y:702,t:1528139847779};\\\", \\\"{x:479,y:708,t:1528139847795};\\\", \\\"{x:489,y:718,t:1528139847811};\\\", \\\"{x:490,y:720,t:1528139847828};\\\", \\\"{x:492,y:722,t:1528139847845};\\\", \\\"{x:493,y:724,t:1528139847862};\\\", \\\"{x:496,y:729,t:1528139847878};\\\", \\\"{x:499,y:734,t:1528139847896};\\\", \\\"{x:501,y:739,t:1528139847912};\\\", \\\"{x:503,y:742,t:1528139847929};\\\", \\\"{x:503,y:745,t:1528139847946};\\\", \\\"{x:506,y:750,t:1528139847962};\\\", \\\"{x:507,y:755,t:1528139847979};\\\", \\\"{x:510,y:764,t:1528139847995};\\\", \\\"{x:510,y:767,t:1528139848012};\\\", \\\"{x:511,y:768,t:1528139848029};\\\", \\\"{x:511,y:767,t:1528139848165};\\\", \\\"{x:511,y:760,t:1528139848180};\\\", \\\"{x:511,y:756,t:1528139848197};\\\", \\\"{x:512,y:754,t:1528139848214};\\\", \\\"{x:512,y:752,t:1528139848440};\\\", \\\"{x:512,y:751,t:1528139848499};\\\", \\\"{x:512,y:750,t:1528139848512};\\\", \\\"{x:525,y:743,t:1528139848529};\\\", \\\"{x:553,y:734,t:1528139848546};\\\", \\\"{x:592,y:724,t:1528139848562};\\\", \\\"{x:650,y:707,t:1528139848579};\\\", \\\"{x:817,y:675,t:1528139848595};\\\", \\\"{x:956,y:654,t:1528139848612};\\\", \\\"{x:1108,y:634,t:1528139848628};\\\", \\\"{x:1250,y:628,t:1528139848646};\\\", \\\"{x:1380,y:628,t:1528139848663};\\\", \\\"{x:1502,y:628,t:1528139848679};\\\", \\\"{x:1601,y:628,t:1528139848696};\\\", \\\"{x:1679,y:628,t:1528139848713};\\\", \\\"{x:1728,y:625,t:1528139848729};\\\", \\\"{x:1763,y:618,t:1528139848746};\\\", \\\"{x:1780,y:613,t:1528139848763};\\\", \\\"{x:1791,y:609,t:1528139848780};\\\", \\\"{x:1794,y:607,t:1528139848796};\\\", \\\"{x:1796,y:605,t:1528139849276};\\\", \\\"{x:1798,y:601,t:1528139849284};\\\", \\\"{x:1801,y:600,t:1528139849300};\\\", \\\"{x:1803,y:597,t:1528139849313};\\\", \\\"{x:1809,y:595,t:1528139849330};\\\", \\\"{x:1812,y:593,t:1528139849346};\\\", \\\"{x:1813,y:593,t:1528139849363};\\\", \\\"{x:1814,y:592,t:1528139849381};\\\" ] }, { \\\"rt\\\": 56960, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1017401, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Find 12 pm on the horizontal axis and follow the diagonal line that slopes upward. Any point along this line begins at 12\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6838, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1025246, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 16260, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1042520, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4848, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1048710, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"8EQOW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"8EQOW\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 123, dom: 759, initialDom: 882",
  "javascriptErrors": []
}