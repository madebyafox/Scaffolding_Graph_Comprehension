var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525590715971343f3f258638a1554a5076a1229"] = {
  "startTime": "2018-05-25T18:07:00.0577831Z",
  "websitePageUrl": "/",
  "visitTime": 139122,
  "engagementTime": 62091,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "2790a97f16d52318217a67200ecd8be2",
    "created": "2018-05-25T18:07:00.0577831+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "106eb0a386652d1e02a2b3fcfb08a011",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2790a97f16d52318217a67200ecd8be2/play"
  },
  "events": [
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 101,
      "e": 101,
      "ty": 2,
      "x": 305,
      "y": 17
    },
    {
      "t": 186,
      "e": 186,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 395,
      "y": 0
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 13602,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 304,
      "e": 304,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 442,
      "y": 143
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 14945,
      "y": 8214,
      "ta": "html > body"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 614,
      "y": 483
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 13898,
      "y": 27565,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10000,
      "e": 6251,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 81359,
      "e": 6251,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 81459,
      "e": 6351,
      "ty": 2,
      "x": 614,
      "y": 549
    },
    {
      "t": 81559,
      "e": 6451,
      "ty": 41,
      "x": 13898,
      "y": 28630,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 83131,
      "e": 8023,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 84447,
      "e": 9339,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 88158,
      "e": 11451,
      "ty": 2,
      "x": 504,
      "y": 491
    },
    {
      "t": 88259,
      "e": 11552,
      "ty": 2,
      "x": 106,
      "y": 297
    },
    {
      "t": 88308,
      "e": 11601,
      "ty": 41,
      "x": 2996,
      "y": 8863,
      "ta": "> div.masterdiv"
    },
    {
      "t": 88359,
      "e": 11652,
      "ty": 2,
      "x": 134,
      "y": 68
    },
    {
      "t": 88458,
      "e": 11751,
      "ty": 2,
      "x": 245,
      "y": 74
    },
    {
      "t": 88559,
      "e": 11852,
      "ty": 2,
      "x": 458,
      "y": 385
    },
    {
      "t": 88559,
      "e": 11852,
      "ty": 41,
      "x": 8095,
      "y": 8698,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 88658,
      "e": 11951,
      "ty": 2,
      "x": 346,
      "y": 564
    },
    {
      "t": 88759,
      "e": 12052,
      "ty": 2,
      "x": 266,
      "y": 576
    },
    {
      "t": 88808,
      "e": 12101,
      "ty": 41,
      "x": 9332,
      "y": 30136,
      "ta": "> div.masterdiv"
    },
    {
      "t": 88858,
      "e": 12151,
      "ty": 2,
      "x": 311,
      "y": 527
    },
    {
      "t": 88958,
      "e": 12251,
      "ty": 2,
      "x": 547,
      "y": 486
    },
    {
      "t": 89058,
      "e": 12351,
      "ty": 2,
      "x": 652,
      "y": 461
    },
    {
      "t": 89058,
      "e": 12351,
      "ty": 41,
      "x": 17639,
      "y": 15087,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 89658,
      "e": 12951,
      "ty": 2,
      "x": 686,
      "y": 506
    },
    {
      "t": 89758,
      "e": 13051,
      "ty": 2,
      "x": 856,
      "y": 794
    },
    {
      "t": 89809,
      "e": 13102,
      "ty": 41,
      "x": 28364,
      "y": 53837,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89859,
      "e": 13152,
      "ty": 2,
      "x": 870,
      "y": 821
    },
    {
      "t": 90058,
      "e": 13351,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90759,
      "e": 14052,
      "ty": 2,
      "x": 841,
      "y": 866
    },
    {
      "t": 90809,
      "e": 14102,
      "ty": 41,
      "x": 26937,
      "y": 40977,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 91258,
      "e": 14551,
      "ty": 2,
      "x": 841,
      "y": 871
    },
    {
      "t": 91308,
      "e": 14601,
      "ty": 41,
      "x": 26839,
      "y": 60877,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 91358,
      "e": 14651,
      "ty": 2,
      "x": 838,
      "y": 896
    },
    {
      "t": 91458,
      "e": 14751,
      "ty": 2,
      "x": 832,
      "y": 904
    },
    {
      "t": 91559,
      "e": 14852,
      "ty": 2,
      "x": 823,
      "y": 913
    },
    {
      "t": 91559,
      "e": 14852,
      "ty": 41,
      "x": 64101,
      "y": 6604,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 91658,
      "e": 14951,
      "ty": 2,
      "x": 816,
      "y": 922
    },
    {
      "t": 91808,
      "e": 15101,
      "ty": 41,
      "x": 41164,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 92389,
      "e": 15682,
      "ty": 3,
      "x": 816,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 92564,
      "e": 15857,
      "ty": 4,
      "x": 41164,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 92564,
      "e": 15857,
      "ty": 5,
      "x": 816,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 92565,
      "e": 15858,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 92568,
      "e": 15861,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 92958,
      "e": 16251,
      "ty": 2,
      "x": 878,
      "y": 999
    },
    {
      "t": 93059,
      "e": 16352,
      "ty": 2,
      "x": 900,
      "y": 1034
    },
    {
      "t": 93059,
      "e": 16352,
      "ty": 41,
      "x": 29840,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93158,
      "e": 16451,
      "ty": 2,
      "x": 916,
      "y": 1053
    },
    {
      "t": 93180,
      "e": 16473,
      "ty": 6,
      "x": 946,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 93259,
      "e": 16552,
      "ty": 2,
      "x": 961,
      "y": 1105
    },
    {
      "t": 93309,
      "e": 16602,
      "ty": 41,
      "x": 28125,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 93659,
      "e": 16952,
      "ty": 2,
      "x": 961,
      "y": 1096
    },
    {
      "t": 93809,
      "e": 17102,
      "ty": 41,
      "x": 28125,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 94060,
      "e": 17353,
      "ty": 3,
      "x": 961,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 94060,
      "e": 17353,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 94061,
      "e": 17354,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 94156,
      "e": 17449,
      "ty": 4,
      "x": 28125,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 94157,
      "e": 17450,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 94158,
      "e": 17451,
      "ty": 5,
      "x": 961,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 94158,
      "e": 17451,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 94458,
      "e": 17751,
      "ty": 2,
      "x": 961,
      "y": 1012
    },
    {
      "t": 94558,
      "e": 17851,
      "ty": 2,
      "x": 835,
      "y": 419
    },
    {
      "t": 94558,
      "e": 17851,
      "ty": 41,
      "x": 28480,
      "y": 22768,
      "ta": "html > body"
    },
    {
      "t": 94658,
      "e": 17951,
      "ty": 2,
      "x": 818,
      "y": 325
    },
    {
      "t": 94809,
      "e": 18102,
      "ty": 41,
      "x": 27894,
      "y": 17560,
      "ta": "html > body"
    },
    {
      "t": 95159,
      "e": 18452,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 95759,
      "e": 19052,
      "ty": 2,
      "x": 915,
      "y": 578
    },
    {
      "t": 95800,
      "e": 19093,
      "ty": 6,
      "x": 955,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95808,
      "e": 19101,
      "ty": 41,
      "x": 30448,
      "y": 5957,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95859,
      "e": 19152,
      "ty": 2,
      "x": 956,
      "y": 712
    },
    {
      "t": 95949,
      "e": 19242,
      "ty": 7,
      "x": 956,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95949,
      "e": 19242,
      "ty": 6,
      "x": 956,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95959,
      "e": 19252,
      "ty": 2,
      "x": 956,
      "y": 695
    },
    {
      "t": 95983,
      "e": 19276,
      "ty": 7,
      "x": 956,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96059,
      "e": 19352,
      "ty": 2,
      "x": 954,
      "y": 607
    },
    {
      "t": 96059,
      "e": 19352,
      "ty": 41,
      "x": 31577,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 96065,
      "e": 19358,
      "ty": 6,
      "x": 954,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96159,
      "e": 19452,
      "ty": 2,
      "x": 954,
      "y": 602
    },
    {
      "t": 96259,
      "e": 19552,
      "ty": 2,
      "x": 954,
      "y": 600
    },
    {
      "t": 96292,
      "e": 19585,
      "ty": 3,
      "x": 954,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96292,
      "e": 19585,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96308,
      "e": 19601,
      "ty": 41,
      "x": 31577,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96380,
      "e": 19673,
      "ty": 4,
      "x": 31577,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 96380,
      "e": 19673,
      "ty": 5,
      "x": 954,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98487,
      "e": 21780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 98680,
      "e": 21973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 98680,
      "e": 21973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98752,
      "e": 22045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 98863,
      "e": 22156,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 98895,
      "e": 22188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 98896,
      "e": 22189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98984,
      "e": 22277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 99160,
      "e": 22453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 99160,
      "e": 22453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99239,
      "e": 22532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 99344,
      "e": 22637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 99360,
      "e": 22653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 99536,
      "e": 22829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 99904,
      "e": 23197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 99984,
      "e": 23277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 100059,
      "e": 23352,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100096,
      "e": 23389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 100159,
      "e": 23452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 100263,
      "e": 23556,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 100592,
      "e": 23885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 100592,
      "e": 23885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100656,
      "e": 23949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 100992,
      "e": 24285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 101048,
      "e": 24341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 101352,
      "e": 24645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 101352,
      "e": 24645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101416,
      "e": 24709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 101456,
      "e": 24749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 101457,
      "e": 24750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101528,
      "e": 24821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nov"
    },
    {
      "t": 101657,
      "e": 24950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 101658,
      "e": 24951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101712,
      "e": 25005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nove"
    },
    {
      "t": 101752,
      "e": 25045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 101752,
      "e": 25045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101807,
      "e": 25100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 101952,
      "e": 25245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 101952,
      "e": 25245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101992,
      "e": 25285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 101992,
      "e": 25285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102015,
      "e": 25308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||be"
    },
    {
      "t": 102047,
      "e": 25340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 102160,
      "e": 25453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 102160,
      "e": 25453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102216,
      "e": 25509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 103060,
      "e": 26353,
      "ty": 2,
      "x": 958,
      "y": 603
    },
    {
      "t": 103060,
      "e": 26353,
      "ty": 41,
      "x": 32443,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103115,
      "e": 26408,
      "ty": 7,
      "x": 959,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103159,
      "e": 26452,
      "ty": 2,
      "x": 950,
      "y": 637
    },
    {
      "t": 103259,
      "e": 26552,
      "ty": 2,
      "x": 941,
      "y": 656
    },
    {
      "t": 103309,
      "e": 26602,
      "ty": 41,
      "x": 28766,
      "y": 53832,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 103521,
      "e": 26814,
      "ty": 6,
      "x": 950,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103559,
      "e": 26852,
      "ty": 2,
      "x": 950,
      "y": 684
    },
    {
      "t": 103559,
      "e": 26852,
      "ty": 41,
      "x": 30712,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103732,
      "e": 27025,
      "ty": 3,
      "x": 950,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103732,
      "e": 27025,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 103732,
      "e": 27025,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103733,
      "e": 27026,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103827,
      "e": 27120,
      "ty": 4,
      "x": 30712,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103827,
      "e": 27120,
      "ty": 5,
      "x": 950,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104471,
      "e": 27764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 104471,
      "e": 27764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104528,
      "e": 27821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 104624,
      "e": 27917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 104624,
      "e": 27917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104704,
      "e": 27997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 104943,
      "e": 28236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 104944,
      "e": 28237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104991,
      "e": 28284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 105407,
      "e": 28700,
      "ty": 7,
      "x": 962,
      "y": 705,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105424,
      "e": 28717,
      "ty": 6,
      "x": 964,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105458,
      "e": 28751,
      "ty": 2,
      "x": 964,
      "y": 708
    },
    {
      "t": 105559,
      "e": 28852,
      "ty": 41,
      "x": 35086,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 108308,
      "e": 31601,
      "ty": 41,
      "x": 35086,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 108358,
      "e": 31651,
      "ty": 2,
      "x": 959,
      "y": 714
    },
    {
      "t": 108409,
      "e": 31702,
      "ty": 7,
      "x": 927,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 108426,
      "e": 31719,
      "ty": 6,
      "x": 911,
      "y": 696,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108458,
      "e": 31751,
      "ty": 2,
      "x": 900,
      "y": 680
    },
    {
      "t": 108459,
      "e": 31752,
      "ty": 7,
      "x": 896,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108559,
      "e": 31852,
      "ty": 2,
      "x": 903,
      "y": 614
    },
    {
      "t": 108559,
      "e": 31852,
      "ty": 41,
      "x": 20547,
      "y": 64830,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 108559,
      "e": 31852,
      "ty": 6,
      "x": 905,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108659,
      "e": 31952,
      "ty": 2,
      "x": 905,
      "y": 605
    },
    {
      "t": 108758,
      "e": 32051,
      "ty": 2,
      "x": 905,
      "y": 604
    },
    {
      "t": 108808,
      "e": 32101,
      "ty": 41,
      "x": 20979,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108940,
      "e": 32233,
      "ty": 3,
      "x": 905,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108940,
      "e": 32233,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 108940,
      "e": 32233,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108941,
      "e": 32234,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109058,
      "e": 32351,
      "ty": 2,
      "x": 899,
      "y": 599
    },
    {
      "t": 109058,
      "e": 32351,
      "ty": 41,
      "x": 19682,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109158,
      "e": 32451,
      "ty": 2,
      "x": 841,
      "y": 592
    },
    {
      "t": 109259,
      "e": 32552,
      "ty": 2,
      "x": 831,
      "y": 591
    },
    {
      "t": 109309,
      "e": 32602,
      "ty": 41,
      "x": 4974,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109412,
      "e": 32705,
      "ty": 4,
      "x": 4974,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109412,
      "e": 32705,
      "ty": 5,
      "x": 831,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109558,
      "e": 32851,
      "ty": 2,
      "x": 851,
      "y": 591
    },
    {
      "t": 109559,
      "e": 32852,
      "ty": 41,
      "x": 9300,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109658,
      "e": 32951,
      "ty": 2,
      "x": 875,
      "y": 591
    },
    {
      "t": 109707,
      "e": 33000,
      "ty": 3,
      "x": 875,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109796,
      "e": 33089,
      "ty": 4,
      "x": 14491,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109796,
      "e": 33089,
      "ty": 5,
      "x": 875,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109808,
      "e": 33101,
      "ty": 41,
      "x": 14491,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109959,
      "e": 33252,
      "ty": 2,
      "x": 876,
      "y": 591
    },
    {
      "t": 110059,
      "e": 33352,
      "ty": 2,
      "x": 881,
      "y": 591
    },
    {
      "t": 110059,
      "e": 33352,
      "ty": 41,
      "x": 15788,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110059,
      "e": 33352,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110379,
      "e": 33672,
      "ty": 3,
      "x": 881,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110459,
      "e": 33752,
      "ty": 2,
      "x": 858,
      "y": 597
    },
    {
      "t": 110477,
      "e": 33770,
      "ty": 7,
      "x": 788,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110559,
      "e": 33852,
      "ty": 2,
      "x": 746,
      "y": 599
    },
    {
      "t": 110559,
      "e": 33852,
      "ty": 41,
      "x": 25415,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 110651,
      "e": 33944,
      "ty": 4,
      "x": 25415,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 111208,
      "e": 34501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 111416,
      "e": 34709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 111416,
      "e": 34709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111472,
      "e": 34765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 111576,
      "e": 34869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 111576,
      "e": 34869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 111664,
      "e": 34957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 112136,
      "e": 35429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 112528,
      "e": 35821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 112639,
      "e": 35932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 113167,
      "e": 36460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 113344,
      "e": 36637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 113344,
      "e": 36637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113408,
      "e": 36701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 113496,
      "e": 36789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 113496,
      "e": 36789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113575,
      "e": 36868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 113736,
      "e": 37029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 113737,
      "e": 37030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113855,
      "e": 37148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVE"
    },
    {
      "t": 113928,
      "e": 37221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 113928,
      "e": 37221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113992,
      "e": 37285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||M"
    },
    {
      "t": 114119,
      "e": 37412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 114120,
      "e": 37413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114176,
      "e": 37469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 114176,
      "e": 37469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114183,
      "e": 37476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||BE"
    },
    {
      "t": 114264,
      "e": 37557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 114384,
      "e": 37677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 114384,
      "e": 37677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 114464,
      "e": 37757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 114560,
      "e": 37853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 115059,
      "e": 38352,
      "ty": 2,
      "x": 742,
      "y": 599
    },
    {
      "t": 115059,
      "e": 38352,
      "ty": 41,
      "x": 25277,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 115159,
      "e": 38452,
      "ty": 2,
      "x": 708,
      "y": 562
    },
    {
      "t": 115259,
      "e": 38552,
      "ty": 2,
      "x": 884,
      "y": 733
    },
    {
      "t": 115309,
      "e": 38602,
      "ty": 41,
      "x": 31269,
      "y": 40993,
      "ta": "html > body"
    },
    {
      "t": 115359,
      "e": 38652,
      "ty": 2,
      "x": 916,
      "y": 748
    },
    {
      "t": 115415,
      "e": 38708,
      "ty": 6,
      "x": 922,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 115458,
      "e": 38751,
      "ty": 2,
      "x": 923,
      "y": 727
    },
    {
      "t": 115559,
      "e": 38852,
      "ty": 41,
      "x": 13955,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116259,
      "e": 39552,
      "ty": 2,
      "x": 897,
      "y": 720
    },
    {
      "t": 116264,
      "e": 39557,
      "ty": 7,
      "x": 890,
      "y": 718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116309,
      "e": 39602,
      "ty": 41,
      "x": 30201,
      "y": 39110,
      "ta": "html > body"
    },
    {
      "t": 116359,
      "e": 39652,
      "ty": 2,
      "x": 885,
      "y": 713
    },
    {
      "t": 116448,
      "e": 39741,
      "ty": 6,
      "x": 886,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116458,
      "e": 39751,
      "ty": 2,
      "x": 886,
      "y": 699
    },
    {
      "t": 116558,
      "e": 39851,
      "ty": 2,
      "x": 883,
      "y": 691
    },
    {
      "t": 116558,
      "e": 39851,
      "ty": 41,
      "x": 16221,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116612,
      "e": 39905,
      "ty": 3,
      "x": 882,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116612,
      "e": 39905,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVEMBER"
    },
    {
      "t": 116612,
      "e": 39905,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 116612,
      "e": 39905,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116659,
      "e": 39952,
      "ty": 2,
      "x": 882,
      "y": 689
    },
    {
      "t": 116683,
      "e": 39976,
      "ty": 4,
      "x": 16005,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116684,
      "e": 39977,
      "ty": 5,
      "x": 882,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116800,
      "e": 40093,
      "ty": 7,
      "x": 885,
      "y": 703,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 116809,
      "e": 40102,
      "ty": 41,
      "x": 16654,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 116859,
      "e": 40152,
      "ty": 2,
      "x": 893,
      "y": 711
    },
    {
      "t": 116866,
      "e": 40159,
      "ty": 6,
      "x": 902,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 116959,
      "e": 40252,
      "ty": 2,
      "x": 927,
      "y": 728
    },
    {
      "t": 117059,
      "e": 40352,
      "ty": 2,
      "x": 936,
      "y": 726
    },
    {
      "t": 117059,
      "e": 40352,
      "ty": 41,
      "x": 20655,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 117158,
      "e": 40451,
      "ty": 2,
      "x": 936,
      "y": 725
    },
    {
      "t": 117309,
      "e": 40602,
      "ty": 41,
      "x": 20655,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 118419,
      "e": 41712,
      "ty": 3,
      "x": 936,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 118420,
      "e": 41713,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 118420,
      "e": 41713,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 118500,
      "e": 41793,
      "ty": 4,
      "x": 20655,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 118501,
      "e": 41794,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 118501,
      "e": 41794,
      "ty": 5,
      "x": 936,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 118502,
      "e": 41795,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 119587,
      "e": 42880,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 119616,
      "e": 42909,
      "ty": 6,
      "x": 936,
      "y": 725,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 119860,
      "e": 43153,
      "ty": 2,
      "x": 937,
      "y": 725
    },
    {
      "t": 119959,
      "e": 43252,
      "ty": 2,
      "x": 940,
      "y": 722
    },
    {
      "t": 120059,
      "e": 43352,
      "ty": 41,
      "x": 30802,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 120059,
      "e": 43352,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120135,
      "e": 43428,
      "ty": 7,
      "x": 803,
      "y": 696,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 120136,
      "e": 43429,
      "ty": 6,
      "x": 803,
      "y": 696,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 120159,
      "e": 43452,
      "ty": 2,
      "x": 684,
      "y": 675
    },
    {
      "t": 120168,
      "e": 43461,
      "ty": 7,
      "x": 552,
      "y": 643,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 120259,
      "e": 43552,
      "ty": 2,
      "x": 178,
      "y": 548
    },
    {
      "t": 120309,
      "e": 43602,
      "ty": 41,
      "x": 4993,
      "y": 29526,
      "ta": "> div.masterdiv"
    },
    {
      "t": 120359,
      "e": 43652,
      "ty": 2,
      "x": 152,
      "y": 537
    },
    {
      "t": 120459,
      "e": 43752,
      "ty": 2,
      "x": 196,
      "y": 493
    },
    {
      "t": 120559,
      "e": 43852,
      "ty": 2,
      "x": 317,
      "y": 479
    },
    {
      "t": 120559,
      "e": 43852,
      "ty": 41,
      "x": 1158,
      "y": 11312,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 120759,
      "e": 44052,
      "ty": 2,
      "x": 332,
      "y": 485
    },
    {
      "t": 120809,
      "e": 44102,
      "ty": 41,
      "x": 63154,
      "y": 5869,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td"
    },
    {
      "t": 120959,
      "e": 44252,
      "ty": 2,
      "x": 287,
      "y": 499
    },
    {
      "t": 121059,
      "e": 44352,
      "ty": 2,
      "x": 234,
      "y": 514
    },
    {
      "t": 121060,
      "e": 44353,
      "ty": 41,
      "x": 7782,
      "y": 28031,
      "ta": "> div.masterdiv"
    },
    {
      "t": 123158,
      "e": 46451,
      "ty": 2,
      "x": 249,
      "y": 523
    },
    {
      "t": 123258,
      "e": 46551,
      "ty": 2,
      "x": 274,
      "y": 540
    },
    {
      "t": 123310,
      "e": 46603,
      "ty": 41,
      "x": 9401,
      "y": 29914,
      "ta": "> div.masterdiv"
    },
    {
      "t": 123338,
      "e": 46631,
      "ty": 6,
      "x": 306,
      "y": 571,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td > a"
    },
    {
      "t": 123354,
      "e": 46647,
      "ty": 7,
      "x": 327,
      "y": 589,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td > a"
    },
    {
      "t": 123358,
      "e": 46651,
      "ty": 2,
      "x": 327,
      "y": 589
    },
    {
      "t": 123404,
      "e": 46697,
      "ty": 6,
      "x": 392,
      "y": 687,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 123422,
      "e": 46715,
      "ty": 7,
      "x": 400,
      "y": 706,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 123422,
      "e": 46715,
      "ty": 6,
      "x": 400,
      "y": 706,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 123459,
      "e": 46752,
      "ty": 2,
      "x": 405,
      "y": 721
    },
    {
      "t": 123558,
      "e": 46851,
      "ty": 2,
      "x": 405,
      "y": 722
    },
    {
      "t": 123558,
      "e": 46851,
      "ty": 41,
      "x": 3697,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 123758,
      "e": 47051,
      "ty": 2,
      "x": 406,
      "y": 702
    },
    {
      "t": 123772,
      "e": 47065,
      "ty": 7,
      "x": 406,
      "y": 696,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 123772,
      "e": 47065,
      "ty": 6,
      "x": 406,
      "y": 696,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 123808,
      "e": 47101,
      "ty": 41,
      "x": 3748,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 123859,
      "e": 47152,
      "ty": 2,
      "x": 406,
      "y": 694
    },
    {
      "t": 124058,
      "e": 47351,
      "ty": 2,
      "x": 390,
      "y": 694
    },
    {
      "t": 124058,
      "e": 47351,
      "ty": 41,
      "x": 2937,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 124158,
      "e": 47451,
      "ty": 2,
      "x": 382,
      "y": 696
    },
    {
      "t": 124308,
      "e": 47601,
      "ty": 41,
      "x": 2532,
      "y": 58549,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 124405,
      "e": 47698,
      "ty": 7,
      "x": 382,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 124405,
      "e": 47698,
      "ty": 6,
      "x": 382,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 124458,
      "e": 47751,
      "ty": 2,
      "x": 415,
      "y": 713
    },
    {
      "t": 124505,
      "e": 47798,
      "ty": 7,
      "x": 451,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 124505,
      "e": 47798,
      "ty": 6,
      "x": 451,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 124538,
      "e": 47831,
      "ty": 7,
      "x": 525,
      "y": 764,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 124538,
      "e": 47831,
      "ty": 6,
      "x": 525,
      "y": 764,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 124555,
      "e": 47848,
      "ty": 7,
      "x": 599,
      "y": 797,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 124558,
      "e": 47851,
      "ty": 2,
      "x": 599,
      "y": 797
    },
    {
      "t": 124558,
      "e": 47851,
      "ty": 41,
      "x": 15031,
      "y": 60579,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 124658,
      "e": 47951,
      "ty": 2,
      "x": 866,
      "y": 935
    },
    {
      "t": 124759,
      "e": 48052,
      "ty": 2,
      "x": 971,
      "y": 998
    },
    {
      "t": 124808,
      "e": 48101,
      "ty": 41,
      "x": 33431,
      "y": 60432,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 124858,
      "e": 48151,
      "ty": 2,
      "x": 1021,
      "y": 1059
    },
    {
      "t": 124940,
      "e": 48233,
      "ty": 6,
      "x": 1027,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 124959,
      "e": 48252,
      "ty": 2,
      "x": 1026,
      "y": 1080
    },
    {
      "t": 125058,
      "e": 48351,
      "ty": 2,
      "x": 1016,
      "y": 1088
    },
    {
      "t": 125058,
      "e": 48351,
      "ty": 41,
      "x": 58162,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 125159,
      "e": 48452,
      "ty": 2,
      "x": 977,
      "y": 1093
    },
    {
      "t": 125308,
      "e": 48601,
      "ty": 41,
      "x": 36863,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 126388,
      "e": 49681,
      "ty": 3,
      "x": 977,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 126388,
      "e": 49681,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 126484,
      "e": 49777,
      "ty": 4,
      "x": 36863,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 126484,
      "e": 49777,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 126485,
      "e": 49778,
      "ty": 5,
      "x": 977,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 126485,
      "e": 49778,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 127486,
      "e": 50779,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 130058,
      "e": 53351,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 131809,
      "e": 54778,
      "ty": 41,
      "x": 33335,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 131858,
      "e": 54827,
      "ty": 2,
      "x": 975,
      "y": 1093
    },
    {
      "t": 132059,
      "e": 55028,
      "ty": 41,
      "x": 33266,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 132059,
      "e": 55028,
      "ty": 2,
      "x": 974,
      "y": 1093
    },
    {
      "t": 133158,
      "e": 56127,
      "ty": 2,
      "x": 969,
      "y": 1087
    },
    {
      "t": 133259,
      "e": 56228,
      "ty": 2,
      "x": 549,
      "y": 466
    },
    {
      "t": 133309,
      "e": 56278,
      "ty": 41,
      "x": 3373,
      "y": 9046,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 133358,
      "e": 56327,
      "ty": 2,
      "x": 312,
      "y": 191
    },
    {
      "t": 133458,
      "e": 56427,
      "ty": 2,
      "x": 320,
      "y": 190
    },
    {
      "t": 133558,
      "e": 56527,
      "ty": 2,
      "x": 736,
      "y": 518
    },
    {
      "t": 133558,
      "e": 56527,
      "ty": 41,
      "x": 21917,
      "y": 28923,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 133659,
      "e": 56628,
      "ty": 2,
      "x": 809,
      "y": 649
    },
    {
      "t": 133759,
      "e": 56728,
      "ty": 2,
      "x": 664,
      "y": 694
    },
    {
      "t": 133809,
      "e": 56778,
      "ty": 41,
      "x": 15801,
      "y": 43832,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 133859,
      "e": 56828,
      "ty": 2,
      "x": 610,
      "y": 710
    },
    {
      "t": 133959,
      "e": 56928,
      "ty": 2,
      "x": 714,
      "y": 687
    },
    {
      "t": 134059,
      "e": 57028,
      "ty": 2,
      "x": 945,
      "y": 679
    },
    {
      "t": 134059,
      "e": 57028,
      "ty": 41,
      "x": 32063,
      "y": 41425,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 134259,
      "e": 57228,
      "ty": 2,
      "x": 776,
      "y": 679
    },
    {
      "t": 134309,
      "e": 57278,
      "ty": 41,
      "x": 13762,
      "y": 41425,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 134359,
      "e": 57328,
      "ty": 2,
      "x": 547,
      "y": 679
    },
    {
      "t": 134459,
      "e": 57428,
      "ty": 2,
      "x": 540,
      "y": 679
    },
    {
      "t": 134559,
      "e": 57528,
      "ty": 41,
      "x": 12403,
      "y": 41425,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 134958,
      "e": 57927,
      "ty": 2,
      "x": 542,
      "y": 756
    },
    {
      "t": 135059,
      "e": 58028,
      "ty": 2,
      "x": 537,
      "y": 776
    },
    {
      "t": 135059,
      "e": 58028,
      "ty": 41,
      "x": 12257,
      "y": 48957,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135159,
      "e": 58128,
      "ty": 2,
      "x": 535,
      "y": 780
    },
    {
      "t": 135259,
      "e": 58228,
      "ty": 2,
      "x": 557,
      "y": 815
    },
    {
      "t": 135324,
      "e": 58293,
      "ty": 41,
      "x": 13228,
      "y": 51985,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135374,
      "e": 58343,
      "ty": 2,
      "x": 558,
      "y": 817
    },
    {
      "t": 135474,
      "e": 58443,
      "ty": 2,
      "x": 665,
      "y": 853
    },
    {
      "t": 135573,
      "e": 58542,
      "ty": 2,
      "x": 910,
      "y": 932
    },
    {
      "t": 135573,
      "e": 58542,
      "ty": 41,
      "x": 30364,
      "y": 61070,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135674,
      "e": 58643,
      "ty": 2,
      "x": 915,
      "y": 934
    },
    {
      "t": 135774,
      "e": 58743,
      "ty": 2,
      "x": 942,
      "y": 924
    },
    {
      "t": 135823,
      "e": 58792,
      "ty": 41,
      "x": 32646,
      "y": 59672,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 135874,
      "e": 58843,
      "ty": 2,
      "x": 957,
      "y": 914
    },
    {
      "t": 135974,
      "e": 58943,
      "ty": 2,
      "x": 962,
      "y": 891
    },
    {
      "t": 136074,
      "e": 59043,
      "ty": 2,
      "x": 967,
      "y": 885
    },
    {
      "t": 136074,
      "e": 59043,
      "ty": 41,
      "x": 33131,
      "y": 57420,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136173,
      "e": 59142,
      "ty": 2,
      "x": 968,
      "y": 885
    },
    {
      "t": 136274,
      "e": 59243,
      "ty": 2,
      "x": 1014,
      "y": 883
    },
    {
      "t": 136323,
      "e": 59292,
      "ty": 41,
      "x": 35704,
      "y": 57265,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136373,
      "e": 59342,
      "ty": 2,
      "x": 1020,
      "y": 883
    },
    {
      "t": 136474,
      "e": 59443,
      "ty": 2,
      "x": 1053,
      "y": 869
    },
    {
      "t": 136574,
      "e": 59543,
      "ty": 2,
      "x": 1163,
      "y": 861
    },
    {
      "t": 136574,
      "e": 59543,
      "ty": 41,
      "x": 42646,
      "y": 55557,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136674,
      "e": 59643,
      "ty": 2,
      "x": 1175,
      "y": 861
    },
    {
      "t": 136774,
      "e": 59743,
      "ty": 2,
      "x": 1326,
      "y": 861
    },
    {
      "t": 136823,
      "e": 59792,
      "ty": 41,
      "x": 50656,
      "y": 55557,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 136873,
      "e": 59842,
      "ty": 2,
      "x": 1328,
      "y": 861
    },
    {
      "t": 136974,
      "e": 59943,
      "ty": 2,
      "x": 983,
      "y": 997
    },
    {
      "t": 137074,
      "e": 60043,
      "ty": 2,
      "x": 823,
      "y": 1046
    },
    {
      "t": 137074,
      "e": 60043,
      "ty": 41,
      "x": 28066,
      "y": 57502,
      "ta": "html > body"
    },
    {
      "t": 137174,
      "e": 60143,
      "ty": 2,
      "x": 819,
      "y": 1051
    },
    {
      "t": 137274,
      "e": 60243,
      "ty": 2,
      "x": 891,
      "y": 1019
    },
    {
      "t": 137324,
      "e": 60293,
      "ty": 41,
      "x": 9227,
      "y": 26916,
      "ta": "> p"
    },
    {
      "t": 137373,
      "e": 60342,
      "ty": 2,
      "x": 893,
      "y": 1019
    },
    {
      "t": 138119,
      "e": 61088,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 138774,
      "e": 61743,
      "ty": 2,
      "x": 971,
      "y": 397
    },
    {
      "t": 138824,
      "e": 61793,
      "ty": 41,
      "x": 33163,
      "y": 21438,
      "ta": "html > body"
    },
    {
      "t": 138874,
      "e": 61843,
      "ty": 2,
      "x": 971,
      "y": 395
    },
    {
      "t": 139122,
      "e": 62091,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 228, dom: 824, initialDom: 828",
  "javascriptErrors": []
}