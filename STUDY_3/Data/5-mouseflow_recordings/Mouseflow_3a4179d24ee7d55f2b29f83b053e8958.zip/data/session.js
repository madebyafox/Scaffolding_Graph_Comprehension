var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3a4179d24ee7d55f2b29f83b053e8958",
  "created": "2018-05-29T15:12:13.9573079-07:00",
  "lastActivity": "2018-05-29T15:12:38.9471611-07:00",
  "pageViews": [
    {
      "id": "05291465890acc701991875904ddbfd151c0a7bc",
      "startTime": "2018-05-29T15:12:13.9573079-07:00",
      "endTime": "2018-05-29T15:12:38.9471611-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 25290,
      "engagementTime": 21303,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 25290,
  "engagementTime": 21303,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8TUB0",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f37e4efacdf099835cabdb7d5ce3ee6b",
  "gdpr": false
}