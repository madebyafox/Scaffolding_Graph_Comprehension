var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a49642ad91a29f6e82fc904b0cbb1157",
  "created": "2018-05-21T09:03:51.612528-07:00",
  "lastActivity": "2018-05-21T09:08:16.1572891-07:00",
  "pageViews": [
    {
      "id": "05215102202124e040068c0edc6ad709dd6f7b86",
      "startTime": "2018-05-21T09:03:51.6740386-07:00",
      "endTime": "2018-05-21T09:08:16.1572891-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 264908,
      "engagementTime": 73728,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 264908,
  "engagementTime": 73728,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "28c37294900a85f9d07e4efb40b92df9",
  "gdpr": false
}