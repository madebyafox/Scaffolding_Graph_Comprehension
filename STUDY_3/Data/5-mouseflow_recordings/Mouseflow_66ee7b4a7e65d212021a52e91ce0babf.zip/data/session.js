var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "66ee7b4a7e65d212021a52e91ce0babf",
  "created": "2018-06-01T10:13:14.0389214-07:00",
  "lastActivity": "2018-06-01T10:13:27.5059214-07:00",
  "pageViews": [
    {
      "id": "0601146575233aaad6e282172515636c5ad85f78",
      "startTime": "2018-06-01T10:13:14.0389214-07:00",
      "endTime": "2018-06-01T10:13:27.5059214-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 13467,
      "engagementTime": 10544,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13467,
  "engagementTime": 10544,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9BS72",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8cc10386568ab3596e7745d4f3f554ed",
  "gdpr": false
}