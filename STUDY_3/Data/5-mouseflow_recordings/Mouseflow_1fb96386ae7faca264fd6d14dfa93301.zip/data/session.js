var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1fb96386ae7faca264fd6d14dfa93301",
  "created": "2018-05-22T12:10:17.3924928-07:00",
  "lastActivity": "2018-05-22T12:11:41.9764928-07:00",
  "pageViews": [
    {
      "id": "052217639132cc4c434884b59afaf01f54676c20",
      "startTime": "2018-05-22T12:10:17.3924928-07:00",
      "endTime": "2018-05-22T12:11:41.9764928-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 84584,
      "engagementTime": 53517,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 84584,
  "engagementTime": 53517,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6Y93F",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f17b04ba1023a4ab9057189dd414fe2c",
  "gdpr": false
}