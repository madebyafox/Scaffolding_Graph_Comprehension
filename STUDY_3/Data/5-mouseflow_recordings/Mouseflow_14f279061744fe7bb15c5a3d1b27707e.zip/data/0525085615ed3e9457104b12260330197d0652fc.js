var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525085615ed3e9457104b12260330197d0652fc"] = {
  "startTime": "2018-05-25T18:19:08.0136186Z",
  "websitePageUrl": "/16",
  "visitTime": 98901,
  "engagementTime": 98536,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "14f279061744fe7bb15c5a3d1b27707e",
    "created": "2018-05-25T18:19:08.0136186+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=TPGMW",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4254f15c3a36e17bbb58626529681aa7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/14f279061744fe7bb15c5a3d1b27707e/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 191,
      "e": 191,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 191,
      "e": 191,
      "ty": 2,
      "x": 716,
      "y": 493
    },
    {
      "t": 191,
      "e": 191,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 714,
      "y": 496
    },
    {
      "t": 252,
      "e": 252,
      "ty": 41,
      "x": 1027,
      "y": 27051,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 303,
      "e": 303,
      "ty": 2,
      "x": 681,
      "y": 543
    },
    {
      "t": 402,
      "e": 402,
      "ty": 2,
      "x": 676,
      "y": 547
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 665,
      "y": 575
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 63838,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 660,
      "e": 660,
      "ty": 2,
      "x": 589,
      "y": 701
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 589,
      "y": 702
    },
    {
      "t": 753,
      "e": 753,
      "ty": 41,
      "x": 55295,
      "y": 38445,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 802,
      "e": 802,
      "ty": 2,
      "x": 586,
      "y": 705
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 585,
      "y": 708
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 54845,
      "y": 38778,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 575,
      "y": 715
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 573,
      "y": 716
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 53496,
      "y": 39221,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 573,
      "y": 718
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 53496,
      "y": 39332,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 572,
      "y": 721
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 53384,
      "y": 39498,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 545,
      "y": 706
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 533,
      "y": 698
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 49000,
      "y": 38224,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 553,
      "y": 651
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 559,
      "y": 627
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 51922,
      "y": 34235,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 559,
      "y": 626
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 548,
      "y": 625
    },
    {
      "t": 5496,
      "e": 5496,
      "ty": 6,
      "x": 347,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 347,
      "y": 598
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 28091,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 337,
      "y": 592
    },
    {
      "t": 5702,
      "e": 5702,
      "ty": 2,
      "x": 335,
      "y": 586
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 26518,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 331,
      "y": 578
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 341,
      "y": 537
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 341,
      "y": 536
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 27417,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6023,
      "e": 6023,
      "ty": 3,
      "x": 341,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6023,
      "e": 6023,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6142,
      "e": 6142,
      "ty": 4,
      "x": 27417,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6142,
      "e": 6142,
      "ty": 5,
      "x": 341,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7307,
      "e": 7307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 7307,
      "e": 7307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7395,
      "e": 7395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7395,
      "e": 7395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7411,
      "e": 7411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yo"
    },
    {
      "t": 7482,
      "e": 7482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 7483,
      "e": 7483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7539,
      "e": 7539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you"
    },
    {
      "t": 7587,
      "e": 7587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you"
    },
    {
      "t": 7770,
      "e": 7770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7770,
      "e": 7770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7907,
      "e": 7907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you "
    },
    {
      "t": 9867,
      "e": 9867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 9867,
      "e": 9867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9979,
      "e": 9979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9979,
      "e": 9979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9986,
      "e": 9986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10074,
      "e": 10074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10170,
      "e": 10170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10170,
      "e": 10170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10274,
      "e": 10274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10299,
      "e": 10299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10299,
      "e": 10299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10402,
      "e": 10402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go t"
    },
    {
      "t": 10434,
      "e": 10434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10443,
      "e": 10443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10443,
      "e": 10443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10555,
      "e": 10555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10674,
      "e": 10674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10674,
      "e": 10674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10787,
      "e": 10787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11131,
      "e": 11131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11131,
      "e": 11131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11274,
      "e": 11274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 11355,
      "e": 11355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11707,
      "e": 11707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11707,
      "e": 11707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11803,
      "e": 11803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 11850,
      "e": 11850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 11851,
      "e": 11851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11963,
      "e": 11963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 12115,
      "e": 12115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12115,
      "e": 12115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12250,
      "e": 12250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13099,
      "e": 13099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13099,
      "e": 13099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13187,
      "e": 13187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13188,
      "e": 13188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13218,
      "e": 13218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 13307,
      "e": 13307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13659,
      "e": 13659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13660,
      "e": 13660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13755,
      "e": 13755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13978,
      "e": 13978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13979,
      "e": 13979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14091,
      "e": 14091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14123,
      "e": 14123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14123,
      "e": 14123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14203,
      "e": 14203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14250,
      "e": 14250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14251,
      "e": 14251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14338,
      "e": 14338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14362,
      "e": 14362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14362,
      "e": 14362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14466,
      "e": 14466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14947,
      "e": 14947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14947,
      "e": 14947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15050,
      "e": 15050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 15763,
      "e": 15763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 15763,
      "e": 15763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15874,
      "e": 15874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 16059,
      "e": 16059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16059,
      "e": 16059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16154,
      "e": 16154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16739,
      "e": 16739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16740,
      "e": 16740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16818,
      "e": 16818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16874,
      "e": 16874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16875,
      "e": 16875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16971,
      "e": 16971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17004,
      "e": 17004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17005,
      "e": 17005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17082,
      "e": 17082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 17162,
      "e": 17162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17162,
      "e": 17162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17258,
      "e": 17258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17338,
      "e": 17338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17339,
      "e": 17339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17482,
      "e": 17482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17498,
      "e": 17498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17499,
      "e": 17499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17586,
      "e": 17586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17586,
      "e": 17586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17610,
      "e": 17610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 17698,
      "e": 17698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17730,
      "e": 17730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17731,
      "e": 17731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17834,
      "e": 17834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17922,
      "e": 17922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17923,
      "e": 17923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18075,
      "e": 18075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18097,
      "e": 18097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18098,
      "e": 18098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18194,
      "e": 18194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18226,
      "e": 18226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18226,
      "e": 18226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18331,
      "e": 18331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18555,
      "e": 18555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18556,
      "e": 18556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18643,
      "e": 18643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18882,
      "e": 18882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18883,
      "e": 18883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19003,
      "e": 19003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then "
    },
    {
      "t": 19011,
      "e": 19011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20178,
      "e": 20178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 20179,
      "e": 20179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20307,
      "e": 20307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 20322,
      "e": 20322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20322,
      "e": 20322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20419,
      "e": 20419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20739,
      "e": 20739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20740,
      "e": 20740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20858,
      "e": 20858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22059,
      "e": 22059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22059,
      "e": 22059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22179,
      "e": 22179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 22298,
      "e": 22298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22298,
      "e": 22298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22403,
      "e": 22403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go di"
    },
    {
      "t": 22410,
      "e": 22410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22410,
      "e": 22410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22410,
      "e": 22410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22522,
      "e": 22522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22546,
      "e": 22546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22546,
      "e": 22546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22618,
      "e": 22618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22754,
      "e": 22754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 22755,
      "e": 22755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22826,
      "e": 22826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 22954,
      "e": 22954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22954,
      "e": 22954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23082,
      "e": 23082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23146,
      "e": 23146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23146,
      "e": 23146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23266,
      "e": 23266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 23275,
      "e": 23275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 23275,
      "e": 23275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23371,
      "e": 23371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 23459,
      "e": 23459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23460,
      "e": 23460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23562,
      "e": 23562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24458,
      "e": 24458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 24458,
      "e": 24458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24602,
      "e": 24602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly v"
    },
    {
      "t": 24642,
      "e": 24642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24642,
      "e": 24642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24650,
      "e": 24650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 24786,
      "e": 24786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24795,
      "e": 24795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24795,
      "e": 24795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24906,
      "e": 24906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 24914,
      "e": 24914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24915,
      "e": 24915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25010,
      "e": 25010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25058,
      "e": 25058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25058,
      "e": 25058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25130,
      "e": 25130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25242,
      "e": 25242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 25243,
      "e": 25243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25274,
      "e": 25274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 25274,
      "e": 25274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25290,
      "e": 25290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||vc"
    },
    {
      "t": 25322,
      "e": 25322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26194,
      "e": 26194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26306,
      "e": 26306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly vertiv"
    },
    {
      "t": 26426,
      "e": 26426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26490,
      "e": 26490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly verti"
    },
    {
      "t": 26602,
      "e": 26602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly verti"
    },
    {
      "t": 26626,
      "e": 26626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 26626,
      "e": 26626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26762,
      "e": 26762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 26794,
      "e": 26794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26794,
      "e": 26794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26915,
      "e": 26915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27091,
      "e": 27091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27092,
      "e": 27092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27186,
      "e": 27186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27346,
      "e": 27346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27347,
      "e": 27347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27458,
      "e": 27458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29410,
      "e": 29410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29411,
      "e": 29411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29483,
      "e": 29483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 29595,
      "e": 29595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29596,
      "e": 29596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29690,
      "e": 29690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29930,
      "e": 29930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29930,
      "e": 29930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29986,
      "e": 29986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 29986,
      "e": 29986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30002,
      "e": 30002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30042,
      "e": 30042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 30090,
      "e": 30090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30186,
      "e": 30186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30186,
      "e": 30186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30281,
      "e": 30281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30497,
      "e": 30497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30498,
      "e": 30498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30593,
      "e": 30593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30650,
      "e": 30650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30650,
      "e": 30650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30729,
      "e": 30729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30730,
      "e": 30730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30738,
      "e": 30738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 30826,
      "e": 30826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30827,
      "e": 30827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30833,
      "e": 30833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30914,
      "e": 30914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30947,
      "e": 30947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30947,
      "e": 30947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31050,
      "e": 31050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31290,
      "e": 31290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31291,
      "e": 31291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31394,
      "e": 31394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31394,
      "e": 31394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31426,
      "e": 31426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 31505,
      "e": 31505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31538,
      "e": 31538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31538,
      "e": 31538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31658,
      "e": 31658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 31891,
      "e": 31891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31891,
      "e": 31891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32002,
      "e": 32002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly vertical from that posi"
    },
    {
      "t": 32003,
      "e": 32003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32066,
      "e": 32066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32066,
      "e": 32066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32201,
      "e": 32201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32210,
      "e": 32210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32210,
      "e": 32210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32298,
      "e": 32298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32299,
      "e": 32299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32322,
      "e": 32322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||io"
    },
    {
      "t": 32410,
      "e": 32410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32410,
      "e": 32410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32433,
      "e": 32433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32529,
      "e": 32529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33666,
      "e": 33666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 33666,
      "e": 33666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33762,
      "e": 33762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 33905,
      "e": 33905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33907,
      "e": 33907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33986,
      "e": 33986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34435,
      "e": 34435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34563,
      "e": 34563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 34563,
      "e": 34563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34665,
      "e": 34665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 34706,
      "e": 34706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34867,
      "e": 34867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34868,
      "e": 34868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34953,
      "e": 34953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35010,
      "e": 35010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35010,
      "e": 35010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35114,
      "e": 35114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35354,
      "e": 35354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35450,
      "e": 35450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly vertical from that position. We"
    },
    {
      "t": 35569,
      "e": 35569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35642,
      "e": 35642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly vertical from that position. W"
    },
    {
      "t": 36026,
      "e": 36026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36028,
      "e": 36028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36098,
      "e": 36098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36099,
      "e": 36099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36114,
      "e": 36114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 36225,
      "e": 36225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36226,
      "e": 36226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36250,
      "e": 36250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36321,
      "e": 36321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36490,
      "e": 36490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36490,
      "e": 36490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36578,
      "e": 36578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36778,
      "e": 36778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 36780,
      "e": 36780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36889,
      "e": 36889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 36970,
      "e": 36970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36972,
      "e": 36972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37099,
      "e": 37099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37100,
      "e": 37100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37101,
      "e": 37101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37202,
      "e": 37202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 37234,
      "e": 37234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37234,
      "e": 37234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37346,
      "e": 37346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37946,
      "e": 37946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 37946,
      "e": 37946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38057,
      "e": 38057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38058,
      "e": 38058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38098,
      "e": 38098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 38162,
      "e": 38162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38490,
      "e": 38490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38490,
      "e": 38490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38554,
      "e": 38554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38554,
      "e": 38554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38602,
      "e": 38602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 38666,
      "e": 38602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38667,
      "e": 38603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38682,
      "e": 38618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38786,
      "e": 38722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38811,
      "e": 38747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38811,
      "e": 38747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38890,
      "e": 38826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 38898,
      "e": 38834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38898,
      "e": 38834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39002,
      "e": 38938,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly vertical from that position. Whatever points "
    },
    {
      "t": 39017,
      "e": 38953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39139,
      "e": 39075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 39139,
      "e": 39075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39258,
      "e": 39194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 39282,
      "e": 39218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39282,
      "e": 39218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39402,
      "e": 39338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39409,
      "e": 39345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39410,
      "e": 39346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39490,
      "e": 39426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 39586,
      "e": 39522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39586,
      "e": 39522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39658,
      "e": 39594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 39771,
      "e": 39707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39771,
      "e": 39707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39858,
      "e": 39794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40034,
      "e": 39970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40034,
      "e": 39970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40154,
      "e": 40090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40154,
      "e": 40090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40178,
      "e": 40114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 40226,
      "e": 40162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40290,
      "e": 40226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40290,
      "e": 40226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40386,
      "e": 40322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40458,
      "e": 40394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40458,
      "e": 40394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40530,
      "e": 40466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40530,
      "e": 40466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40554,
      "e": 40490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 40674,
      "e": 40610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40674,
      "e": 40610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40682,
      "e": 40618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40778,
      "e": 40714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40779,
      "e": 40715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40794,
      "e": 40730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40875,
      "e": 40811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40907,
      "e": 40843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40907,
      "e": 40843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41002,
      "e": 40938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41586,
      "e": 41522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41587,
      "e": 41523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41682,
      "e": 41618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41914,
      "e": 41850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41914,
      "e": 41850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42010,
      "e": 41946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42010,
      "e": 41946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42058,
      "e": 41994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 42137,
      "e": 42073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42145,
      "e": 42081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42145,
      "e": 42081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42250,
      "e": 42186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42297,
      "e": 42233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42297,
      "e": 42233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42402,
      "e": 42338,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line "
    },
    {
      "t": 42433,
      "e": 42369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43583,
      "e": 43519,
      "ty": 7,
      "x": 312,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43601,
      "e": 43537,
      "ty": 2,
      "x": 236,
      "y": 479
    },
    {
      "t": 43701,
      "e": 43637,
      "ty": 2,
      "x": 0,
      "y": 348
    },
    {
      "t": 43751,
      "e": 43687,
      "ty": 41,
      "x": 0,
      "y": 19444,
      "ta": "html"
    },
    {
      "t": 43801,
      "e": 43737,
      "ty": 2,
      "x": 0,
      "y": 396
    },
    {
      "t": 43900,
      "e": 43836,
      "ty": 2,
      "x": 4,
      "y": 465
    },
    {
      "t": 44001,
      "e": 43937,
      "ty": 2,
      "x": 192,
      "y": 509
    },
    {
      "t": 44001,
      "e": 43937,
      "ty": 41,
      "x": 10668,
      "y": 33389,
      "ta": "#.strategy > p"
    },
    {
      "t": 44046,
      "e": 43982,
      "ty": 6,
      "x": 195,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44101,
      "e": 44037,
      "ty": 2,
      "x": 177,
      "y": 553
    },
    {
      "t": 44201,
      "e": 44137,
      "ty": 2,
      "x": 178,
      "y": 576
    },
    {
      "t": 44251,
      "e": 44187,
      "ty": 41,
      "x": 9207,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44301,
      "e": 44237,
      "ty": 2,
      "x": 180,
      "y": 550
    },
    {
      "t": 44401,
      "e": 44337,
      "ty": 2,
      "x": 182,
      "y": 544
    },
    {
      "t": 44501,
      "e": 44437,
      "ty": 2,
      "x": 189,
      "y": 526
    },
    {
      "t": 44502,
      "e": 44438,
      "ty": 41,
      "x": 10331,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44601,
      "e": 44537,
      "ty": 2,
      "x": 191,
      "y": 524
    },
    {
      "t": 44751,
      "e": 44687,
      "ty": 41,
      "x": 10555,
      "y": 1023,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45001,
      "e": 44937,
      "ty": 2,
      "x": 181,
      "y": 527
    },
    {
      "t": 45002,
      "e": 44938,
      "ty": 41,
      "x": 9431,
      "y": 3451,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45501,
      "e": 45437,
      "ty": 2,
      "x": 182,
      "y": 526
    },
    {
      "t": 45501,
      "e": 45437,
      "ty": 41,
      "x": 9544,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45601,
      "e": 45537,
      "ty": 2,
      "x": 184,
      "y": 526
    },
    {
      "t": 45701,
      "e": 45637,
      "ty": 2,
      "x": 185,
      "y": 526
    },
    {
      "t": 45751,
      "e": 45687,
      "ty": 41,
      "x": 9881,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45871,
      "e": 45807,
      "ty": 3,
      "x": 185,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45982,
      "e": 45918,
      "ty": 4,
      "x": 9881,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45982,
      "e": 45918,
      "ty": 5,
      "x": 185,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46201,
      "e": 46137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46202,
      "e": 46138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46307,
      "e": 46139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line "
    },
    {
      "t": 46501,
      "e": 46333,
      "ty": 2,
      "x": 209,
      "y": 557
    },
    {
      "t": 46502,
      "e": 46334,
      "ty": 41,
      "x": 12579,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46601,
      "e": 46433,
      "ty": 2,
      "x": 429,
      "y": 575
    },
    {
      "t": 46701,
      "e": 46533,
      "ty": 2,
      "x": 404,
      "y": 562
    },
    {
      "t": 46751,
      "e": 46583,
      "ty": 41,
      "x": 33037,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46801,
      "e": 46633,
      "ty": 2,
      "x": 391,
      "y": 561
    },
    {
      "t": 46901,
      "e": 46733,
      "ty": 2,
      "x": 441,
      "y": 546
    },
    {
      "t": 47002,
      "e": 46834,
      "ty": 2,
      "x": 442,
      "y": 546
    },
    {
      "t": 47002,
      "e": 46834,
      "ty": 41,
      "x": 38770,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47101,
      "e": 46933,
      "ty": 2,
      "x": 447,
      "y": 545
    },
    {
      "t": 47201,
      "e": 47033,
      "ty": 2,
      "x": 453,
      "y": 543
    },
    {
      "t": 47230,
      "e": 47062,
      "ty": 3,
      "x": 453,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47251,
      "e": 47083,
      "ty": 41,
      "x": 40007,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47342,
      "e": 47174,
      "ty": 4,
      "x": 40007,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47343,
      "e": 47175,
      "ty": 5,
      "x": 453,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47701,
      "e": 47533,
      "ty": 2,
      "x": 454,
      "y": 540
    },
    {
      "t": 47751,
      "e": 47583,
      "ty": 41,
      "x": 40119,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48338,
      "e": 48170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48434,
      "e": 48266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line"
    },
    {
      "t": 48763,
      "e": 48595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48764,
      "e": 48596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48858,
      "e": 48690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49130,
      "e": 48962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 49131,
      "e": 48963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49257,
      "e": 49089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49257,
      "e": 49089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49274,
      "e": 49106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 49402,
      "e": 49234,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line st"
    },
    {
      "t": 49417,
      "e": 49249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49417,
      "e": 49249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49417,
      "e": 49249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49538,
      "e": 49370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49538,
      "e": 49370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49578,
      "e": 49410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 49634,
      "e": 49466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49721,
      "e": 49553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49722,
      "e": 49554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49810,
      "e": 49642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49915,
      "e": 49747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49915,
      "e": 49747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50017,
      "e": 49849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50218,
      "e": 50050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50219,
      "e": 50051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50362,
      "e": 50194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50363,
      "e": 50195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50369,
      "e": 50201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 50506,
      "e": 50338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50627,
      "e": 50459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50627,
      "e": 50459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50730,
      "e": 50562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51505,
      "e": 51337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 51505,
      "e": 51337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51626,
      "e": 51458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 51626,
      "e": 51458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51641,
      "e": 51473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 51721,
      "e": 51553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51758,
      "e": 51590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51758,
      "e": 51590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51862,
      "e": 51694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52342,
      "e": 52174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 52342,
      "e": 52174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52422,
      "e": 52254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 52422,
      "e": 52254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52453,
      "e": 52285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 52502,
      "e": 52334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52609,
      "e": 52441,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line start at 12 pm"
    },
    {
      "t": 52671,
      "e": 52503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 52671,
      "e": 52503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52742,
      "e": 52574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 53645,
      "e": 53477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53742,
      "e": 53477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line start at 12 pm"
    },
    {
      "t": 54197,
      "e": 53932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 54198,
      "e": 53933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54302,
      "e": 54037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 54606,
      "e": 54341,
      "ty": 2,
      "x": 446,
      "y": 593
    },
    {
      "t": 54610,
      "e": 54345,
      "ty": 7,
      "x": 444,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54659,
      "e": 54394,
      "ty": 6,
      "x": 420,
      "y": 661,
      "ta": "#strategyButton"
    },
    {
      "t": 54692,
      "e": 54427,
      "ty": 7,
      "x": 402,
      "y": 693,
      "ta": "#strategyButton"
    },
    {
      "t": 54706,
      "e": 54441,
      "ty": 2,
      "x": 402,
      "y": 693
    },
    {
      "t": 54755,
      "e": 54490,
      "ty": 41,
      "x": 39043,
      "y": 46703,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 54994,
      "e": 54729,
      "ty": 6,
      "x": 405,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 55005,
      "e": 54740,
      "ty": 2,
      "x": 405,
      "y": 687
    },
    {
      "t": 55005,
      "e": 54740,
      "ty": 41,
      "x": 36266,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 55105,
      "e": 54840,
      "ty": 2,
      "x": 408,
      "y": 685
    },
    {
      "t": 55130,
      "e": 54865,
      "ty": 3,
      "x": 408,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 55130,
      "e": 54865,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line start at 12 pm."
    },
    {
      "t": 55131,
      "e": 54866,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55131,
      "e": 54866,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 55256,
      "e": 54991,
      "ty": 41,
      "x": 37904,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 55258,
      "e": 54993,
      "ty": 4,
      "x": 37904,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 55267,
      "e": 55002,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 55269,
      "e": 55004,
      "ty": 5,
      "x": 408,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 55275,
      "e": 55010,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 55905,
      "e": 55640,
      "ty": 2,
      "x": 410,
      "y": 685
    },
    {
      "t": 56006,
      "e": 55741,
      "ty": 2,
      "x": 411,
      "y": 685
    },
    {
      "t": 56006,
      "e": 55741,
      "ty": 41,
      "x": 13878,
      "y": 37503,
      "ta": "html > body"
    },
    {
      "t": 56272,
      "e": 56007,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 56506,
      "e": 56241,
      "ty": 2,
      "x": 426,
      "y": 682
    },
    {
      "t": 56506,
      "e": 56241,
      "ty": 41,
      "x": 14394,
      "y": 37337,
      "ta": "html > body"
    },
    {
      "t": 56606,
      "e": 56341,
      "ty": 2,
      "x": 614,
      "y": 671
    },
    {
      "t": 56678,
      "e": 56413,
      "ty": 6,
      "x": 912,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56705,
      "e": 56440,
      "ty": 2,
      "x": 931,
      "y": 693
    },
    {
      "t": 56756,
      "e": 56491,
      "ty": 41,
      "x": 23748,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56805,
      "e": 56540,
      "ty": 2,
      "x": 942,
      "y": 696
    },
    {
      "t": 56905,
      "e": 56640,
      "ty": 2,
      "x": 949,
      "y": 681
    },
    {
      "t": 56911,
      "e": 56646,
      "ty": 7,
      "x": 954,
      "y": 654,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56911,
      "e": 56646,
      "ty": 6,
      "x": 954,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56927,
      "e": 56662,
      "ty": 7,
      "x": 966,
      "y": 607,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56977,
      "e": 56712,
      "ty": 6,
      "x": 976,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57005,
      "e": 56740,
      "ty": 2,
      "x": 978,
      "y": 569
    },
    {
      "t": 57006,
      "e": 56741,
      "ty": 41,
      "x": 36768,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57275,
      "e": 57010,
      "ty": 3,
      "x": 978,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57276,
      "e": 57011,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57403,
      "e": 57138,
      "ty": 4,
      "x": 36768,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57403,
      "e": 57138,
      "ty": 5,
      "x": 978,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58150,
      "e": 57885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 58150,
      "e": 57885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58270,
      "e": 58005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 58279,
      "e": 58014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 58279,
      "e": 58014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58349,
      "e": 58084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 58946,
      "e": 58681,
      "ty": 7,
      "x": 1058,
      "y": 536,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59006,
      "e": 58741,
      "ty": 2,
      "x": 1062,
      "y": 537
    },
    {
      "t": 59006,
      "e": 58741,
      "ty": 41,
      "x": 54936,
      "y": 33119,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 59030,
      "e": 58765,
      "ty": 6,
      "x": 1054,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59046,
      "e": 58781,
      "ty": 7,
      "x": 1047,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59097,
      "e": 58832,
      "ty": 6,
      "x": 1031,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59105,
      "e": 58840,
      "ty": 2,
      "x": 1031,
      "y": 653
    },
    {
      "t": 59146,
      "e": 58881,
      "ty": 7,
      "x": 1030,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59206,
      "e": 58941,
      "ty": 2,
      "x": 1030,
      "y": 671
    },
    {
      "t": 59256,
      "e": 58991,
      "ty": 41,
      "x": 48015,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 59405,
      "e": 59140,
      "ty": 2,
      "x": 1029,
      "y": 671
    },
    {
      "t": 59506,
      "e": 59241,
      "ty": 41,
      "x": 47799,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 59629,
      "e": 59364,
      "ty": 6,
      "x": 1032,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59706,
      "e": 59441,
      "ty": 2,
      "x": 1036,
      "y": 660
    },
    {
      "t": 59756,
      "e": 59491,
      "ty": 41,
      "x": 49962,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59806,
      "e": 59541,
      "ty": 2,
      "x": 1039,
      "y": 655
    },
    {
      "t": 59826,
      "e": 59561,
      "ty": 3,
      "x": 1039,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59828,
      "e": 59563,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 59829,
      "e": 59564,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59830,
      "e": 59565,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59922,
      "e": 59657,
      "ty": 4,
      "x": 49962,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59922,
      "e": 59657,
      "ty": 5,
      "x": 1039,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60006,
      "e": 59741,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60645,
      "e": 60380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 60879,
      "e": 60614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 60879,
      "e": 60614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60974,
      "e": 60709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 60990,
      "e": 60725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 60990,
      "e": 60725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61102,
      "e": 60837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 61103,
      "e": 60838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61117,
      "e": 60852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 61214,
      "e": 60949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 61230,
      "e": 60965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 61806,
      "e": 61541,
      "ty": 2,
      "x": 1043,
      "y": 655
    },
    {
      "t": 61864,
      "e": 61599,
      "ty": 7,
      "x": 1058,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61906,
      "e": 61641,
      "ty": 2,
      "x": 1049,
      "y": 695
    },
    {
      "t": 62006,
      "e": 61741,
      "ty": 2,
      "x": 1021,
      "y": 711
    },
    {
      "t": 62006,
      "e": 61741,
      "ty": 41,
      "x": 34885,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 62106,
      "e": 61841,
      "ty": 2,
      "x": 999,
      "y": 751
    },
    {
      "t": 62206,
      "e": 61941,
      "ty": 2,
      "x": 1008,
      "y": 726
    },
    {
      "t": 62256,
      "e": 61991,
      "ty": 41,
      "x": 34368,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 62282,
      "e": 62017,
      "ty": 6,
      "x": 1006,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62305,
      "e": 62040,
      "ty": 2,
      "x": 1006,
      "y": 702
    },
    {
      "t": 62406,
      "e": 62141,
      "ty": 2,
      "x": 1006,
      "y": 698
    },
    {
      "t": 62474,
      "e": 62209,
      "ty": 3,
      "x": 1006,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62475,
      "e": 62210,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 62475,
      "e": 62210,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62475,
      "e": 62210,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62506,
      "e": 62241,
      "ty": 41,
      "x": 56733,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62609,
      "e": 62344,
      "ty": 4,
      "x": 56733,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62610,
      "e": 62345,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62611,
      "e": 62346,
      "ty": 5,
      "x": 1006,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62611,
      "e": 62346,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 63625,
      "e": 63360,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 64606,
      "e": 64341,
      "ty": 2,
      "x": 872,
      "y": 385
    },
    {
      "t": 64705,
      "e": 64440,
      "ty": 2,
      "x": 806,
      "y": 159
    },
    {
      "t": 64756,
      "e": 64491,
      "ty": 41,
      "x": 27687,
      "y": 7811,
      "ta": "html > body"
    },
    {
      "t": 64806,
      "e": 64541,
      "ty": 2,
      "x": 812,
      "y": 149
    },
    {
      "t": 64905,
      "e": 64640,
      "ty": 2,
      "x": 844,
      "y": 224
    },
    {
      "t": 65005,
      "e": 64740,
      "ty": 2,
      "x": 852,
      "y": 247
    },
    {
      "t": 65005,
      "e": 64740,
      "ty": 41,
      "x": 25039,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65106,
      "e": 64841,
      "ty": 2,
      "x": 853,
      "y": 249
    },
    {
      "t": 65206,
      "e": 64941,
      "ty": 2,
      "x": 853,
      "y": 250
    },
    {
      "t": 65256,
      "e": 64991,
      "ty": 41,
      "x": 5832,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 65306,
      "e": 65041,
      "ty": 2,
      "x": 840,
      "y": 242
    },
    {
      "t": 65318,
      "e": 65053,
      "ty": 6,
      "x": 839,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65405,
      "e": 65140,
      "ty": 2,
      "x": 839,
      "y": 240
    },
    {
      "t": 65506,
      "e": 65241,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65705,
      "e": 65440,
      "ty": 2,
      "x": 838,
      "y": 236
    },
    {
      "t": 65755,
      "e": 65490,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65899,
      "e": 65634,
      "ty": 3,
      "x": 838,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65900,
      "e": 65635,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66025,
      "e": 65760,
      "ty": 4,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66026,
      "e": 65761,
      "ty": 5,
      "x": 838,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66027,
      "e": 65762,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 66405,
      "e": 66140,
      "ty": 2,
      "x": 837,
      "y": 243
    },
    {
      "t": 66418,
      "e": 66153,
      "ty": 7,
      "x": 837,
      "y": 254,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66436,
      "e": 66171,
      "ty": 6,
      "x": 839,
      "y": 270,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 66452,
      "e": 66187,
      "ty": 7,
      "x": 840,
      "y": 286,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 66505,
      "e": 66240,
      "ty": 2,
      "x": 844,
      "y": 354
    },
    {
      "t": 66505,
      "e": 66240,
      "ty": 41,
      "x": 5358,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66606,
      "e": 66341,
      "ty": 2,
      "x": 845,
      "y": 435
    },
    {
      "t": 66705,
      "e": 66440,
      "ty": 2,
      "x": 844,
      "y": 437
    },
    {
      "t": 66755,
      "e": 66490,
      "ty": 41,
      "x": 5121,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 66806,
      "e": 66541,
      "ty": 2,
      "x": 841,
      "y": 422
    },
    {
      "t": 66869,
      "e": 66604,
      "ty": 6,
      "x": 839,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66905,
      "e": 66640,
      "ty": 2,
      "x": 839,
      "y": 416
    },
    {
      "t": 67005,
      "e": 66740,
      "ty": 2,
      "x": 839,
      "y": 415
    },
    {
      "t": 67005,
      "e": 66740,
      "ty": 41,
      "x": 63408,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67105,
      "e": 66840,
      "ty": 2,
      "x": 835,
      "y": 414
    },
    {
      "t": 67205,
      "e": 66940,
      "ty": 2,
      "x": 830,
      "y": 411
    },
    {
      "t": 67255,
      "e": 66990,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67619,
      "e": 67354,
      "ty": 3,
      "x": 830,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67620,
      "e": 67355,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67621,
      "e": 67356,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67746,
      "e": 67481,
      "ty": 4,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67746,
      "e": 67481,
      "ty": 5,
      "x": 830,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67746,
      "e": 67481,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 68120,
      "e": 67855,
      "ty": 7,
      "x": 837,
      "y": 426,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 68205,
      "e": 67940,
      "ty": 2,
      "x": 930,
      "y": 546
    },
    {
      "t": 68255,
      "e": 67990,
      "ty": 41,
      "x": 31938,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 68305,
      "e": 68040,
      "ty": 2,
      "x": 959,
      "y": 589
    },
    {
      "t": 68405,
      "e": 68040,
      "ty": 2,
      "x": 963,
      "y": 597
    },
    {
      "t": 68505,
      "e": 68140,
      "ty": 2,
      "x": 968,
      "y": 604
    },
    {
      "t": 68505,
      "e": 68140,
      "ty": 41,
      "x": 34786,
      "y": 33103,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68606,
      "e": 68241,
      "ty": 2,
      "x": 962,
      "y": 622
    },
    {
      "t": 68705,
      "e": 68340,
      "ty": 2,
      "x": 872,
      "y": 707
    },
    {
      "t": 68755,
      "e": 68390,
      "ty": 41,
      "x": 10184,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 68806,
      "e": 68441,
      "ty": 2,
      "x": 857,
      "y": 735
    },
    {
      "t": 68905,
      "e": 68540,
      "ty": 2,
      "x": 857,
      "y": 749
    },
    {
      "t": 69005,
      "e": 68640,
      "ty": 2,
      "x": 862,
      "y": 768
    },
    {
      "t": 69005,
      "e": 68640,
      "ty": 41,
      "x": 16931,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 69105,
      "e": 68740,
      "ty": 2,
      "x": 861,
      "y": 801
    },
    {
      "t": 69205,
      "e": 68840,
      "ty": 2,
      "x": 852,
      "y": 871
    },
    {
      "t": 69255,
      "e": 68890,
      "ty": 41,
      "x": 5832,
      "y": 17139,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 69305,
      "e": 68940,
      "ty": 2,
      "x": 844,
      "y": 933
    },
    {
      "t": 69405,
      "e": 69040,
      "ty": 2,
      "x": 844,
      "y": 934
    },
    {
      "t": 69505,
      "e": 69140,
      "ty": 2,
      "x": 840,
      "y": 934
    },
    {
      "t": 69505,
      "e": 69140,
      "ty": 41,
      "x": 20291,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 69505,
      "e": 69140,
      "ty": 6,
      "x": 839,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69605,
      "e": 69240,
      "ty": 2,
      "x": 836,
      "y": 931
    },
    {
      "t": 69665,
      "e": 69300,
      "ty": 7,
      "x": 835,
      "y": 927,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69705,
      "e": 69340,
      "ty": 2,
      "x": 834,
      "y": 921
    },
    {
      "t": 69755,
      "e": 69390,
      "ty": 41,
      "x": 3222,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 69805,
      "e": 69440,
      "ty": 2,
      "x": 835,
      "y": 886
    },
    {
      "t": 69905,
      "e": 69540,
      "ty": 2,
      "x": 799,
      "y": 853
    },
    {
      "t": 70005,
      "e": 69640,
      "ty": 2,
      "x": 816,
      "y": 866
    },
    {
      "t": 70005,
      "e": 69640,
      "ty": 41,
      "x": 27825,
      "y": 47530,
      "ta": "html > body"
    },
    {
      "t": 70105,
      "e": 69740,
      "ty": 2,
      "x": 833,
      "y": 868
    },
    {
      "t": 70205,
      "e": 69840,
      "ty": 2,
      "x": 985,
      "y": 768
    },
    {
      "t": 70255,
      "e": 69890,
      "ty": 41,
      "x": 37159,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 70305,
      "e": 69940,
      "ty": 2,
      "x": 954,
      "y": 732
    },
    {
      "t": 70405,
      "e": 70040,
      "ty": 2,
      "x": 851,
      "y": 751
    },
    {
      "t": 70505,
      "e": 70140,
      "ty": 2,
      "x": 853,
      "y": 755
    },
    {
      "t": 70505,
      "e": 70140,
      "ty": 41,
      "x": 13176,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 70606,
      "e": 70241,
      "ty": 2,
      "x": 900,
      "y": 687
    },
    {
      "t": 70705,
      "e": 70340,
      "ty": 2,
      "x": 863,
      "y": 682
    },
    {
      "t": 70756,
      "e": 70391,
      "ty": 41,
      "x": 7941,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 70805,
      "e": 70440,
      "ty": 2,
      "x": 843,
      "y": 680
    },
    {
      "t": 70905,
      "e": 70540,
      "ty": 2,
      "x": 840,
      "y": 680
    },
    {
      "t": 71005,
      "e": 70640,
      "ty": 41,
      "x": 4988,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 71090,
      "e": 70725,
      "ty": 6,
      "x": 833,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 71105,
      "e": 70740,
      "ty": 2,
      "x": 833,
      "y": 697
    },
    {
      "t": 71255,
      "e": 70890,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 71305,
      "e": 70940,
      "ty": 2,
      "x": 832,
      "y": 702
    },
    {
      "t": 71338,
      "e": 70973,
      "ty": 7,
      "x": 832,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 71389,
      "e": 71024,
      "ty": 6,
      "x": 832,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71405,
      "e": 71040,
      "ty": 2,
      "x": 832,
      "y": 728
    },
    {
      "t": 71422,
      "e": 71057,
      "ty": 7,
      "x": 839,
      "y": 745,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71505,
      "e": 71140,
      "ty": 2,
      "x": 847,
      "y": 765
    },
    {
      "t": 71505,
      "e": 71140,
      "ty": 41,
      "x": 10672,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 71605,
      "e": 71240,
      "ty": 2,
      "x": 849,
      "y": 778
    },
    {
      "t": 71705,
      "e": 71340,
      "ty": 2,
      "x": 848,
      "y": 786
    },
    {
      "t": 71755,
      "e": 71390,
      "ty": 41,
      "x": 14319,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 71805,
      "e": 71440,
      "ty": 2,
      "x": 847,
      "y": 787
    },
    {
      "t": 72705,
      "e": 72340,
      "ty": 2,
      "x": 902,
      "y": 771
    },
    {
      "t": 72755,
      "e": 72390,
      "ty": 41,
      "x": 26242,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 72805,
      "e": 72440,
      "ty": 2,
      "x": 949,
      "y": 762
    },
    {
      "t": 72905,
      "e": 72540,
      "ty": 2,
      "x": 963,
      "y": 735
    },
    {
      "t": 73005,
      "e": 72640,
      "ty": 2,
      "x": 970,
      "y": 719
    },
    {
      "t": 73005,
      "e": 72640,
      "ty": 41,
      "x": 35261,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 73105,
      "e": 72740,
      "ty": 2,
      "x": 974,
      "y": 715
    },
    {
      "t": 73206,
      "e": 72841,
      "ty": 2,
      "x": 973,
      "y": 716
    },
    {
      "t": 73255,
      "e": 72890,
      "ty": 41,
      "x": 34786,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 73305,
      "e": 72940,
      "ty": 2,
      "x": 963,
      "y": 725
    },
    {
      "t": 73405,
      "e": 73040,
      "ty": 2,
      "x": 952,
      "y": 733
    },
    {
      "t": 73505,
      "e": 73140,
      "ty": 2,
      "x": 915,
      "y": 756
    },
    {
      "t": 73505,
      "e": 73140,
      "ty": 41,
      "x": 39045,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 73605,
      "e": 73240,
      "ty": 2,
      "x": 893,
      "y": 768
    },
    {
      "t": 73706,
      "e": 73341,
      "ty": 2,
      "x": 850,
      "y": 784
    },
    {
      "t": 73725,
      "e": 73360,
      "ty": 6,
      "x": 838,
      "y": 788,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73755,
      "e": 73390,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73774,
      "e": 73409,
      "ty": 7,
      "x": 829,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73805,
      "e": 73440,
      "ty": 2,
      "x": 829,
      "y": 793
    },
    {
      "t": 73905,
      "e": 73540,
      "ty": 2,
      "x": 829,
      "y": 795
    },
    {
      "t": 74006,
      "e": 73641,
      "ty": 41,
      "x": 4242,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 74177,
      "e": 73812,
      "ty": 6,
      "x": 829,
      "y": 792,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74205,
      "e": 73840,
      "ty": 2,
      "x": 829,
      "y": 791
    },
    {
      "t": 74255,
      "e": 73890,
      "ty": 41,
      "x": 18037,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74306,
      "e": 73941,
      "ty": 2,
      "x": 832,
      "y": 788
    },
    {
      "t": 74505,
      "e": 74140,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74505,
      "e": 74140,
      "ty": 3,
      "x": 832,
      "y": 788,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74506,
      "e": 74141,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 74506,
      "e": 74141,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74618,
      "e": 74253,
      "ty": 4,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74618,
      "e": 74253,
      "ty": 5,
      "x": 832,
      "y": 788,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 74618,
      "e": 74253,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 74930,
      "e": 74565,
      "ty": 7,
      "x": 838,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 75005,
      "e": 74640,
      "ty": 2,
      "x": 853,
      "y": 843
    },
    {
      "t": 75005,
      "e": 74640,
      "ty": 41,
      "x": 22248,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 75105,
      "e": 74740,
      "ty": 2,
      "x": 856,
      "y": 886
    },
    {
      "t": 75205,
      "e": 74840,
      "ty": 2,
      "x": 846,
      "y": 935
    },
    {
      "t": 75255,
      "e": 74890,
      "ty": 41,
      "x": 25753,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75305,
      "e": 74940,
      "ty": 2,
      "x": 844,
      "y": 940
    },
    {
      "t": 75506,
      "e": 75141,
      "ty": 41,
      "x": 24660,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75705,
      "e": 75340,
      "ty": 2,
      "x": 841,
      "y": 940
    },
    {
      "t": 75756,
      "e": 75391,
      "ty": 41,
      "x": 20291,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75787,
      "e": 75422,
      "ty": 6,
      "x": 838,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75805,
      "e": 75440,
      "ty": 2,
      "x": 837,
      "y": 938
    },
    {
      "t": 75905,
      "e": 75540,
      "ty": 2,
      "x": 834,
      "y": 936
    },
    {
      "t": 75931,
      "e": 75566,
      "ty": 3,
      "x": 834,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75932,
      "e": 75567,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 75933,
      "e": 75568,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76006,
      "e": 75641,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76026,
      "e": 75661,
      "ty": 4,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76026,
      "e": 75661,
      "ty": 5,
      "x": 834,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76026,
      "e": 75661,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 76506,
      "e": 76141,
      "ty": 2,
      "x": 839,
      "y": 936
    },
    {
      "t": 76506,
      "e": 76141,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76510,
      "e": 76145,
      "ty": 7,
      "x": 841,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76605,
      "e": 76240,
      "ty": 2,
      "x": 860,
      "y": 983
    },
    {
      "t": 76706,
      "e": 76341,
      "ty": 2,
      "x": 862,
      "y": 987
    },
    {
      "t": 76756,
      "e": 76391,
      "ty": 41,
      "x": 41275,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 76805,
      "e": 76440,
      "ty": 2,
      "x": 870,
      "y": 1000
    },
    {
      "t": 76826,
      "e": 76461,
      "ty": 6,
      "x": 879,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76905,
      "e": 76540,
      "ty": 2,
      "x": 887,
      "y": 1018
    },
    {
      "t": 77006,
      "e": 76641,
      "ty": 2,
      "x": 887,
      "y": 1019
    },
    {
      "t": 77006,
      "e": 76641,
      "ty": 41,
      "x": 29675,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 77606,
      "e": 77241,
      "ty": 2,
      "x": 889,
      "y": 1020
    },
    {
      "t": 77755,
      "e": 77390,
      "ty": 41,
      "x": 30705,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79106,
      "e": 78741,
      "ty": 2,
      "x": 893,
      "y": 1020
    },
    {
      "t": 79205,
      "e": 78840,
      "ty": 2,
      "x": 894,
      "y": 1020
    },
    {
      "t": 79255,
      "e": 78890,
      "ty": 41,
      "x": 33282,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80005,
      "e": 79640,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80178,
      "e": 79813,
      "ty": 3,
      "x": 894,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80178,
      "e": 79813,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 80178,
      "e": 79813,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80306,
      "e": 79941,
      "ty": 4,
      "x": 33282,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80306,
      "e": 79941,
      "ty": 5,
      "x": 894,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80307,
      "e": 79942,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80308,
      "e": 79943,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 80309,
      "e": 79944,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 81641,
      "e": 81276,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 82606,
      "e": 82241,
      "ty": 2,
      "x": 886,
      "y": 852
    },
    {
      "t": 82706,
      "e": 82341,
      "ty": 2,
      "x": 881,
      "y": 719
    },
    {
      "t": 82756,
      "e": 82391,
      "ty": 41,
      "x": 28856,
      "y": 27803,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82806,
      "e": 82441,
      "ty": 2,
      "x": 880,
      "y": 716
    },
    {
      "t": 82906,
      "e": 82541,
      "ty": 2,
      "x": 871,
      "y": 717
    },
    {
      "t": 83005,
      "e": 82640,
      "ty": 2,
      "x": 864,
      "y": 703
    },
    {
      "t": 83005,
      "e": 82640,
      "ty": 41,
      "x": 28069,
      "y": 20196,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83105,
      "e": 82740,
      "ty": 2,
      "x": 876,
      "y": 618
    },
    {
      "t": 83205,
      "e": 82840,
      "ty": 2,
      "x": 896,
      "y": 581
    },
    {
      "t": 83256,
      "e": 82891,
      "ty": 41,
      "x": 29889,
      "y": 33748,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83305,
      "e": 82940,
      "ty": 2,
      "x": 902,
      "y": 566
    },
    {
      "t": 83506,
      "e": 83141,
      "ty": 41,
      "x": 29938,
      "y": 32578,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 84406,
      "e": 84041,
      "ty": 2,
      "x": 898,
      "y": 566
    },
    {
      "t": 84506,
      "e": 84141,
      "ty": 41,
      "x": 29741,
      "y": 32578,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85105,
      "e": 84740,
      "ty": 2,
      "x": 901,
      "y": 566
    },
    {
      "t": 85206,
      "e": 84841,
      "ty": 2,
      "x": 972,
      "y": 576
    },
    {
      "t": 85256,
      "e": 84891,
      "ty": 41,
      "x": 33776,
      "y": 36869,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85306,
      "e": 84941,
      "ty": 2,
      "x": 980,
      "y": 577
    },
    {
      "t": 88406,
      "e": 88041,
      "ty": 2,
      "x": 968,
      "y": 589
    },
    {
      "t": 88506,
      "e": 88141,
      "ty": 2,
      "x": 963,
      "y": 592
    },
    {
      "t": 88506,
      "e": 88141,
      "ty": 41,
      "x": 32939,
      "y": 42720,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 89205,
      "e": 88840,
      "ty": 2,
      "x": 977,
      "y": 631
    },
    {
      "t": 89255,
      "e": 88890,
      "ty": 41,
      "x": 34464,
      "y": 37227,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89305,
      "e": 88940,
      "ty": 2,
      "x": 1042,
      "y": 712
    },
    {
      "t": 89405,
      "e": 89040,
      "ty": 2,
      "x": 1131,
      "y": 798
    },
    {
      "t": 89506,
      "e": 89141,
      "ty": 41,
      "x": 41204,
      "y": 53668,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 90006,
      "e": 89641,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 92405,
      "e": 92040,
      "ty": 2,
      "x": 1132,
      "y": 814
    },
    {
      "t": 92506,
      "e": 92141,
      "ty": 2,
      "x": 1131,
      "y": 894
    },
    {
      "t": 92506,
      "e": 92141,
      "ty": 41,
      "x": 41204,
      "y": 50358,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 92606,
      "e": 92241,
      "ty": 2,
      "x": 1117,
      "y": 942
    },
    {
      "t": 92705,
      "e": 92340,
      "ty": 2,
      "x": 1012,
      "y": 1035
    },
    {
      "t": 92756,
      "e": 92391,
      "ty": 41,
      "x": 33333,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92806,
      "e": 92441,
      "ty": 2,
      "x": 951,
      "y": 1064
    },
    {
      "t": 92906,
      "e": 92541,
      "ty": 2,
      "x": 949,
      "y": 1065
    },
    {
      "t": 93006,
      "e": 92641,
      "ty": 41,
      "x": 32250,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93305,
      "e": 92940,
      "ty": 2,
      "x": 952,
      "y": 1065
    },
    {
      "t": 93406,
      "e": 93041,
      "ty": 2,
      "x": 954,
      "y": 1065
    },
    {
      "t": 93506,
      "e": 93141,
      "ty": 41,
      "x": 32496,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93706,
      "e": 93341,
      "ty": 2,
      "x": 955,
      "y": 1065
    },
    {
      "t": 93756,
      "e": 93391,
      "ty": 41,
      "x": 32792,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93806,
      "e": 93441,
      "ty": 2,
      "x": 968,
      "y": 1065
    },
    {
      "t": 93906,
      "e": 93541,
      "ty": 2,
      "x": 974,
      "y": 1065
    },
    {
      "t": 94006,
      "e": 93641,
      "ty": 2,
      "x": 1036,
      "y": 1065
    },
    {
      "t": 94006,
      "e": 93641,
      "ty": 41,
      "x": 36531,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94106,
      "e": 93741,
      "ty": 2,
      "x": 1102,
      "y": 1070
    },
    {
      "t": 94206,
      "e": 93841,
      "ty": 2,
      "x": 1108,
      "y": 1071
    },
    {
      "t": 94256,
      "e": 93891,
      "ty": 41,
      "x": 40073,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94806,
      "e": 94441,
      "ty": 2,
      "x": 1091,
      "y": 1071
    },
    {
      "t": 94906,
      "e": 94541,
      "ty": 2,
      "x": 1065,
      "y": 1071
    },
    {
      "t": 95006,
      "e": 94641,
      "ty": 2,
      "x": 1045,
      "y": 1069
    },
    {
      "t": 95007,
      "e": 94642,
      "ty": 41,
      "x": 36973,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95060,
      "e": 94695,
      "ty": 6,
      "x": 1027,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 95106,
      "e": 94741,
      "ty": 2,
      "x": 1021,
      "y": 1083
    },
    {
      "t": 95205,
      "e": 94840,
      "ty": 2,
      "x": 1013,
      "y": 1091
    },
    {
      "t": 95256,
      "e": 94891,
      "ty": 41,
      "x": 56523,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 96235,
      "e": 95870,
      "ty": 3,
      "x": 1013,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 96236,
      "e": 95871,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96394,
      "e": 96029,
      "ty": 4,
      "x": 56523,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 96394,
      "e": 96029,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96394,
      "e": 96029,
      "ty": 5,
      "x": 1013,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 96395,
      "e": 96030,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 97435,
      "e": 97070,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 98901,
      "e": 98536,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 85259, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 85263, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 2897, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 89489, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13179, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 103674, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12965, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 117728, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8612, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 127343, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 18134, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 146877, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:994,y:629,t:1527271755055};\\\", \\\"{x:1006,y:624,t:1527271755062};\\\", \\\"{x:1030,y:623,t:1527271755079};\\\", \\\"{x:1045,y:627,t:1527271755096};\\\", \\\"{x:1066,y:637,t:1527271755112};\\\", \\\"{x:1096,y:645,t:1527271755129};\\\", \\\"{x:1141,y:658,t:1527271755146};\\\", \\\"{x:1199,y:675,t:1527271755162};\\\", \\\"{x:1250,y:690,t:1527271755179};\\\", \\\"{x:1308,y:716,t:1527271755196};\\\", \\\"{x:1364,y:741,t:1527271755212};\\\", \\\"{x:1413,y:762,t:1527271755230};\\\", \\\"{x:1472,y:787,t:1527271755245};\\\", \\\"{x:1491,y:796,t:1527271755262};\\\", \\\"{x:1498,y:802,t:1527271755279};\\\", \\\"{x:1499,y:805,t:1527271755296};\\\", \\\"{x:1502,y:810,t:1527271755312};\\\", \\\"{x:1502,y:822,t:1527271755329};\\\", \\\"{x:1502,y:839,t:1527271755346};\\\", \\\"{x:1500,y:857,t:1527271755363};\\\", \\\"{x:1489,y:876,t:1527271755380};\\\", \\\"{x:1478,y:892,t:1527271755396};\\\", \\\"{x:1462,y:913,t:1527271755413};\\\", \\\"{x:1451,y:928,t:1527271755430};\\\", \\\"{x:1439,y:940,t:1527271755446};\\\", \\\"{x:1434,y:944,t:1527271755463};\\\", \\\"{x:1432,y:946,t:1527271755479};\\\", \\\"{x:1429,y:948,t:1527271755496};\\\", \\\"{x:1424,y:951,t:1527271755513};\\\", \\\"{x:1419,y:952,t:1527271755529};\\\", \\\"{x:1417,y:953,t:1527271755547};\\\", \\\"{x:1416,y:953,t:1527271755582};\\\", \\\"{x:1415,y:953,t:1527271755596};\\\", \\\"{x:1409,y:953,t:1527271755613};\\\", \\\"{x:1405,y:953,t:1527271755629};\\\", \\\"{x:1398,y:954,t:1527271755646};\\\", \\\"{x:1392,y:955,t:1527271755663};\\\", \\\"{x:1385,y:955,t:1527271755680};\\\", \\\"{x:1379,y:955,t:1527271755696};\\\", \\\"{x:1377,y:955,t:1527271755714};\\\", \\\"{x:1374,y:955,t:1527271755729};\\\", \\\"{x:1372,y:955,t:1527271755878};\\\", \\\"{x:1371,y:955,t:1527271755894};\\\", \\\"{x:1370,y:955,t:1527271755902};\\\", \\\"{x:1369,y:956,t:1527271755913};\\\", \\\"{x:1367,y:956,t:1527271755930};\\\", \\\"{x:1361,y:958,t:1527271755946};\\\", \\\"{x:1353,y:960,t:1527271755963};\\\", \\\"{x:1347,y:960,t:1527271755980};\\\", \\\"{x:1339,y:960,t:1527271755996};\\\", \\\"{x:1333,y:960,t:1527271756013};\\\", \\\"{x:1328,y:960,t:1527271756030};\\\", \\\"{x:1325,y:960,t:1527271756046};\\\", \\\"{x:1321,y:960,t:1527271756063};\\\", \\\"{x:1313,y:962,t:1527271756080};\\\", \\\"{x:1307,y:963,t:1527271756096};\\\", \\\"{x:1302,y:964,t:1527271756113};\\\", \\\"{x:1297,y:964,t:1527271756130};\\\", \\\"{x:1294,y:964,t:1527271756146};\\\", \\\"{x:1291,y:964,t:1527271756164};\\\", \\\"{x:1289,y:964,t:1527271756180};\\\", \\\"{x:1288,y:964,t:1527271756413};\\\", \\\"{x:1287,y:964,t:1527271756430};\\\", \\\"{x:1286,y:964,t:1527271756558};\\\", \\\"{x:1286,y:963,t:1527271756581};\\\", \\\"{x:1286,y:962,t:1527271756597};\\\", \\\"{x:1286,y:959,t:1527271756613};\\\", \\\"{x:1287,y:953,t:1527271756630};\\\", \\\"{x:1289,y:949,t:1527271756647};\\\", \\\"{x:1290,y:944,t:1527271756663};\\\", \\\"{x:1292,y:940,t:1527271756680};\\\", \\\"{x:1293,y:935,t:1527271756697};\\\", \\\"{x:1293,y:931,t:1527271756713};\\\", \\\"{x:1293,y:927,t:1527271756730};\\\", \\\"{x:1293,y:924,t:1527271756747};\\\", \\\"{x:1296,y:918,t:1527271756763};\\\", \\\"{x:1298,y:911,t:1527271756780};\\\", \\\"{x:1301,y:903,t:1527271756797};\\\", \\\"{x:1304,y:894,t:1527271756814};\\\", \\\"{x:1306,y:887,t:1527271756830};\\\", \\\"{x:1306,y:882,t:1527271756848};\\\", \\\"{x:1306,y:878,t:1527271756865};\\\", \\\"{x:1306,y:873,t:1527271756880};\\\", \\\"{x:1306,y:872,t:1527271756897};\\\", \\\"{x:1306,y:869,t:1527271756914};\\\", \\\"{x:1306,y:867,t:1527271756930};\\\", \\\"{x:1305,y:865,t:1527271756947};\\\", \\\"{x:1304,y:863,t:1527271756964};\\\", \\\"{x:1303,y:862,t:1527271756981};\\\", \\\"{x:1302,y:860,t:1527271756997};\\\", \\\"{x:1301,y:858,t:1527271757014};\\\", \\\"{x:1300,y:856,t:1527271757031};\\\", \\\"{x:1298,y:854,t:1527271757047};\\\", \\\"{x:1297,y:852,t:1527271757064};\\\", \\\"{x:1296,y:849,t:1527271757081};\\\", \\\"{x:1294,y:846,t:1527271757097};\\\", \\\"{x:1294,y:842,t:1527271757115};\\\", \\\"{x:1291,y:837,t:1527271757130};\\\", \\\"{x:1291,y:835,t:1527271757147};\\\", \\\"{x:1291,y:834,t:1527271757164};\\\", \\\"{x:1291,y:832,t:1527271757180};\\\", \\\"{x:1291,y:831,t:1527271757197};\\\", \\\"{x:1291,y:826,t:1527271757214};\\\", \\\"{x:1291,y:821,t:1527271757231};\\\", \\\"{x:1291,y:814,t:1527271757248};\\\", \\\"{x:1291,y:809,t:1527271757265};\\\", \\\"{x:1291,y:805,t:1527271757281};\\\", \\\"{x:1291,y:802,t:1527271757297};\\\", \\\"{x:1291,y:800,t:1527271757315};\\\", \\\"{x:1291,y:798,t:1527271757331};\\\", \\\"{x:1291,y:795,t:1527271757348};\\\", \\\"{x:1291,y:793,t:1527271757365};\\\", \\\"{x:1291,y:790,t:1527271757381};\\\", \\\"{x:1291,y:789,t:1527271757398};\\\", \\\"{x:1291,y:784,t:1527271757415};\\\", \\\"{x:1292,y:781,t:1527271757432};\\\", \\\"{x:1292,y:778,t:1527271757447};\\\", \\\"{x:1292,y:775,t:1527271757464};\\\", \\\"{x:1292,y:771,t:1527271757481};\\\", \\\"{x:1291,y:765,t:1527271757497};\\\", \\\"{x:1290,y:761,t:1527271757514};\\\", \\\"{x:1288,y:757,t:1527271757532};\\\", \\\"{x:1288,y:754,t:1527271757547};\\\", \\\"{x:1287,y:751,t:1527271757565};\\\", \\\"{x:1287,y:746,t:1527271757581};\\\", \\\"{x:1286,y:743,t:1527271757598};\\\", \\\"{x:1286,y:736,t:1527271757615};\\\", \\\"{x:1286,y:732,t:1527271757631};\\\", \\\"{x:1286,y:730,t:1527271757647};\\\", \\\"{x:1286,y:728,t:1527271757664};\\\", \\\"{x:1286,y:726,t:1527271757681};\\\", \\\"{x:1286,y:724,t:1527271757697};\\\", \\\"{x:1286,y:722,t:1527271757715};\\\", \\\"{x:1286,y:719,t:1527271757732};\\\", \\\"{x:1286,y:716,t:1527271757747};\\\", \\\"{x:1286,y:712,t:1527271757764};\\\", \\\"{x:1286,y:710,t:1527271757781};\\\", \\\"{x:1286,y:709,t:1527271757797};\\\", \\\"{x:1285,y:708,t:1527271757854};\\\", \\\"{x:1285,y:707,t:1527271757864};\\\", \\\"{x:1285,y:706,t:1527271757881};\\\", \\\"{x:1285,y:704,t:1527271757898};\\\", \\\"{x:1285,y:703,t:1527271757917};\\\", \\\"{x:1285,y:701,t:1527271757941};\\\", \\\"{x:1284,y:699,t:1527271757973};\\\", \\\"{x:1284,y:698,t:1527271758006};\\\", \\\"{x:1284,y:697,t:1527271758015};\\\", \\\"{x:1284,y:696,t:1527271758031};\\\", \\\"{x:1284,y:694,t:1527271758048};\\\", \\\"{x:1284,y:692,t:1527271758070};\\\", \\\"{x:1284,y:691,t:1527271758081};\\\", \\\"{x:1284,y:689,t:1527271758099};\\\", \\\"{x:1284,y:688,t:1527271758115};\\\", \\\"{x:1284,y:684,t:1527271758131};\\\", \\\"{x:1284,y:682,t:1527271758149};\\\", \\\"{x:1284,y:681,t:1527271758165};\\\", \\\"{x:1284,y:679,t:1527271758182};\\\", \\\"{x:1284,y:675,t:1527271758197};\\\", \\\"{x:1284,y:670,t:1527271758218};\\\", \\\"{x:1284,y:661,t:1527271758231};\\\", \\\"{x:1284,y:648,t:1527271758249};\\\", \\\"{x:1282,y:632,t:1527271758265};\\\", \\\"{x:1279,y:622,t:1527271758281};\\\", \\\"{x:1279,y:613,t:1527271758298};\\\", \\\"{x:1279,y:609,t:1527271758315};\\\", \\\"{x:1278,y:604,t:1527271758331};\\\", \\\"{x:1275,y:599,t:1527271758349};\\\", \\\"{x:1273,y:594,t:1527271758366};\\\", \\\"{x:1272,y:591,t:1527271758382};\\\", \\\"{x:1272,y:587,t:1527271758399};\\\", \\\"{x:1273,y:583,t:1527271758415};\\\", \\\"{x:1273,y:582,t:1527271758431};\\\", \\\"{x:1273,y:581,t:1527271758449};\\\", \\\"{x:1273,y:580,t:1527271758518};\\\", \\\"{x:1273,y:579,t:1527271758532};\\\", \\\"{x:1273,y:578,t:1527271758549};\\\", \\\"{x:1273,y:576,t:1527271758566};\\\", \\\"{x:1275,y:575,t:1527271758581};\\\", \\\"{x:1277,y:572,t:1527271758599};\\\", \\\"{x:1278,y:570,t:1527271758615};\\\", \\\"{x:1278,y:569,t:1527271758677};\\\", \\\"{x:1278,y:568,t:1527271758685};\\\", \\\"{x:1279,y:567,t:1527271758702};\\\", \\\"{x:1273,y:567,t:1527271759334};\\\", \\\"{x:1262,y:573,t:1527271759350};\\\", \\\"{x:1231,y:590,t:1527271759366};\\\", \\\"{x:1105,y:644,t:1527271759382};\\\", \\\"{x:972,y:687,t:1527271759399};\\\", \\\"{x:826,y:724,t:1527271759416};\\\", \\\"{x:686,y:752,t:1527271759433};\\\", \\\"{x:592,y:777,t:1527271759449};\\\", \\\"{x:529,y:795,t:1527271759465};\\\", \\\"{x:486,y:808,t:1527271759482};\\\", \\\"{x:462,y:815,t:1527271759499};\\\", \\\"{x:454,y:818,t:1527271759515};\\\", \\\"{x:453,y:818,t:1527271759532};\\\", \\\"{x:451,y:818,t:1527271759582};\\\", \\\"{x:449,y:818,t:1527271759590};\\\", \\\"{x:443,y:818,t:1527271759599};\\\", \\\"{x:436,y:818,t:1527271759616};\\\", \\\"{x:429,y:818,t:1527271759632};\\\", \\\"{x:422,y:817,t:1527271759650};\\\", \\\"{x:416,y:811,t:1527271759667};\\\", \\\"{x:415,y:811,t:1527271759683};\\\", \\\"{x:408,y:802,t:1527271759894};\\\", \\\"{x:388,y:787,t:1527271759902};\\\", \\\"{x:340,y:769,t:1527271759917};\\\", \\\"{x:271,y:740,t:1527271759932};\\\", \\\"{x:225,y:717,t:1527271759949};\\\", \\\"{x:204,y:703,t:1527271759966};\\\", \\\"{x:203,y:702,t:1527271759983};\\\", \\\"{x:202,y:702,t:1527271759999};\\\", \\\"{x:202,y:700,t:1527271760062};\\\", \\\"{x:205,y:695,t:1527271760070};\\\", \\\"{x:207,y:691,t:1527271760082};\\\", \\\"{x:210,y:684,t:1527271760100};\\\", \\\"{x:211,y:679,t:1527271760116};\\\", \\\"{x:219,y:669,t:1527271760133};\\\", \\\"{x:220,y:665,t:1527271760150};\\\", \\\"{x:227,y:651,t:1527271760166};\\\", \\\"{x:231,y:637,t:1527271760184};\\\", \\\"{x:232,y:627,t:1527271760199};\\\", \\\"{x:232,y:621,t:1527271760216};\\\", \\\"{x:232,y:615,t:1527271760234};\\\", \\\"{x:232,y:613,t:1527271760251};\\\", \\\"{x:233,y:609,t:1527271760267};\\\", \\\"{x:233,y:606,t:1527271760283};\\\", \\\"{x:234,y:602,t:1527271760300};\\\", \\\"{x:234,y:600,t:1527271760317};\\\", \\\"{x:237,y:597,t:1527271760333};\\\", \\\"{x:240,y:596,t:1527271760350};\\\", \\\"{x:246,y:595,t:1527271760367};\\\", \\\"{x:254,y:605,t:1527271760383};\\\", \\\"{x:256,y:605,t:1527271760401};\\\", \\\"{x:256,y:606,t:1527271760686};\\\", \\\"{x:252,y:605,t:1527271760701};\\\", \\\"{x:231,y:597,t:1527271760718};\\\", \\\"{x:214,y:588,t:1527271760734};\\\", \\\"{x:197,y:577,t:1527271760752};\\\", \\\"{x:181,y:566,t:1527271760767};\\\", \\\"{x:163,y:553,t:1527271760785};\\\", \\\"{x:138,y:538,t:1527271760801};\\\", \\\"{x:117,y:525,t:1527271760818};\\\", \\\"{x:100,y:516,t:1527271760834};\\\", \\\"{x:91,y:512,t:1527271760851};\\\", \\\"{x:90,y:511,t:1527271760910};\\\", \\\"{x:90,y:509,t:1527271760926};\\\", \\\"{x:95,y:508,t:1527271760934};\\\", \\\"{x:111,y:507,t:1527271760951};\\\", \\\"{x:138,y:507,t:1527271760968};\\\", \\\"{x:167,y:507,t:1527271760985};\\\", \\\"{x:207,y:507,t:1527271761002};\\\", \\\"{x:252,y:507,t:1527271761018};\\\", \\\"{x:291,y:507,t:1527271761036};\\\", \\\"{x:323,y:507,t:1527271761051};\\\", \\\"{x:345,y:507,t:1527271761067};\\\", \\\"{x:357,y:508,t:1527271761084};\\\", \\\"{x:372,y:515,t:1527271761102};\\\", \\\"{x:375,y:519,t:1527271761117};\\\", \\\"{x:377,y:521,t:1527271761134};\\\", \\\"{x:378,y:521,t:1527271762062};\\\", \\\"{x:388,y:526,t:1527271762069};\\\", \\\"{x:434,y:543,t:1527271762086};\\\", \\\"{x:553,y:576,t:1527271762101};\\\", \\\"{x:718,y:616,t:1527271762118};\\\", \\\"{x:893,y:650,t:1527271762135};\\\", \\\"{x:1066,y:695,t:1527271762152};\\\", \\\"{x:1246,y:745,t:1527271762169};\\\", \\\"{x:1416,y:813,t:1527271762186};\\\", \\\"{x:1548,y:867,t:1527271762202};\\\", \\\"{x:1611,y:900,t:1527271762218};\\\", \\\"{x:1626,y:911,t:1527271762236};\\\", \\\"{x:1627,y:914,t:1527271762252};\\\", \\\"{x:1627,y:917,t:1527271762269};\\\", \\\"{x:1622,y:922,t:1527271762285};\\\", \\\"{x:1611,y:926,t:1527271762302};\\\", \\\"{x:1600,y:932,t:1527271762318};\\\", \\\"{x:1580,y:944,t:1527271762336};\\\", \\\"{x:1563,y:957,t:1527271762352};\\\", \\\"{x:1551,y:968,t:1527271762369};\\\", \\\"{x:1542,y:978,t:1527271762386};\\\", \\\"{x:1533,y:987,t:1527271762403};\\\", \\\"{x:1528,y:992,t:1527271762419};\\\", \\\"{x:1521,y:997,t:1527271762436};\\\", \\\"{x:1510,y:1002,t:1527271762452};\\\", \\\"{x:1491,y:1008,t:1527271762469};\\\", \\\"{x:1466,y:1012,t:1527271762486};\\\", \\\"{x:1436,y:1013,t:1527271762503};\\\", \\\"{x:1401,y:1012,t:1527271762520};\\\", \\\"{x:1379,y:1008,t:1527271762536};\\\", \\\"{x:1365,y:1006,t:1527271762553};\\\", \\\"{x:1360,y:1006,t:1527271762569};\\\", \\\"{x:1359,y:1006,t:1527271762585};\\\", \\\"{x:1358,y:1005,t:1527271762614};\\\", \\\"{x:1358,y:1002,t:1527271762630};\\\", \\\"{x:1358,y:998,t:1527271762638};\\\", \\\"{x:1357,y:996,t:1527271762652};\\\", \\\"{x:1355,y:985,t:1527271762670};\\\", \\\"{x:1351,y:976,t:1527271762686};\\\", \\\"{x:1349,y:967,t:1527271762703};\\\", \\\"{x:1341,y:948,t:1527271762720};\\\", \\\"{x:1335,y:922,t:1527271762736};\\\", \\\"{x:1326,y:884,t:1527271762753};\\\", \\\"{x:1313,y:847,t:1527271762770};\\\", \\\"{x:1303,y:817,t:1527271762787};\\\", \\\"{x:1295,y:796,t:1527271762802};\\\", \\\"{x:1285,y:777,t:1527271762820};\\\", \\\"{x:1276,y:761,t:1527271762836};\\\", \\\"{x:1269,y:752,t:1527271762852};\\\", \\\"{x:1267,y:750,t:1527271762869};\\\", \\\"{x:1267,y:751,t:1527271763262};\\\", \\\"{x:1266,y:752,t:1527271763270};\\\", \\\"{x:1266,y:755,t:1527271763287};\\\", \\\"{x:1265,y:757,t:1527271763304};\\\", \\\"{x:1265,y:759,t:1527271763321};\\\", \\\"{x:1265,y:761,t:1527271763336};\\\", \\\"{x:1265,y:762,t:1527271763353};\\\", \\\"{x:1265,y:763,t:1527271763370};\\\", \\\"{x:1265,y:764,t:1527271763386};\\\", \\\"{x:1265,y:766,t:1527271763403};\\\", \\\"{x:1263,y:770,t:1527271763421};\\\", \\\"{x:1263,y:771,t:1527271763436};\\\", \\\"{x:1262,y:774,t:1527271763454};\\\", \\\"{x:1262,y:776,t:1527271763470};\\\", \\\"{x:1262,y:777,t:1527271763488};\\\", \\\"{x:1262,y:778,t:1527271763504};\\\", \\\"{x:1261,y:779,t:1527271763521};\\\", \\\"{x:1260,y:782,t:1527271763537};\\\", \\\"{x:1258,y:785,t:1527271763553};\\\", \\\"{x:1257,y:788,t:1527271763570};\\\", \\\"{x:1255,y:793,t:1527271763588};\\\", \\\"{x:1253,y:801,t:1527271763604};\\\", \\\"{x:1252,y:805,t:1527271763621};\\\", \\\"{x:1251,y:810,t:1527271763638};\\\", \\\"{x:1251,y:811,t:1527271763654};\\\", \\\"{x:1251,y:812,t:1527271763671};\\\", \\\"{x:1251,y:813,t:1527271763688};\\\", \\\"{x:1251,y:814,t:1527271763703};\\\", \\\"{x:1251,y:816,t:1527271763720};\\\", \\\"{x:1251,y:818,t:1527271763738};\\\", \\\"{x:1251,y:820,t:1527271763754};\\\", \\\"{x:1251,y:821,t:1527271763771};\\\", \\\"{x:1251,y:823,t:1527271763787};\\\", \\\"{x:1251,y:825,t:1527271763804};\\\", \\\"{x:1251,y:826,t:1527271763821};\\\", \\\"{x:1251,y:827,t:1527271763838};\\\", \\\"{x:1251,y:829,t:1527271763853};\\\", \\\"{x:1251,y:830,t:1527271763871};\\\", \\\"{x:1251,y:832,t:1527271763888};\\\", \\\"{x:1251,y:834,t:1527271763904};\\\", \\\"{x:1251,y:836,t:1527271763921};\\\", \\\"{x:1251,y:839,t:1527271763938};\\\", \\\"{x:1251,y:841,t:1527271763955};\\\", \\\"{x:1249,y:843,t:1527271763971};\\\", \\\"{x:1249,y:844,t:1527271763987};\\\", \\\"{x:1249,y:846,t:1527271764004};\\\", \\\"{x:1248,y:849,t:1527271764021};\\\", \\\"{x:1248,y:850,t:1527271764045};\\\", \\\"{x:1248,y:851,t:1527271764054};\\\", \\\"{x:1247,y:853,t:1527271764071};\\\", \\\"{x:1246,y:855,t:1527271764088};\\\", \\\"{x:1246,y:856,t:1527271764105};\\\", \\\"{x:1246,y:858,t:1527271764126};\\\", \\\"{x:1245,y:858,t:1527271764137};\\\", \\\"{x:1245,y:859,t:1527271764154};\\\", \\\"{x:1245,y:860,t:1527271764173};\\\", \\\"{x:1245,y:861,t:1527271764189};\\\", \\\"{x:1245,y:862,t:1527271764238};\\\", \\\"{x:1244,y:864,t:1527271764254};\\\", \\\"{x:1244,y:865,t:1527271764277};\\\", \\\"{x:1244,y:864,t:1527271764414};\\\", \\\"{x:1244,y:862,t:1527271764422};\\\", \\\"{x:1244,y:857,t:1527271764438};\\\", \\\"{x:1242,y:853,t:1527271764455};\\\", \\\"{x:1242,y:850,t:1527271764472};\\\", \\\"{x:1242,y:847,t:1527271764488};\\\", \\\"{x:1242,y:843,t:1527271764504};\\\", \\\"{x:1242,y:841,t:1527271764522};\\\", \\\"{x:1243,y:840,t:1527271764538};\\\", \\\"{x:1243,y:838,t:1527271764554};\\\", \\\"{x:1243,y:837,t:1527271764572};\\\", \\\"{x:1244,y:833,t:1527271764588};\\\", \\\"{x:1245,y:827,t:1527271764605};\\\", \\\"{x:1246,y:826,t:1527271764621};\\\", \\\"{x:1246,y:823,t:1527271764639};\\\", \\\"{x:1246,y:824,t:1527271764789};\\\", \\\"{x:1246,y:829,t:1527271764806};\\\", \\\"{x:1247,y:833,t:1527271764821};\\\", \\\"{x:1249,y:839,t:1527271764839};\\\", \\\"{x:1251,y:844,t:1527271764856};\\\", \\\"{x:1254,y:850,t:1527271764872};\\\", \\\"{x:1257,y:860,t:1527271764889};\\\", \\\"{x:1258,y:868,t:1527271764905};\\\", \\\"{x:1259,y:877,t:1527271764923};\\\", \\\"{x:1262,y:890,t:1527271764939};\\\", \\\"{x:1263,y:900,t:1527271764955};\\\", \\\"{x:1266,y:909,t:1527271764973};\\\", \\\"{x:1268,y:915,t:1527271764988};\\\", \\\"{x:1271,y:923,t:1527271765006};\\\", \\\"{x:1271,y:925,t:1527271765022};\\\", \\\"{x:1271,y:926,t:1527271765142};\\\", \\\"{x:1272,y:923,t:1527271765155};\\\", \\\"{x:1276,y:914,t:1527271765172};\\\", \\\"{x:1283,y:889,t:1527271765190};\\\", \\\"{x:1289,y:871,t:1527271765206};\\\", \\\"{x:1291,y:856,t:1527271765222};\\\", \\\"{x:1291,y:845,t:1527271765239};\\\", \\\"{x:1291,y:835,t:1527271765255};\\\", \\\"{x:1291,y:822,t:1527271765272};\\\", \\\"{x:1286,y:803,t:1527271765290};\\\", \\\"{x:1278,y:780,t:1527271765306};\\\", \\\"{x:1273,y:760,t:1527271765323};\\\", \\\"{x:1262,y:740,t:1527271765339};\\\", \\\"{x:1251,y:720,t:1527271765355};\\\", \\\"{x:1238,y:702,t:1527271765372};\\\", \\\"{x:1224,y:675,t:1527271765389};\\\", \\\"{x:1217,y:658,t:1527271765406};\\\", \\\"{x:1215,y:644,t:1527271765422};\\\", \\\"{x:1214,y:634,t:1527271765440};\\\", \\\"{x:1214,y:622,t:1527271765456};\\\", \\\"{x:1214,y:617,t:1527271765473};\\\", \\\"{x:1214,y:611,t:1527271765490};\\\", \\\"{x:1217,y:607,t:1527271765507};\\\", \\\"{x:1223,y:601,t:1527271765522};\\\", \\\"{x:1228,y:596,t:1527271765539};\\\", \\\"{x:1232,y:590,t:1527271765557};\\\", \\\"{x:1235,y:585,t:1527271765573};\\\", \\\"{x:1236,y:584,t:1527271765589};\\\", \\\"{x:1236,y:586,t:1527271765630};\\\", \\\"{x:1236,y:592,t:1527271765639};\\\", \\\"{x:1236,y:615,t:1527271765656};\\\", \\\"{x:1233,y:648,t:1527271765673};\\\", \\\"{x:1223,y:702,t:1527271765690};\\\", \\\"{x:1204,y:766,t:1527271765707};\\\", \\\"{x:1178,y:847,t:1527271765723};\\\", \\\"{x:1139,y:933,t:1527271765739};\\\", \\\"{x:1084,y:1011,t:1527271765757};\\\", \\\"{x:1005,y:1098,t:1527271765774};\\\", \\\"{x:979,y:1114,t:1527271765790};\\\", \\\"{x:963,y:1119,t:1527271765807};\\\", \\\"{x:952,y:1121,t:1527271765824};\\\", \\\"{x:933,y:1121,t:1527271765840};\\\", \\\"{x:907,y:1107,t:1527271765857};\\\", \\\"{x:872,y:1068,t:1527271765874};\\\", \\\"{x:835,y:1015,t:1527271765890};\\\", \\\"{x:784,y:944,t:1527271765907};\\\", \\\"{x:715,y:872,t:1527271765924};\\\", \\\"{x:634,y:813,t:1527271765939};\\\", \\\"{x:540,y:742,t:1527271765958};\\\", \\\"{x:508,y:715,t:1527271765973};\\\", \\\"{x:495,y:693,t:1527271765991};\\\", \\\"{x:483,y:666,t:1527271766006};\\\", \\\"{x:474,y:643,t:1527271766021};\\\", \\\"{x:462,y:623,t:1527271766038};\\\", \\\"{x:452,y:609,t:1527271766055};\\\", \\\"{x:449,y:601,t:1527271766072};\\\", \\\"{x:447,y:595,t:1527271766089};\\\", \\\"{x:444,y:586,t:1527271766105};\\\", \\\"{x:442,y:580,t:1527271766123};\\\", \\\"{x:441,y:578,t:1527271766138};\\\", \\\"{x:441,y:581,t:1527271766205};\\\", \\\"{x:447,y:595,t:1527271766222};\\\", \\\"{x:455,y:612,t:1527271766239};\\\", \\\"{x:460,y:627,t:1527271766256};\\\", \\\"{x:463,y:639,t:1527271766271};\\\", \\\"{x:468,y:651,t:1527271766289};\\\", \\\"{x:472,y:661,t:1527271766306};\\\", \\\"{x:475,y:666,t:1527271766322};\\\", \\\"{x:477,y:671,t:1527271766339};\\\", \\\"{x:479,y:677,t:1527271766356};\\\", \\\"{x:480,y:682,t:1527271766373};\\\", \\\"{x:480,y:683,t:1527271766389};\\\", \\\"{x:480,y:684,t:1527271766461};\\\", \\\"{x:480,y:685,t:1527271766472};\\\", \\\"{x:480,y:689,t:1527271766489};\\\", \\\"{x:483,y:693,t:1527271766505};\\\", \\\"{x:484,y:699,t:1527271766522};\\\", \\\"{x:488,y:707,t:1527271766540};\\\", \\\"{x:491,y:713,t:1527271766555};\\\", \\\"{x:494,y:717,t:1527271766572};\\\", \\\"{x:495,y:718,t:1527271766588};\\\", \\\"{x:496,y:719,t:1527271766605};\\\", \\\"{x:497,y:720,t:1527271766622};\\\", \\\"{x:498,y:723,t:1527271766638};\\\", \\\"{x:499,y:724,t:1527271766655};\\\", \\\"{x:499,y:726,t:1527271767878};\\\", \\\"{x:502,y:731,t:1527271767889};\\\", \\\"{x:511,y:741,t:1527271767906};\\\", \\\"{x:526,y:752,t:1527271767923};\\\", \\\"{x:540,y:759,t:1527271767939};\\\", \\\"{x:557,y:768,t:1527271767956};\\\", \\\"{x:599,y:782,t:1527271767973};\\\", \\\"{x:629,y:795,t:1527271767989};\\\", \\\"{x:659,y:804,t:1527271768007};\\\", \\\"{x:674,y:810,t:1527271768023};\\\", \\\"{x:677,y:811,t:1527271768039};\\\", \\\"{x:678,y:811,t:1527271768069};\\\" ] }, { \\\"rt\\\": 14768, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 162892, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -E -3\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:679,y:811,t:1527271770397};\\\", \\\"{x:687,y:811,t:1527271770409};\\\", \\\"{x:716,y:809,t:1527271770425};\\\", \\\"{x:740,y:809,t:1527271770441};\\\", \\\"{x:766,y:811,t:1527271770458};\\\", \\\"{x:794,y:816,t:1527271770476};\\\", \\\"{x:825,y:821,t:1527271770491};\\\", \\\"{x:854,y:827,t:1527271770509};\\\", \\\"{x:899,y:834,t:1527271770525};\\\", \\\"{x:952,y:834,t:1527271770542};\\\", \\\"{x:1008,y:835,t:1527271770559};\\\", \\\"{x:1067,y:835,t:1527271770576};\\\", \\\"{x:1134,y:835,t:1527271770591};\\\", \\\"{x:1217,y:835,t:1527271770609};\\\", \\\"{x:1320,y:835,t:1527271770626};\\\", \\\"{x:1427,y:824,t:1527271770642};\\\", \\\"{x:1527,y:809,t:1527271770659};\\\", \\\"{x:1624,y:785,t:1527271770675};\\\", \\\"{x:1710,y:758,t:1527271770692};\\\", \\\"{x:1774,y:741,t:1527271770709};\\\", \\\"{x:1799,y:736,t:1527271770725};\\\", \\\"{x:1805,y:733,t:1527271770743};\\\", \\\"{x:1811,y:731,t:1527271770758};\\\", \\\"{x:1822,y:726,t:1527271770775};\\\", \\\"{x:1834,y:717,t:1527271770792};\\\", \\\"{x:1838,y:709,t:1527271770809};\\\", \\\"{x:1838,y:703,t:1527271770826};\\\", \\\"{x:1838,y:698,t:1527271770843};\\\", \\\"{x:1837,y:697,t:1527271770859};\\\", \\\"{x:1832,y:693,t:1527271770876};\\\", \\\"{x:1828,y:691,t:1527271770892};\\\", \\\"{x:1823,y:690,t:1527271770908};\\\", \\\"{x:1810,y:684,t:1527271770925};\\\", \\\"{x:1804,y:684,t:1527271770943};\\\", \\\"{x:1796,y:684,t:1527271770959};\\\", \\\"{x:1781,y:681,t:1527271770975};\\\", \\\"{x:1764,y:676,t:1527271770993};\\\", \\\"{x:1743,y:671,t:1527271771009};\\\", \\\"{x:1720,y:665,t:1527271771025};\\\", \\\"{x:1697,y:657,t:1527271771043};\\\", \\\"{x:1684,y:648,t:1527271771058};\\\", \\\"{x:1678,y:644,t:1527271771075};\\\", \\\"{x:1674,y:641,t:1527271771092};\\\", \\\"{x:1668,y:641,t:1527271771221};\\\", \\\"{x:1660,y:640,t:1527271771229};\\\", \\\"{x:1648,y:640,t:1527271771242};\\\", \\\"{x:1627,y:639,t:1527271771260};\\\", \\\"{x:1607,y:633,t:1527271771276};\\\", \\\"{x:1581,y:625,t:1527271771293};\\\", \\\"{x:1534,y:619,t:1527271771309};\\\", \\\"{x:1507,y:616,t:1527271771326};\\\", \\\"{x:1492,y:614,t:1527271771343};\\\", \\\"{x:1483,y:614,t:1527271771359};\\\", \\\"{x:1481,y:614,t:1527271771375};\\\", \\\"{x:1480,y:613,t:1527271771549};\\\", \\\"{x:1480,y:612,t:1527271771559};\\\", \\\"{x:1479,y:610,t:1527271771577};\\\", \\\"{x:1477,y:608,t:1527271771592};\\\", \\\"{x:1477,y:607,t:1527271771610};\\\", \\\"{x:1476,y:606,t:1527271771645};\\\", \\\"{x:1475,y:604,t:1527271771660};\\\", \\\"{x:1472,y:600,t:1527271771676};\\\", \\\"{x:1472,y:599,t:1527271771693};\\\", \\\"{x:1472,y:597,t:1527271771709};\\\", \\\"{x:1472,y:593,t:1527271771727};\\\", \\\"{x:1472,y:589,t:1527271771743};\\\", \\\"{x:1475,y:582,t:1527271771760};\\\", \\\"{x:1480,y:574,t:1527271771776};\\\", \\\"{x:1484,y:569,t:1527271771793};\\\", \\\"{x:1487,y:566,t:1527271771810};\\\", \\\"{x:1489,y:564,t:1527271771827};\\\", \\\"{x:1490,y:564,t:1527271771843};\\\", \\\"{x:1491,y:563,t:1527271771859};\\\", \\\"{x:1491,y:565,t:1527271772158};\\\", \\\"{x:1489,y:570,t:1527271772165};\\\", \\\"{x:1487,y:573,t:1527271772176};\\\", \\\"{x:1478,y:581,t:1527271772193};\\\", \\\"{x:1468,y:590,t:1527271772209};\\\", \\\"{x:1465,y:592,t:1527271772226};\\\", \\\"{x:1465,y:593,t:1527271772244};\\\", \\\"{x:1465,y:594,t:1527271772294};\\\", \\\"{x:1470,y:595,t:1527271772309};\\\", \\\"{x:1489,y:595,t:1527271772326};\\\", \\\"{x:1515,y:593,t:1527271772344};\\\", \\\"{x:1548,y:583,t:1527271772360};\\\", \\\"{x:1585,y:572,t:1527271772377};\\\", \\\"{x:1619,y:556,t:1527271772393};\\\", \\\"{x:1656,y:535,t:1527271772409};\\\", \\\"{x:1666,y:525,t:1527271772427};\\\", \\\"{x:1667,y:517,t:1527271772443};\\\", \\\"{x:1667,y:508,t:1527271772460};\\\", \\\"{x:1664,y:498,t:1527271772477};\\\", \\\"{x:1657,y:487,t:1527271772493};\\\", \\\"{x:1654,y:483,t:1527271772510};\\\", \\\"{x:1653,y:481,t:1527271772527};\\\", \\\"{x:1651,y:477,t:1527271772543};\\\", \\\"{x:1649,y:474,t:1527271772561};\\\", \\\"{x:1646,y:470,t:1527271772577};\\\", \\\"{x:1644,y:466,t:1527271772593};\\\", \\\"{x:1642,y:464,t:1527271772610};\\\", \\\"{x:1640,y:462,t:1527271772627};\\\", \\\"{x:1637,y:460,t:1527271772644};\\\", \\\"{x:1636,y:459,t:1527271772661};\\\", \\\"{x:1633,y:453,t:1527271772677};\\\", \\\"{x:1621,y:438,t:1527271772693};\\\", \\\"{x:1609,y:426,t:1527271772711};\\\", \\\"{x:1601,y:420,t:1527271772727};\\\", \\\"{x:1597,y:417,t:1527271772743};\\\", \\\"{x:1596,y:416,t:1527271772761};\\\", \\\"{x:1595,y:417,t:1527271772933};\\\", \\\"{x:1595,y:419,t:1527271772943};\\\", \\\"{x:1595,y:424,t:1527271772961};\\\", \\\"{x:1595,y:430,t:1527271772977};\\\", \\\"{x:1595,y:439,t:1527271772994};\\\", \\\"{x:1599,y:455,t:1527271773010};\\\", \\\"{x:1604,y:476,t:1527271773028};\\\", \\\"{x:1606,y:496,t:1527271773043};\\\", \\\"{x:1606,y:510,t:1527271773060};\\\", \\\"{x:1606,y:521,t:1527271773077};\\\", \\\"{x:1608,y:525,t:1527271773094};\\\", \\\"{x:1609,y:530,t:1527271773111};\\\", \\\"{x:1610,y:534,t:1527271773128};\\\", \\\"{x:1610,y:539,t:1527271773144};\\\", \\\"{x:1610,y:543,t:1527271773160};\\\", \\\"{x:1610,y:549,t:1527271773177};\\\", \\\"{x:1610,y:558,t:1527271773194};\\\", \\\"{x:1610,y:569,t:1527271773210};\\\", \\\"{x:1610,y:580,t:1527271773228};\\\", \\\"{x:1610,y:588,t:1527271773244};\\\", \\\"{x:1610,y:595,t:1527271773261};\\\", \\\"{x:1612,y:600,t:1527271773277};\\\", \\\"{x:1612,y:601,t:1527271773365};\\\", \\\"{x:1612,y:600,t:1527271773557};\\\", \\\"{x:1612,y:597,t:1527271773565};\\\", \\\"{x:1612,y:595,t:1527271773578};\\\", \\\"{x:1612,y:590,t:1527271773595};\\\", \\\"{x:1612,y:583,t:1527271773610};\\\", \\\"{x:1612,y:580,t:1527271773627};\\\", \\\"{x:1613,y:579,t:1527271773644};\\\", \\\"{x:1613,y:578,t:1527271773757};\\\", \\\"{x:1609,y:578,t:1527271773765};\\\", \\\"{x:1598,y:578,t:1527271773777};\\\", \\\"{x:1572,y:578,t:1527271773794};\\\", \\\"{x:1517,y:592,t:1527271773811};\\\", \\\"{x:1367,y:620,t:1527271773828};\\\", \\\"{x:1171,y:645,t:1527271773844};\\\", \\\"{x:879,y:651,t:1527271773860};\\\", \\\"{x:749,y:632,t:1527271773878};\\\", \\\"{x:695,y:629,t:1527271773895};\\\", \\\"{x:674,y:629,t:1527271773912};\\\", \\\"{x:661,y:637,t:1527271773927};\\\", \\\"{x:655,y:641,t:1527271773942};\\\", \\\"{x:652,y:643,t:1527271773959};\\\", \\\"{x:649,y:644,t:1527271773977};\\\", \\\"{x:645,y:644,t:1527271773992};\\\", \\\"{x:637,y:644,t:1527271774010};\\\", \\\"{x:625,y:642,t:1527271774027};\\\", \\\"{x:615,y:637,t:1527271774045};\\\", \\\"{x:603,y:624,t:1527271774061};\\\", \\\"{x:585,y:611,t:1527271774078};\\\", \\\"{x:555,y:595,t:1527271774095};\\\", \\\"{x:524,y:579,t:1527271774112};\\\", \\\"{x:485,y:562,t:1527271774128};\\\", \\\"{x:458,y:550,t:1527271774145};\\\", \\\"{x:439,y:542,t:1527271774162};\\\", \\\"{x:414,y:532,t:1527271774178};\\\", \\\"{x:390,y:520,t:1527271774195};\\\", \\\"{x:363,y:511,t:1527271774212};\\\", \\\"{x:350,y:508,t:1527271774227};\\\", \\\"{x:337,y:506,t:1527271774245};\\\", \\\"{x:327,y:506,t:1527271774261};\\\", \\\"{x:320,y:506,t:1527271774278};\\\", \\\"{x:314,y:507,t:1527271774294};\\\", \\\"{x:309,y:510,t:1527271774312};\\\", \\\"{x:308,y:510,t:1527271774328};\\\", \\\"{x:307,y:511,t:1527271774344};\\\", \\\"{x:304,y:514,t:1527271774362};\\\", \\\"{x:294,y:521,t:1527271774379};\\\", \\\"{x:280,y:533,t:1527271774394};\\\", \\\"{x:263,y:543,t:1527271774412};\\\", \\\"{x:252,y:550,t:1527271774429};\\\", \\\"{x:244,y:555,t:1527271774444};\\\", \\\"{x:234,y:566,t:1527271774461};\\\", \\\"{x:227,y:571,t:1527271774477};\\\", \\\"{x:217,y:573,t:1527271774494};\\\", \\\"{x:211,y:577,t:1527271774512};\\\", \\\"{x:208,y:577,t:1527271774528};\\\", \\\"{x:209,y:577,t:1527271774565};\\\", \\\"{x:217,y:577,t:1527271774579};\\\", \\\"{x:248,y:574,t:1527271774594};\\\", \\\"{x:296,y:572,t:1527271774612};\\\", \\\"{x:371,y:572,t:1527271774628};\\\", \\\"{x:435,y:572,t:1527271774644};\\\", \\\"{x:493,y:574,t:1527271774661};\\\", \\\"{x:517,y:578,t:1527271774679};\\\", \\\"{x:528,y:580,t:1527271774695};\\\", \\\"{x:529,y:580,t:1527271774711};\\\", \\\"{x:529,y:581,t:1527271774766};\\\", \\\"{x:529,y:584,t:1527271774779};\\\", \\\"{x:526,y:587,t:1527271774795};\\\", \\\"{x:525,y:587,t:1527271774811};\\\", \\\"{x:516,y:588,t:1527271774828};\\\", \\\"{x:491,y:591,t:1527271774846};\\\", \\\"{x:469,y:591,t:1527271774862};\\\", \\\"{x:453,y:593,t:1527271774878};\\\", \\\"{x:444,y:594,t:1527271774896};\\\", \\\"{x:443,y:594,t:1527271774911};\\\", \\\"{x:442,y:594,t:1527271774929};\\\", \\\"{x:446,y:592,t:1527271774981};\\\", \\\"{x:458,y:589,t:1527271774996};\\\", \\\"{x:496,y:582,t:1527271775012};\\\", \\\"{x:584,y:573,t:1527271775029};\\\", \\\"{x:703,y:565,t:1527271775046};\\\", \\\"{x:756,y:565,t:1527271775062};\\\", \\\"{x:785,y:565,t:1527271775079};\\\", \\\"{x:796,y:565,t:1527271775096};\\\", \\\"{x:812,y:566,t:1527271775113};\\\", \\\"{x:821,y:566,t:1527271775129};\\\", \\\"{x:822,y:566,t:1527271775146};\\\", \\\"{x:824,y:567,t:1527271775189};\\\", \\\"{x:824,y:568,t:1527271775197};\\\", \\\"{x:824,y:569,t:1527271775212};\\\", \\\"{x:824,y:570,t:1527271775229};\\\", \\\"{x:824,y:572,t:1527271775245};\\\", \\\"{x:824,y:573,t:1527271775262};\\\", \\\"{x:824,y:574,t:1527271775325};\\\", \\\"{x:818,y:574,t:1527271775333};\\\", \\\"{x:808,y:575,t:1527271775346};\\\", \\\"{x:772,y:575,t:1527271775363};\\\", \\\"{x:706,y:575,t:1527271775378};\\\", \\\"{x:609,y:575,t:1527271775396};\\\", \\\"{x:481,y:575,t:1527271775413};\\\", \\\"{x:224,y:575,t:1527271775428};\\\", \\\"{x:74,y:581,t:1527271775445};\\\", \\\"{x:0,y:581,t:1527271775462};\\\", \\\"{x:0,y:582,t:1527271775479};\\\", \\\"{x:0,y:586,t:1527271775496};\\\", \\\"{x:0,y:587,t:1527271775512};\\\", \\\"{x:0,y:588,t:1527271775528};\\\", \\\"{x:0,y:589,t:1527271775546};\\\", \\\"{x:0,y:590,t:1527271775562};\\\", \\\"{x:0,y:594,t:1527271775578};\\\", \\\"{x:0,y:598,t:1527271775595};\\\", \\\"{x:0,y:601,t:1527271775613};\\\", \\\"{x:0,y:607,t:1527271775628};\\\", \\\"{x:12,y:626,t:1527271775645};\\\", \\\"{x:31,y:641,t:1527271775663};\\\", \\\"{x:55,y:649,t:1527271775680};\\\", \\\"{x:71,y:656,t:1527271775696};\\\", \\\"{x:86,y:661,t:1527271775712};\\\", \\\"{x:102,y:661,t:1527271775730};\\\", \\\"{x:110,y:663,t:1527271775746};\\\", \\\"{x:115,y:663,t:1527271775762};\\\", \\\"{x:116,y:663,t:1527271775829};\\\", \\\"{x:117,y:657,t:1527271775846};\\\", \\\"{x:117,y:648,t:1527271775863};\\\", \\\"{x:120,y:642,t:1527271775880};\\\", \\\"{x:130,y:636,t:1527271775896};\\\", \\\"{x:142,y:629,t:1527271775913};\\\", \\\"{x:149,y:625,t:1527271775929};\\\", \\\"{x:150,y:624,t:1527271775946};\\\", \\\"{x:151,y:624,t:1527271775962};\\\", \\\"{x:152,y:623,t:1527271776037};\\\", \\\"{x:153,y:623,t:1527271776053};\\\", \\\"{x:155,y:624,t:1527271776062};\\\", \\\"{x:158,y:626,t:1527271776079};\\\", \\\"{x:161,y:628,t:1527271776097};\\\", \\\"{x:161,y:629,t:1527271776116};\\\", \\\"{x:162,y:631,t:1527271776132};\\\", \\\"{x:162,y:634,t:1527271776146};\\\", \\\"{x:163,y:642,t:1527271776162};\\\", \\\"{x:165,y:648,t:1527271776179};\\\", \\\"{x:165,y:650,t:1527271776197};\\\", \\\"{x:165,y:647,t:1527271776413};\\\", \\\"{x:161,y:640,t:1527271776429};\\\", \\\"{x:161,y:639,t:1527271776447};\\\", \\\"{x:161,y:637,t:1527271776581};\\\", \\\"{x:159,y:635,t:1527271776596};\\\", \\\"{x:158,y:634,t:1527271776614};\\\", \\\"{x:159,y:630,t:1527271777109};\\\", \\\"{x:170,y:624,t:1527271777116};\\\", \\\"{x:191,y:621,t:1527271777131};\\\", \\\"{x:341,y:602,t:1527271777147};\\\", \\\"{x:535,y:595,t:1527271777164};\\\", \\\"{x:786,y:596,t:1527271777181};\\\", \\\"{x:1136,y:596,t:1527271777197};\\\", \\\"{x:1737,y:599,t:1527271777214};\\\", \\\"{x:1919,y:601,t:1527271777230};\\\", \\\"{x:1919,y:606,t:1527271777248};\\\", \\\"{x:1919,y:623,t:1527271777263};\\\", \\\"{x:1919,y:644,t:1527271777280};\\\", \\\"{x:1919,y:653,t:1527271777297};\\\", \\\"{x:1919,y:657,t:1527271777314};\\\", \\\"{x:1919,y:658,t:1527271777333};\\\", \\\"{x:1916,y:660,t:1527271777349};\\\", \\\"{x:1911,y:660,t:1527271777364};\\\", \\\"{x:1903,y:662,t:1527271777381};\\\", \\\"{x:1902,y:662,t:1527271777404};\\\", \\\"{x:1900,y:662,t:1527271777413};\\\", \\\"{x:1893,y:660,t:1527271777431};\\\", \\\"{x:1879,y:656,t:1527271777446};\\\", \\\"{x:1861,y:650,t:1527271777463};\\\", \\\"{x:1834,y:644,t:1527271777481};\\\", \\\"{x:1795,y:637,t:1527271777496};\\\", \\\"{x:1767,y:635,t:1527271777513};\\\", \\\"{x:1739,y:632,t:1527271777530};\\\", \\\"{x:1715,y:632,t:1527271777547};\\\", \\\"{x:1689,y:632,t:1527271777563};\\\", \\\"{x:1675,y:632,t:1527271777580};\\\", \\\"{x:1667,y:632,t:1527271777596};\\\", \\\"{x:1663,y:628,t:1527271777613};\\\", \\\"{x:1662,y:624,t:1527271777630};\\\", \\\"{x:1661,y:618,t:1527271777647};\\\", \\\"{x:1661,y:611,t:1527271777664};\\\", \\\"{x:1659,y:604,t:1527271777679};\\\", \\\"{x:1656,y:587,t:1527271777697};\\\", \\\"{x:1648,y:562,t:1527271777713};\\\", \\\"{x:1630,y:536,t:1527271777730};\\\", \\\"{x:1616,y:519,t:1527271777746};\\\", \\\"{x:1607,y:506,t:1527271777762};\\\", \\\"{x:1601,y:500,t:1527271777780};\\\", \\\"{x:1591,y:488,t:1527271777797};\\\", \\\"{x:1586,y:482,t:1527271777813};\\\", \\\"{x:1581,y:477,t:1527271777830};\\\", \\\"{x:1578,y:475,t:1527271777847};\\\", \\\"{x:1579,y:475,t:1527271777941};\\\", \\\"{x:1580,y:477,t:1527271777957};\\\", \\\"{x:1581,y:477,t:1527271778054};\\\", \\\"{x:1582,y:477,t:1527271778062};\\\", \\\"{x:1585,y:479,t:1527271778080};\\\", \\\"{x:1588,y:480,t:1527271778096};\\\", \\\"{x:1589,y:481,t:1527271778113};\\\", \\\"{x:1592,y:484,t:1527271778130};\\\", \\\"{x:1594,y:488,t:1527271778146};\\\", \\\"{x:1595,y:489,t:1527271778162};\\\", \\\"{x:1598,y:494,t:1527271778179};\\\", \\\"{x:1600,y:500,t:1527271778196};\\\", \\\"{x:1603,y:510,t:1527271778213};\\\", \\\"{x:1606,y:513,t:1527271778229};\\\", \\\"{x:1606,y:514,t:1527271778246};\\\", \\\"{x:1606,y:515,t:1527271778293};\\\", \\\"{x:1606,y:517,t:1527271778300};\\\", \\\"{x:1606,y:518,t:1527271778313};\\\", \\\"{x:1606,y:522,t:1527271778329};\\\", \\\"{x:1606,y:527,t:1527271778346};\\\", \\\"{x:1606,y:531,t:1527271778363};\\\", \\\"{x:1606,y:535,t:1527271778379};\\\", \\\"{x:1607,y:543,t:1527271778396};\\\", \\\"{x:1607,y:551,t:1527271778413};\\\", \\\"{x:1607,y:555,t:1527271778429};\\\", \\\"{x:1607,y:561,t:1527271778445};\\\", \\\"{x:1607,y:567,t:1527271778462};\\\", \\\"{x:1607,y:573,t:1527271778479};\\\", \\\"{x:1607,y:577,t:1527271778495};\\\", \\\"{x:1607,y:582,t:1527271778511};\\\", \\\"{x:1607,y:585,t:1527271778529};\\\", \\\"{x:1607,y:589,t:1527271778546};\\\", \\\"{x:1610,y:593,t:1527271778561};\\\", \\\"{x:1610,y:596,t:1527271778579};\\\", \\\"{x:1610,y:598,t:1527271778596};\\\", \\\"{x:1611,y:598,t:1527271778611};\\\", \\\"{x:1611,y:599,t:1527271778636};\\\", \\\"{x:1611,y:600,t:1527271778644};\\\", \\\"{x:1611,y:601,t:1527271778669};\\\", \\\"{x:1612,y:603,t:1527271778765};\\\", \\\"{x:1612,y:604,t:1527271778779};\\\", \\\"{x:1612,y:605,t:1527271778795};\\\", \\\"{x:1612,y:606,t:1527271778812};\\\", \\\"{x:1613,y:611,t:1527271778829};\\\", \\\"{x:1613,y:612,t:1527271778845};\\\", \\\"{x:1613,y:616,t:1527271778862};\\\", \\\"{x:1614,y:619,t:1527271778878};\\\", \\\"{x:1614,y:621,t:1527271778894};\\\", \\\"{x:1614,y:624,t:1527271778912};\\\", \\\"{x:1614,y:627,t:1527271778928};\\\", \\\"{x:1614,y:631,t:1527271778945};\\\", \\\"{x:1614,y:636,t:1527271778961};\\\", \\\"{x:1614,y:638,t:1527271778979};\\\", \\\"{x:1614,y:641,t:1527271778994};\\\", \\\"{x:1614,y:642,t:1527271779011};\\\", \\\"{x:1614,y:645,t:1527271779117};\\\", \\\"{x:1614,y:646,t:1527271779133};\\\", \\\"{x:1614,y:647,t:1527271779157};\\\", \\\"{x:1614,y:648,t:1527271779189};\\\", \\\"{x:1614,y:651,t:1527271779197};\\\", \\\"{x:1614,y:653,t:1527271779211};\\\", \\\"{x:1614,y:664,t:1527271779228};\\\", \\\"{x:1614,y:678,t:1527271779245};\\\", \\\"{x:1614,y:685,t:1527271779261};\\\", \\\"{x:1614,y:688,t:1527271779277};\\\", \\\"{x:1614,y:690,t:1527271779294};\\\", \\\"{x:1614,y:691,t:1527271779311};\\\", \\\"{x:1614,y:692,t:1527271779357};\\\", \\\"{x:1614,y:693,t:1527271779365};\\\", \\\"{x:1614,y:694,t:1527271779389};\\\", \\\"{x:1614,y:696,t:1527271779396};\\\", \\\"{x:1614,y:698,t:1527271779421};\\\", \\\"{x:1614,y:699,t:1527271779437};\\\", \\\"{x:1614,y:701,t:1527271779461};\\\", \\\"{x:1614,y:704,t:1527271779477};\\\", \\\"{x:1614,y:706,t:1527271779494};\\\", \\\"{x:1614,y:708,t:1527271779511};\\\", \\\"{x:1614,y:709,t:1527271779528};\\\", \\\"{x:1614,y:710,t:1527271779543};\\\", \\\"{x:1614,y:711,t:1527271779561};\\\", \\\"{x:1614,y:712,t:1527271779578};\\\", \\\"{x:1614,y:714,t:1527271779594};\\\", \\\"{x:1613,y:715,t:1527271779611};\\\", \\\"{x:1613,y:718,t:1527271779628};\\\", \\\"{x:1612,y:721,t:1527271779644};\\\", \\\"{x:1612,y:723,t:1527271779669};\\\", \\\"{x:1612,y:724,t:1527271779677};\\\", \\\"{x:1612,y:726,t:1527271779694};\\\", \\\"{x:1612,y:727,t:1527271779711};\\\", \\\"{x:1612,y:729,t:1527271779728};\\\", \\\"{x:1612,y:731,t:1527271779743};\\\", \\\"{x:1612,y:734,t:1527271779761};\\\", \\\"{x:1612,y:737,t:1527271779777};\\\", \\\"{x:1610,y:743,t:1527271779793};\\\", \\\"{x:1609,y:748,t:1527271779811};\\\", \\\"{x:1608,y:751,t:1527271779827};\\\", \\\"{x:1608,y:752,t:1527271779844};\\\", \\\"{x:1608,y:755,t:1527271779861};\\\", \\\"{x:1608,y:759,t:1527271779876};\\\", \\\"{x:1612,y:765,t:1527271779894};\\\", \\\"{x:1616,y:771,t:1527271779911};\\\", \\\"{x:1617,y:773,t:1527271779926};\\\", \\\"{x:1618,y:776,t:1527271779943};\\\", \\\"{x:1618,y:777,t:1527271779960};\\\", \\\"{x:1618,y:779,t:1527271779976};\\\", \\\"{x:1618,y:781,t:1527271779994};\\\", \\\"{x:1618,y:787,t:1527271780010};\\\", \\\"{x:1619,y:794,t:1527271780027};\\\", \\\"{x:1619,y:799,t:1527271780044};\\\", \\\"{x:1619,y:801,t:1527271780059};\\\", \\\"{x:1619,y:802,t:1527271780077};\\\", \\\"{x:1619,y:804,t:1527271780094};\\\", \\\"{x:1619,y:805,t:1527271780109};\\\", \\\"{x:1619,y:807,t:1527271780127};\\\", \\\"{x:1619,y:811,t:1527271780143};\\\", \\\"{x:1618,y:814,t:1527271780160};\\\", \\\"{x:1617,y:817,t:1527271780176};\\\", \\\"{x:1617,y:818,t:1527271780193};\\\", \\\"{x:1617,y:819,t:1527271780210};\\\", \\\"{x:1615,y:820,t:1527271780227};\\\", \\\"{x:1615,y:821,t:1527271780243};\\\", \\\"{x:1615,y:823,t:1527271780260};\\\", \\\"{x:1614,y:826,t:1527271780277};\\\", \\\"{x:1614,y:828,t:1527271780293};\\\", \\\"{x:1613,y:829,t:1527271780310};\\\", \\\"{x:1613,y:830,t:1527271780327};\\\", \\\"{x:1613,y:832,t:1527271780342};\\\", \\\"{x:1613,y:833,t:1527271780360};\\\", \\\"{x:1612,y:835,t:1527271780376};\\\", \\\"{x:1612,y:839,t:1527271780393};\\\", \\\"{x:1611,y:842,t:1527271780409};\\\", \\\"{x:1611,y:845,t:1527271780427};\\\", \\\"{x:1610,y:846,t:1527271780443};\\\", \\\"{x:1610,y:848,t:1527271780459};\\\", \\\"{x:1610,y:850,t:1527271780477};\\\", \\\"{x:1610,y:851,t:1527271780493};\\\", \\\"{x:1610,y:853,t:1527271780510};\\\", \\\"{x:1610,y:854,t:1527271780525};\\\", \\\"{x:1610,y:855,t:1527271780549};\\\", \\\"{x:1610,y:857,t:1527271780559};\\\", \\\"{x:1610,y:858,t:1527271780576};\\\", \\\"{x:1609,y:861,t:1527271780593};\\\", \\\"{x:1609,y:865,t:1527271780610};\\\", \\\"{x:1609,y:871,t:1527271780626};\\\", \\\"{x:1609,y:875,t:1527271780642};\\\", \\\"{x:1609,y:881,t:1527271780660};\\\", \\\"{x:1609,y:884,t:1527271780675};\\\", \\\"{x:1609,y:892,t:1527271780692};\\\", \\\"{x:1609,y:898,t:1527271780709};\\\", \\\"{x:1610,y:907,t:1527271780726};\\\", \\\"{x:1612,y:914,t:1527271780743};\\\", \\\"{x:1612,y:916,t:1527271780758};\\\", \\\"{x:1612,y:918,t:1527271780776};\\\", \\\"{x:1612,y:919,t:1527271780793};\\\", \\\"{x:1612,y:921,t:1527271780809};\\\", \\\"{x:1612,y:922,t:1527271780829};\\\", \\\"{x:1612,y:924,t:1527271780845};\\\", \\\"{x:1612,y:925,t:1527271780859};\\\", \\\"{x:1611,y:926,t:1527271780876};\\\", \\\"{x:1611,y:927,t:1527271780909};\\\", \\\"{x:1610,y:928,t:1527271781197};\\\", \\\"{x:1608,y:928,t:1527271781209};\\\", \\\"{x:1598,y:926,t:1527271781225};\\\", \\\"{x:1583,y:921,t:1527271781242};\\\", \\\"{x:1559,y:915,t:1527271781259};\\\", \\\"{x:1535,y:907,t:1527271781275};\\\", \\\"{x:1513,y:904,t:1527271781292};\\\", \\\"{x:1414,y:880,t:1527271781308};\\\", \\\"{x:1287,y:844,t:1527271781325};\\\", \\\"{x:1167,y:802,t:1527271781342};\\\", \\\"{x:1057,y:760,t:1527271781359};\\\", \\\"{x:928,y:726,t:1527271781375};\\\", \\\"{x:787,y:685,t:1527271781392};\\\", \\\"{x:671,y:659,t:1527271781409};\\\", \\\"{x:591,y:648,t:1527271781426};\\\", \\\"{x:561,y:646,t:1527271781442};\\\", \\\"{x:545,y:648,t:1527271781458};\\\", \\\"{x:534,y:653,t:1527271781468};\\\", \\\"{x:511,y:664,t:1527271781484};\\\", \\\"{x:479,y:682,t:1527271781501};\\\", \\\"{x:473,y:687,t:1527271781517};\\\", \\\"{x:471,y:688,t:1527271781534};\\\", \\\"{x:468,y:690,t:1527271781551};\\\", \\\"{x:467,y:692,t:1527271781567};\\\", \\\"{x:465,y:692,t:1527271781584};\\\", \\\"{x:467,y:694,t:1527271781601};\\\", \\\"{x:485,y:701,t:1527271781618};\\\", \\\"{x:525,y:718,t:1527271781634};\\\", \\\"{x:546,y:731,t:1527271781651};\\\", \\\"{x:564,y:740,t:1527271781668};\\\", \\\"{x:575,y:747,t:1527271781684};\\\", \\\"{x:577,y:750,t:1527271781700};\\\", \\\"{x:580,y:745,t:1527271781829};\\\", \\\"{x:581,y:738,t:1527271781836};\\\", \\\"{x:581,y:731,t:1527271781851};\\\", \\\"{x:581,y:721,t:1527271781868};\\\", \\\"{x:575,y:711,t:1527271781884};\\\", \\\"{x:572,y:704,t:1527271781901};\\\", \\\"{x:572,y:703,t:1527271781918};\\\", \\\"{x:571,y:702,t:1527271781934};\\\", \\\"{x:570,y:702,t:1527271781973};\\\", \\\"{x:568,y:702,t:1527271781997};\\\", \\\"{x:566,y:702,t:1527271782005};\\\", \\\"{x:562,y:702,t:1527271782018};\\\", \\\"{x:553,y:700,t:1527271782034};\\\", \\\"{x:539,y:698,t:1527271782051};\\\", \\\"{x:526,y:696,t:1527271782068};\\\", \\\"{x:513,y:695,t:1527271782084};\\\", \\\"{x:500,y:694,t:1527271782101};\\\", \\\"{x:499,y:694,t:1527271782132};\\\", \\\"{x:497,y:694,t:1527271782173};\\\", \\\"{x:496,y:694,t:1527271782205};\\\", \\\"{x:496,y:695,t:1527271782245};\\\", \\\"{x:496,y:697,t:1527271782261};\\\", \\\"{x:496,y:701,t:1527271782269};\\\", \\\"{x:498,y:711,t:1527271782284};\\\", \\\"{x:499,y:718,t:1527271782300};\\\", \\\"{x:501,y:721,t:1527271782317};\\\", \\\"{x:501,y:722,t:1527271782335};\\\", \\\"{x:502,y:722,t:1527271782429};\\\", \\\"{x:503,y:723,t:1527271782437};\\\", \\\"{x:505,y:723,t:1527271783477};\\\", \\\"{x:506,y:723,t:1527271783572};\\\", \\\"{x:508,y:723,t:1527271783586};\\\", \\\"{x:515,y:717,t:1527271783602};\\\", \\\"{x:522,y:712,t:1527271783619};\\\", \\\"{x:529,y:707,t:1527271783636};\\\", \\\"{x:534,y:701,t:1527271783652};\\\", \\\"{x:540,y:699,t:1527271783669};\\\", \\\"{x:550,y:696,t:1527271783686};\\\", \\\"{x:564,y:692,t:1527271783702};\\\", \\\"{x:572,y:689,t:1527271783718};\\\", \\\"{x:575,y:686,t:1527271783736};\\\", \\\"{x:575,y:684,t:1527271783751};\\\", \\\"{x:574,y:682,t:1527271783772};\\\", \\\"{x:574,y:680,t:1527271783786};\\\", \\\"{x:570,y:680,t:1527271783803};\\\", \\\"{x:568,y:681,t:1527271783819};\\\", \\\"{x:567,y:681,t:1527271783836};\\\", \\\"{x:564,y:682,t:1527271783852};\\\", \\\"{x:565,y:682,t:1527271783908};\\\", \\\"{x:572,y:682,t:1527271783919};\\\", \\\"{x:588,y:674,t:1527271783936};\\\", \\\"{x:599,y:667,t:1527271783953};\\\", \\\"{x:603,y:664,t:1527271783969};\\\", \\\"{x:605,y:663,t:1527271783986};\\\" ] }, { \\\"rt\\\": 69108, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 233248, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -A -Z -C -A -A -A -C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:597,y:646,t:1527271785118};\\\", \\\"{x:595,y:643,t:1527271785137};\\\", \\\"{x:594,y:642,t:1527271785154};\\\", \\\"{x:593,y:641,t:1527271785169};\\\", \\\"{x:596,y:637,t:1527271785213};\\\", \\\"{x:606,y:631,t:1527271785221};\\\", \\\"{x:629,y:615,t:1527271785238};\\\", \\\"{x:660,y:601,t:1527271785254};\\\", \\\"{x:681,y:590,t:1527271785270};\\\", \\\"{x:684,y:588,t:1527271785287};\\\", \\\"{x:687,y:586,t:1527271785304};\\\", \\\"{x:693,y:583,t:1527271785320};\\\", \\\"{x:701,y:579,t:1527271785337};\\\", \\\"{x:712,y:578,t:1527271785354};\\\", \\\"{x:720,y:578,t:1527271785370};\\\", \\\"{x:722,y:578,t:1527271785387};\\\", \\\"{x:723,y:578,t:1527271785404};\\\", \\\"{x:721,y:578,t:1527271785485};\\\", \\\"{x:717,y:578,t:1527271785493};\\\", \\\"{x:713,y:578,t:1527271785504};\\\", \\\"{x:704,y:577,t:1527271785521};\\\", \\\"{x:700,y:575,t:1527271785538};\\\", \\\"{x:694,y:574,t:1527271785555};\\\", \\\"{x:685,y:571,t:1527271785571};\\\", \\\"{x:675,y:566,t:1527271785587};\\\", \\\"{x:670,y:563,t:1527271785604};\\\", \\\"{x:661,y:556,t:1527271785620};\\\", \\\"{x:656,y:552,t:1527271785637};\\\", \\\"{x:649,y:547,t:1527271785653};\\\", \\\"{x:646,y:544,t:1527271785671};\\\", \\\"{x:644,y:542,t:1527271785687};\\\", \\\"{x:644,y:539,t:1527271785704};\\\", \\\"{x:642,y:538,t:1527271785721};\\\", \\\"{x:642,y:535,t:1527271785813};\\\", \\\"{x:642,y:532,t:1527271785820};\\\", \\\"{x:642,y:527,t:1527271785837};\\\", \\\"{x:642,y:518,t:1527271785854};\\\", \\\"{x:642,y:511,t:1527271785871};\\\", \\\"{x:641,y:506,t:1527271785887};\\\", \\\"{x:638,y:501,t:1527271785905};\\\", \\\"{x:635,y:495,t:1527271785921};\\\", \\\"{x:630,y:490,t:1527271785937};\\\", \\\"{x:619,y:480,t:1527271785954};\\\", \\\"{x:601,y:468,t:1527271785971};\\\", \\\"{x:582,y:453,t:1527271785988};\\\", \\\"{x:563,y:441,t:1527271786004};\\\", \\\"{x:547,y:429,t:1527271786020};\\\", \\\"{x:544,y:428,t:1527271786037};\\\", \\\"{x:544,y:427,t:1527271786054};\\\", \\\"{x:543,y:427,t:1527271786621};\\\", \\\"{x:534,y:433,t:1527271786637};\\\", \\\"{x:525,y:440,t:1527271786654};\\\", \\\"{x:521,y:442,t:1527271786671};\\\", \\\"{x:519,y:443,t:1527271786687};\\\", \\\"{x:516,y:445,t:1527271786704};\\\", \\\"{x:515,y:446,t:1527271786721};\\\", \\\"{x:521,y:446,t:1527271787141};\\\", \\\"{x:533,y:446,t:1527271787154};\\\", \\\"{x:597,y:451,t:1527271787171};\\\", \\\"{x:691,y:465,t:1527271787188};\\\", \\\"{x:800,y:487,t:1527271787204};\\\", \\\"{x:949,y:525,t:1527271787222};\\\", \\\"{x:1055,y:561,t:1527271787239};\\\", \\\"{x:1136,y:586,t:1527271787255};\\\", \\\"{x:1188,y:607,t:1527271787272};\\\", \\\"{x:1222,y:623,t:1527271787289};\\\", \\\"{x:1252,y:635,t:1527271787305};\\\", \\\"{x:1277,y:651,t:1527271787322};\\\", \\\"{x:1295,y:665,t:1527271787339};\\\", \\\"{x:1311,y:682,t:1527271787355};\\\", \\\"{x:1327,y:699,t:1527271787372};\\\", \\\"{x:1355,y:725,t:1527271787389};\\\", \\\"{x:1373,y:741,t:1527271787406};\\\", \\\"{x:1386,y:753,t:1527271787422};\\\", \\\"{x:1388,y:755,t:1527271787439};\\\", \\\"{x:1388,y:756,t:1527271787549};\\\", \\\"{x:1387,y:756,t:1527271787565};\\\", \\\"{x:1385,y:756,t:1527271787589};\\\", \\\"{x:1379,y:756,t:1527271787606};\\\", \\\"{x:1370,y:755,t:1527271787622};\\\", \\\"{x:1358,y:755,t:1527271787639};\\\", \\\"{x:1344,y:755,t:1527271787656};\\\", \\\"{x:1329,y:754,t:1527271787673};\\\", \\\"{x:1312,y:752,t:1527271787689};\\\", \\\"{x:1298,y:749,t:1527271787706};\\\", \\\"{x:1289,y:748,t:1527271787723};\\\", \\\"{x:1285,y:748,t:1527271787739};\\\", \\\"{x:1280,y:747,t:1527271787756};\\\", \\\"{x:1279,y:747,t:1527271787773};\\\", \\\"{x:1278,y:747,t:1527271787789};\\\", \\\"{x:1277,y:747,t:1527271787812};\\\", \\\"{x:1275,y:747,t:1527271790980};\\\", \\\"{x:1273,y:748,t:1527271790994};\\\", \\\"{x:1272,y:748,t:1527271791013};\\\", \\\"{x:1272,y:749,t:1527271791028};\\\", \\\"{x:1270,y:750,t:1527271795836};\\\", \\\"{x:1267,y:751,t:1527271795850};\\\", \\\"{x:1264,y:753,t:1527271795867};\\\", \\\"{x:1262,y:756,t:1527271795884};\\\", \\\"{x:1261,y:756,t:1527271795900};\\\", \\\"{x:1260,y:757,t:1527271795988};\\\", \\\"{x:1260,y:758,t:1527271796004};\\\", \\\"{x:1259,y:759,t:1527271796140};\\\", \\\"{x:1259,y:761,t:1527271796156};\\\", \\\"{x:1260,y:758,t:1527271796685};\\\", \\\"{x:1273,y:749,t:1527271796702};\\\", \\\"{x:1286,y:734,t:1527271796718};\\\", \\\"{x:1301,y:705,t:1527271796735};\\\", \\\"{x:1316,y:666,t:1527271796752};\\\", \\\"{x:1334,y:622,t:1527271796769};\\\", \\\"{x:1349,y:597,t:1527271796785};\\\", \\\"{x:1356,y:589,t:1527271796803};\\\", \\\"{x:1362,y:580,t:1527271796819};\\\", \\\"{x:1371,y:568,t:1527271796836};\\\", \\\"{x:1374,y:564,t:1527271796852};\\\", \\\"{x:1377,y:560,t:1527271797132};\\\", \\\"{x:1387,y:544,t:1527271797140};\\\", \\\"{x:1405,y:514,t:1527271797153};\\\", \\\"{x:1442,y:441,t:1527271797170};\\\", \\\"{x:1471,y:378,t:1527271797186};\\\", \\\"{x:1490,y:331,t:1527271797203};\\\", \\\"{x:1508,y:288,t:1527271797219};\\\", \\\"{x:1514,y:250,t:1527271797237};\\\", \\\"{x:1514,y:225,t:1527271797252};\\\", \\\"{x:1514,y:200,t:1527271797270};\\\", \\\"{x:1514,y:185,t:1527271797287};\\\", \\\"{x:1509,y:173,t:1527271797302};\\\", \\\"{x:1504,y:162,t:1527271797320};\\\", \\\"{x:1502,y:157,t:1527271797337};\\\", \\\"{x:1502,y:155,t:1527271797353};\\\", \\\"{x:1502,y:153,t:1527271797428};\\\", \\\"{x:1502,y:150,t:1527271797436};\\\", \\\"{x:1502,y:146,t:1527271797452};\\\", \\\"{x:1501,y:143,t:1527271797470};\\\", \\\"{x:1500,y:141,t:1527271797486};\\\", \\\"{x:1499,y:140,t:1527271797503};\\\", \\\"{x:1498,y:139,t:1527271797581};\\\", \\\"{x:1497,y:139,t:1527271797612};\\\", \\\"{x:1494,y:144,t:1527271797620};\\\", \\\"{x:1489,y:157,t:1527271797636};\\\", \\\"{x:1484,y:175,t:1527271797654};\\\", \\\"{x:1477,y:199,t:1527271797670};\\\", \\\"{x:1467,y:223,t:1527271797686};\\\", \\\"{x:1461,y:245,t:1527271797703};\\\", \\\"{x:1456,y:264,t:1527271797721};\\\", \\\"{x:1450,y:282,t:1527271797736};\\\", \\\"{x:1445,y:295,t:1527271797754};\\\", \\\"{x:1440,y:312,t:1527271797770};\\\", \\\"{x:1434,y:328,t:1527271797787};\\\", \\\"{x:1429,y:341,t:1527271797803};\\\", \\\"{x:1424,y:350,t:1527271797820};\\\", \\\"{x:1423,y:353,t:1527271797837};\\\", \\\"{x:1422,y:355,t:1527271797853};\\\", \\\"{x:1421,y:358,t:1527271797870};\\\", \\\"{x:1421,y:364,t:1527271797888};\\\", \\\"{x:1418,y:371,t:1527271797904};\\\", \\\"{x:1416,y:377,t:1527271797920};\\\", \\\"{x:1413,y:386,t:1527271797937};\\\", \\\"{x:1409,y:394,t:1527271797953};\\\", \\\"{x:1406,y:404,t:1527271797971};\\\", \\\"{x:1398,y:419,t:1527271797987};\\\", \\\"{x:1392,y:435,t:1527271798003};\\\", \\\"{x:1384,y:458,t:1527271798020};\\\", \\\"{x:1378,y:470,t:1527271798037};\\\", \\\"{x:1376,y:478,t:1527271798054};\\\", \\\"{x:1372,y:487,t:1527271798070};\\\", \\\"{x:1370,y:493,t:1527271798087};\\\", \\\"{x:1368,y:498,t:1527271798104};\\\", \\\"{x:1367,y:501,t:1527271798121};\\\", \\\"{x:1367,y:503,t:1527271798137};\\\", \\\"{x:1367,y:504,t:1527271798154};\\\", \\\"{x:1366,y:505,t:1527271798261};\\\", \\\"{x:1365,y:505,t:1527271798271};\\\", \\\"{x:1362,y:503,t:1527271798287};\\\", \\\"{x:1361,y:501,t:1527271798304};\\\", \\\"{x:1360,y:499,t:1527271798321};\\\", \\\"{x:1360,y:498,t:1527271798340};\\\", \\\"{x:1360,y:497,t:1527271798356};\\\", \\\"{x:1359,y:496,t:1527271798757};\\\", \\\"{x:1358,y:496,t:1527271798772};\\\", \\\"{x:1355,y:491,t:1527271798789};\\\", \\\"{x:1349,y:484,t:1527271798805};\\\", \\\"{x:1342,y:474,t:1527271798821};\\\", \\\"{x:1337,y:469,t:1527271798839};\\\", \\\"{x:1335,y:466,t:1527271798855};\\\", \\\"{x:1334,y:465,t:1527271798872};\\\", \\\"{x:1333,y:465,t:1527271799005};\\\", \\\"{x:1330,y:466,t:1527271799022};\\\", \\\"{x:1329,y:467,t:1527271799039};\\\", \\\"{x:1326,y:473,t:1527271799056};\\\", \\\"{x:1322,y:478,t:1527271799072};\\\", \\\"{x:1321,y:482,t:1527271799089};\\\", \\\"{x:1320,y:483,t:1527271799106};\\\", \\\"{x:1320,y:484,t:1527271799125};\\\", \\\"{x:1319,y:486,t:1527271799355};\\\", \\\"{x:1319,y:487,t:1527271799371};\\\", \\\"{x:1318,y:488,t:1527271799388};\\\", \\\"{x:1318,y:490,t:1527271799403};\\\", \\\"{x:1318,y:492,t:1527271799451};\\\", \\\"{x:1317,y:494,t:1527271799471};\\\", \\\"{x:1316,y:495,t:1527271799488};\\\", \\\"{x:1316,y:496,t:1527271799595};\\\", \\\"{x:1316,y:497,t:1527271799866};\\\", \\\"{x:1319,y:497,t:1527271799875};\\\", \\\"{x:1326,y:497,t:1527271799889};\\\", \\\"{x:1347,y:497,t:1527271799905};\\\", \\\"{x:1374,y:497,t:1527271799921};\\\", \\\"{x:1406,y:498,t:1527271799938};\\\", \\\"{x:1452,y:499,t:1527271799954};\\\", \\\"{x:1475,y:504,t:1527271799971};\\\", \\\"{x:1500,y:508,t:1527271799987};\\\", \\\"{x:1524,y:511,t:1527271800004};\\\", \\\"{x:1547,y:515,t:1527271800021};\\\", \\\"{x:1569,y:519,t:1527271800038};\\\", \\\"{x:1584,y:519,t:1527271800055};\\\", \\\"{x:1604,y:524,t:1527271800072};\\\", \\\"{x:1615,y:526,t:1527271800088};\\\", \\\"{x:1624,y:527,t:1527271800104};\\\", \\\"{x:1633,y:529,t:1527271800122};\\\", \\\"{x:1640,y:529,t:1527271800139};\\\", \\\"{x:1648,y:529,t:1527271800155};\\\", \\\"{x:1664,y:529,t:1527271800172};\\\", \\\"{x:1677,y:529,t:1527271800189};\\\", \\\"{x:1687,y:529,t:1527271800205};\\\", \\\"{x:1692,y:528,t:1527271800221};\\\", \\\"{x:1694,y:527,t:1527271800239};\\\", \\\"{x:1695,y:526,t:1527271800255};\\\", \\\"{x:1696,y:525,t:1527271800275};\\\", \\\"{x:1697,y:525,t:1527271800289};\\\", \\\"{x:1697,y:522,t:1527271800305};\\\", \\\"{x:1697,y:518,t:1527271800322};\\\", \\\"{x:1682,y:504,t:1527271800339};\\\", \\\"{x:1672,y:499,t:1527271800355};\\\", \\\"{x:1663,y:498,t:1527271800372};\\\", \\\"{x:1655,y:495,t:1527271800389};\\\", \\\"{x:1651,y:494,t:1527271800406};\\\", \\\"{x:1648,y:492,t:1527271800422};\\\", \\\"{x:1647,y:492,t:1527271800483};\\\", \\\"{x:1646,y:492,t:1527271800602};\\\", \\\"{x:1645,y:495,t:1527271800611};\\\", \\\"{x:1643,y:496,t:1527271800623};\\\", \\\"{x:1639,y:502,t:1527271800639};\\\", \\\"{x:1634,y:507,t:1527271800656};\\\", \\\"{x:1625,y:519,t:1527271800672};\\\", \\\"{x:1610,y:534,t:1527271800689};\\\", \\\"{x:1590,y:554,t:1527271800705};\\\", \\\"{x:1546,y:577,t:1527271800722};\\\", \\\"{x:1508,y:599,t:1527271800739};\\\", \\\"{x:1480,y:620,t:1527271800756};\\\", \\\"{x:1445,y:645,t:1527271800773};\\\", \\\"{x:1412,y:667,t:1527271800789};\\\", \\\"{x:1369,y:690,t:1527271800805};\\\", \\\"{x:1324,y:712,t:1527271800823};\\\", \\\"{x:1296,y:723,t:1527271800839};\\\", \\\"{x:1281,y:731,t:1527271800855};\\\", \\\"{x:1271,y:737,t:1527271800873};\\\", \\\"{x:1262,y:741,t:1527271800890};\\\", \\\"{x:1254,y:744,t:1527271800906};\\\", \\\"{x:1239,y:750,t:1527271800922};\\\", \\\"{x:1227,y:756,t:1527271800940};\\\", \\\"{x:1213,y:762,t:1527271800956};\\\", \\\"{x:1201,y:767,t:1527271800973};\\\", \\\"{x:1197,y:769,t:1527271800990};\\\", \\\"{x:1196,y:770,t:1527271801006};\\\", \\\"{x:1196,y:772,t:1527271802699};\\\", \\\"{x:1196,y:773,t:1527271802709};\\\", \\\"{x:1196,y:774,t:1527271802725};\\\", \\\"{x:1196,y:776,t:1527271802742};\\\", \\\"{x:1198,y:780,t:1527271802759};\\\", \\\"{x:1199,y:781,t:1527271802775};\\\", \\\"{x:1200,y:784,t:1527271802963};\\\", \\\"{x:1202,y:787,t:1527271802976};\\\", \\\"{x:1206,y:793,t:1527271802993};\\\", \\\"{x:1208,y:797,t:1527271803009};\\\", \\\"{x:1211,y:801,t:1527271803026};\\\", \\\"{x:1221,y:811,t:1527271803042};\\\", \\\"{x:1229,y:817,t:1527271803059};\\\", \\\"{x:1239,y:823,t:1527271803075};\\\", \\\"{x:1247,y:828,t:1527271803093};\\\", \\\"{x:1253,y:830,t:1527271803108};\\\", \\\"{x:1259,y:832,t:1527271803126};\\\", \\\"{x:1262,y:834,t:1527271803143};\\\", \\\"{x:1263,y:834,t:1527271803291};\\\", \\\"{x:1264,y:834,t:1527271803299};\\\", \\\"{x:1266,y:834,t:1527271803310};\\\", \\\"{x:1268,y:834,t:1527271803326};\\\", \\\"{x:1271,y:834,t:1527271803343};\\\", \\\"{x:1280,y:834,t:1527271803361};\\\", \\\"{x:1295,y:834,t:1527271803377};\\\", \\\"{x:1318,y:834,t:1527271803393};\\\", \\\"{x:1351,y:834,t:1527271803410};\\\", \\\"{x:1396,y:834,t:1527271803426};\\\", \\\"{x:1486,y:834,t:1527271803442};\\\", \\\"{x:1544,y:834,t:1527271803460};\\\", \\\"{x:1587,y:834,t:1527271803476};\\\", \\\"{x:1624,y:841,t:1527271803493};\\\", \\\"{x:1650,y:844,t:1527271803510};\\\", \\\"{x:1683,y:848,t:1527271803526};\\\", \\\"{x:1704,y:850,t:1527271803543};\\\", \\\"{x:1722,y:853,t:1527271803560};\\\", \\\"{x:1740,y:858,t:1527271803576};\\\", \\\"{x:1753,y:859,t:1527271803593};\\\", \\\"{x:1764,y:860,t:1527271803610};\\\", \\\"{x:1775,y:862,t:1527271803626};\\\", \\\"{x:1782,y:862,t:1527271803643};\\\", \\\"{x:1785,y:862,t:1527271803659};\\\", \\\"{x:1786,y:862,t:1527271803683};\\\", \\\"{x:1787,y:862,t:1527271803827};\\\", \\\"{x:1789,y:861,t:1527271803844};\\\", \\\"{x:1791,y:860,t:1527271803860};\\\", \\\"{x:1795,y:856,t:1527271803877};\\\", \\\"{x:1797,y:854,t:1527271803894};\\\", \\\"{x:1799,y:852,t:1527271803910};\\\", \\\"{x:1800,y:851,t:1527271803931};\\\", \\\"{x:1803,y:850,t:1527271803954};\\\", \\\"{x:1806,y:849,t:1527271803979};\\\", \\\"{x:1807,y:849,t:1527271803993};\\\", \\\"{x:1814,y:847,t:1527271804011};\\\", \\\"{x:1815,y:846,t:1527271804027};\\\", \\\"{x:1816,y:846,t:1527271804131};\\\", \\\"{x:1818,y:845,t:1527271804147};\\\", \\\"{x:1814,y:845,t:1527271804219};\\\", \\\"{x:1799,y:845,t:1527271804227};\\\", \\\"{x:1722,y:845,t:1527271804244};\\\", \\\"{x:1578,y:843,t:1527271804261};\\\", \\\"{x:1382,y:813,t:1527271804277};\\\", \\\"{x:1150,y:780,t:1527271804294};\\\", \\\"{x:912,y:740,t:1527271804311};\\\", \\\"{x:679,y:696,t:1527271804328};\\\", \\\"{x:491,y:645,t:1527271804345};\\\", \\\"{x:363,y:605,t:1527271804361};\\\", \\\"{x:299,y:573,t:1527271804378};\\\", \\\"{x:280,y:565,t:1527271804393};\\\", \\\"{x:278,y:564,t:1527271804410};\\\", \\\"{x:278,y:563,t:1527271804426};\\\", \\\"{x:282,y:559,t:1527271804443};\\\", \\\"{x:286,y:559,t:1527271804460};\\\", \\\"{x:288,y:558,t:1527271804476};\\\", \\\"{x:290,y:558,t:1527271804493};\\\", \\\"{x:291,y:558,t:1527271804546};\\\", \\\"{x:303,y:564,t:1527271804559};\\\", \\\"{x:336,y:589,t:1527271804577};\\\", \\\"{x:403,y:637,t:1527271804594};\\\", \\\"{x:453,y:677,t:1527271804618};\\\", \\\"{x:484,y:698,t:1527271804634};\\\", \\\"{x:522,y:721,t:1527271804651};\\\", \\\"{x:533,y:727,t:1527271804668};\\\", \\\"{x:535,y:727,t:1527271804683};\\\", \\\"{x:536,y:727,t:1527271804701};\\\", \\\"{x:539,y:727,t:1527271810139};\\\", \\\"{x:549,y:717,t:1527271810146};\\\", \\\"{x:566,y:710,t:1527271810161};\\\", \\\"{x:630,y:684,t:1527271810178};\\\", \\\"{x:663,y:671,t:1527271810194};\\\", \\\"{x:682,y:667,t:1527271810205};\\\", \\\"{x:697,y:661,t:1527271810222};\\\", \\\"{x:703,y:658,t:1527271810238};\\\", \\\"{x:707,y:654,t:1527271810255};\\\", \\\"{x:708,y:654,t:1527271810271};\\\", \\\"{x:710,y:654,t:1527271810410};\\\", \\\"{x:720,y:654,t:1527271810422};\\\", \\\"{x:756,y:670,t:1527271810439};\\\", \\\"{x:822,y:697,t:1527271810456};\\\", \\\"{x:915,y:718,t:1527271810472};\\\", \\\"{x:1049,y:741,t:1527271810490};\\\", \\\"{x:1188,y:765,t:1527271810506};\\\", \\\"{x:1337,y:780,t:1527271810522};\\\", \\\"{x:1554,y:790,t:1527271810539};\\\", \\\"{x:1657,y:790,t:1527271810556};\\\", \\\"{x:1712,y:790,t:1527271810573};\\\", \\\"{x:1747,y:792,t:1527271810589};\\\", \\\"{x:1760,y:795,t:1527271810606};\\\", \\\"{x:1761,y:796,t:1527271810623};\\\", \\\"{x:1760,y:796,t:1527271810682};\\\", \\\"{x:1755,y:796,t:1527271810690};\\\", \\\"{x:1746,y:800,t:1527271810706};\\\", \\\"{x:1723,y:813,t:1527271810723};\\\", \\\"{x:1706,y:820,t:1527271810740};\\\", \\\"{x:1691,y:827,t:1527271810756};\\\", \\\"{x:1661,y:834,t:1527271810773};\\\", \\\"{x:1613,y:850,t:1527271810790};\\\", \\\"{x:1547,y:867,t:1527271810806};\\\", \\\"{x:1488,y:884,t:1527271810823};\\\", \\\"{x:1446,y:897,t:1527271810840};\\\", \\\"{x:1421,y:903,t:1527271810857};\\\", \\\"{x:1406,y:904,t:1527271810874};\\\", \\\"{x:1399,y:905,t:1527271810890};\\\", \\\"{x:1398,y:905,t:1527271810996};\\\", \\\"{x:1396,y:905,t:1527271811012};\\\", \\\"{x:1394,y:905,t:1527271811025};\\\", \\\"{x:1388,y:902,t:1527271811040};\\\", \\\"{x:1379,y:897,t:1527271811058};\\\", \\\"{x:1346,y:883,t:1527271811075};\\\", \\\"{x:1334,y:881,t:1527271811091};\\\", \\\"{x:1289,y:868,t:1527271811107};\\\", \\\"{x:1270,y:863,t:1527271811124};\\\", \\\"{x:1252,y:855,t:1527271811140};\\\", \\\"{x:1242,y:850,t:1527271811158};\\\", \\\"{x:1239,y:848,t:1527271811174};\\\", \\\"{x:1236,y:846,t:1527271811191};\\\", \\\"{x:1236,y:845,t:1527271811208};\\\", \\\"{x:1235,y:845,t:1527271811243};\\\", \\\"{x:1234,y:844,t:1527271811257};\\\", \\\"{x:1234,y:843,t:1527271811275};\\\", \\\"{x:1233,y:842,t:1527271811292};\\\", \\\"{x:1233,y:841,t:1527271811307};\\\", \\\"{x:1232,y:839,t:1527271811324};\\\", \\\"{x:1231,y:837,t:1527271811341};\\\", \\\"{x:1230,y:835,t:1527271811359};\\\", \\\"{x:1230,y:834,t:1527271811374};\\\", \\\"{x:1228,y:832,t:1527271811419};\\\", \\\"{x:1228,y:831,t:1527271811426};\\\", \\\"{x:1228,y:830,t:1527271811441};\\\", \\\"{x:1227,y:830,t:1527271811459};\\\", \\\"{x:1226,y:830,t:1527271811515};\\\", \\\"{x:1224,y:829,t:1527271811525};\\\", \\\"{x:1222,y:829,t:1527271811542};\\\", \\\"{x:1221,y:828,t:1527271811558};\\\", \\\"{x:1220,y:828,t:1527271811576};\\\", \\\"{x:1218,y:827,t:1527271813650};\\\", \\\"{x:1217,y:827,t:1527271813662};\\\", \\\"{x:1216,y:827,t:1527271813698};\\\", \\\"{x:1216,y:826,t:1527271813713};\\\", \\\"{x:1217,y:826,t:1527271816834};\\\", \\\"{x:1218,y:826,t:1527271816850};\\\", \\\"{x:1219,y:826,t:1527271816858};\\\", \\\"{x:1220,y:826,t:1527271816869};\\\", \\\"{x:1222,y:826,t:1527271816885};\\\", \\\"{x:1226,y:826,t:1527271816902};\\\", \\\"{x:1231,y:826,t:1527271816918};\\\", \\\"{x:1234,y:827,t:1527271816935};\\\", \\\"{x:1240,y:827,t:1527271816952};\\\", \\\"{x:1245,y:827,t:1527271816969};\\\", \\\"{x:1249,y:826,t:1527271816985};\\\", \\\"{x:1249,y:825,t:1527271817115};\\\", \\\"{x:1251,y:824,t:1527271817130};\\\", \\\"{x:1252,y:824,t:1527271817138};\\\", \\\"{x:1256,y:823,t:1527271817152};\\\", \\\"{x:1264,y:822,t:1527271817169};\\\", \\\"{x:1271,y:822,t:1527271817186};\\\", \\\"{x:1276,y:823,t:1527271817203};\\\", \\\"{x:1277,y:824,t:1527271817219};\\\", \\\"{x:1278,y:825,t:1527271817258};\\\", \\\"{x:1279,y:825,t:1527271817306};\\\", \\\"{x:1282,y:825,t:1527271817587};\\\", \\\"{x:1289,y:828,t:1527271817603};\\\", \\\"{x:1301,y:832,t:1527271817620};\\\", \\\"{x:1317,y:835,t:1527271817637};\\\", \\\"{x:1336,y:838,t:1527271817653};\\\", \\\"{x:1347,y:839,t:1527271817670};\\\", \\\"{x:1357,y:842,t:1527271817687};\\\", \\\"{x:1358,y:842,t:1527271817703};\\\", \\\"{x:1359,y:842,t:1527271817720};\\\", \\\"{x:1359,y:840,t:1527271817963};\\\", \\\"{x:1359,y:839,t:1527271817971};\\\", \\\"{x:1359,y:838,t:1527271817987};\\\", \\\"{x:1358,y:836,t:1527271818005};\\\", \\\"{x:1357,y:835,t:1527271818026};\\\", \\\"{x:1357,y:834,t:1527271818038};\\\", \\\"{x:1356,y:832,t:1527271818054};\\\", \\\"{x:1356,y:831,t:1527271818071};\\\", \\\"{x:1355,y:830,t:1527271818322};\\\", \\\"{x:1354,y:830,t:1527271818338};\\\", \\\"{x:1353,y:830,t:1527271818355};\\\", \\\"{x:1353,y:829,t:1527271818434};\\\", \\\"{x:1351,y:829,t:1527271818442};\\\", \\\"{x:1350,y:829,t:1527271818458};\\\", \\\"{x:1349,y:828,t:1527271818472};\\\", \\\"{x:1348,y:828,t:1527271818488};\\\", \\\"{x:1347,y:828,t:1527271819131};\\\", \\\"{x:1346,y:828,t:1527271819354};\\\", \\\"{x:1345,y:828,t:1527271820906};\\\", \\\"{x:1344,y:828,t:1527271820915};\\\", \\\"{x:1342,y:828,t:1527271820926};\\\", \\\"{x:1340,y:828,t:1527271820944};\\\", \\\"{x:1338,y:828,t:1527271820961};\\\", \\\"{x:1337,y:828,t:1527271820977};\\\", \\\"{x:1335,y:828,t:1527271820993};\\\", \\\"{x:1333,y:828,t:1527271821219};\\\", \\\"{x:1332,y:828,t:1527271821234};\\\", \\\"{x:1331,y:828,t:1527271821244};\\\", \\\"{x:1328,y:828,t:1527271821261};\\\", \\\"{x:1323,y:829,t:1527271821278};\\\", \\\"{x:1321,y:829,t:1527271821295};\\\", \\\"{x:1319,y:830,t:1527271821311};\\\", \\\"{x:1318,y:830,t:1527271821327};\\\", \\\"{x:1317,y:831,t:1527271821345};\\\", \\\"{x:1316,y:831,t:1527271821371};\\\", \\\"{x:1315,y:831,t:1527271821379};\\\", \\\"{x:1314,y:831,t:1527271821395};\\\", \\\"{x:1311,y:831,t:1527271821412};\\\", \\\"{x:1308,y:831,t:1527271821428};\\\", \\\"{x:1307,y:831,t:1527271821445};\\\", \\\"{x:1305,y:831,t:1527271821461};\\\", \\\"{x:1304,y:833,t:1527271822523};\\\", \\\"{x:1302,y:833,t:1527271822538};\\\", \\\"{x:1301,y:833,t:1527271822610};\\\", \\\"{x:1300,y:833,t:1527271823130};\\\", \\\"{x:1299,y:833,t:1527271823139};\\\", \\\"{x:1298,y:833,t:1527271823170};\\\", \\\"{x:1297,y:833,t:1527271823186};\\\", \\\"{x:1296,y:833,t:1527271823198};\\\", \\\"{x:1293,y:833,t:1527271823214};\\\", \\\"{x:1286,y:833,t:1527271823232};\\\", \\\"{x:1281,y:833,t:1527271823249};\\\", \\\"{x:1279,y:833,t:1527271823264};\\\", \\\"{x:1278,y:833,t:1527271823281};\\\", \\\"{x:1275,y:833,t:1527271823298};\\\", \\\"{x:1273,y:833,t:1527271823498};\\\", \\\"{x:1268,y:833,t:1527271823516};\\\", \\\"{x:1265,y:833,t:1527271823531};\\\", \\\"{x:1263,y:832,t:1527271823548};\\\", \\\"{x:1259,y:830,t:1527271823566};\\\", \\\"{x:1258,y:829,t:1527271823583};\\\", \\\"{x:1252,y:828,t:1527271823599};\\\", \\\"{x:1248,y:826,t:1527271823615};\\\", \\\"{x:1246,y:825,t:1527271823642};\\\", \\\"{x:1244,y:824,t:1527271823651};\\\", \\\"{x:1240,y:822,t:1527271823665};\\\", \\\"{x:1230,y:817,t:1527271823682};\\\", \\\"{x:1225,y:814,t:1527271823698};\\\", \\\"{x:1222,y:813,t:1527271823715};\\\", \\\"{x:1219,y:812,t:1527271823733};\\\", \\\"{x:1218,y:811,t:1527271823749};\\\", \\\"{x:1217,y:810,t:1527271823786};\\\", \\\"{x:1217,y:808,t:1527271823867};\\\", \\\"{x:1217,y:806,t:1527271823883};\\\", \\\"{x:1217,y:799,t:1527271823900};\\\", \\\"{x:1217,y:791,t:1527271823917};\\\", \\\"{x:1217,y:785,t:1527271823933};\\\", \\\"{x:1217,y:781,t:1527271823950};\\\", \\\"{x:1217,y:777,t:1527271823966};\\\", \\\"{x:1215,y:773,t:1527271823983};\\\", \\\"{x:1215,y:771,t:1527271823999};\\\", \\\"{x:1215,y:769,t:1527271824017};\\\", \\\"{x:1215,y:767,t:1527271824033};\\\", \\\"{x:1215,y:766,t:1527271824050};\\\", \\\"{x:1214,y:765,t:1527271824074};\\\", \\\"{x:1214,y:764,t:1527271824090};\\\", \\\"{x:1214,y:763,t:1527271824122};\\\", \\\"{x:1214,y:762,t:1527271824138};\\\", \\\"{x:1214,y:761,t:1527271824149};\\\", \\\"{x:1214,y:759,t:1527271824166};\\\", \\\"{x:1213,y:756,t:1527271824184};\\\", \\\"{x:1213,y:752,t:1527271824199};\\\", \\\"{x:1212,y:749,t:1527271824216};\\\", \\\"{x:1212,y:747,t:1527271824234};\\\", \\\"{x:1210,y:741,t:1527271824250};\\\", \\\"{x:1207,y:733,t:1527271824267};\\\", \\\"{x:1207,y:728,t:1527271824283};\\\", \\\"{x:1206,y:725,t:1527271824300};\\\", \\\"{x:1206,y:721,t:1527271824316};\\\", \\\"{x:1205,y:716,t:1527271824333};\\\", \\\"{x:1204,y:713,t:1527271824351};\\\", \\\"{x:1203,y:708,t:1527271824367};\\\", \\\"{x:1202,y:705,t:1527271824383};\\\", \\\"{x:1202,y:702,t:1527271824401};\\\", \\\"{x:1202,y:701,t:1527271824417};\\\", \\\"{x:1202,y:698,t:1527271824434};\\\", \\\"{x:1202,y:697,t:1527271824451};\\\", \\\"{x:1201,y:697,t:1527271825082};\\\", \\\"{x:1200,y:697,t:1527271825106};\\\", \\\"{x:1200,y:698,t:1527271825138};\\\", \\\"{x:1200,y:699,t:1527271825154};\\\", \\\"{x:1200,y:701,t:1527271825169};\\\", \\\"{x:1200,y:702,t:1527271825226};\\\", \\\"{x:1200,y:704,t:1527271825810};\\\", \\\"{x:1201,y:705,t:1527271825820};\\\", \\\"{x:1201,y:706,t:1527271825850};\\\", \\\"{x:1203,y:708,t:1527271825858};\\\", \\\"{x:1203,y:710,t:1527271825882};\\\", \\\"{x:1204,y:712,t:1527271825898};\\\", \\\"{x:1205,y:714,t:1527271825906};\\\", \\\"{x:1206,y:715,t:1527271825920};\\\", \\\"{x:1208,y:719,t:1527271825936};\\\", \\\"{x:1211,y:723,t:1527271825954};\\\", \\\"{x:1213,y:727,t:1527271825970};\\\", \\\"{x:1215,y:731,t:1527271825986};\\\", \\\"{x:1215,y:733,t:1527271826004};\\\", \\\"{x:1218,y:739,t:1527271826021};\\\", \\\"{x:1223,y:751,t:1527271826036};\\\", \\\"{x:1227,y:766,t:1527271826053};\\\", \\\"{x:1232,y:775,t:1527271826070};\\\", \\\"{x:1234,y:784,t:1527271826087};\\\", \\\"{x:1236,y:789,t:1527271826103};\\\", \\\"{x:1237,y:794,t:1527271826121};\\\", \\\"{x:1237,y:796,t:1527271826138};\\\", \\\"{x:1237,y:799,t:1527271826154};\\\", \\\"{x:1237,y:807,t:1527271826170};\\\", \\\"{x:1237,y:812,t:1527271826188};\\\", \\\"{x:1237,y:816,t:1527271826204};\\\", \\\"{x:1237,y:817,t:1527271826221};\\\", \\\"{x:1237,y:818,t:1527271826238};\\\", \\\"{x:1238,y:820,t:1527271826253};\\\", \\\"{x:1238,y:822,t:1527271826275};\\\", \\\"{x:1238,y:823,t:1527271826291};\\\", \\\"{x:1238,y:825,t:1527271826323};\\\", \\\"{x:1238,y:826,t:1527271826338};\\\", \\\"{x:1238,y:829,t:1527271826354};\\\", \\\"{x:1238,y:831,t:1527271826370};\\\", \\\"{x:1238,y:832,t:1527271826388};\\\", \\\"{x:1238,y:833,t:1527271826404};\\\", \\\"{x:1236,y:835,t:1527271826420};\\\", \\\"{x:1235,y:836,t:1527271826442};\\\", \\\"{x:1235,y:837,t:1527271826570};\\\", \\\"{x:1234,y:837,t:1527271826634};\\\", \\\"{x:1233,y:837,t:1527271826930};\\\", \\\"{x:1231,y:837,t:1527271827091};\\\", \\\"{x:1230,y:836,t:1527271827107};\\\", \\\"{x:1228,y:835,t:1527271827123};\\\", \\\"{x:1227,y:834,t:1527271827140};\\\", \\\"{x:1226,y:834,t:1527271827202};\\\", \\\"{x:1224,y:833,t:1527271827210};\\\", \\\"{x:1224,y:832,t:1527271827223};\\\", \\\"{x:1223,y:830,t:1527271827240};\\\", \\\"{x:1221,y:828,t:1527271827256};\\\", \\\"{x:1220,y:827,t:1527271827272};\\\", \\\"{x:1220,y:826,t:1527271827290};\\\", \\\"{x:1219,y:825,t:1527271827306};\\\", \\\"{x:1219,y:823,t:1527271827419};\\\", \\\"{x:1219,y:822,t:1527271827427};\\\", \\\"{x:1219,y:821,t:1527271827523};\\\", \\\"{x:1219,y:819,t:1527271827530};\\\", \\\"{x:1219,y:817,t:1527271827539};\\\", \\\"{x:1219,y:816,t:1527271827556};\\\", \\\"{x:1220,y:813,t:1527271827573};\\\", \\\"{x:1220,y:812,t:1527271827590};\\\", \\\"{x:1220,y:811,t:1527271827607};\\\", \\\"{x:1221,y:810,t:1527271827623};\\\", \\\"{x:1221,y:808,t:1527271827640};\\\", \\\"{x:1222,y:806,t:1527271827657};\\\", \\\"{x:1222,y:804,t:1527271827674};\\\", \\\"{x:1224,y:800,t:1527271827690};\\\", \\\"{x:1225,y:798,t:1527271827706};\\\", \\\"{x:1225,y:797,t:1527271827723};\\\", \\\"{x:1226,y:795,t:1527271827741};\\\", \\\"{x:1227,y:791,t:1527271827757};\\\", \\\"{x:1231,y:789,t:1527271827773};\\\", \\\"{x:1231,y:788,t:1527271827791};\\\", \\\"{x:1231,y:791,t:1527271827843};\\\", \\\"{x:1230,y:793,t:1527271827858};\\\", \\\"{x:1228,y:798,t:1527271827874};\\\", \\\"{x:1227,y:799,t:1527271827891};\\\", \\\"{x:1226,y:800,t:1527271827908};\\\", \\\"{x:1225,y:801,t:1527271827994};\\\", \\\"{x:1224,y:802,t:1527271828008};\\\", \\\"{x:1222,y:804,t:1527271828024};\\\", \\\"{x:1221,y:804,t:1527271828041};\\\", \\\"{x:1219,y:804,t:1527271828058};\\\", \\\"{x:1217,y:804,t:1527271828138};\\\", \\\"{x:1213,y:804,t:1527271828146};\\\", \\\"{x:1210,y:804,t:1527271828158};\\\", \\\"{x:1203,y:804,t:1527271828174};\\\", \\\"{x:1200,y:804,t:1527271828192};\\\", \\\"{x:1200,y:805,t:1527271828514};\\\", \\\"{x:1201,y:807,t:1527271828530};\\\", \\\"{x:1204,y:808,t:1527271828542};\\\", \\\"{x:1212,y:812,t:1527271828559};\\\", \\\"{x:1220,y:815,t:1527271828576};\\\", \\\"{x:1223,y:817,t:1527271828592};\\\", \\\"{x:1225,y:819,t:1527271828609};\\\", \\\"{x:1225,y:821,t:1527271828626};\\\", \\\"{x:1226,y:821,t:1527271828658};\\\", \\\"{x:1229,y:822,t:1527271828666};\\\", \\\"{x:1231,y:822,t:1527271828676};\\\", \\\"{x:1239,y:823,t:1527271828693};\\\", \\\"{x:1250,y:823,t:1527271828709};\\\", \\\"{x:1264,y:824,t:1527271828726};\\\", \\\"{x:1266,y:824,t:1527271828742};\\\", \\\"{x:1267,y:824,t:1527271828850};\\\", \\\"{x:1268,y:824,t:1527271828907};\\\", \\\"{x:1270,y:825,t:1527271828914};\\\", \\\"{x:1273,y:825,t:1527271828930};\\\", \\\"{x:1274,y:825,t:1527271828943};\\\", \\\"{x:1278,y:825,t:1527271828959};\\\", \\\"{x:1281,y:825,t:1527271828976};\\\", \\\"{x:1282,y:825,t:1527271829066};\\\", \\\"{x:1284,y:825,t:1527271829578};\\\", \\\"{x:1288,y:825,t:1527271829594};\\\", \\\"{x:1303,y:826,t:1527271829611};\\\", \\\"{x:1317,y:827,t:1527271829628};\\\", \\\"{x:1329,y:827,t:1527271829644};\\\", \\\"{x:1340,y:827,t:1527271829661};\\\", \\\"{x:1345,y:827,t:1527271829678};\\\", \\\"{x:1349,y:828,t:1527271829695};\\\", \\\"{x:1351,y:828,t:1527271829711};\\\", \\\"{x:1353,y:828,t:1527271829728};\\\", \\\"{x:1355,y:829,t:1527271829745};\\\", \\\"{x:1358,y:829,t:1527271829761};\\\", \\\"{x:1360,y:830,t:1527271829778};\\\", \\\"{x:1358,y:830,t:1527271830026};\\\", \\\"{x:1357,y:830,t:1527271830034};\\\", \\\"{x:1355,y:830,t:1527271830045};\\\", \\\"{x:1353,y:830,t:1527271830062};\\\", \\\"{x:1352,y:830,t:1527271830078};\\\", \\\"{x:1351,y:830,t:1527271830094};\\\", \\\"{x:1350,y:830,t:1527271830111};\\\", \\\"{x:1349,y:830,t:1527271830130};\\\", \\\"{x:1348,y:830,t:1527271830154};\\\", \\\"{x:1347,y:830,t:1527271830162};\\\", \\\"{x:1346,y:830,t:1527271830194};\\\", \\\"{x:1345,y:829,t:1527271832075};\\\", \\\"{x:1345,y:827,t:1527271832083};\\\", \\\"{x:1345,y:823,t:1527271832100};\\\", \\\"{x:1347,y:822,t:1527271832116};\\\", \\\"{x:1347,y:821,t:1527271832133};\\\", \\\"{x:1347,y:820,t:1527271832149};\\\", \\\"{x:1347,y:819,t:1527271832171};\\\", \\\"{x:1347,y:818,t:1527271832195};\\\", \\\"{x:1347,y:817,t:1527271832532};\\\", \\\"{x:1347,y:816,t:1527271832539};\\\", \\\"{x:1346,y:813,t:1527271832554};\\\", \\\"{x:1345,y:813,t:1527271832571};\\\", \\\"{x:1345,y:812,t:1527271832603};\\\", \\\"{x:1344,y:810,t:1527271832619};\\\", \\\"{x:1344,y:809,t:1527271832635};\\\", \\\"{x:1342,y:811,t:1527271833010};\\\", \\\"{x:1341,y:812,t:1527271833018};\\\", \\\"{x:1340,y:820,t:1527271833034};\\\", \\\"{x:1335,y:831,t:1527271833051};\\\", \\\"{x:1327,y:839,t:1527271833068};\\\", \\\"{x:1320,y:845,t:1527271833085};\\\", \\\"{x:1307,y:854,t:1527271833101};\\\", \\\"{x:1286,y:861,t:1527271833118};\\\", \\\"{x:1255,y:865,t:1527271833135};\\\", \\\"{x:1172,y:865,t:1527271833151};\\\", \\\"{x:1061,y:852,t:1527271833168};\\\", \\\"{x:939,y:836,t:1527271833185};\\\", \\\"{x:847,y:808,t:1527271833200};\\\", \\\"{x:736,y:778,t:1527271833218};\\\", \\\"{x:686,y:755,t:1527271833234};\\\", \\\"{x:642,y:729,t:1527271833251};\\\", \\\"{x:611,y:705,t:1527271833268};\\\", \\\"{x:597,y:696,t:1527271833285};\\\", \\\"{x:595,y:695,t:1527271833302};\\\", \\\"{x:595,y:693,t:1527271833322};\\\", \\\"{x:595,y:692,t:1527271833338};\\\", \\\"{x:595,y:690,t:1527271833352};\\\", \\\"{x:597,y:672,t:1527271833368};\\\", \\\"{x:597,y:643,t:1527271833386};\\\", \\\"{x:567,y:568,t:1527271833403};\\\", \\\"{x:538,y:519,t:1527271833419};\\\", \\\"{x:516,y:485,t:1527271833441};\\\", \\\"{x:508,y:471,t:1527271833457};\\\", \\\"{x:507,y:470,t:1527271833473};\\\", \\\"{x:507,y:474,t:1527271833554};\\\", \\\"{x:507,y:482,t:1527271833562};\\\", \\\"{x:514,y:490,t:1527271833574};\\\", \\\"{x:532,y:507,t:1527271833591};\\\", \\\"{x:567,y:520,t:1527271833608};\\\", \\\"{x:617,y:534,t:1527271833624};\\\", \\\"{x:702,y:551,t:1527271833642};\\\", \\\"{x:831,y:557,t:1527271833658};\\\", \\\"{x:868,y:557,t:1527271833675};\\\", \\\"{x:882,y:557,t:1527271833691};\\\", \\\"{x:886,y:556,t:1527271833707};\\\", \\\"{x:886,y:555,t:1527271833746};\\\", \\\"{x:889,y:551,t:1527271833757};\\\", \\\"{x:902,y:548,t:1527271833774};\\\", \\\"{x:916,y:544,t:1527271833791};\\\", \\\"{x:922,y:544,t:1527271833808};\\\", \\\"{x:923,y:544,t:1527271833823};\\\", \\\"{x:924,y:544,t:1527271833841};\\\", \\\"{x:923,y:544,t:1527271833889};\\\", \\\"{x:915,y:544,t:1527271833898};\\\", \\\"{x:904,y:544,t:1527271833907};\\\", \\\"{x:873,y:548,t:1527271833923};\\\", \\\"{x:781,y:560,t:1527271833940};\\\", \\\"{x:643,y:581,t:1527271833959};\\\", \\\"{x:461,y:599,t:1527271833974};\\\", \\\"{x:244,y:615,t:1527271833991};\\\", \\\"{x:46,y:633,t:1527271834008};\\\", \\\"{x:0,y:636,t:1527271834025};\\\", \\\"{x:4,y:636,t:1527271834171};\\\", \\\"{x:9,y:636,t:1527271834178};\\\", \\\"{x:16,y:636,t:1527271834191};\\\", \\\"{x:37,y:639,t:1527271834208};\\\", \\\"{x:64,y:641,t:1527271834225};\\\", \\\"{x:98,y:643,t:1527271834241};\\\", \\\"{x:138,y:639,t:1527271834258};\\\", \\\"{x:154,y:632,t:1527271834274};\\\", \\\"{x:160,y:626,t:1527271834291};\\\", \\\"{x:160,y:622,t:1527271834308};\\\", \\\"{x:160,y:617,t:1527271834325};\\\", \\\"{x:160,y:616,t:1527271834342};\\\", \\\"{x:160,y:615,t:1527271834362};\\\", \\\"{x:160,y:614,t:1527271834378};\\\", \\\"{x:160,y:613,t:1527271834391};\\\", \\\"{x:157,y:609,t:1527271834409};\\\", \\\"{x:155,y:605,t:1527271834426};\\\", \\\"{x:154,y:603,t:1527271834442};\\\", \\\"{x:154,y:602,t:1527271834458};\\\", \\\"{x:154,y:600,t:1527271834506};\\\", \\\"{x:154,y:597,t:1527271834513};\\\", \\\"{x:156,y:594,t:1527271834525};\\\", \\\"{x:159,y:577,t:1527271834543};\\\", \\\"{x:161,y:563,t:1527271834560};\\\", \\\"{x:161,y:554,t:1527271834575};\\\", \\\"{x:161,y:548,t:1527271834592};\\\", \\\"{x:161,y:543,t:1527271834609};\\\", \\\"{x:161,y:541,t:1527271834625};\\\", \\\"{x:161,y:543,t:1527271834850};\\\", \\\"{x:163,y:546,t:1527271834859};\\\", \\\"{x:166,y:554,t:1527271834875};\\\", \\\"{x:167,y:554,t:1527271834892};\\\", \\\"{x:167,y:555,t:1527271834909};\\\", \\\"{x:169,y:558,t:1527271834925};\\\", \\\"{x:170,y:558,t:1527271835714};\\\", \\\"{x:179,y:562,t:1527271835726};\\\", \\\"{x:211,y:569,t:1527271835743};\\\", \\\"{x:278,y:578,t:1527271835760};\\\", \\\"{x:359,y:591,t:1527271835777};\\\", \\\"{x:424,y:615,t:1527271835792};\\\", \\\"{x:496,y:649,t:1527271835809};\\\", \\\"{x:609,y:701,t:1527271835826};\\\", \\\"{x:644,y:721,t:1527271835842};\\\", \\\"{x:664,y:737,t:1527271835859};\\\", \\\"{x:676,y:749,t:1527271835875};\\\", \\\"{x:686,y:766,t:1527271835893};\\\", \\\"{x:690,y:786,t:1527271835909};\\\", \\\"{x:696,y:802,t:1527271835926};\\\", \\\"{x:697,y:812,t:1527271835943};\\\", \\\"{x:697,y:817,t:1527271835959};\\\", \\\"{x:697,y:818,t:1527271835976};\\\", \\\"{x:697,y:819,t:1527271835993};\\\", \\\"{x:691,y:818,t:1527271836009};\\\", \\\"{x:658,y:794,t:1527271836026};\\\", \\\"{x:616,y:766,t:1527271836042};\\\", \\\"{x:572,y:737,t:1527271836059};\\\", \\\"{x:522,y:715,t:1527271836076};\\\", \\\"{x:486,y:700,t:1527271836093};\\\", \\\"{x:468,y:690,t:1527271836110};\\\", \\\"{x:461,y:686,t:1527271836126};\\\", \\\"{x:460,y:686,t:1527271836142};\\\", \\\"{x:463,y:687,t:1527271836402};\\\", \\\"{x:465,y:688,t:1527271836410};\\\", \\\"{x:471,y:692,t:1527271836426};\\\", \\\"{x:474,y:695,t:1527271836443};\\\", \\\"{x:478,y:698,t:1527271836460};\\\", \\\"{x:480,y:699,t:1527271836477};\\\", \\\"{x:484,y:700,t:1527271836494};\\\", \\\"{x:486,y:703,t:1527271836522};\\\", \\\"{x:489,y:708,t:1527271836530};\\\", \\\"{x:493,y:715,t:1527271836543};\\\", \\\"{x:499,y:726,t:1527271836559};\\\", \\\"{x:501,y:727,t:1527271836576};\\\", \\\"{x:503,y:727,t:1527271836698};\\\", \\\"{x:504,y:727,t:1527271836709};\\\", \\\"{x:506,y:727,t:1527271836727};\\\", \\\"{x:507,y:727,t:1527271837050};\\\", \\\"{x:507,y:726,t:1527271837059};\\\", \\\"{x:507,y:725,t:1527271837077};\\\" ] }, { \\\"rt\\\": 59369, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 294172, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -U -O -C -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:711,t:1527271856146};\\\", \\\"{x:521,y:687,t:1527271856159};\\\", \\\"{x:536,y:651,t:1527271856176};\\\", \\\"{x:543,y:630,t:1527271856193};\\\", \\\"{x:546,y:620,t:1527271856209};\\\", \\\"{x:546,y:608,t:1527271856226};\\\", \\\"{x:546,y:598,t:1527271856242};\\\", \\\"{x:546,y:573,t:1527271856259};\\\", \\\"{x:554,y:530,t:1527271856276};\\\", \\\"{x:560,y:494,t:1527271856293};\\\", \\\"{x:562,y:475,t:1527271856310};\\\", \\\"{x:562,y:467,t:1527271856325};\\\", \\\"{x:562,y:458,t:1527271856342};\\\", \\\"{x:562,y:455,t:1527271856359};\\\", \\\"{x:562,y:453,t:1527271856385};\\\", \\\"{x:562,y:452,t:1527271856410};\\\", \\\"{x:562,y:449,t:1527271856425};\\\", \\\"{x:562,y:446,t:1527271856442};\\\", \\\"{x:562,y:445,t:1527271856460};\\\", \\\"{x:564,y:445,t:1527271856737};\\\", \\\"{x:564,y:447,t:1527271856746};\\\", \\\"{x:566,y:451,t:1527271856759};\\\", \\\"{x:571,y:459,t:1527271856775};\\\", \\\"{x:578,y:471,t:1527271856792};\\\", \\\"{x:594,y:487,t:1527271856809};\\\", \\\"{x:607,y:491,t:1527271856826};\\\", \\\"{x:623,y:498,t:1527271856842};\\\", \\\"{x:657,y:512,t:1527271856870};\\\", \\\"{x:669,y:518,t:1527271856876};\\\", \\\"{x:709,y:532,t:1527271856893};\\\", \\\"{x:759,y:544,t:1527271856910};\\\", \\\"{x:811,y:558,t:1527271856926};\\\", \\\"{x:865,y:575,t:1527271856943};\\\", \\\"{x:893,y:587,t:1527271856960};\\\", \\\"{x:913,y:596,t:1527271856977};\\\", \\\"{x:921,y:599,t:1527271856993};\\\", \\\"{x:924,y:601,t:1527271857010};\\\", \\\"{x:925,y:601,t:1527271859360};\\\", \\\"{x:934,y:611,t:1527271859375};\\\", \\\"{x:960,y:625,t:1527271859392};\\\", \\\"{x:997,y:641,t:1527271859410};\\\", \\\"{x:1041,y:659,t:1527271859426};\\\", \\\"{x:1079,y:681,t:1527271859443};\\\", \\\"{x:1117,y:699,t:1527271859459};\\\", \\\"{x:1153,y:714,t:1527271859476};\\\", \\\"{x:1177,y:724,t:1527271859493};\\\", \\\"{x:1197,y:732,t:1527271859509};\\\", \\\"{x:1208,y:738,t:1527271859526};\\\", \\\"{x:1218,y:744,t:1527271859543};\\\", \\\"{x:1220,y:745,t:1527271859559};\\\", \\\"{x:1221,y:746,t:1527271859616};\\\", \\\"{x:1223,y:748,t:1527271859639};\\\", \\\"{x:1224,y:749,t:1527271859656};\\\", \\\"{x:1224,y:750,t:1527271859664};\\\", \\\"{x:1225,y:751,t:1527271859676};\\\", \\\"{x:1226,y:752,t:1527271859693};\\\", \\\"{x:1226,y:753,t:1527271859710};\\\", \\\"{x:1226,y:754,t:1527271859727};\\\", \\\"{x:1226,y:756,t:1527271859743};\\\", \\\"{x:1226,y:759,t:1527271859760};\\\", \\\"{x:1226,y:761,t:1527271859777};\\\", \\\"{x:1226,y:763,t:1527271859794};\\\", \\\"{x:1226,y:766,t:1527271859811};\\\", \\\"{x:1226,y:769,t:1527271859827};\\\", \\\"{x:1224,y:779,t:1527271859843};\\\", \\\"{x:1220,y:789,t:1527271859860};\\\", \\\"{x:1220,y:795,t:1527271859877};\\\", \\\"{x:1218,y:800,t:1527271859893};\\\", \\\"{x:1217,y:804,t:1527271859910};\\\", \\\"{x:1217,y:810,t:1527271859927};\\\", \\\"{x:1217,y:811,t:1527271859944};\\\", \\\"{x:1217,y:813,t:1527271859960};\\\", \\\"{x:1216,y:814,t:1527271859983};\\\", \\\"{x:1215,y:816,t:1527271859995};\\\", \\\"{x:1214,y:817,t:1527271860011};\\\", \\\"{x:1213,y:818,t:1527271860027};\\\", \\\"{x:1213,y:820,t:1527271860044};\\\", \\\"{x:1213,y:821,t:1527271860063};\\\", \\\"{x:1213,y:822,t:1527271860078};\\\", \\\"{x:1211,y:824,t:1527271860094};\\\", \\\"{x:1210,y:826,t:1527271860112};\\\", \\\"{x:1209,y:829,t:1527271860127};\\\", \\\"{x:1208,y:830,t:1527271860145};\\\", \\\"{x:1207,y:831,t:1527271860162};\\\", \\\"{x:1207,y:832,t:1527271860178};\\\", \\\"{x:1207,y:834,t:1527271860195};\\\", \\\"{x:1206,y:834,t:1527271860211};\\\", \\\"{x:1206,y:835,t:1527271860231};\\\", \\\"{x:1206,y:836,t:1527271860255};\\\", \\\"{x:1205,y:837,t:1527271860263};\\\", \\\"{x:1205,y:839,t:1527271860288};\\\", \\\"{x:1205,y:841,t:1527271860295};\\\", \\\"{x:1205,y:843,t:1527271860311};\\\", \\\"{x:1205,y:847,t:1527271860328};\\\", \\\"{x:1205,y:850,t:1527271860345};\\\", \\\"{x:1207,y:853,t:1527271860362};\\\", \\\"{x:1212,y:856,t:1527271860379};\\\", \\\"{x:1217,y:859,t:1527271860395};\\\", \\\"{x:1228,y:863,t:1527271860411};\\\", \\\"{x:1244,y:868,t:1527271860429};\\\", \\\"{x:1262,y:872,t:1527271860445};\\\", \\\"{x:1284,y:876,t:1527271860462};\\\", \\\"{x:1304,y:881,t:1527271860478};\\\", \\\"{x:1333,y:886,t:1527271860495};\\\", \\\"{x:1353,y:889,t:1527271860512};\\\", \\\"{x:1369,y:891,t:1527271860528};\\\", \\\"{x:1385,y:895,t:1527271860546};\\\", \\\"{x:1398,y:897,t:1527271860563};\\\", \\\"{x:1408,y:898,t:1527271860580};\\\", \\\"{x:1414,y:899,t:1527271860596};\\\", \\\"{x:1420,y:900,t:1527271860612};\\\", \\\"{x:1425,y:901,t:1527271860629};\\\", \\\"{x:1427,y:901,t:1527271860646};\\\", \\\"{x:1432,y:901,t:1527271860662};\\\", \\\"{x:1434,y:902,t:1527271860679};\\\", \\\"{x:1435,y:903,t:1527271860880};\\\", \\\"{x:1434,y:904,t:1527271860897};\\\", \\\"{x:1431,y:905,t:1527271860914};\\\", \\\"{x:1429,y:907,t:1527271860930};\\\", \\\"{x:1427,y:907,t:1527271860947};\\\", \\\"{x:1422,y:909,t:1527271860963};\\\", \\\"{x:1418,y:910,t:1527271860981};\\\", \\\"{x:1416,y:910,t:1527271860996};\\\", \\\"{x:1415,y:910,t:1527271861014};\\\", \\\"{x:1414,y:911,t:1527271861030};\\\", \\\"{x:1413,y:912,t:1527271861047};\\\", \\\"{x:1413,y:913,t:1527271861216};\\\", \\\"{x:1417,y:913,t:1527271861231};\\\", \\\"{x:1436,y:913,t:1527271861247};\\\", \\\"{x:1456,y:913,t:1527271861265};\\\", \\\"{x:1474,y:913,t:1527271861281};\\\", \\\"{x:1491,y:917,t:1527271861297};\\\", \\\"{x:1509,y:918,t:1527271861314};\\\", \\\"{x:1525,y:918,t:1527271861331};\\\", \\\"{x:1542,y:918,t:1527271861347};\\\", \\\"{x:1557,y:918,t:1527271861365};\\\", \\\"{x:1571,y:918,t:1527271861381};\\\", \\\"{x:1580,y:918,t:1527271861397};\\\", \\\"{x:1585,y:918,t:1527271861414};\\\", \\\"{x:1593,y:922,t:1527271861431};\\\", \\\"{x:1597,y:922,t:1527271861447};\\\", \\\"{x:1603,y:925,t:1527271861464};\\\", \\\"{x:1608,y:925,t:1527271861482};\\\", \\\"{x:1611,y:926,t:1527271861498};\\\", \\\"{x:1613,y:926,t:1527271861515};\\\", \\\"{x:1615,y:927,t:1527271861532};\\\", \\\"{x:1619,y:928,t:1527271861549};\\\", \\\"{x:1621,y:929,t:1527271861565};\\\", \\\"{x:1622,y:929,t:1527271861581};\\\", \\\"{x:1623,y:931,t:1527271861616};\\\", \\\"{x:1623,y:935,t:1527271861631};\\\", \\\"{x:1624,y:937,t:1527271861649};\\\", \\\"{x:1624,y:940,t:1527271861665};\\\", \\\"{x:1623,y:945,t:1527271861681};\\\", \\\"{x:1621,y:949,t:1527271861698};\\\", \\\"{x:1620,y:950,t:1527271861716};\\\", \\\"{x:1620,y:951,t:1527271861732};\\\", \\\"{x:1620,y:952,t:1527271861748};\\\", \\\"{x:1620,y:953,t:1527271861765};\\\", \\\"{x:1619,y:954,t:1527271861782};\\\", \\\"{x:1618,y:954,t:1527271861815};\\\", \\\"{x:1618,y:955,t:1527271861879};\\\", \\\"{x:1618,y:956,t:1527271862375};\\\", \\\"{x:1618,y:957,t:1527271862384};\\\", \\\"{x:1617,y:957,t:1527271862401};\\\", \\\"{x:1617,y:958,t:1527271862418};\\\", \\\"{x:1615,y:958,t:1527271862434};\\\", \\\"{x:1608,y:958,t:1527271862451};\\\", \\\"{x:1600,y:958,t:1527271862468};\\\", \\\"{x:1583,y:957,t:1527271862484};\\\", \\\"{x:1563,y:952,t:1527271862501};\\\", \\\"{x:1545,y:947,t:1527271862517};\\\", \\\"{x:1535,y:946,t:1527271862534};\\\", \\\"{x:1530,y:944,t:1527271862551};\\\", \\\"{x:1526,y:943,t:1527271862568};\\\", \\\"{x:1525,y:942,t:1527271862585};\\\", \\\"{x:1520,y:940,t:1527271862601};\\\", \\\"{x:1516,y:938,t:1527271862617};\\\", \\\"{x:1509,y:936,t:1527271862634};\\\", \\\"{x:1501,y:934,t:1527271862651};\\\", \\\"{x:1495,y:930,t:1527271862667};\\\", \\\"{x:1490,y:925,t:1527271862685};\\\", \\\"{x:1484,y:916,t:1527271862701};\\\", \\\"{x:1481,y:906,t:1527271862717};\\\", \\\"{x:1479,y:898,t:1527271862735};\\\", \\\"{x:1479,y:889,t:1527271862750};\\\", \\\"{x:1479,y:884,t:1527271862768};\\\", \\\"{x:1479,y:878,t:1527271862785};\\\", \\\"{x:1479,y:874,t:1527271862801};\\\", \\\"{x:1479,y:871,t:1527271862818};\\\", \\\"{x:1479,y:867,t:1527271862834};\\\", \\\"{x:1483,y:860,t:1527271862852};\\\", \\\"{x:1485,y:855,t:1527271862869};\\\", \\\"{x:1486,y:850,t:1527271862884};\\\", \\\"{x:1488,y:846,t:1527271862901};\\\", \\\"{x:1488,y:844,t:1527271862919};\\\", \\\"{x:1488,y:843,t:1527271862934};\\\", \\\"{x:1488,y:842,t:1527271862992};\\\", \\\"{x:1488,y:841,t:1527271863002};\\\", \\\"{x:1488,y:839,t:1527271863018};\\\", \\\"{x:1488,y:838,t:1527271863035};\\\", \\\"{x:1488,y:837,t:1527271863053};\\\", \\\"{x:1488,y:836,t:1527271863575};\\\", \\\"{x:1488,y:835,t:1527271863586};\\\", \\\"{x:1487,y:835,t:1527271863607};\\\", \\\"{x:1486,y:835,t:1527271863760};\\\", \\\"{x:1485,y:835,t:1527271863807};\\\", \\\"{x:1484,y:835,t:1527271863823};\\\", \\\"{x:1485,y:835,t:1527271870471};\\\", \\\"{x:1487,y:833,t:1527271870488};\\\", \\\"{x:1488,y:830,t:1527271870505};\\\", \\\"{x:1489,y:830,t:1527271870522};\\\", \\\"{x:1490,y:829,t:1527271870551};\\\", \\\"{x:1491,y:829,t:1527271870567};\\\", \\\"{x:1491,y:828,t:1527271870590};\\\", \\\"{x:1492,y:827,t:1527271870606};\\\", \\\"{x:1492,y:826,t:1527271870623};\\\", \\\"{x:1492,y:825,t:1527271870791};\\\", \\\"{x:1490,y:825,t:1527271870807};\\\", \\\"{x:1488,y:825,t:1527271870823};\\\", \\\"{x:1487,y:825,t:1527271870839};\\\", \\\"{x:1485,y:825,t:1527271870975};\\\", \\\"{x:1484,y:825,t:1527271871439};\\\", \\\"{x:1482,y:825,t:1527271871457};\\\", \\\"{x:1481,y:825,t:1527271871478};\\\", \\\"{x:1479,y:825,t:1527271871490};\\\", \\\"{x:1478,y:825,t:1527271871510};\\\", \\\"{x:1476,y:825,t:1527271871525};\\\", \\\"{x:1468,y:832,t:1527271871541};\\\", \\\"{x:1447,y:856,t:1527271871558};\\\", \\\"{x:1429,y:871,t:1527271871574};\\\", \\\"{x:1414,y:880,t:1527271871591};\\\", \\\"{x:1416,y:879,t:1527271871839};\\\", \\\"{x:1418,y:878,t:1527271871846};\\\", \\\"{x:1419,y:877,t:1527271871858};\\\", \\\"{x:1421,y:876,t:1527271871874};\\\", \\\"{x:1425,y:873,t:1527271871892};\\\", \\\"{x:1428,y:871,t:1527271871909};\\\", \\\"{x:1432,y:869,t:1527271871925};\\\", \\\"{x:1433,y:868,t:1527271871942};\\\", \\\"{x:1434,y:867,t:1527271871959};\\\", \\\"{x:1430,y:867,t:1527271872614};\\\", \\\"{x:1406,y:867,t:1527271872627};\\\", \\\"{x:1310,y:859,t:1527271872644};\\\", \\\"{x:1199,y:847,t:1527271872660};\\\", \\\"{x:1075,y:828,t:1527271872676};\\\", \\\"{x:936,y:811,t:1527271872694};\\\", \\\"{x:687,y:762,t:1527271872710};\\\", \\\"{x:507,y:733,t:1527271872727};\\\", \\\"{x:349,y:682,t:1527271872744};\\\", \\\"{x:229,y:635,t:1527271872761};\\\", \\\"{x:177,y:608,t:1527271872771};\\\", \\\"{x:118,y:579,t:1527271872787};\\\", \\\"{x:91,y:564,t:1527271872803};\\\", \\\"{x:89,y:562,t:1527271872820};\\\", \\\"{x:89,y:559,t:1527271872935};\\\", \\\"{x:92,y:554,t:1527271872943};\\\", \\\"{x:95,y:550,t:1527271872954};\\\", \\\"{x:96,y:546,t:1527271872969};\\\", \\\"{x:97,y:545,t:1527271872998};\\\", \\\"{x:98,y:544,t:1527271873023};\\\", \\\"{x:99,y:544,t:1527271873036};\\\", \\\"{x:118,y:545,t:1527271873054};\\\", \\\"{x:199,y:578,t:1527271873071};\\\", \\\"{x:263,y:597,t:1527271873087};\\\", \\\"{x:342,y:609,t:1527271873104};\\\", \\\"{x:425,y:611,t:1527271873121};\\\", \\\"{x:492,y:611,t:1527271873136};\\\", \\\"{x:522,y:609,t:1527271873155};\\\", \\\"{x:540,y:601,t:1527271873170};\\\", \\\"{x:553,y:593,t:1527271873186};\\\", \\\"{x:564,y:585,t:1527271873203};\\\", \\\"{x:580,y:576,t:1527271873220};\\\", \\\"{x:606,y:565,t:1527271873237};\\\", \\\"{x:640,y:554,t:1527271873254};\\\", \\\"{x:665,y:548,t:1527271873270};\\\", \\\"{x:705,y:544,t:1527271873287};\\\", \\\"{x:732,y:544,t:1527271873304};\\\", \\\"{x:755,y:544,t:1527271873320};\\\", \\\"{x:777,y:544,t:1527271873337};\\\", \\\"{x:787,y:546,t:1527271873354};\\\", \\\"{x:788,y:546,t:1527271873370};\\\", \\\"{x:793,y:546,t:1527271873387};\\\", \\\"{x:806,y:546,t:1527271873404};\\\", \\\"{x:830,y:546,t:1527271873421};\\\", \\\"{x:850,y:546,t:1527271873437};\\\", \\\"{x:868,y:546,t:1527271873454};\\\", \\\"{x:885,y:546,t:1527271873471};\\\", \\\"{x:890,y:546,t:1527271873487};\\\", \\\"{x:889,y:546,t:1527271873607};\\\", \\\"{x:876,y:551,t:1527271873621};\\\", \\\"{x:847,y:566,t:1527271873637};\\\", \\\"{x:820,y:582,t:1527271873654};\\\", \\\"{x:773,y:605,t:1527271873670};\\\", \\\"{x:747,y:614,t:1527271873688};\\\", \\\"{x:734,y:617,t:1527271873704};\\\", \\\"{x:725,y:619,t:1527271873721};\\\", \\\"{x:718,y:619,t:1527271873737};\\\", \\\"{x:712,y:619,t:1527271873754};\\\", \\\"{x:703,y:619,t:1527271873771};\\\", \\\"{x:698,y:619,t:1527271873786};\\\", \\\"{x:689,y:619,t:1527271873804};\\\", \\\"{x:674,y:619,t:1527271873821};\\\", \\\"{x:651,y:615,t:1527271873837};\\\", \\\"{x:642,y:612,t:1527271873854};\\\", \\\"{x:639,y:609,t:1527271873871};\\\", \\\"{x:638,y:608,t:1527271873888};\\\", \\\"{x:638,y:606,t:1527271873906};\\\", \\\"{x:638,y:605,t:1527271873921};\\\", \\\"{x:637,y:605,t:1527271873938};\\\", \\\"{x:636,y:604,t:1527271873954};\\\", \\\"{x:635,y:604,t:1527271873974};\\\", \\\"{x:634,y:604,t:1527271873991};\\\", \\\"{x:633,y:602,t:1527271874003};\\\", \\\"{x:631,y:601,t:1527271874021};\\\", \\\"{x:628,y:600,t:1527271874038};\\\", \\\"{x:624,y:598,t:1527271874053};\\\", \\\"{x:621,y:597,t:1527271874070};\\\", \\\"{x:620,y:597,t:1527271874103};\\\", \\\"{x:619,y:597,t:1527271874127};\\\", \\\"{x:626,y:597,t:1527271875136};\\\", \\\"{x:651,y:597,t:1527271875144};\\\", \\\"{x:698,y:597,t:1527271875155};\\\", \\\"{x:793,y:602,t:1527271875173};\\\", \\\"{x:920,y:616,t:1527271875190};\\\", \\\"{x:1048,y:618,t:1527271875205};\\\", \\\"{x:1194,y:640,t:1527271875222};\\\", \\\"{x:1410,y:679,t:1527271875239};\\\", \\\"{x:1526,y:693,t:1527271875255};\\\", \\\"{x:1596,y:706,t:1527271875271};\\\", \\\"{x:1617,y:708,t:1527271875289};\\\", \\\"{x:1624,y:709,t:1527271875305};\\\", \\\"{x:1625,y:709,t:1527271875322};\\\", \\\"{x:1626,y:709,t:1527271875343};\\\", \\\"{x:1627,y:709,t:1527271875582};\\\", \\\"{x:1627,y:710,t:1527271875606};\\\", \\\"{x:1627,y:711,t:1527271875694};\\\", \\\"{x:1626,y:711,t:1527271876199};\\\", \\\"{x:1618,y:711,t:1527271876207};\\\", \\\"{x:1598,y:711,t:1527271876223};\\\", \\\"{x:1581,y:711,t:1527271876239};\\\", \\\"{x:1560,y:711,t:1527271876256};\\\", \\\"{x:1544,y:711,t:1527271876272};\\\", \\\"{x:1534,y:709,t:1527271876289};\\\", \\\"{x:1530,y:709,t:1527271876306};\\\", \\\"{x:1527,y:709,t:1527271876323};\\\", \\\"{x:1525,y:709,t:1527271876343};\\\", \\\"{x:1523,y:709,t:1527271876356};\\\", \\\"{x:1522,y:709,t:1527271876373};\\\", \\\"{x:1520,y:709,t:1527271876390};\\\", \\\"{x:1516,y:710,t:1527271876406};\\\", \\\"{x:1511,y:711,t:1527271876423};\\\", \\\"{x:1509,y:711,t:1527271876440};\\\", \\\"{x:1504,y:713,t:1527271876456};\\\", \\\"{x:1502,y:713,t:1527271876473};\\\", \\\"{x:1501,y:714,t:1527271876490};\\\", \\\"{x:1500,y:715,t:1527271876511};\\\", \\\"{x:1499,y:715,t:1527271876523};\\\", \\\"{x:1498,y:715,t:1527271876540};\\\", \\\"{x:1497,y:715,t:1527271876984};\\\", \\\"{x:1496,y:715,t:1527271877015};\\\", \\\"{x:1496,y:716,t:1527271877039};\\\", \\\"{x:1495,y:716,t:1527271877046};\\\", \\\"{x:1494,y:717,t:1527271877057};\\\", \\\"{x:1493,y:717,t:1527271877073};\\\", \\\"{x:1490,y:717,t:1527271877126};\\\", \\\"{x:1486,y:718,t:1527271877142};\\\", \\\"{x:1480,y:720,t:1527271877157};\\\", \\\"{x:1468,y:720,t:1527271877173};\\\", \\\"{x:1454,y:720,t:1527271877190};\\\", \\\"{x:1445,y:720,t:1527271877206};\\\", \\\"{x:1441,y:720,t:1527271877222};\\\", \\\"{x:1436,y:717,t:1527271877240};\\\", \\\"{x:1432,y:717,t:1527271877257};\\\", \\\"{x:1429,y:715,t:1527271877273};\\\", \\\"{x:1422,y:709,t:1527271877290};\\\", \\\"{x:1412,y:699,t:1527271877307};\\\", \\\"{x:1400,y:685,t:1527271877323};\\\", \\\"{x:1386,y:670,t:1527271877340};\\\", \\\"{x:1374,y:658,t:1527271877357};\\\", \\\"{x:1367,y:650,t:1527271877375};\\\", \\\"{x:1359,y:642,t:1527271877390};\\\", \\\"{x:1353,y:637,t:1527271877407};\\\", \\\"{x:1352,y:635,t:1527271877424};\\\", \\\"{x:1351,y:635,t:1527271877440};\\\", \\\"{x:1351,y:633,t:1527271877458};\\\", \\\"{x:1348,y:631,t:1527271877475};\\\", \\\"{x:1347,y:631,t:1527271878327};\\\", \\\"{x:1346,y:631,t:1527271878359};\\\", \\\"{x:1344,y:631,t:1527271878383};\\\", \\\"{x:1343,y:631,t:1527271878399};\\\", \\\"{x:1341,y:631,t:1527271878422};\\\", \\\"{x:1339,y:631,t:1527271878439};\\\", \\\"{x:1338,y:631,t:1527271878447};\\\", \\\"{x:1337,y:632,t:1527271878458};\\\", \\\"{x:1335,y:632,t:1527271878474};\\\", \\\"{x:1332,y:632,t:1527271878491};\\\", \\\"{x:1329,y:632,t:1527271878508};\\\", \\\"{x:1327,y:632,t:1527271878524};\\\", \\\"{x:1325,y:633,t:1527271878541};\\\", \\\"{x:1324,y:633,t:1527271878606};\\\", \\\"{x:1323,y:633,t:1527271878727};\\\", \\\"{x:1322,y:633,t:1527271878758};\\\", \\\"{x:1321,y:633,t:1527271878775};\\\", \\\"{x:1320,y:633,t:1527271878791};\\\", \\\"{x:1319,y:633,t:1527271878808};\\\", \\\"{x:1318,y:633,t:1527271878841};\\\", \\\"{x:1317,y:633,t:1527271878858};\\\", \\\"{x:1316,y:635,t:1527271880326};\\\", \\\"{x:1316,y:637,t:1527271880342};\\\", \\\"{x:1314,y:643,t:1527271880359};\\\", \\\"{x:1314,y:645,t:1527271880377};\\\", \\\"{x:1314,y:649,t:1527271880392};\\\", \\\"{x:1314,y:650,t:1527271880410};\\\", \\\"{x:1313,y:654,t:1527271880426};\\\", \\\"{x:1312,y:657,t:1527271880442};\\\", \\\"{x:1311,y:661,t:1527271880459};\\\", \\\"{x:1310,y:664,t:1527271880477};\\\", \\\"{x:1309,y:667,t:1527271880493};\\\", \\\"{x:1309,y:670,t:1527271880509};\\\", \\\"{x:1307,y:675,t:1527271880526};\\\", \\\"{x:1307,y:684,t:1527271880542};\\\", \\\"{x:1307,y:694,t:1527271880559};\\\", \\\"{x:1307,y:698,t:1527271880576};\\\", \\\"{x:1307,y:703,t:1527271880592};\\\", \\\"{x:1307,y:709,t:1527271880609};\\\", \\\"{x:1307,y:716,t:1527271880626};\\\", \\\"{x:1307,y:727,t:1527271880642};\\\", \\\"{x:1308,y:747,t:1527271880660};\\\", \\\"{x:1312,y:765,t:1527271880676};\\\", \\\"{x:1317,y:782,t:1527271880693};\\\", \\\"{x:1322,y:791,t:1527271880709};\\\", \\\"{x:1325,y:797,t:1527271880726};\\\", \\\"{x:1326,y:800,t:1527271880743};\\\", \\\"{x:1327,y:801,t:1527271880759};\\\", \\\"{x:1327,y:802,t:1527271880943};\\\", \\\"{x:1327,y:808,t:1527271880959};\\\", \\\"{x:1325,y:812,t:1527271880976};\\\", \\\"{x:1325,y:819,t:1527271880993};\\\", \\\"{x:1321,y:825,t:1527271881009};\\\", \\\"{x:1318,y:835,t:1527271881026};\\\", \\\"{x:1315,y:842,t:1527271881043};\\\", \\\"{x:1312,y:850,t:1527271881059};\\\", \\\"{x:1312,y:852,t:1527271881077};\\\", \\\"{x:1312,y:853,t:1527271881093};\\\", \\\"{x:1312,y:854,t:1527271881167};\\\", \\\"{x:1312,y:856,t:1527271881176};\\\", \\\"{x:1312,y:857,t:1527271881194};\\\", \\\"{x:1312,y:859,t:1527271881210};\\\", \\\"{x:1312,y:860,t:1527271881226};\\\", \\\"{x:1312,y:862,t:1527271881243};\\\", \\\"{x:1312,y:866,t:1527271881260};\\\", \\\"{x:1312,y:870,t:1527271881276};\\\", \\\"{x:1312,y:876,t:1527271881293};\\\", \\\"{x:1312,y:881,t:1527271881310};\\\", \\\"{x:1312,y:884,t:1527271881326};\\\", \\\"{x:1312,y:890,t:1527271881343};\\\", \\\"{x:1312,y:896,t:1527271881360};\\\", \\\"{x:1314,y:904,t:1527271881376};\\\", \\\"{x:1314,y:909,t:1527271881393};\\\", \\\"{x:1314,y:911,t:1527271881410};\\\", \\\"{x:1314,y:912,t:1527271881426};\\\", \\\"{x:1314,y:914,t:1527271881443};\\\", \\\"{x:1314,y:915,t:1527271881478};\\\", \\\"{x:1314,y:916,t:1527271881502};\\\", \\\"{x:1314,y:917,t:1527271881519};\\\", \\\"{x:1314,y:918,t:1527271881542};\\\", \\\"{x:1314,y:919,t:1527271881550};\\\", \\\"{x:1314,y:920,t:1527271881560};\\\", \\\"{x:1314,y:923,t:1527271881576};\\\", \\\"{x:1314,y:927,t:1527271881593};\\\", \\\"{x:1314,y:931,t:1527271881610};\\\", \\\"{x:1314,y:938,t:1527271881627};\\\", \\\"{x:1314,y:947,t:1527271881643};\\\", \\\"{x:1314,y:952,t:1527271881660};\\\", \\\"{x:1314,y:955,t:1527271881677};\\\", \\\"{x:1314,y:959,t:1527271881693};\\\", \\\"{x:1314,y:961,t:1527271881710};\\\", \\\"{x:1314,y:962,t:1527271881727};\\\", \\\"{x:1314,y:963,t:1527271881743};\\\", \\\"{x:1314,y:964,t:1527271881760};\\\", \\\"{x:1314,y:965,t:1527271881790};\\\", \\\"{x:1314,y:966,t:1527271881798};\\\", \\\"{x:1314,y:967,t:1527271890167};\\\", \\\"{x:1306,y:967,t:1527271890183};\\\", \\\"{x:1295,y:967,t:1527271890200};\\\", \\\"{x:1280,y:967,t:1527271890216};\\\", \\\"{x:1265,y:967,t:1527271890233};\\\", \\\"{x:1258,y:967,t:1527271890250};\\\", \\\"{x:1257,y:967,t:1527271890267};\\\", \\\"{x:1256,y:967,t:1527271890283};\\\", \\\"{x:1255,y:967,t:1527271890318};\\\", \\\"{x:1254,y:967,t:1527271890366};\\\", \\\"{x:1254,y:966,t:1527271890383};\\\", \\\"{x:1253,y:961,t:1527271890400};\\\", \\\"{x:1251,y:955,t:1527271890417};\\\", \\\"{x:1249,y:944,t:1527271890433};\\\", \\\"{x:1245,y:937,t:1527271890450};\\\", \\\"{x:1240,y:928,t:1527271890467};\\\", \\\"{x:1235,y:920,t:1527271890483};\\\", \\\"{x:1228,y:908,t:1527271890499};\\\", \\\"{x:1222,y:896,t:1527271890517};\\\", \\\"{x:1220,y:881,t:1527271890534};\\\", \\\"{x:1220,y:861,t:1527271890549};\\\", \\\"{x:1220,y:834,t:1527271890566};\\\", \\\"{x:1220,y:828,t:1527271890583};\\\", \\\"{x:1220,y:821,t:1527271890600};\\\", \\\"{x:1221,y:811,t:1527271890616};\\\", \\\"{x:1224,y:802,t:1527271890634};\\\", \\\"{x:1227,y:791,t:1527271890651};\\\", \\\"{x:1233,y:780,t:1527271890667};\\\", \\\"{x:1239,y:771,t:1527271890683};\\\", \\\"{x:1243,y:761,t:1527271890701};\\\", \\\"{x:1248,y:753,t:1527271890716};\\\", \\\"{x:1253,y:742,t:1527271890733};\\\", \\\"{x:1256,y:733,t:1527271890750};\\\", \\\"{x:1261,y:719,t:1527271890766};\\\", \\\"{x:1263,y:712,t:1527271890783};\\\", \\\"{x:1265,y:705,t:1527271890800};\\\", \\\"{x:1269,y:697,t:1527271890816};\\\", \\\"{x:1270,y:691,t:1527271890833};\\\", \\\"{x:1272,y:687,t:1527271890851};\\\", \\\"{x:1272,y:684,t:1527271890867};\\\", \\\"{x:1273,y:682,t:1527271890884};\\\", \\\"{x:1273,y:680,t:1527271890900};\\\", \\\"{x:1273,y:679,t:1527271890917};\\\", \\\"{x:1273,y:676,t:1527271890934};\\\", \\\"{x:1273,y:675,t:1527271890950};\\\", \\\"{x:1273,y:672,t:1527271890967};\\\", \\\"{x:1273,y:671,t:1527271890998};\\\", \\\"{x:1273,y:670,t:1527271891054};\\\", \\\"{x:1274,y:670,t:1527271891918};\\\", \\\"{x:1275,y:668,t:1527271891934};\\\", \\\"{x:1276,y:664,t:1527271891952};\\\", \\\"{x:1276,y:662,t:1527271891967};\\\", \\\"{x:1277,y:659,t:1527271891984};\\\", \\\"{x:1277,y:656,t:1527271892000};\\\", \\\"{x:1277,y:654,t:1527271892018};\\\", \\\"{x:1278,y:651,t:1527271892034};\\\", \\\"{x:1279,y:650,t:1527271892051};\\\", \\\"{x:1280,y:645,t:1527271892068};\\\", \\\"{x:1281,y:641,t:1527271892085};\\\", \\\"{x:1283,y:637,t:1527271892102};\\\", \\\"{x:1283,y:636,t:1527271892118};\\\", \\\"{x:1283,y:633,t:1527271892135};\\\", \\\"{x:1283,y:632,t:1527271892166};\\\", \\\"{x:1283,y:631,t:1527271892174};\\\", \\\"{x:1284,y:630,t:1527271892184};\\\", \\\"{x:1285,y:628,t:1527271892202};\\\", \\\"{x:1285,y:627,t:1527271892218};\\\", \\\"{x:1285,y:625,t:1527271892234};\\\", \\\"{x:1285,y:624,t:1527271892252};\\\", \\\"{x:1285,y:625,t:1527271893279};\\\", \\\"{x:1286,y:625,t:1527271898318};\\\", \\\"{x:1290,y:625,t:1527271898326};\\\", \\\"{x:1293,y:626,t:1527271898339};\\\", \\\"{x:1300,y:628,t:1527271898356};\\\", \\\"{x:1302,y:629,t:1527271898372};\\\", \\\"{x:1304,y:630,t:1527271898389};\\\", \\\"{x:1309,y:632,t:1527271898406};\\\", \\\"{x:1320,y:636,t:1527271898423};\\\", \\\"{x:1330,y:640,t:1527271898439};\\\", \\\"{x:1347,y:650,t:1527271898456};\\\", \\\"{x:1373,y:664,t:1527271898473};\\\", \\\"{x:1407,y:679,t:1527271898489};\\\", \\\"{x:1448,y:695,t:1527271898506};\\\", \\\"{x:1480,y:704,t:1527271898523};\\\", \\\"{x:1501,y:710,t:1527271898539};\\\", \\\"{x:1518,y:715,t:1527271898556};\\\", \\\"{x:1528,y:716,t:1527271898572};\\\", \\\"{x:1535,y:717,t:1527271898590};\\\", \\\"{x:1541,y:720,t:1527271898606};\\\", \\\"{x:1550,y:720,t:1527271898623};\\\", \\\"{x:1551,y:720,t:1527271898640};\\\", \\\"{x:1551,y:722,t:1527271898806};\\\", \\\"{x:1551,y:726,t:1527271898823};\\\", \\\"{x:1551,y:730,t:1527271898840};\\\", \\\"{x:1548,y:734,t:1527271898856};\\\", \\\"{x:1543,y:740,t:1527271898873};\\\", \\\"{x:1539,y:748,t:1527271898890};\\\", \\\"{x:1533,y:758,t:1527271898906};\\\", \\\"{x:1530,y:769,t:1527271898923};\\\", \\\"{x:1527,y:780,t:1527271898940};\\\", \\\"{x:1525,y:786,t:1527271898955};\\\", \\\"{x:1522,y:791,t:1527271898973};\\\", \\\"{x:1519,y:796,t:1527271898989};\\\", \\\"{x:1505,y:815,t:1527271899006};\\\", \\\"{x:1496,y:834,t:1527271899022};\\\", \\\"{x:1490,y:853,t:1527271899040};\\\", \\\"{x:1488,y:864,t:1527271899056};\\\", \\\"{x:1486,y:872,t:1527271899073};\\\", \\\"{x:1485,y:877,t:1527271899090};\\\", \\\"{x:1485,y:881,t:1527271899107};\\\", \\\"{x:1484,y:884,t:1527271899123};\\\", \\\"{x:1483,y:886,t:1527271899140};\\\", \\\"{x:1482,y:888,t:1527271899157};\\\", \\\"{x:1481,y:888,t:1527271899335};\\\", \\\"{x:1481,y:887,t:1527271899470};\\\", \\\"{x:1481,y:886,t:1527271899478};\\\", \\\"{x:1481,y:885,t:1527271899489};\\\", \\\"{x:1481,y:884,t:1527271899507};\\\", \\\"{x:1481,y:883,t:1527271899523};\\\", \\\"{x:1481,y:882,t:1527271899540};\\\", \\\"{x:1481,y:881,t:1527271899566};\\\", \\\"{x:1481,y:880,t:1527271899583};\\\", \\\"{x:1481,y:879,t:1527271899639};\\\", \\\"{x:1481,y:877,t:1527271899663};\\\", \\\"{x:1481,y:875,t:1527271899686};\\\", \\\"{x:1479,y:874,t:1527271899695};\\\", \\\"{x:1479,y:873,t:1527271899711};\\\", \\\"{x:1479,y:871,t:1527271899724};\\\", \\\"{x:1478,y:868,t:1527271899740};\\\", \\\"{x:1477,y:866,t:1527271899756};\\\", \\\"{x:1476,y:863,t:1527271899774};\\\", \\\"{x:1476,y:861,t:1527271899790};\\\", \\\"{x:1475,y:859,t:1527271899807};\\\", \\\"{x:1475,y:858,t:1527271899830};\\\", \\\"{x:1475,y:857,t:1527271899854};\\\", \\\"{x:1475,y:856,t:1527271899862};\\\", \\\"{x:1474,y:855,t:1527271899886};\\\", \\\"{x:1474,y:854,t:1527271900047};\\\", \\\"{x:1474,y:853,t:1527271900095};\\\", \\\"{x:1474,y:852,t:1527271900310};\\\", \\\"{x:1474,y:851,t:1527271900324};\\\", \\\"{x:1474,y:850,t:1527271900375};\\\", \\\"{x:1474,y:849,t:1527271900422};\\\", \\\"{x:1474,y:848,t:1527271900463};\\\", \\\"{x:1469,y:847,t:1527271901982};\\\", \\\"{x:1464,y:847,t:1527271901992};\\\", \\\"{x:1458,y:847,t:1527271902009};\\\", \\\"{x:1448,y:847,t:1527271902025};\\\", \\\"{x:1437,y:845,t:1527271902042};\\\", \\\"{x:1427,y:845,t:1527271902059};\\\", \\\"{x:1420,y:844,t:1527271902075};\\\", \\\"{x:1415,y:844,t:1527271902092};\\\", \\\"{x:1408,y:844,t:1527271902109};\\\", \\\"{x:1401,y:844,t:1527271902125};\\\", \\\"{x:1394,y:844,t:1527271902142};\\\", \\\"{x:1384,y:844,t:1527271902158};\\\", \\\"{x:1380,y:844,t:1527271902175};\\\", \\\"{x:1370,y:844,t:1527271902192};\\\", \\\"{x:1350,y:843,t:1527271902209};\\\", \\\"{x:1326,y:842,t:1527271902225};\\\", \\\"{x:1298,y:842,t:1527271902242};\\\", \\\"{x:1270,y:842,t:1527271902259};\\\", \\\"{x:1245,y:842,t:1527271902274};\\\", \\\"{x:1222,y:842,t:1527271902292};\\\", \\\"{x:1211,y:841,t:1527271902309};\\\", \\\"{x:1202,y:840,t:1527271902325};\\\", \\\"{x:1198,y:839,t:1527271902342};\\\", \\\"{x:1197,y:839,t:1527271902359};\\\", \\\"{x:1196,y:839,t:1527271902478};\\\", \\\"{x:1194,y:839,t:1527271902494};\\\", \\\"{x:1191,y:839,t:1527271902508};\\\", \\\"{x:1180,y:839,t:1527271902526};\\\", \\\"{x:1165,y:839,t:1527271902542};\\\", \\\"{x:1146,y:839,t:1527271902559};\\\", \\\"{x:1115,y:837,t:1527271902576};\\\", \\\"{x:1070,y:835,t:1527271902591};\\\", \\\"{x:1013,y:826,t:1527271902609};\\\", \\\"{x:966,y:820,t:1527271902626};\\\", \\\"{x:915,y:812,t:1527271902642};\\\", \\\"{x:864,y:804,t:1527271902659};\\\", \\\"{x:816,y:797,t:1527271902676};\\\", \\\"{x:791,y:790,t:1527271902691};\\\", \\\"{x:757,y:779,t:1527271902709};\\\", \\\"{x:732,y:777,t:1527271902725};\\\", \\\"{x:706,y:774,t:1527271902742};\\\", \\\"{x:674,y:773,t:1527271902759};\\\", \\\"{x:651,y:773,t:1527271902776};\\\", \\\"{x:627,y:773,t:1527271902792};\\\", \\\"{x:608,y:773,t:1527271902809};\\\", \\\"{x:590,y:772,t:1527271902826};\\\", \\\"{x:571,y:772,t:1527271902842};\\\", \\\"{x:559,y:770,t:1527271902858};\\\", \\\"{x:556,y:769,t:1527271902876};\\\", \\\"{x:552,y:768,t:1527271902893};\\\", \\\"{x:549,y:768,t:1527271902909};\\\", \\\"{x:549,y:764,t:1527271904047};\\\", \\\"{x:555,y:749,t:1527271904060};\\\", \\\"{x:568,y:719,t:1527271904077};\\\", \\\"{x:578,y:691,t:1527271904093};\\\", \\\"{x:593,y:661,t:1527271904111};\\\", \\\"{x:602,y:639,t:1527271904127};\\\", \\\"{x:607,y:627,t:1527271904143};\\\", \\\"{x:610,y:621,t:1527271904160};\\\", \\\"{x:611,y:617,t:1527271904177};\\\", \\\"{x:611,y:615,t:1527271904194};\\\", \\\"{x:611,y:614,t:1527271904318};\\\", \\\"{x:610,y:614,t:1527271904329};\\\", \\\"{x:607,y:617,t:1527271904345};\\\", \\\"{x:603,y:622,t:1527271904362};\\\", \\\"{x:594,y:632,t:1527271904379};\\\", \\\"{x:586,y:641,t:1527271904395};\\\", \\\"{x:572,y:652,t:1527271904412};\\\", \\\"{x:557,y:664,t:1527271904428};\\\", \\\"{x:539,y:679,t:1527271904445};\\\", \\\"{x:525,y:695,t:1527271904462};\\\", \\\"{x:519,y:702,t:1527271904479};\\\", \\\"{x:510,y:714,t:1527271904496};\\\", \\\"{x:500,y:726,t:1527271904512};\\\", \\\"{x:494,y:737,t:1527271904529};\\\", \\\"{x:490,y:748,t:1527271904545};\\\", \\\"{x:485,y:756,t:1527271904562};\\\", \\\"{x:482,y:759,t:1527271904579};\\\", \\\"{x:479,y:762,t:1527271904596};\\\", \\\"{x:477,y:764,t:1527271904612};\\\", \\\"{x:477,y:765,t:1527271904655};\\\", \\\"{x:477,y:758,t:1527271904750};\\\", \\\"{x:477,y:747,t:1527271904763};\\\", \\\"{x:477,y:734,t:1527271904779};\\\", \\\"{x:477,y:726,t:1527271904796};\\\", \\\"{x:476,y:719,t:1527271904813};\\\", \\\"{x:475,y:714,t:1527271904829};\\\", \\\"{x:475,y:710,t:1527271904846};\\\", \\\"{x:487,y:709,t:1527271909719};\\\", \\\"{x:542,y:709,t:1527271909733};\\\", \\\"{x:822,y:704,t:1527271909751};\\\", \\\"{x:1095,y:704,t:1527271909767};\\\", \\\"{x:1362,y:704,t:1527271909783};\\\", \\\"{x:1636,y:699,t:1527271909800};\\\", \\\"{x:1892,y:678,t:1527271909816};\\\", \\\"{x:1919,y:652,t:1527271909833};\\\", \\\"{x:1919,y:644,t:1527271909850};\\\", \\\"{x:1919,y:641,t:1527271909865};\\\", \\\"{x:1919,y:636,t:1527271909883};\\\", \\\"{x:1919,y:635,t:1527271909900};\\\", \\\"{x:1919,y:633,t:1527271909958};\\\", \\\"{x:1919,y:628,t:1527271909966};\\\", \\\"{x:1906,y:617,t:1527271909983};\\\", \\\"{x:1894,y:611,t:1527271910000};\\\", \\\"{x:1877,y:605,t:1527271910016};\\\", \\\"{x:1858,y:599,t:1527271910033};\\\", \\\"{x:1832,y:593,t:1527271910050};\\\", \\\"{x:1804,y:584,t:1527271910067};\\\", \\\"{x:1771,y:574,t:1527271910083};\\\", \\\"{x:1737,y:564,t:1527271910101};\\\", \\\"{x:1705,y:552,t:1527271910117};\\\", \\\"{x:1684,y:543,t:1527271910134};\\\", \\\"{x:1659,y:529,t:1527271910151};\\\", \\\"{x:1650,y:523,t:1527271910166};\\\", \\\"{x:1646,y:517,t:1527271910184};\\\", \\\"{x:1641,y:510,t:1527271910200};\\\", \\\"{x:1640,y:507,t:1527271910218};\\\", \\\"{x:1637,y:503,t:1527271910235};\\\", \\\"{x:1634,y:499,t:1527271910250};\\\", \\\"{x:1632,y:494,t:1527271910268};\\\", \\\"{x:1629,y:489,t:1527271910285};\\\", \\\"{x:1626,y:485,t:1527271910301};\\\", \\\"{x:1625,y:481,t:1527271910317};\\\", \\\"{x:1624,y:480,t:1527271910334};\\\", \\\"{x:1624,y:479,t:1527271910382};\\\", \\\"{x:1624,y:478,t:1527271910398};\\\", \\\"{x:1623,y:477,t:1527271910407};\\\", \\\"{x:1623,y:476,t:1527271910418};\\\", \\\"{x:1622,y:474,t:1527271910435};\\\", \\\"{x:1620,y:469,t:1527271910450};\\\", \\\"{x:1619,y:465,t:1527271910467};\\\", \\\"{x:1619,y:460,t:1527271910484};\\\", \\\"{x:1616,y:453,t:1527271910500};\\\", \\\"{x:1615,y:447,t:1527271910517};\\\", \\\"{x:1613,y:440,t:1527271910534};\\\", \\\"{x:1613,y:439,t:1527271910557};\\\", \\\"{x:1612,y:438,t:1527271911303};\\\", \\\"{x:1610,y:436,t:1527271911318};\\\", \\\"{x:1609,y:435,t:1527271911336};\\\", \\\"{x:1608,y:431,t:1527271911352};\\\", \\\"{x:1606,y:430,t:1527271911369};\\\", \\\"{x:1606,y:428,t:1527271911386};\\\", \\\"{x:1606,y:427,t:1527271911407};\\\", \\\"{x:1605,y:425,t:1527271911423};\\\", \\\"{x:1605,y:424,t:1527271911446};\\\", \\\"{x:1604,y:423,t:1527271911487};\\\", \\\"{x:1589,y:434,t:1527271912631};\\\", \\\"{x:1545,y:460,t:1527271912638};\\\", \\\"{x:1496,y:484,t:1527271912653};\\\", \\\"{x:1284,y:567,t:1527271912670};\\\", \\\"{x:1096,y:618,t:1527271912687};\\\", \\\"{x:888,y:657,t:1527271912704};\\\", \\\"{x:677,y:696,t:1527271912721};\\\", \\\"{x:482,y:744,t:1527271912737};\\\", \\\"{x:272,y:803,t:1527271912754};\\\", \\\"{x:79,y:858,t:1527271912770};\\\", \\\"{x:0,y:902,t:1527271912786};\\\", \\\"{x:0,y:922,t:1527271912804};\\\", \\\"{x:0,y:930,t:1527271912821};\\\", \\\"{x:0,y:933,t:1527271912838};\\\", \\\"{x:0,y:930,t:1527271912903};\\\", \\\"{x:0,y:911,t:1527271912920};\\\", \\\"{x:0,y:891,t:1527271912938};\\\", \\\"{x:0,y:878,t:1527271912954};\\\", \\\"{x:0,y:870,t:1527271912971};\\\", \\\"{x:0,y:865,t:1527271912988};\\\", \\\"{x:0,y:864,t:1527271913003};\\\", \\\"{x:0,y:863,t:1527271913021};\\\", \\\"{x:1,y:859,t:1527271913037};\\\", \\\"{x:9,y:845,t:1527271913054};\\\", \\\"{x:19,y:835,t:1527271913070};\\\", \\\"{x:43,y:823,t:1527271913087};\\\", \\\"{x:103,y:802,t:1527271913104};\\\", \\\"{x:198,y:782,t:1527271913120};\\\", \\\"{x:303,y:768,t:1527271913137};\\\", \\\"{x:423,y:750,t:1527271913154};\\\", \\\"{x:562,y:726,t:1527271913170};\\\", \\\"{x:700,y:705,t:1527271913187};\\\", \\\"{x:817,y:688,t:1527271913202};\\\", \\\"{x:925,y:674,t:1527271913218};\\\", \\\"{x:980,y:670,t:1527271913236};\\\", \\\"{x:994,y:670,t:1527271913252};\\\", \\\"{x:995,y:670,t:1527271913269};\\\", \\\"{x:990,y:670,t:1527271913350};\\\", \\\"{x:976,y:674,t:1527271913357};\\\", \\\"{x:945,y:683,t:1527271913369};\\\", \\\"{x:884,y:700,t:1527271913386};\\\", \\\"{x:815,y:717,t:1527271913403};\\\", \\\"{x:737,y:732,t:1527271913419};\\\", \\\"{x:644,y:747,t:1527271913436};\\\", \\\"{x:564,y:758,t:1527271913453};\\\", \\\"{x:506,y:765,t:1527271913469};\\\", \\\"{x:459,y:767,t:1527271913485};\\\", \\\"{x:442,y:767,t:1527271913503};\\\", \\\"{x:436,y:769,t:1527271913519};\\\", \\\"{x:435,y:769,t:1527271913536};\\\", \\\"{x:434,y:769,t:1527271913630};\\\", \\\"{x:434,y:766,t:1527271913638};\\\", \\\"{x:434,y:762,t:1527271913652};\\\", \\\"{x:438,y:754,t:1527271913669};\\\", \\\"{x:443,y:744,t:1527271913686};\\\", \\\"{x:449,y:734,t:1527271913703};\\\", \\\"{x:453,y:728,t:1527271913720};\\\", \\\"{x:455,y:726,t:1527271913736};\\\", \\\"{x:457,y:722,t:1527271913752};\\\", \\\"{x:458,y:719,t:1527271913769};\\\", \\\"{x:459,y:719,t:1527271913785};\\\", \\\"{x:459,y:718,t:1527271913854};\\\" ] }, { \\\"rt\\\": 128471, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 424184, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -I -U -F -H -F -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:470,y:714,t:1527271916783};\\\", \\\"{x:519,y:701,t:1527271916790};\\\", \\\"{x:588,y:688,t:1527271916806};\\\", \\\"{x:806,y:668,t:1527271916822};\\\", \\\"{x:960,y:658,t:1527271916838};\\\", \\\"{x:1093,y:658,t:1527271916855};\\\", \\\"{x:1184,y:658,t:1527271916872};\\\", \\\"{x:1220,y:658,t:1527271916889};\\\", \\\"{x:1237,y:660,t:1527271916905};\\\", \\\"{x:1240,y:661,t:1527271916922};\\\", \\\"{x:1240,y:662,t:1527271917054};\\\", \\\"{x:1237,y:668,t:1527271917061};\\\", \\\"{x:1220,y:675,t:1527271917072};\\\", \\\"{x:1165,y:699,t:1527271917089};\\\", \\\"{x:1090,y:721,t:1527271917105};\\\", \\\"{x:1020,y:733,t:1527271917123};\\\", \\\"{x:984,y:735,t:1527271917139};\\\", \\\"{x:970,y:735,t:1527271917156};\\\", \\\"{x:965,y:735,t:1527271917172};\\\", \\\"{x:960,y:735,t:1527271917189};\\\", \\\"{x:957,y:735,t:1527271917205};\\\", \\\"{x:955,y:735,t:1527271917222};\\\", \\\"{x:957,y:735,t:1527271921761};\\\", \\\"{x:960,y:736,t:1527271921769};\\\", \\\"{x:961,y:736,t:1527271921785};\\\", \\\"{x:964,y:736,t:1527271921797};\\\", \\\"{x:968,y:736,t:1527271921813};\\\", \\\"{x:969,y:736,t:1527271921833};\\\", \\\"{x:971,y:736,t:1527271921848};\\\", \\\"{x:980,y:736,t:1527271921864};\\\", \\\"{x:996,y:739,t:1527271921881};\\\", \\\"{x:1006,y:744,t:1527271921897};\\\", \\\"{x:1007,y:745,t:1527271922147};\\\", \\\"{x:1007,y:746,t:1527271922165};\\\", \\\"{x:1009,y:747,t:1527271922182};\\\", \\\"{x:1010,y:748,t:1527271922202};\\\", \\\"{x:1011,y:750,t:1527271922218};\\\", \\\"{x:1012,y:750,t:1527271922242};\\\", \\\"{x:1013,y:751,t:1527271922250};\\\", \\\"{x:1014,y:752,t:1527271922264};\\\", \\\"{x:1018,y:754,t:1527271922282};\\\", \\\"{x:1020,y:755,t:1527271922298};\\\", \\\"{x:1025,y:759,t:1527271922314};\\\", \\\"{x:1033,y:764,t:1527271922331};\\\", \\\"{x:1036,y:765,t:1527271922347};\\\", \\\"{x:1037,y:766,t:1527271922365};\\\", \\\"{x:1038,y:766,t:1527271922410};\\\", \\\"{x:1039,y:767,t:1527271922586};\\\", \\\"{x:1041,y:769,t:1527271922599};\\\", \\\"{x:1041,y:770,t:1527271922615};\\\", \\\"{x:1045,y:775,t:1527271922632};\\\", \\\"{x:1050,y:780,t:1527271922649};\\\", \\\"{x:1056,y:787,t:1527271922664};\\\", \\\"{x:1065,y:794,t:1527271922682};\\\", \\\"{x:1070,y:797,t:1527271922698};\\\", \\\"{x:1076,y:801,t:1527271922715};\\\", \\\"{x:1079,y:804,t:1527271922732};\\\", \\\"{x:1084,y:807,t:1527271922748};\\\", \\\"{x:1088,y:809,t:1527271922765};\\\", \\\"{x:1092,y:812,t:1527271922782};\\\", \\\"{x:1103,y:815,t:1527271922799};\\\", \\\"{x:1124,y:821,t:1527271922814};\\\", \\\"{x:1154,y:827,t:1527271922831};\\\", \\\"{x:1184,y:831,t:1527271922849};\\\", \\\"{x:1210,y:835,t:1527271922864};\\\", \\\"{x:1238,y:839,t:1527271922882};\\\", \\\"{x:1244,y:839,t:1527271922898};\\\", \\\"{x:1245,y:839,t:1527271922915};\\\", \\\"{x:1244,y:839,t:1527271923273};\\\", \\\"{x:1243,y:839,t:1527271923297};\\\", \\\"{x:1242,y:839,t:1527271923554};\\\", \\\"{x:1241,y:839,t:1527271923566};\\\", \\\"{x:1240,y:839,t:1527271923582};\\\", \\\"{x:1239,y:838,t:1527271923599};\\\", \\\"{x:1238,y:838,t:1527271923615};\\\", \\\"{x:1237,y:837,t:1527271923632};\\\", \\\"{x:1235,y:836,t:1527271923648};\\\", \\\"{x:1234,y:835,t:1527271923681};\\\", \\\"{x:1233,y:835,t:1527271923810};\\\", \\\"{x:1232,y:835,t:1527271923818};\\\", \\\"{x:1231,y:835,t:1527271923833};\\\", \\\"{x:1230,y:833,t:1527271923850};\\\", \\\"{x:1229,y:833,t:1527271923890};\\\", \\\"{x:1228,y:833,t:1527271923899};\\\", \\\"{x:1227,y:832,t:1527271923921};\\\", \\\"{x:1225,y:831,t:1527271923978};\\\", \\\"{x:1222,y:831,t:1527271924049};\\\", \\\"{x:1222,y:830,t:1527271924090};\\\", \\\"{x:1221,y:830,t:1527271925626};\\\", \\\"{x:1223,y:829,t:1527271930986};\\\", \\\"{x:1229,y:829,t:1527271930993};\\\", \\\"{x:1233,y:830,t:1527271931006};\\\", \\\"{x:1237,y:831,t:1527271931023};\\\", \\\"{x:1238,y:832,t:1527271931039};\\\", \\\"{x:1240,y:833,t:1527271931055};\\\", \\\"{x:1244,y:835,t:1527271931072};\\\", \\\"{x:1248,y:836,t:1527271931088};\\\", \\\"{x:1250,y:837,t:1527271931105};\\\", \\\"{x:1251,y:837,t:1527271931122};\\\", \\\"{x:1252,y:838,t:1527271931138};\\\", \\\"{x:1254,y:839,t:1527271931156};\\\", \\\"{x:1257,y:840,t:1527271931172};\\\", \\\"{x:1259,y:841,t:1527271931189};\\\", \\\"{x:1260,y:841,t:1527271931205};\\\", \\\"{x:1261,y:842,t:1527271931222};\\\", \\\"{x:1266,y:844,t:1527271931239};\\\", \\\"{x:1280,y:844,t:1527271931255};\\\", \\\"{x:1298,y:841,t:1527271931273};\\\", \\\"{x:1301,y:839,t:1527271931290};\\\", \\\"{x:1302,y:839,t:1527271931305};\\\", \\\"{x:1302,y:838,t:1527271931393};\\\", \\\"{x:1302,y:837,t:1527271931417};\\\", \\\"{x:1301,y:836,t:1527271931433};\\\", \\\"{x:1298,y:835,t:1527271931449};\\\", \\\"{x:1296,y:834,t:1527271931466};\\\", \\\"{x:1295,y:834,t:1527271931481};\\\", \\\"{x:1293,y:833,t:1527271931489};\\\", \\\"{x:1292,y:832,t:1527271931505};\\\", \\\"{x:1290,y:832,t:1527271931522};\\\", \\\"{x:1289,y:831,t:1527271931540};\\\", \\\"{x:1288,y:831,t:1527271931556};\\\", \\\"{x:1286,y:830,t:1527271931573};\\\", \\\"{x:1285,y:829,t:1527271931607};\\\", \\\"{x:1286,y:829,t:1527271933289};\\\", \\\"{x:1287,y:829,t:1527271933313};\\\", \\\"{x:1288,y:829,t:1527271933330};\\\", \\\"{x:1288,y:830,t:1527271933369};\\\", \\\"{x:1289,y:830,t:1527271935929};\\\", \\\"{x:1290,y:831,t:1527271935994};\\\", \\\"{x:1294,y:828,t:1527271971066};\\\", \\\"{x:1300,y:778,t:1527271971077};\\\", \\\"{x:1329,y:660,t:1527271971093};\\\", \\\"{x:1341,y:618,t:1527271971109};\\\", \\\"{x:1341,y:606,t:1527271971126};\\\", \\\"{x:1339,y:590,t:1527271971143};\\\", \\\"{x:1338,y:580,t:1527271971159};\\\", \\\"{x:1337,y:571,t:1527271971176};\\\", \\\"{x:1332,y:550,t:1527271971193};\\\", \\\"{x:1324,y:533,t:1527271971209};\\\", \\\"{x:1319,y:524,t:1527271971226};\\\", \\\"{x:1319,y:523,t:1527271971514};\\\", \\\"{x:1319,y:521,t:1527271971526};\\\", \\\"{x:1322,y:517,t:1527271971544};\\\", \\\"{x:1323,y:516,t:1527271971560};\\\", \\\"{x:1323,y:514,t:1527271971641};\\\", \\\"{x:1324,y:510,t:1527271971648};\\\", \\\"{x:1325,y:509,t:1527271971660};\\\", \\\"{x:1327,y:507,t:1527271971676};\\\", \\\"{x:1327,y:506,t:1527271971720};\\\", \\\"{x:1329,y:506,t:1527271971745};\\\", \\\"{x:1333,y:506,t:1527271971809};\\\", \\\"{x:1339,y:506,t:1527271971817};\\\", \\\"{x:1346,y:509,t:1527271971827};\\\", \\\"{x:1361,y:518,t:1527271971843};\\\", \\\"{x:1373,y:525,t:1527271971860};\\\", \\\"{x:1385,y:535,t:1527271971877};\\\", \\\"{x:1406,y:547,t:1527271971893};\\\", \\\"{x:1429,y:565,t:1527271971911};\\\", \\\"{x:1451,y:579,t:1527271971927};\\\", \\\"{x:1466,y:591,t:1527271971943};\\\", \\\"{x:1484,y:608,t:1527271971960};\\\", \\\"{x:1495,y:619,t:1527271971977};\\\", \\\"{x:1508,y:635,t:1527271971993};\\\", \\\"{x:1525,y:653,t:1527271972010};\\\", \\\"{x:1541,y:672,t:1527271972026};\\\", \\\"{x:1551,y:683,t:1527271972043};\\\", \\\"{x:1558,y:693,t:1527271972061};\\\", \\\"{x:1560,y:696,t:1527271972077};\\\", \\\"{x:1562,y:700,t:1527271972093};\\\", \\\"{x:1562,y:703,t:1527271972110};\\\", \\\"{x:1560,y:706,t:1527271972127};\\\", \\\"{x:1554,y:707,t:1527271972144};\\\", \\\"{x:1548,y:707,t:1527271972160};\\\", \\\"{x:1536,y:706,t:1527271972176};\\\", \\\"{x:1522,y:699,t:1527271972194};\\\", \\\"{x:1508,y:693,t:1527271972210};\\\", \\\"{x:1494,y:685,t:1527271972227};\\\", \\\"{x:1477,y:675,t:1527271972244};\\\", \\\"{x:1456,y:658,t:1527271972260};\\\", \\\"{x:1433,y:637,t:1527271972277};\\\", \\\"{x:1411,y:616,t:1527271972294};\\\", \\\"{x:1396,y:600,t:1527271972310};\\\", \\\"{x:1386,y:588,t:1527271972327};\\\", \\\"{x:1382,y:580,t:1527271972344};\\\", \\\"{x:1382,y:578,t:1527271972360};\\\", \\\"{x:1380,y:575,t:1527271972377};\\\", \\\"{x:1380,y:574,t:1527271972394};\\\", \\\"{x:1380,y:573,t:1527271972410};\\\", \\\"{x:1380,y:571,t:1527271972427};\\\", \\\"{x:1380,y:568,t:1527271972444};\\\", \\\"{x:1380,y:565,t:1527271972460};\\\", \\\"{x:1379,y:561,t:1527271972477};\\\", \\\"{x:1377,y:558,t:1527271972495};\\\", \\\"{x:1374,y:553,t:1527271972510};\\\", \\\"{x:1370,y:545,t:1527271972527};\\\", \\\"{x:1360,y:528,t:1527271972544};\\\", \\\"{x:1345,y:510,t:1527271972560};\\\", \\\"{x:1332,y:495,t:1527271972577};\\\", \\\"{x:1323,y:484,t:1527271972594};\\\", \\\"{x:1320,y:478,t:1527271972611};\\\", \\\"{x:1319,y:475,t:1527271972627};\\\", \\\"{x:1318,y:475,t:1527271972644};\\\", \\\"{x:1317,y:475,t:1527271973240};\\\", \\\"{x:1316,y:476,t:1527271973249};\\\", \\\"{x:1316,y:478,t:1527271973261};\\\", \\\"{x:1316,y:481,t:1527271973278};\\\", \\\"{x:1315,y:484,t:1527271973294};\\\", \\\"{x:1315,y:485,t:1527271973312};\\\", \\\"{x:1314,y:487,t:1527271973328};\\\", \\\"{x:1313,y:488,t:1527271973344};\\\", \\\"{x:1313,y:490,t:1527271973409};\\\", \\\"{x:1313,y:491,t:1527271973610};\\\", \\\"{x:1313,y:494,t:1527271974840};\\\", \\\"{x:1312,y:498,t:1527271974848};\\\", \\\"{x:1312,y:503,t:1527271974863};\\\", \\\"{x:1312,y:515,t:1527271974879};\\\", \\\"{x:1312,y:534,t:1527271974896};\\\", \\\"{x:1312,y:549,t:1527271974912};\\\", \\\"{x:1314,y:567,t:1527271974929};\\\", \\\"{x:1319,y:586,t:1527271974946};\\\", \\\"{x:1321,y:601,t:1527271974963};\\\", \\\"{x:1323,y:617,t:1527271974979};\\\", \\\"{x:1325,y:628,t:1527271974996};\\\", \\\"{x:1326,y:638,t:1527271975013};\\\", \\\"{x:1327,y:642,t:1527271975029};\\\", \\\"{x:1327,y:644,t:1527271975046};\\\", \\\"{x:1327,y:645,t:1527271975144};\\\", \\\"{x:1326,y:647,t:1527271975160};\\\", \\\"{x:1325,y:648,t:1527271975168};\\\", \\\"{x:1325,y:649,t:1527271975179};\\\", \\\"{x:1322,y:654,t:1527271975196};\\\", \\\"{x:1318,y:658,t:1527271975213};\\\", \\\"{x:1316,y:661,t:1527271975229};\\\", \\\"{x:1313,y:664,t:1527271975246};\\\", \\\"{x:1313,y:669,t:1527271975263};\\\", \\\"{x:1313,y:672,t:1527271975281};\\\", \\\"{x:1313,y:674,t:1527271975296};\\\", \\\"{x:1313,y:675,t:1527271975313};\\\", \\\"{x:1313,y:678,t:1527271975330};\\\", \\\"{x:1313,y:680,t:1527271975345};\\\", \\\"{x:1312,y:683,t:1527271975363};\\\", \\\"{x:1312,y:687,t:1527271975380};\\\", \\\"{x:1310,y:692,t:1527271975396};\\\", \\\"{x:1308,y:697,t:1527271975413};\\\", \\\"{x:1307,y:702,t:1527271975430};\\\", \\\"{x:1306,y:708,t:1527271975446};\\\", \\\"{x:1305,y:712,t:1527271975463};\\\", \\\"{x:1303,y:722,t:1527271975480};\\\", \\\"{x:1303,y:726,t:1527271975496};\\\", \\\"{x:1303,y:732,t:1527271975513};\\\", \\\"{x:1303,y:734,t:1527271975530};\\\", \\\"{x:1303,y:738,t:1527271975547};\\\", \\\"{x:1304,y:741,t:1527271975563};\\\", \\\"{x:1304,y:743,t:1527271975580};\\\", \\\"{x:1304,y:745,t:1527271975598};\\\", \\\"{x:1304,y:747,t:1527271975682};\\\", \\\"{x:1306,y:750,t:1527271975698};\\\", \\\"{x:1306,y:754,t:1527271975713};\\\", \\\"{x:1307,y:757,t:1527271975731};\\\", \\\"{x:1308,y:759,t:1527271975747};\\\", \\\"{x:1309,y:761,t:1527271975764};\\\", \\\"{x:1309,y:767,t:1527271975906};\\\", \\\"{x:1309,y:772,t:1527271975914};\\\", \\\"{x:1320,y:790,t:1527271975930};\\\", \\\"{x:1323,y:804,t:1527271975948};\\\", \\\"{x:1325,y:809,t:1527271975964};\\\", \\\"{x:1325,y:811,t:1527271975980};\\\", \\\"{x:1325,y:812,t:1527271975997};\\\", \\\"{x:1325,y:814,t:1527271976014};\\\", \\\"{x:1324,y:814,t:1527271976030};\\\", \\\"{x:1324,y:815,t:1527271976047};\\\", \\\"{x:1324,y:818,t:1527271976063};\\\", \\\"{x:1323,y:820,t:1527271976080};\\\", \\\"{x:1322,y:823,t:1527271976097};\\\", \\\"{x:1321,y:823,t:1527271976120};\\\", \\\"{x:1321,y:824,t:1527271976130};\\\", \\\"{x:1321,y:826,t:1527271976201};\\\", \\\"{x:1321,y:827,t:1527271976214};\\\", \\\"{x:1321,y:829,t:1527271976230};\\\", \\\"{x:1321,y:831,t:1527271976247};\\\", \\\"{x:1321,y:834,t:1527271976265};\\\", \\\"{x:1321,y:836,t:1527271976280};\\\", \\\"{x:1321,y:839,t:1527271976297};\\\", \\\"{x:1321,y:844,t:1527271976314};\\\", \\\"{x:1321,y:851,t:1527271976330};\\\", \\\"{x:1322,y:856,t:1527271976347};\\\", \\\"{x:1323,y:860,t:1527271976364};\\\", \\\"{x:1323,y:861,t:1527271976381};\\\", \\\"{x:1323,y:863,t:1527271976397};\\\", \\\"{x:1323,y:864,t:1527271976416};\\\", \\\"{x:1323,y:865,t:1527271976431};\\\", \\\"{x:1323,y:866,t:1527271976447};\\\", \\\"{x:1323,y:872,t:1527271976464};\\\", \\\"{x:1323,y:876,t:1527271976481};\\\", \\\"{x:1323,y:880,t:1527271976497};\\\", \\\"{x:1322,y:884,t:1527271976514};\\\", \\\"{x:1319,y:887,t:1527271976532};\\\", \\\"{x:1319,y:888,t:1527271976547};\\\", \\\"{x:1318,y:889,t:1527271976625};\\\", \\\"{x:1317,y:889,t:1527271976680};\\\", \\\"{x:1315,y:890,t:1527271976698};\\\", \\\"{x:1315,y:891,t:1527271976715};\\\", \\\"{x:1314,y:897,t:1527271976731};\\\", \\\"{x:1314,y:905,t:1527271976748};\\\", \\\"{x:1314,y:910,t:1527271976764};\\\", \\\"{x:1314,y:911,t:1527271976781};\\\", \\\"{x:1314,y:914,t:1527271976798};\\\", \\\"{x:1314,y:915,t:1527271976888};\\\", \\\"{x:1316,y:916,t:1527271976898};\\\", \\\"{x:1317,y:919,t:1527271976914};\\\", \\\"{x:1319,y:920,t:1527271976931};\\\", \\\"{x:1319,y:923,t:1527271976948};\\\", \\\"{x:1319,y:924,t:1527271976976};\\\", \\\"{x:1319,y:926,t:1527271976984};\\\", \\\"{x:1319,y:927,t:1527271976997};\\\", \\\"{x:1319,y:935,t:1527271977014};\\\", \\\"{x:1319,y:943,t:1527271977031};\\\", \\\"{x:1323,y:957,t:1527271977048};\\\", \\\"{x:1324,y:962,t:1527271977064};\\\", \\\"{x:1325,y:965,t:1527271977081};\\\", \\\"{x:1326,y:968,t:1527271977098};\\\", \\\"{x:1327,y:969,t:1527271977116};\\\", \\\"{x:1327,y:970,t:1527271977144};\\\", \\\"{x:1327,y:971,t:1527271977160};\\\", \\\"{x:1327,y:972,t:1527271977234};\\\", \\\"{x:1326,y:972,t:1527271977248};\\\", \\\"{x:1323,y:972,t:1527271977265};\\\", \\\"{x:1320,y:972,t:1527271977282};\\\", \\\"{x:1319,y:971,t:1527271977513};\\\", \\\"{x:1318,y:971,t:1527271977603};\\\", \\\"{x:1318,y:970,t:1527271977617};\\\", \\\"{x:1316,y:969,t:1527271977633};\\\", \\\"{x:1315,y:969,t:1527271977738};\\\", \\\"{x:1313,y:968,t:1527271977749};\\\", \\\"{x:1311,y:967,t:1527271977766};\\\", \\\"{x:1310,y:966,t:1527271994660};\\\", \\\"{x:1313,y:959,t:1527271994667};\\\", \\\"{x:1338,y:942,t:1527271994685};\\\", \\\"{x:1359,y:933,t:1527271994702};\\\", \\\"{x:1372,y:927,t:1527271994718};\\\", \\\"{x:1381,y:924,t:1527271994735};\\\", \\\"{x:1387,y:921,t:1527271994752};\\\", \\\"{x:1391,y:919,t:1527271994769};\\\", \\\"{x:1394,y:916,t:1527271994785};\\\", \\\"{x:1403,y:909,t:1527271994802};\\\", \\\"{x:1408,y:906,t:1527271994819};\\\", \\\"{x:1411,y:904,t:1527271994836};\\\", \\\"{x:1416,y:901,t:1527271994852};\\\", \\\"{x:1423,y:897,t:1527271994868};\\\", \\\"{x:1427,y:895,t:1527271994886};\\\", \\\"{x:1430,y:893,t:1527271994902};\\\", \\\"{x:1430,y:892,t:1527271994924};\\\", \\\"{x:1431,y:891,t:1527271994941};\\\", \\\"{x:1431,y:890,t:1527271994957};\\\", \\\"{x:1434,y:888,t:1527271994970};\\\", \\\"{x:1437,y:884,t:1527271994985};\\\", \\\"{x:1438,y:882,t:1527271995002};\\\", \\\"{x:1439,y:880,t:1527271995019};\\\", \\\"{x:1441,y:878,t:1527271995036};\\\", \\\"{x:1444,y:873,t:1527271995052};\\\", \\\"{x:1446,y:871,t:1527271995069};\\\", \\\"{x:1447,y:869,t:1527271995086};\\\", \\\"{x:1447,y:868,t:1527271995102};\\\", \\\"{x:1448,y:867,t:1527271995119};\\\", \\\"{x:1448,y:866,t:1527271995141};\\\", \\\"{x:1449,y:866,t:1527271995277};\\\", \\\"{x:1449,y:864,t:1527271995341};\\\", \\\"{x:1449,y:862,t:1527271995352};\\\", \\\"{x:1450,y:860,t:1527271995370};\\\", \\\"{x:1451,y:859,t:1527271995407};\\\", \\\"{x:1451,y:858,t:1527271995421};\\\", \\\"{x:1451,y:857,t:1527271995436};\\\", \\\"{x:1451,y:856,t:1527271995452};\\\", \\\"{x:1453,y:853,t:1527271995469};\\\", \\\"{x:1453,y:852,t:1527271995487};\\\", \\\"{x:1454,y:851,t:1527271995502};\\\", \\\"{x:1456,y:850,t:1527271995532};\\\", \\\"{x:1456,y:849,t:1527271995541};\\\", \\\"{x:1457,y:848,t:1527271995557};\\\", \\\"{x:1459,y:845,t:1527271995570};\\\", \\\"{x:1460,y:843,t:1527271995586};\\\", \\\"{x:1461,y:843,t:1527271995604};\\\", \\\"{x:1462,y:841,t:1527271995620};\\\", \\\"{x:1463,y:840,t:1527271995636};\\\", \\\"{x:1464,y:840,t:1527271995669};\\\", \\\"{x:1466,y:837,t:1527271995687};\\\", \\\"{x:1466,y:836,t:1527271995703};\\\", \\\"{x:1466,y:835,t:1527271995732};\\\", \\\"{x:1467,y:835,t:1527271995747};\\\", \\\"{x:1467,y:834,t:1527271995764};\\\", \\\"{x:1469,y:833,t:1527271995916};\\\", \\\"{x:1470,y:833,t:1527271996509};\\\", \\\"{x:1471,y:833,t:1527271996520};\\\", \\\"{x:1473,y:833,t:1527271996537};\\\", \\\"{x:1474,y:832,t:1527271996553};\\\", \\\"{x:1474,y:831,t:1527271996570};\\\", \\\"{x:1476,y:831,t:1527271996587};\\\", \\\"{x:1478,y:831,t:1527271996603};\\\", \\\"{x:1479,y:830,t:1527271996619};\\\", \\\"{x:1472,y:830,t:1527272000260};\\\", \\\"{x:1459,y:830,t:1527272000273};\\\", \\\"{x:1433,y:828,t:1527272000290};\\\", \\\"{x:1406,y:824,t:1527272000307};\\\", \\\"{x:1373,y:814,t:1527272000323};\\\", \\\"{x:1337,y:804,t:1527272000340};\\\", \\\"{x:1328,y:801,t:1527272000357};\\\", \\\"{x:1323,y:798,t:1527272000373};\\\", \\\"{x:1323,y:797,t:1527272000516};\\\", \\\"{x:1325,y:794,t:1527272000523};\\\", \\\"{x:1328,y:793,t:1527272000541};\\\", \\\"{x:1331,y:791,t:1527272000557};\\\", \\\"{x:1332,y:790,t:1527272000574};\\\", \\\"{x:1334,y:788,t:1527272000590};\\\", \\\"{x:1336,y:788,t:1527272000607};\\\", \\\"{x:1337,y:788,t:1527272000624};\\\", \\\"{x:1337,y:787,t:1527272000640};\\\", \\\"{x:1338,y:787,t:1527272000708};\\\", \\\"{x:1339,y:787,t:1527272000723};\\\", \\\"{x:1341,y:785,t:1527272000740};\\\", \\\"{x:1342,y:784,t:1527272000819};\\\", \\\"{x:1344,y:783,t:1527272000835};\\\", \\\"{x:1345,y:781,t:1527272000843};\\\", \\\"{x:1346,y:781,t:1527272000857};\\\", \\\"{x:1348,y:780,t:1527272000874};\\\", \\\"{x:1352,y:778,t:1527272000891};\\\", \\\"{x:1354,y:777,t:1527272000907};\\\", \\\"{x:1357,y:775,t:1527272000924};\\\", \\\"{x:1358,y:775,t:1527272001292};\\\", \\\"{x:1362,y:773,t:1527272001309};\\\", \\\"{x:1364,y:771,t:1527272001324};\\\", \\\"{x:1365,y:771,t:1527272001341};\\\", \\\"{x:1368,y:770,t:1527272001358};\\\", \\\"{x:1370,y:768,t:1527272001375};\\\", \\\"{x:1371,y:768,t:1527272001391};\\\", \\\"{x:1371,y:767,t:1527272001408};\\\", \\\"{x:1372,y:767,t:1527272001428};\\\", \\\"{x:1374,y:763,t:1527272005116};\\\", \\\"{x:1378,y:756,t:1527272005128};\\\", \\\"{x:1380,y:751,t:1527272005144};\\\", \\\"{x:1385,y:739,t:1527272005161};\\\", \\\"{x:1394,y:720,t:1527272005179};\\\", \\\"{x:1402,y:700,t:1527272005194};\\\", \\\"{x:1407,y:679,t:1527272005211};\\\", \\\"{x:1416,y:648,t:1527272005227};\\\", \\\"{x:1420,y:633,t:1527272005245};\\\", \\\"{x:1422,y:622,t:1527272005261};\\\", \\\"{x:1423,y:615,t:1527272005278};\\\", \\\"{x:1424,y:612,t:1527272005295};\\\", \\\"{x:1424,y:611,t:1527272005312};\\\", \\\"{x:1424,y:610,t:1527272005388};\\\", \\\"{x:1424,y:609,t:1527272005396};\\\", \\\"{x:1424,y:606,t:1527272005411};\\\", \\\"{x:1423,y:604,t:1527272005428};\\\", \\\"{x:1423,y:600,t:1527272005445};\\\", \\\"{x:1421,y:596,t:1527272005461};\\\", \\\"{x:1420,y:594,t:1527272005478};\\\", \\\"{x:1418,y:592,t:1527272005494};\\\", \\\"{x:1418,y:591,t:1527272005511};\\\", \\\"{x:1417,y:590,t:1527272005548};\\\", \\\"{x:1417,y:588,t:1527272007061};\\\", \\\"{x:1417,y:584,t:1527272007068};\\\", \\\"{x:1417,y:583,t:1527272007079};\\\", \\\"{x:1417,y:570,t:1527272007096};\\\", \\\"{x:1417,y:559,t:1527272007113};\\\", \\\"{x:1417,y:543,t:1527272007129};\\\", \\\"{x:1416,y:526,t:1527272007146};\\\", \\\"{x:1412,y:514,t:1527272007163};\\\", \\\"{x:1410,y:508,t:1527272007179};\\\", \\\"{x:1409,y:503,t:1527272007196};\\\", \\\"{x:1408,y:499,t:1527272007213};\\\", \\\"{x:1406,y:492,t:1527272007230};\\\", \\\"{x:1404,y:488,t:1527272007247};\\\", \\\"{x:1402,y:483,t:1527272007263};\\\", \\\"{x:1402,y:481,t:1527272007280};\\\", \\\"{x:1401,y:478,t:1527272007296};\\\", \\\"{x:1401,y:475,t:1527272007314};\\\", \\\"{x:1401,y:474,t:1527272007331};\\\", \\\"{x:1401,y:473,t:1527272007346};\\\", \\\"{x:1401,y:472,t:1527272007363};\\\", \\\"{x:1401,y:471,t:1527272007412};\\\", \\\"{x:1401,y:470,t:1527272007419};\\\", \\\"{x:1401,y:469,t:1527272007430};\\\", \\\"{x:1401,y:468,t:1527272007447};\\\", \\\"{x:1401,y:466,t:1527272007464};\\\", \\\"{x:1401,y:464,t:1527272007484};\\\", \\\"{x:1401,y:463,t:1527272007556};\\\", \\\"{x:1399,y:464,t:1527272008451};\\\", \\\"{x:1391,y:467,t:1527272008465};\\\", \\\"{x:1384,y:470,t:1527272008481};\\\", \\\"{x:1370,y:475,t:1527272008497};\\\", \\\"{x:1357,y:481,t:1527272008514};\\\", \\\"{x:1352,y:483,t:1527272008532};\\\", \\\"{x:1349,y:484,t:1527272008548};\\\", \\\"{x:1347,y:486,t:1527272008565};\\\", \\\"{x:1346,y:486,t:1527272008582};\\\", \\\"{x:1345,y:488,t:1527272008597};\\\", \\\"{x:1344,y:488,t:1527272008676};\\\", \\\"{x:1343,y:489,t:1527272008684};\\\", \\\"{x:1342,y:491,t:1527272008697};\\\", \\\"{x:1340,y:493,t:1527272008714};\\\", \\\"{x:1338,y:495,t:1527272008732};\\\", \\\"{x:1333,y:500,t:1527272008747};\\\", \\\"{x:1331,y:502,t:1527272008764};\\\", \\\"{x:1329,y:503,t:1527272008782};\\\", \\\"{x:1328,y:505,t:1527272008798};\\\", \\\"{x:1326,y:507,t:1527272008815};\\\", \\\"{x:1322,y:508,t:1527272008832};\\\", \\\"{x:1321,y:510,t:1527272008849};\\\", \\\"{x:1319,y:511,t:1527272008865};\\\", \\\"{x:1317,y:511,t:1527272009053};\\\", \\\"{x:1315,y:511,t:1527272009077};\\\", \\\"{x:1314,y:511,t:1527272009085};\\\", \\\"{x:1313,y:511,t:1527272009100};\\\", \\\"{x:1312,y:511,t:1527272009116};\\\", \\\"{x:1312,y:509,t:1527272009132};\\\", \\\"{x:1312,y:508,t:1527272009149};\\\", \\\"{x:1312,y:507,t:1527272009165};\\\", \\\"{x:1311,y:506,t:1527272009182};\\\", \\\"{x:1311,y:505,t:1527272010348};\\\", \\\"{x:1310,y:505,t:1527272010396};\\\", \\\"{x:1311,y:506,t:1527272011725};\\\", \\\"{x:1313,y:506,t:1527272011860};\\\", \\\"{x:1313,y:508,t:1527272011876};\\\", \\\"{x:1314,y:510,t:1527272011907};\\\", \\\"{x:1316,y:513,t:1527272011917};\\\", \\\"{x:1324,y:520,t:1527272011934};\\\", \\\"{x:1339,y:533,t:1527272011951};\\\", \\\"{x:1361,y:552,t:1527272011967};\\\", \\\"{x:1392,y:584,t:1527272011985};\\\", \\\"{x:1423,y:618,t:1527272012001};\\\", \\\"{x:1457,y:656,t:1527272012018};\\\", \\\"{x:1502,y:689,t:1527272012035};\\\", \\\"{x:1554,y:710,t:1527272012051};\\\", \\\"{x:1623,y:728,t:1527272012068};\\\", \\\"{x:1648,y:733,t:1527272012084};\\\", \\\"{x:1660,y:737,t:1527272012102};\\\", \\\"{x:1661,y:738,t:1527272012118};\\\", \\\"{x:1660,y:737,t:1527272012340};\\\", \\\"{x:1655,y:735,t:1527272012352};\\\", \\\"{x:1641,y:730,t:1527272012368};\\\", \\\"{x:1620,y:725,t:1527272012384};\\\", \\\"{x:1594,y:719,t:1527272012401};\\\", \\\"{x:1565,y:716,t:1527272012418};\\\", \\\"{x:1533,y:712,t:1527272012434};\\\", \\\"{x:1498,y:706,t:1527272012451};\\\", \\\"{x:1488,y:703,t:1527272012467};\\\", \\\"{x:1472,y:695,t:1527272012484};\\\", \\\"{x:1459,y:687,t:1527272012501};\\\", \\\"{x:1447,y:682,t:1527272012518};\\\", \\\"{x:1438,y:678,t:1527272012534};\\\", \\\"{x:1431,y:676,t:1527272012551};\\\", \\\"{x:1425,y:673,t:1527272012569};\\\", \\\"{x:1421,y:671,t:1527272012585};\\\", \\\"{x:1420,y:670,t:1527272012602};\\\", \\\"{x:1420,y:668,t:1527272013757};\\\", \\\"{x:1420,y:667,t:1527272013770};\\\", \\\"{x:1418,y:665,t:1527272013786};\\\", \\\"{x:1418,y:661,t:1527272013803};\\\", \\\"{x:1418,y:658,t:1527272013821};\\\", \\\"{x:1418,y:657,t:1527272013836};\\\", \\\"{x:1417,y:654,t:1527272013853};\\\", \\\"{x:1413,y:653,t:1527272014124};\\\", \\\"{x:1408,y:653,t:1527272014137};\\\", \\\"{x:1401,y:653,t:1527272014152};\\\", \\\"{x:1395,y:653,t:1527272014169};\\\", \\\"{x:1387,y:653,t:1527272014187};\\\", \\\"{x:1378,y:653,t:1527272014202};\\\", \\\"{x:1366,y:653,t:1527272014219};\\\", \\\"{x:1356,y:653,t:1527272014236};\\\", \\\"{x:1345,y:653,t:1527272014252};\\\", \\\"{x:1339,y:653,t:1527272014269};\\\", \\\"{x:1338,y:653,t:1527272014286};\\\", \\\"{x:1337,y:653,t:1527272014303};\\\", \\\"{x:1335,y:652,t:1527272014421};\\\", \\\"{x:1328,y:649,t:1527272014437};\\\", \\\"{x:1318,y:644,t:1527272014454};\\\", \\\"{x:1310,y:639,t:1527272014470};\\\", \\\"{x:1304,y:636,t:1527272014487};\\\", \\\"{x:1297,y:632,t:1527272014504};\\\", \\\"{x:1291,y:628,t:1527272014520};\\\", \\\"{x:1289,y:627,t:1527272014537};\\\", \\\"{x:1287,y:626,t:1527272014554};\\\", \\\"{x:1287,y:625,t:1527272014570};\\\", \\\"{x:1287,y:626,t:1527272017059};\\\", \\\"{x:1289,y:626,t:1527272017072};\\\", \\\"{x:1296,y:630,t:1527272017089};\\\", \\\"{x:1299,y:630,t:1527272017106};\\\", \\\"{x:1301,y:632,t:1527272017122};\\\", \\\"{x:1302,y:633,t:1527272017139};\\\", \\\"{x:1303,y:633,t:1527272017155};\\\", \\\"{x:1304,y:633,t:1527272017267};\\\", \\\"{x:1305,y:635,t:1527272017275};\\\", \\\"{x:1306,y:635,t:1527272017291};\\\", \\\"{x:1306,y:636,t:1527272017307};\\\", \\\"{x:1306,y:637,t:1527272017355};\\\", \\\"{x:1306,y:638,t:1527272017373};\\\", \\\"{x:1306,y:640,t:1527272017390};\\\", \\\"{x:1306,y:642,t:1527272017406};\\\", \\\"{x:1306,y:643,t:1527272017423};\\\", \\\"{x:1306,y:644,t:1527272017440};\\\", \\\"{x:1306,y:645,t:1527272017456};\\\", \\\"{x:1306,y:646,t:1527272017473};\\\", \\\"{x:1306,y:647,t:1527272017490};\\\", \\\"{x:1306,y:649,t:1527272017508};\\\", \\\"{x:1306,y:650,t:1527272017524};\\\", \\\"{x:1306,y:652,t:1527272017540};\\\", \\\"{x:1307,y:656,t:1527272017556};\\\", \\\"{x:1307,y:659,t:1527272017572};\\\", \\\"{x:1307,y:666,t:1527272017590};\\\", \\\"{x:1307,y:672,t:1527272017605};\\\", \\\"{x:1307,y:676,t:1527272017622};\\\", \\\"{x:1307,y:682,t:1527272017640};\\\", \\\"{x:1307,y:691,t:1527272017656};\\\", \\\"{x:1307,y:696,t:1527272017672};\\\", \\\"{x:1307,y:700,t:1527272017690};\\\", \\\"{x:1307,y:707,t:1527272017707};\\\", \\\"{x:1307,y:716,t:1527272017723};\\\", \\\"{x:1311,y:734,t:1527272017739};\\\", \\\"{x:1312,y:742,t:1527272017756};\\\", \\\"{x:1312,y:746,t:1527272017773};\\\", \\\"{x:1312,y:750,t:1527272017790};\\\", \\\"{x:1314,y:756,t:1527272017807};\\\", \\\"{x:1315,y:766,t:1527272017823};\\\", \\\"{x:1315,y:779,t:1527272017839};\\\", \\\"{x:1315,y:792,t:1527272017857};\\\", \\\"{x:1315,y:807,t:1527272017872};\\\", \\\"{x:1315,y:817,t:1527272017890};\\\", \\\"{x:1315,y:821,t:1527272017907};\\\", \\\"{x:1315,y:826,t:1527272017923};\\\", \\\"{x:1315,y:830,t:1527272017939};\\\", \\\"{x:1315,y:833,t:1527272017957};\\\", \\\"{x:1314,y:843,t:1527272017973};\\\", \\\"{x:1314,y:857,t:1527272017990};\\\", \\\"{x:1314,y:872,t:1527272018007};\\\", \\\"{x:1314,y:887,t:1527272018023};\\\", \\\"{x:1314,y:897,t:1527272018040};\\\", \\\"{x:1314,y:904,t:1527272018057};\\\", \\\"{x:1314,y:911,t:1527272018073};\\\", \\\"{x:1314,y:918,t:1527272018090};\\\", \\\"{x:1314,y:926,t:1527272018107};\\\", \\\"{x:1314,y:933,t:1527272018123};\\\", \\\"{x:1314,y:938,t:1527272018139};\\\", \\\"{x:1314,y:940,t:1527272018157};\\\", \\\"{x:1313,y:942,t:1527272018173};\\\", \\\"{x:1313,y:941,t:1527272018436};\\\", \\\"{x:1316,y:933,t:1527272018444};\\\", \\\"{x:1321,y:922,t:1527272018457};\\\", \\\"{x:1332,y:903,t:1527272018474};\\\", \\\"{x:1342,y:884,t:1527272018490};\\\", \\\"{x:1354,y:864,t:1527272018507};\\\", \\\"{x:1366,y:827,t:1527272018523};\\\", \\\"{x:1373,y:804,t:1527272018540};\\\", \\\"{x:1378,y:783,t:1527272018557};\\\", \\\"{x:1383,y:768,t:1527272018574};\\\", \\\"{x:1385,y:760,t:1527272018591};\\\", \\\"{x:1387,y:756,t:1527272018606};\\\", \\\"{x:1387,y:751,t:1527272018623};\\\", \\\"{x:1387,y:747,t:1527272018640};\\\", \\\"{x:1388,y:741,t:1527272018656};\\\", \\\"{x:1388,y:735,t:1527272018674};\\\", \\\"{x:1388,y:729,t:1527272018690};\\\", \\\"{x:1386,y:714,t:1527272018706};\\\", \\\"{x:1386,y:692,t:1527272018723};\\\", \\\"{x:1386,y:679,t:1527272018741};\\\", \\\"{x:1386,y:670,t:1527272018757};\\\", \\\"{x:1386,y:658,t:1527272018774};\\\", \\\"{x:1384,y:651,t:1527272018791};\\\", \\\"{x:1383,y:647,t:1527272018806};\\\", \\\"{x:1381,y:640,t:1527272018824};\\\", \\\"{x:1379,y:637,t:1527272018841};\\\", \\\"{x:1378,y:637,t:1527272018858};\\\", \\\"{x:1378,y:636,t:1527272018873};\\\", \\\"{x:1377,y:636,t:1527272027764};\\\", \\\"{x:1380,y:633,t:1527272027771};\\\", \\\"{x:1394,y:631,t:1527272027782};\\\", \\\"{x:1412,y:627,t:1527272027799};\\\", \\\"{x:1419,y:623,t:1527272027815};\\\", \\\"{x:1420,y:623,t:1527272027832};\\\", \\\"{x:1421,y:622,t:1527272027851};\\\", \\\"{x:1425,y:618,t:1527272027866};\\\", \\\"{x:1430,y:613,t:1527272027882};\\\", \\\"{x:1439,y:605,t:1527272027899};\\\", \\\"{x:1442,y:603,t:1527272027915};\\\", \\\"{x:1442,y:602,t:1527272027939};\\\", \\\"{x:1442,y:601,t:1527272027949};\\\", \\\"{x:1442,y:599,t:1527272027966};\\\", \\\"{x:1436,y:595,t:1527272027982};\\\", \\\"{x:1427,y:589,t:1527272027999};\\\", \\\"{x:1416,y:580,t:1527272028016};\\\", \\\"{x:1408,y:573,t:1527272028032};\\\", \\\"{x:1400,y:566,t:1527272028049};\\\", \\\"{x:1397,y:563,t:1527272028066};\\\", \\\"{x:1394,y:561,t:1527272028082};\\\", \\\"{x:1393,y:561,t:1527272028132};\\\", \\\"{x:1393,y:560,t:1527272028139};\\\", \\\"{x:1392,y:559,t:1527272028149};\\\", \\\"{x:1391,y:559,t:1527272028166};\\\", \\\"{x:1392,y:559,t:1527272028251};\\\", \\\"{x:1392,y:560,t:1527272028267};\\\", \\\"{x:1393,y:560,t:1527272028282};\\\", \\\"{x:1395,y:560,t:1527272028299};\\\", \\\"{x:1397,y:562,t:1527272028316};\\\", \\\"{x:1398,y:563,t:1527272028333};\\\", \\\"{x:1402,y:564,t:1527272028349};\\\", \\\"{x:1402,y:565,t:1527272028366};\\\", \\\"{x:1404,y:565,t:1527272028383};\\\", \\\"{x:1405,y:566,t:1527272028436};\\\", \\\"{x:1406,y:568,t:1527272028449};\\\", \\\"{x:1408,y:570,t:1527272028466};\\\", \\\"{x:1411,y:572,t:1527272028483};\\\", \\\"{x:1411,y:575,t:1527272028523};\\\", \\\"{x:1412,y:575,t:1527272028547};\\\", \\\"{x:1412,y:576,t:1527272028571};\\\", \\\"{x:1413,y:578,t:1527272028588};\\\", \\\"{x:1414,y:580,t:1527272028603};\\\", \\\"{x:1414,y:581,t:1527272028619};\\\", \\\"{x:1414,y:582,t:1527272028635};\\\", \\\"{x:1414,y:584,t:1527272028650};\\\", \\\"{x:1414,y:586,t:1527272028666};\\\", \\\"{x:1415,y:590,t:1527272028683};\\\", \\\"{x:1415,y:592,t:1527272028700};\\\", \\\"{x:1415,y:596,t:1527272028716};\\\", \\\"{x:1415,y:598,t:1527272028733};\\\", \\\"{x:1416,y:601,t:1527272028750};\\\", \\\"{x:1416,y:604,t:1527272028766};\\\", \\\"{x:1416,y:606,t:1527272028783};\\\", \\\"{x:1416,y:607,t:1527272028799};\\\", \\\"{x:1417,y:609,t:1527272028816};\\\", \\\"{x:1417,y:610,t:1527272028833};\\\", \\\"{x:1417,y:611,t:1527272028850};\\\", \\\"{x:1417,y:612,t:1527272028866};\\\", \\\"{x:1417,y:614,t:1527272028883};\\\", \\\"{x:1418,y:617,t:1527272028900};\\\", \\\"{x:1418,y:618,t:1527272028923};\\\", \\\"{x:1419,y:620,t:1527272028933};\\\", \\\"{x:1420,y:621,t:1527272028950};\\\", \\\"{x:1421,y:623,t:1527272028966};\\\", \\\"{x:1421,y:627,t:1527272028983};\\\", \\\"{x:1421,y:629,t:1527272029000};\\\", \\\"{x:1421,y:630,t:1527272029017};\\\", \\\"{x:1422,y:633,t:1527272029035};\\\", \\\"{x:1422,y:634,t:1527272029050};\\\", \\\"{x:1422,y:640,t:1527272029067};\\\", \\\"{x:1422,y:644,t:1527272029083};\\\", \\\"{x:1422,y:649,t:1527272029100};\\\", \\\"{x:1421,y:656,t:1527272029117};\\\", \\\"{x:1421,y:662,t:1527272029133};\\\", \\\"{x:1420,y:668,t:1527272029149};\\\", \\\"{x:1420,y:669,t:1527272029167};\\\", \\\"{x:1420,y:671,t:1527272029183};\\\", \\\"{x:1420,y:673,t:1527272029200};\\\", \\\"{x:1420,y:674,t:1527272029217};\\\", \\\"{x:1420,y:676,t:1527272029235};\\\", \\\"{x:1420,y:677,t:1527272029251};\\\", \\\"{x:1420,y:679,t:1527272029266};\\\", \\\"{x:1420,y:680,t:1527272029283};\\\", \\\"{x:1420,y:682,t:1527272029307};\\\", \\\"{x:1420,y:683,t:1527272029317};\\\", \\\"{x:1420,y:685,t:1527272029333};\\\", \\\"{x:1419,y:688,t:1527272029350};\\\", \\\"{x:1418,y:690,t:1527272029367};\\\", \\\"{x:1417,y:693,t:1527272029384};\\\", \\\"{x:1417,y:696,t:1527272029400};\\\", \\\"{x:1416,y:699,t:1527272029417};\\\", \\\"{x:1415,y:702,t:1527272029434};\\\", \\\"{x:1415,y:705,t:1527272029450};\\\", \\\"{x:1415,y:707,t:1527272029467};\\\", \\\"{x:1414,y:708,t:1527272029484};\\\", \\\"{x:1414,y:710,t:1527272029507};\\\", \\\"{x:1414,y:712,t:1527272029517};\\\", \\\"{x:1414,y:714,t:1527272029534};\\\", \\\"{x:1414,y:718,t:1527272029550};\\\", \\\"{x:1414,y:722,t:1527272029567};\\\", \\\"{x:1414,y:725,t:1527272029584};\\\", \\\"{x:1415,y:727,t:1527272029601};\\\", \\\"{x:1416,y:729,t:1527272029617};\\\", \\\"{x:1416,y:734,t:1527272029634};\\\", \\\"{x:1417,y:737,t:1527272029650};\\\", \\\"{x:1417,y:745,t:1527272029667};\\\", \\\"{x:1417,y:751,t:1527272029684};\\\", \\\"{x:1417,y:758,t:1527272029701};\\\", \\\"{x:1418,y:768,t:1527272029718};\\\", \\\"{x:1418,y:778,t:1527272029734};\\\", \\\"{x:1419,y:787,t:1527272029751};\\\", \\\"{x:1419,y:794,t:1527272029767};\\\", \\\"{x:1419,y:797,t:1527272029784};\\\", \\\"{x:1419,y:801,t:1527272029802};\\\", \\\"{x:1419,y:803,t:1527272029818};\\\", \\\"{x:1419,y:805,t:1527272029835};\\\", \\\"{x:1420,y:808,t:1527272029851};\\\", \\\"{x:1421,y:813,t:1527272029868};\\\", \\\"{x:1422,y:815,t:1527272029884};\\\", \\\"{x:1423,y:819,t:1527272029902};\\\", \\\"{x:1425,y:822,t:1527272029917};\\\", \\\"{x:1427,y:824,t:1527272029940};\\\", \\\"{x:1427,y:825,t:1527272029952};\\\", \\\"{x:1428,y:828,t:1527272029968};\\\", \\\"{x:1428,y:829,t:1527272029984};\\\", \\\"{x:1429,y:831,t:1527272030002};\\\", \\\"{x:1429,y:832,t:1527272030020};\\\", \\\"{x:1430,y:834,t:1527272030034};\\\", \\\"{x:1430,y:838,t:1527272030052};\\\", \\\"{x:1430,y:841,t:1527272030068};\\\", \\\"{x:1430,y:842,t:1527272030156};\\\", \\\"{x:1430,y:844,t:1527272030168};\\\", \\\"{x:1430,y:845,t:1527272030188};\\\", \\\"{x:1430,y:847,t:1527272030204};\\\", \\\"{x:1430,y:848,t:1527272030220};\\\", \\\"{x:1430,y:850,t:1527272030268};\\\", \\\"{x:1430,y:852,t:1527272030285};\\\", \\\"{x:1430,y:853,t:1527272030301};\\\", \\\"{x:1430,y:855,t:1527272030319};\\\", \\\"{x:1430,y:856,t:1527272030335};\\\", \\\"{x:1430,y:858,t:1527272030352};\\\", \\\"{x:1430,y:859,t:1527272030369};\\\", \\\"{x:1430,y:860,t:1527272030405};\\\", \\\"{x:1428,y:861,t:1527272030444};\\\", \\\"{x:1421,y:856,t:1527272030452};\\\", \\\"{x:1400,y:845,t:1527272030468};\\\", \\\"{x:1310,y:810,t:1527272030484};\\\", \\\"{x:1181,y:759,t:1527272030502};\\\", \\\"{x:1009,y:709,t:1527272030519};\\\", \\\"{x:850,y:644,t:1527272030536};\\\", \\\"{x:771,y:605,t:1527272030553};\\\", \\\"{x:749,y:582,t:1527272030568};\\\", \\\"{x:741,y:565,t:1527272030584};\\\", \\\"{x:732,y:541,t:1527272030606};\\\", \\\"{x:729,y:530,t:1527272030622};\\\", \\\"{x:729,y:523,t:1527272030637};\\\", \\\"{x:729,y:517,t:1527272030655};\\\", \\\"{x:723,y:508,t:1527272030670};\\\", \\\"{x:710,y:496,t:1527272030688};\\\", \\\"{x:685,y:486,t:1527272030705};\\\", \\\"{x:665,y:477,t:1527272030721};\\\", \\\"{x:662,y:476,t:1527272030738};\\\", \\\"{x:664,y:478,t:1527272030788};\\\", \\\"{x:664,y:479,t:1527272030795};\\\", \\\"{x:664,y:481,t:1527272030805};\\\", \\\"{x:660,y:488,t:1527272030822};\\\", \\\"{x:658,y:492,t:1527272030839};\\\", \\\"{x:657,y:495,t:1527272030855};\\\", \\\"{x:658,y:500,t:1527272030872};\\\", \\\"{x:658,y:504,t:1527272030889};\\\", \\\"{x:660,y:510,t:1527272030905};\\\", \\\"{x:661,y:516,t:1527272030922};\\\", \\\"{x:657,y:526,t:1527272030939};\\\", \\\"{x:638,y:542,t:1527272030956};\\\", \\\"{x:626,y:549,t:1527272030972};\\\", \\\"{x:620,y:552,t:1527272030989};\\\", \\\"{x:615,y:561,t:1527272031005};\\\", \\\"{x:610,y:577,t:1527272031023};\\\", \\\"{x:604,y:586,t:1527272031039};\\\", \\\"{x:601,y:588,t:1527272031055};\\\", \\\"{x:599,y:588,t:1527272031073};\\\", \\\"{x:595,y:588,t:1527272031089};\\\", \\\"{x:592,y:588,t:1527272031105};\\\", \\\"{x:592,y:589,t:1527272031173};\\\", \\\"{x:595,y:586,t:1527272031261};\\\", \\\"{x:597,y:584,t:1527272031272};\\\", \\\"{x:604,y:579,t:1527272031290};\\\", \\\"{x:614,y:577,t:1527272031305};\\\", \\\"{x:618,y:577,t:1527272031322};\\\", \\\"{x:619,y:577,t:1527272031339};\\\", \\\"{x:622,y:577,t:1527272031429};\\\", \\\"{x:624,y:575,t:1527272031439};\\\", \\\"{x:626,y:575,t:1527272031456};\\\", \\\"{x:623,y:575,t:1527272031651};\\\", \\\"{x:620,y:575,t:1527272031666};\\\", \\\"{x:619,y:575,t:1527272031739};\\\", \\\"{x:617,y:575,t:1527272031755};\\\", \\\"{x:616,y:575,t:1527272031796};\\\", \\\"{x:616,y:574,t:1527272032300};\\\", \\\"{x:619,y:572,t:1527272032308};\\\", \\\"{x:628,y:570,t:1527272032324};\\\", \\\"{x:648,y:566,t:1527272032341};\\\", \\\"{x:696,y:563,t:1527272032356};\\\", \\\"{x:791,y:560,t:1527272032374};\\\", \\\"{x:922,y:558,t:1527272032389};\\\", \\\"{x:1086,y:552,t:1527272032407};\\\", \\\"{x:1258,y:552,t:1527272032423};\\\", \\\"{x:1432,y:552,t:1527272032439};\\\", \\\"{x:1590,y:554,t:1527272032456};\\\", \\\"{x:1725,y:554,t:1527272032473};\\\", \\\"{x:1846,y:543,t:1527272032490};\\\", \\\"{x:1911,y:539,t:1527272032506};\\\", \\\"{x:1919,y:539,t:1527272032523};\\\", \\\"{x:1919,y:542,t:1527272032571};\\\", \\\"{x:1918,y:542,t:1527272032579};\\\", \\\"{x:1915,y:542,t:1527272032590};\\\", \\\"{x:1910,y:543,t:1527272032606};\\\", \\\"{x:1897,y:543,t:1527272032623};\\\", \\\"{x:1879,y:543,t:1527272032640};\\\", \\\"{x:1852,y:543,t:1527272032656};\\\", \\\"{x:1825,y:543,t:1527272032673};\\\", \\\"{x:1801,y:543,t:1527272032690};\\\", \\\"{x:1773,y:543,t:1527272032706};\\\", \\\"{x:1746,y:546,t:1527272032723};\\\", \\\"{x:1726,y:552,t:1527272032740};\\\", \\\"{x:1711,y:553,t:1527272032756};\\\", \\\"{x:1693,y:557,t:1527272032774};\\\", \\\"{x:1679,y:559,t:1527272032791};\\\", \\\"{x:1670,y:560,t:1527272032807};\\\", \\\"{x:1663,y:562,t:1527272032823};\\\", \\\"{x:1659,y:563,t:1527272032841};\\\", \\\"{x:1654,y:563,t:1527272032856};\\\", \\\"{x:1651,y:565,t:1527272032874};\\\", \\\"{x:1646,y:566,t:1527272032891};\\\", \\\"{x:1637,y:571,t:1527272032906};\\\", \\\"{x:1628,y:574,t:1527272032924};\\\", \\\"{x:1623,y:576,t:1527272032940};\\\", \\\"{x:1620,y:576,t:1527272032957};\\\", \\\"{x:1618,y:578,t:1527272032973};\\\", \\\"{x:1616,y:579,t:1527272033085};\\\", \\\"{x:1613,y:580,t:1527272033092};\\\", \\\"{x:1609,y:582,t:1527272033107};\\\", \\\"{x:1608,y:583,t:1527272033123};\\\", \\\"{x:1607,y:583,t:1527272033140};\\\", \\\"{x:1606,y:583,t:1527272033532};\\\", \\\"{x:1606,y:584,t:1527272033548};\\\", \\\"{x:1604,y:585,t:1527272033564};\\\", \\\"{x:1604,y:586,t:1527272033574};\\\", \\\"{x:1601,y:589,t:1527272033590};\\\", \\\"{x:1598,y:590,t:1527272033608};\\\", \\\"{x:1593,y:593,t:1527272033624};\\\", \\\"{x:1591,y:593,t:1527272033640};\\\", \\\"{x:1587,y:595,t:1527272033657};\\\", \\\"{x:1584,y:597,t:1527272033673};\\\", \\\"{x:1582,y:598,t:1527272033690};\\\", \\\"{x:1580,y:600,t:1527272033707};\\\", \\\"{x:1579,y:602,t:1527272033755};\\\", \\\"{x:1578,y:603,t:1527272033763};\\\", \\\"{x:1577,y:605,t:1527272033774};\\\", \\\"{x:1575,y:607,t:1527272033790};\\\", \\\"{x:1573,y:609,t:1527272033808};\\\", \\\"{x:1572,y:611,t:1527272033824};\\\", \\\"{x:1570,y:612,t:1527272033841};\\\", \\\"{x:1568,y:613,t:1527272033857};\\\", \\\"{x:1566,y:615,t:1527272033874};\\\", \\\"{x:1563,y:616,t:1527272033891};\\\", \\\"{x:1556,y:621,t:1527272033907};\\\", \\\"{x:1553,y:623,t:1527272033924};\\\", \\\"{x:1550,y:625,t:1527272033941};\\\", \\\"{x:1548,y:626,t:1527272033958};\\\", \\\"{x:1547,y:626,t:1527272033975};\\\", \\\"{x:1546,y:626,t:1527272033996};\\\", \\\"{x:1544,y:627,t:1527272034067};\\\", \\\"{x:1543,y:628,t:1527272034083};\\\", \\\"{x:1541,y:629,t:1527272034099};\\\", \\\"{x:1540,y:629,t:1527272034107};\\\", \\\"{x:1539,y:630,t:1527272034124};\\\", \\\"{x:1536,y:630,t:1527272034140};\\\", \\\"{x:1534,y:630,t:1527272034157};\\\", \\\"{x:1533,y:633,t:1527272035811};\\\", \\\"{x:1533,y:642,t:1527272035825};\\\", \\\"{x:1535,y:658,t:1527272035841};\\\", \\\"{x:1544,y:678,t:1527272035858};\\\", \\\"{x:1550,y:700,t:1527272035874};\\\", \\\"{x:1554,y:707,t:1527272035891};\\\", \\\"{x:1555,y:710,t:1527272035908};\\\", \\\"{x:1559,y:717,t:1527272035925};\\\", \\\"{x:1562,y:722,t:1527272035942};\\\", \\\"{x:1565,y:726,t:1527272035959};\\\", \\\"{x:1571,y:736,t:1527272035975};\\\", \\\"{x:1581,y:752,t:1527272035992};\\\", \\\"{x:1591,y:769,t:1527272036008};\\\", \\\"{x:1600,y:783,t:1527272036026};\\\", \\\"{x:1609,y:797,t:1527272036042};\\\", \\\"{x:1621,y:811,t:1527272036058};\\\", \\\"{x:1634,y:831,t:1527272036075};\\\", \\\"{x:1641,y:848,t:1527272036092};\\\", \\\"{x:1645,y:860,t:1527272036108};\\\", \\\"{x:1640,y:871,t:1527272036126};\\\", \\\"{x:1633,y:878,t:1527272036142};\\\", \\\"{x:1628,y:886,t:1527272036159};\\\", \\\"{x:1621,y:891,t:1527272036176};\\\", \\\"{x:1614,y:894,t:1527272036192};\\\", \\\"{x:1606,y:896,t:1527272036209};\\\", \\\"{x:1603,y:896,t:1527272036226};\\\", \\\"{x:1597,y:896,t:1527272036243};\\\", \\\"{x:1595,y:896,t:1527272036258};\\\", \\\"{x:1592,y:896,t:1527272036276};\\\", \\\"{x:1590,y:896,t:1527272036388};\\\", \\\"{x:1588,y:896,t:1527272036395};\\\", \\\"{x:1587,y:895,t:1527272036410};\\\", \\\"{x:1581,y:894,t:1527272036426};\\\", \\\"{x:1576,y:893,t:1527272036443};\\\", \\\"{x:1569,y:893,t:1527272036459};\\\", \\\"{x:1557,y:891,t:1527272036476};\\\", \\\"{x:1551,y:890,t:1527272036493};\\\", \\\"{x:1545,y:888,t:1527272036508};\\\", \\\"{x:1542,y:887,t:1527272036526};\\\", \\\"{x:1541,y:886,t:1527272036543};\\\", \\\"{x:1540,y:885,t:1527272037020};\\\", \\\"{x:1540,y:884,t:1527272038892};\\\", \\\"{x:1540,y:882,t:1527272038900};\\\", \\\"{x:1539,y:878,t:1527272038911};\\\", \\\"{x:1539,y:874,t:1527272038927};\\\", \\\"{x:1537,y:868,t:1527272038944};\\\", \\\"{x:1537,y:864,t:1527272038961};\\\", \\\"{x:1538,y:858,t:1527272038977};\\\", \\\"{x:1544,y:852,t:1527272038994};\\\", \\\"{x:1545,y:850,t:1527272039011};\\\", \\\"{x:1542,y:850,t:1527272039204};\\\", \\\"{x:1537,y:853,t:1527272039211};\\\", \\\"{x:1534,y:854,t:1527272039226};\\\", \\\"{x:1529,y:856,t:1527272039243};\\\", \\\"{x:1528,y:856,t:1527272039260};\\\", \\\"{x:1526,y:856,t:1527272039435};\\\", \\\"{x:1523,y:856,t:1527272039443};\\\", \\\"{x:1517,y:854,t:1527272039461};\\\", \\\"{x:1512,y:851,t:1527272039478};\\\", \\\"{x:1509,y:849,t:1527272039494};\\\", \\\"{x:1507,y:847,t:1527272039511};\\\", \\\"{x:1506,y:845,t:1527272039527};\\\", \\\"{x:1503,y:842,t:1527272039543};\\\", \\\"{x:1500,y:841,t:1527272039560};\\\", \\\"{x:1496,y:838,t:1527272039577};\\\", \\\"{x:1493,y:838,t:1527272039593};\\\", \\\"{x:1492,y:837,t:1527272039615};\\\", \\\"{x:1490,y:837,t:1527272039632};\\\", \\\"{x:1489,y:837,t:1527272039655};\\\", \\\"{x:1487,y:837,t:1527272039679};\\\", \\\"{x:1486,y:836,t:1527272039687};\\\", \\\"{x:1484,y:834,t:1527272039698};\\\", \\\"{x:1478,y:831,t:1527272039715};\\\", \\\"{x:1474,y:829,t:1527272039733};\\\", \\\"{x:1472,y:829,t:1527272039748};\\\", \\\"{x:1470,y:827,t:1527272039765};\\\", \\\"{x:1469,y:827,t:1527272039782};\\\", \\\"{x:1468,y:827,t:1527272039808};\\\", \\\"{x:1470,y:827,t:1527272040919};\\\", \\\"{x:1472,y:827,t:1527272040935};\\\", \\\"{x:1473,y:827,t:1527272040951};\\\", \\\"{x:1475,y:829,t:1527272040966};\\\", \\\"{x:1480,y:834,t:1527272040982};\\\", \\\"{x:1483,y:837,t:1527272041000};\\\", \\\"{x:1485,y:839,t:1527272041016};\\\", \\\"{x:1486,y:839,t:1527272041033};\\\", \\\"{x:1487,y:840,t:1527272041056};\\\", \\\"{x:1487,y:842,t:1527272041088};\\\", \\\"{x:1487,y:843,t:1527272041099};\\\", \\\"{x:1488,y:844,t:1527272041116};\\\", \\\"{x:1489,y:845,t:1527272041132};\\\", \\\"{x:1490,y:846,t:1527272041150};\\\", \\\"{x:1491,y:846,t:1527272041263};\\\", \\\"{x:1492,y:846,t:1527272041280};\\\", \\\"{x:1494,y:846,t:1527272041320};\\\", \\\"{x:1494,y:845,t:1527272041333};\\\", \\\"{x:1495,y:845,t:1527272041349};\\\", \\\"{x:1495,y:844,t:1527272041366};\\\", \\\"{x:1497,y:844,t:1527272041383};\\\", \\\"{x:1499,y:843,t:1527272041399};\\\", \\\"{x:1506,y:841,t:1527272041416};\\\", \\\"{x:1508,y:841,t:1527272041439};\\\", \\\"{x:1509,y:841,t:1527272041449};\\\", \\\"{x:1511,y:840,t:1527272041479};\\\", \\\"{x:1512,y:838,t:1527272041487};\\\", \\\"{x:1513,y:837,t:1527272041499};\\\", \\\"{x:1516,y:832,t:1527272041516};\\\", \\\"{x:1518,y:826,t:1527272041534};\\\", \\\"{x:1518,y:821,t:1527272041549};\\\", \\\"{x:1518,y:818,t:1527272041566};\\\", \\\"{x:1518,y:815,t:1527272041583};\\\", \\\"{x:1518,y:808,t:1527272041599};\\\", \\\"{x:1506,y:764,t:1527272041616};\\\", \\\"{x:1481,y:725,t:1527272041634};\\\", \\\"{x:1464,y:702,t:1527272041650};\\\", \\\"{x:1454,y:688,t:1527272041666};\\\", \\\"{x:1450,y:682,t:1527272041683};\\\", \\\"{x:1449,y:678,t:1527272041699};\\\", \\\"{x:1447,y:674,t:1527272041716};\\\", \\\"{x:1446,y:671,t:1527272041733};\\\", \\\"{x:1445,y:669,t:1527272041749};\\\", \\\"{x:1444,y:668,t:1527272041766};\\\", \\\"{x:1444,y:667,t:1527272041783};\\\", \\\"{x:1443,y:662,t:1527272041800};\\\", \\\"{x:1443,y:659,t:1527272041823};\\\", \\\"{x:1443,y:658,t:1527272041833};\\\", \\\"{x:1440,y:651,t:1527272041850};\\\", \\\"{x:1440,y:648,t:1527272041866};\\\", \\\"{x:1440,y:647,t:1527272041883};\\\", \\\"{x:1440,y:646,t:1527272041903};\\\", \\\"{x:1440,y:645,t:1527272041919};\\\", \\\"{x:1440,y:644,t:1527272041933};\\\", \\\"{x:1440,y:643,t:1527272041949};\\\", \\\"{x:1440,y:641,t:1527272041966};\\\", \\\"{x:1440,y:639,t:1527272041983};\\\", \\\"{x:1440,y:637,t:1527272041999};\\\", \\\"{x:1440,y:635,t:1527272042024};\\\", \\\"{x:1440,y:634,t:1527272042033};\\\", \\\"{x:1440,y:626,t:1527272042050};\\\", \\\"{x:1440,y:619,t:1527272042067};\\\", \\\"{x:1440,y:615,t:1527272042083};\\\", \\\"{x:1440,y:614,t:1527272042100};\\\", \\\"{x:1439,y:612,t:1527272042127};\\\", \\\"{x:1440,y:611,t:1527272042135};\\\", \\\"{x:1447,y:609,t:1527272042150};\\\", \\\"{x:1458,y:596,t:1527272042166};\\\", \\\"{x:1455,y:595,t:1527272042183};\\\", \\\"{x:1430,y:595,t:1527272042199};\\\", \\\"{x:1414,y:599,t:1527272042216};\\\", \\\"{x:1406,y:602,t:1527272042233};\\\", \\\"{x:1406,y:603,t:1527272042250};\\\", \\\"{x:1405,y:603,t:1527272042295};\\\", \\\"{x:1405,y:604,t:1527272042303};\\\", \\\"{x:1411,y:604,t:1527272042471};\\\", \\\"{x:1421,y:607,t:1527272042483};\\\", \\\"{x:1430,y:613,t:1527272042500};\\\", \\\"{x:1430,y:614,t:1527272042516};\\\", \\\"{x:1421,y:606,t:1527272042863};\\\", \\\"{x:1364,y:581,t:1527272042871};\\\", \\\"{x:1275,y:551,t:1527272042883};\\\", \\\"{x:971,y:488,t:1527272042900};\\\", \\\"{x:598,y:436,t:1527272042917};\\\", \\\"{x:215,y:386,t:1527272042933};\\\", \\\"{x:0,y:339,t:1527272042950};\\\", \\\"{x:0,y:301,t:1527272042967};\\\", \\\"{x:0,y:284,t:1527272042983};\\\", \\\"{x:0,y:282,t:1527272043000};\\\", \\\"{x:0,y:289,t:1527272043017};\\\", \\\"{x:0,y:296,t:1527272043033};\\\", \\\"{x:0,y:310,t:1527272043050};\\\", \\\"{x:0,y:333,t:1527272043067};\\\", \\\"{x:6,y:365,t:1527272043083};\\\", \\\"{x:25,y:403,t:1527272043100};\\\", \\\"{x:62,y:445,t:1527272043117};\\\", \\\"{x:110,y:500,t:1527272043133};\\\", \\\"{x:162,y:558,t:1527272043150};\\\", \\\"{x:198,y:611,t:1527272043168};\\\", \\\"{x:211,y:635,t:1527272043184};\\\", \\\"{x:212,y:642,t:1527272043204};\\\", \\\"{x:200,y:657,t:1527272043220};\\\", \\\"{x:188,y:672,t:1527272043237};\\\", \\\"{x:181,y:684,t:1527272043253};\\\", \\\"{x:179,y:695,t:1527272043269};\\\", \\\"{x:179,y:715,t:1527272043286};\\\", \\\"{x:196,y:746,t:1527272043303};\\\", \\\"{x:253,y:807,t:1527272043319};\\\", \\\"{x:299,y:839,t:1527272043336};\\\", \\\"{x:339,y:861,t:1527272043353};\\\", \\\"{x:387,y:875,t:1527272043369};\\\", \\\"{x:424,y:878,t:1527272043387};\\\", \\\"{x:446,y:878,t:1527272043403};\\\", \\\"{x:464,y:869,t:1527272043419};\\\", \\\"{x:497,y:862,t:1527272043436};\\\", \\\"{x:545,y:860,t:1527272043453};\\\", \\\"{x:609,y:860,t:1527272043470};\\\", \\\"{x:648,y:860,t:1527272043486};\\\", \\\"{x:666,y:860,t:1527272043503};\\\", \\\"{x:657,y:857,t:1527272043527};\\\", \\\"{x:641,y:842,t:1527272043536};\\\", \\\"{x:574,y:794,t:1527272043553};\\\", \\\"{x:503,y:740,t:1527272043572};\\\", \\\"{x:470,y:720,t:1527272043586};\\\", \\\"{x:458,y:712,t:1527272043604};\\\", \\\"{x:457,y:711,t:1527272043620};\\\", \\\"{x:456,y:711,t:1527272043636};\\\", \\\"{x:456,y:710,t:1527272043663};\\\", \\\"{x:456,y:709,t:1527272043736};\\\", \\\"{x:456,y:708,t:1527272043776};\\\", \\\"{x:459,y:708,t:1527272043856};\\\", \\\"{x:462,y:708,t:1527272043871};\\\", \\\"{x:472,y:716,t:1527272043888};\\\", \\\"{x:484,y:725,t:1527272043903};\\\", \\\"{x:499,y:737,t:1527272043920};\\\", \\\"{x:501,y:739,t:1527272043937};\\\", \\\"{x:502,y:740,t:1527272044001};\\\", \\\"{x:503,y:741,t:1527272044015};\\\" ] }, { \\\"rt\\\": 14991, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 440751, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:738,t:1527272047135};\\\", \\\"{x:513,y:730,t:1527272047143};\\\", \\\"{x:521,y:726,t:1527272047155};\\\", \\\"{x:530,y:721,t:1527272047172};\\\", \\\"{x:545,y:709,t:1527272047189};\\\", \\\"{x:566,y:692,t:1527272047205};\\\", \\\"{x:604,y:664,t:1527272047223};\\\", \\\"{x:658,y:640,t:1527272047239};\\\", \\\"{x:666,y:636,t:1527272047256};\\\", \\\"{x:669,y:635,t:1527272047272};\\\", \\\"{x:673,y:635,t:1527272047289};\\\", \\\"{x:677,y:631,t:1527272047307};\\\", \\\"{x:686,y:621,t:1527272047323};\\\", \\\"{x:704,y:600,t:1527272047339};\\\", \\\"{x:711,y:595,t:1527272047356};\\\", \\\"{x:711,y:594,t:1527272047463};\\\", \\\"{x:711,y:593,t:1527272047489};\\\", \\\"{x:712,y:592,t:1527272047528};\\\", \\\"{x:713,y:592,t:1527272047544};\\\", \\\"{x:715,y:591,t:1527272047557};\\\", \\\"{x:717,y:589,t:1527272047574};\\\", \\\"{x:720,y:588,t:1527272047590};\\\", \\\"{x:724,y:588,t:1527272047608};\\\", \\\"{x:736,y:590,t:1527272047623};\\\", \\\"{x:752,y:596,t:1527272047640};\\\", \\\"{x:769,y:604,t:1527272047657};\\\", \\\"{x:789,y:613,t:1527272047673};\\\", \\\"{x:805,y:619,t:1527272047689};\\\", \\\"{x:822,y:624,t:1527272047706};\\\", \\\"{x:832,y:628,t:1527272047723};\\\", \\\"{x:851,y:632,t:1527272047740};\\\", \\\"{x:875,y:635,t:1527272047756};\\\", \\\"{x:902,y:635,t:1527272047774};\\\", \\\"{x:932,y:635,t:1527272047789};\\\", \\\"{x:955,y:637,t:1527272047806};\\\", \\\"{x:975,y:639,t:1527272047841};\\\", \\\"{x:979,y:640,t:1527272047857};\\\", \\\"{x:989,y:640,t:1527272047873};\\\", \\\"{x:1003,y:640,t:1527272047889};\\\", \\\"{x:1013,y:638,t:1527272047906};\\\", \\\"{x:1019,y:638,t:1527272047923};\\\", \\\"{x:1021,y:638,t:1527272047939};\\\", \\\"{x:1024,y:638,t:1527272047956};\\\", \\\"{x:1027,y:639,t:1527272047974};\\\", \\\"{x:1030,y:639,t:1527272047989};\\\", \\\"{x:1032,y:639,t:1527272048007};\\\", \\\"{x:1034,y:639,t:1527272048023};\\\", \\\"{x:1035,y:639,t:1527272048079};\\\", \\\"{x:1036,y:639,t:1527272048090};\\\", \\\"{x:1038,y:635,t:1527272048106};\\\", \\\"{x:1048,y:625,t:1527272048122};\\\", \\\"{x:1062,y:612,t:1527272048140};\\\", \\\"{x:1078,y:600,t:1527272048156};\\\", \\\"{x:1088,y:595,t:1527272048172};\\\", \\\"{x:1089,y:594,t:1527272048189};\\\", \\\"{x:1089,y:592,t:1527272048208};\\\", \\\"{x:1089,y:590,t:1527272048222};\\\", \\\"{x:1091,y:588,t:1527272048240};\\\", \\\"{x:1092,y:587,t:1527272048272};\\\", \\\"{x:1092,y:586,t:1527272048296};\\\", \\\"{x:1094,y:585,t:1527272048307};\\\", \\\"{x:1096,y:585,t:1527272048323};\\\", \\\"{x:1097,y:584,t:1527272048384};\\\", \\\"{x:1099,y:584,t:1527272048392};\\\", \\\"{x:1102,y:585,t:1527272048406};\\\", \\\"{x:1107,y:585,t:1527272048423};\\\", \\\"{x:1117,y:585,t:1527272048440};\\\", \\\"{x:1120,y:585,t:1527272048457};\\\", \\\"{x:1124,y:584,t:1527272048473};\\\", \\\"{x:1128,y:583,t:1527272048490};\\\", \\\"{x:1132,y:582,t:1527272048506};\\\", \\\"{x:1135,y:582,t:1527272048522};\\\", \\\"{x:1136,y:582,t:1527272048540};\\\", \\\"{x:1137,y:582,t:1527272048556};\\\", \\\"{x:1138,y:581,t:1527272048573};\\\", \\\"{x:1139,y:581,t:1527272048608};\\\", \\\"{x:1139,y:580,t:1527272048632};\\\", \\\"{x:1140,y:580,t:1527272048656};\\\", \\\"{x:1141,y:580,t:1527272048679};\\\", \\\"{x:1142,y:579,t:1527272048688};\\\", \\\"{x:1145,y:579,t:1527272048705};\\\", \\\"{x:1150,y:579,t:1527272048722};\\\", \\\"{x:1155,y:577,t:1527272048739};\\\", \\\"{x:1160,y:576,t:1527272048755};\\\", \\\"{x:1165,y:576,t:1527272048772};\\\", \\\"{x:1171,y:575,t:1527272048789};\\\", \\\"{x:1181,y:573,t:1527272048805};\\\", \\\"{x:1192,y:570,t:1527272048823};\\\", \\\"{x:1205,y:567,t:1527272048838};\\\", \\\"{x:1218,y:565,t:1527272048856};\\\", \\\"{x:1221,y:565,t:1527272048872};\\\", \\\"{x:1223,y:564,t:1527272048888};\\\", \\\"{x:1227,y:564,t:1527272048906};\\\", \\\"{x:1232,y:562,t:1527272048922};\\\", \\\"{x:1235,y:562,t:1527272048938};\\\", \\\"{x:1236,y:561,t:1527272048959};\\\", \\\"{x:1238,y:560,t:1527272048976};\\\", \\\"{x:1239,y:559,t:1527272048989};\\\", \\\"{x:1247,y:555,t:1527272049006};\\\", \\\"{x:1254,y:552,t:1527272049021};\\\", \\\"{x:1258,y:552,t:1527272049038};\\\", \\\"{x:1259,y:552,t:1527272049055};\\\", \\\"{x:1262,y:552,t:1527272049071};\\\", \\\"{x:1267,y:552,t:1527272049088};\\\", \\\"{x:1274,y:552,t:1527272049106};\\\", \\\"{x:1281,y:552,t:1527272049121};\\\", \\\"{x:1288,y:552,t:1527272049138};\\\", \\\"{x:1292,y:552,t:1527272049155};\\\", \\\"{x:1295,y:552,t:1527272049171};\\\", \\\"{x:1300,y:552,t:1527272049188};\\\", \\\"{x:1310,y:552,t:1527272049204};\\\", \\\"{x:1323,y:553,t:1527272049221};\\\", \\\"{x:1330,y:554,t:1527272049238};\\\", \\\"{x:1340,y:556,t:1527272049255};\\\", \\\"{x:1360,y:557,t:1527272049271};\\\", \\\"{x:1371,y:557,t:1527272049288};\\\", \\\"{x:1375,y:558,t:1527272049304};\\\", \\\"{x:1377,y:558,t:1527272049322};\\\", \\\"{x:1377,y:559,t:1527272049338};\\\", \\\"{x:1377,y:560,t:1527272049408};\\\", \\\"{x:1378,y:560,t:1527272049421};\\\", \\\"{x:1379,y:561,t:1527272049439};\\\", \\\"{x:1380,y:562,t:1527272049464};\\\", \\\"{x:1378,y:564,t:1527272049528};\\\", \\\"{x:1372,y:565,t:1527272049538};\\\", \\\"{x:1351,y:571,t:1527272049555};\\\", \\\"{x:1276,y:595,t:1527272049571};\\\", \\\"{x:1104,y:624,t:1527272049587};\\\", \\\"{x:867,y:647,t:1527272049604};\\\", \\\"{x:643,y:648,t:1527272049621};\\\", \\\"{x:419,y:634,t:1527272049637};\\\", \\\"{x:246,y:598,t:1527272049655};\\\", \\\"{x:45,y:549,t:1527272049672};\\\", \\\"{x:0,y:517,t:1527272049688};\\\", \\\"{x:0,y:495,t:1527272049705};\\\", \\\"{x:0,y:482,t:1527272049722};\\\", \\\"{x:0,y:480,t:1527272049738};\\\", \\\"{x:0,y:479,t:1527272049755};\\\", \\\"{x:0,y:478,t:1527272049849};\\\", \\\"{x:0,y:476,t:1527272049864};\\\", \\\"{x:0,y:473,t:1527272049872};\\\", \\\"{x:0,y:471,t:1527272049888};\\\", \\\"{x:1,y:469,t:1527272049912};\\\", \\\"{x:1,y:468,t:1527272049921};\\\", \\\"{x:5,y:467,t:1527272049937};\\\", \\\"{x:14,y:464,t:1527272049955};\\\", \\\"{x:34,y:464,t:1527272049970};\\\", \\\"{x:69,y:472,t:1527272049988};\\\", \\\"{x:102,y:479,t:1527272050004};\\\", \\\"{x:128,y:489,t:1527272050021};\\\", \\\"{x:147,y:496,t:1527272050038};\\\", \\\"{x:164,y:503,t:1527272050055};\\\", \\\"{x:173,y:507,t:1527272050076};\\\", \\\"{x:173,y:509,t:1527272050144};\\\", \\\"{x:173,y:513,t:1527272050158};\\\", \\\"{x:179,y:523,t:1527272050176};\\\", \\\"{x:182,y:530,t:1527272050192};\\\", \\\"{x:184,y:538,t:1527272050208};\\\", \\\"{x:187,y:548,t:1527272050225};\\\", \\\"{x:194,y:563,t:1527272050243};\\\", \\\"{x:202,y:574,t:1527272050258};\\\", \\\"{x:210,y:581,t:1527272050275};\\\", \\\"{x:218,y:584,t:1527272050293};\\\", \\\"{x:227,y:584,t:1527272050308};\\\", \\\"{x:239,y:584,t:1527272050326};\\\", \\\"{x:257,y:582,t:1527272050342};\\\", \\\"{x:279,y:577,t:1527272050359};\\\", \\\"{x:326,y:566,t:1527272050375};\\\", \\\"{x:377,y:557,t:1527272050392};\\\", \\\"{x:443,y:548,t:1527272050409};\\\", \\\"{x:531,y:540,t:1527272050426};\\\", \\\"{x:609,y:540,t:1527272050442};\\\", \\\"{x:646,y:540,t:1527272050458};\\\", \\\"{x:668,y:541,t:1527272050475};\\\", \\\"{x:671,y:542,t:1527272050492};\\\", \\\"{x:672,y:543,t:1527272050508};\\\", \\\"{x:670,y:538,t:1527272050632};\\\", \\\"{x:663,y:528,t:1527272050643};\\\", \\\"{x:648,y:508,t:1527272050660};\\\", \\\"{x:636,y:490,t:1527272050676};\\\", \\\"{x:625,y:478,t:1527272050692};\\\", \\\"{x:622,y:472,t:1527272050710};\\\", \\\"{x:622,y:471,t:1527272050725};\\\", \\\"{x:622,y:470,t:1527272050815};\\\", \\\"{x:623,y:470,t:1527272050825};\\\", \\\"{x:627,y:473,t:1527272050842};\\\", \\\"{x:628,y:478,t:1527272050860};\\\", \\\"{x:628,y:482,t:1527272050875};\\\", \\\"{x:628,y:485,t:1527272050893};\\\", \\\"{x:628,y:489,t:1527272050910};\\\", \\\"{x:628,y:491,t:1527272050926};\\\", \\\"{x:627,y:493,t:1527272050942};\\\", \\\"{x:626,y:493,t:1527272050959};\\\", \\\"{x:621,y:497,t:1527272050976};\\\", \\\"{x:612,y:499,t:1527272050993};\\\", \\\"{x:601,y:501,t:1527272051009};\\\", \\\"{x:595,y:502,t:1527272051026};\\\", \\\"{x:592,y:502,t:1527272051043};\\\", \\\"{x:590,y:502,t:1527272051060};\\\", \\\"{x:590,y:503,t:1527272051216};\\\", \\\"{x:591,y:504,t:1527272051232};\\\", \\\"{x:592,y:504,t:1527272051241};\\\", \\\"{x:596,y:505,t:1527272051259};\\\", \\\"{x:599,y:505,t:1527272051276};\\\", \\\"{x:604,y:508,t:1527272051292};\\\", \\\"{x:606,y:508,t:1527272051309};\\\", \\\"{x:609,y:509,t:1527272051326};\\\", \\\"{x:610,y:510,t:1527272051343};\\\", \\\"{x:613,y:510,t:1527272051871};\\\", \\\"{x:624,y:516,t:1527272051879};\\\", \\\"{x:639,y:523,t:1527272051894};\\\", \\\"{x:686,y:542,t:1527272051910};\\\", \\\"{x:737,y:553,t:1527272051927};\\\", \\\"{x:801,y:565,t:1527272051943};\\\", \\\"{x:825,y:569,t:1527272051961};\\\", \\\"{x:831,y:571,t:1527272051976};\\\", \\\"{x:832,y:571,t:1527272052039};\\\", \\\"{x:833,y:571,t:1527272052047};\\\", \\\"{x:835,y:571,t:1527272052059};\\\", \\\"{x:837,y:571,t:1527272052095};\\\", \\\"{x:840,y:571,t:1527272052127};\\\", \\\"{x:840,y:569,t:1527272052143};\\\", \\\"{x:840,y:566,t:1527272052160};\\\", \\\"{x:840,y:562,t:1527272052177};\\\", \\\"{x:840,y:560,t:1527272052193};\\\", \\\"{x:840,y:556,t:1527272052211};\\\", \\\"{x:840,y:553,t:1527272052227};\\\", \\\"{x:840,y:549,t:1527272052243};\\\", \\\"{x:841,y:547,t:1527272052260};\\\", \\\"{x:841,y:546,t:1527272052276};\\\", \\\"{x:842,y:544,t:1527272052293};\\\", \\\"{x:843,y:543,t:1527272052311};\\\", \\\"{x:847,y:543,t:1527272052776};\\\", \\\"{x:858,y:544,t:1527272052783};\\\", \\\"{x:879,y:546,t:1527272052794};\\\", \\\"{x:974,y:546,t:1527272052810};\\\", \\\"{x:1109,y:546,t:1527272052828};\\\", \\\"{x:1265,y:555,t:1527272052845};\\\", \\\"{x:1399,y:576,t:1527272052860};\\\", \\\"{x:1515,y:593,t:1527272052877};\\\", \\\"{x:1599,y:606,t:1527272052895};\\\", \\\"{x:1642,y:614,t:1527272052911};\\\", \\\"{x:1654,y:617,t:1527272052928};\\\", \\\"{x:1652,y:617,t:1527272053009};\\\", \\\"{x:1651,y:617,t:1527272053016};\\\", \\\"{x:1648,y:615,t:1527272053027};\\\", \\\"{x:1631,y:607,t:1527272053045};\\\", \\\"{x:1600,y:595,t:1527272053061};\\\", \\\"{x:1567,y:587,t:1527272053077};\\\", \\\"{x:1519,y:579,t:1527272053095};\\\", \\\"{x:1461,y:572,t:1527272053111};\\\", \\\"{x:1434,y:569,t:1527272053128};\\\", \\\"{x:1414,y:567,t:1527272053146};\\\", \\\"{x:1403,y:566,t:1527272053162};\\\", \\\"{x:1402,y:564,t:1527272053177};\\\", \\\"{x:1401,y:564,t:1527272053351};\\\", \\\"{x:1401,y:565,t:1527272053375};\\\", \\\"{x:1401,y:566,t:1527272053399};\\\", \\\"{x:1401,y:567,t:1527272053551};\\\", \\\"{x:1401,y:568,t:1527272053599};\\\", \\\"{x:1402,y:569,t:1527272053615};\\\", \\\"{x:1403,y:569,t:1527272053628};\\\", \\\"{x:1406,y:570,t:1527272053645};\\\", \\\"{x:1409,y:572,t:1527272053662};\\\", \\\"{x:1414,y:572,t:1527272053678};\\\", \\\"{x:1414,y:573,t:1527272053694};\\\", \\\"{x:1416,y:574,t:1527272053711};\\\", \\\"{x:1416,y:575,t:1527272053863};\\\", \\\"{x:1414,y:575,t:1527272053879};\\\", \\\"{x:1394,y:578,t:1527272053895};\\\", \\\"{x:1382,y:579,t:1527272053912};\\\", \\\"{x:1372,y:581,t:1527272053928};\\\", \\\"{x:1365,y:582,t:1527272053946};\\\", \\\"{x:1362,y:582,t:1527272053961};\\\", \\\"{x:1361,y:582,t:1527272053983};\\\", \\\"{x:1361,y:583,t:1527272053995};\\\", \\\"{x:1362,y:585,t:1527272054056};\\\", \\\"{x:1366,y:585,t:1527272054071};\\\", \\\"{x:1373,y:586,t:1527272054080};\\\", \\\"{x:1391,y:588,t:1527272054096};\\\", \\\"{x:1403,y:588,t:1527272054113};\\\", \\\"{x:1409,y:588,t:1527272054128};\\\", \\\"{x:1410,y:589,t:1527272054146};\\\", \\\"{x:1408,y:589,t:1527272054265};\\\", \\\"{x:1403,y:589,t:1527272054279};\\\", \\\"{x:1385,y:589,t:1527272054295};\\\", \\\"{x:1376,y:589,t:1527272054313};\\\", \\\"{x:1369,y:589,t:1527272054330};\\\", \\\"{x:1365,y:589,t:1527272054346};\\\", \\\"{x:1364,y:589,t:1527272054364};\\\", \\\"{x:1365,y:589,t:1527272054535};\\\", \\\"{x:1366,y:589,t:1527272054568};\\\", \\\"{x:1367,y:589,t:1527272054881};\\\", \\\"{x:1368,y:589,t:1527272054945};\\\", \\\"{x:1369,y:589,t:1527272055031};\\\", \\\"{x:1370,y:589,t:1527272055247};\\\", \\\"{x:1371,y:589,t:1527272057855};\\\", \\\"{x:1372,y:589,t:1527272057871};\\\", \\\"{x:1373,y:589,t:1527272057887};\\\", \\\"{x:1375,y:589,t:1527272057903};\\\", \\\"{x:1376,y:589,t:1527272057915};\\\", \\\"{x:1378,y:589,t:1527272057932};\\\", \\\"{x:1381,y:587,t:1527272057949};\\\", \\\"{x:1382,y:587,t:1527272057983};\\\", \\\"{x:1383,y:587,t:1527272058007};\\\", \\\"{x:1384,y:587,t:1527272058031};\\\", \\\"{x:1385,y:587,t:1527272058063};\\\", \\\"{x:1386,y:587,t:1527272058079};\\\", \\\"{x:1387,y:587,t:1527272058095};\\\", \\\"{x:1389,y:587,t:1527272058103};\\\", \\\"{x:1390,y:587,t:1527272058119};\\\", \\\"{x:1390,y:586,t:1527272058132};\\\", \\\"{x:1392,y:586,t:1527272058149};\\\", \\\"{x:1393,y:586,t:1527272058165};\\\", \\\"{x:1395,y:586,t:1527272058183};\\\", \\\"{x:1396,y:586,t:1527272058247};\\\", \\\"{x:1384,y:588,t:1527272059599};\\\", \\\"{x:1352,y:592,t:1527272059607};\\\", \\\"{x:1298,y:602,t:1527272059618};\\\", \\\"{x:1138,y:622,t:1527272059633};\\\", \\\"{x:919,y:629,t:1527272059651};\\\", \\\"{x:659,y:631,t:1527272059668};\\\", \\\"{x:381,y:631,t:1527272059684};\\\", \\\"{x:130,y:634,t:1527272059700};\\\", \\\"{x:0,y:614,t:1527272059716};\\\", \\\"{x:0,y:595,t:1527272059732};\\\", \\\"{x:0,y:586,t:1527272059750};\\\", \\\"{x:0,y:585,t:1527272059765};\\\", \\\"{x:0,y:587,t:1527272059790};\\\", \\\"{x:0,y:588,t:1527272059799};\\\", \\\"{x:2,y:590,t:1527272059817};\\\", \\\"{x:5,y:595,t:1527272059833};\\\", \\\"{x:8,y:601,t:1527272059849};\\\", \\\"{x:9,y:606,t:1527272059867};\\\", \\\"{x:16,y:618,t:1527272059883};\\\", \\\"{x:23,y:630,t:1527272059899};\\\", \\\"{x:35,y:644,t:1527272059916};\\\", \\\"{x:50,y:658,t:1527272059933};\\\", \\\"{x:67,y:667,t:1527272059950};\\\", \\\"{x:81,y:674,t:1527272059968};\\\", \\\"{x:102,y:684,t:1527272059983};\\\", \\\"{x:119,y:691,t:1527272060000};\\\", \\\"{x:135,y:696,t:1527272060017};\\\", \\\"{x:159,y:698,t:1527272060033};\\\", \\\"{x:188,y:702,t:1527272060050};\\\", \\\"{x:210,y:706,t:1527272060067};\\\", \\\"{x:230,y:709,t:1527272060084};\\\", \\\"{x:252,y:712,t:1527272060100};\\\", \\\"{x:266,y:713,t:1527272060117};\\\", \\\"{x:280,y:715,t:1527272060133};\\\", \\\"{x:296,y:715,t:1527272060150};\\\", \\\"{x:328,y:716,t:1527272060167};\\\", \\\"{x:344,y:718,t:1527272060183};\\\", \\\"{x:354,y:722,t:1527272060200};\\\", \\\"{x:360,y:722,t:1527272060217};\\\", \\\"{x:363,y:724,t:1527272060234};\\\", \\\"{x:365,y:724,t:1527272060250};\\\", \\\"{x:367,y:724,t:1527272060267};\\\", \\\"{x:372,y:725,t:1527272060283};\\\", \\\"{x:379,y:725,t:1527272060300};\\\", \\\"{x:386,y:729,t:1527272060316};\\\", \\\"{x:399,y:733,t:1527272060333};\\\", \\\"{x:415,y:738,t:1527272060350};\\\", \\\"{x:433,y:741,t:1527272060367};\\\", \\\"{x:453,y:744,t:1527272060383};\\\", \\\"{x:459,y:744,t:1527272060400};\\\", \\\"{x:465,y:744,t:1527272060416};\\\", \\\"{x:470,y:744,t:1527272060433};\\\", \\\"{x:476,y:744,t:1527272060449};\\\", \\\"{x:482,y:744,t:1527272060467};\\\", \\\"{x:487,y:744,t:1527272060484};\\\", \\\"{x:491,y:744,t:1527272060499};\\\", \\\"{x:497,y:743,t:1527272060516};\\\", \\\"{x:503,y:742,t:1527272060534};\\\", \\\"{x:505,y:742,t:1527272060550};\\\", \\\"{x:509,y:742,t:1527272060567};\\\", \\\"{x:509,y:741,t:1527272060583};\\\", \\\"{x:510,y:741,t:1527272060600};\\\" ] }, { \\\"rt\\\": 25191, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 467238, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:740,t:1527272063087};\\\", \\\"{x:509,y:737,t:1527272063102};\\\", \\\"{x:499,y:720,t:1527272063120};\\\", \\\"{x:489,y:695,t:1527272063137};\\\", \\\"{x:482,y:675,t:1527272063153};\\\", \\\"{x:474,y:657,t:1527272063170};\\\", \\\"{x:467,y:643,t:1527272063186};\\\", \\\"{x:459,y:626,t:1527272063203};\\\", \\\"{x:449,y:610,t:1527272063219};\\\", \\\"{x:443,y:597,t:1527272063236};\\\", \\\"{x:439,y:587,t:1527272063252};\\\", \\\"{x:436,y:581,t:1527272063269};\\\", \\\"{x:434,y:577,t:1527272063285};\\\", \\\"{x:432,y:570,t:1527272063303};\\\", \\\"{x:432,y:567,t:1527272063319};\\\", \\\"{x:432,y:563,t:1527272063336};\\\", \\\"{x:431,y:557,t:1527272063353};\\\", \\\"{x:431,y:553,t:1527272063370};\\\", \\\"{x:429,y:545,t:1527272063386};\\\", \\\"{x:429,y:539,t:1527272063402};\\\", \\\"{x:429,y:530,t:1527272063419};\\\", \\\"{x:429,y:518,t:1527272063436};\\\", \\\"{x:429,y:510,t:1527272063453};\\\", \\\"{x:429,y:498,t:1527272063469};\\\", \\\"{x:431,y:483,t:1527272063486};\\\", \\\"{x:435,y:465,t:1527272063503};\\\", \\\"{x:436,y:461,t:1527272063519};\\\", \\\"{x:436,y:458,t:1527272063536};\\\", \\\"{x:436,y:457,t:1527272063553};\\\", \\\"{x:437,y:456,t:1527272064359};\\\", \\\"{x:438,y:456,t:1527272064370};\\\", \\\"{x:444,y:456,t:1527272064387};\\\", \\\"{x:448,y:456,t:1527272064403};\\\", \\\"{x:451,y:456,t:1527272064420};\\\", \\\"{x:454,y:456,t:1527272064437};\\\", \\\"{x:456,y:456,t:1527272064453};\\\", \\\"{x:458,y:456,t:1527272064469};\\\", \\\"{x:459,y:456,t:1527272064486};\\\", \\\"{x:460,y:456,t:1527272064502};\\\", \\\"{x:461,y:456,t:1527272064520};\\\", \\\"{x:462,y:456,t:1527272064551};\\\", \\\"{x:463,y:456,t:1527272064559};\\\", \\\"{x:464,y:456,t:1527272064569};\\\", \\\"{x:466,y:456,t:1527272064586};\\\", \\\"{x:471,y:456,t:1527272064603};\\\", \\\"{x:474,y:456,t:1527272064619};\\\", \\\"{x:482,y:456,t:1527272064637};\\\", \\\"{x:489,y:456,t:1527272064652};\\\", \\\"{x:497,y:459,t:1527272064670};\\\", \\\"{x:505,y:460,t:1527272064687};\\\", \\\"{x:510,y:460,t:1527272064703};\\\", \\\"{x:512,y:461,t:1527272064719};\\\", \\\"{x:512,y:462,t:1527272064737};\\\", \\\"{x:513,y:462,t:1527272064823};\\\", \\\"{x:514,y:462,t:1527272064887};\\\", \\\"{x:515,y:462,t:1527272064903};\\\", \\\"{x:518,y:462,t:1527272064919};\\\", \\\"{x:522,y:462,t:1527272064937};\\\", \\\"{x:525,y:462,t:1527272064952};\\\", \\\"{x:527,y:462,t:1527272064970};\\\", \\\"{x:529,y:462,t:1527272064987};\\\", \\\"{x:531,y:462,t:1527272065003};\\\", \\\"{x:533,y:462,t:1527272065020};\\\", \\\"{x:534,y:462,t:1527272065037};\\\", \\\"{x:536,y:462,t:1527272065054};\\\", \\\"{x:539,y:462,t:1527272065070};\\\", \\\"{x:546,y:462,t:1527272065087};\\\", \\\"{x:551,y:462,t:1527272065104};\\\", \\\"{x:554,y:462,t:1527272065120};\\\", \\\"{x:555,y:462,t:1527272065136};\\\", \\\"{x:557,y:462,t:1527272065158};\\\", \\\"{x:554,y:464,t:1527272065463};\\\", \\\"{x:548,y:467,t:1527272065471};\\\", \\\"{x:538,y:469,t:1527272065487};\\\", \\\"{x:530,y:472,t:1527272065504};\\\", \\\"{x:520,y:473,t:1527272065520};\\\", \\\"{x:511,y:474,t:1527272065536};\\\", \\\"{x:503,y:475,t:1527272065553};\\\", \\\"{x:496,y:476,t:1527272065570};\\\", \\\"{x:488,y:477,t:1527272065587};\\\", \\\"{x:483,y:478,t:1527272065604};\\\", \\\"{x:480,y:478,t:1527272065620};\\\", \\\"{x:476,y:479,t:1527272065637};\\\", \\\"{x:475,y:480,t:1527272065654};\\\", \\\"{x:474,y:480,t:1527272065670};\\\", \\\"{x:473,y:480,t:1527272065687};\\\", \\\"{x:471,y:480,t:1527272065711};\\\", \\\"{x:470,y:480,t:1527272065758};\\\", \\\"{x:468,y:480,t:1527272065799};\\\", \\\"{x:468,y:479,t:1527272065871};\\\", \\\"{x:467,y:479,t:1527272065919};\\\", \\\"{x:466,y:478,t:1527272065975};\\\", \\\"{x:466,y:477,t:1527272066055};\\\", \\\"{x:465,y:477,t:1527272066111};\\\", \\\"{x:464,y:476,t:1527272066127};\\\", \\\"{x:463,y:476,t:1527272066158};\\\", \\\"{x:462,y:475,t:1527272066215};\\\", \\\"{x:461,y:474,t:1527272066231};\\\", \\\"{x:461,y:472,t:1527272066462};\\\", \\\"{x:461,y:471,t:1527272066478};\\\", \\\"{x:462,y:470,t:1527272066495};\\\", \\\"{x:463,y:468,t:1527272066518};\\\", \\\"{x:465,y:468,t:1527272066527};\\\", \\\"{x:465,y:467,t:1527272066538};\\\", \\\"{x:468,y:466,t:1527272066553};\\\", \\\"{x:469,y:466,t:1527272066575};\\\", \\\"{x:472,y:465,t:1527272066587};\\\", \\\"{x:475,y:465,t:1527272066604};\\\", \\\"{x:477,y:464,t:1527272066621};\\\", \\\"{x:482,y:464,t:1527272066638};\\\", \\\"{x:485,y:464,t:1527272066654};\\\", \\\"{x:491,y:464,t:1527272066671};\\\", \\\"{x:492,y:464,t:1527272066688};\\\", \\\"{x:495,y:464,t:1527272066703};\\\", \\\"{x:499,y:464,t:1527272066721};\\\", \\\"{x:503,y:463,t:1527272066738};\\\", \\\"{x:509,y:463,t:1527272066754};\\\", \\\"{x:514,y:463,t:1527272066771};\\\", \\\"{x:518,y:463,t:1527272066788};\\\", \\\"{x:523,y:463,t:1527272066804};\\\", \\\"{x:528,y:463,t:1527272066821};\\\", \\\"{x:533,y:463,t:1527272066838};\\\", \\\"{x:537,y:461,t:1527272066854};\\\", \\\"{x:542,y:461,t:1527272066871};\\\", \\\"{x:545,y:459,t:1527272066888};\\\", \\\"{x:548,y:458,t:1527272066904};\\\", \\\"{x:549,y:458,t:1527272066921};\\\", \\\"{x:551,y:457,t:1527272066938};\\\", \\\"{x:552,y:457,t:1527272066954};\\\", \\\"{x:555,y:457,t:1527272066970};\\\", \\\"{x:559,y:457,t:1527272066988};\\\", \\\"{x:564,y:454,t:1527272067004};\\\", \\\"{x:567,y:454,t:1527272067020};\\\", \\\"{x:572,y:453,t:1527272067038};\\\", \\\"{x:575,y:453,t:1527272067054};\\\", \\\"{x:578,y:453,t:1527272067071};\\\", \\\"{x:580,y:453,t:1527272067127};\\\", \\\"{x:581,y:453,t:1527272067175};\\\", \\\"{x:583,y:453,t:1527272067271};\\\", \\\"{x:585,y:453,t:1527272067615};\\\", \\\"{x:587,y:454,t:1527272067631};\\\", \\\"{x:589,y:456,t:1527272067647};\\\", \\\"{x:591,y:457,t:1527272067654};\\\", \\\"{x:593,y:458,t:1527272067671};\\\", \\\"{x:594,y:458,t:1527272067711};\\\", \\\"{x:594,y:459,t:1527272067759};\\\", \\\"{x:595,y:459,t:1527272067775};\\\", \\\"{x:596,y:460,t:1527272067791};\\\", \\\"{x:597,y:460,t:1527272067806};\\\", \\\"{x:597,y:461,t:1527272067821};\\\", \\\"{x:598,y:461,t:1527272067838};\\\", \\\"{x:600,y:461,t:1527272067855};\\\", \\\"{x:601,y:461,t:1527272068014};\\\", \\\"{x:602,y:461,t:1527272068023};\\\", \\\"{x:603,y:461,t:1527272068037};\\\", \\\"{x:609,y:463,t:1527272068054};\\\", \\\"{x:612,y:463,t:1527272068072};\\\", \\\"{x:616,y:463,t:1527272068088};\\\", \\\"{x:620,y:464,t:1527272068105};\\\", \\\"{x:621,y:464,t:1527272068127};\\\", \\\"{x:622,y:464,t:1527272068159};\\\", \\\"{x:623,y:464,t:1527272068262};\\\", \\\"{x:624,y:465,t:1527272068287};\\\", \\\"{x:625,y:465,t:1527272068318};\\\", \\\"{x:626,y:465,t:1527272068334};\\\", \\\"{x:627,y:465,t:1527272068399};\\\", \\\"{x:628,y:466,t:1527272068431};\\\", \\\"{x:629,y:466,t:1527272068447};\\\", \\\"{x:630,y:466,t:1527272068479};\\\", \\\"{x:631,y:467,t:1527272068495};\\\", \\\"{x:632,y:467,t:1527272068511};\\\", \\\"{x:633,y:467,t:1527272068535};\\\", \\\"{x:634,y:467,t:1527272068543};\\\", \\\"{x:634,y:468,t:1527272068559};\\\", \\\"{x:635,y:468,t:1527272068598};\\\", \\\"{x:636,y:468,t:1527272068639};\\\", \\\"{x:639,y:468,t:1527272068655};\\\", \\\"{x:645,y:468,t:1527272068672};\\\", \\\"{x:656,y:469,t:1527272068689};\\\", \\\"{x:664,y:470,t:1527272068705};\\\", \\\"{x:678,y:472,t:1527272068722};\\\", \\\"{x:695,y:475,t:1527272068739};\\\", \\\"{x:716,y:478,t:1527272068755};\\\", \\\"{x:741,y:483,t:1527272068773};\\\", \\\"{x:771,y:493,t:1527272068791};\\\", \\\"{x:807,y:501,t:1527272068805};\\\", \\\"{x:847,y:512,t:1527272068822};\\\", \\\"{x:970,y:550,t:1527272068839};\\\", \\\"{x:1078,y:585,t:1527272068856};\\\", \\\"{x:1181,y:615,t:1527272068874};\\\", \\\"{x:1277,y:651,t:1527272068890};\\\", \\\"{x:1350,y:675,t:1527272068907};\\\", \\\"{x:1417,y:698,t:1527272068923};\\\", \\\"{x:1480,y:722,t:1527272068940};\\\", \\\"{x:1548,y:745,t:1527272068957};\\\", \\\"{x:1611,y:774,t:1527272068974};\\\", \\\"{x:1654,y:795,t:1527272068990};\\\", \\\"{x:1676,y:808,t:1527272069006};\\\", \\\"{x:1681,y:811,t:1527272069024};\\\", \\\"{x:1682,y:812,t:1527272069039};\\\", \\\"{x:1682,y:813,t:1527272069328};\\\", \\\"{x:1680,y:813,t:1527272069340};\\\", \\\"{x:1676,y:815,t:1527272069358};\\\", \\\"{x:1668,y:816,t:1527272069375};\\\", \\\"{x:1663,y:816,t:1527272069392};\\\", \\\"{x:1659,y:816,t:1527272069407};\\\", \\\"{x:1655,y:816,t:1527272069424};\\\", \\\"{x:1649,y:816,t:1527272069441};\\\", \\\"{x:1640,y:816,t:1527272069457};\\\", \\\"{x:1630,y:816,t:1527272069474};\\\", \\\"{x:1618,y:816,t:1527272069492};\\\", \\\"{x:1609,y:816,t:1527272069508};\\\", \\\"{x:1604,y:816,t:1527272069524};\\\", \\\"{x:1597,y:814,t:1527272069541};\\\", \\\"{x:1592,y:814,t:1527272069557};\\\", \\\"{x:1586,y:814,t:1527272069574};\\\", \\\"{x:1577,y:814,t:1527272069591};\\\", \\\"{x:1571,y:814,t:1527272069607};\\\", \\\"{x:1566,y:814,t:1527272069624};\\\", \\\"{x:1560,y:814,t:1527272069641};\\\", \\\"{x:1553,y:816,t:1527272069657};\\\", \\\"{x:1544,y:819,t:1527272069674};\\\", \\\"{x:1537,y:822,t:1527272069691};\\\", \\\"{x:1531,y:825,t:1527272069708};\\\", \\\"{x:1529,y:827,t:1527272069724};\\\", \\\"{x:1528,y:828,t:1527272069741};\\\", \\\"{x:1527,y:828,t:1527272069757};\\\", \\\"{x:1526,y:828,t:1527272069799};\\\", \\\"{x:1525,y:829,t:1527272069831};\\\", \\\"{x:1523,y:829,t:1527272069911};\\\", \\\"{x:1522,y:828,t:1527272069925};\\\", \\\"{x:1518,y:823,t:1527272069941};\\\", \\\"{x:1513,y:817,t:1527272069958};\\\", \\\"{x:1508,y:811,t:1527272069974};\\\", \\\"{x:1502,y:805,t:1527272069991};\\\", \\\"{x:1497,y:799,t:1527272070008};\\\", \\\"{x:1491,y:794,t:1527272070024};\\\", \\\"{x:1488,y:790,t:1527272070041};\\\", \\\"{x:1484,y:786,t:1527272070058};\\\", \\\"{x:1479,y:781,t:1527272070075};\\\", \\\"{x:1472,y:776,t:1527272070091};\\\", \\\"{x:1469,y:773,t:1527272070108};\\\", \\\"{x:1465,y:772,t:1527272070124};\\\", \\\"{x:1465,y:771,t:1527272070140};\\\", \\\"{x:1464,y:771,t:1527272070157};\\\", \\\"{x:1463,y:769,t:1527272070174};\\\", \\\"{x:1459,y:767,t:1527272070191};\\\", \\\"{x:1457,y:764,t:1527272070208};\\\", \\\"{x:1452,y:760,t:1527272070224};\\\", \\\"{x:1448,y:758,t:1527272070241};\\\", \\\"{x:1445,y:756,t:1527272070258};\\\", \\\"{x:1444,y:756,t:1527272070275};\\\", \\\"{x:1442,y:755,t:1527272070291};\\\", \\\"{x:1440,y:753,t:1527272070308};\\\", \\\"{x:1438,y:753,t:1527272070343};\\\", \\\"{x:1437,y:752,t:1527272070359};\\\", \\\"{x:1436,y:752,t:1527272070399};\\\", \\\"{x:1434,y:751,t:1527272070408};\\\", \\\"{x:1431,y:750,t:1527272070425};\\\", \\\"{x:1426,y:748,t:1527272070441};\\\", \\\"{x:1419,y:744,t:1527272070457};\\\", \\\"{x:1414,y:742,t:1527272070475};\\\", \\\"{x:1412,y:741,t:1527272070495};\\\", \\\"{x:1412,y:740,t:1527272070508};\\\", \\\"{x:1411,y:740,t:1527272070525};\\\", \\\"{x:1411,y:738,t:1527272070541};\\\", \\\"{x:1408,y:735,t:1527272070558};\\\", \\\"{x:1404,y:731,t:1527272070575};\\\", \\\"{x:1404,y:730,t:1527272070591};\\\", \\\"{x:1403,y:729,t:1527272070608};\\\", \\\"{x:1402,y:728,t:1527272070625};\\\", \\\"{x:1401,y:727,t:1527272070641};\\\", \\\"{x:1401,y:725,t:1527272070658};\\\", \\\"{x:1401,y:723,t:1527272070675};\\\", \\\"{x:1400,y:718,t:1527272070691};\\\", \\\"{x:1400,y:715,t:1527272070708};\\\", \\\"{x:1398,y:711,t:1527272070725};\\\", \\\"{x:1398,y:709,t:1527272070741};\\\", \\\"{x:1398,y:708,t:1527272070758};\\\", \\\"{x:1397,y:700,t:1527272070775};\\\", \\\"{x:1392,y:692,t:1527272070792};\\\", \\\"{x:1388,y:685,t:1527272070809};\\\", \\\"{x:1383,y:678,t:1527272070825};\\\", \\\"{x:1380,y:672,t:1527272070842};\\\", \\\"{x:1375,y:667,t:1527272070858};\\\", \\\"{x:1373,y:662,t:1527272070876};\\\", \\\"{x:1371,y:660,t:1527272070892};\\\", \\\"{x:1370,y:658,t:1527272070909};\\\", \\\"{x:1369,y:656,t:1527272070925};\\\", \\\"{x:1369,y:654,t:1527272070943};\\\", \\\"{x:1368,y:654,t:1527272070958};\\\", \\\"{x:1367,y:652,t:1527272070975};\\\", \\\"{x:1365,y:652,t:1527272071152};\\\", \\\"{x:1365,y:654,t:1527272071159};\\\", \\\"{x:1365,y:660,t:1527272071175};\\\", \\\"{x:1363,y:666,t:1527272071193};\\\", \\\"{x:1363,y:670,t:1527272071209};\\\", \\\"{x:1361,y:674,t:1527272071225};\\\", \\\"{x:1361,y:677,t:1527272071243};\\\", \\\"{x:1359,y:681,t:1527272071259};\\\", \\\"{x:1358,y:684,t:1527272071275};\\\", \\\"{x:1358,y:691,t:1527272071292};\\\", \\\"{x:1357,y:696,t:1527272071310};\\\", \\\"{x:1356,y:700,t:1527272071325};\\\", \\\"{x:1356,y:705,t:1527272071342};\\\", \\\"{x:1356,y:711,t:1527272071359};\\\", \\\"{x:1356,y:713,t:1527272071375};\\\", \\\"{x:1356,y:716,t:1527272071392};\\\", \\\"{x:1356,y:717,t:1527272071409};\\\", \\\"{x:1356,y:718,t:1527272071425};\\\", \\\"{x:1356,y:720,t:1527272071442};\\\", \\\"{x:1356,y:722,t:1527272071458};\\\", \\\"{x:1356,y:723,t:1527272071475};\\\", \\\"{x:1356,y:725,t:1527272071492};\\\", \\\"{x:1356,y:729,t:1527272071509};\\\", \\\"{x:1356,y:731,t:1527272071525};\\\", \\\"{x:1356,y:733,t:1527272071542};\\\", \\\"{x:1355,y:736,t:1527272071558};\\\", \\\"{x:1355,y:737,t:1527272071583};\\\", \\\"{x:1354,y:738,t:1527272071593};\\\", \\\"{x:1354,y:739,t:1527272071609};\\\", \\\"{x:1354,y:742,t:1527272071625};\\\", \\\"{x:1353,y:743,t:1527272071687};\\\", \\\"{x:1352,y:743,t:1527272071711};\\\", \\\"{x:1352,y:742,t:1527272071726};\\\", \\\"{x:1350,y:733,t:1527272071742};\\\", \\\"{x:1346,y:723,t:1527272071759};\\\", \\\"{x:1343,y:720,t:1527272071776};\\\", \\\"{x:1340,y:716,t:1527272071793};\\\", \\\"{x:1340,y:717,t:1527272071919};\\\", \\\"{x:1340,y:721,t:1527272071927};\\\", \\\"{x:1340,y:725,t:1527272071942};\\\", \\\"{x:1340,y:736,t:1527272071958};\\\", \\\"{x:1340,y:739,t:1527272071976};\\\", \\\"{x:1340,y:740,t:1527272071992};\\\", \\\"{x:1340,y:743,t:1527272072208};\\\", \\\"{x:1340,y:747,t:1527272072215};\\\", \\\"{x:1334,y:754,t:1527272072227};\\\", \\\"{x:1319,y:761,t:1527272072243};\\\", \\\"{x:1295,y:770,t:1527272072259};\\\", \\\"{x:1251,y:778,t:1527272072277};\\\", \\\"{x:1166,y:786,t:1527272072293};\\\", \\\"{x:1071,y:786,t:1527272072309};\\\", \\\"{x:966,y:786,t:1527272072327};\\\", \\\"{x:819,y:771,t:1527272072342};\\\", \\\"{x:749,y:752,t:1527272072359};\\\", \\\"{x:688,y:726,t:1527272072376};\\\", \\\"{x:652,y:709,t:1527272072393};\\\", \\\"{x:632,y:702,t:1527272072409};\\\", \\\"{x:623,y:699,t:1527272072426};\\\", \\\"{x:622,y:698,t:1527272072444};\\\", \\\"{x:621,y:698,t:1527272072463};\\\", \\\"{x:621,y:697,t:1527272072496};\\\", \\\"{x:620,y:695,t:1527272072512};\\\", \\\"{x:619,y:694,t:1527272072527};\\\", \\\"{x:615,y:687,t:1527272072544};\\\", \\\"{x:612,y:683,t:1527272072559};\\\", \\\"{x:612,y:682,t:1527272072576};\\\", \\\"{x:612,y:681,t:1527272072615};\\\", \\\"{x:611,y:679,t:1527272072625};\\\", \\\"{x:609,y:676,t:1527272072643};\\\", \\\"{x:607,y:670,t:1527272072660};\\\", \\\"{x:603,y:663,t:1527272072676};\\\", \\\"{x:595,y:652,t:1527272072692};\\\", \\\"{x:587,y:639,t:1527272072710};\\\", \\\"{x:578,y:626,t:1527272072726};\\\", \\\"{x:557,y:598,t:1527272072743};\\\", \\\"{x:539,y:582,t:1527272072761};\\\", \\\"{x:533,y:574,t:1527272072777};\\\", \\\"{x:533,y:573,t:1527272072798};\\\", \\\"{x:533,y:574,t:1527272074359};\\\", \\\"{x:533,y:575,t:1527272074382};\\\", \\\"{x:533,y:576,t:1527272074590};\\\", \\\"{x:533,y:578,t:1527272074599};\\\", \\\"{x:533,y:579,t:1527272074622};\\\", \\\"{x:533,y:580,t:1527272074630};\\\", \\\"{x:532,y:581,t:1527272074646};\\\", \\\"{x:532,y:582,t:1527272074678};\\\", \\\"{x:532,y:583,t:1527272074775};\\\", \\\"{x:531,y:584,t:1527272074783};\\\", \\\"{x:531,y:585,t:1527272074796};\\\", \\\"{x:530,y:586,t:1527272074815};\\\", \\\"{x:530,y:587,t:1527272074902};\\\", \\\"{x:530,y:588,t:1527272074919};\\\", \\\"{x:530,y:589,t:1527272074930};\\\", \\\"{x:530,y:590,t:1527272074946};\\\", \\\"{x:529,y:592,t:1527272074963};\\\", \\\"{x:529,y:593,t:1527272074991};\\\", \\\"{x:529,y:594,t:1527272074999};\\\", \\\"{x:528,y:596,t:1527272075013};\\\", \\\"{x:528,y:597,t:1527272075028};\\\", \\\"{x:528,y:600,t:1527272075045};\\\", \\\"{x:528,y:602,t:1527272075063};\\\", \\\"{x:528,y:604,t:1527272075142};\\\", \\\"{x:528,y:605,t:1527272075166};\\\", \\\"{x:527,y:606,t:1527272075207};\\\", \\\"{x:527,y:607,t:1527272075222};\\\", \\\"{x:526,y:607,t:1527272075230};\\\", \\\"{x:522,y:609,t:1527272075245};\\\", \\\"{x:509,y:616,t:1527272075262};\\\", \\\"{x:482,y:634,t:1527272075279};\\\", \\\"{x:465,y:641,t:1527272075295};\\\", \\\"{x:457,y:644,t:1527272075312};\\\", \\\"{x:453,y:648,t:1527272075329};\\\", \\\"{x:452,y:647,t:1527272075439};\\\", \\\"{x:452,y:644,t:1527272075446};\\\", \\\"{x:452,y:642,t:1527272075462};\\\", \\\"{x:452,y:631,t:1527272075479};\\\", \\\"{x:450,y:621,t:1527272075495};\\\", \\\"{x:449,y:613,t:1527272075512};\\\", \\\"{x:448,y:605,t:1527272075529};\\\", \\\"{x:447,y:596,t:1527272075546};\\\", \\\"{x:443,y:581,t:1527272075562};\\\", \\\"{x:440,y:576,t:1527272075579};\\\", \\\"{x:438,y:568,t:1527272075595};\\\", \\\"{x:436,y:564,t:1527272075612};\\\", \\\"{x:435,y:563,t:1527272075630};\\\", \\\"{x:434,y:562,t:1527272075646};\\\", \\\"{x:438,y:561,t:1527272075911};\\\", \\\"{x:450,y:561,t:1527272075918};\\\", \\\"{x:468,y:561,t:1527272075929};\\\", \\\"{x:532,y:561,t:1527272075946};\\\", \\\"{x:624,y:561,t:1527272075963};\\\", \\\"{x:743,y:561,t:1527272075979};\\\", \\\"{x:873,y:575,t:1527272075997};\\\", \\\"{x:1035,y:588,t:1527272076013};\\\", \\\"{x:1206,y:612,t:1527272076030};\\\", \\\"{x:1386,y:635,t:1527272076046};\\\", \\\"{x:1552,y:664,t:1527272076062};\\\", \\\"{x:1715,y:706,t:1527272076079};\\\", \\\"{x:1766,y:730,t:1527272076096};\\\", \\\"{x:1789,y:745,t:1527272076112};\\\", \\\"{x:1797,y:751,t:1527272076129};\\\", \\\"{x:1798,y:753,t:1527272076146};\\\", \\\"{x:1798,y:755,t:1527272076162};\\\", \\\"{x:1792,y:761,t:1527272076179};\\\", \\\"{x:1774,y:769,t:1527272076196};\\\", \\\"{x:1749,y:778,t:1527272076212};\\\", \\\"{x:1728,y:783,t:1527272076229};\\\", \\\"{x:1703,y:789,t:1527272076246};\\\", \\\"{x:1673,y:795,t:1527272076263};\\\", \\\"{x:1647,y:798,t:1527272076279};\\\", \\\"{x:1629,y:798,t:1527272076296};\\\", \\\"{x:1614,y:798,t:1527272076314};\\\", \\\"{x:1597,y:798,t:1527272076329};\\\", \\\"{x:1584,y:798,t:1527272076346};\\\", \\\"{x:1571,y:798,t:1527272076364};\\\", \\\"{x:1568,y:798,t:1527272076379};\\\", \\\"{x:1566,y:798,t:1527272076397};\\\", \\\"{x:1562,y:796,t:1527272076413};\\\", \\\"{x:1551,y:792,t:1527272076429};\\\", \\\"{x:1519,y:784,t:1527272076446};\\\", \\\"{x:1438,y:762,t:1527272076463};\\\", \\\"{x:1388,y:754,t:1527272076480};\\\", \\\"{x:1340,y:740,t:1527272076496};\\\", \\\"{x:1310,y:731,t:1527272076513};\\\", \\\"{x:1289,y:725,t:1527272076529};\\\", \\\"{x:1273,y:720,t:1527272076546};\\\", \\\"{x:1264,y:717,t:1527272076563};\\\", \\\"{x:1260,y:717,t:1527272076579};\\\", \\\"{x:1258,y:717,t:1527272076596};\\\", \\\"{x:1257,y:717,t:1527272076614};\\\", \\\"{x:1259,y:715,t:1527272078591};\\\", \\\"{x:1272,y:709,t:1527272078598};\\\", \\\"{x:1285,y:702,t:1527272078614};\\\", \\\"{x:1302,y:691,t:1527272078630};\\\", \\\"{x:1305,y:688,t:1527272078647};\\\", \\\"{x:1305,y:687,t:1527272078665};\\\", \\\"{x:1305,y:686,t:1527272078681};\\\", \\\"{x:1308,y:690,t:1527272078806};\\\", \\\"{x:1308,y:692,t:1527272078815};\\\", \\\"{x:1310,y:700,t:1527272078831};\\\", \\\"{x:1317,y:713,t:1527272078848};\\\", \\\"{x:1320,y:723,t:1527272078864};\\\", \\\"{x:1324,y:733,t:1527272078881};\\\", \\\"{x:1326,y:737,t:1527272078897};\\\", \\\"{x:1327,y:738,t:1527272078914};\\\", \\\"{x:1328,y:738,t:1527272078958};\\\", \\\"{x:1331,y:736,t:1527272078966};\\\", \\\"{x:1331,y:735,t:1527272078982};\\\", \\\"{x:1335,y:732,t:1527272078997};\\\", \\\"{x:1341,y:728,t:1527272079015};\\\", \\\"{x:1346,y:721,t:1527272079031};\\\", \\\"{x:1348,y:715,t:1527272079047};\\\", \\\"{x:1349,y:712,t:1527272079064};\\\", \\\"{x:1350,y:710,t:1527272079081};\\\", \\\"{x:1350,y:711,t:1527272079182};\\\", \\\"{x:1350,y:723,t:1527272079198};\\\", \\\"{x:1350,y:730,t:1527272079214};\\\", \\\"{x:1349,y:738,t:1527272079231};\\\", \\\"{x:1349,y:741,t:1527272079248};\\\", \\\"{x:1348,y:741,t:1527272079334};\\\", \\\"{x:1346,y:740,t:1527272079348};\\\", \\\"{x:1345,y:737,t:1527272079364};\\\", \\\"{x:1342,y:729,t:1527272079383};\\\", \\\"{x:1342,y:722,t:1527272079399};\\\", \\\"{x:1339,y:715,t:1527272079414};\\\", \\\"{x:1339,y:714,t:1527272079431};\\\", \\\"{x:1339,y:717,t:1527272079535};\\\", \\\"{x:1339,y:722,t:1527272079549};\\\", \\\"{x:1339,y:729,t:1527272079564};\\\", \\\"{x:1339,y:735,t:1527272079582};\\\", \\\"{x:1339,y:737,t:1527272079599};\\\", \\\"{x:1339,y:738,t:1527272079631};\\\", \\\"{x:1339,y:737,t:1527272079695};\\\", \\\"{x:1338,y:734,t:1527272079702};\\\", \\\"{x:1338,y:733,t:1527272079715};\\\", \\\"{x:1336,y:730,t:1527272079731};\\\", \\\"{x:1336,y:728,t:1527272079748};\\\", \\\"{x:1336,y:727,t:1527272079765};\\\", \\\"{x:1336,y:726,t:1527272079782};\\\", \\\"{x:1335,y:726,t:1527272082063};\\\", \\\"{x:1322,y:726,t:1527272082070};\\\", \\\"{x:1299,y:726,t:1527272082083};\\\", \\\"{x:1196,y:726,t:1527272082099};\\\", \\\"{x:1072,y:726,t:1527272082116};\\\", \\\"{x:939,y:726,t:1527272082134};\\\", \\\"{x:797,y:719,t:1527272082150};\\\", \\\"{x:581,y:676,t:1527272082167};\\\", \\\"{x:467,y:643,t:1527272082183};\\\", \\\"{x:384,y:616,t:1527272082200};\\\", \\\"{x:353,y:607,t:1527272082217};\\\", \\\"{x:339,y:600,t:1527272082235};\\\", \\\"{x:336,y:600,t:1527272082251};\\\", \\\"{x:336,y:598,t:1527272082326};\\\", \\\"{x:337,y:598,t:1527272082334};\\\", \\\"{x:342,y:597,t:1527272082351};\\\", \\\"{x:356,y:597,t:1527272082367};\\\", \\\"{x:374,y:597,t:1527272082384};\\\", \\\"{x:391,y:598,t:1527272082401};\\\", \\\"{x:409,y:601,t:1527272082417};\\\", \\\"{x:429,y:602,t:1527272082434};\\\", \\\"{x:448,y:602,t:1527272082451};\\\", \\\"{x:458,y:602,t:1527272082468};\\\", \\\"{x:460,y:602,t:1527272082484};\\\", \\\"{x:452,y:602,t:1527272082518};\\\", \\\"{x:418,y:594,t:1527272082535};\\\", \\\"{x:366,y:588,t:1527272082552};\\\", \\\"{x:294,y:579,t:1527272082567};\\\", \\\"{x:214,y:574,t:1527272082585};\\\", \\\"{x:172,y:570,t:1527272082601};\\\", \\\"{x:153,y:570,t:1527272082619};\\\", \\\"{x:149,y:570,t:1527272082634};\\\", \\\"{x:152,y:571,t:1527272082710};\\\", \\\"{x:154,y:571,t:1527272082718};\\\", \\\"{x:161,y:575,t:1527272082734};\\\", \\\"{x:161,y:577,t:1527272082783};\\\", \\\"{x:161,y:580,t:1527272082791};\\\", \\\"{x:161,y:584,t:1527272082802};\\\", \\\"{x:161,y:590,t:1527272082818};\\\", \\\"{x:160,y:596,t:1527272082835};\\\", \\\"{x:159,y:599,t:1527272082852};\\\", \\\"{x:159,y:600,t:1527272082868};\\\", \\\"{x:163,y:601,t:1527272082983};\\\", \\\"{x:196,y:597,t:1527272083002};\\\", \\\"{x:279,y:588,t:1527272083019};\\\", \\\"{x:388,y:570,t:1527272083036};\\\", \\\"{x:504,y:553,t:1527272083052};\\\", \\\"{x:580,y:550,t:1527272083068};\\\", \\\"{x:614,y:548,t:1527272083085};\\\", \\\"{x:635,y:546,t:1527272083101};\\\", \\\"{x:653,y:546,t:1527272083119};\\\", \\\"{x:662,y:545,t:1527272083136};\\\", \\\"{x:665,y:545,t:1527272083151};\\\", \\\"{x:668,y:545,t:1527272083168};\\\", \\\"{x:670,y:545,t:1527272083185};\\\", \\\"{x:666,y:545,t:1527272083286};\\\", \\\"{x:653,y:545,t:1527272083302};\\\", \\\"{x:638,y:544,t:1527272083319};\\\", \\\"{x:622,y:538,t:1527272083335};\\\", \\\"{x:614,y:534,t:1527272083351};\\\", \\\"{x:612,y:534,t:1527272083368};\\\", \\\"{x:612,y:536,t:1527272083526};\\\", \\\"{x:612,y:537,t:1527272083534};\\\", \\\"{x:612,y:541,t:1527272083552};\\\", \\\"{x:613,y:544,t:1527272083569};\\\", \\\"{x:614,y:550,t:1527272083585};\\\", \\\"{x:614,y:555,t:1527272083602};\\\", \\\"{x:615,y:559,t:1527272083617};\\\", \\\"{x:616,y:563,t:1527272083636};\\\", \\\"{x:616,y:564,t:1527272083653};\\\", \\\"{x:617,y:565,t:1527272083670};\\\", \\\"{x:618,y:565,t:1527272083685};\\\", \\\"{x:620,y:567,t:1527272083702};\\\", \\\"{x:624,y:567,t:1527272083718};\\\", \\\"{x:632,y:567,t:1527272083736};\\\", \\\"{x:651,y:563,t:1527272083752};\\\", \\\"{x:690,y:549,t:1527272083769};\\\", \\\"{x:718,y:537,t:1527272083785};\\\", \\\"{x:725,y:535,t:1527272083803};\\\", \\\"{x:726,y:534,t:1527272083818};\\\", \\\"{x:724,y:532,t:1527272083854};\\\", \\\"{x:721,y:532,t:1527272083870};\\\", \\\"{x:711,y:532,t:1527272083885};\\\", \\\"{x:689,y:532,t:1527272083902};\\\", \\\"{x:683,y:532,t:1527272083918};\\\", \\\"{x:691,y:529,t:1527272083959};\\\", \\\"{x:701,y:524,t:1527272083970};\\\", \\\"{x:727,y:518,t:1527272083985};\\\", \\\"{x:765,y:507,t:1527272084003};\\\", \\\"{x:805,y:500,t:1527272084019};\\\", \\\"{x:837,y:495,t:1527272084036};\\\", \\\"{x:850,y:494,t:1527272084052};\\\", \\\"{x:851,y:494,t:1527272084069};\\\", \\\"{x:851,y:495,t:1527272084086};\\\", \\\"{x:848,y:496,t:1527272084102};\\\", \\\"{x:846,y:498,t:1527272084120};\\\", \\\"{x:845,y:498,t:1527272084136};\\\", \\\"{x:844,y:498,t:1527272084152};\\\", \\\"{x:844,y:499,t:1527272084223};\\\", \\\"{x:843,y:499,t:1527272084343};\\\", \\\"{x:842,y:499,t:1527272084406};\\\", \\\"{x:842,y:499,t:1527272084475};\\\", \\\"{x:840,y:501,t:1527272084590};\\\", \\\"{x:835,y:503,t:1527272084603};\\\", \\\"{x:805,y:512,t:1527272084620};\\\", \\\"{x:726,y:529,t:1527272084637};\\\", \\\"{x:618,y:543,t:1527272084654};\\\", \\\"{x:506,y:549,t:1527272084669};\\\", \\\"{x:370,y:551,t:1527272084687};\\\", \\\"{x:309,y:551,t:1527272084702};\\\", \\\"{x:270,y:553,t:1527272084720};\\\", \\\"{x:243,y:558,t:1527272084737};\\\", \\\"{x:219,y:562,t:1527272084753};\\\", \\\"{x:200,y:569,t:1527272084770};\\\", \\\"{x:188,y:574,t:1527272084787};\\\", \\\"{x:183,y:577,t:1527272084803};\\\", \\\"{x:182,y:577,t:1527272084819};\\\", \\\"{x:182,y:578,t:1527272084862};\\\", \\\"{x:182,y:579,t:1527272084870};\\\", \\\"{x:182,y:583,t:1527272084886};\\\", \\\"{x:182,y:584,t:1527272084903};\\\", \\\"{x:181,y:584,t:1527272085047};\\\", \\\"{x:178,y:579,t:1527272085054};\\\", \\\"{x:175,y:573,t:1527272085069};\\\", \\\"{x:170,y:560,t:1527272085087};\\\", \\\"{x:169,y:554,t:1527272085104};\\\", \\\"{x:169,y:553,t:1527272085119};\\\", \\\"{x:169,y:550,t:1527272085137};\\\", \\\"{x:169,y:548,t:1527272085153};\\\", \\\"{x:170,y:546,t:1527272085170};\\\", \\\"{x:170,y:544,t:1527272085186};\\\", \\\"{x:170,y:543,t:1527272085214};\\\", \\\"{x:179,y:543,t:1527272085750};\\\", \\\"{x:200,y:550,t:1527272085758};\\\", \\\"{x:237,y:553,t:1527272085770};\\\", \\\"{x:348,y:572,t:1527272085788};\\\", \\\"{x:469,y:601,t:1527272085804};\\\", \\\"{x:575,y:633,t:1527272085821};\\\", \\\"{x:682,y:675,t:1527272085837};\\\", \\\"{x:762,y:711,t:1527272085854};\\\", \\\"{x:867,y:753,t:1527272085870};\\\", \\\"{x:937,y:774,t:1527272085887};\\\", \\\"{x:984,y:785,t:1527272085904};\\\", \\\"{x:1008,y:789,t:1527272085920};\\\", \\\"{x:1019,y:792,t:1527272085938};\\\", \\\"{x:1021,y:793,t:1527272085955};\\\", \\\"{x:1022,y:793,t:1527272085970};\\\", \\\"{x:1025,y:794,t:1527272086015};\\\", \\\"{x:1027,y:794,t:1527272086023};\\\", \\\"{x:1033,y:794,t:1527272086037};\\\", \\\"{x:1072,y:798,t:1527272086054};\\\", \\\"{x:1108,y:798,t:1527272086071};\\\", \\\"{x:1145,y:801,t:1527272086088};\\\", \\\"{x:1192,y:801,t:1527272086104};\\\", \\\"{x:1247,y:801,t:1527272086122};\\\", \\\"{x:1306,y:801,t:1527272086138};\\\", \\\"{x:1367,y:801,t:1527272086154};\\\", \\\"{x:1422,y:797,t:1527272086172};\\\", \\\"{x:1454,y:792,t:1527272086187};\\\", \\\"{x:1475,y:790,t:1527272086204};\\\", \\\"{x:1485,y:787,t:1527272086222};\\\", \\\"{x:1488,y:787,t:1527272086238};\\\", \\\"{x:1489,y:786,t:1527272086270};\\\", \\\"{x:1489,y:784,t:1527272086311};\\\", \\\"{x:1488,y:783,t:1527272086327};\\\", \\\"{x:1485,y:782,t:1527272086343};\\\", \\\"{x:1485,y:781,t:1527272086359};\\\", \\\"{x:1484,y:781,t:1527272086372};\\\", \\\"{x:1484,y:780,t:1527272086391};\\\", \\\"{x:1482,y:779,t:1527272086407};\\\", \\\"{x:1481,y:777,t:1527272086422};\\\", \\\"{x:1475,y:771,t:1527272086438};\\\", \\\"{x:1471,y:768,t:1527272086455};\\\", \\\"{x:1467,y:764,t:1527272086472};\\\", \\\"{x:1466,y:762,t:1527272086489};\\\", \\\"{x:1465,y:761,t:1527272086505};\\\", \\\"{x:1464,y:760,t:1527272086522};\\\", \\\"{x:1464,y:759,t:1527272086539};\\\", \\\"{x:1463,y:759,t:1527272086599};\\\", \\\"{x:1462,y:759,t:1527272086662};\\\", \\\"{x:1460,y:758,t:1527272086678};\\\", \\\"{x:1452,y:759,t:1527272086742};\\\", \\\"{x:1441,y:762,t:1527272086755};\\\", \\\"{x:1368,y:786,t:1527272086773};\\\", \\\"{x:1245,y:813,t:1527272086788};\\\", \\\"{x:1096,y:830,t:1527272086806};\\\", \\\"{x:884,y:839,t:1527272086823};\\\", \\\"{x:738,y:839,t:1527272086838};\\\", \\\"{x:596,y:839,t:1527272086855};\\\", \\\"{x:480,y:839,t:1527272086873};\\\", \\\"{x:422,y:832,t:1527272086889};\\\", \\\"{x:402,y:824,t:1527272086906};\\\", \\\"{x:393,y:817,t:1527272086923};\\\", \\\"{x:390,y:810,t:1527272086938};\\\", \\\"{x:389,y:806,t:1527272086956};\\\", \\\"{x:386,y:797,t:1527272086972};\\\", \\\"{x:384,y:788,t:1527272086989};\\\", \\\"{x:379,y:774,t:1527272087005};\\\", \\\"{x:360,y:751,t:1527272087022};\\\", \\\"{x:348,y:738,t:1527272087040};\\\", \\\"{x:344,y:732,t:1527272087055};\\\", \\\"{x:344,y:731,t:1527272087073};\\\", \\\"{x:345,y:727,t:1527272087090};\\\", \\\"{x:350,y:722,t:1527272087106};\\\", \\\"{x:356,y:720,t:1527272087122};\\\", \\\"{x:367,y:716,t:1527272087140};\\\", \\\"{x:386,y:714,t:1527272087157};\\\", \\\"{x:409,y:714,t:1527272087172};\\\", \\\"{x:433,y:719,t:1527272087189};\\\", \\\"{x:463,y:729,t:1527272087207};\\\", \\\"{x:476,y:733,t:1527272087222};\\\", \\\"{x:482,y:734,t:1527272087240};\\\", \\\"{x:483,y:734,t:1527272087256};\\\", \\\"{x:485,y:735,t:1527272087286};\\\", \\\"{x:487,y:737,t:1527272087295};\\\", \\\"{x:488,y:738,t:1527272087310};\\\", \\\"{x:490,y:738,t:1527272087322};\\\", \\\"{x:491,y:740,t:1527272087390};\\\", \\\"{x:492,y:740,t:1527272087406};\\\", \\\"{x:493,y:740,t:1527272088710};\\\" ] }, { \\\"rt\\\": 33334, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 501842, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:740,t:1527272089166};\\\", \\\"{x:495,y:740,t:1527272089174};\\\", \\\"{x:485,y:716,t:1527272089472};\\\", \\\"{x:480,y:707,t:1527272089488};\\\", \\\"{x:476,y:701,t:1527272089494};\\\", \\\"{x:475,y:699,t:1527272089507};\\\", \\\"{x:470,y:681,t:1527272089524};\\\", \\\"{x:460,y:656,t:1527272089540};\\\", \\\"{x:452,y:637,t:1527272089557};\\\", \\\"{x:442,y:615,t:1527272089574};\\\", \\\"{x:437,y:596,t:1527272089590};\\\", \\\"{x:429,y:582,t:1527272089607};\\\", \\\"{x:426,y:569,t:1527272089623};\\\", \\\"{x:425,y:563,t:1527272089640};\\\", \\\"{x:425,y:560,t:1527272089657};\\\", \\\"{x:425,y:557,t:1527272089673};\\\", \\\"{x:425,y:556,t:1527272089690};\\\", \\\"{x:428,y:551,t:1527272089950};\\\", \\\"{x:430,y:543,t:1527272089958};\\\", \\\"{x:433,y:540,t:1527272089974};\\\", \\\"{x:435,y:536,t:1527272089990};\\\", \\\"{x:436,y:534,t:1527272090006};\\\", \\\"{x:437,y:532,t:1527272090024};\\\", \\\"{x:439,y:530,t:1527272090040};\\\", \\\"{x:442,y:528,t:1527272090056};\\\", \\\"{x:444,y:528,t:1527272090074};\\\", \\\"{x:447,y:526,t:1527272090090};\\\", \\\"{x:449,y:524,t:1527272090107};\\\", \\\"{x:450,y:524,t:1527272090123};\\\", \\\"{x:450,y:523,t:1527272090141};\\\", \\\"{x:450,y:522,t:1527272090158};\\\", \\\"{x:451,y:520,t:1527272090174};\\\", \\\"{x:455,y:517,t:1527272090190};\\\", \\\"{x:460,y:514,t:1527272090207};\\\", \\\"{x:470,y:509,t:1527272090224};\\\", \\\"{x:483,y:504,t:1527272090240};\\\", \\\"{x:492,y:500,t:1527272090258};\\\", \\\"{x:494,y:499,t:1527272090273};\\\", \\\"{x:495,y:498,t:1527272090534};\\\", \\\"{x:496,y:497,t:1527272090551};\\\", \\\"{x:497,y:496,t:1527272090566};\\\", \\\"{x:499,y:495,t:1527272090584};\\\", \\\"{x:500,y:494,t:1527272090591};\\\", \\\"{x:502,y:493,t:1527272090607};\\\", \\\"{x:504,y:492,t:1527272090624};\\\", \\\"{x:507,y:489,t:1527272090642};\\\", \\\"{x:514,y:488,t:1527272090658};\\\", \\\"{x:525,y:484,t:1527272090676};\\\", \\\"{x:542,y:479,t:1527272090692};\\\", \\\"{x:566,y:473,t:1527272090708};\\\", \\\"{x:593,y:466,t:1527272090725};\\\", \\\"{x:617,y:463,t:1527272090741};\\\", \\\"{x:646,y:460,t:1527272090758};\\\", \\\"{x:672,y:457,t:1527272090775};\\\", \\\"{x:690,y:457,t:1527272090791};\\\", \\\"{x:701,y:457,t:1527272090807};\\\", \\\"{x:709,y:458,t:1527272090825};\\\", \\\"{x:712,y:459,t:1527272090842};\\\", \\\"{x:715,y:459,t:1527272090857};\\\", \\\"{x:716,y:459,t:1527272090875};\\\", \\\"{x:717,y:459,t:1527272090892};\\\", \\\"{x:718,y:459,t:1527272090918};\\\", \\\"{x:719,y:459,t:1527272090926};\\\", \\\"{x:721,y:459,t:1527272090950};\\\", \\\"{x:722,y:459,t:1527272090958};\\\", \\\"{x:728,y:459,t:1527272090974};\\\", \\\"{x:730,y:459,t:1527272090992};\\\", \\\"{x:732,y:459,t:1527272091007};\\\", \\\"{x:733,y:459,t:1527272091025};\\\", \\\"{x:735,y:459,t:1527272091095};\\\", \\\"{x:736,y:459,t:1527272091119};\\\", \\\"{x:738,y:459,t:1527272091127};\\\", \\\"{x:740,y:459,t:1527272091143};\\\", \\\"{x:742,y:459,t:1527272091158};\\\", \\\"{x:743,y:459,t:1527272091174};\\\", \\\"{x:745,y:459,t:1527272091192};\\\", \\\"{x:747,y:459,t:1527272091207};\\\", \\\"{x:748,y:459,t:1527272091225};\\\", \\\"{x:752,y:459,t:1527272091242};\\\", \\\"{x:753,y:459,t:1527272091258};\\\", \\\"{x:755,y:459,t:1527272091274};\\\", \\\"{x:758,y:459,t:1527272091292};\\\", \\\"{x:762,y:459,t:1527272091309};\\\", \\\"{x:768,y:459,t:1527272091324};\\\", \\\"{x:772,y:459,t:1527272091341};\\\", \\\"{x:775,y:459,t:1527272091358};\\\", \\\"{x:777,y:459,t:1527272091470};\\\", \\\"{x:777,y:461,t:1527272091799};\\\", \\\"{x:778,y:461,t:1527272091809};\\\", \\\"{x:779,y:461,t:1527272091826};\\\", \\\"{x:780,y:461,t:1527272092063};\\\", \\\"{x:781,y:461,t:1527272092087};\\\", \\\"{x:782,y:461,t:1527272092094};\\\", \\\"{x:784,y:461,t:1527272092110};\\\", \\\"{x:785,y:461,t:1527272092126};\\\", \\\"{x:792,y:461,t:1527272092142};\\\", \\\"{x:814,y:456,t:1527272092158};\\\", \\\"{x:844,y:453,t:1527272092176};\\\", \\\"{x:892,y:446,t:1527272092192};\\\", \\\"{x:956,y:438,t:1527272092208};\\\", \\\"{x:1037,y:425,t:1527272092226};\\\", \\\"{x:1122,y:416,t:1527272092241};\\\", \\\"{x:1205,y:406,t:1527272092259};\\\", \\\"{x:1285,y:397,t:1527272092276};\\\", \\\"{x:1336,y:390,t:1527272092293};\\\", \\\"{x:1380,y:385,t:1527272092309};\\\", \\\"{x:1402,y:383,t:1527272092325};\\\", \\\"{x:1422,y:383,t:1527272092342};\\\", \\\"{x:1426,y:383,t:1527272092359};\\\", \\\"{x:1429,y:383,t:1527272092375};\\\", \\\"{x:1433,y:382,t:1527272092393};\\\", \\\"{x:1438,y:381,t:1527272092408};\\\", \\\"{x:1445,y:380,t:1527272092426};\\\", \\\"{x:1449,y:379,t:1527272092442};\\\", \\\"{x:1453,y:379,t:1527272092459};\\\", \\\"{x:1456,y:379,t:1527272092476};\\\", \\\"{x:1457,y:379,t:1527272092493};\\\", \\\"{x:1458,y:379,t:1527272092551};\\\", \\\"{x:1459,y:380,t:1527272092583};\\\", \\\"{x:1460,y:380,t:1527272092593};\\\", \\\"{x:1461,y:382,t:1527272092609};\\\", \\\"{x:1462,y:386,t:1527272092626};\\\", \\\"{x:1463,y:392,t:1527272092643};\\\", \\\"{x:1464,y:397,t:1527272092658};\\\", \\\"{x:1464,y:401,t:1527272092675};\\\", \\\"{x:1464,y:405,t:1527272092693};\\\", \\\"{x:1464,y:411,t:1527272092709};\\\", \\\"{x:1464,y:414,t:1527272092726};\\\", \\\"{x:1459,y:420,t:1527272092743};\\\", \\\"{x:1457,y:423,t:1527272092760};\\\", \\\"{x:1455,y:426,t:1527272092776};\\\", \\\"{x:1452,y:429,t:1527272092793};\\\", \\\"{x:1449,y:431,t:1527272092809};\\\", \\\"{x:1445,y:435,t:1527272092826};\\\", \\\"{x:1440,y:438,t:1527272092843};\\\", \\\"{x:1432,y:443,t:1527272092860};\\\", \\\"{x:1426,y:446,t:1527272092876};\\\", \\\"{x:1420,y:449,t:1527272092894};\\\", \\\"{x:1417,y:452,t:1527272092911};\\\", \\\"{x:1411,y:455,t:1527272092927};\\\", \\\"{x:1403,y:459,t:1527272092943};\\\", \\\"{x:1398,y:463,t:1527272092961};\\\", \\\"{x:1391,y:467,t:1527272092977};\\\", \\\"{x:1387,y:472,t:1527272092994};\\\", \\\"{x:1382,y:474,t:1527272093011};\\\", \\\"{x:1379,y:475,t:1527272093026};\\\", \\\"{x:1375,y:477,t:1527272093044};\\\", \\\"{x:1374,y:477,t:1527272093060};\\\", \\\"{x:1372,y:478,t:1527272093077};\\\", \\\"{x:1370,y:478,t:1527272093094};\\\", \\\"{x:1369,y:478,t:1527272093110};\\\", \\\"{x:1368,y:478,t:1527272093126};\\\", \\\"{x:1366,y:479,t:1527272093143};\\\", \\\"{x:1364,y:481,t:1527272093160};\\\", \\\"{x:1363,y:481,t:1527272093177};\\\", \\\"{x:1361,y:483,t:1527272093193};\\\", \\\"{x:1360,y:484,t:1527272093209};\\\", \\\"{x:1358,y:485,t:1527272093254};\\\", \\\"{x:1354,y:487,t:1527272093679};\\\", \\\"{x:1348,y:489,t:1527272093693};\\\", \\\"{x:1336,y:497,t:1527272093710};\\\", \\\"{x:1326,y:499,t:1527272093727};\\\", \\\"{x:1321,y:500,t:1527272093744};\\\", \\\"{x:1316,y:501,t:1527272093760};\\\", \\\"{x:1312,y:502,t:1527272093777};\\\", \\\"{x:1311,y:503,t:1527272093794};\\\", \\\"{x:1310,y:503,t:1527272093830};\\\", \\\"{x:1309,y:503,t:1527272093844};\\\", \\\"{x:1308,y:503,t:1527272093860};\\\", \\\"{x:1304,y:503,t:1527272093877};\\\", \\\"{x:1303,y:503,t:1527272093895};\\\", \\\"{x:1303,y:502,t:1527272094094};\\\", \\\"{x:1304,y:501,t:1527272094110};\\\", \\\"{x:1307,y:500,t:1527272094127};\\\", \\\"{x:1308,y:498,t:1527272094144};\\\", \\\"{x:1309,y:498,t:1527272094286};\\\", \\\"{x:1310,y:498,t:1527272098607};\\\", \\\"{x:1310,y:502,t:1527272098614};\\\", \\\"{x:1304,y:510,t:1527272098630};\\\", \\\"{x:1299,y:516,t:1527272098647};\\\", \\\"{x:1293,y:521,t:1527272098664};\\\", \\\"{x:1289,y:524,t:1527272098679};\\\", \\\"{x:1288,y:525,t:1527272098697};\\\", \\\"{x:1287,y:526,t:1527272098714};\\\", \\\"{x:1287,y:527,t:1527272098730};\\\", \\\"{x:1286,y:530,t:1527272098747};\\\", \\\"{x:1284,y:535,t:1527272098764};\\\", \\\"{x:1282,y:539,t:1527272098780};\\\", \\\"{x:1281,y:544,t:1527272098797};\\\", \\\"{x:1281,y:548,t:1527272098813};\\\", \\\"{x:1281,y:549,t:1527272098862};\\\", \\\"{x:1281,y:550,t:1527272098878};\\\", \\\"{x:1281,y:551,t:1527272098886};\\\", \\\"{x:1281,y:552,t:1527272098902};\\\", \\\"{x:1281,y:553,t:1527272098914};\\\", \\\"{x:1281,y:554,t:1527272098931};\\\", \\\"{x:1281,y:555,t:1527272098947};\\\", \\\"{x:1281,y:557,t:1527272099039};\\\", \\\"{x:1282,y:557,t:1527272099054};\\\", \\\"{x:1282,y:558,t:1527272099080};\\\", \\\"{x:1283,y:559,t:1527272099097};\\\", \\\"{x:1283,y:560,t:1527272099119};\\\", \\\"{x:1283,y:561,t:1527272099134};\\\", \\\"{x:1284,y:561,t:1527272099200};\\\", \\\"{x:1284,y:562,t:1527272099223};\\\", \\\"{x:1284,y:563,t:1527272114682};\\\", \\\"{x:1268,y:563,t:1527272114697};\\\", \\\"{x:1236,y:563,t:1527272114712};\\\", \\\"{x:1222,y:561,t:1527272114729};\\\", \\\"{x:1217,y:560,t:1527272114746};\\\", \\\"{x:1217,y:559,t:1527272114785};\\\", \\\"{x:1214,y:559,t:1527272115018};\\\", \\\"{x:1207,y:559,t:1527272115029};\\\", \\\"{x:1162,y:559,t:1527272115046};\\\", \\\"{x:1056,y:560,t:1527272115063};\\\", \\\"{x:936,y:571,t:1527272115081};\\\", \\\"{x:811,y:573,t:1527272115095};\\\", \\\"{x:564,y:604,t:1527272115113};\\\", \\\"{x:370,y:631,t:1527272115132};\\\", \\\"{x:203,y:669,t:1527272115148};\\\", \\\"{x:100,y:685,t:1527272115164};\\\", \\\"{x:60,y:690,t:1527272115181};\\\", \\\"{x:34,y:694,t:1527272115198};\\\", \\\"{x:24,y:694,t:1527272115214};\\\", \\\"{x:22,y:694,t:1527272115231};\\\", \\\"{x:25,y:687,t:1527272115273};\\\", \\\"{x:31,y:680,t:1527272115281};\\\", \\\"{x:54,y:658,t:1527272115298};\\\", \\\"{x:109,y:625,t:1527272115314};\\\", \\\"{x:241,y:569,t:1527272115332};\\\", \\\"{x:397,y:518,t:1527272115348};\\\", \\\"{x:527,y:479,t:1527272115363};\\\", \\\"{x:588,y:462,t:1527272115381};\\\", \\\"{x:605,y:455,t:1527272115398};\\\", \\\"{x:606,y:455,t:1527272115414};\\\", \\\"{x:605,y:455,t:1527272115497};\\\", \\\"{x:594,y:459,t:1527272115514};\\\", \\\"{x:585,y:466,t:1527272115531};\\\", \\\"{x:583,y:469,t:1527272115546};\\\", \\\"{x:583,y:472,t:1527272115564};\\\", \\\"{x:584,y:476,t:1527272115580};\\\", \\\"{x:588,y:479,t:1527272115597};\\\", \\\"{x:591,y:480,t:1527272115614};\\\", \\\"{x:592,y:481,t:1527272115629};\\\", \\\"{x:595,y:487,t:1527272115647};\\\", \\\"{x:599,y:499,t:1527272115664};\\\", \\\"{x:601,y:512,t:1527272115681};\\\", \\\"{x:601,y:513,t:1527272115697};\\\", \\\"{x:601,y:514,t:1527272115715};\\\", \\\"{x:603,y:515,t:1527272115792};\\\", \\\"{x:604,y:516,t:1527272115801};\\\", \\\"{x:605,y:516,t:1527272115815};\\\", \\\"{x:605,y:515,t:1527272116089};\\\", \\\"{x:605,y:513,t:1527272116099};\\\", \\\"{x:605,y:510,t:1527272116115};\\\", \\\"{x:605,y:509,t:1527272116130};\\\", \\\"{x:605,y:508,t:1527272116148};\\\", \\\"{x:605,y:507,t:1527272116164};\\\", \\\"{x:605,y:506,t:1527272116233};\\\", \\\"{x:604,y:506,t:1527272116273};\\\", \\\"{x:604,y:505,t:1527272116289};\\\", \\\"{x:605,y:504,t:1527272116913};\\\", \\\"{x:614,y:501,t:1527272116921};\\\", \\\"{x:624,y:500,t:1527272116932};\\\", \\\"{x:647,y:497,t:1527272116949};\\\", \\\"{x:676,y:495,t:1527272116966};\\\", \\\"{x:706,y:495,t:1527272116982};\\\", \\\"{x:754,y:499,t:1527272117000};\\\", \\\"{x:819,y:509,t:1527272117016};\\\", \\\"{x:883,y:519,t:1527272117033};\\\", \\\"{x:953,y:531,t:1527272117049};\\\", \\\"{x:986,y:534,t:1527272117065};\\\", \\\"{x:1020,y:540,t:1527272117082};\\\", \\\"{x:1051,y:544,t:1527272117099};\\\", \\\"{x:1079,y:551,t:1527272117116};\\\", \\\"{x:1098,y:561,t:1527272117133};\\\", \\\"{x:1105,y:569,t:1527272117149};\\\", \\\"{x:1108,y:573,t:1527272117166};\\\", \\\"{x:1113,y:581,t:1527272117183};\\\", \\\"{x:1119,y:593,t:1527272117200};\\\", \\\"{x:1126,y:608,t:1527272117216};\\\", \\\"{x:1131,y:624,t:1527272117232};\\\", \\\"{x:1138,y:644,t:1527272117250};\\\", \\\"{x:1145,y:656,t:1527272117266};\\\", \\\"{x:1147,y:664,t:1527272117284};\\\", \\\"{x:1149,y:676,t:1527272117300};\\\", \\\"{x:1151,y:688,t:1527272117316};\\\", \\\"{x:1152,y:701,t:1527272117333};\\\", \\\"{x:1154,y:711,t:1527272117349};\\\", \\\"{x:1154,y:714,t:1527272117367};\\\", \\\"{x:1154,y:717,t:1527272117383};\\\", \\\"{x:1155,y:718,t:1527272117399};\\\", \\\"{x:1155,y:719,t:1527272117433};\\\", \\\"{x:1155,y:723,t:1527272117505};\\\", \\\"{x:1155,y:728,t:1527272117516};\\\", \\\"{x:1155,y:745,t:1527272117533};\\\", \\\"{x:1155,y:765,t:1527272117550};\\\", \\\"{x:1159,y:781,t:1527272117566};\\\", \\\"{x:1164,y:787,t:1527272117583};\\\", \\\"{x:1166,y:788,t:1527272117600};\\\", \\\"{x:1168,y:789,t:1527272117616};\\\", \\\"{x:1169,y:790,t:1527272117634};\\\", \\\"{x:1172,y:790,t:1527272117649};\\\", \\\"{x:1178,y:790,t:1527272117666};\\\", \\\"{x:1190,y:791,t:1527272117683};\\\", \\\"{x:1199,y:793,t:1527272117700};\\\", \\\"{x:1205,y:794,t:1527272117716};\\\", \\\"{x:1210,y:794,t:1527272117733};\\\", \\\"{x:1220,y:794,t:1527272117750};\\\", \\\"{x:1232,y:794,t:1527272117767};\\\", \\\"{x:1249,y:794,t:1527272117784};\\\", \\\"{x:1268,y:794,t:1527272117801};\\\", \\\"{x:1280,y:794,t:1527272117817};\\\", \\\"{x:1292,y:794,t:1527272117834};\\\", \\\"{x:1296,y:794,t:1527272117850};\\\", \\\"{x:1297,y:794,t:1527272117867};\\\", \\\"{x:1296,y:794,t:1527272118122};\\\", \\\"{x:1292,y:794,t:1527272118133};\\\", \\\"{x:1283,y:794,t:1527272118151};\\\", \\\"{x:1274,y:794,t:1527272118167};\\\", \\\"{x:1264,y:793,t:1527272118184};\\\", \\\"{x:1250,y:791,t:1527272118200};\\\", \\\"{x:1232,y:791,t:1527272118218};\\\", \\\"{x:1215,y:791,t:1527272118234};\\\", \\\"{x:1204,y:791,t:1527272118251};\\\", \\\"{x:1197,y:791,t:1527272118268};\\\", \\\"{x:1195,y:791,t:1527272118283};\\\", \\\"{x:1193,y:789,t:1527272118490};\\\", \\\"{x:1193,y:788,t:1527272118539};\\\", \\\"{x:1193,y:787,t:1527272118562};\\\", \\\"{x:1193,y:786,t:1527272118626};\\\", \\\"{x:1192,y:785,t:1527272118650};\\\", \\\"{x:1191,y:784,t:1527272118667};\\\", \\\"{x:1191,y:783,t:1527272121025};\\\", \\\"{x:1188,y:782,t:1527272121241};\\\", \\\"{x:1147,y:782,t:1527272121253};\\\", \\\"{x:981,y:782,t:1527272121269};\\\", \\\"{x:737,y:775,t:1527272121287};\\\", \\\"{x:473,y:749,t:1527272121303};\\\", \\\"{x:266,y:714,t:1527272121319};\\\", \\\"{x:100,y:670,t:1527272121336};\\\", \\\"{x:26,y:640,t:1527272121347};\\\", \\\"{x:17,y:634,t:1527272121364};\\\", \\\"{x:19,y:633,t:1527272121385};\\\", \\\"{x:24,y:633,t:1527272121397};\\\", \\\"{x:33,y:632,t:1527272121414};\\\", \\\"{x:41,y:631,t:1527272121430};\\\", \\\"{x:46,y:630,t:1527272121447};\\\", \\\"{x:55,y:628,t:1527272121464};\\\", \\\"{x:77,y:626,t:1527272121480};\\\", \\\"{x:146,y:618,t:1527272121503};\\\", \\\"{x:196,y:610,t:1527272121519};\\\", \\\"{x:248,y:599,t:1527272121537};\\\", \\\"{x:308,y:598,t:1527272121553};\\\", \\\"{x:330,y:598,t:1527272121569};\\\", \\\"{x:338,y:598,t:1527272121586};\\\", \\\"{x:342,y:600,t:1527272121603};\\\", \\\"{x:348,y:606,t:1527272121620};\\\", \\\"{x:362,y:616,t:1527272121635};\\\", \\\"{x:377,y:629,t:1527272121653};\\\", \\\"{x:399,y:644,t:1527272121670};\\\", \\\"{x:419,y:660,t:1527272121686};\\\", \\\"{x:432,y:674,t:1527272121703};\\\", \\\"{x:442,y:693,t:1527272121720};\\\", \\\"{x:458,y:716,t:1527272121736};\\\", \\\"{x:469,y:737,t:1527272121752};\\\", \\\"{x:483,y:757,t:1527272121769};\\\", \\\"{x:490,y:762,t:1527272121786};\\\", \\\"{x:496,y:763,t:1527272121803};\\\", \\\"{x:499,y:765,t:1527272121819};\\\", \\\"{x:500,y:765,t:1527272121836};\\\", \\\"{x:502,y:764,t:1527272121853};\\\", \\\"{x:505,y:761,t:1527272121869};\\\", \\\"{x:510,y:756,t:1527272121887};\\\", \\\"{x:513,y:751,t:1527272121904};\\\", \\\"{x:515,y:749,t:1527272121920};\\\", \\\"{x:515,y:748,t:1527272121962};\\\", \\\"{x:515,y:747,t:1527272121977};\\\", \\\"{x:515,y:746,t:1527272122001};\\\", \\\"{x:515,y:745,t:1527272122010};\\\", \\\"{x:515,y:744,t:1527272122020};\\\", \\\"{x:515,y:743,t:1527272122038};\\\", \\\"{x:515,y:742,t:1527272122057};\\\", \\\"{x:516,y:741,t:1527272123170};\\\" ] }, { \\\"rt\\\": 21214, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 524393, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -J -J -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:738,t:1527272124187};\\\", \\\"{x:516,y:731,t:1527272124203};\\\", \\\"{x:516,y:724,t:1527272124209};\\\", \\\"{x:516,y:716,t:1527272124223};\\\", \\\"{x:511,y:694,t:1527272124239};\\\", \\\"{x:507,y:675,t:1527272124256};\\\", \\\"{x:505,y:661,t:1527272124271};\\\", \\\"{x:502,y:652,t:1527272124288};\\\", \\\"{x:500,y:634,t:1527272124305};\\\", \\\"{x:500,y:616,t:1527272124321};\\\", \\\"{x:512,y:593,t:1527272124339};\\\", \\\"{x:523,y:574,t:1527272124355};\\\", \\\"{x:534,y:556,t:1527272124372};\\\", \\\"{x:541,y:544,t:1527272124388};\\\", \\\"{x:542,y:543,t:1527272124405};\\\", \\\"{x:542,y:537,t:1527272124729};\\\", \\\"{x:538,y:529,t:1527272124739};\\\", \\\"{x:529,y:511,t:1527272124757};\\\", \\\"{x:524,y:500,t:1527272124772};\\\", \\\"{x:517,y:492,t:1527272124788};\\\", \\\"{x:511,y:487,t:1527272124805};\\\", \\\"{x:504,y:483,t:1527272124822};\\\", \\\"{x:498,y:478,t:1527272124838};\\\", \\\"{x:492,y:471,t:1527272124855};\\\", \\\"{x:486,y:464,t:1527272124873};\\\", \\\"{x:483,y:460,t:1527272124888};\\\", \\\"{x:483,y:459,t:1527272124905};\\\", \\\"{x:483,y:458,t:1527272124922};\\\", \\\"{x:485,y:458,t:1527272125986};\\\", \\\"{x:486,y:458,t:1527272125993};\\\", \\\"{x:488,y:459,t:1527272126007};\\\", \\\"{x:489,y:459,t:1527272126354};\\\", \\\"{x:495,y:459,t:1527272126361};\\\", \\\"{x:504,y:455,t:1527272126373};\\\", \\\"{x:525,y:449,t:1527272126390};\\\", \\\"{x:546,y:441,t:1527272126406};\\\", \\\"{x:563,y:436,t:1527272126423};\\\", \\\"{x:579,y:433,t:1527272126439};\\\", \\\"{x:587,y:430,t:1527272126457};\\\", \\\"{x:595,y:430,t:1527272126474};\\\", \\\"{x:602,y:430,t:1527272126490};\\\", \\\"{x:606,y:430,t:1527272126507};\\\", \\\"{x:609,y:430,t:1527272126523};\\\", \\\"{x:612,y:430,t:1527272126539};\\\", \\\"{x:614,y:430,t:1527272126557};\\\", \\\"{x:615,y:430,t:1527272126573};\\\", \\\"{x:616,y:430,t:1527272126589};\\\", \\\"{x:617,y:430,t:1527272126606};\\\", \\\"{x:619,y:430,t:1527272126623};\\\", \\\"{x:623,y:430,t:1527272126639};\\\", \\\"{x:627,y:430,t:1527272126656};\\\", \\\"{x:645,y:432,t:1527272126673};\\\", \\\"{x:671,y:432,t:1527272126689};\\\", \\\"{x:713,y:432,t:1527272126707};\\\", \\\"{x:757,y:432,t:1527272126723};\\\", \\\"{x:822,y:432,t:1527272126739};\\\", \\\"{x:908,y:432,t:1527272126756};\\\", \\\"{x:1013,y:432,t:1527272126774};\\\", \\\"{x:1118,y:432,t:1527272126789};\\\", \\\"{x:1218,y:432,t:1527272126806};\\\", \\\"{x:1299,y:432,t:1527272126823};\\\", \\\"{x:1363,y:432,t:1527272126840};\\\", \\\"{x:1413,y:432,t:1527272126858};\\\", \\\"{x:1452,y:432,t:1527272126874};\\\", \\\"{x:1462,y:436,t:1527272126890};\\\", \\\"{x:1465,y:436,t:1527272126906};\\\", \\\"{x:1466,y:436,t:1527272126985};\\\", \\\"{x:1466,y:437,t:1527272127009};\\\", \\\"{x:1467,y:438,t:1527272127025};\\\", \\\"{x:1467,y:441,t:1527272127122};\\\", \\\"{x:1466,y:443,t:1527272127137};\\\", \\\"{x:1464,y:445,t:1527272127145};\\\", \\\"{x:1461,y:448,t:1527272127157};\\\", \\\"{x:1455,y:457,t:1527272127174};\\\", \\\"{x:1451,y:464,t:1527272127191};\\\", \\\"{x:1449,y:466,t:1527272127207};\\\", \\\"{x:1449,y:469,t:1527272127224};\\\", \\\"{x:1449,y:471,t:1527272127241};\\\", \\\"{x:1449,y:472,t:1527272127256};\\\", \\\"{x:1449,y:476,t:1527272127274};\\\", \\\"{x:1448,y:480,t:1527272127290};\\\", \\\"{x:1448,y:488,t:1527272127306};\\\", \\\"{x:1445,y:495,t:1527272127324};\\\", \\\"{x:1443,y:503,t:1527272127340};\\\", \\\"{x:1441,y:511,t:1527272127356};\\\", \\\"{x:1439,y:519,t:1527272127373};\\\", \\\"{x:1436,y:533,t:1527272127390};\\\", \\\"{x:1434,y:554,t:1527272127407};\\\", \\\"{x:1431,y:572,t:1527272127423};\\\", \\\"{x:1431,y:587,t:1527272127441};\\\", \\\"{x:1429,y:599,t:1527272127457};\\\", \\\"{x:1429,y:604,t:1527272127473};\\\", \\\"{x:1429,y:607,t:1527272127491};\\\", \\\"{x:1429,y:611,t:1527272127507};\\\", \\\"{x:1429,y:615,t:1527272127523};\\\", \\\"{x:1428,y:621,t:1527272127540};\\\", \\\"{x:1428,y:626,t:1527272127557};\\\", \\\"{x:1428,y:630,t:1527272127573};\\\", \\\"{x:1428,y:633,t:1527272127590};\\\", \\\"{x:1428,y:635,t:1527272127607};\\\", \\\"{x:1428,y:637,t:1527272127623};\\\", \\\"{x:1428,y:638,t:1527272127640};\\\", \\\"{x:1430,y:643,t:1527272127657};\\\", \\\"{x:1431,y:646,t:1527272127673};\\\", \\\"{x:1436,y:651,t:1527272127690};\\\", \\\"{x:1439,y:654,t:1527272127707};\\\", \\\"{x:1445,y:656,t:1527272127723};\\\", \\\"{x:1448,y:658,t:1527272127740};\\\", \\\"{x:1454,y:661,t:1527272127757};\\\", \\\"{x:1458,y:663,t:1527272127773};\\\", \\\"{x:1461,y:665,t:1527272127790};\\\", \\\"{x:1464,y:666,t:1527272127807};\\\", \\\"{x:1468,y:669,t:1527272127823};\\\", \\\"{x:1473,y:671,t:1527272127841};\\\", \\\"{x:1486,y:679,t:1527272127857};\\\", \\\"{x:1491,y:682,t:1527272127874};\\\", \\\"{x:1499,y:687,t:1527272127890};\\\", \\\"{x:1505,y:690,t:1527272127908};\\\", \\\"{x:1512,y:694,t:1527272127924};\\\", \\\"{x:1518,y:697,t:1527272127941};\\\", \\\"{x:1524,y:700,t:1527272127958};\\\", \\\"{x:1532,y:705,t:1527272127974};\\\", \\\"{x:1540,y:710,t:1527272127990};\\\", \\\"{x:1544,y:714,t:1527272128008};\\\", \\\"{x:1550,y:718,t:1527272128025};\\\", \\\"{x:1555,y:721,t:1527272128041};\\\", \\\"{x:1564,y:729,t:1527272128057};\\\", \\\"{x:1571,y:735,t:1527272128075};\\\", \\\"{x:1576,y:739,t:1527272128091};\\\", \\\"{x:1578,y:742,t:1527272128108};\\\", \\\"{x:1578,y:745,t:1527272128124};\\\", \\\"{x:1578,y:749,t:1527272128141};\\\", \\\"{x:1577,y:760,t:1527272128158};\\\", \\\"{x:1571,y:767,t:1527272128175};\\\", \\\"{x:1562,y:776,t:1527272128191};\\\", \\\"{x:1546,y:784,t:1527272128208};\\\", \\\"{x:1525,y:789,t:1527272128225};\\\", \\\"{x:1503,y:795,t:1527272128241};\\\", \\\"{x:1471,y:799,t:1527272128257};\\\", \\\"{x:1454,y:800,t:1527272128275};\\\", \\\"{x:1435,y:800,t:1527272128291};\\\", \\\"{x:1418,y:800,t:1527272128308};\\\", \\\"{x:1392,y:800,t:1527272128325};\\\", \\\"{x:1371,y:800,t:1527272128341};\\\", \\\"{x:1351,y:800,t:1527272128357};\\\", \\\"{x:1333,y:800,t:1527272128375};\\\", \\\"{x:1322,y:800,t:1527272128391};\\\", \\\"{x:1314,y:800,t:1527272128408};\\\", \\\"{x:1307,y:802,t:1527272128424};\\\", \\\"{x:1304,y:803,t:1527272128441};\\\", \\\"{x:1295,y:807,t:1527272128458};\\\", \\\"{x:1285,y:811,t:1527272128475};\\\", \\\"{x:1274,y:812,t:1527272128491};\\\", \\\"{x:1260,y:817,t:1527272128507};\\\", \\\"{x:1247,y:821,t:1527272128525};\\\", \\\"{x:1236,y:826,t:1527272128541};\\\", \\\"{x:1232,y:826,t:1527272128558};\\\", \\\"{x:1228,y:827,t:1527272128575};\\\", \\\"{x:1226,y:827,t:1527272128592};\\\", \\\"{x:1223,y:827,t:1527272128608};\\\", \\\"{x:1221,y:827,t:1527272128762};\\\", \\\"{x:1220,y:826,t:1527272129145};\\\", \\\"{x:1219,y:826,t:1527272129158};\\\", \\\"{x:1218,y:824,t:1527272129174};\\\", \\\"{x:1217,y:822,t:1527272129191};\\\", \\\"{x:1214,y:819,t:1527272129209};\\\", \\\"{x:1212,y:816,t:1527272129225};\\\", \\\"{x:1209,y:813,t:1527272129241};\\\", \\\"{x:1207,y:810,t:1527272129258};\\\", \\\"{x:1205,y:807,t:1527272129275};\\\", \\\"{x:1204,y:805,t:1527272129292};\\\", \\\"{x:1203,y:803,t:1527272129308};\\\", \\\"{x:1201,y:802,t:1527272129324};\\\", \\\"{x:1200,y:801,t:1527272129345};\\\", \\\"{x:1200,y:800,t:1527272129513};\\\", \\\"{x:1199,y:799,t:1527272129890};\\\", \\\"{x:1199,y:798,t:1527272129897};\\\", \\\"{x:1199,y:797,t:1527272129909};\\\", \\\"{x:1199,y:796,t:1527272129930};\\\", \\\"{x:1199,y:795,t:1527272129942};\\\", \\\"{x:1199,y:794,t:1527272129959};\\\", \\\"{x:1199,y:792,t:1527272130043};\\\", \\\"{x:1199,y:791,t:1527272130059};\\\", \\\"{x:1199,y:790,t:1527272130076};\\\", \\\"{x:1199,y:787,t:1527272130092};\\\", \\\"{x:1198,y:787,t:1527272130109};\\\", \\\"{x:1198,y:786,t:1527272130126};\\\", \\\"{x:1198,y:784,t:1527272130142};\\\", \\\"{x:1196,y:782,t:1527272130159};\\\", \\\"{x:1196,y:781,t:1527272130176};\\\", \\\"{x:1196,y:779,t:1527272130192};\\\", \\\"{x:1195,y:777,t:1527272130209};\\\", \\\"{x:1195,y:776,t:1527272130226};\\\", \\\"{x:1194,y:775,t:1527272130554};\\\", \\\"{x:1192,y:774,t:1527272130962};\\\", \\\"{x:1191,y:774,t:1527272131010};\\\", \\\"{x:1190,y:772,t:1527272131289};\\\", \\\"{x:1190,y:771,t:1527272131296};\\\", \\\"{x:1190,y:770,t:1527272131309};\\\", \\\"{x:1190,y:769,t:1527272131345};\\\", \\\"{x:1189,y:768,t:1527272131985};\\\", \\\"{x:1188,y:768,t:1527272132049};\\\", \\\"{x:1187,y:768,t:1527272132066};\\\", \\\"{x:1186,y:768,t:1527272132077};\\\", \\\"{x:1187,y:768,t:1527272134825};\\\", \\\"{x:1188,y:768,t:1527272134841};\\\", \\\"{x:1189,y:768,t:1527272134856};\\\", \\\"{x:1190,y:768,t:1527272134873};\\\", \\\"{x:1191,y:768,t:1527272134897};\\\", \\\"{x:1193,y:768,t:1527272134921};\\\", \\\"{x:1195,y:768,t:1527272134929};\\\", \\\"{x:1198,y:767,t:1527272134945};\\\", \\\"{x:1202,y:766,t:1527272134962};\\\", \\\"{x:1204,y:765,t:1527272134979};\\\", \\\"{x:1206,y:765,t:1527272134994};\\\", \\\"{x:1207,y:765,t:1527272135056};\\\", \\\"{x:1209,y:765,t:1527272135081};\\\", \\\"{x:1209,y:764,t:1527272135094};\\\", \\\"{x:1210,y:764,t:1527272135111};\\\", \\\"{x:1213,y:763,t:1527272135129};\\\", \\\"{x:1215,y:762,t:1527272135145};\\\", \\\"{x:1217,y:761,t:1527272135162};\\\", \\\"{x:1220,y:761,t:1527272135179};\\\", \\\"{x:1221,y:761,t:1527272135195};\\\", \\\"{x:1224,y:759,t:1527272135225};\\\", \\\"{x:1226,y:759,t:1527272135274};\\\", \\\"{x:1228,y:759,t:1527272135305};\\\", \\\"{x:1229,y:759,t:1527272135385};\\\", \\\"{x:1230,y:759,t:1527272135401};\\\", \\\"{x:1231,y:759,t:1527272135411};\\\", \\\"{x:1233,y:759,t:1527272135465};\\\", \\\"{x:1234,y:759,t:1527272136666};\\\", \\\"{x:1235,y:759,t:1527272136680};\\\", \\\"{x:1236,y:759,t:1527272136696};\\\", \\\"{x:1237,y:759,t:1527272136729};\\\", \\\"{x:1238,y:759,t:1527272137280};\\\", \\\"{x:1239,y:759,t:1527272137369};\\\", \\\"{x:1243,y:759,t:1527272137466};\\\", \\\"{x:1243,y:758,t:1527272137481};\\\", \\\"{x:1245,y:758,t:1527272137497};\\\", \\\"{x:1249,y:757,t:1527272137513};\\\", \\\"{x:1253,y:755,t:1527272137529};\\\", \\\"{x:1257,y:754,t:1527272137547};\\\", \\\"{x:1261,y:753,t:1527272137563};\\\", \\\"{x:1262,y:753,t:1527272137580};\\\", \\\"{x:1264,y:753,t:1527272137596};\\\", \\\"{x:1267,y:753,t:1527272137614};\\\", \\\"{x:1278,y:753,t:1527272137630};\\\", \\\"{x:1296,y:753,t:1527272137647};\\\", \\\"{x:1315,y:757,t:1527272137663};\\\", \\\"{x:1329,y:759,t:1527272137680};\\\", \\\"{x:1338,y:762,t:1527272137697};\\\", \\\"{x:1335,y:762,t:1527272138169};\\\", \\\"{x:1331,y:762,t:1527272138180};\\\", \\\"{x:1322,y:762,t:1527272138197};\\\", \\\"{x:1315,y:762,t:1527272138214};\\\", \\\"{x:1311,y:762,t:1527272138230};\\\", \\\"{x:1305,y:762,t:1527272138247};\\\", \\\"{x:1306,y:761,t:1527272138570};\\\", \\\"{x:1310,y:761,t:1527272138581};\\\", \\\"{x:1325,y:759,t:1527272138597};\\\", \\\"{x:1342,y:758,t:1527272138614};\\\", \\\"{x:1357,y:758,t:1527272138631};\\\", \\\"{x:1366,y:758,t:1527272138647};\\\", \\\"{x:1368,y:758,t:1527272138663};\\\", \\\"{x:1369,y:758,t:1527272138681};\\\", \\\"{x:1370,y:758,t:1527272138824};\\\", \\\"{x:1371,y:758,t:1527272138849};\\\", \\\"{x:1372,y:757,t:1527272138864};\\\", \\\"{x:1370,y:758,t:1527272139593};\\\", \\\"{x:1366,y:761,t:1527272139601};\\\", \\\"{x:1362,y:762,t:1527272139614};\\\", \\\"{x:1348,y:763,t:1527272139630};\\\", \\\"{x:1332,y:765,t:1527272139648};\\\", \\\"{x:1305,y:765,t:1527272139664};\\\", \\\"{x:1278,y:765,t:1527272139680};\\\", \\\"{x:1224,y:765,t:1527272139697};\\\", \\\"{x:1173,y:765,t:1527272139714};\\\", \\\"{x:1136,y:765,t:1527272139730};\\\", \\\"{x:1102,y:765,t:1527272139747};\\\", \\\"{x:1070,y:765,t:1527272139764};\\\", \\\"{x:1047,y:765,t:1527272139781};\\\", \\\"{x:1037,y:765,t:1527272139798};\\\", \\\"{x:1032,y:765,t:1527272139815};\\\", \\\"{x:1021,y:765,t:1527272139832};\\\", \\\"{x:982,y:765,t:1527272139848};\\\", \\\"{x:832,y:736,t:1527272139864};\\\", \\\"{x:705,y:705,t:1527272139881};\\\", \\\"{x:605,y:673,t:1527272139897};\\\", \\\"{x:530,y:641,t:1527272139914};\\\", \\\"{x:478,y:618,t:1527272139931};\\\", \\\"{x:448,y:597,t:1527272139948};\\\", \\\"{x:424,y:581,t:1527272139964};\\\", \\\"{x:412,y:570,t:1527272139980};\\\", \\\"{x:406,y:564,t:1527272139997};\\\", \\\"{x:402,y:562,t:1527272140018};\\\", \\\"{x:402,y:560,t:1527272140064};\\\", \\\"{x:402,y:558,t:1527272140073};\\\", \\\"{x:407,y:556,t:1527272140084};\\\", \\\"{x:415,y:550,t:1527272140101};\\\", \\\"{x:432,y:537,t:1527272140118};\\\", \\\"{x:444,y:525,t:1527272140133};\\\", \\\"{x:450,y:521,t:1527272140152};\\\", \\\"{x:452,y:519,t:1527272140167};\\\", \\\"{x:453,y:518,t:1527272140184};\\\", \\\"{x:451,y:518,t:1527272140625};\\\", \\\"{x:447,y:518,t:1527272140634};\\\", \\\"{x:433,y:520,t:1527272140649};\\\", \\\"{x:423,y:521,t:1527272140667};\\\", \\\"{x:407,y:521,t:1527272140684};\\\", \\\"{x:384,y:525,t:1527272140700};\\\", \\\"{x:353,y:526,t:1527272140716};\\\", \\\"{x:327,y:526,t:1527272140735};\\\", \\\"{x:308,y:526,t:1527272140752};\\\", \\\"{x:298,y:526,t:1527272140768};\\\", \\\"{x:280,y:526,t:1527272140785};\\\", \\\"{x:272,y:526,t:1527272140804};\\\", \\\"{x:267,y:526,t:1527272140818};\\\", \\\"{x:263,y:526,t:1527272140834};\\\", \\\"{x:249,y:526,t:1527272140852};\\\", \\\"{x:227,y:526,t:1527272140868};\\\", \\\"{x:206,y:526,t:1527272140885};\\\", \\\"{x:187,y:523,t:1527272140901};\\\", \\\"{x:181,y:523,t:1527272140919};\\\", \\\"{x:179,y:520,t:1527272140935};\\\", \\\"{x:178,y:519,t:1527272140952};\\\", \\\"{x:174,y:517,t:1527272140968};\\\", \\\"{x:162,y:511,t:1527272140985};\\\", \\\"{x:150,y:506,t:1527272141002};\\\", \\\"{x:144,y:504,t:1527272141019};\\\", \\\"{x:143,y:504,t:1527272141035};\\\", \\\"{x:142,y:503,t:1527272141064};\\\", \\\"{x:144,y:503,t:1527272141297};\\\", \\\"{x:146,y:503,t:1527272141320};\\\", \\\"{x:147,y:503,t:1527272141345};\\\", \\\"{x:149,y:502,t:1527272141402};\\\", \\\"{x:150,y:502,t:1527272141435};\\\", \\\"{x:150,y:502,t:1527272141531};\\\", \\\"{x:152,y:504,t:1527272141729};\\\", \\\"{x:160,y:510,t:1527272141737};\\\", \\\"{x:171,y:518,t:1527272141752};\\\", \\\"{x:218,y:546,t:1527272141768};\\\", \\\"{x:289,y:575,t:1527272141785};\\\", \\\"{x:400,y:633,t:1527272141803};\\\", \\\"{x:448,y:677,t:1527272141818};\\\", \\\"{x:482,y:704,t:1527272141836};\\\", \\\"{x:490,y:708,t:1527272141853};\\\", \\\"{x:488,y:708,t:1527272141880};\\\", \\\"{x:473,y:692,t:1527272141888};\\\", \\\"{x:451,y:676,t:1527272141903};\\\", \\\"{x:393,y:639,t:1527272141919};\\\", \\\"{x:319,y:595,t:1527272141936};\\\", \\\"{x:191,y:522,t:1527272141953};\\\", \\\"{x:89,y:464,t:1527272141969};\\\", \\\"{x:0,y:416,t:1527272141986};\\\", \\\"{x:0,y:397,t:1527272142003};\\\", \\\"{x:0,y:395,t:1527272142019};\\\", \\\"{x:1,y:395,t:1527272142065};\\\", \\\"{x:2,y:395,t:1527272142072};\\\", \\\"{x:3,y:395,t:1527272142085};\\\", \\\"{x:7,y:395,t:1527272142102};\\\", \\\"{x:17,y:395,t:1527272142119};\\\", \\\"{x:34,y:403,t:1527272142136};\\\", \\\"{x:57,y:418,t:1527272142153};\\\", \\\"{x:67,y:426,t:1527272142169};\\\", \\\"{x:73,y:434,t:1527272142186};\\\", \\\"{x:76,y:440,t:1527272142203};\\\", \\\"{x:79,y:442,t:1527272142220};\\\", \\\"{x:82,y:445,t:1527272142236};\\\", \\\"{x:84,y:451,t:1527272142252};\\\", \\\"{x:86,y:455,t:1527272142269};\\\", \\\"{x:87,y:460,t:1527272142286};\\\", \\\"{x:90,y:465,t:1527272142302};\\\", \\\"{x:92,y:471,t:1527272142320};\\\", \\\"{x:99,y:482,t:1527272142335};\\\", \\\"{x:103,y:486,t:1527272142353};\\\", \\\"{x:104,y:487,t:1527272142402};\\\", \\\"{x:116,y:490,t:1527272142419};\\\", \\\"{x:135,y:495,t:1527272142435};\\\", \\\"{x:155,y:497,t:1527272142452};\\\", \\\"{x:162,y:497,t:1527272142468};\\\", \\\"{x:166,y:499,t:1527272142485};\\\", \\\"{x:167,y:499,t:1527272142569};\\\", \\\"{x:168,y:499,t:1527272142753};\\\", \\\"{x:168,y:499,t:1527272142862};\\\", \\\"{x:168,y:497,t:1527272142888};\\\", \\\"{x:167,y:497,t:1527272142903};\\\", \\\"{x:165,y:497,t:1527272142920};\\\", \\\"{x:161,y:497,t:1527272142936};\\\", \\\"{x:161,y:501,t:1527272143024};\\\", \\\"{x:161,y:508,t:1527272143036};\\\", \\\"{x:175,y:532,t:1527272143053};\\\", \\\"{x:207,y:573,t:1527272143070};\\\", \\\"{x:273,y:641,t:1527272143087};\\\", \\\"{x:356,y:711,t:1527272143103};\\\", \\\"{x:430,y:757,t:1527272143120};\\\", \\\"{x:499,y:784,t:1527272143137};\\\", \\\"{x:508,y:788,t:1527272143154};\\\", \\\"{x:511,y:790,t:1527272143170};\\\", \\\"{x:513,y:789,t:1527272143248};\\\", \\\"{x:514,y:786,t:1527272143257};\\\", \\\"{x:516,y:784,t:1527272143273};\\\", \\\"{x:516,y:783,t:1527272143287};\\\", \\\"{x:520,y:778,t:1527272143304};\\\", \\\"{x:520,y:767,t:1527272143320};\\\", \\\"{x:520,y:733,t:1527272143337};\\\", \\\"{x:520,y:722,t:1527272143354};\\\", \\\"{x:522,y:718,t:1527272143371};\\\", \\\"{x:522,y:717,t:1527272143387};\\\", \\\"{x:522,y:716,t:1527272143408};\\\", \\\"{x:524,y:716,t:1527272143656};\\\", \\\"{x:526,y:717,t:1527272143670};\\\", \\\"{x:528,y:723,t:1527272143688};\\\", \\\"{x:530,y:726,t:1527272143704};\\\", \\\"{x:530,y:731,t:1527272143720};\\\", \\\"{x:534,y:752,t:1527272143737};\\\", \\\"{x:535,y:760,t:1527272143753};\\\", \\\"{x:535,y:762,t:1527272143770};\\\", \\\"{x:535,y:761,t:1527272144233};\\\", \\\"{x:535,y:759,t:1527272144257};\\\", \\\"{x:535,y:758,t:1527272144271};\\\", \\\"{x:536,y:757,t:1527272144288};\\\", \\\"{x:536,y:756,t:1527272144458};\\\", \\\"{x:536,y:755,t:1527272144473};\\\", \\\"{x:536,y:754,t:1527272144474};\\\", \\\"{x:535,y:754,t:1527272144489};\\\", \\\"{x:535,y:753,t:1527272144538};\\\", \\\"{x:535,y:751,t:1527272144555};\\\", \\\"{x:535,y:750,t:1527272144572};\\\", \\\"{x:535,y:748,t:1527272144588};\\\", \\\"{x:535,y:745,t:1527272144606};\\\", \\\"{x:535,y:738,t:1527272144621};\\\", \\\"{x:537,y:732,t:1527272144638};\\\" ] }, { \\\"rt\\\": 48961, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 574571, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -Z -Z -Z -X -B -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:729,t:1527272146576};\\\", \\\"{x:534,y:716,t:1527272146589};\\\", \\\"{x:510,y:653,t:1527272146609};\\\", \\\"{x:504,y:637,t:1527272146623};\\\", \\\"{x:491,y:607,t:1527272146640};\\\", \\\"{x:487,y:582,t:1527272146656};\\\", \\\"{x:484,y:542,t:1527272146672};\\\", \\\"{x:493,y:511,t:1527272146690};\\\", \\\"{x:501,y:492,t:1527272146706};\\\", \\\"{x:502,y:486,t:1527272146723};\\\", \\\"{x:502,y:485,t:1527272146761};\\\", \\\"{x:506,y:485,t:1527272147304};\\\", \\\"{x:510,y:485,t:1527272147312};\\\", \\\"{x:511,y:485,t:1527272147322};\\\", \\\"{x:513,y:485,t:1527272147339};\\\", \\\"{x:514,y:485,t:1527272147356};\\\", \\\"{x:516,y:485,t:1527272147372};\\\", \\\"{x:517,y:485,t:1527272147388};\\\", \\\"{x:518,y:485,t:1527272147406};\\\", \\\"{x:520,y:485,t:1527272147425};\\\", \\\"{x:521,y:485,t:1527272147439};\\\", \\\"{x:523,y:485,t:1527272147456};\\\", \\\"{x:525,y:485,t:1527272147471};\\\", \\\"{x:529,y:485,t:1527272147489};\\\", \\\"{x:530,y:485,t:1527272147506};\\\", \\\"{x:532,y:485,t:1527272147522};\\\", \\\"{x:533,y:485,t:1527272147539};\\\", \\\"{x:534,y:485,t:1527272147556};\\\", \\\"{x:537,y:484,t:1527272147573};\\\", \\\"{x:542,y:482,t:1527272147590};\\\", \\\"{x:547,y:481,t:1527272147607};\\\", \\\"{x:555,y:479,t:1527272147622};\\\", \\\"{x:560,y:478,t:1527272147639};\\\", \\\"{x:564,y:478,t:1527272147656};\\\", \\\"{x:570,y:478,t:1527272147672};\\\", \\\"{x:574,y:478,t:1527272147688};\\\", \\\"{x:579,y:478,t:1527272147707};\\\", \\\"{x:593,y:480,t:1527272147723};\\\", \\\"{x:608,y:483,t:1527272147740};\\\", \\\"{x:623,y:489,t:1527272147757};\\\", \\\"{x:636,y:494,t:1527272147773};\\\", \\\"{x:642,y:497,t:1527272147791};\\\", \\\"{x:646,y:499,t:1527272147807};\\\", \\\"{x:653,y:502,t:1527272147824};\\\", \\\"{x:655,y:505,t:1527272147840};\\\", \\\"{x:657,y:506,t:1527272147857};\\\", \\\"{x:663,y:509,t:1527272147875};\\\", \\\"{x:669,y:511,t:1527272147890};\\\", \\\"{x:678,y:514,t:1527272147907};\\\", \\\"{x:686,y:514,t:1527272147924};\\\", \\\"{x:695,y:516,t:1527272147941};\\\", \\\"{x:708,y:518,t:1527272147959};\\\", \\\"{x:715,y:521,t:1527272147974};\\\", \\\"{x:720,y:521,t:1527272147991};\\\", \\\"{x:722,y:523,t:1527272148007};\\\", \\\"{x:724,y:523,t:1527272148024};\\\", \\\"{x:726,y:524,t:1527272148641};\\\", \\\"{x:733,y:530,t:1527272148658};\\\", \\\"{x:753,y:542,t:1527272148674};\\\", \\\"{x:780,y:553,t:1527272148690};\\\", \\\"{x:818,y:569,t:1527272148708};\\\", \\\"{x:873,y:591,t:1527272148724};\\\", \\\"{x:924,y:606,t:1527272148742};\\\", \\\"{x:964,y:620,t:1527272148758};\\\", \\\"{x:1010,y:631,t:1527272148775};\\\", \\\"{x:1045,y:636,t:1527272148791};\\\", \\\"{x:1071,y:640,t:1527272148808};\\\", \\\"{x:1105,y:643,t:1527272148824};\\\", \\\"{x:1124,y:643,t:1527272148841};\\\", \\\"{x:1136,y:643,t:1527272148858};\\\", \\\"{x:1149,y:643,t:1527272148875};\\\", \\\"{x:1161,y:643,t:1527272148891};\\\", \\\"{x:1177,y:646,t:1527272148908};\\\", \\\"{x:1194,y:648,t:1527272148925};\\\", \\\"{x:1208,y:651,t:1527272148941};\\\", \\\"{x:1222,y:653,t:1527272148958};\\\", \\\"{x:1239,y:656,t:1527272148975};\\\", \\\"{x:1253,y:658,t:1527272148991};\\\", \\\"{x:1269,y:658,t:1527272149008};\\\", \\\"{x:1298,y:662,t:1527272149025};\\\", \\\"{x:1316,y:663,t:1527272149041};\\\", \\\"{x:1329,y:664,t:1527272149058};\\\", \\\"{x:1340,y:664,t:1527272149075};\\\", \\\"{x:1346,y:666,t:1527272149091};\\\", \\\"{x:1353,y:666,t:1527272149108};\\\", \\\"{x:1356,y:667,t:1527272149125};\\\", \\\"{x:1357,y:667,t:1527272149142};\\\", \\\"{x:1361,y:669,t:1527272149449};\\\", \\\"{x:1366,y:674,t:1527272149458};\\\", \\\"{x:1373,y:681,t:1527272149475};\\\", \\\"{x:1385,y:689,t:1527272149492};\\\", \\\"{x:1393,y:691,t:1527272149508};\\\", \\\"{x:1398,y:693,t:1527272149525};\\\", \\\"{x:1402,y:694,t:1527272149542};\\\", \\\"{x:1404,y:694,t:1527272149560};\\\", \\\"{x:1406,y:694,t:1527272149600};\\\", \\\"{x:1407,y:694,t:1527272149664};\\\", \\\"{x:1408,y:694,t:1527272149890};\\\", \\\"{x:1409,y:693,t:1527272149922};\\\", \\\"{x:1409,y:691,t:1527272149945};\\\", \\\"{x:1409,y:690,t:1527272149961};\\\", \\\"{x:1409,y:689,t:1527272149977};\\\", \\\"{x:1409,y:688,t:1527272149992};\\\", \\\"{x:1409,y:687,t:1527272150040};\\\", \\\"{x:1404,y:687,t:1527272150048};\\\", \\\"{x:1393,y:687,t:1527272150059};\\\", \\\"{x:1367,y:687,t:1527272150076};\\\", \\\"{x:1336,y:687,t:1527272150092};\\\", \\\"{x:1302,y:687,t:1527272150109};\\\", \\\"{x:1284,y:684,t:1527272150126};\\\", \\\"{x:1276,y:683,t:1527272150142};\\\", \\\"{x:1275,y:682,t:1527272150159};\\\", \\\"{x:1274,y:682,t:1527272150184};\\\", \\\"{x:1274,y:681,t:1527272150217};\\\", \\\"{x:1274,y:680,t:1527272150272};\\\", \\\"{x:1275,y:679,t:1527272150280};\\\", \\\"{x:1278,y:678,t:1527272150292};\\\", \\\"{x:1280,y:677,t:1527272150309};\\\", \\\"{x:1285,y:676,t:1527272150327};\\\", \\\"{x:1290,y:674,t:1527272150342};\\\", \\\"{x:1300,y:673,t:1527272150359};\\\", \\\"{x:1313,y:673,t:1527272150376};\\\", \\\"{x:1324,y:674,t:1527272150392};\\\", \\\"{x:1341,y:682,t:1527272150410};\\\", \\\"{x:1345,y:684,t:1527272150426};\\\", \\\"{x:1347,y:686,t:1527272150442};\\\", \\\"{x:1348,y:687,t:1527272150459};\\\", \\\"{x:1349,y:687,t:1527272150512};\\\", \\\"{x:1349,y:688,t:1527272150526};\\\", \\\"{x:1348,y:689,t:1527272150542};\\\", \\\"{x:1346,y:691,t:1527272150569};\\\", \\\"{x:1346,y:693,t:1527272150861};\\\", \\\"{x:1346,y:695,t:1527272150876};\\\", \\\"{x:1346,y:696,t:1527272150892};\\\", \\\"{x:1346,y:698,t:1527272150928};\\\", \\\"{x:1346,y:699,t:1527272150993};\\\", \\\"{x:1348,y:700,t:1527272151024};\\\", \\\"{x:1349,y:701,t:1527272151040};\\\", \\\"{x:1350,y:701,t:1527272151056};\\\", \\\"{x:1350,y:702,t:1527272151065};\\\", \\\"{x:1351,y:703,t:1527272151081};\\\", \\\"{x:1352,y:704,t:1527272151093};\\\", \\\"{x:1353,y:704,t:1527272151249};\\\", \\\"{x:1354,y:704,t:1527272151264};\\\", \\\"{x:1355,y:704,t:1527272151276};\\\", \\\"{x:1356,y:704,t:1527272151294};\\\", \\\"{x:1359,y:703,t:1527272151310};\\\", \\\"{x:1363,y:701,t:1527272151327};\\\", \\\"{x:1367,y:699,t:1527272151343};\\\", \\\"{x:1374,y:698,t:1527272151360};\\\", \\\"{x:1385,y:698,t:1527272151376};\\\", \\\"{x:1395,y:698,t:1527272151393};\\\", \\\"{x:1403,y:698,t:1527272151410};\\\", \\\"{x:1411,y:698,t:1527272151427};\\\", \\\"{x:1412,y:698,t:1527272151443};\\\", \\\"{x:1415,y:697,t:1527272151761};\\\", \\\"{x:1421,y:696,t:1527272151778};\\\", \\\"{x:1423,y:696,t:1527272151794};\\\", \\\"{x:1427,y:696,t:1527272151811};\\\", \\\"{x:1431,y:696,t:1527272151828};\\\", \\\"{x:1438,y:696,t:1527272151844};\\\", \\\"{x:1445,y:696,t:1527272151861};\\\", \\\"{x:1453,y:696,t:1527272151877};\\\", \\\"{x:1459,y:696,t:1527272151894};\\\", \\\"{x:1461,y:696,t:1527272151910};\\\", \\\"{x:1463,y:695,t:1527272151928};\\\", \\\"{x:1464,y:695,t:1527272151986};\\\", \\\"{x:1465,y:695,t:1527272152001};\\\", \\\"{x:1467,y:695,t:1527272152010};\\\", \\\"{x:1469,y:694,t:1527272152028};\\\", \\\"{x:1472,y:693,t:1527272152045};\\\", \\\"{x:1475,y:693,t:1527272152061};\\\", \\\"{x:1478,y:693,t:1527272152078};\\\", \\\"{x:1479,y:691,t:1527272152095};\\\", \\\"{x:1481,y:691,t:1527272152154};\\\", \\\"{x:1482,y:691,t:1527272152161};\\\", \\\"{x:1484,y:691,t:1527272152177};\\\", \\\"{x:1485,y:691,t:1527272152194};\\\", \\\"{x:1487,y:691,t:1527272152217};\\\", \\\"{x:1487,y:692,t:1527272152322};\\\", \\\"{x:1489,y:692,t:1527272152537};\\\", \\\"{x:1492,y:692,t:1527272152545};\\\", \\\"{x:1496,y:692,t:1527272152561};\\\", \\\"{x:1501,y:692,t:1527272152578};\\\", \\\"{x:1517,y:692,t:1527272152595};\\\", \\\"{x:1534,y:692,t:1527272152612};\\\", \\\"{x:1551,y:692,t:1527272152628};\\\", \\\"{x:1562,y:692,t:1527272152645};\\\", \\\"{x:1563,y:692,t:1527272152662};\\\", \\\"{x:1562,y:692,t:1527272152800};\\\", \\\"{x:1561,y:692,t:1527272152816};\\\", \\\"{x:1560,y:692,t:1527272152832};\\\", \\\"{x:1559,y:692,t:1527272152844};\\\", \\\"{x:1556,y:692,t:1527272152861};\\\", \\\"{x:1550,y:694,t:1527272152878};\\\", \\\"{x:1547,y:694,t:1527272152895};\\\", \\\"{x:1548,y:694,t:1527272153090};\\\", \\\"{x:1550,y:694,t:1527272153097};\\\", \\\"{x:1552,y:694,t:1527272153112};\\\", \\\"{x:1559,y:694,t:1527272153130};\\\", \\\"{x:1566,y:694,t:1527272153145};\\\", \\\"{x:1571,y:694,t:1527272153162};\\\", \\\"{x:1576,y:694,t:1527272153179};\\\", \\\"{x:1578,y:694,t:1527272153196};\\\", \\\"{x:1580,y:694,t:1527272153212};\\\", \\\"{x:1581,y:694,t:1527272153346};\\\", \\\"{x:1586,y:694,t:1527272153362};\\\", \\\"{x:1590,y:694,t:1527272153379};\\\", \\\"{x:1593,y:694,t:1527272153396};\\\", \\\"{x:1599,y:693,t:1527272153412};\\\", \\\"{x:1606,y:689,t:1527272153429};\\\", \\\"{x:1611,y:687,t:1527272153446};\\\", \\\"{x:1610,y:687,t:1527272153560};\\\", \\\"{x:1608,y:687,t:1527272153576};\\\", \\\"{x:1607,y:687,t:1527272153583};\\\", \\\"{x:1606,y:687,t:1527272153595};\\\", \\\"{x:1606,y:689,t:1527272153672};\\\", \\\"{x:1606,y:690,t:1527272153680};\\\", \\\"{x:1606,y:691,t:1527272153695};\\\", \\\"{x:1608,y:698,t:1527272153712};\\\", \\\"{x:1608,y:701,t:1527272153728};\\\", \\\"{x:1608,y:702,t:1527272153745};\\\", \\\"{x:1608,y:703,t:1527272153763};\\\", \\\"{x:1608,y:704,t:1527272154024};\\\", \\\"{x:1609,y:704,t:1527272154032};\\\", \\\"{x:1610,y:704,t:1527272154048};\\\", \\\"{x:1611,y:703,t:1527272154064};\\\", \\\"{x:1612,y:702,t:1527272154561};\\\", \\\"{x:1612,y:701,t:1527272154714};\\\", \\\"{x:1612,y:700,t:1527272155776};\\\", \\\"{x:1612,y:699,t:1527272156082};\\\", \\\"{x:1609,y:699,t:1527272156097};\\\", \\\"{x:1608,y:699,t:1527272156113};\\\", \\\"{x:1607,y:699,t:1527272156131};\\\", \\\"{x:1608,y:699,t:1527272157305};\\\", \\\"{x:1610,y:699,t:1527272157315};\\\", \\\"{x:1612,y:699,t:1527272157331};\\\", \\\"{x:1613,y:699,t:1527272158592};\\\", \\\"{x:1614,y:699,t:1527272158648};\\\", \\\"{x:1615,y:699,t:1527272158888};\\\", \\\"{x:1616,y:699,t:1527272158928};\\\", \\\"{x:1617,y:699,t:1527272159885};\\\", \\\"{x:1617,y:701,t:1527272159893};\\\", \\\"{x:1616,y:703,t:1527272159906};\\\", \\\"{x:1608,y:716,t:1527272159921};\\\", \\\"{x:1597,y:731,t:1527272159938};\\\", \\\"{x:1583,y:746,t:1527272159955};\\\", \\\"{x:1571,y:764,t:1527272159971};\\\", \\\"{x:1562,y:779,t:1527272159988};\\\", \\\"{x:1551,y:793,t:1527272160005};\\\", \\\"{x:1545,y:799,t:1527272160021};\\\", \\\"{x:1540,y:805,t:1527272160037};\\\", \\\"{x:1534,y:812,t:1527272160054};\\\", \\\"{x:1530,y:817,t:1527272160071};\\\", \\\"{x:1522,y:822,t:1527272160088};\\\", \\\"{x:1519,y:824,t:1527272160105};\\\", \\\"{x:1517,y:825,t:1527272160121};\\\", \\\"{x:1516,y:825,t:1527272160138};\\\", \\\"{x:1516,y:826,t:1527272160197};\\\", \\\"{x:1515,y:826,t:1527272160261};\\\", \\\"{x:1513,y:826,t:1527272160301};\\\", \\\"{x:1511,y:826,t:1527272160316};\\\", \\\"{x:1509,y:826,t:1527272160324};\\\", \\\"{x:1506,y:826,t:1527272160337};\\\", \\\"{x:1499,y:826,t:1527272160354};\\\", \\\"{x:1493,y:827,t:1527272160371};\\\", \\\"{x:1489,y:828,t:1527272160387};\\\", \\\"{x:1488,y:828,t:1527272160404};\\\", \\\"{x:1487,y:828,t:1527272160436};\\\", \\\"{x:1479,y:826,t:1527272162532};\\\", \\\"{x:1410,y:809,t:1527272162557};\\\", \\\"{x:1303,y:785,t:1527272162573};\\\", \\\"{x:1155,y:752,t:1527272162590};\\\", \\\"{x:976,y:704,t:1527272162606};\\\", \\\"{x:815,y:648,t:1527272162623};\\\", \\\"{x:659,y:595,t:1527272162639};\\\", \\\"{x:537,y:559,t:1527272162656};\\\", \\\"{x:444,y:523,t:1527272162672};\\\", \\\"{x:414,y:511,t:1527272162689};\\\", \\\"{x:404,y:506,t:1527272162706};\\\", \\\"{x:407,y:502,t:1527272162796};\\\", \\\"{x:413,y:499,t:1527272162803};\\\", \\\"{x:418,y:496,t:1527272162819};\\\", \\\"{x:440,y:486,t:1527272162836};\\\", \\\"{x:462,y:484,t:1527272162857};\\\", \\\"{x:503,y:484,t:1527272162873};\\\", \\\"{x:574,y:497,t:1527272162889};\\\", \\\"{x:633,y:517,t:1527272162906};\\\", \\\"{x:663,y:540,t:1527272162924};\\\", \\\"{x:673,y:555,t:1527272162939};\\\", \\\"{x:674,y:572,t:1527272162957};\\\", \\\"{x:671,y:577,t:1527272162973};\\\", \\\"{x:657,y:583,t:1527272162989};\\\", \\\"{x:654,y:586,t:1527272163006};\\\", \\\"{x:654,y:587,t:1527272163027};\\\", \\\"{x:654,y:588,t:1527272163051};\\\", \\\"{x:654,y:590,t:1527272163060};\\\", \\\"{x:653,y:591,t:1527272163074};\\\", \\\"{x:648,y:594,t:1527272163090};\\\", \\\"{x:647,y:594,t:1527272163106};\\\", \\\"{x:645,y:595,t:1527272163123};\\\", \\\"{x:644,y:595,t:1527272163179};\\\", \\\"{x:642,y:595,t:1527272163212};\\\", \\\"{x:640,y:595,t:1527272163223};\\\", \\\"{x:636,y:592,t:1527272163241};\\\", \\\"{x:634,y:590,t:1527272163256};\\\", \\\"{x:633,y:589,t:1527272163273};\\\", \\\"{x:632,y:589,t:1527272163364};\\\", \\\"{x:630,y:589,t:1527272163374};\\\", \\\"{x:627,y:587,t:1527272163391};\\\", \\\"{x:626,y:587,t:1527272163406};\\\", \\\"{x:625,y:587,t:1527272163468};\\\", \\\"{x:622,y:585,t:1527272163476};\\\", \\\"{x:620,y:584,t:1527272163491};\\\", \\\"{x:619,y:583,t:1527272163516};\\\", \\\"{x:624,y:580,t:1527272164588};\\\", \\\"{x:638,y:578,t:1527272164595};\\\", \\\"{x:651,y:577,t:1527272164607};\\\", \\\"{x:691,y:571,t:1527272164624};\\\", \\\"{x:759,y:569,t:1527272164641};\\\", \\\"{x:829,y:570,t:1527272164657};\\\", \\\"{x:915,y:583,t:1527272164675};\\\", \\\"{x:1003,y:593,t:1527272164692};\\\", \\\"{x:1103,y:606,t:1527272164707};\\\", \\\"{x:1221,y:623,t:1527272164725};\\\", \\\"{x:1266,y:630,t:1527272164741};\\\", \\\"{x:1297,y:635,t:1527272164758};\\\", \\\"{x:1326,y:638,t:1527272164774};\\\", \\\"{x:1355,y:643,t:1527272164791};\\\", \\\"{x:1376,y:644,t:1527272164808};\\\", \\\"{x:1398,y:649,t:1527272164824};\\\", \\\"{x:1415,y:654,t:1527272164842};\\\", \\\"{x:1431,y:659,t:1527272164859};\\\", \\\"{x:1440,y:662,t:1527272164874};\\\", \\\"{x:1448,y:666,t:1527272164892};\\\", \\\"{x:1455,y:669,t:1527272164909};\\\", \\\"{x:1462,y:673,t:1527272164925};\\\", \\\"{x:1467,y:678,t:1527272164942};\\\", \\\"{x:1470,y:683,t:1527272164959};\\\", \\\"{x:1472,y:692,t:1527272164975};\\\", \\\"{x:1474,y:701,t:1527272164992};\\\", \\\"{x:1476,y:708,t:1527272165009};\\\", \\\"{x:1478,y:713,t:1527272165025};\\\", \\\"{x:1478,y:718,t:1527272165042};\\\", \\\"{x:1478,y:724,t:1527272165059};\\\", \\\"{x:1478,y:727,t:1527272165075};\\\", \\\"{x:1478,y:730,t:1527272165092};\\\", \\\"{x:1478,y:733,t:1527272165108};\\\", \\\"{x:1478,y:735,t:1527272165124};\\\", \\\"{x:1478,y:736,t:1527272165142};\\\", \\\"{x:1477,y:737,t:1527272165159};\\\", \\\"{x:1478,y:737,t:1527272165819};\\\", \\\"{x:1479,y:736,t:1527272165885};\\\", \\\"{x:1480,y:735,t:1527272165972};\\\", \\\"{x:1479,y:735,t:1527272166452};\\\", \\\"{x:1478,y:735,t:1527272166516};\\\", \\\"{x:1476,y:735,t:1527272166526};\\\", \\\"{x:1472,y:736,t:1527272166542};\\\", \\\"{x:1468,y:736,t:1527272166559};\\\", \\\"{x:1466,y:737,t:1527272166576};\\\", \\\"{x:1463,y:737,t:1527272166592};\\\", \\\"{x:1460,y:738,t:1527272166609};\\\", \\\"{x:1456,y:738,t:1527272166627};\\\", \\\"{x:1450,y:739,t:1527272166643};\\\", \\\"{x:1439,y:739,t:1527272166660};\\\", \\\"{x:1424,y:740,t:1527272166676};\\\", \\\"{x:1412,y:744,t:1527272166693};\\\", \\\"{x:1402,y:745,t:1527272166709};\\\", \\\"{x:1396,y:746,t:1527272166727};\\\", \\\"{x:1392,y:748,t:1527272166743};\\\", \\\"{x:1391,y:748,t:1527272166759};\\\", \\\"{x:1388,y:748,t:1527272166777};\\\", \\\"{x:1387,y:748,t:1527272166793};\\\", \\\"{x:1385,y:750,t:1527272166809};\\\", \\\"{x:1384,y:750,t:1527272166827};\\\", \\\"{x:1381,y:750,t:1527272166842};\\\", \\\"{x:1379,y:752,t:1527272166859};\\\", \\\"{x:1378,y:752,t:1527272166900};\\\", \\\"{x:1377,y:752,t:1527272166931};\\\", \\\"{x:1376,y:752,t:1527272166980};\\\", \\\"{x:1375,y:753,t:1527272167004};\\\", \\\"{x:1374,y:754,t:1527272167748};\\\", \\\"{x:1372,y:754,t:1527272167836};\\\", \\\"{x:1371,y:754,t:1527272167844};\\\", \\\"{x:1367,y:755,t:1527272167861};\\\", \\\"{x:1365,y:755,t:1527272167878};\\\", \\\"{x:1362,y:755,t:1527272167894};\\\", \\\"{x:1360,y:755,t:1527272167910};\\\", \\\"{x:1359,y:755,t:1527272167928};\\\", \\\"{x:1357,y:755,t:1527272167948};\\\", \\\"{x:1357,y:756,t:1527272167963};\\\", \\\"{x:1356,y:756,t:1527272168004};\\\", \\\"{x:1355,y:756,t:1527272168204};\\\", \\\"{x:1354,y:756,t:1527272168220};\\\", \\\"{x:1354,y:754,t:1527272168244};\\\", \\\"{x:1352,y:751,t:1527272168261};\\\", \\\"{x:1352,y:750,t:1527272168277};\\\", \\\"{x:1351,y:747,t:1527272168294};\\\", \\\"{x:1351,y:746,t:1527272168316};\\\", \\\"{x:1350,y:745,t:1527272168332};\\\", \\\"{x:1350,y:744,t:1527272168348};\\\", \\\"{x:1350,y:743,t:1527272168364};\\\", \\\"{x:1350,y:742,t:1527272168378};\\\", \\\"{x:1350,y:740,t:1527272168395};\\\", \\\"{x:1350,y:738,t:1527272168410};\\\", \\\"{x:1350,y:737,t:1527272168452};\\\", \\\"{x:1350,y:736,t:1527272168501};\\\", \\\"{x:1350,y:735,t:1527272168565};\\\", \\\"{x:1350,y:734,t:1527272168981};\\\", \\\"{x:1351,y:733,t:1527272169013};\\\", \\\"{x:1353,y:732,t:1527272169052};\\\", \\\"{x:1353,y:731,t:1527272169077};\\\", \\\"{x:1354,y:731,t:1527272169085};\\\", \\\"{x:1355,y:730,t:1527272169100};\\\", \\\"{x:1357,y:730,t:1527272169124};\\\", \\\"{x:1359,y:729,t:1527272169131};\\\", \\\"{x:1361,y:729,t:1527272169145};\\\", \\\"{x:1363,y:728,t:1527272169162};\\\", \\\"{x:1364,y:728,t:1527272169178};\\\", \\\"{x:1365,y:728,t:1527272169196};\\\", \\\"{x:1366,y:728,t:1527272169212};\\\", \\\"{x:1368,y:727,t:1527272169228};\\\", \\\"{x:1371,y:727,t:1527272169244};\\\", \\\"{x:1372,y:727,t:1527272169332};\\\", \\\"{x:1373,y:727,t:1527272169404};\\\", \\\"{x:1373,y:726,t:1527272169435};\\\", \\\"{x:1374,y:725,t:1527272169444};\\\", \\\"{x:1376,y:725,t:1527272170620};\\\", \\\"{x:1379,y:725,t:1527272170630};\\\", \\\"{x:1398,y:725,t:1527272170645};\\\", \\\"{x:1433,y:732,t:1527272170663};\\\", \\\"{x:1463,y:739,t:1527272170680};\\\", \\\"{x:1489,y:749,t:1527272170696};\\\", \\\"{x:1512,y:754,t:1527272170713};\\\", \\\"{x:1534,y:761,t:1527272170730};\\\", \\\"{x:1558,y:767,t:1527272170746};\\\", \\\"{x:1580,y:772,t:1527272170762};\\\", \\\"{x:1596,y:777,t:1527272170780};\\\", \\\"{x:1603,y:778,t:1527272170796};\\\", \\\"{x:1606,y:780,t:1527272170813};\\\", \\\"{x:1607,y:781,t:1527272170851};\\\", \\\"{x:1607,y:782,t:1527272170876};\\\", \\\"{x:1606,y:782,t:1527272170883};\\\", \\\"{x:1605,y:782,t:1527272171724};\\\", \\\"{x:1604,y:782,t:1527272171732};\\\", \\\"{x:1603,y:782,t:1527272171747};\\\", \\\"{x:1600,y:779,t:1527272171764};\\\", \\\"{x:1597,y:778,t:1527272171780};\\\", \\\"{x:1596,y:776,t:1527272171797};\\\", \\\"{x:1589,y:776,t:1527272171814};\\\", \\\"{x:1586,y:776,t:1527272171831};\\\", \\\"{x:1584,y:776,t:1527272171847};\\\", \\\"{x:1585,y:776,t:1527272172620};\\\", \\\"{x:1586,y:777,t:1527272172630};\\\", \\\"{x:1587,y:777,t:1527272172668};\\\", \\\"{x:1588,y:777,t:1527272172680};\\\", \\\"{x:1590,y:779,t:1527272172698};\\\", \\\"{x:1591,y:781,t:1527272172714};\\\", \\\"{x:1592,y:782,t:1527272172731};\\\", \\\"{x:1593,y:783,t:1527272172764};\\\", \\\"{x:1593,y:784,t:1527272172787};\\\", \\\"{x:1593,y:785,t:1527272172812};\\\", \\\"{x:1594,y:785,t:1527272172820};\\\", \\\"{x:1594,y:786,t:1527272172830};\\\", \\\"{x:1594,y:787,t:1527272172940};\\\", \\\"{x:1594,y:788,t:1527272172948};\\\", \\\"{x:1594,y:791,t:1527272172965};\\\", \\\"{x:1592,y:792,t:1527272172981};\\\", \\\"{x:1587,y:794,t:1527272172997};\\\", \\\"{x:1582,y:795,t:1527272173014};\\\", \\\"{x:1575,y:796,t:1527272173031};\\\", \\\"{x:1563,y:797,t:1527272173048};\\\", \\\"{x:1549,y:797,t:1527272173065};\\\", \\\"{x:1529,y:797,t:1527272173081};\\\", \\\"{x:1508,y:797,t:1527272173097};\\\", \\\"{x:1491,y:797,t:1527272173115};\\\", \\\"{x:1467,y:796,t:1527272173132};\\\", \\\"{x:1457,y:794,t:1527272173147};\\\", \\\"{x:1451,y:794,t:1527272173164};\\\", \\\"{x:1448,y:793,t:1527272173182};\\\", \\\"{x:1447,y:792,t:1527272173198};\\\", \\\"{x:1446,y:792,t:1527272173228};\\\", \\\"{x:1445,y:792,t:1527272173236};\\\", \\\"{x:1444,y:792,t:1527272173259};\\\", \\\"{x:1443,y:792,t:1527272173267};\\\", \\\"{x:1442,y:792,t:1527272173308};\\\", \\\"{x:1441,y:791,t:1527272173348};\\\", \\\"{x:1439,y:790,t:1527272173365};\\\", \\\"{x:1439,y:789,t:1527272173382};\\\", \\\"{x:1438,y:788,t:1527272173398};\\\", \\\"{x:1437,y:784,t:1527272173414};\\\", \\\"{x:1435,y:782,t:1527272173432};\\\", \\\"{x:1435,y:781,t:1527272173451};\\\", \\\"{x:1435,y:780,t:1527272173468};\\\", \\\"{x:1434,y:780,t:1527272173482};\\\", \\\"{x:1433,y:779,t:1527272173500};\\\", \\\"{x:1433,y:778,t:1527272173676};\\\", \\\"{x:1433,y:777,t:1527272173684};\\\", \\\"{x:1433,y:776,t:1527272173699};\\\", \\\"{x:1433,y:773,t:1527272173715};\\\", \\\"{x:1433,y:767,t:1527272173732};\\\", \\\"{x:1433,y:765,t:1527272173748};\\\", \\\"{x:1432,y:764,t:1527272173804};\\\", \\\"{x:1432,y:763,t:1527272173828};\\\", \\\"{x:1429,y:762,t:1527272173836};\\\", \\\"{x:1428,y:761,t:1527272173849};\\\", \\\"{x:1421,y:758,t:1527272173865};\\\", \\\"{x:1411,y:753,t:1527272173882};\\\", \\\"{x:1402,y:749,t:1527272173898};\\\", \\\"{x:1395,y:745,t:1527272173915};\\\", \\\"{x:1389,y:741,t:1527272173932};\\\", \\\"{x:1388,y:741,t:1527272173949};\\\", \\\"{x:1386,y:739,t:1527272173966};\\\", \\\"{x:1384,y:738,t:1527272173982};\\\", \\\"{x:1383,y:738,t:1527272174029};\\\", \\\"{x:1381,y:738,t:1527272174092};\\\", \\\"{x:1380,y:739,t:1527272174100};\\\", \\\"{x:1374,y:749,t:1527272174116};\\\", \\\"{x:1370,y:758,t:1527272174132};\\\", \\\"{x:1367,y:766,t:1527272174148};\\\", \\\"{x:1365,y:771,t:1527272174166};\\\", \\\"{x:1364,y:774,t:1527272174182};\\\", \\\"{x:1363,y:779,t:1527272174199};\\\", \\\"{x:1363,y:782,t:1527272174215};\\\", \\\"{x:1362,y:788,t:1527272174232};\\\", \\\"{x:1361,y:791,t:1527272174249};\\\", \\\"{x:1361,y:793,t:1527272174266};\\\", \\\"{x:1361,y:795,t:1527272174282};\\\", \\\"{x:1361,y:797,t:1527272174299};\\\", \\\"{x:1360,y:798,t:1527272174315};\\\", \\\"{x:1360,y:799,t:1527272174332};\\\", \\\"{x:1359,y:801,t:1527272174349};\\\", \\\"{x:1359,y:802,t:1527272174366};\\\", \\\"{x:1359,y:804,t:1527272174383};\\\", \\\"{x:1358,y:805,t:1527272174398};\\\", \\\"{x:1357,y:806,t:1527272174416};\\\", \\\"{x:1357,y:807,t:1527272174484};\\\", \\\"{x:1357,y:808,t:1527272174668};\\\", \\\"{x:1357,y:810,t:1527272174683};\\\", \\\"{x:1355,y:815,t:1527272174699};\\\", \\\"{x:1352,y:819,t:1527272174716};\\\", \\\"{x:1351,y:823,t:1527272174732};\\\", \\\"{x:1350,y:825,t:1527272174749};\\\", \\\"{x:1349,y:826,t:1527272174766};\\\", \\\"{x:1347,y:830,t:1527272174782};\\\", \\\"{x:1345,y:832,t:1527272174800};\\\", \\\"{x:1344,y:835,t:1527272174816};\\\", \\\"{x:1344,y:836,t:1527272174832};\\\", \\\"{x:1344,y:834,t:1527272175276};\\\", \\\"{x:1344,y:833,t:1527272175299};\\\", \\\"{x:1344,y:832,t:1527272175317};\\\", \\\"{x:1345,y:832,t:1527272175333};\\\", \\\"{x:1346,y:830,t:1527272175350};\\\", \\\"{x:1347,y:828,t:1527272175372};\\\", \\\"{x:1347,y:827,t:1527272175387};\\\", \\\"{x:1348,y:826,t:1527272175400};\\\", \\\"{x:1349,y:824,t:1527272175417};\\\", \\\"{x:1350,y:821,t:1527272175432};\\\", \\\"{x:1351,y:818,t:1527272175450};\\\", \\\"{x:1351,y:817,t:1527272175467};\\\", \\\"{x:1352,y:813,t:1527272175482};\\\", \\\"{x:1353,y:806,t:1527272175500};\\\", \\\"{x:1353,y:803,t:1527272175516};\\\", \\\"{x:1354,y:800,t:1527272175533};\\\", \\\"{x:1354,y:797,t:1527272175550};\\\", \\\"{x:1354,y:796,t:1527272175567};\\\", \\\"{x:1354,y:794,t:1527272175582};\\\", \\\"{x:1354,y:793,t:1527272175600};\\\", \\\"{x:1354,y:791,t:1527272175617};\\\", \\\"{x:1354,y:789,t:1527272175633};\\\", \\\"{x:1354,y:785,t:1527272175650};\\\", \\\"{x:1354,y:780,t:1527272175667};\\\", \\\"{x:1354,y:778,t:1527272175683};\\\", \\\"{x:1354,y:777,t:1527272175700};\\\", \\\"{x:1354,y:776,t:1527272175717};\\\", \\\"{x:1354,y:774,t:1527272175734};\\\", \\\"{x:1354,y:769,t:1527272175750};\\\", \\\"{x:1354,y:766,t:1527272175766};\\\", \\\"{x:1354,y:763,t:1527272175784};\\\", \\\"{x:1354,y:762,t:1527272175800};\\\", \\\"{x:1354,y:761,t:1527272175817};\\\", \\\"{x:1354,y:758,t:1527272175833};\\\", \\\"{x:1351,y:745,t:1527272175850};\\\", \\\"{x:1349,y:726,t:1527272175867};\\\", \\\"{x:1337,y:692,t:1527272175884};\\\", \\\"{x:1328,y:676,t:1527272175900};\\\", \\\"{x:1324,y:669,t:1527272175917};\\\", \\\"{x:1324,y:668,t:1527272175934};\\\", \\\"{x:1324,y:667,t:1527272175956};\\\", \\\"{x:1324,y:668,t:1527272176147};\\\", \\\"{x:1325,y:670,t:1527272176156};\\\", \\\"{x:1326,y:672,t:1527272176166};\\\", \\\"{x:1328,y:675,t:1527272176183};\\\", \\\"{x:1328,y:676,t:1527272176201};\\\", \\\"{x:1329,y:678,t:1527272176217};\\\", \\\"{x:1331,y:681,t:1527272176234};\\\", \\\"{x:1332,y:681,t:1527272176251};\\\", \\\"{x:1332,y:682,t:1527272176268};\\\", \\\"{x:1334,y:682,t:1527272176933};\\\", \\\"{x:1334,y:684,t:1527272176940};\\\", \\\"{x:1335,y:686,t:1527272176956};\\\", \\\"{x:1336,y:687,t:1527272176968};\\\", \\\"{x:1336,y:688,t:1527272176985};\\\", \\\"{x:1337,y:691,t:1527272177002};\\\", \\\"{x:1338,y:693,t:1527272177019};\\\", \\\"{x:1338,y:696,t:1527272177036};\\\", \\\"{x:1338,y:698,t:1527272177052};\\\", \\\"{x:1339,y:705,t:1527272177070};\\\", \\\"{x:1341,y:710,t:1527272177085};\\\", \\\"{x:1341,y:714,t:1527272177101};\\\", \\\"{x:1341,y:718,t:1527272177119};\\\", \\\"{x:1341,y:722,t:1527272177136};\\\", \\\"{x:1341,y:725,t:1527272177152};\\\", \\\"{x:1341,y:727,t:1527272177169};\\\", \\\"{x:1341,y:731,t:1527272177185};\\\", \\\"{x:1341,y:736,t:1527272177201};\\\", \\\"{x:1341,y:740,t:1527272177218};\\\", \\\"{x:1341,y:743,t:1527272177236};\\\", \\\"{x:1341,y:748,t:1527272177251};\\\", \\\"{x:1341,y:751,t:1527272177269};\\\", \\\"{x:1341,y:753,t:1527272177286};\\\", \\\"{x:1341,y:755,t:1527272177302};\\\", \\\"{x:1341,y:756,t:1527272177319};\\\", \\\"{x:1341,y:760,t:1527272177336};\\\", \\\"{x:1341,y:761,t:1527272177351};\\\", \\\"{x:1341,y:767,t:1527272177368};\\\", \\\"{x:1341,y:768,t:1527272177385};\\\", \\\"{x:1340,y:770,t:1527272177402};\\\", \\\"{x:1340,y:771,t:1527272177419};\\\", \\\"{x:1340,y:773,t:1527272177436};\\\", \\\"{x:1340,y:776,t:1527272177452};\\\", \\\"{x:1340,y:785,t:1527272177469};\\\", \\\"{x:1340,y:792,t:1527272177486};\\\", \\\"{x:1338,y:797,t:1527272177502};\\\", \\\"{x:1338,y:801,t:1527272177518};\\\", \\\"{x:1338,y:804,t:1527272177536};\\\", \\\"{x:1338,y:805,t:1527272177597};\\\", \\\"{x:1337,y:807,t:1527272177669};\\\", \\\"{x:1337,y:808,t:1527272178772};\\\", \\\"{x:1336,y:808,t:1527272178786};\\\", \\\"{x:1335,y:811,t:1527272178812};\\\", \\\"{x:1334,y:811,t:1527272178835};\\\", \\\"{x:1334,y:812,t:1527272178877};\\\", \\\"{x:1333,y:813,t:1527272178900};\\\", \\\"{x:1333,y:814,t:1527272178924};\\\", \\\"{x:1334,y:814,t:1527272179077};\\\", \\\"{x:1335,y:814,t:1527272179164};\\\", \\\"{x:1338,y:814,t:1527272179172};\\\", \\\"{x:1341,y:814,t:1527272179187};\\\", \\\"{x:1342,y:814,t:1527272180051};\\\", \\\"{x:1343,y:815,t:1527272180083};\\\", \\\"{x:1343,y:816,t:1527272180091};\\\", \\\"{x:1344,y:817,t:1527272180148};\\\", \\\"{x:1341,y:822,t:1527272180589};\\\", \\\"{x:1336,y:826,t:1527272180605};\\\", \\\"{x:1335,y:826,t:1527272180621};\\\", \\\"{x:1334,y:826,t:1527272180637};\\\", \\\"{x:1333,y:826,t:1527272180655};\\\", \\\"{x:1332,y:826,t:1527272180672};\\\", \\\"{x:1331,y:826,t:1527272180963};\\\", \\\"{x:1330,y:826,t:1527272180979};\\\", \\\"{x:1330,y:827,t:1527272180996};\\\", \\\"{x:1329,y:827,t:1527272181004};\\\", \\\"{x:1328,y:829,t:1527272181021};\\\", \\\"{x:1327,y:830,t:1527272181083};\\\", \\\"{x:1327,y:831,t:1527272181197};\\\", \\\"{x:1326,y:831,t:1527272181220};\\\", \\\"{x:1325,y:831,t:1527272181267};\\\", \\\"{x:1324,y:832,t:1527272181723};\\\", \\\"{x:1324,y:834,t:1527272181738};\\\", \\\"{x:1323,y:836,t:1527272182619};\\\", \\\"{x:1322,y:836,t:1527272182627};\\\", \\\"{x:1319,y:837,t:1527272182639};\\\", \\\"{x:1317,y:838,t:1527272182656};\\\", \\\"{x:1316,y:839,t:1527272182692};\\\", \\\"{x:1315,y:835,t:1527272189781};\\\", \\\"{x:1315,y:826,t:1527272189795};\\\", \\\"{x:1315,y:788,t:1527272189812};\\\", \\\"{x:1319,y:772,t:1527272189829};\\\", \\\"{x:1320,y:754,t:1527272189847};\\\", \\\"{x:1320,y:742,t:1527272189861};\\\", \\\"{x:1320,y:736,t:1527272189878};\\\", \\\"{x:1320,y:731,t:1527272189894};\\\", \\\"{x:1320,y:728,t:1527272189911};\\\", \\\"{x:1319,y:726,t:1527272189928};\\\", \\\"{x:1319,y:720,t:1527272189945};\\\", \\\"{x:1318,y:714,t:1527272189961};\\\", \\\"{x:1315,y:708,t:1527272189979};\\\", \\\"{x:1311,y:701,t:1527272189995};\\\", \\\"{x:1306,y:696,t:1527272190011};\\\", \\\"{x:1304,y:693,t:1527272190029};\\\", \\\"{x:1302,y:691,t:1527272190045};\\\", \\\"{x:1300,y:689,t:1527272190061};\\\", \\\"{x:1298,y:687,t:1527272190078};\\\", \\\"{x:1296,y:683,t:1527272190667};\\\", \\\"{x:1295,y:682,t:1527272190678};\\\", \\\"{x:1293,y:676,t:1527272190695};\\\", \\\"{x:1291,y:673,t:1527272190712};\\\", \\\"{x:1289,y:667,t:1527272190729};\\\", \\\"{x:1288,y:664,t:1527272190745};\\\", \\\"{x:1287,y:661,t:1527272190762};\\\", \\\"{x:1287,y:659,t:1527272190779};\\\", \\\"{x:1287,y:656,t:1527272190795};\\\", \\\"{x:1287,y:653,t:1527272190812};\\\", \\\"{x:1285,y:649,t:1527272190828};\\\", \\\"{x:1280,y:642,t:1527272190845};\\\", \\\"{x:1279,y:636,t:1527272190863};\\\", \\\"{x:1275,y:631,t:1527272190880};\\\", \\\"{x:1273,y:627,t:1527272190896};\\\", \\\"{x:1273,y:625,t:1527272190912};\\\", \\\"{x:1273,y:624,t:1527272190929};\\\", \\\"{x:1273,y:623,t:1527272190988};\\\", \\\"{x:1273,y:622,t:1527272191021};\\\", \\\"{x:1273,y:620,t:1527272191030};\\\", \\\"{x:1273,y:619,t:1527272191045};\\\", \\\"{x:1273,y:617,t:1527272191063};\\\", \\\"{x:1273,y:616,t:1527272191079};\\\", \\\"{x:1273,y:615,t:1527272191096};\\\", \\\"{x:1273,y:614,t:1527272191112};\\\", \\\"{x:1273,y:613,t:1527272191130};\\\", \\\"{x:1273,y:611,t:1527272191145};\\\", \\\"{x:1273,y:609,t:1527272191162};\\\", \\\"{x:1273,y:607,t:1527272191180};\\\", \\\"{x:1273,y:605,t:1527272191195};\\\", \\\"{x:1273,y:604,t:1527272191228};\\\", \\\"{x:1273,y:603,t:1527272191244};\\\", \\\"{x:1273,y:602,t:1527272191259};\\\", \\\"{x:1272,y:600,t:1527272191291};\\\", \\\"{x:1272,y:599,t:1527272191307};\\\", \\\"{x:1272,y:598,t:1527272191315};\\\", \\\"{x:1272,y:597,t:1527272191331};\\\", \\\"{x:1272,y:595,t:1527272191346};\\\", \\\"{x:1272,y:593,t:1527272191362};\\\", \\\"{x:1272,y:590,t:1527272191379};\\\", \\\"{x:1272,y:589,t:1527272191427};\\\", \\\"{x:1272,y:587,t:1527272191460};\\\", \\\"{x:1272,y:586,t:1527272191643};\\\", \\\"{x:1273,y:586,t:1527272191787};\\\", \\\"{x:1262,y:587,t:1527272194012};\\\", \\\"{x:1242,y:592,t:1527272194019};\\\", \\\"{x:1220,y:597,t:1527272194032};\\\", \\\"{x:1153,y:605,t:1527272194049};\\\", \\\"{x:1082,y:612,t:1527272194064};\\\", \\\"{x:1001,y:612,t:1527272194081};\\\", \\\"{x:921,y:612,t:1527272194099};\\\", \\\"{x:826,y:612,t:1527272194115};\\\", \\\"{x:660,y:612,t:1527272194132};\\\", \\\"{x:609,y:620,t:1527272194145};\\\", \\\"{x:531,y:620,t:1527272194161};\\\", \\\"{x:491,y:618,t:1527272194182};\\\", \\\"{x:471,y:618,t:1527272194198};\\\", \\\"{x:450,y:617,t:1527272194215};\\\", \\\"{x:431,y:617,t:1527272194231};\\\", \\\"{x:412,y:620,t:1527272194249};\\\", \\\"{x:401,y:626,t:1527272194265};\\\", \\\"{x:395,y:630,t:1527272194281};\\\", \\\"{x:390,y:642,t:1527272194299};\\\", \\\"{x:387,y:666,t:1527272194316};\\\", \\\"{x:388,y:680,t:1527272194332};\\\", \\\"{x:398,y:690,t:1527272194348};\\\", \\\"{x:413,y:697,t:1527272194366};\\\", \\\"{x:425,y:704,t:1527272194382};\\\", \\\"{x:442,y:712,t:1527272194398};\\\", \\\"{x:457,y:718,t:1527272194415};\\\", \\\"{x:471,y:722,t:1527272194432};\\\", \\\"{x:481,y:722,t:1527272194449};\\\", \\\"{x:490,y:722,t:1527272194465};\\\", \\\"{x:495,y:722,t:1527272194481};\\\", \\\"{x:497,y:722,t:1527272194498};\\\", \\\"{x:500,y:722,t:1527272194515};\\\", \\\"{x:503,y:722,t:1527272194531};\\\", \\\"{x:505,y:722,t:1527272194660};\\\", \\\"{x:506,y:722,t:1527272194675};\\\", \\\"{x:508,y:722,t:1527272194691};\\\", \\\"{x:508,y:727,t:1527272195036};\\\", \\\"{x:510,y:733,t:1527272195049};\\\", \\\"{x:514,y:738,t:1527272195066};\\\", \\\"{x:516,y:743,t:1527272195083};\\\", \\\"{x:517,y:744,t:1527272195099};\\\", \\\"{x:518,y:744,t:1527272195300};\\\", \\\"{x:520,y:741,t:1527272195316};\\\", \\\"{x:522,y:737,t:1527272195333};\\\", \\\"{x:523,y:730,t:1527272195349};\\\", \\\"{x:527,y:727,t:1527272195366};\\\", \\\"{x:534,y:716,t:1527272195383};\\\", \\\"{x:538,y:708,t:1527272195399};\\\", \\\"{x:541,y:703,t:1527272195417};\\\", \\\"{x:545,y:698,t:1527272195432};\\\", \\\"{x:550,y:693,t:1527272195449};\\\", \\\"{x:559,y:689,t:1527272195467};\\\", \\\"{x:581,y:679,t:1527272195483};\\\", \\\"{x:619,y:669,t:1527272195499};\\\", \\\"{x:649,y:661,t:1527272195516};\\\", \\\"{x:668,y:657,t:1527272195533};\\\", \\\"{x:681,y:657,t:1527272195550};\\\", \\\"{x:691,y:654,t:1527272195567};\\\", \\\"{x:703,y:649,t:1527272195582};\\\", \\\"{x:716,y:643,t:1527272195599};\\\", \\\"{x:728,y:638,t:1527272195616};\\\", \\\"{x:738,y:633,t:1527272195633};\\\", \\\"{x:747,y:629,t:1527272195650};\\\", \\\"{x:752,y:628,t:1527272195667};\\\", \\\"{x:757,y:628,t:1527272195682};\\\", \\\"{x:762,y:627,t:1527272195700};\\\", \\\"{x:766,y:625,t:1527272195716};\\\", \\\"{x:768,y:625,t:1527272195732};\\\" ] }, { \\\"rt\\\": 9868, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 585641, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:774,y:624,t:1527272197035};\\\", \\\"{x:818,y:624,t:1527272197063};\\\", \\\"{x:843,y:624,t:1527272197070};\\\", \\\"{x:885,y:622,t:1527272197086};\\\", \\\"{x:919,y:622,t:1527272197100};\\\", \\\"{x:948,y:623,t:1527272197118};\\\", \\\"{x:979,y:627,t:1527272197134};\\\", \\\"{x:1018,y:627,t:1527272197151};\\\", \\\"{x:1066,y:627,t:1527272197168};\\\", \\\"{x:1093,y:627,t:1527272197185};\\\", \\\"{x:1119,y:629,t:1527272197200};\\\", \\\"{x:1138,y:631,t:1527272197218};\\\", \\\"{x:1160,y:633,t:1527272197235};\\\", \\\"{x:1178,y:634,t:1527272197251};\\\", \\\"{x:1212,y:634,t:1527272197267};\\\", \\\"{x:1232,y:634,t:1527272197285};\\\", \\\"{x:1252,y:631,t:1527272197301};\\\", \\\"{x:1267,y:630,t:1527272197318};\\\", \\\"{x:1280,y:627,t:1527272197335};\\\", \\\"{x:1294,y:625,t:1527272197352};\\\", \\\"{x:1317,y:622,t:1527272197368};\\\", \\\"{x:1339,y:619,t:1527272197385};\\\", \\\"{x:1358,y:616,t:1527272197402};\\\", \\\"{x:1361,y:616,t:1527272197417};\\\", \\\"{x:1362,y:616,t:1527272197434};\\\", \\\"{x:1363,y:616,t:1527272197467};\\\", \\\"{x:1365,y:616,t:1527272197515};\\\", \\\"{x:1368,y:616,t:1527272197523};\\\", \\\"{x:1372,y:616,t:1527272197535};\\\", \\\"{x:1376,y:616,t:1527272197552};\\\", \\\"{x:1378,y:617,t:1527272197612};\\\", \\\"{x:1382,y:620,t:1527272197619};\\\", \\\"{x:1388,y:632,t:1527272197635};\\\", \\\"{x:1395,y:648,t:1527272197651};\\\", \\\"{x:1405,y:671,t:1527272197669};\\\", \\\"{x:1410,y:694,t:1527272197686};\\\", \\\"{x:1413,y:712,t:1527272197702};\\\", \\\"{x:1417,y:725,t:1527272197719};\\\", \\\"{x:1422,y:738,t:1527272197737};\\\", \\\"{x:1429,y:753,t:1527272197752};\\\", \\\"{x:1436,y:768,t:1527272197770};\\\", \\\"{x:1441,y:777,t:1527272197786};\\\", \\\"{x:1444,y:783,t:1527272197803};\\\", \\\"{x:1448,y:791,t:1527272197819};\\\", \\\"{x:1454,y:805,t:1527272197836};\\\", \\\"{x:1459,y:814,t:1527272197854};\\\", \\\"{x:1462,y:821,t:1527272197869};\\\", \\\"{x:1463,y:824,t:1527272197886};\\\", \\\"{x:1466,y:829,t:1527272197903};\\\", \\\"{x:1468,y:831,t:1527272197919};\\\", \\\"{x:1469,y:834,t:1527272197936};\\\", \\\"{x:1470,y:836,t:1527272197953};\\\", \\\"{x:1471,y:840,t:1527272197971};\\\", \\\"{x:1473,y:844,t:1527272197987};\\\", \\\"{x:1474,y:847,t:1527272198003};\\\", \\\"{x:1478,y:855,t:1527272198020};\\\", \\\"{x:1479,y:859,t:1527272198036};\\\", \\\"{x:1480,y:865,t:1527272198053};\\\", \\\"{x:1481,y:870,t:1527272198070};\\\", \\\"{x:1481,y:875,t:1527272198086};\\\", \\\"{x:1481,y:878,t:1527272198103};\\\", \\\"{x:1481,y:882,t:1527272198120};\\\", \\\"{x:1481,y:884,t:1527272198137};\\\", \\\"{x:1482,y:887,t:1527272198154};\\\", \\\"{x:1482,y:891,t:1527272198170};\\\", \\\"{x:1482,y:896,t:1527272198187};\\\", \\\"{x:1482,y:899,t:1527272198202};\\\", \\\"{x:1482,y:905,t:1527272198220};\\\", \\\"{x:1482,y:909,t:1527272198236};\\\", \\\"{x:1482,y:913,t:1527272198253};\\\", \\\"{x:1482,y:917,t:1527272198270};\\\", \\\"{x:1484,y:922,t:1527272198287};\\\", \\\"{x:1485,y:925,t:1527272198304};\\\", \\\"{x:1485,y:928,t:1527272198320};\\\", \\\"{x:1485,y:929,t:1527272198340};\\\", \\\"{x:1485,y:930,t:1527272198353};\\\", \\\"{x:1485,y:931,t:1527272198370};\\\", \\\"{x:1485,y:934,t:1527272198387};\\\", \\\"{x:1484,y:935,t:1527272198403};\\\", \\\"{x:1482,y:935,t:1527272198435};\\\", \\\"{x:1480,y:936,t:1527272198443};\\\", \\\"{x:1480,y:937,t:1527272198453};\\\", \\\"{x:1471,y:941,t:1527272198470};\\\", \\\"{x:1463,y:942,t:1527272198487};\\\", \\\"{x:1452,y:945,t:1527272198503};\\\", \\\"{x:1441,y:946,t:1527272198520};\\\", \\\"{x:1428,y:947,t:1527272198537};\\\", \\\"{x:1418,y:948,t:1527272198553};\\\", \\\"{x:1411,y:948,t:1527272198571};\\\", \\\"{x:1401,y:949,t:1527272198587};\\\", \\\"{x:1397,y:950,t:1527272198604};\\\", \\\"{x:1393,y:951,t:1527272198621};\\\", \\\"{x:1392,y:951,t:1527272198667};\\\", \\\"{x:1390,y:952,t:1527272198692};\\\", \\\"{x:1388,y:952,t:1527272198707};\\\", \\\"{x:1387,y:953,t:1527272198720};\\\", \\\"{x:1385,y:954,t:1527272198738};\\\", \\\"{x:1384,y:954,t:1527272198754};\\\", \\\"{x:1381,y:955,t:1527272198770};\\\", \\\"{x:1376,y:957,t:1527272198787};\\\", \\\"{x:1374,y:957,t:1527272198804};\\\", \\\"{x:1371,y:957,t:1527272198820};\\\", \\\"{x:1367,y:957,t:1527272198837};\\\", \\\"{x:1363,y:957,t:1527272198855};\\\", \\\"{x:1359,y:957,t:1527272198872};\\\", \\\"{x:1356,y:957,t:1527272198888};\\\", \\\"{x:1353,y:957,t:1527272198904};\\\", \\\"{x:1352,y:957,t:1527272198922};\\\", \\\"{x:1350,y:957,t:1527272198937};\\\", \\\"{x:1349,y:957,t:1527272198954};\\\", \\\"{x:1347,y:956,t:1527272198972};\\\", \\\"{x:1346,y:955,t:1527272199003};\\\", \\\"{x:1346,y:954,t:1527272199035};\\\", \\\"{x:1346,y:952,t:1527272199059};\\\", \\\"{x:1346,y:950,t:1527272199075};\\\", \\\"{x:1346,y:949,t:1527272199089};\\\", \\\"{x:1346,y:948,t:1527272199104};\\\", \\\"{x:1346,y:945,t:1527272199122};\\\", \\\"{x:1347,y:943,t:1527272199138};\\\", \\\"{x:1347,y:942,t:1527272199154};\\\", \\\"{x:1347,y:941,t:1527272199171};\\\", \\\"{x:1348,y:940,t:1527272199236};\\\", \\\"{x:1349,y:940,t:1527272199259};\\\", \\\"{x:1349,y:939,t:1527272199283};\\\", \\\"{x:1349,y:938,t:1527272199291};\\\", \\\"{x:1350,y:938,t:1527272199307};\\\", \\\"{x:1350,y:937,t:1527272199322};\\\", \\\"{x:1351,y:935,t:1527272199338};\\\", \\\"{x:1354,y:927,t:1527272199355};\\\", \\\"{x:1355,y:921,t:1527272199372};\\\", \\\"{x:1356,y:917,t:1527272199388};\\\", \\\"{x:1357,y:914,t:1527272199406};\\\", \\\"{x:1360,y:907,t:1527272199423};\\\", \\\"{x:1363,y:899,t:1527272199439};\\\", \\\"{x:1365,y:892,t:1527272199455};\\\", \\\"{x:1366,y:886,t:1527272199472};\\\", \\\"{x:1367,y:878,t:1527272199490};\\\", \\\"{x:1367,y:870,t:1527272199506};\\\", \\\"{x:1370,y:866,t:1527272199522};\\\", \\\"{x:1371,y:860,t:1527272199538};\\\", \\\"{x:1373,y:857,t:1527272199555};\\\", \\\"{x:1373,y:854,t:1527272199573};\\\", \\\"{x:1373,y:847,t:1527272199590};\\\", \\\"{x:1373,y:844,t:1527272199605};\\\", \\\"{x:1372,y:838,t:1527272199623};\\\", \\\"{x:1370,y:834,t:1527272199640};\\\", \\\"{x:1370,y:830,t:1527272199657};\\\", \\\"{x:1368,y:825,t:1527272199673};\\\", \\\"{x:1365,y:811,t:1527272199690};\\\", \\\"{x:1365,y:804,t:1527272199707};\\\", \\\"{x:1364,y:799,t:1527272199723};\\\", \\\"{x:1363,y:788,t:1527272199740};\\\", \\\"{x:1361,y:782,t:1527272199757};\\\", \\\"{x:1361,y:777,t:1527272199774};\\\", \\\"{x:1361,y:773,t:1527272199789};\\\", \\\"{x:1361,y:770,t:1527272199806};\\\", \\\"{x:1361,y:768,t:1527272199824};\\\", \\\"{x:1361,y:765,t:1527272199839};\\\", \\\"{x:1361,y:763,t:1527272199867};\\\", \\\"{x:1360,y:762,t:1527272199891};\\\", \\\"{x:1360,y:760,t:1527272199915};\\\", \\\"{x:1360,y:759,t:1527272199923};\\\", \\\"{x:1359,y:756,t:1527272199940};\\\", \\\"{x:1357,y:752,t:1527272199956};\\\", \\\"{x:1356,y:748,t:1527272199973};\\\", \\\"{x:1356,y:745,t:1527272199991};\\\", \\\"{x:1356,y:742,t:1527272200006};\\\", \\\"{x:1353,y:738,t:1527272200024};\\\", \\\"{x:1353,y:735,t:1527272200041};\\\", \\\"{x:1352,y:732,t:1527272200057};\\\", \\\"{x:1351,y:729,t:1527272200074};\\\", \\\"{x:1350,y:727,t:1527272200091};\\\", \\\"{x:1350,y:726,t:1527272200107};\\\", \\\"{x:1350,y:725,t:1527272200155};\\\", \\\"{x:1350,y:724,t:1527272200220};\\\", \\\"{x:1350,y:723,t:1527272200277};\\\", \\\"{x:1350,y:722,t:1527272200292};\\\", \\\"{x:1350,y:719,t:1527272200308};\\\", \\\"{x:1350,y:715,t:1527272200325};\\\", \\\"{x:1350,y:712,t:1527272200341};\\\", \\\"{x:1350,y:708,t:1527272200358};\\\", \\\"{x:1350,y:707,t:1527272200375};\\\", \\\"{x:1350,y:706,t:1527272200391};\\\", \\\"{x:1350,y:704,t:1527272200408};\\\", \\\"{x:1351,y:704,t:1527272200427};\\\", \\\"{x:1341,y:703,t:1527272201421};\\\", \\\"{x:1322,y:703,t:1527272201428};\\\", \\\"{x:1254,y:707,t:1527272201444};\\\", \\\"{x:1180,y:708,t:1527272201460};\\\", \\\"{x:1110,y:698,t:1527272201477};\\\", \\\"{x:1056,y:685,t:1527272201495};\\\", \\\"{x:995,y:669,t:1527272201510};\\\", \\\"{x:926,y:652,t:1527272201527};\\\", \\\"{x:862,y:631,t:1527272201545};\\\", \\\"{x:812,y:619,t:1527272201561};\\\", \\\"{x:768,y:608,t:1527272201570};\\\", \\\"{x:737,y:600,t:1527272201588};\\\", \\\"{x:712,y:594,t:1527272201605};\\\", \\\"{x:690,y:591,t:1527272201621};\\\", \\\"{x:677,y:589,t:1527272201637};\\\", \\\"{x:671,y:589,t:1527272201655};\\\", \\\"{x:667,y:588,t:1527272201671};\\\", \\\"{x:663,y:587,t:1527272201688};\\\", \\\"{x:661,y:586,t:1527272201704};\\\", \\\"{x:657,y:583,t:1527272201721};\\\", \\\"{x:655,y:582,t:1527272201737};\\\", \\\"{x:652,y:581,t:1527272201819};\\\", \\\"{x:650,y:580,t:1527272201826};\\\", \\\"{x:648,y:578,t:1527272201838};\\\", \\\"{x:640,y:575,t:1527272201854};\\\", \\\"{x:629,y:570,t:1527272201872};\\\", \\\"{x:606,y:568,t:1527272201888};\\\", \\\"{x:579,y:568,t:1527272201904};\\\", \\\"{x:558,y:568,t:1527272201921};\\\", \\\"{x:546,y:568,t:1527272201937};\\\", \\\"{x:536,y:569,t:1527272201954};\\\", \\\"{x:529,y:571,t:1527272201971};\\\", \\\"{x:514,y:579,t:1527272201987};\\\", \\\"{x:502,y:583,t:1527272202005};\\\", \\\"{x:492,y:584,t:1527272202022};\\\", \\\"{x:485,y:586,t:1527272202038};\\\", \\\"{x:482,y:588,t:1527272202054};\\\", \\\"{x:480,y:588,t:1527272202071};\\\", \\\"{x:474,y:589,t:1527272202087};\\\", \\\"{x:458,y:589,t:1527272202105};\\\", \\\"{x:431,y:589,t:1527272202121};\\\", \\\"{x:397,y:589,t:1527272202138};\\\", \\\"{x:371,y:593,t:1527272202155};\\\", \\\"{x:352,y:593,t:1527272202171};\\\", \\\"{x:347,y:593,t:1527272202187};\\\", \\\"{x:340,y:593,t:1527272202205};\\\", \\\"{x:330,y:594,t:1527272202222};\\\", \\\"{x:313,y:595,t:1527272202239};\\\", \\\"{x:281,y:597,t:1527272202254};\\\", \\\"{x:227,y:599,t:1527272202271};\\\", \\\"{x:162,y:597,t:1527272202288};\\\", \\\"{x:121,y:588,t:1527272202305};\\\", \\\"{x:104,y:584,t:1527272202322};\\\", \\\"{x:101,y:583,t:1527272202338};\\\", \\\"{x:100,y:583,t:1527272202380};\\\", \\\"{x:99,y:582,t:1527272202395};\\\", \\\"{x:99,y:581,t:1527272202405};\\\", \\\"{x:98,y:580,t:1527272202422};\\\", \\\"{x:96,y:575,t:1527272202439};\\\", \\\"{x:95,y:571,t:1527272202455};\\\", \\\"{x:94,y:566,t:1527272202471};\\\", \\\"{x:94,y:562,t:1527272202489};\\\", \\\"{x:94,y:551,t:1527272202505};\\\", \\\"{x:99,y:540,t:1527272202521};\\\", \\\"{x:103,y:532,t:1527272202539};\\\", \\\"{x:105,y:529,t:1527272202554};\\\", \\\"{x:106,y:528,t:1527272202571};\\\", \\\"{x:107,y:527,t:1527272202595};\\\", \\\"{x:111,y:527,t:1527272202635};\\\", \\\"{x:112,y:527,t:1527272202643};\\\", \\\"{x:115,y:527,t:1527272202654};\\\", \\\"{x:118,y:528,t:1527272202672};\\\", \\\"{x:119,y:528,t:1527272202688};\\\", \\\"{x:121,y:528,t:1527272202707};\\\", \\\"{x:121,y:529,t:1527272202779};\\\", \\\"{x:123,y:530,t:1527272202827};\\\", \\\"{x:126,y:531,t:1527272202839};\\\", \\\"{x:132,y:534,t:1527272202855};\\\", \\\"{x:139,y:538,t:1527272202871};\\\", \\\"{x:141,y:540,t:1527272202889};\\\", \\\"{x:142,y:540,t:1527272202907};\\\", \\\"{x:144,y:541,t:1527272203035};\\\", \\\"{x:146,y:541,t:1527272203931};\\\", \\\"{x:150,y:541,t:1527272203940};\\\", \\\"{x:153,y:542,t:1527272203956};\\\", \\\"{x:157,y:544,t:1527272203972};\\\", \\\"{x:158,y:544,t:1527272204082};\\\", \\\"{x:161,y:544,t:1527272204507};\\\", \\\"{x:232,y:523,t:1527272204524};\\\", \\\"{x:400,y:503,t:1527272204541};\\\", \\\"{x:555,y:501,t:1527272204557};\\\", \\\"{x:680,y:501,t:1527272204573};\\\", \\\"{x:771,y:507,t:1527272204590};\\\", \\\"{x:816,y:522,t:1527272204607};\\\", \\\"{x:835,y:530,t:1527272204623};\\\", \\\"{x:839,y:532,t:1527272204640};\\\", \\\"{x:840,y:532,t:1527272204656};\\\", \\\"{x:841,y:531,t:1527272204787};\\\", \\\"{x:843,y:529,t:1527272204794};\\\", \\\"{x:843,y:526,t:1527272204807};\\\", \\\"{x:843,y:523,t:1527272204824};\\\", \\\"{x:842,y:521,t:1527272204839};\\\", \\\"{x:842,y:520,t:1527272204857};\\\", \\\"{x:840,y:517,t:1527272204874};\\\", \\\"{x:838,y:513,t:1527272204891};\\\", \\\"{x:837,y:511,t:1527272204906};\\\", \\\"{x:837,y:507,t:1527272205019};\\\", \\\"{x:837,y:505,t:1527272205026};\\\", \\\"{x:837,y:504,t:1527272205041};\\\", \\\"{x:837,y:502,t:1527272205056};\\\", \\\"{x:838,y:506,t:1527272205339};\\\", \\\"{x:835,y:521,t:1527272205347};\\\", \\\"{x:822,y:541,t:1527272205357};\\\", \\\"{x:797,y:572,t:1527272205374};\\\", \\\"{x:761,y:597,t:1527272205391};\\\", \\\"{x:718,y:628,t:1527272205408};\\\", \\\"{x:677,y:663,t:1527272205424};\\\", \\\"{x:649,y:690,t:1527272205440};\\\", \\\"{x:634,y:706,t:1527272205457};\\\", \\\"{x:622,y:715,t:1527272205474};\\\", \\\"{x:600,y:721,t:1527272205491};\\\", \\\"{x:580,y:724,t:1527272205508};\\\", \\\"{x:560,y:724,t:1527272205526};\\\", \\\"{x:549,y:724,t:1527272205541};\\\", \\\"{x:547,y:724,t:1527272205557};\\\", \\\"{x:543,y:722,t:1527272205574};\\\", \\\"{x:540,y:719,t:1527272205591};\\\", \\\"{x:538,y:716,t:1527272205608};\\\", \\\"{x:536,y:711,t:1527272205624};\\\", \\\"{x:535,y:709,t:1527272205641};\\\", \\\"{x:533,y:709,t:1527272205700};\\\", \\\"{x:531,y:709,t:1527272205708};\\\", \\\"{x:527,y:717,t:1527272205724};\\\", \\\"{x:526,y:720,t:1527272205741};\\\", \\\"{x:526,y:721,t:1527272205758};\\\", \\\"{x:526,y:722,t:1527272205787};\\\", \\\"{x:524,y:723,t:1527272205795};\\\", \\\"{x:524,y:724,t:1527272205808};\\\", \\\"{x:524,y:726,t:1527272205825};\\\", \\\"{x:524,y:727,t:1527272205841};\\\" ] }, { \\\"rt\\\": 11193, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 598025, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:722,t:1527272207851};\\\", \\\"{x:534,y:710,t:1527272207860};\\\", \\\"{x:542,y:690,t:1527272207876};\\\", \\\"{x:546,y:676,t:1527272207893};\\\", \\\"{x:551,y:664,t:1527272207910};\\\", \\\"{x:556,y:651,t:1527272207926};\\\", \\\"{x:566,y:633,t:1527272207942};\\\", \\\"{x:574,y:613,t:1527272207961};\\\", \\\"{x:578,y:596,t:1527272207976};\\\", \\\"{x:579,y:585,t:1527272207993};\\\", \\\"{x:580,y:581,t:1527272208008};\\\", \\\"{x:580,y:577,t:1527272208026};\\\", \\\"{x:580,y:572,t:1527272208043};\\\", \\\"{x:580,y:568,t:1527272208060};\\\", \\\"{x:578,y:560,t:1527272208076};\\\", \\\"{x:578,y:556,t:1527272208093};\\\", \\\"{x:577,y:555,t:1527272208109};\\\", \\\"{x:576,y:553,t:1527272208139};\\\", \\\"{x:576,y:552,t:1527272208147};\\\", \\\"{x:576,y:549,t:1527272208160};\\\", \\\"{x:574,y:542,t:1527272208175};\\\", \\\"{x:569,y:532,t:1527272208193};\\\", \\\"{x:567,y:522,t:1527272208211};\\\", \\\"{x:564,y:511,t:1527272208226};\\\", \\\"{x:560,y:491,t:1527272208243};\\\", \\\"{x:560,y:478,t:1527272208260};\\\", \\\"{x:560,y:470,t:1527272208276};\\\", \\\"{x:560,y:462,t:1527272208293};\\\", \\\"{x:560,y:458,t:1527272208310};\\\", \\\"{x:560,y:454,t:1527272208326};\\\", \\\"{x:561,y:452,t:1527272208343};\\\", \\\"{x:561,y:451,t:1527272208359};\\\", \\\"{x:563,y:451,t:1527272208652};\\\", \\\"{x:566,y:451,t:1527272208660};\\\", \\\"{x:591,y:451,t:1527272208677};\\\", \\\"{x:630,y:449,t:1527272208693};\\\", \\\"{x:692,y:441,t:1527272208710};\\\", \\\"{x:745,y:441,t:1527272208727};\\\", \\\"{x:772,y:441,t:1527272208743};\\\", \\\"{x:781,y:441,t:1527272208760};\\\", \\\"{x:789,y:442,t:1527272208777};\\\", \\\"{x:797,y:444,t:1527272208793};\\\", \\\"{x:800,y:446,t:1527272208809};\\\", \\\"{x:800,y:447,t:1527272208826};\\\", \\\"{x:801,y:447,t:1527272208842};\\\", \\\"{x:802,y:448,t:1527272208883};\\\", \\\"{x:803,y:449,t:1527272208892};\\\", \\\"{x:806,y:451,t:1527272208910};\\\", \\\"{x:816,y:456,t:1527272208926};\\\", \\\"{x:836,y:465,t:1527272208942};\\\", \\\"{x:867,y:479,t:1527272208960};\\\", \\\"{x:911,y:497,t:1527272208977};\\\", \\\"{x:970,y:514,t:1527272208993};\\\", \\\"{x:1050,y:537,t:1527272209009};\\\", \\\"{x:1162,y:573,t:1527272209027};\\\", \\\"{x:1212,y:596,t:1527272209044};\\\", \\\"{x:1245,y:616,t:1527272209060};\\\", \\\"{x:1267,y:634,t:1527272209077};\\\", \\\"{x:1288,y:649,t:1527272209094};\\\", \\\"{x:1307,y:662,t:1527272209109};\\\", \\\"{x:1320,y:669,t:1527272209127};\\\", \\\"{x:1328,y:676,t:1527272209144};\\\", \\\"{x:1339,y:684,t:1527272209160};\\\", \\\"{x:1352,y:694,t:1527272209177};\\\", \\\"{x:1368,y:705,t:1527272209194};\\\", \\\"{x:1383,y:717,t:1527272209210};\\\", \\\"{x:1397,y:729,t:1527272209227};\\\", \\\"{x:1402,y:732,t:1527272209244};\\\", \\\"{x:1403,y:733,t:1527272209260};\\\", \\\"{x:1405,y:734,t:1527272209277};\\\", \\\"{x:1403,y:731,t:1527272209387};\\\", \\\"{x:1401,y:729,t:1527272209395};\\\", \\\"{x:1397,y:724,t:1527272209410};\\\", \\\"{x:1392,y:722,t:1527272209427};\\\", \\\"{x:1389,y:719,t:1527272209444};\\\", \\\"{x:1385,y:716,t:1527272209461};\\\", \\\"{x:1382,y:713,t:1527272209477};\\\", \\\"{x:1381,y:712,t:1527272209494};\\\", \\\"{x:1378,y:710,t:1527272209511};\\\", \\\"{x:1375,y:708,t:1527272209527};\\\", \\\"{x:1374,y:707,t:1527272209544};\\\", \\\"{x:1373,y:706,t:1527272209561};\\\", \\\"{x:1372,y:706,t:1527272209578};\\\", \\\"{x:1371,y:706,t:1527272210811};\\\", \\\"{x:1370,y:706,t:1527272212027};\\\", \\\"{x:1367,y:706,t:1527272212035};\\\", \\\"{x:1364,y:708,t:1527272212046};\\\", \\\"{x:1353,y:715,t:1527272212063};\\\", \\\"{x:1333,y:725,t:1527272212080};\\\", \\\"{x:1299,y:733,t:1527272212096};\\\", \\\"{x:1232,y:733,t:1527272212113};\\\", \\\"{x:1140,y:730,t:1527272212130};\\\", \\\"{x:1015,y:714,t:1527272212147};\\\", \\\"{x:822,y:682,t:1527272212163};\\\", \\\"{x:726,y:649,t:1527272212180};\\\", \\\"{x:665,y:621,t:1527272212197};\\\", \\\"{x:633,y:603,t:1527272212213};\\\", \\\"{x:617,y:594,t:1527272212230};\\\", \\\"{x:616,y:592,t:1527272212242};\\\", \\\"{x:615,y:592,t:1527272212258};\\\", \\\"{x:613,y:590,t:1527272212331};\\\", \\\"{x:611,y:589,t:1527272212342};\\\", \\\"{x:604,y:585,t:1527272212359};\\\", \\\"{x:592,y:577,t:1527272212380};\\\", \\\"{x:587,y:575,t:1527272212396};\\\", \\\"{x:585,y:574,t:1527272212413};\\\", \\\"{x:584,y:573,t:1527272212514};\\\", \\\"{x:585,y:570,t:1527272212530};\\\", \\\"{x:599,y:558,t:1527272212546};\\\", \\\"{x:619,y:547,t:1527272212563};\\\", \\\"{x:625,y:544,t:1527272212580};\\\", \\\"{x:629,y:542,t:1527272212596};\\\", \\\"{x:633,y:540,t:1527272212613};\\\", \\\"{x:638,y:539,t:1527272212630};\\\", \\\"{x:641,y:537,t:1527272212647};\\\", \\\"{x:645,y:536,t:1527272212663};\\\", \\\"{x:647,y:536,t:1527272212683};\\\", \\\"{x:647,y:535,t:1527272212696};\\\", \\\"{x:653,y:534,t:1527272212713};\\\", \\\"{x:661,y:534,t:1527272212729};\\\", \\\"{x:684,y:534,t:1527272212746};\\\", \\\"{x:698,y:534,t:1527272212762};\\\", \\\"{x:713,y:534,t:1527272212780};\\\", \\\"{x:722,y:534,t:1527272212797};\\\", \\\"{x:729,y:534,t:1527272212814};\\\", \\\"{x:734,y:534,t:1527272212830};\\\", \\\"{x:737,y:534,t:1527272212846};\\\", \\\"{x:738,y:535,t:1527272212863};\\\", \\\"{x:736,y:535,t:1527272213075};\\\", \\\"{x:716,y:537,t:1527272213083};\\\", \\\"{x:671,y:539,t:1527272213096};\\\", \\\"{x:588,y:539,t:1527272213113};\\\", \\\"{x:499,y:539,t:1527272213130};\\\", \\\"{x:409,y:531,t:1527272213148};\\\", \\\"{x:381,y:528,t:1527272213163};\\\", \\\"{x:348,y:522,t:1527272213180};\\\", \\\"{x:333,y:521,t:1527272213197};\\\", \\\"{x:327,y:521,t:1527272213214};\\\", \\\"{x:325,y:521,t:1527272213230};\\\", \\\"{x:322,y:521,t:1527272213332};\\\", \\\"{x:312,y:523,t:1527272213347};\\\", \\\"{x:297,y:524,t:1527272213364};\\\", \\\"{x:275,y:528,t:1527272213381};\\\", \\\"{x:234,y:540,t:1527272213399};\\\", \\\"{x:198,y:549,t:1527272213414};\\\", \\\"{x:177,y:552,t:1527272213430};\\\", \\\"{x:163,y:555,t:1527272213447};\\\", \\\"{x:159,y:557,t:1527272213465};\\\", \\\"{x:157,y:559,t:1527272213480};\\\", \\\"{x:155,y:561,t:1527272213497};\\\", \\\"{x:152,y:566,t:1527272213515};\\\", \\\"{x:150,y:573,t:1527272213531};\\\", \\\"{x:148,y:579,t:1527272213546};\\\", \\\"{x:148,y:581,t:1527272213564};\\\", \\\"{x:145,y:586,t:1527272213580};\\\", \\\"{x:144,y:593,t:1527272213597};\\\", \\\"{x:144,y:599,t:1527272213614};\\\", \\\"{x:143,y:604,t:1527272213631};\\\", \\\"{x:143,y:608,t:1527272213647};\\\", \\\"{x:145,y:605,t:1527272213756};\\\", \\\"{x:148,y:601,t:1527272213764};\\\", \\\"{x:154,y:592,t:1527272213781};\\\", \\\"{x:158,y:585,t:1527272213798};\\\", \\\"{x:162,y:577,t:1527272213814};\\\", \\\"{x:162,y:571,t:1527272213831};\\\", \\\"{x:162,y:567,t:1527272213847};\\\", \\\"{x:163,y:562,t:1527272213864};\\\", \\\"{x:164,y:557,t:1527272213881};\\\", \\\"{x:164,y:555,t:1527272213898};\\\", \\\"{x:165,y:551,t:1527272213914};\\\", \\\"{x:165,y:550,t:1527272213930};\\\", \\\"{x:165,y:549,t:1527272213947};\\\", \\\"{x:166,y:548,t:1527272213964};\\\", \\\"{x:166,y:546,t:1527272214010};\\\", \\\"{x:166,y:545,t:1527272214026};\\\", \\\"{x:184,y:544,t:1527272214675};\\\", \\\"{x:236,y:544,t:1527272214683};\\\", \\\"{x:311,y:545,t:1527272214699};\\\", \\\"{x:611,y:586,t:1527272214715};\\\", \\\"{x:838,y:621,t:1527272214732};\\\", \\\"{x:1061,y:678,t:1527272214749};\\\", \\\"{x:1248,y:730,t:1527272214765};\\\", \\\"{x:1434,y:785,t:1527272214781};\\\", \\\"{x:1591,y:829,t:1527272214798};\\\", \\\"{x:1694,y:859,t:1527272214815};\\\", \\\"{x:1734,y:879,t:1527272214831};\\\", \\\"{x:1745,y:886,t:1527272214848};\\\", \\\"{x:1742,y:886,t:1527272214891};\\\", \\\"{x:1739,y:886,t:1527272214899};\\\", \\\"{x:1735,y:886,t:1527272214914};\\\", \\\"{x:1719,y:884,t:1527272214931};\\\", \\\"{x:1698,y:879,t:1527272214948};\\\", \\\"{x:1675,y:876,t:1527272214964};\\\", \\\"{x:1651,y:871,t:1527272214981};\\\", \\\"{x:1612,y:859,t:1527272214998};\\\", \\\"{x:1562,y:845,t:1527272215014};\\\", \\\"{x:1497,y:833,t:1527272215032};\\\", \\\"{x:1436,y:823,t:1527272215048};\\\", \\\"{x:1389,y:804,t:1527272215064};\\\", \\\"{x:1363,y:795,t:1527272215081};\\\", \\\"{x:1350,y:786,t:1527272215099};\\\", \\\"{x:1342,y:781,t:1527272215115};\\\", \\\"{x:1326,y:770,t:1527272215130};\\\", \\\"{x:1313,y:765,t:1527272215147};\\\", \\\"{x:1307,y:762,t:1527272215164};\\\", \\\"{x:1306,y:762,t:1527272215181};\\\", \\\"{x:1306,y:761,t:1527272215274};\\\", \\\"{x:1307,y:761,t:1527272215307};\\\", \\\"{x:1309,y:761,t:1527272215323};\\\", \\\"{x:1312,y:761,t:1527272215330};\\\", \\\"{x:1321,y:761,t:1527272215347};\\\", \\\"{x:1335,y:761,t:1527272215364};\\\", \\\"{x:1343,y:762,t:1527272215380};\\\", \\\"{x:1348,y:763,t:1527272215397};\\\", \\\"{x:1351,y:763,t:1527272215414};\\\", \\\"{x:1352,y:764,t:1527272216612};\\\", \\\"{x:1352,y:769,t:1527272216629};\\\", \\\"{x:1351,y:774,t:1527272216646};\\\", \\\"{x:1350,y:777,t:1527272216663};\\\", \\\"{x:1349,y:782,t:1527272216679};\\\", \\\"{x:1349,y:786,t:1527272216696};\\\", \\\"{x:1347,y:792,t:1527272216713};\\\", \\\"{x:1346,y:798,t:1527272216729};\\\", \\\"{x:1345,y:807,t:1527272216746};\\\", \\\"{x:1345,y:820,t:1527272216762};\\\", \\\"{x:1345,y:834,t:1527272216779};\\\", \\\"{x:1345,y:848,t:1527272216796};\\\", \\\"{x:1342,y:863,t:1527272216812};\\\", \\\"{x:1341,y:876,t:1527272216830};\\\", \\\"{x:1337,y:891,t:1527272216846};\\\", \\\"{x:1334,y:906,t:1527272216863};\\\", \\\"{x:1329,y:914,t:1527272216879};\\\", \\\"{x:1325,y:919,t:1527272216896};\\\", \\\"{x:1323,y:924,t:1527272216913};\\\", \\\"{x:1322,y:926,t:1527272216928};\\\", \\\"{x:1322,y:920,t:1527272217011};\\\", \\\"{x:1322,y:887,t:1527272217029};\\\", \\\"{x:1322,y:842,t:1527272217045};\\\", \\\"{x:1322,y:786,t:1527272217063};\\\", \\\"{x:1328,y:738,t:1527272217078};\\\", \\\"{x:1340,y:693,t:1527272217095};\\\", \\\"{x:1344,y:667,t:1527272217112};\\\", \\\"{x:1347,y:654,t:1527272217128};\\\", \\\"{x:1348,y:646,t:1527272217145};\\\", \\\"{x:1348,y:640,t:1527272217162};\\\", \\\"{x:1348,y:637,t:1527272217178};\\\", \\\"{x:1348,y:634,t:1527272217195};\\\", \\\"{x:1348,y:633,t:1527272217211};\\\", \\\"{x:1348,y:632,t:1527272217228};\\\", \\\"{x:1347,y:631,t:1527272217246};\\\", \\\"{x:1342,y:631,t:1527272217261};\\\", \\\"{x:1318,y:641,t:1527272217278};\\\", \\\"{x:1264,y:672,t:1527272217295};\\\", \\\"{x:1196,y:708,t:1527272217311};\\\", \\\"{x:1135,y:734,t:1527272217328};\\\", \\\"{x:1054,y:761,t:1527272217345};\\\", \\\"{x:966,y:780,t:1527272217361};\\\", \\\"{x:885,y:793,t:1527272217378};\\\", \\\"{x:807,y:802,t:1527272217395};\\\", \\\"{x:771,y:805,t:1527272217411};\\\", \\\"{x:740,y:806,t:1527272217428};\\\", \\\"{x:716,y:806,t:1527272217445};\\\", \\\"{x:693,y:806,t:1527272217461};\\\", \\\"{x:676,y:806,t:1527272217478};\\\", \\\"{x:672,y:806,t:1527272217495};\\\", \\\"{x:671,y:806,t:1527272217511};\\\", \\\"{x:670,y:805,t:1527272217528};\\\", \\\"{x:666,y:802,t:1527272217544};\\\", \\\"{x:662,y:798,t:1527272217561};\\\", \\\"{x:660,y:796,t:1527272217578};\\\", \\\"{x:656,y:787,t:1527272217594};\\\", \\\"{x:644,y:757,t:1527272217612};\\\", \\\"{x:632,y:735,t:1527272217628};\\\", \\\"{x:618,y:723,t:1527272217644};\\\", \\\"{x:613,y:719,t:1527272217661};\\\", \\\"{x:609,y:718,t:1527272217678};\\\", \\\"{x:607,y:717,t:1527272217694};\\\", \\\"{x:599,y:717,t:1527272217711};\\\", \\\"{x:576,y:714,t:1527272217728};\\\", \\\"{x:548,y:709,t:1527272217744};\\\", \\\"{x:535,y:706,t:1527272217761};\\\", \\\"{x:533,y:705,t:1527272217777};\\\", \\\"{x:532,y:705,t:1527272217794};\\\", \\\"{x:531,y:705,t:1527272217834};\\\", \\\"{x:530,y:707,t:1527272217845};\\\", \\\"{x:524,y:716,t:1527272217861};\\\", \\\"{x:520,y:721,t:1527272217878};\\\", \\\"{x:519,y:723,t:1527272217894};\\\", \\\"{x:519,y:725,t:1527272217911};\\\", \\\"{x:518,y:727,t:1527272217934};\\\", \\\"{x:518,y:733,t:1527272217950};\\\", \\\"{x:518,y:741,t:1527272217967};\\\", \\\"{x:518,y:748,t:1527272217984};\\\", \\\"{x:518,y:752,t:1527272218001};\\\", \\\"{x:518,y:753,t:1527272218017};\\\", \\\"{x:518,y:752,t:1527272218172};\\\", \\\"{x:518,y:750,t:1527272218184};\\\", \\\"{x:518,y:742,t:1527272218202};\\\", \\\"{x:519,y:732,t:1527272218218};\\\", \\\"{x:521,y:730,t:1527272218235};\\\" ] }, { \\\"rt\\\": 32594, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 631832, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -N -12 PM-12 PM-2\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:729,t:1527272220223};\\\", \\\"{x:521,y:706,t:1527272220239};\\\", \\\"{x:521,y:676,t:1527272220256};\\\", \\\"{x:521,y:643,t:1527272220272};\\\", \\\"{x:521,y:584,t:1527272220289};\\\", \\\"{x:521,y:546,t:1527272220307};\\\", \\\"{x:521,y:529,t:1527272220323};\\\", \\\"{x:519,y:518,t:1527272220340};\\\", \\\"{x:517,y:515,t:1527272220721};\\\", \\\"{x:510,y:499,t:1527272220740};\\\", \\\"{x:497,y:478,t:1527272220758};\\\", \\\"{x:491,y:468,t:1527272220773};\\\", \\\"{x:488,y:461,t:1527272220790};\\\", \\\"{x:487,y:460,t:1527272220806};\\\", \\\"{x:486,y:457,t:1527272220823};\\\", \\\"{x:483,y:453,t:1527272220841};\\\", \\\"{x:481,y:452,t:1527272220858};\\\", \\\"{x:480,y:450,t:1527272220873};\\\", \\\"{x:480,y:449,t:1527272220895};\\\", \\\"{x:484,y:449,t:1527272221560};\\\", \\\"{x:493,y:451,t:1527272221575};\\\", \\\"{x:518,y:456,t:1527272221591};\\\", \\\"{x:537,y:459,t:1527272221608};\\\", \\\"{x:554,y:464,t:1527272221625};\\\", \\\"{x:561,y:466,t:1527272221643};\\\", \\\"{x:568,y:469,t:1527272221658};\\\", \\\"{x:569,y:469,t:1527272221674};\\\", \\\"{x:570,y:469,t:1527272221692};\\\", \\\"{x:571,y:469,t:1527272221943};\\\", \\\"{x:572,y:469,t:1527272222023};\\\", \\\"{x:573,y:469,t:1527272222031};\\\", \\\"{x:574,y:469,t:1527272222041};\\\", \\\"{x:580,y:469,t:1527272222057};\\\", \\\"{x:596,y:469,t:1527272222074};\\\", \\\"{x:635,y:466,t:1527272222092};\\\", \\\"{x:728,y:464,t:1527272222107};\\\", \\\"{x:827,y:464,t:1527272222124};\\\", \\\"{x:935,y:464,t:1527272222141};\\\", \\\"{x:1103,y:471,t:1527272222158};\\\", \\\"{x:1223,y:489,t:1527272222175};\\\", \\\"{x:1344,y:521,t:1527272222191};\\\", \\\"{x:1468,y:554,t:1527272222208};\\\", \\\"{x:1584,y:603,t:1527272222224};\\\", \\\"{x:1669,y:652,t:1527272222241};\\\", \\\"{x:1722,y:690,t:1527272222258};\\\", \\\"{x:1757,y:718,t:1527272222274};\\\", \\\"{x:1775,y:733,t:1527272222292};\\\", \\\"{x:1783,y:739,t:1527272222309};\\\", \\\"{x:1788,y:742,t:1527272222324};\\\", \\\"{x:1789,y:743,t:1527272222341};\\\", \\\"{x:1789,y:744,t:1527272222408};\\\", \\\"{x:1788,y:749,t:1527272222416};\\\", \\\"{x:1784,y:756,t:1527272222425};\\\", \\\"{x:1775,y:770,t:1527272222442};\\\", \\\"{x:1771,y:780,t:1527272222459};\\\", \\\"{x:1767,y:788,t:1527272222475};\\\", \\\"{x:1767,y:791,t:1527272222492};\\\", \\\"{x:1766,y:792,t:1527272222509};\\\", \\\"{x:1762,y:797,t:1527272222525};\\\", \\\"{x:1755,y:803,t:1527272222542};\\\", \\\"{x:1746,y:813,t:1527272222559};\\\", \\\"{x:1739,y:818,t:1527272222577};\\\", \\\"{x:1734,y:820,t:1527272222592};\\\", \\\"{x:1729,y:821,t:1527272222609};\\\", \\\"{x:1724,y:823,t:1527272222625};\\\", \\\"{x:1719,y:825,t:1527272222643};\\\", \\\"{x:1715,y:827,t:1527272222659};\\\", \\\"{x:1712,y:827,t:1527272222676};\\\", \\\"{x:1707,y:827,t:1527272222692};\\\", \\\"{x:1704,y:829,t:1527272222709};\\\", \\\"{x:1702,y:829,t:1527272223464};\\\", \\\"{x:1700,y:829,t:1527272223476};\\\", \\\"{x:1693,y:829,t:1527272223493};\\\", \\\"{x:1680,y:828,t:1527272223511};\\\", \\\"{x:1673,y:824,t:1527272223526};\\\", \\\"{x:1657,y:814,t:1527272223542};\\\", \\\"{x:1640,y:806,t:1527272223559};\\\", \\\"{x:1634,y:800,t:1527272223575};\\\", \\\"{x:1633,y:799,t:1527272223593};\\\", \\\"{x:1633,y:796,t:1527272223695};\\\", \\\"{x:1633,y:787,t:1527272223709};\\\", \\\"{x:1635,y:776,t:1527272223725};\\\", \\\"{x:1637,y:766,t:1527272223743};\\\", \\\"{x:1637,y:754,t:1527272223759};\\\", \\\"{x:1633,y:747,t:1527272223776};\\\", \\\"{x:1630,y:743,t:1527272223792};\\\", \\\"{x:1629,y:742,t:1527272223809};\\\", \\\"{x:1627,y:740,t:1527272223826};\\\", \\\"{x:1625,y:738,t:1527272223842};\\\", \\\"{x:1621,y:734,t:1527272223860};\\\", \\\"{x:1620,y:733,t:1527272223876};\\\", \\\"{x:1618,y:731,t:1527272223892};\\\", \\\"{x:1618,y:729,t:1527272223909};\\\", \\\"{x:1617,y:729,t:1527272223925};\\\", \\\"{x:1616,y:728,t:1527272223958};\\\", \\\"{x:1615,y:726,t:1527272223974};\\\", \\\"{x:1614,y:725,t:1527272223982};\\\", \\\"{x:1614,y:724,t:1527272223992};\\\", \\\"{x:1611,y:721,t:1527272224009};\\\", \\\"{x:1611,y:720,t:1527272224026};\\\", \\\"{x:1611,y:719,t:1527272224110};\\\", \\\"{x:1611,y:718,t:1527272224150};\\\", \\\"{x:1611,y:717,t:1527272224167};\\\", \\\"{x:1610,y:715,t:1527272224343};\\\", \\\"{x:1610,y:714,t:1527272224359};\\\", \\\"{x:1610,y:713,t:1527272224486};\\\", \\\"{x:1610,y:711,t:1527272224600};\\\", \\\"{x:1610,y:710,t:1527272224712};\\\", \\\"{x:1609,y:710,t:1527272224727};\\\", \\\"{x:1608,y:709,t:1527272224856};\\\", \\\"{x:1604,y:718,t:1527272229046};\\\", \\\"{x:1592,y:735,t:1527272229062};\\\", \\\"{x:1583,y:748,t:1527272229080};\\\", \\\"{x:1578,y:754,t:1527272229095};\\\", \\\"{x:1574,y:759,t:1527272229113};\\\", \\\"{x:1569,y:765,t:1527272229130};\\\", \\\"{x:1565,y:772,t:1527272229145};\\\", \\\"{x:1560,y:780,t:1527272229162};\\\", \\\"{x:1555,y:786,t:1527272229180};\\\", \\\"{x:1552,y:789,t:1527272229195};\\\", \\\"{x:1549,y:794,t:1527272229213};\\\", \\\"{x:1548,y:795,t:1527272229230};\\\", \\\"{x:1541,y:795,t:1527272230303};\\\", \\\"{x:1513,y:788,t:1527272230314};\\\", \\\"{x:1397,y:759,t:1527272230331};\\\", \\\"{x:1233,y:724,t:1527272230347};\\\", \\\"{x:1071,y:693,t:1527272230364};\\\", \\\"{x:949,y:674,t:1527272230380};\\\", \\\"{x:852,y:663,t:1527272230397};\\\", \\\"{x:760,y:645,t:1527272230414};\\\", \\\"{x:694,y:627,t:1527272230432};\\\", \\\"{x:636,y:613,t:1527272230446};\\\", \\\"{x:519,y:591,t:1527272230464};\\\", \\\"{x:405,y:570,t:1527272230482};\\\", \\\"{x:301,y:550,t:1527272230499};\\\", \\\"{x:231,y:540,t:1527272230516};\\\", \\\"{x:183,y:533,t:1527272230532};\\\", \\\"{x:173,y:530,t:1527272230547};\\\", \\\"{x:172,y:530,t:1527272230582};\\\", \\\"{x:182,y:528,t:1527272230598};\\\", \\\"{x:251,y:515,t:1527272230615};\\\", \\\"{x:342,y:503,t:1527272230632};\\\", \\\"{x:447,y:491,t:1527272230648};\\\", \\\"{x:539,y:491,t:1527272230665};\\\", \\\"{x:608,y:491,t:1527272230682};\\\", \\\"{x:638,y:495,t:1527272230699};\\\", \\\"{x:652,y:499,t:1527272230715};\\\", \\\"{x:654,y:500,t:1527272230732};\\\", \\\"{x:653,y:504,t:1527272230767};\\\", \\\"{x:652,y:505,t:1527272230790};\\\", \\\"{x:651,y:507,t:1527272230798};\\\", \\\"{x:641,y:517,t:1527272230816};\\\", \\\"{x:627,y:540,t:1527272230833};\\\", \\\"{x:615,y:562,t:1527272230849};\\\", \\\"{x:609,y:579,t:1527272230865};\\\", \\\"{x:608,y:586,t:1527272230881};\\\", \\\"{x:607,y:586,t:1527272230898};\\\", \\\"{x:606,y:586,t:1527272230914};\\\", \\\"{x:605,y:587,t:1527272230942};\\\", \\\"{x:605,y:589,t:1527272230975};\\\", \\\"{x:605,y:590,t:1527272230983};\\\", \\\"{x:605,y:591,t:1527272230999};\\\", \\\"{x:606,y:593,t:1527272231016};\\\", \\\"{x:607,y:594,t:1527272231033};\\\", \\\"{x:608,y:596,t:1527272231049};\\\", \\\"{x:609,y:597,t:1527272231066};\\\", \\\"{x:610,y:599,t:1527272231081};\\\", \\\"{x:609,y:599,t:1527272231199};\\\", \\\"{x:608,y:597,t:1527272231216};\\\", \\\"{x:608,y:595,t:1527272231232};\\\", \\\"{x:608,y:594,t:1527272231249};\\\", \\\"{x:608,y:592,t:1527272231267};\\\", \\\"{x:608,y:590,t:1527272231282};\\\", \\\"{x:608,y:588,t:1527272231300};\\\", \\\"{x:608,y:587,t:1527272231316};\\\", \\\"{x:608,y:586,t:1527272231351};\\\", \\\"{x:608,y:585,t:1527272231406};\\\", \\\"{x:608,y:584,t:1527272231416};\\\", \\\"{x:608,y:583,t:1527272231439};\\\", \\\"{x:608,y:582,t:1527272232558};\\\", \\\"{x:606,y:581,t:1527272232566};\\\", \\\"{x:591,y:586,t:1527272232583};\\\", \\\"{x:574,y:594,t:1527272232601};\\\", \\\"{x:550,y:605,t:1527272232618};\\\", \\\"{x:511,y:629,t:1527272232633};\\\", \\\"{x:479,y:656,t:1527272232651};\\\", \\\"{x:448,y:674,t:1527272232667};\\\", \\\"{x:420,y:695,t:1527272232683};\\\", \\\"{x:390,y:721,t:1527272232700};\\\", \\\"{x:338,y:764,t:1527272232717};\\\", \\\"{x:290,y:795,t:1527272232732};\\\", \\\"{x:235,y:832,t:1527272232749};\\\", \\\"{x:184,y:881,t:1527272232766};\\\", \\\"{x:174,y:892,t:1527272232783};\\\", \\\"{x:171,y:896,t:1527272232800};\\\", \\\"{x:170,y:896,t:1527272232983};\\\", \\\"{x:153,y:898,t:1527272233001};\\\", \\\"{x:128,y:898,t:1527272233017};\\\", \\\"{x:93,y:901,t:1527272233033};\\\", \\\"{x:40,y:902,t:1527272233050};\\\", \\\"{x:0,y:902,t:1527272233068};\\\", \\\"{x:0,y:899,t:1527272233083};\\\", \\\"{x:0,y:893,t:1527272233100};\\\", \\\"{x:0,y:890,t:1527272233117};\\\", \\\"{x:0,y:888,t:1527272233133};\\\", \\\"{x:0,y:891,t:1527272233151};\\\", \\\"{x:0,y:899,t:1527272233167};\\\", \\\"{x:0,y:905,t:1527272233183};\\\", \\\"{x:0,y:906,t:1527272233200};\\\", \\\"{x:0,y:910,t:1527272233216};\\\", \\\"{x:0,y:912,t:1527272233233};\\\", \\\"{x:0,y:915,t:1527272233249};\\\", \\\"{x:0,y:921,t:1527272233266};\\\", \\\"{x:0,y:925,t:1527272233282};\\\", \\\"{x:0,y:928,t:1527272233299};\\\", \\\"{x:0,y:930,t:1527272233315};\\\", \\\"{x:0,y:932,t:1527272233333};\\\", \\\"{x:0,y:934,t:1527272233350};\\\", \\\"{x:0,y:935,t:1527272233365};\\\", \\\"{x:0,y:936,t:1527272233382};\\\", \\\"{x:0,y:937,t:1527272233478};\\\", \\\"{x:0,y:938,t:1527272233494};\\\", \\\"{x:0,y:939,t:1527272233502};\\\", \\\"{x:0,y:943,t:1527272233515};\\\", \\\"{x:0,y:947,t:1527272233533};\\\", \\\"{x:0,y:950,t:1527272233550};\\\", \\\"{x:0,y:951,t:1527272233566};\\\", \\\"{x:0,y:952,t:1527272233583};\\\", \\\"{x:0,y:954,t:1527272233695};\\\", \\\"{x:1,y:956,t:1527272233711};\\\", \\\"{x:3,y:957,t:1527272233718};\\\", \\\"{x:7,y:959,t:1527272233733};\\\", \\\"{x:11,y:959,t:1527272233750};\\\", \\\"{x:12,y:959,t:1527272233766};\\\", \\\"{x:13,y:959,t:1527272241847};\\\", \\\"{x:17,y:951,t:1527272241863};\\\", \\\"{x:23,y:935,t:1527272241879};\\\", \\\"{x:39,y:911,t:1527272241896};\\\", \\\"{x:55,y:892,t:1527272241913};\\\", \\\"{x:67,y:878,t:1527272241930};\\\", \\\"{x:77,y:866,t:1527272241946};\\\", \\\"{x:89,y:852,t:1527272241962};\\\", \\\"{x:102,y:835,t:1527272241979};\\\", \\\"{x:118,y:816,t:1527272241995};\\\", \\\"{x:131,y:797,t:1527272242012};\\\", \\\"{x:148,y:768,t:1527272242029};\\\", \\\"{x:164,y:736,t:1527272242045};\\\", \\\"{x:193,y:659,t:1527272242062};\\\", \\\"{x:206,y:599,t:1527272242079};\\\", \\\"{x:208,y:556,t:1527272242095};\\\", \\\"{x:208,y:541,t:1527272242108};\\\", \\\"{x:205,y:523,t:1527272242125};\\\", \\\"{x:204,y:514,t:1527272242141};\\\", \\\"{x:204,y:513,t:1527272242157};\\\", \\\"{x:204,y:512,t:1527272242174};\\\", \\\"{x:204,y:511,t:1527272242254};\\\", \\\"{x:205,y:511,t:1527272242262};\\\", \\\"{x:206,y:511,t:1527272242286};\\\", \\\"{x:206,y:513,t:1527272242294};\\\", \\\"{x:208,y:519,t:1527272242308};\\\", \\\"{x:209,y:523,t:1527272242324};\\\", \\\"{x:211,y:529,t:1527272242342};\\\", \\\"{x:211,y:534,t:1527272242357};\\\", \\\"{x:211,y:548,t:1527272242374};\\\", \\\"{x:209,y:557,t:1527272242392};\\\", \\\"{x:207,y:566,t:1527272242408};\\\", \\\"{x:204,y:572,t:1527272242424};\\\", \\\"{x:204,y:579,t:1527272242441};\\\", \\\"{x:204,y:585,t:1527272242458};\\\", \\\"{x:203,y:591,t:1527272242474};\\\", \\\"{x:203,y:597,t:1527272242492};\\\", \\\"{x:204,y:607,t:1527272242507};\\\", \\\"{x:211,y:619,t:1527272242524};\\\", \\\"{x:221,y:628,t:1527272242541};\\\", \\\"{x:246,y:634,t:1527272242559};\\\", \\\"{x:275,y:634,t:1527272242574};\\\", \\\"{x:302,y:634,t:1527272242591};\\\", \\\"{x:345,y:634,t:1527272242608};\\\", \\\"{x:386,y:630,t:1527272242625};\\\", \\\"{x:426,y:623,t:1527272242642};\\\", \\\"{x:457,y:614,t:1527272242658};\\\", \\\"{x:479,y:609,t:1527272242674};\\\", \\\"{x:495,y:604,t:1527272242692};\\\", \\\"{x:511,y:600,t:1527272242709};\\\", \\\"{x:518,y:600,t:1527272242725};\\\", \\\"{x:521,y:600,t:1527272242741};\\\", \\\"{x:521,y:598,t:1527272242806};\\\", \\\"{x:525,y:597,t:1527272242813};\\\", \\\"{x:531,y:595,t:1527272242825};\\\", \\\"{x:540,y:592,t:1527272242842};\\\", \\\"{x:556,y:588,t:1527272242858};\\\", \\\"{x:573,y:585,t:1527272242875};\\\", \\\"{x:592,y:581,t:1527272242891};\\\", \\\"{x:604,y:580,t:1527272242909};\\\", \\\"{x:613,y:576,t:1527272242925};\\\", \\\"{x:620,y:573,t:1527272242941};\\\", \\\"{x:631,y:571,t:1527272242958};\\\", \\\"{x:645,y:565,t:1527272242975};\\\", \\\"{x:661,y:560,t:1527272242992};\\\", \\\"{x:674,y:556,t:1527272243008};\\\", \\\"{x:685,y:551,t:1527272243026};\\\", \\\"{x:689,y:550,t:1527272243042};\\\", \\\"{x:689,y:549,t:1527272243058};\\\", \\\"{x:689,y:548,t:1527272243126};\\\", \\\"{x:686,y:548,t:1527272243142};\\\", \\\"{x:678,y:547,t:1527272243158};\\\", \\\"{x:674,y:547,t:1527272243175};\\\", \\\"{x:669,y:547,t:1527272243192};\\\", \\\"{x:660,y:547,t:1527272243208};\\\", \\\"{x:653,y:547,t:1527272243225};\\\", \\\"{x:645,y:549,t:1527272243242};\\\", \\\"{x:640,y:551,t:1527272243258};\\\", \\\"{x:636,y:552,t:1527272243275};\\\", \\\"{x:634,y:553,t:1527272243292};\\\", \\\"{x:633,y:554,t:1527272243308};\\\", \\\"{x:631,y:555,t:1527272243325};\\\", \\\"{x:629,y:557,t:1527272243343};\\\", \\\"{x:627,y:558,t:1527272243358};\\\", \\\"{x:625,y:559,t:1527272243375};\\\", \\\"{x:624,y:560,t:1527272243392};\\\", \\\"{x:623,y:561,t:1527272243439};\\\", \\\"{x:621,y:561,t:1527272243455};\\\", \\\"{x:620,y:561,t:1527272243463};\\\", \\\"{x:618,y:563,t:1527272243476};\\\", \\\"{x:614,y:564,t:1527272243492};\\\", \\\"{x:610,y:567,t:1527272243509};\\\", \\\"{x:601,y:568,t:1527272243526};\\\", \\\"{x:583,y:571,t:1527272243543};\\\", \\\"{x:565,y:574,t:1527272243559};\\\", \\\"{x:536,y:574,t:1527272243575};\\\", \\\"{x:477,y:574,t:1527272243593};\\\", \\\"{x:399,y:574,t:1527272243609};\\\", \\\"{x:324,y:574,t:1527272243625};\\\", \\\"{x:271,y:574,t:1527272243642};\\\", \\\"{x:237,y:574,t:1527272243659};\\\", \\\"{x:216,y:574,t:1527272243674};\\\", \\\"{x:209,y:574,t:1527272243692};\\\", \\\"{x:207,y:574,t:1527272243708};\\\", \\\"{x:208,y:574,t:1527272243878};\\\", \\\"{x:211,y:574,t:1527272243891};\\\", \\\"{x:221,y:572,t:1527272243908};\\\", \\\"{x:235,y:568,t:1527272243925};\\\", \\\"{x:251,y:566,t:1527272243941};\\\", \\\"{x:276,y:561,t:1527272243959};\\\", \\\"{x:298,y:560,t:1527272243974};\\\", \\\"{x:325,y:557,t:1527272243992};\\\", \\\"{x:355,y:555,t:1527272244009};\\\", \\\"{x:380,y:550,t:1527272244025};\\\", \\\"{x:402,y:548,t:1527272244042};\\\", \\\"{x:419,y:545,t:1527272244059};\\\", \\\"{x:430,y:544,t:1527272244076};\\\", \\\"{x:436,y:541,t:1527272244092};\\\", \\\"{x:439,y:541,t:1527272244109};\\\", \\\"{x:440,y:541,t:1527272244150};\\\", \\\"{x:441,y:541,t:1527272244159};\\\", \\\"{x:448,y:539,t:1527272244176};\\\", \\\"{x:455,y:536,t:1527272244193};\\\", \\\"{x:465,y:535,t:1527272244209};\\\", \\\"{x:477,y:535,t:1527272244227};\\\", \\\"{x:490,y:532,t:1527272244243};\\\", \\\"{x:498,y:531,t:1527272244259};\\\", \\\"{x:505,y:530,t:1527272244277};\\\", \\\"{x:512,y:530,t:1527272244293};\\\", \\\"{x:526,y:528,t:1527272244309};\\\", \\\"{x:550,y:528,t:1527272244326};\\\", \\\"{x:572,y:528,t:1527272244343};\\\", \\\"{x:591,y:528,t:1527272244359};\\\", \\\"{x:609,y:528,t:1527272244377};\\\", \\\"{x:624,y:528,t:1527272244393};\\\", \\\"{x:639,y:528,t:1527272244409};\\\", \\\"{x:659,y:528,t:1527272244426};\\\", \\\"{x:678,y:528,t:1527272244443};\\\", \\\"{x:697,y:528,t:1527272244459};\\\", \\\"{x:711,y:528,t:1527272244476};\\\", \\\"{x:721,y:528,t:1527272244493};\\\", \\\"{x:726,y:528,t:1527272244509};\\\", \\\"{x:734,y:528,t:1527272244526};\\\", \\\"{x:738,y:528,t:1527272244543};\\\", \\\"{x:741,y:528,t:1527272244559};\\\", \\\"{x:742,y:528,t:1527272244576};\\\", \\\"{x:741,y:528,t:1527272244646};\\\", \\\"{x:737,y:531,t:1527272244660};\\\", \\\"{x:726,y:537,t:1527272244676};\\\", \\\"{x:708,y:547,t:1527272244693};\\\", \\\"{x:693,y:553,t:1527272244710};\\\", \\\"{x:693,y:554,t:1527272244726};\\\", \\\"{x:693,y:555,t:1527272244743};\\\", \\\"{x:692,y:557,t:1527272244760};\\\", \\\"{x:688,y:561,t:1527272244776};\\\", \\\"{x:679,y:569,t:1527272244793};\\\", \\\"{x:668,y:579,t:1527272244809};\\\", \\\"{x:658,y:588,t:1527272244826};\\\", \\\"{x:653,y:591,t:1527272244843};\\\", \\\"{x:651,y:593,t:1527272244859};\\\", \\\"{x:652,y:593,t:1527272244886};\\\", \\\"{x:663,y:593,t:1527272244894};\\\", \\\"{x:680,y:591,t:1527272244909};\\\", \\\"{x:739,y:576,t:1527272244926};\\\", \\\"{x:762,y:570,t:1527272244943};\\\", \\\"{x:774,y:564,t:1527272244960};\\\", \\\"{x:780,y:562,t:1527272244976};\\\", \\\"{x:781,y:561,t:1527272245022};\\\", \\\"{x:782,y:559,t:1527272245038};\\\", \\\"{x:785,y:555,t:1527272245047};\\\", \\\"{x:787,y:553,t:1527272245060};\\\", \\\"{x:790,y:549,t:1527272245076};\\\", \\\"{x:794,y:542,t:1527272245093};\\\", \\\"{x:798,y:535,t:1527272245110};\\\", \\\"{x:806,y:525,t:1527272245127};\\\", \\\"{x:808,y:520,t:1527272245143};\\\", \\\"{x:809,y:515,t:1527272245160};\\\", \\\"{x:811,y:509,t:1527272245176};\\\", \\\"{x:815,y:504,t:1527272245193};\\\", \\\"{x:820,y:501,t:1527272245210};\\\", \\\"{x:823,y:499,t:1527272245226};\\\", \\\"{x:824,y:498,t:1527272245243};\\\", \\\"{x:825,y:497,t:1527272245260};\\\", \\\"{x:827,y:496,t:1527272245276};\\\", \\\"{x:829,y:495,t:1527272245293};\\\", \\\"{x:829,y:494,t:1527272245310};\\\", \\\"{x:831,y:495,t:1527272245389};\\\", \\\"{x:832,y:496,t:1527272245405};\\\", \\\"{x:833,y:498,t:1527272245414};\\\", \\\"{x:833,y:499,t:1527272245427};\\\", \\\"{x:834,y:500,t:1527272245443};\\\", \\\"{x:838,y:501,t:1527272245894};\\\", \\\"{x:870,y:501,t:1527272245910};\\\", \\\"{x:969,y:496,t:1527272245927};\\\", \\\"{x:1037,y:491,t:1527272245944};\\\", \\\"{x:1046,y:490,t:1527272245960};\\\", \\\"{x:1046,y:491,t:1527272245982};\\\", \\\"{x:1067,y:494,t:1527272245994};\\\", \\\"{x:1079,y:496,t:1527272246010};\\\", \\\"{x:1079,y:497,t:1527272246026};\\\", \\\"{x:1080,y:500,t:1527272246044};\\\", \\\"{x:1079,y:509,t:1527272246060};\\\", \\\"{x:1074,y:523,t:1527272246077};\\\", \\\"{x:1074,y:542,t:1527272246093};\\\", \\\"{x:1074,y:551,t:1527272246111};\\\", \\\"{x:1072,y:556,t:1527272246127};\\\", \\\"{x:1072,y:562,t:1527272246144};\\\", \\\"{x:1072,y:570,t:1527272246161};\\\", \\\"{x:1079,y:582,t:1527272246177};\\\", \\\"{x:1086,y:598,t:1527272246194};\\\", \\\"{x:1094,y:607,t:1527272246211};\\\", \\\"{x:1101,y:613,t:1527272246227};\\\", \\\"{x:1111,y:621,t:1527272246244};\\\", \\\"{x:1128,y:630,t:1527272246261};\\\", \\\"{x:1155,y:646,t:1527272246277};\\\", \\\"{x:1188,y:667,t:1527272246294};\\\", \\\"{x:1206,y:675,t:1527272246312};\\\", \\\"{x:1218,y:681,t:1527272246327};\\\", \\\"{x:1234,y:689,t:1527272246345};\\\", \\\"{x:1248,y:695,t:1527272246362};\\\", \\\"{x:1258,y:698,t:1527272246377};\\\", \\\"{x:1267,y:699,t:1527272246394};\\\", \\\"{x:1275,y:700,t:1527272246412};\\\", \\\"{x:1286,y:703,t:1527272246428};\\\", \\\"{x:1307,y:707,t:1527272246444};\\\", \\\"{x:1329,y:711,t:1527272246462};\\\", \\\"{x:1352,y:714,t:1527272246478};\\\", \\\"{x:1370,y:716,t:1527272246494};\\\", \\\"{x:1381,y:719,t:1527272246511};\\\", \\\"{x:1385,y:719,t:1527272246528};\\\", \\\"{x:1388,y:719,t:1527272246544};\\\", \\\"{x:1390,y:719,t:1527272246562};\\\", \\\"{x:1391,y:719,t:1527272246578};\\\", \\\"{x:1393,y:718,t:1527272246595};\\\", \\\"{x:1395,y:716,t:1527272246612};\\\", \\\"{x:1396,y:716,t:1527272246629};\\\", \\\"{x:1397,y:716,t:1527272246751};\\\", \\\"{x:1397,y:717,t:1527272246762};\\\", \\\"{x:1397,y:723,t:1527272246779};\\\", \\\"{x:1397,y:731,t:1527272246794};\\\", \\\"{x:1397,y:740,t:1527272246811};\\\", \\\"{x:1397,y:755,t:1527272246828};\\\", \\\"{x:1397,y:776,t:1527272246845};\\\", \\\"{x:1394,y:794,t:1527272246861};\\\", \\\"{x:1386,y:819,t:1527272246878};\\\", \\\"{x:1381,y:842,t:1527272246896};\\\", \\\"{x:1379,y:871,t:1527272246912};\\\", \\\"{x:1373,y:907,t:1527272246929};\\\", \\\"{x:1372,y:941,t:1527272246945};\\\", \\\"{x:1369,y:962,t:1527272246961};\\\", \\\"{x:1368,y:972,t:1527272246978};\\\", \\\"{x:1367,y:977,t:1527272246996};\\\", \\\"{x:1367,y:980,t:1527272247011};\\\", \\\"{x:1367,y:984,t:1527272247028};\\\", \\\"{x:1367,y:986,t:1527272247046};\\\", \\\"{x:1367,y:988,t:1527272247062};\\\", \\\"{x:1365,y:988,t:1527272247192};\\\", \\\"{x:1365,y:987,t:1527272247215};\\\", \\\"{x:1364,y:986,t:1527272247229};\\\", \\\"{x:1363,y:984,t:1527272247246};\\\", \\\"{x:1362,y:981,t:1527272247263};\\\", \\\"{x:1361,y:978,t:1527272247279};\\\", \\\"{x:1361,y:977,t:1527272247335};\\\", \\\"{x:1361,y:975,t:1527272247367};\\\", \\\"{x:1362,y:974,t:1527272247407};\\\", \\\"{x:1362,y:973,t:1527272247735};\\\", \\\"{x:1361,y:971,t:1527272247863};\\\", \\\"{x:1359,y:971,t:1527272247887};\\\", \\\"{x:1358,y:971,t:1527272247895};\\\", \\\"{x:1356,y:969,t:1527272247913};\\\", \\\"{x:1354,y:969,t:1527272247930};\\\", \\\"{x:1353,y:968,t:1527272247947};\\\", \\\"{x:1351,y:967,t:1527272247963};\\\", \\\"{x:1355,y:962,t:1527272248302};\\\", \\\"{x:1364,y:959,t:1527272248312};\\\", \\\"{x:1394,y:952,t:1527272248329};\\\", \\\"{x:1432,y:943,t:1527272248346};\\\", \\\"{x:1478,y:940,t:1527272248362};\\\", \\\"{x:1520,y:940,t:1527272248379};\\\", \\\"{x:1554,y:943,t:1527272248396};\\\", \\\"{x:1581,y:949,t:1527272248413};\\\", \\\"{x:1606,y:957,t:1527272248429};\\\", \\\"{x:1628,y:961,t:1527272248446};\\\", \\\"{x:1631,y:962,t:1527272248464};\\\", \\\"{x:1634,y:962,t:1527272248480};\\\", \\\"{x:1630,y:962,t:1527272248662};\\\", \\\"{x:1617,y:962,t:1527272248669};\\\", \\\"{x:1599,y:959,t:1527272248680};\\\", \\\"{x:1538,y:942,t:1527272248696};\\\", \\\"{x:1454,y:925,t:1527272248713};\\\", \\\"{x:1347,y:903,t:1527272248730};\\\", \\\"{x:1248,y:879,t:1527272248746};\\\", \\\"{x:1147,y:858,t:1527272248763};\\\", \\\"{x:1056,y:835,t:1527272248780};\\\", \\\"{x:973,y:812,t:1527272248796};\\\", \\\"{x:909,y:793,t:1527272248813};\\\", \\\"{x:831,y:770,t:1527272248830};\\\", \\\"{x:798,y:757,t:1527272248846};\\\", \\\"{x:773,y:748,t:1527272248863};\\\", \\\"{x:742,y:739,t:1527272248880};\\\", \\\"{x:697,y:725,t:1527272248896};\\\", \\\"{x:641,y:709,t:1527272248913};\\\", \\\"{x:589,y:694,t:1527272248930};\\\", \\\"{x:549,y:683,t:1527272248946};\\\", \\\"{x:527,y:678,t:1527272248963};\\\", \\\"{x:515,y:674,t:1527272248980};\\\", \\\"{x:512,y:673,t:1527272248996};\\\", \\\"{x:509,y:673,t:1527272249094};\\\", \\\"{x:503,y:674,t:1527272249102};\\\", \\\"{x:497,y:677,t:1527272249113};\\\", \\\"{x:484,y:685,t:1527272249130};\\\", \\\"{x:474,y:692,t:1527272249147};\\\", \\\"{x:469,y:696,t:1527272249163};\\\", \\\"{x:469,y:698,t:1527272249180};\\\", \\\"{x:469,y:702,t:1527272249197};\\\", \\\"{x:469,y:707,t:1527272249213};\\\", \\\"{x:469,y:712,t:1527272249230};\\\", \\\"{x:472,y:719,t:1527272249247};\\\", \\\"{x:478,y:727,t:1527272249263};\\\", \\\"{x:480,y:732,t:1527272249280};\\\", \\\"{x:482,y:735,t:1527272249297};\\\", \\\"{x:483,y:737,t:1527272249313};\\\", \\\"{x:483,y:738,t:1527272249329};\\\", \\\"{x:484,y:739,t:1527272249346};\\\", \\\"{x:484,y:740,t:1527272249363};\\\", \\\"{x:484,y:742,t:1527272249390};\\\", \\\"{x:484,y:743,t:1527272249414};\\\", \\\"{x:486,y:744,t:1527272249430};\\\", \\\"{x:486,y:742,t:1527272249766};\\\", \\\"{x:486,y:741,t:1527272249782};\\\", \\\"{x:487,y:740,t:1527272249796};\\\", \\\"{x:487,y:739,t:1527272249813};\\\", \\\"{x:488,y:739,t:1527272249830};\\\", \\\"{x:489,y:738,t:1527272249846};\\\", \\\"{x:489,y:737,t:1527272251183};\\\", \\\"{x:488,y:736,t:1527272251198};\\\", \\\"{x:485,y:736,t:1527272251215};\\\", \\\"{x:484,y:736,t:1527272251232};\\\", \\\"{x:483,y:736,t:1527272251248};\\\", \\\"{x:485,y:736,t:1527272251487};\\\", \\\"{x:486,y:736,t:1527272252430};\\\", \\\"{x:485,y:736,t:1527272252790};\\\", \\\"{x:486,y:732,t:1527272252799};\\\", \\\"{x:494,y:720,t:1527272252817};\\\", \\\"{x:500,y:713,t:1527272252832};\\\", \\\"{x:505,y:709,t:1527272252849};\\\", \\\"{x:512,y:703,t:1527272252866};\\\", \\\"{x:517,y:700,t:1527272252883};\\\", \\\"{x:518,y:699,t:1527272252900};\\\", \\\"{x:518,y:698,t:1527272252926};\\\", \\\"{x:519,y:698,t:1527272252933};\\\", \\\"{x:520,y:697,t:1527272252949};\\\", \\\"{x:523,y:694,t:1527272252966};\\\", \\\"{x:525,y:692,t:1527272252982};\\\", \\\"{x:527,y:690,t:1527272252999};\\\", \\\"{x:530,y:688,t:1527272253017};\\\", \\\"{x:535,y:683,t:1527272253032};\\\", \\\"{x:537,y:680,t:1527272253049};\\\", \\\"{x:540,y:678,t:1527272253066};\\\", \\\"{x:544,y:676,t:1527272253083};\\\", \\\"{x:555,y:670,t:1527272253099};\\\", \\\"{x:564,y:668,t:1527272253116};\\\", \\\"{x:567,y:667,t:1527272253134};\\\", \\\"{x:568,y:667,t:1527272253149};\\\", \\\"{x:569,y:666,t:1527272253280};\\\" ] }, { \\\"rt\\\": 54861, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 687972, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-J -11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:560,y:681,t:1527272253501};\\\", \\\"{x:557,y:689,t:1527272253516};\\\", \\\"{x:554,y:695,t:1527272253534};\\\", \\\"{x:551,y:706,t:1527272253550};\\\", \\\"{x:551,y:709,t:1527272253566};\\\", \\\"{x:551,y:710,t:1527272253968};\\\", \\\"{x:553,y:709,t:1527272253997};\\\", \\\"{x:555,y:707,t:1527272254013};\\\", \\\"{x:557,y:705,t:1527272254021};\\\", \\\"{x:558,y:704,t:1527272254034};\\\", \\\"{x:561,y:701,t:1527272254050};\\\", \\\"{x:566,y:697,t:1527272254067};\\\", \\\"{x:566,y:696,t:1527272254083};\\\", \\\"{x:567,y:695,t:1527272254100};\\\", \\\"{x:568,y:693,t:1527272254118};\\\", \\\"{x:569,y:692,t:1527272254134};\\\", \\\"{x:570,y:692,t:1527272254439};\\\", \\\"{x:572,y:692,t:1527272254451};\\\", \\\"{x:579,y:693,t:1527272254468};\\\", \\\"{x:587,y:694,t:1527272254484};\\\", \\\"{x:591,y:694,t:1527272254500};\\\", \\\"{x:598,y:694,t:1527272254517};\\\", \\\"{x:621,y:696,t:1527272254534};\\\", \\\"{x:653,y:697,t:1527272254550};\\\", \\\"{x:744,y:707,t:1527272254568};\\\", \\\"{x:849,y:721,t:1527272254585};\\\", \\\"{x:955,y:735,t:1527272254600};\\\", \\\"{x:1084,y:752,t:1527272254619};\\\", \\\"{x:1209,y:770,t:1527272254635};\\\", \\\"{x:1320,y:782,t:1527272254651};\\\", \\\"{x:1409,y:797,t:1527272254668};\\\", \\\"{x:1463,y:807,t:1527272254685};\\\", \\\"{x:1491,y:814,t:1527272254701};\\\", \\\"{x:1502,y:819,t:1527272254718};\\\", \\\"{x:1513,y:825,t:1527272254735};\\\", \\\"{x:1520,y:828,t:1527272254751};\\\", \\\"{x:1529,y:832,t:1527272254768};\\\", \\\"{x:1536,y:835,t:1527272254785};\\\", \\\"{x:1540,y:838,t:1527272254801};\\\", \\\"{x:1544,y:840,t:1527272254818};\\\", \\\"{x:1551,y:846,t:1527272254835};\\\", \\\"{x:1560,y:854,t:1527272254851};\\\", \\\"{x:1566,y:860,t:1527272254869};\\\", \\\"{x:1574,y:865,t:1527272254885};\\\", \\\"{x:1578,y:868,t:1527272254902};\\\", \\\"{x:1590,y:876,t:1527272254918};\\\", \\\"{x:1593,y:878,t:1527272254935};\\\", \\\"{x:1596,y:879,t:1527272254952};\\\", \\\"{x:1597,y:880,t:1527272254968};\\\", \\\"{x:1598,y:880,t:1527272254985};\\\", \\\"{x:1598,y:884,t:1527272255135};\\\", \\\"{x:1595,y:895,t:1527272255151};\\\", \\\"{x:1589,y:904,t:1527272255167};\\\", \\\"{x:1583,y:914,t:1527272255184};\\\", \\\"{x:1577,y:922,t:1527272255201};\\\", \\\"{x:1571,y:929,t:1527272255218};\\\", \\\"{x:1566,y:936,t:1527272255235};\\\", \\\"{x:1560,y:946,t:1527272255252};\\\", \\\"{x:1556,y:953,t:1527272255268};\\\", \\\"{x:1553,y:956,t:1527272255285};\\\", \\\"{x:1553,y:958,t:1527272255302};\\\", \\\"{x:1552,y:960,t:1527272255319};\\\", \\\"{x:1552,y:961,t:1527272255334};\\\", \\\"{x:1552,y:963,t:1527272255352};\\\", \\\"{x:1552,y:964,t:1527272255390};\\\", \\\"{x:1552,y:965,t:1527272255423};\\\", \\\"{x:1552,y:966,t:1527272255439};\\\", \\\"{x:1552,y:968,t:1527272255454};\\\", \\\"{x:1552,y:970,t:1527272255469};\\\", \\\"{x:1552,y:972,t:1527272255485};\\\", \\\"{x:1552,y:974,t:1527272255502};\\\", \\\"{x:1552,y:976,t:1527272255519};\\\", \\\"{x:1554,y:969,t:1527272256318};\\\", \\\"{x:1555,y:956,t:1527272256336};\\\", \\\"{x:1556,y:946,t:1527272256353};\\\", \\\"{x:1556,y:936,t:1527272256369};\\\", \\\"{x:1556,y:931,t:1527272256386};\\\", \\\"{x:1558,y:926,t:1527272256402};\\\", \\\"{x:1559,y:917,t:1527272256419};\\\", \\\"{x:1559,y:908,t:1527272256436};\\\", \\\"{x:1559,y:898,t:1527272256453};\\\", \\\"{x:1559,y:889,t:1527272256468};\\\", \\\"{x:1559,y:883,t:1527272256485};\\\", \\\"{x:1560,y:878,t:1527272256502};\\\", \\\"{x:1562,y:869,t:1527272256518};\\\", \\\"{x:1562,y:861,t:1527272256535};\\\", \\\"{x:1562,y:856,t:1527272256553};\\\", \\\"{x:1562,y:854,t:1527272256569};\\\", \\\"{x:1562,y:851,t:1527272256585};\\\", \\\"{x:1562,y:848,t:1527272256602};\\\", \\\"{x:1562,y:846,t:1527272256619};\\\", \\\"{x:1562,y:842,t:1527272256636};\\\", \\\"{x:1562,y:839,t:1527272256652};\\\", \\\"{x:1561,y:834,t:1527272256669};\\\", \\\"{x:1560,y:833,t:1527272256685};\\\", \\\"{x:1560,y:832,t:1527272256702};\\\", \\\"{x:1559,y:831,t:1527272256766};\\\", \\\"{x:1559,y:830,t:1527272256774};\\\", \\\"{x:1559,y:828,t:1527272256786};\\\", \\\"{x:1558,y:823,t:1527272256802};\\\", \\\"{x:1556,y:820,t:1527272256819};\\\", \\\"{x:1555,y:817,t:1527272256836};\\\", \\\"{x:1554,y:815,t:1527272256853};\\\", \\\"{x:1554,y:813,t:1527272256870};\\\", \\\"{x:1552,y:810,t:1527272256886};\\\", \\\"{x:1551,y:806,t:1527272256902};\\\", \\\"{x:1548,y:798,t:1527272256921};\\\", \\\"{x:1544,y:790,t:1527272256936};\\\", \\\"{x:1542,y:784,t:1527272256952};\\\", \\\"{x:1540,y:779,t:1527272256969};\\\", \\\"{x:1539,y:775,t:1527272256986};\\\", \\\"{x:1538,y:774,t:1527272257002};\\\", \\\"{x:1538,y:772,t:1527272257046};\\\", \\\"{x:1537,y:770,t:1527272257054};\\\", \\\"{x:1537,y:768,t:1527272257070};\\\", \\\"{x:1537,y:767,t:1527272257086};\\\", \\\"{x:1536,y:764,t:1527272257103};\\\", \\\"{x:1536,y:762,t:1527272257120};\\\", \\\"{x:1536,y:760,t:1527272257136};\\\", \\\"{x:1536,y:758,t:1527272257153};\\\", \\\"{x:1536,y:757,t:1527272257169};\\\", \\\"{x:1536,y:754,t:1527272257185};\\\", \\\"{x:1536,y:752,t:1527272257203};\\\", \\\"{x:1536,y:750,t:1527272257220};\\\", \\\"{x:1537,y:747,t:1527272257238};\\\", \\\"{x:1538,y:744,t:1527272257253};\\\", \\\"{x:1541,y:737,t:1527272257270};\\\", \\\"{x:1542,y:730,t:1527272257286};\\\", \\\"{x:1544,y:720,t:1527272257303};\\\", \\\"{x:1545,y:710,t:1527272257320};\\\", \\\"{x:1546,y:696,t:1527272257337};\\\", \\\"{x:1546,y:687,t:1527272257353};\\\", \\\"{x:1546,y:682,t:1527272257370};\\\", \\\"{x:1547,y:678,t:1527272257387};\\\", \\\"{x:1548,y:678,t:1527272257403};\\\", \\\"{x:1548,y:679,t:1527272257718};\\\", \\\"{x:1548,y:680,t:1527272257725};\\\", \\\"{x:1547,y:682,t:1527272257736};\\\", \\\"{x:1547,y:686,t:1527272257754};\\\", \\\"{x:1545,y:689,t:1527272257770};\\\", \\\"{x:1545,y:690,t:1527272257786};\\\", \\\"{x:1544,y:691,t:1527272257803};\\\", \\\"{x:1544,y:692,t:1527272258798};\\\", \\\"{x:1544,y:693,t:1527272258806};\\\", \\\"{x:1544,y:695,t:1527272258822};\\\", \\\"{x:1544,y:696,t:1527272258838};\\\", \\\"{x:1544,y:698,t:1527272258853};\\\", \\\"{x:1544,y:699,t:1527272258877};\\\", \\\"{x:1544,y:701,t:1527272258901};\\\", \\\"{x:1544,y:702,t:1527272258957};\\\", \\\"{x:1544,y:704,t:1527272258998};\\\", \\\"{x:1544,y:705,t:1527272259031};\\\", \\\"{x:1544,y:707,t:1527272259062};\\\", \\\"{x:1544,y:708,t:1527272259110};\\\", \\\"{x:1544,y:709,t:1527272259126};\\\", \\\"{x:1544,y:710,t:1527272259142};\\\", \\\"{x:1544,y:711,t:1527272259174};\\\", \\\"{x:1544,y:713,t:1527272259188};\\\", \\\"{x:1544,y:715,t:1527272259205};\\\", \\\"{x:1544,y:718,t:1527272259221};\\\", \\\"{x:1544,y:728,t:1527272259238};\\\", \\\"{x:1544,y:733,t:1527272259254};\\\", \\\"{x:1544,y:737,t:1527272259270};\\\", \\\"{x:1544,y:743,t:1527272259288};\\\", \\\"{x:1544,y:746,t:1527272259305};\\\", \\\"{x:1544,y:750,t:1527272259320};\\\", \\\"{x:1544,y:753,t:1527272259337};\\\", \\\"{x:1544,y:758,t:1527272259354};\\\", \\\"{x:1544,y:765,t:1527272259371};\\\", \\\"{x:1544,y:775,t:1527272259388};\\\", \\\"{x:1545,y:785,t:1527272259404};\\\", \\\"{x:1545,y:793,t:1527272259421};\\\", \\\"{x:1547,y:800,t:1527272259437};\\\", \\\"{x:1547,y:804,t:1527272259455};\\\", \\\"{x:1549,y:813,t:1527272259471};\\\", \\\"{x:1550,y:823,t:1527272259487};\\\", \\\"{x:1550,y:830,t:1527272259505};\\\", \\\"{x:1551,y:837,t:1527272259521};\\\", \\\"{x:1553,y:843,t:1527272259538};\\\", \\\"{x:1554,y:848,t:1527272259555};\\\", \\\"{x:1554,y:850,t:1527272259571};\\\", \\\"{x:1554,y:853,t:1527272259587};\\\", \\\"{x:1554,y:855,t:1527272259607};\\\", \\\"{x:1554,y:856,t:1527272259695};\\\", \\\"{x:1553,y:856,t:1527272259880};\\\", \\\"{x:1551,y:856,t:1527272259895};\\\", \\\"{x:1550,y:856,t:1527272259904};\\\", \\\"{x:1550,y:853,t:1527272259922};\\\", \\\"{x:1550,y:852,t:1527272259937};\\\", \\\"{x:1550,y:850,t:1527272259998};\\\", \\\"{x:1551,y:849,t:1527272260078};\\\", \\\"{x:1552,y:848,t:1527272260126};\\\", \\\"{x:1552,y:847,t:1527272260599};\\\", \\\"{x:1552,y:846,t:1527272260623};\\\", \\\"{x:1552,y:844,t:1527272260638};\\\", \\\"{x:1552,y:843,t:1527272260656};\\\", \\\"{x:1552,y:842,t:1527272260672};\\\", \\\"{x:1552,y:840,t:1527272260689};\\\", \\\"{x:1551,y:840,t:1527272260707};\\\", \\\"{x:1551,y:839,t:1527272260722};\\\", \\\"{x:1550,y:839,t:1527272260775};\\\", \\\"{x:1550,y:838,t:1527272260791};\\\", \\\"{x:1549,y:838,t:1527272260806};\\\", \\\"{x:1548,y:836,t:1527272260839};\\\", \\\"{x:1547,y:835,t:1527272260967};\\\", \\\"{x:1547,y:834,t:1527272261143};\\\", \\\"{x:1547,y:833,t:1527272261309};\\\", \\\"{x:1547,y:832,t:1527272261526};\\\", \\\"{x:1547,y:831,t:1527272261589};\\\", \\\"{x:1539,y:830,t:1527272268471};\\\", \\\"{x:1500,y:830,t:1527272268478};\\\", \\\"{x:1365,y:830,t:1527272268495};\\\", \\\"{x:1214,y:819,t:1527272268512};\\\", \\\"{x:990,y:786,t:1527272268530};\\\", \\\"{x:755,y:746,t:1527272268545};\\\", \\\"{x:580,y:720,t:1527272268561};\\\", \\\"{x:506,y:700,t:1527272268579};\\\", \\\"{x:490,y:692,t:1527272268595};\\\", \\\"{x:487,y:690,t:1527272268611};\\\", \\\"{x:486,y:690,t:1527272268628};\\\", \\\"{x:484,y:690,t:1527272268646};\\\", \\\"{x:480,y:690,t:1527272268661};\\\", \\\"{x:459,y:692,t:1527272268678};\\\", \\\"{x:440,y:692,t:1527272268695};\\\", \\\"{x:424,y:690,t:1527272268711};\\\", \\\"{x:417,y:688,t:1527272268728};\\\", \\\"{x:417,y:687,t:1527272268758};\\\", \\\"{x:417,y:684,t:1527272268774};\\\", \\\"{x:417,y:683,t:1527272268782};\\\", \\\"{x:415,y:680,t:1527272268795};\\\", \\\"{x:415,y:675,t:1527272268812};\\\", \\\"{x:414,y:670,t:1527272268828};\\\", \\\"{x:411,y:663,t:1527272268847};\\\", \\\"{x:408,y:651,t:1527272268861};\\\", \\\"{x:405,y:641,t:1527272268878};\\\", \\\"{x:402,y:638,t:1527272268890};\\\", \\\"{x:398,y:631,t:1527272268906};\\\", \\\"{x:387,y:621,t:1527272268922};\\\", \\\"{x:345,y:608,t:1527272268947};\\\", \\\"{x:297,y:594,t:1527272268964};\\\", \\\"{x:225,y:585,t:1527272268979};\\\", \\\"{x:148,y:578,t:1527272268996};\\\", \\\"{x:91,y:575,t:1527272269012};\\\", \\\"{x:69,y:570,t:1527272269028};\\\", \\\"{x:63,y:569,t:1527272269046};\\\", \\\"{x:66,y:569,t:1527272269198};\\\", \\\"{x:71,y:573,t:1527272269213};\\\", \\\"{x:80,y:577,t:1527272269230};\\\", \\\"{x:93,y:578,t:1527272269246};\\\", \\\"{x:99,y:578,t:1527272269264};\\\", \\\"{x:103,y:580,t:1527272269279};\\\", \\\"{x:108,y:581,t:1527272269296};\\\", \\\"{x:115,y:581,t:1527272269313};\\\", \\\"{x:126,y:581,t:1527272269329};\\\", \\\"{x:145,y:577,t:1527272269346};\\\", \\\"{x:159,y:570,t:1527272269363};\\\", \\\"{x:167,y:564,t:1527272269379};\\\", \\\"{x:168,y:560,t:1527272269396};\\\", \\\"{x:168,y:557,t:1527272269412};\\\", \\\"{x:168,y:555,t:1527272269429};\\\", \\\"{x:168,y:554,t:1527272269453};\\\", \\\"{x:168,y:552,t:1527272269485};\\\", \\\"{x:167,y:551,t:1527272269518};\\\", \\\"{x:166,y:550,t:1527272269533};\\\", \\\"{x:165,y:549,t:1527272269546};\\\", \\\"{x:164,y:548,t:1527272269563};\\\", \\\"{x:161,y:546,t:1527272269580};\\\", \\\"{x:160,y:545,t:1527272269596};\\\", \\\"{x:160,y:544,t:1527272269613};\\\", \\\"{x:166,y:546,t:1527272270206};\\\", \\\"{x:195,y:560,t:1527272270214};\\\", \\\"{x:273,y:582,t:1527272270231};\\\", \\\"{x:365,y:611,t:1527272270248};\\\", \\\"{x:459,y:651,t:1527272270264};\\\", \\\"{x:537,y:689,t:1527272270280};\\\", \\\"{x:592,y:712,t:1527272270297};\\\", \\\"{x:633,y:730,t:1527272270313};\\\", \\\"{x:680,y:751,t:1527272270330};\\\", \\\"{x:716,y:766,t:1527272270347};\\\", \\\"{x:761,y:779,t:1527272270364};\\\", \\\"{x:807,y:794,t:1527272270380};\\\", \\\"{x:870,y:823,t:1527272270398};\\\", \\\"{x:986,y:880,t:1527272270413};\\\", \\\"{x:1069,y:914,t:1527272270430};\\\", \\\"{x:1148,y:942,t:1527272270447};\\\", \\\"{x:1195,y:958,t:1527272270464};\\\", \\\"{x:1231,y:966,t:1527272270480};\\\", \\\"{x:1255,y:973,t:1527272270497};\\\", \\\"{x:1284,y:978,t:1527272270514};\\\", \\\"{x:1306,y:982,t:1527272270530};\\\", \\\"{x:1310,y:983,t:1527272270547};\\\", \\\"{x:1311,y:983,t:1527272270621};\\\", \\\"{x:1311,y:981,t:1527272270638};\\\", \\\"{x:1310,y:980,t:1527272270648};\\\", \\\"{x:1307,y:979,t:1527272270665};\\\", \\\"{x:1303,y:976,t:1527272270680};\\\", \\\"{x:1295,y:971,t:1527272270698};\\\", \\\"{x:1291,y:965,t:1527272270715};\\\", \\\"{x:1288,y:958,t:1527272270730};\\\", \\\"{x:1284,y:950,t:1527272270748};\\\", \\\"{x:1283,y:949,t:1527272270765};\\\", \\\"{x:1283,y:948,t:1527272270782};\\\", \\\"{x:1283,y:947,t:1527272270847};\\\", \\\"{x:1283,y:946,t:1527272270911};\\\", \\\"{x:1283,y:943,t:1527272270918};\\\", \\\"{x:1285,y:939,t:1527272270931};\\\", \\\"{x:1286,y:926,t:1527272270947};\\\", \\\"{x:1286,y:910,t:1527272270965};\\\", \\\"{x:1286,y:898,t:1527272270980};\\\", \\\"{x:1286,y:883,t:1527272270998};\\\", \\\"{x:1287,y:855,t:1527272271014};\\\", \\\"{x:1290,y:834,t:1527272271032};\\\", \\\"{x:1292,y:821,t:1527272271048};\\\", \\\"{x:1292,y:815,t:1527272271065};\\\", \\\"{x:1293,y:813,t:1527272271081};\\\", \\\"{x:1293,y:812,t:1527272271223};\\\", \\\"{x:1295,y:812,t:1527272271232};\\\", \\\"{x:1295,y:811,t:1527272271248};\\\", \\\"{x:1296,y:811,t:1527272271271};\\\", \\\"{x:1294,y:814,t:1527272304169};\\\", \\\"{x:1289,y:821,t:1527272304184};\\\", \\\"{x:1281,y:834,t:1527272304200};\\\", \\\"{x:1277,y:844,t:1527272304217};\\\", \\\"{x:1269,y:863,t:1527272304234};\\\", \\\"{x:1267,y:880,t:1527272304251};\\\", \\\"{x:1267,y:888,t:1527272304268};\\\", \\\"{x:1267,y:892,t:1527272304285};\\\", \\\"{x:1267,y:893,t:1527272304304};\\\", \\\"{x:1268,y:893,t:1527272304433};\\\", \\\"{x:1269,y:894,t:1527272304449};\\\", \\\"{x:1270,y:895,t:1527272304457};\\\", \\\"{x:1272,y:897,t:1527272304468};\\\", \\\"{x:1272,y:898,t:1527272304484};\\\", \\\"{x:1273,y:898,t:1527272304553};\\\", \\\"{x:1273,y:899,t:1527272304568};\\\", \\\"{x:1275,y:904,t:1527272304584};\\\", \\\"{x:1276,y:910,t:1527272304601};\\\", \\\"{x:1276,y:911,t:1527272304618};\\\", \\\"{x:1276,y:913,t:1527272304635};\\\", \\\"{x:1276,y:914,t:1527272304657};\\\", \\\"{x:1276,y:915,t:1527272304668};\\\", \\\"{x:1276,y:916,t:1527272304686};\\\", \\\"{x:1276,y:918,t:1527272304701};\\\", \\\"{x:1276,y:919,t:1527272304718};\\\", \\\"{x:1276,y:921,t:1527272304735};\\\", \\\"{x:1276,y:923,t:1527272304751};\\\", \\\"{x:1276,y:926,t:1527272304767};\\\", \\\"{x:1276,y:928,t:1527272304784};\\\", \\\"{x:1276,y:929,t:1527272304817};\\\", \\\"{x:1276,y:930,t:1527272304824};\\\", \\\"{x:1276,y:931,t:1527272304848};\\\", \\\"{x:1276,y:932,t:1527272305265};\\\", \\\"{x:1276,y:934,t:1527272305273};\\\", \\\"{x:1276,y:935,t:1527272305289};\\\", \\\"{x:1276,y:936,t:1527272305305};\\\", \\\"{x:1276,y:937,t:1527272305318};\\\", \\\"{x:1276,y:938,t:1527272305335};\\\", \\\"{x:1276,y:939,t:1527272305351};\\\", \\\"{x:1276,y:940,t:1527272305608};\\\", \\\"{x:1276,y:941,t:1527272305657};\\\", \\\"{x:1276,y:942,t:1527272305673};\\\", \\\"{x:1276,y:943,t:1527272305688};\\\", \\\"{x:1275,y:943,t:1527272305985};\\\", \\\"{x:1275,y:944,t:1527272306777};\\\", \\\"{x:1272,y:943,t:1527272306793};\\\", \\\"{x:1272,y:941,t:1527272306802};\\\", \\\"{x:1271,y:936,t:1527272306819};\\\", \\\"{x:1271,y:930,t:1527272306836};\\\", \\\"{x:1269,y:923,t:1527272306852};\\\", \\\"{x:1266,y:915,t:1527272306869};\\\", \\\"{x:1263,y:903,t:1527272306886};\\\", \\\"{x:1260,y:890,t:1527272306902};\\\", \\\"{x:1257,y:878,t:1527272306919};\\\", \\\"{x:1253,y:868,t:1527272306936};\\\", \\\"{x:1250,y:856,t:1527272306952};\\\", \\\"{x:1248,y:840,t:1527272306968};\\\", \\\"{x:1248,y:828,t:1527272306987};\\\", \\\"{x:1248,y:809,t:1527272307002};\\\", \\\"{x:1248,y:791,t:1527272307019};\\\", \\\"{x:1248,y:765,t:1527272307037};\\\", \\\"{x:1248,y:743,t:1527272307052};\\\", \\\"{x:1245,y:725,t:1527272307069};\\\", \\\"{x:1244,y:718,t:1527272307086};\\\", \\\"{x:1242,y:713,t:1527272307103};\\\", \\\"{x:1236,y:713,t:1527272307242};\\\", \\\"{x:1221,y:713,t:1527272307253};\\\", \\\"{x:1149,y:713,t:1527272307269};\\\", \\\"{x:1019,y:713,t:1527272307287};\\\", \\\"{x:811,y:749,t:1527272307303};\\\", \\\"{x:579,y:817,t:1527272307319};\\\", \\\"{x:358,y:886,t:1527272307337};\\\", \\\"{x:173,y:948,t:1527272307352};\\\", \\\"{x:0,y:976,t:1527272307369};\\\", \\\"{x:0,y:974,t:1527272307386};\\\", \\\"{x:0,y:960,t:1527272307403};\\\", \\\"{x:0,y:947,t:1527272307419};\\\", \\\"{x:0,y:942,t:1527272307437};\\\", \\\"{x:0,y:939,t:1527272307452};\\\", \\\"{x:0,y:935,t:1527272307470};\\\", \\\"{x:1,y:925,t:1527272307487};\\\", \\\"{x:1,y:919,t:1527272307503};\\\", \\\"{x:1,y:914,t:1527272307520};\\\", \\\"{x:8,y:907,t:1527272307537};\\\", \\\"{x:38,y:893,t:1527272307553};\\\", \\\"{x:69,y:882,t:1527272307569};\\\", \\\"{x:102,y:867,t:1527272307587};\\\", \\\"{x:146,y:851,t:1527272307604};\\\", \\\"{x:214,y:826,t:1527272307620};\\\", \\\"{x:299,y:807,t:1527272307637};\\\", \\\"{x:383,y:790,t:1527272307653};\\\", \\\"{x:440,y:770,t:1527272307670};\\\", \\\"{x:469,y:759,t:1527272307686};\\\", \\\"{x:480,y:754,t:1527272307704};\\\", \\\"{x:482,y:754,t:1527272307719};\\\", \\\"{x:487,y:754,t:1527272307785};\\\", \\\"{x:497,y:754,t:1527272307797};\\\", \\\"{x:520,y:754,t:1527272307814};\\\", \\\"{x:533,y:751,t:1527272307831};\\\", \\\"{x:539,y:747,t:1527272307847};\\\" ] }, { \\\"rt\\\": 37575, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 726741, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:734,t:1527272310289};\\\", \\\"{x:539,y:711,t:1527272310301};\\\", \\\"{x:539,y:669,t:1527272310317};\\\", \\\"{x:544,y:635,t:1527272310333};\\\", \\\"{x:557,y:595,t:1527272310350};\\\", \\\"{x:570,y:569,t:1527272310367};\\\", \\\"{x:580,y:549,t:1527272310383};\\\", \\\"{x:587,y:531,t:1527272310400};\\\", \\\"{x:590,y:519,t:1527272310416};\\\", \\\"{x:590,y:517,t:1527272310433};\\\", \\\"{x:590,y:516,t:1527272310449};\\\", \\\"{x:590,y:512,t:1527272310832};\\\", \\\"{x:590,y:508,t:1527272310840};\\\", \\\"{x:590,y:505,t:1527272310849};\\\", \\\"{x:590,y:496,t:1527272310866};\\\", \\\"{x:590,y:491,t:1527272310883};\\\", \\\"{x:591,y:488,t:1527272310899};\\\", \\\"{x:592,y:485,t:1527272310916};\\\", \\\"{x:595,y:481,t:1527272310932};\\\", \\\"{x:599,y:480,t:1527272310949};\\\", \\\"{x:612,y:474,t:1527272310966};\\\", \\\"{x:622,y:471,t:1527272310983};\\\", \\\"{x:626,y:470,t:1527272310998};\\\", \\\"{x:638,y:465,t:1527272311016};\\\", \\\"{x:642,y:464,t:1527272311032};\\\", \\\"{x:643,y:464,t:1527272311049};\\\", \\\"{x:644,y:463,t:1527272311066};\\\", \\\"{x:646,y:464,t:1527272311704};\\\", \\\"{x:646,y:466,t:1527272311716};\\\", \\\"{x:647,y:468,t:1527272311732};\\\", \\\"{x:648,y:472,t:1527272311748};\\\", \\\"{x:650,y:476,t:1527272311766};\\\", \\\"{x:654,y:481,t:1527272311782};\\\", \\\"{x:661,y:491,t:1527272311799};\\\", \\\"{x:666,y:499,t:1527272311815};\\\", \\\"{x:681,y:522,t:1527272311833};\\\", \\\"{x:694,y:540,t:1527272311850};\\\", \\\"{x:706,y:554,t:1527272311867};\\\", \\\"{x:724,y:570,t:1527272311884};\\\", \\\"{x:772,y:598,t:1527272311901};\\\", \\\"{x:854,y:617,t:1527272311918};\\\", \\\"{x:957,y:647,t:1527272311934};\\\", \\\"{x:1056,y:675,t:1527272311951};\\\", \\\"{x:1145,y:698,t:1527272311967};\\\", \\\"{x:1259,y:744,t:1527272311984};\\\", \\\"{x:1307,y:779,t:1527272312000};\\\", \\\"{x:1331,y:809,t:1527272312017};\\\", \\\"{x:1346,y:834,t:1527272312034};\\\", \\\"{x:1353,y:854,t:1527272312051};\\\", \\\"{x:1356,y:864,t:1527272312067};\\\", \\\"{x:1356,y:867,t:1527272312084};\\\", \\\"{x:1356,y:876,t:1527272312101};\\\", \\\"{x:1359,y:891,t:1527272312117};\\\", \\\"{x:1360,y:895,t:1527272312135};\\\", \\\"{x:1361,y:896,t:1527272312152};\\\", \\\"{x:1360,y:900,t:1527272312177};\\\", \\\"{x:1352,y:909,t:1527272312184};\\\", \\\"{x:1320,y:946,t:1527272312201};\\\", \\\"{x:1318,y:952,t:1527272312218};\\\", \\\"{x:1328,y:963,t:1527272312235};\\\", \\\"{x:1335,y:977,t:1527272312252};\\\", \\\"{x:1337,y:986,t:1527272312269};\\\", \\\"{x:1339,y:985,t:1527272312976};\\\", \\\"{x:1343,y:982,t:1527272312986};\\\", \\\"{x:1352,y:972,t:1527272313001};\\\", \\\"{x:1357,y:966,t:1527272313018};\\\", \\\"{x:1363,y:957,t:1527272313035};\\\", \\\"{x:1368,y:951,t:1527272313051};\\\", \\\"{x:1370,y:949,t:1527272313069};\\\", \\\"{x:1375,y:944,t:1527272313085};\\\", \\\"{x:1379,y:941,t:1527272313102};\\\", \\\"{x:1383,y:940,t:1527272313118};\\\", \\\"{x:1388,y:937,t:1527272313135};\\\", \\\"{x:1399,y:932,t:1527272313152};\\\", \\\"{x:1412,y:929,t:1527272313168};\\\", \\\"{x:1422,y:927,t:1527272313185};\\\", \\\"{x:1432,y:924,t:1527272313202};\\\", \\\"{x:1439,y:922,t:1527272313218};\\\", \\\"{x:1441,y:921,t:1527272313235};\\\", \\\"{x:1442,y:920,t:1527272313252};\\\", \\\"{x:1444,y:920,t:1527272313268};\\\", \\\"{x:1449,y:919,t:1527272313286};\\\", \\\"{x:1455,y:918,t:1527272313302};\\\", \\\"{x:1457,y:917,t:1527272313318};\\\", \\\"{x:1459,y:917,t:1527272313337};\\\", \\\"{x:1460,y:919,t:1527272313472};\\\", \\\"{x:1462,y:922,t:1527272313485};\\\", \\\"{x:1464,y:927,t:1527272313503};\\\", \\\"{x:1465,y:932,t:1527272313518};\\\", \\\"{x:1466,y:934,t:1527272313535};\\\", \\\"{x:1467,y:936,t:1527272313552};\\\", \\\"{x:1468,y:938,t:1527272313569};\\\", \\\"{x:1469,y:938,t:1527272313586};\\\", \\\"{x:1469,y:939,t:1527272313608};\\\", \\\"{x:1470,y:939,t:1527272313620};\\\", \\\"{x:1472,y:940,t:1527272313636};\\\", \\\"{x:1472,y:941,t:1527272313652};\\\", \\\"{x:1473,y:943,t:1527272313669};\\\", \\\"{x:1474,y:943,t:1527272313685};\\\", \\\"{x:1474,y:944,t:1527272313702};\\\", \\\"{x:1474,y:948,t:1527272330281};\\\", \\\"{x:1448,y:955,t:1527272330300};\\\", \\\"{x:1427,y:961,t:1527272330316};\\\", \\\"{x:1413,y:962,t:1527272330333};\\\", \\\"{x:1405,y:963,t:1527272330350};\\\", \\\"{x:1402,y:964,t:1527272330367};\\\", \\\"{x:1401,y:964,t:1527272330382};\\\", \\\"{x:1401,y:965,t:1527272330399};\\\", \\\"{x:1398,y:964,t:1527272330633};\\\", \\\"{x:1389,y:958,t:1527272330649};\\\", \\\"{x:1382,y:953,t:1527272330667};\\\", \\\"{x:1378,y:950,t:1527272330683};\\\", \\\"{x:1374,y:946,t:1527272330699};\\\", \\\"{x:1370,y:941,t:1527272330716};\\\", \\\"{x:1368,y:938,t:1527272330733};\\\", \\\"{x:1366,y:933,t:1527272330748};\\\", \\\"{x:1361,y:921,t:1527272330766};\\\", \\\"{x:1353,y:902,t:1527272330783};\\\", \\\"{x:1344,y:882,t:1527272330799};\\\", \\\"{x:1327,y:852,t:1527272330816};\\\", \\\"{x:1320,y:837,t:1527272330832};\\\", \\\"{x:1313,y:820,t:1527272330849};\\\", \\\"{x:1307,y:807,t:1527272330866};\\\", \\\"{x:1302,y:792,t:1527272330883};\\\", \\\"{x:1299,y:779,t:1527272330899};\\\", \\\"{x:1294,y:770,t:1527272330916};\\\", \\\"{x:1290,y:764,t:1527272330933};\\\", \\\"{x:1289,y:762,t:1527272330950};\\\", \\\"{x:1287,y:761,t:1527272330966};\\\", \\\"{x:1286,y:760,t:1527272330984};\\\", \\\"{x:1285,y:760,t:1527272331041};\\\", \\\"{x:1283,y:764,t:1527272331050};\\\", \\\"{x:1273,y:776,t:1527272331067};\\\", \\\"{x:1268,y:786,t:1527272331083};\\\", \\\"{x:1266,y:792,t:1527272331101};\\\", \\\"{x:1262,y:800,t:1527272331116};\\\", \\\"{x:1262,y:805,t:1527272331133};\\\", \\\"{x:1260,y:809,t:1527272331150};\\\", \\\"{x:1258,y:816,t:1527272331166};\\\", \\\"{x:1254,y:825,t:1527272331183};\\\", \\\"{x:1254,y:833,t:1527272331200};\\\", \\\"{x:1254,y:835,t:1527272331215};\\\", \\\"{x:1254,y:836,t:1527272331233};\\\", \\\"{x:1254,y:837,t:1527272331250};\\\", \\\"{x:1254,y:840,t:1527272331266};\\\", \\\"{x:1254,y:845,t:1527272331283};\\\", \\\"{x:1254,y:851,t:1527272331300};\\\", \\\"{x:1254,y:855,t:1527272331316};\\\", \\\"{x:1254,y:860,t:1527272331333};\\\", \\\"{x:1254,y:865,t:1527272331349};\\\", \\\"{x:1254,y:868,t:1527272331366};\\\", \\\"{x:1254,y:872,t:1527272331383};\\\", \\\"{x:1254,y:878,t:1527272331400};\\\", \\\"{x:1254,y:880,t:1527272331417};\\\", \\\"{x:1254,y:881,t:1527272331456};\\\", \\\"{x:1255,y:883,t:1527272331467};\\\", \\\"{x:1255,y:885,t:1527272331483};\\\", \\\"{x:1256,y:890,t:1527272331500};\\\", \\\"{x:1257,y:892,t:1527272331517};\\\", \\\"{x:1258,y:895,t:1527272331533};\\\", \\\"{x:1258,y:896,t:1527272331551};\\\", \\\"{x:1259,y:897,t:1527272331569};\\\", \\\"{x:1259,y:898,t:1527272331584};\\\", \\\"{x:1259,y:902,t:1527272331601};\\\", \\\"{x:1260,y:905,t:1527272331617};\\\", \\\"{x:1261,y:907,t:1527272331634};\\\", \\\"{x:1262,y:908,t:1527272331977};\\\", \\\"{x:1262,y:909,t:1527272332032};\\\", \\\"{x:1263,y:910,t:1527272332040};\\\", \\\"{x:1262,y:910,t:1527272332361};\\\", \\\"{x:1256,y:906,t:1527272332368};\\\", \\\"{x:1234,y:889,t:1527272332384};\\\", \\\"{x:1210,y:871,t:1527272332401};\\\", \\\"{x:1184,y:854,t:1527272332417};\\\", \\\"{x:1168,y:843,t:1527272332434};\\\", \\\"{x:1158,y:838,t:1527272332451};\\\", \\\"{x:1153,y:835,t:1527272332467};\\\", \\\"{x:1152,y:834,t:1527272332617};\\\", \\\"{x:1144,y:826,t:1527272332635};\\\", \\\"{x:1116,y:810,t:1527272332652};\\\", \\\"{x:1067,y:792,t:1527272332667};\\\", \\\"{x:1011,y:784,t:1527272332684};\\\", \\\"{x:958,y:784,t:1527272332702};\\\", \\\"{x:891,y:795,t:1527272332718};\\\", \\\"{x:807,y:807,t:1527272332734};\\\", \\\"{x:760,y:814,t:1527272332751};\\\", \\\"{x:721,y:821,t:1527272332768};\\\", \\\"{x:703,y:826,t:1527272332784};\\\", \\\"{x:682,y:832,t:1527272332801};\\\", \\\"{x:661,y:836,t:1527272332818};\\\", \\\"{x:643,y:836,t:1527272332834};\\\", \\\"{x:624,y:841,t:1527272332851};\\\", \\\"{x:600,y:847,t:1527272332868};\\\", \\\"{x:576,y:851,t:1527272332884};\\\", \\\"{x:551,y:851,t:1527272332901};\\\", \\\"{x:521,y:850,t:1527272332918};\\\", \\\"{x:481,y:842,t:1527272332934};\\\", \\\"{x:432,y:826,t:1527272332951};\\\", \\\"{x:345,y:787,t:1527272332968};\\\", \\\"{x:288,y:754,t:1527272332984};\\\", \\\"{x:246,y:728,t:1527272333001};\\\", \\\"{x:221,y:708,t:1527272333018};\\\", \\\"{x:207,y:695,t:1527272333034};\\\", \\\"{x:199,y:684,t:1527272333051};\\\", \\\"{x:194,y:674,t:1527272333069};\\\", \\\"{x:192,y:666,t:1527272333085};\\\", \\\"{x:189,y:652,t:1527272333101};\\\", \\\"{x:189,y:647,t:1527272333110};\\\", \\\"{x:184,y:635,t:1527272333127};\\\", \\\"{x:182,y:624,t:1527272333143};\\\", \\\"{x:184,y:610,t:1527272333168};\\\", \\\"{x:189,y:602,t:1527272333186};\\\", \\\"{x:195,y:593,t:1527272333201};\\\", \\\"{x:200,y:586,t:1527272333218};\\\", \\\"{x:205,y:581,t:1527272333234};\\\", \\\"{x:213,y:577,t:1527272333251};\\\", \\\"{x:224,y:570,t:1527272333268};\\\", \\\"{x:240,y:564,t:1527272333286};\\\", \\\"{x:260,y:562,t:1527272333302};\\\", \\\"{x:283,y:561,t:1527272333318};\\\", \\\"{x:307,y:559,t:1527272333335};\\\", \\\"{x:339,y:559,t:1527272333351};\\\", \\\"{x:386,y:558,t:1527272333368};\\\", \\\"{x:419,y:558,t:1527272333386};\\\", \\\"{x:438,y:558,t:1527272333401};\\\", \\\"{x:454,y:561,t:1527272333418};\\\", \\\"{x:464,y:564,t:1527272333435};\\\", \\\"{x:468,y:565,t:1527272333451};\\\", \\\"{x:469,y:565,t:1527272333585};\\\", \\\"{x:469,y:567,t:1527272333601};\\\", \\\"{x:468,y:569,t:1527272333618};\\\", \\\"{x:466,y:572,t:1527272333636};\\\", \\\"{x:460,y:576,t:1527272333652};\\\", \\\"{x:449,y:582,t:1527272333669};\\\", \\\"{x:435,y:591,t:1527272333685};\\\", \\\"{x:420,y:602,t:1527272333701};\\\", \\\"{x:406,y:614,t:1527272333718};\\\", \\\"{x:396,y:623,t:1527272333735};\\\", \\\"{x:383,y:631,t:1527272333752};\\\", \\\"{x:375,y:634,t:1527272333767};\\\", \\\"{x:364,y:636,t:1527272333786};\\\", \\\"{x:348,y:640,t:1527272333801};\\\", \\\"{x:335,y:642,t:1527272333818};\\\", \\\"{x:324,y:644,t:1527272333835};\\\", \\\"{x:311,y:645,t:1527272333851};\\\", \\\"{x:303,y:645,t:1527272333868};\\\", \\\"{x:298,y:645,t:1527272333885};\\\", \\\"{x:296,y:645,t:1527272333901};\\\", \\\"{x:293,y:644,t:1527272333918};\\\", \\\"{x:287,y:639,t:1527272333935};\\\", \\\"{x:277,y:632,t:1527272333951};\\\", \\\"{x:264,y:623,t:1527272333968};\\\", \\\"{x:256,y:618,t:1527272333986};\\\", \\\"{x:247,y:615,t:1527272334002};\\\", \\\"{x:236,y:611,t:1527272334020};\\\", \\\"{x:226,y:608,t:1527272334035};\\\", \\\"{x:216,y:608,t:1527272334052};\\\", \\\"{x:209,y:608,t:1527272334069};\\\", \\\"{x:204,y:608,t:1527272334085};\\\", \\\"{x:201,y:607,t:1527272334103};\\\", \\\"{x:198,y:606,t:1527272334119};\\\", \\\"{x:196,y:605,t:1527272334135};\\\", \\\"{x:195,y:604,t:1527272334168};\\\", \\\"{x:195,y:602,t:1527272334192};\\\", \\\"{x:197,y:598,t:1527272334202};\\\", \\\"{x:215,y:589,t:1527272334219};\\\", \\\"{x:237,y:579,t:1527272334236};\\\", \\\"{x:266,y:568,t:1527272334253};\\\", \\\"{x:300,y:558,t:1527272334269};\\\", \\\"{x:336,y:548,t:1527272334285};\\\", \\\"{x:365,y:545,t:1527272334302};\\\", \\\"{x:394,y:540,t:1527272334318};\\\", \\\"{x:441,y:540,t:1527272334336};\\\", \\\"{x:464,y:540,t:1527272334352};\\\", \\\"{x:476,y:540,t:1527272334369};\\\", \\\"{x:482,y:540,t:1527272334387};\\\", \\\"{x:484,y:540,t:1527272334402};\\\", \\\"{x:485,y:539,t:1527272334431};\\\", \\\"{x:487,y:539,t:1527272334440};\\\", \\\"{x:493,y:538,t:1527272334453};\\\", \\\"{x:513,y:536,t:1527272334469};\\\", \\\"{x:535,y:534,t:1527272334486};\\\", \\\"{x:566,y:532,t:1527272334503};\\\", \\\"{x:597,y:532,t:1527272334519};\\\", \\\"{x:641,y:532,t:1527272334536};\\\", \\\"{x:665,y:530,t:1527272334554};\\\", \\\"{x:675,y:527,t:1527272334569};\\\", \\\"{x:677,y:527,t:1527272334586};\\\", \\\"{x:677,y:526,t:1527272334608};\\\", \\\"{x:676,y:526,t:1527272334656};\\\", \\\"{x:675,y:526,t:1527272334669};\\\", \\\"{x:673,y:526,t:1527272334686};\\\", \\\"{x:667,y:526,t:1527272334702};\\\", \\\"{x:658,y:526,t:1527272334719};\\\", \\\"{x:634,y:527,t:1527272334736};\\\", \\\"{x:616,y:534,t:1527272334753};\\\", \\\"{x:598,y:544,t:1527272334770};\\\", \\\"{x:582,y:551,t:1527272334786};\\\", \\\"{x:574,y:555,t:1527272334802};\\\", \\\"{x:574,y:556,t:1527272334819};\\\", \\\"{x:574,y:560,t:1527272334836};\\\", \\\"{x:596,y:568,t:1527272334852};\\\", \\\"{x:652,y:574,t:1527272334870};\\\", \\\"{x:708,y:574,t:1527272334886};\\\", \\\"{x:761,y:573,t:1527272334902};\\\", \\\"{x:802,y:565,t:1527272334920};\\\", \\\"{x:831,y:556,t:1527272334936};\\\", \\\"{x:838,y:554,t:1527272334953};\\\", \\\"{x:840,y:552,t:1527272334969};\\\", \\\"{x:840,y:550,t:1527272334986};\\\", \\\"{x:840,y:549,t:1527272335003};\\\", \\\"{x:842,y:547,t:1527272335018};\\\", \\\"{x:842,y:545,t:1527272335036};\\\", \\\"{x:843,y:542,t:1527272335053};\\\", \\\"{x:844,y:539,t:1527272335069};\\\", \\\"{x:845,y:537,t:1527272335086};\\\", \\\"{x:846,y:534,t:1527272335103};\\\", \\\"{x:846,y:533,t:1527272335120};\\\", \\\"{x:846,y:532,t:1527272335143};\\\", \\\"{x:846,y:530,t:1527272335193};\\\", \\\"{x:845,y:528,t:1527272335203};\\\", \\\"{x:842,y:524,t:1527272335220};\\\", \\\"{x:837,y:519,t:1527272335235};\\\", \\\"{x:834,y:517,t:1527272335253};\\\", \\\"{x:833,y:517,t:1527272335270};\\\", \\\"{x:834,y:517,t:1527272335928};\\\", \\\"{x:837,y:517,t:1527272335937};\\\", \\\"{x:864,y:518,t:1527272335954};\\\", \\\"{x:926,y:527,t:1527272335971};\\\", \\\"{x:995,y:535,t:1527272335987};\\\", \\\"{x:1051,y:543,t:1527272336003};\\\", \\\"{x:1110,y:553,t:1527272336020};\\\", \\\"{x:1152,y:559,t:1527272336037};\\\", \\\"{x:1205,y:567,t:1527272336053};\\\", \\\"{x:1247,y:571,t:1527272336070};\\\", \\\"{x:1279,y:576,t:1527272336087};\\\", \\\"{x:1304,y:580,t:1527272336104};\\\", \\\"{x:1326,y:583,t:1527272336120};\\\", \\\"{x:1330,y:583,t:1527272336138};\\\", \\\"{x:1331,y:583,t:1527272336154};\\\", \\\"{x:1324,y:589,t:1527272339408};\\\", \\\"{x:1297,y:602,t:1527272339422};\\\", \\\"{x:1219,y:626,t:1527272339439};\\\", \\\"{x:1119,y:652,t:1527272339455};\\\", \\\"{x:1092,y:657,t:1527272339472};\\\", \\\"{x:1079,y:658,t:1527272339489};\\\", \\\"{x:1075,y:659,t:1527272339506};\\\", \\\"{x:1074,y:659,t:1527272339536};\\\", \\\"{x:1071,y:659,t:1527272339576};\\\", \\\"{x:1066,y:659,t:1527272339589};\\\", \\\"{x:1042,y:659,t:1527272339606};\\\", \\\"{x:966,y:662,t:1527272339622};\\\", \\\"{x:836,y:662,t:1527272339639};\\\", \\\"{x:605,y:648,t:1527272339656};\\\", \\\"{x:472,y:627,t:1527272339673};\\\", \\\"{x:388,y:615,t:1527272339689};\\\", \\\"{x:353,y:602,t:1527272339707};\\\", \\\"{x:342,y:597,t:1527272339723};\\\", \\\"{x:342,y:595,t:1527272339743};\\\", \\\"{x:343,y:593,t:1527272339756};\\\", \\\"{x:348,y:588,t:1527272339773};\\\", \\\"{x:353,y:583,t:1527272339790};\\\", \\\"{x:359,y:578,t:1527272339806};\\\", \\\"{x:371,y:572,t:1527272339824};\\\", \\\"{x:401,y:561,t:1527272339840};\\\", \\\"{x:430,y:552,t:1527272339856};\\\", \\\"{x:459,y:543,t:1527272339872};\\\", \\\"{x:490,y:533,t:1527272339895};\\\", \\\"{x:511,y:528,t:1527272339910};\\\", \\\"{x:527,y:521,t:1527272339928};\\\", \\\"{x:536,y:517,t:1527272339944};\\\", \\\"{x:545,y:513,t:1527272339961};\\\", \\\"{x:549,y:511,t:1527272339977};\\\", \\\"{x:553,y:509,t:1527272339994};\\\", \\\"{x:556,y:509,t:1527272340011};\\\", \\\"{x:560,y:508,t:1527272340027};\\\", \\\"{x:571,y:508,t:1527272340044};\\\", \\\"{x:576,y:509,t:1527272340061};\\\", \\\"{x:580,y:510,t:1527272340077};\\\", \\\"{x:582,y:510,t:1527272340094};\\\", \\\"{x:583,y:510,t:1527272340173};\\\", \\\"{x:587,y:511,t:1527272340180};\\\", \\\"{x:593,y:514,t:1527272340195};\\\", \\\"{x:602,y:518,t:1527272340212};\\\", \\\"{x:613,y:520,t:1527272340228};\\\", \\\"{x:615,y:520,t:1527272340245};\\\", \\\"{x:621,y:525,t:1527272341796};\\\", \\\"{x:709,y:586,t:1527272341813};\\\", \\\"{x:834,y:650,t:1527272341830};\\\", \\\"{x:960,y:697,t:1527272341846};\\\", \\\"{x:1057,y:725,t:1527272341862};\\\", \\\"{x:1134,y:747,t:1527272341880};\\\", \\\"{x:1205,y:775,t:1527272341895};\\\", \\\"{x:1264,y:800,t:1527272341913};\\\", \\\"{x:1300,y:819,t:1527272341930};\\\", \\\"{x:1316,y:826,t:1527272341946};\\\", \\\"{x:1320,y:828,t:1527272341963};\\\", \\\"{x:1320,y:830,t:1527272342612};\\\", \\\"{x:1320,y:849,t:1527272342630};\\\", \\\"{x:1319,y:853,t:1527272342646};\\\", \\\"{x:1311,y:851,t:1527272345725};\\\", \\\"{x:1287,y:834,t:1527272345732};\\\", \\\"{x:1185,y:772,t:1527272345749};\\\", \\\"{x:1060,y:712,t:1527272345766};\\\", \\\"{x:904,y:652,t:1527272345783};\\\", \\\"{x:742,y:594,t:1527272345799};\\\", \\\"{x:581,y:538,t:1527272345816};\\\", \\\"{x:414,y:500,t:1527272345833};\\\", \\\"{x:260,y:482,t:1527272345848};\\\", \\\"{x:132,y:483,t:1527272345866};\\\", \\\"{x:60,y:490,t:1527272345882};\\\", \\\"{x:39,y:497,t:1527272345900};\\\", \\\"{x:37,y:498,t:1527272345916};\\\", \\\"{x:46,y:503,t:1527272346084};\\\", \\\"{x:152,y:547,t:1527272346100};\\\", \\\"{x:269,y:589,t:1527272346116};\\\", \\\"{x:317,y:631,t:1527272346133};\\\", \\\"{x:334,y:647,t:1527272346150};\\\", \\\"{x:345,y:666,t:1527272346166};\\\", \\\"{x:355,y:681,t:1527272346182};\\\", \\\"{x:361,y:689,t:1527272346200};\\\", \\\"{x:362,y:690,t:1527272346216};\\\", \\\"{x:363,y:692,t:1527272346232};\\\", \\\"{x:364,y:693,t:1527272346324};\\\", \\\"{x:368,y:696,t:1527272346333};\\\", \\\"{x:382,y:701,t:1527272346350};\\\", \\\"{x:398,y:708,t:1527272346367};\\\", \\\"{x:424,y:718,t:1527272346383};\\\", \\\"{x:486,y:738,t:1527272346401};\\\", \\\"{x:554,y:761,t:1527272346417};\\\", \\\"{x:603,y:764,t:1527272346433};\\\", \\\"{x:626,y:764,t:1527272346449};\\\", \\\"{x:631,y:763,t:1527272346467};\\\", \\\"{x:632,y:762,t:1527272346483};\\\", \\\"{x:632,y:760,t:1527272346500};\\\", \\\"{x:632,y:758,t:1527272346596};\\\", \\\"{x:626,y:754,t:1527272346605};\\\", \\\"{x:615,y:750,t:1527272346617};\\\", \\\"{x:580,y:735,t:1527272346633};\\\", \\\"{x:550,y:724,t:1527272346650};\\\", \\\"{x:534,y:724,t:1527272346667};\\\", \\\"{x:525,y:724,t:1527272346682};\\\", \\\"{x:516,y:728,t:1527272346700};\\\", \\\"{x:515,y:729,t:1527272346718};\\\", \\\"{x:514,y:730,t:1527272346733};\\\", \\\"{x:513,y:731,t:1527272346750};\\\", \\\"{x:513,y:734,t:1527272346768};\\\", \\\"{x:513,y:735,t:1527272346796};\\\", \\\"{x:513,y:737,t:1527272346803};\\\", \\\"{x:513,y:741,t:1527272346815};\\\", \\\"{x:513,y:750,t:1527272346833};\\\", \\\"{x:512,y:758,t:1527272346849};\\\", \\\"{x:511,y:761,t:1527272346866};\\\", \\\"{x:510,y:763,t:1527272346883};\\\", \\\"{x:513,y:758,t:1527272347531};\\\", \\\"{x:516,y:752,t:1527272347540};\\\", \\\"{x:519,y:743,t:1527272347550};\\\", \\\"{x:527,y:723,t:1527272347566};\\\", \\\"{x:534,y:691,t:1527272347583};\\\", \\\"{x:539,y:623,t:1527272347601};\\\", \\\"{x:538,y:570,t:1527272347617};\\\", \\\"{x:538,y:552,t:1527272347633};\\\", \\\"{x:540,y:537,t:1527272347651};\\\", \\\"{x:551,y:523,t:1527272347667};\\\", \\\"{x:560,y:510,t:1527272347684};\\\", \\\"{x:563,y:507,t:1527272347701};\\\", \\\"{x:565,y:506,t:1527272347717};\\\", \\\"{x:565,y:505,t:1527272347733};\\\", \\\"{x:572,y:499,t:1527272347751};\\\", \\\"{x:582,y:490,t:1527272347766};\\\", \\\"{x:596,y:481,t:1527272347784};\\\", \\\"{x:616,y:471,t:1527272347800};\\\", \\\"{x:635,y:466,t:1527272347817};\\\", \\\"{x:659,y:464,t:1527272347833};\\\", \\\"{x:683,y:461,t:1527272347851};\\\", \\\"{x:697,y:459,t:1527272347866};\\\", \\\"{x:709,y:459,t:1527272347884};\\\", \\\"{x:712,y:460,t:1527272347901};\\\", \\\"{x:715,y:460,t:1527272347918};\\\", \\\"{x:720,y:460,t:1527272347934};\\\", \\\"{x:723,y:461,t:1527272347950};\\\", \\\"{x:724,y:462,t:1527272347967};\\\", \\\"{x:724,y:463,t:1527272348068};\\\", \\\"{x:726,y:464,t:1527272348084};\\\", \\\"{x:726,y:465,t:1527272348108};\\\", \\\"{x:726,y:466,t:1527272348124};\\\", \\\"{x:726,y:468,t:1527272348159};\\\", \\\"{x:726,y:469,t:1527272348167};\\\", \\\"{x:726,y:470,t:1527272348184};\\\", \\\"{x:726,y:472,t:1527272348201};\\\", \\\"{x:724,y:477,t:1527272348217};\\\", \\\"{x:720,y:484,t:1527272348234};\\\" ] }, { \\\"rt\\\": 55070, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 783022, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"you go to 12 pm on the x-axis and then go directly vertical from that position. Whatever points fall on that line start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6339, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 790364, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 16685, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Engineering\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 808061, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14755, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 824148, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"TPGMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"TPGMW\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 148, dom: 775, initialDom: 822",
  "javascriptErrors": []
}