var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f7ad0a78447d94a042fff90e1ba2a540",
  "created": "2018-05-29T10:13:32.7056892-07:00",
  "lastActivity": "2018-05-29T10:16:51.7088477-07:00",
  "pageViews": [
    {
      "id": "052932854a83d97fa69ec4894ea36aab9e238dde",
      "startTime": "2018-05-29T10:13:32.7056892-07:00",
      "endTime": "2018-05-29T10:16:51.7088477-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 199306,
      "engagementTime": 146102,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 199306,
  "engagementTime": 146102,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=8GUB2",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b5ad0c17bac1f76f69409e07992c8d6c",
  "gdpr": false
}