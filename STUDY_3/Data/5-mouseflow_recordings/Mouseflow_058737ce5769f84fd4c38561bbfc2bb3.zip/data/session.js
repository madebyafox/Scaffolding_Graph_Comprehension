var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "058737ce5769f84fd4c38561bbfc2bb3",
  "created": "2018-05-29T10:12:26.9686163-07:00",
  "lastActivity": "2018-05-29T10:12:36.4286163-07:00",
  "pageViews": [
    {
      "id": "0529274327b2f3303ca5bbad84f34ec50ebfee36",
      "startTime": "2018-05-29T10:12:26.9686163-07:00",
      "endTime": "2018-05-29T10:12:36.4286163-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 9460,
      "engagementTime": 9460,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9460,
  "engagementTime": 9460,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FUXZY",
    "CONDITION=114",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e39c674887b269fbf5ede472259480d0",
  "gdpr": false
}