var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ae5afc2abd5bd78d595d083270484235",
  "created": "2018-05-25T11:12:16.2980548-07:00",
  "lastActivity": "2018-05-25T11:12:26.1743757-07:00",
  "pageViews": [
    {
      "id": "05251651c2dddba5a2e916e3e28e8e4e5e9eef0b",
      "startTime": "2018-05-25T11:12:16.3434548-07:00",
      "endTime": "2018-05-25T11:12:26.1743757-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10007,
      "engagementTime": 10004,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10007,
  "engagementTime": 10004,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=53R9B",
    "CONDITION=114",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ed2cbef089b1cc07f9a7593188f37b84",
  "gdpr": false
}