var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052559148b5370843d8aa1db876879356a93393b"] = {
  "startTime": "2018-05-25T18:17:59.4692713Z",
  "websitePageUrl": "/16",
  "visitTime": 75749,
  "engagementTime": 64962,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "05fbe017a6f6aa21f64369a8ea0b684a",
    "created": "2018-05-25T18:17:59.4692713+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=FK2HU",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "98077e13a4014de4b29642b53e2d2ed0",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/05fbe017a6f6aa21f64369a8ea0b684a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 196,
      "e": 196,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 496,
      "y": 753
    },
    {
      "t": 782,
      "e": 782,
      "ty": 41,
      "x": 44841,
      "y": 41270,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 802,
      "e": 802,
      "ty": 2,
      "x": 496,
      "y": 744
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 505,
      "y": 683
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 502,
      "y": 618
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 45515,
      "y": 63841,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1034,
      "e": 1034,
      "ty": 6,
      "x": 499,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 495,
      "y": 578
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 494,
      "y": 568
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 44616,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 497,
      "y": 564
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 503,
      "y": 560
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 45627,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9721,
      "e": 7502,
      "ty": 3,
      "x": 503,
      "y": 560,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9722,
      "e": 7503,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9855,
      "e": 7636,
      "ty": 4,
      "x": 45627,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9855,
      "e": 7636,
      "ty": 5,
      "x": 503,
      "y": 560,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 7782,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 23373,
      "e": 12636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 23547,
      "e": 12810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 23556,
      "e": 12819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23556,
      "e": 12819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23651,
      "e": 12914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 23675,
      "e": 12938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 23843,
      "e": 13106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 23851,
      "e": 13114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23853,
      "e": 13116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23923,
      "e": 13186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 24195,
      "e": 13458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24196,
      "e": 13459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24323,
      "e": 13586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 24684,
      "e": 13947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24684,
      "e": 13947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24794,
      "e": 14057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 25695,
      "e": 14958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 25696,
      "e": 14959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25774,
      "e": 15037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 25894,
      "e": 15157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25895,
      "e": 15158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25958,
      "e": 15221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26279,
      "e": 15542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26279,
      "e": 15542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26406,
      "e": 15669,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x a"
    },
    {
      "t": 26407,
      "e": 15670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26663,
      "e": 15926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26664,
      "e": 15927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26727,
      "e": 15990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 26943,
      "e": 16206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26944,
      "e": 16207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26998,
      "e": 16261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27159,
      "e": 16422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27159,
      "e": 16422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27246,
      "e": 16509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27678,
      "e": 16941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27679,
      "e": 16942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27797,
      "e": 17060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28200,
      "e": 17463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28201,
      "e": 17464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28333,
      "e": 17596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28358,
      "e": 17621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28359,
      "e": 17622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28494,
      "e": 17757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28503,
      "e": 17766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28503,
      "e": 17766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28566,
      "e": 17829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 28605,
      "e": 17868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28606,
      "e": 17869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28718,
      "e": 17981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28783,
      "e": 18046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28783,
      "e": 18046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28846,
      "e": 18109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29038,
      "e": 18301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29039,
      "e": 18302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29093,
      "e": 18356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29206,
      "e": 18469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says t"
    },
    {
      "t": 29367,
      "e": 18630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29367,
      "e": 18630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29431,
      "e": 18694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29494,
      "e": 18757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29496,
      "e": 18759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29597,
      "e": 18860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29662,
      "e": 18925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29663,
      "e": 18926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29718,
      "e": 18981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30003,
      "e": 19266,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30053,
      "e": 19316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30053,
      "e": 19316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30110,
      "e": 19373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32615,
      "e": 21878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32615,
      "e": 21878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32710,
      "e": 21973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32807,
      "e": 22070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32807,
      "e": 22070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32853,
      "e": 22116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33006,
      "e": 22269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that sh"
    },
    {
      "t": 33014,
      "e": 22277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33015,
      "e": 22278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33069,
      "e": 22332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33206,
      "e": 22469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that shi"
    },
    {
      "t": 33326,
      "e": 22589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33327,
      "e": 22590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33381,
      "e": 22644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 33486,
      "e": 22749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33486,
      "e": 22749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33550,
      "e": 22813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34078,
      "e": 23341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34078,
      "e": 23341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34174,
      "e": 23437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34230,
      "e": 23493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34231,
      "e": 23494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34309,
      "e": 23572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34950,
      "e": 24213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34950,
      "e": 24213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35054,
      "e": 24317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 35118,
      "e": 24381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35119,
      "e": 24382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35174,
      "e": 24437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 35302,
      "e": 24565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35303,
      "e": 24566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35381,
      "e": 24644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 35526,
      "e": 24789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35527,
      "e": 24790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35582,
      "e": 24845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36350,
      "e": 25613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 36351,
      "e": 25614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36405,
      "e": 25668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 36550,
      "e": 25813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36550,
      "e": 25813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36598,
      "e": 25861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36671,
      "e": 25934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36671,
      "e": 25934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36775,
      "e": 26038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36807,
      "e": 26070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36808,
      "e": 26071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36869,
      "e": 26132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37006,
      "e": 26269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that shifts for b an"
    },
    {
      "t": 37230,
      "e": 26493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37231,
      "e": 26494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37334,
      "e": 26597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 37446,
      "e": 26709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37446,
      "e": 26709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37518,
      "e": 26781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37710,
      "e": 26973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37711,
      "e": 26974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37749,
      "e": 27012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 38214,
      "e": 27477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38215,
      "e": 27478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38270,
      "e": 27533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38406,
      "e": 27669,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that shifts for b and f "
    },
    {
      "t": 38462,
      "e": 27725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38462,
      "e": 27725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38557,
      "e": 27820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 38598,
      "e": 27861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38598,
      "e": 27861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38654,
      "e": 27917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38694,
      "e": 27957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38694,
      "e": 27957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38806,
      "e": 28069,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that shifts for b and f sta"
    },
    {
      "t": 38814,
      "e": 28077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38822,
      "e": 28085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38822,
      "e": 28085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38877,
      "e": 28140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 39006,
      "e": 28269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that shifts for b and f star"
    },
    {
      "t": 39933,
      "e": 29196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39933,
      "e": 29196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40004,
      "e": 29267,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40021,
      "e": 29284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40502,
      "e": 29765,
      "ty": 7,
      "x": 440,
      "y": 628,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40504,
      "e": 29767,
      "ty": 2,
      "x": 440,
      "y": 628
    },
    {
      "t": 40504,
      "e": 29767,
      "ty": 41,
      "x": 56831,
      "y": 4106,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 40519,
      "e": 29782,
      "ty": 6,
      "x": 397,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 40537,
      "e": 29800,
      "ty": 7,
      "x": 357,
      "y": 719,
      "ta": "#strategyButton"
    },
    {
      "t": 40603,
      "e": 29866,
      "ty": 2,
      "x": 323,
      "y": 783
    },
    {
      "t": 40704,
      "e": 29967,
      "ty": 2,
      "x": 319,
      "y": 791
    },
    {
      "t": 40754,
      "e": 30017,
      "ty": 41,
      "x": 24832,
      "y": 43376,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 40804,
      "e": 30067,
      "ty": 2,
      "x": 343,
      "y": 755
    },
    {
      "t": 40904,
      "e": 30167,
      "ty": 2,
      "x": 379,
      "y": 698
    },
    {
      "t": 40938,
      "e": 30201,
      "ty": 6,
      "x": 384,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 41004,
      "e": 30267,
      "ty": 2,
      "x": 390,
      "y": 671
    },
    {
      "t": 41004,
      "e": 30267,
      "ty": 41,
      "x": 28074,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 41104,
      "e": 30367,
      "ty": 2,
      "x": 392,
      "y": 665
    },
    {
      "t": 41171,
      "e": 30434,
      "ty": 3,
      "x": 392,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 41172,
      "e": 30435,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The x axis says that shifts for b and f start"
    },
    {
      "t": 41173,
      "e": 30436,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41174,
      "e": 30437,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 41254,
      "e": 30517,
      "ty": 41,
      "x": 29166,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 41282,
      "e": 30545,
      "ty": 4,
      "x": 29166,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 41293,
      "e": 30556,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 41295,
      "e": 30558,
      "ty": 5,
      "x": 392,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 41299,
      "e": 30562,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 42004,
      "e": 31267,
      "ty": 2,
      "x": 460,
      "y": 656
    },
    {
      "t": 42004,
      "e": 31267,
      "ty": 41,
      "x": 15565,
      "y": 35897,
      "ta": "html > body"
    },
    {
      "t": 42104,
      "e": 31367,
      "ty": 2,
      "x": 1009,
      "y": 648
    },
    {
      "t": 42204,
      "e": 31467,
      "ty": 2,
      "x": 1011,
      "y": 646
    },
    {
      "t": 42254,
      "e": 31517,
      "ty": 41,
      "x": 34541,
      "y": 35343,
      "ta": "html > body"
    },
    {
      "t": 42302,
      "e": 31565,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 43004,
      "e": 32267,
      "ty": 2,
      "x": 1011,
      "y": 637
    },
    {
      "t": 43004,
      "e": 32267,
      "ty": 41,
      "x": 43906,
      "y": 38052,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43055,
      "e": 32318,
      "ty": 6,
      "x": 988,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43071,
      "e": 32334,
      "ty": 7,
      "x": 984,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43104,
      "e": 32367,
      "ty": 2,
      "x": 984,
      "y": 544
    },
    {
      "t": 43204,
      "e": 32467,
      "ty": 2,
      "x": 979,
      "y": 523
    },
    {
      "t": 43254,
      "e": 32517,
      "ty": 41,
      "x": 36985,
      "y": 35108,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 43304,
      "e": 32567,
      "ty": 2,
      "x": 978,
      "y": 535
    },
    {
      "t": 43322,
      "e": 32585,
      "ty": 6,
      "x": 974,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43354,
      "e": 32617,
      "ty": 7,
      "x": 970,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43404,
      "e": 32667,
      "ty": 2,
      "x": 970,
      "y": 580
    },
    {
      "t": 43504,
      "e": 32767,
      "ty": 41,
      "x": 35038,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 43754,
      "e": 33017,
      "ty": 41,
      "x": 34822,
      "y": 62716,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 43804,
      "e": 33067,
      "ty": 2,
      "x": 969,
      "y": 577
    },
    {
      "t": 43995,
      "e": 33258,
      "ty": 6,
      "x": 969,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44004,
      "e": 33267,
      "ty": 2,
      "x": 969,
      "y": 574
    },
    {
      "t": 44005,
      "e": 33268,
      "ty": 41,
      "x": 34822,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44104,
      "e": 33367,
      "ty": 2,
      "x": 969,
      "y": 569
    },
    {
      "t": 44195,
      "e": 33458,
      "ty": 3,
      "x": 969,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44196,
      "e": 33459,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44254,
      "e": 33517,
      "ty": 41,
      "x": 34822,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44313,
      "e": 33576,
      "ty": 4,
      "x": 34822,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44313,
      "e": 33576,
      "ty": 5,
      "x": 969,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45150,
      "e": 34413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 45150,
      "e": 34413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45237,
      "e": 34500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 45253,
      "e": 34516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 45253,
      "e": 34516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45309,
      "e": 34572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 45904,
      "e": 35167,
      "ty": 2,
      "x": 965,
      "y": 569
    },
    {
      "t": 45924,
      "e": 35187,
      "ty": 7,
      "x": 937,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46004,
      "e": 35267,
      "ty": 2,
      "x": 920,
      "y": 617
    },
    {
      "t": 46005,
      "e": 35268,
      "ty": 41,
      "x": 24224,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 46058,
      "e": 35321,
      "ty": 6,
      "x": 912,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46090,
      "e": 35353,
      "ty": 7,
      "x": 911,
      "y": 674,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46104,
      "e": 35367,
      "ty": 2,
      "x": 911,
      "y": 674
    },
    {
      "t": 46108,
      "e": 35371,
      "ty": 6,
      "x": 909,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46204,
      "e": 35467,
      "ty": 2,
      "x": 908,
      "y": 693
    },
    {
      "t": 46255,
      "e": 35518,
      "ty": 41,
      "x": 6224,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46403,
      "e": 35666,
      "ty": 2,
      "x": 908,
      "y": 685
    },
    {
      "t": 46425,
      "e": 35688,
      "ty": 7,
      "x": 909,
      "y": 670,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46504,
      "e": 35767,
      "ty": 2,
      "x": 910,
      "y": 670
    },
    {
      "t": 46504,
      "e": 35767,
      "ty": 41,
      "x": 22061,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 46658,
      "e": 35921,
      "ty": 6,
      "x": 910,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46704,
      "e": 35967,
      "ty": 2,
      "x": 910,
      "y": 654
    },
    {
      "t": 46754,
      "e": 36017,
      "ty": 41,
      "x": 22277,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46804,
      "e": 36067,
      "ty": 2,
      "x": 911,
      "y": 650
    },
    {
      "t": 46850,
      "e": 36113,
      "ty": 3,
      "x": 911,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46851,
      "e": 36114,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 46852,
      "e": 36115,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46853,
      "e": 36116,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46954,
      "e": 36217,
      "ty": 4,
      "x": 22277,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46954,
      "e": 36217,
      "ty": 5,
      "x": 911,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48414,
      "e": 37677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 48582,
      "e": 37845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 48615,
      "e": 37878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 48615,
      "e": 37878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48709,
      "e": 37972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "M"
    },
    {
      "t": 48806,
      "e": 38069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 48974,
      "e": 38237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "M"
    },
    {
      "t": 49486,
      "e": 38749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 49487,
      "e": 38750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49565,
      "e": 38828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Me"
    },
    {
      "t": 49782,
      "e": 39045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "88"
    },
    {
      "t": 49783,
      "e": 39046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49861,
      "e": 39124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mex"
    },
    {
      "t": 49973,
      "e": 39236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 49974,
      "e": 39237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50004,
      "e": 39267,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50038,
      "e": 39301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mexi"
    },
    {
      "t": 50158,
      "e": 39421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 50159,
      "e": 39422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50222,
      "e": 39485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 50302,
      "e": 39565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 50303,
      "e": 39566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50358,
      "e": 39621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 51178,
      "e": 40441,
      "ty": 7,
      "x": 911,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51195,
      "e": 40458,
      "ty": 6,
      "x": 911,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51205,
      "e": 40468,
      "ty": 2,
      "x": 911,
      "y": 680
    },
    {
      "t": 51254,
      "e": 40517,
      "ty": 41,
      "x": 8801,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51305,
      "e": 40568,
      "ty": 2,
      "x": 913,
      "y": 697
    },
    {
      "t": 51404,
      "e": 40667,
      "ty": 2,
      "x": 917,
      "y": 708
    },
    {
      "t": 51504,
      "e": 40767,
      "ty": 41,
      "x": 10863,
      "y": 63549,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51514,
      "e": 40777,
      "ty": 3,
      "x": 917,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51516,
      "e": 40779,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mexico"
    },
    {
      "t": 51517,
      "e": 40780,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51517,
      "e": 40780,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51650,
      "e": 40913,
      "ty": 4,
      "x": 10863,
      "y": 63549,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51651,
      "e": 40914,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51651,
      "e": 40914,
      "ty": 5,
      "x": 917,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51651,
      "e": 40914,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 52669,
      "e": 41932,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 53605,
      "e": 42868,
      "ty": 2,
      "x": 941,
      "y": 645
    },
    {
      "t": 53703,
      "e": 42966,
      "ty": 2,
      "x": 1058,
      "y": 175
    },
    {
      "t": 53754,
      "e": 43017,
      "ty": 41,
      "x": 36228,
      "y": 1828,
      "ta": "html > body"
    },
    {
      "t": 53803,
      "e": 43066,
      "ty": 2,
      "x": 1056,
      "y": 13
    },
    {
      "t": 53903,
      "e": 43166,
      "ty": 2,
      "x": 1029,
      "y": 52
    },
    {
      "t": 54003,
      "e": 43266,
      "ty": 2,
      "x": 979,
      "y": 179
    },
    {
      "t": 54003,
      "e": 43266,
      "ty": 41,
      "x": 37397,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 54104,
      "e": 43367,
      "ty": 2,
      "x": 950,
      "y": 207
    },
    {
      "t": 54203,
      "e": 43466,
      "ty": 2,
      "x": 908,
      "y": 236
    },
    {
      "t": 54253,
      "e": 43516,
      "ty": 41,
      "x": 19835,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 54304,
      "e": 43567,
      "ty": 2,
      "x": 893,
      "y": 249
    },
    {
      "t": 54403,
      "e": 43666,
      "ty": 2,
      "x": 867,
      "y": 256
    },
    {
      "t": 54503,
      "e": 43766,
      "ty": 2,
      "x": 864,
      "y": 259
    },
    {
      "t": 54503,
      "e": 43766,
      "ty": 41,
      "x": 32428,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 54604,
      "e": 43867,
      "ty": 2,
      "x": 864,
      "y": 260
    },
    {
      "t": 54754,
      "e": 44017,
      "ty": 41,
      "x": 32428,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 54803,
      "e": 44066,
      "ty": 2,
      "x": 864,
      "y": 255
    },
    {
      "t": 54903,
      "e": 44166,
      "ty": 2,
      "x": 865,
      "y": 244
    },
    {
      "t": 55003,
      "e": 44266,
      "ty": 41,
      "x": 35684,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55404,
      "e": 44667,
      "ty": 2,
      "x": 865,
      "y": 235
    },
    {
      "t": 55503,
      "e": 44766,
      "ty": 2,
      "x": 865,
      "y": 234
    },
    {
      "t": 55503,
      "e": 44766,
      "ty": 41,
      "x": 35684,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55603,
      "e": 44866,
      "ty": 2,
      "x": 866,
      "y": 233
    },
    {
      "t": 55754,
      "e": 45017,
      "ty": 41,
      "x": 36503,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55883,
      "e": 45146,
      "ty": 3,
      "x": 866,
      "y": 233,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56018,
      "e": 45281,
      "ty": 4,
      "x": 36503,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56018,
      "e": 45281,
      "ty": 5,
      "x": 866,
      "y": 233,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56020,
      "e": 45283,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56021,
      "e": 45284,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 56203,
      "e": 45466,
      "ty": 2,
      "x": 865,
      "y": 231
    },
    {
      "t": 56254,
      "e": 45517,
      "ty": 41,
      "x": 26677,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56304,
      "e": 45567,
      "ty": 2,
      "x": 848,
      "y": 242
    },
    {
      "t": 56404,
      "e": 45667,
      "ty": 2,
      "x": 866,
      "y": 305
    },
    {
      "t": 56503,
      "e": 45766,
      "ty": 2,
      "x": 859,
      "y": 442
    },
    {
      "t": 56504,
      "e": 45767,
      "ty": 41,
      "x": 30015,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 56604,
      "e": 45867,
      "ty": 2,
      "x": 854,
      "y": 456
    },
    {
      "t": 56703,
      "e": 45966,
      "ty": 2,
      "x": 853,
      "y": 434
    },
    {
      "t": 56754,
      "e": 46017,
      "ty": 41,
      "x": 7494,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 56804,
      "e": 46067,
      "ty": 2,
      "x": 858,
      "y": 379
    },
    {
      "t": 56904,
      "e": 46167,
      "ty": 2,
      "x": 870,
      "y": 367
    },
    {
      "t": 57003,
      "e": 46266,
      "ty": 41,
      "x": 11528,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 57254,
      "e": 46517,
      "ty": 41,
      "x": 14614,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 57303,
      "e": 46566,
      "ty": 2,
      "x": 910,
      "y": 367
    },
    {
      "t": 57404,
      "e": 46667,
      "ty": 2,
      "x": 940,
      "y": 367
    },
    {
      "t": 57504,
      "e": 46767,
      "ty": 41,
      "x": 28141,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 57754,
      "e": 47017,
      "ty": 41,
      "x": 26954,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 57804,
      "e": 47067,
      "ty": 2,
      "x": 927,
      "y": 387
    },
    {
      "t": 57903,
      "e": 47166,
      "ty": 2,
      "x": 902,
      "y": 452
    },
    {
      "t": 58004,
      "e": 47267,
      "ty": 2,
      "x": 895,
      "y": 475
    },
    {
      "t": 58004,
      "e": 47267,
      "ty": 41,
      "x": 17461,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 58103,
      "e": 47366,
      "ty": 2,
      "x": 890,
      "y": 472
    },
    {
      "t": 58204,
      "e": 47467,
      "ty": 2,
      "x": 883,
      "y": 451
    },
    {
      "t": 58254,
      "e": 47517,
      "ty": 41,
      "x": 49185,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58304,
      "e": 47567,
      "ty": 2,
      "x": 883,
      "y": 448
    },
    {
      "t": 58403,
      "e": 47666,
      "ty": 2,
      "x": 883,
      "y": 441
    },
    {
      "t": 58490,
      "e": 47753,
      "ty": 3,
      "x": 883,
      "y": 441,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58491,
      "e": 47754,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 58503,
      "e": 47766,
      "ty": 41,
      "x": 49185,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58601,
      "e": 47864,
      "ty": 4,
      "x": 49185,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58601,
      "e": 47864,
      "ty": 5,
      "x": 883,
      "y": 441,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58601,
      "e": 47864,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58602,
      "e": 47865,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 58804,
      "e": 48067,
      "ty": 2,
      "x": 882,
      "y": 447
    },
    {
      "t": 58904,
      "e": 48167,
      "ty": 2,
      "x": 851,
      "y": 601
    },
    {
      "t": 58934,
      "e": 48197,
      "ty": 6,
      "x": 831,
      "y": 668,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 58951,
      "e": 48214,
      "ty": 7,
      "x": 822,
      "y": 688,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 59004,
      "e": 48267,
      "ty": 2,
      "x": 818,
      "y": 701
    },
    {
      "t": 59004,
      "e": 48267,
      "ty": 41,
      "x": 27894,
      "y": 38390,
      "ta": "html > body"
    },
    {
      "t": 59169,
      "e": 48432,
      "ty": 6,
      "x": 839,
      "y": 675,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 59185,
      "e": 48448,
      "ty": 7,
      "x": 848,
      "y": 667,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 59203,
      "e": 48466,
      "ty": 2,
      "x": 853,
      "y": 663
    },
    {
      "t": 59253,
      "e": 48516,
      "ty": 41,
      "x": 8918,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 59303,
      "e": 48566,
      "ty": 2,
      "x": 859,
      "y": 658
    },
    {
      "t": 59404,
      "e": 48667,
      "ty": 2,
      "x": 860,
      "y": 671
    },
    {
      "t": 59503,
      "e": 48766,
      "ty": 2,
      "x": 861,
      "y": 686
    },
    {
      "t": 59503,
      "e": 48766,
      "ty": 41,
      "x": 9392,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 59604,
      "e": 48867,
      "ty": 2,
      "x": 865,
      "y": 696
    },
    {
      "t": 59704,
      "e": 48967,
      "ty": 2,
      "x": 869,
      "y": 696
    },
    {
      "t": 59754,
      "e": 49017,
      "ty": 41,
      "x": 12240,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 59804,
      "e": 49067,
      "ty": 2,
      "x": 876,
      "y": 684
    },
    {
      "t": 59904,
      "e": 49167,
      "ty": 2,
      "x": 882,
      "y": 674
    },
    {
      "t": 60003,
      "e": 49266,
      "ty": 2,
      "x": 884,
      "y": 671
    },
    {
      "t": 60004,
      "e": 49267,
      "ty": 41,
      "x": 16802,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 60604,
      "e": 49867,
      "ty": 2,
      "x": 886,
      "y": 679
    },
    {
      "t": 60703,
      "e": 49966,
      "ty": 2,
      "x": 891,
      "y": 693
    },
    {
      "t": 60754,
      "e": 50017,
      "ty": 41,
      "x": 17532,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60803,
      "e": 50066,
      "ty": 2,
      "x": 891,
      "y": 695
    },
    {
      "t": 60903,
      "e": 50166,
      "ty": 2,
      "x": 892,
      "y": 696
    },
    {
      "t": 61004,
      "e": 50267,
      "ty": 41,
      "x": 17784,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61203,
      "e": 50466,
      "ty": 2,
      "x": 892,
      "y": 706
    },
    {
      "t": 61253,
      "e": 50516,
      "ty": 41,
      "x": 16749,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 61303,
      "e": 50566,
      "ty": 2,
      "x": 892,
      "y": 717
    },
    {
      "t": 61503,
      "e": 50766,
      "ty": 2,
      "x": 892,
      "y": 711
    },
    {
      "t": 61503,
      "e": 50766,
      "ty": 41,
      "x": 17784,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61604,
      "e": 50867,
      "ty": 2,
      "x": 892,
      "y": 705
    },
    {
      "t": 61704,
      "e": 50967,
      "ty": 2,
      "x": 892,
      "y": 701
    },
    {
      "t": 61753,
      "e": 51016,
      "ty": 41,
      "x": 17784,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62899,
      "e": 52162,
      "ty": 3,
      "x": 892,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62899,
      "e": 52162,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 63042,
      "e": 52305,
      "ty": 4,
      "x": 17784,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63042,
      "e": 52305,
      "ty": 5,
      "x": 892,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63042,
      "e": 52305,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63043,
      "e": 52306,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 63504,
      "e": 52767,
      "ty": 2,
      "x": 892,
      "y": 711
    },
    {
      "t": 63504,
      "e": 52767,
      "ty": 41,
      "x": 17784,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63604,
      "e": 52867,
      "ty": 2,
      "x": 896,
      "y": 767
    },
    {
      "t": 63704,
      "e": 52967,
      "ty": 2,
      "x": 896,
      "y": 781
    },
    {
      "t": 63756,
      "e": 52969,
      "ty": 41,
      "x": 41751,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 63804,
      "e": 53017,
      "ty": 2,
      "x": 896,
      "y": 782
    },
    {
      "t": 63904,
      "e": 53117,
      "ty": 2,
      "x": 896,
      "y": 799
    },
    {
      "t": 64004,
      "e": 53217,
      "ty": 2,
      "x": 895,
      "y": 814
    },
    {
      "t": 64004,
      "e": 53217,
      "ty": 41,
      "x": 43428,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 64104,
      "e": 53317,
      "ty": 2,
      "x": 894,
      "y": 819
    },
    {
      "t": 64204,
      "e": 53417,
      "ty": 2,
      "x": 903,
      "y": 870
    },
    {
      "t": 64254,
      "e": 53467,
      "ty": 41,
      "x": 21021,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 64303,
      "e": 53516,
      "ty": 2,
      "x": 913,
      "y": 894
    },
    {
      "t": 64404,
      "e": 53617,
      "ty": 2,
      "x": 918,
      "y": 907
    },
    {
      "t": 64504,
      "e": 53717,
      "ty": 2,
      "x": 918,
      "y": 922
    },
    {
      "t": 64504,
      "e": 53717,
      "ty": 41,
      "x": 22920,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 64603,
      "e": 53816,
      "ty": 2,
      "x": 914,
      "y": 951
    },
    {
      "t": 64704,
      "e": 53917,
      "ty": 2,
      "x": 902,
      "y": 973
    },
    {
      "t": 64754,
      "e": 53967,
      "ty": 41,
      "x": 16037,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 64804,
      "e": 54017,
      "ty": 2,
      "x": 885,
      "y": 977
    },
    {
      "t": 64904,
      "e": 54117,
      "ty": 2,
      "x": 884,
      "y": 977
    },
    {
      "t": 65004,
      "e": 54217,
      "ty": 2,
      "x": 879,
      "y": 969
    },
    {
      "t": 65004,
      "e": 54217,
      "ty": 41,
      "x": 46575,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65104,
      "e": 54317,
      "ty": 2,
      "x": 878,
      "y": 963
    },
    {
      "t": 65204,
      "e": 54417,
      "ty": 2,
      "x": 878,
      "y": 962
    },
    {
      "t": 65219,
      "e": 54432,
      "ty": 3,
      "x": 878,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65220,
      "e": 54433,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65254,
      "e": 54467,
      "ty": 41,
      "x": 45767,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65304,
      "e": 54517,
      "ty": 2,
      "x": 878,
      "y": 960
    },
    {
      "t": 65337,
      "e": 54550,
      "ty": 4,
      "x": 45767,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65337,
      "e": 54550,
      "ty": 5,
      "x": 878,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65338,
      "e": 54551,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65339,
      "e": 54552,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 65504,
      "e": 54717,
      "ty": 2,
      "x": 878,
      "y": 970
    },
    {
      "t": 65504,
      "e": 54717,
      "ty": 41,
      "x": 45767,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65604,
      "e": 54817,
      "ty": 2,
      "x": 884,
      "y": 1001
    },
    {
      "t": 65624,
      "e": 54837,
      "ty": 6,
      "x": 884,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65704,
      "e": 54917,
      "ty": 2,
      "x": 885,
      "y": 1006
    },
    {
      "t": 65754,
      "e": 54967,
      "ty": 41,
      "x": 28644,
      "y": 1985,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65804,
      "e": 55017,
      "ty": 2,
      "x": 886,
      "y": 1008
    },
    {
      "t": 65903,
      "e": 55116,
      "ty": 2,
      "x": 886,
      "y": 1015
    },
    {
      "t": 66004,
      "e": 55217,
      "ty": 41,
      "x": 29159,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66304,
      "e": 55517,
      "ty": 2,
      "x": 886,
      "y": 1016
    },
    {
      "t": 66348,
      "e": 55561,
      "ty": 3,
      "x": 886,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66348,
      "e": 55561,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 66349,
      "e": 55562,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66449,
      "e": 55662,
      "ty": 4,
      "x": 29159,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66449,
      "e": 55662,
      "ty": 5,
      "x": 886,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66452,
      "e": 55665,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66452,
      "e": 55665,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66454,
      "e": 55667,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 66504,
      "e": 55717,
      "ty": 41,
      "x": 30236,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 66704,
      "e": 55917,
      "ty": 2,
      "x": 887,
      "y": 1016
    },
    {
      "t": 66754,
      "e": 55967,
      "ty": 41,
      "x": 30339,
      "y": 55674,
      "ta": "html > body"
    },
    {
      "t": 66804,
      "e": 56017,
      "ty": 2,
      "x": 897,
      "y": 1003
    },
    {
      "t": 66904,
      "e": 56117,
      "ty": 2,
      "x": 1092,
      "y": 929
    },
    {
      "t": 67004,
      "e": 56217,
      "ty": 2,
      "x": 1172,
      "y": 885
    },
    {
      "t": 67004,
      "e": 56217,
      "ty": 41,
      "x": 40085,
      "y": 48583,
      "ta": "html > body"
    },
    {
      "t": 67798,
      "e": 57011,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 69204,
      "e": 58417,
      "ty": 2,
      "x": 1102,
      "y": 986
    },
    {
      "t": 69255,
      "e": 58468,
      "ty": 41,
      "x": 36973,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69304,
      "e": 58517,
      "ty": 2,
      "x": 1032,
      "y": 1066
    },
    {
      "t": 69378,
      "e": 58591,
      "ty": 6,
      "x": 992,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 69404,
      "e": 58617,
      "ty": 2,
      "x": 979,
      "y": 1072
    },
    {
      "t": 69504,
      "e": 58717,
      "ty": 2,
      "x": 972,
      "y": 1074
    },
    {
      "t": 69504,
      "e": 58717,
      "ty": 41,
      "x": 34132,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 69604,
      "e": 58817,
      "ty": 2,
      "x": 971,
      "y": 1085
    },
    {
      "t": 69704,
      "e": 58917,
      "ty": 2,
      "x": 971,
      "y": 1089
    },
    {
      "t": 69755,
      "e": 58968,
      "ty": 41,
      "x": 33586,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 70004,
      "e": 59217,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 73035,
      "e": 62248,
      "ty": 3,
      "x": 971,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 73036,
      "e": 62249,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 73169,
      "e": 62382,
      "ty": 4,
      "x": 33586,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 73169,
      "e": 62382,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 73170,
      "e": 62383,
      "ty": 5,
      "x": 971,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 73170,
      "e": 62383,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 73705,
      "e": 62918,
      "ty": 2,
      "x": 971,
      "y": 1088
    },
    {
      "t": 73755,
      "e": 62968,
      "ty": 41,
      "x": 33163,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 73804,
      "e": 63017,
      "ty": 2,
      "x": 971,
      "y": 1087
    },
    {
      "t": 74212,
      "e": 63425,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 75749,
      "e": 64962,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 118515, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 118522, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 20331, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 140180, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17193, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 158383, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 35274, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 194743, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 16458, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 212203, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 35791, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 249366, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-A -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:957,y:746,t:1527271801735};\\\", \\\"{x:995,y:717,t:1527271801752};\\\", \\\"{x:1045,y:683,t:1527271801767};\\\", \\\"{x:1093,y:639,t:1527271801784};\\\", \\\"{x:1140,y:589,t:1527271801802};\\\", \\\"{x:1186,y:534,t:1527271801819};\\\", \\\"{x:1226,y:480,t:1527271801834};\\\", \\\"{x:1258,y:428,t:1527271801851};\\\", \\\"{x:1287,y:372,t:1527271801868};\\\", \\\"{x:1313,y:314,t:1527271801885};\\\", \\\"{x:1343,y:238,t:1527271801901};\\\", \\\"{x:1359,y:183,t:1527271801918};\\\", \\\"{x:1372,y:136,t:1527271801935};\\\", \\\"{x:1380,y:100,t:1527271801951};\\\", \\\"{x:1388,y:65,t:1527271801969};\\\", \\\"{x:1392,y:29,t:1527271801984};\\\", \\\"{x:1392,y:1,t:1527271802002};\\\", \\\"{x:1392,y:0,t:1527271802018};\\\", \\\"{x:1390,y:0,t:1527271802034};\\\", \\\"{x:1387,y:0,t:1527271802051};\\\", \\\"{x:1386,y:0,t:1527271802077};\\\", \\\"{x:1384,y:0,t:1527271802101};\\\", \\\"{x:1376,y:6,t:1527271802118};\\\", \\\"{x:1369,y:19,t:1527271802135};\\\", \\\"{x:1360,y:40,t:1527271802151};\\\", \\\"{x:1354,y:67,t:1527271802169};\\\", \\\"{x:1348,y:98,t:1527271802185};\\\", \\\"{x:1345,y:131,t:1527271802202};\\\", \\\"{x:1340,y:164,t:1527271802219};\\\", \\\"{x:1335,y:191,t:1527271802235};\\\", \\\"{x:1333,y:215,t:1527271802252};\\\", \\\"{x:1329,y:239,t:1527271802269};\\\", \\\"{x:1324,y:254,t:1527271802285};\\\", \\\"{x:1319,y:275,t:1527271802302};\\\", \\\"{x:1315,y:284,t:1527271802319};\\\", \\\"{x:1311,y:292,t:1527271802336};\\\", \\\"{x:1307,y:298,t:1527271802352};\\\", \\\"{x:1303,y:303,t:1527271802369};\\\", \\\"{x:1301,y:305,t:1527271802385};\\\", \\\"{x:1299,y:307,t:1527271802402};\\\", \\\"{x:1297,y:309,t:1527271802419};\\\", \\\"{x:1296,y:310,t:1527271802436};\\\", \\\"{x:1293,y:312,t:1527271802453};\\\", \\\"{x:1292,y:313,t:1527271802469};\\\", \\\"{x:1289,y:316,t:1527271802486};\\\", \\\"{x:1287,y:319,t:1527271802502};\\\", \\\"{x:1284,y:322,t:1527271802519};\\\", \\\"{x:1280,y:325,t:1527271802536};\\\", \\\"{x:1278,y:329,t:1527271802552};\\\", \\\"{x:1275,y:332,t:1527271802569};\\\", \\\"{x:1271,y:336,t:1527271802586};\\\", \\\"{x:1270,y:338,t:1527271802602};\\\", \\\"{x:1269,y:340,t:1527271802619};\\\", \\\"{x:1267,y:342,t:1527271802637};\\\", \\\"{x:1266,y:343,t:1527271802652};\\\", \\\"{x:1264,y:344,t:1527271802669};\\\", \\\"{x:1262,y:346,t:1527271802686};\\\", \\\"{x:1259,y:349,t:1527271802702};\\\", \\\"{x:1255,y:351,t:1527271802718};\\\", \\\"{x:1254,y:352,t:1527271802736};\\\", \\\"{x:1252,y:354,t:1527271802752};\\\", \\\"{x:1248,y:356,t:1527271802768};\\\", \\\"{x:1246,y:358,t:1527271802785};\\\", \\\"{x:1245,y:359,t:1527271802803};\\\", \\\"{x:1244,y:359,t:1527271802818};\\\", \\\"{x:1243,y:361,t:1527271802835};\\\", \\\"{x:1242,y:361,t:1527271802935};\\\", \\\"{x:1241,y:361,t:1527271802950};\\\", \\\"{x:1238,y:360,t:1527271802959};\\\", \\\"{x:1233,y:356,t:1527271802969};\\\", \\\"{x:1220,y:346,t:1527271802986};\\\", \\\"{x:1209,y:333,t:1527271803003};\\\", \\\"{x:1197,y:318,t:1527271803019};\\\", \\\"{x:1182,y:300,t:1527271803036};\\\", \\\"{x:1169,y:284,t:1527271803052};\\\", \\\"{x:1156,y:270,t:1527271803069};\\\", \\\"{x:1134,y:248,t:1527271803086};\\\", \\\"{x:1126,y:241,t:1527271803103};\\\", \\\"{x:1116,y:233,t:1527271803120};\\\", \\\"{x:1112,y:230,t:1527271803136};\\\", \\\"{x:1111,y:230,t:1527271803153};\\\", \\\"{x:1111,y:229,t:1527271803169};\\\", \\\"{x:1110,y:229,t:1527271803246};\\\", \\\"{x:1109,y:229,t:1527271803262};\\\", \\\"{x:1108,y:229,t:1527271803278};\\\", \\\"{x:1107,y:229,t:1527271803287};\\\", \\\"{x:1105,y:229,t:1527271803303};\\\", \\\"{x:1103,y:230,t:1527271803319};\\\", \\\"{x:1100,y:231,t:1527271803336};\\\", \\\"{x:1097,y:232,t:1527271803352};\\\", \\\"{x:1097,y:233,t:1527271803370};\\\", \\\"{x:1096,y:233,t:1527271803386};\\\", \\\"{x:1095,y:235,t:1527271803421};\\\", \\\"{x:1095,y:236,t:1527271803526};\\\", \\\"{x:1096,y:236,t:1527271803536};\\\", \\\"{x:1099,y:237,t:1527271803553};\\\", \\\"{x:1100,y:238,t:1527271803570};\\\", \\\"{x:1103,y:238,t:1527271803586};\\\", \\\"{x:1110,y:238,t:1527271803603};\\\", \\\"{x:1121,y:238,t:1527271803619};\\\", \\\"{x:1133,y:238,t:1527271803636};\\\", \\\"{x:1150,y:238,t:1527271803653};\\\", \\\"{x:1170,y:236,t:1527271803669};\\\", \\\"{x:1184,y:233,t:1527271803687};\\\", \\\"{x:1195,y:233,t:1527271803703};\\\", \\\"{x:1206,y:230,t:1527271803720};\\\", \\\"{x:1216,y:230,t:1527271803736};\\\", \\\"{x:1229,y:228,t:1527271803753};\\\", \\\"{x:1242,y:228,t:1527271803769};\\\", \\\"{x:1255,y:225,t:1527271803787};\\\", \\\"{x:1266,y:224,t:1527271803804};\\\", \\\"{x:1282,y:223,t:1527271803820};\\\", \\\"{x:1298,y:223,t:1527271803837};\\\", \\\"{x:1313,y:221,t:1527271803854};\\\", \\\"{x:1330,y:221,t:1527271803870};\\\", \\\"{x:1343,y:221,t:1527271803886};\\\", \\\"{x:1355,y:221,t:1527271803903};\\\", \\\"{x:1368,y:221,t:1527271803920};\\\", \\\"{x:1379,y:221,t:1527271803937};\\\", \\\"{x:1395,y:221,t:1527271803953};\\\", \\\"{x:1407,y:221,t:1527271803970};\\\", \\\"{x:1417,y:221,t:1527271803987};\\\", \\\"{x:1429,y:221,t:1527271804003};\\\", \\\"{x:1442,y:221,t:1527271804021};\\\", \\\"{x:1455,y:221,t:1527271804037};\\\", \\\"{x:1465,y:221,t:1527271804053};\\\", \\\"{x:1478,y:221,t:1527271804070};\\\", \\\"{x:1480,y:221,t:1527271804087};\\\", \\\"{x:1481,y:221,t:1527271804103};\\\", \\\"{x:1482,y:221,t:1527271804120};\\\", \\\"{x:1483,y:221,t:1527271804137};\\\", \\\"{x:1484,y:221,t:1527271804154};\\\", \\\"{x:1487,y:221,t:1527271804170};\\\", \\\"{x:1488,y:221,t:1527271804187};\\\", \\\"{x:1491,y:221,t:1527271804203};\\\", \\\"{x:1494,y:222,t:1527271804221};\\\", \\\"{x:1497,y:223,t:1527271804237};\\\", \\\"{x:1498,y:223,t:1527271804253};\\\", \\\"{x:1500,y:224,t:1527271804342};\\\", \\\"{x:1501,y:224,t:1527271804391};\\\", \\\"{x:1503,y:224,t:1527271804414};\\\", \\\"{x:1504,y:225,t:1527271804422};\\\", \\\"{x:1505,y:225,t:1527271804437};\\\", \\\"{x:1508,y:225,t:1527271804454};\\\", \\\"{x:1512,y:227,t:1527271804470};\\\", \\\"{x:1513,y:227,t:1527271804487};\\\", \\\"{x:1514,y:227,t:1527271804574};\\\", \\\"{x:1515,y:227,t:1527271804590};\\\", \\\"{x:1516,y:227,t:1527271804604};\\\", \\\"{x:1517,y:227,t:1527271804620};\\\", \\\"{x:1518,y:227,t:1527271804637};\\\", \\\"{x:1519,y:227,t:1527271804654};\\\", \\\"{x:1520,y:227,t:1527271805870};\\\", \\\"{x:1520,y:228,t:1527271807087};\\\", \\\"{x:1520,y:230,t:1527271807094};\\\", \\\"{x:1520,y:233,t:1527271807106};\\\", \\\"{x:1520,y:237,t:1527271807121};\\\", \\\"{x:1519,y:241,t:1527271807138};\\\", \\\"{x:1519,y:245,t:1527271807156};\\\", \\\"{x:1518,y:250,t:1527271807171};\\\", \\\"{x:1518,y:253,t:1527271807189};\\\", \\\"{x:1516,y:261,t:1527271807205};\\\", \\\"{x:1514,y:266,t:1527271807227};\\\", \\\"{x:1514,y:270,t:1527271807239};\\\", \\\"{x:1514,y:274,t:1527271807256};\\\", \\\"{x:1514,y:278,t:1527271807272};\\\", \\\"{x:1512,y:282,t:1527271807289};\\\", \\\"{x:1511,y:286,t:1527271807306};\\\", \\\"{x:1511,y:288,t:1527271807322};\\\", \\\"{x:1510,y:289,t:1527271807339};\\\", \\\"{x:1509,y:292,t:1527271807355};\\\", \\\"{x:1509,y:293,t:1527271807372};\\\", \\\"{x:1509,y:296,t:1527271807389};\\\", \\\"{x:1508,y:299,t:1527271807406};\\\", \\\"{x:1508,y:300,t:1527271807422};\\\", \\\"{x:1508,y:303,t:1527271807439};\\\", \\\"{x:1507,y:305,t:1527271807456};\\\", \\\"{x:1507,y:308,t:1527271807472};\\\", \\\"{x:1507,y:310,t:1527271807489};\\\", \\\"{x:1506,y:312,t:1527271807506};\\\", \\\"{x:1506,y:314,t:1527271807522};\\\", \\\"{x:1505,y:315,t:1527271807539};\\\", \\\"{x:1505,y:316,t:1527271807556};\\\", \\\"{x:1505,y:318,t:1527271807573};\\\", \\\"{x:1505,y:320,t:1527271807589};\\\", \\\"{x:1504,y:322,t:1527271807605};\\\", \\\"{x:1504,y:326,t:1527271807623};\\\", \\\"{x:1502,y:331,t:1527271807639};\\\", \\\"{x:1501,y:336,t:1527271807656};\\\", \\\"{x:1499,y:346,t:1527271807673};\\\", \\\"{x:1496,y:361,t:1527271807688};\\\", \\\"{x:1492,y:388,t:1527271807706};\\\", \\\"{x:1488,y:430,t:1527271807723};\\\", \\\"{x:1479,y:505,t:1527271807739};\\\", \\\"{x:1465,y:599,t:1527271807756};\\\", \\\"{x:1449,y:719,t:1527271807773};\\\", \\\"{x:1413,y:846,t:1527271807790};\\\", \\\"{x:1348,y:1040,t:1527271807806};\\\", \\\"{x:1302,y:1156,t:1527271807823};\\\", \\\"{x:1265,y:1199,t:1527271807839};\\\", \\\"{x:1241,y:1199,t:1527271807856};\\\", \\\"{x:1228,y:1199,t:1527271807873};\\\", \\\"{x:1221,y:1199,t:1527271807890};\\\", \\\"{x:1216,y:1199,t:1527271807907};\\\", \\\"{x:1213,y:1199,t:1527271807922};\\\", \\\"{x:1210,y:1199,t:1527271807940};\\\", \\\"{x:1208,y:1199,t:1527271807956};\\\", \\\"{x:1205,y:1199,t:1527271807972};\\\", \\\"{x:1203,y:1199,t:1527271807989};\\\", \\\"{x:1202,y:1199,t:1527271808029};\\\", \\\"{x:1201,y:1198,t:1527271808061};\\\", \\\"{x:1201,y:1192,t:1527271808073};\\\", \\\"{x:1201,y:1176,t:1527271808090};\\\", \\\"{x:1201,y:1155,t:1527271808106};\\\", \\\"{x:1201,y:1132,t:1527271808124};\\\", \\\"{x:1201,y:1112,t:1527271808140};\\\", \\\"{x:1201,y:1093,t:1527271808157};\\\", \\\"{x:1201,y:1068,t:1527271808173};\\\", \\\"{x:1201,y:1058,t:1527271808190};\\\", \\\"{x:1201,y:1052,t:1527271808207};\\\", \\\"{x:1201,y:1049,t:1527271808224};\\\", \\\"{x:1201,y:1046,t:1527271808241};\\\", \\\"{x:1201,y:1044,t:1527271808256};\\\", \\\"{x:1201,y:1042,t:1527271808274};\\\", \\\"{x:1201,y:1038,t:1527271808291};\\\", \\\"{x:1205,y:1033,t:1527271808307};\\\", \\\"{x:1213,y:1021,t:1527271808324};\\\", \\\"{x:1222,y:1009,t:1527271808340};\\\", \\\"{x:1233,y:996,t:1527271808357};\\\", \\\"{x:1247,y:977,t:1527271808373};\\\", \\\"{x:1254,y:967,t:1527271808390};\\\", \\\"{x:1260,y:959,t:1527271808407};\\\", \\\"{x:1263,y:953,t:1527271808423};\\\", \\\"{x:1264,y:950,t:1527271808440};\\\", \\\"{x:1265,y:947,t:1527271808457};\\\", \\\"{x:1266,y:946,t:1527271808473};\\\", \\\"{x:1266,y:945,t:1527271808491};\\\", \\\"{x:1266,y:943,t:1527271808507};\\\", \\\"{x:1267,y:941,t:1527271808526};\\\", \\\"{x:1268,y:940,t:1527271808550};\\\", \\\"{x:1269,y:939,t:1527271808630};\\\", \\\"{x:1269,y:938,t:1527271808686};\\\", \\\"{x:1270,y:938,t:1527271808726};\\\", \\\"{x:1271,y:938,t:1527271808741};\\\", \\\"{x:1273,y:939,t:1527271808758};\\\", \\\"{x:1275,y:942,t:1527271808774};\\\", \\\"{x:1276,y:945,t:1527271808791};\\\", \\\"{x:1277,y:948,t:1527271808808};\\\", \\\"{x:1280,y:950,t:1527271808824};\\\", \\\"{x:1281,y:952,t:1527271808841};\\\", \\\"{x:1283,y:951,t:1527271809015};\\\", \\\"{x:1284,y:948,t:1527271809024};\\\", \\\"{x:1288,y:942,t:1527271809041};\\\", \\\"{x:1291,y:932,t:1527271809059};\\\", \\\"{x:1296,y:922,t:1527271809074};\\\", \\\"{x:1301,y:910,t:1527271809091};\\\", \\\"{x:1306,y:895,t:1527271809109};\\\", \\\"{x:1311,y:882,t:1527271809125};\\\", \\\"{x:1318,y:867,t:1527271809141};\\\", \\\"{x:1328,y:844,t:1527271809158};\\\", \\\"{x:1335,y:827,t:1527271809175};\\\", \\\"{x:1340,y:810,t:1527271809191};\\\", \\\"{x:1346,y:793,t:1527271809209};\\\", \\\"{x:1351,y:777,t:1527271809225};\\\", \\\"{x:1355,y:765,t:1527271809242};\\\", \\\"{x:1357,y:757,t:1527271809258};\\\", \\\"{x:1358,y:753,t:1527271809275};\\\", \\\"{x:1359,y:749,t:1527271809291};\\\", \\\"{x:1359,y:748,t:1527271809326};\\\", \\\"{x:1360,y:748,t:1527271809470};\\\", \\\"{x:1361,y:748,t:1527271809478};\\\", \\\"{x:1362,y:748,t:1527271809494};\\\", \\\"{x:1364,y:748,t:1527271809508};\\\", \\\"{x:1364,y:749,t:1527271809526};\\\", \\\"{x:1365,y:749,t:1527271809541};\\\", \\\"{x:1366,y:750,t:1527271809558};\\\", \\\"{x:1368,y:751,t:1527271809576};\\\", \\\"{x:1370,y:753,t:1527271809606};\\\", \\\"{x:1371,y:754,t:1527271809647};\\\", \\\"{x:1372,y:755,t:1527271809659};\\\", \\\"{x:1373,y:755,t:1527271809676};\\\", \\\"{x:1373,y:756,t:1527271809702};\\\", \\\"{x:1373,y:757,t:1527271809846};\\\", \\\"{x:1374,y:757,t:1527271810046};\\\", \\\"{x:1374,y:758,t:1527271810062};\\\", \\\"{x:1374,y:760,t:1527271813447};\\\", \\\"{x:1374,y:761,t:1527271813462};\\\", \\\"{x:1374,y:762,t:1527271813486};\\\", \\\"{x:1374,y:763,t:1527271813502};\\\", \\\"{x:1373,y:763,t:1527271813550};\\\", \\\"{x:1373,y:766,t:1527271821190};\\\", \\\"{x:1371,y:771,t:1527271821201};\\\", \\\"{x:1368,y:780,t:1527271821218};\\\", \\\"{x:1363,y:789,t:1527271821235};\\\", \\\"{x:1358,y:801,t:1527271821250};\\\", \\\"{x:1354,y:810,t:1527271821268};\\\", \\\"{x:1348,y:824,t:1527271821285};\\\", \\\"{x:1343,y:836,t:1527271821301};\\\", \\\"{x:1337,y:850,t:1527271821318};\\\", \\\"{x:1334,y:857,t:1527271821334};\\\", \\\"{x:1331,y:862,t:1527271821350};\\\", \\\"{x:1331,y:864,t:1527271821502};\\\", \\\"{x:1331,y:866,t:1527271821518};\\\", \\\"{x:1331,y:871,t:1527271821535};\\\", \\\"{x:1331,y:877,t:1527271821551};\\\", \\\"{x:1331,y:888,t:1527271821568};\\\", \\\"{x:1331,y:899,t:1527271821585};\\\", \\\"{x:1331,y:914,t:1527271821602};\\\", \\\"{x:1331,y:929,t:1527271821618};\\\", \\\"{x:1331,y:943,t:1527271821635};\\\", \\\"{x:1331,y:954,t:1527271821652};\\\", \\\"{x:1331,y:961,t:1527271821668};\\\", \\\"{x:1331,y:966,t:1527271821685};\\\", \\\"{x:1331,y:972,t:1527271821702};\\\", \\\"{x:1330,y:972,t:1527271821718};\\\", \\\"{x:1330,y:973,t:1527271821735};\\\", \\\"{x:1330,y:974,t:1527271821758};\\\", \\\"{x:1330,y:975,t:1527271821773};\\\", \\\"{x:1329,y:975,t:1527271821785};\\\", \\\"{x:1328,y:977,t:1527271821802};\\\", \\\"{x:1327,y:978,t:1527271821819};\\\", \\\"{x:1326,y:979,t:1527271821834};\\\", \\\"{x:1325,y:980,t:1527271821852};\\\", \\\"{x:1324,y:980,t:1527271822343};\\\", \\\"{x:1321,y:978,t:1527271822352};\\\", \\\"{x:1318,y:973,t:1527271822369};\\\", \\\"{x:1315,y:968,t:1527271822385};\\\", \\\"{x:1313,y:962,t:1527271822402};\\\", \\\"{x:1312,y:955,t:1527271822419};\\\", \\\"{x:1311,y:946,t:1527271822437};\\\", \\\"{x:1308,y:936,t:1527271822452};\\\", \\\"{x:1307,y:922,t:1527271822469};\\\", \\\"{x:1302,y:899,t:1527271822486};\\\", \\\"{x:1297,y:881,t:1527271822502};\\\", \\\"{x:1293,y:869,t:1527271822519};\\\", \\\"{x:1291,y:862,t:1527271822536};\\\", \\\"{x:1289,y:856,t:1527271822552};\\\", \\\"{x:1287,y:851,t:1527271822569};\\\", \\\"{x:1285,y:846,t:1527271822586};\\\", \\\"{x:1282,y:840,t:1527271822602};\\\", \\\"{x:1276,y:830,t:1527271822622};\\\", \\\"{x:1268,y:817,t:1527271822635};\\\", \\\"{x:1256,y:805,t:1527271822652};\\\", \\\"{x:1242,y:788,t:1527271822668};\\\", \\\"{x:1217,y:759,t:1527271822685};\\\", \\\"{x:1198,y:737,t:1527271822701};\\\", \\\"{x:1162,y:708,t:1527271822718};\\\", \\\"{x:1104,y:669,t:1527271822735};\\\", \\\"{x:1030,y:626,t:1527271822751};\\\", \\\"{x:949,y:583,t:1527271822769};\\\", \\\"{x:880,y:554,t:1527271822786};\\\", \\\"{x:820,y:534,t:1527271822801};\\\", \\\"{x:765,y:518,t:1527271822817};\\\", \\\"{x:689,y:507,t:1527271822835};\\\", \\\"{x:598,y:497,t:1527271822851};\\\", \\\"{x:520,y:496,t:1527271822868};\\\", \\\"{x:442,y:496,t:1527271822884};\\\", \\\"{x:407,y:496,t:1527271822902};\\\", \\\"{x:377,y:496,t:1527271822918};\\\", \\\"{x:360,y:498,t:1527271822935};\\\", \\\"{x:351,y:500,t:1527271822952};\\\", \\\"{x:349,y:502,t:1527271822968};\\\", \\\"{x:349,y:503,t:1527271822985};\\\", \\\"{x:348,y:504,t:1527271823002};\\\", \\\"{x:348,y:505,t:1527271823018};\\\", \\\"{x:347,y:506,t:1527271823036};\\\", \\\"{x:347,y:507,t:1527271823052};\\\", \\\"{x:347,y:508,t:1527271823068};\\\", \\\"{x:348,y:511,t:1527271823085};\\\", \\\"{x:349,y:512,t:1527271823102};\\\", \\\"{x:350,y:512,t:1527271823118};\\\", \\\"{x:352,y:513,t:1527271823134};\\\", \\\"{x:356,y:514,t:1527271823152};\\\", \\\"{x:356,y:515,t:1527271823169};\\\", \\\"{x:359,y:516,t:1527271823185};\\\", \\\"{x:364,y:518,t:1527271823202};\\\", \\\"{x:366,y:519,t:1527271823219};\\\", \\\"{x:371,y:520,t:1527271823235};\\\", \\\"{x:377,y:522,t:1527271823253};\\\", \\\"{x:384,y:523,t:1527271823269};\\\", \\\"{x:395,y:527,t:1527271823285};\\\", \\\"{x:402,y:528,t:1527271823302};\\\", \\\"{x:406,y:530,t:1527271823320};\\\", \\\"{x:409,y:531,t:1527271823335};\\\", \\\"{x:410,y:531,t:1527271823366};\\\", \\\"{x:410,y:532,t:1527271823815};\\\", \\\"{x:410,y:534,t:1527271823822};\\\", \\\"{x:409,y:536,t:1527271823837};\\\", \\\"{x:409,y:538,t:1527271823853};\\\", \\\"{x:406,y:545,t:1527271823870};\\\", \\\"{x:403,y:548,t:1527271823886};\\\", \\\"{x:401,y:551,t:1527271823905};\\\", \\\"{x:400,y:552,t:1527271823923};\\\", \\\"{x:399,y:553,t:1527271823939};\\\", \\\"{x:397,y:554,t:1527271823956};\\\", \\\"{x:396,y:555,t:1527271823972};\\\", \\\"{x:394,y:556,t:1527271823989};\\\", \\\"{x:392,y:558,t:1527271824005};\\\", \\\"{x:390,y:559,t:1527271824032};\\\", \\\"{x:389,y:559,t:1527271824048};\\\", \\\"{x:387,y:560,t:1527271824064};\\\", \\\"{x:386,y:560,t:1527271824080};\\\", \\\"{x:392,y:563,t:1527271830465};\\\", \\\"{x:402,y:567,t:1527271830478};\\\", \\\"{x:432,y:569,t:1527271830496};\\\", \\\"{x:468,y:575,t:1527271830511};\\\", \\\"{x:530,y:582,t:1527271830528};\\\", \\\"{x:603,y:594,t:1527271830545};\\\", \\\"{x:686,y:605,t:1527271830560};\\\", \\\"{x:783,y:619,t:1527271830578};\\\", \\\"{x:892,y:635,t:1527271830595};\\\", \\\"{x:991,y:649,t:1527271830612};\\\", \\\"{x:1094,y:665,t:1527271830628};\\\", \\\"{x:1192,y:678,t:1527271830645};\\\", \\\"{x:1269,y:687,t:1527271830661};\\\", \\\"{x:1321,y:700,t:1527271830678};\\\", \\\"{x:1363,y:706,t:1527271830695};\\\", \\\"{x:1394,y:711,t:1527271830711};\\\", \\\"{x:1407,y:714,t:1527271830727};\\\", \\\"{x:1413,y:717,t:1527271830745};\\\", \\\"{x:1417,y:719,t:1527271830761};\\\", \\\"{x:1420,y:722,t:1527271830778};\\\", \\\"{x:1422,y:723,t:1527271830794};\\\", \\\"{x:1423,y:724,t:1527271830816};\\\", \\\"{x:1425,y:725,t:1527271830827};\\\", \\\"{x:1426,y:729,t:1527271830845};\\\", \\\"{x:1430,y:734,t:1527271830862};\\\", \\\"{x:1430,y:739,t:1527271830878};\\\", \\\"{x:1430,y:746,t:1527271830895};\\\", \\\"{x:1430,y:765,t:1527271830913};\\\", \\\"{x:1428,y:781,t:1527271830928};\\\", \\\"{x:1424,y:801,t:1527271830945};\\\", \\\"{x:1416,y:819,t:1527271830962};\\\", \\\"{x:1405,y:837,t:1527271830978};\\\", \\\"{x:1394,y:852,t:1527271830995};\\\", \\\"{x:1391,y:857,t:1527271831012};\\\", \\\"{x:1388,y:859,t:1527271831028};\\\", \\\"{x:1385,y:859,t:1527271831045};\\\", \\\"{x:1381,y:859,t:1527271831062};\\\", \\\"{x:1377,y:859,t:1527271831079};\\\", \\\"{x:1375,y:859,t:1527271831096};\\\", \\\"{x:1370,y:862,t:1527271831112};\\\", \\\"{x:1366,y:864,t:1527271831128};\\\", \\\"{x:1354,y:868,t:1527271831145};\\\", \\\"{x:1336,y:874,t:1527271831162};\\\", \\\"{x:1323,y:878,t:1527271831178};\\\", \\\"{x:1314,y:880,t:1527271831195};\\\", \\\"{x:1308,y:882,t:1527271831213};\\\", \\\"{x:1305,y:883,t:1527271831228};\\\", \\\"{x:1302,y:883,t:1527271831246};\\\", \\\"{x:1301,y:884,t:1527271831262};\\\", \\\"{x:1300,y:885,t:1527271831278};\\\", \\\"{x:1300,y:884,t:1527271831417};\\\", \\\"{x:1300,y:882,t:1527271831430};\\\", \\\"{x:1300,y:877,t:1527271831446};\\\", \\\"{x:1304,y:869,t:1527271831462};\\\", \\\"{x:1308,y:858,t:1527271831480};\\\", \\\"{x:1316,y:847,t:1527271831495};\\\", \\\"{x:1326,y:834,t:1527271831512};\\\", \\\"{x:1331,y:825,t:1527271831528};\\\", \\\"{x:1336,y:815,t:1527271831544};\\\", \\\"{x:1340,y:809,t:1527271831562};\\\", \\\"{x:1346,y:802,t:1527271831578};\\\", \\\"{x:1350,y:798,t:1527271831595};\\\", \\\"{x:1352,y:794,t:1527271831611};\\\", \\\"{x:1353,y:790,t:1527271831629};\\\", \\\"{x:1356,y:787,t:1527271831645};\\\", \\\"{x:1358,y:784,t:1527271831662};\\\", \\\"{x:1360,y:780,t:1527271831679};\\\", \\\"{x:1362,y:776,t:1527271831695};\\\", \\\"{x:1367,y:768,t:1527271831712};\\\", \\\"{x:1371,y:764,t:1527271831729};\\\", \\\"{x:1375,y:759,t:1527271831745};\\\", \\\"{x:1377,y:754,t:1527271831762};\\\", \\\"{x:1381,y:748,t:1527271831779};\\\", \\\"{x:1385,y:743,t:1527271831796};\\\", \\\"{x:1388,y:738,t:1527271831812};\\\", \\\"{x:1391,y:730,t:1527271831830};\\\", \\\"{x:1393,y:726,t:1527271831845};\\\", \\\"{x:1397,y:720,t:1527271831862};\\\", \\\"{x:1400,y:713,t:1527271831879};\\\", \\\"{x:1402,y:708,t:1527271831896};\\\", \\\"{x:1406,y:698,t:1527271831912};\\\", \\\"{x:1410,y:689,t:1527271831929};\\\", \\\"{x:1412,y:680,t:1527271831946};\\\", \\\"{x:1415,y:669,t:1527271831963};\\\", \\\"{x:1418,y:661,t:1527271831980};\\\", \\\"{x:1419,y:653,t:1527271831995};\\\", \\\"{x:1422,y:646,t:1527271832013};\\\", \\\"{x:1423,y:639,t:1527271832029};\\\", \\\"{x:1425,y:630,t:1527271832045};\\\", \\\"{x:1427,y:621,t:1527271832061};\\\", \\\"{x:1428,y:608,t:1527271832078};\\\", \\\"{x:1433,y:591,t:1527271832096};\\\", \\\"{x:1438,y:576,t:1527271832111};\\\", \\\"{x:1442,y:562,t:1527271832128};\\\", \\\"{x:1447,y:546,t:1527271832145};\\\", \\\"{x:1452,y:532,t:1527271832162};\\\", \\\"{x:1456,y:515,t:1527271832179};\\\", \\\"{x:1461,y:498,t:1527271832195};\\\", \\\"{x:1468,y:480,t:1527271832212};\\\", \\\"{x:1473,y:462,t:1527271832229};\\\", \\\"{x:1481,y:443,t:1527271832246};\\\", \\\"{x:1488,y:426,t:1527271832261};\\\", \\\"{x:1496,y:405,t:1527271832278};\\\", \\\"{x:1511,y:376,t:1527271832296};\\\", \\\"{x:1522,y:357,t:1527271832312};\\\", \\\"{x:1533,y:341,t:1527271832329};\\\", \\\"{x:1543,y:327,t:1527271832346};\\\", \\\"{x:1554,y:315,t:1527271832362};\\\", \\\"{x:1561,y:304,t:1527271832378};\\\", \\\"{x:1566,y:295,t:1527271832397};\\\", \\\"{x:1573,y:287,t:1527271832412};\\\", \\\"{x:1577,y:281,t:1527271832429};\\\", \\\"{x:1579,y:278,t:1527271832446};\\\", \\\"{x:1581,y:276,t:1527271832462};\\\", \\\"{x:1581,y:277,t:1527271832594};\\\", \\\"{x:1579,y:282,t:1527271832601};\\\", \\\"{x:1574,y:290,t:1527271832612};\\\", \\\"{x:1562,y:311,t:1527271832630};\\\", \\\"{x:1537,y:346,t:1527271832647};\\\", \\\"{x:1503,y:389,t:1527271832663};\\\", \\\"{x:1460,y:432,t:1527271832679};\\\", \\\"{x:1388,y:491,t:1527271832697};\\\", \\\"{x:1350,y:521,t:1527271832712};\\\", \\\"{x:1315,y:547,t:1527271832730};\\\", \\\"{x:1276,y:575,t:1527271832746};\\\", \\\"{x:1239,y:599,t:1527271832763};\\\", \\\"{x:1193,y:628,t:1527271832780};\\\", \\\"{x:1138,y:659,t:1527271832797};\\\", \\\"{x:1081,y:692,t:1527271832814};\\\", \\\"{x:1014,y:727,t:1527271832830};\\\", \\\"{x:939,y:762,t:1527271832846};\\\", \\\"{x:867,y:792,t:1527271832863};\\\", \\\"{x:796,y:821,t:1527271832880};\\\", \\\"{x:707,y:855,t:1527271832897};\\\", \\\"{x:658,y:868,t:1527271832912};\\\", \\\"{x:634,y:870,t:1527271832929};\\\", \\\"{x:617,y:870,t:1527271832946};\\\", \\\"{x:609,y:870,t:1527271832964};\\\", \\\"{x:606,y:870,t:1527271832979};\\\", \\\"{x:601,y:869,t:1527271832997};\\\", \\\"{x:598,y:867,t:1527271833013};\\\", \\\"{x:593,y:865,t:1527271833030};\\\", \\\"{x:588,y:864,t:1527271833046};\\\", \\\"{x:580,y:859,t:1527271833063};\\\", \\\"{x:569,y:853,t:1527271833079};\\\", \\\"{x:564,y:848,t:1527271833097};\\\", \\\"{x:561,y:840,t:1527271833112};\\\", \\\"{x:555,y:825,t:1527271833130};\\\", \\\"{x:547,y:807,t:1527271833147};\\\", \\\"{x:539,y:789,t:1527271833163};\\\", \\\"{x:534,y:770,t:1527271833181};\\\", \\\"{x:528,y:750,t:1527271833197};\\\", \\\"{x:525,y:732,t:1527271833215};\\\", \\\"{x:521,y:716,t:1527271833228};\\\", \\\"{x:518,y:706,t:1527271833246};\\\", \\\"{x:516,y:698,t:1527271833256};\\\", \\\"{x:516,y:696,t:1527271833273};\\\", \\\"{x:516,y:695,t:1527271833289};\\\", \\\"{x:516,y:698,t:1527271833594};\\\", \\\"{x:516,y:701,t:1527271833606};\\\", \\\"{x:516,y:704,t:1527271833622};\\\", \\\"{x:516,y:706,t:1527271833630};\\\", \\\"{x:516,y:708,t:1527271833646};\\\", \\\"{x:516,y:709,t:1527271833664};\\\", \\\"{x:516,y:710,t:1527271833680};\\\", \\\"{x:516,y:712,t:1527271834329};\\\", \\\"{x:516,y:716,t:1527271834336};\\\", \\\"{x:516,y:719,t:1527271834348};\\\", \\\"{x:515,y:724,t:1527271834364};\\\", \\\"{x:513,y:729,t:1527271834381};\\\", \\\"{x:513,y:735,t:1527271834398};\\\", \\\"{x:513,y:740,t:1527271834414};\\\", \\\"{x:512,y:745,t:1527271834431};\\\", \\\"{x:510,y:752,t:1527271834448};\\\", \\\"{x:510,y:755,t:1527271834465};\\\", \\\"{x:510,y:757,t:1527271834481};\\\", \\\"{x:510,y:759,t:1527271834499};\\\", \\\"{x:510,y:760,t:1527271834515};\\\", \\\"{x:509,y:761,t:1527271834537};\\\", \\\"{x:509,y:762,t:1527271834560};\\\", \\\"{x:509,y:763,t:1527271834568};\\\", \\\"{x:509,y:764,t:1527271834593};\\\", \\\"{x:509,y:765,t:1527271834600};\\\", \\\"{x:509,y:766,t:1527271834617};\\\", \\\"{x:509,y:767,t:1527271834631};\\\", \\\"{x:509,y:768,t:1527271834648};\\\", \\\"{x:509,y:769,t:1527271834665};\\\", \\\"{x:509,y:770,t:1527271834800};\\\", \\\"{x:508,y:771,t:1527271834832};\\\" ] }, { \\\"rt\\\": 14203, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 264932, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:771,t:1527271836545};\\\", \\\"{x:509,y:760,t:1527271836561};\\\", \\\"{x:513,y:753,t:1527271836567};\\\", \\\"{x:518,y:741,t:1527271836582};\\\", \\\"{x:529,y:716,t:1527271836600};\\\", \\\"{x:552,y:661,t:1527271836616};\\\", \\\"{x:565,y:616,t:1527271836633};\\\", \\\"{x:575,y:575,t:1527271836649};\\\", \\\"{x:580,y:538,t:1527271836666};\\\", \\\"{x:584,y:509,t:1527271836684};\\\", \\\"{x:584,y:484,t:1527271836701};\\\", \\\"{x:584,y:466,t:1527271836716};\\\", \\\"{x:584,y:458,t:1527271836733};\\\", \\\"{x:583,y:453,t:1527271836749};\\\", \\\"{x:583,y:451,t:1527271836768};\\\", \\\"{x:582,y:451,t:1527271836783};\\\", \\\"{x:580,y:449,t:1527271836800};\\\", \\\"{x:578,y:449,t:1527271836816};\\\", \\\"{x:574,y:447,t:1527271836832};\\\", \\\"{x:574,y:446,t:1527271836849};\\\", \\\"{x:571,y:445,t:1527271836866};\\\", \\\"{x:569,y:445,t:1527271836882};\\\", \\\"{x:564,y:445,t:1527271836899};\\\", \\\"{x:557,y:446,t:1527271836916};\\\", \\\"{x:546,y:451,t:1527271836932};\\\", \\\"{x:531,y:457,t:1527271836949};\\\", \\\"{x:517,y:461,t:1527271836965};\\\", \\\"{x:508,y:466,t:1527271836982};\\\", \\\"{x:502,y:468,t:1527271837000};\\\", \\\"{x:495,y:471,t:1527271837015};\\\", \\\"{x:488,y:475,t:1527271837032};\\\", \\\"{x:483,y:478,t:1527271837049};\\\", \\\"{x:477,y:481,t:1527271837065};\\\", \\\"{x:472,y:484,t:1527271837083};\\\", \\\"{x:469,y:487,t:1527271837099};\\\", \\\"{x:466,y:489,t:1527271837116};\\\", \\\"{x:464,y:491,t:1527271837132};\\\", \\\"{x:460,y:493,t:1527271837148};\\\", \\\"{x:459,y:494,t:1527271837168};\\\", \\\"{x:458,y:494,t:1527271837369};\\\", \\\"{x:458,y:492,t:1527271837384};\\\", \\\"{x:458,y:490,t:1527271837398};\\\", \\\"{x:458,y:488,t:1527271837416};\\\", \\\"{x:458,y:486,t:1527271837431};\\\", \\\"{x:460,y:482,t:1527271837448};\\\", \\\"{x:462,y:480,t:1527271837472};\\\", \\\"{x:463,y:480,t:1527271837496};\\\", \\\"{x:465,y:479,t:1527271837513};\\\", \\\"{x:467,y:478,t:1527271837520};\\\", \\\"{x:469,y:477,t:1527271837536};\\\", \\\"{x:470,y:476,t:1527271837549};\\\", \\\"{x:472,y:476,t:1527271837564};\\\", \\\"{x:474,y:475,t:1527271837582};\\\", \\\"{x:478,y:474,t:1527271837598};\\\", \\\"{x:482,y:474,t:1527271837614};\\\", \\\"{x:485,y:472,t:1527271837632};\\\", \\\"{x:493,y:471,t:1527271837648};\\\", \\\"{x:499,y:471,t:1527271837664};\\\", \\\"{x:503,y:470,t:1527271837682};\\\", \\\"{x:508,y:470,t:1527271837698};\\\", \\\"{x:513,y:470,t:1527271837714};\\\", \\\"{x:518,y:470,t:1527271837731};\\\", \\\"{x:526,y:470,t:1527271837747};\\\", \\\"{x:535,y:470,t:1527271837764};\\\", \\\"{x:548,y:470,t:1527271837781};\\\", \\\"{x:559,y:470,t:1527271837797};\\\", \\\"{x:572,y:470,t:1527271837815};\\\", \\\"{x:584,y:470,t:1527271837831};\\\", \\\"{x:596,y:470,t:1527271837848};\\\", \\\"{x:608,y:470,t:1527271837864};\\\", \\\"{x:609,y:470,t:1527271837881};\\\", \\\"{x:611,y:470,t:1527271837897};\\\", \\\"{x:611,y:471,t:1527271838448};\\\", \\\"{x:611,y:474,t:1527271838463};\\\", \\\"{x:611,y:479,t:1527271838480};\\\", \\\"{x:611,y:487,t:1527271838496};\\\", \\\"{x:611,y:492,t:1527271838514};\\\", \\\"{x:614,y:499,t:1527271838529};\\\", \\\"{x:617,y:504,t:1527271838546};\\\", \\\"{x:620,y:509,t:1527271838564};\\\", \\\"{x:623,y:515,t:1527271838579};\\\", \\\"{x:628,y:521,t:1527271838596};\\\", \\\"{x:643,y:534,t:1527271838618};\\\", \\\"{x:660,y:546,t:1527271838634};\\\", \\\"{x:692,y:564,t:1527271838650};\\\", \\\"{x:730,y:586,t:1527271838668};\\\", \\\"{x:792,y:622,t:1527271838684};\\\", \\\"{x:862,y:655,t:1527271838701};\\\", \\\"{x:934,y:700,t:1527271838718};\\\", \\\"{x:1008,y:748,t:1527271838734};\\\", \\\"{x:1078,y:797,t:1527271838751};\\\", \\\"{x:1143,y:847,t:1527271838767};\\\", \\\"{x:1228,y:913,t:1527271838784};\\\", \\\"{x:1274,y:945,t:1527271838801};\\\", \\\"{x:1311,y:972,t:1527271838817};\\\", \\\"{x:1335,y:986,t:1527271838834};\\\", \\\"{x:1353,y:997,t:1527271838851};\\\", \\\"{x:1369,y:1004,t:1527271838867};\\\", \\\"{x:1379,y:1008,t:1527271838884};\\\", \\\"{x:1384,y:1009,t:1527271838900};\\\", \\\"{x:1384,y:1010,t:1527271839089};\\\", \\\"{x:1383,y:1011,t:1527271839104};\\\", \\\"{x:1382,y:1011,t:1527271839117};\\\", \\\"{x:1378,y:1011,t:1527271839133};\\\", \\\"{x:1375,y:1012,t:1527271839150};\\\", \\\"{x:1373,y:1012,t:1527271839176};\\\", \\\"{x:1372,y:1013,t:1527271839713};\\\", \\\"{x:1372,y:1005,t:1527271839720};\\\", \\\"{x:1372,y:980,t:1527271839732};\\\", \\\"{x:1372,y:927,t:1527271839749};\\\", \\\"{x:1379,y:847,t:1527271839765};\\\", \\\"{x:1394,y:750,t:1527271839782};\\\", \\\"{x:1415,y:627,t:1527271839799};\\\", \\\"{x:1434,y:505,t:1527271839815};\\\", \\\"{x:1458,y:321,t:1527271839832};\\\", \\\"{x:1470,y:216,t:1527271839849};\\\", \\\"{x:1470,y:125,t:1527271839865};\\\", \\\"{x:1470,y:61,t:1527271839882};\\\", \\\"{x:1466,y:8,t:1527271839899};\\\", \\\"{x:1453,y:0,t:1527271839915};\\\", \\\"{x:1443,y:0,t:1527271839932};\\\", \\\"{x:1433,y:0,t:1527271839949};\\\", \\\"{x:1427,y:0,t:1527271839965};\\\", \\\"{x:1424,y:0,t:1527271839982};\\\", \\\"{x:1423,y:0,t:1527271839998};\\\", \\\"{x:1422,y:0,t:1527271840057};\\\", \\\"{x:1421,y:0,t:1527271840066};\\\", \\\"{x:1416,y:6,t:1527271840082};\\\", \\\"{x:1413,y:16,t:1527271840099};\\\", \\\"{x:1411,y:23,t:1527271840116};\\\", \\\"{x:1411,y:33,t:1527271840131};\\\", \\\"{x:1411,y:47,t:1527271840148};\\\", \\\"{x:1413,y:65,t:1527271840165};\\\", \\\"{x:1419,y:86,t:1527271840181};\\\", \\\"{x:1432,y:110,t:1527271840197};\\\", \\\"{x:1457,y:143,t:1527271840216};\\\", \\\"{x:1485,y:180,t:1527271840231};\\\", \\\"{x:1536,y:237,t:1527271840248};\\\", \\\"{x:1583,y:277,t:1527271840264};\\\", \\\"{x:1625,y:307,t:1527271840281};\\\", \\\"{x:1660,y:333,t:1527271840298};\\\", \\\"{x:1680,y:346,t:1527271840314};\\\", \\\"{x:1687,y:355,t:1527271840331};\\\", \\\"{x:1690,y:362,t:1527271840348};\\\", \\\"{x:1690,y:365,t:1527271840364};\\\", \\\"{x:1689,y:368,t:1527271840381};\\\", \\\"{x:1686,y:371,t:1527271840397};\\\", \\\"{x:1679,y:375,t:1527271840414};\\\", \\\"{x:1669,y:381,t:1527271840431};\\\", \\\"{x:1654,y:390,t:1527271840447};\\\", \\\"{x:1625,y:401,t:1527271840465};\\\", \\\"{x:1605,y:411,t:1527271840481};\\\", \\\"{x:1597,y:416,t:1527271840498};\\\", \\\"{x:1588,y:423,t:1527271840514};\\\", \\\"{x:1588,y:426,t:1527271840532};\\\", \\\"{x:1587,y:428,t:1527271840548};\\\", \\\"{x:1587,y:432,t:1527271840565};\\\", \\\"{x:1587,y:433,t:1527271840580};\\\", \\\"{x:1587,y:434,t:1527271840598};\\\", \\\"{x:1587,y:435,t:1527271840614};\\\", \\\"{x:1587,y:437,t:1527271840630};\\\", \\\"{x:1587,y:440,t:1527271840647};\\\", \\\"{x:1587,y:444,t:1527271840664};\\\", \\\"{x:1589,y:446,t:1527271840680};\\\", \\\"{x:1590,y:448,t:1527271840698};\\\", \\\"{x:1590,y:450,t:1527271840715};\\\", \\\"{x:1591,y:452,t:1527271840731};\\\", \\\"{x:1592,y:452,t:1527271840748};\\\", \\\"{x:1593,y:453,t:1527271840801};\\\", \\\"{x:1594,y:453,t:1527271840813};\\\", \\\"{x:1596,y:454,t:1527271840830};\\\", \\\"{x:1597,y:455,t:1527271840848};\\\", \\\"{x:1598,y:455,t:1527271840863};\\\", \\\"{x:1599,y:456,t:1527271841008};\\\", \\\"{x:1599,y:457,t:1527271841016};\\\", \\\"{x:1599,y:459,t:1527271841031};\\\", \\\"{x:1597,y:465,t:1527271841047};\\\", \\\"{x:1593,y:474,t:1527271841064};\\\", \\\"{x:1588,y:485,t:1527271841080};\\\", \\\"{x:1577,y:512,t:1527271841096};\\\", \\\"{x:1570,y:532,t:1527271841114};\\\", \\\"{x:1562,y:553,t:1527271841129};\\\", \\\"{x:1552,y:575,t:1527271841146};\\\", \\\"{x:1544,y:601,t:1527271841164};\\\", \\\"{x:1535,y:623,t:1527271841180};\\\", \\\"{x:1525,y:647,t:1527271841197};\\\", \\\"{x:1518,y:670,t:1527271841214};\\\", \\\"{x:1514,y:685,t:1527271841229};\\\", \\\"{x:1510,y:700,t:1527271841247};\\\", \\\"{x:1508,y:706,t:1527271841263};\\\", \\\"{x:1507,y:710,t:1527271841279};\\\", \\\"{x:1506,y:711,t:1527271841297};\\\", \\\"{x:1505,y:711,t:1527271841393};\\\", \\\"{x:1504,y:711,t:1527271841416};\\\", \\\"{x:1502,y:711,t:1527271841433};\\\", \\\"{x:1500,y:711,t:1527271841446};\\\", \\\"{x:1498,y:711,t:1527271841463};\\\", \\\"{x:1494,y:711,t:1527271841480};\\\", \\\"{x:1492,y:711,t:1527271841496};\\\", \\\"{x:1488,y:711,t:1527271841513};\\\", \\\"{x:1486,y:712,t:1527271841530};\\\", \\\"{x:1483,y:712,t:1527271841546};\\\", \\\"{x:1482,y:713,t:1527271841563};\\\", \\\"{x:1480,y:713,t:1527271841578};\\\", \\\"{x:1478,y:713,t:1527271841600};\\\", \\\"{x:1478,y:714,t:1527271841613};\\\", \\\"{x:1477,y:714,t:1527271841673};\\\", \\\"{x:1477,y:715,t:1527271841689};\\\", \\\"{x:1477,y:716,t:1527271841695};\\\", \\\"{x:1476,y:717,t:1527271841711};\\\", \\\"{x:1474,y:719,t:1527271841728};\\\", \\\"{x:1473,y:723,t:1527271841745};\\\", \\\"{x:1470,y:726,t:1527271841762};\\\", \\\"{x:1469,y:731,t:1527271841777};\\\", \\\"{x:1467,y:735,t:1527271841795};\\\", \\\"{x:1462,y:742,t:1527271841811};\\\", \\\"{x:1458,y:752,t:1527271841828};\\\", \\\"{x:1454,y:757,t:1527271841845};\\\", \\\"{x:1450,y:765,t:1527271841861};\\\", \\\"{x:1447,y:771,t:1527271841878};\\\", \\\"{x:1442,y:779,t:1527271841894};\\\", \\\"{x:1437,y:787,t:1527271841911};\\\", \\\"{x:1428,y:802,t:1527271841927};\\\", \\\"{x:1425,y:808,t:1527271841944};\\\", \\\"{x:1421,y:814,t:1527271841961};\\\", \\\"{x:1417,y:821,t:1527271841978};\\\", \\\"{x:1414,y:826,t:1527271841995};\\\", \\\"{x:1410,y:832,t:1527271842011};\\\", \\\"{x:1409,y:837,t:1527271842028};\\\", \\\"{x:1405,y:842,t:1527271842044};\\\", \\\"{x:1401,y:849,t:1527271842062};\\\", \\\"{x:1397,y:856,t:1527271842077};\\\", \\\"{x:1393,y:864,t:1527271842095};\\\", \\\"{x:1390,y:873,t:1527271842111};\\\", \\\"{x:1387,y:880,t:1527271842127};\\\", \\\"{x:1381,y:893,t:1527271842145};\\\", \\\"{x:1378,y:898,t:1527271842162};\\\", \\\"{x:1375,y:904,t:1527271842177};\\\", \\\"{x:1373,y:909,t:1527271842195};\\\", \\\"{x:1372,y:913,t:1527271842211};\\\", \\\"{x:1370,y:917,t:1527271842227};\\\", \\\"{x:1369,y:920,t:1527271842245};\\\", \\\"{x:1368,y:924,t:1527271842261};\\\", \\\"{x:1366,y:929,t:1527271842278};\\\", \\\"{x:1364,y:932,t:1527271842295};\\\", \\\"{x:1364,y:936,t:1527271842311};\\\", \\\"{x:1363,y:938,t:1527271842327};\\\", \\\"{x:1362,y:941,t:1527271842345};\\\", \\\"{x:1362,y:942,t:1527271842361};\\\", \\\"{x:1361,y:944,t:1527271842392};\\\", \\\"{x:1361,y:945,t:1527271842408};\\\", \\\"{x:1360,y:946,t:1527271842416};\\\", \\\"{x:1360,y:948,t:1527271842433};\\\", \\\"{x:1360,y:949,t:1527271842444};\\\", \\\"{x:1358,y:952,t:1527271842461};\\\", \\\"{x:1356,y:955,t:1527271842478};\\\", \\\"{x:1354,y:958,t:1527271842494};\\\", \\\"{x:1353,y:962,t:1527271842511};\\\", \\\"{x:1351,y:966,t:1527271842526};\\\", \\\"{x:1350,y:966,t:1527271842543};\\\", \\\"{x:1349,y:968,t:1527271842560};\\\", \\\"{x:1348,y:969,t:1527271842576};\\\", \\\"{x:1348,y:970,t:1527271842632};\\\", \\\"{x:1347,y:970,t:1527271842849};\\\", \\\"{x:1346,y:970,t:1527271842860};\\\", \\\"{x:1345,y:970,t:1527271842877};\\\", \\\"{x:1344,y:970,t:1527271842892};\\\", \\\"{x:1341,y:968,t:1527271842911};\\\", \\\"{x:1339,y:966,t:1527271842927};\\\", \\\"{x:1338,y:961,t:1527271842943};\\\", \\\"{x:1335,y:952,t:1527271842960};\\\", \\\"{x:1334,y:939,t:1527271842976};\\\", \\\"{x:1334,y:927,t:1527271842993};\\\", \\\"{x:1333,y:909,t:1527271843010};\\\", \\\"{x:1330,y:889,t:1527271843027};\\\", \\\"{x:1327,y:867,t:1527271843043};\\\", \\\"{x:1321,y:845,t:1527271843059};\\\", \\\"{x:1308,y:825,t:1527271843076};\\\", \\\"{x:1284,y:791,t:1527271843093};\\\", \\\"{x:1254,y:758,t:1527271843110};\\\", \\\"{x:1207,y:720,t:1527271843125};\\\", \\\"{x:1156,y:682,t:1527271843142};\\\", \\\"{x:1104,y:648,t:1527271843159};\\\", \\\"{x:1042,y:616,t:1527271843175};\\\", \\\"{x:924,y:559,t:1527271843192};\\\", \\\"{x:821,y:514,t:1527271843210};\\\", \\\"{x:712,y:473,t:1527271843232};\\\", \\\"{x:570,y:432,t:1527271843247};\\\", \\\"{x:490,y:409,t:1527271843271};\\\", \\\"{x:413,y:390,t:1527271843288};\\\", \\\"{x:385,y:383,t:1527271843306};\\\", \\\"{x:367,y:382,t:1527271843321};\\\", \\\"{x:359,y:382,t:1527271843338};\\\", \\\"{x:354,y:382,t:1527271843355};\\\", \\\"{x:350,y:383,t:1527271843372};\\\", \\\"{x:348,y:388,t:1527271843388};\\\", \\\"{x:341,y:397,t:1527271843406};\\\", \\\"{x:336,y:406,t:1527271843422};\\\", \\\"{x:334,y:417,t:1527271843439};\\\", \\\"{x:334,y:427,t:1527271843456};\\\", \\\"{x:333,y:435,t:1527271843472};\\\", \\\"{x:345,y:452,t:1527271843488};\\\", \\\"{x:370,y:466,t:1527271843506};\\\", \\\"{x:418,y:481,t:1527271843521};\\\", \\\"{x:500,y:498,t:1527271843538};\\\", \\\"{x:591,y:509,t:1527271843555};\\\", \\\"{x:677,y:520,t:1527271843571};\\\", \\\"{x:749,y:529,t:1527271843588};\\\", \\\"{x:807,y:538,t:1527271843606};\\\", \\\"{x:845,y:545,t:1527271843622};\\\", \\\"{x:862,y:548,t:1527271843638};\\\", \\\"{x:865,y:548,t:1527271843656};\\\", \\\"{x:866,y:548,t:1527271843671};\\\", \\\"{x:867,y:548,t:1527271843776};\\\", \\\"{x:868,y:550,t:1527271843791};\\\", \\\"{x:873,y:551,t:1527271843805};\\\", \\\"{x:885,y:551,t:1527271843821};\\\", \\\"{x:901,y:551,t:1527271843838};\\\", \\\"{x:925,y:551,t:1527271843854};\\\", \\\"{x:978,y:551,t:1527271843872};\\\", \\\"{x:1031,y:551,t:1527271843887};\\\", \\\"{x:1090,y:551,t:1527271843905};\\\", \\\"{x:1160,y:551,t:1527271843922};\\\", \\\"{x:1235,y:551,t:1527271843938};\\\", \\\"{x:1299,y:551,t:1527271843955};\\\", \\\"{x:1368,y:551,t:1527271843972};\\\", \\\"{x:1446,y:551,t:1527271843988};\\\", \\\"{x:1505,y:551,t:1527271844006};\\\", \\\"{x:1558,y:551,t:1527271844022};\\\", \\\"{x:1605,y:551,t:1527271844038};\\\", \\\"{x:1660,y:544,t:1527271844056};\\\", \\\"{x:1688,y:541,t:1527271844072};\\\", \\\"{x:1711,y:536,t:1527271844089};\\\", \\\"{x:1732,y:532,t:1527271844105};\\\", \\\"{x:1746,y:528,t:1527271844122};\\\", \\\"{x:1755,y:523,t:1527271844139};\\\", \\\"{x:1757,y:521,t:1527271844155};\\\", \\\"{x:1757,y:517,t:1527271844172};\\\", \\\"{x:1760,y:513,t:1527271844189};\\\", \\\"{x:1760,y:508,t:1527271844206};\\\", \\\"{x:1760,y:502,t:1527271844222};\\\", \\\"{x:1760,y:493,t:1527271844239};\\\", \\\"{x:1760,y:486,t:1527271844256};\\\", \\\"{x:1741,y:464,t:1527271844272};\\\", \\\"{x:1721,y:450,t:1527271844290};\\\", \\\"{x:1702,y:440,t:1527271844306};\\\", \\\"{x:1687,y:434,t:1527271844323};\\\", \\\"{x:1677,y:429,t:1527271844340};\\\", \\\"{x:1673,y:428,t:1527271844356};\\\", \\\"{x:1672,y:428,t:1527271844373};\\\", \\\"{x:1670,y:427,t:1527271844425};\\\", \\\"{x:1668,y:427,t:1527271844441};\\\", \\\"{x:1667,y:427,t:1527271844456};\\\", \\\"{x:1664,y:427,t:1527271844472};\\\", \\\"{x:1661,y:429,t:1527271844489};\\\", \\\"{x:1657,y:435,t:1527271844508};\\\", \\\"{x:1651,y:441,t:1527271844522};\\\", \\\"{x:1644,y:447,t:1527271844539};\\\", \\\"{x:1634,y:454,t:1527271844556};\\\", \\\"{x:1628,y:459,t:1527271844573};\\\", \\\"{x:1628,y:460,t:1527271844590};\\\", \\\"{x:1627,y:460,t:1527271845537};\\\", \\\"{x:1626,y:459,t:1527271845865};\\\", \\\"{x:1626,y:458,t:1527271845874};\\\", \\\"{x:1625,y:457,t:1527271845891};\\\", \\\"{x:1625,y:456,t:1527271845908};\\\", \\\"{x:1625,y:455,t:1527271845924};\\\", \\\"{x:1625,y:454,t:1527271845941};\\\", \\\"{x:1624,y:453,t:1527271846200};\\\", \\\"{x:1623,y:453,t:1527271846208};\\\", \\\"{x:1621,y:453,t:1527271846224};\\\", \\\"{x:1618,y:456,t:1527271846241};\\\", \\\"{x:1615,y:461,t:1527271846258};\\\", \\\"{x:1611,y:467,t:1527271846275};\\\", \\\"{x:1608,y:472,t:1527271846291};\\\", \\\"{x:1607,y:477,t:1527271846308};\\\", \\\"{x:1607,y:480,t:1527271846325};\\\", \\\"{x:1606,y:485,t:1527271846341};\\\", \\\"{x:1606,y:492,t:1527271846358};\\\", \\\"{x:1606,y:502,t:1527271846375};\\\", \\\"{x:1606,y:516,t:1527271846392};\\\", \\\"{x:1604,y:529,t:1527271846408};\\\", \\\"{x:1603,y:540,t:1527271846425};\\\", \\\"{x:1602,y:554,t:1527271846442};\\\", \\\"{x:1601,y:568,t:1527271846458};\\\", \\\"{x:1598,y:583,t:1527271846475};\\\", \\\"{x:1597,y:598,t:1527271846491};\\\", \\\"{x:1593,y:610,t:1527271846508};\\\", \\\"{x:1589,y:622,t:1527271846525};\\\", \\\"{x:1586,y:629,t:1527271846542};\\\", \\\"{x:1583,y:638,t:1527271846558};\\\", \\\"{x:1579,y:645,t:1527271846575};\\\", \\\"{x:1575,y:652,t:1527271846592};\\\", \\\"{x:1575,y:653,t:1527271846608};\\\", \\\"{x:1573,y:655,t:1527271846625};\\\", \\\"{x:1572,y:656,t:1527271846641};\\\", \\\"{x:1569,y:658,t:1527271846657};\\\", \\\"{x:1568,y:660,t:1527271846675};\\\", \\\"{x:1564,y:662,t:1527271846692};\\\", \\\"{x:1561,y:665,t:1527271846708};\\\", \\\"{x:1559,y:667,t:1527271846724};\\\", \\\"{x:1557,y:669,t:1527271846742};\\\", \\\"{x:1554,y:671,t:1527271846758};\\\", \\\"{x:1550,y:673,t:1527271846775};\\\", \\\"{x:1545,y:676,t:1527271846793};\\\", \\\"{x:1541,y:677,t:1527271846808};\\\", \\\"{x:1534,y:680,t:1527271846825};\\\", \\\"{x:1524,y:683,t:1527271846842};\\\", \\\"{x:1509,y:687,t:1527271846859};\\\", \\\"{x:1492,y:691,t:1527271846875};\\\", \\\"{x:1472,y:695,t:1527271846892};\\\", \\\"{x:1451,y:698,t:1527271846909};\\\", \\\"{x:1426,y:698,t:1527271846925};\\\", \\\"{x:1401,y:698,t:1527271846942};\\\", \\\"{x:1369,y:698,t:1527271846959};\\\", \\\"{x:1319,y:698,t:1527271846975};\\\", \\\"{x:1230,y:690,t:1527271846993};\\\", \\\"{x:1155,y:681,t:1527271847008};\\\", \\\"{x:1084,y:668,t:1527271847024};\\\", \\\"{x:1022,y:656,t:1527271847042};\\\", \\\"{x:975,y:650,t:1527271847059};\\\", \\\"{x:948,y:646,t:1527271847075};\\\", \\\"{x:935,y:646,t:1527271847092};\\\", \\\"{x:926,y:646,t:1527271847108};\\\", \\\"{x:919,y:646,t:1527271847126};\\\", \\\"{x:912,y:646,t:1527271847142};\\\", \\\"{x:905,y:646,t:1527271847159};\\\", \\\"{x:895,y:646,t:1527271847176};\\\", \\\"{x:888,y:646,t:1527271847193};\\\", \\\"{x:880,y:646,t:1527271847208};\\\", \\\"{x:871,y:645,t:1527271847226};\\\", \\\"{x:862,y:642,t:1527271847242};\\\", \\\"{x:853,y:641,t:1527271847258};\\\", \\\"{x:849,y:640,t:1527271847276};\\\", \\\"{x:847,y:640,t:1527271847292};\\\", \\\"{x:846,y:640,t:1527271847309};\\\", \\\"{x:845,y:640,t:1527271847337};\\\", \\\"{x:844,y:640,t:1527271847352};\\\", \\\"{x:843,y:640,t:1527271847360};\\\", \\\"{x:841,y:639,t:1527271847376};\\\", \\\"{x:839,y:637,t:1527271847392};\\\", \\\"{x:836,y:635,t:1527271847409};\\\", \\\"{x:835,y:634,t:1527271847425};\\\", \\\"{x:833,y:631,t:1527271847442};\\\", \\\"{x:832,y:629,t:1527271847459};\\\", \\\"{x:832,y:628,t:1527271847475};\\\", \\\"{x:832,y:626,t:1527271847493};\\\", \\\"{x:829,y:623,t:1527271847508};\\\", \\\"{x:825,y:618,t:1527271847525};\\\", \\\"{x:815,y:613,t:1527271847543};\\\", \\\"{x:791,y:602,t:1527271847561};\\\", \\\"{x:706,y:577,t:1527271847575};\\\", \\\"{x:627,y:560,t:1527271847592};\\\", \\\"{x:549,y:549,t:1527271847608};\\\", \\\"{x:492,y:546,t:1527271847626};\\\", \\\"{x:444,y:546,t:1527271847641};\\\", \\\"{x:418,y:546,t:1527271847658};\\\", \\\"{x:406,y:546,t:1527271847674};\\\", \\\"{x:400,y:549,t:1527271847691};\\\", \\\"{x:395,y:550,t:1527271847709};\\\", \\\"{x:391,y:553,t:1527271847725};\\\", \\\"{x:386,y:556,t:1527271847741};\\\", \\\"{x:378,y:561,t:1527271847759};\\\", \\\"{x:372,y:564,t:1527271847775};\\\", \\\"{x:362,y:570,t:1527271847791};\\\", \\\"{x:358,y:574,t:1527271847808};\\\", \\\"{x:355,y:580,t:1527271847825};\\\", \\\"{x:355,y:583,t:1527271847842};\\\", \\\"{x:355,y:587,t:1527271847858};\\\", \\\"{x:355,y:590,t:1527271847876};\\\", \\\"{x:355,y:592,t:1527271847891};\\\", \\\"{x:355,y:595,t:1527271847908};\\\", \\\"{x:355,y:597,t:1527271847926};\\\", \\\"{x:355,y:600,t:1527271847941};\\\", \\\"{x:355,y:601,t:1527271847959};\\\", \\\"{x:356,y:602,t:1527271847976};\\\", \\\"{x:357,y:602,t:1527271847992};\\\", \\\"{x:358,y:602,t:1527271848008};\\\", \\\"{x:360,y:602,t:1527271848026};\\\", \\\"{x:362,y:602,t:1527271848042};\\\", \\\"{x:364,y:602,t:1527271848058};\\\", \\\"{x:366,y:601,t:1527271848076};\\\", \\\"{x:368,y:600,t:1527271848093};\\\", \\\"{x:372,y:598,t:1527271848109};\\\", \\\"{x:374,y:597,t:1527271848127};\\\", \\\"{x:377,y:596,t:1527271848143};\\\", \\\"{x:379,y:596,t:1527271848158};\\\", \\\"{x:380,y:594,t:1527271848175};\\\", \\\"{x:381,y:594,t:1527271848560};\\\", \\\"{x:393,y:604,t:1527271848576};\\\", \\\"{x:411,y:628,t:1527271848594};\\\", \\\"{x:434,y:657,t:1527271848610};\\\", \\\"{x:465,y:693,t:1527271848626};\\\", \\\"{x:489,y:723,t:1527271848642};\\\", \\\"{x:510,y:743,t:1527271848660};\\\", \\\"{x:531,y:760,t:1527271848675};\\\", \\\"{x:551,y:772,t:1527271848693};\\\", \\\"{x:571,y:781,t:1527271848709};\\\", \\\"{x:579,y:784,t:1527271848725};\\\", \\\"{x:582,y:786,t:1527271848742};\\\", \\\"{x:582,y:785,t:1527271848872};\\\", \\\"{x:582,y:782,t:1527271848880};\\\", \\\"{x:581,y:777,t:1527271848892};\\\", \\\"{x:578,y:770,t:1527271848910};\\\", \\\"{x:570,y:758,t:1527271848926};\\\", \\\"{x:565,y:750,t:1527271848943};\\\", \\\"{x:557,y:739,t:1527271848960};\\\", \\\"{x:555,y:737,t:1527271848976};\\\", \\\"{x:554,y:735,t:1527271848994};\\\", \\\"{x:553,y:734,t:1527271849010};\\\", \\\"{x:551,y:732,t:1527271849027};\\\", \\\"{x:549,y:729,t:1527271849043};\\\", \\\"{x:546,y:725,t:1527271849060};\\\", \\\"{x:542,y:720,t:1527271849077};\\\", \\\"{x:541,y:719,t:1527271849093};\\\", \\\"{x:540,y:718,t:1527271849110};\\\", \\\"{x:540,y:717,t:1527271849225};\\\" ] }, { \\\"rt\\\": 82986, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 349231, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -C -C -C -Z -C -Z -Z -F -O -O -Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:717,t:1527271851809};\\\", \\\"{x:539,y:702,t:1527271851816};\\\", \\\"{x:543,y:681,t:1527271851829};\\\", \\\"{x:550,y:636,t:1527271851846};\\\", \\\"{x:560,y:568,t:1527271851862};\\\", \\\"{x:565,y:514,t:1527271851880};\\\", \\\"{x:567,y:463,t:1527271851895};\\\", \\\"{x:565,y:416,t:1527271851911};\\\", \\\"{x:562,y:391,t:1527271851929};\\\", \\\"{x:557,y:375,t:1527271851945};\\\", \\\"{x:549,y:360,t:1527271851962};\\\", \\\"{x:546,y:357,t:1527271851978};\\\", \\\"{x:544,y:355,t:1527271851996};\\\", \\\"{x:543,y:355,t:1527271852032};\\\", \\\"{x:542,y:355,t:1527271852046};\\\", \\\"{x:539,y:355,t:1527271852063};\\\", \\\"{x:531,y:359,t:1527271852079};\\\", \\\"{x:514,y:380,t:1527271852096};\\\", \\\"{x:504,y:397,t:1527271852112};\\\", \\\"{x:497,y:413,t:1527271852128};\\\", \\\"{x:493,y:426,t:1527271852145};\\\", \\\"{x:490,y:435,t:1527271852162};\\\", \\\"{x:486,y:443,t:1527271852178};\\\", \\\"{x:486,y:444,t:1527271852196};\\\", \\\"{x:486,y:446,t:1527271852213};\\\", \\\"{x:484,y:447,t:1527271852229};\\\", \\\"{x:484,y:448,t:1527271852245};\\\", \\\"{x:483,y:449,t:1527271852263};\\\", \\\"{x:482,y:453,t:1527271852279};\\\", \\\"{x:480,y:456,t:1527271852296};\\\", \\\"{x:477,y:459,t:1527271852313};\\\", \\\"{x:474,y:462,t:1527271852329};\\\", \\\"{x:473,y:464,t:1527271852346};\\\", \\\"{x:470,y:468,t:1527271852362};\\\", \\\"{x:467,y:470,t:1527271852380};\\\", \\\"{x:466,y:471,t:1527271852397};\\\", \\\"{x:465,y:471,t:1527271852416};\\\", \\\"{x:464,y:471,t:1527271852432};\\\", \\\"{x:463,y:472,t:1527271852456};\\\", \\\"{x:462,y:473,t:1527271852487};\\\", \\\"{x:463,y:474,t:1527271852808};\\\", \\\"{x:465,y:474,t:1527271852816};\\\", \\\"{x:468,y:474,t:1527271852831};\\\", \\\"{x:476,y:474,t:1527271852847};\\\", \\\"{x:489,y:474,t:1527271852864};\\\", \\\"{x:497,y:474,t:1527271852881};\\\", \\\"{x:504,y:474,t:1527271852898};\\\", \\\"{x:510,y:474,t:1527271852914};\\\", \\\"{x:515,y:474,t:1527271852931};\\\", \\\"{x:520,y:474,t:1527271852948};\\\", \\\"{x:522,y:474,t:1527271852965};\\\", \\\"{x:523,y:474,t:1527271852981};\\\", \\\"{x:525,y:474,t:1527271852998};\\\", \\\"{x:526,y:474,t:1527271853014};\\\", \\\"{x:528,y:474,t:1527271853031};\\\", \\\"{x:534,y:474,t:1527271853049};\\\", \\\"{x:537,y:473,t:1527271853065};\\\", \\\"{x:541,y:473,t:1527271853081};\\\", \\\"{x:542,y:473,t:1527271853098};\\\", \\\"{x:543,y:473,t:1527271853115};\\\", \\\"{x:544,y:473,t:1527271853400};\\\", \\\"{x:545,y:473,t:1527271853415};\\\", \\\"{x:554,y:472,t:1527271853432};\\\", \\\"{x:561,y:472,t:1527271853449};\\\", \\\"{x:565,y:472,t:1527271853465};\\\", \\\"{x:569,y:472,t:1527271853482};\\\", \\\"{x:572,y:472,t:1527271856847};\\\", \\\"{x:577,y:472,t:1527271856855};\\\", \\\"{x:590,y:472,t:1527271856872};\\\", \\\"{x:601,y:472,t:1527271856888};\\\", \\\"{x:609,y:472,t:1527271856906};\\\", \\\"{x:615,y:472,t:1527271856922};\\\", \\\"{x:617,y:472,t:1527271856938};\\\", \\\"{x:618,y:472,t:1527271857832};\\\", \\\"{x:620,y:472,t:1527271857841};\\\", \\\"{x:633,y:472,t:1527271857859};\\\", \\\"{x:656,y:475,t:1527271857876};\\\", \\\"{x:686,y:480,t:1527271857892};\\\", \\\"{x:738,y:485,t:1527271857908};\\\", \\\"{x:792,y:496,t:1527271857926};\\\", \\\"{x:861,y:504,t:1527271857941};\\\", \\\"{x:929,y:515,t:1527271857960};\\\", \\\"{x:998,y:525,t:1527271857975};\\\", \\\"{x:1097,y:539,t:1527271857991};\\\", \\\"{x:1130,y:544,t:1527271857999};\\\", \\\"{x:1200,y:556,t:1527271858017};\\\", \\\"{x:1264,y:565,t:1527271858032};\\\", \\\"{x:1320,y:573,t:1527271858050};\\\", \\\"{x:1366,y:582,t:1527271858067};\\\", \\\"{x:1403,y:588,t:1527271858082};\\\", \\\"{x:1437,y:593,t:1527271858099};\\\", \\\"{x:1462,y:597,t:1527271858117};\\\", \\\"{x:1483,y:600,t:1527271858134};\\\", \\\"{x:1497,y:601,t:1527271858149};\\\", \\\"{x:1503,y:602,t:1527271858167};\\\", \\\"{x:1505,y:603,t:1527271858184};\\\", \\\"{x:1505,y:604,t:1527271858785};\\\", \\\"{x:1504,y:605,t:1527271858808};\\\", \\\"{x:1503,y:606,t:1527271858819};\\\", \\\"{x:1501,y:607,t:1527271858837};\\\", \\\"{x:1500,y:608,t:1527271858853};\\\", \\\"{x:1498,y:609,t:1527271858871};\\\", \\\"{x:1497,y:610,t:1527271858887};\\\", \\\"{x:1496,y:611,t:1527271858903};\\\", \\\"{x:1495,y:611,t:1527271858920};\\\", \\\"{x:1493,y:611,t:1527271858937};\\\", \\\"{x:1492,y:612,t:1527271858954};\\\", \\\"{x:1490,y:613,t:1527271858971};\\\", \\\"{x:1487,y:614,t:1527271858988};\\\", \\\"{x:1484,y:614,t:1527271859004};\\\", \\\"{x:1481,y:615,t:1527271859021};\\\", \\\"{x:1479,y:615,t:1527271859037};\\\", \\\"{x:1478,y:616,t:1527271859053};\\\", \\\"{x:1476,y:617,t:1527271859071};\\\", \\\"{x:1474,y:617,t:1527271859089};\\\", \\\"{x:1472,y:618,t:1527271859104};\\\", \\\"{x:1470,y:620,t:1527271859121};\\\", \\\"{x:1469,y:620,t:1527271859138};\\\", \\\"{x:1467,y:620,t:1527271859155};\\\", \\\"{x:1466,y:621,t:1527271859172};\\\", \\\"{x:1465,y:621,t:1527271859187};\\\", \\\"{x:1463,y:621,t:1527271859205};\\\", \\\"{x:1462,y:621,t:1527271859222};\\\", \\\"{x:1460,y:623,t:1527271859237};\\\", \\\"{x:1458,y:623,t:1527271859255};\\\", \\\"{x:1457,y:623,t:1527271859272};\\\", \\\"{x:1453,y:625,t:1527271859288};\\\", \\\"{x:1451,y:626,t:1527271859305};\\\", \\\"{x:1450,y:627,t:1527271859322};\\\", \\\"{x:1449,y:627,t:1527271859339};\\\", \\\"{x:1448,y:627,t:1527271859354};\\\", \\\"{x:1448,y:628,t:1527271859401};\\\", \\\"{x:1447,y:628,t:1527271859424};\\\", \\\"{x:1446,y:629,t:1527271859439};\\\", \\\"{x:1445,y:629,t:1527271859454};\\\", \\\"{x:1444,y:630,t:1527271859472};\\\", \\\"{x:1443,y:631,t:1527271859488};\\\", \\\"{x:1441,y:632,t:1527271859751};\\\", \\\"{x:1441,y:633,t:1527271859759};\\\", \\\"{x:1441,y:635,t:1527271859772};\\\", \\\"{x:1439,y:637,t:1527271859789};\\\", \\\"{x:1438,y:640,t:1527271859806};\\\", \\\"{x:1437,y:644,t:1527271859823};\\\", \\\"{x:1435,y:649,t:1527271859839};\\\", \\\"{x:1434,y:653,t:1527271859855};\\\", \\\"{x:1434,y:658,t:1527271859873};\\\", \\\"{x:1431,y:664,t:1527271859890};\\\", \\\"{x:1430,y:670,t:1527271859906};\\\", \\\"{x:1430,y:676,t:1527271859923};\\\", \\\"{x:1430,y:681,t:1527271859940};\\\", \\\"{x:1430,y:687,t:1527271859958};\\\", \\\"{x:1430,y:692,t:1527271859973};\\\", \\\"{x:1430,y:697,t:1527271859990};\\\", \\\"{x:1430,y:704,t:1527271860007};\\\", \\\"{x:1430,y:711,t:1527271860023};\\\", \\\"{x:1430,y:723,t:1527271860040};\\\", \\\"{x:1430,y:730,t:1527271860057};\\\", \\\"{x:1431,y:737,t:1527271860074};\\\", \\\"{x:1433,y:751,t:1527271860090};\\\", \\\"{x:1435,y:761,t:1527271860107};\\\", \\\"{x:1438,y:773,t:1527271860125};\\\", \\\"{x:1441,y:782,t:1527271860142};\\\", \\\"{x:1443,y:789,t:1527271860158};\\\", \\\"{x:1445,y:796,t:1527271860175};\\\", \\\"{x:1446,y:800,t:1527271860191};\\\", \\\"{x:1448,y:806,t:1527271860208};\\\", \\\"{x:1450,y:812,t:1527271860224};\\\", \\\"{x:1450,y:817,t:1527271860241};\\\", \\\"{x:1453,y:821,t:1527271860259};\\\", \\\"{x:1454,y:825,t:1527271860275};\\\", \\\"{x:1457,y:830,t:1527271860292};\\\", \\\"{x:1460,y:835,t:1527271860308};\\\", \\\"{x:1462,y:837,t:1527271860326};\\\", \\\"{x:1464,y:840,t:1527271860341};\\\", \\\"{x:1465,y:841,t:1527271860359};\\\", \\\"{x:1467,y:845,t:1527271860375};\\\", \\\"{x:1468,y:847,t:1527271860392};\\\", \\\"{x:1470,y:850,t:1527271860409};\\\", \\\"{x:1472,y:852,t:1527271860426};\\\", \\\"{x:1472,y:853,t:1527271860443};\\\", \\\"{x:1473,y:853,t:1527271860856};\\\", \\\"{x:1473,y:852,t:1527271860929};\\\", \\\"{x:1473,y:851,t:1527271861137};\\\", \\\"{x:1472,y:852,t:1527271861145};\\\", \\\"{x:1468,y:855,t:1527271861162};\\\", \\\"{x:1466,y:859,t:1527271861177};\\\", \\\"{x:1462,y:863,t:1527271861195};\\\", \\\"{x:1460,y:866,t:1527271861212};\\\", \\\"{x:1459,y:867,t:1527271861229};\\\", \\\"{x:1459,y:866,t:1527271861537};\\\", \\\"{x:1459,y:863,t:1527271861545};\\\", \\\"{x:1459,y:862,t:1527271861562};\\\", \\\"{x:1459,y:859,t:1527271861579};\\\", \\\"{x:1459,y:856,t:1527271861596};\\\", \\\"{x:1459,y:855,t:1527271861613};\\\", \\\"{x:1459,y:853,t:1527271861630};\\\", \\\"{x:1460,y:851,t:1527271861647};\\\", \\\"{x:1460,y:850,t:1527271861663};\\\", \\\"{x:1460,y:848,t:1527271861679};\\\", \\\"{x:1460,y:847,t:1527271861697};\\\", \\\"{x:1460,y:846,t:1527271861714};\\\", \\\"{x:1460,y:845,t:1527271861729};\\\", \\\"{x:1460,y:844,t:1527271861747};\\\", \\\"{x:1460,y:843,t:1527271861800};\\\", \\\"{x:1460,y:842,t:1527271861953};\\\", \\\"{x:1460,y:841,t:1527271861964};\\\", \\\"{x:1460,y:840,t:1527271861981};\\\", \\\"{x:1460,y:837,t:1527271861998};\\\", \\\"{x:1460,y:836,t:1527271862015};\\\", \\\"{x:1460,y:834,t:1527271862031};\\\", \\\"{x:1460,y:831,t:1527271862048};\\\", \\\"{x:1460,y:828,t:1527271862064};\\\", \\\"{x:1460,y:826,t:1527271862082};\\\", \\\"{x:1459,y:822,t:1527271862098};\\\", \\\"{x:1456,y:816,t:1527271862114};\\\", \\\"{x:1452,y:807,t:1527271862131};\\\", \\\"{x:1444,y:795,t:1527271862147};\\\", \\\"{x:1436,y:782,t:1527271862164};\\\", \\\"{x:1426,y:769,t:1527271862181};\\\", \\\"{x:1414,y:755,t:1527271862198};\\\", \\\"{x:1400,y:741,t:1527271862214};\\\", \\\"{x:1383,y:724,t:1527271862231};\\\", \\\"{x:1357,y:699,t:1527271862248};\\\", \\\"{x:1338,y:683,t:1527271862265};\\\", \\\"{x:1322,y:669,t:1527271862281};\\\", \\\"{x:1308,y:660,t:1527271862298};\\\", \\\"{x:1296,y:650,t:1527271862315};\\\", \\\"{x:1287,y:645,t:1527271862332};\\\", \\\"{x:1281,y:640,t:1527271862348};\\\", \\\"{x:1279,y:638,t:1527271862366};\\\", \\\"{x:1277,y:638,t:1527271862382};\\\", \\\"{x:1276,y:637,t:1527271862593};\\\", \\\"{x:1276,y:636,t:1527271862600};\\\", \\\"{x:1276,y:635,t:1527271862616};\\\", \\\"{x:1276,y:631,t:1527271862633};\\\", \\\"{x:1277,y:627,t:1527271862650};\\\", \\\"{x:1281,y:623,t:1527271862667};\\\", \\\"{x:1284,y:620,t:1527271862683};\\\", \\\"{x:1287,y:617,t:1527271862700};\\\", \\\"{x:1289,y:616,t:1527271862717};\\\", \\\"{x:1290,y:616,t:1527271862733};\\\", \\\"{x:1291,y:615,t:1527271862750};\\\", \\\"{x:1291,y:614,t:1527271862768};\\\", \\\"{x:1293,y:614,t:1527271862792};\\\", \\\"{x:1294,y:614,t:1527271862808};\\\", \\\"{x:1296,y:615,t:1527271862832};\\\", \\\"{x:1297,y:616,t:1527271862840};\\\", \\\"{x:1298,y:617,t:1527271862850};\\\", \\\"{x:1300,y:621,t:1527271862867};\\\", \\\"{x:1301,y:626,t:1527271862883};\\\", \\\"{x:1305,y:634,t:1527271862900};\\\", \\\"{x:1309,y:644,t:1527271862917};\\\", \\\"{x:1312,y:657,t:1527271862933};\\\", \\\"{x:1315,y:672,t:1527271862950};\\\", \\\"{x:1317,y:693,t:1527271862967};\\\", \\\"{x:1320,y:708,t:1527271862983};\\\", \\\"{x:1323,y:724,t:1527271863000};\\\", \\\"{x:1324,y:734,t:1527271863017};\\\", \\\"{x:1326,y:744,t:1527271863034};\\\", \\\"{x:1326,y:752,t:1527271863052};\\\", \\\"{x:1326,y:760,t:1527271863067};\\\", \\\"{x:1326,y:766,t:1527271863084};\\\", \\\"{x:1326,y:772,t:1527271863101};\\\", \\\"{x:1326,y:780,t:1527271863117};\\\", \\\"{x:1326,y:786,t:1527271863135};\\\", \\\"{x:1324,y:796,t:1527271863151};\\\", \\\"{x:1320,y:803,t:1527271863168};\\\", \\\"{x:1319,y:807,t:1527271863184};\\\", \\\"{x:1317,y:811,t:1527271863201};\\\", \\\"{x:1314,y:816,t:1527271863219};\\\", \\\"{x:1311,y:819,t:1527271863235};\\\", \\\"{x:1307,y:822,t:1527271863252};\\\", \\\"{x:1301,y:823,t:1527271863268};\\\", \\\"{x:1294,y:827,t:1527271863286};\\\", \\\"{x:1287,y:828,t:1527271863302};\\\", \\\"{x:1279,y:831,t:1527271863321};\\\", \\\"{x:1263,y:836,t:1527271863336};\\\", \\\"{x:1253,y:837,t:1527271863351};\\\", \\\"{x:1244,y:840,t:1527271863368};\\\", \\\"{x:1235,y:840,t:1527271863385};\\\", \\\"{x:1228,y:840,t:1527271863402};\\\", \\\"{x:1223,y:840,t:1527271863419};\\\", \\\"{x:1220,y:840,t:1527271863435};\\\", \\\"{x:1218,y:840,t:1527271863452};\\\", \\\"{x:1214,y:840,t:1527271863469};\\\", \\\"{x:1211,y:840,t:1527271863485};\\\", \\\"{x:1205,y:840,t:1527271863502};\\\", \\\"{x:1201,y:840,t:1527271863520};\\\", \\\"{x:1200,y:839,t:1527271863535};\\\", \\\"{x:1199,y:838,t:1527271863761};\\\", \\\"{x:1199,y:837,t:1527271863771};\\\", \\\"{x:1200,y:834,t:1527271863787};\\\", \\\"{x:1202,y:832,t:1527271863803};\\\", \\\"{x:1203,y:831,t:1527271863821};\\\", \\\"{x:1203,y:829,t:1527271863838};\\\", \\\"{x:1203,y:828,t:1527271863864};\\\", \\\"{x:1204,y:828,t:1527271863873};\\\", \\\"{x:1205,y:826,t:1527271863896};\\\", \\\"{x:1205,y:825,t:1527271863912};\\\", \\\"{x:1206,y:824,t:1527271863921};\\\", \\\"{x:1207,y:823,t:1527271864041};\\\", \\\"{x:1208,y:823,t:1527271864057};\\\", \\\"{x:1209,y:823,t:1527271864104};\\\", \\\"{x:1211,y:822,t:1527271864152};\\\", \\\"{x:1212,y:821,t:1527271864168};\\\", \\\"{x:1215,y:820,t:1527271865896};\\\", \\\"{x:1220,y:819,t:1527271865911};\\\", \\\"{x:1228,y:818,t:1527271865929};\\\", \\\"{x:1234,y:818,t:1527271865944};\\\", \\\"{x:1240,y:818,t:1527271865962};\\\", \\\"{x:1242,y:818,t:1527271865978};\\\", \\\"{x:1243,y:818,t:1527271865995};\\\", \\\"{x:1244,y:818,t:1527271866011};\\\", \\\"{x:1245,y:818,t:1527271866120};\\\", \\\"{x:1242,y:818,t:1527271867640};\\\", \\\"{x:1235,y:818,t:1527271867651};\\\", \\\"{x:1223,y:818,t:1527271867667};\\\", \\\"{x:1209,y:820,t:1527271867684};\\\", \\\"{x:1197,y:823,t:1527271867701};\\\", \\\"{x:1188,y:824,t:1527271867718};\\\", \\\"{x:1186,y:824,t:1527271867733};\\\", \\\"{x:1188,y:824,t:1527271867976};\\\", \\\"{x:1189,y:824,t:1527271867985};\\\", \\\"{x:1195,y:824,t:1527271868002};\\\", \\\"{x:1200,y:824,t:1527271868019};\\\", \\\"{x:1204,y:824,t:1527271868035};\\\", \\\"{x:1205,y:824,t:1527271868377};\\\", \\\"{x:1207,y:824,t:1527271868387};\\\", \\\"{x:1210,y:824,t:1527271868404};\\\", \\\"{x:1216,y:826,t:1527271868421};\\\", \\\"{x:1217,y:826,t:1527271868454};\\\", \\\"{x:1218,y:824,t:1527271870362};\\\", \\\"{x:1221,y:819,t:1527271870376};\\\", \\\"{x:1225,y:813,t:1527271870393};\\\", \\\"{x:1227,y:808,t:1527271870409};\\\", \\\"{x:1229,y:803,t:1527271870427};\\\", \\\"{x:1231,y:799,t:1527271870443};\\\", \\\"{x:1233,y:795,t:1527271870460};\\\", \\\"{x:1234,y:791,t:1527271870476};\\\", \\\"{x:1234,y:789,t:1527271870493};\\\", \\\"{x:1236,y:787,t:1527271870511};\\\", \\\"{x:1236,y:786,t:1527271870526};\\\", \\\"{x:1237,y:783,t:1527271870543};\\\", \\\"{x:1238,y:780,t:1527271870561};\\\", \\\"{x:1239,y:778,t:1527271870578};\\\", \\\"{x:1240,y:775,t:1527271870594};\\\", \\\"{x:1240,y:773,t:1527271870611};\\\", \\\"{x:1241,y:772,t:1527271870627};\\\", \\\"{x:1242,y:769,t:1527271870646};\\\", \\\"{x:1243,y:767,t:1527271870661};\\\", \\\"{x:1243,y:766,t:1527271870678};\\\", \\\"{x:1244,y:764,t:1527271870695};\\\", \\\"{x:1245,y:762,t:1527271870711};\\\", \\\"{x:1246,y:758,t:1527271870728};\\\", \\\"{x:1247,y:757,t:1527271870751};\\\", \\\"{x:1249,y:757,t:1527271871688};\\\", \\\"{x:1253,y:761,t:1527271871698};\\\", \\\"{x:1264,y:770,t:1527271871715};\\\", \\\"{x:1275,y:776,t:1527271871731};\\\", \\\"{x:1286,y:781,t:1527271871748};\\\", \\\"{x:1291,y:782,t:1527271871766};\\\", \\\"{x:1292,y:783,t:1527271871783};\\\", \\\"{x:1294,y:783,t:1527271871798};\\\", \\\"{x:1295,y:784,t:1527271872023};\\\", \\\"{x:1297,y:784,t:1527271872032};\\\", \\\"{x:1298,y:784,t:1527271872055};\\\", \\\"{x:1299,y:783,t:1527271872070};\\\", \\\"{x:1300,y:782,t:1527271872135};\\\", \\\"{x:1301,y:781,t:1527271872167};\\\", \\\"{x:1302,y:781,t:1527271872183};\\\", \\\"{x:1303,y:780,t:1527271872199};\\\", \\\"{x:1305,y:779,t:1527271872215};\\\", \\\"{x:1308,y:777,t:1527271872233};\\\", \\\"{x:1309,y:777,t:1527271872250};\\\", \\\"{x:1312,y:776,t:1527271872267};\\\", \\\"{x:1314,y:775,t:1527271872282};\\\", \\\"{x:1316,y:774,t:1527271872299};\\\", \\\"{x:1318,y:773,t:1527271872317};\\\", \\\"{x:1320,y:771,t:1527271872334};\\\", \\\"{x:1325,y:768,t:1527271872349};\\\", \\\"{x:1331,y:766,t:1527271872367};\\\", \\\"{x:1342,y:762,t:1527271872383};\\\", \\\"{x:1351,y:761,t:1527271872400};\\\", \\\"{x:1356,y:759,t:1527271872417};\\\", \\\"{x:1358,y:758,t:1527271872434};\\\", \\\"{x:1360,y:758,t:1527271872472};\\\", \\\"{x:1361,y:758,t:1527271872576};\\\", \\\"{x:1363,y:758,t:1527271872592};\\\", \\\"{x:1365,y:758,t:1527271872608};\\\", \\\"{x:1367,y:760,t:1527271872624};\\\", \\\"{x:1368,y:762,t:1527271872640};\\\", \\\"{x:1369,y:765,t:1527271872651};\\\", \\\"{x:1371,y:769,t:1527271872667};\\\", \\\"{x:1373,y:776,t:1527271872684};\\\", \\\"{x:1376,y:781,t:1527271872701};\\\", \\\"{x:1378,y:787,t:1527271872717};\\\", \\\"{x:1379,y:792,t:1527271872735};\\\", \\\"{x:1380,y:797,t:1527271872752};\\\", \\\"{x:1382,y:801,t:1527271872768};\\\", \\\"{x:1382,y:803,t:1527271872784};\\\", \\\"{x:1382,y:804,t:1527271872802};\\\", \\\"{x:1382,y:803,t:1527271873144};\\\", \\\"{x:1382,y:801,t:1527271873153};\\\", \\\"{x:1381,y:798,t:1527271873170};\\\", \\\"{x:1381,y:797,t:1527271873187};\\\", \\\"{x:1379,y:795,t:1527271873203};\\\", \\\"{x:1379,y:793,t:1527271873220};\\\", \\\"{x:1379,y:791,t:1527271873237};\\\", \\\"{x:1378,y:790,t:1527271873253};\\\", \\\"{x:1378,y:787,t:1527271873270};\\\", \\\"{x:1376,y:784,t:1527271873287};\\\", \\\"{x:1372,y:778,t:1527271873303};\\\", \\\"{x:1370,y:776,t:1527271873320};\\\", \\\"{x:1368,y:773,t:1527271873337};\\\", \\\"{x:1365,y:772,t:1527271873354};\\\", \\\"{x:1364,y:770,t:1527271873370};\\\", \\\"{x:1362,y:769,t:1527271873387};\\\", \\\"{x:1361,y:769,t:1527271873404};\\\", \\\"{x:1360,y:768,t:1527271873421};\\\", \\\"{x:1360,y:767,t:1527271873437};\\\", \\\"{x:1359,y:767,t:1527271873454};\\\", \\\"{x:1359,y:766,t:1527271873471};\\\", \\\"{x:1358,y:764,t:1527271873496};\\\", \\\"{x:1358,y:763,t:1527271873536};\\\", \\\"{x:1357,y:761,t:1527271874352};\\\", \\\"{x:1356,y:759,t:1527271874368};\\\", \\\"{x:1355,y:758,t:1527271874384};\\\", \\\"{x:1355,y:757,t:1527271874393};\\\", \\\"{x:1354,y:757,t:1527271874408};\\\", \\\"{x:1354,y:755,t:1527271874424};\\\", \\\"{x:1354,y:754,t:1527271874442};\\\", \\\"{x:1353,y:752,t:1527271874464};\\\", \\\"{x:1352,y:751,t:1527271874496};\\\", \\\"{x:1351,y:750,t:1527271874551};\\\", \\\"{x:1351,y:749,t:1527271874599};\\\", \\\"{x:1351,y:748,t:1527271874623};\\\", \\\"{x:1350,y:747,t:1527271874646};\\\", \\\"{x:1350,y:746,t:1527271874662};\\\", \\\"{x:1349,y:745,t:1527271874687};\\\", \\\"{x:1349,y:744,t:1527271874703};\\\", \\\"{x:1349,y:743,t:1527271874711};\\\", \\\"{x:1348,y:741,t:1527271874725};\\\", \\\"{x:1346,y:739,t:1527271874751};\\\", \\\"{x:1346,y:737,t:1527271874759};\\\", \\\"{x:1346,y:736,t:1527271874775};\\\", \\\"{x:1344,y:732,t:1527271874792};\\\", \\\"{x:1342,y:728,t:1527271874809};\\\", \\\"{x:1341,y:723,t:1527271874825};\\\", \\\"{x:1341,y:720,t:1527271874842};\\\", \\\"{x:1340,y:716,t:1527271874859};\\\", \\\"{x:1340,y:713,t:1527271874876};\\\", \\\"{x:1339,y:709,t:1527271874892};\\\", \\\"{x:1339,y:707,t:1527271874909};\\\", \\\"{x:1338,y:703,t:1527271874926};\\\", \\\"{x:1338,y:699,t:1527271874942};\\\", \\\"{x:1338,y:696,t:1527271874960};\\\", \\\"{x:1337,y:690,t:1527271874977};\\\", \\\"{x:1337,y:684,t:1527271874993};\\\", \\\"{x:1335,y:678,t:1527271875009};\\\", \\\"{x:1335,y:673,t:1527271875026};\\\", \\\"{x:1334,y:667,t:1527271875044};\\\", \\\"{x:1333,y:663,t:1527271875061};\\\", \\\"{x:1331,y:657,t:1527271875076};\\\", \\\"{x:1331,y:656,t:1527271875094};\\\", \\\"{x:1331,y:653,t:1527271875111};\\\", \\\"{x:1331,y:651,t:1527271875126};\\\", \\\"{x:1330,y:648,t:1527271875143};\\\", \\\"{x:1329,y:645,t:1527271875160};\\\", \\\"{x:1328,y:643,t:1527271875176};\\\", \\\"{x:1327,y:641,t:1527271875193};\\\", \\\"{x:1327,y:640,t:1527271875216};\\\", \\\"{x:1327,y:639,t:1527271875227};\\\", \\\"{x:1324,y:639,t:1527271878216};\\\", \\\"{x:1323,y:640,t:1527271878233};\\\", \\\"{x:1322,y:640,t:1527271878240};\\\", \\\"{x:1321,y:641,t:1527271878254};\\\", \\\"{x:1320,y:642,t:1527271878272};\\\", \\\"{x:1320,y:644,t:1527271879129};\\\", \\\"{x:1320,y:647,t:1527271879140};\\\", \\\"{x:1320,y:653,t:1527271879158};\\\", \\\"{x:1322,y:661,t:1527271879175};\\\", \\\"{x:1324,y:666,t:1527271879191};\\\", \\\"{x:1326,y:673,t:1527271879208};\\\", \\\"{x:1330,y:682,t:1527271879224};\\\", \\\"{x:1335,y:692,t:1527271879242};\\\", \\\"{x:1340,y:700,t:1527271879257};\\\", \\\"{x:1345,y:711,t:1527271879275};\\\", \\\"{x:1348,y:718,t:1527271879292};\\\", \\\"{x:1350,y:721,t:1527271879308};\\\", \\\"{x:1352,y:725,t:1527271879325};\\\", \\\"{x:1353,y:726,t:1527271879341};\\\", \\\"{x:1354,y:728,t:1527271879359};\\\", \\\"{x:1354,y:729,t:1527271879375};\\\", \\\"{x:1355,y:734,t:1527271879391};\\\", \\\"{x:1355,y:740,t:1527271879408};\\\", \\\"{x:1355,y:748,t:1527271879425};\\\", \\\"{x:1355,y:758,t:1527271879441};\\\", \\\"{x:1355,y:770,t:1527271879458};\\\", \\\"{x:1355,y:785,t:1527271879475};\\\", \\\"{x:1355,y:799,t:1527271879492};\\\", \\\"{x:1355,y:815,t:1527271879509};\\\", \\\"{x:1355,y:831,t:1527271879526};\\\", \\\"{x:1357,y:846,t:1527271879543};\\\", \\\"{x:1359,y:861,t:1527271879558};\\\", \\\"{x:1361,y:872,t:1527271879575};\\\", \\\"{x:1363,y:881,t:1527271879592};\\\", \\\"{x:1363,y:887,t:1527271879609};\\\", \\\"{x:1364,y:889,t:1527271879626};\\\", \\\"{x:1364,y:891,t:1527271879644};\\\", \\\"{x:1364,y:892,t:1527271879775};\\\", \\\"{x:1364,y:893,t:1527271879815};\\\", \\\"{x:1363,y:893,t:1527271879855};\\\", \\\"{x:1361,y:893,t:1527271879871};\\\", \\\"{x:1359,y:893,t:1527271879888};\\\", \\\"{x:1358,y:892,t:1527271879895};\\\", \\\"{x:1356,y:892,t:1527271879919};\\\", \\\"{x:1356,y:891,t:1527271879928};\\\", \\\"{x:1355,y:891,t:1527271880225};\\\", \\\"{x:1353,y:891,t:1527271880240};\\\", \\\"{x:1352,y:891,t:1527271880248};\\\", \\\"{x:1349,y:890,t:1527271880261};\\\", \\\"{x:1344,y:889,t:1527271880279};\\\", \\\"{x:1336,y:887,t:1527271880295};\\\", \\\"{x:1332,y:886,t:1527271880311};\\\", \\\"{x:1328,y:885,t:1527271880328};\\\", \\\"{x:1327,y:885,t:1527271880344};\\\", \\\"{x:1327,y:884,t:1527271880624};\\\", \\\"{x:1327,y:883,t:1527271880640};\\\", \\\"{x:1327,y:882,t:1527271880888};\\\", \\\"{x:1327,y:880,t:1527271880896};\\\", \\\"{x:1327,y:878,t:1527271880913};\\\", \\\"{x:1328,y:876,t:1527271880930};\\\", \\\"{x:1328,y:874,t:1527271880946};\\\", \\\"{x:1329,y:871,t:1527271880964};\\\", \\\"{x:1330,y:870,t:1527271880980};\\\", \\\"{x:1330,y:866,t:1527271880997};\\\", \\\"{x:1330,y:864,t:1527271881013};\\\", \\\"{x:1330,y:863,t:1527271881031};\\\", \\\"{x:1332,y:859,t:1527271881048};\\\", \\\"{x:1333,y:857,t:1527271881063};\\\", \\\"{x:1334,y:854,t:1527271881081};\\\", \\\"{x:1334,y:851,t:1527271881098};\\\", \\\"{x:1334,y:849,t:1527271881114};\\\", \\\"{x:1336,y:846,t:1527271881130};\\\", \\\"{x:1336,y:843,t:1527271881147};\\\", \\\"{x:1336,y:841,t:1527271881165};\\\", \\\"{x:1337,y:840,t:1527271881181};\\\", \\\"{x:1338,y:837,t:1527271881198};\\\", \\\"{x:1338,y:836,t:1527271881216};\\\", \\\"{x:1338,y:834,t:1527271881231};\\\", \\\"{x:1339,y:831,t:1527271881248};\\\", \\\"{x:1339,y:828,t:1527271881264};\\\", \\\"{x:1340,y:825,t:1527271881281};\\\", \\\"{x:1340,y:821,t:1527271881299};\\\", \\\"{x:1342,y:819,t:1527271881314};\\\", \\\"{x:1343,y:816,t:1527271881331};\\\", \\\"{x:1343,y:813,t:1527271881348};\\\", \\\"{x:1344,y:810,t:1527271881365};\\\", \\\"{x:1345,y:809,t:1527271881381};\\\", \\\"{x:1346,y:807,t:1527271881398};\\\", \\\"{x:1346,y:806,t:1527271881416};\\\", \\\"{x:1347,y:805,t:1527271881431};\\\", \\\"{x:1347,y:804,t:1527271885812};\\\", \\\"{x:1347,y:800,t:1527271885819};\\\", \\\"{x:1347,y:798,t:1527271885834};\\\", \\\"{x:1347,y:781,t:1527271885851};\\\", \\\"{x:1347,y:766,t:1527271885867};\\\", \\\"{x:1347,y:750,t:1527271885884};\\\", \\\"{x:1344,y:733,t:1527271885900};\\\", \\\"{x:1343,y:719,t:1527271885918};\\\", \\\"{x:1340,y:706,t:1527271885933};\\\", \\\"{x:1338,y:697,t:1527271885951};\\\", \\\"{x:1335,y:690,t:1527271885968};\\\", \\\"{x:1332,y:682,t:1527271885985};\\\", \\\"{x:1331,y:679,t:1527271886001};\\\", \\\"{x:1330,y:676,t:1527271886018};\\\", \\\"{x:1327,y:671,t:1527271886035};\\\", \\\"{x:1325,y:668,t:1527271886051};\\\", \\\"{x:1323,y:664,t:1527271886067};\\\", \\\"{x:1321,y:661,t:1527271886084};\\\", \\\"{x:1316,y:652,t:1527271886101};\\\", \\\"{x:1314,y:648,t:1527271886117};\\\", \\\"{x:1310,y:641,t:1527271886135};\\\", \\\"{x:1306,y:634,t:1527271886151};\\\", \\\"{x:1302,y:628,t:1527271886167};\\\", \\\"{x:1302,y:624,t:1527271886184};\\\", \\\"{x:1299,y:621,t:1527271886201};\\\", \\\"{x:1298,y:619,t:1527271886219};\\\", \\\"{x:1298,y:620,t:1527271886403};\\\", \\\"{x:1298,y:624,t:1527271886418};\\\", \\\"{x:1298,y:631,t:1527271886435};\\\", \\\"{x:1300,y:641,t:1527271886453};\\\", \\\"{x:1301,y:649,t:1527271886469};\\\", \\\"{x:1302,y:659,t:1527271886486};\\\", \\\"{x:1303,y:669,t:1527271886503};\\\", \\\"{x:1307,y:682,t:1527271886520};\\\", \\\"{x:1310,y:700,t:1527271886536};\\\", \\\"{x:1312,y:715,t:1527271886553};\\\", \\\"{x:1316,y:731,t:1527271886569};\\\", \\\"{x:1322,y:755,t:1527271886586};\\\", \\\"{x:1323,y:767,t:1527271886602};\\\", \\\"{x:1325,y:776,t:1527271886620};\\\", \\\"{x:1326,y:783,t:1527271886637};\\\", \\\"{x:1327,y:789,t:1527271886653};\\\", \\\"{x:1327,y:793,t:1527271886670};\\\", \\\"{x:1327,y:797,t:1527271886687};\\\", \\\"{x:1327,y:801,t:1527271886703};\\\", \\\"{x:1327,y:808,t:1527271886720};\\\", \\\"{x:1327,y:813,t:1527271886736};\\\", \\\"{x:1327,y:819,t:1527271886753};\\\", \\\"{x:1325,y:832,t:1527271886771};\\\", \\\"{x:1323,y:842,t:1527271886787};\\\", \\\"{x:1323,y:852,t:1527271886803};\\\", \\\"{x:1321,y:862,t:1527271886821};\\\", \\\"{x:1320,y:873,t:1527271886836};\\\", \\\"{x:1319,y:882,t:1527271886854};\\\", \\\"{x:1319,y:892,t:1527271886871};\\\", \\\"{x:1319,y:900,t:1527271886888};\\\", \\\"{x:1319,y:906,t:1527271886904};\\\", \\\"{x:1319,y:912,t:1527271886921};\\\", \\\"{x:1319,y:916,t:1527271886938};\\\", \\\"{x:1319,y:919,t:1527271886955};\\\", \\\"{x:1319,y:921,t:1527271886971};\\\", \\\"{x:1319,y:922,t:1527271886988};\\\", \\\"{x:1319,y:925,t:1527271887005};\\\", \\\"{x:1319,y:926,t:1527271887021};\\\", \\\"{x:1319,y:928,t:1527271887037};\\\", \\\"{x:1319,y:929,t:1527271887059};\\\", \\\"{x:1319,y:930,t:1527271887072};\\\", \\\"{x:1319,y:931,t:1527271887087};\\\", \\\"{x:1319,y:933,t:1527271887104};\\\", \\\"{x:1319,y:934,t:1527271887121};\\\", \\\"{x:1316,y:938,t:1527271887138};\\\", \\\"{x:1315,y:943,t:1527271887154};\\\", \\\"{x:1314,y:948,t:1527271887171};\\\", \\\"{x:1313,y:951,t:1527271887188};\\\", \\\"{x:1311,y:956,t:1527271887204};\\\", \\\"{x:1310,y:958,t:1527271887221};\\\", \\\"{x:1310,y:960,t:1527271887238};\\\", \\\"{x:1310,y:961,t:1527271887255};\\\", \\\"{x:1310,y:962,t:1527271887692};\\\", \\\"{x:1310,y:958,t:1527271887707};\\\", \\\"{x:1310,y:951,t:1527271887724};\\\", \\\"{x:1310,y:941,t:1527271887741};\\\", \\\"{x:1311,y:927,t:1527271887757};\\\", \\\"{x:1312,y:906,t:1527271887774};\\\", \\\"{x:1312,y:890,t:1527271887791};\\\", \\\"{x:1313,y:871,t:1527271887807};\\\", \\\"{x:1315,y:849,t:1527271887824};\\\", \\\"{x:1315,y:831,t:1527271887840};\\\", \\\"{x:1315,y:814,t:1527271887858};\\\", \\\"{x:1315,y:797,t:1527271887873};\\\", \\\"{x:1315,y:771,t:1527271887890};\\\", \\\"{x:1315,y:758,t:1527271887907};\\\", \\\"{x:1315,y:744,t:1527271887924};\\\", \\\"{x:1315,y:733,t:1527271887940};\\\", \\\"{x:1315,y:722,t:1527271887957};\\\", \\\"{x:1314,y:713,t:1527271887975};\\\", \\\"{x:1311,y:706,t:1527271887991};\\\", \\\"{x:1310,y:700,t:1527271888007};\\\", \\\"{x:1309,y:693,t:1527271888024};\\\", \\\"{x:1307,y:687,t:1527271888042};\\\", \\\"{x:1307,y:681,t:1527271888057};\\\", \\\"{x:1306,y:672,t:1527271888074};\\\", \\\"{x:1305,y:666,t:1527271888091};\\\", \\\"{x:1304,y:660,t:1527271888108};\\\", \\\"{x:1303,y:657,t:1527271888124};\\\", \\\"{x:1303,y:654,t:1527271888141};\\\", \\\"{x:1302,y:650,t:1527271888158};\\\", \\\"{x:1302,y:648,t:1527271888174};\\\", \\\"{x:1302,y:646,t:1527271888191};\\\", \\\"{x:1302,y:645,t:1527271888208};\\\", \\\"{x:1302,y:644,t:1527271888226};\\\", \\\"{x:1301,y:641,t:1527271888242};\\\", \\\"{x:1300,y:639,t:1527271888259};\\\", \\\"{x:1300,y:638,t:1527271888275};\\\", \\\"{x:1300,y:636,t:1527271888292};\\\", \\\"{x:1300,y:635,t:1527271888308};\\\", \\\"{x:1299,y:633,t:1527271888325};\\\", \\\"{x:1298,y:632,t:1527271888343};\\\", \\\"{x:1297,y:632,t:1527271888363};\\\", \\\"{x:1299,y:633,t:1527271888554};\\\", \\\"{x:1300,y:633,t:1527271888618};\\\", \\\"{x:1301,y:633,t:1527271888626};\\\", \\\"{x:1304,y:635,t:1527271888643};\\\", \\\"{x:1305,y:635,t:1527271888659};\\\", \\\"{x:1306,y:635,t:1527271888676};\\\", \\\"{x:1307,y:636,t:1527271888693};\\\", \\\"{x:1308,y:636,t:1527271888710};\\\", \\\"{x:1309,y:636,t:1527271888726};\\\", \\\"{x:1310,y:637,t:1527271888744};\\\", \\\"{x:1310,y:638,t:1527271888836};\\\", \\\"{x:1310,y:639,t:1527271888858};\\\", \\\"{x:1310,y:640,t:1527271888891};\\\", \\\"{x:1310,y:641,t:1527271888923};\\\", \\\"{x:1311,y:643,t:1527271888939};\\\", \\\"{x:1311,y:644,t:1527271888955};\\\", \\\"{x:1312,y:646,t:1527271888962};\\\", \\\"{x:1312,y:647,t:1527271888978};\\\", \\\"{x:1313,y:651,t:1527271888994};\\\", \\\"{x:1314,y:653,t:1527271889012};\\\", \\\"{x:1314,y:657,t:1527271889027};\\\", \\\"{x:1314,y:660,t:1527271889045};\\\", \\\"{x:1316,y:664,t:1527271889062};\\\", \\\"{x:1317,y:668,t:1527271889079};\\\", \\\"{x:1317,y:669,t:1527271889094};\\\", \\\"{x:1317,y:671,t:1527271889112};\\\", \\\"{x:1318,y:672,t:1527271889128};\\\", \\\"{x:1318,y:674,t:1527271889146};\\\", \\\"{x:1319,y:675,t:1527271889162};\\\", \\\"{x:1320,y:678,t:1527271889179};\\\", \\\"{x:1320,y:679,t:1527271889195};\\\", \\\"{x:1321,y:681,t:1527271889211};\\\", \\\"{x:1321,y:683,t:1527271889229};\\\", \\\"{x:1321,y:684,t:1527271889247};\\\", \\\"{x:1321,y:687,t:1527271889263};\\\", \\\"{x:1323,y:690,t:1527271889279};\\\", \\\"{x:1323,y:692,t:1527271889296};\\\", \\\"{x:1323,y:694,t:1527271889314};\\\", \\\"{x:1323,y:695,t:1527271889338};\\\", \\\"{x:1324,y:695,t:1527271889490};\\\", \\\"{x:1323,y:694,t:1527271890051};\\\", \\\"{x:1319,y:694,t:1527271890065};\\\", \\\"{x:1308,y:697,t:1527271890081};\\\", \\\"{x:1298,y:705,t:1527271890099};\\\", \\\"{x:1289,y:713,t:1527271890115};\\\", \\\"{x:1282,y:718,t:1527271890132};\\\", \\\"{x:1276,y:725,t:1527271890149};\\\", \\\"{x:1273,y:730,t:1527271890166};\\\", \\\"{x:1272,y:734,t:1527271890182};\\\", \\\"{x:1269,y:740,t:1527271890199};\\\", \\\"{x:1269,y:743,t:1527271890216};\\\", \\\"{x:1266,y:749,t:1527271890232};\\\", \\\"{x:1266,y:753,t:1527271890249};\\\", \\\"{x:1265,y:757,t:1527271890266};\\\", \\\"{x:1264,y:761,t:1527271890283};\\\", \\\"{x:1263,y:764,t:1527271890299};\\\", \\\"{x:1262,y:766,t:1527271890315};\\\", \\\"{x:1262,y:767,t:1527271890333};\\\", \\\"{x:1262,y:768,t:1527271890350};\\\", \\\"{x:1262,y:769,t:1527271890371};\\\", \\\"{x:1261,y:770,t:1527271890386};\\\", \\\"{x:1260,y:771,t:1527271890826};\\\", \\\"{x:1259,y:771,t:1527271890867};\\\", \\\"{x:1257,y:771,t:1527271891188};\\\", \\\"{x:1256,y:771,t:1527271891201};\\\", \\\"{x:1250,y:778,t:1527271891219};\\\", \\\"{x:1242,y:786,t:1527271891236};\\\", \\\"{x:1232,y:796,t:1527271891252};\\\", \\\"{x:1222,y:808,t:1527271891268};\\\", \\\"{x:1218,y:814,t:1527271891285};\\\", \\\"{x:1218,y:818,t:1527271891302};\\\", \\\"{x:1218,y:822,t:1527271891319};\\\", \\\"{x:1218,y:824,t:1527271891335};\\\", \\\"{x:1218,y:827,t:1527271891352};\\\", \\\"{x:1218,y:829,t:1527271891386};\\\", \\\"{x:1218,y:830,t:1527271891403};\\\", \\\"{x:1218,y:829,t:1527271894035};\\\", \\\"{x:1218,y:828,t:1527271894475};\\\", \\\"{x:1218,y:827,t:1527271894906};\\\", \\\"{x:1219,y:826,t:1527271894922};\\\", \\\"{x:1219,y:825,t:1527271894988};\\\", \\\"{x:1219,y:823,t:1527271895002};\\\", \\\"{x:1219,y:822,t:1527271895016};\\\", \\\"{x:1220,y:820,t:1527271895032};\\\", \\\"{x:1220,y:819,t:1527271895050};\\\", \\\"{x:1221,y:818,t:1527271895067};\\\", \\\"{x:1222,y:818,t:1527271895562};\\\", \\\"{x:1225,y:819,t:1527271895594};\\\", \\\"{x:1228,y:822,t:1527271895602};\\\", \\\"{x:1232,y:827,t:1527271895617};\\\", \\\"{x:1239,y:834,t:1527271895633};\\\", \\\"{x:1257,y:848,t:1527271895651};\\\", \\\"{x:1272,y:859,t:1527271895667};\\\", \\\"{x:1290,y:869,t:1527271895684};\\\", \\\"{x:1309,y:880,t:1527271895700};\\\", \\\"{x:1326,y:886,t:1527271895718};\\\", \\\"{x:1342,y:890,t:1527271895734};\\\", \\\"{x:1351,y:891,t:1527271895752};\\\", \\\"{x:1355,y:893,t:1527271895767};\\\", \\\"{x:1355,y:894,t:1527271896907};\\\", \\\"{x:1355,y:896,t:1527271896923};\\\", \\\"{x:1355,y:897,t:1527271896939};\\\", \\\"{x:1355,y:900,t:1527271896957};\\\", \\\"{x:1355,y:901,t:1527271896972};\\\", \\\"{x:1354,y:901,t:1527271897259};\\\", \\\"{x:1354,y:900,t:1527271897307};\\\", \\\"{x:1353,y:899,t:1527271897339};\\\", \\\"{x:1353,y:898,t:1527271897427};\\\", \\\"{x:1353,y:897,t:1527271897442};\\\", \\\"{x:1352,y:897,t:1527271897457};\\\", \\\"{x:1352,y:896,t:1527271897474};\\\", \\\"{x:1352,y:895,t:1527271897498};\\\", \\\"{x:1352,y:894,t:1527271897515};\\\", \\\"{x:1351,y:893,t:1527271897554};\\\", \\\"{x:1351,y:892,t:1527271897562};\\\", \\\"{x:1351,y:891,t:1527271897588};\\\", \\\"{x:1350,y:890,t:1527271897627};\\\", \\\"{x:1350,y:889,t:1527271897641};\\\", \\\"{x:1350,y:888,t:1527271897658};\\\", \\\"{x:1349,y:887,t:1527271897675};\\\", \\\"{x:1348,y:885,t:1527271897692};\\\", \\\"{x:1347,y:884,t:1527271897714};\\\", \\\"{x:1347,y:882,t:1527271897787};\\\", \\\"{x:1346,y:881,t:1527271897819};\\\", \\\"{x:1345,y:880,t:1527271897899};\\\", \\\"{x:1345,y:881,t:1527271899026};\\\", \\\"{x:1345,y:882,t:1527271899043};\\\", \\\"{x:1345,y:884,t:1527271899051};\\\", \\\"{x:1346,y:884,t:1527271899063};\\\", \\\"{x:1346,y:885,t:1527271899083};\\\", \\\"{x:1347,y:886,t:1527271899195};\\\", \\\"{x:1348,y:886,t:1527271899323};\\\", \\\"{x:1349,y:886,t:1527271899330};\\\", \\\"{x:1352,y:885,t:1527271899347};\\\", \\\"{x:1355,y:883,t:1527271899365};\\\", \\\"{x:1355,y:882,t:1527271899381};\\\", \\\"{x:1357,y:881,t:1527271899397};\\\", \\\"{x:1359,y:879,t:1527271899414};\\\", \\\"{x:1360,y:877,t:1527271899431};\\\", \\\"{x:1361,y:877,t:1527271899448};\\\", \\\"{x:1362,y:876,t:1527271899463};\\\", \\\"{x:1362,y:875,t:1527271899480};\\\", \\\"{x:1363,y:874,t:1527271899497};\\\", \\\"{x:1364,y:873,t:1527271899514};\\\", \\\"{x:1365,y:872,t:1527271899531};\\\", \\\"{x:1365,y:871,t:1527271899554};\\\", \\\"{x:1366,y:870,t:1527271899570};\\\", \\\"{x:1366,y:869,t:1527271899580};\\\", \\\"{x:1367,y:868,t:1527271899597};\\\", \\\"{x:1368,y:866,t:1527271899615};\\\", \\\"{x:1370,y:864,t:1527271899632};\\\", \\\"{x:1370,y:863,t:1527271899650};\\\", \\\"{x:1370,y:862,t:1527271899665};\\\", \\\"{x:1371,y:860,t:1527271899682};\\\", \\\"{x:1372,y:859,t:1527271899698};\\\", \\\"{x:1374,y:856,t:1527271899714};\\\", \\\"{x:1374,y:855,t:1527271899732};\\\", \\\"{x:1375,y:853,t:1527271899754};\\\", \\\"{x:1376,y:852,t:1527271899778};\\\", \\\"{x:1377,y:851,t:1527271899810};\\\", \\\"{x:1377,y:850,t:1527271899818};\\\", \\\"{x:1377,y:849,t:1527271899834};\\\", \\\"{x:1378,y:849,t:1527271899851};\\\", \\\"{x:1378,y:848,t:1527271899866};\\\", \\\"{x:1379,y:846,t:1527271899882};\\\", \\\"{x:1380,y:844,t:1527271899898};\\\", \\\"{x:1380,y:843,t:1527271899916};\\\", \\\"{x:1381,y:841,t:1527271899933};\\\", \\\"{x:1382,y:840,t:1527271899949};\\\", \\\"{x:1383,y:839,t:1527271899966};\\\", \\\"{x:1383,y:838,t:1527271899983};\\\", \\\"{x:1384,y:837,t:1527271899999};\\\", \\\"{x:1385,y:835,t:1527271900017};\\\", \\\"{x:1386,y:833,t:1527271900034};\\\", \\\"{x:1386,y:832,t:1527271900051};\\\", \\\"{x:1387,y:830,t:1527271900067};\\\", \\\"{x:1389,y:829,t:1527271900084};\\\", \\\"{x:1389,y:827,t:1527271900100};\\\", \\\"{x:1389,y:826,t:1527271900118};\\\", \\\"{x:1390,y:824,t:1527271900134};\\\", \\\"{x:1391,y:822,t:1527271900150};\\\", \\\"{x:1392,y:821,t:1527271900171};\\\", \\\"{x:1392,y:819,t:1527271900187};\\\", \\\"{x:1393,y:818,t:1527271900200};\\\", \\\"{x:1393,y:817,t:1527271900218};\\\", \\\"{x:1394,y:813,t:1527271900234};\\\", \\\"{x:1396,y:812,t:1527271900251};\\\", \\\"{x:1396,y:810,t:1527271900267};\\\", \\\"{x:1397,y:809,t:1527271900284};\\\", \\\"{x:1398,y:808,t:1527271900300};\\\", \\\"{x:1398,y:807,t:1527271900318};\\\", \\\"{x:1399,y:806,t:1527271900334};\\\", \\\"{x:1399,y:805,t:1527271900351};\\\", \\\"{x:1399,y:804,t:1527271900371};\\\", \\\"{x:1400,y:804,t:1527271900384};\\\", \\\"{x:1400,y:803,t:1527271900402};\\\", \\\"{x:1401,y:802,t:1527271900418};\\\", \\\"{x:1402,y:802,t:1527271900947};\\\", \\\"{x:1401,y:804,t:1527271900979};\\\", \\\"{x:1400,y:805,t:1527271900995};\\\", \\\"{x:1399,y:805,t:1527271901003};\\\", \\\"{x:1399,y:806,t:1527271901020};\\\", \\\"{x:1398,y:808,t:1527271901036};\\\", \\\"{x:1397,y:810,t:1527271901059};\\\", \\\"{x:1396,y:810,t:1527271901070};\\\", \\\"{x:1395,y:813,t:1527271901087};\\\", \\\"{x:1394,y:814,t:1527271901104};\\\", \\\"{x:1393,y:816,t:1527271901120};\\\", \\\"{x:1391,y:817,t:1527271901138};\\\", \\\"{x:1390,y:819,t:1527271901153};\\\", \\\"{x:1389,y:820,t:1527271901171};\\\", \\\"{x:1388,y:820,t:1527271901691};\\\", \\\"{x:1386,y:821,t:1527271901706};\\\", \\\"{x:1380,y:825,t:1527271901723};\\\", \\\"{x:1376,y:829,t:1527271901738};\\\", \\\"{x:1372,y:833,t:1527271901757};\\\", \\\"{x:1369,y:837,t:1527271901772};\\\", \\\"{x:1366,y:839,t:1527271901790};\\\", \\\"{x:1364,y:841,t:1527271901807};\\\", \\\"{x:1364,y:842,t:1527271901827};\\\", \\\"{x:1364,y:844,t:1527271901839};\\\", \\\"{x:1363,y:845,t:1527271901857};\\\", \\\"{x:1363,y:846,t:1527271902020};\\\", \\\"{x:1363,y:847,t:1527271902035};\\\", \\\"{x:1362,y:848,t:1527271902042};\\\", \\\"{x:1361,y:851,t:1527271902057};\\\", \\\"{x:1361,y:852,t:1527271902075};\\\", \\\"{x:1360,y:855,t:1527271902091};\\\", \\\"{x:1359,y:858,t:1527271902107};\\\", \\\"{x:1359,y:862,t:1527271902123};\\\", \\\"{x:1358,y:865,t:1527271902140};\\\", \\\"{x:1358,y:867,t:1527271902157};\\\", \\\"{x:1358,y:868,t:1527271902174};\\\", \\\"{x:1358,y:869,t:1527271902189};\\\", \\\"{x:1358,y:868,t:1527271902322};\\\", \\\"{x:1358,y:867,t:1527271902330};\\\", \\\"{x:1356,y:865,t:1527271902340};\\\", \\\"{x:1353,y:861,t:1527271902358};\\\", \\\"{x:1347,y:855,t:1527271902374};\\\", \\\"{x:1322,y:838,t:1527271902391};\\\", \\\"{x:1258,y:809,t:1527271902407};\\\", \\\"{x:1139,y:770,t:1527271902424};\\\", \\\"{x:989,y:726,t:1527271902440};\\\", \\\"{x:721,y:648,t:1527271902458};\\\", \\\"{x:554,y:613,t:1527271902475};\\\", \\\"{x:453,y:591,t:1527271902491};\\\", \\\"{x:418,y:586,t:1527271902502};\\\", \\\"{x:401,y:579,t:1527271902519};\\\", \\\"{x:400,y:579,t:1527271902535};\\\", \\\"{x:399,y:579,t:1527271902626};\\\", \\\"{x:399,y:577,t:1527271902642};\\\", \\\"{x:399,y:576,t:1527271902658};\\\", \\\"{x:399,y:575,t:1527271902673};\\\", \\\"{x:399,y:574,t:1527271902689};\\\", \\\"{x:399,y:573,t:1527271902706};\\\", \\\"{x:399,y:571,t:1527271902722};\\\", \\\"{x:400,y:571,t:1527271902738};\\\", \\\"{x:401,y:570,t:1527271902756};\\\", \\\"{x:405,y:567,t:1527271902774};\\\", \\\"{x:409,y:566,t:1527271902788};\\\", \\\"{x:414,y:564,t:1527271902805};\\\", \\\"{x:423,y:563,t:1527271902823};\\\", \\\"{x:436,y:560,t:1527271902839};\\\", \\\"{x:453,y:558,t:1527271902856};\\\", \\\"{x:474,y:558,t:1527271902873};\\\", \\\"{x:520,y:558,t:1527271902891};\\\", \\\"{x:565,y:558,t:1527271902906};\\\", \\\"{x:621,y:558,t:1527271902924};\\\", \\\"{x:686,y:569,t:1527271902940};\\\", \\\"{x:752,y:577,t:1527271902958};\\\", \\\"{x:824,y:586,t:1527271902973};\\\", \\\"{x:894,y:597,t:1527271902990};\\\", \\\"{x:966,y:606,t:1527271903007};\\\", \\\"{x:1030,y:616,t:1527271903023};\\\", \\\"{x:1097,y:624,t:1527271903040};\\\", \\\"{x:1156,y:626,t:1527271903057};\\\", \\\"{x:1208,y:629,t:1527271903073};\\\", \\\"{x:1273,y:638,t:1527271903090};\\\", \\\"{x:1304,y:640,t:1527271903107};\\\", \\\"{x:1332,y:645,t:1527271903123};\\\", \\\"{x:1355,y:648,t:1527271903140};\\\", \\\"{x:1375,y:651,t:1527271903157};\\\", \\\"{x:1390,y:656,t:1527271903174};\\\", \\\"{x:1402,y:661,t:1527271903190};\\\", \\\"{x:1409,y:666,t:1527271903207};\\\", \\\"{x:1411,y:667,t:1527271903225};\\\", \\\"{x:1413,y:671,t:1527271903240};\\\", \\\"{x:1414,y:674,t:1527271903258};\\\", \\\"{x:1415,y:684,t:1527271903275};\\\", \\\"{x:1415,y:691,t:1527271903291};\\\", \\\"{x:1414,y:701,t:1527271903307};\\\", \\\"{x:1411,y:713,t:1527271903325};\\\", \\\"{x:1404,y:725,t:1527271903341};\\\", \\\"{x:1398,y:736,t:1527271903358};\\\", \\\"{x:1391,y:744,t:1527271903375};\\\", \\\"{x:1382,y:754,t:1527271903391};\\\", \\\"{x:1373,y:762,t:1527271903409};\\\", \\\"{x:1364,y:770,t:1527271903424};\\\", \\\"{x:1354,y:775,t:1527271903442};\\\", \\\"{x:1345,y:782,t:1527271903459};\\\", \\\"{x:1343,y:783,t:1527271903475};\\\", \\\"{x:1342,y:785,t:1527271903492};\\\", \\\"{x:1340,y:787,t:1527271903509};\\\", \\\"{x:1338,y:789,t:1527271903524};\\\", \\\"{x:1336,y:790,t:1527271903541};\\\", \\\"{x:1333,y:792,t:1527271903558};\\\", \\\"{x:1332,y:792,t:1527271903575};\\\", \\\"{x:1329,y:793,t:1527271903592};\\\", \\\"{x:1323,y:796,t:1527271903608};\\\", \\\"{x:1318,y:797,t:1527271903625};\\\", \\\"{x:1307,y:800,t:1527271903642};\\\", \\\"{x:1302,y:803,t:1527271903658};\\\", \\\"{x:1295,y:804,t:1527271903675};\\\", \\\"{x:1290,y:805,t:1527271903692};\\\", \\\"{x:1285,y:808,t:1527271903709};\\\", \\\"{x:1280,y:808,t:1527271903725};\\\", \\\"{x:1279,y:809,t:1527271903742};\\\", \\\"{x:1277,y:810,t:1527271903760};\\\", \\\"{x:1276,y:810,t:1527271903775};\\\", \\\"{x:1275,y:811,t:1527271903793};\\\", \\\"{x:1274,y:812,t:1527271903809};\\\", \\\"{x:1273,y:812,t:1527271903826};\\\", \\\"{x:1272,y:812,t:1527271903891};\\\", \\\"{x:1271,y:812,t:1527271903899};\\\", \\\"{x:1269,y:812,t:1527271903909};\\\", \\\"{x:1266,y:812,t:1527271903926};\\\", \\\"{x:1262,y:812,t:1527271903943};\\\", \\\"{x:1254,y:812,t:1527271903959};\\\", \\\"{x:1248,y:812,t:1527271903976};\\\", \\\"{x:1245,y:812,t:1527271903993};\\\", \\\"{x:1241,y:812,t:1527271904011};\\\", \\\"{x:1240,y:812,t:1527271904027};\\\", \\\"{x:1240,y:811,t:1527271904147};\\\", \\\"{x:1240,y:810,t:1527271904160};\\\", \\\"{x:1239,y:807,t:1527271904178};\\\", \\\"{x:1239,y:799,t:1527271904195};\\\", \\\"{x:1239,y:791,t:1527271904211};\\\", \\\"{x:1239,y:781,t:1527271904228};\\\", \\\"{x:1241,y:767,t:1527271904244};\\\", \\\"{x:1243,y:754,t:1527271904261};\\\", \\\"{x:1247,y:737,t:1527271904278};\\\", \\\"{x:1253,y:721,t:1527271904294};\\\", \\\"{x:1258,y:704,t:1527271904312};\\\", \\\"{x:1260,y:693,t:1527271904327};\\\", \\\"{x:1264,y:681,t:1527271904344};\\\", \\\"{x:1267,y:673,t:1527271904361};\\\", \\\"{x:1269,y:663,t:1527271904378};\\\", \\\"{x:1271,y:658,t:1527271904395};\\\", \\\"{x:1272,y:654,t:1527271904412};\\\", \\\"{x:1273,y:651,t:1527271904428};\\\", \\\"{x:1275,y:647,t:1527271904444};\\\", \\\"{x:1276,y:645,t:1527271904462};\\\", \\\"{x:1276,y:644,t:1527271904478};\\\", \\\"{x:1276,y:642,t:1527271904495};\\\", \\\"{x:1278,y:641,t:1527271904539};\\\", \\\"{x:1278,y:640,t:1527271904554};\\\", \\\"{x:1279,y:640,t:1527271904563};\\\", \\\"{x:1282,y:638,t:1527271904579};\\\", \\\"{x:1283,y:637,t:1527271904596};\\\", \\\"{x:1285,y:635,t:1527271904612};\\\", \\\"{x:1287,y:634,t:1527271904628};\\\", \\\"{x:1288,y:633,t:1527271904646};\\\", \\\"{x:1290,y:632,t:1527271904663};\\\", \\\"{x:1292,y:631,t:1527271904679};\\\", \\\"{x:1293,y:630,t:1527271904696};\\\", \\\"{x:1294,y:630,t:1527271904712};\\\", \\\"{x:1295,y:630,t:1527271904755};\\\", \\\"{x:1296,y:630,t:1527271904771};\\\", \\\"{x:1297,y:629,t:1527271904780};\\\", \\\"{x:1298,y:629,t:1527271904826};\\\", \\\"{x:1302,y:626,t:1527271905364};\\\", \\\"{x:1307,y:625,t:1527271905381};\\\", \\\"{x:1317,y:625,t:1527271905399};\\\", \\\"{x:1322,y:625,t:1527271905416};\\\", \\\"{x:1328,y:625,t:1527271905431};\\\", \\\"{x:1331,y:625,t:1527271905448};\\\", \\\"{x:1332,y:625,t:1527271905465};\\\", \\\"{x:1331,y:625,t:1527271905755};\\\", \\\"{x:1330,y:625,t:1527271905779};\\\", \\\"{x:1330,y:626,t:1527271905787};\\\", \\\"{x:1329,y:627,t:1527271905818};\\\", \\\"{x:1328,y:627,t:1527271905850};\\\", \\\"{x:1327,y:627,t:1527271909827};\\\", \\\"{x:1321,y:630,t:1527271909843};\\\", \\\"{x:1311,y:631,t:1527271909851};\\\", \\\"{x:1300,y:631,t:1527271909862};\\\", \\\"{x:1270,y:631,t:1527271909879};\\\", \\\"{x:1217,y:631,t:1527271909896};\\\", \\\"{x:1119,y:631,t:1527271909913};\\\", \\\"{x:1009,y:618,t:1527271909929};\\\", \\\"{x:857,y:596,t:1527271909947};\\\", \\\"{x:801,y:586,t:1527271909963};\\\", \\\"{x:775,y:581,t:1527271909980};\\\", \\\"{x:769,y:580,t:1527271909990};\\\", \\\"{x:764,y:579,t:1527271910007};\\\", \\\"{x:763,y:578,t:1527271910023};\\\", \\\"{x:760,y:577,t:1527271910040};\\\", \\\"{x:757,y:577,t:1527271910057};\\\", \\\"{x:747,y:573,t:1527271910074};\\\", \\\"{x:722,y:567,t:1527271910090};\\\", \\\"{x:697,y:558,t:1527271910112};\\\", \\\"{x:681,y:550,t:1527271910128};\\\", \\\"{x:672,y:546,t:1527271910145};\\\", \\\"{x:671,y:540,t:1527271910164};\\\", \\\"{x:671,y:535,t:1527271910178};\\\", \\\"{x:682,y:525,t:1527271910195};\\\", \\\"{x:700,y:514,t:1527271910212};\\\", \\\"{x:717,y:508,t:1527271910229};\\\", \\\"{x:748,y:498,t:1527271910246};\\\", \\\"{x:782,y:494,t:1527271910262};\\\", \\\"{x:805,y:492,t:1527271910279};\\\", \\\"{x:822,y:491,t:1527271910295};\\\", \\\"{x:834,y:491,t:1527271910312};\\\", \\\"{x:845,y:491,t:1527271910329};\\\", \\\"{x:853,y:491,t:1527271910345};\\\", \\\"{x:856,y:492,t:1527271910362};\\\", \\\"{x:857,y:492,t:1527271910379};\\\", \\\"{x:858,y:492,t:1527271910427};\\\", \\\"{x:858,y:494,t:1527271910459};\\\", \\\"{x:858,y:495,t:1527271910466};\\\", \\\"{x:858,y:497,t:1527271910479};\\\", \\\"{x:858,y:499,t:1527271910496};\\\", \\\"{x:858,y:502,t:1527271910513};\\\", \\\"{x:858,y:506,t:1527271910531};\\\", \\\"{x:856,y:511,t:1527271910546};\\\", \\\"{x:852,y:519,t:1527271910562};\\\", \\\"{x:847,y:526,t:1527271910579};\\\", \\\"{x:844,y:531,t:1527271910596};\\\", \\\"{x:840,y:536,t:1527271910612};\\\", \\\"{x:838,y:537,t:1527271910630};\\\", \\\"{x:837,y:537,t:1527271910947};\\\", \\\"{x:835,y:532,t:1527271910965};\\\", \\\"{x:835,y:530,t:1527271910979};\\\", \\\"{x:835,y:529,t:1527271910996};\\\", \\\"{x:835,y:527,t:1527271911013};\\\", \\\"{x:833,y:525,t:1527271911029};\\\", \\\"{x:833,y:530,t:1527271913274};\\\", \\\"{x:833,y:535,t:1527271913283};\\\", \\\"{x:834,y:545,t:1527271913298};\\\", \\\"{x:844,y:578,t:1527271913315};\\\", \\\"{x:861,y:610,t:1527271913331};\\\", \\\"{x:902,y:668,t:1527271913349};\\\", \\\"{x:959,y:727,t:1527271913364};\\\", \\\"{x:1032,y:781,t:1527271913381};\\\", \\\"{x:1112,y:830,t:1527271913397};\\\", \\\"{x:1185,y:869,t:1527271913414};\\\", \\\"{x:1251,y:896,t:1527271913431};\\\", \\\"{x:1298,y:914,t:1527271913448};\\\", \\\"{x:1333,y:925,t:1527271913464};\\\", \\\"{x:1351,y:931,t:1527271913481};\\\", \\\"{x:1361,y:933,t:1527271913498};\\\", \\\"{x:1365,y:936,t:1527271913514};\\\", \\\"{x:1366,y:936,t:1527271913531};\\\", \\\"{x:1366,y:937,t:1527271913578};\\\", \\\"{x:1369,y:940,t:1527271913586};\\\", \\\"{x:1373,y:944,t:1527271913598};\\\", \\\"{x:1381,y:949,t:1527271913614};\\\", \\\"{x:1387,y:953,t:1527271913631};\\\", \\\"{x:1390,y:953,t:1527271913647};\\\", \\\"{x:1391,y:952,t:1527271913986};\\\", \\\"{x:1392,y:950,t:1527271913997};\\\", \\\"{x:1392,y:947,t:1527271914014};\\\", \\\"{x:1394,y:944,t:1527271914031};\\\", \\\"{x:1394,y:942,t:1527271914047};\\\", \\\"{x:1394,y:939,t:1527271914065};\\\", \\\"{x:1397,y:936,t:1527271914081};\\\", \\\"{x:1397,y:934,t:1527271914097};\\\", \\\"{x:1398,y:930,t:1527271914114};\\\", \\\"{x:1399,y:927,t:1527271914131};\\\", \\\"{x:1401,y:925,t:1527271914147};\\\", \\\"{x:1401,y:923,t:1527271914164};\\\", \\\"{x:1404,y:921,t:1527271914181};\\\", \\\"{x:1405,y:920,t:1527271914197};\\\", \\\"{x:1406,y:919,t:1527271914214};\\\", \\\"{x:1407,y:918,t:1527271914231};\\\", \\\"{x:1409,y:918,t:1527271914474};\\\", \\\"{x:1410,y:920,t:1527271914491};\\\", \\\"{x:1411,y:921,t:1527271914499};\\\", \\\"{x:1413,y:925,t:1527271914514};\\\", \\\"{x:1414,y:927,t:1527271914531};\\\", \\\"{x:1415,y:930,t:1527271914548};\\\", \\\"{x:1416,y:933,t:1527271914565};\\\", \\\"{x:1417,y:934,t:1527271914580};\\\", \\\"{x:1417,y:935,t:1527271914598};\\\", \\\"{x:1417,y:936,t:1527271914615};\\\", \\\"{x:1417,y:938,t:1527271914631};\\\", \\\"{x:1417,y:939,t:1527271914648};\\\", \\\"{x:1417,y:941,t:1527271914665};\\\", \\\"{x:1417,y:943,t:1527271914683};\\\", \\\"{x:1417,y:944,t:1527271914707};\\\", \\\"{x:1416,y:944,t:1527271914723};\\\", \\\"{x:1415,y:945,t:1527271914731};\\\", \\\"{x:1415,y:946,t:1527271914748};\\\", \\\"{x:1412,y:947,t:1527271914765};\\\", \\\"{x:1408,y:948,t:1527271914781};\\\", \\\"{x:1402,y:948,t:1527271914798};\\\", \\\"{x:1395,y:951,t:1527271914814};\\\", \\\"{x:1390,y:952,t:1527271914830};\\\", \\\"{x:1382,y:953,t:1527271914847};\\\", \\\"{x:1379,y:954,t:1527271914864};\\\", \\\"{x:1376,y:955,t:1527271914881};\\\", \\\"{x:1374,y:955,t:1527271914897};\\\", \\\"{x:1372,y:955,t:1527271914915};\\\", \\\"{x:1371,y:955,t:1527271914946};\\\", \\\"{x:1370,y:955,t:1527271914954};\\\", \\\"{x:1369,y:955,t:1527271914964};\\\", \\\"{x:1368,y:955,t:1527271914980};\\\", \\\"{x:1366,y:955,t:1527271914997};\\\", \\\"{x:1365,y:955,t:1527271915091};\\\", \\\"{x:1364,y:954,t:1527271915098};\\\", \\\"{x:1363,y:954,t:1527271915114};\\\", \\\"{x:1359,y:950,t:1527271915130};\\\", \\\"{x:1357,y:948,t:1527271915148};\\\", \\\"{x:1354,y:945,t:1527271915164};\\\", \\\"{x:1347,y:941,t:1527271915181};\\\", \\\"{x:1339,y:937,t:1527271915198};\\\", \\\"{x:1333,y:933,t:1527271915215};\\\", \\\"{x:1329,y:930,t:1527271915231};\\\", \\\"{x:1326,y:927,t:1527271915248};\\\", \\\"{x:1324,y:925,t:1527271915264};\\\", \\\"{x:1323,y:925,t:1527271915282};\\\", \\\"{x:1322,y:922,t:1527271915298};\\\", \\\"{x:1322,y:919,t:1527271915314};\\\", \\\"{x:1321,y:915,t:1527271915331};\\\", \\\"{x:1321,y:911,t:1527271915348};\\\", \\\"{x:1320,y:907,t:1527271915364};\\\", \\\"{x:1320,y:903,t:1527271915381};\\\", \\\"{x:1320,y:900,t:1527271915398};\\\", \\\"{x:1320,y:897,t:1527271915414};\\\", \\\"{x:1320,y:895,t:1527271915431};\\\", \\\"{x:1321,y:893,t:1527271915448};\\\", \\\"{x:1323,y:890,t:1527271915464};\\\", \\\"{x:1324,y:889,t:1527271915481};\\\", \\\"{x:1324,y:888,t:1527271915498};\\\", \\\"{x:1325,y:888,t:1527271915514};\\\", \\\"{x:1325,y:887,t:1527271915546};\\\", \\\"{x:1327,y:886,t:1527271915586};\\\", \\\"{x:1328,y:885,t:1527271915795};\\\", \\\"{x:1329,y:885,t:1527271915810};\\\", \\\"{x:1331,y:884,t:1527271915819};\\\", \\\"{x:1331,y:883,t:1527271915834};\\\", \\\"{x:1333,y:883,t:1527271915847};\\\", \\\"{x:1334,y:882,t:1527271915863};\\\", \\\"{x:1336,y:881,t:1527271915881};\\\", \\\"{x:1337,y:880,t:1527271915897};\\\", \\\"{x:1338,y:880,t:1527271916018};\\\", \\\"{x:1339,y:880,t:1527271916033};\\\", \\\"{x:1340,y:880,t:1527271916074};\\\", \\\"{x:1342,y:881,t:1527271916081};\\\", \\\"{x:1343,y:883,t:1527271916096};\\\", \\\"{x:1345,y:885,t:1527271916114};\\\", \\\"{x:1348,y:888,t:1527271916129};\\\", \\\"{x:1350,y:891,t:1527271916147};\\\", \\\"{x:1352,y:893,t:1527271916164};\\\", \\\"{x:1353,y:893,t:1527271916181};\\\", \\\"{x:1354,y:895,t:1527271916197};\\\", \\\"{x:1355,y:895,t:1527271916859};\\\", \\\"{x:1355,y:896,t:1527271916867};\\\", \\\"{x:1355,y:897,t:1527271916880};\\\", \\\"{x:1355,y:898,t:1527271916897};\\\", \\\"{x:1355,y:901,t:1527271916914};\\\", \\\"{x:1355,y:903,t:1527271916930};\\\", \\\"{x:1354,y:905,t:1527271916946};\\\", \\\"{x:1353,y:906,t:1527271919955};\\\", \\\"{x:1352,y:905,t:1527271920058};\\\", \\\"{x:1352,y:904,t:1527271920499};\\\", \\\"{x:1352,y:903,t:1527271920522};\\\", \\\"{x:1352,y:902,t:1527271920538};\\\", \\\"{x:1352,y:901,t:1527271920546};\\\", \\\"{x:1352,y:900,t:1527271920651};\\\", \\\"{x:1352,y:899,t:1527271920682};\\\", \\\"{x:1352,y:898,t:1527271920746};\\\", \\\"{x:1352,y:897,t:1527271920809};\\\", \\\"{x:1352,y:896,t:1527271920834};\\\", \\\"{x:1352,y:895,t:1527271920857};\\\", \\\"{x:1352,y:894,t:1527271920914};\\\", \\\"{x:1352,y:893,t:1527271920938};\\\", \\\"{x:1352,y:892,t:1527271920964};\\\", \\\"{x:1352,y:891,t:1527271921185};\\\", \\\"{x:1352,y:892,t:1527271923179};\\\", \\\"{x:1350,y:895,t:1527271923195};\\\", \\\"{x:1349,y:897,t:1527271923211};\\\", \\\"{x:1348,y:900,t:1527271923227};\\\", \\\"{x:1348,y:899,t:1527271924107};\\\", \\\"{x:1348,y:898,t:1527271924131};\\\", \\\"{x:1348,y:897,t:1527271924171};\\\", \\\"{x:1348,y:896,t:1527271924235};\\\", \\\"{x:1348,y:895,t:1527271924386};\\\", \\\"{x:1348,y:894,t:1527271924795};\\\", \\\"{x:1348,y:893,t:1527271924817};\\\", \\\"{x:1348,y:892,t:1527271924850};\\\", \\\"{x:1348,y:891,t:1527271924866};\\\", \\\"{x:1348,y:890,t:1527271925411};\\\", \\\"{x:1347,y:890,t:1527271925426};\\\", \\\"{x:1346,y:888,t:1527271925443};\\\", \\\"{x:1345,y:888,t:1527271925466};\\\", \\\"{x:1344,y:888,t:1527271925476};\\\", \\\"{x:1343,y:888,t:1527271925493};\\\", \\\"{x:1341,y:888,t:1527271925511};\\\", \\\"{x:1337,y:889,t:1527271925525};\\\", \\\"{x:1331,y:889,t:1527271925543};\\\", \\\"{x:1325,y:891,t:1527271925560};\\\", \\\"{x:1315,y:891,t:1527271925576};\\\", \\\"{x:1305,y:892,t:1527271925593};\\\", \\\"{x:1290,y:893,t:1527271925610};\\\", \\\"{x:1282,y:894,t:1527271925626};\\\", \\\"{x:1276,y:894,t:1527271925643};\\\", \\\"{x:1270,y:895,t:1527271925660};\\\", \\\"{x:1265,y:896,t:1527271925676};\\\", \\\"{x:1259,y:897,t:1527271925693};\\\", \\\"{x:1254,y:898,t:1527271925710};\\\", \\\"{x:1247,y:898,t:1527271925726};\\\", \\\"{x:1243,y:899,t:1527271925743};\\\", \\\"{x:1236,y:900,t:1527271925760};\\\", \\\"{x:1230,y:901,t:1527271925776};\\\", \\\"{x:1224,y:901,t:1527271925793};\\\", \\\"{x:1212,y:902,t:1527271925810};\\\", \\\"{x:1207,y:903,t:1527271925826};\\\", \\\"{x:1203,y:903,t:1527271925843};\\\", \\\"{x:1198,y:903,t:1527271925860};\\\", \\\"{x:1195,y:903,t:1527271925876};\\\", \\\"{x:1191,y:903,t:1527271925893};\\\", \\\"{x:1189,y:904,t:1527271925910};\\\", \\\"{x:1188,y:904,t:1527271925926};\\\", \\\"{x:1187,y:904,t:1527271926057};\\\", \\\"{x:1186,y:904,t:1527271926226};\\\", \\\"{x:1185,y:904,t:1527271926243};\\\", \\\"{x:1183,y:902,t:1527271926260};\\\", \\\"{x:1183,y:901,t:1527271926276};\\\", \\\"{x:1181,y:900,t:1527271926293};\\\", \\\"{x:1179,y:897,t:1527271926309};\\\", \\\"{x:1178,y:895,t:1527271926326};\\\", \\\"{x:1176,y:892,t:1527271926343};\\\", \\\"{x:1174,y:888,t:1527271926359};\\\", \\\"{x:1171,y:883,t:1527271926376};\\\", \\\"{x:1168,y:878,t:1527271926393};\\\", \\\"{x:1165,y:872,t:1527271926408};\\\", \\\"{x:1164,y:868,t:1527271926426};\\\", \\\"{x:1164,y:866,t:1527271926442};\\\", \\\"{x:1164,y:864,t:1527271926458};\\\", \\\"{x:1164,y:860,t:1527271926475};\\\", \\\"{x:1164,y:858,t:1527271926492};\\\", \\\"{x:1164,y:856,t:1527271926508};\\\", \\\"{x:1164,y:855,t:1527271926526};\\\", \\\"{x:1164,y:854,t:1527271926755};\\\", \\\"{x:1164,y:853,t:1527271926762};\\\", \\\"{x:1164,y:852,t:1527271926776};\\\", \\\"{x:1164,y:847,t:1527271926793};\\\", \\\"{x:1164,y:842,t:1527271926810};\\\", \\\"{x:1164,y:837,t:1527271926826};\\\", \\\"{x:1164,y:833,t:1527271926842};\\\", \\\"{x:1165,y:831,t:1527271926860};\\\", \\\"{x:1165,y:830,t:1527271926876};\\\", \\\"{x:1166,y:828,t:1527271926894};\\\", \\\"{x:1166,y:827,t:1527271926909};\\\", \\\"{x:1167,y:827,t:1527271927019};\\\", \\\"{x:1169,y:827,t:1527271927034};\\\", \\\"{x:1171,y:830,t:1527271927043};\\\", \\\"{x:1177,y:842,t:1527271927060};\\\", \\\"{x:1184,y:852,t:1527271927076};\\\", \\\"{x:1196,y:865,t:1527271927092};\\\", \\\"{x:1207,y:879,t:1527271927109};\\\", \\\"{x:1218,y:890,t:1527271927126};\\\", \\\"{x:1226,y:901,t:1527271927142};\\\", \\\"{x:1239,y:916,t:1527271927159};\\\", \\\"{x:1254,y:930,t:1527271927176};\\\", \\\"{x:1272,y:943,t:1527271927192};\\\", \\\"{x:1287,y:950,t:1527271927209};\\\", \\\"{x:1305,y:958,t:1527271927226};\\\", \\\"{x:1313,y:962,t:1527271927242};\\\", \\\"{x:1315,y:962,t:1527271927259};\\\", \\\"{x:1316,y:962,t:1527271927276};\\\", \\\"{x:1316,y:961,t:1527271927411};\\\", \\\"{x:1316,y:960,t:1527271927427};\\\", \\\"{x:1316,y:956,t:1527271927442};\\\", \\\"{x:1316,y:955,t:1527271927466};\\\", \\\"{x:1316,y:954,t:1527271927476};\\\", \\\"{x:1316,y:953,t:1527271927493};\\\", \\\"{x:1316,y:952,t:1527271927530};\\\", \\\"{x:1316,y:951,t:1527271927643};\\\", \\\"{x:1316,y:950,t:1527271927667};\\\", \\\"{x:1317,y:950,t:1527271927714};\\\", \\\"{x:1318,y:950,t:1527271927726};\\\", \\\"{x:1319,y:950,t:1527271927743};\\\", \\\"{x:1320,y:950,t:1527271927759};\\\", \\\"{x:1322,y:950,t:1527271927775};\\\", \\\"{x:1323,y:950,t:1527271927802};\\\", \\\"{x:1324,y:950,t:1527271927810};\\\", \\\"{x:1325,y:950,t:1527271927826};\\\", \\\"{x:1326,y:950,t:1527271927850};\\\", \\\"{x:1327,y:950,t:1527271927860};\\\", \\\"{x:1328,y:950,t:1527271927876};\\\", \\\"{x:1329,y:950,t:1527271928051};\\\", \\\"{x:1330,y:950,t:1527271928060};\\\", \\\"{x:1331,y:949,t:1527271928076};\\\", \\\"{x:1332,y:949,t:1527271928155};\\\", \\\"{x:1333,y:949,t:1527271928170};\\\", \\\"{x:1334,y:949,t:1527271928195};\\\", \\\"{x:1335,y:948,t:1527271928234};\\\", \\\"{x:1336,y:948,t:1527271928290};\\\", \\\"{x:1337,y:947,t:1527271928307};\\\", \\\"{x:1338,y:947,t:1527271928323};\\\", \\\"{x:1339,y:947,t:1527271928331};\\\", \\\"{x:1339,y:946,t:1527271928343};\\\", \\\"{x:1340,y:946,t:1527271928359};\\\", \\\"{x:1341,y:945,t:1527271928376};\\\", \\\"{x:1342,y:945,t:1527271928394};\\\", \\\"{x:1343,y:944,t:1527271928427};\\\", \\\"{x:1344,y:944,t:1527271928443};\\\", \\\"{x:1344,y:943,t:1527271928458};\\\", \\\"{x:1345,y:943,t:1527271928483};\\\", \\\"{x:1345,y:942,t:1527271928506};\\\", \\\"{x:1346,y:941,t:1527271928555};\\\", \\\"{x:1346,y:939,t:1527271929938};\\\", \\\"{x:1346,y:938,t:1527271929946};\\\", \\\"{x:1346,y:937,t:1527271929963};\\\", \\\"{x:1346,y:936,t:1527271929974};\\\", \\\"{x:1346,y:935,t:1527271929992};\\\", \\\"{x:1346,y:934,t:1527271930011};\\\", \\\"{x:1346,y:933,t:1527271930442};\\\", \\\"{x:1346,y:931,t:1527271930457};\\\", \\\"{x:1346,y:923,t:1527271930474};\\\", \\\"{x:1346,y:909,t:1527271930491};\\\", \\\"{x:1340,y:891,t:1527271930508};\\\", \\\"{x:1313,y:853,t:1527271930524};\\\", \\\"{x:1234,y:787,t:1527271930540};\\\", \\\"{x:1076,y:708,t:1527271930558};\\\", \\\"{x:857,y:630,t:1527271930574};\\\", \\\"{x:628,y:564,t:1527271930591};\\\", \\\"{x:413,y:511,t:1527271930608};\\\", \\\"{x:260,y:484,t:1527271930624};\\\", \\\"{x:109,y:461,t:1527271930645};\\\", \\\"{x:87,y:460,t:1527271930662};\\\", \\\"{x:84,y:460,t:1527271930679};\\\", \\\"{x:83,y:460,t:1527271930695};\\\", \\\"{x:80,y:460,t:1527271930712};\\\", \\\"{x:78,y:461,t:1527271930729};\\\", \\\"{x:78,y:463,t:1527271930754};\\\", \\\"{x:78,y:466,t:1527271930761};\\\", \\\"{x:78,y:471,t:1527271930779};\\\", \\\"{x:82,y:480,t:1527271930794};\\\", \\\"{x:93,y:493,t:1527271930812};\\\", \\\"{x:111,y:508,t:1527271930829};\\\", \\\"{x:134,y:520,t:1527271930846};\\\", \\\"{x:166,y:533,t:1527271930862};\\\", \\\"{x:203,y:545,t:1527271930880};\\\", \\\"{x:236,y:554,t:1527271930895};\\\", \\\"{x:271,y:568,t:1527271930912};\\\", \\\"{x:293,y:578,t:1527271930930};\\\", \\\"{x:310,y:586,t:1527271930946};\\\", \\\"{x:316,y:591,t:1527271930962};\\\", \\\"{x:317,y:592,t:1527271931009};\\\", \\\"{x:317,y:594,t:1527271931026};\\\", \\\"{x:317,y:595,t:1527271931033};\\\", \\\"{x:313,y:598,t:1527271931046};\\\", \\\"{x:305,y:602,t:1527271931062};\\\", \\\"{x:293,y:608,t:1527271931079};\\\", \\\"{x:280,y:616,t:1527271931096};\\\", \\\"{x:263,y:626,t:1527271931113};\\\", \\\"{x:242,y:638,t:1527271931129};\\\", \\\"{x:235,y:643,t:1527271931145};\\\", \\\"{x:234,y:644,t:1527271931162};\\\", \\\"{x:235,y:643,t:1527271931305};\\\", \\\"{x:236,y:642,t:1527271931313};\\\", \\\"{x:236,y:641,t:1527271931329};\\\", \\\"{x:243,y:639,t:1527271931345};\\\", \\\"{x:256,y:634,t:1527271931362};\\\", \\\"{x:277,y:631,t:1527271931381};\\\", \\\"{x:307,y:631,t:1527271931396};\\\", \\\"{x:352,y:631,t:1527271931412};\\\", \\\"{x:410,y:631,t:1527271931430};\\\", \\\"{x:461,y:631,t:1527271931447};\\\", \\\"{x:514,y:631,t:1527271931462};\\\", \\\"{x:554,y:631,t:1527271931479};\\\", \\\"{x:592,y:635,t:1527271931496};\\\", \\\"{x:619,y:640,t:1527271931512};\\\", \\\"{x:638,y:643,t:1527271931529};\\\", \\\"{x:659,y:645,t:1527271931545};\\\", \\\"{x:666,y:646,t:1527271931563};\\\", \\\"{x:673,y:647,t:1527271931579};\\\", \\\"{x:676,y:647,t:1527271931596};\\\", \\\"{x:677,y:647,t:1527271931612};\\\", \\\"{x:678,y:647,t:1527271931714};\\\", \\\"{x:678,y:646,t:1527271931729};\\\", \\\"{x:678,y:642,t:1527271931746};\\\", \\\"{x:678,y:634,t:1527271931763};\\\", \\\"{x:677,y:628,t:1527271931779};\\\", \\\"{x:669,y:618,t:1527271931797};\\\", \\\"{x:661,y:611,t:1527271931814};\\\", \\\"{x:650,y:604,t:1527271931830};\\\", \\\"{x:638,y:598,t:1527271931847};\\\", \\\"{x:627,y:594,t:1527271931863};\\\", \\\"{x:611,y:587,t:1527271931879};\\\", \\\"{x:595,y:581,t:1527271931897};\\\", \\\"{x:582,y:575,t:1527271931912};\\\", \\\"{x:559,y:570,t:1527271931930};\\\", \\\"{x:546,y:567,t:1527271931946};\\\", \\\"{x:532,y:563,t:1527271931963};\\\", \\\"{x:518,y:562,t:1527271931981};\\\", \\\"{x:505,y:559,t:1527271931996};\\\", \\\"{x:490,y:557,t:1527271932014};\\\", \\\"{x:475,y:556,t:1527271932030};\\\", \\\"{x:459,y:554,t:1527271932046};\\\", \\\"{x:441,y:553,t:1527271932063};\\\", \\\"{x:417,y:552,t:1527271932079};\\\", \\\"{x:391,y:551,t:1527271932096};\\\", \\\"{x:351,y:549,t:1527271932114};\\\", \\\"{x:328,y:549,t:1527271932129};\\\", \\\"{x:313,y:548,t:1527271932146};\\\", \\\"{x:309,y:547,t:1527271932163};\\\", \\\"{x:308,y:547,t:1527271932179};\\\", \\\"{x:307,y:547,t:1527271932266};\\\", \\\"{x:307,y:546,t:1527271932279};\\\", \\\"{x:303,y:545,t:1527271932296};\\\", \\\"{x:296,y:542,t:1527271932314};\\\", \\\"{x:283,y:538,t:1527271932329};\\\", \\\"{x:268,y:534,t:1527271932347};\\\", \\\"{x:249,y:531,t:1527271932363};\\\", \\\"{x:226,y:529,t:1527271932380};\\\", \\\"{x:199,y:524,t:1527271932397};\\\", \\\"{x:179,y:523,t:1527271932414};\\\", \\\"{x:162,y:519,t:1527271932431};\\\", \\\"{x:149,y:517,t:1527271932447};\\\", \\\"{x:145,y:517,t:1527271932464};\\\", \\\"{x:142,y:517,t:1527271932480};\\\", \\\"{x:141,y:517,t:1527271932498};\\\", \\\"{x:139,y:518,t:1527271932513};\\\", \\\"{x:133,y:525,t:1527271932530};\\\", \\\"{x:130,y:529,t:1527271932546};\\\", \\\"{x:128,y:532,t:1527271932563};\\\", \\\"{x:127,y:535,t:1527271932580};\\\", \\\"{x:127,y:536,t:1527271932596};\\\", \\\"{x:127,y:537,t:1527271932613};\\\", \\\"{x:127,y:538,t:1527271932630};\\\", \\\"{x:127,y:540,t:1527271932646};\\\", \\\"{x:129,y:542,t:1527271932663};\\\", \\\"{x:131,y:544,t:1527271932680};\\\", \\\"{x:132,y:545,t:1527271932697};\\\", \\\"{x:135,y:546,t:1527271932713};\\\", \\\"{x:136,y:547,t:1527271932730};\\\", \\\"{x:137,y:547,t:1527271932753};\\\", \\\"{x:138,y:547,t:1527271932777};\\\", \\\"{x:139,y:547,t:1527271932785};\\\", \\\"{x:140,y:548,t:1527271932797};\\\", \\\"{x:146,y:548,t:1527271932813};\\\", \\\"{x:149,y:548,t:1527271932830};\\\", \\\"{x:151,y:550,t:1527271932847};\\\", \\\"{x:153,y:550,t:1527271932863};\\\", \\\"{x:158,y:550,t:1527271933145};\\\", \\\"{x:173,y:552,t:1527271933153};\\\", \\\"{x:198,y:565,t:1527271933164};\\\", \\\"{x:254,y:594,t:1527271933181};\\\", \\\"{x:316,y:628,t:1527271933197};\\\", \\\"{x:395,y:668,t:1527271933215};\\\", \\\"{x:466,y:697,t:1527271933230};\\\", \\\"{x:538,y:729,t:1527271933247};\\\", \\\"{x:589,y:748,t:1527271933265};\\\", \\\"{x:629,y:759,t:1527271933281};\\\", \\\"{x:665,y:768,t:1527271933297};\\\", \\\"{x:676,y:770,t:1527271933315};\\\", \\\"{x:678,y:770,t:1527271933330};\\\", \\\"{x:677,y:770,t:1527271933459};\\\", \\\"{x:672,y:770,t:1527271933466};\\\", \\\"{x:663,y:768,t:1527271933482};\\\", \\\"{x:641,y:763,t:1527271933498};\\\", \\\"{x:593,y:748,t:1527271933514};\\\", \\\"{x:557,y:738,t:1527271933532};\\\", \\\"{x:530,y:729,t:1527271933548};\\\", \\\"{x:513,y:721,t:1527271933564};\\\", \\\"{x:497,y:717,t:1527271933581};\\\", \\\"{x:493,y:716,t:1527271933597};\\\", \\\"{x:491,y:714,t:1527271933614};\\\", \\\"{x:492,y:714,t:1527271934203};\\\", \\\"{x:493,y:714,t:1527271934214};\\\", \\\"{x:499,y:712,t:1527271934231};\\\", \\\"{x:508,y:709,t:1527271934248};\\\", \\\"{x:526,y:708,t:1527271934264};\\\", \\\"{x:551,y:705,t:1527271934281};\\\", \\\"{x:592,y:701,t:1527271934298};\\\", \\\"{x:621,y:701,t:1527271934316};\\\", \\\"{x:648,y:701,t:1527271934331};\\\", \\\"{x:673,y:697,t:1527271934349};\\\", \\\"{x:691,y:693,t:1527271934365};\\\", \\\"{x:705,y:691,t:1527271934381};\\\", \\\"{x:714,y:691,t:1527271934398};\\\", \\\"{x:720,y:689,t:1527271934416};\\\", \\\"{x:721,y:689,t:1527271934431};\\\" ] }, { \\\"rt\\\": 44568, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 395305, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-F -Z -Z -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:723,y:689,t:1527271940051};\\\", \\\"{x:728,y:689,t:1527271940057};\\\", \\\"{x:739,y:693,t:1527271940069};\\\", \\\"{x:764,y:700,t:1527271940085};\\\", \\\"{x:791,y:708,t:1527271940102};\\\", \\\"{x:818,y:714,t:1527271940119};\\\", \\\"{x:849,y:723,t:1527271940135};\\\", \\\"{x:874,y:730,t:1527271940153};\\\", \\\"{x:902,y:738,t:1527271940169};\\\", \\\"{x:916,y:742,t:1527271940186};\\\", \\\"{x:922,y:742,t:1527271940202};\\\", \\\"{x:924,y:742,t:1527271940219};\\\", \\\"{x:926,y:742,t:1527271940235};\\\", \\\"{x:930,y:744,t:1527271940252};\\\", \\\"{x:933,y:744,t:1527271940270};\\\", \\\"{x:939,y:744,t:1527271940286};\\\", \\\"{x:946,y:745,t:1527271940302};\\\", \\\"{x:956,y:746,t:1527271940319};\\\", \\\"{x:963,y:748,t:1527271940336};\\\", \\\"{x:970,y:748,t:1527271940353};\\\", \\\"{x:975,y:748,t:1527271940370};\\\", \\\"{x:979,y:747,t:1527271940386};\\\", \\\"{x:983,y:745,t:1527271940404};\\\", \\\"{x:986,y:743,t:1527271940420};\\\", \\\"{x:993,y:740,t:1527271940436};\\\", \\\"{x:998,y:737,t:1527271940453};\\\", \\\"{x:1002,y:733,t:1527271940470};\\\", \\\"{x:1006,y:730,t:1527271940487};\\\", \\\"{x:1009,y:727,t:1527271940503};\\\", \\\"{x:1012,y:725,t:1527271940520};\\\", \\\"{x:1013,y:724,t:1527271940537};\\\", \\\"{x:1014,y:724,t:1527271940553};\\\", \\\"{x:1015,y:723,t:1527271940594};\\\", \\\"{x:1015,y:722,t:1527271940699};\\\", \\\"{x:1016,y:722,t:1527271940746};\\\", \\\"{x:1016,y:721,t:1527271940787};\\\", \\\"{x:1017,y:720,t:1527271940803};\\\", \\\"{x:1019,y:719,t:1527271940820};\\\", \\\"{x:1021,y:718,t:1527271940842};\\\", \\\"{x:1024,y:716,t:1527271940857};\\\", \\\"{x:1025,y:716,t:1527271940870};\\\", \\\"{x:1029,y:714,t:1527271940887};\\\", \\\"{x:1032,y:712,t:1527271940904};\\\", \\\"{x:1034,y:711,t:1527271940919};\\\", \\\"{x:1036,y:711,t:1527271940936};\\\", \\\"{x:1037,y:710,t:1527271940954};\\\", \\\"{x:1038,y:709,t:1527271941243};\\\", \\\"{x:1039,y:710,t:1527271941254};\\\", \\\"{x:1043,y:714,t:1527271941270};\\\", \\\"{x:1047,y:719,t:1527271941287};\\\", \\\"{x:1054,y:724,t:1527271941303};\\\", \\\"{x:1067,y:733,t:1527271941320};\\\", \\\"{x:1089,y:742,t:1527271941337};\\\", \\\"{x:1136,y:754,t:1527271941354};\\\", \\\"{x:1181,y:762,t:1527271941370};\\\", \\\"{x:1217,y:769,t:1527271941387};\\\", \\\"{x:1263,y:778,t:1527271941404};\\\", \\\"{x:1305,y:790,t:1527271941420};\\\", \\\"{x:1342,y:802,t:1527271941437};\\\", \\\"{x:1383,y:814,t:1527271941454};\\\", \\\"{x:1420,y:825,t:1527271941471};\\\", \\\"{x:1448,y:832,t:1527271941487};\\\", \\\"{x:1471,y:839,t:1527271941503};\\\", \\\"{x:1499,y:847,t:1527271941521};\\\", \\\"{x:1520,y:854,t:1527271941537};\\\", \\\"{x:1543,y:863,t:1527271941555};\\\", \\\"{x:1550,y:866,t:1527271941570};\\\", \\\"{x:1553,y:868,t:1527271941587};\\\", \\\"{x:1554,y:869,t:1527271941626};\\\", \\\"{x:1554,y:870,t:1527271941651};\\\", \\\"{x:1554,y:872,t:1527271941659};\\\", \\\"{x:1553,y:872,t:1527271941675};\\\", \\\"{x:1550,y:874,t:1527271941687};\\\", \\\"{x:1544,y:878,t:1527271941705};\\\", \\\"{x:1539,y:880,t:1527271941721};\\\", \\\"{x:1527,y:887,t:1527271941737};\\\", \\\"{x:1510,y:895,t:1527271941754};\\\", \\\"{x:1498,y:903,t:1527271941770};\\\", \\\"{x:1490,y:906,t:1527271941787};\\\", \\\"{x:1485,y:908,t:1527271941804};\\\", \\\"{x:1482,y:908,t:1527271941821};\\\", \\\"{x:1478,y:908,t:1527271941839};\\\", \\\"{x:1475,y:909,t:1527271941854};\\\", \\\"{x:1471,y:911,t:1527271941871};\\\", \\\"{x:1467,y:914,t:1527271941888};\\\", \\\"{x:1464,y:916,t:1527271941905};\\\", \\\"{x:1461,y:918,t:1527271941921};\\\", \\\"{x:1460,y:919,t:1527271941937};\\\", \\\"{x:1459,y:920,t:1527271941954};\\\", \\\"{x:1459,y:921,t:1527271941971};\\\", \\\"{x:1459,y:922,t:1527271941988};\\\", \\\"{x:1459,y:924,t:1527271942004};\\\", \\\"{x:1460,y:926,t:1527271942022};\\\", \\\"{x:1462,y:931,t:1527271942038};\\\", \\\"{x:1464,y:935,t:1527271942054};\\\", \\\"{x:1466,y:938,t:1527271942071};\\\", \\\"{x:1469,y:942,t:1527271942088};\\\", \\\"{x:1470,y:944,t:1527271942104};\\\", \\\"{x:1472,y:946,t:1527271942121};\\\", \\\"{x:1472,y:948,t:1527271942138};\\\", \\\"{x:1473,y:949,t:1527271942162};\\\", \\\"{x:1474,y:949,t:1527271942179};\\\", \\\"{x:1475,y:950,t:1527271942202};\\\", \\\"{x:1478,y:951,t:1527271942227};\\\", \\\"{x:1479,y:951,t:1527271942251};\\\", \\\"{x:1480,y:952,t:1527271942259};\\\", \\\"{x:1482,y:953,t:1527271942271};\\\", \\\"{x:1486,y:954,t:1527271942289};\\\", \\\"{x:1489,y:956,t:1527271942305};\\\", \\\"{x:1495,y:957,t:1527271942321};\\\", \\\"{x:1507,y:964,t:1527271942338};\\\", \\\"{x:1517,y:966,t:1527271942355};\\\", \\\"{x:1532,y:970,t:1527271942371};\\\", \\\"{x:1550,y:972,t:1527271942388};\\\", \\\"{x:1567,y:976,t:1527271942405};\\\", \\\"{x:1582,y:979,t:1527271942422};\\\", \\\"{x:1598,y:980,t:1527271942438};\\\", \\\"{x:1606,y:980,t:1527271942455};\\\", \\\"{x:1610,y:980,t:1527271942471};\\\", \\\"{x:1611,y:980,t:1527271942498};\\\", \\\"{x:1611,y:979,t:1527271942594};\\\", \\\"{x:1611,y:978,t:1527271942610};\\\", \\\"{x:1611,y:976,t:1527271942626};\\\", \\\"{x:1611,y:975,t:1527271942638};\\\", \\\"{x:1613,y:974,t:1527271942655};\\\", \\\"{x:1613,y:971,t:1527271942671};\\\", \\\"{x:1613,y:970,t:1527271942688};\\\", \\\"{x:1613,y:967,t:1527271942705};\\\", \\\"{x:1613,y:965,t:1527271942722};\\\", \\\"{x:1613,y:960,t:1527271942739};\\\", \\\"{x:1613,y:958,t:1527271942755};\\\", \\\"{x:1613,y:957,t:1527271942771};\\\", \\\"{x:1613,y:955,t:1527271942788};\\\", \\\"{x:1613,y:954,t:1527271942826};\\\", \\\"{x:1612,y:954,t:1527271942850};\\\", \\\"{x:1612,y:953,t:1527271942867};\\\", \\\"{x:1611,y:951,t:1527271942890};\\\", \\\"{x:1611,y:950,t:1527271942947};\\\", \\\"{x:1612,y:950,t:1527271944173};\\\", \\\"{x:1613,y:950,t:1527271944221};\\\", \\\"{x:1614,y:950,t:1527271944245};\\\", \\\"{x:1616,y:951,t:1527271944260};\\\", \\\"{x:1617,y:951,t:1527271944285};\\\", \\\"{x:1618,y:951,t:1527271944293};\\\", \\\"{x:1619,y:951,t:1527271944309};\\\", \\\"{x:1617,y:951,t:1527271946631};\\\", \\\"{x:1616,y:951,t:1527271946646};\\\", \\\"{x:1613,y:951,t:1527271946662};\\\", \\\"{x:1609,y:951,t:1527271946678};\\\", \\\"{x:1607,y:951,t:1527271946695};\\\", \\\"{x:1606,y:951,t:1527271946726};\\\", \\\"{x:1604,y:951,t:1527271946934};\\\", \\\"{x:1603,y:951,t:1527271948214};\\\", \\\"{x:1602,y:951,t:1527271948229};\\\", \\\"{x:1599,y:954,t:1527271948246};\\\", \\\"{x:1597,y:955,t:1527271948263};\\\", \\\"{x:1596,y:955,t:1527271948286};\\\", \\\"{x:1595,y:956,t:1527271948296};\\\", \\\"{x:1593,y:957,t:1527271948313};\\\", \\\"{x:1592,y:958,t:1527271948329};\\\", \\\"{x:1590,y:958,t:1527271948346};\\\", \\\"{x:1586,y:959,t:1527271948363};\\\", \\\"{x:1580,y:959,t:1527271948380};\\\", \\\"{x:1571,y:959,t:1527271948397};\\\", \\\"{x:1556,y:959,t:1527271948413};\\\", \\\"{x:1542,y:959,t:1527271948430};\\\", \\\"{x:1521,y:959,t:1527271948446};\\\", \\\"{x:1510,y:959,t:1527271948464};\\\", \\\"{x:1504,y:959,t:1527271948480};\\\", \\\"{x:1500,y:959,t:1527271948497};\\\", \\\"{x:1496,y:959,t:1527271948513};\\\", \\\"{x:1493,y:959,t:1527271948528};\\\", \\\"{x:1489,y:959,t:1527271948546};\\\", \\\"{x:1486,y:959,t:1527271948562};\\\", \\\"{x:1483,y:959,t:1527271948580};\\\", \\\"{x:1483,y:958,t:1527271948596};\\\", \\\"{x:1481,y:958,t:1527271948613};\\\", \\\"{x:1480,y:958,t:1527271948645};\\\", \\\"{x:1476,y:956,t:1527271948958};\\\", \\\"{x:1471,y:953,t:1527271948966};\\\", \\\"{x:1460,y:949,t:1527271948981};\\\", \\\"{x:1443,y:946,t:1527271948997};\\\", \\\"{x:1425,y:943,t:1527271949014};\\\", \\\"{x:1414,y:942,t:1527271949030};\\\", \\\"{x:1411,y:941,t:1527271949046};\\\", \\\"{x:1413,y:940,t:1527271949279};\\\", \\\"{x:1414,y:939,t:1527271949286};\\\", \\\"{x:1415,y:939,t:1527271949302};\\\", \\\"{x:1417,y:938,t:1527271949313};\\\", \\\"{x:1417,y:937,t:1527271949330};\\\", \\\"{x:1421,y:934,t:1527271949347};\\\", \\\"{x:1431,y:924,t:1527271949363};\\\", \\\"{x:1442,y:912,t:1527271949380};\\\", \\\"{x:1456,y:900,t:1527271949397};\\\", \\\"{x:1470,y:889,t:1527271949414};\\\", \\\"{x:1486,y:869,t:1527271949430};\\\", \\\"{x:1495,y:856,t:1527271949449};\\\", \\\"{x:1498,y:847,t:1527271949463};\\\", \\\"{x:1501,y:840,t:1527271949480};\\\", \\\"{x:1503,y:831,t:1527271949498};\\\", \\\"{x:1503,y:825,t:1527271949514};\\\", \\\"{x:1503,y:822,t:1527271949531};\\\", \\\"{x:1503,y:821,t:1527271949547};\\\", \\\"{x:1503,y:819,t:1527271949564};\\\", \\\"{x:1503,y:818,t:1527271949582};\\\", \\\"{x:1503,y:817,t:1527271949694};\\\", \\\"{x:1500,y:818,t:1527271949718};\\\", \\\"{x:1499,y:818,t:1527271949733};\\\", \\\"{x:1498,y:819,t:1527271949747};\\\", \\\"{x:1496,y:821,t:1527271949764};\\\", \\\"{x:1495,y:822,t:1527271949781};\\\", \\\"{x:1493,y:826,t:1527271949798};\\\", \\\"{x:1492,y:828,t:1527271949814};\\\", \\\"{x:1492,y:829,t:1527271949831};\\\", \\\"{x:1492,y:831,t:1527271949847};\\\", \\\"{x:1492,y:832,t:1527271949864};\\\", \\\"{x:1490,y:834,t:1527271949880};\\\", \\\"{x:1489,y:835,t:1527271949897};\\\", \\\"{x:1488,y:837,t:1527271949914};\\\", \\\"{x:1487,y:838,t:1527271949930};\\\", \\\"{x:1486,y:839,t:1527271949947};\\\", \\\"{x:1485,y:839,t:1527271951927};\\\", \\\"{x:1480,y:839,t:1527271951933};\\\", \\\"{x:1475,y:839,t:1527271951950};\\\", \\\"{x:1466,y:837,t:1527271951964};\\\", \\\"{x:1459,y:835,t:1527271951982};\\\", \\\"{x:1444,y:830,t:1527271951999};\\\", \\\"{x:1425,y:822,t:1527271952015};\\\", \\\"{x:1397,y:813,t:1527271952032};\\\", \\\"{x:1347,y:800,t:1527271952049};\\\", \\\"{x:1265,y:780,t:1527271952064};\\\", \\\"{x:1156,y:764,t:1527271952082};\\\", \\\"{x:1023,y:743,t:1527271952099};\\\", \\\"{x:857,y:716,t:1527271952115};\\\", \\\"{x:705,y:694,t:1527271952132};\\\", \\\"{x:517,y:665,t:1527271952148};\\\", \\\"{x:445,y:645,t:1527271952165};\\\", \\\"{x:418,y:638,t:1527271952181};\\\", \\\"{x:410,y:633,t:1527271952198};\\\", \\\"{x:408,y:632,t:1527271952215};\\\", \\\"{x:408,y:631,t:1527271952232};\\\", \\\"{x:408,y:629,t:1527271952249};\\\", \\\"{x:409,y:626,t:1527271952266};\\\", \\\"{x:409,y:624,t:1527271952282};\\\", \\\"{x:412,y:619,t:1527271952299};\\\", \\\"{x:416,y:614,t:1527271952315};\\\", \\\"{x:423,y:606,t:1527271952333};\\\", \\\"{x:434,y:599,t:1527271952349};\\\", \\\"{x:457,y:588,t:1527271952366};\\\", \\\"{x:479,y:582,t:1527271952383};\\\", \\\"{x:504,y:575,t:1527271952399};\\\", \\\"{x:525,y:569,t:1527271952417};\\\", \\\"{x:542,y:564,t:1527271952433};\\\", \\\"{x:555,y:561,t:1527271952450};\\\", \\\"{x:562,y:558,t:1527271952467};\\\", \\\"{x:565,y:557,t:1527271952483};\\\", \\\"{x:568,y:557,t:1527271952565};\\\", \\\"{x:571,y:557,t:1527271952573};\\\", \\\"{x:575,y:557,t:1527271952583};\\\", \\\"{x:586,y:560,t:1527271952600};\\\", \\\"{x:593,y:563,t:1527271952617};\\\", \\\"{x:597,y:566,t:1527271952634};\\\", \\\"{x:599,y:568,t:1527271952650};\\\", \\\"{x:601,y:570,t:1527271952667};\\\", \\\"{x:601,y:572,t:1527271952683};\\\", \\\"{x:602,y:575,t:1527271952700};\\\", \\\"{x:606,y:580,t:1527271952717};\\\", \\\"{x:607,y:584,t:1527271952733};\\\", \\\"{x:609,y:586,t:1527271952750};\\\", \\\"{x:610,y:589,t:1527271952767};\\\", \\\"{x:612,y:591,t:1527271952784};\\\", \\\"{x:613,y:594,t:1527271952799};\\\", \\\"{x:614,y:596,t:1527271952816};\\\", \\\"{x:615,y:597,t:1527271952833};\\\", \\\"{x:616,y:598,t:1527271952850};\\\", \\\"{x:616,y:600,t:1527271953958};\\\", \\\"{x:616,y:607,t:1527271953968};\\\", \\\"{x:624,y:624,t:1527271953986};\\\", \\\"{x:642,y:650,t:1527271954001};\\\", \\\"{x:682,y:677,t:1527271954018};\\\", \\\"{x:754,y:712,t:1527271954035};\\\", \\\"{x:832,y:746,t:1527271954051};\\\", \\\"{x:918,y:771,t:1527271954068};\\\", \\\"{x:1065,y:815,t:1527271954086};\\\", \\\"{x:1109,y:824,t:1527271954102};\\\", \\\"{x:1230,y:856,t:1527271954118};\\\", \\\"{x:1297,y:875,t:1527271954135};\\\", \\\"{x:1355,y:892,t:1527271954151};\\\", \\\"{x:1400,y:906,t:1527271954168};\\\", \\\"{x:1425,y:913,t:1527271954185};\\\", \\\"{x:1444,y:918,t:1527271954201};\\\", \\\"{x:1452,y:921,t:1527271954218};\\\", \\\"{x:1454,y:922,t:1527271954235};\\\", \\\"{x:1456,y:923,t:1527271954252};\\\", \\\"{x:1457,y:924,t:1527271954268};\\\", \\\"{x:1454,y:923,t:1527271954397};\\\", \\\"{x:1449,y:922,t:1527271954405};\\\", \\\"{x:1443,y:917,t:1527271954418};\\\", \\\"{x:1432,y:915,t:1527271954435};\\\", \\\"{x:1418,y:913,t:1527271954452};\\\", \\\"{x:1402,y:912,t:1527271954468};\\\", \\\"{x:1387,y:909,t:1527271954485};\\\", \\\"{x:1385,y:908,t:1527271954502};\\\", \\\"{x:1384,y:908,t:1527271954517};\\\", \\\"{x:1383,y:908,t:1527271954582};\\\", \\\"{x:1383,y:906,t:1527271954590};\\\", \\\"{x:1381,y:906,t:1527271954602};\\\", \\\"{x:1379,y:906,t:1527271954619};\\\", \\\"{x:1372,y:905,t:1527271954635};\\\", \\\"{x:1362,y:902,t:1527271954652};\\\", \\\"{x:1355,y:900,t:1527271954668};\\\", \\\"{x:1340,y:897,t:1527271954685};\\\", \\\"{x:1332,y:896,t:1527271954702};\\\", \\\"{x:1331,y:896,t:1527271954718};\\\", \\\"{x:1330,y:893,t:1527271954990};\\\", \\\"{x:1330,y:891,t:1527271955002};\\\", \\\"{x:1330,y:883,t:1527271955019};\\\", \\\"{x:1330,y:871,t:1527271955035};\\\", \\\"{x:1330,y:862,t:1527271955052};\\\", \\\"{x:1331,y:845,t:1527271955069};\\\", \\\"{x:1334,y:834,t:1527271955084};\\\", \\\"{x:1336,y:831,t:1527271955102};\\\", \\\"{x:1337,y:826,t:1527271955118};\\\", \\\"{x:1338,y:822,t:1527271955135};\\\", \\\"{x:1339,y:819,t:1527271955152};\\\", \\\"{x:1340,y:816,t:1527271955169};\\\", \\\"{x:1342,y:813,t:1527271955186};\\\", \\\"{x:1345,y:807,t:1527271955202};\\\", \\\"{x:1348,y:802,t:1527271955219};\\\", \\\"{x:1352,y:798,t:1527271955236};\\\", \\\"{x:1357,y:792,t:1527271955252};\\\", \\\"{x:1366,y:782,t:1527271955269};\\\", \\\"{x:1372,y:776,t:1527271955285};\\\", \\\"{x:1379,y:772,t:1527271955302};\\\", \\\"{x:1391,y:767,t:1527271955319};\\\", \\\"{x:1407,y:762,t:1527271955336};\\\", \\\"{x:1422,y:759,t:1527271955352};\\\", \\\"{x:1432,y:757,t:1527271955369};\\\", \\\"{x:1439,y:757,t:1527271955386};\\\", \\\"{x:1447,y:757,t:1527271955401};\\\", \\\"{x:1450,y:757,t:1527271955419};\\\", \\\"{x:1454,y:760,t:1527271955436};\\\", \\\"{x:1458,y:764,t:1527271955452};\\\", \\\"{x:1473,y:774,t:1527271955469};\\\", \\\"{x:1490,y:784,t:1527271955485};\\\", \\\"{x:1510,y:796,t:1527271955503};\\\", \\\"{x:1529,y:807,t:1527271955519};\\\", \\\"{x:1551,y:816,t:1527271955535};\\\", \\\"{x:1566,y:822,t:1527271955552};\\\", \\\"{x:1578,y:828,t:1527271955568};\\\", \\\"{x:1584,y:831,t:1527271955586};\\\", \\\"{x:1586,y:834,t:1527271955602};\\\", \\\"{x:1589,y:836,t:1527271955619};\\\", \\\"{x:1591,y:838,t:1527271955636};\\\", \\\"{x:1592,y:839,t:1527271955653};\\\", \\\"{x:1594,y:842,t:1527271955669};\\\", \\\"{x:1596,y:845,t:1527271955686};\\\", \\\"{x:1599,y:849,t:1527271955703};\\\", \\\"{x:1602,y:854,t:1527271955719};\\\", \\\"{x:1603,y:857,t:1527271955736};\\\", \\\"{x:1604,y:862,t:1527271955753};\\\", \\\"{x:1608,y:868,t:1527271955769};\\\", \\\"{x:1608,y:874,t:1527271955786};\\\", \\\"{x:1612,y:882,t:1527271955803};\\\", \\\"{x:1613,y:889,t:1527271955819};\\\", \\\"{x:1615,y:894,t:1527271955836};\\\", \\\"{x:1616,y:898,t:1527271955853};\\\", \\\"{x:1618,y:900,t:1527271955869};\\\", \\\"{x:1618,y:901,t:1527271956079};\\\", \\\"{x:1617,y:901,t:1527271956102};\\\", \\\"{x:1616,y:901,t:1527271956109};\\\", \\\"{x:1615,y:901,t:1527271956120};\\\", \\\"{x:1614,y:901,t:1527271956166};\\\", \\\"{x:1613,y:901,t:1527271956262};\\\", \\\"{x:1612,y:901,t:1527271956269};\\\", \\\"{x:1610,y:900,t:1527271956286};\\\", \\\"{x:1607,y:892,t:1527271956304};\\\", \\\"{x:1604,y:884,t:1527271956320};\\\", \\\"{x:1600,y:876,t:1527271956337};\\\", \\\"{x:1597,y:869,t:1527271956354};\\\", \\\"{x:1594,y:861,t:1527271956370};\\\", \\\"{x:1590,y:854,t:1527271956387};\\\", \\\"{x:1588,y:850,t:1527271956404};\\\", \\\"{x:1586,y:844,t:1527271956420};\\\", \\\"{x:1582,y:835,t:1527271956438};\\\", \\\"{x:1579,y:828,t:1527271956454};\\\", \\\"{x:1577,y:822,t:1527271956471};\\\", \\\"{x:1576,y:813,t:1527271956487};\\\", \\\"{x:1574,y:807,t:1527271956504};\\\", \\\"{x:1573,y:799,t:1527271956520};\\\", \\\"{x:1572,y:790,t:1527271956537};\\\", \\\"{x:1570,y:783,t:1527271956554};\\\", \\\"{x:1569,y:774,t:1527271956570};\\\", \\\"{x:1567,y:766,t:1527271956587};\\\", \\\"{x:1566,y:759,t:1527271956603};\\\", \\\"{x:1565,y:752,t:1527271956621};\\\", \\\"{x:1563,y:740,t:1527271956637};\\\", \\\"{x:1561,y:734,t:1527271956653};\\\", \\\"{x:1559,y:729,t:1527271956671};\\\", \\\"{x:1557,y:722,t:1527271956688};\\\", \\\"{x:1554,y:716,t:1527271956703};\\\", \\\"{x:1551,y:709,t:1527271956721};\\\", \\\"{x:1546,y:701,t:1527271956738};\\\", \\\"{x:1541,y:693,t:1527271956754};\\\", \\\"{x:1536,y:685,t:1527271956770};\\\", \\\"{x:1529,y:675,t:1527271956788};\\\", \\\"{x:1524,y:665,t:1527271956804};\\\", \\\"{x:1518,y:658,t:1527271956820};\\\", \\\"{x:1513,y:648,t:1527271956837};\\\", \\\"{x:1511,y:643,t:1527271956854};\\\", \\\"{x:1510,y:641,t:1527271956870};\\\", \\\"{x:1507,y:636,t:1527271956887};\\\", \\\"{x:1505,y:634,t:1527271956903};\\\", \\\"{x:1505,y:631,t:1527271956920};\\\", \\\"{x:1503,y:630,t:1527271956937};\\\", \\\"{x:1502,y:629,t:1527271956954};\\\", \\\"{x:1502,y:628,t:1527271956981};\\\", \\\"{x:1502,y:630,t:1527271959214};\\\", \\\"{x:1499,y:635,t:1527271959223};\\\", \\\"{x:1494,y:646,t:1527271959240};\\\", \\\"{x:1487,y:655,t:1527271959255};\\\", \\\"{x:1481,y:669,t:1527271959273};\\\", \\\"{x:1474,y:677,t:1527271959289};\\\", \\\"{x:1470,y:683,t:1527271959305};\\\", \\\"{x:1469,y:685,t:1527271959323};\\\", \\\"{x:1467,y:688,t:1527271959340};\\\", \\\"{x:1466,y:690,t:1527271959356};\\\", \\\"{x:1465,y:694,t:1527271959373};\\\", \\\"{x:1463,y:698,t:1527271959389};\\\", \\\"{x:1462,y:701,t:1527271959406};\\\", \\\"{x:1460,y:704,t:1527271959423};\\\", \\\"{x:1459,y:707,t:1527271959439};\\\", \\\"{x:1459,y:708,t:1527271959462};\\\", \\\"{x:1458,y:710,t:1527271959472};\\\", \\\"{x:1458,y:712,t:1527271959489};\\\", \\\"{x:1458,y:717,t:1527271959505};\\\", \\\"{x:1456,y:723,t:1527271959523};\\\", \\\"{x:1455,y:730,t:1527271959540};\\\", \\\"{x:1454,y:739,t:1527271959556};\\\", \\\"{x:1453,y:750,t:1527271959573};\\\", \\\"{x:1451,y:760,t:1527271959589};\\\", \\\"{x:1450,y:767,t:1527271959606};\\\", \\\"{x:1449,y:775,t:1527271959622};\\\", \\\"{x:1448,y:782,t:1527271959640};\\\", \\\"{x:1448,y:787,t:1527271959656};\\\", \\\"{x:1448,y:789,t:1527271959673};\\\", \\\"{x:1448,y:790,t:1527271959690};\\\", \\\"{x:1447,y:791,t:1527271960294};\\\", \\\"{x:1444,y:791,t:1527271960306};\\\", \\\"{x:1440,y:791,t:1527271960323};\\\", \\\"{x:1427,y:791,t:1527271960339};\\\", \\\"{x:1412,y:789,t:1527271960356};\\\", \\\"{x:1401,y:786,t:1527271960373};\\\", \\\"{x:1398,y:785,t:1527271960389};\\\", \\\"{x:1397,y:784,t:1527271960406};\\\", \\\"{x:1396,y:783,t:1527271960437};\\\", \\\"{x:1395,y:783,t:1527271960453};\\\", \\\"{x:1393,y:781,t:1527271960461};\\\", \\\"{x:1392,y:781,t:1527271960474};\\\", \\\"{x:1391,y:779,t:1527271960491};\\\", \\\"{x:1389,y:779,t:1527271960507};\\\", \\\"{x:1388,y:778,t:1527271960524};\\\", \\\"{x:1388,y:777,t:1527271960540};\\\", \\\"{x:1388,y:776,t:1527271960556};\\\", \\\"{x:1387,y:772,t:1527271960575};\\\", \\\"{x:1387,y:767,t:1527271960590};\\\", \\\"{x:1387,y:763,t:1527271960609};\\\", \\\"{x:1387,y:758,t:1527271960624};\\\", \\\"{x:1387,y:752,t:1527271960640};\\\", \\\"{x:1387,y:746,t:1527271960656};\\\", \\\"{x:1387,y:741,t:1527271960673};\\\", \\\"{x:1387,y:737,t:1527271960690};\\\", \\\"{x:1387,y:731,t:1527271960706};\\\", \\\"{x:1388,y:725,t:1527271960723};\\\", \\\"{x:1390,y:719,t:1527271960740};\\\", \\\"{x:1394,y:710,t:1527271960756};\\\", \\\"{x:1397,y:701,t:1527271960773};\\\", \\\"{x:1401,y:693,t:1527271960790};\\\", \\\"{x:1404,y:687,t:1527271960806};\\\", \\\"{x:1408,y:681,t:1527271960823};\\\", \\\"{x:1412,y:674,t:1527271960841};\\\", \\\"{x:1414,y:669,t:1527271960856};\\\", \\\"{x:1416,y:662,t:1527271960874};\\\", \\\"{x:1420,y:655,t:1527271960890};\\\", \\\"{x:1422,y:651,t:1527271960906};\\\", \\\"{x:1424,y:644,t:1527271960923};\\\", \\\"{x:1426,y:635,t:1527271960940};\\\", \\\"{x:1431,y:619,t:1527271960958};\\\", \\\"{x:1434,y:607,t:1527271960973};\\\", \\\"{x:1437,y:597,t:1527271960990};\\\", \\\"{x:1441,y:586,t:1527271961008};\\\", \\\"{x:1442,y:579,t:1527271961024};\\\", \\\"{x:1445,y:570,t:1527271961040};\\\", \\\"{x:1448,y:559,t:1527271961057};\\\", \\\"{x:1451,y:554,t:1527271961074};\\\", \\\"{x:1452,y:549,t:1527271961090};\\\", \\\"{x:1454,y:545,t:1527271961107};\\\", \\\"{x:1457,y:540,t:1527271961123};\\\", \\\"{x:1458,y:537,t:1527271961140};\\\", \\\"{x:1459,y:535,t:1527271961158};\\\", \\\"{x:1459,y:534,t:1527271961173};\\\", \\\"{x:1460,y:533,t:1527271961190};\\\", \\\"{x:1461,y:533,t:1527271961208};\\\", \\\"{x:1461,y:532,t:1527271961224};\\\", \\\"{x:1462,y:532,t:1527271961245};\\\", \\\"{x:1463,y:533,t:1527271961494};\\\", \\\"{x:1464,y:535,t:1527271961507};\\\", \\\"{x:1469,y:543,t:1527271961524};\\\", \\\"{x:1474,y:551,t:1527271961540};\\\", \\\"{x:1481,y:561,t:1527271961557};\\\", \\\"{x:1485,y:565,t:1527271961575};\\\", \\\"{x:1487,y:568,t:1527271961591};\\\", \\\"{x:1488,y:569,t:1527271961608};\\\", \\\"{x:1489,y:570,t:1527271961625};\\\", \\\"{x:1491,y:572,t:1527271961641};\\\", \\\"{x:1493,y:572,t:1527271961670};\\\", \\\"{x:1493,y:573,t:1527271961694};\\\", \\\"{x:1494,y:573,t:1527271961742};\\\", \\\"{x:1495,y:574,t:1527271961758};\\\", \\\"{x:1496,y:574,t:1527271961790};\\\", \\\"{x:1497,y:575,t:1527271961806};\\\", \\\"{x:1498,y:575,t:1527271961830};\\\", \\\"{x:1499,y:575,t:1527271961854};\\\", \\\"{x:1500,y:576,t:1527271961861};\\\", \\\"{x:1502,y:576,t:1527271961885};\\\", \\\"{x:1505,y:578,t:1527271961901};\\\", \\\"{x:1507,y:578,t:1527271961918};\\\", \\\"{x:1508,y:578,t:1527271961926};\\\", \\\"{x:1510,y:579,t:1527271961942};\\\", \\\"{x:1512,y:579,t:1527271961958};\\\", \\\"{x:1515,y:579,t:1527271961975};\\\", \\\"{x:1517,y:579,t:1527271961992};\\\", \\\"{x:1518,y:580,t:1527271962008};\\\", \\\"{x:1522,y:581,t:1527271962024};\\\", \\\"{x:1523,y:581,t:1527271962042};\\\", \\\"{x:1525,y:581,t:1527271962058};\\\", \\\"{x:1528,y:581,t:1527271962075};\\\", \\\"{x:1528,y:582,t:1527271962092};\\\", \\\"{x:1530,y:582,t:1527271962108};\\\", \\\"{x:1532,y:583,t:1527271962166};\\\", \\\"{x:1532,y:584,t:1527271962238};\\\", \\\"{x:1532,y:586,t:1527271962254};\\\", \\\"{x:1532,y:588,t:1527271962262};\\\", \\\"{x:1532,y:592,t:1527271962275};\\\", \\\"{x:1532,y:600,t:1527271962291};\\\", \\\"{x:1532,y:612,t:1527271962308};\\\", \\\"{x:1529,y:626,t:1527271962324};\\\", \\\"{x:1522,y:647,t:1527271962341};\\\", \\\"{x:1516,y:661,t:1527271962358};\\\", \\\"{x:1513,y:669,t:1527271962374};\\\", \\\"{x:1510,y:674,t:1527271962391};\\\", \\\"{x:1509,y:675,t:1527271962408};\\\", \\\"{x:1508,y:675,t:1527271962502};\\\", \\\"{x:1507,y:675,t:1527271962534};\\\", \\\"{x:1506,y:675,t:1527271962558};\\\", \\\"{x:1504,y:676,t:1527271962606};\\\", \\\"{x:1504,y:677,t:1527271962622};\\\", \\\"{x:1503,y:677,t:1527271962638};\\\", \\\"{x:1503,y:678,t:1527271962654};\\\", \\\"{x:1502,y:678,t:1527271962662};\\\", \\\"{x:1501,y:680,t:1527271962678};\\\", \\\"{x:1500,y:680,t:1527271962694};\\\", \\\"{x:1500,y:681,t:1527271962709};\\\", \\\"{x:1498,y:682,t:1527271962726};\\\", \\\"{x:1497,y:683,t:1527271962742};\\\", \\\"{x:1497,y:684,t:1527271962759};\\\", \\\"{x:1496,y:684,t:1527271962776};\\\", \\\"{x:1494,y:686,t:1527271962791};\\\", \\\"{x:1491,y:689,t:1527271962808};\\\", \\\"{x:1489,y:692,t:1527271962825};\\\", \\\"{x:1487,y:693,t:1527271962842};\\\", \\\"{x:1487,y:694,t:1527271962858};\\\", \\\"{x:1487,y:692,t:1527271963270};\\\", \\\"{x:1487,y:691,t:1527271963278};\\\", \\\"{x:1487,y:689,t:1527271963293};\\\", \\\"{x:1487,y:685,t:1527271963309};\\\", \\\"{x:1487,y:679,t:1527271963326};\\\", \\\"{x:1487,y:675,t:1527271963343};\\\", \\\"{x:1487,y:673,t:1527271963359};\\\", \\\"{x:1487,y:669,t:1527271963376};\\\", \\\"{x:1487,y:668,t:1527271963393};\\\", \\\"{x:1487,y:666,t:1527271963409};\\\", \\\"{x:1487,y:665,t:1527271963425};\\\", \\\"{x:1487,y:662,t:1527271963443};\\\", \\\"{x:1487,y:659,t:1527271963459};\\\", \\\"{x:1488,y:656,t:1527271963476};\\\", \\\"{x:1488,y:653,t:1527271963493};\\\", \\\"{x:1490,y:646,t:1527271963510};\\\", \\\"{x:1492,y:639,t:1527271963525};\\\", \\\"{x:1492,y:635,t:1527271963542};\\\", \\\"{x:1492,y:628,t:1527271963559};\\\", \\\"{x:1493,y:624,t:1527271963575};\\\", \\\"{x:1494,y:617,t:1527271963592};\\\", \\\"{x:1495,y:612,t:1527271963610};\\\", \\\"{x:1496,y:606,t:1527271963626};\\\", \\\"{x:1496,y:601,t:1527271963642};\\\", \\\"{x:1498,y:595,t:1527271963659};\\\", \\\"{x:1498,y:592,t:1527271963675};\\\", \\\"{x:1499,y:587,t:1527271963692};\\\", \\\"{x:1499,y:584,t:1527271963710};\\\", \\\"{x:1499,y:583,t:1527271963726};\\\", \\\"{x:1499,y:582,t:1527271963974};\\\", \\\"{x:1496,y:582,t:1527271963990};\\\", \\\"{x:1493,y:586,t:1527271963998};\\\", \\\"{x:1491,y:589,t:1527271964011};\\\", \\\"{x:1485,y:600,t:1527271964026};\\\", \\\"{x:1475,y:616,t:1527271964042};\\\", \\\"{x:1466,y:635,t:1527271964060};\\\", \\\"{x:1460,y:651,t:1527271964076};\\\", \\\"{x:1455,y:663,t:1527271964092};\\\", \\\"{x:1453,y:676,t:1527271964109};\\\", \\\"{x:1452,y:682,t:1527271964127};\\\", \\\"{x:1451,y:688,t:1527271964143};\\\", \\\"{x:1451,y:691,t:1527271964159};\\\", \\\"{x:1450,y:695,t:1527271964176};\\\", \\\"{x:1450,y:697,t:1527271964192};\\\", \\\"{x:1450,y:698,t:1527271964210};\\\", \\\"{x:1450,y:700,t:1527271964238};\\\", \\\"{x:1448,y:701,t:1527271964246};\\\", \\\"{x:1447,y:702,t:1527271964262};\\\", \\\"{x:1446,y:704,t:1527271964278};\\\", \\\"{x:1445,y:704,t:1527271964293};\\\", \\\"{x:1440,y:707,t:1527271964310};\\\", \\\"{x:1438,y:709,t:1527271964327};\\\", \\\"{x:1437,y:709,t:1527271964343};\\\", \\\"{x:1434,y:711,t:1527271964360};\\\", \\\"{x:1433,y:711,t:1527271964377};\\\", \\\"{x:1431,y:712,t:1527271964393};\\\", \\\"{x:1430,y:712,t:1527271964422};\\\", \\\"{x:1429,y:712,t:1527271964495};\\\", \\\"{x:1428,y:712,t:1527271964509};\\\", \\\"{x:1423,y:710,t:1527271964527};\\\", \\\"{x:1419,y:707,t:1527271964544};\\\", \\\"{x:1415,y:704,t:1527271964560};\\\", \\\"{x:1411,y:701,t:1527271964577};\\\", \\\"{x:1406,y:696,t:1527271964595};\\\", \\\"{x:1402,y:693,t:1527271964610};\\\", \\\"{x:1400,y:691,t:1527271964627};\\\", \\\"{x:1396,y:688,t:1527271964644};\\\", \\\"{x:1391,y:686,t:1527271964660};\\\", \\\"{x:1389,y:684,t:1527271964677};\\\", \\\"{x:1388,y:683,t:1527271964694};\\\", \\\"{x:1387,y:683,t:1527271964710};\\\", \\\"{x:1387,y:684,t:1527271964981};\\\", \\\"{x:1387,y:686,t:1527271965013};\\\", \\\"{x:1387,y:687,t:1527271965026};\\\", \\\"{x:1390,y:691,t:1527271965043};\\\", \\\"{x:1392,y:694,t:1527271965060};\\\", \\\"{x:1394,y:697,t:1527271965076};\\\", \\\"{x:1395,y:697,t:1527271965094};\\\", \\\"{x:1395,y:698,t:1527271965230};\\\", \\\"{x:1396,y:698,t:1527271965244};\\\", \\\"{x:1397,y:698,t:1527271965261};\\\", \\\"{x:1398,y:698,t:1527271965277};\\\", \\\"{x:1399,y:698,t:1527271965294};\\\", \\\"{x:1400,y:698,t:1527271965326};\\\", \\\"{x:1402,y:698,t:1527271965798};\\\", \\\"{x:1403,y:698,t:1527271965811};\\\", \\\"{x:1406,y:697,t:1527271965828};\\\", \\\"{x:1407,y:696,t:1527271965846};\\\", \\\"{x:1410,y:694,t:1527271965861};\\\", \\\"{x:1411,y:694,t:1527271965902};\\\", \\\"{x:1411,y:693,t:1527271966174};\\\", \\\"{x:1412,y:693,t:1527271966181};\\\", \\\"{x:1413,y:692,t:1527271966197};\\\", \\\"{x:1414,y:691,t:1527271966238};\\\", \\\"{x:1415,y:690,t:1527271966254};\\\", \\\"{x:1416,y:690,t:1527271967063};\\\", \\\"{x:1417,y:691,t:1527271967079};\\\", \\\"{x:1418,y:694,t:1527271967096};\\\", \\\"{x:1419,y:699,t:1527271967112};\\\", \\\"{x:1419,y:702,t:1527271967129};\\\", \\\"{x:1420,y:711,t:1527271967146};\\\", \\\"{x:1422,y:719,t:1527271967162};\\\", \\\"{x:1424,y:728,t:1527271967179};\\\", \\\"{x:1425,y:738,t:1527271967196};\\\", \\\"{x:1426,y:752,t:1527271967212};\\\", \\\"{x:1427,y:766,t:1527271967228};\\\", \\\"{x:1427,y:782,t:1527271967245};\\\", \\\"{x:1427,y:794,t:1527271967262};\\\", \\\"{x:1427,y:804,t:1527271967279};\\\", \\\"{x:1427,y:814,t:1527271967296};\\\", \\\"{x:1424,y:827,t:1527271967312};\\\", \\\"{x:1422,y:837,t:1527271967329};\\\", \\\"{x:1420,y:845,t:1527271967346};\\\", \\\"{x:1420,y:853,t:1527271967362};\\\", \\\"{x:1418,y:861,t:1527271967379};\\\", \\\"{x:1417,y:870,t:1527271967396};\\\", \\\"{x:1416,y:879,t:1527271967413};\\\", \\\"{x:1414,y:889,t:1527271967429};\\\", \\\"{x:1414,y:897,t:1527271967445};\\\", \\\"{x:1414,y:901,t:1527271967463};\\\", \\\"{x:1414,y:904,t:1527271967479};\\\", \\\"{x:1414,y:908,t:1527271967496};\\\", \\\"{x:1414,y:911,t:1527271967513};\\\", \\\"{x:1414,y:915,t:1527271967529};\\\", \\\"{x:1414,y:917,t:1527271967546};\\\", \\\"{x:1414,y:918,t:1527271967563};\\\", \\\"{x:1414,y:919,t:1527271967579};\\\", \\\"{x:1414,y:920,t:1527271967596};\\\", \\\"{x:1414,y:921,t:1527271967613};\\\", \\\"{x:1414,y:922,t:1527271967629};\\\", \\\"{x:1414,y:923,t:1527271967646};\\\", \\\"{x:1414,y:920,t:1527271968437};\\\", \\\"{x:1414,y:919,t:1527271968447};\\\", \\\"{x:1414,y:914,t:1527271968462};\\\", \\\"{x:1414,y:912,t:1527271968480};\\\", \\\"{x:1414,y:909,t:1527271968496};\\\", \\\"{x:1414,y:908,t:1527271968512};\\\", \\\"{x:1414,y:906,t:1527271968529};\\\", \\\"{x:1414,y:904,t:1527271968547};\\\", \\\"{x:1414,y:901,t:1527271968562};\\\", \\\"{x:1414,y:900,t:1527271968580};\\\", \\\"{x:1414,y:898,t:1527271968596};\\\", \\\"{x:1414,y:897,t:1527271968613};\\\", \\\"{x:1414,y:895,t:1527271968630};\\\", \\\"{x:1414,y:894,t:1527271968653};\\\", \\\"{x:1414,y:892,t:1527271968670};\\\", \\\"{x:1414,y:891,t:1527271968686};\\\", \\\"{x:1414,y:889,t:1527271968701};\\\", \\\"{x:1414,y:888,t:1527271968718};\\\", \\\"{x:1414,y:886,t:1527271968742};\\\", \\\"{x:1414,y:885,t:1527271968757};\\\", \\\"{x:1413,y:884,t:1527271968774};\\\", \\\"{x:1413,y:883,t:1527271968782};\\\", \\\"{x:1413,y:882,t:1527271968797};\\\", \\\"{x:1413,y:880,t:1527271968814};\\\", \\\"{x:1412,y:879,t:1527271968830};\\\", \\\"{x:1412,y:877,t:1527271968886};\\\", \\\"{x:1411,y:877,t:1527271968918};\\\", \\\"{x:1411,y:876,t:1527271968958};\\\", \\\"{x:1411,y:875,t:1527271968981};\\\", \\\"{x:1411,y:874,t:1527271968998};\\\", \\\"{x:1411,y:873,t:1527271969054};\\\", \\\"{x:1411,y:871,t:1527271969166};\\\", \\\"{x:1411,y:870,t:1527271969486};\\\", \\\"{x:1411,y:868,t:1527271969502};\\\", \\\"{x:1410,y:866,t:1527271969838};\\\", \\\"{x:1409,y:866,t:1527271969853};\\\", \\\"{x:1408,y:866,t:1527271969869};\\\", \\\"{x:1406,y:868,t:1527271969880};\\\", \\\"{x:1402,y:869,t:1527271969898};\\\", \\\"{x:1399,y:871,t:1527271969913};\\\", \\\"{x:1395,y:872,t:1527271969931};\\\", \\\"{x:1394,y:873,t:1527271969947};\\\", \\\"{x:1393,y:873,t:1527271969964};\\\", \\\"{x:1392,y:874,t:1527271969980};\\\", \\\"{x:1390,y:875,t:1527271969997};\\\", \\\"{x:1389,y:875,t:1527271970014};\\\", \\\"{x:1387,y:877,t:1527271970030};\\\", \\\"{x:1384,y:877,t:1527271970048};\\\", \\\"{x:1381,y:878,t:1527271970064};\\\", \\\"{x:1379,y:879,t:1527271970080};\\\", \\\"{x:1377,y:881,t:1527271970098};\\\", \\\"{x:1374,y:882,t:1527271970113};\\\", \\\"{x:1371,y:884,t:1527271970131};\\\", \\\"{x:1370,y:886,t:1527271970149};\\\", \\\"{x:1363,y:892,t:1527271970165};\\\", \\\"{x:1361,y:893,t:1527271970181};\\\", \\\"{x:1356,y:899,t:1527271970198};\\\", \\\"{x:1352,y:901,t:1527271970215};\\\", \\\"{x:1351,y:902,t:1527271970231};\\\", \\\"{x:1349,y:903,t:1527271970248};\\\", \\\"{x:1349,y:902,t:1527271970975};\\\", \\\"{x:1349,y:900,t:1527271970981};\\\", \\\"{x:1349,y:895,t:1527271970998};\\\", \\\"{x:1349,y:891,t:1527271971015};\\\", \\\"{x:1349,y:885,t:1527271971032};\\\", \\\"{x:1351,y:880,t:1527271971050};\\\", \\\"{x:1353,y:871,t:1527271971065};\\\", \\\"{x:1355,y:858,t:1527271971082};\\\", \\\"{x:1360,y:841,t:1527271971099};\\\", \\\"{x:1366,y:817,t:1527271971115};\\\", \\\"{x:1375,y:789,t:1527271971131};\\\", \\\"{x:1391,y:723,t:1527271971148};\\\", \\\"{x:1400,y:677,t:1527271971165};\\\", \\\"{x:1409,y:628,t:1527271971181};\\\", \\\"{x:1412,y:580,t:1527271971198};\\\", \\\"{x:1413,y:537,t:1527271971214};\\\", \\\"{x:1413,y:505,t:1527271971232};\\\", \\\"{x:1413,y:485,t:1527271971249};\\\", \\\"{x:1413,y:468,t:1527271971265};\\\", \\\"{x:1413,y:461,t:1527271971282};\\\", \\\"{x:1413,y:458,t:1527271971298};\\\", \\\"{x:1413,y:455,t:1527271971314};\\\", \\\"{x:1413,y:456,t:1527271971438};\\\", \\\"{x:1413,y:460,t:1527271971450};\\\", \\\"{x:1415,y:470,t:1527271971466};\\\", \\\"{x:1418,y:479,t:1527271971482};\\\", \\\"{x:1420,y:491,t:1527271971500};\\\", \\\"{x:1424,y:501,t:1527271971517};\\\", \\\"{x:1428,y:511,t:1527271971532};\\\", \\\"{x:1428,y:517,t:1527271971550};\\\", \\\"{x:1429,y:521,t:1527271971566};\\\", \\\"{x:1431,y:522,t:1527271971583};\\\", \\\"{x:1431,y:526,t:1527271971599};\\\", \\\"{x:1432,y:528,t:1527271971616};\\\", \\\"{x:1432,y:529,t:1527271971632};\\\", \\\"{x:1433,y:532,t:1527271971649};\\\", \\\"{x:1433,y:534,t:1527271971666};\\\", \\\"{x:1433,y:536,t:1527271971682};\\\", \\\"{x:1433,y:539,t:1527271971699};\\\", \\\"{x:1434,y:546,t:1527271971716};\\\", \\\"{x:1435,y:551,t:1527271971733};\\\", \\\"{x:1436,y:556,t:1527271971750};\\\", \\\"{x:1437,y:560,t:1527271971766};\\\", \\\"{x:1437,y:561,t:1527271971782};\\\", \\\"{x:1437,y:562,t:1527271971800};\\\", \\\"{x:1437,y:564,t:1527271971816};\\\", \\\"{x:1437,y:565,t:1527271971832};\\\", \\\"{x:1437,y:566,t:1527271971849};\\\", \\\"{x:1437,y:567,t:1527271971877};\\\", \\\"{x:1437,y:568,t:1527271971894};\\\", \\\"{x:1437,y:569,t:1527271971901};\\\", \\\"{x:1435,y:570,t:1527271971917};\\\", \\\"{x:1432,y:574,t:1527271971933};\\\", \\\"{x:1431,y:574,t:1527271971949};\\\", \\\"{x:1430,y:575,t:1527271971967};\\\", \\\"{x:1428,y:576,t:1527271971983};\\\", \\\"{x:1428,y:577,t:1527271972022};\\\", \\\"{x:1427,y:577,t:1527271972045};\\\", \\\"{x:1426,y:577,t:1527271972430};\\\", \\\"{x:1425,y:577,t:1527271972437};\\\", \\\"{x:1424,y:577,t:1527271972450};\\\", \\\"{x:1423,y:576,t:1527271972466};\\\", \\\"{x:1423,y:575,t:1527271972484};\\\", \\\"{x:1422,y:573,t:1527271972501};\\\", \\\"{x:1421,y:571,t:1527271972516};\\\", \\\"{x:1420,y:569,t:1527271972533};\\\", \\\"{x:1419,y:568,t:1527271972550};\\\", \\\"{x:1419,y:567,t:1527271972566};\\\", \\\"{x:1419,y:566,t:1527271972630};\\\", \\\"{x:1419,y:565,t:1527271972650};\\\", \\\"{x:1419,y:564,t:1527271972666};\\\", \\\"{x:1419,y:563,t:1527271972685};\\\", \\\"{x:1418,y:563,t:1527271972700};\\\", \\\"{x:1418,y:562,t:1527271973494};\\\", \\\"{x:1418,y:561,t:1527271973501};\\\", \\\"{x:1418,y:558,t:1527271973519};\\\", \\\"{x:1418,y:553,t:1527271973534};\\\", \\\"{x:1420,y:547,t:1527271973550};\\\", \\\"{x:1421,y:541,t:1527271973567};\\\", \\\"{x:1424,y:535,t:1527271973584};\\\", \\\"{x:1428,y:528,t:1527271973600};\\\", \\\"{x:1430,y:521,t:1527271973618};\\\", \\\"{x:1434,y:513,t:1527271973635};\\\", \\\"{x:1439,y:503,t:1527271973650};\\\", \\\"{x:1443,y:488,t:1527271973667};\\\", \\\"{x:1448,y:472,t:1527271973685};\\\", \\\"{x:1454,y:451,t:1527271973702};\\\", \\\"{x:1457,y:438,t:1527271973718};\\\", \\\"{x:1460,y:428,t:1527271973734};\\\", \\\"{x:1463,y:419,t:1527271973751};\\\", \\\"{x:1464,y:414,t:1527271973767};\\\", \\\"{x:1466,y:409,t:1527271973784};\\\", \\\"{x:1467,y:406,t:1527271973802};\\\", \\\"{x:1467,y:402,t:1527271973817};\\\", \\\"{x:1470,y:398,t:1527271973834};\\\", \\\"{x:1470,y:396,t:1527271973851};\\\", \\\"{x:1471,y:393,t:1527271973866};\\\", \\\"{x:1472,y:390,t:1527271973884};\\\", \\\"{x:1475,y:384,t:1527271973900};\\\", \\\"{x:1475,y:380,t:1527271973917};\\\", \\\"{x:1477,y:376,t:1527271973933};\\\", \\\"{x:1478,y:372,t:1527271973950};\\\", \\\"{x:1480,y:370,t:1527271973967};\\\", \\\"{x:1481,y:368,t:1527271973983};\\\", \\\"{x:1481,y:367,t:1527271974000};\\\", \\\"{x:1481,y:366,t:1527271974028};\\\", \\\"{x:1482,y:366,t:1527271974093};\\\", \\\"{x:1483,y:365,t:1527271974109};\\\", \\\"{x:1484,y:364,t:1527271974133};\\\", \\\"{x:1485,y:362,t:1527271974165};\\\", \\\"{x:1486,y:362,t:1527271974181};\\\", \\\"{x:1487,y:361,t:1527271974188};\\\", \\\"{x:1489,y:359,t:1527271974205};\\\", \\\"{x:1492,y:357,t:1527271974217};\\\", \\\"{x:1494,y:355,t:1527271974234};\\\", \\\"{x:1498,y:351,t:1527271974250};\\\", \\\"{x:1501,y:349,t:1527271974268};\\\", \\\"{x:1505,y:343,t:1527271974284};\\\", \\\"{x:1514,y:334,t:1527271974301};\\\", \\\"{x:1519,y:327,t:1527271974318};\\\", \\\"{x:1524,y:321,t:1527271974334};\\\", \\\"{x:1529,y:314,t:1527271974351};\\\", \\\"{x:1535,y:308,t:1527271974368};\\\", \\\"{x:1539,y:304,t:1527271974384};\\\", \\\"{x:1544,y:298,t:1527271974401};\\\", \\\"{x:1547,y:295,t:1527271974418};\\\", \\\"{x:1548,y:293,t:1527271974435};\\\", \\\"{x:1551,y:290,t:1527271974451};\\\", \\\"{x:1552,y:288,t:1527271974468};\\\", \\\"{x:1553,y:287,t:1527271974484};\\\", \\\"{x:1554,y:286,t:1527271974526};\\\", \\\"{x:1554,y:288,t:1527271975109};\\\", \\\"{x:1554,y:290,t:1527271975125};\\\", \\\"{x:1554,y:291,t:1527271975135};\\\", \\\"{x:1554,y:293,t:1527271975151};\\\", \\\"{x:1554,y:294,t:1527271975168};\\\", \\\"{x:1554,y:296,t:1527271975185};\\\", \\\"{x:1554,y:297,t:1527271975201};\\\", \\\"{x:1554,y:299,t:1527271975218};\\\", \\\"{x:1554,y:300,t:1527271975235};\\\", \\\"{x:1554,y:303,t:1527271975252};\\\", \\\"{x:1554,y:306,t:1527271975268};\\\", \\\"{x:1556,y:309,t:1527271975285};\\\", \\\"{x:1556,y:312,t:1527271975302};\\\", \\\"{x:1556,y:313,t:1527271975318};\\\", \\\"{x:1556,y:318,t:1527271975335};\\\", \\\"{x:1557,y:322,t:1527271975352};\\\", \\\"{x:1558,y:328,t:1527271975368};\\\", \\\"{x:1560,y:335,t:1527271975385};\\\", \\\"{x:1562,y:342,t:1527271975402};\\\", \\\"{x:1562,y:348,t:1527271975419};\\\", \\\"{x:1562,y:352,t:1527271975435};\\\", \\\"{x:1564,y:360,t:1527271975452};\\\", \\\"{x:1566,y:374,t:1527271975469};\\\", \\\"{x:1567,y:388,t:1527271975485};\\\", \\\"{x:1570,y:404,t:1527271975502};\\\", \\\"{x:1574,y:423,t:1527271975519};\\\", \\\"{x:1575,y:437,t:1527271975535};\\\", \\\"{x:1577,y:451,t:1527271975552};\\\", \\\"{x:1579,y:465,t:1527271975568};\\\", \\\"{x:1581,y:477,t:1527271975585};\\\", \\\"{x:1582,y:488,t:1527271975602};\\\", \\\"{x:1584,y:497,t:1527271975619};\\\", \\\"{x:1584,y:504,t:1527271975635};\\\", \\\"{x:1584,y:510,t:1527271975652};\\\", \\\"{x:1585,y:520,t:1527271975669};\\\", \\\"{x:1586,y:528,t:1527271975685};\\\", \\\"{x:1586,y:535,t:1527271975702};\\\", \\\"{x:1586,y:543,t:1527271975720};\\\", \\\"{x:1586,y:552,t:1527271975735};\\\", \\\"{x:1586,y:562,t:1527271975752};\\\", \\\"{x:1586,y:569,t:1527271975770};\\\", \\\"{x:1588,y:578,t:1527271975785};\\\", \\\"{x:1589,y:586,t:1527271975802};\\\", \\\"{x:1591,y:599,t:1527271975819};\\\", \\\"{x:1593,y:610,t:1527271975837};\\\", \\\"{x:1595,y:624,t:1527271975852};\\\", \\\"{x:1598,y:651,t:1527271975868};\\\", \\\"{x:1600,y:666,t:1527271975886};\\\", \\\"{x:1603,y:679,t:1527271975901};\\\", \\\"{x:1604,y:689,t:1527271975919};\\\", \\\"{x:1605,y:694,t:1527271975936};\\\", \\\"{x:1606,y:700,t:1527271975952};\\\", \\\"{x:1607,y:708,t:1527271975968};\\\", \\\"{x:1607,y:714,t:1527271975985};\\\", \\\"{x:1608,y:723,t:1527271976002};\\\", \\\"{x:1609,y:730,t:1527271976019};\\\", \\\"{x:1609,y:736,t:1527271976036};\\\", \\\"{x:1609,y:741,t:1527271976052};\\\", \\\"{x:1609,y:750,t:1527271976069};\\\", \\\"{x:1609,y:755,t:1527271976085};\\\", \\\"{x:1609,y:759,t:1527271976102};\\\", \\\"{x:1609,y:760,t:1527271976119};\\\", \\\"{x:1609,y:761,t:1527271976136};\\\", \\\"{x:1610,y:763,t:1527271976152};\\\", \\\"{x:1611,y:764,t:1527271976170};\\\", \\\"{x:1611,y:765,t:1527271976186};\\\", \\\"{x:1611,y:766,t:1527271976202};\\\", \\\"{x:1611,y:770,t:1527271976220};\\\", \\\"{x:1611,y:774,t:1527271976236};\\\", \\\"{x:1611,y:779,t:1527271976252};\\\", \\\"{x:1611,y:786,t:1527271976269};\\\", \\\"{x:1611,y:790,t:1527271976286};\\\", \\\"{x:1611,y:794,t:1527271976302};\\\", \\\"{x:1611,y:796,t:1527271976319};\\\", \\\"{x:1611,y:799,t:1527271976336};\\\", \\\"{x:1611,y:802,t:1527271976354};\\\", \\\"{x:1611,y:805,t:1527271976370};\\\", \\\"{x:1611,y:806,t:1527271976386};\\\", \\\"{x:1611,y:807,t:1527271976403};\\\", \\\"{x:1611,y:808,t:1527271976421};\\\", \\\"{x:1611,y:809,t:1527271976446};\\\", \\\"{x:1611,y:811,t:1527271977830};\\\", \\\"{x:1611,y:812,t:1527271977837};\\\", \\\"{x:1611,y:818,t:1527271977853};\\\", \\\"{x:1610,y:823,t:1527271977870};\\\", \\\"{x:1610,y:833,t:1527271977888};\\\", \\\"{x:1608,y:840,t:1527271977905};\\\", \\\"{x:1607,y:847,t:1527271977921};\\\", \\\"{x:1606,y:855,t:1527271977937};\\\", \\\"{x:1605,y:860,t:1527271977954};\\\", \\\"{x:1605,y:864,t:1527271977971};\\\", \\\"{x:1605,y:866,t:1527271977987};\\\", \\\"{x:1605,y:867,t:1527271978004};\\\", \\\"{x:1604,y:863,t:1527271978414};\\\", \\\"{x:1603,y:860,t:1527271978422};\\\", \\\"{x:1599,y:848,t:1527271978437};\\\", \\\"{x:1596,y:833,t:1527271978453};\\\", \\\"{x:1588,y:810,t:1527271978471};\\\", \\\"{x:1581,y:787,t:1527271978487};\\\", \\\"{x:1575,y:764,t:1527271978504};\\\", \\\"{x:1563,y:737,t:1527271978521};\\\", \\\"{x:1550,y:714,t:1527271978538};\\\", \\\"{x:1534,y:687,t:1527271978554};\\\", \\\"{x:1521,y:668,t:1527271978571};\\\", \\\"{x:1506,y:650,t:1527271978589};\\\", \\\"{x:1494,y:636,t:1527271978604};\\\", \\\"{x:1467,y:612,t:1527271978621};\\\", \\\"{x:1444,y:597,t:1527271978638};\\\", \\\"{x:1385,y:565,t:1527271978654};\\\", \\\"{x:1291,y:525,t:1527271978671};\\\", \\\"{x:1174,y:490,t:1527271978688};\\\", \\\"{x:1028,y:453,t:1527271978704};\\\", \\\"{x:898,y:432,t:1527271978721};\\\", \\\"{x:790,y:420,t:1527271978739};\\\", \\\"{x:717,y:416,t:1527271978755};\\\", \\\"{x:681,y:416,t:1527271978771};\\\", \\\"{x:661,y:416,t:1527271978788};\\\", \\\"{x:645,y:424,t:1527271978804};\\\", \\\"{x:623,y:443,t:1527271978821};\\\", \\\"{x:606,y:460,t:1527271978839};\\\", \\\"{x:575,y:484,t:1527271978854};\\\", \\\"{x:531,y:520,t:1527271978872};\\\", \\\"{x:485,y:568,t:1527271978888};\\\", \\\"{x:441,y:632,t:1527271978905};\\\", \\\"{x:394,y:762,t:1527271978939};\\\", \\\"{x:391,y:819,t:1527271978954};\\\", \\\"{x:389,y:876,t:1527271978971};\\\", \\\"{x:396,y:904,t:1527271978988};\\\", \\\"{x:411,y:928,t:1527271979004};\\\", \\\"{x:415,y:934,t:1527271979021};\\\", \\\"{x:416,y:935,t:1527271979038};\\\", \\\"{x:417,y:935,t:1527271979054};\\\", \\\"{x:417,y:932,t:1527271979117};\\\", \\\"{x:417,y:924,t:1527271979125};\\\", \\\"{x:417,y:908,t:1527271979138};\\\", \\\"{x:417,y:882,t:1527271979155};\\\", \\\"{x:423,y:848,t:1527271979172};\\\", \\\"{x:430,y:815,t:1527271979188};\\\", \\\"{x:444,y:772,t:1527271979205};\\\", \\\"{x:451,y:751,t:1527271979222};\\\", \\\"{x:455,y:735,t:1527271979239};\\\", \\\"{x:463,y:721,t:1527271979254};\\\", \\\"{x:472,y:709,t:1527271979271};\\\", \\\"{x:477,y:704,t:1527271979288};\\\", \\\"{x:481,y:701,t:1527271979305};\\\", \\\"{x:482,y:699,t:1527271979321};\\\", \\\"{x:483,y:700,t:1527271979614};\\\", \\\"{x:483,y:701,t:1527271979624};\\\", \\\"{x:484,y:706,t:1527271979638};\\\", \\\"{x:484,y:708,t:1527271979655};\\\", \\\"{x:484,y:710,t:1527271979672};\\\", \\\"{x:484,y:711,t:1527271979689};\\\", \\\"{x:486,y:712,t:1527271980350};\\\", \\\"{x:494,y:711,t:1527271980357};\\\", \\\"{x:506,y:707,t:1527271980372};\\\", \\\"{x:562,y:688,t:1527271980389};\\\", \\\"{x:621,y:671,t:1527271980406};\\\", \\\"{x:671,y:657,t:1527271980423};\\\", \\\"{x:711,y:644,t:1527271980439};\\\", \\\"{x:737,y:635,t:1527271980456};\\\", \\\"{x:751,y:627,t:1527271980473};\\\", \\\"{x:761,y:624,t:1527271980489};\\\" ] }, { \\\"rt\\\": 60009, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 456535, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -O -Z -12 PM-12 PM-Z -O -O -H -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:766,y:618,t:1527271981240};\\\", \\\"{x:777,y:610,t:1527271981256};\\\", \\\"{x:785,y:603,t:1527271981273};\\\", \\\"{x:806,y:587,t:1527271981303};\\\", \\\"{x:811,y:582,t:1527271981309};\\\", \\\"{x:815,y:578,t:1527271981322};\\\", \\\"{x:821,y:574,t:1527271981340};\\\", \\\"{x:827,y:569,t:1527271981356};\\\", \\\"{x:828,y:568,t:1527271981373};\\\", \\\"{x:829,y:568,t:1527271981397};\\\", \\\"{x:830,y:567,t:1527271981407};\\\", \\\"{x:830,y:566,t:1527271981605};\\\", \\\"{x:827,y:564,t:1527271981615};\\\", \\\"{x:823,y:563,t:1527271981624};\\\", \\\"{x:812,y:558,t:1527271981640};\\\", \\\"{x:796,y:550,t:1527271981657};\\\", \\\"{x:774,y:539,t:1527271981674};\\\", \\\"{x:756,y:530,t:1527271981690};\\\", \\\"{x:646,y:476,t:1527271981785};\\\", \\\"{x:633,y:470,t:1527271981790};\\\", \\\"{x:612,y:461,t:1527271981807};\\\", \\\"{x:592,y:455,t:1527271981824};\\\", \\\"{x:573,y:449,t:1527271981840};\\\", \\\"{x:552,y:445,t:1527271981857};\\\", \\\"{x:527,y:443,t:1527271981874};\\\", \\\"{x:494,y:439,t:1527271981890};\\\", \\\"{x:455,y:439,t:1527271981907};\\\", \\\"{x:421,y:439,t:1527271981924};\\\", \\\"{x:392,y:439,t:1527271981940};\\\", \\\"{x:351,y:439,t:1527271981957};\\\", \\\"{x:334,y:439,t:1527271981974};\\\", \\\"{x:322,y:443,t:1527271981990};\\\", \\\"{x:320,y:444,t:1527271982007};\\\", \\\"{x:317,y:445,t:1527271982024};\\\", \\\"{x:317,y:446,t:1527271982118};\\\", \\\"{x:318,y:447,t:1527271982125};\\\", \\\"{x:320,y:448,t:1527271982140};\\\", \\\"{x:331,y:453,t:1527271982157};\\\", \\\"{x:346,y:458,t:1527271982174};\\\", \\\"{x:361,y:462,t:1527271982191};\\\", \\\"{x:381,y:467,t:1527271982207};\\\", \\\"{x:397,y:467,t:1527271982224};\\\", \\\"{x:411,y:467,t:1527271982241};\\\", \\\"{x:422,y:467,t:1527271982257};\\\", \\\"{x:435,y:467,t:1527271982274};\\\", \\\"{x:449,y:467,t:1527271982291};\\\", \\\"{x:461,y:467,t:1527271982307};\\\", \\\"{x:475,y:467,t:1527271982324};\\\", \\\"{x:500,y:469,t:1527271982341};\\\", \\\"{x:515,y:472,t:1527271982357};\\\", \\\"{x:532,y:473,t:1527271982373};\\\", \\\"{x:546,y:474,t:1527271982391};\\\", \\\"{x:558,y:474,t:1527271982407};\\\", \\\"{x:567,y:474,t:1527271982424};\\\", \\\"{x:572,y:474,t:1527271982441};\\\", \\\"{x:574,y:474,t:1527271982457};\\\", \\\"{x:576,y:474,t:1527271982474};\\\", \\\"{x:577,y:474,t:1527271982493};\\\", \\\"{x:578,y:474,t:1527271982509};\\\", \\\"{x:579,y:474,t:1527271982524};\\\", \\\"{x:582,y:474,t:1527271982541};\\\", \\\"{x:583,y:473,t:1527271982557};\\\", \\\"{x:585,y:473,t:1527271982574};\\\", \\\"{x:586,y:473,t:1527271982591};\\\", \\\"{x:588,y:473,t:1527271982608};\\\", \\\"{x:589,y:472,t:1527271982624};\\\", \\\"{x:592,y:472,t:1527271982642};\\\", \\\"{x:594,y:472,t:1527271982659};\\\", \\\"{x:595,y:472,t:1527271982677};\\\", \\\"{x:596,y:472,t:1527271983069};\\\", \\\"{x:597,y:470,t:1527271983116};\\\", \\\"{x:602,y:469,t:1527271983124};\\\", \\\"{x:611,y:469,t:1527271983141};\\\", \\\"{x:625,y:469,t:1527271983158};\\\", \\\"{x:640,y:469,t:1527271983175};\\\", \\\"{x:650,y:469,t:1527271983191};\\\", \\\"{x:657,y:469,t:1527271983208};\\\", \\\"{x:660,y:469,t:1527271983225};\\\", \\\"{x:661,y:469,t:1527271983241};\\\", \\\"{x:658,y:469,t:1527271983469};\\\", \\\"{x:651,y:469,t:1527271983477};\\\", \\\"{x:642,y:472,t:1527271983492};\\\", \\\"{x:627,y:476,t:1527271983508};\\\", \\\"{x:605,y:485,t:1527271983525};\\\", \\\"{x:593,y:491,t:1527271983542};\\\", \\\"{x:585,y:496,t:1527271983558};\\\", \\\"{x:576,y:500,t:1527271983575};\\\", \\\"{x:569,y:504,t:1527271983593};\\\", \\\"{x:561,y:505,t:1527271983608};\\\", \\\"{x:548,y:509,t:1527271983626};\\\", \\\"{x:531,y:511,t:1527271983642};\\\", \\\"{x:518,y:513,t:1527271983659};\\\", \\\"{x:504,y:518,t:1527271983675};\\\", \\\"{x:495,y:519,t:1527271983692};\\\", \\\"{x:491,y:519,t:1527271983708};\\\", \\\"{x:490,y:520,t:1527271983727};\\\", \\\"{x:489,y:520,t:1527271983901};\\\", \\\"{x:488,y:520,t:1527271983909};\\\", \\\"{x:484,y:518,t:1527271983925};\\\", \\\"{x:475,y:514,t:1527271983942};\\\", \\\"{x:466,y:509,t:1527271983958};\\\", \\\"{x:461,y:506,t:1527271983975};\\\", \\\"{x:458,y:505,t:1527271983992};\\\", \\\"{x:456,y:504,t:1527271984010};\\\", \\\"{x:455,y:502,t:1527271984110};\\\", \\\"{x:455,y:501,t:1527271984166};\\\", \\\"{x:457,y:500,t:1527271984182};\\\", \\\"{x:458,y:498,t:1527271984193};\\\", \\\"{x:462,y:498,t:1527271984210};\\\", \\\"{x:466,y:498,t:1527271984225};\\\", \\\"{x:469,y:498,t:1527271984243};\\\", \\\"{x:473,y:497,t:1527271984259};\\\", \\\"{x:476,y:497,t:1527271984275};\\\", \\\"{x:478,y:497,t:1527271984292};\\\", \\\"{x:483,y:497,t:1527271984309};\\\", \\\"{x:486,y:496,t:1527271984327};\\\", \\\"{x:489,y:496,t:1527271984343};\\\", \\\"{x:494,y:496,t:1527271984360};\\\", \\\"{x:499,y:496,t:1527271984376};\\\", \\\"{x:502,y:496,t:1527271984392};\\\", \\\"{x:504,y:495,t:1527271984410};\\\", \\\"{x:506,y:495,t:1527271984426};\\\", \\\"{x:507,y:494,t:1527271984443};\\\", \\\"{x:509,y:494,t:1527271984460};\\\", \\\"{x:512,y:494,t:1527271984476};\\\", \\\"{x:516,y:494,t:1527271984492};\\\", \\\"{x:523,y:494,t:1527271984509};\\\", \\\"{x:527,y:494,t:1527271984526};\\\", \\\"{x:531,y:494,t:1527271984543};\\\", \\\"{x:536,y:494,t:1527271984559};\\\", \\\"{x:540,y:494,t:1527271984576};\\\", \\\"{x:546,y:494,t:1527271984592};\\\", \\\"{x:550,y:494,t:1527271984610};\\\", \\\"{x:554,y:494,t:1527271984627};\\\", \\\"{x:560,y:494,t:1527271984643};\\\", \\\"{x:565,y:494,t:1527271984659};\\\", \\\"{x:572,y:494,t:1527271984677};\\\", \\\"{x:583,y:495,t:1527271984693};\\\", \\\"{x:600,y:497,t:1527271984709};\\\", \\\"{x:614,y:500,t:1527271984727};\\\", \\\"{x:627,y:502,t:1527271984743};\\\", \\\"{x:639,y:503,t:1527271984759};\\\", \\\"{x:653,y:505,t:1527271984776};\\\", \\\"{x:663,y:505,t:1527271984794};\\\", \\\"{x:675,y:507,t:1527271984810};\\\", \\\"{x:682,y:507,t:1527271984827};\\\", \\\"{x:685,y:507,t:1527271984843};\\\", \\\"{x:688,y:507,t:1527271984860};\\\", \\\"{x:689,y:507,t:1527271984876};\\\", \\\"{x:693,y:507,t:1527271985381};\\\", \\\"{x:703,y:512,t:1527271985393};\\\", \\\"{x:738,y:526,t:1527271985412};\\\", \\\"{x:806,y:549,t:1527271985427};\\\", \\\"{x:904,y:573,t:1527271985443};\\\", \\\"{x:1024,y:594,t:1527271985461};\\\", \\\"{x:1163,y:613,t:1527271985476};\\\", \\\"{x:1347,y:638,t:1527271985493};\\\", \\\"{x:1456,y:662,t:1527271985510};\\\", \\\"{x:1552,y:684,t:1527271985526};\\\", \\\"{x:1621,y:699,t:1527271985543};\\\", \\\"{x:1671,y:712,t:1527271985560};\\\", \\\"{x:1703,y:722,t:1527271985576};\\\", \\\"{x:1726,y:727,t:1527271985593};\\\", \\\"{x:1742,y:733,t:1527271985610};\\\", \\\"{x:1750,y:735,t:1527271985627};\\\", \\\"{x:1753,y:737,t:1527271985644};\\\", \\\"{x:1753,y:738,t:1527271985660};\\\", \\\"{x:1754,y:739,t:1527271985709};\\\", \\\"{x:1754,y:741,t:1527271985734};\\\", \\\"{x:1753,y:741,t:1527271985749};\\\", \\\"{x:1752,y:742,t:1527271985766};\\\", \\\"{x:1751,y:743,t:1527271985778};\\\", \\\"{x:1750,y:743,t:1527271985793};\\\", \\\"{x:1749,y:744,t:1527271985811};\\\", \\\"{x:1747,y:745,t:1527271985828};\\\", \\\"{x:1746,y:746,t:1527271985845};\\\", \\\"{x:1746,y:747,t:1527271985861};\\\", \\\"{x:1744,y:747,t:1527271985878};\\\", \\\"{x:1741,y:747,t:1527271985894};\\\", \\\"{x:1737,y:747,t:1527271985910};\\\", \\\"{x:1733,y:747,t:1527271985927};\\\", \\\"{x:1730,y:747,t:1527271985944};\\\", \\\"{x:1727,y:747,t:1527271985960};\\\", \\\"{x:1726,y:747,t:1527271985978};\\\", \\\"{x:1724,y:747,t:1527271986326};\\\", \\\"{x:1721,y:747,t:1527271986334};\\\", \\\"{x:1718,y:747,t:1527271986345};\\\", \\\"{x:1710,y:744,t:1527271986361};\\\", \\\"{x:1698,y:738,t:1527271986377};\\\", \\\"{x:1686,y:731,t:1527271986395};\\\", \\\"{x:1678,y:728,t:1527271986410};\\\", \\\"{x:1666,y:723,t:1527271986427};\\\", \\\"{x:1659,y:721,t:1527271986444};\\\", \\\"{x:1656,y:720,t:1527271986460};\\\", \\\"{x:1655,y:719,t:1527271986477};\\\", \\\"{x:1653,y:719,t:1527271986494};\\\", \\\"{x:1652,y:719,t:1527271986654};\\\", \\\"{x:1650,y:717,t:1527271987494};\\\", \\\"{x:1645,y:712,t:1527271987502};\\\", \\\"{x:1639,y:708,t:1527271987512};\\\", \\\"{x:1622,y:695,t:1527271987529};\\\", \\\"{x:1602,y:681,t:1527271987546};\\\", \\\"{x:1577,y:667,t:1527271987562};\\\", \\\"{x:1553,y:654,t:1527271987579};\\\", \\\"{x:1525,y:638,t:1527271987596};\\\", \\\"{x:1501,y:627,t:1527271987612};\\\", \\\"{x:1470,y:614,t:1527271987629};\\\", \\\"{x:1448,y:607,t:1527271987646};\\\", \\\"{x:1424,y:599,t:1527271987662};\\\", \\\"{x:1402,y:594,t:1527271987679};\\\", \\\"{x:1385,y:591,t:1527271987696};\\\", \\\"{x:1363,y:587,t:1527271987712};\\\", \\\"{x:1345,y:585,t:1527271987729};\\\", \\\"{x:1324,y:581,t:1527271987745};\\\", \\\"{x:1302,y:577,t:1527271987761};\\\", \\\"{x:1278,y:574,t:1527271987779};\\\", \\\"{x:1249,y:571,t:1527271987796};\\\", \\\"{x:1209,y:565,t:1527271987812};\\\", \\\"{x:1153,y:564,t:1527271987829};\\\", \\\"{x:1028,y:564,t:1527271987846};\\\", \\\"{x:948,y:564,t:1527271987864};\\\", \\\"{x:867,y:564,t:1527271987878};\\\", \\\"{x:803,y:564,t:1527271987895};\\\", \\\"{x:733,y:562,t:1527271987911};\\\", \\\"{x:662,y:548,t:1527271987929};\\\", \\\"{x:606,y:530,t:1527271987945};\\\", \\\"{x:564,y:512,t:1527271987962};\\\", \\\"{x:530,y:494,t:1527271987979};\\\", \\\"{x:492,y:474,t:1527271987995};\\\", \\\"{x:431,y:442,t:1527271988012};\\\", \\\"{x:416,y:436,t:1527271988028};\\\", \\\"{x:379,y:420,t:1527271988045};\\\", \\\"{x:372,y:417,t:1527271988062};\\\", \\\"{x:370,y:416,t:1527271988078};\\\", \\\"{x:369,y:416,t:1527271988237};\\\", \\\"{x:368,y:416,t:1527271988245};\\\", \\\"{x:368,y:419,t:1527271988263};\\\", \\\"{x:368,y:426,t:1527271988278};\\\", \\\"{x:373,y:432,t:1527271988296};\\\", \\\"{x:383,y:441,t:1527271988313};\\\", \\\"{x:393,y:445,t:1527271988330};\\\", \\\"{x:401,y:450,t:1527271988346};\\\", \\\"{x:410,y:453,t:1527271988363};\\\", \\\"{x:422,y:455,t:1527271988379};\\\", \\\"{x:434,y:457,t:1527271988396};\\\", \\\"{x:457,y:460,t:1527271988413};\\\", \\\"{x:471,y:461,t:1527271988429};\\\", \\\"{x:484,y:461,t:1527271988445};\\\", \\\"{x:496,y:464,t:1527271988463};\\\", \\\"{x:502,y:464,t:1527271988479};\\\", \\\"{x:505,y:464,t:1527271988496};\\\", \\\"{x:506,y:464,t:1527271988513};\\\", \\\"{x:507,y:464,t:1527271988549};\\\", \\\"{x:509,y:464,t:1527271988669};\\\", \\\"{x:511,y:464,t:1527271988680};\\\", \\\"{x:517,y:463,t:1527271988696};\\\", \\\"{x:531,y:463,t:1527271988713};\\\", \\\"{x:549,y:463,t:1527271988729};\\\", \\\"{x:569,y:463,t:1527271988746};\\\", \\\"{x:587,y:463,t:1527271988763};\\\", \\\"{x:606,y:463,t:1527271988780};\\\", \\\"{x:626,y:463,t:1527271988796};\\\", \\\"{x:640,y:463,t:1527271988813};\\\", \\\"{x:658,y:463,t:1527271988829};\\\", \\\"{x:665,y:463,t:1527271988846};\\\", \\\"{x:669,y:463,t:1527271988862};\\\", \\\"{x:668,y:463,t:1527271989494};\\\", \\\"{x:667,y:463,t:1527271989510};\\\", \\\"{x:666,y:463,t:1527271989517};\\\", \\\"{x:665,y:463,t:1527271989758};\\\", \\\"{x:664,y:463,t:1527271990029};\\\", \\\"{x:663,y:463,t:1527271990037};\\\", \\\"{x:662,y:463,t:1527271990053};\\\", \\\"{x:661,y:463,t:1527271990069};\\\", \\\"{x:659,y:464,t:1527271990081};\\\", \\\"{x:658,y:465,t:1527271990101};\\\", \\\"{x:657,y:465,t:1527271990117};\\\", \\\"{x:656,y:465,t:1527271990165};\\\", \\\"{x:655,y:467,t:1527271990181};\\\", \\\"{x:654,y:467,t:1527271990197};\\\", \\\"{x:653,y:468,t:1527271990215};\\\", \\\"{x:652,y:468,t:1527271990230};\\\", \\\"{x:651,y:468,t:1527271990248};\\\", \\\"{x:650,y:469,t:1527271990518};\\\", \\\"{x:649,y:469,t:1527271990531};\\\", \\\"{x:646,y:469,t:1527271990547};\\\", \\\"{x:645,y:470,t:1527271990564};\\\", \\\"{x:639,y:471,t:1527271990581};\\\", \\\"{x:632,y:471,t:1527271990598};\\\", \\\"{x:626,y:471,t:1527271990615};\\\", \\\"{x:621,y:471,t:1527271990630};\\\", \\\"{x:616,y:472,t:1527271990648};\\\", \\\"{x:612,y:473,t:1527271990664};\\\", \\\"{x:609,y:474,t:1527271990681};\\\", \\\"{x:605,y:474,t:1527271990697};\\\", \\\"{x:602,y:475,t:1527271990715};\\\", \\\"{x:601,y:475,t:1527271990733};\\\", \\\"{x:600,y:475,t:1527271990748};\\\", \\\"{x:599,y:475,t:1527271990765};\\\", \\\"{x:597,y:476,t:1527271990781};\\\", \\\"{x:596,y:477,t:1527271990798};\\\", \\\"{x:595,y:478,t:1527271990815};\\\", \\\"{x:591,y:480,t:1527271990831};\\\", \\\"{x:589,y:482,t:1527271990847};\\\", \\\"{x:587,y:485,t:1527271990865};\\\", \\\"{x:585,y:488,t:1527271990881};\\\", \\\"{x:582,y:491,t:1527271990898};\\\", \\\"{x:579,y:497,t:1527271990915};\\\", \\\"{x:577,y:500,t:1527271990931};\\\", \\\"{x:575,y:503,t:1527271990948};\\\", \\\"{x:575,y:504,t:1527271992654};\\\", \\\"{x:575,y:502,t:1527271992678};\\\", \\\"{x:575,y:501,t:1527271992685};\\\", \\\"{x:575,y:499,t:1527271992699};\\\", \\\"{x:575,y:498,t:1527271992716};\\\", \\\"{x:576,y:495,t:1527271992733};\\\", \\\"{x:576,y:494,t:1527271992749};\\\", \\\"{x:576,y:492,t:1527271992765};\\\", \\\"{x:577,y:491,t:1527271992789};\\\", \\\"{x:578,y:491,t:1527271993060};\\\", \\\"{x:579,y:491,t:1527271993084};\\\", \\\"{x:580,y:491,t:1527271993100};\\\", \\\"{x:581,y:491,t:1527271993116};\\\", \\\"{x:583,y:491,t:1527271993132};\\\", \\\"{x:584,y:491,t:1527271993149};\\\", \\\"{x:585,y:491,t:1527271993165};\\\", \\\"{x:587,y:491,t:1527271993182};\\\", \\\"{x:588,y:491,t:1527271993212};\\\", \\\"{x:590,y:491,t:1527271993236};\\\", \\\"{x:591,y:491,t:1527271993252};\\\", \\\"{x:594,y:491,t:1527271993265};\\\", \\\"{x:597,y:491,t:1527271993282};\\\", \\\"{x:600,y:491,t:1527271993299};\\\", \\\"{x:601,y:491,t:1527271993316};\\\", \\\"{x:605,y:491,t:1527271993332};\\\", \\\"{x:606,y:491,t:1527271993350};\\\", \\\"{x:607,y:491,t:1527271993366};\\\", \\\"{x:608,y:491,t:1527271993382};\\\", \\\"{x:610,y:491,t:1527271993400};\\\", \\\"{x:614,y:491,t:1527271993415};\\\", \\\"{x:618,y:491,t:1527271993433};\\\", \\\"{x:623,y:491,t:1527271993450};\\\", \\\"{x:625,y:491,t:1527271993466};\\\", \\\"{x:628,y:491,t:1527271993483};\\\", \\\"{x:630,y:491,t:1527271993499};\\\", \\\"{x:631,y:491,t:1527271993573};\\\", \\\"{x:634,y:491,t:1527271993926};\\\", \\\"{x:646,y:493,t:1527271993933};\\\", \\\"{x:679,y:502,t:1527271993950};\\\", \\\"{x:737,y:515,t:1527271993967};\\\", \\\"{x:803,y:532,t:1527271993984};\\\", \\\"{x:888,y:551,t:1527271993999};\\\", \\\"{x:988,y:581,t:1527271994016};\\\", \\\"{x:1107,y:612,t:1527271994033};\\\", \\\"{x:1234,y:648,t:1527271994051};\\\", \\\"{x:1372,y:687,t:1527271994067};\\\", \\\"{x:1521,y:727,t:1527271994083};\\\", \\\"{x:1734,y:787,t:1527271994101};\\\", \\\"{x:1861,y:819,t:1527271994116};\\\", \\\"{x:1915,y:829,t:1527271994132};\\\", \\\"{x:1918,y:947,t:1527271994901};\\\", \\\"{x:1913,y:947,t:1527271994915};\\\", \\\"{x:1906,y:947,t:1527271994938};\\\", \\\"{x:1883,y:944,t:1527271994967};\\\", \\\"{x:1867,y:937,t:1527271994985};\\\", \\\"{x:1844,y:929,t:1527271995001};\\\", \\\"{x:1826,y:921,t:1527271995017};\\\", \\\"{x:1798,y:910,t:1527271995034};\\\", \\\"{x:1776,y:902,t:1527271995050};\\\", \\\"{x:1757,y:894,t:1527271995067};\\\", \\\"{x:1744,y:888,t:1527271995084};\\\", \\\"{x:1741,y:887,t:1527271995100};\\\", \\\"{x:1740,y:886,t:1527271995117};\\\", \\\"{x:1739,y:885,t:1527271995156};\\\", \\\"{x:1738,y:884,t:1527271995228};\\\", \\\"{x:1738,y:883,t:1527271995253};\\\", \\\"{x:1737,y:882,t:1527271995284};\\\", \\\"{x:1737,y:881,t:1527271995318};\\\", \\\"{x:1736,y:879,t:1527271995357};\\\", \\\"{x:1736,y:878,t:1527271995422};\\\", \\\"{x:1736,y:877,t:1527271995445};\\\", \\\"{x:1736,y:876,t:1527271995461};\\\", \\\"{x:1735,y:876,t:1527271995486};\\\", \\\"{x:1735,y:875,t:1527271996678};\\\", \\\"{x:1735,y:874,t:1527271996685};\\\", \\\"{x:1729,y:869,t:1527271997374};\\\", \\\"{x:1712,y:868,t:1527271997386};\\\", \\\"{x:1653,y:858,t:1527271997404};\\\", \\\"{x:1573,y:849,t:1527271997420};\\\", \\\"{x:1491,y:834,t:1527271997437};\\\", \\\"{x:1402,y:818,t:1527271997453};\\\", \\\"{x:1365,y:809,t:1527271997470};\\\", \\\"{x:1348,y:804,t:1527271997487};\\\", \\\"{x:1346,y:804,t:1527271997504};\\\", \\\"{x:1345,y:804,t:1527271997520};\\\", \\\"{x:1345,y:805,t:1527271997829};\\\", \\\"{x:1345,y:806,t:1527271997838};\\\", \\\"{x:1345,y:810,t:1527271997853};\\\", \\\"{x:1345,y:811,t:1527271997870};\\\", \\\"{x:1345,y:814,t:1527271997887};\\\", \\\"{x:1345,y:816,t:1527271997903};\\\", \\\"{x:1344,y:818,t:1527271997920};\\\", \\\"{x:1343,y:820,t:1527271997937};\\\", \\\"{x:1342,y:822,t:1527271997953};\\\", \\\"{x:1341,y:823,t:1527271997971};\\\", \\\"{x:1341,y:824,t:1527271997987};\\\", \\\"{x:1341,y:821,t:1527271998341};\\\", \\\"{x:1341,y:819,t:1527271998353};\\\", \\\"{x:1342,y:808,t:1527271998370};\\\", \\\"{x:1344,y:790,t:1527271998387};\\\", \\\"{x:1349,y:761,t:1527271998404};\\\", \\\"{x:1352,y:733,t:1527271998421};\\\", \\\"{x:1361,y:678,t:1527271998438};\\\", \\\"{x:1362,y:651,t:1527271998454};\\\", \\\"{x:1362,y:624,t:1527271998471};\\\", \\\"{x:1362,y:600,t:1527271998487};\\\", \\\"{x:1358,y:575,t:1527271998504};\\\", \\\"{x:1354,y:551,t:1527271998520};\\\", \\\"{x:1351,y:535,t:1527271998536};\\\", \\\"{x:1349,y:522,t:1527271998554};\\\", \\\"{x:1346,y:514,t:1527271998570};\\\", \\\"{x:1346,y:509,t:1527271998587};\\\", \\\"{x:1346,y:504,t:1527271998603};\\\", \\\"{x:1345,y:501,t:1527271998620};\\\", \\\"{x:1345,y:499,t:1527271998636};\\\", \\\"{x:1344,y:498,t:1527271998733};\\\", \\\"{x:1342,y:498,t:1527271998749};\\\", \\\"{x:1340,y:498,t:1527271998757};\\\", \\\"{x:1339,y:498,t:1527271998770};\\\", \\\"{x:1338,y:498,t:1527271998787};\\\", \\\"{x:1335,y:498,t:1527271998804};\\\", \\\"{x:1333,y:498,t:1527271998820};\\\", \\\"{x:1330,y:498,t:1527271998837};\\\", \\\"{x:1329,y:498,t:1527271998877};\\\", \\\"{x:1328,y:497,t:1527271998888};\\\", \\\"{x:1325,y:496,t:1527271998905};\\\", \\\"{x:1323,y:496,t:1527271998920};\\\", \\\"{x:1322,y:496,t:1527271998940};\\\", \\\"{x:1321,y:496,t:1527271998989};\\\", \\\"{x:1320,y:496,t:1527271999336};\\\", \\\"{x:1319,y:496,t:1527271999371};\\\", \\\"{x:1314,y:498,t:1527271999388};\\\", \\\"{x:1312,y:500,t:1527271999404};\\\", \\\"{x:1306,y:503,t:1527271999422};\\\", \\\"{x:1304,y:504,t:1527271999445};\\\", \\\"{x:1306,y:503,t:1527272000044};\\\", \\\"{x:1312,y:499,t:1527272000055};\\\", \\\"{x:1318,y:496,t:1527272000071};\\\", \\\"{x:1321,y:495,t:1527272000089};\\\", \\\"{x:1321,y:494,t:1527272000105};\\\", \\\"{x:1322,y:493,t:1527272000121};\\\", \\\"{x:1322,y:495,t:1527272002918};\\\", \\\"{x:1322,y:499,t:1527272002925};\\\", \\\"{x:1319,y:503,t:1527272002941};\\\", \\\"{x:1315,y:511,t:1527272002957};\\\", \\\"{x:1309,y:522,t:1527272002973};\\\", \\\"{x:1308,y:526,t:1527272002991};\\\", \\\"{x:1307,y:527,t:1527272003007};\\\", \\\"{x:1306,y:528,t:1527272003024};\\\", \\\"{x:1305,y:530,t:1527272003041};\\\", \\\"{x:1305,y:533,t:1527272003057};\\\", \\\"{x:1304,y:535,t:1527272003074};\\\", \\\"{x:1303,y:541,t:1527272003090};\\\", \\\"{x:1301,y:544,t:1527272003107};\\\", \\\"{x:1301,y:547,t:1527272003124};\\\", \\\"{x:1301,y:549,t:1527272003141};\\\", \\\"{x:1300,y:553,t:1527272003157};\\\", \\\"{x:1300,y:555,t:1527272003174};\\\", \\\"{x:1298,y:561,t:1527272003191};\\\", \\\"{x:1298,y:564,t:1527272003208};\\\", \\\"{x:1296,y:569,t:1527272003224};\\\", \\\"{x:1294,y:575,t:1527272003241};\\\", \\\"{x:1292,y:585,t:1527272003258};\\\", \\\"{x:1288,y:595,t:1527272003274};\\\", \\\"{x:1284,y:608,t:1527272003291};\\\", \\\"{x:1282,y:618,t:1527272003307};\\\", \\\"{x:1278,y:628,t:1527272003323};\\\", \\\"{x:1275,y:639,t:1527272003341};\\\", \\\"{x:1268,y:658,t:1527272003358};\\\", \\\"{x:1264,y:668,t:1527272003373};\\\", \\\"{x:1261,y:680,t:1527272003391};\\\", \\\"{x:1258,y:691,t:1527272003408};\\\", \\\"{x:1255,y:701,t:1527272003423};\\\", \\\"{x:1254,y:710,t:1527272003440};\\\", \\\"{x:1253,y:718,t:1527272003457};\\\", \\\"{x:1251,y:726,t:1527272003473};\\\", \\\"{x:1250,y:730,t:1527272003490};\\\", \\\"{x:1249,y:737,t:1527272003508};\\\", \\\"{x:1247,y:742,t:1527272003524};\\\", \\\"{x:1246,y:747,t:1527272003540};\\\", \\\"{x:1242,y:754,t:1527272003557};\\\", \\\"{x:1242,y:756,t:1527272003573};\\\", \\\"{x:1242,y:759,t:1527272003591};\\\", \\\"{x:1240,y:762,t:1527272003608};\\\", \\\"{x:1238,y:766,t:1527272003624};\\\", \\\"{x:1237,y:770,t:1527272003641};\\\", \\\"{x:1234,y:774,t:1527272003657};\\\", \\\"{x:1234,y:779,t:1527272003674};\\\", \\\"{x:1231,y:782,t:1527272003691};\\\", \\\"{x:1230,y:786,t:1527272003707};\\\", \\\"{x:1228,y:789,t:1527272003725};\\\", \\\"{x:1227,y:793,t:1527272003741};\\\", \\\"{x:1226,y:796,t:1527272003758};\\\", \\\"{x:1225,y:799,t:1527272003775};\\\", \\\"{x:1225,y:800,t:1527272003791};\\\", \\\"{x:1225,y:802,t:1527272003808};\\\", \\\"{x:1225,y:803,t:1527272003824};\\\", \\\"{x:1224,y:805,t:1527272003840};\\\", \\\"{x:1224,y:806,t:1527272003856};\\\", \\\"{x:1224,y:808,t:1527272003874};\\\", \\\"{x:1224,y:809,t:1527272003890};\\\", \\\"{x:1224,y:811,t:1527272003907};\\\", \\\"{x:1224,y:812,t:1527272003932};\\\", \\\"{x:1224,y:811,t:1527272004833};\\\", \\\"{x:1224,y:810,t:1527272004845};\\\", \\\"{x:1224,y:809,t:1527272004897};\\\", \\\"{x:1225,y:808,t:1527272004945};\\\", \\\"{x:1225,y:807,t:1527272004962};\\\", \\\"{x:1225,y:806,t:1527272004978};\\\", \\\"{x:1225,y:805,t:1527272004995};\\\", \\\"{x:1226,y:803,t:1527272005012};\\\", \\\"{x:1227,y:800,t:1527272005027};\\\", \\\"{x:1229,y:796,t:1527272005044};\\\", \\\"{x:1229,y:793,t:1527272005061};\\\", \\\"{x:1232,y:788,t:1527272005077};\\\", \\\"{x:1232,y:781,t:1527272005094};\\\", \\\"{x:1238,y:764,t:1527272005111};\\\", \\\"{x:1244,y:746,t:1527272005127};\\\", \\\"{x:1253,y:726,t:1527272005144};\\\", \\\"{x:1266,y:703,t:1527272005162};\\\", \\\"{x:1282,y:676,t:1527272005177};\\\", \\\"{x:1291,y:655,t:1527272005194};\\\", \\\"{x:1300,y:635,t:1527272005212};\\\", \\\"{x:1307,y:617,t:1527272005228};\\\", \\\"{x:1312,y:602,t:1527272005245};\\\", \\\"{x:1319,y:585,t:1527272005262};\\\", \\\"{x:1321,y:571,t:1527272005278};\\\", \\\"{x:1326,y:555,t:1527272005296};\\\", \\\"{x:1331,y:539,t:1527272005312};\\\", \\\"{x:1335,y:523,t:1527272005328};\\\", \\\"{x:1336,y:517,t:1527272005345};\\\", \\\"{x:1336,y:510,t:1527272005361};\\\", \\\"{x:1336,y:508,t:1527272005379};\\\", \\\"{x:1336,y:507,t:1527272005395};\\\", \\\"{x:1336,y:504,t:1527272005412};\\\", \\\"{x:1336,y:503,t:1527272005433};\\\", \\\"{x:1336,y:501,t:1527272005445};\\\", \\\"{x:1336,y:500,t:1527272005462};\\\", \\\"{x:1336,y:499,t:1527272005479};\\\", \\\"{x:1336,y:498,t:1527272005496};\\\", \\\"{x:1336,y:497,t:1527272005528};\\\", \\\"{x:1336,y:496,t:1527272005569};\\\", \\\"{x:1335,y:496,t:1527272005592};\\\", \\\"{x:1335,y:495,t:1527272005601};\\\", \\\"{x:1334,y:495,t:1527272005616};\\\", \\\"{x:1333,y:495,t:1527272005628};\\\", \\\"{x:1332,y:495,t:1527272005644};\\\", \\\"{x:1331,y:494,t:1527272005662};\\\", \\\"{x:1330,y:494,t:1527272005697};\\\", \\\"{x:1329,y:494,t:1527272005712};\\\", \\\"{x:1326,y:494,t:1527272005728};\\\", \\\"{x:1322,y:494,t:1527272005745};\\\", \\\"{x:1318,y:495,t:1527272005762};\\\", \\\"{x:1315,y:496,t:1527272005779};\\\", \\\"{x:1314,y:497,t:1527272005795};\\\", \\\"{x:1312,y:498,t:1527272005812};\\\", \\\"{x:1311,y:499,t:1527272005832};\\\", \\\"{x:1311,y:498,t:1527272008359};\\\", \\\"{x:1314,y:496,t:1527272008367};\\\", \\\"{x:1318,y:494,t:1527272008379};\\\", \\\"{x:1326,y:490,t:1527272008396};\\\", \\\"{x:1328,y:490,t:1527272008413};\\\", \\\"{x:1329,y:489,t:1527272008430};\\\", \\\"{x:1328,y:491,t:1527272008728};\\\", \\\"{x:1328,y:492,t:1527272008737};\\\", \\\"{x:1327,y:494,t:1527272008747};\\\", \\\"{x:1325,y:497,t:1527272008764};\\\", \\\"{x:1324,y:499,t:1527272008781};\\\", \\\"{x:1323,y:501,t:1527272008797};\\\", \\\"{x:1322,y:502,t:1527272008814};\\\", \\\"{x:1322,y:503,t:1527272012224};\\\", \\\"{x:1322,y:504,t:1527272014976};\\\", \\\"{x:1321,y:505,t:1527272016865};\\\", \\\"{x:1319,y:508,t:1527272016872};\\\", \\\"{x:1319,y:509,t:1527272016896};\\\", \\\"{x:1319,y:510,t:1527272016904};\\\", \\\"{x:1319,y:511,t:1527272016920};\\\", \\\"{x:1318,y:512,t:1527272016936};\\\", \\\"{x:1318,y:513,t:1527272016960};\\\", \\\"{x:1318,y:514,t:1527272016993};\\\", \\\"{x:1318,y:515,t:1527272017008};\\\", \\\"{x:1318,y:516,t:1527272017020};\\\", \\\"{x:1316,y:517,t:1527272017036};\\\", \\\"{x:1316,y:519,t:1527272017053};\\\", \\\"{x:1315,y:522,t:1527272017068};\\\", \\\"{x:1314,y:523,t:1527272017086};\\\", \\\"{x:1314,y:526,t:1527272017103};\\\", \\\"{x:1313,y:528,t:1527272017118};\\\", \\\"{x:1312,y:530,t:1527272017136};\\\", \\\"{x:1311,y:532,t:1527272017159};\\\", \\\"{x:1310,y:533,t:1527272017183};\\\", \\\"{x:1310,y:535,t:1527272017208};\\\", \\\"{x:1309,y:535,t:1527272017224};\\\", \\\"{x:1309,y:536,t:1527272017236};\\\", \\\"{x:1308,y:538,t:1527272017253};\\\", \\\"{x:1308,y:539,t:1527272017269};\\\", \\\"{x:1306,y:542,t:1527272017286};\\\", \\\"{x:1305,y:543,t:1527272017303};\\\", \\\"{x:1303,y:547,t:1527272017319};\\\", \\\"{x:1301,y:551,t:1527272017336};\\\", \\\"{x:1301,y:553,t:1527272017354};\\\", \\\"{x:1298,y:557,t:1527272017370};\\\", \\\"{x:1297,y:560,t:1527272017386};\\\", \\\"{x:1295,y:564,t:1527272017403};\\\", \\\"{x:1293,y:570,t:1527272017421};\\\", \\\"{x:1290,y:575,t:1527272017436};\\\", \\\"{x:1286,y:583,t:1527272017453};\\\", \\\"{x:1282,y:593,t:1527272017470};\\\", \\\"{x:1279,y:599,t:1527272017487};\\\", \\\"{x:1276,y:608,t:1527272017503};\\\", \\\"{x:1271,y:619,t:1527272017521};\\\", \\\"{x:1269,y:621,t:1527272017536};\\\", \\\"{x:1268,y:623,t:1527272017553};\\\", \\\"{x:1268,y:624,t:1527272017576};\\\", \\\"{x:1267,y:626,t:1527272017586};\\\", \\\"{x:1266,y:628,t:1527272017609};\\\", \\\"{x:1265,y:629,t:1527272017620};\\\", \\\"{x:1265,y:631,t:1527272017636};\\\", \\\"{x:1262,y:633,t:1527272017653};\\\", \\\"{x:1261,y:635,t:1527272017670};\\\", \\\"{x:1260,y:638,t:1527272017686};\\\", \\\"{x:1259,y:640,t:1527272017703};\\\", \\\"{x:1258,y:644,t:1527272017720};\\\", \\\"{x:1257,y:646,t:1527272017737};\\\", \\\"{x:1255,y:650,t:1527272017753};\\\", \\\"{x:1254,y:655,t:1527272017771};\\\", \\\"{x:1252,y:659,t:1527272017786};\\\", \\\"{x:1251,y:663,t:1527272017803};\\\", \\\"{x:1251,y:664,t:1527272017821};\\\", \\\"{x:1251,y:666,t:1527272017836};\\\", \\\"{x:1251,y:667,t:1527272017853};\\\", \\\"{x:1251,y:669,t:1527272017871};\\\", \\\"{x:1251,y:670,t:1527272017888};\\\", \\\"{x:1250,y:670,t:1527272017903};\\\", \\\"{x:1249,y:670,t:1527272019129};\\\", \\\"{x:1249,y:669,t:1527272019144};\\\", \\\"{x:1249,y:668,t:1527272019160};\\\", \\\"{x:1249,y:667,t:1527272019176};\\\", \\\"{x:1249,y:666,t:1527272019200};\\\", \\\"{x:1249,y:665,t:1527272019208};\\\", \\\"{x:1249,y:664,t:1527272019232};\\\", \\\"{x:1249,y:663,t:1527272019256};\\\", \\\"{x:1249,y:662,t:1527272019272};\\\", \\\"{x:1249,y:661,t:1527272019287};\\\", \\\"{x:1249,y:658,t:1527272019304};\\\", \\\"{x:1249,y:654,t:1527272019321};\\\", \\\"{x:1250,y:650,t:1527272019337};\\\", \\\"{x:1253,y:645,t:1527272019354};\\\", \\\"{x:1255,y:642,t:1527272019371};\\\", \\\"{x:1261,y:633,t:1527272019387};\\\", \\\"{x:1269,y:624,t:1527272019405};\\\", \\\"{x:1276,y:616,t:1527272019421};\\\", \\\"{x:1286,y:604,t:1527272019437};\\\", \\\"{x:1296,y:592,t:1527272019454};\\\", \\\"{x:1309,y:581,t:1527272019472};\\\", \\\"{x:1337,y:555,t:1527272019488};\\\", \\\"{x:1357,y:535,t:1527272019504};\\\", \\\"{x:1382,y:512,t:1527272019522};\\\", \\\"{x:1400,y:494,t:1527272019538};\\\", \\\"{x:1412,y:479,t:1527272019554};\\\", \\\"{x:1417,y:472,t:1527272019571};\\\", \\\"{x:1417,y:470,t:1527272019588};\\\", \\\"{x:1418,y:468,t:1527272019604};\\\", \\\"{x:1418,y:467,t:1527272019728};\\\", \\\"{x:1413,y:466,t:1527272019738};\\\", \\\"{x:1404,y:466,t:1527272019755};\\\", \\\"{x:1389,y:466,t:1527272019772};\\\", \\\"{x:1375,y:466,t:1527272019789};\\\", \\\"{x:1365,y:466,t:1527272019805};\\\", \\\"{x:1358,y:466,t:1527272019821};\\\", \\\"{x:1352,y:466,t:1527272019838};\\\", \\\"{x:1349,y:467,t:1527272019855};\\\", \\\"{x:1348,y:467,t:1527272019952};\\\", \\\"{x:1348,y:465,t:1527272019968};\\\", \\\"{x:1348,y:464,t:1527272019977};\\\", \\\"{x:1348,y:462,t:1527272019989};\\\", \\\"{x:1348,y:460,t:1527272020006};\\\", \\\"{x:1348,y:457,t:1527272020022};\\\", \\\"{x:1348,y:455,t:1527272020038};\\\", \\\"{x:1346,y:452,t:1527272020056};\\\", \\\"{x:1346,y:450,t:1527272020071};\\\", \\\"{x:1346,y:445,t:1527272020088};\\\", \\\"{x:1346,y:441,t:1527272020106};\\\", \\\"{x:1346,y:438,t:1527272020121};\\\", \\\"{x:1346,y:434,t:1527272020139};\\\", \\\"{x:1346,y:430,t:1527272020156};\\\", \\\"{x:1346,y:427,t:1527272020172};\\\", \\\"{x:1346,y:424,t:1527272020188};\\\", \\\"{x:1346,y:423,t:1527272020205};\\\", \\\"{x:1346,y:422,t:1527272020222};\\\", \\\"{x:1346,y:421,t:1527272020239};\\\", \\\"{x:1346,y:420,t:1527272020289};\\\", \\\"{x:1350,y:416,t:1527272020641};\\\", \\\"{x:1354,y:411,t:1527272020655};\\\", \\\"{x:1364,y:393,t:1527272020672};\\\", \\\"{x:1369,y:385,t:1527272020689};\\\", \\\"{x:1372,y:377,t:1527272020705};\\\", \\\"{x:1374,y:372,t:1527272020722};\\\", \\\"{x:1374,y:370,t:1527272020739};\\\", \\\"{x:1375,y:368,t:1527272020755};\\\", \\\"{x:1376,y:366,t:1527272020772};\\\", \\\"{x:1376,y:364,t:1527272020789};\\\", \\\"{x:1377,y:361,t:1527272020805};\\\", \\\"{x:1378,y:358,t:1527272020822};\\\", \\\"{x:1379,y:356,t:1527272020838};\\\", \\\"{x:1380,y:352,t:1527272020855};\\\", \\\"{x:1381,y:350,t:1527272020873};\\\", \\\"{x:1381,y:349,t:1527272020888};\\\", \\\"{x:1381,y:351,t:1527272022273};\\\", \\\"{x:1378,y:364,t:1527272022290};\\\", \\\"{x:1372,y:385,t:1527272022306};\\\", \\\"{x:1364,y:408,t:1527272022323};\\\", \\\"{x:1358,y:431,t:1527272022340};\\\", \\\"{x:1354,y:453,t:1527272022357};\\\", \\\"{x:1351,y:472,t:1527272022373};\\\", \\\"{x:1348,y:492,t:1527272022389};\\\", \\\"{x:1346,y:503,t:1527272022406};\\\", \\\"{x:1346,y:512,t:1527272022424};\\\", \\\"{x:1346,y:515,t:1527272022439};\\\", \\\"{x:1346,y:518,t:1527272022456};\\\", \\\"{x:1346,y:519,t:1527272022473};\\\", \\\"{x:1345,y:519,t:1527272022553};\\\", \\\"{x:1344,y:519,t:1527272022569};\\\", \\\"{x:1343,y:519,t:1527272022584};\\\", \\\"{x:1342,y:519,t:1527272022600};\\\", \\\"{x:1340,y:519,t:1527272022608};\\\", \\\"{x:1339,y:519,t:1527272022624};\\\", \\\"{x:1337,y:519,t:1527272022640};\\\", \\\"{x:1333,y:519,t:1527272022657};\\\", \\\"{x:1331,y:519,t:1527272022674};\\\", \\\"{x:1327,y:519,t:1527272022690};\\\", \\\"{x:1326,y:519,t:1527272022707};\\\", \\\"{x:1325,y:519,t:1527272022724};\\\", \\\"{x:1324,y:518,t:1527272022809};\\\", \\\"{x:1324,y:517,t:1527272022841};\\\", \\\"{x:1323,y:515,t:1527272022856};\\\", \\\"{x:1323,y:513,t:1527272022880};\\\", \\\"{x:1322,y:512,t:1527272022913};\\\", \\\"{x:1320,y:514,t:1527272024625};\\\", \\\"{x:1318,y:520,t:1527272024642};\\\", \\\"{x:1316,y:525,t:1527272024658};\\\", \\\"{x:1315,y:529,t:1527272024675};\\\", \\\"{x:1311,y:536,t:1527272024691};\\\", \\\"{x:1311,y:538,t:1527272024708};\\\", \\\"{x:1311,y:540,t:1527272024724};\\\", \\\"{x:1311,y:543,t:1527272024741};\\\", \\\"{x:1310,y:546,t:1527272024758};\\\", \\\"{x:1310,y:550,t:1527272024775};\\\", \\\"{x:1309,y:554,t:1527272024792};\\\", \\\"{x:1309,y:556,t:1527272024809};\\\", \\\"{x:1308,y:559,t:1527272024824};\\\", \\\"{x:1308,y:562,t:1527272024842};\\\", \\\"{x:1308,y:563,t:1527272024859};\\\", \\\"{x:1308,y:565,t:1527272024888};\\\", \\\"{x:1308,y:566,t:1527272024904};\\\", \\\"{x:1308,y:568,t:1527272024919};\\\", \\\"{x:1308,y:569,t:1527272024927};\\\", \\\"{x:1308,y:571,t:1527272024943};\\\", \\\"{x:1308,y:572,t:1527272024958};\\\", \\\"{x:1308,y:575,t:1527272024974};\\\", \\\"{x:1308,y:578,t:1527272024991};\\\", \\\"{x:1308,y:579,t:1527272025007};\\\", \\\"{x:1308,y:582,t:1527272025024};\\\", \\\"{x:1308,y:584,t:1527272025041};\\\", \\\"{x:1308,y:587,t:1527272025058};\\\", \\\"{x:1308,y:591,t:1527272025074};\\\", \\\"{x:1308,y:596,t:1527272025091};\\\", \\\"{x:1309,y:603,t:1527272025108};\\\", \\\"{x:1310,y:613,t:1527272025125};\\\", \\\"{x:1312,y:627,t:1527272025142};\\\", \\\"{x:1314,y:640,t:1527272025159};\\\", \\\"{x:1317,y:655,t:1527272025174};\\\", \\\"{x:1319,y:672,t:1527272025191};\\\", \\\"{x:1320,y:686,t:1527272025209};\\\", \\\"{x:1323,y:700,t:1527272025224};\\\", \\\"{x:1324,y:712,t:1527272025241};\\\", \\\"{x:1327,y:722,t:1527272025259};\\\", \\\"{x:1329,y:731,t:1527272025274};\\\", \\\"{x:1330,y:739,t:1527272025291};\\\", \\\"{x:1332,y:746,t:1527272025309};\\\", \\\"{x:1334,y:752,t:1527272025325};\\\", \\\"{x:1336,y:758,t:1527272025341};\\\", \\\"{x:1337,y:762,t:1527272025358};\\\", \\\"{x:1339,y:771,t:1527272025377};\\\", \\\"{x:1339,y:775,t:1527272025392};\\\", \\\"{x:1340,y:781,t:1527272025408};\\\", \\\"{x:1340,y:785,t:1527272025425};\\\", \\\"{x:1342,y:792,t:1527272025441};\\\", \\\"{x:1342,y:797,t:1527272025459};\\\", \\\"{x:1343,y:804,t:1527272025476};\\\", \\\"{x:1344,y:811,t:1527272025491};\\\", \\\"{x:1344,y:818,t:1527272025509};\\\", \\\"{x:1344,y:831,t:1527272025526};\\\", \\\"{x:1344,y:842,t:1527272025542};\\\", \\\"{x:1344,y:856,t:1527272025559};\\\", \\\"{x:1345,y:874,t:1527272025576};\\\", \\\"{x:1345,y:888,t:1527272025592};\\\", \\\"{x:1344,y:905,t:1527272025609};\\\", \\\"{x:1343,y:914,t:1527272025626};\\\", \\\"{x:1341,y:929,t:1527272025642};\\\", \\\"{x:1339,y:937,t:1527272025659};\\\", \\\"{x:1338,y:945,t:1527272025676};\\\", \\\"{x:1338,y:959,t:1527272025692};\\\", \\\"{x:1338,y:974,t:1527272025709};\\\", \\\"{x:1338,y:982,t:1527272025726};\\\", \\\"{x:1338,y:986,t:1527272025742};\\\", \\\"{x:1338,y:989,t:1527272025759};\\\", \\\"{x:1338,y:990,t:1527272025776};\\\", \\\"{x:1338,y:992,t:1527272025808};\\\", \\\"{x:1338,y:984,t:1527272025993};\\\", \\\"{x:1338,y:961,t:1527272026010};\\\", \\\"{x:1342,y:933,t:1527272026025};\\\", \\\"{x:1344,y:907,t:1527272026042};\\\", \\\"{x:1348,y:881,t:1527272026058};\\\", \\\"{x:1351,y:852,t:1527272026075};\\\", \\\"{x:1354,y:815,t:1527272026093};\\\", \\\"{x:1358,y:784,t:1527272026108};\\\", \\\"{x:1366,y:736,t:1527272026125};\\\", \\\"{x:1374,y:686,t:1527272026142};\\\", \\\"{x:1381,y:643,t:1527272026159};\\\", \\\"{x:1393,y:582,t:1527272026175};\\\", \\\"{x:1401,y:541,t:1527272026192};\\\", \\\"{x:1409,y:506,t:1527272026208};\\\", \\\"{x:1416,y:473,t:1527272026225};\\\", \\\"{x:1420,y:441,t:1527272026242};\\\", \\\"{x:1423,y:414,t:1527272026258};\\\", \\\"{x:1425,y:389,t:1527272026276};\\\", \\\"{x:1425,y:365,t:1527272026292};\\\", \\\"{x:1424,y:342,t:1527272026309};\\\", \\\"{x:1419,y:322,t:1527272026326};\\\", \\\"{x:1414,y:306,t:1527272026342};\\\", \\\"{x:1410,y:291,t:1527272026360};\\\", \\\"{x:1410,y:284,t:1527272026375};\\\", \\\"{x:1409,y:280,t:1527272026392};\\\", \\\"{x:1409,y:278,t:1527272026410};\\\", \\\"{x:1409,y:277,t:1527272026426};\\\", \\\"{x:1409,y:279,t:1527272026593};\\\", \\\"{x:1409,y:283,t:1527272026610};\\\", \\\"{x:1409,y:286,t:1527272026626};\\\", \\\"{x:1409,y:287,t:1527272026643};\\\", \\\"{x:1409,y:289,t:1527272026660};\\\", \\\"{x:1409,y:294,t:1527272026676};\\\", \\\"{x:1409,y:297,t:1527272026693};\\\", \\\"{x:1409,y:298,t:1527272026710};\\\", \\\"{x:1410,y:300,t:1527272026726};\\\", \\\"{x:1410,y:301,t:1527272026760};\\\", \\\"{x:1410,y:302,t:1527272026776};\\\", \\\"{x:1411,y:303,t:1527272026793};\\\", \\\"{x:1411,y:304,t:1527272026810};\\\", \\\"{x:1411,y:305,t:1527272026928};\\\", \\\"{x:1411,y:306,t:1527272026952};\\\", \\\"{x:1411,y:307,t:1527272026960};\\\", \\\"{x:1411,y:308,t:1527272026977};\\\", \\\"{x:1411,y:309,t:1527272026992};\\\", \\\"{x:1411,y:310,t:1527272027010};\\\", \\\"{x:1411,y:311,t:1527272027027};\\\", \\\"{x:1411,y:312,t:1527272027043};\\\", \\\"{x:1411,y:313,t:1527272027060};\\\", \\\"{x:1411,y:314,t:1527272027077};\\\", \\\"{x:1411,y:316,t:1527272027092};\\\", \\\"{x:1410,y:319,t:1527272027110};\\\", \\\"{x:1409,y:322,t:1527272027126};\\\", \\\"{x:1409,y:325,t:1527272027143};\\\", \\\"{x:1408,y:329,t:1527272027159};\\\", \\\"{x:1408,y:331,t:1527272027256};\\\", \\\"{x:1407,y:332,t:1527272027337};\\\", \\\"{x:1406,y:332,t:1527272027344};\\\", \\\"{x:1406,y:333,t:1527272027360};\\\", \\\"{x:1405,y:335,t:1527272027376};\\\", \\\"{x:1404,y:336,t:1527272027394};\\\", \\\"{x:1403,y:337,t:1527272027410};\\\", \\\"{x:1403,y:338,t:1527272027432};\\\", \\\"{x:1402,y:339,t:1527272027464};\\\", \\\"{x:1401,y:339,t:1527272027477};\\\", \\\"{x:1401,y:340,t:1527272027494};\\\", \\\"{x:1399,y:341,t:1527272027510};\\\", \\\"{x:1399,y:343,t:1527272028265};\\\", \\\"{x:1399,y:349,t:1527272028277};\\\", \\\"{x:1404,y:370,t:1527272028293};\\\", \\\"{x:1415,y:399,t:1527272028311};\\\", \\\"{x:1428,y:430,t:1527272028327};\\\", \\\"{x:1445,y:469,t:1527272028344};\\\", \\\"{x:1451,y:486,t:1527272028361};\\\", \\\"{x:1456,y:496,t:1527272028377};\\\", \\\"{x:1460,y:504,t:1527272028394};\\\", \\\"{x:1461,y:508,t:1527272028411};\\\", \\\"{x:1461,y:511,t:1527272028428};\\\", \\\"{x:1463,y:513,t:1527272028444};\\\", \\\"{x:1459,y:513,t:1527272028640};\\\", \\\"{x:1448,y:516,t:1527272028648};\\\", \\\"{x:1435,y:518,t:1527272028660};\\\", \\\"{x:1383,y:518,t:1527272028678};\\\", \\\"{x:1295,y:518,t:1527272028694};\\\", \\\"{x:1195,y:518,t:1527272028710};\\\", \\\"{x:1036,y:536,t:1527272028727};\\\", \\\"{x:944,y:549,t:1527272028744};\\\", \\\"{x:853,y:575,t:1527272028761};\\\", \\\"{x:773,y:597,t:1527272028777};\\\", \\\"{x:714,y:614,t:1527272028791};\\\", \\\"{x:681,y:624,t:1527272028808};\\\", \\\"{x:669,y:630,t:1527272028831};\\\", \\\"{x:669,y:631,t:1527272028855};\\\", \\\"{x:671,y:631,t:1527272029015};\\\", \\\"{x:675,y:628,t:1527272029032};\\\", \\\"{x:684,y:622,t:1527272029049};\\\", \\\"{x:691,y:618,t:1527272029065};\\\", \\\"{x:700,y:611,t:1527272029081};\\\", \\\"{x:707,y:607,t:1527272029098};\\\", \\\"{x:712,y:603,t:1527272029115};\\\", \\\"{x:714,y:600,t:1527272029131};\\\", \\\"{x:715,y:600,t:1527272029148};\\\", \\\"{x:715,y:599,t:1527272029164};\\\", \\\"{x:715,y:598,t:1527272029199};\\\", \\\"{x:715,y:597,t:1527272029214};\\\", \\\"{x:700,y:589,t:1527272029233};\\\", \\\"{x:682,y:582,t:1527272029249};\\\", \\\"{x:658,y:577,t:1527272029265};\\\", \\\"{x:628,y:572,t:1527272029282};\\\", \\\"{x:588,y:572,t:1527272029299};\\\", \\\"{x:554,y:572,t:1527272029316};\\\", \\\"{x:527,y:572,t:1527272029332};\\\", \\\"{x:508,y:572,t:1527272029348};\\\", \\\"{x:492,y:573,t:1527272029366};\\\", \\\"{x:479,y:579,t:1527272029382};\\\", \\\"{x:474,y:583,t:1527272029398};\\\", \\\"{x:469,y:590,t:1527272029415};\\\", \\\"{x:462,y:599,t:1527272029432};\\\", \\\"{x:457,y:611,t:1527272029448};\\\", \\\"{x:450,y:626,t:1527272029465};\\\", \\\"{x:441,y:640,t:1527272029483};\\\", \\\"{x:436,y:650,t:1527272029498};\\\", \\\"{x:434,y:657,t:1527272029515};\\\", \\\"{x:432,y:661,t:1527272029533};\\\", \\\"{x:431,y:663,t:1527272029548};\\\", \\\"{x:430,y:664,t:1527272029565};\\\", \\\"{x:429,y:664,t:1527272029617};\\\", \\\"{x:429,y:665,t:1527272029634};\\\", \\\"{x:427,y:665,t:1527272029649};\\\", \\\"{x:426,y:665,t:1527272029666};\\\", \\\"{x:425,y:665,t:1527272029688};\\\", \\\"{x:424,y:665,t:1527272029700};\\\", \\\"{x:421,y:660,t:1527272029716};\\\", \\\"{x:416,y:653,t:1527272029732};\\\", \\\"{x:414,y:647,t:1527272029749};\\\", \\\"{x:409,y:639,t:1527272029765};\\\", \\\"{x:408,y:633,t:1527272029783};\\\", \\\"{x:402,y:622,t:1527272029800};\\\", \\\"{x:397,y:615,t:1527272029816};\\\", \\\"{x:396,y:611,t:1527272029832};\\\", \\\"{x:395,y:608,t:1527272029849};\\\", \\\"{x:394,y:604,t:1527272029865};\\\", \\\"{x:394,y:599,t:1527272029883};\\\", \\\"{x:394,y:595,t:1527272029900};\\\", \\\"{x:395,y:590,t:1527272029915};\\\", \\\"{x:400,y:585,t:1527272029933};\\\", \\\"{x:410,y:580,t:1527272029950};\\\", \\\"{x:426,y:574,t:1527272029967};\\\", \\\"{x:447,y:570,t:1527272029982};\\\", \\\"{x:489,y:570,t:1527272029999};\\\", \\\"{x:521,y:570,t:1527272030016};\\\", \\\"{x:556,y:571,t:1527272030033};\\\", \\\"{x:589,y:579,t:1527272030049};\\\", \\\"{x:618,y:584,t:1527272030066};\\\", \\\"{x:647,y:592,t:1527272030083};\\\", \\\"{x:672,y:599,t:1527272030100};\\\", \\\"{x:686,y:603,t:1527272030116};\\\", \\\"{x:698,y:607,t:1527272030132};\\\", \\\"{x:702,y:608,t:1527272030150};\\\", \\\"{x:703,y:608,t:1527272030166};\\\", \\\"{x:705,y:608,t:1527272030264};\\\", \\\"{x:706,y:608,t:1527272030288};\\\", \\\"{x:707,y:608,t:1527272030299};\\\", \\\"{x:708,y:608,t:1527272030317};\\\", \\\"{x:709,y:608,t:1527272030332};\\\", \\\"{x:711,y:608,t:1527272030350};\\\", \\\"{x:712,y:608,t:1527272030368};\\\", \\\"{x:714,y:608,t:1527272030696};\\\", \\\"{x:715,y:608,t:1527272030784};\\\", \\\"{x:717,y:610,t:1527272030832};\\\", \\\"{x:718,y:610,t:1527272030840};\\\", \\\"{x:722,y:611,t:1527272030849};\\\", \\\"{x:734,y:615,t:1527272030868};\\\", \\\"{x:750,y:619,t:1527272030883};\\\", \\\"{x:775,y:622,t:1527272030901};\\\", \\\"{x:801,y:629,t:1527272030917};\\\", \\\"{x:829,y:633,t:1527272030933};\\\", \\\"{x:871,y:643,t:1527272030950};\\\", \\\"{x:912,y:654,t:1527272030966};\\\", \\\"{x:975,y:667,t:1527272030983};\\\", \\\"{x:1022,y:671,t:1527272031001};\\\", \\\"{x:1059,y:678,t:1527272031018};\\\", \\\"{x:1088,y:681,t:1527272031033};\\\", \\\"{x:1113,y:687,t:1527272031050};\\\", \\\"{x:1135,y:689,t:1527272031066};\\\", \\\"{x:1155,y:693,t:1527272031084};\\\", \\\"{x:1172,y:695,t:1527272031101};\\\", \\\"{x:1190,y:698,t:1527272031116};\\\", \\\"{x:1209,y:699,t:1527272031133};\\\", \\\"{x:1229,y:699,t:1527272031150};\\\", \\\"{x:1244,y:699,t:1527272031166};\\\", \\\"{x:1260,y:699,t:1527272031184};\\\", \\\"{x:1274,y:699,t:1527272031200};\\\", \\\"{x:1289,y:699,t:1527272031217};\\\", \\\"{x:1300,y:696,t:1527272031234};\\\", \\\"{x:1304,y:694,t:1527272031251};\\\", \\\"{x:1309,y:692,t:1527272031267};\\\", \\\"{x:1313,y:689,t:1527272031283};\\\", \\\"{x:1319,y:684,t:1527272031301};\\\", \\\"{x:1326,y:679,t:1527272031317};\\\", \\\"{x:1337,y:670,t:1527272031334};\\\", \\\"{x:1348,y:662,t:1527272031351};\\\", \\\"{x:1356,y:655,t:1527272031367};\\\", \\\"{x:1365,y:648,t:1527272031384};\\\", \\\"{x:1370,y:645,t:1527272031401};\\\", \\\"{x:1372,y:643,t:1527272031418};\\\", \\\"{x:1374,y:641,t:1527272031434};\\\", \\\"{x:1375,y:640,t:1527272031451};\\\", \\\"{x:1375,y:639,t:1527272031468};\\\", \\\"{x:1376,y:638,t:1527272031484};\\\", \\\"{x:1377,y:636,t:1527272031501};\\\", \\\"{x:1377,y:634,t:1527272031518};\\\", \\\"{x:1377,y:632,t:1527272031534};\\\", \\\"{x:1377,y:630,t:1527272031551};\\\", \\\"{x:1377,y:629,t:1527272031568};\\\", \\\"{x:1374,y:626,t:1527272031583};\\\", \\\"{x:1370,y:624,t:1527272031601};\\\", \\\"{x:1363,y:621,t:1527272031619};\\\", \\\"{x:1353,y:617,t:1527272031633};\\\", \\\"{x:1345,y:615,t:1527272031650};\\\", \\\"{x:1328,y:615,t:1527272031668};\\\", \\\"{x:1310,y:615,t:1527272031685};\\\", \\\"{x:1305,y:615,t:1527272031702};\\\", \\\"{x:1302,y:615,t:1527272031718};\\\", \\\"{x:1304,y:615,t:1527272031992};\\\", \\\"{x:1305,y:615,t:1527272032001};\\\", \\\"{x:1306,y:616,t:1527272032024};\\\", \\\"{x:1307,y:616,t:1527272032036};\\\", \\\"{x:1309,y:616,t:1527272032051};\\\", \\\"{x:1311,y:617,t:1527272032068};\\\", \\\"{x:1313,y:618,t:1527272032085};\\\", \\\"{x:1317,y:620,t:1527272032100};\\\", \\\"{x:1322,y:621,t:1527272032118};\\\", \\\"{x:1326,y:624,t:1527272032134};\\\", \\\"{x:1331,y:625,t:1527272032151};\\\", \\\"{x:1334,y:626,t:1527272032168};\\\", \\\"{x:1335,y:627,t:1527272032185};\\\", \\\"{x:1338,y:626,t:1527272032577};\\\", \\\"{x:1340,y:625,t:1527272032585};\\\", \\\"{x:1345,y:621,t:1527272032602};\\\", \\\"{x:1355,y:615,t:1527272032619};\\\", \\\"{x:1367,y:605,t:1527272032636};\\\", \\\"{x:1376,y:597,t:1527272032652};\\\", \\\"{x:1385,y:587,t:1527272032668};\\\", \\\"{x:1389,y:579,t:1527272032685};\\\", \\\"{x:1393,y:569,t:1527272032702};\\\", \\\"{x:1394,y:562,t:1527272032719};\\\", \\\"{x:1395,y:558,t:1527272032735};\\\", \\\"{x:1395,y:554,t:1527272032752};\\\", \\\"{x:1395,y:552,t:1527272032769};\\\", \\\"{x:1396,y:552,t:1527272033216};\\\", \\\"{x:1399,y:554,t:1527272033224};\\\", \\\"{x:1403,y:557,t:1527272033236};\\\", \\\"{x:1411,y:565,t:1527272033252};\\\", \\\"{x:1421,y:572,t:1527272033270};\\\", \\\"{x:1432,y:578,t:1527272033286};\\\", \\\"{x:1440,y:582,t:1527272033303};\\\", \\\"{x:1451,y:589,t:1527272033319};\\\", \\\"{x:1465,y:597,t:1527272033336};\\\", \\\"{x:1473,y:601,t:1527272033352};\\\", \\\"{x:1487,y:610,t:1527272033370};\\\", \\\"{x:1502,y:616,t:1527272033386};\\\", \\\"{x:1517,y:622,t:1527272033402};\\\", \\\"{x:1529,y:627,t:1527272033420};\\\", \\\"{x:1540,y:632,t:1527272033436};\\\", \\\"{x:1550,y:638,t:1527272033452};\\\", \\\"{x:1557,y:643,t:1527272033469};\\\", \\\"{x:1561,y:645,t:1527272033486};\\\", \\\"{x:1565,y:648,t:1527272033502};\\\", \\\"{x:1566,y:648,t:1527272033519};\\\", \\\"{x:1570,y:651,t:1527272033536};\\\", \\\"{x:1571,y:652,t:1527272033552};\\\", \\\"{x:1573,y:653,t:1527272033569};\\\", \\\"{x:1572,y:653,t:1527272033857};\\\", \\\"{x:1567,y:652,t:1527272033869};\\\", \\\"{x:1552,y:644,t:1527272033886};\\\", \\\"{x:1539,y:637,t:1527272033903};\\\", \\\"{x:1509,y:625,t:1527272033919};\\\", \\\"{x:1446,y:609,t:1527272033936};\\\", \\\"{x:1427,y:601,t:1527272033953};\\\", \\\"{x:1426,y:601,t:1527272033969};\\\", \\\"{x:1425,y:601,t:1527272033986};\\\", \\\"{x:1424,y:600,t:1527272034003};\\\", \\\"{x:1423,y:599,t:1527272034020};\\\", \\\"{x:1422,y:597,t:1527272034036};\\\", \\\"{x:1421,y:593,t:1527272034053};\\\", \\\"{x:1418,y:588,t:1527272034070};\\\", \\\"{x:1418,y:584,t:1527272034086};\\\", \\\"{x:1415,y:581,t:1527272034103};\\\", \\\"{x:1413,y:579,t:1527272034120};\\\", \\\"{x:1413,y:577,t:1527272034136};\\\", \\\"{x:1411,y:575,t:1527272034153};\\\", \\\"{x:1410,y:575,t:1527272034175};\\\", \\\"{x:1410,y:573,t:1527272034186};\\\", \\\"{x:1409,y:573,t:1527272034203};\\\", \\\"{x:1409,y:572,t:1527272034219};\\\", \\\"{x:1410,y:572,t:1527272034344};\\\", \\\"{x:1413,y:572,t:1527272034353};\\\", \\\"{x:1414,y:573,t:1527272034370};\\\", \\\"{x:1418,y:574,t:1527272034385};\\\", \\\"{x:1421,y:575,t:1527272034402};\\\", \\\"{x:1425,y:578,t:1527272034420};\\\", \\\"{x:1429,y:582,t:1527272034436};\\\", \\\"{x:1437,y:587,t:1527272034453};\\\", \\\"{x:1448,y:595,t:1527272034470};\\\", \\\"{x:1459,y:601,t:1527272034487};\\\", \\\"{x:1475,y:610,t:1527272034503};\\\", \\\"{x:1493,y:617,t:1527272034519};\\\", \\\"{x:1504,y:622,t:1527272034537};\\\", \\\"{x:1514,y:626,t:1527272034553};\\\", \\\"{x:1524,y:631,t:1527272034571};\\\", \\\"{x:1529,y:633,t:1527272034586};\\\", \\\"{x:1532,y:635,t:1527272034603};\\\", \\\"{x:1535,y:637,t:1527272034620};\\\", \\\"{x:1537,y:638,t:1527272034637};\\\", \\\"{x:1538,y:639,t:1527272034653};\\\", \\\"{x:1539,y:640,t:1527272034670};\\\", \\\"{x:1540,y:642,t:1527272034687};\\\", \\\"{x:1541,y:644,t:1527272034704};\\\", \\\"{x:1541,y:645,t:1527272034768};\\\", \\\"{x:1541,y:647,t:1527272034776};\\\", \\\"{x:1540,y:648,t:1527272034787};\\\", \\\"{x:1526,y:650,t:1527272034802};\\\", \\\"{x:1501,y:650,t:1527272034819};\\\", \\\"{x:1445,y:650,t:1527272034837};\\\", \\\"{x:1345,y:650,t:1527272034853};\\\", \\\"{x:1238,y:641,t:1527272034870};\\\", \\\"{x:1125,y:633,t:1527272034886};\\\", \\\"{x:985,y:625,t:1527272034903};\\\", \\\"{x:923,y:622,t:1527272034920};\\\", \\\"{x:891,y:615,t:1527272034936};\\\", \\\"{x:884,y:615,t:1527272034949};\\\", \\\"{x:878,y:615,t:1527272034965};\\\", \\\"{x:873,y:612,t:1527272034983};\\\", \\\"{x:869,y:611,t:1527272034998};\\\", \\\"{x:857,y:611,t:1527272035016};\\\", \\\"{x:844,y:611,t:1527272035033};\\\", \\\"{x:832,y:611,t:1527272035049};\\\", \\\"{x:819,y:611,t:1527272035069};\\\", \\\"{x:810,y:611,t:1527272035086};\\\", \\\"{x:800,y:611,t:1527272035102};\\\", \\\"{x:794,y:611,t:1527272035119};\\\", \\\"{x:787,y:611,t:1527272035136};\\\", \\\"{x:780,y:609,t:1527272035154};\\\", \\\"{x:774,y:609,t:1527272035171};\\\", \\\"{x:766,y:608,t:1527272035187};\\\", \\\"{x:753,y:606,t:1527272035204};\\\", \\\"{x:743,y:603,t:1527272035220};\\\", \\\"{x:735,y:600,t:1527272035236};\\\", \\\"{x:725,y:597,t:1527272035254};\\\", \\\"{x:710,y:592,t:1527272035272};\\\", \\\"{x:692,y:583,t:1527272035288};\\\", \\\"{x:674,y:576,t:1527272035303};\\\", \\\"{x:634,y:565,t:1527272035320};\\\", \\\"{x:606,y:558,t:1527272035337};\\\", \\\"{x:586,y:553,t:1527272035354};\\\", \\\"{x:576,y:551,t:1527272035370};\\\", \\\"{x:572,y:550,t:1527272035387};\\\", \\\"{x:569,y:550,t:1527272035403};\\\", \\\"{x:565,y:549,t:1527272035420};\\\", \\\"{x:563,y:549,t:1527272035437};\\\", \\\"{x:556,y:547,t:1527272035454};\\\", \\\"{x:550,y:547,t:1527272035470};\\\", \\\"{x:539,y:547,t:1527272035487};\\\", \\\"{x:535,y:547,t:1527272035503};\\\", \\\"{x:533,y:547,t:1527272035520};\\\", \\\"{x:532,y:547,t:1527272035552};\\\", \\\"{x:531,y:547,t:1527272035560};\\\", \\\"{x:531,y:548,t:1527272035616};\\\", \\\"{x:531,y:550,t:1527272035624};\\\", \\\"{x:531,y:552,t:1527272035639};\\\", \\\"{x:531,y:553,t:1527272035686};\\\", \\\"{x:535,y:557,t:1527272036473};\\\", \\\"{x:552,y:561,t:1527272036488};\\\", \\\"{x:581,y:566,t:1527272036504};\\\", \\\"{x:608,y:570,t:1527272036521};\\\", \\\"{x:636,y:578,t:1527272036538};\\\", \\\"{x:651,y:583,t:1527272036554};\\\", \\\"{x:658,y:585,t:1527272036571};\\\", \\\"{x:661,y:586,t:1527272036587};\\\", \\\"{x:662,y:586,t:1527272036728};\\\", \\\"{x:661,y:588,t:1527272036737};\\\", \\\"{x:656,y:592,t:1527272036756};\\\", \\\"{x:647,y:596,t:1527272036771};\\\", \\\"{x:639,y:601,t:1527272036788};\\\", \\\"{x:630,y:607,t:1527272036805};\\\", \\\"{x:619,y:611,t:1527272036822};\\\", \\\"{x:606,y:616,t:1527272036837};\\\", \\\"{x:594,y:622,t:1527272036854};\\\", \\\"{x:575,y:627,t:1527272036871};\\\", \\\"{x:565,y:630,t:1527272036887};\\\", \\\"{x:556,y:631,t:1527272036904};\\\", \\\"{x:551,y:632,t:1527272036922};\\\", \\\"{x:547,y:633,t:1527272036937};\\\", \\\"{x:546,y:634,t:1527272036955};\\\", \\\"{x:545,y:634,t:1527272036972};\\\", \\\"{x:538,y:634,t:1527272036988};\\\", \\\"{x:522,y:632,t:1527272037005};\\\", \\\"{x:499,y:624,t:1527272037022};\\\", \\\"{x:477,y:618,t:1527272037039};\\\", \\\"{x:454,y:615,t:1527272037054};\\\", \\\"{x:428,y:607,t:1527272037072};\\\", \\\"{x:419,y:605,t:1527272037087};\\\", \\\"{x:415,y:604,t:1527272037105};\\\", \\\"{x:413,y:603,t:1527272037121};\\\", \\\"{x:412,y:603,t:1527272037138};\\\", \\\"{x:410,y:603,t:1527272037155};\\\", \\\"{x:409,y:603,t:1527272037172};\\\", \\\"{x:406,y:604,t:1527272037188};\\\", \\\"{x:404,y:607,t:1527272037205};\\\", \\\"{x:402,y:609,t:1527272037222};\\\", \\\"{x:401,y:612,t:1527272037238};\\\", \\\"{x:401,y:614,t:1527272037255};\\\", \\\"{x:401,y:616,t:1527272037272};\\\", \\\"{x:401,y:617,t:1527272037288};\\\", \\\"{x:401,y:618,t:1527272037305};\\\", \\\"{x:401,y:619,t:1527272037321};\\\", \\\"{x:402,y:620,t:1527272037496};\\\", \\\"{x:406,y:619,t:1527272037505};\\\", \\\"{x:415,y:619,t:1527272037521};\\\", \\\"{x:424,y:618,t:1527272037539};\\\", \\\"{x:438,y:618,t:1527272037554};\\\", \\\"{x:453,y:618,t:1527272037572};\\\", \\\"{x:470,y:618,t:1527272037589};\\\", \\\"{x:499,y:621,t:1527272037607};\\\", \\\"{x:527,y:627,t:1527272037624};\\\", \\\"{x:560,y:631,t:1527272037639};\\\", \\\"{x:601,y:638,t:1527272037655};\\\", \\\"{x:628,y:640,t:1527272037671};\\\", \\\"{x:652,y:645,t:1527272037688};\\\", \\\"{x:669,y:646,t:1527272037705};\\\", \\\"{x:679,y:648,t:1527272037722};\\\", \\\"{x:683,y:648,t:1527272037738};\\\", \\\"{x:684,y:648,t:1527272037775};\\\", \\\"{x:685,y:648,t:1527272037791};\\\", \\\"{x:687,y:648,t:1527272037805};\\\", \\\"{x:688,y:646,t:1527272037822};\\\", \\\"{x:690,y:644,t:1527272037839};\\\", \\\"{x:691,y:642,t:1527272037855};\\\", \\\"{x:691,y:641,t:1527272037873};\\\", \\\"{x:691,y:640,t:1527272037889};\\\", \\\"{x:691,y:638,t:1527272037906};\\\", \\\"{x:691,y:637,t:1527272037923};\\\", \\\"{x:691,y:636,t:1527272037939};\\\", \\\"{x:691,y:635,t:1527272037956};\\\", \\\"{x:691,y:633,t:1527272037974};\\\", \\\"{x:691,y:631,t:1527272037989};\\\", \\\"{x:688,y:628,t:1527272038006};\\\", \\\"{x:682,y:626,t:1527272038024};\\\", \\\"{x:678,y:624,t:1527272038039};\\\", \\\"{x:667,y:621,t:1527272038056};\\\", \\\"{x:660,y:620,t:1527272038073};\\\", \\\"{x:651,y:616,t:1527272038089};\\\", \\\"{x:642,y:615,t:1527272038106};\\\", \\\"{x:634,y:612,t:1527272038123};\\\", \\\"{x:630,y:611,t:1527272038138};\\\", \\\"{x:626,y:611,t:1527272038156};\\\", \\\"{x:625,y:611,t:1527272038172};\\\", \\\"{x:624,y:611,t:1527272038191};\\\", \\\"{x:622,y:611,t:1527272038223};\\\", \\\"{x:620,y:611,t:1527272038238};\\\", \\\"{x:615,y:611,t:1527272038255};\\\", \\\"{x:614,y:611,t:1527272038273};\\\", \\\"{x:613,y:609,t:1527272038456};\\\", \\\"{x:612,y:608,t:1527272038471};\\\", \\\"{x:610,y:605,t:1527272038489};\\\", \\\"{x:609,y:603,t:1527272038505};\\\", \\\"{x:607,y:601,t:1527272038521};\\\", \\\"{x:606,y:599,t:1527272038539};\\\", \\\"{x:605,y:597,t:1527272038556};\\\", \\\"{x:604,y:594,t:1527272038571};\\\", \\\"{x:603,y:589,t:1527272038590};\\\", \\\"{x:603,y:581,t:1527272038606};\\\", \\\"{x:601,y:572,t:1527272038623};\\\", \\\"{x:601,y:565,t:1527272038639};\\\", \\\"{x:601,y:564,t:1527272038656};\\\", \\\"{x:601,y:562,t:1527272038673};\\\", \\\"{x:595,y:562,t:1527272039184};\\\", \\\"{x:583,y:566,t:1527272039191};\\\", \\\"{x:571,y:572,t:1527272039207};\\\", \\\"{x:535,y:590,t:1527272039224};\\\", \\\"{x:516,y:599,t:1527272039240};\\\", \\\"{x:502,y:607,t:1527272039256};\\\", \\\"{x:495,y:611,t:1527272039275};\\\", \\\"{x:487,y:616,t:1527272039289};\\\", \\\"{x:482,y:619,t:1527272039307};\\\", \\\"{x:480,y:620,t:1527272039323};\\\", \\\"{x:476,y:622,t:1527272039340};\\\", \\\"{x:472,y:622,t:1527272039356};\\\", \\\"{x:464,y:622,t:1527272039373};\\\", \\\"{x:454,y:622,t:1527272039389};\\\", \\\"{x:435,y:620,t:1527272039407};\\\", \\\"{x:420,y:615,t:1527272039423};\\\", \\\"{x:411,y:613,t:1527272039440};\\\", \\\"{x:402,y:611,t:1527272039456};\\\", \\\"{x:392,y:607,t:1527272039473};\\\", \\\"{x:383,y:604,t:1527272039491};\\\", \\\"{x:371,y:602,t:1527272039507};\\\", \\\"{x:363,y:602,t:1527272039524};\\\", \\\"{x:357,y:602,t:1527272039540};\\\", \\\"{x:355,y:600,t:1527272039556};\\\", \\\"{x:354,y:600,t:1527272039591};\\\", \\\"{x:352,y:600,t:1527272039816};\\\", \\\"{x:351,y:600,t:1527272039840};\\\", \\\"{x:351,y:599,t:1527272039896};\\\", \\\"{x:355,y:599,t:1527272039912};\\\", \\\"{x:358,y:599,t:1527272039924};\\\", \\\"{x:362,y:599,t:1527272039940};\\\", \\\"{x:366,y:599,t:1527272039956};\\\", \\\"{x:368,y:599,t:1527272039974};\\\", \\\"{x:369,y:599,t:1527272039991};\\\", \\\"{x:370,y:599,t:1527272040007};\\\", \\\"{x:372,y:599,t:1527272040023};\\\", \\\"{x:374,y:599,t:1527272040041};\\\", \\\"{x:376,y:599,t:1527272040057};\\\", \\\"{x:383,y:606,t:1527272040480};\\\", \\\"{x:395,y:622,t:1527272040491};\\\", \\\"{x:429,y:655,t:1527272040508};\\\", \\\"{x:470,y:689,t:1527272040526};\\\", \\\"{x:505,y:719,t:1527272040542};\\\", \\\"{x:536,y:739,t:1527272040558};\\\", \\\"{x:559,y:759,t:1527272040576};\\\", \\\"{x:574,y:769,t:1527272040591};\\\", \\\"{x:582,y:773,t:1527272040608};\\\", \\\"{x:584,y:775,t:1527272040624};\\\", \\\"{x:587,y:775,t:1527272040641};\\\", \\\"{x:587,y:774,t:1527272040752};\\\", \\\"{x:587,y:769,t:1527272040759};\\\", \\\"{x:585,y:767,t:1527272040775};\\\", \\\"{x:575,y:759,t:1527272040791};\\\", \\\"{x:555,y:749,t:1527272040809};\\\", \\\"{x:545,y:743,t:1527272040824};\\\", \\\"{x:529,y:737,t:1527272040840};\\\", \\\"{x:521,y:733,t:1527272040858};\\\", \\\"{x:511,y:728,t:1527272040875};\\\", \\\"{x:509,y:726,t:1527272040892};\\\", \\\"{x:509,y:725,t:1527272040959};\\\", \\\"{x:516,y:722,t:1527272041648};\\\", \\\"{x:525,y:719,t:1527272041659};\\\", \\\"{x:559,y:704,t:1527272041675};\\\", \\\"{x:608,y:692,t:1527272041692};\\\", \\\"{x:673,y:680,t:1527272041710};\\\", \\\"{x:773,y:668,t:1527272041725};\\\", \\\"{x:848,y:655,t:1527272041742};\\\", \\\"{x:929,y:635,t:1527272041759};\\\", \\\"{x:949,y:628,t:1527272041775};\\\", \\\"{x:989,y:617,t:1527272041792};\\\", \\\"{x:999,y:614,t:1527272041809};\\\", \\\"{x:1008,y:611,t:1527272041825};\\\", \\\"{x:1011,y:610,t:1527272041842};\\\", \\\"{x:1012,y:610,t:1527272041859};\\\", \\\"{x:995,y:602,t:1527272042311};\\\", \\\"{x:988,y:600,t:1527272042325};\\\", \\\"{x:971,y:598,t:1527272042343};\\\", \\\"{x:963,y:598,t:1527272042359};\\\", \\\"{x:960,y:598,t:1527272042375};\\\", \\\"{x:958,y:598,t:1527272042432};\\\", \\\"{x:957,y:597,t:1527272042443};\\\", \\\"{x:953,y:597,t:1527272042459};\\\", \\\"{x:947,y:596,t:1527272042475};\\\", \\\"{x:941,y:596,t:1527272042493};\\\", \\\"{x:935,y:596,t:1527272042509};\\\", \\\"{x:934,y:596,t:1527272042525};\\\", \\\"{x:930,y:596,t:1527272042543};\\\", \\\"{x:929,y:596,t:1527272042558};\\\", \\\"{x:927,y:594,t:1527272042576};\\\", \\\"{x:925,y:594,t:1527272042593};\\\" ] }, { \\\"rt\\\": 14683, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 472794, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:804,y:576,t:1527272042775};\\\", \\\"{x:802,y:576,t:1527272042793};\\\", \\\"{x:800,y:576,t:1527272042810};\\\", \\\"{x:797,y:573,t:1527272043520};\\\", \\\"{x:788,y:567,t:1527272043528};\\\", \\\"{x:765,y:553,t:1527272043545};\\\", \\\"{x:725,y:536,t:1527272043560};\\\", \\\"{x:674,y:517,t:1527272043578};\\\", \\\"{x:610,y:497,t:1527272043594};\\\", \\\"{x:543,y:478,t:1527272043610};\\\", \\\"{x:487,y:464,t:1527272043627};\\\", \\\"{x:454,y:454,t:1527272043643};\\\", \\\"{x:433,y:449,t:1527272043659};\\\", \\\"{x:420,y:444,t:1527272043677};\\\", \\\"{x:415,y:442,t:1527272043694};\\\", \\\"{x:414,y:442,t:1527272043710};\\\", \\\"{x:412,y:441,t:1527272043726};\\\", \\\"{x:414,y:441,t:1527272043944};\\\", \\\"{x:418,y:442,t:1527272043961};\\\", \\\"{x:422,y:443,t:1527272043977};\\\", \\\"{x:425,y:444,t:1527272043994};\\\", \\\"{x:430,y:445,t:1527272044012};\\\", \\\"{x:437,y:447,t:1527272044028};\\\", \\\"{x:447,y:448,t:1527272044044};\\\", \\\"{x:460,y:451,t:1527272044062};\\\", \\\"{x:469,y:452,t:1527272044078};\\\", \\\"{x:475,y:452,t:1527272044095};\\\", \\\"{x:481,y:452,t:1527272044112};\\\", \\\"{x:482,y:452,t:1527272044145};\\\", \\\"{x:484,y:452,t:1527272044520};\\\", \\\"{x:485,y:452,t:1527272044528};\\\", \\\"{x:491,y:452,t:1527272044544};\\\", \\\"{x:500,y:454,t:1527272044562};\\\", \\\"{x:512,y:456,t:1527272044579};\\\", \\\"{x:526,y:459,t:1527272044595};\\\", \\\"{x:536,y:460,t:1527272044611};\\\", \\\"{x:547,y:461,t:1527272044628};\\\", \\\"{x:556,y:462,t:1527272044644};\\\", \\\"{x:562,y:463,t:1527272044662};\\\", \\\"{x:566,y:464,t:1527272044679};\\\", \\\"{x:570,y:465,t:1527272044695};\\\", \\\"{x:571,y:465,t:1527272044711};\\\", \\\"{x:572,y:465,t:1527272044785};\\\", \\\"{x:573,y:465,t:1527272044832};\\\", \\\"{x:574,y:465,t:1527272044912};\\\", \\\"{x:575,y:465,t:1527272044928};\\\", \\\"{x:578,y:465,t:1527272044944};\\\", \\\"{x:582,y:465,t:1527272044961};\\\", \\\"{x:586,y:465,t:1527272044977};\\\", \\\"{x:594,y:464,t:1527272044995};\\\", \\\"{x:598,y:464,t:1527272045011};\\\", \\\"{x:604,y:463,t:1527272045028};\\\", \\\"{x:607,y:462,t:1527272045045};\\\", \\\"{x:611,y:462,t:1527272045061};\\\", \\\"{x:619,y:460,t:1527272045078};\\\", \\\"{x:631,y:460,t:1527272045095};\\\", \\\"{x:640,y:460,t:1527272045111};\\\", \\\"{x:646,y:460,t:1527272045128};\\\", \\\"{x:648,y:460,t:1527272045145};\\\", \\\"{x:649,y:460,t:1527272045167};\\\", \\\"{x:652,y:460,t:1527272046296};\\\", \\\"{x:671,y:463,t:1527272046312};\\\", \\\"{x:697,y:466,t:1527272046329};\\\", \\\"{x:725,y:471,t:1527272046347};\\\", \\\"{x:755,y:474,t:1527272046362};\\\", \\\"{x:784,y:479,t:1527272046379};\\\", \\\"{x:810,y:487,t:1527272046398};\\\", \\\"{x:838,y:494,t:1527272046412};\\\", \\\"{x:861,y:500,t:1527272046429};\\\", \\\"{x:889,y:503,t:1527272046441};\\\", \\\"{x:923,y:509,t:1527272046458};\\\", \\\"{x:951,y:515,t:1527272046475};\\\", \\\"{x:976,y:520,t:1527272046491};\\\", \\\"{x:1006,y:525,t:1527272046513};\\\", \\\"{x:1019,y:529,t:1527272046529};\\\", \\\"{x:1034,y:533,t:1527272046546};\\\", \\\"{x:1048,y:535,t:1527272046563};\\\", \\\"{x:1065,y:541,t:1527272046579};\\\", \\\"{x:1082,y:545,t:1527272046596};\\\", \\\"{x:1101,y:547,t:1527272046613};\\\", \\\"{x:1119,y:550,t:1527272046629};\\\", \\\"{x:1135,y:552,t:1527272046646};\\\", \\\"{x:1154,y:559,t:1527272046663};\\\", \\\"{x:1160,y:561,t:1527272046679};\\\", \\\"{x:1165,y:563,t:1527272046696};\\\", \\\"{x:1168,y:564,t:1527272046713};\\\", \\\"{x:1171,y:564,t:1527272046729};\\\", \\\"{x:1176,y:568,t:1527272046746};\\\", \\\"{x:1179,y:568,t:1527272046763};\\\", \\\"{x:1180,y:569,t:1527272046779};\\\", \\\"{x:1182,y:569,t:1527272046807};\\\", \\\"{x:1181,y:570,t:1527272046896};\\\", \\\"{x:1179,y:570,t:1527272046913};\\\", \\\"{x:1176,y:570,t:1527272046929};\\\", \\\"{x:1173,y:570,t:1527272046947};\\\", \\\"{x:1169,y:570,t:1527272046964};\\\", \\\"{x:1165,y:569,t:1527272046980};\\\", \\\"{x:1164,y:569,t:1527272046997};\\\", \\\"{x:1162,y:569,t:1527272047014};\\\", \\\"{x:1161,y:568,t:1527272047032};\\\", \\\"{x:1161,y:567,t:1527272047312};\\\", \\\"{x:1167,y:567,t:1527272047331};\\\", \\\"{x:1177,y:565,t:1527272047346};\\\", \\\"{x:1186,y:564,t:1527272047363};\\\", \\\"{x:1201,y:562,t:1527272047381};\\\", \\\"{x:1212,y:561,t:1527272047396};\\\", \\\"{x:1228,y:559,t:1527272047414};\\\", \\\"{x:1242,y:559,t:1527272047431};\\\", \\\"{x:1251,y:559,t:1527272047446};\\\", \\\"{x:1266,y:559,t:1527272047463};\\\", \\\"{x:1276,y:559,t:1527272047480};\\\", \\\"{x:1283,y:559,t:1527272047500};\\\", \\\"{x:1293,y:559,t:1527272047515};\\\", \\\"{x:1303,y:559,t:1527272047530};\\\", \\\"{x:1315,y:559,t:1527272047547};\\\", \\\"{x:1329,y:559,t:1527272047563};\\\", \\\"{x:1339,y:559,t:1527272047580};\\\", \\\"{x:1345,y:559,t:1527272047597};\\\", \\\"{x:1352,y:559,t:1527272047613};\\\", \\\"{x:1358,y:559,t:1527272047630};\\\", \\\"{x:1368,y:559,t:1527272047647};\\\", \\\"{x:1375,y:559,t:1527272047663};\\\", \\\"{x:1383,y:559,t:1527272047680};\\\", \\\"{x:1392,y:559,t:1527272047698};\\\", \\\"{x:1401,y:559,t:1527272047713};\\\", \\\"{x:1413,y:559,t:1527272047730};\\\", \\\"{x:1424,y:559,t:1527272047748};\\\", \\\"{x:1434,y:559,t:1527272047763};\\\", \\\"{x:1445,y:559,t:1527272047780};\\\", \\\"{x:1452,y:560,t:1527272047797};\\\", \\\"{x:1458,y:560,t:1527272047813};\\\", \\\"{x:1459,y:560,t:1527272047831};\\\", \\\"{x:1461,y:560,t:1527272047848};\\\", \\\"{x:1461,y:561,t:1527272050800};\\\", \\\"{x:1460,y:563,t:1527272050817};\\\", \\\"{x:1458,y:564,t:1527272050833};\\\", \\\"{x:1455,y:564,t:1527272050850};\\\", \\\"{x:1455,y:565,t:1527272050867};\\\", \\\"{x:1454,y:565,t:1527272051001};\\\", \\\"{x:1451,y:565,t:1527272051017};\\\", \\\"{x:1450,y:565,t:1527272051034};\\\", \\\"{x:1449,y:565,t:1527272051049};\\\", \\\"{x:1448,y:565,t:1527272051066};\\\", \\\"{x:1447,y:565,t:1527272051112};\\\", \\\"{x:1446,y:565,t:1527272051128};\\\", \\\"{x:1445,y:565,t:1527272051136};\\\", \\\"{x:1444,y:566,t:1527272051150};\\\", \\\"{x:1443,y:566,t:1527272051167};\\\", \\\"{x:1442,y:566,t:1527272051192};\\\", \\\"{x:1441,y:566,t:1527272051240};\\\", \\\"{x:1440,y:566,t:1527272051256};\\\", \\\"{x:1439,y:566,t:1527272051266};\\\", \\\"{x:1438,y:566,t:1527272051287};\\\", \\\"{x:1437,y:566,t:1527272051300};\\\", \\\"{x:1436,y:566,t:1527272051317};\\\", \\\"{x:1434,y:566,t:1527272051334};\\\", \\\"{x:1431,y:566,t:1527272051350};\\\", \\\"{x:1428,y:566,t:1527272051366};\\\", \\\"{x:1427,y:566,t:1527272051384};\\\", \\\"{x:1426,y:566,t:1527272051401};\\\", \\\"{x:1425,y:566,t:1527272051424};\\\", \\\"{x:1424,y:566,t:1527272051456};\\\", \\\"{x:1423,y:566,t:1527272051488};\\\", \\\"{x:1422,y:566,t:1527272051503};\\\", \\\"{x:1421,y:566,t:1527272051528};\\\", \\\"{x:1421,y:567,t:1527272051585};\\\", \\\"{x:1420,y:567,t:1527272051977};\\\", \\\"{x:1419,y:567,t:1527272051992};\\\", \\\"{x:1418,y:567,t:1527272052001};\\\", \\\"{x:1416,y:567,t:1527272052034};\\\", \\\"{x:1416,y:568,t:1527272052051};\\\", \\\"{x:1415,y:568,t:1527272052067};\\\", \\\"{x:1413,y:568,t:1527272052084};\\\", \\\"{x:1409,y:568,t:1527272052102};\\\", \\\"{x:1406,y:568,t:1527272052118};\\\", \\\"{x:1401,y:568,t:1527272052134};\\\", \\\"{x:1396,y:568,t:1527272052151};\\\", \\\"{x:1380,y:568,t:1527272052167};\\\", \\\"{x:1362,y:568,t:1527272052184};\\\", \\\"{x:1337,y:568,t:1527272052201};\\\", \\\"{x:1308,y:571,t:1527272052218};\\\", \\\"{x:1259,y:574,t:1527272052234};\\\", \\\"{x:1183,y:578,t:1527272052251};\\\", \\\"{x:1113,y:578,t:1527272052268};\\\", \\\"{x:1041,y:580,t:1527272052284};\\\", \\\"{x:955,y:580,t:1527272052300};\\\", \\\"{x:857,y:580,t:1527272052318};\\\", \\\"{x:766,y:580,t:1527272052334};\\\", \\\"{x:683,y:580,t:1527272052351};\\\", \\\"{x:599,y:580,t:1527272052367};\\\", \\\"{x:562,y:580,t:1527272052384};\\\", \\\"{x:538,y:580,t:1527272052400};\\\", \\\"{x:525,y:580,t:1527272052417};\\\", \\\"{x:518,y:582,t:1527272052434};\\\", \\\"{x:513,y:584,t:1527272052450};\\\", \\\"{x:511,y:585,t:1527272052467};\\\", \\\"{x:509,y:586,t:1527272052485};\\\", \\\"{x:509,y:587,t:1527272052501};\\\", \\\"{x:506,y:589,t:1527272052518};\\\", \\\"{x:505,y:590,t:1527272052535};\\\", \\\"{x:502,y:591,t:1527272052550};\\\", \\\"{x:502,y:592,t:1527272052567};\\\", \\\"{x:501,y:593,t:1527272052640};\\\", \\\"{x:501,y:594,t:1527272052656};\\\", \\\"{x:501,y:595,t:1527272052667};\\\", \\\"{x:510,y:599,t:1527272052685};\\\", \\\"{x:529,y:602,t:1527272052702};\\\", \\\"{x:553,y:605,t:1527272052718};\\\", \\\"{x:579,y:610,t:1527272052735};\\\", \\\"{x:613,y:616,t:1527272052750};\\\", \\\"{x:630,y:619,t:1527272052767};\\\", \\\"{x:645,y:623,t:1527272052784};\\\", \\\"{x:654,y:626,t:1527272052801};\\\", \\\"{x:656,y:626,t:1527272052817};\\\", \\\"{x:657,y:626,t:1527272052871};\\\", \\\"{x:657,y:625,t:1527272052884};\\\", \\\"{x:657,y:623,t:1527272052901};\\\", \\\"{x:658,y:619,t:1527272052917};\\\", \\\"{x:660,y:611,t:1527272052934};\\\", \\\"{x:660,y:604,t:1527272052950};\\\", \\\"{x:660,y:600,t:1527272052967};\\\", \\\"{x:660,y:592,t:1527272052985};\\\", \\\"{x:660,y:586,t:1527272053001};\\\", \\\"{x:658,y:577,t:1527272053018};\\\", \\\"{x:652,y:564,t:1527272053034};\\\", \\\"{x:645,y:551,t:1527272053052};\\\", \\\"{x:633,y:534,t:1527272053068};\\\", \\\"{x:618,y:522,t:1527272053085};\\\", \\\"{x:600,y:510,t:1527272053102};\\\", \\\"{x:588,y:502,t:1527272053119};\\\", \\\"{x:578,y:497,t:1527272053134};\\\", \\\"{x:576,y:496,t:1527272053152};\\\", \\\"{x:576,y:495,t:1527272053223};\\\", \\\"{x:576,y:494,t:1527272053239};\\\", \\\"{x:576,y:493,t:1527272053280};\\\", \\\"{x:576,y:492,t:1527272053287};\\\", \\\"{x:576,y:491,t:1527272053319};\\\", \\\"{x:577,y:491,t:1527272053343};\\\", \\\"{x:579,y:490,t:1527272053351};\\\", \\\"{x:580,y:490,t:1527272053367};\\\", \\\"{x:584,y:490,t:1527272053385};\\\", \\\"{x:586,y:490,t:1527272053401};\\\", \\\"{x:587,y:490,t:1527272053417};\\\", \\\"{x:589,y:490,t:1527272053434};\\\", \\\"{x:590,y:490,t:1527272053463};\\\", \\\"{x:591,y:490,t:1527272053471};\\\", \\\"{x:592,y:490,t:1527272053487};\\\", \\\"{x:593,y:490,t:1527272053503};\\\", \\\"{x:594,y:490,t:1527272053518};\\\", \\\"{x:595,y:490,t:1527272053535};\\\", \\\"{x:596,y:491,t:1527272053551};\\\", \\\"{x:598,y:492,t:1527272053568};\\\", \\\"{x:599,y:492,t:1527272053584};\\\", \\\"{x:600,y:492,t:1527272054017};\\\", \\\"{x:603,y:492,t:1527272054079};\\\", \\\"{x:611,y:495,t:1527272054087};\\\", \\\"{x:619,y:498,t:1527272054103};\\\", \\\"{x:653,y:513,t:1527272054119};\\\", \\\"{x:730,y:533,t:1527272054136};\\\", \\\"{x:791,y:550,t:1527272054152};\\\", \\\"{x:841,y:564,t:1527272054169};\\\", \\\"{x:872,y:571,t:1527272054185};\\\", \\\"{x:890,y:578,t:1527272054202};\\\", \\\"{x:896,y:581,t:1527272054219};\\\", \\\"{x:897,y:582,t:1527272054235};\\\", \\\"{x:897,y:583,t:1527272054352};\\\", \\\"{x:895,y:583,t:1527272054400};\\\", \\\"{x:891,y:582,t:1527272054407};\\\", \\\"{x:885,y:581,t:1527272054419};\\\", \\\"{x:876,y:576,t:1527272054436};\\\", \\\"{x:861,y:568,t:1527272054454};\\\", \\\"{x:852,y:562,t:1527272054469};\\\", \\\"{x:846,y:559,t:1527272054485};\\\", \\\"{x:842,y:557,t:1527272054503};\\\", \\\"{x:840,y:557,t:1527272054518};\\\", \\\"{x:839,y:556,t:1527272054535};\\\", \\\"{x:838,y:555,t:1527272054552};\\\", \\\"{x:836,y:554,t:1527272054720};\\\", \\\"{x:830,y:551,t:1527272054736};\\\", \\\"{x:813,y:547,t:1527272054752};\\\", \\\"{x:788,y:542,t:1527272054770};\\\", \\\"{x:756,y:539,t:1527272054785};\\\", \\\"{x:711,y:532,t:1527272054803};\\\", \\\"{x:667,y:526,t:1527272054820};\\\", \\\"{x:629,y:518,t:1527272054837};\\\", \\\"{x:603,y:515,t:1527272054852};\\\", \\\"{x:594,y:513,t:1527272054869};\\\", \\\"{x:592,y:513,t:1527272054886};\\\", \\\"{x:591,y:513,t:1527272054983};\\\", \\\"{x:591,y:512,t:1527272055024};\\\", \\\"{x:591,y:510,t:1527272055039};\\\", \\\"{x:593,y:508,t:1527272055053};\\\", \\\"{x:597,y:506,t:1527272055069};\\\", \\\"{x:603,y:502,t:1527272055088};\\\", \\\"{x:608,y:501,t:1527272055102};\\\", \\\"{x:611,y:498,t:1527272055119};\\\", \\\"{x:618,y:498,t:1527272055631};\\\", \\\"{x:625,y:498,t:1527272055639};\\\", \\\"{x:636,y:498,t:1527272055654};\\\", \\\"{x:663,y:500,t:1527272055671};\\\", \\\"{x:706,y:508,t:1527272055686};\\\", \\\"{x:762,y:517,t:1527272055704};\\\", \\\"{x:792,y:520,t:1527272055720};\\\", \\\"{x:808,y:523,t:1527272055736};\\\", \\\"{x:816,y:525,t:1527272055754};\\\", \\\"{x:818,y:525,t:1527272055769};\\\", \\\"{x:819,y:526,t:1527272055786};\\\", \\\"{x:819,y:528,t:1527272055912};\\\", \\\"{x:820,y:530,t:1527272055920};\\\", \\\"{x:822,y:534,t:1527272055937};\\\", \\\"{x:823,y:537,t:1527272055954};\\\", \\\"{x:824,y:538,t:1527272055972};\\\", \\\"{x:824,y:539,t:1527272056024};\\\", \\\"{x:825,y:539,t:1527272056519};\\\", \\\"{x:826,y:539,t:1527272056527};\\\", \\\"{x:827,y:539,t:1527272056538};\\\", \\\"{x:828,y:539,t:1527272056553};\\\", \\\"{x:829,y:540,t:1527272056570};\\\", \\\"{x:830,y:540,t:1527272056588};\\\", \\\"{x:831,y:541,t:1527272056603};\\\", \\\"{x:831,y:542,t:1527272056720};\\\", \\\"{x:826,y:547,t:1527272056738};\\\", \\\"{x:818,y:556,t:1527272056756};\\\", \\\"{x:806,y:571,t:1527272056771};\\\", \\\"{x:785,y:587,t:1527272056787};\\\", \\\"{x:758,y:611,t:1527272056806};\\\", \\\"{x:725,y:636,t:1527272056821};\\\", \\\"{x:689,y:661,t:1527272056837};\\\", \\\"{x:660,y:682,t:1527272056854};\\\", \\\"{x:615,y:713,t:1527272056870};\\\", \\\"{x:593,y:726,t:1527272056887};\\\", \\\"{x:579,y:736,t:1527272056904};\\\", \\\"{x:573,y:742,t:1527272056921};\\\", \\\"{x:572,y:743,t:1527272056938};\\\", \\\"{x:571,y:746,t:1527272056955};\\\", \\\"{x:570,y:748,t:1527272056971};\\\", \\\"{x:568,y:749,t:1527272056987};\\\", \\\"{x:567,y:750,t:1527272057004};\\\", \\\"{x:566,y:750,t:1527272057024};\\\", \\\"{x:564,y:750,t:1527272057039};\\\", \\\"{x:563,y:750,t:1527272057056};\\\", \\\"{x:561,y:750,t:1527272057078};\\\", \\\"{x:559,y:750,t:1527272057095};\\\", \\\"{x:555,y:750,t:1527272057104};\\\", \\\"{x:547,y:744,t:1527272057122};\\\", \\\"{x:536,y:740,t:1527272057138};\\\", \\\"{x:526,y:735,t:1527272057154};\\\", \\\"{x:517,y:733,t:1527272057172};\\\", \\\"{x:511,y:731,t:1527272057188};\\\", \\\"{x:509,y:729,t:1527272057204};\\\", \\\"{x:509,y:726,t:1527272057736};\\\", \\\"{x:509,y:722,t:1527272057744};\\\", \\\"{x:515,y:718,t:1527272057755};\\\", \\\"{x:539,y:708,t:1527272057772};\\\", \\\"{x:582,y:692,t:1527272057789};\\\", \\\"{x:648,y:674,t:1527272057806};\\\", \\\"{x:731,y:653,t:1527272057822};\\\", \\\"{x:818,y:636,t:1527272057838};\\\", \\\"{x:939,y:620,t:1527272057855};\\\", \\\"{x:998,y:610,t:1527272057872};\\\", \\\"{x:1036,y:604,t:1527272057889};\\\", \\\"{x:1053,y:599,t:1527272057906};\\\", \\\"{x:1058,y:599,t:1527272057921};\\\", \\\"{x:1059,y:599,t:1527272057939};\\\", \\\"{x:1059,y:598,t:1527272058256};\\\", \\\"{x:1053,y:595,t:1527272058273};\\\", \\\"{x:1038,y:588,t:1527272058289};\\\", \\\"{x:1024,y:583,t:1527272058306};\\\", \\\"{x:1013,y:579,t:1527272058323};\\\", \\\"{x:1003,y:577,t:1527272058338};\\\", \\\"{x:991,y:577,t:1527272058355};\\\", \\\"{x:985,y:577,t:1527272058373};\\\", \\\"{x:978,y:579,t:1527272058389};\\\", \\\"{x:976,y:579,t:1527272058406};\\\", \\\"{x:973,y:580,t:1527272058422};\\\", \\\"{x:972,y:580,t:1527272058439};\\\", \\\"{x:969,y:580,t:1527272058455};\\\", \\\"{x:968,y:580,t:1527272058473};\\\", \\\"{x:966,y:580,t:1527272058501};\\\", \\\"{x:965,y:580,t:1527272058505};\\\" ] }, { \\\"rt\\\": 20258, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 494284, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:962,y:581,t:1527272058705};\\\", \\\"{x:958,y:582,t:1527272058721};\\\", \\\"{x:952,y:584,t:1527272058739};\\\", \\\"{x:942,y:585,t:1527272058756};\\\", \\\"{x:931,y:587,t:1527272058772};\\\", \\\"{x:925,y:587,t:1527272058788};\\\", \\\"{x:924,y:587,t:1527272058806};\\\", \\\"{x:924,y:586,t:1527272058822};\\\", \\\"{x:923,y:586,t:1527272059464};\\\", \\\"{x:923,y:585,t:1527272059807};\\\", \\\"{x:923,y:583,t:1527272059920};\\\", \\\"{x:923,y:582,t:1527272059928};\\\", \\\"{x:923,y:581,t:1527272059940};\\\", \\\"{x:923,y:577,t:1527272059956};\\\", \\\"{x:923,y:571,t:1527272059973};\\\", \\\"{x:918,y:559,t:1527272059991};\\\", \\\"{x:902,y:546,t:1527272060007};\\\", \\\"{x:868,y:530,t:1527272060024};\\\", \\\"{x:821,y:509,t:1527272060040};\\\", \\\"{x:749,y:489,t:1527272060057};\\\", \\\"{x:661,y:466,t:1527272060074};\\\", \\\"{x:563,y:449,t:1527272060090};\\\", \\\"{x:467,y:429,t:1527272060107};\\\", \\\"{x:407,y:414,t:1527272060124};\\\", \\\"{x:350,y:405,t:1527272060141};\\\", \\\"{x:320,y:397,t:1527272060157};\\\", \\\"{x:301,y:394,t:1527272060174};\\\", \\\"{x:287,y:392,t:1527272060191};\\\", \\\"{x:281,y:390,t:1527272060206};\\\", \\\"{x:275,y:389,t:1527272060224};\\\", \\\"{x:274,y:389,t:1527272060240};\\\", \\\"{x:273,y:389,t:1527272060257};\\\", \\\"{x:272,y:389,t:1527272060303};\\\", \\\"{x:272,y:390,t:1527272060311};\\\", \\\"{x:272,y:392,t:1527272060324};\\\", \\\"{x:272,y:396,t:1527272060341};\\\", \\\"{x:275,y:402,t:1527272060357};\\\", \\\"{x:282,y:408,t:1527272060374};\\\", \\\"{x:299,y:417,t:1527272060392};\\\", \\\"{x:305,y:420,t:1527272060406};\\\", \\\"{x:324,y:426,t:1527272060424};\\\", \\\"{x:339,y:430,t:1527272060441};\\\", \\\"{x:354,y:435,t:1527272060457};\\\", \\\"{x:371,y:441,t:1527272060474};\\\", \\\"{x:390,y:446,t:1527272060491};\\\", \\\"{x:410,y:452,t:1527272060508};\\\", \\\"{x:428,y:456,t:1527272060523};\\\", \\\"{x:439,y:457,t:1527272060541};\\\", \\\"{x:444,y:458,t:1527272060557};\\\", \\\"{x:446,y:458,t:1527272060928};\\\", \\\"{x:448,y:458,t:1527272060941};\\\", \\\"{x:455,y:458,t:1527272060959};\\\", \\\"{x:475,y:460,t:1527272060976};\\\", \\\"{x:485,y:461,t:1527272060991};\\\", \\\"{x:517,y:466,t:1527272061008};\\\", \\\"{x:536,y:469,t:1527272061025};\\\", \\\"{x:554,y:471,t:1527272061041};\\\", \\\"{x:566,y:473,t:1527272061058};\\\", \\\"{x:572,y:474,t:1527272061076};\\\", \\\"{x:577,y:474,t:1527272061091};\\\", \\\"{x:579,y:475,t:1527272061108};\\\", \\\"{x:580,y:475,t:1527272061125};\\\", \\\"{x:581,y:475,t:1527272061256};\\\", \\\"{x:583,y:475,t:1527272061271};\\\", \\\"{x:584,y:473,t:1527272061280};\\\", \\\"{x:585,y:472,t:1527272061295};\\\", \\\"{x:588,y:469,t:1527272061309};\\\", \\\"{x:590,y:467,t:1527272061325};\\\", \\\"{x:592,y:465,t:1527272061342};\\\", \\\"{x:593,y:464,t:1527272061358};\\\", \\\"{x:594,y:464,t:1527272061376};\\\", \\\"{x:595,y:463,t:1527272061392};\\\", \\\"{x:595,y:462,t:1527272061408};\\\", \\\"{x:595,y:460,t:1527272061439};\\\", \\\"{x:597,y:458,t:1527272061463};\\\", \\\"{x:599,y:457,t:1527272061648};\\\", \\\"{x:600,y:457,t:1527272061672};\\\", \\\"{x:601,y:457,t:1527272061777};\\\", \\\"{x:602,y:457,t:1527272061793};\\\", \\\"{x:604,y:457,t:1527272061809};\\\", \\\"{x:607,y:457,t:1527272061825};\\\", \\\"{x:609,y:457,t:1527272061842};\\\", \\\"{x:610,y:457,t:1527272061859};\\\", \\\"{x:612,y:457,t:1527272061875};\\\", \\\"{x:613,y:457,t:1527272061893};\\\", \\\"{x:615,y:457,t:1527272061909};\\\", \\\"{x:616,y:457,t:1527272061926};\\\", \\\"{x:621,y:456,t:1527272061943};\\\", \\\"{x:629,y:456,t:1527272061959};\\\", \\\"{x:633,y:455,t:1527272061976};\\\", \\\"{x:636,y:455,t:1527272061992};\\\", \\\"{x:638,y:455,t:1527272062009};\\\", \\\"{x:637,y:453,t:1527272062624};\\\", \\\"{x:633,y:452,t:1527272062631};\\\", \\\"{x:628,y:449,t:1527272062643};\\\", \\\"{x:619,y:445,t:1527272062659};\\\", \\\"{x:611,y:444,t:1527272062676};\\\", \\\"{x:588,y:444,t:1527272062692};\\\", \\\"{x:568,y:442,t:1527272062709};\\\", \\\"{x:555,y:438,t:1527272062726};\\\", \\\"{x:552,y:438,t:1527272062743};\\\", \\\"{x:551,y:438,t:1527272062807};\\\", \\\"{x:552,y:438,t:1527272062984};\\\", \\\"{x:553,y:438,t:1527272062994};\\\", \\\"{x:554,y:438,t:1527272063010};\\\", \\\"{x:559,y:439,t:1527272063026};\\\", \\\"{x:568,y:439,t:1527272063043};\\\", \\\"{x:583,y:440,t:1527272063060};\\\", \\\"{x:604,y:445,t:1527272063076};\\\", \\\"{x:626,y:446,t:1527272063093};\\\", \\\"{x:648,y:449,t:1527272063110};\\\", \\\"{x:669,y:454,t:1527272063126};\\\", \\\"{x:689,y:455,t:1527272063143};\\\", \\\"{x:698,y:456,t:1527272063159};\\\", \\\"{x:700,y:456,t:1527272063176};\\\", \\\"{x:702,y:457,t:1527272063194};\\\", \\\"{x:702,y:458,t:1527272063808};\\\", \\\"{x:703,y:458,t:1527272063815};\\\", \\\"{x:704,y:458,t:1527272063827};\\\", \\\"{x:707,y:458,t:1527272063844};\\\", \\\"{x:710,y:458,t:1527272063860};\\\", \\\"{x:714,y:458,t:1527272063877};\\\", \\\"{x:717,y:458,t:1527272063894};\\\", \\\"{x:718,y:458,t:1527272063910};\\\", \\\"{x:720,y:458,t:1527272063928};\\\", \\\"{x:722,y:458,t:1527272063943};\\\", \\\"{x:723,y:458,t:1527272063961};\\\", \\\"{x:724,y:458,t:1527272064032};\\\", \\\"{x:726,y:458,t:1527272064144};\\\", \\\"{x:735,y:458,t:1527272064161};\\\", \\\"{x:761,y:465,t:1527272064177};\\\", \\\"{x:808,y:479,t:1527272064194};\\\", \\\"{x:875,y:496,t:1527272064213};\\\", \\\"{x:948,y:522,t:1527272064230};\\\", \\\"{x:1039,y:545,t:1527272064247};\\\", \\\"{x:1125,y:570,t:1527272064263};\\\", \\\"{x:1212,y:599,t:1527272064280};\\\", \\\"{x:1289,y:621,t:1527272064297};\\\", \\\"{x:1378,y:646,t:1527272064314};\\\", \\\"{x:1421,y:660,t:1527272064330};\\\", \\\"{x:1453,y:669,t:1527272064347};\\\", \\\"{x:1470,y:673,t:1527272064364};\\\", \\\"{x:1477,y:677,t:1527272064381};\\\", \\\"{x:1478,y:678,t:1527272064398};\\\", \\\"{x:1477,y:678,t:1527272064500};\\\", \\\"{x:1465,y:681,t:1527272064515};\\\", \\\"{x:1447,y:686,t:1527272064531};\\\", \\\"{x:1422,y:689,t:1527272064548};\\\", \\\"{x:1394,y:694,t:1527272064565};\\\", \\\"{x:1362,y:698,t:1527272064580};\\\", \\\"{x:1333,y:704,t:1527272064597};\\\", \\\"{x:1308,y:706,t:1527272064614};\\\", \\\"{x:1294,y:706,t:1527272064631};\\\", \\\"{x:1291,y:706,t:1527272064648};\\\", \\\"{x:1290,y:706,t:1527272064723};\\\", \\\"{x:1289,y:706,t:1527272064739};\\\", \\\"{x:1287,y:706,t:1527272064747};\\\", \\\"{x:1283,y:706,t:1527272064764};\\\", \\\"{x:1274,y:703,t:1527272064782};\\\", \\\"{x:1261,y:699,t:1527272064798};\\\", \\\"{x:1242,y:693,t:1527272064815};\\\", \\\"{x:1221,y:687,t:1527272064831};\\\", \\\"{x:1198,y:680,t:1527272064848};\\\", \\\"{x:1182,y:675,t:1527272064865};\\\", \\\"{x:1173,y:673,t:1527272064882};\\\", \\\"{x:1169,y:672,t:1527272064898};\\\", \\\"{x:1167,y:672,t:1527272064915};\\\", \\\"{x:1166,y:671,t:1527272064955};\\\", \\\"{x:1164,y:671,t:1527272064978};\\\", \\\"{x:1166,y:671,t:1527272065306};\\\", \\\"{x:1168,y:671,t:1527272065323};\\\", \\\"{x:1170,y:671,t:1527272065331};\\\", \\\"{x:1176,y:671,t:1527272065349};\\\", \\\"{x:1182,y:671,t:1527272065365};\\\", \\\"{x:1193,y:671,t:1527272065382};\\\", \\\"{x:1203,y:671,t:1527272065398};\\\", \\\"{x:1214,y:671,t:1527272065415};\\\", \\\"{x:1224,y:673,t:1527272065431};\\\", \\\"{x:1235,y:673,t:1527272065448};\\\", \\\"{x:1245,y:673,t:1527272065465};\\\", \\\"{x:1255,y:674,t:1527272065481};\\\", \\\"{x:1263,y:674,t:1527272065499};\\\", \\\"{x:1266,y:675,t:1527272065515};\\\", \\\"{x:1269,y:675,t:1527272065532};\\\", \\\"{x:1270,y:675,t:1527272065548};\\\", \\\"{x:1271,y:675,t:1527272065566};\\\", \\\"{x:1272,y:675,t:1527272065581};\\\", \\\"{x:1275,y:675,t:1527272065598};\\\", \\\"{x:1279,y:678,t:1527272065615};\\\", \\\"{x:1284,y:678,t:1527272065631};\\\", \\\"{x:1289,y:681,t:1527272065648};\\\", \\\"{x:1295,y:683,t:1527272065665};\\\", \\\"{x:1299,y:685,t:1527272065681};\\\", \\\"{x:1303,y:687,t:1527272065698};\\\", \\\"{x:1306,y:689,t:1527272065716};\\\", \\\"{x:1310,y:692,t:1527272065731};\\\", \\\"{x:1317,y:697,t:1527272065748};\\\", \\\"{x:1325,y:701,t:1527272065766};\\\", \\\"{x:1332,y:703,t:1527272065781};\\\", \\\"{x:1339,y:705,t:1527272065799};\\\", \\\"{x:1346,y:706,t:1527272065816};\\\", \\\"{x:1352,y:709,t:1527272065831};\\\", \\\"{x:1355,y:709,t:1527272065849};\\\", \\\"{x:1356,y:709,t:1527272069267};\\\", \\\"{x:1356,y:710,t:1527272069284};\\\", \\\"{x:1356,y:720,t:1527272069301};\\\", \\\"{x:1356,y:729,t:1527272069318};\\\", \\\"{x:1356,y:738,t:1527272069334};\\\", \\\"{x:1356,y:748,t:1527272069351};\\\", \\\"{x:1356,y:754,t:1527272069369};\\\", \\\"{x:1356,y:758,t:1527272069385};\\\", \\\"{x:1357,y:760,t:1527272069402};\\\", \\\"{x:1358,y:762,t:1527272069418};\\\", \\\"{x:1358,y:763,t:1527272069435};\\\", \\\"{x:1358,y:765,t:1527272069452};\\\", \\\"{x:1358,y:766,t:1527272069468};\\\", \\\"{x:1358,y:768,t:1527272069484};\\\", \\\"{x:1358,y:769,t:1527272069501};\\\", \\\"{x:1358,y:771,t:1527272069518};\\\", \\\"{x:1358,y:773,t:1527272069534};\\\", \\\"{x:1358,y:774,t:1527272069552};\\\", \\\"{x:1358,y:775,t:1527272069579};\\\", \\\"{x:1358,y:776,t:1527272069594};\\\", \\\"{x:1358,y:777,t:1527272069610};\\\", \\\"{x:1358,y:779,t:1527272069642};\\\", \\\"{x:1357,y:776,t:1527272069819};\\\", \\\"{x:1352,y:766,t:1527272069839};\\\", \\\"{x:1347,y:751,t:1527272069853};\\\", \\\"{x:1342,y:741,t:1527272069869};\\\", \\\"{x:1340,y:732,t:1527272069885};\\\", \\\"{x:1338,y:723,t:1527272069901};\\\", \\\"{x:1337,y:719,t:1527272069918};\\\", \\\"{x:1336,y:714,t:1527272069935};\\\", \\\"{x:1335,y:711,t:1527272069951};\\\", \\\"{x:1335,y:709,t:1527272069968};\\\", \\\"{x:1334,y:707,t:1527272069985};\\\", \\\"{x:1334,y:706,t:1527272070026};\\\", \\\"{x:1334,y:709,t:1527272070315};\\\", \\\"{x:1334,y:713,t:1527272070323};\\\", \\\"{x:1334,y:715,t:1527272070336};\\\", \\\"{x:1334,y:720,t:1527272070353};\\\", \\\"{x:1334,y:724,t:1527272070369};\\\", \\\"{x:1334,y:728,t:1527272070387};\\\", \\\"{x:1334,y:733,t:1527272070403};\\\", \\\"{x:1334,y:735,t:1527272070419};\\\", \\\"{x:1334,y:739,t:1527272070436};\\\", \\\"{x:1334,y:742,t:1527272070453};\\\", \\\"{x:1334,y:746,t:1527272070469};\\\", \\\"{x:1334,y:749,t:1527272070486};\\\", \\\"{x:1334,y:752,t:1527272070503};\\\", \\\"{x:1334,y:755,t:1527272070520};\\\", \\\"{x:1334,y:756,t:1527272070536};\\\", \\\"{x:1334,y:758,t:1527272070554};\\\", \\\"{x:1334,y:760,t:1527272070570};\\\", \\\"{x:1334,y:761,t:1527272070586};\\\", \\\"{x:1334,y:764,t:1527272070602};\\\", \\\"{x:1334,y:765,t:1527272070627};\\\", \\\"{x:1334,y:766,t:1527272070635};\\\", \\\"{x:1334,y:767,t:1527272070653};\\\", \\\"{x:1334,y:768,t:1527272070670};\\\", \\\"{x:1334,y:770,t:1527272070723};\\\", \\\"{x:1335,y:770,t:1527272070736};\\\", \\\"{x:1335,y:771,t:1527272070771};\\\", \\\"{x:1336,y:771,t:1527272071235};\\\", \\\"{x:1336,y:770,t:1527272071275};\\\", \\\"{x:1337,y:768,t:1527272071291};\\\", \\\"{x:1338,y:767,t:1527272071315};\\\", \\\"{x:1338,y:765,t:1527272071338};\\\", \\\"{x:1338,y:764,t:1527272071354};\\\", \\\"{x:1338,y:763,t:1527272071370};\\\", \\\"{x:1338,y:761,t:1527272071386};\\\", \\\"{x:1338,y:760,t:1527272071404};\\\", \\\"{x:1338,y:758,t:1527272071420};\\\", \\\"{x:1338,y:757,t:1527272071442};\\\", \\\"{x:1338,y:756,t:1527272071453};\\\", \\\"{x:1338,y:755,t:1527272071469};\\\", \\\"{x:1339,y:754,t:1527272071486};\\\", \\\"{x:1339,y:753,t:1527272071504};\\\", \\\"{x:1339,y:752,t:1527272071523};\\\", \\\"{x:1340,y:750,t:1527272071547};\\\", \\\"{x:1341,y:752,t:1527272071804};\\\", \\\"{x:1342,y:758,t:1527272071821};\\\", \\\"{x:1342,y:766,t:1527272071837};\\\", \\\"{x:1343,y:774,t:1527272071854};\\\", \\\"{x:1344,y:781,t:1527272071871};\\\", \\\"{x:1344,y:785,t:1527272071887};\\\", \\\"{x:1345,y:788,t:1527272071904};\\\", \\\"{x:1345,y:791,t:1527272071921};\\\", \\\"{x:1345,y:792,t:1527272071937};\\\", \\\"{x:1345,y:793,t:1527272071954};\\\", \\\"{x:1345,y:795,t:1527272071971};\\\", \\\"{x:1345,y:796,t:1527272072251};\\\", \\\"{x:1346,y:796,t:1527272072275};\\\", \\\"{x:1346,y:795,t:1527272072288};\\\", \\\"{x:1346,y:792,t:1527272072304};\\\", \\\"{x:1346,y:789,t:1527272072322};\\\", \\\"{x:1346,y:786,t:1527272072338};\\\", \\\"{x:1346,y:784,t:1527272072354};\\\", \\\"{x:1346,y:783,t:1527272072371};\\\", \\\"{x:1345,y:781,t:1527272072388};\\\", \\\"{x:1345,y:780,t:1527272072411};\\\", \\\"{x:1345,y:779,t:1527272072443};\\\", \\\"{x:1345,y:778,t:1527272072458};\\\", \\\"{x:1345,y:777,t:1527272072470};\\\", \\\"{x:1345,y:776,t:1527272072498};\\\", \\\"{x:1345,y:775,t:1527272072521};\\\", \\\"{x:1345,y:774,t:1527272072554};\\\", \\\"{x:1345,y:773,t:1527272073155};\\\", \\\"{x:1345,y:770,t:1527272073172};\\\", \\\"{x:1345,y:769,t:1527272073188};\\\", \\\"{x:1345,y:768,t:1527272073206};\\\", \\\"{x:1345,y:767,t:1527272073222};\\\", \\\"{x:1343,y:766,t:1527272074171};\\\", \\\"{x:1337,y:767,t:1527272074180};\\\", \\\"{x:1330,y:768,t:1527272074189};\\\", \\\"{x:1304,y:770,t:1527272074206};\\\", \\\"{x:1271,y:773,t:1527272074223};\\\", \\\"{x:1221,y:771,t:1527272074239};\\\", \\\"{x:1156,y:761,t:1527272074256};\\\", \\\"{x:1110,y:750,t:1527272074273};\\\", \\\"{x:1077,y:740,t:1527272074289};\\\", \\\"{x:1057,y:734,t:1527272074307};\\\", \\\"{x:1051,y:732,t:1527272074322};\\\", \\\"{x:1044,y:729,t:1527272074339};\\\", \\\"{x:1035,y:726,t:1527272074356};\\\", \\\"{x:1021,y:722,t:1527272074373};\\\", \\\"{x:1005,y:718,t:1527272074388};\\\", \\\"{x:987,y:715,t:1527272074406};\\\", \\\"{x:966,y:712,t:1527272074423};\\\", \\\"{x:949,y:708,t:1527272074439};\\\", \\\"{x:935,y:705,t:1527272074456};\\\", \\\"{x:922,y:700,t:1527272074473};\\\", \\\"{x:910,y:695,t:1527272074489};\\\", \\\"{x:889,y:685,t:1527272074506};\\\", \\\"{x:876,y:679,t:1527272074523};\\\", \\\"{x:857,y:673,t:1527272074539};\\\", \\\"{x:840,y:664,t:1527272074556};\\\", \\\"{x:817,y:654,t:1527272074573};\\\", \\\"{x:795,y:646,t:1527272074590};\\\", \\\"{x:772,y:636,t:1527272074606};\\\", \\\"{x:751,y:626,t:1527272074624};\\\", \\\"{x:731,y:618,t:1527272074639};\\\", \\\"{x:715,y:611,t:1527272074656};\\\", \\\"{x:702,y:604,t:1527272074672};\\\", \\\"{x:695,y:599,t:1527272074688};\\\", \\\"{x:691,y:594,t:1527272074705};\\\", \\\"{x:689,y:592,t:1527272074722};\\\", \\\"{x:687,y:591,t:1527272074739};\\\", \\\"{x:686,y:590,t:1527272074756};\\\", \\\"{x:685,y:589,t:1527272074772};\\\", \\\"{x:685,y:587,t:1527272074882};\\\", \\\"{x:689,y:581,t:1527272074890};\\\", \\\"{x:706,y:567,t:1527272074905};\\\", \\\"{x:735,y:544,t:1527272074923};\\\", \\\"{x:761,y:530,t:1527272074939};\\\", \\\"{x:787,y:516,t:1527272074956};\\\", \\\"{x:811,y:508,t:1527272074973};\\\", \\\"{x:828,y:501,t:1527272074989};\\\", \\\"{x:838,y:496,t:1527272075005};\\\", \\\"{x:839,y:496,t:1527272075022};\\\", \\\"{x:829,y:500,t:1527272075546};\\\", \\\"{x:812,y:512,t:1527272075556};\\\", \\\"{x:763,y:537,t:1527272075573};\\\", \\\"{x:708,y:561,t:1527272075590};\\\", \\\"{x:657,y:578,t:1527272075606};\\\", \\\"{x:621,y:588,t:1527272075622};\\\", \\\"{x:594,y:596,t:1527272075640};\\\", \\\"{x:574,y:602,t:1527272075656};\\\", \\\"{x:561,y:607,t:1527272075673};\\\", \\\"{x:552,y:611,t:1527272075689};\\\", \\\"{x:547,y:611,t:1527272075706};\\\", \\\"{x:541,y:612,t:1527272075723};\\\", \\\"{x:530,y:612,t:1527272075740};\\\", \\\"{x:517,y:612,t:1527272075755};\\\", \\\"{x:499,y:610,t:1527272075773};\\\", \\\"{x:478,y:608,t:1527272075791};\\\", \\\"{x:457,y:602,t:1527272075806};\\\", \\\"{x:436,y:594,t:1527272075824};\\\", \\\"{x:418,y:588,t:1527272075842};\\\", \\\"{x:395,y:581,t:1527272075856};\\\", \\\"{x:372,y:577,t:1527272075873};\\\", \\\"{x:333,y:570,t:1527272075889};\\\", \\\"{x:307,y:565,t:1527272075905};\\\", \\\"{x:288,y:563,t:1527272075923};\\\", \\\"{x:274,y:561,t:1527272075940};\\\", \\\"{x:263,y:560,t:1527272075957};\\\", \\\"{x:248,y:558,t:1527272075973};\\\", \\\"{x:236,y:556,t:1527272075989};\\\", \\\"{x:223,y:554,t:1527272076008};\\\", \\\"{x:213,y:553,t:1527272076022};\\\", \\\"{x:205,y:551,t:1527272076040};\\\", \\\"{x:200,y:551,t:1527272076056};\\\", \\\"{x:194,y:551,t:1527272076073};\\\", \\\"{x:179,y:551,t:1527272076090};\\\", \\\"{x:166,y:550,t:1527272076107};\\\", \\\"{x:154,y:548,t:1527272076123};\\\", \\\"{x:149,y:547,t:1527272076139};\\\", \\\"{x:144,y:546,t:1527272076157};\\\", \\\"{x:141,y:543,t:1527272076174};\\\", \\\"{x:138,y:543,t:1527272076190};\\\", \\\"{x:137,y:542,t:1527272076206};\\\", \\\"{x:136,y:542,t:1527272076223};\\\", \\\"{x:135,y:541,t:1527272076240};\\\", \\\"{x:138,y:541,t:1527272076810};\\\", \\\"{x:144,y:544,t:1527272076824};\\\", \\\"{x:167,y:554,t:1527272076840};\\\", \\\"{x:195,y:568,t:1527272076858};\\\", \\\"{x:249,y:591,t:1527272076874};\\\", \\\"{x:286,y:611,t:1527272076892};\\\", \\\"{x:322,y:625,t:1527272076906};\\\", \\\"{x:344,y:635,t:1527272076924};\\\", \\\"{x:359,y:640,t:1527272076941};\\\", \\\"{x:364,y:642,t:1527272076958};\\\", \\\"{x:365,y:642,t:1527272077002};\\\", \\\"{x:365,y:640,t:1527272077010};\\\", \\\"{x:365,y:637,t:1527272077024};\\\", \\\"{x:360,y:630,t:1527272077041};\\\", \\\"{x:351,y:621,t:1527272077057};\\\", \\\"{x:330,y:608,t:1527272077074};\\\", \\\"{x:311,y:601,t:1527272077090};\\\", \\\"{x:290,y:594,t:1527272077107};\\\", \\\"{x:273,y:589,t:1527272077124};\\\", \\\"{x:257,y:585,t:1527272077142};\\\", \\\"{x:246,y:581,t:1527272077158};\\\", \\\"{x:236,y:579,t:1527272077173};\\\", \\\"{x:226,y:576,t:1527272077191};\\\", \\\"{x:222,y:574,t:1527272077208};\\\", \\\"{x:221,y:572,t:1527272077224};\\\", \\\"{x:219,y:571,t:1527272077241};\\\", \\\"{x:218,y:570,t:1527272077258};\\\", \\\"{x:217,y:568,t:1527272077283};\\\", \\\"{x:215,y:565,t:1527272077291};\\\", \\\"{x:213,y:562,t:1527272077309};\\\", \\\"{x:205,y:556,t:1527272077323};\\\", \\\"{x:196,y:548,t:1527272077341};\\\", \\\"{x:192,y:546,t:1527272077357};\\\", \\\"{x:184,y:540,t:1527272077374};\\\", \\\"{x:177,y:535,t:1527272077390};\\\", \\\"{x:170,y:531,t:1527272077407};\\\", \\\"{x:163,y:529,t:1527272077424};\\\", \\\"{x:159,y:526,t:1527272077441};\\\", \\\"{x:155,y:524,t:1527272077458};\\\", \\\"{x:154,y:523,t:1527272077474};\\\", \\\"{x:155,y:523,t:1527272077779};\\\", \\\"{x:155,y:524,t:1527272077791};\\\", \\\"{x:157,y:525,t:1527272077810};\\\", \\\"{x:159,y:527,t:1527272077824};\\\", \\\"{x:162,y:530,t:1527272077842};\\\", \\\"{x:166,y:533,t:1527272077857};\\\", \\\"{x:168,y:535,t:1527272077874};\\\", \\\"{x:170,y:535,t:1527272077891};\\\", \\\"{x:173,y:539,t:1527272078298};\\\", \\\"{x:183,y:544,t:1527272078308};\\\", \\\"{x:210,y:568,t:1527272078325};\\\", \\\"{x:253,y:597,t:1527272078342};\\\", \\\"{x:301,y:625,t:1527272078359};\\\", \\\"{x:351,y:655,t:1527272078375};\\\", \\\"{x:405,y:683,t:1527272078393};\\\", \\\"{x:443,y:707,t:1527272078409};\\\", \\\"{x:470,y:723,t:1527272078425};\\\", \\\"{x:496,y:736,t:1527272078441};\\\", \\\"{x:504,y:742,t:1527272078458};\\\", \\\"{x:505,y:743,t:1527272078474};\\\", \\\"{x:509,y:743,t:1527272078492};\\\", \\\"{x:509,y:744,t:1527272078547};\\\", \\\"{x:510,y:744,t:1527272078559};\\\", \\\"{x:511,y:744,t:1527272078576};\\\", \\\"{x:512,y:744,t:1527272078592};\\\", \\\"{x:512,y:743,t:1527272079403};\\\", \\\"{x:512,y:739,t:1527272079410};\\\", \\\"{x:515,y:736,t:1527272079426};\\\", \\\"{x:517,y:732,t:1527272079442};\\\", \\\"{x:520,y:729,t:1527272079459};\\\", \\\"{x:524,y:723,t:1527272079475};\\\", \\\"{x:530,y:719,t:1527272079493};\\\", \\\"{x:539,y:715,t:1527272079508};\\\", \\\"{x:553,y:709,t:1527272079525};\\\", \\\"{x:566,y:701,t:1527272079543};\\\", \\\"{x:574,y:697,t:1527272079560};\\\", \\\"{x:585,y:691,t:1527272079576};\\\", \\\"{x:591,y:687,t:1527272079594};\\\", \\\"{x:598,y:683,t:1527272079610};\\\", \\\"{x:600,y:681,t:1527272079626};\\\", \\\"{x:603,y:679,t:1527272079643};\\\", \\\"{x:604,y:679,t:1527272079660};\\\", \\\"{x:605,y:677,t:1527272079676};\\\", \\\"{x:608,y:675,t:1527272079693};\\\", \\\"{x:611,y:673,t:1527272079710};\\\", \\\"{x:613,y:672,t:1527272079726};\\\", \\\"{x:615,y:670,t:1527272079743};\\\", \\\"{x:618,y:668,t:1527272079760};\\\", \\\"{x:621,y:665,t:1527272079776};\\\", \\\"{x:622,y:664,t:1527272079793};\\\", \\\"{x:624,y:662,t:1527272079810};\\\", \\\"{x:624,y:661,t:1527272079882};\\\", \\\"{x:624,y:660,t:1527272079893};\\\", \\\"{x:625,y:659,t:1527272079922};\\\", \\\"{x:625,y:658,t:1527272079930};\\\", \\\"{x:627,y:656,t:1527272079943};\\\", \\\"{x:627,y:654,t:1527272079960};\\\", \\\"{x:628,y:652,t:1527272079992};\\\", \\\"{x:628,y:651,t:1527272080009};\\\" ] }, { \\\"rt\\\": 41207, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 536710, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:625,y:645,t:1527272080987};\\\", \\\"{x:616,y:635,t:1527272080994};\\\", \\\"{x:600,y:616,t:1527272081012};\\\", \\\"{x:578,y:591,t:1527272081027};\\\", \\\"{x:557,y:566,t:1527272081044};\\\", \\\"{x:538,y:546,t:1527272081061};\\\", \\\"{x:517,y:527,t:1527272081076};\\\", \\\"{x:498,y:511,t:1527272081094};\\\", \\\"{x:482,y:498,t:1527272081109};\\\", \\\"{x:467,y:484,t:1527272081127};\\\", \\\"{x:449,y:471,t:1527272081144};\\\", \\\"{x:426,y:455,t:1527272081161};\\\", \\\"{x:410,y:446,t:1527272081176};\\\", \\\"{x:386,y:436,t:1527272081194};\\\", \\\"{x:376,y:431,t:1527272081211};\\\", \\\"{x:373,y:429,t:1527272081226};\\\", \\\"{x:373,y:430,t:1527272081298};\\\", \\\"{x:375,y:432,t:1527272081310};\\\", \\\"{x:376,y:432,t:1527272081327};\\\", \\\"{x:377,y:432,t:1527272081346};\\\", \\\"{x:378,y:433,t:1527272081386};\\\", \\\"{x:380,y:434,t:1527272081403};\\\", \\\"{x:381,y:434,t:1527272081411};\\\", \\\"{x:385,y:437,t:1527272081427};\\\", \\\"{x:390,y:439,t:1527272081444};\\\", \\\"{x:393,y:443,t:1527272081462};\\\", \\\"{x:396,y:445,t:1527272081477};\\\", \\\"{x:397,y:447,t:1527272081494};\\\", \\\"{x:397,y:449,t:1527272081511};\\\", \\\"{x:398,y:450,t:1527272081528};\\\", \\\"{x:399,y:450,t:1527272081544};\\\", \\\"{x:399,y:452,t:1527272081561};\\\", \\\"{x:399,y:453,t:1527272081595};\\\", \\\"{x:400,y:453,t:1527272081612};\\\", \\\"{x:400,y:455,t:1527272081650};\\\", \\\"{x:400,y:456,t:1527272081811};\\\", \\\"{x:402,y:456,t:1527272081828};\\\", \\\"{x:406,y:457,t:1527272081845};\\\", \\\"{x:413,y:460,t:1527272081861};\\\", \\\"{x:427,y:464,t:1527272081878};\\\", \\\"{x:442,y:466,t:1527272081894};\\\", \\\"{x:461,y:469,t:1527272081911};\\\", \\\"{x:482,y:471,t:1527272081929};\\\", \\\"{x:503,y:476,t:1527272081944};\\\", \\\"{x:521,y:478,t:1527272081961};\\\", \\\"{x:543,y:481,t:1527272081978};\\\", \\\"{x:553,y:481,t:1527272081994};\\\", \\\"{x:558,y:481,t:1527272082011};\\\", \\\"{x:562,y:482,t:1527272082028};\\\", \\\"{x:563,y:482,t:1527272082045};\\\", \\\"{x:564,y:482,t:1527272082066};\\\", \\\"{x:565,y:482,t:1527272082211};\\\", \\\"{x:570,y:480,t:1527272082228};\\\", \\\"{x:574,y:477,t:1527272082245};\\\", \\\"{x:579,y:476,t:1527272082261};\\\", \\\"{x:583,y:474,t:1527272082278};\\\", \\\"{x:586,y:473,t:1527272082296};\\\", \\\"{x:589,y:472,t:1527272082311};\\\", \\\"{x:593,y:471,t:1527272082328};\\\", \\\"{x:597,y:470,t:1527272082346};\\\", \\\"{x:602,y:468,t:1527272082362};\\\", \\\"{x:612,y:468,t:1527272082379};\\\", \\\"{x:617,y:466,t:1527272082394};\\\", \\\"{x:624,y:466,t:1527272082411};\\\", \\\"{x:628,y:465,t:1527272082429};\\\", \\\"{x:630,y:465,t:1527272082445};\\\", \\\"{x:634,y:465,t:1527272082462};\\\", \\\"{x:638,y:465,t:1527272082479};\\\", \\\"{x:643,y:465,t:1527272082495};\\\", \\\"{x:646,y:464,t:1527272082512};\\\", \\\"{x:647,y:464,t:1527272082528};\\\", \\\"{x:650,y:463,t:1527272082545};\\\", \\\"{x:651,y:463,t:1527272082562};\\\", \\\"{x:653,y:462,t:1527272083506};\\\", \\\"{x:657,y:461,t:1527272083514};\\\", \\\"{x:665,y:460,t:1527272083530};\\\", \\\"{x:690,y:456,t:1527272083546};\\\", \\\"{x:707,y:455,t:1527272083563};\\\", \\\"{x:719,y:455,t:1527272083579};\\\", \\\"{x:728,y:455,t:1527272083597};\\\", \\\"{x:730,y:455,t:1527272083612};\\\", \\\"{x:731,y:455,t:1527272083629};\\\", \\\"{x:731,y:454,t:1527272084795};\\\", \\\"{x:729,y:452,t:1527272084802};\\\", \\\"{x:719,y:449,t:1527272084813};\\\", \\\"{x:698,y:448,t:1527272084831};\\\", \\\"{x:676,y:448,t:1527272084847};\\\", \\\"{x:655,y:448,t:1527272084864};\\\", \\\"{x:638,y:448,t:1527272084881};\\\", \\\"{x:620,y:446,t:1527272084898};\\\", \\\"{x:604,y:445,t:1527272084914};\\\", \\\"{x:587,y:443,t:1527272084930};\\\", \\\"{x:576,y:442,t:1527272084947};\\\", \\\"{x:568,y:442,t:1527272084963};\\\", \\\"{x:561,y:442,t:1527272084980};\\\", \\\"{x:555,y:442,t:1527272084997};\\\", \\\"{x:552,y:442,t:1527272085013};\\\", \\\"{x:551,y:442,t:1527272085030};\\\", \\\"{x:549,y:442,t:1527272085049};\\\", \\\"{x:548,y:442,t:1527272085074};\\\", \\\"{x:546,y:442,t:1527272085089};\\\", \\\"{x:545,y:442,t:1527272085105};\\\", \\\"{x:544,y:442,t:1527272085137};\\\", \\\"{x:543,y:442,t:1527272085154};\\\", \\\"{x:542,y:442,t:1527272085178};\\\", \\\"{x:541,y:442,t:1527272085194};\\\", \\\"{x:540,y:442,t:1527272085210};\\\", \\\"{x:539,y:443,t:1527272085226};\\\", \\\"{x:539,y:444,t:1527272085250};\\\", \\\"{x:538,y:444,t:1527272085264};\\\", \\\"{x:536,y:445,t:1527272085280};\\\", \\\"{x:534,y:445,t:1527272085403};\\\", \\\"{x:534,y:446,t:1527272085413};\\\", \\\"{x:533,y:447,t:1527272085430};\\\", \\\"{x:529,y:449,t:1527272085448};\\\", \\\"{x:524,y:450,t:1527272085464};\\\", \\\"{x:519,y:452,t:1527272085481};\\\", \\\"{x:515,y:453,t:1527272085497};\\\", \\\"{x:514,y:453,t:1527272085514};\\\", \\\"{x:512,y:454,t:1527272085530};\\\", \\\"{x:511,y:454,t:1527272085547};\\\", \\\"{x:510,y:455,t:1527272085564};\\\", \\\"{x:509,y:456,t:1527272085580};\\\", \\\"{x:508,y:456,t:1527272085731};\\\", \\\"{x:508,y:457,t:1527272085747};\\\", \\\"{x:507,y:457,t:1527272085764};\\\", \\\"{x:507,y:460,t:1527272096867};\\\", \\\"{x:504,y:465,t:1527272096874};\\\", \\\"{x:501,y:469,t:1527272096890};\\\", \\\"{x:493,y:476,t:1527272096907};\\\", \\\"{x:492,y:477,t:1527272096923};\\\", \\\"{x:489,y:479,t:1527272096939};\\\", \\\"{x:488,y:480,t:1527272096956};\\\", \\\"{x:487,y:480,t:1527272097074};\\\", \\\"{x:488,y:480,t:1527272098385};\\\", \\\"{x:492,y:478,t:1527272098393};\\\", \\\"{x:500,y:474,t:1527272098407};\\\", \\\"{x:513,y:471,t:1527272098424};\\\", \\\"{x:529,y:466,t:1527272098440};\\\", \\\"{x:537,y:462,t:1527272098456};\\\", \\\"{x:540,y:460,t:1527272098474};\\\", \\\"{x:540,y:459,t:1527272098489};\\\", \\\"{x:541,y:458,t:1527272098506};\\\", \\\"{x:541,y:457,t:1527272098523};\\\", \\\"{x:542,y:455,t:1527272098540};\\\", \\\"{x:542,y:454,t:1527272098570};\\\", \\\"{x:544,y:454,t:1527272099954};\\\", \\\"{x:545,y:454,t:1527272099962};\\\", \\\"{x:551,y:456,t:1527272099976};\\\", \\\"{x:561,y:458,t:1527272099990};\\\", \\\"{x:571,y:459,t:1527272100008};\\\", \\\"{x:584,y:461,t:1527272100024};\\\", \\\"{x:594,y:462,t:1527272100041};\\\", \\\"{x:603,y:464,t:1527272100057};\\\", \\\"{x:605,y:465,t:1527272100075};\\\", \\\"{x:607,y:465,t:1527272100754};\\\", \\\"{x:608,y:465,t:1527272100761};\\\", \\\"{x:610,y:465,t:1527272100775};\\\", \\\"{x:614,y:465,t:1527272100791};\\\", \\\"{x:617,y:463,t:1527272100808};\\\", \\\"{x:620,y:463,t:1527272100825};\\\", \\\"{x:621,y:463,t:1527272100841};\\\", \\\"{x:622,y:463,t:1527272100873};\\\", \\\"{x:624,y:462,t:1527272101810};\\\", \\\"{x:630,y:460,t:1527272101826};\\\", \\\"{x:639,y:460,t:1527272101842};\\\", \\\"{x:651,y:460,t:1527272101859};\\\", \\\"{x:671,y:460,t:1527272101877};\\\", \\\"{x:683,y:460,t:1527272101893};\\\", \\\"{x:691,y:460,t:1527272101909};\\\", \\\"{x:696,y:460,t:1527272101926};\\\", \\\"{x:697,y:460,t:1527272101943};\\\", \\\"{x:700,y:460,t:1527272102650};\\\", \\\"{x:703,y:460,t:1527272102660};\\\", \\\"{x:714,y:461,t:1527272102677};\\\", \\\"{x:729,y:462,t:1527272102693};\\\", \\\"{x:742,y:465,t:1527272102710};\\\", \\\"{x:751,y:465,t:1527272102727};\\\", \\\"{x:755,y:466,t:1527272102743};\\\", \\\"{x:756,y:466,t:1527272102761};\\\", \\\"{x:757,y:468,t:1527272103395};\\\", \\\"{x:782,y:476,t:1527272103410};\\\", \\\"{x:837,y:489,t:1527272103428};\\\", \\\"{x:926,y:502,t:1527272103443};\\\", \\\"{x:1029,y:518,t:1527272103460};\\\", \\\"{x:1149,y:539,t:1527272103479};\\\", \\\"{x:1272,y:562,t:1527272103494};\\\", \\\"{x:1384,y:588,t:1527272103511};\\\", \\\"{x:1492,y:619,t:1527272103529};\\\", \\\"{x:1592,y:645,t:1527272103545};\\\", \\\"{x:1724,y:677,t:1527272103561};\\\", \\\"{x:1793,y:699,t:1527272103579};\\\", \\\"{x:1849,y:713,t:1527272103594};\\\", \\\"{x:1891,y:727,t:1527272103612};\\\", \\\"{x:1915,y:733,t:1527272103629};\\\", \\\"{x:1913,y:790,t:1527272103794};\\\", \\\"{x:1891,y:804,t:1527272103812};\\\", \\\"{x:1865,y:817,t:1527272103829};\\\", \\\"{x:1849,y:825,t:1527272103846};\\\", \\\"{x:1834,y:830,t:1527272103862};\\\", \\\"{x:1823,y:834,t:1527272103879};\\\", \\\"{x:1814,y:835,t:1527272103896};\\\", \\\"{x:1801,y:836,t:1527272103913};\\\", \\\"{x:1785,y:836,t:1527272103928};\\\", \\\"{x:1752,y:836,t:1527272103946};\\\", \\\"{x:1736,y:836,t:1527272103962};\\\", \\\"{x:1722,y:833,t:1527272103979};\\\", \\\"{x:1711,y:830,t:1527272103996};\\\", \\\"{x:1702,y:827,t:1527272104013};\\\", \\\"{x:1690,y:822,t:1527272104030};\\\", \\\"{x:1679,y:817,t:1527272104046};\\\", \\\"{x:1666,y:810,t:1527272104063};\\\", \\\"{x:1654,y:805,t:1527272104078};\\\", \\\"{x:1646,y:802,t:1527272104096};\\\", \\\"{x:1641,y:800,t:1527272104113};\\\", \\\"{x:1637,y:798,t:1527272104129};\\\", \\\"{x:1634,y:795,t:1527272104146};\\\", \\\"{x:1633,y:795,t:1527272104163};\\\", \\\"{x:1632,y:795,t:1527272104179};\\\", \\\"{x:1631,y:793,t:1527272104196};\\\", \\\"{x:1630,y:792,t:1527272104213};\\\", \\\"{x:1627,y:789,t:1527272104230};\\\", \\\"{x:1623,y:785,t:1527272104247};\\\", \\\"{x:1619,y:781,t:1527272104263};\\\", \\\"{x:1615,y:779,t:1527272104281};\\\", \\\"{x:1613,y:777,t:1527272104296};\\\", \\\"{x:1612,y:775,t:1527272104313};\\\", \\\"{x:1609,y:773,t:1527272104330};\\\", \\\"{x:1609,y:772,t:1527272104346};\\\", \\\"{x:1607,y:770,t:1527272104363};\\\", \\\"{x:1606,y:769,t:1527272104381};\\\", \\\"{x:1606,y:768,t:1527272104396};\\\", \\\"{x:1605,y:766,t:1527272104414};\\\", \\\"{x:1604,y:766,t:1527272104430};\\\", \\\"{x:1603,y:764,t:1527272104507};\\\", \\\"{x:1598,y:764,t:1527272107971};\\\", \\\"{x:1587,y:764,t:1527272107983};\\\", \\\"{x:1569,y:764,t:1527272108000};\\\", \\\"{x:1553,y:764,t:1527272108017};\\\", \\\"{x:1540,y:764,t:1527272108033};\\\", \\\"{x:1531,y:764,t:1527272108050};\\\", \\\"{x:1530,y:764,t:1527272108067};\\\", \\\"{x:1528,y:764,t:1527272108146};\\\", \\\"{x:1527,y:764,t:1527272108162};\\\", \\\"{x:1525,y:764,t:1527272108178};\\\", \\\"{x:1524,y:765,t:1527272108185};\\\", \\\"{x:1523,y:765,t:1527272108201};\\\", \\\"{x:1521,y:766,t:1527272108218};\\\", \\\"{x:1516,y:767,t:1527272108235};\\\", \\\"{x:1510,y:767,t:1527272108250};\\\", \\\"{x:1500,y:769,t:1527272108268};\\\", \\\"{x:1487,y:771,t:1527272108284};\\\", \\\"{x:1473,y:772,t:1527272108300};\\\", \\\"{x:1460,y:776,t:1527272108317};\\\", \\\"{x:1445,y:781,t:1527272108334};\\\", \\\"{x:1435,y:786,t:1527272108351};\\\", \\\"{x:1422,y:792,t:1527272108367};\\\", \\\"{x:1405,y:797,t:1527272108385};\\\", \\\"{x:1389,y:801,t:1527272108400};\\\", \\\"{x:1372,y:803,t:1527272108417};\\\", \\\"{x:1350,y:803,t:1527272108434};\\\", \\\"{x:1346,y:803,t:1527272108451};\\\", \\\"{x:1345,y:803,t:1527272108523};\\\", \\\"{x:1343,y:803,t:1527272108538};\\\", \\\"{x:1341,y:802,t:1527272108552};\\\", \\\"{x:1338,y:795,t:1527272108567};\\\", \\\"{x:1336,y:789,t:1527272108585};\\\", \\\"{x:1333,y:781,t:1527272108602};\\\", \\\"{x:1332,y:776,t:1527272108618};\\\", \\\"{x:1330,y:771,t:1527272108634};\\\", \\\"{x:1329,y:767,t:1527272108651};\\\", \\\"{x:1329,y:764,t:1527272108668};\\\", \\\"{x:1330,y:759,t:1527272108685};\\\", \\\"{x:1331,y:758,t:1527272108701};\\\", \\\"{x:1332,y:756,t:1527272108718};\\\", \\\"{x:1332,y:755,t:1527272108735};\\\", \\\"{x:1331,y:755,t:1527272109259};\\\", \\\"{x:1330,y:755,t:1527272109268};\\\", \\\"{x:1328,y:755,t:1527272109285};\\\", \\\"{x:1326,y:754,t:1527272109302};\\\", \\\"{x:1324,y:754,t:1527272109318};\\\", \\\"{x:1323,y:754,t:1527272109335};\\\", \\\"{x:1322,y:754,t:1527272109351};\\\", \\\"{x:1321,y:754,t:1527272109370};\\\", \\\"{x:1320,y:753,t:1527272109386};\\\", \\\"{x:1319,y:753,t:1527272109403};\\\", \\\"{x:1318,y:753,t:1527272109419};\\\", \\\"{x:1316,y:753,t:1527272109435};\\\", \\\"{x:1315,y:753,t:1527272109453};\\\", \\\"{x:1311,y:753,t:1527272109469};\\\", \\\"{x:1310,y:754,t:1527272109498};\\\", \\\"{x:1309,y:754,t:1527272109506};\\\", \\\"{x:1308,y:754,t:1527272109530};\\\", \\\"{x:1307,y:754,t:1527272109538};\\\", \\\"{x:1306,y:755,t:1527272109553};\\\", \\\"{x:1304,y:756,t:1527272109569};\\\", \\\"{x:1302,y:756,t:1527272109586};\\\", \\\"{x:1299,y:756,t:1527272109602};\\\", \\\"{x:1295,y:757,t:1527272109619};\\\", \\\"{x:1292,y:758,t:1527272109635};\\\", \\\"{x:1289,y:758,t:1527272109653};\\\", \\\"{x:1286,y:759,t:1527272109669};\\\", \\\"{x:1283,y:759,t:1527272109686};\\\", \\\"{x:1281,y:760,t:1527272109703};\\\", \\\"{x:1279,y:760,t:1527272109719};\\\", \\\"{x:1277,y:760,t:1527272109736};\\\", \\\"{x:1275,y:760,t:1527272109753};\\\", \\\"{x:1272,y:760,t:1527272109770};\\\", \\\"{x:1269,y:760,t:1527272109786};\\\", \\\"{x:1264,y:762,t:1527272109802};\\\", \\\"{x:1262,y:762,t:1527272109820};\\\", \\\"{x:1259,y:762,t:1527272109835};\\\", \\\"{x:1256,y:763,t:1527272109852};\\\", \\\"{x:1254,y:763,t:1527272109869};\\\", \\\"{x:1252,y:763,t:1527272109886};\\\", \\\"{x:1248,y:763,t:1527272109903};\\\", \\\"{x:1246,y:764,t:1527272109920};\\\", \\\"{x:1243,y:764,t:1527272109935};\\\", \\\"{x:1238,y:766,t:1527272109953};\\\", \\\"{x:1236,y:766,t:1527272109969};\\\", \\\"{x:1234,y:766,t:1527272109986};\\\", \\\"{x:1232,y:766,t:1527272110002};\\\", \\\"{x:1231,y:766,t:1527272110025};\\\", \\\"{x:1230,y:766,t:1527272110042};\\\", \\\"{x:1229,y:766,t:1527272110052};\\\", \\\"{x:1228,y:766,t:1527272110073};\\\", \\\"{x:1227,y:766,t:1527272110086};\\\", \\\"{x:1226,y:766,t:1527272110102};\\\", \\\"{x:1225,y:766,t:1527272110119};\\\", \\\"{x:1223,y:766,t:1527272110136};\\\", \\\"{x:1222,y:766,t:1527272110162};\\\", \\\"{x:1228,y:766,t:1527272112571};\\\", \\\"{x:1237,y:767,t:1527272112578};\\\", \\\"{x:1248,y:768,t:1527272112588};\\\", \\\"{x:1274,y:772,t:1527272112605};\\\", \\\"{x:1302,y:776,t:1527272112622};\\\", \\\"{x:1324,y:780,t:1527272112638};\\\", \\\"{x:1346,y:788,t:1527272112655};\\\", \\\"{x:1361,y:790,t:1527272112673};\\\", \\\"{x:1370,y:793,t:1527272112688};\\\", \\\"{x:1375,y:794,t:1527272112705};\\\", \\\"{x:1376,y:794,t:1527272112738};\\\", \\\"{x:1377,y:794,t:1527272112851};\\\", \\\"{x:1377,y:793,t:1527272112899};\\\", \\\"{x:1377,y:792,t:1527272112907};\\\", \\\"{x:1376,y:791,t:1527272112923};\\\", \\\"{x:1375,y:790,t:1527272112940};\\\", \\\"{x:1374,y:789,t:1527272112956};\\\", \\\"{x:1371,y:787,t:1527272112973};\\\", \\\"{x:1369,y:786,t:1527272112990};\\\", \\\"{x:1365,y:786,t:1527272113006};\\\", \\\"{x:1362,y:783,t:1527272113022};\\\", \\\"{x:1360,y:782,t:1527272113039};\\\", \\\"{x:1356,y:781,t:1527272113056};\\\", \\\"{x:1354,y:780,t:1527272113072};\\\", \\\"{x:1353,y:780,t:1527272113154};\\\", \\\"{x:1353,y:778,t:1527272113177};\\\", \\\"{x:1352,y:778,t:1527272113189};\\\", \\\"{x:1351,y:777,t:1527272113206};\\\", \\\"{x:1349,y:776,t:1527272113223};\\\", \\\"{x:1346,y:774,t:1527272113240};\\\", \\\"{x:1342,y:773,t:1527272113256};\\\", \\\"{x:1336,y:771,t:1527272113272};\\\", \\\"{x:1332,y:769,t:1527272113289};\\\", \\\"{x:1330,y:768,t:1527272113306};\\\", \\\"{x:1329,y:768,t:1527272113338};\\\", \\\"{x:1328,y:767,t:1527272113354};\\\", \\\"{x:1326,y:766,t:1527272113386};\\\", \\\"{x:1325,y:766,t:1527272113410};\\\", \\\"{x:1323,y:766,t:1527272113426};\\\", \\\"{x:1322,y:766,t:1527272113442};\\\", \\\"{x:1320,y:765,t:1527272113457};\\\", \\\"{x:1319,y:765,t:1527272113473};\\\", \\\"{x:1316,y:764,t:1527272113490};\\\", \\\"{x:1315,y:764,t:1527272114466};\\\", \\\"{x:1314,y:763,t:1527272114475};\\\", \\\"{x:1313,y:763,t:1527272114499};\\\", \\\"{x:1311,y:763,t:1527272114514};\\\", \\\"{x:1307,y:763,t:1527272114524};\\\", \\\"{x:1306,y:763,t:1527272114541};\\\", \\\"{x:1304,y:763,t:1527272114557};\\\", \\\"{x:1303,y:763,t:1527272114574};\\\", \\\"{x:1300,y:762,t:1527272114591};\\\", \\\"{x:1298,y:762,t:1527272114607};\\\", \\\"{x:1297,y:762,t:1527272114626};\\\", \\\"{x:1296,y:762,t:1527272114642};\\\", \\\"{x:1295,y:762,t:1527272114657};\\\", \\\"{x:1294,y:762,t:1527272114723};\\\", \\\"{x:1293,y:761,t:1527272115746};\\\", \\\"{x:1293,y:760,t:1527272115763};\\\", \\\"{x:1293,y:759,t:1527272115777};\\\", \\\"{x:1293,y:758,t:1527272115793};\\\", \\\"{x:1293,y:757,t:1527272115810};\\\", \\\"{x:1293,y:755,t:1527272115826};\\\", \\\"{x:1293,y:753,t:1527272115843};\\\", \\\"{x:1293,y:752,t:1527272115859};\\\", \\\"{x:1293,y:748,t:1527272115875};\\\", \\\"{x:1295,y:744,t:1527272115893};\\\", \\\"{x:1296,y:735,t:1527272115909};\\\", \\\"{x:1301,y:719,t:1527272115926};\\\", \\\"{x:1305,y:697,t:1527272115943};\\\", \\\"{x:1306,y:674,t:1527272115959};\\\", \\\"{x:1308,y:649,t:1527272115977};\\\", \\\"{x:1308,y:626,t:1527272115993};\\\", \\\"{x:1308,y:592,t:1527272116010};\\\", \\\"{x:1307,y:572,t:1527272116026};\\\", \\\"{x:1302,y:555,t:1527272116043};\\\", \\\"{x:1298,y:544,t:1527272116060};\\\", \\\"{x:1294,y:535,t:1527272116076};\\\", \\\"{x:1291,y:528,t:1527272116093};\\\", \\\"{x:1290,y:523,t:1527272116110};\\\", \\\"{x:1290,y:521,t:1527272116126};\\\", \\\"{x:1289,y:520,t:1527272116143};\\\", \\\"{x:1289,y:521,t:1527272116259};\\\", \\\"{x:1289,y:528,t:1527272116276};\\\", \\\"{x:1289,y:535,t:1527272116293};\\\", \\\"{x:1289,y:541,t:1527272116310};\\\", \\\"{x:1289,y:547,t:1527272116327};\\\", \\\"{x:1289,y:551,t:1527272116343};\\\", \\\"{x:1289,y:555,t:1527272116360};\\\", \\\"{x:1289,y:557,t:1527272116377};\\\", \\\"{x:1289,y:560,t:1527272116393};\\\", \\\"{x:1289,y:564,t:1527272116410};\\\", \\\"{x:1289,y:565,t:1527272116427};\\\", \\\"{x:1289,y:566,t:1527272116443};\\\", \\\"{x:1289,y:567,t:1527272116460};\\\", \\\"{x:1289,y:568,t:1527272116477};\\\", \\\"{x:1289,y:569,t:1527272118667};\\\", \\\"{x:1267,y:569,t:1527272118679};\\\", \\\"{x:1162,y:569,t:1527272118696};\\\", \\\"{x:1048,y:569,t:1527272118712};\\\", \\\"{x:927,y:569,t:1527272118730};\\\", \\\"{x:766,y:569,t:1527272118745};\\\", \\\"{x:697,y:565,t:1527272118762};\\\", \\\"{x:682,y:563,t:1527272118774};\\\", \\\"{x:670,y:561,t:1527272118792};\\\", \\\"{x:668,y:560,t:1527272118808};\\\", \\\"{x:669,y:560,t:1527272118913};\\\", \\\"{x:672,y:560,t:1527272118924};\\\", \\\"{x:678,y:560,t:1527272118942};\\\", \\\"{x:685,y:560,t:1527272118958};\\\", \\\"{x:693,y:560,t:1527272118974};\\\", \\\"{x:696,y:558,t:1527272118991};\\\", \\\"{x:697,y:558,t:1527272119009};\\\", \\\"{x:697,y:556,t:1527272119115};\\\", \\\"{x:694,y:554,t:1527272119127};\\\", \\\"{x:685,y:551,t:1527272119142};\\\", \\\"{x:672,y:544,t:1527272119158};\\\", \\\"{x:658,y:538,t:1527272119174};\\\", \\\"{x:648,y:534,t:1527272119191};\\\", \\\"{x:637,y:529,t:1527272119208};\\\", \\\"{x:629,y:527,t:1527272119225};\\\", \\\"{x:624,y:523,t:1527272119242};\\\", \\\"{x:620,y:519,t:1527272119257};\\\", \\\"{x:616,y:516,t:1527272119275};\\\", \\\"{x:614,y:513,t:1527272119292};\\\", \\\"{x:613,y:510,t:1527272119308};\\\", \\\"{x:613,y:507,t:1527272119324};\\\", \\\"{x:612,y:502,t:1527272119341};\\\", \\\"{x:610,y:499,t:1527272119358};\\\", \\\"{x:609,y:497,t:1527272119374};\\\", \\\"{x:607,y:495,t:1527272119391};\\\", \\\"{x:602,y:491,t:1527272119409};\\\", \\\"{x:601,y:491,t:1527272119426};\\\", \\\"{x:600,y:491,t:1527272119441};\\\", \\\"{x:600,y:490,t:1527272119459};\\\", \\\"{x:600,y:491,t:1527272119758};\\\", \\\"{x:605,y:512,t:1527272119774};\\\", \\\"{x:612,y:538,t:1527272119792};\\\", \\\"{x:618,y:583,t:1527272119809};\\\", \\\"{x:624,y:647,t:1527272119826};\\\", \\\"{x:624,y:684,t:1527272119842};\\\", \\\"{x:629,y:718,t:1527272119859};\\\", \\\"{x:633,y:741,t:1527272119875};\\\", \\\"{x:639,y:761,t:1527272119892};\\\", \\\"{x:644,y:772,t:1527272119908};\\\", \\\"{x:645,y:775,t:1527272119926};\\\", \\\"{x:646,y:776,t:1527272119942};\\\", \\\"{x:643,y:776,t:1527272120002};\\\", \\\"{x:637,y:776,t:1527272120010};\\\", \\\"{x:622,y:776,t:1527272120025};\\\", \\\"{x:600,y:775,t:1527272120041};\\\", \\\"{x:575,y:769,t:1527272120058};\\\", \\\"{x:549,y:767,t:1527272120076};\\\", \\\"{x:526,y:762,t:1527272120092};\\\", \\\"{x:501,y:760,t:1527272120109};\\\", \\\"{x:492,y:756,t:1527272120125};\\\", \\\"{x:490,y:756,t:1527272120141};\\\", \\\"{x:489,y:755,t:1527272120426};\\\", \\\"{x:487,y:738,t:1527272120444};\\\", \\\"{x:486,y:728,t:1527272120459};\\\", \\\"{x:484,y:718,t:1527272120476};\\\", \\\"{x:484,y:713,t:1527272120492};\\\", \\\"{x:483,y:712,t:1527272120508};\\\", \\\"{x:482,y:711,t:1527272120525};\\\", \\\"{x:486,y:717,t:1527272120787};\\\", \\\"{x:494,y:722,t:1527272120795};\\\", \\\"{x:513,y:733,t:1527272120809};\\\", \\\"{x:533,y:744,t:1527272120826};\\\", \\\"{x:553,y:754,t:1527272120842};\\\", \\\"{x:568,y:762,t:1527272120860};\\\", \\\"{x:575,y:766,t:1527272120875};\\\", \\\"{x:575,y:767,t:1527272120892};\\\", \\\"{x:575,y:766,t:1527272121010};\\\", \\\"{x:573,y:761,t:1527272121025};\\\", \\\"{x:567,y:753,t:1527272121043};\\\", \\\"{x:555,y:743,t:1527272121060};\\\", \\\"{x:547,y:736,t:1527272121076};\\\", \\\"{x:540,y:733,t:1527272121093};\\\", \\\"{x:536,y:730,t:1527272121110};\\\", \\\"{x:534,y:729,t:1527272121127};\\\", \\\"{x:533,y:728,t:1527272121143};\\\", \\\"{x:537,y:724,t:1527272121779};\\\", \\\"{x:580,y:703,t:1527272121794};\\\", \\\"{x:648,y:669,t:1527272121810};\\\", \\\"{x:737,y:625,t:1527272121826};\\\", \\\"{x:839,y:582,t:1527272121844};\\\", \\\"{x:946,y:535,t:1527272121859};\\\", \\\"{x:1048,y:492,t:1527272121877};\\\", \\\"{x:1131,y:453,t:1527272121894};\\\", \\\"{x:1190,y:426,t:1527272121910};\\\", \\\"{x:1223,y:411,t:1527272121927};\\\", \\\"{x:1236,y:402,t:1527272121944};\\\", \\\"{x:1239,y:399,t:1527272121960};\\\", \\\"{x:1239,y:398,t:1527272121976};\\\", \\\"{x:1240,y:398,t:1527272122001};\\\" ] }, { \\\"rt\\\": 24806, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 562721, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1238,y:397,t:1527272122857};\\\", \\\"{x:1228,y:399,t:1527272122865};\\\", \\\"{x:1216,y:403,t:1527272122877};\\\", \\\"{x:1183,y:411,t:1527272122894};\\\", \\\"{x:1149,y:422,t:1527272122911};\\\", \\\"{x:1124,y:427,t:1527272122928};\\\", \\\"{x:1109,y:428,t:1527272122945};\\\", \\\"{x:1101,y:431,t:1527272122961};\\\", \\\"{x:1097,y:432,t:1527272122977};\\\", \\\"{x:1067,y:444,t:1527272123054};\\\", \\\"{x:1063,y:445,t:1527272123061};\\\", \\\"{x:1047,y:450,t:1527272123078};\\\", \\\"{x:1027,y:452,t:1527272123095};\\\", \\\"{x:1002,y:455,t:1527272123110};\\\", \\\"{x:968,y:455,t:1527272123128};\\\", \\\"{x:910,y:455,t:1527272123144};\\\", \\\"{x:813,y:455,t:1527272123160};\\\", \\\"{x:674,y:455,t:1527272123177};\\\", \\\"{x:593,y:455,t:1527272123194};\\\", \\\"{x:546,y:455,t:1527272123210};\\\", \\\"{x:527,y:455,t:1527272123228};\\\", \\\"{x:520,y:455,t:1527272123245};\\\", \\\"{x:519,y:456,t:1527272123260};\\\", \\\"{x:518,y:456,t:1527272123278};\\\", \\\"{x:516,y:457,t:1527272123295};\\\", \\\"{x:515,y:458,t:1527272123311};\\\", \\\"{x:513,y:459,t:1527272123328};\\\", \\\"{x:512,y:459,t:1527272123346};\\\", \\\"{x:514,y:459,t:1527272124710};\\\", \\\"{x:518,y:458,t:1527272124718};\\\", \\\"{x:524,y:457,t:1527272124732};\\\", \\\"{x:546,y:455,t:1527272124750};\\\", \\\"{x:564,y:455,t:1527272124766};\\\", \\\"{x:587,y:455,t:1527272124783};\\\", \\\"{x:613,y:455,t:1527272124800};\\\", \\\"{x:632,y:458,t:1527272124816};\\\", \\\"{x:650,y:459,t:1527272124833};\\\", \\\"{x:662,y:462,t:1527272124849};\\\", \\\"{x:668,y:463,t:1527272124866};\\\", \\\"{x:669,y:463,t:1527272124883};\\\", \\\"{x:669,y:464,t:1527272124950};\\\", \\\"{x:671,y:464,t:1527272125173};\\\", \\\"{x:677,y:464,t:1527272125182};\\\", \\\"{x:700,y:468,t:1527272125199};\\\", \\\"{x:739,y:475,t:1527272125217};\\\", \\\"{x:794,y:490,t:1527272125234};\\\", \\\"{x:859,y:502,t:1527272125250};\\\", \\\"{x:1046,y:547,t:1527272125284};\\\", \\\"{x:1153,y:571,t:1527272125300};\\\", \\\"{x:1263,y:597,t:1527272125316};\\\", \\\"{x:1413,y:629,t:1527272125333};\\\", \\\"{x:1490,y:645,t:1527272125351};\\\", \\\"{x:1549,y:657,t:1527272125366};\\\", \\\"{x:1587,y:662,t:1527272125383};\\\", \\\"{x:1616,y:667,t:1527272125401};\\\", \\\"{x:1632,y:668,t:1527272125416};\\\", \\\"{x:1647,y:670,t:1527272125433};\\\", \\\"{x:1660,y:673,t:1527272125450};\\\", \\\"{x:1674,y:674,t:1527272125466};\\\", \\\"{x:1687,y:675,t:1527272125484};\\\", \\\"{x:1698,y:675,t:1527272125500};\\\", \\\"{x:1703,y:675,t:1527272125516};\\\", \\\"{x:1706,y:675,t:1527272125533};\\\", \\\"{x:1704,y:675,t:1527272125654};\\\", \\\"{x:1698,y:675,t:1527272125667};\\\", \\\"{x:1686,y:670,t:1527272125684};\\\", \\\"{x:1680,y:666,t:1527272125701};\\\", \\\"{x:1670,y:663,t:1527272125717};\\\", \\\"{x:1659,y:663,t:1527272125734};\\\", \\\"{x:1649,y:663,t:1527272125750};\\\", \\\"{x:1636,y:663,t:1527272125767};\\\", \\\"{x:1619,y:663,t:1527272125784};\\\", \\\"{x:1603,y:663,t:1527272125800};\\\", \\\"{x:1592,y:663,t:1527272125818};\\\", \\\"{x:1586,y:662,t:1527272125833};\\\", \\\"{x:1583,y:662,t:1527272125894};\\\", \\\"{x:1580,y:663,t:1527272125901};\\\", \\\"{x:1575,y:664,t:1527272125917};\\\", \\\"{x:1555,y:669,t:1527272125934};\\\", \\\"{x:1541,y:671,t:1527272125950};\\\", \\\"{x:1527,y:673,t:1527272125967};\\\", \\\"{x:1516,y:673,t:1527272125983};\\\", \\\"{x:1509,y:673,t:1527272126001};\\\", \\\"{x:1506,y:673,t:1527272126018};\\\", \\\"{x:1504,y:673,t:1527272126034};\\\", \\\"{x:1501,y:672,t:1527272126051};\\\", \\\"{x:1496,y:669,t:1527272126068};\\\", \\\"{x:1489,y:666,t:1527272126083};\\\", \\\"{x:1481,y:664,t:1527272126101};\\\", \\\"{x:1473,y:662,t:1527272126117};\\\", \\\"{x:1471,y:661,t:1527272126134};\\\", \\\"{x:1470,y:660,t:1527272126151};\\\", \\\"{x:1469,y:660,t:1527272128966};\\\", \\\"{x:1466,y:660,t:1527272128974};\\\", \\\"{x:1465,y:660,t:1527272129006};\\\", \\\"{x:1464,y:660,t:1527272129022};\\\", \\\"{x:1463,y:660,t:1527272129110};\\\", \\\"{x:1462,y:660,t:1527272129230};\\\", \\\"{x:1461,y:659,t:1527272131046};\\\", \\\"{x:1461,y:662,t:1527272131061};\\\", \\\"{x:1461,y:666,t:1527272131072};\\\", \\\"{x:1461,y:674,t:1527272131088};\\\", \\\"{x:1461,y:684,t:1527272131106};\\\", \\\"{x:1463,y:696,t:1527272131121};\\\", \\\"{x:1468,y:706,t:1527272131138};\\\", \\\"{x:1474,y:717,t:1527272131156};\\\", \\\"{x:1479,y:727,t:1527272131172};\\\", \\\"{x:1486,y:747,t:1527272131215};\\\", \\\"{x:1486,y:751,t:1527272131221};\\\", \\\"{x:1488,y:756,t:1527272131238};\\\", \\\"{x:1488,y:757,t:1527272131254};\\\", \\\"{x:1488,y:761,t:1527272131317};\\\", \\\"{x:1488,y:765,t:1527272131325};\\\", \\\"{x:1488,y:768,t:1527272131337};\\\", \\\"{x:1492,y:774,t:1527272131354};\\\", \\\"{x:1495,y:778,t:1527272131372};\\\", \\\"{x:1495,y:781,t:1527272131388};\\\", \\\"{x:1498,y:786,t:1527272131405};\\\", \\\"{x:1498,y:789,t:1527272131422};\\\", \\\"{x:1498,y:792,t:1527272131439};\\\", \\\"{x:1499,y:793,t:1527272131454};\\\", \\\"{x:1499,y:794,t:1527272131477};\\\", \\\"{x:1499,y:795,t:1527272131518};\\\", \\\"{x:1500,y:795,t:1527272131582};\\\", \\\"{x:1501,y:795,t:1527272131630};\\\", \\\"{x:1497,y:800,t:1527272131686};\\\", \\\"{x:1486,y:807,t:1527272131693};\\\", \\\"{x:1475,y:813,t:1527272131705};\\\", \\\"{x:1455,y:823,t:1527272131722};\\\", \\\"{x:1440,y:830,t:1527272131739};\\\", \\\"{x:1433,y:835,t:1527272131755};\\\", \\\"{x:1430,y:837,t:1527272131773};\\\", \\\"{x:1428,y:839,t:1527272131789};\\\", \\\"{x:1426,y:841,t:1527272131806};\\\", \\\"{x:1422,y:843,t:1527272131822};\\\", \\\"{x:1418,y:845,t:1527272131857};\\\", \\\"{x:1413,y:847,t:1527272131872};\\\", \\\"{x:1402,y:849,t:1527272131888};\\\", \\\"{x:1381,y:851,t:1527272131905};\\\", \\\"{x:1357,y:853,t:1527272131922};\\\", \\\"{x:1335,y:853,t:1527272131939};\\\", \\\"{x:1316,y:853,t:1527272131955};\\\", \\\"{x:1299,y:853,t:1527272131971};\\\", \\\"{x:1288,y:853,t:1527272131988};\\\", \\\"{x:1284,y:853,t:1527272132005};\\\", \\\"{x:1278,y:852,t:1527272132022};\\\", \\\"{x:1272,y:852,t:1527272132038};\\\", \\\"{x:1265,y:852,t:1527272132055};\\\", \\\"{x:1260,y:851,t:1527272132071};\\\", \\\"{x:1256,y:850,t:1527272132089};\\\", \\\"{x:1253,y:850,t:1527272132106};\\\", \\\"{x:1252,y:850,t:1527272132121};\\\", \\\"{x:1252,y:849,t:1527272132190};\\\", \\\"{x:1247,y:848,t:1527272132205};\\\", \\\"{x:1232,y:839,t:1527272132222};\\\", \\\"{x:1201,y:826,t:1527272132239};\\\", \\\"{x:1144,y:806,t:1527272132256};\\\", \\\"{x:1093,y:789,t:1527272132273};\\\", \\\"{x:1052,y:773,t:1527272132289};\\\", \\\"{x:1030,y:765,t:1527272132306};\\\", \\\"{x:1029,y:764,t:1527272132322};\\\", \\\"{x:1030,y:764,t:1527272132428};\\\", \\\"{x:1031,y:764,t:1527272132438};\\\", \\\"{x:1042,y:765,t:1527272132455};\\\", \\\"{x:1070,y:770,t:1527272132491};\\\", \\\"{x:1086,y:773,t:1527272132505};\\\", \\\"{x:1094,y:773,t:1527272132522};\\\", \\\"{x:1103,y:776,t:1527272132538};\\\", \\\"{x:1111,y:777,t:1527272132555};\\\", \\\"{x:1121,y:777,t:1527272132572};\\\", \\\"{x:1129,y:777,t:1527272132588};\\\", \\\"{x:1136,y:777,t:1527272132605};\\\", \\\"{x:1143,y:777,t:1527272132623};\\\", \\\"{x:1147,y:777,t:1527272132638};\\\", \\\"{x:1148,y:777,t:1527272132701};\\\", \\\"{x:1148,y:776,t:1527272132716};\\\", \\\"{x:1149,y:775,t:1527272132724};\\\", \\\"{x:1150,y:774,t:1527272132740};\\\", \\\"{x:1150,y:773,t:1527272132756};\\\", \\\"{x:1153,y:768,t:1527272132772};\\\", \\\"{x:1154,y:767,t:1527272132788};\\\", \\\"{x:1157,y:762,t:1527272132806};\\\", \\\"{x:1161,y:757,t:1527272132822};\\\", \\\"{x:1165,y:753,t:1527272132839};\\\", \\\"{x:1169,y:749,t:1527272132855};\\\", \\\"{x:1173,y:746,t:1527272132872};\\\", \\\"{x:1176,y:744,t:1527272132889};\\\", \\\"{x:1176,y:743,t:1527272132906};\\\", \\\"{x:1175,y:742,t:1527272133222};\\\", \\\"{x:1159,y:739,t:1527272133240};\\\", \\\"{x:1126,y:733,t:1527272133256};\\\", \\\"{x:1054,y:724,t:1527272133273};\\\", \\\"{x:976,y:713,t:1527272133290};\\\", \\\"{x:903,y:703,t:1527272133306};\\\", \\\"{x:853,y:695,t:1527272133323};\\\", \\\"{x:832,y:689,t:1527272133340};\\\", \\\"{x:827,y:688,t:1527272133356};\\\", \\\"{x:827,y:687,t:1527272133518};\\\", \\\"{x:826,y:682,t:1527272133525};\\\", \\\"{x:821,y:674,t:1527272133540};\\\", \\\"{x:821,y:673,t:1527272133557};\\\", \\\"{x:820,y:673,t:1527272134317};\\\", \\\"{x:820,y:672,t:1527272134486};\\\", \\\"{x:820,y:671,t:1527272134525};\\\", \\\"{x:826,y:670,t:1527272134541};\\\", \\\"{x:838,y:670,t:1527272134557};\\\", \\\"{x:853,y:670,t:1527272134574};\\\", \\\"{x:874,y:670,t:1527272134591};\\\", \\\"{x:903,y:670,t:1527272134608};\\\", \\\"{x:939,y:670,t:1527272134624};\\\", \\\"{x:977,y:667,t:1527272134641};\\\", \\\"{x:1022,y:660,t:1527272134659};\\\", \\\"{x:1067,y:654,t:1527272134674};\\\", \\\"{x:1113,y:645,t:1527272134691};\\\", \\\"{x:1153,y:638,t:1527272134708};\\\", \\\"{x:1181,y:632,t:1527272134725};\\\", \\\"{x:1228,y:626,t:1527272134742};\\\", \\\"{x:1248,y:620,t:1527272134757};\\\", \\\"{x:1262,y:615,t:1527272134774};\\\", \\\"{x:1275,y:609,t:1527272134791};\\\", \\\"{x:1283,y:605,t:1527272134810};\\\", \\\"{x:1288,y:599,t:1527272134825};\\\", \\\"{x:1292,y:593,t:1527272134841};\\\", \\\"{x:1296,y:587,t:1527272134858};\\\", \\\"{x:1300,y:581,t:1527272134874};\\\", \\\"{x:1306,y:574,t:1527272134891};\\\", \\\"{x:1308,y:572,t:1527272134909};\\\", \\\"{x:1309,y:569,t:1527272134925};\\\", \\\"{x:1310,y:567,t:1527272134942};\\\", \\\"{x:1310,y:566,t:1527272134958};\\\", \\\"{x:1311,y:565,t:1527272134997};\\\", \\\"{x:1311,y:564,t:1527272135021};\\\", \\\"{x:1310,y:564,t:1527272135374};\\\", \\\"{x:1308,y:564,t:1527272135392};\\\", \\\"{x:1307,y:565,t:1527272135408};\\\", \\\"{x:1306,y:565,t:1527272135429};\\\", \\\"{x:1304,y:565,t:1527272135446};\\\", \\\"{x:1303,y:566,t:1527272135494};\\\", \\\"{x:1302,y:566,t:1527272135526};\\\", \\\"{x:1302,y:567,t:1527272135549};\\\", \\\"{x:1301,y:568,t:1527272135558};\\\", \\\"{x:1300,y:568,t:1527272135576};\\\", \\\"{x:1298,y:570,t:1527272135598};\\\", \\\"{x:1297,y:570,t:1527272135621};\\\", \\\"{x:1297,y:571,t:1527272135629};\\\", \\\"{x:1296,y:571,t:1527272135642};\\\", \\\"{x:1295,y:571,t:1527272135659};\\\", \\\"{x:1295,y:572,t:1527272135676};\\\", \\\"{x:1294,y:572,t:1527272135692};\\\", \\\"{x:1294,y:573,t:1527272135709};\\\", \\\"{x:1293,y:574,t:1527272135725};\\\", \\\"{x:1292,y:574,t:1527272135743};\\\", \\\"{x:1291,y:575,t:1527272135766};\\\", \\\"{x:1290,y:576,t:1527272135902};\\\", \\\"{x:1290,y:577,t:1527272135974};\\\", \\\"{x:1289,y:577,t:1527272135997};\\\", \\\"{x:1288,y:577,t:1527272136010};\\\", \\\"{x:1288,y:578,t:1527272136037};\\\", \\\"{x:1286,y:580,t:1527272139478};\\\", \\\"{x:1284,y:583,t:1527272139496};\\\", \\\"{x:1279,y:585,t:1527272139512};\\\", \\\"{x:1276,y:588,t:1527272139528};\\\", \\\"{x:1273,y:590,t:1527272139545};\\\", \\\"{x:1271,y:593,t:1527272139562};\\\", \\\"{x:1269,y:596,t:1527272139579};\\\", \\\"{x:1265,y:602,t:1527272139596};\\\", \\\"{x:1261,y:611,t:1527272139611};\\\", \\\"{x:1255,y:630,t:1527272139628};\\\", \\\"{x:1246,y:658,t:1527272139645};\\\", \\\"{x:1239,y:680,t:1527272139661};\\\", \\\"{x:1232,y:709,t:1527272139677};\\\", \\\"{x:1224,y:735,t:1527272139695};\\\", \\\"{x:1221,y:758,t:1527272139710};\\\", \\\"{x:1221,y:773,t:1527272139727};\\\", \\\"{x:1221,y:785,t:1527272139745};\\\", \\\"{x:1221,y:794,t:1527272139761};\\\", \\\"{x:1221,y:797,t:1527272139778};\\\", \\\"{x:1222,y:800,t:1527272139795};\\\", \\\"{x:1222,y:801,t:1527272139918};\\\", \\\"{x:1222,y:799,t:1527272139950};\\\", \\\"{x:1221,y:798,t:1527272139962};\\\", \\\"{x:1218,y:796,t:1527272139978};\\\", \\\"{x:1215,y:793,t:1527272139995};\\\", \\\"{x:1214,y:792,t:1527272140012};\\\", \\\"{x:1212,y:790,t:1527272140028};\\\", \\\"{x:1211,y:789,t:1527272140046};\\\", \\\"{x:1210,y:789,t:1527272140062};\\\", \\\"{x:1210,y:788,t:1527272140086};\\\", \\\"{x:1209,y:787,t:1527272140101};\\\", \\\"{x:1208,y:786,t:1527272140125};\\\", \\\"{x:1207,y:784,t:1527272140141};\\\", \\\"{x:1207,y:783,t:1527272140158};\\\", \\\"{x:1207,y:781,t:1527272140182};\\\", \\\"{x:1206,y:780,t:1527272140195};\\\", \\\"{x:1205,y:779,t:1527272140213};\\\", \\\"{x:1204,y:778,t:1527272140229};\\\", \\\"{x:1203,y:774,t:1527272140246};\\\", \\\"{x:1202,y:773,t:1527272140262};\\\", \\\"{x:1200,y:771,t:1527272140279};\\\", \\\"{x:1199,y:769,t:1527272140295};\\\", \\\"{x:1198,y:768,t:1527272140313};\\\", \\\"{x:1198,y:767,t:1527272140329};\\\", \\\"{x:1197,y:767,t:1527272140345};\\\", \\\"{x:1197,y:765,t:1527272140363};\\\", \\\"{x:1195,y:764,t:1527272140379};\\\", \\\"{x:1194,y:763,t:1527272140395};\\\", \\\"{x:1194,y:761,t:1527272140412};\\\", \\\"{x:1192,y:761,t:1527272140429};\\\", \\\"{x:1192,y:760,t:1527272140445};\\\", \\\"{x:1191,y:759,t:1527272140462};\\\", \\\"{x:1191,y:758,t:1527272141062};\\\", \\\"{x:1191,y:755,t:1527272141080};\\\", \\\"{x:1191,y:754,t:1527272141096};\\\", \\\"{x:1191,y:750,t:1527272141112};\\\", \\\"{x:1192,y:747,t:1527272141129};\\\", \\\"{x:1193,y:744,t:1527272141146};\\\", \\\"{x:1193,y:741,t:1527272141162};\\\", \\\"{x:1194,y:739,t:1527272141179};\\\", \\\"{x:1195,y:737,t:1527272141197};\\\", \\\"{x:1196,y:735,t:1527272141212};\\\", \\\"{x:1196,y:733,t:1527272141229};\\\", \\\"{x:1196,y:731,t:1527272141246};\\\", \\\"{x:1197,y:729,t:1527272141263};\\\", \\\"{x:1198,y:728,t:1527272141280};\\\", \\\"{x:1198,y:727,t:1527272141296};\\\", \\\"{x:1198,y:726,t:1527272141317};\\\", \\\"{x:1199,y:725,t:1527272141349};\\\", \\\"{x:1200,y:723,t:1527272141454};\\\", \\\"{x:1202,y:721,t:1527272141854};\\\", \\\"{x:1203,y:721,t:1527272141864};\\\", \\\"{x:1205,y:719,t:1527272141880};\\\", \\\"{x:1207,y:718,t:1527272141896};\\\", \\\"{x:1208,y:717,t:1527272141917};\\\", \\\"{x:1210,y:717,t:1527272142110};\\\", \\\"{x:1210,y:716,t:1527272142174};\\\", \\\"{x:1212,y:716,t:1527272142830};\\\", \\\"{x:1216,y:714,t:1527272142848};\\\", \\\"{x:1219,y:710,t:1527272142864};\\\", \\\"{x:1223,y:706,t:1527272142881};\\\", \\\"{x:1225,y:704,t:1527272142898};\\\", \\\"{x:1226,y:702,t:1527272142914};\\\", \\\"{x:1227,y:701,t:1527272142931};\\\", \\\"{x:1230,y:698,t:1527272142948};\\\", \\\"{x:1233,y:693,t:1527272142964};\\\", \\\"{x:1235,y:689,t:1527272142981};\\\", \\\"{x:1241,y:681,t:1527272142997};\\\", \\\"{x:1246,y:674,t:1527272143014};\\\", \\\"{x:1250,y:669,t:1527272143031};\\\", \\\"{x:1254,y:662,t:1527272143048};\\\", \\\"{x:1258,y:656,t:1527272143065};\\\", \\\"{x:1259,y:653,t:1527272143082};\\\", \\\"{x:1260,y:649,t:1527272143097};\\\", \\\"{x:1262,y:648,t:1527272143115};\\\", \\\"{x:1262,y:647,t:1527272143132};\\\", \\\"{x:1263,y:646,t:1527272143148};\\\", \\\"{x:1265,y:643,t:1527272143165};\\\", \\\"{x:1265,y:640,t:1527272143181};\\\", \\\"{x:1266,y:637,t:1527272143197};\\\", \\\"{x:1267,y:635,t:1527272143214};\\\", \\\"{x:1267,y:633,t:1527272143231};\\\", \\\"{x:1268,y:630,t:1527272143248};\\\", \\\"{x:1269,y:628,t:1527272143265};\\\", \\\"{x:1269,y:625,t:1527272143282};\\\", \\\"{x:1269,y:624,t:1527272143297};\\\", \\\"{x:1271,y:622,t:1527272143314};\\\", \\\"{x:1271,y:621,t:1527272143332};\\\", \\\"{x:1271,y:620,t:1527272143348};\\\", \\\"{x:1271,y:619,t:1527272143364};\\\", \\\"{x:1270,y:619,t:1527272143501};\\\", \\\"{x:1263,y:619,t:1527272143515};\\\", \\\"{x:1240,y:622,t:1527272143531};\\\", \\\"{x:1208,y:625,t:1527272143548};\\\", \\\"{x:1157,y:633,t:1527272143564};\\\", \\\"{x:1084,y:636,t:1527272143581};\\\", \\\"{x:1028,y:636,t:1527272143598};\\\", \\\"{x:969,y:636,t:1527272143614};\\\", \\\"{x:913,y:636,t:1527272143631};\\\", \\\"{x:858,y:636,t:1527272143648};\\\", \\\"{x:810,y:636,t:1527272143664};\\\", \\\"{x:771,y:636,t:1527272143681};\\\", \\\"{x:738,y:636,t:1527272143698};\\\", \\\"{x:709,y:636,t:1527272143714};\\\", \\\"{x:685,y:636,t:1527272143731};\\\", \\\"{x:664,y:635,t:1527272143748};\\\", \\\"{x:634,y:630,t:1527272143765};\\\", \\\"{x:614,y:627,t:1527272143781};\\\", \\\"{x:596,y:624,t:1527272143798};\\\", \\\"{x:589,y:621,t:1527272143812};\\\", \\\"{x:578,y:619,t:1527272143828};\\\", \\\"{x:575,y:617,t:1527272143845};\\\", \\\"{x:574,y:617,t:1527272143924};\\\", \\\"{x:574,y:616,t:1527272143940};\\\", \\\"{x:573,y:616,t:1527272144005};\\\", \\\"{x:573,y:615,t:1527272144061};\\\", \\\"{x:573,y:614,t:1527272144079};\\\", \\\"{x:572,y:615,t:1527272144374};\\\", \\\"{x:570,y:616,t:1527272144381};\\\", \\\"{x:565,y:618,t:1527272144394};\\\", \\\"{x:556,y:619,t:1527272144411};\\\", \\\"{x:541,y:621,t:1527272144427};\\\", \\\"{x:526,y:621,t:1527272144443};\\\", \\\"{x:505,y:621,t:1527272144460};\\\", \\\"{x:496,y:620,t:1527272144477};\\\", \\\"{x:489,y:618,t:1527272144494};\\\", \\\"{x:482,y:616,t:1527272144515};\\\", \\\"{x:473,y:612,t:1527272144532};\\\", \\\"{x:467,y:609,t:1527272144548};\\\", \\\"{x:460,y:604,t:1527272144565};\\\", \\\"{x:455,y:601,t:1527272144581};\\\", \\\"{x:451,y:599,t:1527272144600};\\\", \\\"{x:449,y:597,t:1527272144615};\\\", \\\"{x:448,y:596,t:1527272144632};\\\", \\\"{x:448,y:594,t:1527272144648};\\\", \\\"{x:448,y:592,t:1527272144666};\\\", \\\"{x:456,y:589,t:1527272144682};\\\", \\\"{x:466,y:583,t:1527272144699};\\\", \\\"{x:480,y:577,t:1527272144715};\\\", \\\"{x:506,y:573,t:1527272144733};\\\", \\\"{x:592,y:568,t:1527272144748};\\\", \\\"{x:651,y:568,t:1527272144765};\\\", \\\"{x:683,y:567,t:1527272144782};\\\", \\\"{x:700,y:567,t:1527272144799};\\\", \\\"{x:705,y:566,t:1527272144815};\\\", \\\"{x:706,y:566,t:1527272144901};\\\", \\\"{x:709,y:566,t:1527272144915};\\\", \\\"{x:714,y:562,t:1527272144933};\\\", \\\"{x:727,y:555,t:1527272144949};\\\", \\\"{x:735,y:553,t:1527272144967};\\\", \\\"{x:747,y:551,t:1527272144982};\\\", \\\"{x:752,y:551,t:1527272144999};\\\", \\\"{x:751,y:551,t:1527272145069};\\\", \\\"{x:750,y:552,t:1527272145082};\\\", \\\"{x:747,y:553,t:1527272145099};\\\", \\\"{x:743,y:555,t:1527272145117};\\\", \\\"{x:737,y:556,t:1527272145133};\\\", \\\"{x:719,y:560,t:1527272145149};\\\", \\\"{x:699,y:564,t:1527272145166};\\\", \\\"{x:671,y:564,t:1527272145182};\\\", \\\"{x:645,y:564,t:1527272145199};\\\", \\\"{x:618,y:564,t:1527272145216};\\\", \\\"{x:592,y:564,t:1527272145232};\\\", \\\"{x:565,y:564,t:1527272145249};\\\", \\\"{x:542,y:564,t:1527272145266};\\\", \\\"{x:518,y:564,t:1527272145282};\\\", \\\"{x:501,y:564,t:1527272145299};\\\", \\\"{x:485,y:564,t:1527272145316};\\\", \\\"{x:475,y:564,t:1527272145332};\\\", \\\"{x:464,y:562,t:1527272145350};\\\", \\\"{x:461,y:560,t:1527272145366};\\\", \\\"{x:459,y:559,t:1527272145382};\\\", \\\"{x:454,y:557,t:1527272145399};\\\", \\\"{x:448,y:555,t:1527272145416};\\\", \\\"{x:437,y:551,t:1527272145432};\\\", \\\"{x:422,y:547,t:1527272145449};\\\", \\\"{x:402,y:541,t:1527272145467};\\\", \\\"{x:380,y:535,t:1527272145484};\\\", \\\"{x:356,y:532,t:1527272145499};\\\", \\\"{x:327,y:527,t:1527272145516};\\\", \\\"{x:316,y:525,t:1527272145533};\\\", \\\"{x:310,y:525,t:1527272145549};\\\", \\\"{x:307,y:525,t:1527272145566};\\\", \\\"{x:301,y:526,t:1527272145584};\\\", \\\"{x:289,y:529,t:1527272145599};\\\", \\\"{x:275,y:532,t:1527272145616};\\\", \\\"{x:257,y:534,t:1527272145635};\\\", \\\"{x:240,y:534,t:1527272145649};\\\", \\\"{x:225,y:534,t:1527272145666};\\\", \\\"{x:212,y:530,t:1527272145682};\\\", \\\"{x:199,y:527,t:1527272145699};\\\", \\\"{x:181,y:521,t:1527272145717};\\\", \\\"{x:147,y:506,t:1527272145734};\\\", \\\"{x:125,y:497,t:1527272145750};\\\", \\\"{x:112,y:490,t:1527272145766};\\\", \\\"{x:107,y:488,t:1527272145783};\\\", \\\"{x:105,y:487,t:1527272145800};\\\", \\\"{x:106,y:487,t:1527272145981};\\\", \\\"{x:108,y:487,t:1527272145989};\\\", \\\"{x:111,y:487,t:1527272146000};\\\", \\\"{x:115,y:488,t:1527272146016};\\\", \\\"{x:121,y:491,t:1527272146033};\\\", \\\"{x:125,y:494,t:1527272146051};\\\", \\\"{x:128,y:496,t:1527272146067};\\\", \\\"{x:131,y:498,t:1527272146084};\\\", \\\"{x:132,y:500,t:1527272146100};\\\", \\\"{x:133,y:500,t:1527272146141};\\\", \\\"{x:135,y:501,t:1527272146150};\\\", \\\"{x:138,y:502,t:1527272146167};\\\", \\\"{x:140,y:502,t:1527272146183};\\\", \\\"{x:143,y:503,t:1527272146201};\\\", \\\"{x:146,y:505,t:1527272146218};\\\", \\\"{x:150,y:505,t:1527272146233};\\\", \\\"{x:154,y:505,t:1527272146252};\\\", \\\"{x:157,y:506,t:1527272146267};\\\", \\\"{x:158,y:506,t:1527272146292};\\\", \\\"{x:160,y:506,t:1527272146316};\\\", \\\"{x:161,y:506,t:1527272146348};\\\", \\\"{x:163,y:505,t:1527272146605};\\\", \\\"{x:172,y:511,t:1527272146617};\\\", \\\"{x:204,y:535,t:1527272146634};\\\", \\\"{x:245,y:572,t:1527272146651};\\\", \\\"{x:312,y:619,t:1527272146667};\\\", \\\"{x:386,y:660,t:1527272146684};\\\", \\\"{x:485,y:711,t:1527272146700};\\\", \\\"{x:529,y:729,t:1527272146719};\\\", \\\"{x:552,y:741,t:1527272146734};\\\", \\\"{x:561,y:744,t:1527272146750};\\\", \\\"{x:562,y:744,t:1527272146767};\\\", \\\"{x:562,y:745,t:1527272146783};\\\", \\\"{x:561,y:744,t:1527272147126};\\\", \\\"{x:558,y:743,t:1527272147133};\\\", \\\"{x:553,y:742,t:1527272147150};\\\", \\\"{x:548,y:740,t:1527272147167};\\\", \\\"{x:547,y:740,t:1527272147183};\\\", \\\"{x:546,y:740,t:1527272147428};\\\", \\\"{x:543,y:739,t:1527272147436};\\\", \\\"{x:543,y:738,t:1527272147451};\\\", \\\"{x:542,y:735,t:1527272147467};\\\", \\\"{x:541,y:733,t:1527272147484};\\\", \\\"{x:543,y:731,t:1527272147797};\\\", \\\"{x:546,y:729,t:1527272147805};\\\", \\\"{x:551,y:726,t:1527272147819};\\\", \\\"{x:559,y:719,t:1527272147835};\\\", \\\"{x:573,y:710,t:1527272147852};\\\", \\\"{x:594,y:698,t:1527272147869};\\\", \\\"{x:602,y:693,t:1527272147884};\\\", \\\"{x:629,y:678,t:1527272147901};\\\", \\\"{x:648,y:671,t:1527272147919};\\\", \\\"{x:664,y:664,t:1527272147934};\\\", \\\"{x:678,y:659,t:1527272147951};\\\", \\\"{x:688,y:657,t:1527272147969};\\\", \\\"{x:703,y:654,t:1527272147984};\\\", \\\"{x:717,y:651,t:1527272148001};\\\", \\\"{x:730,y:650,t:1527272148019};\\\", \\\"{x:740,y:649,t:1527272148035};\\\", \\\"{x:745,y:647,t:1527272148051};\\\", \\\"{x:747,y:646,t:1527272148068};\\\" ] }, { \\\"rt\\\": 12439, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 576454, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:748,y:646,t:1527272148780};\\\", \\\"{x:752,y:643,t:1527272148788};\\\", \\\"{x:758,y:641,t:1527272148802};\\\", \\\"{x:779,y:636,t:1527272148818};\\\", \\\"{x:801,y:632,t:1527272148836};\\\", \\\"{x:859,y:627,t:1527272148871};\\\", \\\"{x:881,y:627,t:1527272148885};\\\", \\\"{x:896,y:627,t:1527272148903};\\\", \\\"{x:907,y:627,t:1527272148919};\\\", \\\"{x:910,y:627,t:1527272148936};\\\", \\\"{x:911,y:627,t:1527272148952};\\\", \\\"{x:909,y:627,t:1527272149093};\\\", \\\"{x:905,y:627,t:1527272149102};\\\", \\\"{x:892,y:627,t:1527272149119};\\\", \\\"{x:871,y:627,t:1527272149135};\\\", \\\"{x:840,y:627,t:1527272149152};\\\", \\\"{x:800,y:623,t:1527272149169};\\\", \\\"{x:758,y:616,t:1527272149185};\\\", \\\"{x:554,y:564,t:1527272149275};\\\", \\\"{x:510,y:546,t:1527272149286};\\\", \\\"{x:469,y:530,t:1527272149303};\\\", \\\"{x:439,y:517,t:1527272149319};\\\", \\\"{x:424,y:510,t:1527272149336};\\\", \\\"{x:420,y:508,t:1527272149352};\\\", \\\"{x:419,y:506,t:1527272149369};\\\", \\\"{x:419,y:504,t:1527272149385};\\\", \\\"{x:419,y:501,t:1527272149402};\\\", \\\"{x:423,y:498,t:1527272149419};\\\", \\\"{x:429,y:494,t:1527272149435};\\\", \\\"{x:443,y:486,t:1527272149454};\\\", \\\"{x:456,y:483,t:1527272149468};\\\", \\\"{x:475,y:479,t:1527272149485};\\\", \\\"{x:494,y:475,t:1527272149502};\\\", \\\"{x:512,y:470,t:1527272149520};\\\", \\\"{x:526,y:468,t:1527272149536};\\\", \\\"{x:542,y:467,t:1527272149552};\\\", \\\"{x:556,y:464,t:1527272149569};\\\", \\\"{x:567,y:463,t:1527272149585};\\\", \\\"{x:576,y:460,t:1527272149602};\\\", \\\"{x:583,y:460,t:1527272149620};\\\", \\\"{x:586,y:460,t:1527272149635};\\\", \\\"{x:587,y:460,t:1527272149653};\\\", \\\"{x:591,y:461,t:1527272150213};\\\", \\\"{x:593,y:462,t:1527272150221};\\\", \\\"{x:599,y:465,t:1527272150236};\\\", \\\"{x:631,y:472,t:1527272150255};\\\", \\\"{x:672,y:479,t:1527272150270};\\\", \\\"{x:736,y:487,t:1527272150287};\\\", \\\"{x:817,y:496,t:1527272150302};\\\", \\\"{x:903,y:512,t:1527272150319};\\\", \\\"{x:999,y:529,t:1527272150337};\\\", \\\"{x:1095,y:541,t:1527272150353};\\\", \\\"{x:1195,y:554,t:1527272150370};\\\", \\\"{x:1293,y:570,t:1527272150386};\\\", \\\"{x:1388,y:587,t:1527272150403};\\\", \\\"{x:1518,y:608,t:1527272150420};\\\", \\\"{x:1586,y:624,t:1527272150436};\\\", \\\"{x:1651,y:634,t:1527272150454};\\\", \\\"{x:1702,y:645,t:1527272150470};\\\", \\\"{x:1734,y:655,t:1527272150486};\\\", \\\"{x:1755,y:662,t:1527272150504};\\\", \\\"{x:1774,y:669,t:1527272150520};\\\", \\\"{x:1785,y:676,t:1527272150536};\\\", \\\"{x:1793,y:682,t:1527272150553};\\\", \\\"{x:1798,y:685,t:1527272150571};\\\", \\\"{x:1800,y:688,t:1527272150586};\\\", \\\"{x:1801,y:691,t:1527272150604};\\\", \\\"{x:1801,y:695,t:1527272150621};\\\", \\\"{x:1798,y:702,t:1527272150637};\\\", \\\"{x:1791,y:709,t:1527272150653};\\\", \\\"{x:1776,y:714,t:1527272150671};\\\", \\\"{x:1758,y:721,t:1527272150687};\\\", \\\"{x:1736,y:725,t:1527272150704};\\\", \\\"{x:1711,y:729,t:1527272150721};\\\", \\\"{x:1681,y:729,t:1527272150737};\\\", \\\"{x:1636,y:729,t:1527272150754};\\\", \\\"{x:1566,y:729,t:1527272150771};\\\", \\\"{x:1532,y:729,t:1527272150787};\\\", \\\"{x:1512,y:728,t:1527272150804};\\\", \\\"{x:1504,y:725,t:1527272150822};\\\", \\\"{x:1503,y:725,t:1527272150902};\\\", \\\"{x:1502,y:725,t:1527272150910};\\\", \\\"{x:1501,y:724,t:1527272150921};\\\", \\\"{x:1500,y:724,t:1527272150938};\\\", \\\"{x:1495,y:724,t:1527272150955};\\\", \\\"{x:1491,y:724,t:1527272150971};\\\", \\\"{x:1488,y:724,t:1527272150988};\\\", \\\"{x:1486,y:723,t:1527272151006};\\\", \\\"{x:1486,y:722,t:1527272151029};\\\", \\\"{x:1485,y:722,t:1527272151038};\\\", \\\"{x:1482,y:721,t:1527272151055};\\\", \\\"{x:1478,y:720,t:1527272151071};\\\", \\\"{x:1470,y:718,t:1527272151088};\\\", \\\"{x:1461,y:716,t:1527272151104};\\\", \\\"{x:1447,y:712,t:1527272151121};\\\", \\\"{x:1426,y:706,t:1527272151138};\\\", \\\"{x:1400,y:701,t:1527272151154};\\\", \\\"{x:1376,y:697,t:1527272151171};\\\", \\\"{x:1361,y:695,t:1527272151188};\\\", \\\"{x:1353,y:694,t:1527272151207};\\\", \\\"{x:1351,y:694,t:1527272151220};\\\", \\\"{x:1343,y:690,t:1527272156927};\\\", \\\"{x:1278,y:686,t:1527272156943};\\\", \\\"{x:1166,y:682,t:1527272156959};\\\", \\\"{x:1031,y:667,t:1527272156976};\\\", \\\"{x:898,y:650,t:1527272156992};\\\", \\\"{x:795,y:634,t:1527272157008};\\\", \\\"{x:737,y:627,t:1527272157026};\\\", \\\"{x:708,y:624,t:1527272157042};\\\", \\\"{x:698,y:621,t:1527272157058};\\\", \\\"{x:696,y:621,t:1527272157075};\\\", \\\"{x:694,y:621,t:1527272157092};\\\", \\\"{x:692,y:621,t:1527272157108};\\\", \\\"{x:689,y:621,t:1527272157126};\\\", \\\"{x:685,y:621,t:1527272157143};\\\", \\\"{x:684,y:621,t:1527272157158};\\\", \\\"{x:683,y:621,t:1527272157175};\\\", \\\"{x:682,y:621,t:1527272157196};\\\", \\\"{x:680,y:620,t:1527272157236};\\\", \\\"{x:677,y:618,t:1527272157244};\\\", \\\"{x:675,y:618,t:1527272157258};\\\", \\\"{x:666,y:613,t:1527272157276};\\\", \\\"{x:638,y:605,t:1527272157294};\\\", \\\"{x:612,y:597,t:1527272157309};\\\", \\\"{x:587,y:589,t:1527272157325};\\\", \\\"{x:569,y:583,t:1527272157342};\\\", \\\"{x:562,y:579,t:1527272157358};\\\", \\\"{x:559,y:577,t:1527272157376};\\\", \\\"{x:558,y:576,t:1527272157392};\\\", \\\"{x:558,y:574,t:1527272157409};\\\", \\\"{x:558,y:572,t:1527272157425};\\\", \\\"{x:558,y:570,t:1527272157443};\\\", \\\"{x:558,y:568,t:1527272157459};\\\", \\\"{x:566,y:564,t:1527272157476};\\\", \\\"{x:576,y:558,t:1527272157493};\\\", \\\"{x:582,y:556,t:1527272157508};\\\", \\\"{x:586,y:553,t:1527272157526};\\\", \\\"{x:592,y:553,t:1527272157543};\\\", \\\"{x:599,y:553,t:1527272157560};\\\", \\\"{x:602,y:553,t:1527272157576};\\\", \\\"{x:606,y:553,t:1527272157593};\\\", \\\"{x:609,y:552,t:1527272157609};\\\", \\\"{x:610,y:552,t:1527272157637};\\\", \\\"{x:610,y:553,t:1527272157669};\\\", \\\"{x:608,y:553,t:1527272157676};\\\", \\\"{x:601,y:557,t:1527272157693};\\\", \\\"{x:592,y:560,t:1527272157710};\\\", \\\"{x:582,y:562,t:1527272157726};\\\", \\\"{x:571,y:564,t:1527272157744};\\\", \\\"{x:557,y:568,t:1527272157758};\\\", \\\"{x:546,y:572,t:1527272157775};\\\", \\\"{x:537,y:574,t:1527272157793};\\\", \\\"{x:531,y:576,t:1527272157810};\\\", \\\"{x:522,y:578,t:1527272157826};\\\", \\\"{x:514,y:581,t:1527272157843};\\\", \\\"{x:507,y:582,t:1527272157859};\\\", \\\"{x:499,y:586,t:1527272157876};\\\", \\\"{x:492,y:590,t:1527272157894};\\\", \\\"{x:487,y:591,t:1527272157909};\\\", \\\"{x:483,y:594,t:1527272157926};\\\", \\\"{x:479,y:595,t:1527272157943};\\\", \\\"{x:476,y:596,t:1527272157959};\\\", \\\"{x:472,y:598,t:1527272157976};\\\", \\\"{x:468,y:600,t:1527272157993};\\\", \\\"{x:465,y:602,t:1527272158010};\\\", \\\"{x:459,y:604,t:1527272158025};\\\", \\\"{x:455,y:605,t:1527272158043};\\\", \\\"{x:449,y:608,t:1527272158059};\\\", \\\"{x:439,y:609,t:1527272158076};\\\", \\\"{x:434,y:610,t:1527272158092};\\\", \\\"{x:428,y:610,t:1527272158110};\\\", \\\"{x:423,y:610,t:1527272158126};\\\", \\\"{x:415,y:610,t:1527272158144};\\\", \\\"{x:410,y:610,t:1527272158160};\\\", \\\"{x:403,y:610,t:1527272158177};\\\", \\\"{x:396,y:610,t:1527272158192};\\\", \\\"{x:389,y:610,t:1527272158210};\\\", \\\"{x:385,y:610,t:1527272158227};\\\", \\\"{x:382,y:610,t:1527272158242};\\\", \\\"{x:379,y:609,t:1527272158259};\\\", \\\"{x:376,y:608,t:1527272158276};\\\", \\\"{x:373,y:607,t:1527272158294};\\\", \\\"{x:369,y:605,t:1527272158310};\\\", \\\"{x:364,y:603,t:1527272158327};\\\", \\\"{x:357,y:600,t:1527272158343};\\\", \\\"{x:350,y:599,t:1527272158360};\\\", \\\"{x:343,y:596,t:1527272158376};\\\", \\\"{x:338,y:595,t:1527272158393};\\\", \\\"{x:335,y:595,t:1527272158410};\\\", \\\"{x:327,y:592,t:1527272158427};\\\", \\\"{x:321,y:591,t:1527272158443};\\\", \\\"{x:309,y:590,t:1527272158459};\\\", \\\"{x:294,y:589,t:1527272158476};\\\", \\\"{x:280,y:589,t:1527272158492};\\\", \\\"{x:269,y:589,t:1527272158510};\\\", \\\"{x:256,y:589,t:1527272158526};\\\", \\\"{x:247,y:589,t:1527272158543};\\\", \\\"{x:237,y:589,t:1527272158560};\\\", \\\"{x:230,y:592,t:1527272158577};\\\", \\\"{x:223,y:597,t:1527272158594};\\\", \\\"{x:215,y:603,t:1527272158610};\\\", \\\"{x:203,y:609,t:1527272158627};\\\", \\\"{x:190,y:616,t:1527272158644};\\\", \\\"{x:183,y:618,t:1527272158660};\\\", \\\"{x:178,y:620,t:1527272158676};\\\", \\\"{x:181,y:620,t:1527272158830};\\\", \\\"{x:186,y:619,t:1527272158843};\\\", \\\"{x:200,y:619,t:1527272158861};\\\", \\\"{x:228,y:619,t:1527272158876};\\\", \\\"{x:255,y:619,t:1527272158894};\\\", \\\"{x:293,y:621,t:1527272158911};\\\", \\\"{x:340,y:625,t:1527272158926};\\\", \\\"{x:383,y:628,t:1527272158943};\\\", \\\"{x:428,y:630,t:1527272158959};\\\", \\\"{x:470,y:630,t:1527272158977};\\\", \\\"{x:515,y:630,t:1527272158994};\\\", \\\"{x:553,y:633,t:1527272159011};\\\", \\\"{x:580,y:635,t:1527272159027};\\\", \\\"{x:600,y:637,t:1527272159044};\\\", \\\"{x:630,y:640,t:1527272159060};\\\", \\\"{x:649,y:640,t:1527272159076};\\\", \\\"{x:667,y:640,t:1527272159093};\\\", \\\"{x:686,y:640,t:1527272159111};\\\", \\\"{x:711,y:638,t:1527272159126};\\\", \\\"{x:741,y:630,t:1527272159144};\\\", \\\"{x:785,y:618,t:1527272159161};\\\", \\\"{x:835,y:605,t:1527272159177};\\\", \\\"{x:884,y:594,t:1527272159194};\\\", \\\"{x:910,y:585,t:1527272159212};\\\", \\\"{x:924,y:582,t:1527272159227};\\\", \\\"{x:927,y:580,t:1527272159244};\\\", \\\"{x:927,y:579,t:1527272159261};\\\", \\\"{x:928,y:579,t:1527272159317};\\\", \\\"{x:929,y:578,t:1527272159327};\\\", \\\"{x:930,y:578,t:1527272159344};\\\", \\\"{x:930,y:577,t:1527272159405};\\\", \\\"{x:924,y:574,t:1527272159412};\\\", \\\"{x:921,y:573,t:1527272159428};\\\", \\\"{x:907,y:572,t:1527272159444};\\\", \\\"{x:881,y:572,t:1527272159461};\\\", \\\"{x:858,y:575,t:1527272159479};\\\", \\\"{x:831,y:582,t:1527272159495};\\\", \\\"{x:803,y:587,t:1527272159511};\\\", \\\"{x:775,y:597,t:1527272159528};\\\", \\\"{x:754,y:604,t:1527272159544};\\\", \\\"{x:739,y:612,t:1527272159560};\\\", \\\"{x:729,y:619,t:1527272159577};\\\", \\\"{x:724,y:626,t:1527272159593};\\\", \\\"{x:718,y:633,t:1527272159611};\\\", \\\"{x:716,y:639,t:1527272159628};\\\", \\\"{x:715,y:642,t:1527272159643};\\\", \\\"{x:715,y:644,t:1527272159661};\\\", \\\"{x:715,y:645,t:1527272159678};\\\", \\\"{x:715,y:646,t:1527272159695};\\\", \\\"{x:719,y:649,t:1527272159711};\\\", \\\"{x:736,y:652,t:1527272159728};\\\", \\\"{x:760,y:655,t:1527272159745};\\\", \\\"{x:798,y:659,t:1527272159760};\\\", \\\"{x:840,y:665,t:1527272159778};\\\", \\\"{x:880,y:672,t:1527272159794};\\\", \\\"{x:904,y:675,t:1527272159812};\\\", \\\"{x:914,y:675,t:1527272159828};\\\", \\\"{x:917,y:675,t:1527272159845};\\\", \\\"{x:917,y:672,t:1527272159917};\\\", \\\"{x:915,y:670,t:1527272159928};\\\", \\\"{x:909,y:667,t:1527272159946};\\\", \\\"{x:893,y:661,t:1527272159962};\\\", \\\"{x:873,y:653,t:1527272159979};\\\", \\\"{x:853,y:646,t:1527272159995};\\\", \\\"{x:841,y:640,t:1527272160012};\\\", \\\"{x:836,y:636,t:1527272160028};\\\", \\\"{x:835,y:634,t:1527272160045};\\\", \\\"{x:835,y:631,t:1527272160063};\\\", \\\"{x:835,y:628,t:1527272160079};\\\", \\\"{x:835,y:624,t:1527272160094};\\\", \\\"{x:835,y:623,t:1527272160111};\\\", \\\"{x:835,y:621,t:1527272160128};\\\", \\\"{x:835,y:619,t:1527272160145};\\\", \\\"{x:834,y:618,t:1527272160161};\\\", \\\"{x:834,y:617,t:1527272160180};\\\", \\\"{x:834,y:614,t:1527272160194};\\\", \\\"{x:836,y:614,t:1527272160211};\\\", \\\"{x:838,y:613,t:1527272160228};\\\", \\\"{x:839,y:612,t:1527272160310};\\\", \\\"{x:842,y:612,t:1527272160340};\\\", \\\"{x:842,y:612,t:1527272160442};\\\", \\\"{x:842,y:614,t:1527272160468};\\\", \\\"{x:838,y:617,t:1527272160478};\\\", \\\"{x:824,y:628,t:1527272160495};\\\", \\\"{x:798,y:644,t:1527272160512};\\\", \\\"{x:764,y:658,t:1527272160527};\\\", \\\"{x:710,y:678,t:1527272160544};\\\", \\\"{x:653,y:698,t:1527272160562};\\\", \\\"{x:601,y:721,t:1527272160577};\\\", \\\"{x:574,y:736,t:1527272160594};\\\", \\\"{x:560,y:749,t:1527272160613};\\\", \\\"{x:557,y:758,t:1527272160628};\\\", \\\"{x:557,y:766,t:1527272160645};\\\", \\\"{x:557,y:770,t:1527272160662};\\\", \\\"{x:556,y:771,t:1527272160725};\\\", \\\"{x:555,y:771,t:1527272160765};\\\", \\\"{x:554,y:771,t:1527272160778};\\\", \\\"{x:550,y:766,t:1527272160795};\\\", \\\"{x:542,y:761,t:1527272160813};\\\", \\\"{x:528,y:752,t:1527272160830};\\\", \\\"{x:519,y:750,t:1527272160845};\\\", \\\"{x:513,y:746,t:1527272160862};\\\", \\\"{x:512,y:745,t:1527272160942};\\\", \\\"{x:512,y:743,t:1527272160949};\\\", \\\"{x:512,y:742,t:1527272160963};\\\", \\\"{x:512,y:741,t:1527272160980};\\\", \\\"{x:512,y:740,t:1527272161453};\\\", \\\"{x:512,y:737,t:1527272161462};\\\", \\\"{x:512,y:729,t:1527272161479};\\\", \\\"{x:515,y:723,t:1527272161496};\\\", \\\"{x:516,y:718,t:1527272161512};\\\", \\\"{x:519,y:714,t:1527272161529};\\\", \\\"{x:520,y:713,t:1527272161546};\\\", \\\"{x:520,y:712,t:1527272161562};\\\", \\\"{x:522,y:710,t:1527272161579};\\\", \\\"{x:522,y:708,t:1527272161596};\\\", \\\"{x:523,y:707,t:1527272161612};\\\", \\\"{x:523,y:706,t:1527272161629};\\\", \\\"{x:523,y:705,t:1527272162021};\\\", \\\"{x:524,y:704,t:1527272162029};\\\", \\\"{x:525,y:703,t:1527272162046};\\\", \\\"{x:525,y:702,t:1527272162063};\\\", \\\"{x:525,y:701,t:1527272162101};\\\", \\\"{x:526,y:699,t:1527272162189};\\\", \\\"{x:526,y:698,t:1527272162213};\\\", \\\"{x:526,y:697,t:1527272162244};\\\" ] }, { \\\"rt\\\": 10618, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 588327, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:693,t:1527272162380};\\\", \\\"{x:529,y:692,t:1527272162413};\\\", \\\"{x:530,y:691,t:1527272162444};\\\", \\\"{x:531,y:690,t:1527272162476};\\\", \\\"{x:531,y:689,t:1527272163766};\\\", \\\"{x:554,y:689,t:1527272163781};\\\", \\\"{x:595,y:689,t:1527272163799};\\\", \\\"{x:644,y:691,t:1527272163814};\\\", \\\"{x:706,y:703,t:1527272163831};\\\", \\\"{x:754,y:718,t:1527272163848};\\\", \\\"{x:807,y:733,t:1527272163864};\\\", \\\"{x:858,y:748,t:1527272163881};\\\", \\\"{x:903,y:762,t:1527272163899};\\\", \\\"{x:967,y:781,t:1527272163914};\\\", \\\"{x:1047,y:801,t:1527272163932};\\\", \\\"{x:1125,y:826,t:1527272163949};\\\", \\\"{x:1208,y:848,t:1527272163965};\\\", \\\"{x:1303,y:878,t:1527272163981};\\\", \\\"{x:1354,y:893,t:1527272163998};\\\", \\\"{x:1392,y:909,t:1527272164014};\\\", \\\"{x:1416,y:917,t:1527272164032};\\\", \\\"{x:1437,y:926,t:1527272164049};\\\", \\\"{x:1454,y:934,t:1527272164065};\\\", \\\"{x:1469,y:941,t:1527272164081};\\\", \\\"{x:1485,y:950,t:1527272164099};\\\", \\\"{x:1500,y:955,t:1527272164115};\\\", \\\"{x:1513,y:962,t:1527272164132};\\\", \\\"{x:1525,y:967,t:1527272164148};\\\", \\\"{x:1533,y:969,t:1527272164165};\\\", \\\"{x:1534,y:969,t:1527272164181};\\\", \\\"{x:1532,y:969,t:1527272164292};\\\", \\\"{x:1527,y:969,t:1527272164300};\\\", \\\"{x:1520,y:969,t:1527272164315};\\\", \\\"{x:1509,y:969,t:1527272164331};\\\", \\\"{x:1493,y:969,t:1527272164349};\\\", \\\"{x:1488,y:969,t:1527272164364};\\\", \\\"{x:1484,y:969,t:1527272164381};\\\", \\\"{x:1481,y:969,t:1527272164398};\\\", \\\"{x:1477,y:969,t:1527272164415};\\\", \\\"{x:1470,y:969,t:1527272164431};\\\", \\\"{x:1461,y:968,t:1527272164449};\\\", \\\"{x:1451,y:968,t:1527272164465};\\\", \\\"{x:1440,y:967,t:1527272164481};\\\", \\\"{x:1431,y:966,t:1527272164498};\\\", \\\"{x:1426,y:965,t:1527272164516};\\\", \\\"{x:1422,y:964,t:1527272164531};\\\", \\\"{x:1414,y:961,t:1527272164549};\\\", \\\"{x:1405,y:959,t:1527272164565};\\\", \\\"{x:1387,y:958,t:1527272164581};\\\", \\\"{x:1377,y:957,t:1527272164598};\\\", \\\"{x:1374,y:955,t:1527272164615};\\\", \\\"{x:1373,y:955,t:1527272164632};\\\", \\\"{x:1372,y:955,t:1527272164669};\\\", \\\"{x:1371,y:955,t:1527272164682};\\\", \\\"{x:1369,y:955,t:1527272164698};\\\", \\\"{x:1366,y:955,t:1527272164716};\\\", \\\"{x:1360,y:956,t:1527272164732};\\\", \\\"{x:1357,y:956,t:1527272164749};\\\", \\\"{x:1356,y:957,t:1527272164766};\\\", \\\"{x:1355,y:957,t:1527272164941};\\\", \\\"{x:1355,y:955,t:1527272164957};\\\", \\\"{x:1354,y:952,t:1527272164965};\\\", \\\"{x:1352,y:948,t:1527272164982};\\\", \\\"{x:1350,y:944,t:1527272164998};\\\", \\\"{x:1348,y:940,t:1527272165016};\\\", \\\"{x:1347,y:933,t:1527272165032};\\\", \\\"{x:1343,y:927,t:1527272165050};\\\", \\\"{x:1339,y:915,t:1527272165065};\\\", \\\"{x:1335,y:903,t:1527272165082};\\\", \\\"{x:1333,y:894,t:1527272165099};\\\", \\\"{x:1333,y:884,t:1527272165115};\\\", \\\"{x:1332,y:867,t:1527272165132};\\\", \\\"{x:1330,y:860,t:1527272165148};\\\", \\\"{x:1329,y:850,t:1527272165165};\\\", \\\"{x:1328,y:838,t:1527272165182};\\\", \\\"{x:1326,y:827,t:1527272165199};\\\", \\\"{x:1326,y:817,t:1527272165215};\\\", \\\"{x:1326,y:807,t:1527272165232};\\\", \\\"{x:1326,y:798,t:1527272165249};\\\", \\\"{x:1326,y:786,t:1527272165265};\\\", \\\"{x:1326,y:775,t:1527272165282};\\\", \\\"{x:1327,y:765,t:1527272165299};\\\", \\\"{x:1330,y:752,t:1527272165315};\\\", \\\"{x:1335,y:737,t:1527272165332};\\\", \\\"{x:1338,y:724,t:1527272165349};\\\", \\\"{x:1340,y:714,t:1527272165365};\\\", \\\"{x:1342,y:709,t:1527272165382};\\\", \\\"{x:1345,y:702,t:1527272165399};\\\", \\\"{x:1345,y:699,t:1527272165418};\\\", \\\"{x:1345,y:698,t:1527272165432};\\\", \\\"{x:1345,y:700,t:1527272165741};\\\", \\\"{x:1345,y:707,t:1527272165750};\\\", \\\"{x:1341,y:725,t:1527272165767};\\\", \\\"{x:1337,y:745,t:1527272165782};\\\", \\\"{x:1335,y:763,t:1527272165799};\\\", \\\"{x:1333,y:780,t:1527272165817};\\\", \\\"{x:1331,y:799,t:1527272165832};\\\", \\\"{x:1328,y:818,t:1527272165849};\\\", \\\"{x:1327,y:828,t:1527272165866};\\\", \\\"{x:1326,y:836,t:1527272165882};\\\", \\\"{x:1326,y:839,t:1527272165899};\\\", \\\"{x:1326,y:843,t:1527272165917};\\\", \\\"{x:1326,y:845,t:1527272165932};\\\", \\\"{x:1326,y:847,t:1527272165950};\\\", \\\"{x:1326,y:849,t:1527272165967};\\\", \\\"{x:1326,y:851,t:1527272165983};\\\", \\\"{x:1326,y:853,t:1527272166000};\\\", \\\"{x:1326,y:854,t:1527272166016};\\\", \\\"{x:1326,y:856,t:1527272166034};\\\", \\\"{x:1326,y:859,t:1527272166049};\\\", \\\"{x:1326,y:861,t:1527272166067};\\\", \\\"{x:1326,y:863,t:1527272166084};\\\", \\\"{x:1326,y:865,t:1527272166099};\\\", \\\"{x:1326,y:863,t:1527272166829};\\\", \\\"{x:1326,y:861,t:1527272166837};\\\", \\\"{x:1327,y:857,t:1527272166850};\\\", \\\"{x:1328,y:854,t:1527272166867};\\\", \\\"{x:1332,y:849,t:1527272166884};\\\", \\\"{x:1336,y:842,t:1527272166900};\\\", \\\"{x:1340,y:836,t:1527272166917};\\\", \\\"{x:1342,y:831,t:1527272166934};\\\", \\\"{x:1343,y:826,t:1527272166951};\\\", \\\"{x:1345,y:819,t:1527272166968};\\\", \\\"{x:1345,y:810,t:1527272166983};\\\", \\\"{x:1345,y:798,t:1527272167000};\\\", \\\"{x:1345,y:787,t:1527272167018};\\\", \\\"{x:1339,y:772,t:1527272167033};\\\", \\\"{x:1335,y:764,t:1527272167050};\\\", \\\"{x:1333,y:759,t:1527272167068};\\\", \\\"{x:1332,y:759,t:1527272167084};\\\", \\\"{x:1332,y:757,t:1527272167101};\\\", \\\"{x:1332,y:756,t:1527272167117};\\\", \\\"{x:1332,y:761,t:1527272167334};\\\", \\\"{x:1327,y:772,t:1527272167351};\\\", \\\"{x:1322,y:784,t:1527272167368};\\\", \\\"{x:1319,y:789,t:1527272167385};\\\", \\\"{x:1316,y:792,t:1527272167401};\\\", \\\"{x:1312,y:795,t:1527272167418};\\\", \\\"{x:1308,y:796,t:1527272167435};\\\", \\\"{x:1300,y:797,t:1527272167451};\\\", \\\"{x:1292,y:797,t:1527272167468};\\\", \\\"{x:1264,y:797,t:1527272167485};\\\", \\\"{x:1254,y:797,t:1527272167501};\\\", \\\"{x:1198,y:797,t:1527272167518};\\\", \\\"{x:1142,y:790,t:1527272167535};\\\", \\\"{x:1085,y:778,t:1527272167551};\\\", \\\"{x:1026,y:770,t:1527272167568};\\\", \\\"{x:974,y:765,t:1527272167585};\\\", \\\"{x:932,y:758,t:1527272167601};\\\", \\\"{x:901,y:756,t:1527272167617};\\\", \\\"{x:864,y:756,t:1527272167635};\\\", \\\"{x:819,y:749,t:1527272167650};\\\", \\\"{x:754,y:737,t:1527272167668};\\\", \\\"{x:637,y:704,t:1527272167685};\\\", \\\"{x:543,y:678,t:1527272167701};\\\", \\\"{x:455,y:653,t:1527272167719};\\\", \\\"{x:393,y:634,t:1527272167735};\\\", \\\"{x:365,y:627,t:1527272167751};\\\", \\\"{x:357,y:623,t:1527272167766};\\\", \\\"{x:357,y:621,t:1527272167828};\\\", \\\"{x:357,y:620,t:1527272167836};\\\", \\\"{x:357,y:618,t:1527272167860};\\\", \\\"{x:357,y:617,t:1527272167884};\\\", \\\"{x:357,y:615,t:1527272167900};\\\", \\\"{x:358,y:614,t:1527272167917};\\\", \\\"{x:363,y:611,t:1527272167934};\\\", \\\"{x:372,y:608,t:1527272167951};\\\", \\\"{x:380,y:605,t:1527272167967};\\\", \\\"{x:390,y:602,t:1527272167984};\\\", \\\"{x:399,y:602,t:1527272168000};\\\", \\\"{x:402,y:602,t:1527272168016};\\\", \\\"{x:402,y:601,t:1527272168077};\\\", \\\"{x:402,y:599,t:1527272168118};\\\", \\\"{x:402,y:595,t:1527272168133};\\\", \\\"{x:402,y:588,t:1527272168152};\\\", \\\"{x:401,y:580,t:1527272168169};\\\", \\\"{x:397,y:569,t:1527272168184};\\\", \\\"{x:392,y:557,t:1527272168202};\\\", \\\"{x:387,y:539,t:1527272168219};\\\", \\\"{x:386,y:523,t:1527272168235};\\\", \\\"{x:385,y:511,t:1527272168252};\\\", \\\"{x:381,y:496,t:1527272168268};\\\", \\\"{x:378,y:488,t:1527272168284};\\\", \\\"{x:377,y:484,t:1527272168301};\\\", \\\"{x:377,y:482,t:1527272168318};\\\", \\\"{x:377,y:479,t:1527272168334};\\\", \\\"{x:377,y:476,t:1527272168351};\\\", \\\"{x:384,y:473,t:1527272168368};\\\", \\\"{x:395,y:471,t:1527272168384};\\\", \\\"{x:413,y:471,t:1527272168402};\\\", \\\"{x:440,y:471,t:1527272168418};\\\", \\\"{x:471,y:471,t:1527272168434};\\\", \\\"{x:519,y:471,t:1527272168451};\\\", \\\"{x:602,y:471,t:1527272168468};\\\", \\\"{x:647,y:471,t:1527272168484};\\\", \\\"{x:684,y:471,t:1527272168502};\\\", \\\"{x:708,y:471,t:1527272168519};\\\", \\\"{x:720,y:471,t:1527272168534};\\\", \\\"{x:724,y:471,t:1527272168552};\\\", \\\"{x:724,y:472,t:1527272168644};\\\", \\\"{x:723,y:475,t:1527272168652};\\\", \\\"{x:718,y:482,t:1527272168668};\\\", \\\"{x:709,y:493,t:1527272168686};\\\", \\\"{x:698,y:502,t:1527272168701};\\\", \\\"{x:687,y:511,t:1527272168718};\\\", \\\"{x:673,y:524,t:1527272168737};\\\", \\\"{x:660,y:535,t:1527272168751};\\\", \\\"{x:651,y:542,t:1527272168768};\\\", \\\"{x:647,y:545,t:1527272168785};\\\", \\\"{x:644,y:548,t:1527272168801};\\\", \\\"{x:641,y:550,t:1527272168818};\\\", \\\"{x:637,y:553,t:1527272168835};\\\", \\\"{x:634,y:556,t:1527272168852};\\\", \\\"{x:628,y:557,t:1527272168868};\\\", \\\"{x:622,y:560,t:1527272168885};\\\", \\\"{x:616,y:561,t:1527272168901};\\\", \\\"{x:608,y:561,t:1527272168918};\\\", \\\"{x:596,y:563,t:1527272168936};\\\", \\\"{x:578,y:564,t:1527272168952};\\\", \\\"{x:554,y:564,t:1527272168968};\\\", \\\"{x:513,y:564,t:1527272168985};\\\", \\\"{x:465,y:564,t:1527272169002};\\\", \\\"{x:401,y:564,t:1527272169018};\\\", \\\"{x:334,y:564,t:1527272169035};\\\", \\\"{x:255,y:566,t:1527272169053};\\\", \\\"{x:225,y:571,t:1527272169068};\\\", \\\"{x:215,y:574,t:1527272169085};\\\", \\\"{x:215,y:575,t:1527272169108};\\\", \\\"{x:215,y:576,t:1527272169118};\\\", \\\"{x:216,y:578,t:1527272169135};\\\", \\\"{x:216,y:579,t:1527272169269};\\\", \\\"{x:216,y:581,t:1527272169285};\\\", \\\"{x:214,y:583,t:1527272169303};\\\", \\\"{x:210,y:585,t:1527272169318};\\\", \\\"{x:207,y:586,t:1527272169335};\\\", \\\"{x:204,y:586,t:1527272169353};\\\", \\\"{x:201,y:586,t:1527272169369};\\\", \\\"{x:199,y:586,t:1527272169396};\\\", \\\"{x:198,y:586,t:1527272169405};\\\", \\\"{x:198,y:585,t:1527272169418};\\\", \\\"{x:194,y:577,t:1527272169435};\\\", \\\"{x:181,y:556,t:1527272169454};\\\", \\\"{x:173,y:543,t:1527272169470};\\\", \\\"{x:165,y:530,t:1527272169485};\\\", \\\"{x:161,y:525,t:1527272169502};\\\", \\\"{x:157,y:521,t:1527272169518};\\\", \\\"{x:157,y:523,t:1527272169821};\\\", \\\"{x:157,y:524,t:1527272169836};\\\", \\\"{x:157,y:526,t:1527272169854};\\\", \\\"{x:157,y:528,t:1527272169869};\\\", \\\"{x:157,y:529,t:1527272169900};\\\", \\\"{x:158,y:529,t:1527272170421};\\\", \\\"{x:175,y:537,t:1527272170437};\\\", \\\"{x:198,y:547,t:1527272170454};\\\", \\\"{x:225,y:560,t:1527272170470};\\\", \\\"{x:249,y:569,t:1527272170487};\\\", \\\"{x:277,y:577,t:1527272170504};\\\", \\\"{x:298,y:583,t:1527272170520};\\\", \\\"{x:322,y:590,t:1527272170536};\\\", \\\"{x:339,y:595,t:1527272170554};\\\", \\\"{x:355,y:599,t:1527272170569};\\\", \\\"{x:364,y:602,t:1527272170587};\\\", \\\"{x:368,y:603,t:1527272170603};\\\", \\\"{x:373,y:604,t:1527272170620};\\\", \\\"{x:374,y:604,t:1527272170636};\\\", \\\"{x:376,y:604,t:1527272170654};\\\", \\\"{x:381,y:604,t:1527272170670};\\\", \\\"{x:385,y:604,t:1527272170686};\\\", \\\"{x:391,y:604,t:1527272170703};\\\", \\\"{x:396,y:604,t:1527272170719};\\\", \\\"{x:401,y:604,t:1527272170736};\\\", \\\"{x:410,y:601,t:1527272170753};\\\", \\\"{x:426,y:594,t:1527272170772};\\\", \\\"{x:446,y:589,t:1527272170787};\\\", \\\"{x:464,y:585,t:1527272170804};\\\", \\\"{x:490,y:579,t:1527272170820};\\\", \\\"{x:504,y:575,t:1527272170838};\\\", \\\"{x:514,y:573,t:1527272170853};\\\", \\\"{x:527,y:569,t:1527272170870};\\\", \\\"{x:542,y:565,t:1527272170886};\\\", \\\"{x:559,y:561,t:1527272170904};\\\", \\\"{x:574,y:559,t:1527272170919};\\\", \\\"{x:586,y:556,t:1527272170936};\\\", \\\"{x:596,y:555,t:1527272170954};\\\", \\\"{x:603,y:554,t:1527272170970};\\\", \\\"{x:607,y:554,t:1527272170986};\\\", \\\"{x:610,y:554,t:1527272171003};\\\", \\\"{x:612,y:554,t:1527272171020};\\\", \\\"{x:613,y:554,t:1527272171052};\\\", \\\"{x:614,y:554,t:1527272171085};\\\", \\\"{x:615,y:554,t:1527272171092};\\\", \\\"{x:616,y:554,t:1527272171103};\\\", \\\"{x:623,y:555,t:1527272171121};\\\", \\\"{x:629,y:556,t:1527272171138};\\\", \\\"{x:634,y:557,t:1527272171153};\\\", \\\"{x:640,y:560,t:1527272171171};\\\", \\\"{x:643,y:562,t:1527272171187};\\\", \\\"{x:646,y:564,t:1527272171204};\\\", \\\"{x:651,y:567,t:1527272171220};\\\", \\\"{x:655,y:569,t:1527272171236};\\\", \\\"{x:657,y:571,t:1527272171253};\\\", \\\"{x:659,y:574,t:1527272171270};\\\", \\\"{x:660,y:575,t:1527272171287};\\\", \\\"{x:660,y:579,t:1527272171304};\\\", \\\"{x:661,y:582,t:1527272171321};\\\", \\\"{x:661,y:588,t:1527272171337};\\\", \\\"{x:660,y:592,t:1527272171354};\\\", \\\"{x:656,y:598,t:1527272171371};\\\", \\\"{x:652,y:602,t:1527272171389};\\\", \\\"{x:649,y:606,t:1527272171403};\\\", \\\"{x:645,y:609,t:1527272171421};\\\", \\\"{x:643,y:611,t:1527272171438};\\\", \\\"{x:642,y:611,t:1527272171453};\\\", \\\"{x:641,y:611,t:1527272171470};\\\", \\\"{x:641,y:612,t:1527272171486};\\\", \\\"{x:641,y:613,t:1527272171564};\\\", \\\"{x:642,y:613,t:1527272171572};\\\", \\\"{x:647,y:612,t:1527272171586};\\\", \\\"{x:667,y:602,t:1527272171603};\\\", \\\"{x:710,y:589,t:1527272171621};\\\", \\\"{x:747,y:578,t:1527272171638};\\\", \\\"{x:775,y:570,t:1527272171654};\\\", \\\"{x:798,y:564,t:1527272171670};\\\", \\\"{x:814,y:559,t:1527272171688};\\\", \\\"{x:820,y:556,t:1527272171705};\\\", \\\"{x:822,y:555,t:1527272171722};\\\", \\\"{x:824,y:554,t:1527272171737};\\\", \\\"{x:824,y:553,t:1527272171820};\\\", \\\"{x:825,y:549,t:1527272171838};\\\", \\\"{x:826,y:546,t:1527272171855};\\\", \\\"{x:828,y:541,t:1527272171870};\\\", \\\"{x:831,y:537,t:1527272171887};\\\", \\\"{x:833,y:533,t:1527272171904};\\\", \\\"{x:834,y:529,t:1527272171921};\\\", \\\"{x:834,y:526,t:1527272171937};\\\", \\\"{x:835,y:524,t:1527272171954};\\\", \\\"{x:836,y:521,t:1527272171972};\\\", \\\"{x:836,y:519,t:1527272171988};\\\", \\\"{x:836,y:517,t:1527272172005};\\\", \\\"{x:836,y:516,t:1527272172021};\\\", \\\"{x:836,y:515,t:1527272172038};\\\", \\\"{x:836,y:514,t:1527272172060};\\\", \\\"{x:836,y:512,t:1527272172076};\\\", \\\"{x:836,y:511,t:1527272172087};\\\", \\\"{x:836,y:510,t:1527272172104};\\\", \\\"{x:836,y:508,t:1527272172122};\\\", \\\"{x:836,y:506,t:1527272172138};\\\", \\\"{x:836,y:505,t:1527272172154};\\\", \\\"{x:831,y:509,t:1527272172412};\\\", \\\"{x:816,y:521,t:1527272172422};\\\", \\\"{x:772,y:557,t:1527272172437};\\\", \\\"{x:709,y:599,t:1527272172454};\\\", \\\"{x:637,y:642,t:1527272172471};\\\", \\\"{x:578,y:676,t:1527272172488};\\\", \\\"{x:551,y:694,t:1527272172504};\\\", \\\"{x:541,y:704,t:1527272172522};\\\", \\\"{x:540,y:712,t:1527272172538};\\\", \\\"{x:540,y:718,t:1527272172555};\\\", \\\"{x:542,y:725,t:1527272172573};\\\", \\\"{x:545,y:732,t:1527272172588};\\\", \\\"{x:545,y:734,t:1527272172605};\\\" ] }, { \\\"rt\\\": 8776, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 598359, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:734,t:1527272175365};\\\", \\\"{x:548,y:725,t:1527272175373};\\\", \\\"{x:552,y:712,t:1527272175389};\\\", \\\"{x:564,y:674,t:1527272175403};\\\", \\\"{x:582,y:610,t:1527272175423};\\\", \\\"{x:587,y:568,t:1527272175440};\\\", \\\"{x:589,y:533,t:1527272175458};\\\", \\\"{x:589,y:506,t:1527272175474};\\\", \\\"{x:583,y:483,t:1527272175490};\\\", \\\"{x:577,y:468,t:1527272175506};\\\", \\\"{x:569,y:456,t:1527272175524};\\\", \\\"{x:564,y:450,t:1527272175540};\\\", \\\"{x:563,y:450,t:1527272175558};\\\", \\\"{x:564,y:450,t:1527272175829};\\\", \\\"{x:566,y:452,t:1527272175841};\\\", \\\"{x:569,y:454,t:1527272175858};\\\", \\\"{x:575,y:458,t:1527272175874};\\\", \\\"{x:579,y:459,t:1527272175891};\\\", \\\"{x:587,y:462,t:1527272175907};\\\", \\\"{x:596,y:463,t:1527272175924};\\\", \\\"{x:608,y:465,t:1527272175940};\\\", \\\"{x:617,y:467,t:1527272175957};\\\", \\\"{x:629,y:468,t:1527272175974};\\\", \\\"{x:643,y:470,t:1527272175991};\\\", \\\"{x:660,y:473,t:1527272176008};\\\", \\\"{x:678,y:475,t:1527272176024};\\\", \\\"{x:702,y:479,t:1527272176041};\\\", \\\"{x:734,y:484,t:1527272176057};\\\", \\\"{x:775,y:494,t:1527272176076};\\\", \\\"{x:835,y:509,t:1527272176091};\\\", \\\"{x:912,y:527,t:1527272176109};\\\", \\\"{x:1048,y:566,t:1527272176125};\\\", \\\"{x:1140,y:598,t:1527272176140};\\\", \\\"{x:1235,y:642,t:1527272176157};\\\", \\\"{x:1326,y:683,t:1527272176174};\\\", \\\"{x:1397,y:725,t:1527272176191};\\\", \\\"{x:1460,y:760,t:1527272176207};\\\", \\\"{x:1507,y:784,t:1527272176224};\\\", \\\"{x:1538,y:803,t:1527272176241};\\\", \\\"{x:1556,y:813,t:1527272176257};\\\", \\\"{x:1566,y:817,t:1527272176275};\\\", \\\"{x:1570,y:820,t:1527272176291};\\\", \\\"{x:1570,y:821,t:1527272176308};\\\", \\\"{x:1565,y:820,t:1527272176398};\\\", \\\"{x:1559,y:819,t:1527272176408};\\\", \\\"{x:1539,y:816,t:1527272176425};\\\", \\\"{x:1516,y:816,t:1527272176442};\\\", \\\"{x:1488,y:816,t:1527272176458};\\\", \\\"{x:1462,y:814,t:1527272176475};\\\", \\\"{x:1443,y:810,t:1527272176492};\\\", \\\"{x:1421,y:810,t:1527272176508};\\\", \\\"{x:1408,y:810,t:1527272176524};\\\", \\\"{x:1406,y:810,t:1527272176542};\\\", \\\"{x:1404,y:810,t:1527272176558};\\\", \\\"{x:1403,y:810,t:1527272176575};\\\", \\\"{x:1401,y:810,t:1527272176592};\\\", \\\"{x:1396,y:810,t:1527272176609};\\\", \\\"{x:1392,y:810,t:1527272176625};\\\", \\\"{x:1387,y:810,t:1527272176641};\\\", \\\"{x:1383,y:810,t:1527272176659};\\\", \\\"{x:1380,y:810,t:1527272176675};\\\", \\\"{x:1377,y:810,t:1527272176691};\\\", \\\"{x:1374,y:810,t:1527272176709};\\\", \\\"{x:1367,y:810,t:1527272176725};\\\", \\\"{x:1356,y:805,t:1527272176742};\\\", \\\"{x:1344,y:800,t:1527272176759};\\\", \\\"{x:1337,y:796,t:1527272176775};\\\", \\\"{x:1331,y:791,t:1527272176792};\\\", \\\"{x:1329,y:789,t:1527272176809};\\\", \\\"{x:1329,y:785,t:1527272176824};\\\", \\\"{x:1328,y:781,t:1527272176842};\\\", \\\"{x:1326,y:773,t:1527272176859};\\\", \\\"{x:1325,y:767,t:1527272176875};\\\", \\\"{x:1325,y:760,t:1527272176892};\\\", \\\"{x:1325,y:747,t:1527272176908};\\\", \\\"{x:1325,y:739,t:1527272176926};\\\", \\\"{x:1325,y:733,t:1527272176941};\\\", \\\"{x:1326,y:728,t:1527272176959};\\\", \\\"{x:1326,y:724,t:1527272176975};\\\", \\\"{x:1326,y:721,t:1527272176991};\\\", \\\"{x:1326,y:718,t:1527272177009};\\\", \\\"{x:1327,y:714,t:1527272177026};\\\", \\\"{x:1328,y:712,t:1527272177042};\\\", \\\"{x:1328,y:711,t:1527272177058};\\\", \\\"{x:1328,y:709,t:1527272177076};\\\", \\\"{x:1329,y:708,t:1527272177092};\\\", \\\"{x:1329,y:706,t:1527272177109};\\\", \\\"{x:1330,y:704,t:1527272177141};\\\", \\\"{x:1330,y:703,t:1527272177164};\\\", \\\"{x:1332,y:702,t:1527272177181};\\\", \\\"{x:1332,y:701,t:1527272177197};\\\", \\\"{x:1333,y:700,t:1527272177212};\\\", \\\"{x:1334,y:700,t:1527272177228};\\\", \\\"{x:1336,y:699,t:1527272177243};\\\", \\\"{x:1336,y:698,t:1527272177259};\\\", \\\"{x:1339,y:698,t:1527272177276};\\\", \\\"{x:1350,y:698,t:1527272177295};\\\", \\\"{x:1368,y:698,t:1527272177309};\\\", \\\"{x:1390,y:698,t:1527272177326};\\\", \\\"{x:1415,y:698,t:1527272177343};\\\", \\\"{x:1439,y:700,t:1527272177359};\\\", \\\"{x:1456,y:702,t:1527272177376};\\\", \\\"{x:1467,y:705,t:1527272177393};\\\", \\\"{x:1472,y:707,t:1527272177409};\\\", \\\"{x:1473,y:707,t:1527272177425};\\\", \\\"{x:1473,y:708,t:1527272177476};\\\", \\\"{x:1472,y:711,t:1527272177492};\\\", \\\"{x:1461,y:717,t:1527272177509};\\\", \\\"{x:1445,y:724,t:1527272177526};\\\", \\\"{x:1421,y:729,t:1527272177543};\\\", \\\"{x:1368,y:741,t:1527272177560};\\\", \\\"{x:1285,y:750,t:1527272177576};\\\", \\\"{x:1179,y:750,t:1527272177593};\\\", \\\"{x:1044,y:749,t:1527272177610};\\\", \\\"{x:883,y:730,t:1527272177626};\\\", \\\"{x:743,y:715,t:1527272177643};\\\", \\\"{x:631,y:709,t:1527272177660};\\\", \\\"{x:539,y:709,t:1527272177676};\\\", \\\"{x:480,y:709,t:1527272177692};\\\", \\\"{x:471,y:709,t:1527272177710};\\\", \\\"{x:469,y:709,t:1527272177726};\\\", \\\"{x:469,y:708,t:1527272177821};\\\", \\\"{x:469,y:706,t:1527272177828};\\\", \\\"{x:469,y:704,t:1527272177843};\\\", \\\"{x:475,y:697,t:1527272177860};\\\", \\\"{x:485,y:685,t:1527272177877};\\\", \\\"{x:490,y:676,t:1527272177893};\\\", \\\"{x:496,y:668,t:1527272177910};\\\", \\\"{x:499,y:661,t:1527272177926};\\\", \\\"{x:504,y:655,t:1527272177942};\\\", \\\"{x:507,y:647,t:1527272177959};\\\", \\\"{x:515,y:636,t:1527272177975};\\\", \\\"{x:526,y:624,t:1527272177992};\\\", \\\"{x:539,y:608,t:1527272178010};\\\", \\\"{x:553,y:596,t:1527272178025};\\\", \\\"{x:565,y:584,t:1527272178043};\\\", \\\"{x:579,y:574,t:1527272178059};\\\", \\\"{x:586,y:568,t:1527272178075};\\\", \\\"{x:592,y:564,t:1527272178092};\\\", \\\"{x:595,y:563,t:1527272178108};\\\", \\\"{x:597,y:562,t:1527272178126};\\\", \\\"{x:598,y:562,t:1527272178142};\\\", \\\"{x:601,y:562,t:1527272178159};\\\", \\\"{x:605,y:561,t:1527272178176};\\\", \\\"{x:610,y:560,t:1527272178193};\\\", \\\"{x:618,y:560,t:1527272178209};\\\", \\\"{x:627,y:559,t:1527272178225};\\\", \\\"{x:641,y:556,t:1527272178243};\\\", \\\"{x:663,y:552,t:1527272178260};\\\", \\\"{x:697,y:543,t:1527272178276};\\\", \\\"{x:761,y:527,t:1527272178294};\\\", \\\"{x:795,y:518,t:1527272178310};\\\", \\\"{x:818,y:511,t:1527272178326};\\\", \\\"{x:832,y:507,t:1527272178342};\\\", \\\"{x:834,y:507,t:1527272178359};\\\", \\\"{x:835,y:506,t:1527272178375};\\\", \\\"{x:836,y:506,t:1527272178396};\\\", \\\"{x:837,y:506,t:1527272178409};\\\", \\\"{x:841,y:506,t:1527272178425};\\\", \\\"{x:849,y:508,t:1527272178442};\\\", \\\"{x:855,y:508,t:1527272178460};\\\", \\\"{x:862,y:511,t:1527272178475};\\\", \\\"{x:866,y:512,t:1527272178492};\\\", \\\"{x:867,y:512,t:1527272178572};\\\", \\\"{x:867,y:513,t:1527272178589};\\\", \\\"{x:867,y:514,t:1527272178609};\\\", \\\"{x:866,y:515,t:1527272178627};\\\", \\\"{x:865,y:515,t:1527272178642};\\\", \\\"{x:863,y:517,t:1527272178659};\\\", \\\"{x:861,y:518,t:1527272178676};\\\", \\\"{x:860,y:518,t:1527272178694};\\\", \\\"{x:860,y:520,t:1527272178709};\\\", \\\"{x:859,y:522,t:1527272178726};\\\", \\\"{x:857,y:524,t:1527272178742};\\\", \\\"{x:856,y:526,t:1527272178760};\\\", \\\"{x:856,y:529,t:1527272178777};\\\", \\\"{x:856,y:532,t:1527272178792};\\\", \\\"{x:856,y:536,t:1527272178809};\\\", \\\"{x:856,y:540,t:1527272178827};\\\", \\\"{x:860,y:547,t:1527272178844};\\\", \\\"{x:868,y:554,t:1527272178860};\\\", \\\"{x:886,y:566,t:1527272178877};\\\", \\\"{x:905,y:572,t:1527272178892};\\\", \\\"{x:930,y:578,t:1527272178910};\\\", \\\"{x:961,y:583,t:1527272178926};\\\", \\\"{x:1005,y:588,t:1527272178944};\\\", \\\"{x:1048,y:596,t:1527272178959};\\\", \\\"{x:1087,y:601,t:1527272178976};\\\", \\\"{x:1119,y:604,t:1527272178992};\\\", \\\"{x:1146,y:609,t:1527272179010};\\\", \\\"{x:1170,y:616,t:1527272179027};\\\", \\\"{x:1194,y:621,t:1527272179043};\\\", \\\"{x:1219,y:629,t:1527272179060};\\\", \\\"{x:1253,y:636,t:1527272179076};\\\", \\\"{x:1272,y:642,t:1527272179092};\\\", \\\"{x:1288,y:647,t:1527272179110};\\\", \\\"{x:1298,y:651,t:1527272179127};\\\", \\\"{x:1306,y:655,t:1527272179142};\\\", \\\"{x:1315,y:662,t:1527272179160};\\\", \\\"{x:1322,y:669,t:1527272179176};\\\", \\\"{x:1329,y:674,t:1527272179193};\\\", \\\"{x:1335,y:683,t:1527272179210};\\\", \\\"{x:1341,y:692,t:1527272179227};\\\", \\\"{x:1344,y:702,t:1527272179243};\\\", \\\"{x:1347,y:711,t:1527272179260};\\\", \\\"{x:1351,y:722,t:1527272179276};\\\", \\\"{x:1351,y:728,t:1527272179293};\\\", \\\"{x:1351,y:731,t:1527272179310};\\\", \\\"{x:1351,y:736,t:1527272179327};\\\", \\\"{x:1351,y:742,t:1527272179342};\\\", \\\"{x:1351,y:750,t:1527272179360};\\\", \\\"{x:1345,y:762,t:1527272179376};\\\", \\\"{x:1338,y:775,t:1527272179393};\\\", \\\"{x:1329,y:787,t:1527272179409};\\\", \\\"{x:1324,y:794,t:1527272179426};\\\", \\\"{x:1320,y:800,t:1527272179443};\\\", \\\"{x:1317,y:803,t:1527272179460};\\\", \\\"{x:1315,y:803,t:1527272179533};\\\", \\\"{x:1312,y:803,t:1527272179544};\\\", \\\"{x:1303,y:799,t:1527272179560};\\\", \\\"{x:1287,y:796,t:1527272179577};\\\", \\\"{x:1269,y:791,t:1527272179593};\\\", \\\"{x:1231,y:780,t:1527272179609};\\\", \\\"{x:1172,y:761,t:1527272179626};\\\", \\\"{x:1090,y:741,t:1527272179643};\\\", \\\"{x:993,y:715,t:1527272179660};\\\", \\\"{x:898,y:696,t:1527272179676};\\\", \\\"{x:784,y:678,t:1527272179693};\\\", \\\"{x:739,y:671,t:1527272179710};\\\", \\\"{x:711,y:666,t:1527272179726};\\\", \\\"{x:693,y:664,t:1527272179743};\\\", \\\"{x:678,y:659,t:1527272179760};\\\", \\\"{x:660,y:651,t:1527272179776};\\\", \\\"{x:621,y:639,t:1527272179793};\\\", \\\"{x:558,y:621,t:1527272179811};\\\", \\\"{x:485,y:600,t:1527272179826};\\\", \\\"{x:433,y:587,t:1527272179843};\\\", \\\"{x:392,y:570,t:1527272179861};\\\", \\\"{x:378,y:564,t:1527272179877};\\\", \\\"{x:371,y:562,t:1527272179894};\\\", \\\"{x:367,y:560,t:1527272179910};\\\", \\\"{x:365,y:558,t:1527272179927};\\\", \\\"{x:361,y:556,t:1527272179943};\\\", \\\"{x:353,y:553,t:1527272179961};\\\", \\\"{x:341,y:548,t:1527272179978};\\\", \\\"{x:327,y:544,t:1527272179993};\\\", \\\"{x:312,y:540,t:1527272180011};\\\", \\\"{x:302,y:539,t:1527272180028};\\\", \\\"{x:299,y:539,t:1527272180044};\\\", \\\"{x:298,y:539,t:1527272180060};\\\", \\\"{x:295,y:540,t:1527272180237};\\\", \\\"{x:295,y:541,t:1527272180245};\\\", \\\"{x:293,y:542,t:1527272180261};\\\", \\\"{x:289,y:543,t:1527272180278};\\\", \\\"{x:281,y:546,t:1527272180294};\\\", \\\"{x:276,y:547,t:1527272180311};\\\", \\\"{x:273,y:549,t:1527272180328};\\\", \\\"{x:267,y:552,t:1527272180346};\\\", \\\"{x:260,y:555,t:1527272180360};\\\", \\\"{x:253,y:556,t:1527272180378};\\\", \\\"{x:250,y:556,t:1527272180395};\\\", \\\"{x:246,y:556,t:1527272180411};\\\", \\\"{x:242,y:556,t:1527272180427};\\\", \\\"{x:228,y:554,t:1527272180444};\\\", \\\"{x:211,y:553,t:1527272180460};\\\", \\\"{x:182,y:548,t:1527272180477};\\\", \\\"{x:159,y:545,t:1527272180495};\\\", \\\"{x:144,y:540,t:1527272180510};\\\", \\\"{x:141,y:538,t:1527272180527};\\\", \\\"{x:143,y:538,t:1527272180909};\\\", \\\"{x:149,y:540,t:1527272180918};\\\", \\\"{x:154,y:543,t:1527272180928};\\\", \\\"{x:171,y:556,t:1527272180945};\\\", \\\"{x:186,y:570,t:1527272180962};\\\", \\\"{x:207,y:587,t:1527272180978};\\\", \\\"{x:231,y:604,t:1527272180995};\\\", \\\"{x:273,y:629,t:1527272181012};\\\", \\\"{x:287,y:639,t:1527272181028};\\\", \\\"{x:342,y:664,t:1527272181045};\\\", \\\"{x:372,y:677,t:1527272181062};\\\", \\\"{x:388,y:683,t:1527272181079};\\\", \\\"{x:389,y:683,t:1527272181095};\\\", \\\"{x:388,y:681,t:1527272181188};\\\", \\\"{x:378,y:676,t:1527272181196};\\\", \\\"{x:371,y:667,t:1527272181213};\\\", \\\"{x:306,y:629,t:1527272181229};\\\", \\\"{x:274,y:613,t:1527272181245};\\\", \\\"{x:241,y:599,t:1527272181262};\\\", \\\"{x:222,y:589,t:1527272181280};\\\", \\\"{x:210,y:584,t:1527272181295};\\\", \\\"{x:204,y:580,t:1527272181311};\\\", \\\"{x:203,y:580,t:1527272181329};\\\", \\\"{x:202,y:579,t:1527272181344};\\\", \\\"{x:200,y:576,t:1527272181361};\\\", \\\"{x:198,y:571,t:1527272181379};\\\", \\\"{x:192,y:565,t:1527272181394};\\\", \\\"{x:188,y:559,t:1527272181413};\\\", \\\"{x:186,y:557,t:1527272181428};\\\", \\\"{x:184,y:555,t:1527272181444};\\\", \\\"{x:184,y:554,t:1527272181461};\\\", \\\"{x:184,y:553,t:1527272181478};\\\", \\\"{x:183,y:551,t:1527272181495};\\\", \\\"{x:181,y:546,t:1527272181512};\\\", \\\"{x:179,y:542,t:1527272181528};\\\", \\\"{x:175,y:535,t:1527272181545};\\\", \\\"{x:173,y:531,t:1527272181562};\\\", \\\"{x:170,y:526,t:1527272181579};\\\", \\\"{x:168,y:524,t:1527272181597};\\\", \\\"{x:168,y:523,t:1527272181901};\\\", \\\"{x:167,y:523,t:1527272181912};\\\", \\\"{x:167,y:524,t:1527272181930};\\\", \\\"{x:166,y:526,t:1527272181948};\\\", \\\"{x:166,y:528,t:1527272181964};\\\", \\\"{x:166,y:529,t:1527272181979};\\\", \\\"{x:166,y:530,t:1527272182020};\\\", \\\"{x:166,y:531,t:1527272182092};\\\", \\\"{x:166,y:532,t:1527272182132};\\\", \\\"{x:167,y:535,t:1527272182364};\\\", \\\"{x:174,y:540,t:1527272182379};\\\", \\\"{x:204,y:564,t:1527272182396};\\\", \\\"{x:242,y:593,t:1527272182412};\\\", \\\"{x:282,y:622,t:1527272182429};\\\", \\\"{x:326,y:648,t:1527272182446};\\\", \\\"{x:364,y:670,t:1527272182463};\\\", \\\"{x:401,y:689,t:1527272182480};\\\", \\\"{x:426,y:697,t:1527272182496};\\\", \\\"{x:437,y:699,t:1527272182513};\\\", \\\"{x:440,y:700,t:1527272182530};\\\", \\\"{x:441,y:701,t:1527272182556};\\\", \\\"{x:443,y:701,t:1527272182692};\\\", \\\"{x:444,y:703,t:1527272182700};\\\", \\\"{x:447,y:707,t:1527272182713};\\\", \\\"{x:450,y:711,t:1527272182729};\\\", \\\"{x:457,y:718,t:1527272182746};\\\", \\\"{x:466,y:727,t:1527272182764};\\\", \\\"{x:473,y:738,t:1527272182780};\\\", \\\"{x:474,y:738,t:1527272182796};\\\", \\\"{x:474,y:739,t:1527272182813};\\\", \\\"{x:475,y:739,t:1527272183301};\\\", \\\"{x:479,y:738,t:1527272183324};\\\", \\\"{x:489,y:732,t:1527272183332};\\\", \\\"{x:495,y:730,t:1527272183347};\\\", \\\"{x:515,y:720,t:1527272183363};\\\", \\\"{x:539,y:711,t:1527272183380};\\\", \\\"{x:573,y:699,t:1527272183396};\\\", \\\"{x:597,y:694,t:1527272183413};\\\", \\\"{x:625,y:690,t:1527272183430};\\\", \\\"{x:656,y:686,t:1527272183447};\\\", \\\"{x:683,y:681,t:1527272183463};\\\", \\\"{x:705,y:679,t:1527272183480};\\\", \\\"{x:720,y:676,t:1527272183497};\\\", \\\"{x:722,y:675,t:1527272183514};\\\", \\\"{x:723,y:674,t:1527272183530};\\\" ] }, { \\\"rt\\\": 29217, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 628817, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:733,y:674,t:1527272187488};\\\", \\\"{x:785,y:674,t:1527272187504};\\\", \\\"{x:868,y:685,t:1527272187519};\\\", \\\"{x:943,y:693,t:1527272187537};\\\", \\\"{x:1021,y:706,t:1527272187554};\\\", \\\"{x:1086,y:720,t:1527272187570};\\\", \\\"{x:1146,y:730,t:1527272187587};\\\", \\\"{x:1195,y:741,t:1527272187604};\\\", \\\"{x:1231,y:746,t:1527272187620};\\\", \\\"{x:1266,y:750,t:1527272187637};\\\", \\\"{x:1297,y:753,t:1527272187654};\\\", \\\"{x:1330,y:758,t:1527272187671};\\\", \\\"{x:1359,y:762,t:1527272187687};\\\", \\\"{x:1400,y:766,t:1527272187704};\\\", \\\"{x:1427,y:768,t:1527272187720};\\\", \\\"{x:1452,y:770,t:1527272187737};\\\", \\\"{x:1471,y:770,t:1527272187754};\\\", \\\"{x:1486,y:770,t:1527272187771};\\\", \\\"{x:1493,y:770,t:1527272187787};\\\", \\\"{x:1494,y:770,t:1527272187804};\\\", \\\"{x:1495,y:770,t:1527272187820};\\\", \\\"{x:1496,y:770,t:1527272187951};\\\", \\\"{x:1496,y:768,t:1527272187959};\\\", \\\"{x:1496,y:767,t:1527272187970};\\\", \\\"{x:1496,y:763,t:1527272187986};\\\", \\\"{x:1495,y:758,t:1527272188003};\\\", \\\"{x:1493,y:756,t:1527272188020};\\\", \\\"{x:1490,y:755,t:1527272188036};\\\", \\\"{x:1489,y:753,t:1527272188053};\\\", \\\"{x:1488,y:753,t:1527272188079};\\\", \\\"{x:1487,y:753,t:1527272188120};\\\", \\\"{x:1487,y:752,t:1527272188368};\\\", \\\"{x:1487,y:751,t:1527272188376};\\\", \\\"{x:1487,y:750,t:1527272188392};\\\", \\\"{x:1488,y:749,t:1527272188403};\\\", \\\"{x:1492,y:743,t:1527272188421};\\\", \\\"{x:1498,y:736,t:1527272188438};\\\", \\\"{x:1505,y:729,t:1527272188453};\\\", \\\"{x:1514,y:721,t:1527272188471};\\\", \\\"{x:1528,y:709,t:1527272188488};\\\", \\\"{x:1533,y:704,t:1527272188504};\\\", \\\"{x:1537,y:701,t:1527272188521};\\\", \\\"{x:1540,y:698,t:1527272188538};\\\", \\\"{x:1542,y:697,t:1527272188554};\\\", \\\"{x:1543,y:696,t:1527272188577};\\\", \\\"{x:1544,y:696,t:1527272188600};\\\", \\\"{x:1545,y:696,t:1527272188616};\\\", \\\"{x:1546,y:696,t:1527272188664};\\\", \\\"{x:1548,y:696,t:1527272188680};\\\", \\\"{x:1550,y:696,t:1527272188697};\\\", \\\"{x:1554,y:696,t:1527272188704};\\\", \\\"{x:1567,y:701,t:1527272188721};\\\", \\\"{x:1583,y:705,t:1527272188738};\\\", \\\"{x:1601,y:708,t:1527272188755};\\\", \\\"{x:1620,y:710,t:1527272188771};\\\", \\\"{x:1634,y:710,t:1527272188788};\\\", \\\"{x:1640,y:710,t:1527272188805};\\\", \\\"{x:1639,y:710,t:1527272188984};\\\", \\\"{x:1637,y:710,t:1527272188992};\\\", \\\"{x:1636,y:709,t:1527272189008};\\\", \\\"{x:1633,y:708,t:1527272189021};\\\", \\\"{x:1632,y:708,t:1527272189056};\\\", \\\"{x:1630,y:708,t:1527272190055};\\\", \\\"{x:1625,y:708,t:1527272190071};\\\", \\\"{x:1617,y:704,t:1527272190088};\\\", \\\"{x:1609,y:701,t:1527272190105};\\\", \\\"{x:1605,y:699,t:1527272190121};\\\", \\\"{x:1604,y:699,t:1527272190138};\\\", \\\"{x:1605,y:699,t:1527272192048};\\\", \\\"{x:1607,y:699,t:1527272192057};\\\", \\\"{x:1609,y:699,t:1527272192074};\\\", \\\"{x:1609,y:700,t:1527272192107};\\\", \\\"{x:1609,y:703,t:1527272192878};\\\", \\\"{x:1609,y:708,t:1527272192890};\\\", \\\"{x:1609,y:718,t:1527272192908};\\\", \\\"{x:1609,y:730,t:1527272192923};\\\", \\\"{x:1607,y:743,t:1527272192940};\\\", \\\"{x:1605,y:754,t:1527272192957};\\\", \\\"{x:1604,y:761,t:1527272192973};\\\", \\\"{x:1603,y:769,t:1527272192991};\\\", \\\"{x:1602,y:780,t:1527272193007};\\\", \\\"{x:1602,y:790,t:1527272193023};\\\", \\\"{x:1602,y:800,t:1527272193041};\\\", \\\"{x:1602,y:812,t:1527272193058};\\\", \\\"{x:1602,y:822,t:1527272193073};\\\", \\\"{x:1602,y:834,t:1527272193091};\\\", \\\"{x:1601,y:844,t:1527272193108};\\\", \\\"{x:1601,y:854,t:1527272193124};\\\", \\\"{x:1601,y:864,t:1527272193140};\\\", \\\"{x:1601,y:872,t:1527272193157};\\\", \\\"{x:1601,y:882,t:1527272193174};\\\", \\\"{x:1601,y:889,t:1527272193191};\\\", \\\"{x:1601,y:901,t:1527272193208};\\\", \\\"{x:1601,y:908,t:1527272193223};\\\", \\\"{x:1601,y:911,t:1527272193241};\\\", \\\"{x:1601,y:915,t:1527272193257};\\\", \\\"{x:1601,y:916,t:1527272193274};\\\", \\\"{x:1601,y:918,t:1527272193291};\\\", \\\"{x:1601,y:919,t:1527272193308};\\\", \\\"{x:1601,y:920,t:1527272193336};\\\", \\\"{x:1601,y:921,t:1527272193592};\\\", \\\"{x:1601,y:923,t:1527272193608};\\\", \\\"{x:1601,y:927,t:1527272193625};\\\", \\\"{x:1601,y:929,t:1527272193642};\\\", \\\"{x:1601,y:932,t:1527272193659};\\\", \\\"{x:1602,y:936,t:1527272193674};\\\", \\\"{x:1603,y:938,t:1527272193690};\\\", \\\"{x:1603,y:940,t:1527272193708};\\\", \\\"{x:1603,y:942,t:1527272193724};\\\", \\\"{x:1605,y:946,t:1527272193740};\\\", \\\"{x:1605,y:949,t:1527272193757};\\\", \\\"{x:1605,y:952,t:1527272193775};\\\", \\\"{x:1605,y:954,t:1527272193790};\\\", \\\"{x:1606,y:955,t:1527272193808};\\\", \\\"{x:1606,y:954,t:1527272194111};\\\", \\\"{x:1606,y:952,t:1527272194124};\\\", \\\"{x:1606,y:950,t:1527272194142};\\\", \\\"{x:1606,y:948,t:1527272194157};\\\", \\\"{x:1606,y:947,t:1527272194175};\\\", \\\"{x:1607,y:945,t:1527272194191};\\\", \\\"{x:1608,y:944,t:1527272194208};\\\", \\\"{x:1608,y:943,t:1527272194231};\\\", \\\"{x:1608,y:942,t:1527272194263};\\\", \\\"{x:1608,y:941,t:1527272194295};\\\", \\\"{x:1608,y:940,t:1527272194424};\\\", \\\"{x:1608,y:939,t:1527272194456};\\\", \\\"{x:1608,y:938,t:1527272194472};\\\", \\\"{x:1608,y:937,t:1527272194479};\\\", \\\"{x:1608,y:936,t:1527272194504};\\\", \\\"{x:1608,y:935,t:1527272194528};\\\", \\\"{x:1608,y:934,t:1527272194542};\\\", \\\"{x:1608,y:933,t:1527272194559};\\\", \\\"{x:1608,y:931,t:1527272194575};\\\", \\\"{x:1608,y:928,t:1527272194592};\\\", \\\"{x:1608,y:926,t:1527272194609};\\\", \\\"{x:1608,y:920,t:1527272194625};\\\", \\\"{x:1604,y:910,t:1527272194642};\\\", \\\"{x:1602,y:894,t:1527272194661};\\\", \\\"{x:1597,y:878,t:1527272194675};\\\", \\\"{x:1594,y:868,t:1527272194692};\\\", \\\"{x:1591,y:858,t:1527272194709};\\\", \\\"{x:1590,y:852,t:1527272194726};\\\", \\\"{x:1590,y:845,t:1527272194742};\\\", \\\"{x:1590,y:834,t:1527272194760};\\\", \\\"{x:1590,y:822,t:1527272194776};\\\", \\\"{x:1591,y:801,t:1527272194792};\\\", \\\"{x:1595,y:788,t:1527272194809};\\\", \\\"{x:1597,y:775,t:1527272194826};\\\", \\\"{x:1598,y:766,t:1527272194842};\\\", \\\"{x:1599,y:759,t:1527272194861};\\\", \\\"{x:1600,y:749,t:1527272194876};\\\", \\\"{x:1601,y:739,t:1527272194892};\\\", \\\"{x:1604,y:730,t:1527272194909};\\\", \\\"{x:1604,y:724,t:1527272194927};\\\", \\\"{x:1605,y:718,t:1527272194942};\\\", \\\"{x:1605,y:712,t:1527272194960};\\\", \\\"{x:1605,y:710,t:1527272194975};\\\", \\\"{x:1605,y:709,t:1527272194992};\\\", \\\"{x:1606,y:709,t:1527272195010};\\\", \\\"{x:1606,y:708,t:1527272195240};\\\", \\\"{x:1606,y:707,t:1527272195248};\\\", \\\"{x:1606,y:706,t:1527272195260};\\\", \\\"{x:1606,y:705,t:1527272195276};\\\", \\\"{x:1607,y:703,t:1527272195293};\\\", \\\"{x:1607,y:702,t:1527272195328};\\\", \\\"{x:1608,y:710,t:1527272195593};\\\", \\\"{x:1613,y:739,t:1527272195610};\\\", \\\"{x:1616,y:765,t:1527272195626};\\\", \\\"{x:1620,y:791,t:1527272195643};\\\", \\\"{x:1622,y:816,t:1527272195661};\\\", \\\"{x:1626,y:838,t:1527272195676};\\\", \\\"{x:1630,y:859,t:1527272195693};\\\", \\\"{x:1635,y:879,t:1527272195709};\\\", \\\"{x:1636,y:894,t:1527272195727};\\\", \\\"{x:1638,y:905,t:1527272195743};\\\", \\\"{x:1638,y:918,t:1527272195759};\\\", \\\"{x:1641,y:938,t:1527272195776};\\\", \\\"{x:1641,y:947,t:1527272195793};\\\", \\\"{x:1641,y:956,t:1527272195810};\\\", \\\"{x:1641,y:964,t:1527272195826};\\\", \\\"{x:1641,y:973,t:1527272195844};\\\", \\\"{x:1641,y:980,t:1527272195860};\\\", \\\"{x:1641,y:985,t:1527272195875};\\\", \\\"{x:1642,y:989,t:1527272195892};\\\", \\\"{x:1643,y:993,t:1527272195910};\\\", \\\"{x:1643,y:996,t:1527272195926};\\\", \\\"{x:1644,y:998,t:1527272195942};\\\", \\\"{x:1645,y:1000,t:1527272195958};\\\", \\\"{x:1645,y:1001,t:1527272195976};\\\", \\\"{x:1645,y:1002,t:1527272195992};\\\", \\\"{x:1645,y:1004,t:1527272196009};\\\", \\\"{x:1645,y:1003,t:1527272196392};\\\", \\\"{x:1645,y:994,t:1527272196410};\\\", \\\"{x:1645,y:983,t:1527272196427};\\\", \\\"{x:1645,y:972,t:1527272196444};\\\", \\\"{x:1645,y:960,t:1527272196459};\\\", \\\"{x:1642,y:940,t:1527272196477};\\\", \\\"{x:1639,y:916,t:1527272196492};\\\", \\\"{x:1636,y:891,t:1527272196509};\\\", \\\"{x:1631,y:870,t:1527272196527};\\\", \\\"{x:1627,y:850,t:1527272196542};\\\", \\\"{x:1625,y:829,t:1527272196560};\\\", \\\"{x:1623,y:815,t:1527272196577};\\\", \\\"{x:1623,y:802,t:1527272196592};\\\", \\\"{x:1621,y:790,t:1527272196610};\\\", \\\"{x:1618,y:777,t:1527272196626};\\\", \\\"{x:1617,y:766,t:1527272196643};\\\", \\\"{x:1616,y:757,t:1527272196659};\\\", \\\"{x:1615,y:753,t:1527272196677};\\\", \\\"{x:1614,y:748,t:1527272196693};\\\", \\\"{x:1614,y:746,t:1527272196710};\\\", \\\"{x:1614,y:744,t:1527272196727};\\\", \\\"{x:1614,y:743,t:1527272196752};\\\", \\\"{x:1613,y:742,t:1527272196760};\\\", \\\"{x:1613,y:741,t:1527272196776};\\\", \\\"{x:1613,y:740,t:1527272196800};\\\", \\\"{x:1613,y:737,t:1527272196810};\\\", \\\"{x:1612,y:735,t:1527272196827};\\\", \\\"{x:1612,y:731,t:1527272196844};\\\", \\\"{x:1612,y:729,t:1527272196860};\\\", \\\"{x:1612,y:724,t:1527272196877};\\\", \\\"{x:1610,y:721,t:1527272196894};\\\", \\\"{x:1610,y:717,t:1527272196910};\\\", \\\"{x:1610,y:716,t:1527272196927};\\\", \\\"{x:1610,y:714,t:1527272196944};\\\", \\\"{x:1609,y:712,t:1527272196961};\\\", \\\"{x:1609,y:711,t:1527272196977};\\\", \\\"{x:1609,y:710,t:1527272196994};\\\", \\\"{x:1609,y:709,t:1527272197011};\\\", \\\"{x:1609,y:707,t:1527272197027};\\\", \\\"{x:1609,y:706,t:1527272197063};\\\", \\\"{x:1608,y:706,t:1527272200241};\\\", \\\"{x:1606,y:708,t:1527272200248};\\\", \\\"{x:1603,y:710,t:1527272200264};\\\", \\\"{x:1602,y:711,t:1527272200280};\\\", \\\"{x:1601,y:712,t:1527272200296};\\\", \\\"{x:1600,y:712,t:1527272200314};\\\", \\\"{x:1600,y:713,t:1527272200601};\\\", \\\"{x:1599,y:713,t:1527272200614};\\\", \\\"{x:1596,y:715,t:1527272200630};\\\", \\\"{x:1596,y:716,t:1527272200646};\\\", \\\"{x:1594,y:718,t:1527272200663};\\\", \\\"{x:1592,y:720,t:1527272200680};\\\", \\\"{x:1590,y:721,t:1527272200696};\\\", \\\"{x:1589,y:722,t:1527272200713};\\\", \\\"{x:1588,y:722,t:1527272200872};\\\", \\\"{x:1587,y:722,t:1527272200944};\\\", \\\"{x:1586,y:723,t:1527272200960};\\\", \\\"{x:1586,y:724,t:1527272200984};\\\", \\\"{x:1585,y:724,t:1527272200996};\\\", \\\"{x:1584,y:725,t:1527272201024};\\\", \\\"{x:1584,y:726,t:1527272201048};\\\", \\\"{x:1582,y:726,t:1527272201064};\\\", \\\"{x:1581,y:727,t:1527272201087};\\\", \\\"{x:1580,y:728,t:1527272201104};\\\", \\\"{x:1578,y:728,t:1527272201128};\\\", \\\"{x:1578,y:730,t:1527272201143};\\\", \\\"{x:1577,y:730,t:1527272201176};\\\", \\\"{x:1577,y:731,t:1527272201184};\\\", \\\"{x:1576,y:732,t:1527272201207};\\\", \\\"{x:1575,y:732,t:1527272201216};\\\", \\\"{x:1575,y:733,t:1527272201232};\\\", \\\"{x:1574,y:734,t:1527272201248};\\\", \\\"{x:1573,y:736,t:1527272201264};\\\", \\\"{x:1570,y:739,t:1527272201280};\\\", \\\"{x:1567,y:742,t:1527272201297};\\\", \\\"{x:1565,y:743,t:1527272201312};\\\", \\\"{x:1565,y:744,t:1527272201330};\\\", \\\"{x:1564,y:745,t:1527272201347};\\\", \\\"{x:1564,y:746,t:1527272201367};\\\", \\\"{x:1563,y:746,t:1527272201391};\\\", \\\"{x:1562,y:747,t:1527272201399};\\\", \\\"{x:1561,y:748,t:1527272201415};\\\", \\\"{x:1561,y:749,t:1527272201431};\\\", \\\"{x:1559,y:750,t:1527272201448};\\\", \\\"{x:1558,y:752,t:1527272201463};\\\", \\\"{x:1557,y:753,t:1527272201488};\\\", \\\"{x:1557,y:754,t:1527272201497};\\\", \\\"{x:1556,y:754,t:1527272201513};\\\", \\\"{x:1556,y:755,t:1527272201530};\\\", \\\"{x:1555,y:755,t:1527272201547};\\\", \\\"{x:1554,y:756,t:1527272201563};\\\", \\\"{x:1553,y:757,t:1527272201580};\\\", \\\"{x:1552,y:758,t:1527272201599};\\\", \\\"{x:1551,y:758,t:1527272201615};\\\", \\\"{x:1551,y:759,t:1527272201631};\\\", \\\"{x:1550,y:759,t:1527272201648};\\\", \\\"{x:1550,y:760,t:1527272201665};\\\", \\\"{x:1549,y:760,t:1527272201681};\\\", \\\"{x:1549,y:761,t:1527272201697};\\\", \\\"{x:1548,y:761,t:1527272201714};\\\", \\\"{x:1547,y:762,t:1527272201730};\\\", \\\"{x:1546,y:763,t:1527272201748};\\\", \\\"{x:1545,y:763,t:1527272201767};\\\", \\\"{x:1545,y:764,t:1527272201817};\\\", \\\"{x:1544,y:764,t:1527272201849};\\\", \\\"{x:1543,y:765,t:1527272201937};\\\", \\\"{x:1542,y:766,t:1527272202072};\\\", \\\"{x:1541,y:766,t:1527272202136};\\\", \\\"{x:1541,y:767,t:1527272202152};\\\", \\\"{x:1540,y:767,t:1527272202176};\\\", \\\"{x:1539,y:767,t:1527272202184};\\\", \\\"{x:1538,y:767,t:1527272202200};\\\", \\\"{x:1537,y:767,t:1527272202216};\\\", \\\"{x:1537,y:768,t:1527272202231};\\\", \\\"{x:1535,y:768,t:1527272202248};\\\", \\\"{x:1534,y:769,t:1527272202270};\\\", \\\"{x:1534,y:770,t:1527272202287};\\\", \\\"{x:1533,y:770,t:1527272202327};\\\", \\\"{x:1532,y:770,t:1527272202375};\\\", \\\"{x:1531,y:771,t:1527272202383};\\\", \\\"{x:1530,y:771,t:1527272202448};\\\", \\\"{x:1530,y:776,t:1527272203976};\\\", \\\"{x:1530,y:785,t:1527272203984};\\\", \\\"{x:1540,y:818,t:1527272203999};\\\", \\\"{x:1561,y:868,t:1527272204016};\\\", \\\"{x:1590,y:936,t:1527272204032};\\\", \\\"{x:1616,y:1000,t:1527272204049};\\\", \\\"{x:1637,y:1040,t:1527272204065};\\\", \\\"{x:1651,y:1068,t:1527272204082};\\\", \\\"{x:1662,y:1088,t:1527272204099};\\\", \\\"{x:1669,y:1100,t:1527272204115};\\\", \\\"{x:1671,y:1106,t:1527272204132};\\\", \\\"{x:1674,y:1110,t:1527272204149};\\\", \\\"{x:1674,y:1112,t:1527272204165};\\\", \\\"{x:1674,y:1111,t:1527272204280};\\\", \\\"{x:1673,y:1103,t:1527272204286};\\\", \\\"{x:1667,y:1093,t:1527272204299};\\\", \\\"{x:1650,y:1068,t:1527272204315};\\\", \\\"{x:1633,y:1046,t:1527272204332};\\\", \\\"{x:1614,y:1029,t:1527272204349};\\\", \\\"{x:1601,y:1014,t:1527272204365};\\\", \\\"{x:1593,y:1006,t:1527272204382};\\\", \\\"{x:1590,y:1002,t:1527272204399};\\\", \\\"{x:1590,y:1001,t:1527272204416};\\\", \\\"{x:1590,y:1000,t:1527272204432};\\\", \\\"{x:1590,y:998,t:1527272204449};\\\", \\\"{x:1590,y:996,t:1527272204466};\\\", \\\"{x:1590,y:995,t:1527272204482};\\\", \\\"{x:1590,y:993,t:1527272204511};\\\", \\\"{x:1592,y:992,t:1527272204528};\\\", \\\"{x:1593,y:991,t:1527272204535};\\\", \\\"{x:1595,y:991,t:1527272204549};\\\", \\\"{x:1598,y:990,t:1527272204566};\\\", \\\"{x:1601,y:988,t:1527272204582};\\\", \\\"{x:1604,y:988,t:1527272204599};\\\", \\\"{x:1601,y:988,t:1527272204751};\\\", \\\"{x:1597,y:987,t:1527272204767};\\\", \\\"{x:1585,y:987,t:1527272204782};\\\", \\\"{x:1561,y:987,t:1527272204799};\\\", \\\"{x:1545,y:987,t:1527272204816};\\\", \\\"{x:1529,y:989,t:1527272204832};\\\", \\\"{x:1515,y:991,t:1527272204849};\\\", \\\"{x:1502,y:995,t:1527272204866};\\\", \\\"{x:1496,y:996,t:1527272204882};\\\", \\\"{x:1489,y:998,t:1527272204899};\\\", \\\"{x:1480,y:999,t:1527272204916};\\\", \\\"{x:1474,y:999,t:1527272204933};\\\", \\\"{x:1468,y:999,t:1527272204949};\\\", \\\"{x:1464,y:999,t:1527272204965};\\\", \\\"{x:1461,y:999,t:1527272204982};\\\", \\\"{x:1459,y:999,t:1527272204998};\\\", \\\"{x:1458,y:999,t:1527272205016};\\\", \\\"{x:1453,y:999,t:1527272205032};\\\", \\\"{x:1444,y:998,t:1527272205048};\\\", \\\"{x:1434,y:997,t:1527272205065};\\\", \\\"{x:1423,y:996,t:1527272205083};\\\", \\\"{x:1413,y:992,t:1527272205098};\\\", \\\"{x:1404,y:990,t:1527272205116};\\\", \\\"{x:1394,y:987,t:1527272205132};\\\", \\\"{x:1389,y:985,t:1527272205149};\\\", \\\"{x:1381,y:985,t:1527272205166};\\\", \\\"{x:1369,y:983,t:1527272205183};\\\", \\\"{x:1359,y:981,t:1527272205199};\\\", \\\"{x:1352,y:980,t:1527272205216};\\\", \\\"{x:1348,y:980,t:1527272205233};\\\", \\\"{x:1346,y:979,t:1527272206032};\\\", \\\"{x:1345,y:977,t:1527272206051};\\\", \\\"{x:1345,y:974,t:1527272206067};\\\", \\\"{x:1343,y:972,t:1527272206083};\\\", \\\"{x:1343,y:971,t:1527272206104};\\\", \\\"{x:1343,y:970,t:1527272206120};\\\", \\\"{x:1343,y:969,t:1527272206160};\\\", \\\"{x:1343,y:968,t:1527272206169};\\\", \\\"{x:1343,y:967,t:1527272207136};\\\", \\\"{x:1343,y:963,t:1527272207152};\\\", \\\"{x:1343,y:960,t:1527272207168};\\\", \\\"{x:1343,y:958,t:1527272207184};\\\", \\\"{x:1343,y:954,t:1527272207202};\\\", \\\"{x:1344,y:947,t:1527272207218};\\\", \\\"{x:1344,y:937,t:1527272207234};\\\", \\\"{x:1347,y:918,t:1527272207252};\\\", \\\"{x:1351,y:891,t:1527272207267};\\\", \\\"{x:1361,y:860,t:1527272207284};\\\", \\\"{x:1370,y:821,t:1527272207302};\\\", \\\"{x:1377,y:791,t:1527272207319};\\\", \\\"{x:1381,y:766,t:1527272207335};\\\", \\\"{x:1385,y:738,t:1527272207352};\\\", \\\"{x:1385,y:723,t:1527272207368};\\\", \\\"{x:1385,y:709,t:1527272207385};\\\", \\\"{x:1385,y:701,t:1527272207401};\\\", \\\"{x:1385,y:695,t:1527272207419};\\\", \\\"{x:1385,y:691,t:1527272207435};\\\", \\\"{x:1385,y:689,t:1527272207452};\\\", \\\"{x:1385,y:688,t:1527272207472};\\\", \\\"{x:1384,y:688,t:1527272207504};\\\", \\\"{x:1382,y:687,t:1527272207520};\\\", \\\"{x:1381,y:686,t:1527272207535};\\\", \\\"{x:1377,y:685,t:1527272207552};\\\", \\\"{x:1372,y:685,t:1527272207568};\\\", \\\"{x:1369,y:685,t:1527272207585};\\\", \\\"{x:1364,y:686,t:1527272207602};\\\", \\\"{x:1361,y:689,t:1527272207619};\\\", \\\"{x:1359,y:691,t:1527272207635};\\\", \\\"{x:1357,y:692,t:1527272207652};\\\", \\\"{x:1356,y:692,t:1527272207669};\\\", \\\"{x:1355,y:694,t:1527272207684};\\\", \\\"{x:1354,y:695,t:1527272207701};\\\", \\\"{x:1354,y:697,t:1527272210168};\\\", \\\"{x:1353,y:697,t:1527272210233};\\\", \\\"{x:1351,y:697,t:1527272210254};\\\", \\\"{x:1350,y:697,t:1527272210936};\\\", \\\"{x:1348,y:697,t:1527272211111};\\\", \\\"{x:1347,y:697,t:1527272211159};\\\", \\\"{x:1345,y:697,t:1527272211192};\\\", \\\"{x:1344,y:697,t:1527272211215};\\\", \\\"{x:1342,y:697,t:1527272211224};\\\", \\\"{x:1341,y:697,t:1527272211239};\\\", \\\"{x:1334,y:697,t:1527272211255};\\\", \\\"{x:1323,y:695,t:1527272211271};\\\", \\\"{x:1290,y:691,t:1527272211287};\\\", \\\"{x:1248,y:684,t:1527272211305};\\\", \\\"{x:1190,y:676,t:1527272211321};\\\", \\\"{x:1109,y:665,t:1527272211338};\\\", \\\"{x:1022,y:648,t:1527272211355};\\\", \\\"{x:952,y:637,t:1527272211371};\\\", \\\"{x:907,y:630,t:1527272211389};\\\", \\\"{x:889,y:628,t:1527272211404};\\\", \\\"{x:878,y:627,t:1527272211419};\\\", \\\"{x:874,y:627,t:1527272211439};\\\", \\\"{x:873,y:626,t:1527272211455};\\\", \\\"{x:871,y:626,t:1527272211473};\\\", \\\"{x:857,y:623,t:1527272211490};\\\", \\\"{x:834,y:621,t:1527272211506};\\\", \\\"{x:805,y:616,t:1527272211523};\\\", \\\"{x:780,y:612,t:1527272211539};\\\", \\\"{x:760,y:610,t:1527272211556};\\\", \\\"{x:745,y:604,t:1527272211572};\\\", \\\"{x:729,y:600,t:1527272211590};\\\", \\\"{x:713,y:595,t:1527272211606};\\\", \\\"{x:697,y:590,t:1527272211623};\\\", \\\"{x:665,y:582,t:1527272211639};\\\", \\\"{x:641,y:574,t:1527272211656};\\\", \\\"{x:618,y:567,t:1527272211673};\\\", \\\"{x:596,y:557,t:1527272211690};\\\", \\\"{x:582,y:550,t:1527272211707};\\\", \\\"{x:576,y:545,t:1527272211723};\\\", \\\"{x:573,y:543,t:1527272211739};\\\", \\\"{x:573,y:542,t:1527272211758};\\\", \\\"{x:573,y:540,t:1527272211773};\\\", \\\"{x:573,y:538,t:1527272211789};\\\", \\\"{x:575,y:535,t:1527272211806};\\\", \\\"{x:581,y:532,t:1527272211823};\\\", \\\"{x:585,y:529,t:1527272211840};\\\", \\\"{x:589,y:527,t:1527272211857};\\\", \\\"{x:592,y:526,t:1527272211873};\\\", \\\"{x:596,y:524,t:1527272211890};\\\", \\\"{x:598,y:524,t:1527272211906};\\\", \\\"{x:600,y:523,t:1527272211923};\\\", \\\"{x:601,y:522,t:1527272211940};\\\", \\\"{x:603,y:521,t:1527272211956};\\\", \\\"{x:604,y:521,t:1527272211974};\\\", \\\"{x:608,y:518,t:1527272211991};\\\", \\\"{x:612,y:517,t:1527272212008};\\\", \\\"{x:633,y:517,t:1527272212023};\\\", \\\"{x:666,y:517,t:1527272212040};\\\", \\\"{x:705,y:517,t:1527272212056};\\\", \\\"{x:761,y:517,t:1527272212074};\\\", \\\"{x:802,y:514,t:1527272212090};\\\", \\\"{x:834,y:510,t:1527272212106};\\\", \\\"{x:855,y:507,t:1527272212123};\\\", \\\"{x:864,y:505,t:1527272212140};\\\", \\\"{x:863,y:505,t:1527272212271};\\\", \\\"{x:862,y:505,t:1527272212279};\\\", \\\"{x:861,y:505,t:1527272212290};\\\", \\\"{x:852,y:505,t:1527272212307};\\\", \\\"{x:844,y:505,t:1527272212324};\\\", \\\"{x:840,y:505,t:1527272212341};\\\", \\\"{x:839,y:505,t:1527272212357};\\\", \\\"{x:838,y:507,t:1527272212679};\\\", \\\"{x:826,y:514,t:1527272212690};\\\", \\\"{x:786,y:544,t:1527272212708};\\\", \\\"{x:732,y:574,t:1527272212724};\\\", \\\"{x:677,y:607,t:1527272212741};\\\", \\\"{x:647,y:625,t:1527272212757};\\\", \\\"{x:634,y:636,t:1527272212773};\\\", \\\"{x:633,y:643,t:1527272212790};\\\", \\\"{x:633,y:652,t:1527272212806};\\\", \\\"{x:633,y:657,t:1527272212823};\\\", \\\"{x:633,y:663,t:1527272212840};\\\", \\\"{x:633,y:667,t:1527272212857};\\\", \\\"{x:631,y:671,t:1527272212873};\\\", \\\"{x:629,y:674,t:1527272212891};\\\", \\\"{x:627,y:676,t:1527272212907};\\\", \\\"{x:624,y:678,t:1527272212923};\\\", \\\"{x:621,y:681,t:1527272212940};\\\", \\\"{x:616,y:685,t:1527272212957};\\\", \\\"{x:608,y:689,t:1527272212974};\\\", \\\"{x:600,y:692,t:1527272212990};\\\", \\\"{x:592,y:697,t:1527272213007};\\\", \\\"{x:586,y:700,t:1527272213024};\\\", \\\"{x:581,y:703,t:1527272213040};\\\", \\\"{x:577,y:705,t:1527272213057};\\\", \\\"{x:572,y:708,t:1527272213074};\\\", \\\"{x:565,y:715,t:1527272213091};\\\", \\\"{x:559,y:720,t:1527272213109};\\\", \\\"{x:553,y:726,t:1527272213124};\\\", \\\"{x:545,y:735,t:1527272213140};\\\", \\\"{x:539,y:742,t:1527272213157};\\\", \\\"{x:537,y:747,t:1527272213173};\\\", \\\"{x:537,y:749,t:1527272213208};\\\", \\\"{x:535,y:749,t:1527272213504};\\\", \\\"{x:535,y:746,t:1527272213524};\\\", \\\"{x:535,y:743,t:1527272213541};\\\", \\\"{x:535,y:741,t:1527272213557};\\\", \\\"{x:535,y:740,t:1527272213574};\\\", \\\"{x:535,y:738,t:1527272213855};\\\", \\\"{x:535,y:737,t:1527272213864};\\\", \\\"{x:535,y:735,t:1527272213880};\\\", \\\"{x:535,y:733,t:1527272213891};\\\", \\\"{x:536,y:728,t:1527272213907};\\\", \\\"{x:543,y:720,t:1527272213925};\\\", \\\"{x:554,y:708,t:1527272213941};\\\", \\\"{x:571,y:694,t:1527272213958};\\\", \\\"{x:593,y:679,t:1527272213975};\\\", \\\"{x:621,y:657,t:1527272213991};\\\", \\\"{x:636,y:645,t:1527272214008};\\\", \\\"{x:646,y:637,t:1527272214025};\\\", \\\"{x:652,y:629,t:1527272214042};\\\", \\\"{x:656,y:624,t:1527272214058};\\\", \\\"{x:658,y:622,t:1527272214075};\\\", \\\"{x:659,y:621,t:1527272214092};\\\", \\\"{x:659,y:620,t:1527272214108};\\\" ] }, { \\\"rt\\\": 30602, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 660685, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -O -M -M -M -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:664,y:620,t:1527272216711};\\\", \\\"{x:670,y:620,t:1527272216719};\\\", \\\"{x:683,y:622,t:1527272216732};\\\", \\\"{x:724,y:635,t:1527272216750};\\\", \\\"{x:796,y:655,t:1527272216765};\\\", \\\"{x:866,y:678,t:1527272216776};\\\", \\\"{x:946,y:697,t:1527272216794};\\\", \\\"{x:1015,y:714,t:1527272216810};\\\", \\\"{x:1083,y:726,t:1527272216826};\\\", \\\"{x:1144,y:735,t:1527272216843};\\\", \\\"{x:1200,y:743,t:1527272216861};\\\", \\\"{x:1244,y:749,t:1527272216876};\\\", \\\"{x:1281,y:754,t:1527272216893};\\\", \\\"{x:1311,y:757,t:1527272216911};\\\", \\\"{x:1348,y:761,t:1527272216928};\\\", \\\"{x:1373,y:762,t:1527272216944};\\\", \\\"{x:1402,y:766,t:1527272216961};\\\", \\\"{x:1429,y:771,t:1527272216978};\\\", \\\"{x:1475,y:778,t:1527272216994};\\\", \\\"{x:1531,y:778,t:1527272217010};\\\", \\\"{x:1585,y:780,t:1527272217028};\\\", \\\"{x:1638,y:780,t:1527272217044};\\\", \\\"{x:1683,y:780,t:1527272217061};\\\", \\\"{x:1710,y:780,t:1527272217078};\\\", \\\"{x:1722,y:780,t:1527272217094};\\\", \\\"{x:1724,y:780,t:1527272217110};\\\", \\\"{x:1725,y:780,t:1527272217127};\\\", \\\"{x:1725,y:779,t:1527272217218};\\\", \\\"{x:1724,y:778,t:1527272217227};\\\", \\\"{x:1718,y:776,t:1527272217243};\\\", \\\"{x:1712,y:774,t:1527272217261};\\\", \\\"{x:1707,y:771,t:1527272217277};\\\", \\\"{x:1705,y:771,t:1527272217294};\\\", \\\"{x:1702,y:769,t:1527272217310};\\\", \\\"{x:1700,y:768,t:1527272217327};\\\", \\\"{x:1698,y:768,t:1527272217344};\\\", \\\"{x:1696,y:767,t:1527272217374};\\\", \\\"{x:1695,y:767,t:1527272217399};\\\", \\\"{x:1694,y:767,t:1527272217410};\\\", \\\"{x:1688,y:767,t:1527272217428};\\\", \\\"{x:1681,y:767,t:1527272217445};\\\", \\\"{x:1675,y:767,t:1527272217460};\\\", \\\"{x:1666,y:769,t:1527272217478};\\\", \\\"{x:1662,y:771,t:1527272217495};\\\", \\\"{x:1658,y:774,t:1527272217511};\\\", \\\"{x:1652,y:779,t:1527272217528};\\\", \\\"{x:1645,y:789,t:1527272217545};\\\", \\\"{x:1639,y:801,t:1527272217561};\\\", \\\"{x:1631,y:817,t:1527272217578};\\\", \\\"{x:1623,y:835,t:1527272217595};\\\", \\\"{x:1618,y:849,t:1527272217610};\\\", \\\"{x:1613,y:858,t:1527272217628};\\\", \\\"{x:1611,y:867,t:1527272217645};\\\", \\\"{x:1610,y:872,t:1527272217661};\\\", \\\"{x:1608,y:877,t:1527272217678};\\\", \\\"{x:1606,y:882,t:1527272217695};\\\", \\\"{x:1602,y:887,t:1527272217712};\\\", \\\"{x:1599,y:891,t:1527272217728};\\\", \\\"{x:1597,y:891,t:1527272217745};\\\", \\\"{x:1596,y:891,t:1527272217784};\\\", \\\"{x:1595,y:892,t:1527272217795};\\\", \\\"{x:1594,y:893,t:1527272217812};\\\", \\\"{x:1591,y:893,t:1527272217828};\\\", \\\"{x:1588,y:893,t:1527272217845};\\\", \\\"{x:1582,y:893,t:1527272217862};\\\", \\\"{x:1577,y:893,t:1527272217878};\\\", \\\"{x:1569,y:893,t:1527272217895};\\\", \\\"{x:1568,y:893,t:1527272217912};\\\", \\\"{x:1566,y:893,t:1527272217928};\\\", \\\"{x:1565,y:893,t:1527272217960};\\\", \\\"{x:1563,y:893,t:1527272217984};\\\", \\\"{x:1560,y:893,t:1527272217995};\\\", \\\"{x:1551,y:896,t:1527272218012};\\\", \\\"{x:1545,y:899,t:1527272218029};\\\", \\\"{x:1534,y:905,t:1527272218045};\\\", \\\"{x:1523,y:912,t:1527272218063};\\\", \\\"{x:1519,y:914,t:1527272218078};\\\", \\\"{x:1517,y:915,t:1527272218095};\\\", \\\"{x:1514,y:915,t:1527272218464};\\\", \\\"{x:1513,y:911,t:1527272218479};\\\", \\\"{x:1513,y:909,t:1527272218495};\\\", \\\"{x:1511,y:901,t:1527272218512};\\\", \\\"{x:1511,y:898,t:1527272218529};\\\", \\\"{x:1511,y:895,t:1527272218545};\\\", \\\"{x:1510,y:892,t:1527272218562};\\\", \\\"{x:1510,y:890,t:1527272218579};\\\", \\\"{x:1509,y:888,t:1527272218595};\\\", \\\"{x:1509,y:886,t:1527272218612};\\\", \\\"{x:1509,y:885,t:1527272218629};\\\", \\\"{x:1509,y:884,t:1527272218645};\\\", \\\"{x:1509,y:882,t:1527272218662};\\\", \\\"{x:1509,y:880,t:1527272218680};\\\", \\\"{x:1509,y:878,t:1527272218696};\\\", \\\"{x:1509,y:875,t:1527272218712};\\\", \\\"{x:1509,y:873,t:1527272218728};\\\", \\\"{x:1509,y:871,t:1527272218746};\\\", \\\"{x:1509,y:868,t:1527272218761};\\\", \\\"{x:1509,y:865,t:1527272218778};\\\", \\\"{x:1509,y:862,t:1527272218795};\\\", \\\"{x:1509,y:859,t:1527272218812};\\\", \\\"{x:1509,y:856,t:1527272218829};\\\", \\\"{x:1509,y:854,t:1527272218845};\\\", \\\"{x:1509,y:851,t:1527272218862};\\\", \\\"{x:1509,y:848,t:1527272218878};\\\", \\\"{x:1509,y:845,t:1527272218895};\\\", \\\"{x:1509,y:842,t:1527272218912};\\\", \\\"{x:1509,y:838,t:1527272218929};\\\", \\\"{x:1509,y:834,t:1527272218946};\\\", \\\"{x:1509,y:830,t:1527272218962};\\\", \\\"{x:1509,y:826,t:1527272218979};\\\", \\\"{x:1509,y:824,t:1527272218996};\\\", \\\"{x:1509,y:821,t:1527272219012};\\\", \\\"{x:1509,y:819,t:1527272219028};\\\", \\\"{x:1509,y:817,t:1527272219046};\\\", \\\"{x:1509,y:815,t:1527272219062};\\\", \\\"{x:1509,y:814,t:1527272219080};\\\", \\\"{x:1509,y:812,t:1527272219128};\\\", \\\"{x:1509,y:811,t:1527272219175};\\\", \\\"{x:1509,y:810,t:1527272219192};\\\", \\\"{x:1509,y:809,t:1527272219208};\\\", \\\"{x:1509,y:808,t:1527272219215};\\\", \\\"{x:1510,y:806,t:1527272219229};\\\", \\\"{x:1510,y:805,t:1527272219246};\\\", \\\"{x:1510,y:802,t:1527272219264};\\\", \\\"{x:1510,y:800,t:1527272219280};\\\", \\\"{x:1511,y:799,t:1527272219296};\\\", \\\"{x:1511,y:797,t:1527272219320};\\\", \\\"{x:1512,y:796,t:1527272219329};\\\", \\\"{x:1512,y:795,t:1527272219352};\\\", \\\"{x:1512,y:794,t:1527272219363};\\\", \\\"{x:1513,y:794,t:1527272219379};\\\", \\\"{x:1513,y:793,t:1527272219396};\\\", \\\"{x:1513,y:792,t:1527272219413};\\\", \\\"{x:1513,y:791,t:1527272219429};\\\", \\\"{x:1513,y:790,t:1527272219446};\\\", \\\"{x:1513,y:789,t:1527272219463};\\\", \\\"{x:1514,y:789,t:1527272219479};\\\", \\\"{x:1514,y:788,t:1527272220247};\\\", \\\"{x:1514,y:786,t:1527272220263};\\\", \\\"{x:1514,y:785,t:1527272220287};\\\", \\\"{x:1514,y:784,t:1527272220303};\\\", \\\"{x:1514,y:783,t:1527272220319};\\\", \\\"{x:1514,y:782,t:1527272220343};\\\", \\\"{x:1514,y:781,t:1527272220407};\\\", \\\"{x:1514,y:780,t:1527272220423};\\\", \\\"{x:1514,y:779,t:1527272220448};\\\", \\\"{x:1514,y:778,t:1527272220512};\\\", \\\"{x:1514,y:777,t:1527272220527};\\\", \\\"{x:1514,y:776,t:1527272220648};\\\", \\\"{x:1514,y:775,t:1527272222304};\\\", \\\"{x:1514,y:773,t:1527272222316};\\\", \\\"{x:1514,y:772,t:1527272222332};\\\", \\\"{x:1514,y:770,t:1527272222348};\\\", \\\"{x:1514,y:769,t:1527272222365};\\\", \\\"{x:1515,y:766,t:1527272223176};\\\", \\\"{x:1520,y:762,t:1527272223199};\\\", \\\"{x:1522,y:760,t:1527272223216};\\\", \\\"{x:1525,y:757,t:1527272223232};\\\", \\\"{x:1529,y:751,t:1527272223250};\\\", \\\"{x:1532,y:747,t:1527272223266};\\\", \\\"{x:1533,y:743,t:1527272223282};\\\", \\\"{x:1535,y:740,t:1527272223299};\\\", \\\"{x:1536,y:737,t:1527272223316};\\\", \\\"{x:1536,y:735,t:1527272223333};\\\", \\\"{x:1537,y:733,t:1527272223349};\\\", \\\"{x:1538,y:731,t:1527272223367};\\\", \\\"{x:1538,y:729,t:1527272223383};\\\", \\\"{x:1538,y:726,t:1527272223399};\\\", \\\"{x:1538,y:724,t:1527272223416};\\\", \\\"{x:1538,y:723,t:1527272223432};\\\", \\\"{x:1539,y:720,t:1527272223458};\\\", \\\"{x:1541,y:713,t:1527272223518};\\\", \\\"{x:1541,y:709,t:1527272223533};\\\", \\\"{x:1541,y:703,t:1527272223548};\\\", \\\"{x:1544,y:697,t:1527272223565};\\\", \\\"{x:1546,y:684,t:1527272223583};\\\", \\\"{x:1549,y:675,t:1527272223599};\\\", \\\"{x:1553,y:665,t:1527272223616};\\\", \\\"{x:1555,y:658,t:1527272223633};\\\", \\\"{x:1556,y:651,t:1527272223648};\\\", \\\"{x:1556,y:645,t:1527272223666};\\\", \\\"{x:1557,y:640,t:1527272223683};\\\", \\\"{x:1557,y:637,t:1527272223699};\\\", \\\"{x:1557,y:635,t:1527272223716};\\\", \\\"{x:1557,y:633,t:1527272223733};\\\", \\\"{x:1557,y:632,t:1527272223749};\\\", \\\"{x:1557,y:630,t:1527272223767};\\\", \\\"{x:1557,y:629,t:1527272223784};\\\", \\\"{x:1557,y:627,t:1527272223799};\\\", \\\"{x:1557,y:626,t:1527272223817};\\\", \\\"{x:1557,y:625,t:1527272223833};\\\", \\\"{x:1557,y:623,t:1527272223850};\\\", \\\"{x:1557,y:620,t:1527272223866};\\\", \\\"{x:1557,y:619,t:1527272223883};\\\", \\\"{x:1555,y:616,t:1527272223899};\\\", \\\"{x:1555,y:615,t:1527272223915};\\\", \\\"{x:1554,y:613,t:1527272223933};\\\", \\\"{x:1554,y:612,t:1527272223951};\\\", \\\"{x:1554,y:611,t:1527272223967};\\\", \\\"{x:1554,y:610,t:1527272223982};\\\", \\\"{x:1554,y:609,t:1527272223999};\\\", \\\"{x:1554,y:608,t:1527272224016};\\\", \\\"{x:1554,y:607,t:1527272224033};\\\", \\\"{x:1553,y:606,t:1527272224063};\\\", \\\"{x:1553,y:604,t:1527272224319};\\\", \\\"{x:1553,y:602,t:1527272224343};\\\", \\\"{x:1553,y:601,t:1527272224359};\\\", \\\"{x:1552,y:599,t:1527272224383};\\\", \\\"{x:1552,y:598,t:1527272224415};\\\", \\\"{x:1551,y:598,t:1527272224431};\\\", \\\"{x:1550,y:602,t:1527272224735};\\\", \\\"{x:1545,y:616,t:1527272224752};\\\", \\\"{x:1536,y:662,t:1527272224795};\\\", \\\"{x:1535,y:670,t:1527272224800};\\\", \\\"{x:1532,y:681,t:1527272224817};\\\", \\\"{x:1532,y:690,t:1527272224833};\\\", \\\"{x:1532,y:697,t:1527272224849};\\\", \\\"{x:1532,y:701,t:1527272224867};\\\", \\\"{x:1532,y:708,t:1527272224884};\\\", \\\"{x:1532,y:713,t:1527272224900};\\\", \\\"{x:1532,y:720,t:1527272224917};\\\", \\\"{x:1531,y:724,t:1527272224934};\\\", \\\"{x:1531,y:729,t:1527272224950};\\\", \\\"{x:1531,y:735,t:1527272224967};\\\", \\\"{x:1531,y:740,t:1527272224983};\\\", \\\"{x:1531,y:742,t:1527272225000};\\\", \\\"{x:1531,y:746,t:1527272225017};\\\", \\\"{x:1531,y:749,t:1527272225033};\\\", \\\"{x:1531,y:753,t:1527272225050};\\\", \\\"{x:1531,y:755,t:1527272225066};\\\", \\\"{x:1531,y:756,t:1527272225084};\\\", \\\"{x:1531,y:758,t:1527272225100};\\\", \\\"{x:1531,y:759,t:1527272225143};\\\", \\\"{x:1531,y:755,t:1527272225368};\\\", \\\"{x:1531,y:748,t:1527272225385};\\\", \\\"{x:1531,y:739,t:1527272225402};\\\", \\\"{x:1531,y:732,t:1527272225417};\\\", \\\"{x:1531,y:728,t:1527272225435};\\\", \\\"{x:1531,y:725,t:1527272225452};\\\", \\\"{x:1531,y:723,t:1527272225467};\\\", \\\"{x:1531,y:720,t:1527272225484};\\\", \\\"{x:1531,y:717,t:1527272225502};\\\", \\\"{x:1531,y:714,t:1527272225517};\\\", \\\"{x:1531,y:709,t:1527272225534};\\\", \\\"{x:1531,y:703,t:1527272225551};\\\", \\\"{x:1531,y:700,t:1527272225566};\\\", \\\"{x:1531,y:697,t:1527272225584};\\\", \\\"{x:1531,y:696,t:1527272225601};\\\", \\\"{x:1531,y:695,t:1527272225617};\\\", \\\"{x:1531,y:694,t:1527272225634};\\\", \\\"{x:1531,y:693,t:1527272225654};\\\", \\\"{x:1531,y:692,t:1527272225667};\\\", \\\"{x:1531,y:691,t:1527272225684};\\\", \\\"{x:1531,y:690,t:1527272225703};\\\", \\\"{x:1531,y:689,t:1527272225719};\\\", \\\"{x:1531,y:688,t:1527272225735};\\\", \\\"{x:1531,y:686,t:1527272225759};\\\", \\\"{x:1531,y:685,t:1527272225768};\\\", \\\"{x:1531,y:684,t:1527272225784};\\\", \\\"{x:1531,y:682,t:1527272225801};\\\", \\\"{x:1531,y:681,t:1527272225819};\\\", \\\"{x:1531,y:679,t:1527272225834};\\\", \\\"{x:1531,y:678,t:1527272225851};\\\", \\\"{x:1531,y:676,t:1527272225868};\\\", \\\"{x:1531,y:675,t:1527272225884};\\\", \\\"{x:1531,y:674,t:1527272225902};\\\", \\\"{x:1531,y:673,t:1527272225918};\\\", \\\"{x:1531,y:672,t:1527272225934};\\\", \\\"{x:1530,y:674,t:1527272226328};\\\", \\\"{x:1529,y:680,t:1527272226335};\\\", \\\"{x:1529,y:689,t:1527272226352};\\\", \\\"{x:1529,y:698,t:1527272226369};\\\", \\\"{x:1529,y:705,t:1527272226386};\\\", \\\"{x:1529,y:713,t:1527272226402};\\\", \\\"{x:1529,y:718,t:1527272226418};\\\", \\\"{x:1529,y:725,t:1527272226435};\\\", \\\"{x:1529,y:732,t:1527272226451};\\\", \\\"{x:1529,y:737,t:1527272226468};\\\", \\\"{x:1529,y:742,t:1527272226485};\\\", \\\"{x:1529,y:745,t:1527272226502};\\\", \\\"{x:1529,y:747,t:1527272226519};\\\", \\\"{x:1529,y:752,t:1527272226536};\\\", \\\"{x:1529,y:755,t:1527272226552};\\\", \\\"{x:1531,y:757,t:1527272226568};\\\", \\\"{x:1531,y:759,t:1527272226591};\\\", \\\"{x:1531,y:760,t:1527272226601};\\\", \\\"{x:1532,y:762,t:1527272226619};\\\", \\\"{x:1533,y:766,t:1527272226635};\\\", \\\"{x:1534,y:769,t:1527272226652};\\\", \\\"{x:1535,y:771,t:1527272226669};\\\", \\\"{x:1535,y:774,t:1527272226686};\\\", \\\"{x:1535,y:775,t:1527272226703};\\\", \\\"{x:1536,y:776,t:1527272226718};\\\", \\\"{x:1536,y:777,t:1527272226736};\\\", \\\"{x:1536,y:781,t:1527272227768};\\\", \\\"{x:1533,y:788,t:1527272227786};\\\", \\\"{x:1523,y:799,t:1527272227803};\\\", \\\"{x:1513,y:812,t:1527272227820};\\\", \\\"{x:1508,y:818,t:1527272227836};\\\", \\\"{x:1506,y:823,t:1527272227853};\\\", \\\"{x:1504,y:827,t:1527272227870};\\\", \\\"{x:1503,y:831,t:1527272227886};\\\", \\\"{x:1501,y:835,t:1527272227903};\\\", \\\"{x:1497,y:841,t:1527272227919};\\\", \\\"{x:1493,y:846,t:1527272227936};\\\", \\\"{x:1489,y:851,t:1527272227954};\\\", \\\"{x:1486,y:854,t:1527272227970};\\\", \\\"{x:1482,y:857,t:1527272227986};\\\", \\\"{x:1475,y:861,t:1527272228003};\\\", \\\"{x:1468,y:866,t:1527272228020};\\\", \\\"{x:1460,y:868,t:1527272228036};\\\", \\\"{x:1452,y:873,t:1527272228054};\\\", \\\"{x:1441,y:878,t:1527272228070};\\\", \\\"{x:1424,y:884,t:1527272228087};\\\", \\\"{x:1398,y:894,t:1527272228104};\\\", \\\"{x:1385,y:899,t:1527272228120};\\\", \\\"{x:1379,y:901,t:1527272228136};\\\", \\\"{x:1372,y:903,t:1527272228154};\\\", \\\"{x:1367,y:904,t:1527272228170};\\\", \\\"{x:1365,y:905,t:1527272228187};\\\", \\\"{x:1363,y:906,t:1527272228204};\\\", \\\"{x:1362,y:906,t:1527272228220};\\\", \\\"{x:1361,y:907,t:1527272228237};\\\", \\\"{x:1361,y:908,t:1527272228327};\\\", \\\"{x:1360,y:909,t:1527272228337};\\\", \\\"{x:1360,y:908,t:1527272228488};\\\", \\\"{x:1360,y:906,t:1527272228504};\\\", \\\"{x:1362,y:904,t:1527272228519};\\\", \\\"{x:1365,y:902,t:1527272228536};\\\", \\\"{x:1369,y:901,t:1527272228553};\\\", \\\"{x:1371,y:899,t:1527272228570};\\\", \\\"{x:1372,y:899,t:1527272228585};\\\", \\\"{x:1372,y:898,t:1527272228602};\\\", \\\"{x:1373,y:897,t:1527272228639};\\\", \\\"{x:1374,y:896,t:1527272228663};\\\", \\\"{x:1374,y:895,t:1527272228671};\\\", \\\"{x:1375,y:895,t:1527272228686};\\\", \\\"{x:1376,y:892,t:1527272228703};\\\", \\\"{x:1377,y:892,t:1527272228768};\\\", \\\"{x:1377,y:891,t:1527272228800};\\\", \\\"{x:1378,y:891,t:1527272228808};\\\", \\\"{x:1379,y:890,t:1527272228820};\\\", \\\"{x:1381,y:889,t:1527272228837};\\\", \\\"{x:1382,y:888,t:1527272228853};\\\", \\\"{x:1384,y:888,t:1527272228870};\\\", \\\"{x:1384,y:887,t:1527272228886};\\\", \\\"{x:1385,y:887,t:1527272231160};\\\", \\\"{x:1392,y:886,t:1527272231172};\\\", \\\"{x:1413,y:886,t:1527272231189};\\\", \\\"{x:1429,y:886,t:1527272231205};\\\", \\\"{x:1443,y:886,t:1527272231222};\\\", \\\"{x:1451,y:886,t:1527272231239};\\\", \\\"{x:1453,y:886,t:1527272231256};\\\", \\\"{x:1455,y:886,t:1527272231473};\\\", \\\"{x:1457,y:886,t:1527272231489};\\\", \\\"{x:1460,y:886,t:1527272231506};\\\", \\\"{x:1462,y:886,t:1527272231523};\\\", \\\"{x:1460,y:886,t:1527272232015};\\\", \\\"{x:1458,y:886,t:1527272232023};\\\", \\\"{x:1456,y:885,t:1527272232040};\\\", \\\"{x:1455,y:884,t:1527272232057};\\\", \\\"{x:1453,y:884,t:1527272232073};\\\", \\\"{x:1452,y:884,t:1527272232090};\\\", \\\"{x:1451,y:883,t:1527272232106};\\\", \\\"{x:1450,y:883,t:1527272232167};\\\", \\\"{x:1449,y:882,t:1527272232176};\\\", \\\"{x:1448,y:882,t:1527272232208};\\\", \\\"{x:1447,y:881,t:1527272232231};\\\", \\\"{x:1446,y:881,t:1527272232295};\\\", \\\"{x:1445,y:880,t:1527272232306};\\\", \\\"{x:1444,y:880,t:1527272232350};\\\", \\\"{x:1442,y:879,t:1527272232366};\\\", \\\"{x:1439,y:876,t:1527272232374};\\\", \\\"{x:1434,y:874,t:1527272232389};\\\", \\\"{x:1430,y:869,t:1527272232406};\\\", \\\"{x:1420,y:853,t:1527272232422};\\\", \\\"{x:1413,y:841,t:1527272232439};\\\", \\\"{x:1408,y:826,t:1527272232456};\\\", \\\"{x:1404,y:818,t:1527272232473};\\\", \\\"{x:1404,y:813,t:1527272232489};\\\", \\\"{x:1404,y:810,t:1527272232507};\\\", \\\"{x:1404,y:808,t:1527272232524};\\\", \\\"{x:1404,y:807,t:1527272232540};\\\", \\\"{x:1404,y:805,t:1527272232557};\\\", \\\"{x:1404,y:804,t:1527272232573};\\\", \\\"{x:1404,y:802,t:1527272232647};\\\", \\\"{x:1404,y:803,t:1527272232912};\\\", \\\"{x:1404,y:804,t:1527272232926};\\\", \\\"{x:1404,y:805,t:1527272232940};\\\", \\\"{x:1404,y:808,t:1527272232956};\\\", \\\"{x:1404,y:812,t:1527272232973};\\\", \\\"{x:1404,y:815,t:1527272232990};\\\", \\\"{x:1404,y:819,t:1527272233006};\\\", \\\"{x:1404,y:821,t:1527272233023};\\\", \\\"{x:1404,y:822,t:1527272233040};\\\", \\\"{x:1404,y:823,t:1527272233056};\\\", \\\"{x:1401,y:824,t:1527272234488};\\\", \\\"{x:1394,y:825,t:1527272234496};\\\", \\\"{x:1387,y:826,t:1527272234508};\\\", \\\"{x:1373,y:826,t:1527272234525};\\\", \\\"{x:1354,y:827,t:1527272234541};\\\", \\\"{x:1335,y:827,t:1527272234558};\\\", \\\"{x:1323,y:827,t:1527272234574};\\\", \\\"{x:1314,y:827,t:1527272234591};\\\", \\\"{x:1311,y:827,t:1527272234608};\\\", \\\"{x:1309,y:827,t:1527272234624};\\\", \\\"{x:1305,y:827,t:1527272234641};\\\", \\\"{x:1299,y:827,t:1527272234658};\\\", \\\"{x:1288,y:827,t:1527272234674};\\\", \\\"{x:1273,y:827,t:1527272234692};\\\", \\\"{x:1260,y:827,t:1527272234709};\\\", \\\"{x:1253,y:827,t:1527272234724};\\\", \\\"{x:1247,y:827,t:1527272234741};\\\", \\\"{x:1240,y:827,t:1527272234759};\\\", \\\"{x:1230,y:827,t:1527272234774};\\\", \\\"{x:1218,y:825,t:1527272234791};\\\", \\\"{x:1214,y:824,t:1527272234809};\\\", \\\"{x:1212,y:824,t:1527272234825};\\\", \\\"{x:1215,y:823,t:1527272235848};\\\", \\\"{x:1218,y:822,t:1527272235859};\\\", \\\"{x:1226,y:820,t:1527272235877};\\\", \\\"{x:1233,y:817,t:1527272235892};\\\", \\\"{x:1238,y:817,t:1527272235910};\\\", \\\"{x:1241,y:816,t:1527272235926};\\\", \\\"{x:1245,y:815,t:1527272235943};\\\", \\\"{x:1249,y:814,t:1527272235960};\\\", \\\"{x:1259,y:814,t:1527272235976};\\\", \\\"{x:1271,y:814,t:1527272235993};\\\", \\\"{x:1286,y:814,t:1527272236010};\\\", \\\"{x:1303,y:814,t:1527272236026};\\\", \\\"{x:1321,y:816,t:1527272236043};\\\", \\\"{x:1335,y:819,t:1527272236060};\\\", \\\"{x:1348,y:820,t:1527272236076};\\\", \\\"{x:1353,y:821,t:1527272236093};\\\", \\\"{x:1357,y:822,t:1527272236110};\\\", \\\"{x:1358,y:823,t:1527272236125};\\\", \\\"{x:1360,y:823,t:1527272236142};\\\", \\\"{x:1361,y:824,t:1527272236183};\\\", \\\"{x:1363,y:823,t:1527272236744};\\\", \\\"{x:1364,y:814,t:1527272236760};\\\", \\\"{x:1366,y:807,t:1527272236777};\\\", \\\"{x:1367,y:797,t:1527272236794};\\\", \\\"{x:1368,y:784,t:1527272236810};\\\", \\\"{x:1368,y:775,t:1527272236827};\\\", \\\"{x:1369,y:770,t:1527272236844};\\\", \\\"{x:1369,y:766,t:1527272236860};\\\", \\\"{x:1369,y:765,t:1527272236877};\\\", \\\"{x:1370,y:765,t:1527272236894};\\\", \\\"{x:1370,y:764,t:1527272236912};\\\", \\\"{x:1370,y:762,t:1527272237015};\\\", \\\"{x:1368,y:761,t:1527272237039};\\\", \\\"{x:1366,y:760,t:1527272237063};\\\", \\\"{x:1365,y:760,t:1527272237168};\\\", \\\"{x:1364,y:760,t:1527272237216};\\\", \\\"{x:1363,y:759,t:1527272237227};\\\", \\\"{x:1362,y:759,t:1527272237279};\\\", \\\"{x:1361,y:759,t:1527272237304};\\\", \\\"{x:1360,y:758,t:1527272237312};\\\", \\\"{x:1359,y:758,t:1527272237327};\\\", \\\"{x:1358,y:757,t:1527272237344};\\\", \\\"{x:1358,y:752,t:1527272241072};\\\", \\\"{x:1358,y:748,t:1527272241080};\\\", \\\"{x:1358,y:736,t:1527272241097};\\\", \\\"{x:1360,y:728,t:1527272241113};\\\", \\\"{x:1360,y:719,t:1527272241130};\\\", \\\"{x:1360,y:713,t:1527272241148};\\\", \\\"{x:1362,y:707,t:1527272241163};\\\", \\\"{x:1362,y:705,t:1527272241180};\\\", \\\"{x:1362,y:702,t:1527272241197};\\\", \\\"{x:1362,y:701,t:1527272242992};\\\", \\\"{x:1359,y:701,t:1527272242999};\\\", \\\"{x:1354,y:701,t:1527272243015};\\\", \\\"{x:1342,y:701,t:1527272243031};\\\", \\\"{x:1321,y:697,t:1527272243048};\\\", \\\"{x:1298,y:690,t:1527272243066};\\\", \\\"{x:1270,y:682,t:1527272243082};\\\", \\\"{x:1232,y:671,t:1527272243098};\\\", \\\"{x:1180,y:657,t:1527272243115};\\\", \\\"{x:1118,y:640,t:1527272243132};\\\", \\\"{x:1035,y:615,t:1527272243148};\\\", \\\"{x:956,y:597,t:1527272243166};\\\", \\\"{x:888,y:584,t:1527272243184};\\\", \\\"{x:830,y:571,t:1527272243198};\\\", \\\"{x:779,y:565,t:1527272243214};\\\", \\\"{x:752,y:561,t:1527272243232};\\\", \\\"{x:728,y:558,t:1527272243248};\\\", \\\"{x:705,y:554,t:1527272243265};\\\", \\\"{x:685,y:551,t:1527272243281};\\\", \\\"{x:662,y:548,t:1527272243299};\\\", \\\"{x:641,y:546,t:1527272243315};\\\", \\\"{x:615,y:542,t:1527272243332};\\\", \\\"{x:593,y:540,t:1527272243348};\\\", \\\"{x:577,y:540,t:1527272243364};\\\", \\\"{x:561,y:538,t:1527272243381};\\\", \\\"{x:550,y:536,t:1527272243398};\\\", \\\"{x:549,y:536,t:1527272243415};\\\", \\\"{x:551,y:535,t:1527272243454};\\\", \\\"{x:555,y:534,t:1527272243465};\\\", \\\"{x:565,y:531,t:1527272243482};\\\", \\\"{x:580,y:527,t:1527272243499};\\\", \\\"{x:599,y:527,t:1527272243516};\\\", \\\"{x:618,y:527,t:1527272243532};\\\", \\\"{x:643,y:527,t:1527272243549};\\\", \\\"{x:669,y:527,t:1527272243567};\\\", \\\"{x:696,y:527,t:1527272243582};\\\", \\\"{x:726,y:526,t:1527272243601};\\\", \\\"{x:736,y:526,t:1527272243616};\\\", \\\"{x:741,y:526,t:1527272243631};\\\", \\\"{x:747,y:524,t:1527272243650};\\\", \\\"{x:748,y:523,t:1527272243671};\\\", \\\"{x:750,y:523,t:1527272243695};\\\", \\\"{x:750,y:522,t:1527272243703};\\\", \\\"{x:752,y:521,t:1527272243716};\\\", \\\"{x:756,y:519,t:1527272243732};\\\", \\\"{x:764,y:517,t:1527272243751};\\\", \\\"{x:777,y:514,t:1527272243765};\\\", \\\"{x:792,y:512,t:1527272243782};\\\", \\\"{x:810,y:510,t:1527272243798};\\\", \\\"{x:817,y:509,t:1527272243815};\\\", \\\"{x:820,y:507,t:1527272243832};\\\", \\\"{x:822,y:507,t:1527272243848};\\\", \\\"{x:824,y:507,t:1527272243866};\\\", \\\"{x:826,y:507,t:1527272243883};\\\", \\\"{x:833,y:507,t:1527272243899};\\\", \\\"{x:842,y:507,t:1527272243915};\\\", \\\"{x:849,y:507,t:1527272243933};\\\", \\\"{x:854,y:507,t:1527272243948};\\\", \\\"{x:857,y:507,t:1527272243965};\\\", \\\"{x:856,y:507,t:1527272244111};\\\", \\\"{x:854,y:507,t:1527272244127};\\\", \\\"{x:852,y:507,t:1527272244135};\\\", \\\"{x:851,y:507,t:1527272244149};\\\", \\\"{x:849,y:507,t:1527272244166};\\\", \\\"{x:847,y:507,t:1527272244182};\\\", \\\"{x:846,y:507,t:1527272244231};\\\", \\\"{x:843,y:508,t:1527272244571};\\\", \\\"{x:822,y:521,t:1527272244586};\\\", \\\"{x:785,y:545,t:1527272244604};\\\", \\\"{x:726,y:584,t:1527272244620};\\\", \\\"{x:652,y:634,t:1527272244637};\\\", \\\"{x:564,y:688,t:1527272244653};\\\", \\\"{x:504,y:719,t:1527272244669};\\\", \\\"{x:471,y:741,t:1527272244687};\\\", \\\"{x:459,y:750,t:1527272244704};\\\", \\\"{x:457,y:753,t:1527272244720};\\\", \\\"{x:457,y:757,t:1527272244736};\\\", \\\"{x:457,y:759,t:1527272244754};\\\", \\\"{x:457,y:760,t:1527272244770};\\\", \\\"{x:457,y:764,t:1527272244787};\\\", \\\"{x:456,y:768,t:1527272244803};\\\", \\\"{x:453,y:772,t:1527272244820};\\\", \\\"{x:451,y:773,t:1527272244837};\\\", \\\"{x:450,y:774,t:1527272244854};\\\", \\\"{x:450,y:772,t:1527272244996};\\\", \\\"{x:452,y:769,t:1527272245004};\\\", \\\"{x:458,y:762,t:1527272245021};\\\", \\\"{x:463,y:755,t:1527272245037};\\\", \\\"{x:466,y:748,t:1527272245055};\\\", \\\"{x:467,y:746,t:1527272245071};\\\", \\\"{x:468,y:744,t:1527272245086};\\\", \\\"{x:470,y:742,t:1527272245104};\\\", \\\"{x:470,y:741,t:1527272245121};\\\", \\\"{x:471,y:741,t:1527272245137};\\\", \\\"{x:472,y:740,t:1527272245860};\\\", \\\"{x:474,y:740,t:1527272245871};\\\", \\\"{x:486,y:740,t:1527272245888};\\\", \\\"{x:504,y:743,t:1527272245905};\\\", \\\"{x:523,y:746,t:1527272245921};\\\", \\\"{x:547,y:749,t:1527272245938};\\\", \\\"{x:584,y:755,t:1527272245955};\\\", \\\"{x:610,y:759,t:1527272245971};\\\", \\\"{x:636,y:761,t:1527272245988};\\\", \\\"{x:662,y:766,t:1527272246005};\\\", \\\"{x:683,y:768,t:1527272246021};\\\", \\\"{x:701,y:770,t:1527272246038};\\\", \\\"{x:712,y:772,t:1527272246055};\\\", \\\"{x:720,y:772,t:1527272246070};\\\", \\\"{x:723,y:772,t:1527272246088};\\\", \\\"{x:724,y:772,t:1527272246104};\\\", \\\"{x:725,y:773,t:1527272246121};\\\" ] }, { \\\"rt\\\": 32077, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 694016, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-10 AM-08 AM-08 AM-09 AM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:728,y:760,t:1527272250756};\\\", \\\"{x:731,y:734,t:1527272250763};\\\", \\\"{x:736,y:712,t:1527272250775};\\\", \\\"{x:738,y:680,t:1527272250792};\\\", \\\"{x:738,y:639,t:1527272250810};\\\", \\\"{x:738,y:599,t:1527272250825};\\\", \\\"{x:732,y:571,t:1527272250842};\\\", \\\"{x:699,y:513,t:1527272250876};\\\", \\\"{x:681,y:496,t:1527272250892};\\\", \\\"{x:662,y:483,t:1527272250909};\\\", \\\"{x:644,y:476,t:1527272250925};\\\", \\\"{x:624,y:470,t:1527272250941};\\\", \\\"{x:613,y:467,t:1527272250958};\\\", \\\"{x:600,y:466,t:1527272250975};\\\", \\\"{x:590,y:466,t:1527272250992};\\\", \\\"{x:576,y:466,t:1527272251009};\\\", \\\"{x:563,y:468,t:1527272251025};\\\", \\\"{x:549,y:473,t:1527272251042};\\\", \\\"{x:536,y:480,t:1527272251058};\\\", \\\"{x:530,y:486,t:1527272251075};\\\", \\\"{x:528,y:488,t:1527272251092};\\\", \\\"{x:527,y:490,t:1527272251110};\\\", \\\"{x:528,y:490,t:1527272251251};\\\", \\\"{x:531,y:490,t:1527272251258};\\\", \\\"{x:540,y:490,t:1527272251275};\\\", \\\"{x:550,y:489,t:1527272251291};\\\", \\\"{x:558,y:488,t:1527272251309};\\\", \\\"{x:566,y:484,t:1527272251325};\\\", \\\"{x:573,y:483,t:1527272251342};\\\", \\\"{x:575,y:481,t:1527272251359};\\\", \\\"{x:577,y:480,t:1527272251375};\\\", \\\"{x:578,y:480,t:1527272251403};\\\", \\\"{x:578,y:479,t:1527272251411};\\\", \\\"{x:579,y:479,t:1527272251427};\\\", \\\"{x:579,y:478,t:1527272251443};\\\", \\\"{x:581,y:478,t:1527272251460};\\\", \\\"{x:583,y:478,t:1527272251580};\\\", \\\"{x:585,y:477,t:1527272251595};\\\", \\\"{x:588,y:476,t:1527272251609};\\\", \\\"{x:592,y:474,t:1527272251626};\\\", \\\"{x:596,y:473,t:1527272251642};\\\", \\\"{x:599,y:471,t:1527272251660};\\\", \\\"{x:600,y:470,t:1527272251699};\\\", \\\"{x:602,y:470,t:1527272252116};\\\", \\\"{x:609,y:474,t:1527272252126};\\\", \\\"{x:637,y:491,t:1527272252143};\\\", \\\"{x:696,y:521,t:1527272252160};\\\", \\\"{x:779,y:555,t:1527272252176};\\\", \\\"{x:871,y:589,t:1527272252193};\\\", \\\"{x:965,y:631,t:1527272252210};\\\", \\\"{x:1117,y:685,t:1527272252226};\\\", \\\"{x:1214,y:715,t:1527272252242};\\\", \\\"{x:1301,y:742,t:1527272252259};\\\", \\\"{x:1367,y:761,t:1527272252276};\\\", \\\"{x:1428,y:778,t:1527272252293};\\\", \\\"{x:1471,y:792,t:1527272252309};\\\", \\\"{x:1496,y:799,t:1527272252327};\\\", \\\"{x:1512,y:804,t:1527272252342};\\\", \\\"{x:1524,y:808,t:1527272252359};\\\", \\\"{x:1529,y:811,t:1527272252376};\\\", \\\"{x:1530,y:811,t:1527272252393};\\\", \\\"{x:1531,y:812,t:1527272252419};\\\", \\\"{x:1532,y:814,t:1527272252435};\\\", \\\"{x:1533,y:815,t:1527272252442};\\\", \\\"{x:1536,y:820,t:1527272252459};\\\", \\\"{x:1538,y:826,t:1527272252476};\\\", \\\"{x:1538,y:833,t:1527272252492};\\\", \\\"{x:1539,y:843,t:1527272252510};\\\", \\\"{x:1539,y:855,t:1527272252526};\\\", \\\"{x:1539,y:871,t:1527272252543};\\\", \\\"{x:1539,y:892,t:1527272252560};\\\", \\\"{x:1539,y:914,t:1527272252576};\\\", \\\"{x:1539,y:930,t:1527272252593};\\\", \\\"{x:1539,y:944,t:1527272252608};\\\", \\\"{x:1539,y:952,t:1527272252626};\\\", \\\"{x:1539,y:954,t:1527272252642};\\\", \\\"{x:1539,y:957,t:1527272252659};\\\", \\\"{x:1537,y:958,t:1527272252675};\\\", \\\"{x:1533,y:959,t:1527272252692};\\\", \\\"{x:1529,y:960,t:1527272252709};\\\", \\\"{x:1523,y:961,t:1527272252726};\\\", \\\"{x:1517,y:961,t:1527272252741};\\\", \\\"{x:1511,y:961,t:1527272252759};\\\", \\\"{x:1508,y:961,t:1527272252776};\\\", \\\"{x:1507,y:961,t:1527272252791};\\\", \\\"{x:1505,y:961,t:1527272252809};\\\", \\\"{x:1504,y:961,t:1527272252922};\\\", \\\"{x:1502,y:961,t:1527272252930};\\\", \\\"{x:1500,y:961,t:1527272252941};\\\", \\\"{x:1497,y:961,t:1527272252958};\\\", \\\"{x:1494,y:961,t:1527272252974};\\\", \\\"{x:1491,y:960,t:1527272252991};\\\", \\\"{x:1488,y:960,t:1527272253008};\\\", \\\"{x:1486,y:959,t:1527272253023};\\\", \\\"{x:1485,y:959,t:1527272253082};\\\", \\\"{x:1482,y:961,t:1527272263796};\\\", \\\"{x:1475,y:969,t:1527272263804};\\\", \\\"{x:1468,y:972,t:1527272263814};\\\", \\\"{x:1450,y:979,t:1527272263832};\\\", \\\"{x:1436,y:985,t:1527272263848};\\\", \\\"{x:1424,y:987,t:1527272263864};\\\", \\\"{x:1420,y:988,t:1527272263881};\\\", \\\"{x:1419,y:988,t:1527272264212};\\\", \\\"{x:1417,y:988,t:1527272264219};\\\", \\\"{x:1412,y:988,t:1527272264230};\\\", \\\"{x:1401,y:988,t:1527272264245};\\\", \\\"{x:1387,y:987,t:1527272264263};\\\", \\\"{x:1378,y:986,t:1527272264280};\\\", \\\"{x:1373,y:985,t:1527272264295};\\\", \\\"{x:1371,y:985,t:1527272264403};\\\", \\\"{x:1370,y:985,t:1527272264435};\\\", \\\"{x:1368,y:985,t:1527272264450};\\\", \\\"{x:1366,y:986,t:1527272264467};\\\", \\\"{x:1364,y:986,t:1527272264479};\\\", \\\"{x:1360,y:986,t:1527272264496};\\\", \\\"{x:1357,y:986,t:1527272264513};\\\", \\\"{x:1354,y:987,t:1527272264529};\\\", \\\"{x:1352,y:987,t:1527272264763};\\\", \\\"{x:1345,y:987,t:1527272264779};\\\", \\\"{x:1314,y:987,t:1527272264795};\\\", \\\"{x:1290,y:987,t:1527272264812};\\\", \\\"{x:1271,y:987,t:1527272264828};\\\", \\\"{x:1259,y:986,t:1527272264845};\\\", \\\"{x:1256,y:986,t:1527272264861};\\\", \\\"{x:1255,y:986,t:1527272264877};\\\", \\\"{x:1253,y:986,t:1527272265186};\\\", \\\"{x:1249,y:986,t:1527272265194};\\\", \\\"{x:1234,y:986,t:1527272265210};\\\", \\\"{x:1213,y:985,t:1527272265227};\\\", \\\"{x:1198,y:984,t:1527272265244};\\\", \\\"{x:1191,y:982,t:1527272265261};\\\", \\\"{x:1189,y:982,t:1527272265277};\\\", \\\"{x:1185,y:982,t:1527272265642};\\\", \\\"{x:1172,y:985,t:1527272265660};\\\", \\\"{x:1160,y:986,t:1527272265676};\\\", \\\"{x:1152,y:987,t:1527272265692};\\\", \\\"{x:1149,y:988,t:1527272265708};\\\", \\\"{x:1148,y:988,t:1527272265726};\\\", \\\"{x:1141,y:988,t:1527272266083};\\\", \\\"{x:1130,y:988,t:1527272266091};\\\", \\\"{x:1097,y:984,t:1527272266108};\\\", \\\"{x:1066,y:979,t:1527272266125};\\\", \\\"{x:1044,y:977,t:1527272266142};\\\", \\\"{x:1039,y:976,t:1527272266158};\\\", \\\"{x:1044,y:976,t:1527272266507};\\\", \\\"{x:1055,y:976,t:1527272266524};\\\", \\\"{x:1074,y:976,t:1527272266541};\\\", \\\"{x:1096,y:976,t:1527272266557};\\\", \\\"{x:1118,y:976,t:1527272266574};\\\", \\\"{x:1143,y:980,t:1527272266589};\\\", \\\"{x:1165,y:982,t:1527272266606};\\\", \\\"{x:1188,y:986,t:1527272266623};\\\", \\\"{x:1213,y:990,t:1527272266640};\\\", \\\"{x:1235,y:990,t:1527272266657};\\\", \\\"{x:1252,y:990,t:1527272266674};\\\", \\\"{x:1268,y:990,t:1527272266689};\\\", \\\"{x:1284,y:990,t:1527272266706};\\\", \\\"{x:1294,y:989,t:1527272266723};\\\", \\\"{x:1299,y:986,t:1527272266740};\\\", \\\"{x:1307,y:985,t:1527272266757};\\\", \\\"{x:1310,y:984,t:1527272266773};\\\", \\\"{x:1313,y:983,t:1527272266790};\\\", \\\"{x:1314,y:983,t:1527272266807};\\\", \\\"{x:1315,y:983,t:1527272266823};\\\", \\\"{x:1315,y:982,t:1527272267299};\\\", \\\"{x:1315,y:981,t:1527272268371};\\\", \\\"{x:1315,y:980,t:1527272268387};\\\", \\\"{x:1316,y:964,t:1527272268403};\\\", \\\"{x:1321,y:942,t:1527272268420};\\\", \\\"{x:1321,y:909,t:1527272268437};\\\", \\\"{x:1321,y:853,t:1527272268453};\\\", \\\"{x:1307,y:792,t:1527272268469};\\\", \\\"{x:1272,y:720,t:1527272268486};\\\", \\\"{x:1234,y:654,t:1527272268502};\\\", \\\"{x:1186,y:601,t:1527272268520};\\\", \\\"{x:1141,y:560,t:1527272268535};\\\", \\\"{x:1096,y:529,t:1527272268553};\\\", \\\"{x:1076,y:518,t:1527272268570};\\\", \\\"{x:1070,y:516,t:1527272268586};\\\", \\\"{x:1068,y:516,t:1527272268602};\\\", \\\"{x:1068,y:515,t:1527272268620};\\\", \\\"{x:1068,y:518,t:1527272268635};\\\", \\\"{x:1068,y:528,t:1527272268652};\\\", \\\"{x:1074,y:549,t:1527272268670};\\\", \\\"{x:1093,y:577,t:1527272268686};\\\", \\\"{x:1122,y:614,t:1527272268702};\\\", \\\"{x:1166,y:662,t:1527272268718};\\\", \\\"{x:1228,y:711,t:1527272268735};\\\", \\\"{x:1295,y:758,t:1527272268752};\\\", \\\"{x:1353,y:791,t:1527272268768};\\\", \\\"{x:1391,y:806,t:1527272268786};\\\", \\\"{x:1415,y:817,t:1527272268801};\\\", \\\"{x:1424,y:820,t:1527272268819};\\\", \\\"{x:1425,y:821,t:1527272268843};\\\", \\\"{x:1421,y:821,t:1527272268931};\\\", \\\"{x:1415,y:821,t:1527272268939};\\\", \\\"{x:1407,y:820,t:1527272268952};\\\", \\\"{x:1389,y:817,t:1527272268968};\\\", \\\"{x:1369,y:814,t:1527272268984};\\\", \\\"{x:1352,y:812,t:1527272269002};\\\", \\\"{x:1337,y:811,t:1527272269018};\\\", \\\"{x:1327,y:809,t:1527272269034};\\\", \\\"{x:1314,y:807,t:1527272269051};\\\", \\\"{x:1308,y:807,t:1527272269069};\\\", \\\"{x:1303,y:806,t:1527272269084};\\\", \\\"{x:1295,y:805,t:1527272269102};\\\", \\\"{x:1286,y:805,t:1527272269117};\\\", \\\"{x:1281,y:804,t:1527272269134};\\\", \\\"{x:1278,y:804,t:1527272269152};\\\", \\\"{x:1276,y:804,t:1527272269228};\\\", \\\"{x:1275,y:804,t:1527272269235};\\\", \\\"{x:1273,y:804,t:1527272269250};\\\", \\\"{x:1262,y:804,t:1527272269267};\\\", \\\"{x:1252,y:803,t:1527272269284};\\\", \\\"{x:1238,y:799,t:1527272269300};\\\", \\\"{x:1222,y:794,t:1527272269317};\\\", \\\"{x:1205,y:789,t:1527272269333};\\\", \\\"{x:1192,y:786,t:1527272269351};\\\", \\\"{x:1186,y:784,t:1527272269368};\\\", \\\"{x:1185,y:784,t:1527272269383};\\\", \\\"{x:1184,y:783,t:1527272269451};\\\", \\\"{x:1185,y:781,t:1527272269523};\\\", \\\"{x:1188,y:781,t:1527272269547};\\\", \\\"{x:1188,y:780,t:1527272269563};\\\", \\\"{x:1189,y:780,t:1527272269571};\\\", \\\"{x:1191,y:779,t:1527272269587};\\\", \\\"{x:1191,y:778,t:1527272269599};\\\", \\\"{x:1193,y:775,t:1527272269617};\\\", \\\"{x:1194,y:772,t:1527272269633};\\\", \\\"{x:1195,y:770,t:1527272269650};\\\", \\\"{x:1195,y:768,t:1527272269666};\\\", \\\"{x:1195,y:767,t:1527272269683};\\\", \\\"{x:1195,y:765,t:1527272269891};\\\", \\\"{x:1194,y:765,t:1527272269907};\\\", \\\"{x:1193,y:764,t:1527272269915};\\\", \\\"{x:1192,y:764,t:1527272269932};\\\", \\\"{x:1191,y:764,t:1527272269950};\\\", \\\"{x:1193,y:764,t:1527272270931};\\\", \\\"{x:1202,y:766,t:1527272270947};\\\", \\\"{x:1249,y:772,t:1527272270963};\\\", \\\"{x:1276,y:773,t:1527272270979};\\\", \\\"{x:1299,y:774,t:1527272270996};\\\", \\\"{x:1317,y:774,t:1527272271014};\\\", \\\"{x:1329,y:774,t:1527272271029};\\\", \\\"{x:1340,y:774,t:1527272271046};\\\", \\\"{x:1347,y:774,t:1527272271063};\\\", \\\"{x:1351,y:774,t:1527272271079};\\\", \\\"{x:1354,y:774,t:1527272271097};\\\", \\\"{x:1356,y:774,t:1527272271115};\\\", \\\"{x:1357,y:774,t:1527272271242};\\\", \\\"{x:1357,y:773,t:1527272271298};\\\", \\\"{x:1356,y:772,t:1527272271311};\\\", \\\"{x:1355,y:771,t:1527272271328};\\\", \\\"{x:1353,y:770,t:1527272271345};\\\", \\\"{x:1352,y:768,t:1527272271361};\\\", \\\"{x:1350,y:767,t:1527272271378};\\\", \\\"{x:1355,y:767,t:1527272275117};\\\", \\\"{x:1363,y:767,t:1527272275121};\\\", \\\"{x:1367,y:767,t:1527272275134};\\\", \\\"{x:1377,y:767,t:1527272275152};\\\", \\\"{x:1383,y:767,t:1527272275169};\\\", \\\"{x:1385,y:767,t:1527272275185};\\\", \\\"{x:1388,y:767,t:1527272275202};\\\", \\\"{x:1391,y:767,t:1527272275219};\\\", \\\"{x:1396,y:767,t:1527272275235};\\\", \\\"{x:1407,y:767,t:1527272275252};\\\", \\\"{x:1423,y:767,t:1527272275268};\\\", \\\"{x:1444,y:767,t:1527272275285};\\\", \\\"{x:1466,y:771,t:1527272275302};\\\", \\\"{x:1481,y:771,t:1527272275318};\\\", \\\"{x:1499,y:771,t:1527272275335};\\\", \\\"{x:1508,y:771,t:1527272275352};\\\", \\\"{x:1515,y:771,t:1527272275368};\\\", \\\"{x:1517,y:771,t:1527272275385};\\\", \\\"{x:1519,y:771,t:1527272275401};\\\", \\\"{x:1520,y:771,t:1527272275418};\\\", \\\"{x:1522,y:771,t:1527272275435};\\\", \\\"{x:1524,y:771,t:1527272275451};\\\", \\\"{x:1522,y:771,t:1527272275690};\\\", \\\"{x:1520,y:771,t:1527272275700};\\\", \\\"{x:1518,y:771,t:1527272275717};\\\", \\\"{x:1517,y:771,t:1527272275734};\\\", \\\"{x:1513,y:771,t:1527272275751};\\\", \\\"{x:1508,y:770,t:1527272275767};\\\", \\\"{x:1497,y:770,t:1527272275784};\\\", \\\"{x:1478,y:770,t:1527272275800};\\\", \\\"{x:1455,y:770,t:1527272275817};\\\", \\\"{x:1420,y:770,t:1527272275834};\\\", \\\"{x:1401,y:770,t:1527272275850};\\\", \\\"{x:1391,y:770,t:1527272275867};\\\", \\\"{x:1386,y:770,t:1527272275883};\\\", \\\"{x:1385,y:770,t:1527272275900};\\\", \\\"{x:1384,y:770,t:1527272276252};\\\", \\\"{x:1382,y:770,t:1527272276267};\\\", \\\"{x:1375,y:770,t:1527272276283};\\\", \\\"{x:1368,y:770,t:1527272276300};\\\", \\\"{x:1359,y:771,t:1527272276317};\\\", \\\"{x:1350,y:773,t:1527272276333};\\\", \\\"{x:1341,y:773,t:1527272276350};\\\", \\\"{x:1332,y:774,t:1527272276367};\\\", \\\"{x:1324,y:776,t:1527272276383};\\\", \\\"{x:1320,y:777,t:1527272276399};\\\", \\\"{x:1314,y:780,t:1527272276415};\\\", \\\"{x:1310,y:781,t:1527272276432};\\\", \\\"{x:1307,y:782,t:1527272276450};\\\", \\\"{x:1303,y:783,t:1527272276465};\\\", \\\"{x:1302,y:784,t:1527272276482};\\\", \\\"{x:1300,y:784,t:1527272276499};\\\", \\\"{x:1299,y:784,t:1527272276515};\\\", \\\"{x:1298,y:785,t:1527272276532};\\\", \\\"{x:1296,y:785,t:1527272276548};\\\", \\\"{x:1293,y:785,t:1527272276565};\\\", \\\"{x:1285,y:784,t:1527272276582};\\\", \\\"{x:1278,y:783,t:1527272276599};\\\", \\\"{x:1269,y:781,t:1527272276615};\\\", \\\"{x:1257,y:777,t:1527272276633};\\\", \\\"{x:1240,y:774,t:1527272276648};\\\", \\\"{x:1218,y:768,t:1527272276665};\\\", \\\"{x:1173,y:758,t:1527272276681};\\\", \\\"{x:1079,y:733,t:1527272276698};\\\", \\\"{x:998,y:708,t:1527272276715};\\\", \\\"{x:924,y:688,t:1527272276731};\\\", \\\"{x:860,y:669,t:1527272276748};\\\", \\\"{x:806,y:653,t:1527272276765};\\\", \\\"{x:767,y:642,t:1527272276782};\\\", \\\"{x:740,y:635,t:1527272276798};\\\", \\\"{x:717,y:625,t:1527272276815};\\\", \\\"{x:695,y:618,t:1527272276830};\\\", \\\"{x:679,y:610,t:1527272276846};\\\", \\\"{x:666,y:604,t:1527272276864};\\\", \\\"{x:662,y:601,t:1527272276879};\\\", \\\"{x:658,y:597,t:1527272276896};\\\", \\\"{x:652,y:593,t:1527272276913};\\\", \\\"{x:647,y:589,t:1527272276929};\\\", \\\"{x:634,y:582,t:1527272276946};\\\", \\\"{x:617,y:574,t:1527272276963};\\\", \\\"{x:581,y:564,t:1527272276980};\\\", \\\"{x:522,y:547,t:1527272276996};\\\", \\\"{x:443,y:529,t:1527272277013};\\\", \\\"{x:383,y:517,t:1527272277029};\\\", \\\"{x:339,y:511,t:1527272277046};\\\", \\\"{x:313,y:507,t:1527272277063};\\\", \\\"{x:303,y:506,t:1527272277080};\\\", \\\"{x:300,y:506,t:1527272277096};\\\", \\\"{x:296,y:507,t:1527272277113};\\\", \\\"{x:287,y:513,t:1527272277130};\\\", \\\"{x:283,y:518,t:1527272277146};\\\", \\\"{x:281,y:523,t:1527272277163};\\\", \\\"{x:280,y:529,t:1527272277180};\\\", \\\"{x:279,y:535,t:1527272277197};\\\", \\\"{x:279,y:543,t:1527272277214};\\\", \\\"{x:279,y:549,t:1527272277229};\\\", \\\"{x:279,y:552,t:1527272277246};\\\", \\\"{x:280,y:556,t:1527272277264};\\\", \\\"{x:280,y:557,t:1527272277279};\\\", \\\"{x:280,y:558,t:1527272277296};\\\", \\\"{x:280,y:559,t:1527272277313};\\\", \\\"{x:280,y:560,t:1527272277330};\\\", \\\"{x:279,y:563,t:1527272277347};\\\", \\\"{x:272,y:563,t:1527272277364};\\\", \\\"{x:262,y:563,t:1527272277379};\\\", \\\"{x:250,y:563,t:1527272277397};\\\", \\\"{x:237,y:563,t:1527272277413};\\\", \\\"{x:226,y:563,t:1527272277430};\\\", \\\"{x:221,y:563,t:1527272277447};\\\", \\\"{x:215,y:563,t:1527272277464};\\\", \\\"{x:211,y:563,t:1527272277480};\\\", \\\"{x:208,y:563,t:1527272277497};\\\", \\\"{x:206,y:563,t:1527272277514};\\\", \\\"{x:205,y:563,t:1527272277595};\\\", \\\"{x:204,y:563,t:1527272277603};\\\", \\\"{x:202,y:563,t:1527272277618};\\\", \\\"{x:201,y:563,t:1527272277632};\\\", \\\"{x:197,y:562,t:1527272277648};\\\", \\\"{x:187,y:558,t:1527272277664};\\\", \\\"{x:172,y:554,t:1527272277681};\\\", \\\"{x:159,y:553,t:1527272277697};\\\", \\\"{x:157,y:553,t:1527272277713};\\\", \\\"{x:161,y:553,t:1527272277969};\\\", \\\"{x:174,y:559,t:1527272277980};\\\", \\\"{x:210,y:582,t:1527272277998};\\\", \\\"{x:252,y:608,t:1527272278014};\\\", \\\"{x:301,y:639,t:1527272278030};\\\", \\\"{x:347,y:665,t:1527272278048};\\\", \\\"{x:393,y:690,t:1527272278065};\\\", \\\"{x:438,y:710,t:1527272278080};\\\", \\\"{x:483,y:725,t:1527272278097};\\\", \\\"{x:530,y:741,t:1527272278114};\\\", \\\"{x:555,y:748,t:1527272278130};\\\", \\\"{x:570,y:750,t:1527272278148};\\\", \\\"{x:576,y:752,t:1527272278164};\\\", \\\"{x:577,y:752,t:1527272278243};\\\", \\\"{x:577,y:754,t:1527272278250};\\\", \\\"{x:577,y:756,t:1527272278264};\\\", \\\"{x:575,y:762,t:1527272278281};\\\", \\\"{x:570,y:768,t:1527272278298};\\\", \\\"{x:564,y:773,t:1527272278315};\\\", \\\"{x:560,y:774,t:1527272278330};\\\", \\\"{x:557,y:775,t:1527272278347};\\\", \\\"{x:546,y:773,t:1527272278364};\\\", \\\"{x:530,y:769,t:1527272278381};\\\", \\\"{x:510,y:763,t:1527272278398};\\\", \\\"{x:498,y:758,t:1527272278414};\\\", \\\"{x:494,y:756,t:1527272278431};\\\", \\\"{x:494,y:755,t:1527272278483};\\\" ] }, { \\\"rt\\\": 41088, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 736330, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The x axis says that shifts for b and f start\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9350, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Mexico\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 746686, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13784, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 761487, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 5378, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 768205, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"FK2HU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"FK2HU\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 208, dom: 1190, initialDom: 1255",
  "javascriptErrors": []
}