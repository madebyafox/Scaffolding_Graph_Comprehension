var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3eb70e688f8d2546caa8630dfb0a0e62",
  "created": "2018-06-01T11:13:52.5271466-07:00",
  "lastActivity": "2018-06-01T11:14:17.1871466-07:00",
  "pageViews": [
    {
      "id": "060152226fc40ec6dfc8023436906061f81fade3",
      "startTime": "2018-06-01T11:13:52.5271466-07:00",
      "endTime": "2018-06-01T11:14:17.1871466-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 24660,
      "engagementTime": 24660,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24660,
  "engagementTime": 24660,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HW2SN",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8d6ba7331dc52a63d01c8f1f7a861e17",
  "gdpr": false
}