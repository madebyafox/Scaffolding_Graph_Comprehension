var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052233559620f9cb096d09e982e97681011f3294"] = {
  "startTime": "2018-05-22T17:07:33.7691006Z",
  "websitePageUrl": "/",
  "visitTime": 119245,
  "engagementTime": 71608,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1302,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "28494af79744471f5b2afc90c1fc378b",
    "created": "2018-05-22T17:07:33.7691006+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "3c445a59746687fdea052226b1544b15",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/28494af79744471f5b2afc90c1fc378b/play"
  },
  "events": [
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1302,
      "y": 1047
    },
    {
      "t": 273,
      "e": 273,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 23565,
      "y": 3440,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 806,
      "y": 551
    },
    {
      "t": 1856,
      "e": 1856,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 1292,
      "y": 840
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 1262,
      "y": 995
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 922,
      "y": 749
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 41969,
      "y": 44318,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 812,
      "y": 638
    },
    {
      "t": 2399,
      "e": 2399,
      "ty": 2,
      "x": 812,
      "y": 637
    },
    {
      "t": 2610,
      "e": 2610,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 2610,
      "e": 2610,
      "ty": 41,
      "x": 41587,
      "y": 42106,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 781,
      "y": 731
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 35743,
      "y": 55540,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 681,
      "y": 814
    },
    {
      "t": 2899,
      "e": 2899,
      "ty": 2,
      "x": 675,
      "y": 816
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 660,
      "y": 795
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 41,
      "x": 33286,
      "y": 55049,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 662,
      "y": 791
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 692,
      "y": 784
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 35033,
      "y": 54148,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3599,
      "e": 3599,
      "ty": 2,
      "x": 705,
      "y": 780
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 706,
      "y": 778
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 41,
      "x": 35907,
      "y": 53411,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3802,
      "e": 3802,
      "ty": 2,
      "x": 708,
      "y": 775
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 709,
      "y": 774
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 711,
      "y": 719
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 36071,
      "y": 48823,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 632,
      "y": 398
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 642,
      "y": 284
    },
    {
      "t": 4239,
      "e": 4239,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 43248,
      "y": 827,
      "ta": "html > body"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 856,
      "y": 21
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1266,
      "y": 497
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 49506,
      "y": 28712,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1157,
      "y": 615
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1145,
      "y": 627
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 41314,
      "y": 36576,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1104,
      "y": 570
    },
    {
      "t": 6346,
      "e": 6346,
      "ty": 3,
      "x": 1104,
      "y": 570,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6441,
      "e": 6441,
      "ty": 4,
      "x": 40659,
      "y": 34692,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6442,
      "e": 6442,
      "ty": 5,
      "x": 1104,
      "y": 570,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 41,
      "x": 40659,
      "y": 34692,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 995,
      "y": 584
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 973,
      "y": 582
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 32576,
      "y": 35839,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 917,
      "y": 599
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 881,
      "y": 628
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 41,
      "x": 28480,
      "y": 39443,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 874,
      "y": 615
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 824,
      "y": 253
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 29306,
      "y": 7849,
      "ta": "html > body"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 878,
      "y": 93
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 901,
      "y": 131
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 928,
      "y": 264
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 41,
      "x": 31047,
      "y": 9625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7575,
      "e": 7575,
      "ty": 3,
      "x": 928,
      "y": 264,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7679,
      "e": 7679,
      "ty": 4,
      "x": 31047,
      "y": 9625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7679,
      "e": 7679,
      "ty": 5,
      "x": 928,
      "y": 264,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 14251,
      "e": 12679,
      "ty": 41,
      "x": 31101,
      "y": 9625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14300,
      "e": 12728,
      "ty": 2,
      "x": 929,
      "y": 264
    },
    {
      "t": 15700,
      "e": 14128,
      "ty": 2,
      "x": 953,
      "y": 334
    },
    {
      "t": 15751,
      "e": 14179,
      "ty": 41,
      "x": 34050,
      "y": 20684,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 15800,
      "e": 14228,
      "ty": 2,
      "x": 988,
      "y": 414
    },
    {
      "t": 15901,
      "e": 14329,
      "ty": 2,
      "x": 1005,
      "y": 472
    },
    {
      "t": 16000,
      "e": 14428,
      "ty": 2,
      "x": 1008,
      "y": 711
    },
    {
      "t": 16000,
      "e": 14428,
      "ty": 41,
      "x": 35416,
      "y": 46243,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16100,
      "e": 14528,
      "ty": 2,
      "x": 1005,
      "y": 741
    },
    {
      "t": 16201,
      "e": 14629,
      "ty": 2,
      "x": 975,
      "y": 817
    },
    {
      "t": 16251,
      "e": 14679,
      "ty": 41,
      "x": 33613,
      "y": 54926,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16301,
      "e": 14729,
      "ty": 2,
      "x": 973,
      "y": 818
    },
    {
      "t": 16305,
      "e": 14733,
      "ty": 3,
      "x": 973,
      "y": 818,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16401,
      "e": 14829,
      "ty": 2,
      "x": 973,
      "y": 817
    },
    {
      "t": 16500,
      "e": 14928,
      "ty": 2,
      "x": 972,
      "y": 812
    },
    {
      "t": 16500,
      "e": 14928,
      "ty": 41,
      "x": 33450,
      "y": 54516,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16701,
      "e": 15129,
      "ty": 2,
      "x": 570,
      "y": 466
    },
    {
      "t": 16750,
      "e": 15178,
      "ty": 41,
      "x": 11441,
      "y": 25927,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16801,
      "e": 15229,
      "ty": 2,
      "x": 569,
      "y": 463
    },
    {
      "t": 16900,
      "e": 15328,
      "ty": 2,
      "x": 574,
      "y": 492
    },
    {
      "t": 17001,
      "e": 15429,
      "ty": 2,
      "x": 587,
      "y": 525
    },
    {
      "t": 17001,
      "e": 15429,
      "ty": 41,
      "x": 12424,
      "y": 31006,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17025,
      "e": 15453,
      "ty": 3,
      "x": 588,
      "y": 525,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17100,
      "e": 15528,
      "ty": 2,
      "x": 607,
      "y": 527
    },
    {
      "t": 17251,
      "e": 15679,
      "ty": 41,
      "x": 28753,
      "y": 33218,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17300,
      "e": 15728,
      "ty": 2,
      "x": 886,
      "y": 552
    },
    {
      "t": 17500,
      "e": 15928,
      "ty": 2,
      "x": 883,
      "y": 543
    },
    {
      "t": 17500,
      "e": 15928,
      "ty": 41,
      "x": 28589,
      "y": 32480,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17591,
      "e": 16019,
      "ty": 3,
      "x": 881,
      "y": 529,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17601,
      "e": 16029,
      "ty": 2,
      "x": 881,
      "y": 529
    },
    {
      "t": 17705,
      "e": 16133,
      "ty": 4,
      "x": 28480,
      "y": 31333,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17705,
      "e": 16133,
      "ty": 5,
      "x": 881,
      "y": 529,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17751,
      "e": 16179,
      "ty": 41,
      "x": 28480,
      "y": 31333,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17801,
      "e": 16229,
      "ty": 2,
      "x": 895,
      "y": 529
    },
    {
      "t": 17901,
      "e": 16329,
      "ty": 2,
      "x": 1492,
      "y": 523
    },
    {
      "t": 17967,
      "e": 16395,
      "ty": 3,
      "x": 1584,
      "y": 523,
      "ta": "html > body"
    },
    {
      "t": 18000,
      "e": 16428,
      "ty": 2,
      "x": 1584,
      "y": 523
    },
    {
      "t": 18000,
      "e": 16428,
      "ty": 41,
      "x": 54273,
      "y": 31337,
      "ta": "html > body"
    },
    {
      "t": 18079,
      "e": 16507,
      "ty": 4,
      "x": 54273,
      "y": 31337,
      "ta": "html > body"
    },
    {
      "t": 18079,
      "e": 16507,
      "ty": 5,
      "x": 1584,
      "y": 523,
      "ta": "html > body"
    },
    {
      "t": 18250,
      "e": 16678,
      "ty": 41,
      "x": 53791,
      "y": 31154,
      "ta": "html > body"
    },
    {
      "t": 18301,
      "e": 16729,
      "ty": 2,
      "x": 1519,
      "y": 513
    },
    {
      "t": 18401,
      "e": 16829,
      "ty": 2,
      "x": 1384,
      "y": 504
    },
    {
      "t": 18501,
      "e": 16929,
      "ty": 2,
      "x": 1352,
      "y": 502
    },
    {
      "t": 18501,
      "e": 16929,
      "ty": 41,
      "x": 54202,
      "y": 29122,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18601,
      "e": 17029,
      "ty": 2,
      "x": 1349,
      "y": 498
    },
    {
      "t": 18750,
      "e": 17178,
      "ty": 41,
      "x": 54039,
      "y": 28794,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18801,
      "e": 17229,
      "ty": 2,
      "x": 1349,
      "y": 497
    },
    {
      "t": 19001,
      "e": 17429,
      "ty": 41,
      "x": 54039,
      "y": 28712,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19800,
      "e": 18228,
      "ty": 2,
      "x": 1348,
      "y": 496
    },
    {
      "t": 19901,
      "e": 18329,
      "ty": 2,
      "x": 1348,
      "y": 494
    },
    {
      "t": 20001,
      "e": 18429,
      "ty": 41,
      "x": 53984,
      "y": 28466,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20001,
      "e": 18429,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21001,
      "e": 19429,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 21001,
      "e": 19429,
      "ty": 2,
      "x": 1348,
      "y": 560
    },
    {
      "t": 21001,
      "e": 19429,
      "ty": 41,
      "x": 53984,
      "y": 29531,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30000,
      "e": 24429,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 46799,
      "e": 24429,
      "ty": 2,
      "x": 1374,
      "y": 551
    },
    {
      "t": 46900,
      "e": 24530,
      "ty": 2,
      "x": 1468,
      "y": 628
    },
    {
      "t": 47000,
      "e": 24630,
      "ty": 2,
      "x": 1409,
      "y": 686
    },
    {
      "t": 47000,
      "e": 24630,
      "ty": 41,
      "x": 57315,
      "y": 39853,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47100,
      "e": 24730,
      "ty": 2,
      "x": 1406,
      "y": 686
    },
    {
      "t": 47104,
      "e": 24734,
      "ty": 3,
      "x": 1406,
      "y": 686,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47250,
      "e": 24880,
      "ty": 41,
      "x": 57151,
      "y": 39853,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47288,
      "e": 24918,
      "ty": 4,
      "x": 57151,
      "y": 39853,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 48137,
      "e": 25767,
      "ty": 3,
      "x": 1602,
      "y": 566,
      "ta": "html > body"
    },
    {
      "t": 48200,
      "e": 25830,
      "ty": 2,
      "x": 1602,
      "y": 566
    },
    {
      "t": 48250,
      "e": 25880,
      "ty": 41,
      "x": 54893,
      "y": 30911,
      "ta": "html > body"
    },
    {
      "t": 48295,
      "e": 25925,
      "ty": 4,
      "x": 54893,
      "y": 30911,
      "ta": "html > body"
    },
    {
      "t": 48295,
      "e": 25925,
      "ty": 5,
      "x": 1602,
      "y": 566,
      "ta": "html > body"
    },
    {
      "t": 48500,
      "e": 26130,
      "ty": 2,
      "x": 1570,
      "y": 571
    },
    {
      "t": 48500,
      "e": 26130,
      "ty": 41,
      "x": 53791,
      "y": 31188,
      "ta": "html > body"
    },
    {
      "t": 48567,
      "e": 26197,
      "ty": 3,
      "x": 1536,
      "y": 576,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 48600,
      "e": 26230,
      "ty": 2,
      "x": 1523,
      "y": 576
    },
    {
      "t": 48750,
      "e": 26380,
      "ty": 41,
      "x": 63541,
      "y": 30842,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 48999,
      "e": 26629,
      "ty": 2,
      "x": 884,
      "y": 582
    },
    {
      "t": 48999,
      "e": 26629,
      "ty": 41,
      "x": 28644,
      "y": 31333,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49100,
      "e": 26730,
      "ty": 2,
      "x": 717,
      "y": 561
    },
    {
      "t": 49200,
      "e": 26830,
      "ty": 2,
      "x": 540,
      "y": 553
    },
    {
      "t": 49250,
      "e": 26880,
      "ty": 41,
      "x": 9857,
      "y": 28958,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49299,
      "e": 26929,
      "ty": 2,
      "x": 567,
      "y": 548
    },
    {
      "t": 49400,
      "e": 27030,
      "ty": 2,
      "x": 796,
      "y": 544
    },
    {
      "t": 49447,
      "e": 27077,
      "ty": 3,
      "x": 800,
      "y": 544,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49500,
      "e": 27130,
      "ty": 2,
      "x": 801,
      "y": 544
    },
    {
      "t": 49500,
      "e": 27130,
      "ty": 41,
      "x": 24111,
      "y": 28221,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49558,
      "e": 27188,
      "ty": 4,
      "x": 24111,
      "y": 28221,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49558,
      "e": 27188,
      "ty": 5,
      "x": 801,
      "y": 544,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49671,
      "e": 27301,
      "ty": 3,
      "x": 801,
      "y": 544,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49767,
      "e": 27397,
      "ty": 4,
      "x": 24220,
      "y": 28221,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49767,
      "e": 27397,
      "ty": 5,
      "x": 803,
      "y": 544,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 49800,
      "e": 27430,
      "ty": 2,
      "x": 852,
      "y": 629
    },
    {
      "t": 49900,
      "e": 27530,
      "ty": 2,
      "x": 984,
      "y": 950
    },
    {
      "t": 50000,
      "e": 27630,
      "ty": 2,
      "x": 943,
      "y": 983
    },
    {
      "t": 50000,
      "e": 27630,
      "ty": 41,
      "x": 31866,
      "y": 64183,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50100,
      "e": 27730,
      "ty": 2,
      "x": 922,
      "y": 934
    },
    {
      "t": 50200,
      "e": 27830,
      "ty": 2,
      "x": 911,
      "y": 868
    },
    {
      "t": 50250,
      "e": 27880,
      "ty": 41,
      "x": 30118,
      "y": 53615,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50300,
      "e": 27930,
      "ty": 2,
      "x": 911,
      "y": 851
    },
    {
      "t": 50400,
      "e": 28030,
      "ty": 2,
      "x": 911,
      "y": 849
    },
    {
      "t": 50424,
      "e": 28054,
      "ty": 3,
      "x": 911,
      "y": 849,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50500,
      "e": 28130,
      "ty": 41,
      "x": 30118,
      "y": 53206,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50503,
      "e": 28133,
      "ty": 4,
      "x": 30118,
      "y": 53206,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50503,
      "e": 28133,
      "ty": 5,
      "x": 911,
      "y": 849,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50600,
      "e": 28230,
      "ty": 2,
      "x": 912,
      "y": 699
    },
    {
      "t": 50699,
      "e": 28329,
      "ty": 2,
      "x": 886,
      "y": 255
    },
    {
      "t": 50750,
      "e": 28380,
      "ty": 41,
      "x": 28753,
      "y": 4464,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50799,
      "e": 28429,
      "ty": 2,
      "x": 888,
      "y": 260
    },
    {
      "t": 50900,
      "e": 28530,
      "ty": 2,
      "x": 903,
      "y": 310
    },
    {
      "t": 50992,
      "e": 28622,
      "ty": 3,
      "x": 906,
      "y": 317,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 51000,
      "e": 28630,
      "ty": 2,
      "x": 906,
      "y": 317
    },
    {
      "t": 51000,
      "e": 28630,
      "ty": 41,
      "x": 29845,
      "y": 9625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 51110,
      "e": 28740,
      "ty": 4,
      "x": 29845,
      "y": 9625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 51111,
      "e": 28741,
      "ty": 5,
      "x": 906,
      "y": 317,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 51249,
      "e": 28879,
      "ty": 41,
      "x": 29845,
      "y": 9789,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 51300,
      "e": 28930,
      "ty": 2,
      "x": 906,
      "y": 319
    },
    {
      "t": 57863,
      "e": 33930,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 58948,
      "e": 33930,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 59998,
      "e": 33930,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60898,
      "e": 33930,
      "ty": 2,
      "x": 895,
      "y": 345
    },
    {
      "t": 60998,
      "e": 34030,
      "ty": 2,
      "x": 808,
      "y": 584
    },
    {
      "t": 60998,
      "e": 34030,
      "ty": 41,
      "x": 25314,
      "y": 47074,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61098,
      "e": 34130,
      "ty": 2,
      "x": 765,
      "y": 911
    },
    {
      "t": 61198,
      "e": 34230,
      "ty": 2,
      "x": 770,
      "y": 918
    },
    {
      "t": 61249,
      "e": 34281,
      "ty": 41,
      "x": 24035,
      "y": 15854,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 61298,
      "e": 34330,
      "ty": 2,
      "x": 867,
      "y": 900
    },
    {
      "t": 61398,
      "e": 34430,
      "ty": 2,
      "x": 797,
      "y": 977
    },
    {
      "t": 61499,
      "e": 34531,
      "ty": 2,
      "x": 785,
      "y": 971
    },
    {
      "t": 61499,
      "e": 34531,
      "ty": 41,
      "x": 24182,
      "y": 58493,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61598,
      "e": 34630,
      "ty": 2,
      "x": 806,
      "y": 930
    },
    {
      "t": 61698,
      "e": 34730,
      "ty": 2,
      "x": 810,
      "y": 918
    },
    {
      "t": 61748,
      "e": 34780,
      "ty": 41,
      "x": 21503,
      "y": 13158,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 61766,
      "e": 34798,
      "ty": 3,
      "x": 810,
      "y": 915,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 61798,
      "e": 34830,
      "ty": 2,
      "x": 810,
      "y": 915
    },
    {
      "t": 61885,
      "e": 34917,
      "ty": 4,
      "x": 21503,
      "y": 13158,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 61886,
      "e": 34918,
      "ty": 5,
      "x": 810,
      "y": 915,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 61889,
      "e": 34921,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 61893,
      "e": 34925,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 61998,
      "e": 35030,
      "ty": 2,
      "x": 858,
      "y": 1005
    },
    {
      "t": 61998,
      "e": 35030,
      "ty": 41,
      "x": 27774,
      "y": 60847,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62058,
      "e": 35090,
      "ty": 6,
      "x": 939,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 62099,
      "e": 35131,
      "ty": 2,
      "x": 961,
      "y": 1089
    },
    {
      "t": 62198,
      "e": 35230,
      "ty": 2,
      "x": 962,
      "y": 1090
    },
    {
      "t": 62248,
      "e": 35280,
      "ty": 41,
      "x": 28671,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 62366,
      "e": 35398,
      "ty": 3,
      "x": 962,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 62367,
      "e": 35399,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 62371,
      "e": 35403,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 62485,
      "e": 35517,
      "ty": 4,
      "x": 28671,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 62485,
      "e": 35517,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 62486,
      "e": 35518,
      "ty": 5,
      "x": 962,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 62487,
      "e": 35519,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 62749,
      "e": 35781,
      "ty": 41,
      "x": 32681,
      "y": 59829,
      "ta": "html > body"
    },
    {
      "t": 62798,
      "e": 35830,
      "ty": 2,
      "x": 938,
      "y": 1080
    },
    {
      "t": 62898,
      "e": 35930,
      "ty": 2,
      "x": 936,
      "y": 1080
    },
    {
      "t": 62999,
      "e": 36031,
      "ty": 41,
      "x": 31958,
      "y": 59385,
      "ta": "html > body"
    },
    {
      "t": 63489,
      "e": 36521,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 66998,
      "e": 40030,
      "ty": 2,
      "x": 1837,
      "y": 784
    },
    {
      "t": 66998,
      "e": 40030,
      "ty": 41,
      "x": 62986,
      "y": 42988,
      "ta": "html > body"
    },
    {
      "t": 67099,
      "e": 40131,
      "ty": 2,
      "x": 1906,
      "y": 738
    },
    {
      "t": 67198,
      "e": 40230,
      "ty": 2,
      "x": 1323,
      "y": 449
    },
    {
      "t": 67248,
      "e": 40280,
      "ty": 41,
      "x": 54323,
      "y": 57343,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 67299,
      "e": 40331,
      "ty": 2,
      "x": 1072,
      "y": 537
    },
    {
      "t": 67396,
      "e": 40428,
      "ty": 6,
      "x": 1042,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67398,
      "e": 40430,
      "ty": 2,
      "x": 1042,
      "y": 588
    },
    {
      "t": 67412,
      "e": 40444,
      "ty": 7,
      "x": 1031,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67498,
      "e": 40530,
      "ty": 2,
      "x": 994,
      "y": 648
    },
    {
      "t": 67498,
      "e": 40530,
      "ty": 41,
      "x": 40229,
      "y": 35108,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 67598,
      "e": 40630,
      "ty": 2,
      "x": 994,
      "y": 647
    },
    {
      "t": 67698,
      "e": 40730,
      "ty": 2,
      "x": 994,
      "y": 626
    },
    {
      "t": 67749,
      "e": 40781,
      "ty": 41,
      "x": 40229,
      "y": 3523,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67799,
      "e": 40831,
      "ty": 2,
      "x": 995,
      "y": 609
    },
    {
      "t": 67949,
      "e": 40981,
      "ty": 3,
      "x": 995,
      "y": 609,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 67998,
      "e": 41030,
      "ty": 41,
      "x": 40445,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 68093,
      "e": 41125,
      "ty": 4,
      "x": 40445,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 68093,
      "e": 41125,
      "ty": 5,
      "x": 995,
      "y": 609,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 68129,
      "e": 41161,
      "ty": 6,
      "x": 995,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68198,
      "e": 41230,
      "ty": 2,
      "x": 1000,
      "y": 595
    },
    {
      "t": 68249,
      "e": 41281,
      "ty": 41,
      "x": 41527,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68333,
      "e": 41365,
      "ty": 3,
      "x": 1000,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68334,
      "e": 41366,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68461,
      "e": 41493,
      "ty": 4,
      "x": 41527,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68461,
      "e": 41493,
      "ty": 5,
      "x": 1000,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68840,
      "e": 41872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 68953,
      "e": 41985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 69281,
      "e": 42313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 69282,
      "e": 42314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69403,
      "e": 42435,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "E"
    },
    {
      "t": 69417,
      "e": 42449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "E"
    },
    {
      "t": 69610,
      "e": 42642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 69610,
      "e": 42642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69752,
      "e": 42784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "EC"
    },
    {
      "t": 69881,
      "e": 42913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 69882,
      "e": 42914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69976,
      "e": 43008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ECH"
    },
    {
      "t": 69997,
      "e": 43029,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70265,
      "e": 43297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 70266,
      "e": 43298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70393,
      "e": 43425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ECHO"
    },
    {
      "t": 71065,
      "e": 44097,
      "ty": 7,
      "x": 1013,
      "y": 614,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71098,
      "e": 44130,
      "ty": 2,
      "x": 1020,
      "y": 633
    },
    {
      "t": 71182,
      "e": 44214,
      "ty": 6,
      "x": 1051,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71198,
      "e": 44230,
      "ty": 2,
      "x": 1051,
      "y": 680
    },
    {
      "t": 71215,
      "e": 44247,
      "ty": 7,
      "x": 1057,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71248,
      "e": 44280,
      "ty": 41,
      "x": 54288,
      "y": 63420,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 71297,
      "e": 44329,
      "ty": 2,
      "x": 1060,
      "y": 707
    },
    {
      "t": 71397,
      "e": 44429,
      "ty": 2,
      "x": 1065,
      "y": 707
    },
    {
      "t": 71498,
      "e": 44530,
      "ty": 2,
      "x": 1065,
      "y": 702
    },
    {
      "t": 71498,
      "e": 44530,
      "ty": 41,
      "x": 55585,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 71532,
      "e": 44564,
      "ty": 6,
      "x": 1065,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71598,
      "e": 44630,
      "ty": 2,
      "x": 1065,
      "y": 694
    },
    {
      "t": 71693,
      "e": 44725,
      "ty": 3,
      "x": 1065,
      "y": 694,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71693,
      "e": 44725,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ECHO"
    },
    {
      "t": 71693,
      "e": 44725,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71693,
      "e": 44725,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71747,
      "e": 44779,
      "ty": 41,
      "x": 55585,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71804,
      "e": 44836,
      "ty": 4,
      "x": 55585,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71804,
      "e": 44836,
      "ty": 5,
      "x": 1065,
      "y": 694,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71928,
      "e": 44960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 72048,
      "e": 45080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 72464,
      "e": 45496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 72465,
      "e": 45497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72578,
      "e": 45610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 72745,
      "e": 45777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "98"
    },
    {
      "t": 72745,
      "e": 45777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72880,
      "e": 45912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 73033,
      "e": 46065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 73033,
      "e": 46065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73145,
      "e": 46177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 74398,
      "e": 47430,
      "ty": 2,
      "x": 1065,
      "y": 696
    },
    {
      "t": 74451,
      "e": 47483,
      "ty": 7,
      "x": 1056,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74498,
      "e": 47530,
      "ty": 2,
      "x": 1036,
      "y": 709
    },
    {
      "t": 74498,
      "e": 47530,
      "ty": 41,
      "x": 35401,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 74518,
      "e": 47550,
      "ty": 6,
      "x": 1018,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 74597,
      "e": 47629,
      "ty": 2,
      "x": 1009,
      "y": 737
    },
    {
      "t": 74748,
      "e": 47780,
      "ty": 41,
      "x": 58279,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77829,
      "e": 50861,
      "ty": 3,
      "x": 1009,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77829,
      "e": 50861,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 77830,
      "e": 50862,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77830,
      "e": 50862,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77957,
      "e": 50989,
      "ty": 4,
      "x": 58279,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77959,
      "e": 50991,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77960,
      "e": 50992,
      "ty": 5,
      "x": 1009,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77960,
      "e": 50992,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 79054,
      "e": 52086,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 79082,
      "e": 52114,
      "ty": 6,
      "x": 1009,
      "y": 737,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 79998,
      "e": 53030,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 88998,
      "e": 57114,
      "ty": 2,
      "x": 1009,
      "y": 747
    },
    {
      "t": 88998,
      "e": 57114,
      "ty": 41,
      "x": 34298,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 89009,
      "e": 57125,
      "ty": 7,
      "x": 1013,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 89009,
      "e": 57125,
      "ty": 6,
      "x": 1013,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 89025,
      "e": 57141,
      "ty": 7,
      "x": 1018,
      "y": 814,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 89098,
      "e": 57214,
      "ty": 2,
      "x": 1008,
      "y": 1001
    },
    {
      "t": 89142,
      "e": 57258,
      "ty": 6,
      "x": 969,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 89198,
      "e": 57314,
      "ty": 2,
      "x": 944,
      "y": 1096
    },
    {
      "t": 89248,
      "e": 57364,
      "ty": 41,
      "x": 16656,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 89298,
      "e": 57414,
      "ty": 2,
      "x": 932,
      "y": 1096
    },
    {
      "t": 89399,
      "e": 57515,
      "ty": 2,
      "x": 931,
      "y": 1092
    },
    {
      "t": 89498,
      "e": 57614,
      "ty": 41,
      "x": 11741,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 89898,
      "e": 58014,
      "ty": 2,
      "x": 920,
      "y": 1085
    },
    {
      "t": 89998,
      "e": 58114,
      "ty": 41,
      "x": 5734,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 97998,
      "e": 63114,
      "ty": 2,
      "x": 927,
      "y": 1086
    },
    {
      "t": 97998,
      "e": 63114,
      "ty": 41,
      "x": 9557,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 98087,
      "e": 63203,
      "ty": 7,
      "x": 963,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 98098,
      "e": 63214,
      "ty": 2,
      "x": 963,
      "y": 1109
    },
    {
      "t": 98198,
      "e": 63314,
      "ty": 2,
      "x": 975,
      "y": 1119
    },
    {
      "t": 98205,
      "e": 63321,
      "ty": 3,
      "x": 975,
      "y": 1119,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 98247,
      "e": 63363,
      "ty": 41,
      "x": 40023,
      "y": 25656,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 98332,
      "e": 63448,
      "ty": 4,
      "x": 40023,
      "y": 25656,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 98332,
      "e": 63448,
      "ty": 5,
      "x": 975,
      "y": 1119,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 98488,
      "e": 63604,
      "ty": 6,
      "x": 973,
      "y": 1102,
      "ta": "#start"
    },
    {
      "t": 98498,
      "e": 63614,
      "ty": 2,
      "x": 973,
      "y": 1102
    },
    {
      "t": 98498,
      "e": 63614,
      "ty": 41,
      "x": 34678,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 98598,
      "e": 63714,
      "ty": 2,
      "x": 973,
      "y": 1087
    },
    {
      "t": 98741,
      "e": 63857,
      "ty": 3,
      "x": 973,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 98741,
      "e": 63857,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 98748,
      "e": 63864,
      "ty": 41,
      "x": 34678,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 98844,
      "e": 63960,
      "ty": 4,
      "x": 34678,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 98845,
      "e": 63961,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 98845,
      "e": 63961,
      "ty": 5,
      "x": 973,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 98846,
      "e": 63962,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 99846,
      "e": 64962,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 99998,
      "e": 65114,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 116598,
      "e": 68961,
      "ty": 2,
      "x": 995,
      "y": 1053
    },
    {
      "t": 116698,
      "e": 69061,
      "ty": 2,
      "x": 1012,
      "y": 999
    },
    {
      "t": 116748,
      "e": 69111,
      "ty": 41,
      "x": 34575,
      "y": 54898,
      "ta": "html > body"
    },
    {
      "t": 116898,
      "e": 69261,
      "ty": 2,
      "x": 965,
      "y": 1053
    },
    {
      "t": 116997,
      "e": 69360,
      "ty": 2,
      "x": 966,
      "y": 1047
    },
    {
      "t": 116997,
      "e": 69360,
      "ty": 41,
      "x": 32991,
      "y": 57557,
      "ta": "html > body"
    },
    {
      "t": 117099,
      "e": 69462,
      "ty": 2,
      "x": 975,
      "y": 1028
    },
    {
      "t": 117100,
      "e": 69463,
      "ty": 3,
      "x": 975,
      "y": 1028,
      "ta": "> p"
    },
    {
      "t": 117244,
      "e": 69607,
      "ty": 4,
      "x": 38257,
      "y": 47980,
      "ta": "> p"
    },
    {
      "t": 117244,
      "e": 69607,
      "ty": 5,
      "x": 975,
      "y": 1028,
      "ta": "> p"
    },
    {
      "t": 117248,
      "e": 69611,
      "ty": 41,
      "x": 38257,
      "y": 47980,
      "ta": "> p"
    },
    {
      "t": 117597,
      "e": 69960,
      "ty": 2,
      "x": 957,
      "y": 1017
    },
    {
      "t": 117748,
      "e": 70111,
      "ty": 41,
      "x": 31885,
      "y": 22235,
      "ta": "> p"
    },
    {
      "t": 118240,
      "e": 70603,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 119245,
      "e": 71608,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 141, dom: 710, initialDom: 716",
  "javascriptErrors": []
}