var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "28494af79744471f5b2afc90c1fc378b",
  "created": "2018-05-22T10:07:33.7691006-07:00",
  "lastActivity": "2018-05-22T10:09:32.8256857-07:00",
  "pageViews": [
    {
      "id": "052233559620f9cb096d09e982e97681011f3294",
      "startTime": "2018-05-22T10:07:33.7691006-07:00",
      "endTime": "2018-05-22T10:09:32.8256857-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 119245,
      "engagementTime": 71608,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 119245,
  "engagementTime": 71608,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3c445a59746687fdea052226b1544b15",
  "gdpr": false
}