var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8a2b47d08979d3dde6bb99c15f307559",
  "created": "2018-05-21T09:09:31.7589103-07:00",
  "lastActivity": "2018-05-21T09:10:36.1249103-07:00",
  "pageViews": [
    {
      "id": "0521316666cbe8208b6e9e27d260e2337cb61535",
      "startTime": "2018-05-21T09:09:31.7589103-07:00",
      "endTime": "2018-05-21T09:10:36.1249103-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 64366,
      "engagementTime": 55867,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 64366,
  "engagementTime": 55867,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Z5Z7P",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6ca62983178fc3f31777bbff3eebbc4e",
  "gdpr": false
}