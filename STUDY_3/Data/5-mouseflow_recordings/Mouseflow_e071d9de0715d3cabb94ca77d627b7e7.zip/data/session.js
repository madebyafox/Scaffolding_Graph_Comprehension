var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e071d9de0715d3cabb94ca77d627b7e7",
  "created": "2018-06-04T12:14:01.3814461-07:00",
  "lastActivity": "2018-06-04T12:14:19.6914798-07:00",
  "pageViews": [
    {
      "id": "06040171b7e854bd65d3a33e90281fcd8e9e5e32",
      "startTime": "2018-06-04T12:14:01.5884798-07:00",
      "endTime": "2018-06-04T12:14:19.6914798-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 18103,
      "engagementTime": 17303,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18103,
  "engagementTime": 17303,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1N65C",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "85c0e6f0f2ddc3507cbddba02755257f",
  "gdpr": false
}