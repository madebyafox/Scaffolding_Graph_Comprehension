var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a56536c1448d1fc08d4d306a217c7c85",
  "created": "2018-05-18T11:19:06.5323917-07:00",
  "lastActivity": "2018-05-18T11:20:45.3487411-07:00",
  "pageViews": [
    {
      "id": "05180656e3279713d7808378d7cbd2d1dadca2e1",
      "startTime": "2018-05-18T11:19:06.5747411-07:00",
      "endTime": "2018-05-18T11:20:45.3487411-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 98774,
      "engagementTime": 94119,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 98774,
  "engagementTime": 94119,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=E3YN6",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0a20633c1c5a0b89b87776bb94362534",
  "gdpr": false
}