var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9768239180fdd7c4435527723da9de5b",
  "created": "2018-05-18T11:13:02.7878641-07:00",
  "lastActivity": "2018-05-18T11:13:48.3218641-07:00",
  "pageViews": [
    {
      "id": "05180220fafda18a8fa4c07422b668329b32fad2",
      "startTime": "2018-05-18T11:13:02.7878641-07:00",
      "endTime": "2018-05-18T11:13:48.3218641-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 45534,
      "engagementTime": 40386,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 45534,
  "engagementTime": 40386,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.42",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HWJDK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5a5a70e792c5de4f938879c207bb606b",
  "gdpr": false
}