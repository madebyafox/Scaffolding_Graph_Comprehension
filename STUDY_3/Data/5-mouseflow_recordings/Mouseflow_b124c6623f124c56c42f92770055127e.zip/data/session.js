var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b124c6623f124c56c42f92770055127e",
  "created": "2018-05-18T10:17:44.9450413-07:00",
  "lastActivity": "2018-05-18T10:18:33.4228536-07:00",
  "pageViews": [
    {
      "id": "0518450086bd27247c3cb570a61be95bccf74958",
      "startTime": "2018-05-18T10:17:45.1838536-07:00",
      "endTime": "2018-05-18T10:18:33.4228536-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 48239,
      "engagementTime": 48203,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48239,
  "engagementTime": 48203,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PQN6T",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "aacbfb4f76f112a9ba195cb25427b465",
  "gdpr": false
}