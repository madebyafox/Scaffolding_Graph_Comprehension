var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f26abb87e4521b0260142ed7f2cfe72d",
  "created": "2018-05-18T11:20:50.4561264-07:00",
  "lastActivity": "2018-05-18T11:21:09.2311264-07:00",
  "pageViews": [
    {
      "id": "051851029ddea0c0c8cf7a23ad2de3440d2b9768",
      "startTime": "2018-05-18T11:20:50.4561264-07:00",
      "endTime": "2018-05-18T11:21:09.2311264-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 18775,
      "engagementTime": 18742,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18775,
  "engagementTime": 18742,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OY8PV",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "07979064dabbb4e968753581c020b9ac",
  "gdpr": false
}