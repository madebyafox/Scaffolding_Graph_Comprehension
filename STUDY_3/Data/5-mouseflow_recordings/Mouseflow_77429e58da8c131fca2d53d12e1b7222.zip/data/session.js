var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "77429e58da8c131fca2d53d12e1b7222",
  "created": "2018-05-22T14:10:12.9906736-07:00",
  "lastActivity": "2018-05-22T14:10:30.4786736-07:00",
  "pageViews": [
    {
      "id": "05221344b23e8206d36a6a3001936097ffed2e04",
      "startTime": "2018-05-22T14:10:12.9906736-07:00",
      "endTime": "2018-05-22T14:10:30.4786736-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 17488,
      "engagementTime": 14788,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17488,
  "engagementTime": 14788,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QOJ6L",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9265c85a9e2db9ebf58d6ae6508aa2b2",
  "gdpr": false
}