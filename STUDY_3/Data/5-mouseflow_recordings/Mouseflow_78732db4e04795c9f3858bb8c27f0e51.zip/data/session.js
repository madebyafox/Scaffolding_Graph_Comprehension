var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "78732db4e04795c9f3858bb8c27f0e51",
  "created": "2018-06-01T11:14:59.2593845-07:00",
  "lastActivity": "2018-06-01T11:15:23.9374126-07:00",
  "pageViews": [
    {
      "id": "06015979810d4961514ec300f94f8981dd59c9f9",
      "startTime": "2018-06-01T11:14:59.3684126-07:00",
      "endTime": "2018-06-01T11:15:23.9374126-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 24569,
      "engagementTime": 24468,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24569,
  "engagementTime": 24468,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.47",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EER58",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dcb463fd86a96a3da37db542d087a38e",
  "gdpr": false
}