var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2483e9fe888763bcd3b2b139cf3fbdea",
  "created": "2018-06-01T10:15:31.4540454-07:00",
  "lastActivity": "2018-06-01T10:16:05.4361206-07:00",
  "pageViews": [
    {
      "id": "0601317000830ec85bd0e8dcabbe3928d11043a7",
      "startTime": "2018-06-01T10:15:31.4741206-07:00",
      "endTime": "2018-06-01T10:16:05.4361206-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 33962,
      "engagementTime": 31158,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33962,
  "engagementTime": 31158,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2OEC4",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "94ef926ea9ec94b6964e29d85e9b8844",
  "gdpr": false
}