var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "544f6c28e84af2b5fe4074b3a1ecc510",
  "created": "2018-05-15T17:04:19.4962289-07:00",
  "lastActivity": "2018-05-15T17:05:30.6141539-07:00",
  "pageViews": [
    {
      "id": "051519191768b0fe0c534097300c956dcbeb093f",
      "startTime": "2018-05-15T17:04:19.7635097-07:00",
      "endTime": "2018-05-15T17:05:30.6141539-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 71017,
      "engagementTime": 68045,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 71017,
  "engagementTime": 68045,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TVQKD",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9c24a1ca87f18783999969ec7ba399ad",
  "gdpr": false
}