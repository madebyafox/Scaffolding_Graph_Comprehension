var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "effa5538baf8ac8077668dc04bc90581",
  "created": "2018-05-25T10:09:11.5427361-07:00",
  "lastActivity": "2018-05-25T10:09:42.1935446-07:00",
  "pageViews": [
    {
      "id": "05251108d40e8700839b0672d162aa01fc892ee9",
      "startTime": "2018-05-25T10:09:11.5679908-07:00",
      "endTime": "2018-05-25T10:09:42.1935446-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 30651,
      "engagementTime": 28774,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 30651,
  "engagementTime": 28774,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5QCE3",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "71f2e6a28e143a499f8cda50e9e327a5",
  "gdpr": false
}