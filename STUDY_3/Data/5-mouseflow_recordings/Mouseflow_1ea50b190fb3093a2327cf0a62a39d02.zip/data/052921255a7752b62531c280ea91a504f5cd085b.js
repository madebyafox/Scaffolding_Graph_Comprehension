var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052921255a7752b62531c280ea91a504f5cd085b"] = {
  "startTime": "2018-05-29T22:03:21.9162487Z",
  "websitePageUrl": "/",
  "visitTime": 223702,
  "engagementTime": 55687,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1055,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "1ea50b190fb3093a2327cf0a62a39d02",
    "created": "2018-05-29T22:03:21.8834807+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "fb604df18943e0837bf1dd65f6cae9c6",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1ea50b190fb3093a2327cf0a62a39d02/play"
  },
  "events": [
    {
      "t": 277,
      "e": 277,
      "ty": 14,
      "x": 0,
      "y": 1054
    },
    {
      "t": 958,
      "e": 958,
      "ty": 0,
      "x": 1920,
      "y": 1055
    },
    {
      "t": 10958,
      "e": 5958,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 35237,
      "e": 5958,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 37101,
      "e": 7822,
      "ty": 2,
      "x": 281,
      "y": 10
    },
    {
      "t": 37202,
      "e": 7923,
      "ty": 2,
      "x": 491,
      "y": 543
    },
    {
      "t": 37252,
      "e": 7973,
      "ty": 41,
      "x": 10130,
      "y": 39607,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37302,
      "e": 8023,
      "ty": 2,
      "x": 545,
      "y": 631
    },
    {
      "t": 37402,
      "e": 8123,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 37501,
      "e": 8222,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 37501,
      "e": 8222,
      "ty": 41,
      "x": 10130,
      "y": 39689,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38301,
      "e": 9022,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 38402,
      "e": 9123,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 38751,
      "e": 9472,
      "ty": 41,
      "x": 6908,
      "y": 32972,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38802,
      "e": 9523,
      "ty": 2,
      "x": 304,
      "y": 323
    },
    {
      "t": 38902,
      "e": 9623,
      "ty": 2,
      "x": 220,
      "y": 101
    },
    {
      "t": 39001,
      "e": 9722,
      "ty": 2,
      "x": 210,
      "y": 68
    },
    {
      "t": 39002,
      "e": 9723,
      "ty": 41,
      "x": 6956,
      "y": 3650,
      "ta": "html > body"
    },
    {
      "t": 39083,
      "e": 9804,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 39102,
      "e": 9823,
      "ty": 2,
      "x": 171,
      "y": 2
    },
    {
      "t": 39252,
      "e": 9973,
      "ty": 41,
      "x": 5888,
      "y": 121,
      "ta": "html"
    },
    {
      "t": 40251,
      "e": 10972,
      "ty": 41,
      "x": 2996,
      "y": 4928,
      "ta": "html > body"
    },
    {
      "t": 40301,
      "e": 11022,
      "ty": 2,
      "x": 270,
      "y": 341
    },
    {
      "t": 40401,
      "e": 11122,
      "ty": 2,
      "x": 677,
      "y": 678
    },
    {
      "t": 40501,
      "e": 11222,
      "ty": 2,
      "x": 678,
      "y": 679
    },
    {
      "t": 40501,
      "e": 11222,
      "ty": 41,
      "x": 17394,
      "y": 43621,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 46101,
      "e": 16222,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 46201,
      "e": 16322,
      "ty": 2,
      "x": 678,
      "y": 745
    },
    {
      "t": 46251,
      "e": 16372,
      "ty": 41,
      "x": 17394,
      "y": 44686,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50001,
      "e": 20122,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 188502,
      "e": 21372,
      "ty": 2,
      "x": 779,
      "y": 955
    },
    {
      "t": 188502,
      "e": 21372,
      "ty": 41,
      "x": 23887,
      "y": 57385,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 188603,
      "e": 21473,
      "ty": 2,
      "x": 782,
      "y": 1003
    },
    {
      "t": 188702,
      "e": 21572,
      "ty": 2,
      "x": 783,
      "y": 1001
    },
    {
      "t": 188753,
      "e": 21623,
      "ty": 41,
      "x": 24281,
      "y": 58908,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 188802,
      "e": 21672,
      "ty": 2,
      "x": 791,
      "y": 963
    },
    {
      "t": 188903,
      "e": 21773,
      "ty": 2,
      "x": 794,
      "y": 952
    },
    {
      "t": 189002,
      "e": 21872,
      "ty": 2,
      "x": 809,
      "y": 917
    },
    {
      "t": 189003,
      "e": 21873,
      "ty": 41,
      "x": 18226,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 189103,
      "e": 21973,
      "ty": 2,
      "x": 821,
      "y": 893
    },
    {
      "t": 189125,
      "e": 21995,
      "ty": 3,
      "x": 821,
      "y": 893,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 189235,
      "e": 22105,
      "ty": 4,
      "x": 25953,
      "y": 61291,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 189235,
      "e": 22105,
      "ty": 5,
      "x": 821,
      "y": 893,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 189253,
      "e": 22123,
      "ty": 41,
      "x": 25953,
      "y": 61291,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 189302,
      "e": 22172,
      "ty": 2,
      "x": 821,
      "y": 896
    },
    {
      "t": 189395,
      "e": 22265,
      "ty": 3,
      "x": 821,
      "y": 907,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 189403,
      "e": 22273,
      "ty": 2,
      "x": 821,
      "y": 907
    },
    {
      "t": 189492,
      "e": 22362,
      "ty": 4,
      "x": 25953,
      "y": 4554,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 189492,
      "e": 22362,
      "ty": 5,
      "x": 821,
      "y": 907,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 189503,
      "e": 22373,
      "ty": 41,
      "x": 25953,
      "y": 4554,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 189603,
      "e": 22473,
      "ty": 2,
      "x": 814,
      "y": 918
    },
    {
      "t": 189651,
      "e": 22521,
      "ty": 3,
      "x": 814,
      "y": 919,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 189703,
      "e": 22573,
      "ty": 2,
      "x": 814,
      "y": 919
    },
    {
      "t": 189715,
      "e": 22585,
      "ty": 4,
      "x": 34610,
      "y": 26265,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 189716,
      "e": 22586,
      "ty": 5,
      "x": 814,
      "y": 919,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 189719,
      "e": 22589,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 189728,
      "e": 22598,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 189752,
      "e": 22622,
      "ty": 41,
      "x": 34610,
      "y": 26265,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 189803,
      "e": 22673,
      "ty": 2,
      "x": 833,
      "y": 942
    },
    {
      "t": 189902,
      "e": 22772,
      "ty": 2,
      "x": 1085,
      "y": 1142
    },
    {
      "t": 190003,
      "e": 22873,
      "ty": 2,
      "x": 1087,
      "y": 1143
    },
    {
      "t": 190003,
      "e": 22873,
      "ty": 41,
      "x": 37158,
      "y": 62875,
      "ta": "> div.masterdiv"
    },
    {
      "t": 190103,
      "e": 22973,
      "ty": 2,
      "x": 1025,
      "y": 1130
    },
    {
      "t": 190202,
      "e": 23072,
      "ty": 2,
      "x": 981,
      "y": 1112
    },
    {
      "t": 190243,
      "e": 23113,
      "ty": 3,
      "x": 980,
      "y": 1110,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 190245,
      "e": 23115,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 190253,
      "e": 23123,
      "ty": 41,
      "x": 42363,
      "y": 20670,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 190303,
      "e": 23173,
      "ty": 2,
      "x": 979,
      "y": 1110
    },
    {
      "t": 190339,
      "e": 23209,
      "ty": 4,
      "x": 39555,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 190339,
      "e": 23209,
      "ty": 5,
      "x": 974,
      "y": 1107,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 190402,
      "e": 23272,
      "ty": 2,
      "x": 958,
      "y": 1098
    },
    {
      "t": 190476,
      "e": 23346,
      "ty": 3,
      "x": 954,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 190477,
      "e": 23347,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 190503,
      "e": 23373,
      "ty": 2,
      "x": 954,
      "y": 1096
    },
    {
      "t": 190503,
      "e": 23373,
      "ty": 41,
      "x": 24302,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 190554,
      "e": 23424,
      "ty": 4,
      "x": 24302,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 190555,
      "e": 23425,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 190557,
      "e": 23427,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 190557,
      "e": 23427,
      "ty": 5,
      "x": 954,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 191002,
      "e": 23872,
      "ty": 2,
      "x": 723,
      "y": 503
    },
    {
      "t": 191003,
      "e": 23873,
      "ty": 41,
      "x": 24622,
      "y": 27421,
      "ta": "html > body"
    },
    {
      "t": 191102,
      "e": 23972,
      "ty": 2,
      "x": 492,
      "y": 121
    },
    {
      "t": 191202,
      "e": 24072,
      "ty": 2,
      "x": 493,
      "y": 119
    },
    {
      "t": 191253,
      "e": 24123,
      "ty": 41,
      "x": 16874,
      "y": 6038,
      "ta": "html > body"
    },
    {
      "t": 191302,
      "e": 24172,
      "ty": 2,
      "x": 498,
      "y": 117
    },
    {
      "t": 191560,
      "e": 24430,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 191703,
      "e": 24573,
      "ty": 2,
      "x": 791,
      "y": 315
    },
    {
      "t": 191753,
      "e": 24623,
      "ty": 41,
      "x": 28066,
      "y": 18170,
      "ta": "html > body"
    },
    {
      "t": 191803,
      "e": 24673,
      "ty": 2,
      "x": 823,
      "y": 336
    },
    {
      "t": 192202,
      "e": 25072,
      "ty": 2,
      "x": 873,
      "y": 478
    },
    {
      "t": 192252,
      "e": 25122,
      "ty": 41,
      "x": 21765,
      "y": 30426,
      "ta": "#jspsych-survey-text-preamble > p"
    },
    {
      "t": 192303,
      "e": 25173,
      "ty": 2,
      "x": 877,
      "y": 495
    },
    {
      "t": 192403,
      "e": 25273,
      "ty": 2,
      "x": 886,
      "y": 571
    },
    {
      "t": 192454,
      "e": 25324,
      "ty": 6,
      "x": 887,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192503,
      "e": 25373,
      "ty": 2,
      "x": 887,
      "y": 596
    },
    {
      "t": 192503,
      "e": 25373,
      "ty": 41,
      "x": 17086,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192602,
      "e": 25472,
      "ty": 2,
      "x": 887,
      "y": 603
    },
    {
      "t": 192612,
      "e": 25482,
      "ty": 3,
      "x": 887,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192612,
      "e": 25482,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192690,
      "e": 25560,
      "ty": 4,
      "x": 17086,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192691,
      "e": 25561,
      "ty": 5,
      "x": 887,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 192753,
      "e": 25623,
      "ty": 41,
      "x": 17086,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 193303,
      "e": 26173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "87"
    },
    {
      "t": 193305,
      "e": 26175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 193399,
      "e": 26269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "w"
    },
    {
      "t": 193406,
      "e": 26276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 193406,
      "e": 26276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 193478,
      "e": 26348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "wi"
    },
    {
      "t": 193543,
      "e": 26413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 193544,
      "e": 26414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 193599,
      "e": 26469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "wie"
    },
    {
      "t": 193919,
      "e": 26789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 193919,
      "e": 26789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 193983,
      "e": 26853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "wiee"
    },
    {
      "t": 194151,
      "e": 27021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 194214,
      "e": 27084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "wie"
    },
    {
      "t": 194294,
      "e": 27164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 194359,
      "e": 27229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "wi"
    },
    {
      "t": 194439,
      "e": 27309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 194486,
      "e": 27356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "w"
    },
    {
      "t": 194566,
      "e": 27436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 194606,
      "e": 27476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 194687,
      "e": 27557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 194727,
      "e": 27597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 194863,
      "e": 27733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 194864,
      "e": 27734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 194911,
      "e": 27781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "s"
    },
    {
      "t": 194919,
      "e": 27789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 194919,
      "e": 27789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 194966,
      "e": 27836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "si"
    },
    {
      "t": 195056,
      "e": 27926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 195056,
      "e": 27926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 195087,
      "e": 27957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "sie"
    },
    {
      "t": 195191,
      "e": 28061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 195192,
      "e": 28062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 195238,
      "e": 28108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "sier"
    },
    {
      "t": 195318,
      "e": 28188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 195319,
      "e": 28189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 195391,
      "e": 28261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 195528,
      "e": 28262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 195531,
      "e": 28265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 195606,
      "e": 28340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||a"
    },
    {
      "t": 195735,
      "e": 28469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 195735,
      "e": 28469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "sierra"
    },
    {
      "t": 195736,
      "e": 28470,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 195736,
      "e": 28470,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 195799,
      "e": 28533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 196303,
      "e": 29037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 196304,
      "e": 29038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 196407,
      "e": 29141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 196463,
      "e": 29197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 196464,
      "e": 29198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 196550,
      "e": 29284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 196622,
      "e": 29356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 196622,
      "e": 29356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 196687,
      "e": 29421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 196807,
      "e": 29541,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 196902,
      "e": 29636,
      "ty": 2,
      "x": 887,
      "y": 606
    },
    {
      "t": 196907,
      "e": 29641,
      "ty": 7,
      "x": 887,
      "y": 616,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 196974,
      "e": 29708,
      "ty": 6,
      "x": 930,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 196989,
      "e": 29723,
      "ty": 7,
      "x": 934,
      "y": 745,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 197002,
      "e": 29736,
      "ty": 2,
      "x": 934,
      "y": 745
    },
    {
      "t": 197002,
      "e": 29736,
      "ty": 41,
      "x": 31889,
      "y": 40827,
      "ta": "html > body"
    },
    {
      "t": 197101,
      "e": 29835,
      "ty": 2,
      "x": 945,
      "y": 782
    },
    {
      "t": 197202,
      "e": 29936,
      "ty": 2,
      "x": 956,
      "y": 748
    },
    {
      "t": 197252,
      "e": 29986,
      "ty": 41,
      "x": 32681,
      "y": 40883,
      "ta": "html > body"
    },
    {
      "t": 197302,
      "e": 30036,
      "ty": 2,
      "x": 957,
      "y": 744
    },
    {
      "t": 197374,
      "e": 30108,
      "ty": 6,
      "x": 959,
      "y": 739,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 197402,
      "e": 30136,
      "ty": 2,
      "x": 959,
      "y": 734
    },
    {
      "t": 197503,
      "e": 30237,
      "ty": 2,
      "x": 961,
      "y": 726
    },
    {
      "t": 197503,
      "e": 30237,
      "ty": 41,
      "x": 33540,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 197602,
      "e": 30336,
      "ty": 2,
      "x": 962,
      "y": 725
    },
    {
      "t": 197702,
      "e": 30436,
      "ty": 2,
      "x": 962,
      "y": 724
    },
    {
      "t": 197752,
      "e": 30486,
      "ty": 41,
      "x": 34055,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 197903,
      "e": 30637,
      "ty": 2,
      "x": 962,
      "y": 721
    },
    {
      "t": 198003,
      "e": 30737,
      "ty": 2,
      "x": 963,
      "y": 720
    },
    {
      "t": 198003,
      "e": 30737,
      "ty": 41,
      "x": 34571,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 198348,
      "e": 31082,
      "ty": 3,
      "x": 963,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 198348,
      "e": 31082,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 198350,
      "e": 31084,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 198350,
      "e": 31084,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 198458,
      "e": 31192,
      "ty": 4,
      "x": 34571,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 198459,
      "e": 31193,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 198460,
      "e": 31194,
      "ty": 5,
      "x": 963,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 198461,
      "e": 31195,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 199562,
      "e": 32296,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 199591,
      "e": 32325,
      "ty": 6,
      "x": 963,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 200252,
      "e": 32986,
      "ty": 41,
      "x": 31815,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 200275,
      "e": 33009,
      "ty": 7,
      "x": 838,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 200275,
      "e": 33009,
      "ty": 6,
      "x": 838,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 200293,
      "e": 33027,
      "ty": 7,
      "x": 724,
      "y": 665,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 200302,
      "e": 33036,
      "ty": 2,
      "x": 724,
      "y": 665
    },
    {
      "t": 200402,
      "e": 33136,
      "ty": 2,
      "x": 190,
      "y": 507
    },
    {
      "t": 200503,
      "e": 33237,
      "ty": 2,
      "x": 165,
      "y": 496
    },
    {
      "t": 200503,
      "e": 33237,
      "ty": 41,
      "x": 5406,
      "y": 27033,
      "ta": "> div.masterdiv"
    },
    {
      "t": 200602,
      "e": 33336,
      "ty": 2,
      "x": 171,
      "y": 493
    },
    {
      "t": 200702,
      "e": 33436,
      "ty": 2,
      "x": 189,
      "y": 488
    },
    {
      "t": 200752,
      "e": 33486,
      "ty": 41,
      "x": 6508,
      "y": 26424,
      "ta": "> div.masterdiv"
    },
    {
      "t": 200803,
      "e": 33537,
      "ty": 2,
      "x": 200,
      "y": 484
    },
    {
      "t": 200903,
      "e": 33637,
      "ty": 2,
      "x": 238,
      "y": 485
    },
    {
      "t": 200977,
      "e": 33711,
      "ty": 6,
      "x": 295,
      "y": 497,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td > a"
    },
    {
      "t": 201002,
      "e": 33736,
      "ty": 2,
      "x": 298,
      "y": 499
    },
    {
      "t": 201002,
      "e": 33736,
      "ty": 41,
      "x": 11586,
      "y": 1194,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td > a"
    },
    {
      "t": 201103,
      "e": 33837,
      "ty": 2,
      "x": 299,
      "y": 499
    },
    {
      "t": 201253,
      "e": 33987,
      "ty": 41,
      "x": 14134,
      "y": 1194,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td > a"
    },
    {
      "t": 202252,
      "e": 34986,
      "ty": 41,
      "x": 16682,
      "y": 12117,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td > a"
    },
    {
      "t": 202302,
      "e": 35036,
      "ty": 2,
      "x": 298,
      "y": 504
    },
    {
      "t": 202402,
      "e": 35136,
      "ty": 2,
      "x": 295,
      "y": 508
    },
    {
      "t": 202502,
      "e": 35236,
      "ty": 2,
      "x": 294,
      "y": 514
    },
    {
      "t": 202503,
      "e": 35237,
      "ty": 41,
      "x": 1393,
      "y": 55807,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td > a"
    },
    {
      "t": 202602,
      "e": 35336,
      "ty": 2,
      "x": 294,
      "y": 519
    },
    {
      "t": 202604,
      "e": 35338,
      "ty": 7,
      "x": 294,
      "y": 520,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td > a"
    },
    {
      "t": 202703,
      "e": 35437,
      "ty": 2,
      "x": 294,
      "y": 528
    },
    {
      "t": 202753,
      "e": 35487,
      "ty": 41,
      "x": 895,
      "y": 60872,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td"
    },
    {
      "t": 202802,
      "e": 35536,
      "ty": 2,
      "x": 295,
      "y": 538
    },
    {
      "t": 202902,
      "e": 35636,
      "ty": 2,
      "x": 296,
      "y": 542
    },
    {
      "t": 203002,
      "e": 35736,
      "ty": 2,
      "x": 296,
      "y": 543
    },
    {
      "t": 203003,
      "e": 35737,
      "ty": 41,
      "x": 125,
      "y": 32517,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 203102,
      "e": 35836,
      "ty": 2,
      "x": 296,
      "y": 544
    },
    {
      "t": 203253,
      "e": 35987,
      "ty": 41,
      "x": 125,
      "y": 33033,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 209002,
      "e": 40987,
      "ty": 2,
      "x": 301,
      "y": 544
    },
    {
      "t": 209003,
      "e": 40988,
      "ty": 41,
      "x": 371,
      "y": 33033,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 209103,
      "e": 41088,
      "ty": 2,
      "x": 308,
      "y": 543
    },
    {
      "t": 209203,
      "e": 41188,
      "ty": 2,
      "x": 312,
      "y": 542
    },
    {
      "t": 209253,
      "e": 41238,
      "ty": 41,
      "x": 1109,
      "y": 32001,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 209302,
      "e": 41287,
      "ty": 2,
      "x": 321,
      "y": 551
    },
    {
      "t": 209403,
      "e": 41388,
      "ty": 2,
      "x": 336,
      "y": 588
    },
    {
      "t": 209503,
      "e": 41488,
      "ty": 2,
      "x": 368,
      "y": 641
    },
    {
      "t": 209504,
      "e": 41489,
      "ty": 41,
      "x": 16296,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 209583,
      "e": 41568,
      "ty": 6,
      "x": 397,
      "y": 676,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 209602,
      "e": 41587,
      "ty": 2,
      "x": 404,
      "y": 682
    },
    {
      "t": 209650,
      "e": 41635,
      "ty": 7,
      "x": 420,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 209650,
      "e": 41635,
      "ty": 6,
      "x": 420,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 209703,
      "e": 41688,
      "ty": 2,
      "x": 424,
      "y": 706
    },
    {
      "t": 209752,
      "e": 41737,
      "ty": 41,
      "x": 4710,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 209802,
      "e": 41787,
      "ty": 2,
      "x": 425,
      "y": 709
    },
    {
      "t": 209902,
      "e": 41887,
      "ty": 2,
      "x": 426,
      "y": 711
    },
    {
      "t": 210003,
      "e": 41988,
      "ty": 41,
      "x": 4761,
      "y": 28122,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 210004,
      "e": 41989,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 210603,
      "e": 42588,
      "ty": 2,
      "x": 431,
      "y": 710
    },
    {
      "t": 210702,
      "e": 42687,
      "ty": 2,
      "x": 434,
      "y": 710
    },
    {
      "t": 210755,
      "e": 42740,
      "ty": 41,
      "x": 5420,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 210800,
      "e": 42785,
      "ty": 7,
      "x": 449,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 210801,
      "e": 42786,
      "ty": 6,
      "x": 449,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 210802,
      "e": 42787,
      "ty": 2,
      "x": 449,
      "y": 697
    },
    {
      "t": 210867,
      "e": 42852,
      "ty": 7,
      "x": 468,
      "y": 665,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 210903,
      "e": 42888,
      "ty": 2,
      "x": 471,
      "y": 655
    },
    {
      "t": 211003,
      "e": 42988,
      "ty": 2,
      "x": 474,
      "y": 649
    },
    {
      "t": 211003,
      "e": 42988,
      "ty": 41,
      "x": 8882,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 211903,
      "e": 43888,
      "ty": 2,
      "x": 475,
      "y": 654
    },
    {
      "t": 211951,
      "e": 43936,
      "ty": 6,
      "x": 478,
      "y": 672,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 212002,
      "e": 43987,
      "ty": 2,
      "x": 479,
      "y": 686
    },
    {
      "t": 212003,
      "e": 43988,
      "ty": 41,
      "x": 7446,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 212051,
      "e": 44036,
      "ty": 7,
      "x": 483,
      "y": 702,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 212052,
      "e": 44037,
      "ty": 6,
      "x": 483,
      "y": 702,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 212103,
      "e": 44088,
      "ty": 2,
      "x": 493,
      "y": 724
    },
    {
      "t": 212118,
      "e": 44103,
      "ty": 7,
      "x": 500,
      "y": 733,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 212118,
      "e": 44103,
      "ty": 6,
      "x": 500,
      "y": 733,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 212168,
      "e": 44153,
      "ty": 7,
      "x": 515,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 212168,
      "e": 44153,
      "ty": 6,
      "x": 515,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 212202,
      "e": 44187,
      "ty": 2,
      "x": 521,
      "y": 763
    },
    {
      "t": 212252,
      "e": 44237,
      "ty": 41,
      "x": 9929,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 212302,
      "e": 44287,
      "ty": 2,
      "x": 536,
      "y": 778
    },
    {
      "t": 212317,
      "e": 44302,
      "ty": 7,
      "x": 540,
      "y": 783,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 212402,
      "e": 44387,
      "ty": 2,
      "x": 576,
      "y": 831
    },
    {
      "t": 212503,
      "e": 44488,
      "ty": 2,
      "x": 621,
      "y": 880
    },
    {
      "t": 212504,
      "e": 44489,
      "ty": 41,
      "x": 16114,
      "y": 52191,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 212603,
      "e": 44588,
      "ty": 2,
      "x": 747,
      "y": 963
    },
    {
      "t": 212703,
      "e": 44688,
      "ty": 2,
      "x": 888,
      "y": 1042
    },
    {
      "t": 212753,
      "e": 44738,
      "ty": 41,
      "x": 31070,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 212803,
      "e": 44788,
      "ty": 2,
      "x": 937,
      "y": 1071
    },
    {
      "t": 212817,
      "e": 44802,
      "ty": 6,
      "x": 940,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 212903,
      "e": 44888,
      "ty": 2,
      "x": 953,
      "y": 1084
    },
    {
      "t": 213003,
      "e": 44988,
      "ty": 2,
      "x": 961,
      "y": 1088
    },
    {
      "t": 213003,
      "e": 44988,
      "ty": 41,
      "x": 28125,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 213102,
      "e": 45087,
      "ty": 2,
      "x": 961,
      "y": 1089
    },
    {
      "t": 213253,
      "e": 45238,
      "ty": 41,
      "x": 28125,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 214148,
      "e": 46133,
      "ty": 3,
      "x": 961,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 214149,
      "e": 46134,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 214274,
      "e": 46259,
      "ty": 4,
      "x": 28125,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 214274,
      "e": 46259,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 214276,
      "e": 46261,
      "ty": 5,
      "x": 961,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 214278,
      "e": 46263,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 215003,
      "e": 46988,
      "ty": 2,
      "x": 922,
      "y": 995
    },
    {
      "t": 215003,
      "e": 46988,
      "ty": 41,
      "x": 31476,
      "y": 54677,
      "ta": "html > body"
    },
    {
      "t": 215102,
      "e": 47087,
      "ty": 2,
      "x": 773,
      "y": 437
    },
    {
      "t": 215202,
      "e": 47187,
      "ty": 2,
      "x": 731,
      "y": 272
    },
    {
      "t": 215254,
      "e": 47239,
      "ty": 41,
      "x": 24898,
      "y": 14569,
      "ta": "html > body"
    },
    {
      "t": 215278,
      "e": 47263,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 215302,
      "e": 47287,
      "ty": 2,
      "x": 731,
      "y": 271
    },
    {
      "t": 215703,
      "e": 47688,
      "ty": 2,
      "x": 730,
      "y": 274
    },
    {
      "t": 215753,
      "e": 47738,
      "ty": 41,
      "x": 21335,
      "y": 12617,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 215803,
      "e": 47788,
      "ty": 2,
      "x": 719,
      "y": 362
    },
    {
      "t": 215904,
      "e": 47889,
      "ty": 2,
      "x": 772,
      "y": 590
    },
    {
      "t": 216003,
      "e": 47988,
      "ty": 2,
      "x": 865,
      "y": 885
    },
    {
      "t": 216004,
      "e": 47989,
      "ty": 41,
      "x": 28180,
      "y": 57420,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 216103,
      "e": 48088,
      "ty": 2,
      "x": 896,
      "y": 937
    },
    {
      "t": 216253,
      "e": 48238,
      "ty": 41,
      "x": 29684,
      "y": 61458,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 216603,
      "e": 48588,
      "ty": 2,
      "x": 890,
      "y": 909
    },
    {
      "t": 216702,
      "e": 48687,
      "ty": 2,
      "x": 886,
      "y": 891
    },
    {
      "t": 216752,
      "e": 48737,
      "ty": 41,
      "x": 29199,
      "y": 57886,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 216902,
      "e": 48887,
      "ty": 2,
      "x": 880,
      "y": 820
    },
    {
      "t": 217002,
      "e": 48987,
      "ty": 2,
      "x": 877,
      "y": 656
    },
    {
      "t": 217002,
      "e": 48987,
      "ty": 41,
      "x": 28762,
      "y": 39639,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 217102,
      "e": 49087,
      "ty": 2,
      "x": 876,
      "y": 656
    },
    {
      "t": 217202,
      "e": 49187,
      "ty": 2,
      "x": 874,
      "y": 656
    },
    {
      "t": 217252,
      "e": 49237,
      "ty": 41,
      "x": 28616,
      "y": 39639,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 217602,
      "e": 49587,
      "ty": 2,
      "x": 868,
      "y": 646
    },
    {
      "t": 217702,
      "e": 49687,
      "ty": 2,
      "x": 860,
      "y": 621
    },
    {
      "t": 217752,
      "e": 49737,
      "ty": 41,
      "x": 27937,
      "y": 35368,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 217802,
      "e": 49787,
      "ty": 2,
      "x": 866,
      "y": 573
    },
    {
      "t": 217902,
      "e": 49887,
      "ty": 2,
      "x": 869,
      "y": 564
    },
    {
      "t": 218002,
      "e": 49987,
      "ty": 41,
      "x": 28374,
      "y": 32495,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 220003,
      "e": 51988,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 221402,
      "e": 53387,
      "ty": 2,
      "x": 892,
      "y": 654
    },
    {
      "t": 221502,
      "e": 53487,
      "ty": 2,
      "x": 963,
      "y": 928
    },
    {
      "t": 221502,
      "e": 53487,
      "ty": 41,
      "x": 32937,
      "y": 60759,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 221602,
      "e": 53587,
      "ty": 2,
      "x": 976,
      "y": 1039
    },
    {
      "t": 221702,
      "e": 53687,
      "ty": 2,
      "x": 980,
      "y": 1091
    },
    {
      "t": 221752,
      "e": 53737,
      "ty": 41,
      "x": 33473,
      "y": 60383,
      "ta": "html > body"
    },
    {
      "t": 221803,
      "e": 53788,
      "ty": 2,
      "x": 980,
      "y": 1099
    },
    {
      "t": 221902,
      "e": 53887,
      "ty": 2,
      "x": 980,
      "y": 1098
    },
    {
      "t": 222003,
      "e": 53988,
      "ty": 2,
      "x": 981,
      "y": 1070
    },
    {
      "t": 222003,
      "e": 53988,
      "ty": 41,
      "x": 33507,
      "y": 58831,
      "ta": "html > body"
    },
    {
      "t": 222102,
      "e": 54087,
      "ty": 2,
      "x": 983,
      "y": 1040
    },
    {
      "t": 222202,
      "e": 54187,
      "ty": 2,
      "x": 983,
      "y": 1027
    },
    {
      "t": 222253,
      "e": 54238,
      "ty": 41,
      "x": 41798,
      "y": 33937,
      "ta": "> p"
    },
    {
      "t": 222303,
      "e": 54288,
      "ty": 2,
      "x": 985,
      "y": 1022
    },
    {
      "t": 222403,
      "e": 54388,
      "ty": 2,
      "x": 1012,
      "y": 956
    },
    {
      "t": 222502,
      "e": 54487,
      "ty": 2,
      "x": 982,
      "y": 942
    },
    {
      "t": 222503,
      "e": 54488,
      "ty": 41,
      "x": 33859,
      "y": 61846,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 222695,
      "e": 54680,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 223702,
      "e": 55687,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 165, dom: 824, initialDom: 828",
  "javascriptErrors": []
}