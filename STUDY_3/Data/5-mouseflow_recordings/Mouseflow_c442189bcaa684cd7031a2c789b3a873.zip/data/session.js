var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c442189bcaa684cd7031a2c789b3a873",
  "created": "2018-05-22T10:19:55.6002074-07:00",
  "lastActivity": "2018-05-22T10:20:27.4872074-07:00",
  "pageViews": [
    {
      "id": "05225537b80c4890c6b9fd6e93b64f7e5fd45f7d",
      "startTime": "2018-05-22T10:19:55.6002074-07:00",
      "endTime": "2018-05-22T10:20:27.4872074-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 31887,
      "engagementTime": 31887,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31887,
  "engagementTime": 31887,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MOWH2",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f07514c1795f0ff2c29ce62a9d63e8c8",
  "gdpr": false
}