var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "aa3e5d6e986194c6654e24c50bf576d6",
  "created": "2018-06-04T12:15:02.615803-07:00",
  "lastActivity": "2018-06-04T12:15:39.0999771-07:00",
  "pageViews": [
    {
      "id": "060402740c6bf3c88fd18af70bd359a6c5fdb522",
      "startTime": "2018-06-04T12:15:02.6359771-07:00",
      "endTime": "2018-06-04T12:15:39.0999771-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 36464,
      "engagementTime": 33260,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36464,
  "engagementTime": 33260,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9TE89",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c396b5a34dcff6b9a5d2d593122193c6",
  "gdpr": false
}