var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ab1456e475d15cf2aeb6bd7bbc6fd399",
  "created": "2018-05-22T14:07:49.4361068-07:00",
  "lastActivity": "2018-05-22T14:09:27.4051203-07:00",
  "pageViews": [
    {
      "id": "0522491707abc9bdc1158258e875b445b7f9ba77",
      "startTime": "2018-05-22T14:07:49.4361068-07:00",
      "endTime": "2018-05-22T14:09:27.4051203-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 98280,
      "engagementTime": 97627,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 98280,
  "engagementTime": 97627,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QOJ6L",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "69c8df7aa7baff4145a9cdd65fb7a62b",
  "gdpr": false
}