var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b56e81499e477182b0d9851f66d23ea4",
  "created": "2018-05-29T10:59:35.6740267-07:00",
  "lastActivity": "2018-05-29T10:59:45.7350267-07:00",
  "pageViews": [
    {
      "id": "05293531a4076ec10c7018397ec0c94dcb18c872",
      "startTime": "2018-05-29T10:59:35.6740267-07:00",
      "endTime": "2018-05-29T10:59:45.7350267-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10061,
      "engagementTime": 10045,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10061,
  "engagementTime": 10045,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1N858",
    "CONDITION=114",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6b6198c5d78b8f2337313b5b23bf56fd",
  "gdpr": false
}