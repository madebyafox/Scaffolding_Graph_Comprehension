var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "46d40b6829400fb6a0fb9bc4751ad635",
  "created": "2018-05-15T17:09:59.2675341-07:00",
  "lastActivity": "2018-05-15T17:10:31.3935719-07:00",
  "pageViews": [
    {
      "id": "051559874b6de53a51b7b710b4e9078a87653ff7",
      "startTime": "2018-05-15T17:09:59.4055719-07:00",
      "endTime": "2018-05-15T17:10:31.3935719-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 31988,
      "engagementTime": 30050,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31988,
  "engagementTime": 30050,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TVQKD",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "57d688e6ad5340008a61cf0702573e1f",
  "gdpr": false
}