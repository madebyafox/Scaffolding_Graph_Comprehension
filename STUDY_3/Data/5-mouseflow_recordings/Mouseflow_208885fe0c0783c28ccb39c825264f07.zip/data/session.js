var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "208885fe0c0783c28ccb39c825264f07",
  "created": "2018-06-01T09:17:23.3290915-07:00",
  "lastActivity": "2018-06-01T09:17:48.9313798-07:00",
  "pageViews": [
    {
      "id": "06012386bd3917563b8aae51aaaba01a638227de",
      "startTime": "2018-06-01T09:17:23.3613798-07:00",
      "endTime": "2018-06-01T09:17:48.9313798-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 25570,
      "engagementTime": 15170,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 25570,
  "engagementTime": 15170,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DZD6F",
    "CONDITION=114",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "77939cc1dff17e6d1455680dc4636ea2",
  "gdpr": false
}