var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bcb047bb38f9d0313a04c1f7d6460e37",
  "created": "2018-05-31T12:10:07.3151156-07:00",
  "lastActivity": "2018-05-31T12:10:45.6600176-07:00",
  "pageViews": [
    {
      "id": "05310769949e356ae5246c588e8ca64533a78d6a",
      "startTime": "2018-05-31T12:10:07.3151156-07:00",
      "endTime": "2018-05-31T12:10:45.6600176-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 38725,
      "engagementTime": 28478,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 38725,
  "engagementTime": 28478,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=LW2XG",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "404f2bd5a8c22561cd9169f6bafeaff1",
  "gdpr": false
}