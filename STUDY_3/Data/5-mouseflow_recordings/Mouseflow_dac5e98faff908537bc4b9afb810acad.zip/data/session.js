var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dac5e98faff908537bc4b9afb810acad",
  "created": "2018-05-18T11:17:38.5200179-07:00",
  "lastActivity": "2018-05-18T11:18:01.4790179-07:00",
  "pageViews": [
    {
      "id": "05183886143682ebb2906ff606aa5125dfccad77",
      "startTime": "2018-05-18T11:17:38.5200179-07:00",
      "endTime": "2018-05-18T11:18:01.4790179-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 22959,
      "engagementTime": 22809,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22959,
  "engagementTime": 22809,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VXAHZ",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b4cbe51af3ff142ed0a38b17b89b1156",
  "gdpr": false
}